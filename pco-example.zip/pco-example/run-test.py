#!/usr/bin/env python3
import subprocess
import argparse

# Parse command-line arguments
parser = argparse.ArgumentParser(description='Run asnets test driver with dynamic parameters.')
parser.add_argument('--oracle', default='policy_comparison_oracle(num_per_state=2)', help='Choose oracle and its parameters.')
args = parser.parse_args()

path_test_driver = "../test-drivers/asnets_test_driver.py"
path_asnet = "../policy-servers/asnets"
path_domain = "domain.pddl"
path_problem = "train-p01.pddl"
path_downward = "../fd-action-policy-testing/builds/debug/bin/downward"

command = [
    path_test_driver,
    "--asnet", path_asnet,
    "--model", "./condor-asnet-baseline7-seed-1000-000097-000001-000038-1.00-00.039.policy",
    "./condor-asnet-baseline7-seed-1000-000097-000001-000038-1.00-00.039.policy",
    "./condor-asnet-baseline7-seed-1000-000203-000003-000024-1.00-00.027.policy",
    "./condor-baseline7-seed-1000-test-score.policy",
    "--domain", path_domain,
    "--problem", path_problem,
    "--downward", path_downward,
    "--search", f"pool_fuzzer(max_steps=10000, oracle={args.oracle})"
]

with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1) as proc:
    for line in proc.stdout:
        print(line, end='')
    proc.wait()
