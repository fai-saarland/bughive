begin_version
3
end_version
begin_metric
0
end_metric
9
begin_variable
var0
-1
5
Atom arm-empty()
Atom holding(b1)
Atom holding(b2)
Atom holding(b3)
Atom holding(b4)
end_variable
begin_variable
var1
-1
5
Atom clear(b1)
Atom on(b2, b1)
Atom on(b3, b1)
Atom on(b4, b1)
<none of those>
end_variable
begin_variable
var2
-1
5
Atom clear(b2)
Atom on(b1, b2)
Atom on(b3, b2)
Atom on(b4, b2)
<none of those>
end_variable
begin_variable
var3
-1
5
Atom clear(b3)
Atom on(b1, b3)
Atom on(b2, b3)
Atom on(b4, b3)
<none of those>
end_variable
begin_variable
var4
-1
5
Atom clear(b4)
Atom on(b1, b4)
Atom on(b2, b4)
Atom on(b3, b4)
<none of those>
end_variable
begin_variable
var5
-1
2
Atom on-table(b1)
<none of those>
end_variable
begin_variable
var6
-1
2
Atom on-table(b2)
<none of those>
end_variable
begin_variable
var7
-1
2
Atom on-table(b3)
<none of those>
end_variable
begin_variable
var8
-1
2
Atom on-table(b4)
<none of those>
end_variable
0
begin_state
0
3
1
0
3
1
0
1
1
end_state
begin_goal
5
1 1
2 2
3 3
4 0
5 0
end_goal
32
begin_operator
pickup b1
0
3
0 0 0 1
0 1 0 4
0 5 0 1
1
end_operator
begin_operator
pickup b2
0
3
0 0 0 2
0 2 0 4
0 6 0 1
1
end_operator
begin_operator
pickup b3
0
3
0 0 0 3
0 3 0 4
0 7 0 1
1
end_operator
begin_operator
pickup b4
0
3
0 0 0 4
0 4 0 4
0 8 0 1
1
end_operator
begin_operator
putdown b1
0
3
0 0 1 0
0 1 -1 0
0 5 -1 0
1
end_operator
begin_operator
putdown b2
0
3
0 0 2 0
0 2 -1 0
0 6 -1 0
1
end_operator
begin_operator
putdown b3
0
3
0 0 3 0
0 3 -1 0
0 7 -1 0
1
end_operator
begin_operator
putdown b4
0
3
0 0 4 0
0 4 -1 0
0 8 -1 0
1
end_operator
begin_operator
stack b1 b2
0
3
0 0 1 0
0 1 -1 0
0 2 0 1
1
end_operator
begin_operator
stack b1 b3
0
3
0 0 1 0
0 1 -1 0
0 3 0 1
1
end_operator
begin_operator
stack b1 b4
0
3
0 0 1 0
0 1 -1 0
0 4 0 1
1
end_operator
begin_operator
stack b2 b1
0
3
0 0 2 0
0 1 0 1
0 2 -1 0
1
end_operator
begin_operator
stack b2 b3
0
3
0 0 2 0
0 2 -1 0
0 3 0 2
1
end_operator
begin_operator
stack b2 b4
0
3
0 0 2 0
0 2 -1 0
0 4 0 2
1
end_operator
begin_operator
stack b3 b1
0
3
0 0 3 0
0 1 0 2
0 3 -1 0
1
end_operator
begin_operator
stack b3 b2
0
3
0 0 3 0
0 2 0 2
0 3 -1 0
1
end_operator
begin_operator
stack b3 b4
0
3
0 0 3 0
0 3 -1 0
0 4 0 3
1
end_operator
begin_operator
stack b4 b1
0
3
0 0 4 0
0 1 0 3
0 4 -1 0
1
end_operator
begin_operator
stack b4 b2
0
3
0 0 4 0
0 2 0 3
0 4 -1 0
1
end_operator
begin_operator
stack b4 b3
0
3
0 0 4 0
0 3 0 3
0 4 -1 0
1
end_operator
begin_operator
unstack b1 b2
0
3
0 0 0 1
0 1 0 4
0 2 1 0
1
end_operator
begin_operator
unstack b1 b3
0
3
0 0 0 1
0 1 0 4
0 3 1 0
1
end_operator
begin_operator
unstack b1 b4
0
3
0 0 0 1
0 1 0 4
0 4 1 0
1
end_operator
begin_operator
unstack b2 b1
0
3
0 0 0 2
0 1 1 0
0 2 0 4
1
end_operator
begin_operator
unstack b2 b3
0
3
0 0 0 2
0 2 0 4
0 3 2 0
1
end_operator
begin_operator
unstack b2 b4
0
3
0 0 0 2
0 2 0 4
0 4 2 0
1
end_operator
begin_operator
unstack b3 b1
0
3
0 0 0 3
0 1 2 0
0 3 0 4
1
end_operator
begin_operator
unstack b3 b2
0
3
0 0 0 3
0 2 2 0
0 3 0 4
1
end_operator
begin_operator
unstack b3 b4
0
3
0 0 0 3
0 3 0 4
0 4 3 0
1
end_operator
begin_operator
unstack b4 b1
0
3
0 0 0 4
0 1 3 0
0 4 0 4
1
end_operator
begin_operator
unstack b4 b2
0
3
0 0 0 4
0 2 3 0
0 4 0 4
1
end_operator
begin_operator
unstack b4 b3
0
3
0 0 0 4
0 3 3 0
0 4 0 4
1
end_operator
0
