begin_version
3
end_version
begin_metric
1
end_metric
36
begin_variable
var0
-1
20
empty-ferry
on car1
on car10
on car11
on car12
on car13
on car14
on car15
on car16
on car17
on car18
on car19
on car2
on car3
on car4
on car5
on car6
on car7
on car8
on car9
end_variable
begin_variable
var1
-1
16
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc2
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var2
-1
16
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc2
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var3
-1
16
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc2
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var4
-1
16
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc2
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var5
-1
15
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc2
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var6
-1
16
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc2
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var7
-1
16
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc2
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
none-of-those
end_variable
begin_variable
var8
-1
16
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc2
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
none-of-those
end_variable
begin_variable
var9
-1
16
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc2
at car14 loc3
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
none-of-those
end_variable
begin_variable
var10
-1
16
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc2
at car15 loc3
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
none-of-those
end_variable
begin_variable
var11
-1
16
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc2
at car16 loc3
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
none-of-those
end_variable
begin_variable
var12
-1
16
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc2
at car17 loc3
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
none-of-those
end_variable
begin_variable
var13
-1
16
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc2
at car18 loc3
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
none-of-those
end_variable
begin_variable
var14
-1
16
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc2
at car19 loc3
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
none-of-those
end_variable
begin_variable
var15
-1
16
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc2
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var16
-1
16
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc2
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var17
-1
16
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc2
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var18
-1
16
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc2
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var19
-1
16
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc2
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var20
-1
16
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc2
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
3
9
8
11
6
8
1
10
1
2
0
7
3
2
9
5
4
1
10
1
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
end_state
begin_goal
19
1 7
2 8
3 5
4 10
6 11
7 8
8 14
9 8
10 6
11 14
12 9
13 0
14 10
15 14
16 14
17 2
18 6
19 13
20 3
end_goal
780
begin_operator
board car1 loc1
1
5 0
2
0 0 0 1
0 2 0 15
1
end_operator
begin_operator
board car1 loc10
1
5 1
2
0 0 0 1
0 2 1 15
1
end_operator
begin_operator
board car1 loc11
1
5 2
2
0 0 0 1
0 2 2 15
1
end_operator
begin_operator
board car1 loc12
1
5 3
2
0 0 0 1
0 2 3 15
1
end_operator
begin_operator
board car1 loc13
1
5 4
2
0 0 0 1
0 2 4 15
1
end_operator
begin_operator
board car1 loc14
1
5 5
2
0 0 0 1
0 2 5 15
1
end_operator
begin_operator
board car1 loc15
1
5 6
2
0 0 0 1
0 2 6 15
1
end_operator
begin_operator
board car1 loc2
1
5 7
2
0 0 0 1
0 2 7 15
1
end_operator
begin_operator
board car1 loc3
1
5 8
2
0 0 0 1
0 2 8 15
1
end_operator
begin_operator
board car1 loc4
1
5 9
2
0 0 0 1
0 2 9 15
1
end_operator
begin_operator
board car1 loc5
1
5 10
2
0 0 0 1
0 2 10 15
1
end_operator
begin_operator
board car1 loc6
1
5 11
2
0 0 0 1
0 2 11 15
1
end_operator
begin_operator
board car1 loc7
1
5 12
2
0 0 0 1
0 2 12 15
1
end_operator
begin_operator
board car1 loc8
1
5 13
2
0 0 0 1
0 2 13 15
1
end_operator
begin_operator
board car1 loc9
1
5 14
2
0 0 0 1
0 2 14 15
1
end_operator
begin_operator
board car10 loc1
1
5 0
2
0 0 0 2
0 4 0 15
1
end_operator
begin_operator
board car10 loc10
1
5 1
2
0 0 0 2
0 4 1 15
1
end_operator
begin_operator
board car10 loc11
1
5 2
2
0 0 0 2
0 4 2 15
1
end_operator
begin_operator
board car10 loc12
1
5 3
2
0 0 0 2
0 4 3 15
1
end_operator
begin_operator
board car10 loc13
1
5 4
2
0 0 0 2
0 4 4 15
1
end_operator
begin_operator
board car10 loc14
1
5 5
2
0 0 0 2
0 4 5 15
1
end_operator
begin_operator
board car10 loc15
1
5 6
2
0 0 0 2
0 4 6 15
1
end_operator
begin_operator
board car10 loc2
1
5 7
2
0 0 0 2
0 4 7 15
1
end_operator
begin_operator
board car10 loc3
1
5 8
2
0 0 0 2
0 4 8 15
1
end_operator
begin_operator
board car10 loc4
1
5 9
2
0 0 0 2
0 4 9 15
1
end_operator
begin_operator
board car10 loc5
1
5 10
2
0 0 0 2
0 4 10 15
1
end_operator
begin_operator
board car10 loc6
1
5 11
2
0 0 0 2
0 4 11 15
1
end_operator
begin_operator
board car10 loc7
1
5 12
2
0 0 0 2
0 4 12 15
1
end_operator
begin_operator
board car10 loc8
1
5 13
2
0 0 0 2
0 4 13 15
1
end_operator
begin_operator
board car10 loc9
1
5 14
2
0 0 0 2
0 4 14 15
1
end_operator
begin_operator
board car11 loc1
1
5 0
2
0 0 0 3
0 6 0 15
1
end_operator
begin_operator
board car11 loc10
1
5 1
2
0 0 0 3
0 6 1 15
1
end_operator
begin_operator
board car11 loc11
1
5 2
2
0 0 0 3
0 6 2 15
1
end_operator
begin_operator
board car11 loc12
1
5 3
2
0 0 0 3
0 6 3 15
1
end_operator
begin_operator
board car11 loc13
1
5 4
2
0 0 0 3
0 6 4 15
1
end_operator
begin_operator
board car11 loc14
1
5 5
2
0 0 0 3
0 6 5 15
1
end_operator
begin_operator
board car11 loc15
1
5 6
2
0 0 0 3
0 6 6 15
1
end_operator
begin_operator
board car11 loc2
1
5 7
2
0 0 0 3
0 6 7 15
1
end_operator
begin_operator
board car11 loc3
1
5 8
2
0 0 0 3
0 6 8 15
1
end_operator
begin_operator
board car11 loc4
1
5 9
2
0 0 0 3
0 6 9 15
1
end_operator
begin_operator
board car11 loc5
1
5 10
2
0 0 0 3
0 6 10 15
1
end_operator
begin_operator
board car11 loc6
1
5 11
2
0 0 0 3
0 6 11 15
1
end_operator
begin_operator
board car11 loc7
1
5 12
2
0 0 0 3
0 6 12 15
1
end_operator
begin_operator
board car11 loc8
1
5 13
2
0 0 0 3
0 6 13 15
1
end_operator
begin_operator
board car11 loc9
1
5 14
2
0 0 0 3
0 6 14 15
1
end_operator
begin_operator
board car12 loc1
1
5 0
2
0 0 0 4
0 7 0 15
1
end_operator
begin_operator
board car12 loc10
1
5 1
2
0 0 0 4
0 7 1 15
1
end_operator
begin_operator
board car12 loc11
1
5 2
2
0 0 0 4
0 7 2 15
1
end_operator
begin_operator
board car12 loc12
1
5 3
2
0 0 0 4
0 7 3 15
1
end_operator
begin_operator
board car12 loc13
1
5 4
2
0 0 0 4
0 7 4 15
1
end_operator
begin_operator
board car12 loc14
1
5 5
2
0 0 0 4
0 7 5 15
1
end_operator
begin_operator
board car12 loc15
1
5 6
2
0 0 0 4
0 7 6 15
1
end_operator
begin_operator
board car12 loc2
1
5 7
2
0 0 0 4
0 7 7 15
1
end_operator
begin_operator
board car12 loc3
1
5 8
2
0 0 0 4
0 7 8 15
1
end_operator
begin_operator
board car12 loc4
1
5 9
2
0 0 0 4
0 7 9 15
1
end_operator
begin_operator
board car12 loc5
1
5 10
2
0 0 0 4
0 7 10 15
1
end_operator
begin_operator
board car12 loc6
1
5 11
2
0 0 0 4
0 7 11 15
1
end_operator
begin_operator
board car12 loc7
1
5 12
2
0 0 0 4
0 7 12 15
1
end_operator
begin_operator
board car12 loc8
1
5 13
2
0 0 0 4
0 7 13 15
1
end_operator
begin_operator
board car12 loc9
1
5 14
2
0 0 0 4
0 7 14 15
1
end_operator
begin_operator
board car13 loc1
1
5 0
2
0 0 0 5
0 8 0 15
1
end_operator
begin_operator
board car13 loc10
1
5 1
2
0 0 0 5
0 8 1 15
1
end_operator
begin_operator
board car13 loc11
1
5 2
2
0 0 0 5
0 8 2 15
1
end_operator
begin_operator
board car13 loc12
1
5 3
2
0 0 0 5
0 8 3 15
1
end_operator
begin_operator
board car13 loc13
1
5 4
2
0 0 0 5
0 8 4 15
1
end_operator
begin_operator
board car13 loc14
1
5 5
2
0 0 0 5
0 8 5 15
1
end_operator
begin_operator
board car13 loc15
1
5 6
2
0 0 0 5
0 8 6 15
1
end_operator
begin_operator
board car13 loc2
1
5 7
2
0 0 0 5
0 8 7 15
1
end_operator
begin_operator
board car13 loc3
1
5 8
2
0 0 0 5
0 8 8 15
1
end_operator
begin_operator
board car13 loc4
1
5 9
2
0 0 0 5
0 8 9 15
1
end_operator
begin_operator
board car13 loc5
1
5 10
2
0 0 0 5
0 8 10 15
1
end_operator
begin_operator
board car13 loc6
1
5 11
2
0 0 0 5
0 8 11 15
1
end_operator
begin_operator
board car13 loc7
1
5 12
2
0 0 0 5
0 8 12 15
1
end_operator
begin_operator
board car13 loc8
1
5 13
2
0 0 0 5
0 8 13 15
1
end_operator
begin_operator
board car13 loc9
1
5 14
2
0 0 0 5
0 8 14 15
1
end_operator
begin_operator
board car14 loc1
1
5 0
2
0 0 0 6
0 9 0 15
1
end_operator
begin_operator
board car14 loc10
1
5 1
2
0 0 0 6
0 9 1 15
1
end_operator
begin_operator
board car14 loc11
1
5 2
2
0 0 0 6
0 9 2 15
1
end_operator
begin_operator
board car14 loc12
1
5 3
2
0 0 0 6
0 9 3 15
1
end_operator
begin_operator
board car14 loc13
1
5 4
2
0 0 0 6
0 9 4 15
1
end_operator
begin_operator
board car14 loc14
1
5 5
2
0 0 0 6
0 9 5 15
1
end_operator
begin_operator
board car14 loc15
1
5 6
2
0 0 0 6
0 9 6 15
1
end_operator
begin_operator
board car14 loc2
1
5 7
2
0 0 0 6
0 9 7 15
1
end_operator
begin_operator
board car14 loc3
1
5 8
2
0 0 0 6
0 9 8 15
1
end_operator
begin_operator
board car14 loc4
1
5 9
2
0 0 0 6
0 9 9 15
1
end_operator
begin_operator
board car14 loc5
1
5 10
2
0 0 0 6
0 9 10 15
1
end_operator
begin_operator
board car14 loc6
1
5 11
2
0 0 0 6
0 9 11 15
1
end_operator
begin_operator
board car14 loc7
1
5 12
2
0 0 0 6
0 9 12 15
1
end_operator
begin_operator
board car14 loc8
1
5 13
2
0 0 0 6
0 9 13 15
1
end_operator
begin_operator
board car14 loc9
1
5 14
2
0 0 0 6
0 9 14 15
1
end_operator
begin_operator
board car15 loc1
1
5 0
2
0 0 0 7
0 10 0 15
1
end_operator
begin_operator
board car15 loc10
1
5 1
2
0 0 0 7
0 10 1 15
1
end_operator
begin_operator
board car15 loc11
1
5 2
2
0 0 0 7
0 10 2 15
1
end_operator
begin_operator
board car15 loc12
1
5 3
2
0 0 0 7
0 10 3 15
1
end_operator
begin_operator
board car15 loc13
1
5 4
2
0 0 0 7
0 10 4 15
1
end_operator
begin_operator
board car15 loc14
1
5 5
2
0 0 0 7
0 10 5 15
1
end_operator
begin_operator
board car15 loc15
1
5 6
2
0 0 0 7
0 10 6 15
1
end_operator
begin_operator
board car15 loc2
1
5 7
2
0 0 0 7
0 10 7 15
1
end_operator
begin_operator
board car15 loc3
1
5 8
2
0 0 0 7
0 10 8 15
1
end_operator
begin_operator
board car15 loc4
1
5 9
2
0 0 0 7
0 10 9 15
1
end_operator
begin_operator
board car15 loc5
1
5 10
2
0 0 0 7
0 10 10 15
1
end_operator
begin_operator
board car15 loc6
1
5 11
2
0 0 0 7
0 10 11 15
1
end_operator
begin_operator
board car15 loc7
1
5 12
2
0 0 0 7
0 10 12 15
1
end_operator
begin_operator
board car15 loc8
1
5 13
2
0 0 0 7
0 10 13 15
1
end_operator
begin_operator
board car15 loc9
1
5 14
2
0 0 0 7
0 10 14 15
1
end_operator
begin_operator
board car16 loc1
1
5 0
2
0 0 0 8
0 11 0 15
1
end_operator
begin_operator
board car16 loc10
1
5 1
2
0 0 0 8
0 11 1 15
1
end_operator
begin_operator
board car16 loc11
1
5 2
2
0 0 0 8
0 11 2 15
1
end_operator
begin_operator
board car16 loc12
1
5 3
2
0 0 0 8
0 11 3 15
1
end_operator
begin_operator
board car16 loc13
1
5 4
2
0 0 0 8
0 11 4 15
1
end_operator
begin_operator
board car16 loc14
1
5 5
2
0 0 0 8
0 11 5 15
1
end_operator
begin_operator
board car16 loc15
1
5 6
2
0 0 0 8
0 11 6 15
1
end_operator
begin_operator
board car16 loc2
1
5 7
2
0 0 0 8
0 11 7 15
1
end_operator
begin_operator
board car16 loc3
1
5 8
2
0 0 0 8
0 11 8 15
1
end_operator
begin_operator
board car16 loc4
1
5 9
2
0 0 0 8
0 11 9 15
1
end_operator
begin_operator
board car16 loc5
1
5 10
2
0 0 0 8
0 11 10 15
1
end_operator
begin_operator
board car16 loc6
1
5 11
2
0 0 0 8
0 11 11 15
1
end_operator
begin_operator
board car16 loc7
1
5 12
2
0 0 0 8
0 11 12 15
1
end_operator
begin_operator
board car16 loc8
1
5 13
2
0 0 0 8
0 11 13 15
1
end_operator
begin_operator
board car16 loc9
1
5 14
2
0 0 0 8
0 11 14 15
1
end_operator
begin_operator
board car17 loc1
1
5 0
2
0 0 0 9
0 12 0 15
1
end_operator
begin_operator
board car17 loc10
1
5 1
2
0 0 0 9
0 12 1 15
1
end_operator
begin_operator
board car17 loc11
1
5 2
2
0 0 0 9
0 12 2 15
1
end_operator
begin_operator
board car17 loc12
1
5 3
2
0 0 0 9
0 12 3 15
1
end_operator
begin_operator
board car17 loc13
1
5 4
2
0 0 0 9
0 12 4 15
1
end_operator
begin_operator
board car17 loc14
1
5 5
2
0 0 0 9
0 12 5 15
1
end_operator
begin_operator
board car17 loc15
1
5 6
2
0 0 0 9
0 12 6 15
1
end_operator
begin_operator
board car17 loc2
1
5 7
2
0 0 0 9
0 12 7 15
1
end_operator
begin_operator
board car17 loc3
1
5 8
2
0 0 0 9
0 12 8 15
1
end_operator
begin_operator
board car17 loc4
1
5 9
2
0 0 0 9
0 12 9 15
1
end_operator
begin_operator
board car17 loc5
1
5 10
2
0 0 0 9
0 12 10 15
1
end_operator
begin_operator
board car17 loc6
1
5 11
2
0 0 0 9
0 12 11 15
1
end_operator
begin_operator
board car17 loc7
1
5 12
2
0 0 0 9
0 12 12 15
1
end_operator
begin_operator
board car17 loc8
1
5 13
2
0 0 0 9
0 12 13 15
1
end_operator
begin_operator
board car17 loc9
1
5 14
2
0 0 0 9
0 12 14 15
1
end_operator
begin_operator
board car18 loc1
1
5 0
2
0 0 0 10
0 13 0 15
1
end_operator
begin_operator
board car18 loc10
1
5 1
2
0 0 0 10
0 13 1 15
1
end_operator
begin_operator
board car18 loc11
1
5 2
2
0 0 0 10
0 13 2 15
1
end_operator
begin_operator
board car18 loc12
1
5 3
2
0 0 0 10
0 13 3 15
1
end_operator
begin_operator
board car18 loc13
1
5 4
2
0 0 0 10
0 13 4 15
1
end_operator
begin_operator
board car18 loc14
1
5 5
2
0 0 0 10
0 13 5 15
1
end_operator
begin_operator
board car18 loc15
1
5 6
2
0 0 0 10
0 13 6 15
1
end_operator
begin_operator
board car18 loc2
1
5 7
2
0 0 0 10
0 13 7 15
1
end_operator
begin_operator
board car18 loc3
1
5 8
2
0 0 0 10
0 13 8 15
1
end_operator
begin_operator
board car18 loc4
1
5 9
2
0 0 0 10
0 13 9 15
1
end_operator
begin_operator
board car18 loc5
1
5 10
2
0 0 0 10
0 13 10 15
1
end_operator
begin_operator
board car18 loc6
1
5 11
2
0 0 0 10
0 13 11 15
1
end_operator
begin_operator
board car18 loc7
1
5 12
2
0 0 0 10
0 13 12 15
1
end_operator
begin_operator
board car18 loc8
1
5 13
2
0 0 0 10
0 13 13 15
1
end_operator
begin_operator
board car18 loc9
1
5 14
2
0 0 0 10
0 13 14 15
1
end_operator
begin_operator
board car19 loc1
1
5 0
2
0 0 0 11
0 14 0 15
1
end_operator
begin_operator
board car19 loc10
1
5 1
2
0 0 0 11
0 14 1 15
1
end_operator
begin_operator
board car19 loc11
1
5 2
2
0 0 0 11
0 14 2 15
1
end_operator
begin_operator
board car19 loc12
1
5 3
2
0 0 0 11
0 14 3 15
1
end_operator
begin_operator
board car19 loc13
1
5 4
2
0 0 0 11
0 14 4 15
1
end_operator
begin_operator
board car19 loc14
1
5 5
2
0 0 0 11
0 14 5 15
1
end_operator
begin_operator
board car19 loc15
1
5 6
2
0 0 0 11
0 14 6 15
1
end_operator
begin_operator
board car19 loc2
1
5 7
2
0 0 0 11
0 14 7 15
1
end_operator
begin_operator
board car19 loc3
1
5 8
2
0 0 0 11
0 14 8 15
1
end_operator
begin_operator
board car19 loc4
1
5 9
2
0 0 0 11
0 14 9 15
1
end_operator
begin_operator
board car19 loc5
1
5 10
2
0 0 0 11
0 14 10 15
1
end_operator
begin_operator
board car19 loc6
1
5 11
2
0 0 0 11
0 14 11 15
1
end_operator
begin_operator
board car19 loc7
1
5 12
2
0 0 0 11
0 14 12 15
1
end_operator
begin_operator
board car19 loc8
1
5 13
2
0 0 0 11
0 14 13 15
1
end_operator
begin_operator
board car19 loc9
1
5 14
2
0 0 0 11
0 14 14 15
1
end_operator
begin_operator
board car2 loc1
1
5 0
2
0 0 0 12
0 15 0 15
1
end_operator
begin_operator
board car2 loc10
1
5 1
2
0 0 0 12
0 15 1 15
1
end_operator
begin_operator
board car2 loc11
1
5 2
2
0 0 0 12
0 15 2 15
1
end_operator
begin_operator
board car2 loc12
1
5 3
2
0 0 0 12
0 15 3 15
1
end_operator
begin_operator
board car2 loc13
1
5 4
2
0 0 0 12
0 15 4 15
1
end_operator
begin_operator
board car2 loc14
1
5 5
2
0 0 0 12
0 15 5 15
1
end_operator
begin_operator
board car2 loc15
1
5 6
2
0 0 0 12
0 15 6 15
1
end_operator
begin_operator
board car2 loc2
1
5 7
2
0 0 0 12
0 15 7 15
1
end_operator
begin_operator
board car2 loc3
1
5 8
2
0 0 0 12
0 15 8 15
1
end_operator
begin_operator
board car2 loc4
1
5 9
2
0 0 0 12
0 15 9 15
1
end_operator
begin_operator
board car2 loc5
1
5 10
2
0 0 0 12
0 15 10 15
1
end_operator
begin_operator
board car2 loc6
1
5 11
2
0 0 0 12
0 15 11 15
1
end_operator
begin_operator
board car2 loc7
1
5 12
2
0 0 0 12
0 15 12 15
1
end_operator
begin_operator
board car2 loc8
1
5 13
2
0 0 0 12
0 15 13 15
1
end_operator
begin_operator
board car2 loc9
1
5 14
2
0 0 0 12
0 15 14 15
1
end_operator
begin_operator
board car3 loc1
1
5 0
2
0 0 0 13
0 16 0 15
1
end_operator
begin_operator
board car3 loc10
1
5 1
2
0 0 0 13
0 16 1 15
1
end_operator
begin_operator
board car3 loc11
1
5 2
2
0 0 0 13
0 16 2 15
1
end_operator
begin_operator
board car3 loc12
1
5 3
2
0 0 0 13
0 16 3 15
1
end_operator
begin_operator
board car3 loc13
1
5 4
2
0 0 0 13
0 16 4 15
1
end_operator
begin_operator
board car3 loc14
1
5 5
2
0 0 0 13
0 16 5 15
1
end_operator
begin_operator
board car3 loc15
1
5 6
2
0 0 0 13
0 16 6 15
1
end_operator
begin_operator
board car3 loc2
1
5 7
2
0 0 0 13
0 16 7 15
1
end_operator
begin_operator
board car3 loc3
1
5 8
2
0 0 0 13
0 16 8 15
1
end_operator
begin_operator
board car3 loc4
1
5 9
2
0 0 0 13
0 16 9 15
1
end_operator
begin_operator
board car3 loc5
1
5 10
2
0 0 0 13
0 16 10 15
1
end_operator
begin_operator
board car3 loc6
1
5 11
2
0 0 0 13
0 16 11 15
1
end_operator
begin_operator
board car3 loc7
1
5 12
2
0 0 0 13
0 16 12 15
1
end_operator
begin_operator
board car3 loc8
1
5 13
2
0 0 0 13
0 16 13 15
1
end_operator
begin_operator
board car3 loc9
1
5 14
2
0 0 0 13
0 16 14 15
1
end_operator
begin_operator
board car4 loc1
1
5 0
2
0 0 0 14
0 17 0 15
1
end_operator
begin_operator
board car4 loc10
1
5 1
2
0 0 0 14
0 17 1 15
1
end_operator
begin_operator
board car4 loc11
1
5 2
2
0 0 0 14
0 17 2 15
1
end_operator
begin_operator
board car4 loc12
1
5 3
2
0 0 0 14
0 17 3 15
1
end_operator
begin_operator
board car4 loc13
1
5 4
2
0 0 0 14
0 17 4 15
1
end_operator
begin_operator
board car4 loc14
1
5 5
2
0 0 0 14
0 17 5 15
1
end_operator
begin_operator
board car4 loc15
1
5 6
2
0 0 0 14
0 17 6 15
1
end_operator
begin_operator
board car4 loc2
1
5 7
2
0 0 0 14
0 17 7 15
1
end_operator
begin_operator
board car4 loc3
1
5 8
2
0 0 0 14
0 17 8 15
1
end_operator
begin_operator
board car4 loc4
1
5 9
2
0 0 0 14
0 17 9 15
1
end_operator
begin_operator
board car4 loc5
1
5 10
2
0 0 0 14
0 17 10 15
1
end_operator
begin_operator
board car4 loc6
1
5 11
2
0 0 0 14
0 17 11 15
1
end_operator
begin_operator
board car4 loc7
1
5 12
2
0 0 0 14
0 17 12 15
1
end_operator
begin_operator
board car4 loc8
1
5 13
2
0 0 0 14
0 17 13 15
1
end_operator
begin_operator
board car4 loc9
1
5 14
2
0 0 0 14
0 17 14 15
1
end_operator
begin_operator
board car5 loc1
1
5 0
2
0 0 0 15
0 18 0 15
1
end_operator
begin_operator
board car5 loc10
1
5 1
2
0 0 0 15
0 18 1 15
1
end_operator
begin_operator
board car5 loc11
1
5 2
2
0 0 0 15
0 18 2 15
1
end_operator
begin_operator
board car5 loc12
1
5 3
2
0 0 0 15
0 18 3 15
1
end_operator
begin_operator
board car5 loc13
1
5 4
2
0 0 0 15
0 18 4 15
1
end_operator
begin_operator
board car5 loc14
1
5 5
2
0 0 0 15
0 18 5 15
1
end_operator
begin_operator
board car5 loc15
1
5 6
2
0 0 0 15
0 18 6 15
1
end_operator
begin_operator
board car5 loc2
1
5 7
2
0 0 0 15
0 18 7 15
1
end_operator
begin_operator
board car5 loc3
1
5 8
2
0 0 0 15
0 18 8 15
1
end_operator
begin_operator
board car5 loc4
1
5 9
2
0 0 0 15
0 18 9 15
1
end_operator
begin_operator
board car5 loc5
1
5 10
2
0 0 0 15
0 18 10 15
1
end_operator
begin_operator
board car5 loc6
1
5 11
2
0 0 0 15
0 18 11 15
1
end_operator
begin_operator
board car5 loc7
1
5 12
2
0 0 0 15
0 18 12 15
1
end_operator
begin_operator
board car5 loc8
1
5 13
2
0 0 0 15
0 18 13 15
1
end_operator
begin_operator
board car5 loc9
1
5 14
2
0 0 0 15
0 18 14 15
1
end_operator
begin_operator
board car6 loc1
1
5 0
2
0 0 0 16
0 19 0 15
1
end_operator
begin_operator
board car6 loc10
1
5 1
2
0 0 0 16
0 19 1 15
1
end_operator
begin_operator
board car6 loc11
1
5 2
2
0 0 0 16
0 19 2 15
1
end_operator
begin_operator
board car6 loc12
1
5 3
2
0 0 0 16
0 19 3 15
1
end_operator
begin_operator
board car6 loc13
1
5 4
2
0 0 0 16
0 19 4 15
1
end_operator
begin_operator
board car6 loc14
1
5 5
2
0 0 0 16
0 19 5 15
1
end_operator
begin_operator
board car6 loc15
1
5 6
2
0 0 0 16
0 19 6 15
1
end_operator
begin_operator
board car6 loc2
1
5 7
2
0 0 0 16
0 19 7 15
1
end_operator
begin_operator
board car6 loc3
1
5 8
2
0 0 0 16
0 19 8 15
1
end_operator
begin_operator
board car6 loc4
1
5 9
2
0 0 0 16
0 19 9 15
1
end_operator
begin_operator
board car6 loc5
1
5 10
2
0 0 0 16
0 19 10 15
1
end_operator
begin_operator
board car6 loc6
1
5 11
2
0 0 0 16
0 19 11 15
1
end_operator
begin_operator
board car6 loc7
1
5 12
2
0 0 0 16
0 19 12 15
1
end_operator
begin_operator
board car6 loc8
1
5 13
2
0 0 0 16
0 19 13 15
1
end_operator
begin_operator
board car6 loc9
1
5 14
2
0 0 0 16
0 19 14 15
1
end_operator
begin_operator
board car7 loc1
1
5 0
2
0 0 0 17
0 20 0 15
1
end_operator
begin_operator
board car7 loc10
1
5 1
2
0 0 0 17
0 20 1 15
1
end_operator
begin_operator
board car7 loc11
1
5 2
2
0 0 0 17
0 20 2 15
1
end_operator
begin_operator
board car7 loc12
1
5 3
2
0 0 0 17
0 20 3 15
1
end_operator
begin_operator
board car7 loc13
1
5 4
2
0 0 0 17
0 20 4 15
1
end_operator
begin_operator
board car7 loc14
1
5 5
2
0 0 0 17
0 20 5 15
1
end_operator
begin_operator
board car7 loc15
1
5 6
2
0 0 0 17
0 20 6 15
1
end_operator
begin_operator
board car7 loc2
1
5 7
2
0 0 0 17
0 20 7 15
1
end_operator
begin_operator
board car7 loc3
1
5 8
2
0 0 0 17
0 20 8 15
1
end_operator
begin_operator
board car7 loc4
1
5 9
2
0 0 0 17
0 20 9 15
1
end_operator
begin_operator
board car7 loc5
1
5 10
2
0 0 0 17
0 20 10 15
1
end_operator
begin_operator
board car7 loc6
1
5 11
2
0 0 0 17
0 20 11 15
1
end_operator
begin_operator
board car7 loc7
1
5 12
2
0 0 0 17
0 20 12 15
1
end_operator
begin_operator
board car7 loc8
1
5 13
2
0 0 0 17
0 20 13 15
1
end_operator
begin_operator
board car7 loc9
1
5 14
2
0 0 0 17
0 20 14 15
1
end_operator
begin_operator
board car8 loc1
1
5 0
2
0 0 0 18
0 1 0 15
1
end_operator
begin_operator
board car8 loc10
1
5 1
2
0 0 0 18
0 1 1 15
1
end_operator
begin_operator
board car8 loc11
1
5 2
2
0 0 0 18
0 1 2 15
1
end_operator
begin_operator
board car8 loc12
1
5 3
2
0 0 0 18
0 1 3 15
1
end_operator
begin_operator
board car8 loc13
1
5 4
2
0 0 0 18
0 1 4 15
1
end_operator
begin_operator
board car8 loc14
1
5 5
2
0 0 0 18
0 1 5 15
1
end_operator
begin_operator
board car8 loc15
1
5 6
2
0 0 0 18
0 1 6 15
1
end_operator
begin_operator
board car8 loc2
1
5 7
2
0 0 0 18
0 1 7 15
1
end_operator
begin_operator
board car8 loc3
1
5 8
2
0 0 0 18
0 1 8 15
1
end_operator
begin_operator
board car8 loc4
1
5 9
2
0 0 0 18
0 1 9 15
1
end_operator
begin_operator
board car8 loc5
1
5 10
2
0 0 0 18
0 1 10 15
1
end_operator
begin_operator
board car8 loc6
1
5 11
2
0 0 0 18
0 1 11 15
1
end_operator
begin_operator
board car8 loc7
1
5 12
2
0 0 0 18
0 1 12 15
1
end_operator
begin_operator
board car8 loc8
1
5 13
2
0 0 0 18
0 1 13 15
1
end_operator
begin_operator
board car8 loc9
1
5 14
2
0 0 0 18
0 1 14 15
1
end_operator
begin_operator
board car9 loc1
1
5 0
2
0 0 0 19
0 3 0 15
1
end_operator
begin_operator
board car9 loc10
1
5 1
2
0 0 0 19
0 3 1 15
1
end_operator
begin_operator
board car9 loc11
1
5 2
2
0 0 0 19
0 3 2 15
1
end_operator
begin_operator
board car9 loc12
1
5 3
2
0 0 0 19
0 3 3 15
1
end_operator
begin_operator
board car9 loc13
1
5 4
2
0 0 0 19
0 3 4 15
1
end_operator
begin_operator
board car9 loc14
1
5 5
2
0 0 0 19
0 3 5 15
1
end_operator
begin_operator
board car9 loc15
1
5 6
2
0 0 0 19
0 3 6 15
1
end_operator
begin_operator
board car9 loc2
1
5 7
2
0 0 0 19
0 3 7 15
1
end_operator
begin_operator
board car9 loc3
1
5 8
2
0 0 0 19
0 3 8 15
1
end_operator
begin_operator
board car9 loc4
1
5 9
2
0 0 0 19
0 3 9 15
1
end_operator
begin_operator
board car9 loc5
1
5 10
2
0 0 0 19
0 3 10 15
1
end_operator
begin_operator
board car9 loc6
1
5 11
2
0 0 0 19
0 3 11 15
1
end_operator
begin_operator
board car9 loc7
1
5 12
2
0 0 0 19
0 3 12 15
1
end_operator
begin_operator
board car9 loc8
1
5 13
2
0 0 0 19
0 3 13 15
1
end_operator
begin_operator
board car9 loc9
1
5 14
2
0 0 0 19
0 3 14 15
1
end_operator
begin_operator
debark car1 loc1
1
5 0
2
0 0 1 0
0 2 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
5 1
2
0 0 1 0
0 2 -1 1
1
end_operator
begin_operator
debark car1 loc11
1
5 2
2
0 0 1 0
0 2 -1 2
1
end_operator
begin_operator
debark car1 loc12
1
5 3
2
0 0 1 0
0 2 -1 3
1
end_operator
begin_operator
debark car1 loc13
1
5 4
2
0 0 1 0
0 2 -1 4
1
end_operator
begin_operator
debark car1 loc14
1
5 5
2
0 0 1 0
0 2 -1 5
1
end_operator
begin_operator
debark car1 loc15
1
5 6
2
0 0 1 0
0 2 -1 6
1
end_operator
begin_operator
debark car1 loc2
1
5 7
2
0 0 1 0
0 2 -1 7
1
end_operator
begin_operator
debark car1 loc3
1
5 8
2
0 0 1 0
0 2 -1 8
1
end_operator
begin_operator
debark car1 loc4
1
5 9
2
0 0 1 0
0 2 -1 9
1
end_operator
begin_operator
debark car1 loc5
1
5 10
2
0 0 1 0
0 2 -1 10
1
end_operator
begin_operator
debark car1 loc6
1
5 11
2
0 0 1 0
0 2 -1 11
1
end_operator
begin_operator
debark car1 loc7
1
5 12
2
0 0 1 0
0 2 -1 12
1
end_operator
begin_operator
debark car1 loc8
1
5 13
2
0 0 1 0
0 2 -1 13
1
end_operator
begin_operator
debark car1 loc9
1
5 14
2
0 0 1 0
0 2 -1 14
1
end_operator
begin_operator
debark car10 loc1
1
5 0
2
0 0 2 0
0 4 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
5 1
2
0 0 2 0
0 4 -1 1
1
end_operator
begin_operator
debark car10 loc11
1
5 2
2
0 0 2 0
0 4 -1 2
1
end_operator
begin_operator
debark car10 loc12
1
5 3
2
0 0 2 0
0 4 -1 3
1
end_operator
begin_operator
debark car10 loc13
1
5 4
2
0 0 2 0
0 4 -1 4
1
end_operator
begin_operator
debark car10 loc14
1
5 5
2
0 0 2 0
0 4 -1 5
1
end_operator
begin_operator
debark car10 loc15
1
5 6
2
0 0 2 0
0 4 -1 6
1
end_operator
begin_operator
debark car10 loc2
1
5 7
2
0 0 2 0
0 4 -1 7
1
end_operator
begin_operator
debark car10 loc3
1
5 8
2
0 0 2 0
0 4 -1 8
1
end_operator
begin_operator
debark car10 loc4
1
5 9
2
0 0 2 0
0 4 -1 9
1
end_operator
begin_operator
debark car10 loc5
1
5 10
2
0 0 2 0
0 4 -1 10
1
end_operator
begin_operator
debark car10 loc6
1
5 11
2
0 0 2 0
0 4 -1 11
1
end_operator
begin_operator
debark car10 loc7
1
5 12
2
0 0 2 0
0 4 -1 12
1
end_operator
begin_operator
debark car10 loc8
1
5 13
2
0 0 2 0
0 4 -1 13
1
end_operator
begin_operator
debark car10 loc9
1
5 14
2
0 0 2 0
0 4 -1 14
1
end_operator
begin_operator
debark car11 loc1
1
5 0
2
0 0 3 0
0 6 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
5 1
2
0 0 3 0
0 6 -1 1
1
end_operator
begin_operator
debark car11 loc11
1
5 2
2
0 0 3 0
0 6 -1 2
1
end_operator
begin_operator
debark car11 loc12
1
5 3
2
0 0 3 0
0 6 -1 3
1
end_operator
begin_operator
debark car11 loc13
1
5 4
2
0 0 3 0
0 6 -1 4
1
end_operator
begin_operator
debark car11 loc14
1
5 5
2
0 0 3 0
0 6 -1 5
1
end_operator
begin_operator
debark car11 loc15
1
5 6
2
0 0 3 0
0 6 -1 6
1
end_operator
begin_operator
debark car11 loc2
1
5 7
2
0 0 3 0
0 6 -1 7
1
end_operator
begin_operator
debark car11 loc3
1
5 8
2
0 0 3 0
0 6 -1 8
1
end_operator
begin_operator
debark car11 loc4
1
5 9
2
0 0 3 0
0 6 -1 9
1
end_operator
begin_operator
debark car11 loc5
1
5 10
2
0 0 3 0
0 6 -1 10
1
end_operator
begin_operator
debark car11 loc6
1
5 11
2
0 0 3 0
0 6 -1 11
1
end_operator
begin_operator
debark car11 loc7
1
5 12
2
0 0 3 0
0 6 -1 12
1
end_operator
begin_operator
debark car11 loc8
1
5 13
2
0 0 3 0
0 6 -1 13
1
end_operator
begin_operator
debark car11 loc9
1
5 14
2
0 0 3 0
0 6 -1 14
1
end_operator
begin_operator
debark car12 loc1
1
5 0
2
0 0 4 0
0 7 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
5 1
2
0 0 4 0
0 7 -1 1
1
end_operator
begin_operator
debark car12 loc11
1
5 2
2
0 0 4 0
0 7 -1 2
1
end_operator
begin_operator
debark car12 loc12
1
5 3
2
0 0 4 0
0 7 -1 3
1
end_operator
begin_operator
debark car12 loc13
1
5 4
2
0 0 4 0
0 7 -1 4
1
end_operator
begin_operator
debark car12 loc14
1
5 5
2
0 0 4 0
0 7 -1 5
1
end_operator
begin_operator
debark car12 loc15
1
5 6
2
0 0 4 0
0 7 -1 6
1
end_operator
begin_operator
debark car12 loc2
1
5 7
2
0 0 4 0
0 7 -1 7
1
end_operator
begin_operator
debark car12 loc3
1
5 8
2
0 0 4 0
0 7 -1 8
1
end_operator
begin_operator
debark car12 loc4
1
5 9
2
0 0 4 0
0 7 -1 9
1
end_operator
begin_operator
debark car12 loc5
1
5 10
2
0 0 4 0
0 7 -1 10
1
end_operator
begin_operator
debark car12 loc6
1
5 11
2
0 0 4 0
0 7 -1 11
1
end_operator
begin_operator
debark car12 loc7
1
5 12
2
0 0 4 0
0 7 -1 12
1
end_operator
begin_operator
debark car12 loc8
1
5 13
2
0 0 4 0
0 7 -1 13
1
end_operator
begin_operator
debark car12 loc9
1
5 14
2
0 0 4 0
0 7 -1 14
1
end_operator
begin_operator
debark car13 loc1
1
5 0
2
0 0 5 0
0 8 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
5 1
2
0 0 5 0
0 8 -1 1
1
end_operator
begin_operator
debark car13 loc11
1
5 2
2
0 0 5 0
0 8 -1 2
1
end_operator
begin_operator
debark car13 loc12
1
5 3
2
0 0 5 0
0 8 -1 3
1
end_operator
begin_operator
debark car13 loc13
1
5 4
2
0 0 5 0
0 8 -1 4
1
end_operator
begin_operator
debark car13 loc14
1
5 5
2
0 0 5 0
0 8 -1 5
1
end_operator
begin_operator
debark car13 loc15
1
5 6
2
0 0 5 0
0 8 -1 6
1
end_operator
begin_operator
debark car13 loc2
1
5 7
2
0 0 5 0
0 8 -1 7
1
end_operator
begin_operator
debark car13 loc3
1
5 8
2
0 0 5 0
0 8 -1 8
1
end_operator
begin_operator
debark car13 loc4
1
5 9
2
0 0 5 0
0 8 -1 9
1
end_operator
begin_operator
debark car13 loc5
1
5 10
2
0 0 5 0
0 8 -1 10
1
end_operator
begin_operator
debark car13 loc6
1
5 11
2
0 0 5 0
0 8 -1 11
1
end_operator
begin_operator
debark car13 loc7
1
5 12
2
0 0 5 0
0 8 -1 12
1
end_operator
begin_operator
debark car13 loc8
1
5 13
2
0 0 5 0
0 8 -1 13
1
end_operator
begin_operator
debark car13 loc9
1
5 14
2
0 0 5 0
0 8 -1 14
1
end_operator
begin_operator
debark car14 loc1
1
5 0
2
0 0 6 0
0 9 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
5 1
2
0 0 6 0
0 9 -1 1
1
end_operator
begin_operator
debark car14 loc11
1
5 2
2
0 0 6 0
0 9 -1 2
1
end_operator
begin_operator
debark car14 loc12
1
5 3
2
0 0 6 0
0 9 -1 3
1
end_operator
begin_operator
debark car14 loc13
1
5 4
2
0 0 6 0
0 9 -1 4
1
end_operator
begin_operator
debark car14 loc14
1
5 5
2
0 0 6 0
0 9 -1 5
1
end_operator
begin_operator
debark car14 loc15
1
5 6
2
0 0 6 0
0 9 -1 6
1
end_operator
begin_operator
debark car14 loc2
1
5 7
2
0 0 6 0
0 9 -1 7
1
end_operator
begin_operator
debark car14 loc3
1
5 8
2
0 0 6 0
0 9 -1 8
1
end_operator
begin_operator
debark car14 loc4
1
5 9
2
0 0 6 0
0 9 -1 9
1
end_operator
begin_operator
debark car14 loc5
1
5 10
2
0 0 6 0
0 9 -1 10
1
end_operator
begin_operator
debark car14 loc6
1
5 11
2
0 0 6 0
0 9 -1 11
1
end_operator
begin_operator
debark car14 loc7
1
5 12
2
0 0 6 0
0 9 -1 12
1
end_operator
begin_operator
debark car14 loc8
1
5 13
2
0 0 6 0
0 9 -1 13
1
end_operator
begin_operator
debark car14 loc9
1
5 14
2
0 0 6 0
0 9 -1 14
1
end_operator
begin_operator
debark car15 loc1
1
5 0
2
0 0 7 0
0 10 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
5 1
2
0 0 7 0
0 10 -1 1
1
end_operator
begin_operator
debark car15 loc11
1
5 2
2
0 0 7 0
0 10 -1 2
1
end_operator
begin_operator
debark car15 loc12
1
5 3
2
0 0 7 0
0 10 -1 3
1
end_operator
begin_operator
debark car15 loc13
1
5 4
2
0 0 7 0
0 10 -1 4
1
end_operator
begin_operator
debark car15 loc14
1
5 5
2
0 0 7 0
0 10 -1 5
1
end_operator
begin_operator
debark car15 loc15
1
5 6
2
0 0 7 0
0 10 -1 6
1
end_operator
begin_operator
debark car15 loc2
1
5 7
2
0 0 7 0
0 10 -1 7
1
end_operator
begin_operator
debark car15 loc3
1
5 8
2
0 0 7 0
0 10 -1 8
1
end_operator
begin_operator
debark car15 loc4
1
5 9
2
0 0 7 0
0 10 -1 9
1
end_operator
begin_operator
debark car15 loc5
1
5 10
2
0 0 7 0
0 10 -1 10
1
end_operator
begin_operator
debark car15 loc6
1
5 11
2
0 0 7 0
0 10 -1 11
1
end_operator
begin_operator
debark car15 loc7
1
5 12
2
0 0 7 0
0 10 -1 12
1
end_operator
begin_operator
debark car15 loc8
1
5 13
2
0 0 7 0
0 10 -1 13
1
end_operator
begin_operator
debark car15 loc9
1
5 14
2
0 0 7 0
0 10 -1 14
1
end_operator
begin_operator
debark car16 loc1
1
5 0
2
0 0 8 0
0 11 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
5 1
2
0 0 8 0
0 11 -1 1
1
end_operator
begin_operator
debark car16 loc11
1
5 2
2
0 0 8 0
0 11 -1 2
1
end_operator
begin_operator
debark car16 loc12
1
5 3
2
0 0 8 0
0 11 -1 3
1
end_operator
begin_operator
debark car16 loc13
1
5 4
2
0 0 8 0
0 11 -1 4
1
end_operator
begin_operator
debark car16 loc14
1
5 5
2
0 0 8 0
0 11 -1 5
1
end_operator
begin_operator
debark car16 loc15
1
5 6
2
0 0 8 0
0 11 -1 6
1
end_operator
begin_operator
debark car16 loc2
1
5 7
2
0 0 8 0
0 11 -1 7
1
end_operator
begin_operator
debark car16 loc3
1
5 8
2
0 0 8 0
0 11 -1 8
1
end_operator
begin_operator
debark car16 loc4
1
5 9
2
0 0 8 0
0 11 -1 9
1
end_operator
begin_operator
debark car16 loc5
1
5 10
2
0 0 8 0
0 11 -1 10
1
end_operator
begin_operator
debark car16 loc6
1
5 11
2
0 0 8 0
0 11 -1 11
1
end_operator
begin_operator
debark car16 loc7
1
5 12
2
0 0 8 0
0 11 -1 12
1
end_operator
begin_operator
debark car16 loc8
1
5 13
2
0 0 8 0
0 11 -1 13
1
end_operator
begin_operator
debark car16 loc9
1
5 14
2
0 0 8 0
0 11 -1 14
1
end_operator
begin_operator
debark car17 loc1
1
5 0
2
0 0 9 0
0 12 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
5 1
2
0 0 9 0
0 12 -1 1
1
end_operator
begin_operator
debark car17 loc11
1
5 2
2
0 0 9 0
0 12 -1 2
1
end_operator
begin_operator
debark car17 loc12
1
5 3
2
0 0 9 0
0 12 -1 3
1
end_operator
begin_operator
debark car17 loc13
1
5 4
2
0 0 9 0
0 12 -1 4
1
end_operator
begin_operator
debark car17 loc14
1
5 5
2
0 0 9 0
0 12 -1 5
1
end_operator
begin_operator
debark car17 loc15
1
5 6
2
0 0 9 0
0 12 -1 6
1
end_operator
begin_operator
debark car17 loc2
1
5 7
2
0 0 9 0
0 12 -1 7
1
end_operator
begin_operator
debark car17 loc3
1
5 8
2
0 0 9 0
0 12 -1 8
1
end_operator
begin_operator
debark car17 loc4
1
5 9
2
0 0 9 0
0 12 -1 9
1
end_operator
begin_operator
debark car17 loc5
1
5 10
2
0 0 9 0
0 12 -1 10
1
end_operator
begin_operator
debark car17 loc6
1
5 11
2
0 0 9 0
0 12 -1 11
1
end_operator
begin_operator
debark car17 loc7
1
5 12
2
0 0 9 0
0 12 -1 12
1
end_operator
begin_operator
debark car17 loc8
1
5 13
2
0 0 9 0
0 12 -1 13
1
end_operator
begin_operator
debark car17 loc9
1
5 14
2
0 0 9 0
0 12 -1 14
1
end_operator
begin_operator
debark car18 loc1
1
5 0
2
0 0 10 0
0 13 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
5 1
2
0 0 10 0
0 13 -1 1
1
end_operator
begin_operator
debark car18 loc11
1
5 2
2
0 0 10 0
0 13 -1 2
1
end_operator
begin_operator
debark car18 loc12
1
5 3
2
0 0 10 0
0 13 -1 3
1
end_operator
begin_operator
debark car18 loc13
1
5 4
2
0 0 10 0
0 13 -1 4
1
end_operator
begin_operator
debark car18 loc14
1
5 5
2
0 0 10 0
0 13 -1 5
1
end_operator
begin_operator
debark car18 loc15
1
5 6
2
0 0 10 0
0 13 -1 6
1
end_operator
begin_operator
debark car18 loc2
1
5 7
2
0 0 10 0
0 13 -1 7
1
end_operator
begin_operator
debark car18 loc3
1
5 8
2
0 0 10 0
0 13 -1 8
1
end_operator
begin_operator
debark car18 loc4
1
5 9
2
0 0 10 0
0 13 -1 9
1
end_operator
begin_operator
debark car18 loc5
1
5 10
2
0 0 10 0
0 13 -1 10
1
end_operator
begin_operator
debark car18 loc6
1
5 11
2
0 0 10 0
0 13 -1 11
1
end_operator
begin_operator
debark car18 loc7
1
5 12
2
0 0 10 0
0 13 -1 12
1
end_operator
begin_operator
debark car18 loc8
1
5 13
2
0 0 10 0
0 13 -1 13
1
end_operator
begin_operator
debark car18 loc9
1
5 14
2
0 0 10 0
0 13 -1 14
1
end_operator
begin_operator
debark car19 loc1
1
5 0
2
0 0 11 0
0 14 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
5 1
2
0 0 11 0
0 14 -1 1
1
end_operator
begin_operator
debark car19 loc11
1
5 2
2
0 0 11 0
0 14 -1 2
1
end_operator
begin_operator
debark car19 loc12
1
5 3
2
0 0 11 0
0 14 -1 3
1
end_operator
begin_operator
debark car19 loc13
1
5 4
2
0 0 11 0
0 14 -1 4
1
end_operator
begin_operator
debark car19 loc14
1
5 5
2
0 0 11 0
0 14 -1 5
1
end_operator
begin_operator
debark car19 loc15
1
5 6
2
0 0 11 0
0 14 -1 6
1
end_operator
begin_operator
debark car19 loc2
1
5 7
2
0 0 11 0
0 14 -1 7
1
end_operator
begin_operator
debark car19 loc3
1
5 8
2
0 0 11 0
0 14 -1 8
1
end_operator
begin_operator
debark car19 loc4
1
5 9
2
0 0 11 0
0 14 -1 9
1
end_operator
begin_operator
debark car19 loc5
1
5 10
2
0 0 11 0
0 14 -1 10
1
end_operator
begin_operator
debark car19 loc6
1
5 11
2
0 0 11 0
0 14 -1 11
1
end_operator
begin_operator
debark car19 loc7
1
5 12
2
0 0 11 0
0 14 -1 12
1
end_operator
begin_operator
debark car19 loc8
1
5 13
2
0 0 11 0
0 14 -1 13
1
end_operator
begin_operator
debark car19 loc9
1
5 14
2
0 0 11 0
0 14 -1 14
1
end_operator
begin_operator
debark car2 loc1
1
5 0
2
0 0 12 0
0 15 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
5 1
2
0 0 12 0
0 15 -1 1
1
end_operator
begin_operator
debark car2 loc11
1
5 2
2
0 0 12 0
0 15 -1 2
1
end_operator
begin_operator
debark car2 loc12
1
5 3
2
0 0 12 0
0 15 -1 3
1
end_operator
begin_operator
debark car2 loc13
1
5 4
2
0 0 12 0
0 15 -1 4
1
end_operator
begin_operator
debark car2 loc14
1
5 5
2
0 0 12 0
0 15 -1 5
1
end_operator
begin_operator
debark car2 loc15
1
5 6
2
0 0 12 0
0 15 -1 6
1
end_operator
begin_operator
debark car2 loc2
1
5 7
2
0 0 12 0
0 15 -1 7
1
end_operator
begin_operator
debark car2 loc3
1
5 8
2
0 0 12 0
0 15 -1 8
1
end_operator
begin_operator
debark car2 loc4
1
5 9
2
0 0 12 0
0 15 -1 9
1
end_operator
begin_operator
debark car2 loc5
1
5 10
2
0 0 12 0
0 15 -1 10
1
end_operator
begin_operator
debark car2 loc6
1
5 11
2
0 0 12 0
0 15 -1 11
1
end_operator
begin_operator
debark car2 loc7
1
5 12
2
0 0 12 0
0 15 -1 12
1
end_operator
begin_operator
debark car2 loc8
1
5 13
2
0 0 12 0
0 15 -1 13
1
end_operator
begin_operator
debark car2 loc9
1
5 14
2
0 0 12 0
0 15 -1 14
1
end_operator
begin_operator
debark car3 loc1
1
5 0
2
0 0 13 0
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
5 1
2
0 0 13 0
0 16 -1 1
1
end_operator
begin_operator
debark car3 loc11
1
5 2
2
0 0 13 0
0 16 -1 2
1
end_operator
begin_operator
debark car3 loc12
1
5 3
2
0 0 13 0
0 16 -1 3
1
end_operator
begin_operator
debark car3 loc13
1
5 4
2
0 0 13 0
0 16 -1 4
1
end_operator
begin_operator
debark car3 loc14
1
5 5
2
0 0 13 0
0 16 -1 5
1
end_operator
begin_operator
debark car3 loc15
1
5 6
2
0 0 13 0
0 16 -1 6
1
end_operator
begin_operator
debark car3 loc2
1
5 7
2
0 0 13 0
0 16 -1 7
1
end_operator
begin_operator
debark car3 loc3
1
5 8
2
0 0 13 0
0 16 -1 8
1
end_operator
begin_operator
debark car3 loc4
1
5 9
2
0 0 13 0
0 16 -1 9
1
end_operator
begin_operator
debark car3 loc5
1
5 10
2
0 0 13 0
0 16 -1 10
1
end_operator
begin_operator
debark car3 loc6
1
5 11
2
0 0 13 0
0 16 -1 11
1
end_operator
begin_operator
debark car3 loc7
1
5 12
2
0 0 13 0
0 16 -1 12
1
end_operator
begin_operator
debark car3 loc8
1
5 13
2
0 0 13 0
0 16 -1 13
1
end_operator
begin_operator
debark car3 loc9
1
5 14
2
0 0 13 0
0 16 -1 14
1
end_operator
begin_operator
debark car4 loc1
1
5 0
2
0 0 14 0
0 17 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
5 1
2
0 0 14 0
0 17 -1 1
1
end_operator
begin_operator
debark car4 loc11
1
5 2
2
0 0 14 0
0 17 -1 2
1
end_operator
begin_operator
debark car4 loc12
1
5 3
2
0 0 14 0
0 17 -1 3
1
end_operator
begin_operator
debark car4 loc13
1
5 4
2
0 0 14 0
0 17 -1 4
1
end_operator
begin_operator
debark car4 loc14
1
5 5
2
0 0 14 0
0 17 -1 5
1
end_operator
begin_operator
debark car4 loc15
1
5 6
2
0 0 14 0
0 17 -1 6
1
end_operator
begin_operator
debark car4 loc2
1
5 7
2
0 0 14 0
0 17 -1 7
1
end_operator
begin_operator
debark car4 loc3
1
5 8
2
0 0 14 0
0 17 -1 8
1
end_operator
begin_operator
debark car4 loc4
1
5 9
2
0 0 14 0
0 17 -1 9
1
end_operator
begin_operator
debark car4 loc5
1
5 10
2
0 0 14 0
0 17 -1 10
1
end_operator
begin_operator
debark car4 loc6
1
5 11
2
0 0 14 0
0 17 -1 11
1
end_operator
begin_operator
debark car4 loc7
1
5 12
2
0 0 14 0
0 17 -1 12
1
end_operator
begin_operator
debark car4 loc8
1
5 13
2
0 0 14 0
0 17 -1 13
1
end_operator
begin_operator
debark car4 loc9
1
5 14
2
0 0 14 0
0 17 -1 14
1
end_operator
begin_operator
debark car5 loc1
1
5 0
2
0 0 15 0
0 18 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
5 1
2
0 0 15 0
0 18 -1 1
1
end_operator
begin_operator
debark car5 loc11
1
5 2
2
0 0 15 0
0 18 -1 2
1
end_operator
begin_operator
debark car5 loc12
1
5 3
2
0 0 15 0
0 18 -1 3
1
end_operator
begin_operator
debark car5 loc13
1
5 4
2
0 0 15 0
0 18 -1 4
1
end_operator
begin_operator
debark car5 loc14
1
5 5
2
0 0 15 0
0 18 -1 5
1
end_operator
begin_operator
debark car5 loc15
1
5 6
2
0 0 15 0
0 18 -1 6
1
end_operator
begin_operator
debark car5 loc2
1
5 7
2
0 0 15 0
0 18 -1 7
1
end_operator
begin_operator
debark car5 loc3
1
5 8
2
0 0 15 0
0 18 -1 8
1
end_operator
begin_operator
debark car5 loc4
1
5 9
2
0 0 15 0
0 18 -1 9
1
end_operator
begin_operator
debark car5 loc5
1
5 10
2
0 0 15 0
0 18 -1 10
1
end_operator
begin_operator
debark car5 loc6
1
5 11
2
0 0 15 0
0 18 -1 11
1
end_operator
begin_operator
debark car5 loc7
1
5 12
2
0 0 15 0
0 18 -1 12
1
end_operator
begin_operator
debark car5 loc8
1
5 13
2
0 0 15 0
0 18 -1 13
1
end_operator
begin_operator
debark car5 loc9
1
5 14
2
0 0 15 0
0 18 -1 14
1
end_operator
begin_operator
debark car6 loc1
1
5 0
2
0 0 16 0
0 19 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
5 1
2
0 0 16 0
0 19 -1 1
1
end_operator
begin_operator
debark car6 loc11
1
5 2
2
0 0 16 0
0 19 -1 2
1
end_operator
begin_operator
debark car6 loc12
1
5 3
2
0 0 16 0
0 19 -1 3
1
end_operator
begin_operator
debark car6 loc13
1
5 4
2
0 0 16 0
0 19 -1 4
1
end_operator
begin_operator
debark car6 loc14
1
5 5
2
0 0 16 0
0 19 -1 5
1
end_operator
begin_operator
debark car6 loc15
1
5 6
2
0 0 16 0
0 19 -1 6
1
end_operator
begin_operator
debark car6 loc2
1
5 7
2
0 0 16 0
0 19 -1 7
1
end_operator
begin_operator
debark car6 loc3
1
5 8
2
0 0 16 0
0 19 -1 8
1
end_operator
begin_operator
debark car6 loc4
1
5 9
2
0 0 16 0
0 19 -1 9
1
end_operator
begin_operator
debark car6 loc5
1
5 10
2
0 0 16 0
0 19 -1 10
1
end_operator
begin_operator
debark car6 loc6
1
5 11
2
0 0 16 0
0 19 -1 11
1
end_operator
begin_operator
debark car6 loc7
1
5 12
2
0 0 16 0
0 19 -1 12
1
end_operator
begin_operator
debark car6 loc8
1
5 13
2
0 0 16 0
0 19 -1 13
1
end_operator
begin_operator
debark car6 loc9
1
5 14
2
0 0 16 0
0 19 -1 14
1
end_operator
begin_operator
debark car7 loc1
1
5 0
2
0 0 17 0
0 20 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
5 1
2
0 0 17 0
0 20 -1 1
1
end_operator
begin_operator
debark car7 loc11
1
5 2
2
0 0 17 0
0 20 -1 2
1
end_operator
begin_operator
debark car7 loc12
1
5 3
2
0 0 17 0
0 20 -1 3
1
end_operator
begin_operator
debark car7 loc13
1
5 4
2
0 0 17 0
0 20 -1 4
1
end_operator
begin_operator
debark car7 loc14
1
5 5
2
0 0 17 0
0 20 -1 5
1
end_operator
begin_operator
debark car7 loc15
1
5 6
2
0 0 17 0
0 20 -1 6
1
end_operator
begin_operator
debark car7 loc2
1
5 7
2
0 0 17 0
0 20 -1 7
1
end_operator
begin_operator
debark car7 loc3
1
5 8
2
0 0 17 0
0 20 -1 8
1
end_operator
begin_operator
debark car7 loc4
1
5 9
2
0 0 17 0
0 20 -1 9
1
end_operator
begin_operator
debark car7 loc5
1
5 10
2
0 0 17 0
0 20 -1 10
1
end_operator
begin_operator
debark car7 loc6
1
5 11
2
0 0 17 0
0 20 -1 11
1
end_operator
begin_operator
debark car7 loc7
1
5 12
2
0 0 17 0
0 20 -1 12
1
end_operator
begin_operator
debark car7 loc8
1
5 13
2
0 0 17 0
0 20 -1 13
1
end_operator
begin_operator
debark car7 loc9
1
5 14
2
0 0 17 0
0 20 -1 14
1
end_operator
begin_operator
debark car8 loc1
1
5 0
2
0 0 18 0
0 1 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
5 1
2
0 0 18 0
0 1 -1 1
1
end_operator
begin_operator
debark car8 loc11
1
5 2
2
0 0 18 0
0 1 -1 2
1
end_operator
begin_operator
debark car8 loc12
1
5 3
2
0 0 18 0
0 1 -1 3
1
end_operator
begin_operator
debark car8 loc13
1
5 4
2
0 0 18 0
0 1 -1 4
1
end_operator
begin_operator
debark car8 loc14
1
5 5
2
0 0 18 0
0 1 -1 5
1
end_operator
begin_operator
debark car8 loc15
1
5 6
2
0 0 18 0
0 1 -1 6
1
end_operator
begin_operator
debark car8 loc2
1
5 7
2
0 0 18 0
0 1 -1 7
1
end_operator
begin_operator
debark car8 loc3
1
5 8
2
0 0 18 0
0 1 -1 8
1
end_operator
begin_operator
debark car8 loc4
1
5 9
2
0 0 18 0
0 1 -1 9
1
end_operator
begin_operator
debark car8 loc5
1
5 10
2
0 0 18 0
0 1 -1 10
1
end_operator
begin_operator
debark car8 loc6
1
5 11
2
0 0 18 0
0 1 -1 11
1
end_operator
begin_operator
debark car8 loc7
1
5 12
2
0 0 18 0
0 1 -1 12
1
end_operator
begin_operator
debark car8 loc8
1
5 13
2
0 0 18 0
0 1 -1 13
1
end_operator
begin_operator
debark car8 loc9
1
5 14
2
0 0 18 0
0 1 -1 14
1
end_operator
begin_operator
debark car9 loc1
1
5 0
2
0 0 19 0
0 3 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
5 1
2
0 0 19 0
0 3 -1 1
1
end_operator
begin_operator
debark car9 loc11
1
5 2
2
0 0 19 0
0 3 -1 2
1
end_operator
begin_operator
debark car9 loc12
1
5 3
2
0 0 19 0
0 3 -1 3
1
end_operator
begin_operator
debark car9 loc13
1
5 4
2
0 0 19 0
0 3 -1 4
1
end_operator
begin_operator
debark car9 loc14
1
5 5
2
0 0 19 0
0 3 -1 5
1
end_operator
begin_operator
debark car9 loc15
1
5 6
2
0 0 19 0
0 3 -1 6
1
end_operator
begin_operator
debark car9 loc2
1
5 7
2
0 0 19 0
0 3 -1 7
1
end_operator
begin_operator
debark car9 loc3
1
5 8
2
0 0 19 0
0 3 -1 8
1
end_operator
begin_operator
debark car9 loc4
1
5 9
2
0 0 19 0
0 3 -1 9
1
end_operator
begin_operator
debark car9 loc5
1
5 10
2
0 0 19 0
0 3 -1 10
1
end_operator
begin_operator
debark car9 loc6
1
5 11
2
0 0 19 0
0 3 -1 11
1
end_operator
begin_operator
debark car9 loc7
1
5 12
2
0 0 19 0
0 3 -1 12
1
end_operator
begin_operator
debark car9 loc8
1
5 13
2
0 0 19 0
0 3 -1 13
1
end_operator
begin_operator
debark car9 loc9
1
5 14
2
0 0 19 0
0 3 -1 14
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 5 0 1
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 5 0 2
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 5 0 3
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 5 0 4
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 5 0 5
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 5 0 6
0 21 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 5 0 7
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 5 0 8
0 21 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 5 0 9
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 5 0 10
0 21 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 5 0 11
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 5 0 12
0 21 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 5 0 13
0 21 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 5 0 14
0 21 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 5 1 0
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 5 1 2
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 5 1 3
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 5 1 4
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 5 1 5
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 5 1 6
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 5 1 7
0 22 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 5 1 8
0 22 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 5 1 9
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 5 1 10
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 5 1 11
0 22 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 5 1 12
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 5 1 13
0 22 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 5 1 14
0 22 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 5 2 0
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 5 2 1
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 5 2 3
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 5 2 4
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 5 2 5
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 5 2 6
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 5 2 7
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 5 2 8
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 5 2 9
0 23 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 5 2 10
0 23 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 5 2 11
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 5 2 12
0 23 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 5 2 13
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 5 2 14
0 23 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 5 3 0
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 5 3 1
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 5 3 2
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 5 3 4
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 5 3 5
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 5 3 6
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 5 3 7
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 5 3 8
0 24 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 5 3 9
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 5 3 10
0 24 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 5 3 11
0 24 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 5 3 12
0 24 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 5 3 13
0 24 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 5 3 14
0 24 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 5 4 0
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 5 4 1
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 5 4 2
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 5 4 3
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 5 4 5
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 5 4 6
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 5 4 7
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 5 4 8
0 25 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 5 4 9
0 25 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 5 4 10
0 25 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 5 4 11
0 25 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 5 4 12
0 25 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 5 4 13
0 25 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 5 4 14
0 25 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 5 5 0
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 5 5 1
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 5 5 2
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 5 5 3
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 5 5 4
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 5 5 6
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 5 5 7
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 5 5 8
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 5 5 9
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 5 5 10
0 26 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 5 5 11
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 5 5 12
0 26 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 5 5 13
0 26 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 5 5 14
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 5 6 0
0 21 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 5 6 1
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 5 6 2
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 5 6 3
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 5 6 4
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 5 6 5
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 5 6 7
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 5 6 8
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 5 6 9
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 5 6 10
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 5 6 11
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 5 6 12
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 5 6 13
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 5 6 14
0 27 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 5 7 0
0 21 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 5 7 1
0 22 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 5 7 2
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 5 7 3
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 5 7 4
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 5 7 5
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 5 7 6
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 5 7 8
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 5 7 9
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 5 7 10
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 5 7 11
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 5 7 12
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 5 7 13
0 28 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 5 7 14
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 5 8 0
0 21 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 5 8 1
0 22 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 5 8 2
0 23 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 5 8 3
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 5 8 4
0 25 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 5 8 5
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 5 8 6
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 5 8 7
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 5 8 9
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 5 8 10
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 5 8 11
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 5 8 12
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 5 8 13
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 5 8 14
0 29 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 5 9 0
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 5 9 1
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 5 9 2
0 23 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 5 9 3
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 5 9 4
0 25 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 5 9 5
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 5 9 6
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 5 9 7
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 5 9 8
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 5 9 10
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 5 9 11
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 5 9 12
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 5 9 13
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 5 9 14
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 5 10 0
0 21 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 5 10 1
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 5 10 2
0 23 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 5 10 3
0 24 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 5 10 4
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 5 10 5
0 26 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 5 10 6
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 5 10 7
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 5 10 8
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 5 10 9
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 5 10 11
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 5 10 12
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 5 10 13
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 5 10 14
0 31 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 5 11 0
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 5 11 1
0 22 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 5 11 2
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 5 11 3
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 5 11 4
0 25 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 5 11 5
0 26 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 5 11 6
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 5 11 7
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 5 11 8
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 5 11 9
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 5 11 10
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 5 11 12
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 5 11 13
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 5 11 14
0 32 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 5 12 0
0 21 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 5 12 1
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 5 12 2
0 23 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 5 12 3
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 5 12 4
0 25 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 5 12 5
0 26 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 5 12 6
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 5 12 7
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 5 12 8
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 5 12 9
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 5 12 10
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 5 12 11
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 5 12 13
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 5 12 14
0 33 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 5 13 0
0 21 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 5 13 1
0 22 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 5 13 2
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 5 13 3
0 24 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 5 13 4
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 5 13 5
0 26 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 5 13 6
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 5 13 7
0 28 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 5 13 8
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 5 13 9
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 5 13 10
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 5 13 11
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 5 13 12
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 5 13 14
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 5 14 0
0 21 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 5 14 1
0 22 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 5 14 2
0 23 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 5 14 3
0 24 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 5 14 4
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 5 14 5
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 5 14 6
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 5 14 7
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 5 14 8
0 29 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 5 14 9
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 5 14 10
0 31 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 5 14 11
0 32 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 5 14 12
0 33 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 5 14 13
0 34 0 1
0 35 -1 0
1
end_operator
0
