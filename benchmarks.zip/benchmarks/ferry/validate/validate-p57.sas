begin_version
3
end_version
begin_metric
1
end_metric
23
begin_variable
var0
-1
12
empty-ferry
on car1
on car10
on car11
on car2
on car3
on car4
on car5
on car6
on car7
on car8
on car9
end_variable
begin_variable
var1
-1
11
at car1 loc1
at car1 loc10
at car1 loc2
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var2
-1
11
at car10 loc1
at car10 loc10
at car10 loc2
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var3
-1
11
at car11 loc1
at car11 loc10
at car11 loc2
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var4
-1
11
at car2 loc1
at car2 loc10
at car2 loc2
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var5
-1
11
at car3 loc1
at car3 loc10
at car3 loc2
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var6
-1
11
at car4 loc1
at car4 loc10
at car4 loc2
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var7
-1
11
at car5 loc1
at car5 loc10
at car5 loc2
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var8
-1
11
at car6 loc1
at car6 loc10
at car6 loc2
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var9
-1
11
at car7 loc1
at car7 loc10
at car7 loc2
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var10
-1
11
at car8 loc1
at car8 loc10
at car8 loc2
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var11
-1
11
at car9 loc1
at car9 loc10
at car9 loc2
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var12
-1
10
at-ferry loc1
at-ferry loc10
at-ferry loc2
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var13
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
4
0
5
9
2
5
6
9
6
2
6
3
0
0
0
1
0
0
0
0
0
0
end_state
begin_goal
11
1 8
2 3
3 6
4 2
5 9
6 1
7 2
8 4
9 5
10 4
11 1
end_goal
310
begin_operator
board car1 loc1
1
12 0
2
0 0 0 1
0 1 0 10
1
end_operator
begin_operator
board car1 loc10
1
12 1
2
0 0 0 1
0 1 1 10
1
end_operator
begin_operator
board car1 loc2
1
12 2
2
0 0 0 1
0 1 2 10
1
end_operator
begin_operator
board car1 loc3
1
12 3
2
0 0 0 1
0 1 3 10
1
end_operator
begin_operator
board car1 loc4
1
12 4
2
0 0 0 1
0 1 4 10
1
end_operator
begin_operator
board car1 loc5
1
12 5
2
0 0 0 1
0 1 5 10
1
end_operator
begin_operator
board car1 loc6
1
12 6
2
0 0 0 1
0 1 6 10
1
end_operator
begin_operator
board car1 loc7
1
12 7
2
0 0 0 1
0 1 7 10
1
end_operator
begin_operator
board car1 loc8
1
12 8
2
0 0 0 1
0 1 8 10
1
end_operator
begin_operator
board car1 loc9
1
12 9
2
0 0 0 1
0 1 9 10
1
end_operator
begin_operator
board car10 loc1
1
12 0
2
0 0 0 2
0 2 0 10
1
end_operator
begin_operator
board car10 loc10
1
12 1
2
0 0 0 2
0 2 1 10
1
end_operator
begin_operator
board car10 loc2
1
12 2
2
0 0 0 2
0 2 2 10
1
end_operator
begin_operator
board car10 loc3
1
12 3
2
0 0 0 2
0 2 3 10
1
end_operator
begin_operator
board car10 loc4
1
12 4
2
0 0 0 2
0 2 4 10
1
end_operator
begin_operator
board car10 loc5
1
12 5
2
0 0 0 2
0 2 5 10
1
end_operator
begin_operator
board car10 loc6
1
12 6
2
0 0 0 2
0 2 6 10
1
end_operator
begin_operator
board car10 loc7
1
12 7
2
0 0 0 2
0 2 7 10
1
end_operator
begin_operator
board car10 loc8
1
12 8
2
0 0 0 2
0 2 8 10
1
end_operator
begin_operator
board car10 loc9
1
12 9
2
0 0 0 2
0 2 9 10
1
end_operator
begin_operator
board car11 loc1
1
12 0
2
0 0 0 3
0 3 0 10
1
end_operator
begin_operator
board car11 loc10
1
12 1
2
0 0 0 3
0 3 1 10
1
end_operator
begin_operator
board car11 loc2
1
12 2
2
0 0 0 3
0 3 2 10
1
end_operator
begin_operator
board car11 loc3
1
12 3
2
0 0 0 3
0 3 3 10
1
end_operator
begin_operator
board car11 loc4
1
12 4
2
0 0 0 3
0 3 4 10
1
end_operator
begin_operator
board car11 loc5
1
12 5
2
0 0 0 3
0 3 5 10
1
end_operator
begin_operator
board car11 loc6
1
12 6
2
0 0 0 3
0 3 6 10
1
end_operator
begin_operator
board car11 loc7
1
12 7
2
0 0 0 3
0 3 7 10
1
end_operator
begin_operator
board car11 loc8
1
12 8
2
0 0 0 3
0 3 8 10
1
end_operator
begin_operator
board car11 loc9
1
12 9
2
0 0 0 3
0 3 9 10
1
end_operator
begin_operator
board car2 loc1
1
12 0
2
0 0 0 4
0 4 0 10
1
end_operator
begin_operator
board car2 loc10
1
12 1
2
0 0 0 4
0 4 1 10
1
end_operator
begin_operator
board car2 loc2
1
12 2
2
0 0 0 4
0 4 2 10
1
end_operator
begin_operator
board car2 loc3
1
12 3
2
0 0 0 4
0 4 3 10
1
end_operator
begin_operator
board car2 loc4
1
12 4
2
0 0 0 4
0 4 4 10
1
end_operator
begin_operator
board car2 loc5
1
12 5
2
0 0 0 4
0 4 5 10
1
end_operator
begin_operator
board car2 loc6
1
12 6
2
0 0 0 4
0 4 6 10
1
end_operator
begin_operator
board car2 loc7
1
12 7
2
0 0 0 4
0 4 7 10
1
end_operator
begin_operator
board car2 loc8
1
12 8
2
0 0 0 4
0 4 8 10
1
end_operator
begin_operator
board car2 loc9
1
12 9
2
0 0 0 4
0 4 9 10
1
end_operator
begin_operator
board car3 loc1
1
12 0
2
0 0 0 5
0 5 0 10
1
end_operator
begin_operator
board car3 loc10
1
12 1
2
0 0 0 5
0 5 1 10
1
end_operator
begin_operator
board car3 loc2
1
12 2
2
0 0 0 5
0 5 2 10
1
end_operator
begin_operator
board car3 loc3
1
12 3
2
0 0 0 5
0 5 3 10
1
end_operator
begin_operator
board car3 loc4
1
12 4
2
0 0 0 5
0 5 4 10
1
end_operator
begin_operator
board car3 loc5
1
12 5
2
0 0 0 5
0 5 5 10
1
end_operator
begin_operator
board car3 loc6
1
12 6
2
0 0 0 5
0 5 6 10
1
end_operator
begin_operator
board car3 loc7
1
12 7
2
0 0 0 5
0 5 7 10
1
end_operator
begin_operator
board car3 loc8
1
12 8
2
0 0 0 5
0 5 8 10
1
end_operator
begin_operator
board car3 loc9
1
12 9
2
0 0 0 5
0 5 9 10
1
end_operator
begin_operator
board car4 loc1
1
12 0
2
0 0 0 6
0 6 0 10
1
end_operator
begin_operator
board car4 loc10
1
12 1
2
0 0 0 6
0 6 1 10
1
end_operator
begin_operator
board car4 loc2
1
12 2
2
0 0 0 6
0 6 2 10
1
end_operator
begin_operator
board car4 loc3
1
12 3
2
0 0 0 6
0 6 3 10
1
end_operator
begin_operator
board car4 loc4
1
12 4
2
0 0 0 6
0 6 4 10
1
end_operator
begin_operator
board car4 loc5
1
12 5
2
0 0 0 6
0 6 5 10
1
end_operator
begin_operator
board car4 loc6
1
12 6
2
0 0 0 6
0 6 6 10
1
end_operator
begin_operator
board car4 loc7
1
12 7
2
0 0 0 6
0 6 7 10
1
end_operator
begin_operator
board car4 loc8
1
12 8
2
0 0 0 6
0 6 8 10
1
end_operator
begin_operator
board car4 loc9
1
12 9
2
0 0 0 6
0 6 9 10
1
end_operator
begin_operator
board car5 loc1
1
12 0
2
0 0 0 7
0 7 0 10
1
end_operator
begin_operator
board car5 loc10
1
12 1
2
0 0 0 7
0 7 1 10
1
end_operator
begin_operator
board car5 loc2
1
12 2
2
0 0 0 7
0 7 2 10
1
end_operator
begin_operator
board car5 loc3
1
12 3
2
0 0 0 7
0 7 3 10
1
end_operator
begin_operator
board car5 loc4
1
12 4
2
0 0 0 7
0 7 4 10
1
end_operator
begin_operator
board car5 loc5
1
12 5
2
0 0 0 7
0 7 5 10
1
end_operator
begin_operator
board car5 loc6
1
12 6
2
0 0 0 7
0 7 6 10
1
end_operator
begin_operator
board car5 loc7
1
12 7
2
0 0 0 7
0 7 7 10
1
end_operator
begin_operator
board car5 loc8
1
12 8
2
0 0 0 7
0 7 8 10
1
end_operator
begin_operator
board car5 loc9
1
12 9
2
0 0 0 7
0 7 9 10
1
end_operator
begin_operator
board car6 loc1
1
12 0
2
0 0 0 8
0 8 0 10
1
end_operator
begin_operator
board car6 loc10
1
12 1
2
0 0 0 8
0 8 1 10
1
end_operator
begin_operator
board car6 loc2
1
12 2
2
0 0 0 8
0 8 2 10
1
end_operator
begin_operator
board car6 loc3
1
12 3
2
0 0 0 8
0 8 3 10
1
end_operator
begin_operator
board car6 loc4
1
12 4
2
0 0 0 8
0 8 4 10
1
end_operator
begin_operator
board car6 loc5
1
12 5
2
0 0 0 8
0 8 5 10
1
end_operator
begin_operator
board car6 loc6
1
12 6
2
0 0 0 8
0 8 6 10
1
end_operator
begin_operator
board car6 loc7
1
12 7
2
0 0 0 8
0 8 7 10
1
end_operator
begin_operator
board car6 loc8
1
12 8
2
0 0 0 8
0 8 8 10
1
end_operator
begin_operator
board car6 loc9
1
12 9
2
0 0 0 8
0 8 9 10
1
end_operator
begin_operator
board car7 loc1
1
12 0
2
0 0 0 9
0 9 0 10
1
end_operator
begin_operator
board car7 loc10
1
12 1
2
0 0 0 9
0 9 1 10
1
end_operator
begin_operator
board car7 loc2
1
12 2
2
0 0 0 9
0 9 2 10
1
end_operator
begin_operator
board car7 loc3
1
12 3
2
0 0 0 9
0 9 3 10
1
end_operator
begin_operator
board car7 loc4
1
12 4
2
0 0 0 9
0 9 4 10
1
end_operator
begin_operator
board car7 loc5
1
12 5
2
0 0 0 9
0 9 5 10
1
end_operator
begin_operator
board car7 loc6
1
12 6
2
0 0 0 9
0 9 6 10
1
end_operator
begin_operator
board car7 loc7
1
12 7
2
0 0 0 9
0 9 7 10
1
end_operator
begin_operator
board car7 loc8
1
12 8
2
0 0 0 9
0 9 8 10
1
end_operator
begin_operator
board car7 loc9
1
12 9
2
0 0 0 9
0 9 9 10
1
end_operator
begin_operator
board car8 loc1
1
12 0
2
0 0 0 10
0 10 0 10
1
end_operator
begin_operator
board car8 loc10
1
12 1
2
0 0 0 10
0 10 1 10
1
end_operator
begin_operator
board car8 loc2
1
12 2
2
0 0 0 10
0 10 2 10
1
end_operator
begin_operator
board car8 loc3
1
12 3
2
0 0 0 10
0 10 3 10
1
end_operator
begin_operator
board car8 loc4
1
12 4
2
0 0 0 10
0 10 4 10
1
end_operator
begin_operator
board car8 loc5
1
12 5
2
0 0 0 10
0 10 5 10
1
end_operator
begin_operator
board car8 loc6
1
12 6
2
0 0 0 10
0 10 6 10
1
end_operator
begin_operator
board car8 loc7
1
12 7
2
0 0 0 10
0 10 7 10
1
end_operator
begin_operator
board car8 loc8
1
12 8
2
0 0 0 10
0 10 8 10
1
end_operator
begin_operator
board car8 loc9
1
12 9
2
0 0 0 10
0 10 9 10
1
end_operator
begin_operator
board car9 loc1
1
12 0
2
0 0 0 11
0 11 0 10
1
end_operator
begin_operator
board car9 loc10
1
12 1
2
0 0 0 11
0 11 1 10
1
end_operator
begin_operator
board car9 loc2
1
12 2
2
0 0 0 11
0 11 2 10
1
end_operator
begin_operator
board car9 loc3
1
12 3
2
0 0 0 11
0 11 3 10
1
end_operator
begin_operator
board car9 loc4
1
12 4
2
0 0 0 11
0 11 4 10
1
end_operator
begin_operator
board car9 loc5
1
12 5
2
0 0 0 11
0 11 5 10
1
end_operator
begin_operator
board car9 loc6
1
12 6
2
0 0 0 11
0 11 6 10
1
end_operator
begin_operator
board car9 loc7
1
12 7
2
0 0 0 11
0 11 7 10
1
end_operator
begin_operator
board car9 loc8
1
12 8
2
0 0 0 11
0 11 8 10
1
end_operator
begin_operator
board car9 loc9
1
12 9
2
0 0 0 11
0 11 9 10
1
end_operator
begin_operator
debark car1 loc1
1
12 0
2
0 0 1 0
0 1 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
12 1
2
0 0 1 0
0 1 -1 1
1
end_operator
begin_operator
debark car1 loc2
1
12 2
2
0 0 1 0
0 1 -1 2
1
end_operator
begin_operator
debark car1 loc3
1
12 3
2
0 0 1 0
0 1 -1 3
1
end_operator
begin_operator
debark car1 loc4
1
12 4
2
0 0 1 0
0 1 -1 4
1
end_operator
begin_operator
debark car1 loc5
1
12 5
2
0 0 1 0
0 1 -1 5
1
end_operator
begin_operator
debark car1 loc6
1
12 6
2
0 0 1 0
0 1 -1 6
1
end_operator
begin_operator
debark car1 loc7
1
12 7
2
0 0 1 0
0 1 -1 7
1
end_operator
begin_operator
debark car1 loc8
1
12 8
2
0 0 1 0
0 1 -1 8
1
end_operator
begin_operator
debark car1 loc9
1
12 9
2
0 0 1 0
0 1 -1 9
1
end_operator
begin_operator
debark car10 loc1
1
12 0
2
0 0 2 0
0 2 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
12 1
2
0 0 2 0
0 2 -1 1
1
end_operator
begin_operator
debark car10 loc2
1
12 2
2
0 0 2 0
0 2 -1 2
1
end_operator
begin_operator
debark car10 loc3
1
12 3
2
0 0 2 0
0 2 -1 3
1
end_operator
begin_operator
debark car10 loc4
1
12 4
2
0 0 2 0
0 2 -1 4
1
end_operator
begin_operator
debark car10 loc5
1
12 5
2
0 0 2 0
0 2 -1 5
1
end_operator
begin_operator
debark car10 loc6
1
12 6
2
0 0 2 0
0 2 -1 6
1
end_operator
begin_operator
debark car10 loc7
1
12 7
2
0 0 2 0
0 2 -1 7
1
end_operator
begin_operator
debark car10 loc8
1
12 8
2
0 0 2 0
0 2 -1 8
1
end_operator
begin_operator
debark car10 loc9
1
12 9
2
0 0 2 0
0 2 -1 9
1
end_operator
begin_operator
debark car11 loc1
1
12 0
2
0 0 3 0
0 3 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
12 1
2
0 0 3 0
0 3 -1 1
1
end_operator
begin_operator
debark car11 loc2
1
12 2
2
0 0 3 0
0 3 -1 2
1
end_operator
begin_operator
debark car11 loc3
1
12 3
2
0 0 3 0
0 3 -1 3
1
end_operator
begin_operator
debark car11 loc4
1
12 4
2
0 0 3 0
0 3 -1 4
1
end_operator
begin_operator
debark car11 loc5
1
12 5
2
0 0 3 0
0 3 -1 5
1
end_operator
begin_operator
debark car11 loc6
1
12 6
2
0 0 3 0
0 3 -1 6
1
end_operator
begin_operator
debark car11 loc7
1
12 7
2
0 0 3 0
0 3 -1 7
1
end_operator
begin_operator
debark car11 loc8
1
12 8
2
0 0 3 0
0 3 -1 8
1
end_operator
begin_operator
debark car11 loc9
1
12 9
2
0 0 3 0
0 3 -1 9
1
end_operator
begin_operator
debark car2 loc1
1
12 0
2
0 0 4 0
0 4 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
12 1
2
0 0 4 0
0 4 -1 1
1
end_operator
begin_operator
debark car2 loc2
1
12 2
2
0 0 4 0
0 4 -1 2
1
end_operator
begin_operator
debark car2 loc3
1
12 3
2
0 0 4 0
0 4 -1 3
1
end_operator
begin_operator
debark car2 loc4
1
12 4
2
0 0 4 0
0 4 -1 4
1
end_operator
begin_operator
debark car2 loc5
1
12 5
2
0 0 4 0
0 4 -1 5
1
end_operator
begin_operator
debark car2 loc6
1
12 6
2
0 0 4 0
0 4 -1 6
1
end_operator
begin_operator
debark car2 loc7
1
12 7
2
0 0 4 0
0 4 -1 7
1
end_operator
begin_operator
debark car2 loc8
1
12 8
2
0 0 4 0
0 4 -1 8
1
end_operator
begin_operator
debark car2 loc9
1
12 9
2
0 0 4 0
0 4 -1 9
1
end_operator
begin_operator
debark car3 loc1
1
12 0
2
0 0 5 0
0 5 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
12 1
2
0 0 5 0
0 5 -1 1
1
end_operator
begin_operator
debark car3 loc2
1
12 2
2
0 0 5 0
0 5 -1 2
1
end_operator
begin_operator
debark car3 loc3
1
12 3
2
0 0 5 0
0 5 -1 3
1
end_operator
begin_operator
debark car3 loc4
1
12 4
2
0 0 5 0
0 5 -1 4
1
end_operator
begin_operator
debark car3 loc5
1
12 5
2
0 0 5 0
0 5 -1 5
1
end_operator
begin_operator
debark car3 loc6
1
12 6
2
0 0 5 0
0 5 -1 6
1
end_operator
begin_operator
debark car3 loc7
1
12 7
2
0 0 5 0
0 5 -1 7
1
end_operator
begin_operator
debark car3 loc8
1
12 8
2
0 0 5 0
0 5 -1 8
1
end_operator
begin_operator
debark car3 loc9
1
12 9
2
0 0 5 0
0 5 -1 9
1
end_operator
begin_operator
debark car4 loc1
1
12 0
2
0 0 6 0
0 6 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
12 1
2
0 0 6 0
0 6 -1 1
1
end_operator
begin_operator
debark car4 loc2
1
12 2
2
0 0 6 0
0 6 -1 2
1
end_operator
begin_operator
debark car4 loc3
1
12 3
2
0 0 6 0
0 6 -1 3
1
end_operator
begin_operator
debark car4 loc4
1
12 4
2
0 0 6 0
0 6 -1 4
1
end_operator
begin_operator
debark car4 loc5
1
12 5
2
0 0 6 0
0 6 -1 5
1
end_operator
begin_operator
debark car4 loc6
1
12 6
2
0 0 6 0
0 6 -1 6
1
end_operator
begin_operator
debark car4 loc7
1
12 7
2
0 0 6 0
0 6 -1 7
1
end_operator
begin_operator
debark car4 loc8
1
12 8
2
0 0 6 0
0 6 -1 8
1
end_operator
begin_operator
debark car4 loc9
1
12 9
2
0 0 6 0
0 6 -1 9
1
end_operator
begin_operator
debark car5 loc1
1
12 0
2
0 0 7 0
0 7 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
12 1
2
0 0 7 0
0 7 -1 1
1
end_operator
begin_operator
debark car5 loc2
1
12 2
2
0 0 7 0
0 7 -1 2
1
end_operator
begin_operator
debark car5 loc3
1
12 3
2
0 0 7 0
0 7 -1 3
1
end_operator
begin_operator
debark car5 loc4
1
12 4
2
0 0 7 0
0 7 -1 4
1
end_operator
begin_operator
debark car5 loc5
1
12 5
2
0 0 7 0
0 7 -1 5
1
end_operator
begin_operator
debark car5 loc6
1
12 6
2
0 0 7 0
0 7 -1 6
1
end_operator
begin_operator
debark car5 loc7
1
12 7
2
0 0 7 0
0 7 -1 7
1
end_operator
begin_operator
debark car5 loc8
1
12 8
2
0 0 7 0
0 7 -1 8
1
end_operator
begin_operator
debark car5 loc9
1
12 9
2
0 0 7 0
0 7 -1 9
1
end_operator
begin_operator
debark car6 loc1
1
12 0
2
0 0 8 0
0 8 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
12 1
2
0 0 8 0
0 8 -1 1
1
end_operator
begin_operator
debark car6 loc2
1
12 2
2
0 0 8 0
0 8 -1 2
1
end_operator
begin_operator
debark car6 loc3
1
12 3
2
0 0 8 0
0 8 -1 3
1
end_operator
begin_operator
debark car6 loc4
1
12 4
2
0 0 8 0
0 8 -1 4
1
end_operator
begin_operator
debark car6 loc5
1
12 5
2
0 0 8 0
0 8 -1 5
1
end_operator
begin_operator
debark car6 loc6
1
12 6
2
0 0 8 0
0 8 -1 6
1
end_operator
begin_operator
debark car6 loc7
1
12 7
2
0 0 8 0
0 8 -1 7
1
end_operator
begin_operator
debark car6 loc8
1
12 8
2
0 0 8 0
0 8 -1 8
1
end_operator
begin_operator
debark car6 loc9
1
12 9
2
0 0 8 0
0 8 -1 9
1
end_operator
begin_operator
debark car7 loc1
1
12 0
2
0 0 9 0
0 9 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
12 1
2
0 0 9 0
0 9 -1 1
1
end_operator
begin_operator
debark car7 loc2
1
12 2
2
0 0 9 0
0 9 -1 2
1
end_operator
begin_operator
debark car7 loc3
1
12 3
2
0 0 9 0
0 9 -1 3
1
end_operator
begin_operator
debark car7 loc4
1
12 4
2
0 0 9 0
0 9 -1 4
1
end_operator
begin_operator
debark car7 loc5
1
12 5
2
0 0 9 0
0 9 -1 5
1
end_operator
begin_operator
debark car7 loc6
1
12 6
2
0 0 9 0
0 9 -1 6
1
end_operator
begin_operator
debark car7 loc7
1
12 7
2
0 0 9 0
0 9 -1 7
1
end_operator
begin_operator
debark car7 loc8
1
12 8
2
0 0 9 0
0 9 -1 8
1
end_operator
begin_operator
debark car7 loc9
1
12 9
2
0 0 9 0
0 9 -1 9
1
end_operator
begin_operator
debark car8 loc1
1
12 0
2
0 0 10 0
0 10 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
12 1
2
0 0 10 0
0 10 -1 1
1
end_operator
begin_operator
debark car8 loc2
1
12 2
2
0 0 10 0
0 10 -1 2
1
end_operator
begin_operator
debark car8 loc3
1
12 3
2
0 0 10 0
0 10 -1 3
1
end_operator
begin_operator
debark car8 loc4
1
12 4
2
0 0 10 0
0 10 -1 4
1
end_operator
begin_operator
debark car8 loc5
1
12 5
2
0 0 10 0
0 10 -1 5
1
end_operator
begin_operator
debark car8 loc6
1
12 6
2
0 0 10 0
0 10 -1 6
1
end_operator
begin_operator
debark car8 loc7
1
12 7
2
0 0 10 0
0 10 -1 7
1
end_operator
begin_operator
debark car8 loc8
1
12 8
2
0 0 10 0
0 10 -1 8
1
end_operator
begin_operator
debark car8 loc9
1
12 9
2
0 0 10 0
0 10 -1 9
1
end_operator
begin_operator
debark car9 loc1
1
12 0
2
0 0 11 0
0 11 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
12 1
2
0 0 11 0
0 11 -1 1
1
end_operator
begin_operator
debark car9 loc2
1
12 2
2
0 0 11 0
0 11 -1 2
1
end_operator
begin_operator
debark car9 loc3
1
12 3
2
0 0 11 0
0 11 -1 3
1
end_operator
begin_operator
debark car9 loc4
1
12 4
2
0 0 11 0
0 11 -1 4
1
end_operator
begin_operator
debark car9 loc5
1
12 5
2
0 0 11 0
0 11 -1 5
1
end_operator
begin_operator
debark car9 loc6
1
12 6
2
0 0 11 0
0 11 -1 6
1
end_operator
begin_operator
debark car9 loc7
1
12 7
2
0 0 11 0
0 11 -1 7
1
end_operator
begin_operator
debark car9 loc8
1
12 8
2
0 0 11 0
0 11 -1 8
1
end_operator
begin_operator
debark car9 loc9
1
12 9
2
0 0 11 0
0 11 -1 9
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 12 0 1
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 12 0 2
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 12 0 3
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 12 0 4
0 13 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 12 0 5
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 12 0 6
0 13 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 12 0 7
0 13 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 12 0 8
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 12 0 9
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 12 1 0
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 12 1 2
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 12 1 3
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 12 1 4
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 12 1 5
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 12 1 6
0 14 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 12 1 7
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 12 1 8
0 14 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 12 1 9
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 12 2 0
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 12 2 1
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 12 2 3
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 12 2 4
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 12 2 5
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 12 2 6
0 15 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 12 2 7
0 15 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 12 2 8
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 12 2 9
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 12 3 0
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 12 3 1
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 12 3 2
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 12 3 4
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 12 3 5
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 12 3 6
0 16 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 12 3 7
0 16 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 12 3 8
0 16 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 12 3 9
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 12 4 0
0 13 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 12 4 1
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 12 4 2
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 12 4 3
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 12 4 5
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 12 4 6
0 17 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 12 4 7
0 17 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 12 4 8
0 17 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 12 4 9
0 17 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 12 5 0
0 13 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 12 5 1
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 12 5 2
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 12 5 3
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 12 5 4
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 12 5 6
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 12 5 7
0 18 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 12 5 8
0 18 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 12 5 9
0 18 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 12 6 0
0 13 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 12 6 1
0 14 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 12 6 2
0 15 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 12 6 3
0 16 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 12 6 4
0 17 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 12 6 5
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 12 6 7
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 12 6 8
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 12 6 9
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 12 7 0
0 13 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 12 7 1
0 14 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 12 7 2
0 15 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 12 7 3
0 16 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 12 7 4
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 12 7 5
0 18 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 12 7 6
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 12 7 8
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 12 7 9
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 12 8 0
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 12 8 1
0 14 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 12 8 2
0 15 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 12 8 3
0 16 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 12 8 4
0 17 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 12 8 5
0 18 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 12 8 6
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 12 8 7
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 12 8 9
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 12 9 0
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 12 9 1
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 12 9 2
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 12 9 3
0 16 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 12 9 4
0 17 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 12 9 5
0 18 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 12 9 6
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 12 9 7
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 12 9 8
0 21 0 1
0 22 -1 0
1
end_operator
0
