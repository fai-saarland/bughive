begin_version
3
end_version
begin_metric
1
end_metric
4
begin_variable
var0
-1
3
at car1 loc1
at car1 loc2
on car1
end_variable
begin_variable
var1
-1
2
NOT-at-ferry loc1
NOT-at-ferry loc2
end_variable
begin_variable
var2
-1
2
at-ferry loc1
at-ferry loc2
end_variable
begin_variable
var3
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
0
1
0
0
end_state
begin_goal
1
0 1
end_goal
6
begin_operator
board car1 loc1
1
2 0
2
0 0 0 2
0 3 0 1
1
end_operator
begin_operator
board car1 loc2
1
2 1
2
0 0 1 2
0 3 0 1
1
end_operator
begin_operator
debark car1 loc1
1
2 0
2
0 0 2 0
0 3 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
2 1
2
0 0 2 1
0 3 -1 0
1
end_operator
begin_operator
sail loc1 loc2
0
2
0 1 1 0
0 2 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
2
0 1 0 1
0 2 1 0
1
end_operator
0
