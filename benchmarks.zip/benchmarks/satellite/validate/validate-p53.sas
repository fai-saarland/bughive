begin_version
3
end_version
begin_metric
1
end_metric
126
begin_variable
var0
-1
7
pointing sat1 dir1
pointing sat1 dir2
pointing sat1 dir3
pointing sat1 dir4
pointing sat1 dir5
pointing sat1 dir6
pointing sat1 dir7
end_variable
begin_variable
var1
-1
7
pointing sat2 dir1
pointing sat2 dir2
pointing sat2 dir3
pointing sat2 dir4
pointing sat2 dir5
pointing sat2 dir6
pointing sat2 dir7
end_variable
begin_variable
var2
-1
7
pointing sat3 dir1
pointing sat3 dir2
pointing sat3 dir3
pointing sat3 dir4
pointing sat3 dir5
pointing sat3 dir6
pointing sat3 dir7
end_variable
begin_variable
var3
-1
7
pointing sat4 dir1
pointing sat4 dir2
pointing sat4 dir3
pointing sat4 dir4
pointing sat4 dir5
pointing sat4 dir6
pointing sat4 dir7
end_variable
begin_variable
var4
-1
7
pointing sat5 dir1
pointing sat5 dir2
pointing sat5 dir3
pointing sat5 dir4
pointing sat5 dir5
pointing sat5 dir6
pointing sat5 dir7
end_variable
begin_variable
var5
-1
7
pointing sat6 dir1
pointing sat6 dir2
pointing sat6 dir3
pointing sat6 dir4
pointing sat6 dir5
pointing sat6 dir6
pointing sat6 dir7
end_variable
begin_variable
var6
-1
2
NOT-pointing sat1 dir1
none-of-those
end_variable
begin_variable
var7
-1
2
NOT-pointing sat1 dir2
none-of-those
end_variable
begin_variable
var8
-1
2
NOT-pointing sat1 dir3
none-of-those
end_variable
begin_variable
var9
-1
2
NOT-pointing sat1 dir4
none-of-those
end_variable
begin_variable
var10
-1
2
NOT-pointing sat1 dir5
none-of-those
end_variable
begin_variable
var11
-1
2
NOT-pointing sat1 dir6
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-pointing sat1 dir7
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-pointing sat2 dir1
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-pointing sat2 dir2
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-pointing sat2 dir3
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-pointing sat2 dir4
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-pointing sat2 dir5
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-pointing sat2 dir6
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-pointing sat2 dir7
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-pointing sat3 dir1
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-pointing sat3 dir2
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-pointing sat3 dir3
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-pointing sat3 dir4
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-pointing sat3 dir5
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-pointing sat3 dir6
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-pointing sat3 dir7
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-pointing sat4 dir1
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-pointing sat4 dir2
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-pointing sat4 dir3
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-pointing sat4 dir4
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-pointing sat4 dir5
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-pointing sat4 dir6
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-pointing sat4 dir7
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-pointing sat5 dir1
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-pointing sat5 dir2
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-pointing sat5 dir3
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-pointing sat5 dir4
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-pointing sat5 dir5
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-pointing sat5 dir6
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-pointing sat5 dir7
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-pointing sat6 dir1
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-pointing sat6 dir2
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-pointing sat6 dir3
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-pointing sat6 dir4
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-pointing sat6 dir5
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-pointing sat6 dir6
none-of-those
end_variable
begin_variable
var47
-1
2
NOT-pointing sat6 dir7
none-of-those
end_variable
begin_variable
var48
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var49
-1
2
calibrated ins10
none-of-those
end_variable
begin_variable
var50
-1
2
calibrated ins11
none-of-those
end_variable
begin_variable
var51
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var52
-1
2
calibrated ins3
none-of-those
end_variable
begin_variable
var53
-1
2
calibrated ins4
none-of-those
end_variable
begin_variable
var54
-1
2
calibrated ins5
none-of-those
end_variable
begin_variable
var55
-1
2
calibrated ins6
none-of-those
end_variable
begin_variable
var56
-1
2
calibrated ins7
none-of-those
end_variable
begin_variable
var57
-1
2
calibrated ins8
none-of-those
end_variable
begin_variable
var58
-1
2
calibrated ins9
none-of-those
end_variable
begin_variable
var59
-1
2
calibration_target ins1 dir6
none-of-those
end_variable
begin_variable
var60
-1
2
calibration_target ins10 dir7
none-of-those
end_variable
begin_variable
var61
-1
2
calibration_target ins11 dir6
none-of-those
end_variable
begin_variable
var62
-1
2
calibration_target ins2 dir1
none-of-those
end_variable
begin_variable
var63
-1
2
calibration_target ins3 dir7
none-of-those
end_variable
begin_variable
var64
-1
2
calibration_target ins4 dir1
none-of-those
end_variable
begin_variable
var65
-1
2
calibration_target ins5 dir6
none-of-those
end_variable
begin_variable
var66
-1
2
calibration_target ins6 dir5
none-of-those
end_variable
begin_variable
var67
-1
2
calibration_target ins7 dir6
none-of-those
end_variable
begin_variable
var68
-1
2
calibration_target ins8 dir6
none-of-those
end_variable
begin_variable
var69
-1
2
calibration_target ins9 dir3
none-of-those
end_variable
begin_variable
var70
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var71
-1
2
have_image dir1 mod2
none-of-those
end_variable
begin_variable
var72
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var73
-1
2
have_image dir2 mod2
none-of-those
end_variable
begin_variable
var74
-1
2
have_image dir3 mod1
none-of-those
end_variable
begin_variable
var75
-1
2
have_image dir3 mod2
none-of-those
end_variable
begin_variable
var76
-1
2
have_image dir4 mod1
none-of-those
end_variable
begin_variable
var77
-1
2
have_image dir4 mod2
none-of-those
end_variable
begin_variable
var78
-1
2
have_image dir5 mod1
none-of-those
end_variable
begin_variable
var79
-1
2
have_image dir5 mod2
none-of-those
end_variable
begin_variable
var80
-1
2
have_image dir6 mod1
none-of-those
end_variable
begin_variable
var81
-1
2
have_image dir6 mod2
none-of-those
end_variable
begin_variable
var82
-1
2
have_image dir7 mod1
none-of-those
end_variable
begin_variable
var83
-1
2
have_image dir7 mod2
none-of-those
end_variable
begin_variable
var84
-1
2
on_board ins1 sat6
none-of-those
end_variable
begin_variable
var85
-1
2
on_board ins10 sat2
none-of-those
end_variable
begin_variable
var86
-1
2
on_board ins11 sat3
none-of-those
end_variable
begin_variable
var87
-1
2
on_board ins2 sat3
none-of-those
end_variable
begin_variable
var88
-1
2
on_board ins3 sat2
none-of-those
end_variable
begin_variable
var89
-1
2
on_board ins4 sat5
none-of-those
end_variable
begin_variable
var90
-1
2
on_board ins5 sat1
none-of-those
end_variable
begin_variable
var91
-1
2
on_board ins6 sat4
none-of-those
end_variable
begin_variable
var92
-1
2
on_board ins7 sat1
none-of-those
end_variable
begin_variable
var93
-1
2
on_board ins8 sat5
none-of-those
end_variable
begin_variable
var94
-1
2
on_board ins9 sat2
none-of-those
end_variable
begin_variable
var95
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var96
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var97
-1
2
power_avail sat3
none-of-those
end_variable
begin_variable
var98
-1
2
power_avail sat4
none-of-those
end_variable
begin_variable
var99
-1
2
power_avail sat5
none-of-those
end_variable
begin_variable
var100
-1
2
power_avail sat6
none-of-those
end_variable
begin_variable
var101
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var102
-1
2
power_on ins10
none-of-those
end_variable
begin_variable
var103
-1
2
power_on ins11
none-of-those
end_variable
begin_variable
var104
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var105
-1
2
power_on ins3
none-of-those
end_variable
begin_variable
var106
-1
2
power_on ins4
none-of-those
end_variable
begin_variable
var107
-1
2
power_on ins5
none-of-those
end_variable
begin_variable
var108
-1
2
power_on ins6
none-of-those
end_variable
begin_variable
var109
-1
2
power_on ins7
none-of-those
end_variable
begin_variable
var110
-1
2
power_on ins8
none-of-those
end_variable
begin_variable
var111
-1
2
power_on ins9
none-of-those
end_variable
begin_variable
var112
-1
2
supports ins1 mod1
none-of-those
end_variable
begin_variable
var113
-1
2
supports ins10 mod1
none-of-those
end_variable
begin_variable
var114
-1
2
supports ins11 mod1
none-of-those
end_variable
begin_variable
var115
-1
2
supports ins2 mod2
none-of-those
end_variable
begin_variable
var116
-1
2
supports ins3 mod1
none-of-those
end_variable
begin_variable
var117
-1
2
supports ins4 mod1
none-of-those
end_variable
begin_variable
var118
-1
2
supports ins4 mod2
none-of-those
end_variable
begin_variable
var119
-1
2
supports ins5 mod1
none-of-those
end_variable
begin_variable
var120
-1
2
supports ins6 mod1
none-of-those
end_variable
begin_variable
var121
-1
2
supports ins6 mod2
none-of-those
end_variable
begin_variable
var122
-1
2
supports ins7 mod2
none-of-those
end_variable
begin_variable
var123
-1
2
supports ins8 mod1
none-of-those
end_variable
begin_variable
var124
-1
2
supports ins9 mod1
none-of-those
end_variable
begin_variable
var125
-1
2
supports ins9 mod2
none-of-those
end_variable
0
begin_state
6
6
0
4
6
2
0
0
0
0
0
0
1
0
0
0
0
0
0
1
1
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
1
0
0
1
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
12
70 0
71 0
72 0
73 0
74 0
75 0
77 0
78 0
80 0
81 0
82 0
83 0
end_goal
383
begin_operator
calibrate sat1 ins5 dir6
4
0 5
65 0
90 0
107 0
1
0 54 -1 0
1
end_operator
begin_operator
calibrate sat1 ins7 dir6
4
0 5
67 0
92 0
109 0
1
0 56 -1 0
1
end_operator
begin_operator
calibrate sat2 ins10 dir7
4
1 6
60 0
85 0
102 0
1
0 49 -1 0
1
end_operator
begin_operator
calibrate sat2 ins3 dir7
4
1 6
63 0
88 0
105 0
1
0 52 -1 0
1
end_operator
begin_operator
calibrate sat2 ins9 dir3
4
1 2
69 0
94 0
111 0
1
0 58 -1 0
1
end_operator
begin_operator
calibrate sat3 ins11 dir6
4
2 5
61 0
86 0
103 0
1
0 50 -1 0
1
end_operator
begin_operator
calibrate sat3 ins2 dir1
4
2 0
62 0
87 0
104 0
1
0 51 -1 0
1
end_operator
begin_operator
calibrate sat4 ins6 dir5
4
3 4
66 0
91 0
108 0
1
0 55 -1 0
1
end_operator
begin_operator
calibrate sat5 ins4 dir1
4
4 0
64 0
89 0
106 0
1
0 53 -1 0
1
end_operator
begin_operator
calibrate sat5 ins8 dir6
4
4 5
68 0
93 0
110 0
1
0 57 -1 0
1
end_operator
begin_operator
calibrate sat6 ins1 dir6
4
5 5
59 0
84 0
101 0
1
0 48 -1 0
1
end_operator
begin_operator
switch_off ins1 sat6
1
84 0
2
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
switch_off ins10 sat2
1
85 0
2
0 96 -1 0
0 102 0 1
1
end_operator
begin_operator
switch_off ins11 sat3
1
86 0
2
0 97 -1 0
0 103 0 1
1
end_operator
begin_operator
switch_off ins2 sat3
1
87 0
2
0 97 -1 0
0 104 0 1
1
end_operator
begin_operator
switch_off ins3 sat2
1
88 0
2
0 96 -1 0
0 105 0 1
1
end_operator
begin_operator
switch_off ins4 sat5
1
89 0
2
0 99 -1 0
0 106 0 1
1
end_operator
begin_operator
switch_off ins5 sat1
1
90 0
2
0 95 -1 0
0 107 0 1
1
end_operator
begin_operator
switch_off ins6 sat4
1
91 0
2
0 98 -1 0
0 108 0 1
1
end_operator
begin_operator
switch_off ins7 sat1
1
92 0
2
0 95 -1 0
0 109 0 1
1
end_operator
begin_operator
switch_off ins8 sat5
1
93 0
2
0 99 -1 0
0 110 0 1
1
end_operator
begin_operator
switch_off ins9 sat2
1
94 0
2
0 96 -1 0
0 111 0 1
1
end_operator
begin_operator
switch_on ins1 sat6
1
84 0
3
0 48 -1 1
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
switch_on ins10 sat2
1
85 0
3
0 49 -1 1
0 96 0 1
0 102 -1 0
1
end_operator
begin_operator
switch_on ins11 sat3
1
86 0
3
0 50 -1 1
0 97 0 1
0 103 -1 0
1
end_operator
begin_operator
switch_on ins2 sat3
1
87 0
3
0 51 -1 1
0 97 0 1
0 104 -1 0
1
end_operator
begin_operator
switch_on ins3 sat2
1
88 0
3
0 52 -1 1
0 96 0 1
0 105 -1 0
1
end_operator
begin_operator
switch_on ins4 sat5
1
89 0
3
0 53 -1 1
0 99 0 1
0 106 -1 0
1
end_operator
begin_operator
switch_on ins5 sat1
1
90 0
3
0 54 -1 1
0 95 0 1
0 107 -1 0
1
end_operator
begin_operator
switch_on ins6 sat4
1
91 0
3
0 55 -1 1
0 98 0 1
0 108 -1 0
1
end_operator
begin_operator
switch_on ins7 sat1
1
92 0
3
0 56 -1 1
0 95 0 1
0 109 -1 0
1
end_operator
begin_operator
switch_on ins8 sat5
1
93 0
3
0 57 -1 1
0 99 0 1
0 110 -1 0
1
end_operator
begin_operator
switch_on ins9 sat2
1
94 0
3
0 58 -1 1
0 96 0 1
0 111 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins5 mod1
5
0 0
54 0
90 0
107 0
119 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins7 mod2
5
0 0
56 0
92 0
109 0
122 0
1
0 71 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins5 mod1
5
0 1
54 0
90 0
107 0
119 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins7 mod2
5
0 1
56 0
92 0
109 0
122 0
1
0 73 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins5 mod1
5
0 2
54 0
90 0
107 0
119 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins7 mod2
5
0 2
56 0
92 0
109 0
122 0
1
0 75 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins5 mod1
5
0 3
54 0
90 0
107 0
119 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins7 mod2
5
0 3
56 0
92 0
109 0
122 0
1
0 77 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins5 mod1
5
0 4
54 0
90 0
107 0
119 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins7 mod2
5
0 4
56 0
92 0
109 0
122 0
1
0 79 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins5 mod1
5
0 5
54 0
90 0
107 0
119 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins7 mod2
5
0 5
56 0
92 0
109 0
122 0
1
0 81 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins5 mod1
5
0 6
54 0
90 0
107 0
119 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins7 mod2
5
0 6
56 0
92 0
109 0
122 0
1
0 83 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins10 mod1
5
1 0
49 0
85 0
102 0
113 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins3 mod1
5
1 0
52 0
88 0
105 0
116 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins9 mod1
5
1 0
58 0
94 0
111 0
124 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins9 mod2
5
1 0
58 0
94 0
111 0
125 0
1
0 71 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins10 mod1
5
1 1
49 0
85 0
102 0
113 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins3 mod1
5
1 1
52 0
88 0
105 0
116 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins9 mod1
5
1 1
58 0
94 0
111 0
124 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins9 mod2
5
1 1
58 0
94 0
111 0
125 0
1
0 73 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins10 mod1
5
1 2
49 0
85 0
102 0
113 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins3 mod1
5
1 2
52 0
88 0
105 0
116 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins9 mod1
5
1 2
58 0
94 0
111 0
124 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins9 mod2
5
1 2
58 0
94 0
111 0
125 0
1
0 75 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins10 mod1
5
1 3
49 0
85 0
102 0
113 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins3 mod1
5
1 3
52 0
88 0
105 0
116 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins9 mod1
5
1 3
58 0
94 0
111 0
124 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins9 mod2
5
1 3
58 0
94 0
111 0
125 0
1
0 77 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins10 mod1
5
1 4
49 0
85 0
102 0
113 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins3 mod1
5
1 4
52 0
88 0
105 0
116 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins9 mod1
5
1 4
58 0
94 0
111 0
124 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins9 mod2
5
1 4
58 0
94 0
111 0
125 0
1
0 79 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins10 mod1
5
1 5
49 0
85 0
102 0
113 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins3 mod1
5
1 5
52 0
88 0
105 0
116 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins9 mod1
5
1 5
58 0
94 0
111 0
124 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins9 mod2
5
1 5
58 0
94 0
111 0
125 0
1
0 81 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins10 mod1
5
1 6
49 0
85 0
102 0
113 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins3 mod1
5
1 6
52 0
88 0
105 0
116 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins9 mod1
5
1 6
58 0
94 0
111 0
124 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins9 mod2
5
1 6
58 0
94 0
111 0
125 0
1
0 83 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins11 mod1
5
2 0
50 0
86 0
103 0
114 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins2 mod2
5
2 0
51 0
87 0
104 0
115 0
1
0 71 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins11 mod1
5
2 1
50 0
86 0
103 0
114 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins2 mod2
5
2 1
51 0
87 0
104 0
115 0
1
0 73 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins11 mod1
5
2 2
50 0
86 0
103 0
114 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins2 mod2
5
2 2
51 0
87 0
104 0
115 0
1
0 75 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins11 mod1
5
2 3
50 0
86 0
103 0
114 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins2 mod2
5
2 3
51 0
87 0
104 0
115 0
1
0 77 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins11 mod1
5
2 4
50 0
86 0
103 0
114 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins2 mod2
5
2 4
51 0
87 0
104 0
115 0
1
0 79 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins11 mod1
5
2 5
50 0
86 0
103 0
114 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins2 mod2
5
2 5
51 0
87 0
104 0
115 0
1
0 81 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins11 mod1
5
2 6
50 0
86 0
103 0
114 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins2 mod2
5
2 6
51 0
87 0
104 0
115 0
1
0 83 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins6 mod1
5
3 0
55 0
91 0
108 0
120 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins6 mod2
5
3 0
55 0
91 0
108 0
121 0
1
0 71 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins6 mod1
5
3 1
55 0
91 0
108 0
120 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins6 mod2
5
3 1
55 0
91 0
108 0
121 0
1
0 73 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins6 mod1
5
3 2
55 0
91 0
108 0
120 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins6 mod2
5
3 2
55 0
91 0
108 0
121 0
1
0 75 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins6 mod1
5
3 3
55 0
91 0
108 0
120 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins6 mod2
5
3 3
55 0
91 0
108 0
121 0
1
0 77 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins6 mod1
5
3 4
55 0
91 0
108 0
120 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins6 mod2
5
3 4
55 0
91 0
108 0
121 0
1
0 79 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins6 mod1
5
3 5
55 0
91 0
108 0
120 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins6 mod2
5
3 5
55 0
91 0
108 0
121 0
1
0 81 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins6 mod1
5
3 6
55 0
91 0
108 0
120 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins6 mod2
5
3 6
55 0
91 0
108 0
121 0
1
0 83 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins4 mod1
5
4 0
53 0
89 0
106 0
117 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins4 mod2
5
4 0
53 0
89 0
106 0
118 0
1
0 71 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins8 mod1
5
4 0
57 0
93 0
110 0
123 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins4 mod1
5
4 1
53 0
89 0
106 0
117 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins4 mod2
5
4 1
53 0
89 0
106 0
118 0
1
0 73 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins8 mod1
5
4 1
57 0
93 0
110 0
123 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins4 mod1
5
4 2
53 0
89 0
106 0
117 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins4 mod2
5
4 2
53 0
89 0
106 0
118 0
1
0 75 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins8 mod1
5
4 2
57 0
93 0
110 0
123 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins4 mod1
5
4 3
53 0
89 0
106 0
117 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins4 mod2
5
4 3
53 0
89 0
106 0
118 0
1
0 77 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins8 mod1
5
4 3
57 0
93 0
110 0
123 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins4 mod1
5
4 4
53 0
89 0
106 0
117 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins4 mod2
5
4 4
53 0
89 0
106 0
118 0
1
0 79 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins8 mod1
5
4 4
57 0
93 0
110 0
123 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins4 mod1
5
4 5
53 0
89 0
106 0
117 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins4 mod2
5
4 5
53 0
89 0
106 0
118 0
1
0 81 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins8 mod1
5
4 5
57 0
93 0
110 0
123 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins4 mod1
5
4 6
53 0
89 0
106 0
117 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins4 mod2
5
4 6
53 0
89 0
106 0
118 0
1
0 83 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins8 mod1
5
4 6
57 0
93 0
110 0
123 0
1
0 82 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins1 mod1
5
5 0
48 0
84 0
101 0
112 0
1
0 70 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins1 mod1
5
5 1
48 0
84 0
101 0
112 0
1
0 72 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins1 mod1
5
5 2
48 0
84 0
101 0
112 0
1
0 74 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins1 mod1
5
5 3
48 0
84 0
101 0
112 0
1
0 76 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins1 mod1
5
5 4
48 0
84 0
101 0
112 0
1
0 78 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins1 mod1
5
5 5
48 0
84 0
101 0
112 0
1
0 80 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins1 mod1
5
5 6
48 0
84 0
101 0
112 0
1
0 82 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
3
0 0 1 0
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
3
0 0 2 0
0 6 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
3
0 0 3 0
0 6 0 1
0 9 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
3
0 0 4 0
0 6 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir6
0
3
0 0 5 0
0 6 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir7
0
3
0 0 6 0
0 6 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
3
0 0 0 1
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
3
0 0 2 1
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
3
0 0 3 1
0 7 0 1
0 9 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir5
0
3
0 0 4 1
0 7 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir6
0
3
0 0 5 1
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir7
0
3
0 0 6 1
0 7 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
3
0 0 0 2
0 6 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
3
0 0 1 2
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
3
0 0 3 2
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir5
0
3
0 0 4 2
0 8 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir6
0
3
0 0 5 2
0 8 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir7
0
3
0 0 6 2
0 8 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
3
0 0 0 3
0 6 -1 0
0 9 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
3
0 0 1 3
0 7 -1 0
0 9 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
3
0 0 2 3
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir5
0
3
0 0 4 3
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir6
0
3
0 0 5 3
0 9 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir7
0
3
0 0 6 3
0 9 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir1
0
3
0 0 0 4
0 6 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir2
0
3
0 0 1 4
0 7 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir3
0
3
0 0 2 4
0 8 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir4
0
3
0 0 3 4
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir6
0
3
0 0 5 4
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir7
0
3
0 0 6 4
0 10 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir1
0
3
0 0 0 5
0 6 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir2
0
3
0 0 1 5
0 7 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir3
0
3
0 0 2 5
0 8 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir4
0
3
0 0 3 5
0 9 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir5
0
3
0 0 4 5
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir7
0
3
0 0 6 5
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir7 dir1
0
3
0 0 0 6
0 6 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir2
0
3
0 0 1 6
0 7 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir3
0
3
0 0 2 6
0 8 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir4
0
3
0 0 3 6
0 9 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir5
0
3
0 0 4 6
0 10 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir6
0
3
0 0 5 6
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
3
0 1 1 0
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
3
0 1 2 0
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
3
0 1 3 0
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir5
0
3
0 1 4 0
0 13 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir6
0
3
0 1 5 0
0 13 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir7
0
3
0 1 6 0
0 13 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
3
0 1 0 1
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
3
0 1 2 1
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
3
0 1 3 1
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir5
0
3
0 1 4 1
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir6
0
3
0 1 5 1
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir7
0
3
0 1 6 1
0 14 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
3
0 1 0 2
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
3
0 1 1 2
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
3
0 1 3 2
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir5
0
3
0 1 4 2
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir6
0
3
0 1 5 2
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir7
0
3
0 1 6 2
0 15 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
3
0 1 0 3
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
3
0 1 1 3
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
3
0 1 2 3
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir5
0
3
0 1 4 3
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir6
0
3
0 1 5 3
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir7
0
3
0 1 6 3
0 16 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir1
0
3
0 1 0 4
0 13 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir2
0
3
0 1 1 4
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir3
0
3
0 1 2 4
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir4
0
3
0 1 3 4
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir6
0
3
0 1 5 4
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir7
0
3
0 1 6 4
0 17 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir1
0
3
0 1 0 5
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir2
0
3
0 1 1 5
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir3
0
3
0 1 2 5
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir4
0
3
0 1 3 5
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir5
0
3
0 1 4 5
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir7
0
3
0 1 6 5
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir7 dir1
0
3
0 1 0 6
0 13 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir2
0
3
0 1 1 6
0 14 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir3
0
3
0 1 2 6
0 15 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir4
0
3
0 1 3 6
0 16 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir5
0
3
0 1 4 6
0 17 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir6
0
3
0 1 5 6
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
3
0 2 1 0
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
3
0 2 2 0
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
3
0 2 3 0
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir5
0
3
0 2 4 0
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir6
0
3
0 2 5 0
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir7
0
3
0 2 6 0
0 20 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
3
0 2 0 1
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
3
0 2 2 1
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
3
0 2 3 1
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir5
0
3
0 2 4 1
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir6
0
3
0 2 5 1
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir7
0
3
0 2 6 1
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
3
0 2 0 2
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
3
0 2 1 2
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
3
0 2 3 2
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir5
0
3
0 2 4 2
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir6
0
3
0 2 5 2
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir7
0
3
0 2 6 2
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
3
0 2 0 3
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
3
0 2 1 3
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
3
0 2 2 3
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir5
0
3
0 2 4 3
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir6
0
3
0 2 5 3
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir7
0
3
0 2 6 3
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir1
0
3
0 2 0 4
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir2
0
3
0 2 1 4
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir3
0
3
0 2 2 4
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir4
0
3
0 2 3 4
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir6
0
3
0 2 5 4
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir7
0
3
0 2 6 4
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir1
0
3
0 2 0 5
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir2
0
3
0 2 1 5
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir3
0
3
0 2 2 5
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir4
0
3
0 2 3 5
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir5
0
3
0 2 4 5
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir7
0
3
0 2 6 5
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat3 dir7 dir1
0
3
0 2 0 6
0 20 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir2
0
3
0 2 1 6
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir3
0
3
0 2 2 6
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir4
0
3
0 2 3 6
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir5
0
3
0 2 4 6
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir6
0
3
0 2 5 6
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
3
0 3 1 0
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
3
0 3 2 0
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
3
0 3 3 0
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir5
0
3
0 3 4 0
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir6
0
3
0 3 5 0
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir7
0
3
0 3 6 0
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
3
0 3 0 1
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
3
0 3 2 1
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
3
0 3 3 1
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir5
0
3
0 3 4 1
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir6
0
3
0 3 5 1
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir7
0
3
0 3 6 1
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
3
0 3 0 2
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
3
0 3 1 2
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
3
0 3 3 2
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
3
0 3 4 2
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir6
0
3
0 3 5 2
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir7
0
3
0 3 6 2
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
3
0 3 0 3
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
3
0 3 1 3
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
3
0 3 2 3
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
3
0 3 4 3
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir6
0
3
0 3 5 3
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir7
0
3
0 3 6 3
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
3
0 3 0 4
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
3
0 3 1 4
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
3
0 3 2 4
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
3
0 3 3 4
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir6
0
3
0 3 5 4
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir7
0
3
0 3 6 4
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir1
0
3
0 3 0 5
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir2
0
3
0 3 1 5
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir3
0
3
0 3 2 5
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir4
0
3
0 3 3 5
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir5
0
3
0 3 4 5
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir7
0
3
0 3 6 5
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat4 dir7 dir1
0
3
0 3 0 6
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir2
0
3
0 3 1 6
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir3
0
3
0 3 2 6
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir4
0
3
0 3 3 6
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir5
0
3
0 3 4 6
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir6
0
3
0 3 5 6
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat5 dir1 dir2
0
3
0 4 1 0
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir3
0
3
0 4 2 0
0 34 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir4
0
3
0 4 3 0
0 34 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir5
0
3
0 4 4 0
0 34 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir6
0
3
0 4 5 0
0 34 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir7
0
3
0 4 6 0
0 34 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir1
0
3
0 4 0 1
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat5 dir2 dir3
0
3
0 4 2 1
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir4
0
3
0 4 3 1
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir5
0
3
0 4 4 1
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir6
0
3
0 4 5 1
0 35 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir7
0
3
0 4 6 1
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir1
0
3
0 4 0 2
0 34 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir2
0
3
0 4 1 2
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir4
0
3
0 4 3 2
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir5
0
3
0 4 4 2
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir6
0
3
0 4 5 2
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir7
0
3
0 4 6 2
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir1
0
3
0 4 0 3
0 34 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir2
0
3
0 4 1 3
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir3
0
3
0 4 2 3
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir5
0
3
0 4 4 3
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir6
0
3
0 4 5 3
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir7
0
3
0 4 6 3
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir1
0
3
0 4 0 4
0 34 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir2
0
3
0 4 1 4
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir3
0
3
0 4 2 4
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir4
0
3
0 4 3 4
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir6
0
3
0 4 5 4
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir7
0
3
0 4 6 4
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir1
0
3
0 4 0 5
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir2
0
3
0 4 1 5
0 35 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir3
0
3
0 4 2 5
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir4
0
3
0 4 3 5
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir5
0
3
0 4 4 5
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir7
0
3
0 4 6 5
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat5 dir7 dir1
0
3
0 4 0 6
0 34 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir2
0
3
0 4 1 6
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir3
0
3
0 4 2 6
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir4
0
3
0 4 3 6
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir5
0
3
0 4 4 6
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir6
0
3
0 4 5 6
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat6 dir1 dir2
0
3
0 5 1 0
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir3
0
3
0 5 2 0
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir4
0
3
0 5 3 0
0 41 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir5
0
3
0 5 4 0
0 41 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir6
0
3
0 5 5 0
0 41 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir7
0
3
0 5 6 0
0 41 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir1
0
3
0 5 0 1
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat6 dir2 dir3
0
3
0 5 2 1
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir4
0
3
0 5 3 1
0 42 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir5
0
3
0 5 4 1
0 42 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir6
0
3
0 5 5 1
0 42 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir7
0
3
0 5 6 1
0 42 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir1
0
3
0 5 0 2
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir2
0
3
0 5 1 2
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir4
0
3
0 5 3 2
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir5
0
3
0 5 4 2
0 43 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir6
0
3
0 5 5 2
0 43 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir7
0
3
0 5 6 2
0 43 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir1
0
3
0 5 0 3
0 41 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir2
0
3
0 5 1 3
0 42 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir3
0
3
0 5 2 3
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir5
0
3
0 5 4 3
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir6
0
3
0 5 5 3
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir7
0
3
0 5 6 3
0 44 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir1
0
3
0 5 0 4
0 41 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir2
0
3
0 5 1 4
0 42 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir3
0
3
0 5 2 4
0 43 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir4
0
3
0 5 3 4
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir6
0
3
0 5 5 4
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir7
0
3
0 5 6 4
0 45 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir1
0
3
0 5 0 5
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir2
0
3
0 5 1 5
0 42 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir3
0
3
0 5 2 5
0 43 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir4
0
3
0 5 3 5
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir5
0
3
0 5 4 5
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir7
0
3
0 5 6 5
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat6 dir7 dir1
0
3
0 5 0 6
0 41 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir2
0
3
0 5 1 6
0 42 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir3
0
3
0 5 2 6
0 43 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir4
0
3
0 5 3 6
0 44 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir5
0
3
0 5 4 6
0 45 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir6
0
3
0 5 5 6
0 46 -1 0
0 47 0 1
1
end_operator
0
