begin_version
3
end_version
begin_metric
1
end_metric
248
begin_variable
var0
-1
10
pointing sat1 dir1
pointing sat1 dir10
pointing sat1 dir2
pointing sat1 dir3
pointing sat1 dir4
pointing sat1 dir5
pointing sat1 dir6
pointing sat1 dir7
pointing sat1 dir8
pointing sat1 dir9
end_variable
begin_variable
var1
-1
10
pointing sat2 dir1
pointing sat2 dir10
pointing sat2 dir2
pointing sat2 dir3
pointing sat2 dir4
pointing sat2 dir5
pointing sat2 dir6
pointing sat2 dir7
pointing sat2 dir8
pointing sat2 dir9
end_variable
begin_variable
var2
-1
10
pointing sat3 dir1
pointing sat3 dir10
pointing sat3 dir2
pointing sat3 dir3
pointing sat3 dir4
pointing sat3 dir5
pointing sat3 dir6
pointing sat3 dir7
pointing sat3 dir8
pointing sat3 dir9
end_variable
begin_variable
var3
-1
10
pointing sat4 dir1
pointing sat4 dir10
pointing sat4 dir2
pointing sat4 dir3
pointing sat4 dir4
pointing sat4 dir5
pointing sat4 dir6
pointing sat4 dir7
pointing sat4 dir8
pointing sat4 dir9
end_variable
begin_variable
var4
-1
10
pointing sat5 dir1
pointing sat5 dir10
pointing sat5 dir2
pointing sat5 dir3
pointing sat5 dir4
pointing sat5 dir5
pointing sat5 dir6
pointing sat5 dir7
pointing sat5 dir8
pointing sat5 dir9
end_variable
begin_variable
var5
-1
10
pointing sat6 dir1
pointing sat6 dir10
pointing sat6 dir2
pointing sat6 dir3
pointing sat6 dir4
pointing sat6 dir5
pointing sat6 dir6
pointing sat6 dir7
pointing sat6 dir8
pointing sat6 dir9
end_variable
begin_variable
var6
-1
10
pointing sat7 dir1
pointing sat7 dir10
pointing sat7 dir2
pointing sat7 dir3
pointing sat7 dir4
pointing sat7 dir5
pointing sat7 dir6
pointing sat7 dir7
pointing sat7 dir8
pointing sat7 dir9
end_variable
begin_variable
var7
-1
10
pointing sat8 dir1
pointing sat8 dir10
pointing sat8 dir2
pointing sat8 dir3
pointing sat8 dir4
pointing sat8 dir5
pointing sat8 dir6
pointing sat8 dir7
pointing sat8 dir8
pointing sat8 dir9
end_variable
begin_variable
var8
-1
10
pointing sat9 dir1
pointing sat9 dir10
pointing sat9 dir2
pointing sat9 dir3
pointing sat9 dir4
pointing sat9 dir5
pointing sat9 dir6
pointing sat9 dir7
pointing sat9 dir8
pointing sat9 dir9
end_variable
begin_variable
var9
-1
2
NOT-pointing sat1 dir1
none-of-those
end_variable
begin_variable
var10
-1
2
NOT-pointing sat1 dir10
none-of-those
end_variable
begin_variable
var11
-1
2
NOT-pointing sat1 dir2
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-pointing sat1 dir3
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-pointing sat1 dir4
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-pointing sat1 dir5
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-pointing sat1 dir6
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-pointing sat1 dir7
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-pointing sat1 dir8
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-pointing sat1 dir9
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-pointing sat2 dir1
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-pointing sat2 dir10
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-pointing sat2 dir2
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-pointing sat2 dir3
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-pointing sat2 dir4
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-pointing sat2 dir5
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-pointing sat2 dir6
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-pointing sat2 dir7
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-pointing sat2 dir8
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-pointing sat2 dir9
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-pointing sat3 dir1
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-pointing sat3 dir10
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-pointing sat3 dir2
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-pointing sat3 dir3
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-pointing sat3 dir4
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-pointing sat3 dir5
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-pointing sat3 dir6
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-pointing sat3 dir7
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-pointing sat3 dir8
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-pointing sat3 dir9
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-pointing sat4 dir1
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-pointing sat4 dir10
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-pointing sat4 dir2
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-pointing sat4 dir3
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-pointing sat4 dir4
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-pointing sat4 dir5
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-pointing sat4 dir6
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-pointing sat4 dir7
none-of-those
end_variable
begin_variable
var47
-1
2
NOT-pointing sat4 dir8
none-of-those
end_variable
begin_variable
var48
-1
2
NOT-pointing sat4 dir9
none-of-those
end_variable
begin_variable
var49
-1
2
NOT-pointing sat5 dir1
none-of-those
end_variable
begin_variable
var50
-1
2
NOT-pointing sat5 dir10
none-of-those
end_variable
begin_variable
var51
-1
2
NOT-pointing sat5 dir2
none-of-those
end_variable
begin_variable
var52
-1
2
NOT-pointing sat5 dir3
none-of-those
end_variable
begin_variable
var53
-1
2
NOT-pointing sat5 dir4
none-of-those
end_variable
begin_variable
var54
-1
2
NOT-pointing sat5 dir5
none-of-those
end_variable
begin_variable
var55
-1
2
NOT-pointing sat5 dir6
none-of-those
end_variable
begin_variable
var56
-1
2
NOT-pointing sat5 dir7
none-of-those
end_variable
begin_variable
var57
-1
2
NOT-pointing sat5 dir8
none-of-those
end_variable
begin_variable
var58
-1
2
NOT-pointing sat5 dir9
none-of-those
end_variable
begin_variable
var59
-1
2
NOT-pointing sat6 dir1
none-of-those
end_variable
begin_variable
var60
-1
2
NOT-pointing sat6 dir10
none-of-those
end_variable
begin_variable
var61
-1
2
NOT-pointing sat6 dir2
none-of-those
end_variable
begin_variable
var62
-1
2
NOT-pointing sat6 dir3
none-of-those
end_variable
begin_variable
var63
-1
2
NOT-pointing sat6 dir4
none-of-those
end_variable
begin_variable
var64
-1
2
NOT-pointing sat6 dir5
none-of-those
end_variable
begin_variable
var65
-1
2
NOT-pointing sat6 dir6
none-of-those
end_variable
begin_variable
var66
-1
2
NOT-pointing sat6 dir7
none-of-those
end_variable
begin_variable
var67
-1
2
NOT-pointing sat6 dir8
none-of-those
end_variable
begin_variable
var68
-1
2
NOT-pointing sat6 dir9
none-of-those
end_variable
begin_variable
var69
-1
2
NOT-pointing sat7 dir1
none-of-those
end_variable
begin_variable
var70
-1
2
NOT-pointing sat7 dir10
none-of-those
end_variable
begin_variable
var71
-1
2
NOT-pointing sat7 dir2
none-of-those
end_variable
begin_variable
var72
-1
2
NOT-pointing sat7 dir3
none-of-those
end_variable
begin_variable
var73
-1
2
NOT-pointing sat7 dir4
none-of-those
end_variable
begin_variable
var74
-1
2
NOT-pointing sat7 dir5
none-of-those
end_variable
begin_variable
var75
-1
2
NOT-pointing sat7 dir6
none-of-those
end_variable
begin_variable
var76
-1
2
NOT-pointing sat7 dir7
none-of-those
end_variable
begin_variable
var77
-1
2
NOT-pointing sat7 dir8
none-of-those
end_variable
begin_variable
var78
-1
2
NOT-pointing sat7 dir9
none-of-those
end_variable
begin_variable
var79
-1
2
NOT-pointing sat8 dir1
none-of-those
end_variable
begin_variable
var80
-1
2
NOT-pointing sat8 dir10
none-of-those
end_variable
begin_variable
var81
-1
2
NOT-pointing sat8 dir2
none-of-those
end_variable
begin_variable
var82
-1
2
NOT-pointing sat8 dir3
none-of-those
end_variable
begin_variable
var83
-1
2
NOT-pointing sat8 dir4
none-of-those
end_variable
begin_variable
var84
-1
2
NOT-pointing sat8 dir5
none-of-those
end_variable
begin_variable
var85
-1
2
NOT-pointing sat8 dir6
none-of-those
end_variable
begin_variable
var86
-1
2
NOT-pointing sat8 dir7
none-of-those
end_variable
begin_variable
var87
-1
2
NOT-pointing sat8 dir8
none-of-those
end_variable
begin_variable
var88
-1
2
NOT-pointing sat8 dir9
none-of-those
end_variable
begin_variable
var89
-1
2
NOT-pointing sat9 dir1
none-of-those
end_variable
begin_variable
var90
-1
2
NOT-pointing sat9 dir10
none-of-those
end_variable
begin_variable
var91
-1
2
NOT-pointing sat9 dir2
none-of-those
end_variable
begin_variable
var92
-1
2
NOT-pointing sat9 dir3
none-of-those
end_variable
begin_variable
var93
-1
2
NOT-pointing sat9 dir4
none-of-those
end_variable
begin_variable
var94
-1
2
NOT-pointing sat9 dir5
none-of-those
end_variable
begin_variable
var95
-1
2
NOT-pointing sat9 dir6
none-of-those
end_variable
begin_variable
var96
-1
2
NOT-pointing sat9 dir7
none-of-those
end_variable
begin_variable
var97
-1
2
NOT-pointing sat9 dir8
none-of-those
end_variable
begin_variable
var98
-1
2
NOT-pointing sat9 dir9
none-of-those
end_variable
begin_variable
var99
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var100
-1
2
calibrated ins10
none-of-those
end_variable
begin_variable
var101
-1
2
calibrated ins11
none-of-those
end_variable
begin_variable
var102
-1
2
calibrated ins12
none-of-those
end_variable
begin_variable
var103
-1
2
calibrated ins13
none-of-those
end_variable
begin_variable
var104
-1
2
calibrated ins14
none-of-those
end_variable
begin_variable
var105
-1
2
calibrated ins15
none-of-those
end_variable
begin_variable
var106
-1
2
calibrated ins16
none-of-those
end_variable
begin_variable
var107
-1
2
calibrated ins17
none-of-those
end_variable
begin_variable
var108
-1
2
calibrated ins18
none-of-those
end_variable
begin_variable
var109
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var110
-1
2
calibrated ins3
none-of-those
end_variable
begin_variable
var111
-1
2
calibrated ins4
none-of-those
end_variable
begin_variable
var112
-1
2
calibrated ins5
none-of-those
end_variable
begin_variable
var113
-1
2
calibrated ins6
none-of-those
end_variable
begin_variable
var114
-1
2
calibrated ins7
none-of-those
end_variable
begin_variable
var115
-1
2
calibrated ins8
none-of-those
end_variable
begin_variable
var116
-1
2
calibrated ins9
none-of-those
end_variable
begin_variable
var117
-1
2
calibration_target ins1 dir5
none-of-those
end_variable
begin_variable
var118
-1
2
calibration_target ins10 dir5
none-of-those
end_variable
begin_variable
var119
-1
2
calibration_target ins11 dir5
none-of-those
end_variable
begin_variable
var120
-1
2
calibration_target ins12 dir4
none-of-those
end_variable
begin_variable
var121
-1
2
calibration_target ins13 dir4
none-of-those
end_variable
begin_variable
var122
-1
2
calibration_target ins14 dir9
none-of-those
end_variable
begin_variable
var123
-1
2
calibration_target ins15 dir9
none-of-those
end_variable
begin_variable
var124
-1
2
calibration_target ins16 dir2
none-of-those
end_variable
begin_variable
var125
-1
2
calibration_target ins17 dir7
none-of-those
end_variable
begin_variable
var126
-1
2
calibration_target ins18 dir4
none-of-those
end_variable
begin_variable
var127
-1
2
calibration_target ins2 dir6
none-of-those
end_variable
begin_variable
var128
-1
2
calibration_target ins3 dir6
none-of-those
end_variable
begin_variable
var129
-1
2
calibration_target ins4 dir3
none-of-those
end_variable
begin_variable
var130
-1
2
calibration_target ins5 dir2
none-of-those
end_variable
begin_variable
var131
-1
2
calibration_target ins6 dir6
none-of-those
end_variable
begin_variable
var132
-1
2
calibration_target ins7 dir5
none-of-those
end_variable
begin_variable
var133
-1
2
calibration_target ins8 dir3
none-of-those
end_variable
begin_variable
var134
-1
2
calibration_target ins9 dir5
none-of-those
end_variable
begin_variable
var135
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var136
-1
2
have_image dir1 mod2
none-of-those
end_variable
begin_variable
var137
-1
2
have_image dir1 mod3
none-of-those
end_variable
begin_variable
var138
-1
2
have_image dir10 mod1
none-of-those
end_variable
begin_variable
var139
-1
2
have_image dir10 mod2
none-of-those
end_variable
begin_variable
var140
-1
2
have_image dir10 mod3
none-of-those
end_variable
begin_variable
var141
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var142
-1
2
have_image dir2 mod2
none-of-those
end_variable
begin_variable
var143
-1
2
have_image dir2 mod3
none-of-those
end_variable
begin_variable
var144
-1
2
have_image dir3 mod1
none-of-those
end_variable
begin_variable
var145
-1
2
have_image dir3 mod2
none-of-those
end_variable
begin_variable
var146
-1
2
have_image dir3 mod3
none-of-those
end_variable
begin_variable
var147
-1
2
have_image dir4 mod1
none-of-those
end_variable
begin_variable
var148
-1
2
have_image dir4 mod2
none-of-those
end_variable
begin_variable
var149
-1
2
have_image dir4 mod3
none-of-those
end_variable
begin_variable
var150
-1
2
have_image dir5 mod1
none-of-those
end_variable
begin_variable
var151
-1
2
have_image dir5 mod2
none-of-those
end_variable
begin_variable
var152
-1
2
have_image dir5 mod3
none-of-those
end_variable
begin_variable
var153
-1
2
have_image dir6 mod1
none-of-those
end_variable
begin_variable
var154
-1
2
have_image dir6 mod2
none-of-those
end_variable
begin_variable
var155
-1
2
have_image dir6 mod3
none-of-those
end_variable
begin_variable
var156
-1
2
have_image dir7 mod1
none-of-those
end_variable
begin_variable
var157
-1
2
have_image dir7 mod2
none-of-those
end_variable
begin_variable
var158
-1
2
have_image dir7 mod3
none-of-those
end_variable
begin_variable
var159
-1
2
have_image dir8 mod1
none-of-those
end_variable
begin_variable
var160
-1
2
have_image dir8 mod2
none-of-those
end_variable
begin_variable
var161
-1
2
have_image dir8 mod3
none-of-those
end_variable
begin_variable
var162
-1
2
have_image dir9 mod1
none-of-those
end_variable
begin_variable
var163
-1
2
have_image dir9 mod2
none-of-those
end_variable
begin_variable
var164
-1
2
have_image dir9 mod3
none-of-those
end_variable
begin_variable
var165
-1
2
on_board ins1 sat6
none-of-those
end_variable
begin_variable
var166
-1
2
on_board ins10 sat7
none-of-those
end_variable
begin_variable
var167
-1
2
on_board ins11 sat9
none-of-those
end_variable
begin_variable
var168
-1
2
on_board ins12 sat7
none-of-those
end_variable
begin_variable
var169
-1
2
on_board ins13 sat2
none-of-those
end_variable
begin_variable
var170
-1
2
on_board ins14 sat1
none-of-those
end_variable
begin_variable
var171
-1
2
on_board ins15 sat1
none-of-those
end_variable
begin_variable
var172
-1
2
on_board ins16 sat7
none-of-those
end_variable
begin_variable
var173
-1
2
on_board ins17 sat6
none-of-those
end_variable
begin_variable
var174
-1
2
on_board ins18 sat5
none-of-those
end_variable
begin_variable
var175
-1
2
on_board ins2 sat3
none-of-those
end_variable
begin_variable
var176
-1
2
on_board ins3 sat2
none-of-those
end_variable
begin_variable
var177
-1
2
on_board ins4 sat5
none-of-those
end_variable
begin_variable
var178
-1
2
on_board ins5 sat9
none-of-those
end_variable
begin_variable
var179
-1
2
on_board ins6 sat7
none-of-those
end_variable
begin_variable
var180
-1
2
on_board ins7 sat8
none-of-those
end_variable
begin_variable
var181
-1
2
on_board ins8 sat1
none-of-those
end_variable
begin_variable
var182
-1
2
on_board ins9 sat4
none-of-those
end_variable
begin_variable
var183
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var184
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var185
-1
2
power_avail sat3
none-of-those
end_variable
begin_variable
var186
-1
2
power_avail sat4
none-of-those
end_variable
begin_variable
var187
-1
2
power_avail sat5
none-of-those
end_variable
begin_variable
var188
-1
2
power_avail sat6
none-of-those
end_variable
begin_variable
var189
-1
2
power_avail sat7
none-of-those
end_variable
begin_variable
var190
-1
2
power_avail sat8
none-of-those
end_variable
begin_variable
var191
-1
2
power_avail sat9
none-of-those
end_variable
begin_variable
var192
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var193
-1
2
power_on ins10
none-of-those
end_variable
begin_variable
var194
-1
2
power_on ins11
none-of-those
end_variable
begin_variable
var195
-1
2
power_on ins12
none-of-those
end_variable
begin_variable
var196
-1
2
power_on ins13
none-of-those
end_variable
begin_variable
var197
-1
2
power_on ins14
none-of-those
end_variable
begin_variable
var198
-1
2
power_on ins15
none-of-those
end_variable
begin_variable
var199
-1
2
power_on ins16
none-of-those
end_variable
begin_variable
var200
-1
2
power_on ins17
none-of-those
end_variable
begin_variable
var201
-1
2
power_on ins18
none-of-those
end_variable
begin_variable
var202
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var203
-1
2
power_on ins3
none-of-those
end_variable
begin_variable
var204
-1
2
power_on ins4
none-of-those
end_variable
begin_variable
var205
-1
2
power_on ins5
none-of-those
end_variable
begin_variable
var206
-1
2
power_on ins6
none-of-those
end_variable
begin_variable
var207
-1
2
power_on ins7
none-of-those
end_variable
begin_variable
var208
-1
2
power_on ins8
none-of-those
end_variable
begin_variable
var209
-1
2
power_on ins9
none-of-those
end_variable
begin_variable
var210
-1
2
supports ins1 mod1
none-of-those
end_variable
begin_variable
var211
-1
2
supports ins1 mod2
none-of-those
end_variable
begin_variable
var212
-1
2
supports ins1 mod3
none-of-those
end_variable
begin_variable
var213
-1
2
supports ins10 mod2
none-of-those
end_variable
begin_variable
var214
-1
2
supports ins10 mod3
none-of-those
end_variable
begin_variable
var215
-1
2
supports ins11 mod2
none-of-those
end_variable
begin_variable
var216
-1
2
supports ins11 mod3
none-of-those
end_variable
begin_variable
var217
-1
2
supports ins12 mod1
none-of-those
end_variable
begin_variable
var218
-1
2
supports ins12 mod2
none-of-those
end_variable
begin_variable
var219
-1
2
supports ins12 mod3
none-of-those
end_variable
begin_variable
var220
-1
2
supports ins13 mod2
none-of-those
end_variable
begin_variable
var221
-1
2
supports ins14 mod2
none-of-those
end_variable
begin_variable
var222
-1
2
supports ins14 mod3
none-of-those
end_variable
begin_variable
var223
-1
2
supports ins15 mod1
none-of-those
end_variable
begin_variable
var224
-1
2
supports ins15 mod2
none-of-those
end_variable
begin_variable
var225
-1
2
supports ins15 mod3
none-of-those
end_variable
begin_variable
var226
-1
2
supports ins16 mod3
none-of-those
end_variable
begin_variable
var227
-1
2
supports ins17 mod1
none-of-those
end_variable
begin_variable
var228
-1
2
supports ins17 mod3
none-of-those
end_variable
begin_variable
var229
-1
2
supports ins18 mod1
none-of-those
end_variable
begin_variable
var230
-1
2
supports ins18 mod2
none-of-those
end_variable
begin_variable
var231
-1
2
supports ins18 mod3
none-of-those
end_variable
begin_variable
var232
-1
2
supports ins2 mod1
none-of-those
end_variable
begin_variable
var233
-1
2
supports ins2 mod2
none-of-those
end_variable
begin_variable
var234
-1
2
supports ins2 mod3
none-of-those
end_variable
begin_variable
var235
-1
2
supports ins3 mod1
none-of-those
end_variable
begin_variable
var236
-1
2
supports ins3 mod2
none-of-those
end_variable
begin_variable
var237
-1
2
supports ins4 mod1
none-of-those
end_variable
begin_variable
var238
-1
2
supports ins4 mod2
none-of-those
end_variable
begin_variable
var239
-1
2
supports ins4 mod3
none-of-those
end_variable
begin_variable
var240
-1
2
supports ins5 mod1
none-of-those
end_variable
begin_variable
var241
-1
2
supports ins5 mod3
none-of-those
end_variable
begin_variable
var242
-1
2
supports ins6 mod1
none-of-those
end_variable
begin_variable
var243
-1
2
supports ins7 mod1
none-of-those
end_variable
begin_variable
var244
-1
2
supports ins7 mod2
none-of-those
end_variable
begin_variable
var245
-1
2
supports ins8 mod1
none-of-those
end_variable
begin_variable
var246
-1
2
supports ins8 mod3
none-of-those
end_variable
begin_variable
var247
-1
2
supports ins9 mod2
none-of-those
end_variable
0
begin_state
9
4
4
1
8
2
6
4
4
0
0
0
0
0
0
0
0
0
1
0
0
0
0
1
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
11
0 9
3 8
4 9
5 6
6 7
7 7
8 8
137 0
141 0
151 0
156 0
end_goal
1244
begin_operator
calibrate sat1 ins14 dir9
4
0 9
122 0
170 0
197 0
1
0 104 -1 0
1
end_operator
begin_operator
calibrate sat1 ins15 dir9
4
0 9
123 0
171 0
198 0
1
0 105 -1 0
1
end_operator
begin_operator
calibrate sat1 ins8 dir3
4
0 3
133 0
181 0
208 0
1
0 115 -1 0
1
end_operator
begin_operator
calibrate sat2 ins13 dir4
4
1 4
121 0
169 0
196 0
1
0 103 -1 0
1
end_operator
begin_operator
calibrate sat2 ins3 dir6
4
1 6
128 0
176 0
203 0
1
0 110 -1 0
1
end_operator
begin_operator
calibrate sat3 ins2 dir6
4
2 6
127 0
175 0
202 0
1
0 109 -1 0
1
end_operator
begin_operator
calibrate sat4 ins9 dir5
4
3 5
134 0
182 0
209 0
1
0 116 -1 0
1
end_operator
begin_operator
calibrate sat5 ins18 dir4
4
4 4
126 0
174 0
201 0
1
0 108 -1 0
1
end_operator
begin_operator
calibrate sat5 ins4 dir3
4
4 3
129 0
177 0
204 0
1
0 111 -1 0
1
end_operator
begin_operator
calibrate sat6 ins1 dir5
4
5 5
117 0
165 0
192 0
1
0 99 -1 0
1
end_operator
begin_operator
calibrate sat6 ins17 dir7
4
5 7
125 0
173 0
200 0
1
0 107 -1 0
1
end_operator
begin_operator
calibrate sat7 ins10 dir5
4
6 5
118 0
166 0
193 0
1
0 100 -1 0
1
end_operator
begin_operator
calibrate sat7 ins12 dir4
4
6 4
120 0
168 0
195 0
1
0 102 -1 0
1
end_operator
begin_operator
calibrate sat7 ins16 dir2
4
6 2
124 0
172 0
199 0
1
0 106 -1 0
1
end_operator
begin_operator
calibrate sat7 ins6 dir6
4
6 6
131 0
179 0
206 0
1
0 113 -1 0
1
end_operator
begin_operator
calibrate sat8 ins7 dir5
4
7 5
132 0
180 0
207 0
1
0 114 -1 0
1
end_operator
begin_operator
calibrate sat9 ins11 dir5
4
8 5
119 0
167 0
194 0
1
0 101 -1 0
1
end_operator
begin_operator
calibrate sat9 ins5 dir2
4
8 2
130 0
178 0
205 0
1
0 112 -1 0
1
end_operator
begin_operator
switch_off ins1 sat6
1
165 0
2
0 188 -1 0
0 192 0 1
1
end_operator
begin_operator
switch_off ins10 sat7
1
166 0
2
0 189 -1 0
0 193 0 1
1
end_operator
begin_operator
switch_off ins11 sat9
1
167 0
2
0 191 -1 0
0 194 0 1
1
end_operator
begin_operator
switch_off ins12 sat7
1
168 0
2
0 189 -1 0
0 195 0 1
1
end_operator
begin_operator
switch_off ins13 sat2
1
169 0
2
0 184 -1 0
0 196 0 1
1
end_operator
begin_operator
switch_off ins14 sat1
1
170 0
2
0 183 -1 0
0 197 0 1
1
end_operator
begin_operator
switch_off ins15 sat1
1
171 0
2
0 183 -1 0
0 198 0 1
1
end_operator
begin_operator
switch_off ins16 sat7
1
172 0
2
0 189 -1 0
0 199 0 1
1
end_operator
begin_operator
switch_off ins17 sat6
1
173 0
2
0 188 -1 0
0 200 0 1
1
end_operator
begin_operator
switch_off ins18 sat5
1
174 0
2
0 187 -1 0
0 201 0 1
1
end_operator
begin_operator
switch_off ins2 sat3
1
175 0
2
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
switch_off ins3 sat2
1
176 0
2
0 184 -1 0
0 203 0 1
1
end_operator
begin_operator
switch_off ins4 sat5
1
177 0
2
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
switch_off ins5 sat9
1
178 0
2
0 191 -1 0
0 205 0 1
1
end_operator
begin_operator
switch_off ins6 sat7
1
179 0
2
0 189 -1 0
0 206 0 1
1
end_operator
begin_operator
switch_off ins7 sat8
1
180 0
2
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
switch_off ins8 sat1
1
181 0
2
0 183 -1 0
0 208 0 1
1
end_operator
begin_operator
switch_off ins9 sat4
1
182 0
2
0 186 -1 0
0 209 0 1
1
end_operator
begin_operator
switch_on ins1 sat6
1
165 0
3
0 99 -1 1
0 188 0 1
0 192 -1 0
1
end_operator
begin_operator
switch_on ins10 sat7
1
166 0
3
0 100 -1 1
0 189 0 1
0 193 -1 0
1
end_operator
begin_operator
switch_on ins11 sat9
1
167 0
3
0 101 -1 1
0 191 0 1
0 194 -1 0
1
end_operator
begin_operator
switch_on ins12 sat7
1
168 0
3
0 102 -1 1
0 189 0 1
0 195 -1 0
1
end_operator
begin_operator
switch_on ins13 sat2
1
169 0
3
0 103 -1 1
0 184 0 1
0 196 -1 0
1
end_operator
begin_operator
switch_on ins14 sat1
1
170 0
3
0 104 -1 1
0 183 0 1
0 197 -1 0
1
end_operator
begin_operator
switch_on ins15 sat1
1
171 0
3
0 105 -1 1
0 183 0 1
0 198 -1 0
1
end_operator
begin_operator
switch_on ins16 sat7
1
172 0
3
0 106 -1 1
0 189 0 1
0 199 -1 0
1
end_operator
begin_operator
switch_on ins17 sat6
1
173 0
3
0 107 -1 1
0 188 0 1
0 200 -1 0
1
end_operator
begin_operator
switch_on ins18 sat5
1
174 0
3
0 108 -1 1
0 187 0 1
0 201 -1 0
1
end_operator
begin_operator
switch_on ins2 sat3
1
175 0
3
0 109 -1 1
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
switch_on ins3 sat2
1
176 0
3
0 110 -1 1
0 184 0 1
0 203 -1 0
1
end_operator
begin_operator
switch_on ins4 sat5
1
177 0
3
0 111 -1 1
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
switch_on ins5 sat9
1
178 0
3
0 112 -1 1
0 191 0 1
0 205 -1 0
1
end_operator
begin_operator
switch_on ins6 sat7
1
179 0
3
0 113 -1 1
0 189 0 1
0 206 -1 0
1
end_operator
begin_operator
switch_on ins7 sat8
1
180 0
3
0 114 -1 1
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
switch_on ins8 sat1
1
181 0
3
0 115 -1 1
0 183 0 1
0 208 -1 0
1
end_operator
begin_operator
switch_on ins9 sat4
1
182 0
3
0 116 -1 1
0 186 0 1
0 209 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins14 mod2
5
0 0
104 0
170 0
197 0
221 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins14 mod3
5
0 0
104 0
170 0
197 0
222 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins15 mod1
5
0 0
105 0
171 0
198 0
223 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins15 mod2
5
0 0
105 0
171 0
198 0
224 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins15 mod3
5
0 0
105 0
171 0
198 0
225 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins8 mod1
5
0 0
115 0
181 0
208 0
245 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins8 mod3
5
0 0
115 0
181 0
208 0
246 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins14 mod2
5
0 1
104 0
170 0
197 0
221 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins14 mod3
5
0 1
104 0
170 0
197 0
222 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins15 mod1
5
0 1
105 0
171 0
198 0
223 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins15 mod2
5
0 1
105 0
171 0
198 0
224 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins15 mod3
5
0 1
105 0
171 0
198 0
225 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins8 mod1
5
0 1
115 0
181 0
208 0
245 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat1 dir10 ins8 mod3
5
0 1
115 0
181 0
208 0
246 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins14 mod2
5
0 2
104 0
170 0
197 0
221 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins14 mod3
5
0 2
104 0
170 0
197 0
222 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins15 mod1
5
0 2
105 0
171 0
198 0
223 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins15 mod2
5
0 2
105 0
171 0
198 0
224 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins15 mod3
5
0 2
105 0
171 0
198 0
225 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins8 mod1
5
0 2
115 0
181 0
208 0
245 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins8 mod3
5
0 2
115 0
181 0
208 0
246 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins14 mod2
5
0 3
104 0
170 0
197 0
221 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins14 mod3
5
0 3
104 0
170 0
197 0
222 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins15 mod1
5
0 3
105 0
171 0
198 0
223 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins15 mod2
5
0 3
105 0
171 0
198 0
224 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins15 mod3
5
0 3
105 0
171 0
198 0
225 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins8 mod1
5
0 3
115 0
181 0
208 0
245 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins8 mod3
5
0 3
115 0
181 0
208 0
246 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins14 mod2
5
0 4
104 0
170 0
197 0
221 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins14 mod3
5
0 4
104 0
170 0
197 0
222 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins15 mod1
5
0 4
105 0
171 0
198 0
223 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins15 mod2
5
0 4
105 0
171 0
198 0
224 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins15 mod3
5
0 4
105 0
171 0
198 0
225 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins8 mod1
5
0 4
115 0
181 0
208 0
245 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins8 mod3
5
0 4
115 0
181 0
208 0
246 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins14 mod2
5
0 5
104 0
170 0
197 0
221 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins14 mod3
5
0 5
104 0
170 0
197 0
222 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins15 mod1
5
0 5
105 0
171 0
198 0
223 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins15 mod2
5
0 5
105 0
171 0
198 0
224 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins15 mod3
5
0 5
105 0
171 0
198 0
225 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins8 mod1
5
0 5
115 0
181 0
208 0
245 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins8 mod3
5
0 5
115 0
181 0
208 0
246 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins14 mod2
5
0 6
104 0
170 0
197 0
221 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins14 mod3
5
0 6
104 0
170 0
197 0
222 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins15 mod1
5
0 6
105 0
171 0
198 0
223 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins15 mod2
5
0 6
105 0
171 0
198 0
224 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins15 mod3
5
0 6
105 0
171 0
198 0
225 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins8 mod1
5
0 6
115 0
181 0
208 0
245 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins8 mod3
5
0 6
115 0
181 0
208 0
246 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins14 mod2
5
0 7
104 0
170 0
197 0
221 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins14 mod3
5
0 7
104 0
170 0
197 0
222 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins15 mod1
5
0 7
105 0
171 0
198 0
223 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins15 mod2
5
0 7
105 0
171 0
198 0
224 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins15 mod3
5
0 7
105 0
171 0
198 0
225 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins8 mod1
5
0 7
115 0
181 0
208 0
245 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins8 mod3
5
0 7
115 0
181 0
208 0
246 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins14 mod2
5
0 8
104 0
170 0
197 0
221 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins14 mod3
5
0 8
104 0
170 0
197 0
222 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins15 mod1
5
0 8
105 0
171 0
198 0
223 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins15 mod2
5
0 8
105 0
171 0
198 0
224 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins15 mod3
5
0 8
105 0
171 0
198 0
225 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins8 mod1
5
0 8
115 0
181 0
208 0
245 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins8 mod3
5
0 8
115 0
181 0
208 0
246 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins14 mod2
5
0 9
104 0
170 0
197 0
221 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins14 mod3
5
0 9
104 0
170 0
197 0
222 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins15 mod1
5
0 9
105 0
171 0
198 0
223 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins15 mod2
5
0 9
105 0
171 0
198 0
224 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins15 mod3
5
0 9
105 0
171 0
198 0
225 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins8 mod1
5
0 9
115 0
181 0
208 0
245 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins8 mod3
5
0 9
115 0
181 0
208 0
246 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins13 mod2
5
1 0
103 0
169 0
196 0
220 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins3 mod1
5
1 0
110 0
176 0
203 0
235 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins3 mod2
5
1 0
110 0
176 0
203 0
236 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat2 dir10 ins13 mod2
5
1 1
103 0
169 0
196 0
220 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat2 dir10 ins3 mod1
5
1 1
110 0
176 0
203 0
235 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat2 dir10 ins3 mod2
5
1 1
110 0
176 0
203 0
236 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins13 mod2
5
1 2
103 0
169 0
196 0
220 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins3 mod1
5
1 2
110 0
176 0
203 0
235 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins3 mod2
5
1 2
110 0
176 0
203 0
236 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins13 mod2
5
1 3
103 0
169 0
196 0
220 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins3 mod1
5
1 3
110 0
176 0
203 0
235 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins3 mod2
5
1 3
110 0
176 0
203 0
236 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins13 mod2
5
1 4
103 0
169 0
196 0
220 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins3 mod1
5
1 4
110 0
176 0
203 0
235 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins3 mod2
5
1 4
110 0
176 0
203 0
236 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins13 mod2
5
1 5
103 0
169 0
196 0
220 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins3 mod1
5
1 5
110 0
176 0
203 0
235 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins3 mod2
5
1 5
110 0
176 0
203 0
236 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins13 mod2
5
1 6
103 0
169 0
196 0
220 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins3 mod1
5
1 6
110 0
176 0
203 0
235 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins3 mod2
5
1 6
110 0
176 0
203 0
236 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins13 mod2
5
1 7
103 0
169 0
196 0
220 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins3 mod1
5
1 7
110 0
176 0
203 0
235 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins3 mod2
5
1 7
110 0
176 0
203 0
236 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat2 dir8 ins13 mod2
5
1 8
103 0
169 0
196 0
220 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat2 dir8 ins3 mod1
5
1 8
110 0
176 0
203 0
235 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat2 dir8 ins3 mod2
5
1 8
110 0
176 0
203 0
236 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat2 dir9 ins13 mod2
5
1 9
103 0
169 0
196 0
220 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat2 dir9 ins3 mod1
5
1 9
110 0
176 0
203 0
235 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat2 dir9 ins3 mod2
5
1 9
110 0
176 0
203 0
236 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins2 mod1
5
2 0
109 0
175 0
202 0
232 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins2 mod2
5
2 0
109 0
175 0
202 0
233 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins2 mod3
5
2 0
109 0
175 0
202 0
234 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat3 dir10 ins2 mod1
5
2 1
109 0
175 0
202 0
232 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat3 dir10 ins2 mod2
5
2 1
109 0
175 0
202 0
233 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat3 dir10 ins2 mod3
5
2 1
109 0
175 0
202 0
234 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins2 mod1
5
2 2
109 0
175 0
202 0
232 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins2 mod2
5
2 2
109 0
175 0
202 0
233 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins2 mod3
5
2 2
109 0
175 0
202 0
234 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins2 mod1
5
2 3
109 0
175 0
202 0
232 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins2 mod2
5
2 3
109 0
175 0
202 0
233 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins2 mod3
5
2 3
109 0
175 0
202 0
234 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins2 mod1
5
2 4
109 0
175 0
202 0
232 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins2 mod2
5
2 4
109 0
175 0
202 0
233 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins2 mod3
5
2 4
109 0
175 0
202 0
234 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins2 mod1
5
2 5
109 0
175 0
202 0
232 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins2 mod2
5
2 5
109 0
175 0
202 0
233 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins2 mod3
5
2 5
109 0
175 0
202 0
234 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins2 mod1
5
2 6
109 0
175 0
202 0
232 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins2 mod2
5
2 6
109 0
175 0
202 0
233 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins2 mod3
5
2 6
109 0
175 0
202 0
234 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins2 mod1
5
2 7
109 0
175 0
202 0
232 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins2 mod2
5
2 7
109 0
175 0
202 0
233 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins2 mod3
5
2 7
109 0
175 0
202 0
234 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins2 mod1
5
2 8
109 0
175 0
202 0
232 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins2 mod2
5
2 8
109 0
175 0
202 0
233 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins2 mod3
5
2 8
109 0
175 0
202 0
234 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins2 mod1
5
2 9
109 0
175 0
202 0
232 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins2 mod2
5
2 9
109 0
175 0
202 0
233 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins2 mod3
5
2 9
109 0
175 0
202 0
234 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins9 mod2
5
3 0
116 0
182 0
209 0
247 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat4 dir10 ins9 mod2
5
3 1
116 0
182 0
209 0
247 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins9 mod2
5
3 2
116 0
182 0
209 0
247 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins9 mod2
5
3 3
116 0
182 0
209 0
247 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins9 mod2
5
3 4
116 0
182 0
209 0
247 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins9 mod2
5
3 5
116 0
182 0
209 0
247 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins9 mod2
5
3 6
116 0
182 0
209 0
247 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins9 mod2
5
3 7
116 0
182 0
209 0
247 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins9 mod2
5
3 8
116 0
182 0
209 0
247 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins9 mod2
5
3 9
116 0
182 0
209 0
247 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins18 mod1
5
4 0
108 0
174 0
201 0
229 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins18 mod2
5
4 0
108 0
174 0
201 0
230 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins18 mod3
5
4 0
108 0
174 0
201 0
231 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins4 mod1
5
4 0
111 0
177 0
204 0
237 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins4 mod2
5
4 0
111 0
177 0
204 0
238 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins4 mod3
5
4 0
111 0
177 0
204 0
239 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins18 mod1
5
4 1
108 0
174 0
201 0
229 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins18 mod2
5
4 1
108 0
174 0
201 0
230 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins18 mod3
5
4 1
108 0
174 0
201 0
231 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins4 mod1
5
4 1
111 0
177 0
204 0
237 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins4 mod2
5
4 1
111 0
177 0
204 0
238 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat5 dir10 ins4 mod3
5
4 1
111 0
177 0
204 0
239 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins18 mod1
5
4 2
108 0
174 0
201 0
229 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins18 mod2
5
4 2
108 0
174 0
201 0
230 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins18 mod3
5
4 2
108 0
174 0
201 0
231 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins4 mod1
5
4 2
111 0
177 0
204 0
237 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins4 mod2
5
4 2
111 0
177 0
204 0
238 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins4 mod3
5
4 2
111 0
177 0
204 0
239 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins18 mod1
5
4 3
108 0
174 0
201 0
229 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins18 mod2
5
4 3
108 0
174 0
201 0
230 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins18 mod3
5
4 3
108 0
174 0
201 0
231 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins4 mod1
5
4 3
111 0
177 0
204 0
237 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins4 mod2
5
4 3
111 0
177 0
204 0
238 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins4 mod3
5
4 3
111 0
177 0
204 0
239 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins18 mod1
5
4 4
108 0
174 0
201 0
229 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins18 mod2
5
4 4
108 0
174 0
201 0
230 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins18 mod3
5
4 4
108 0
174 0
201 0
231 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins4 mod1
5
4 4
111 0
177 0
204 0
237 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins4 mod2
5
4 4
111 0
177 0
204 0
238 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins4 mod3
5
4 4
111 0
177 0
204 0
239 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins18 mod1
5
4 5
108 0
174 0
201 0
229 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins18 mod2
5
4 5
108 0
174 0
201 0
230 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins18 mod3
5
4 5
108 0
174 0
201 0
231 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins4 mod1
5
4 5
111 0
177 0
204 0
237 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins4 mod2
5
4 5
111 0
177 0
204 0
238 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins4 mod3
5
4 5
111 0
177 0
204 0
239 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins18 mod1
5
4 6
108 0
174 0
201 0
229 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins18 mod2
5
4 6
108 0
174 0
201 0
230 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins18 mod3
5
4 6
108 0
174 0
201 0
231 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins4 mod1
5
4 6
111 0
177 0
204 0
237 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins4 mod2
5
4 6
111 0
177 0
204 0
238 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins4 mod3
5
4 6
111 0
177 0
204 0
239 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins18 mod1
5
4 7
108 0
174 0
201 0
229 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins18 mod2
5
4 7
108 0
174 0
201 0
230 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins18 mod3
5
4 7
108 0
174 0
201 0
231 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins4 mod1
5
4 7
111 0
177 0
204 0
237 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins4 mod2
5
4 7
111 0
177 0
204 0
238 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins4 mod3
5
4 7
111 0
177 0
204 0
239 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins18 mod1
5
4 8
108 0
174 0
201 0
229 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins18 mod2
5
4 8
108 0
174 0
201 0
230 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins18 mod3
5
4 8
108 0
174 0
201 0
231 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins4 mod1
5
4 8
111 0
177 0
204 0
237 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins4 mod2
5
4 8
111 0
177 0
204 0
238 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins4 mod3
5
4 8
111 0
177 0
204 0
239 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins18 mod1
5
4 9
108 0
174 0
201 0
229 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins18 mod2
5
4 9
108 0
174 0
201 0
230 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins18 mod3
5
4 9
108 0
174 0
201 0
231 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins4 mod1
5
4 9
111 0
177 0
204 0
237 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins4 mod2
5
4 9
111 0
177 0
204 0
238 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins4 mod3
5
4 9
111 0
177 0
204 0
239 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins1 mod1
5
5 0
99 0
165 0
192 0
210 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins1 mod2
5
5 0
99 0
165 0
192 0
211 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins1 mod3
5
5 0
99 0
165 0
192 0
212 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins17 mod1
5
5 0
107 0
173 0
200 0
227 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins17 mod3
5
5 0
107 0
173 0
200 0
228 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat6 dir10 ins1 mod1
5
5 1
99 0
165 0
192 0
210 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat6 dir10 ins1 mod2
5
5 1
99 0
165 0
192 0
211 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat6 dir10 ins1 mod3
5
5 1
99 0
165 0
192 0
212 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat6 dir10 ins17 mod1
5
5 1
107 0
173 0
200 0
227 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat6 dir10 ins17 mod3
5
5 1
107 0
173 0
200 0
228 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins1 mod1
5
5 2
99 0
165 0
192 0
210 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins1 mod2
5
5 2
99 0
165 0
192 0
211 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins1 mod3
5
5 2
99 0
165 0
192 0
212 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins17 mod1
5
5 2
107 0
173 0
200 0
227 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins17 mod3
5
5 2
107 0
173 0
200 0
228 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins1 mod1
5
5 3
99 0
165 0
192 0
210 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins1 mod2
5
5 3
99 0
165 0
192 0
211 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins1 mod3
5
5 3
99 0
165 0
192 0
212 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins17 mod1
5
5 3
107 0
173 0
200 0
227 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins17 mod3
5
5 3
107 0
173 0
200 0
228 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins1 mod1
5
5 4
99 0
165 0
192 0
210 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins1 mod2
5
5 4
99 0
165 0
192 0
211 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins1 mod3
5
5 4
99 0
165 0
192 0
212 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins17 mod1
5
5 4
107 0
173 0
200 0
227 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins17 mod3
5
5 4
107 0
173 0
200 0
228 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins1 mod1
5
5 5
99 0
165 0
192 0
210 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins1 mod2
5
5 5
99 0
165 0
192 0
211 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins1 mod3
5
5 5
99 0
165 0
192 0
212 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins17 mod1
5
5 5
107 0
173 0
200 0
227 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins17 mod3
5
5 5
107 0
173 0
200 0
228 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins1 mod1
5
5 6
99 0
165 0
192 0
210 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins1 mod2
5
5 6
99 0
165 0
192 0
211 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins1 mod3
5
5 6
99 0
165 0
192 0
212 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins17 mod1
5
5 6
107 0
173 0
200 0
227 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins17 mod3
5
5 6
107 0
173 0
200 0
228 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins1 mod1
5
5 7
99 0
165 0
192 0
210 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins1 mod2
5
5 7
99 0
165 0
192 0
211 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins1 mod3
5
5 7
99 0
165 0
192 0
212 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins17 mod1
5
5 7
107 0
173 0
200 0
227 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins17 mod3
5
5 7
107 0
173 0
200 0
228 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins1 mod1
5
5 8
99 0
165 0
192 0
210 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins1 mod2
5
5 8
99 0
165 0
192 0
211 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins1 mod3
5
5 8
99 0
165 0
192 0
212 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins17 mod1
5
5 8
107 0
173 0
200 0
227 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins17 mod3
5
5 8
107 0
173 0
200 0
228 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins1 mod1
5
5 9
99 0
165 0
192 0
210 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins1 mod2
5
5 9
99 0
165 0
192 0
211 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins1 mod3
5
5 9
99 0
165 0
192 0
212 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins17 mod1
5
5 9
107 0
173 0
200 0
227 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins17 mod3
5
5 9
107 0
173 0
200 0
228 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins10 mod2
5
6 0
100 0
166 0
193 0
213 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins10 mod3
5
6 0
100 0
166 0
193 0
214 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins12 mod1
5
6 0
102 0
168 0
195 0
217 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins12 mod2
5
6 0
102 0
168 0
195 0
218 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins12 mod3
5
6 0
102 0
168 0
195 0
219 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins16 mod3
5
6 0
106 0
172 0
199 0
226 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins6 mod1
5
6 0
113 0
179 0
206 0
242 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins10 mod2
5
6 1
100 0
166 0
193 0
213 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins10 mod3
5
6 1
100 0
166 0
193 0
214 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins12 mod1
5
6 1
102 0
168 0
195 0
217 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins12 mod2
5
6 1
102 0
168 0
195 0
218 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins12 mod3
5
6 1
102 0
168 0
195 0
219 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins16 mod3
5
6 1
106 0
172 0
199 0
226 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat7 dir10 ins6 mod1
5
6 1
113 0
179 0
206 0
242 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins10 mod2
5
6 2
100 0
166 0
193 0
213 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins10 mod3
5
6 2
100 0
166 0
193 0
214 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins12 mod1
5
6 2
102 0
168 0
195 0
217 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins12 mod2
5
6 2
102 0
168 0
195 0
218 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins12 mod3
5
6 2
102 0
168 0
195 0
219 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins16 mod3
5
6 2
106 0
172 0
199 0
226 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins6 mod1
5
6 2
113 0
179 0
206 0
242 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins10 mod2
5
6 3
100 0
166 0
193 0
213 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins10 mod3
5
6 3
100 0
166 0
193 0
214 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins12 mod1
5
6 3
102 0
168 0
195 0
217 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins12 mod2
5
6 3
102 0
168 0
195 0
218 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins12 mod3
5
6 3
102 0
168 0
195 0
219 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins16 mod3
5
6 3
106 0
172 0
199 0
226 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins6 mod1
5
6 3
113 0
179 0
206 0
242 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins10 mod2
5
6 4
100 0
166 0
193 0
213 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins10 mod3
5
6 4
100 0
166 0
193 0
214 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins12 mod1
5
6 4
102 0
168 0
195 0
217 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins12 mod2
5
6 4
102 0
168 0
195 0
218 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins12 mod3
5
6 4
102 0
168 0
195 0
219 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins16 mod3
5
6 4
106 0
172 0
199 0
226 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins6 mod1
5
6 4
113 0
179 0
206 0
242 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins10 mod2
5
6 5
100 0
166 0
193 0
213 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins10 mod3
5
6 5
100 0
166 0
193 0
214 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins12 mod1
5
6 5
102 0
168 0
195 0
217 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins12 mod2
5
6 5
102 0
168 0
195 0
218 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins12 mod3
5
6 5
102 0
168 0
195 0
219 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins16 mod3
5
6 5
106 0
172 0
199 0
226 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins6 mod1
5
6 5
113 0
179 0
206 0
242 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins10 mod2
5
6 6
100 0
166 0
193 0
213 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins10 mod3
5
6 6
100 0
166 0
193 0
214 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins12 mod1
5
6 6
102 0
168 0
195 0
217 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins12 mod2
5
6 6
102 0
168 0
195 0
218 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins12 mod3
5
6 6
102 0
168 0
195 0
219 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins16 mod3
5
6 6
106 0
172 0
199 0
226 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins6 mod1
5
6 6
113 0
179 0
206 0
242 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins10 mod2
5
6 7
100 0
166 0
193 0
213 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins10 mod3
5
6 7
100 0
166 0
193 0
214 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins12 mod1
5
6 7
102 0
168 0
195 0
217 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins12 mod2
5
6 7
102 0
168 0
195 0
218 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins12 mod3
5
6 7
102 0
168 0
195 0
219 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins16 mod3
5
6 7
106 0
172 0
199 0
226 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins6 mod1
5
6 7
113 0
179 0
206 0
242 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins10 mod2
5
6 8
100 0
166 0
193 0
213 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins10 mod3
5
6 8
100 0
166 0
193 0
214 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins12 mod1
5
6 8
102 0
168 0
195 0
217 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins12 mod2
5
6 8
102 0
168 0
195 0
218 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins12 mod3
5
6 8
102 0
168 0
195 0
219 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins16 mod3
5
6 8
106 0
172 0
199 0
226 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins6 mod1
5
6 8
113 0
179 0
206 0
242 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins10 mod2
5
6 9
100 0
166 0
193 0
213 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins10 mod3
5
6 9
100 0
166 0
193 0
214 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins12 mod1
5
6 9
102 0
168 0
195 0
217 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins12 mod2
5
6 9
102 0
168 0
195 0
218 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins12 mod3
5
6 9
102 0
168 0
195 0
219 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins16 mod3
5
6 9
106 0
172 0
199 0
226 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins6 mod1
5
6 9
113 0
179 0
206 0
242 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins7 mod1
5
7 0
114 0
180 0
207 0
243 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins7 mod2
5
7 0
114 0
180 0
207 0
244 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat8 dir10 ins7 mod1
5
7 1
114 0
180 0
207 0
243 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat8 dir10 ins7 mod2
5
7 1
114 0
180 0
207 0
244 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins7 mod1
5
7 2
114 0
180 0
207 0
243 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins7 mod2
5
7 2
114 0
180 0
207 0
244 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins7 mod1
5
7 3
114 0
180 0
207 0
243 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins7 mod2
5
7 3
114 0
180 0
207 0
244 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins7 mod1
5
7 4
114 0
180 0
207 0
243 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins7 mod2
5
7 4
114 0
180 0
207 0
244 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins7 mod1
5
7 5
114 0
180 0
207 0
243 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins7 mod2
5
7 5
114 0
180 0
207 0
244 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins7 mod1
5
7 6
114 0
180 0
207 0
243 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins7 mod2
5
7 6
114 0
180 0
207 0
244 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins7 mod1
5
7 7
114 0
180 0
207 0
243 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins7 mod2
5
7 7
114 0
180 0
207 0
244 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins7 mod1
5
7 8
114 0
180 0
207 0
243 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins7 mod2
5
7 8
114 0
180 0
207 0
244 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins7 mod1
5
7 9
114 0
180 0
207 0
243 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins7 mod2
5
7 9
114 0
180 0
207 0
244 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat9 dir1 ins11 mod2
5
8 0
101 0
167 0
194 0
215 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat9 dir1 ins11 mod3
5
8 0
101 0
167 0
194 0
216 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat9 dir1 ins5 mod1
5
8 0
112 0
178 0
205 0
240 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat9 dir1 ins5 mod3
5
8 0
112 0
178 0
205 0
241 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat9 dir10 ins11 mod2
5
8 1
101 0
167 0
194 0
215 0
1
0 139 -1 0
1
end_operator
begin_operator
take_image sat9 dir10 ins11 mod3
5
8 1
101 0
167 0
194 0
216 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat9 dir10 ins5 mod1
5
8 1
112 0
178 0
205 0
240 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat9 dir10 ins5 mod3
5
8 1
112 0
178 0
205 0
241 0
1
0 140 -1 0
1
end_operator
begin_operator
take_image sat9 dir2 ins11 mod2
5
8 2
101 0
167 0
194 0
215 0
1
0 142 -1 0
1
end_operator
begin_operator
take_image sat9 dir2 ins11 mod3
5
8 2
101 0
167 0
194 0
216 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat9 dir2 ins5 mod1
5
8 2
112 0
178 0
205 0
240 0
1
0 141 -1 0
1
end_operator
begin_operator
take_image sat9 dir2 ins5 mod3
5
8 2
112 0
178 0
205 0
241 0
1
0 143 -1 0
1
end_operator
begin_operator
take_image sat9 dir3 ins11 mod2
5
8 3
101 0
167 0
194 0
215 0
1
0 145 -1 0
1
end_operator
begin_operator
take_image sat9 dir3 ins11 mod3
5
8 3
101 0
167 0
194 0
216 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat9 dir3 ins5 mod1
5
8 3
112 0
178 0
205 0
240 0
1
0 144 -1 0
1
end_operator
begin_operator
take_image sat9 dir3 ins5 mod3
5
8 3
112 0
178 0
205 0
241 0
1
0 146 -1 0
1
end_operator
begin_operator
take_image sat9 dir4 ins11 mod2
5
8 4
101 0
167 0
194 0
215 0
1
0 148 -1 0
1
end_operator
begin_operator
take_image sat9 dir4 ins11 mod3
5
8 4
101 0
167 0
194 0
216 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat9 dir4 ins5 mod1
5
8 4
112 0
178 0
205 0
240 0
1
0 147 -1 0
1
end_operator
begin_operator
take_image sat9 dir4 ins5 mod3
5
8 4
112 0
178 0
205 0
241 0
1
0 149 -1 0
1
end_operator
begin_operator
take_image sat9 dir5 ins11 mod2
5
8 5
101 0
167 0
194 0
215 0
1
0 151 -1 0
1
end_operator
begin_operator
take_image sat9 dir5 ins11 mod3
5
8 5
101 0
167 0
194 0
216 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat9 dir5 ins5 mod1
5
8 5
112 0
178 0
205 0
240 0
1
0 150 -1 0
1
end_operator
begin_operator
take_image sat9 dir5 ins5 mod3
5
8 5
112 0
178 0
205 0
241 0
1
0 152 -1 0
1
end_operator
begin_operator
take_image sat9 dir6 ins11 mod2
5
8 6
101 0
167 0
194 0
215 0
1
0 154 -1 0
1
end_operator
begin_operator
take_image sat9 dir6 ins11 mod3
5
8 6
101 0
167 0
194 0
216 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat9 dir6 ins5 mod1
5
8 6
112 0
178 0
205 0
240 0
1
0 153 -1 0
1
end_operator
begin_operator
take_image sat9 dir6 ins5 mod3
5
8 6
112 0
178 0
205 0
241 0
1
0 155 -1 0
1
end_operator
begin_operator
take_image sat9 dir7 ins11 mod2
5
8 7
101 0
167 0
194 0
215 0
1
0 157 -1 0
1
end_operator
begin_operator
take_image sat9 dir7 ins11 mod3
5
8 7
101 0
167 0
194 0
216 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat9 dir7 ins5 mod1
5
8 7
112 0
178 0
205 0
240 0
1
0 156 -1 0
1
end_operator
begin_operator
take_image sat9 dir7 ins5 mod3
5
8 7
112 0
178 0
205 0
241 0
1
0 158 -1 0
1
end_operator
begin_operator
take_image sat9 dir8 ins11 mod2
5
8 8
101 0
167 0
194 0
215 0
1
0 160 -1 0
1
end_operator
begin_operator
take_image sat9 dir8 ins11 mod3
5
8 8
101 0
167 0
194 0
216 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat9 dir8 ins5 mod1
5
8 8
112 0
178 0
205 0
240 0
1
0 159 -1 0
1
end_operator
begin_operator
take_image sat9 dir8 ins5 mod3
5
8 8
112 0
178 0
205 0
241 0
1
0 161 -1 0
1
end_operator
begin_operator
take_image sat9 dir9 ins11 mod2
5
8 9
101 0
167 0
194 0
215 0
1
0 163 -1 0
1
end_operator
begin_operator
take_image sat9 dir9 ins11 mod3
5
8 9
101 0
167 0
194 0
216 0
1
0 164 -1 0
1
end_operator
begin_operator
take_image sat9 dir9 ins5 mod1
5
8 9
112 0
178 0
205 0
240 0
1
0 162 -1 0
1
end_operator
begin_operator
take_image sat9 dir9 ins5 mod3
5
8 9
112 0
178 0
205 0
241 0
1
0 164 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir10
0
3
0 0 1 0
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
3
0 0 2 0
0 9 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
3
0 0 3 0
0 9 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
3
0 0 4 0
0 9 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
3
0 0 5 0
0 9 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir6
0
3
0 0 6 0
0 9 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir7
0
3
0 0 7 0
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir8
0
3
0 0 8 0
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir9
0
3
0 0 9 0
0 9 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir1
0
3
0 0 0 1
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir10 dir2
0
3
0 0 2 1
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir3
0
3
0 0 3 1
0 10 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir4
0
3
0 0 4 1
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir5
0
3
0 0 5 1
0 10 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir6
0
3
0 0 6 1
0 10 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir7
0
3
0 0 7 1
0 10 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir8
0
3
0 0 8 1
0 10 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir10 dir9
0
3
0 0 9 1
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
3
0 0 0 2
0 9 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir10
0
3
0 0 1 2
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
3
0 0 3 2
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
3
0 0 4 2
0 11 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir5
0
3
0 0 5 2
0 11 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir6
0
3
0 0 6 2
0 11 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir7
0
3
0 0 7 2
0 11 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir8
0
3
0 0 8 2
0 11 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir9
0
3
0 0 9 2
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
3
0 0 0 3
0 9 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir10
0
3
0 0 1 3
0 10 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
3
0 0 2 3
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
3
0 0 4 3
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir5
0
3
0 0 5 3
0 12 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir6
0
3
0 0 6 3
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir7
0
3
0 0 7 3
0 12 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir8
0
3
0 0 8 3
0 12 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir9
0
3
0 0 9 3
0 12 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
3
0 0 0 4
0 9 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir10
0
3
0 0 1 4
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
3
0 0 2 4
0 11 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
3
0 0 3 4
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir5
0
3
0 0 5 4
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir6
0
3
0 0 6 4
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir7
0
3
0 0 7 4
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir8
0
3
0 0 8 4
0 13 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir9
0
3
0 0 9 4
0 13 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir1
0
3
0 0 0 5
0 9 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir10
0
3
0 0 1 5
0 10 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir2
0
3
0 0 2 5
0 11 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir3
0
3
0 0 3 5
0 12 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir4
0
3
0 0 4 5
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir6
0
3
0 0 6 5
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir7
0
3
0 0 7 5
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir8
0
3
0 0 8 5
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir9
0
3
0 0 9 5
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir1
0
3
0 0 0 6
0 9 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir10
0
3
0 0 1 6
0 10 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir2
0
3
0 0 2 6
0 11 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir3
0
3
0 0 3 6
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir4
0
3
0 0 4 6
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir5
0
3
0 0 5 6
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir7
0
3
0 0 7 6
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir8
0
3
0 0 8 6
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir9
0
3
0 0 9 6
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir7 dir1
0
3
0 0 0 7
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir10
0
3
0 0 1 7
0 10 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir2
0
3
0 0 2 7
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir3
0
3
0 0 3 7
0 12 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir4
0
3
0 0 4 7
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir5
0
3
0 0 5 7
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir6
0
3
0 0 6 7
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir8
0
3
0 0 8 7
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat1 dir7 dir9
0
3
0 0 9 7
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir8 dir1
0
3
0 0 0 8
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir10
0
3
0 0 1 8
0 10 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir2
0
3
0 0 2 8
0 11 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir3
0
3
0 0 3 8
0 12 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir4
0
3
0 0 4 8
0 13 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir5
0
3
0 0 5 8
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir6
0
3
0 0 6 8
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir7
0
3
0 0 7 8
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir9
0
3
0 0 9 8
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat1 dir9 dir1
0
3
0 0 0 9
0 9 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir10
0
3
0 0 1 9
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir2
0
3
0 0 2 9
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir3
0
3
0 0 3 9
0 12 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir4
0
3
0 0 4 9
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir5
0
3
0 0 5 9
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir6
0
3
0 0 6 9
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir7
0
3
0 0 7 9
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir8
0
3
0 0 8 9
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir10
0
3
0 1 1 0
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
3
0 1 2 0
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
3
0 1 3 0
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
3
0 1 4 0
0 19 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir5
0
3
0 1 5 0
0 19 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir6
0
3
0 1 6 0
0 19 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir7
0
3
0 1 7 0
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir8
0
3
0 1 8 0
0 19 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir9
0
3
0 1 9 0
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir1
0
3
0 1 0 1
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
turn_to sat2 dir10 dir2
0
3
0 1 2 1
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir3
0
3
0 1 3 1
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir4
0
3
0 1 4 1
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir5
0
3
0 1 5 1
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir6
0
3
0 1 6 1
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir7
0
3
0 1 7 1
0 20 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir8
0
3
0 1 8 1
0 20 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir10 dir9
0
3
0 1 9 1
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
3
0 1 0 2
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir10
0
3
0 1 1 2
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
3
0 1 3 2
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
3
0 1 4 2
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir5
0
3
0 1 5 2
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir6
0
3
0 1 6 2
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir7
0
3
0 1 7 2
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir8
0
3
0 1 8 2
0 21 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir9
0
3
0 1 9 2
0 21 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
3
0 1 0 3
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir10
0
3
0 1 1 3
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
3
0 1 2 3
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
3
0 1 4 3
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir5
0
3
0 1 5 3
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir6
0
3
0 1 6 3
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir7
0
3
0 1 7 3
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir8
0
3
0 1 8 3
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir9
0
3
0 1 9 3
0 22 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
3
0 1 0 4
0 19 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir10
0
3
0 1 1 4
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
3
0 1 2 4
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
3
0 1 3 4
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir5
0
3
0 1 5 4
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir6
0
3
0 1 6 4
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir7
0
3
0 1 7 4
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir8
0
3
0 1 8 4
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir9
0
3
0 1 9 4
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir1
0
3
0 1 0 5
0 19 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir10
0
3
0 1 1 5
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir2
0
3
0 1 2 5
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir3
0
3
0 1 3 5
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir4
0
3
0 1 4 5
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir6
0
3
0 1 6 5
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir7
0
3
0 1 7 5
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir8
0
3
0 1 8 5
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir9
0
3
0 1 9 5
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir1
0
3
0 1 0 6
0 19 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir10
0
3
0 1 1 6
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir2
0
3
0 1 2 6
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir3
0
3
0 1 3 6
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir4
0
3
0 1 4 6
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir5
0
3
0 1 5 6
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir7
0
3
0 1 7 6
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir8
0
3
0 1 8 6
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir9
0
3
0 1 9 6
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir7 dir1
0
3
0 1 0 7
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir10
0
3
0 1 1 7
0 20 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir2
0
3
0 1 2 7
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir3
0
3
0 1 3 7
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir4
0
3
0 1 4 7
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir5
0
3
0 1 5 7
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir6
0
3
0 1 6 7
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir8
0
3
0 1 8 7
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat2 dir7 dir9
0
3
0 1 9 7
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir8 dir1
0
3
0 1 0 8
0 19 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir10
0
3
0 1 1 8
0 20 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir2
0
3
0 1 2 8
0 21 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir3
0
3
0 1 3 8
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir4
0
3
0 1 4 8
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir5
0
3
0 1 5 8
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir6
0
3
0 1 6 8
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir7
0
3
0 1 7 8
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir9
0
3
0 1 9 8
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat2 dir9 dir1
0
3
0 1 0 9
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir10
0
3
0 1 1 9
0 20 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir2
0
3
0 1 2 9
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir3
0
3
0 1 3 9
0 22 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir4
0
3
0 1 4 9
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir5
0
3
0 1 5 9
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir6
0
3
0 1 6 9
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir7
0
3
0 1 7 9
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir8
0
3
0 1 8 9
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat3 dir1 dir10
0
3
0 2 1 0
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
3
0 2 2 0
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
3
0 2 3 0
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
3
0 2 4 0
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir5
0
3
0 2 5 0
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir6
0
3
0 2 6 0
0 29 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir7
0
3
0 2 7 0
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir8
0
3
0 2 8 0
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir9
0
3
0 2 9 0
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir1
0
3
0 2 0 1
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat3 dir10 dir2
0
3
0 2 2 1
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir3
0
3
0 2 3 1
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir4
0
3
0 2 4 1
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir5
0
3
0 2 5 1
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir6
0
3
0 2 6 1
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir7
0
3
0 2 7 1
0 30 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir8
0
3
0 2 8 1
0 30 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir10 dir9
0
3
0 2 9 1
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
3
0 2 0 2
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir2 dir10
0
3
0 2 1 2
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
3
0 2 3 2
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
3
0 2 4 2
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir5
0
3
0 2 5 2
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir6
0
3
0 2 6 2
0 31 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir7
0
3
0 2 7 2
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir8
0
3
0 2 8 2
0 31 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir9
0
3
0 2 9 2
0 31 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
3
0 2 0 3
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir10
0
3
0 2 1 3
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
3
0 2 2 3
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
3
0 2 4 3
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir5
0
3
0 2 5 3
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir6
0
3
0 2 6 3
0 32 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir7
0
3
0 2 7 3
0 32 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir8
0
3
0 2 8 3
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir9
0
3
0 2 9 3
0 32 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
3
0 2 0 4
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir10
0
3
0 2 1 4
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
3
0 2 2 4
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
3
0 2 3 4
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir5
0
3
0 2 5 4
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir6
0
3
0 2 6 4
0 33 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir7
0
3
0 2 7 4
0 33 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir8
0
3
0 2 8 4
0 33 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir9
0
3
0 2 9 4
0 33 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir1
0
3
0 2 0 5
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir10
0
3
0 2 1 5
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir2
0
3
0 2 2 5
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir3
0
3
0 2 3 5
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir4
0
3
0 2 4 5
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir6
0
3
0 2 6 5
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir7
0
3
0 2 7 5
0 34 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir8
0
3
0 2 8 5
0 34 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir9
0
3
0 2 9 5
0 34 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir1
0
3
0 2 0 6
0 29 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir10
0
3
0 2 1 6
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir2
0
3
0 2 2 6
0 31 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir3
0
3
0 2 3 6
0 32 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir4
0
3
0 2 4 6
0 33 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir5
0
3
0 2 5 6
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir7
0
3
0 2 7 6
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir8
0
3
0 2 8 6
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir9
0
3
0 2 9 6
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir7 dir1
0
3
0 2 0 7
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir10
0
3
0 2 1 7
0 30 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir2
0
3
0 2 2 7
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir3
0
3
0 2 3 7
0 32 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir4
0
3
0 2 4 7
0 33 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir5
0
3
0 2 5 7
0 34 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir6
0
3
0 2 6 7
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir8
0
3
0 2 8 7
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat3 dir7 dir9
0
3
0 2 9 7
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir8 dir1
0
3
0 2 0 8
0 29 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir10
0
3
0 2 1 8
0 30 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir2
0
3
0 2 2 8
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir3
0
3
0 2 3 8
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir4
0
3
0 2 4 8
0 33 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir5
0
3
0 2 5 8
0 34 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir6
0
3
0 2 6 8
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir7
0
3
0 2 7 8
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir9
0
3
0 2 9 8
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat3 dir9 dir1
0
3
0 2 0 9
0 29 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir10
0
3
0 2 1 9
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir2
0
3
0 2 2 9
0 31 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir3
0
3
0 2 3 9
0 32 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir4
0
3
0 2 4 9
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir5
0
3
0 2 5 9
0 34 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir6
0
3
0 2 6 9
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir7
0
3
0 2 7 9
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir8
0
3
0 2 8 9
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat4 dir1 dir10
0
3
0 3 1 0
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
3
0 3 2 0
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
3
0 3 3 0
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
3
0 3 4 0
0 39 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir5
0
3
0 3 5 0
0 39 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir6
0
3
0 3 6 0
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir7
0
3
0 3 7 0
0 39 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir8
0
3
0 3 8 0
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir9
0
3
0 3 9 0
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir1
0
3
0 3 0 1
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir10 dir2
0
3
0 3 2 1
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir3
0
3
0 3 3 1
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir4
0
3
0 3 4 1
0 40 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir5
0
3
0 3 5 1
0 40 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir6
0
3
0 3 6 1
0 40 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir7
0
3
0 3 7 1
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir8
0
3
0 3 8 1
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir10 dir9
0
3
0 3 9 1
0 40 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
3
0 3 0 2
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir2 dir10
0
3
0 3 1 2
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
3
0 3 3 2
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
3
0 3 4 2
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir5
0
3
0 3 5 2
0 41 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir6
0
3
0 3 6 2
0 41 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir7
0
3
0 3 7 2
0 41 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir8
0
3
0 3 8 2
0 41 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir9
0
3
0 3 9 2
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
3
0 3 0 3
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir10
0
3
0 3 1 3
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
3
0 3 2 3
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
3
0 3 4 3
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
3
0 3 5 3
0 42 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir6
0
3
0 3 6 3
0 42 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir7
0
3
0 3 7 3
0 42 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir8
0
3
0 3 8 3
0 42 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir9
0
3
0 3 9 3
0 42 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
3
0 3 0 4
0 39 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir10
0
3
0 3 1 4
0 40 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
3
0 3 2 4
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
3
0 3 3 4
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
3
0 3 5 4
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir6
0
3
0 3 6 4
0 43 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir7
0
3
0 3 7 4
0 43 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir8
0
3
0 3 8 4
0 43 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir9
0
3
0 3 9 4
0 43 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
3
0 3 0 5
0 39 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir10
0
3
0 3 1 5
0 40 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
3
0 3 2 5
0 41 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
3
0 3 3 5
0 42 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
3
0 3 4 5
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir6
0
3
0 3 6 5
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir7
0
3
0 3 7 5
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir8
0
3
0 3 8 5
0 44 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir9
0
3
0 3 9 5
0 44 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir1
0
3
0 3 0 6
0 39 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir10
0
3
0 3 1 6
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir2
0
3
0 3 2 6
0 41 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir3
0
3
0 3 3 6
0 42 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir4
0
3
0 3 4 6
0 43 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir5
0
3
0 3 5 6
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir7
0
3
0 3 7 6
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir8
0
3
0 3 8 6
0 45 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir9
0
3
0 3 9 6
0 45 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir7 dir1
0
3
0 3 0 7
0 39 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir10
0
3
0 3 1 7
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir2
0
3
0 3 2 7
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir3
0
3
0 3 3 7
0 42 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir4
0
3
0 3 4 7
0 43 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir5
0
3
0 3 5 7
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir6
0
3
0 3 6 7
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir8
0
3
0 3 8 7
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat4 dir7 dir9
0
3
0 3 9 7
0 46 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir8 dir1
0
3
0 3 0 8
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir10
0
3
0 3 1 8
0 40 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir2
0
3
0 3 2 8
0 41 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir3
0
3
0 3 3 8
0 42 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir4
0
3
0 3 4 8
0 43 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir5
0
3
0 3 5 8
0 44 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir6
0
3
0 3 6 8
0 45 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir7
0
3
0 3 7 8
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir9
0
3
0 3 9 8
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat4 dir9 dir1
0
3
0 3 0 9
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir10
0
3
0 3 1 9
0 40 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir2
0
3
0 3 2 9
0 41 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir3
0
3
0 3 3 9
0 42 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir4
0
3
0 3 4 9
0 43 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir5
0
3
0 3 5 9
0 44 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir6
0
3
0 3 6 9
0 45 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir7
0
3
0 3 7 9
0 46 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir8
0
3
0 3 8 9
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat5 dir1 dir10
0
3
0 4 1 0
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir2
0
3
0 4 2 0
0 49 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir3
0
3
0 4 3 0
0 49 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir4
0
3
0 4 4 0
0 49 0 1
0 53 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir5
0
3
0 4 5 0
0 49 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir6
0
3
0 4 6 0
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir7
0
3
0 4 7 0
0 49 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir8
0
3
0 4 8 0
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir9
0
3
0 4 9 0
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir1
0
3
0 4 0 1
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir10 dir2
0
3
0 4 2 1
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir3
0
3
0 4 3 1
0 50 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir4
0
3
0 4 4 1
0 50 0 1
0 53 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir5
0
3
0 4 5 1
0 50 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir6
0
3
0 4 6 1
0 50 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir7
0
3
0 4 7 1
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir8
0
3
0 4 8 1
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir10 dir9
0
3
0 4 9 1
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir1
0
3
0 4 0 2
0 49 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir2 dir10
0
3
0 4 1 2
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir2 dir3
0
3
0 4 3 2
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir4
0
3
0 4 4 2
0 51 0 1
0 53 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir5
0
3
0 4 5 2
0 51 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir6
0
3
0 4 6 2
0 51 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir7
0
3
0 4 7 2
0 51 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir8
0
3
0 4 8 2
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir9
0
3
0 4 9 2
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir1
0
3
0 4 0 3
0 49 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir10
0
3
0 4 1 3
0 50 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir2
0
3
0 4 2 3
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir4
0
3
0 4 4 3
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir5
0
3
0 4 5 3
0 52 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir6
0
3
0 4 6 3
0 52 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir7
0
3
0 4 7 3
0 52 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir8
0
3
0 4 8 3
0 52 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir9
0
3
0 4 9 3
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir1
0
3
0 4 0 4
0 49 -1 0
0 53 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir10
0
3
0 4 1 4
0 50 -1 0
0 53 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir2
0
3
0 4 2 4
0 51 -1 0
0 53 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir3
0
3
0 4 3 4
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir5
0
3
0 4 5 4
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir6
0
3
0 4 6 4
0 53 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir7
0
3
0 4 7 4
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir8
0
3
0 4 8 4
0 53 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir9
0
3
0 4 9 4
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir1
0
3
0 4 0 5
0 49 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir10
0
3
0 4 1 5
0 50 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir2
0
3
0 4 2 5
0 51 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir3
0
3
0 4 3 5
0 52 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir4
0
3
0 4 4 5
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir6
0
3
0 4 6 5
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir7
0
3
0 4 7 5
0 54 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir8
0
3
0 4 8 5
0 54 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir9
0
3
0 4 9 5
0 54 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir1
0
3
0 4 0 6
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir10
0
3
0 4 1 6
0 50 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir2
0
3
0 4 2 6
0 51 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir3
0
3
0 4 3 6
0 52 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir4
0
3
0 4 4 6
0 53 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir5
0
3
0 4 5 6
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir7
0
3
0 4 7 6
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir8
0
3
0 4 8 6
0 55 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir9
0
3
0 4 9 6
0 55 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir7 dir1
0
3
0 4 0 7
0 49 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir10
0
3
0 4 1 7
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir2
0
3
0 4 2 7
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir3
0
3
0 4 3 7
0 52 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir4
0
3
0 4 4 7
0 53 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir5
0
3
0 4 5 7
0 54 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir6
0
3
0 4 6 7
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir8
0
3
0 4 8 7
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat5 dir7 dir9
0
3
0 4 9 7
0 56 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir8 dir1
0
3
0 4 0 8
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir10
0
3
0 4 1 8
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir2
0
3
0 4 2 8
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir3
0
3
0 4 3 8
0 52 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir4
0
3
0 4 4 8
0 53 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir5
0
3
0 4 5 8
0 54 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir6
0
3
0 4 6 8
0 55 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir7
0
3
0 4 7 8
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir9
0
3
0 4 9 8
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat5 dir9 dir1
0
3
0 4 0 9
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir10
0
3
0 4 1 9
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir2
0
3
0 4 2 9
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir3
0
3
0 4 3 9
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir4
0
3
0 4 4 9
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir5
0
3
0 4 5 9
0 54 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir6
0
3
0 4 6 9
0 55 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir7
0
3
0 4 7 9
0 56 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir8
0
3
0 4 8 9
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir1 dir10
0
3
0 5 1 0
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir2
0
3
0 5 2 0
0 59 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir3
0
3
0 5 3 0
0 59 0 1
0 62 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir4
0
3
0 5 4 0
0 59 0 1
0 63 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir5
0
3
0 5 5 0
0 59 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir6
0
3
0 5 6 0
0 59 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir7
0
3
0 5 7 0
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir8
0
3
0 5 8 0
0 59 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir9
0
3
0 5 9 0
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir1
0
3
0 5 0 1
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir10 dir2
0
3
0 5 2 1
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir3
0
3
0 5 3 1
0 60 0 1
0 62 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir4
0
3
0 5 4 1
0 60 0 1
0 63 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir5
0
3
0 5 5 1
0 60 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir6
0
3
0 5 6 1
0 60 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir7
0
3
0 5 7 1
0 60 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir8
0
3
0 5 8 1
0 60 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir10 dir9
0
3
0 5 9 1
0 60 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir1
0
3
0 5 0 2
0 59 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir2 dir10
0
3
0 5 1 2
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir2 dir3
0
3
0 5 3 2
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir4
0
3
0 5 4 2
0 61 0 1
0 63 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir5
0
3
0 5 5 2
0 61 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir6
0
3
0 5 6 2
0 61 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir7
0
3
0 5 7 2
0 61 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir8
0
3
0 5 8 2
0 61 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir9
0
3
0 5 9 2
0 61 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir1
0
3
0 5 0 3
0 59 -1 0
0 62 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir10
0
3
0 5 1 3
0 60 -1 0
0 62 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir2
0
3
0 5 2 3
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir4
0
3
0 5 4 3
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir5
0
3
0 5 5 3
0 62 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir6
0
3
0 5 6 3
0 62 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir7
0
3
0 5 7 3
0 62 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir8
0
3
0 5 8 3
0 62 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir9
0
3
0 5 9 3
0 62 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir1
0
3
0 5 0 4
0 59 -1 0
0 63 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir10
0
3
0 5 1 4
0 60 -1 0
0 63 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir2
0
3
0 5 2 4
0 61 -1 0
0 63 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir3
0
3
0 5 3 4
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir5
0
3
0 5 5 4
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir6
0
3
0 5 6 4
0 63 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir7
0
3
0 5 7 4
0 63 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir8
0
3
0 5 8 4
0 63 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir9
0
3
0 5 9 4
0 63 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir1
0
3
0 5 0 5
0 59 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir10
0
3
0 5 1 5
0 60 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir2
0
3
0 5 2 5
0 61 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir3
0
3
0 5 3 5
0 62 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir4
0
3
0 5 4 5
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir6
0
3
0 5 6 5
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir7
0
3
0 5 7 5
0 64 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir8
0
3
0 5 8 5
0 64 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir9
0
3
0 5 9 5
0 64 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir1
0
3
0 5 0 6
0 59 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir10
0
3
0 5 1 6
0 60 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir2
0
3
0 5 2 6
0 61 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir3
0
3
0 5 3 6
0 62 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir4
0
3
0 5 4 6
0 63 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir5
0
3
0 5 5 6
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir7
0
3
0 5 7 6
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir8
0
3
0 5 8 6
0 65 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir9
0
3
0 5 9 6
0 65 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir7 dir1
0
3
0 5 0 7
0 59 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir10
0
3
0 5 1 7
0 60 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir2
0
3
0 5 2 7
0 61 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir3
0
3
0 5 3 7
0 62 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir4
0
3
0 5 4 7
0 63 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir5
0
3
0 5 5 7
0 64 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir6
0
3
0 5 6 7
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir8
0
3
0 5 8 7
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat6 dir7 dir9
0
3
0 5 9 7
0 66 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir8 dir1
0
3
0 5 0 8
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir10
0
3
0 5 1 8
0 60 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir2
0
3
0 5 2 8
0 61 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir3
0
3
0 5 3 8
0 62 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir4
0
3
0 5 4 8
0 63 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir5
0
3
0 5 5 8
0 64 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir6
0
3
0 5 6 8
0 65 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir7
0
3
0 5 7 8
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir9
0
3
0 5 9 8
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat6 dir9 dir1
0
3
0 5 0 9
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir10
0
3
0 5 1 9
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir2
0
3
0 5 2 9
0 61 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir3
0
3
0 5 3 9
0 62 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir4
0
3
0 5 4 9
0 63 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir5
0
3
0 5 5 9
0 64 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir6
0
3
0 5 6 9
0 65 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir7
0
3
0 5 7 9
0 66 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir8
0
3
0 5 8 9
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir1 dir10
0
3
0 6 1 0
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir2
0
3
0 6 2 0
0 69 0 1
0 71 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir3
0
3
0 6 3 0
0 69 0 1
0 72 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir4
0
3
0 6 4 0
0 69 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir5
0
3
0 6 5 0
0 69 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir6
0
3
0 6 6 0
0 69 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir7
0
3
0 6 7 0
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir8
0
3
0 6 8 0
0 69 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir9
0
3
0 6 9 0
0 69 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir1
0
3
0 6 0 1
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir10 dir2
0
3
0 6 2 1
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir3
0
3
0 6 3 1
0 70 0 1
0 72 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir4
0
3
0 6 4 1
0 70 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir5
0
3
0 6 5 1
0 70 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir6
0
3
0 6 6 1
0 70 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir7
0
3
0 6 7 1
0 70 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir8
0
3
0 6 8 1
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir10 dir9
0
3
0 6 9 1
0 70 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir1
0
3
0 6 0 2
0 69 -1 0
0 71 0 1
1
end_operator
begin_operator
turn_to sat7 dir2 dir10
0
3
0 6 1 2
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
turn_to sat7 dir2 dir3
0
3
0 6 3 2
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir4
0
3
0 6 4 2
0 71 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir5
0
3
0 6 5 2
0 71 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir6
0
3
0 6 6 2
0 71 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir7
0
3
0 6 7 2
0 71 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir8
0
3
0 6 8 2
0 71 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir9
0
3
0 6 9 2
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir1
0
3
0 6 0 3
0 69 -1 0
0 72 0 1
1
end_operator
begin_operator
turn_to sat7 dir3 dir10
0
3
0 6 1 3
0 70 -1 0
0 72 0 1
1
end_operator
begin_operator
turn_to sat7 dir3 dir2
0
3
0 6 2 3
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
turn_to sat7 dir3 dir4
0
3
0 6 4 3
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir5
0
3
0 6 5 3
0 72 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir6
0
3
0 6 6 3
0 72 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir7
0
3
0 6 7 3
0 72 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir8
0
3
0 6 8 3
0 72 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir9
0
3
0 6 9 3
0 72 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir1
0
3
0 6 0 4
0 69 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir10
0
3
0 6 1 4
0 70 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir2
0
3
0 6 2 4
0 71 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir3
0
3
0 6 3 4
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir5
0
3
0 6 5 4
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir6
0
3
0 6 6 4
0 73 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir7
0
3
0 6 7 4
0 73 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir8
0
3
0 6 8 4
0 73 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir9
0
3
0 6 9 4
0 73 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir1
0
3
0 6 0 5
0 69 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir10
0
3
0 6 1 5
0 70 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir2
0
3
0 6 2 5
0 71 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir3
0
3
0 6 3 5
0 72 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir4
0
3
0 6 4 5
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir6
0
3
0 6 6 5
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir7
0
3
0 6 7 5
0 74 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir8
0
3
0 6 8 5
0 74 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir9
0
3
0 6 9 5
0 74 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir1
0
3
0 6 0 6
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir10
0
3
0 6 1 6
0 70 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir2
0
3
0 6 2 6
0 71 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir3
0
3
0 6 3 6
0 72 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir4
0
3
0 6 4 6
0 73 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir5
0
3
0 6 5 6
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir7
0
3
0 6 7 6
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir8
0
3
0 6 8 6
0 75 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir9
0
3
0 6 9 6
0 75 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir7 dir1
0
3
0 6 0 7
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir10
0
3
0 6 1 7
0 70 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir2
0
3
0 6 2 7
0 71 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir3
0
3
0 6 3 7
0 72 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir4
0
3
0 6 4 7
0 73 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir5
0
3
0 6 5 7
0 74 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir6
0
3
0 6 6 7
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir8
0
3
0 6 8 7
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat7 dir7 dir9
0
3
0 6 9 7
0 76 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir8 dir1
0
3
0 6 0 8
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir10
0
3
0 6 1 8
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir2
0
3
0 6 2 8
0 71 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir3
0
3
0 6 3 8
0 72 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir4
0
3
0 6 4 8
0 73 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir5
0
3
0 6 5 8
0 74 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir6
0
3
0 6 6 8
0 75 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir7
0
3
0 6 7 8
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir9
0
3
0 6 9 8
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat7 dir9 dir1
0
3
0 6 0 9
0 69 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir10
0
3
0 6 1 9
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir2
0
3
0 6 2 9
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir3
0
3
0 6 3 9
0 72 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir4
0
3
0 6 4 9
0 73 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir5
0
3
0 6 5 9
0 74 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir6
0
3
0 6 6 9
0 75 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir7
0
3
0 6 7 9
0 76 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir8
0
3
0 6 8 9
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir1 dir10
0
3
0 7 1 0
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir2
0
3
0 7 2 0
0 79 0 1
0 81 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir3
0
3
0 7 3 0
0 79 0 1
0 82 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir4
0
3
0 7 4 0
0 79 0 1
0 83 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir5
0
3
0 7 5 0
0 79 0 1
0 84 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir6
0
3
0 7 6 0
0 79 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir7
0
3
0 7 7 0
0 79 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir8
0
3
0 7 8 0
0 79 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir9
0
3
0 7 9 0
0 79 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir1
0
3
0 7 0 1
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
turn_to sat8 dir10 dir2
0
3
0 7 2 1
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir3
0
3
0 7 3 1
0 80 0 1
0 82 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir4
0
3
0 7 4 1
0 80 0 1
0 83 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir5
0
3
0 7 5 1
0 80 0 1
0 84 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir6
0
3
0 7 6 1
0 80 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir7
0
3
0 7 7 1
0 80 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir8
0
3
0 7 8 1
0 80 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir10 dir9
0
3
0 7 9 1
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir1
0
3
0 7 0 2
0 79 -1 0
0 81 0 1
1
end_operator
begin_operator
turn_to sat8 dir2 dir10
0
3
0 7 1 2
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
turn_to sat8 dir2 dir3
0
3
0 7 3 2
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir4
0
3
0 7 4 2
0 81 0 1
0 83 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir5
0
3
0 7 5 2
0 81 0 1
0 84 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir6
0
3
0 7 6 2
0 81 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir7
0
3
0 7 7 2
0 81 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir8
0
3
0 7 8 2
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir9
0
3
0 7 9 2
0 81 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir1
0
3
0 7 0 3
0 79 -1 0
0 82 0 1
1
end_operator
begin_operator
turn_to sat8 dir3 dir10
0
3
0 7 1 3
0 80 -1 0
0 82 0 1
1
end_operator
begin_operator
turn_to sat8 dir3 dir2
0
3
0 7 2 3
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
turn_to sat8 dir3 dir4
0
3
0 7 4 3
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir5
0
3
0 7 5 3
0 82 0 1
0 84 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir6
0
3
0 7 6 3
0 82 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir7
0
3
0 7 7 3
0 82 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir8
0
3
0 7 8 3
0 82 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir9
0
3
0 7 9 3
0 82 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir1
0
3
0 7 0 4
0 79 -1 0
0 83 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir10
0
3
0 7 1 4
0 80 -1 0
0 83 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir2
0
3
0 7 2 4
0 81 -1 0
0 83 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir3
0
3
0 7 3 4
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir5
0
3
0 7 5 4
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir6
0
3
0 7 6 4
0 83 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir7
0
3
0 7 7 4
0 83 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir8
0
3
0 7 8 4
0 83 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir9
0
3
0 7 9 4
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir1
0
3
0 7 0 5
0 79 -1 0
0 84 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir10
0
3
0 7 1 5
0 80 -1 0
0 84 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir2
0
3
0 7 2 5
0 81 -1 0
0 84 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir3
0
3
0 7 3 5
0 82 -1 0
0 84 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir4
0
3
0 7 4 5
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir6
0
3
0 7 6 5
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir7
0
3
0 7 7 5
0 84 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir8
0
3
0 7 8 5
0 84 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir9
0
3
0 7 9 5
0 84 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir1
0
3
0 7 0 6
0 79 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir10
0
3
0 7 1 6
0 80 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir2
0
3
0 7 2 6
0 81 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir3
0
3
0 7 3 6
0 82 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir4
0
3
0 7 4 6
0 83 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir5
0
3
0 7 5 6
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir7
0
3
0 7 7 6
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir8
0
3
0 7 8 6
0 85 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir9
0
3
0 7 9 6
0 85 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir7 dir1
0
3
0 7 0 7
0 79 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir10
0
3
0 7 1 7
0 80 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir2
0
3
0 7 2 7
0 81 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir3
0
3
0 7 3 7
0 82 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir4
0
3
0 7 4 7
0 83 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir5
0
3
0 7 5 7
0 84 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir6
0
3
0 7 6 7
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir8
0
3
0 7 8 7
0 86 0 1
0 87 -1 0
1
end_operator
begin_operator
turn_to sat8 dir7 dir9
0
3
0 7 9 7
0 86 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir8 dir1
0
3
0 7 0 8
0 79 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir10
0
3
0 7 1 8
0 80 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir2
0
3
0 7 2 8
0 81 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir3
0
3
0 7 3 8
0 82 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir4
0
3
0 7 4 8
0 83 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir5
0
3
0 7 5 8
0 84 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir6
0
3
0 7 6 8
0 85 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir7
0
3
0 7 7 8
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir9
0
3
0 7 9 8
0 87 0 1
0 88 -1 0
1
end_operator
begin_operator
turn_to sat8 dir9 dir1
0
3
0 7 0 9
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir10
0
3
0 7 1 9
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir2
0
3
0 7 2 9
0 81 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir3
0
3
0 7 3 9
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir4
0
3
0 7 4 9
0 83 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir5
0
3
0 7 5 9
0 84 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir6
0
3
0 7 6 9
0 85 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir7
0
3
0 7 7 9
0 86 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir8
0
3
0 7 8 9
0 87 -1 0
0 88 0 1
1
end_operator
begin_operator
turn_to sat9 dir1 dir10
0
3
0 8 1 0
0 89 0 1
0 90 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir2
0
3
0 8 2 0
0 89 0 1
0 91 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir3
0
3
0 8 3 0
0 89 0 1
0 92 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir4
0
3
0 8 4 0
0 89 0 1
0 93 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir5
0
3
0 8 5 0
0 89 0 1
0 94 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir6
0
3
0 8 6 0
0 89 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir7
0
3
0 8 7 0
0 89 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir8
0
3
0 8 8 0
0 89 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir1 dir9
0
3
0 8 9 0
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir1
0
3
0 8 0 1
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
turn_to sat9 dir10 dir2
0
3
0 8 2 1
0 90 0 1
0 91 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir3
0
3
0 8 3 1
0 90 0 1
0 92 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir4
0
3
0 8 4 1
0 90 0 1
0 93 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir5
0
3
0 8 5 1
0 90 0 1
0 94 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir6
0
3
0 8 6 1
0 90 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir7
0
3
0 8 7 1
0 90 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir8
0
3
0 8 8 1
0 90 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir10 dir9
0
3
0 8 9 1
0 90 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir1
0
3
0 8 0 2
0 89 -1 0
0 91 0 1
1
end_operator
begin_operator
turn_to sat9 dir2 dir10
0
3
0 8 1 2
0 90 -1 0
0 91 0 1
1
end_operator
begin_operator
turn_to sat9 dir2 dir3
0
3
0 8 3 2
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir4
0
3
0 8 4 2
0 91 0 1
0 93 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir5
0
3
0 8 5 2
0 91 0 1
0 94 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir6
0
3
0 8 6 2
0 91 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir7
0
3
0 8 7 2
0 91 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir8
0
3
0 8 8 2
0 91 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir2 dir9
0
3
0 8 9 2
0 91 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir1
0
3
0 8 0 3
0 89 -1 0
0 92 0 1
1
end_operator
begin_operator
turn_to sat9 dir3 dir10
0
3
0 8 1 3
0 90 -1 0
0 92 0 1
1
end_operator
begin_operator
turn_to sat9 dir3 dir2
0
3
0 8 2 3
0 91 -1 0
0 92 0 1
1
end_operator
begin_operator
turn_to sat9 dir3 dir4
0
3
0 8 4 3
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir5
0
3
0 8 5 3
0 92 0 1
0 94 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir6
0
3
0 8 6 3
0 92 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir7
0
3
0 8 7 3
0 92 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir8
0
3
0 8 8 3
0 92 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir3 dir9
0
3
0 8 9 3
0 92 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir4 dir1
0
3
0 8 0 4
0 89 -1 0
0 93 0 1
1
end_operator
begin_operator
turn_to sat9 dir4 dir10
0
3
0 8 1 4
0 90 -1 0
0 93 0 1
1
end_operator
begin_operator
turn_to sat9 dir4 dir2
0
3
0 8 2 4
0 91 -1 0
0 93 0 1
1
end_operator
begin_operator
turn_to sat9 dir4 dir3
0
3
0 8 3 4
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
turn_to sat9 dir4 dir5
0
3
0 8 5 4
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
turn_to sat9 dir4 dir6
0
3
0 8 6 4
0 93 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir4 dir7
0
3
0 8 7 4
0 93 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir4 dir8
0
3
0 8 8 4
0 93 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir4 dir9
0
3
0 8 9 4
0 93 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir5 dir1
0
3
0 8 0 5
0 89 -1 0
0 94 0 1
1
end_operator
begin_operator
turn_to sat9 dir5 dir10
0
3
0 8 1 5
0 90 -1 0
0 94 0 1
1
end_operator
begin_operator
turn_to sat9 dir5 dir2
0
3
0 8 2 5
0 91 -1 0
0 94 0 1
1
end_operator
begin_operator
turn_to sat9 dir5 dir3
0
3
0 8 3 5
0 92 -1 0
0 94 0 1
1
end_operator
begin_operator
turn_to sat9 dir5 dir4
0
3
0 8 4 5
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
turn_to sat9 dir5 dir6
0
3
0 8 6 5
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
turn_to sat9 dir5 dir7
0
3
0 8 7 5
0 94 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir5 dir8
0
3
0 8 8 5
0 94 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir5 dir9
0
3
0 8 9 5
0 94 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir6 dir1
0
3
0 8 0 6
0 89 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir10
0
3
0 8 1 6
0 90 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir2
0
3
0 8 2 6
0 91 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir3
0
3
0 8 3 6
0 92 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir4
0
3
0 8 4 6
0 93 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir5
0
3
0 8 5 6
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
turn_to sat9 dir6 dir7
0
3
0 8 7 6
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
turn_to sat9 dir6 dir8
0
3
0 8 8 6
0 95 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir6 dir9
0
3
0 8 9 6
0 95 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir7 dir1
0
3
0 8 0 7
0 89 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir10
0
3
0 8 1 7
0 90 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir2
0
3
0 8 2 7
0 91 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir3
0
3
0 8 3 7
0 92 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir4
0
3
0 8 4 7
0 93 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir5
0
3
0 8 5 7
0 94 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir6
0
3
0 8 6 7
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
turn_to sat9 dir7 dir8
0
3
0 8 8 7
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
turn_to sat9 dir7 dir9
0
3
0 8 9 7
0 96 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir8 dir1
0
3
0 8 0 8
0 89 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir10
0
3
0 8 1 8
0 90 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir2
0
3
0 8 2 8
0 91 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir3
0
3
0 8 3 8
0 92 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir4
0
3
0 8 4 8
0 93 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir5
0
3
0 8 5 8
0 94 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir6
0
3
0 8 6 8
0 95 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir7
0
3
0 8 7 8
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
turn_to sat9 dir8 dir9
0
3
0 8 9 8
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
turn_to sat9 dir9 dir1
0
3
0 8 0 9
0 89 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir10
0
3
0 8 1 9
0 90 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir2
0
3
0 8 2 9
0 91 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir3
0
3
0 8 3 9
0 92 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir4
0
3
0 8 4 9
0 93 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir5
0
3
0 8 5 9
0 94 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir6
0
3
0 8 6 9
0 95 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir7
0
3
0 8 7 9
0 96 -1 0
0 98 0 1
1
end_operator
begin_operator
turn_to sat9 dir9 dir8
0
3
0 8 8 9
0 97 -1 0
0 98 0 1
1
end_operator
0
