begin_version
3
end_version
begin_metric
1
end_metric
214
begin_variable
var0
-1
9
pointing sat1 dir1
pointing sat1 dir2
pointing sat1 dir3
pointing sat1 dir4
pointing sat1 dir5
pointing sat1 dir6
pointing sat1 dir7
pointing sat1 dir8
pointing sat1 dir9
end_variable
begin_variable
var1
-1
9
pointing sat2 dir1
pointing sat2 dir2
pointing sat2 dir3
pointing sat2 dir4
pointing sat2 dir5
pointing sat2 dir6
pointing sat2 dir7
pointing sat2 dir8
pointing sat2 dir9
end_variable
begin_variable
var2
-1
9
pointing sat3 dir1
pointing sat3 dir2
pointing sat3 dir3
pointing sat3 dir4
pointing sat3 dir5
pointing sat3 dir6
pointing sat3 dir7
pointing sat3 dir8
pointing sat3 dir9
end_variable
begin_variable
var3
-1
9
pointing sat4 dir1
pointing sat4 dir2
pointing sat4 dir3
pointing sat4 dir4
pointing sat4 dir5
pointing sat4 dir6
pointing sat4 dir7
pointing sat4 dir8
pointing sat4 dir9
end_variable
begin_variable
var4
-1
9
pointing sat5 dir1
pointing sat5 dir2
pointing sat5 dir3
pointing sat5 dir4
pointing sat5 dir5
pointing sat5 dir6
pointing sat5 dir7
pointing sat5 dir8
pointing sat5 dir9
end_variable
begin_variable
var5
-1
9
pointing sat6 dir1
pointing sat6 dir2
pointing sat6 dir3
pointing sat6 dir4
pointing sat6 dir5
pointing sat6 dir6
pointing sat6 dir7
pointing sat6 dir8
pointing sat6 dir9
end_variable
begin_variable
var6
-1
9
pointing sat7 dir1
pointing sat7 dir2
pointing sat7 dir3
pointing sat7 dir4
pointing sat7 dir5
pointing sat7 dir6
pointing sat7 dir7
pointing sat7 dir8
pointing sat7 dir9
end_variable
begin_variable
var7
-1
9
pointing sat8 dir1
pointing sat8 dir2
pointing sat8 dir3
pointing sat8 dir4
pointing sat8 dir5
pointing sat8 dir6
pointing sat8 dir7
pointing sat8 dir8
pointing sat8 dir9
end_variable
begin_variable
var8
-1
2
NOT-pointing sat1 dir1
none-of-those
end_variable
begin_variable
var9
-1
2
NOT-pointing sat1 dir2
none-of-those
end_variable
begin_variable
var10
-1
2
NOT-pointing sat1 dir3
none-of-those
end_variable
begin_variable
var11
-1
2
NOT-pointing sat1 dir4
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-pointing sat1 dir5
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-pointing sat1 dir6
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-pointing sat1 dir7
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-pointing sat1 dir8
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-pointing sat1 dir9
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-pointing sat2 dir1
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-pointing sat2 dir2
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-pointing sat2 dir3
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-pointing sat2 dir4
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-pointing sat2 dir5
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-pointing sat2 dir6
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-pointing sat2 dir7
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-pointing sat2 dir8
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-pointing sat2 dir9
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-pointing sat3 dir1
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-pointing sat3 dir2
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-pointing sat3 dir3
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-pointing sat3 dir4
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-pointing sat3 dir5
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-pointing sat3 dir6
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-pointing sat3 dir7
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-pointing sat3 dir8
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-pointing sat3 dir9
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-pointing sat4 dir1
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-pointing sat4 dir2
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-pointing sat4 dir3
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-pointing sat4 dir4
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-pointing sat4 dir5
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-pointing sat4 dir6
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-pointing sat4 dir7
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-pointing sat4 dir8
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-pointing sat4 dir9
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-pointing sat5 dir1
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-pointing sat5 dir2
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-pointing sat5 dir3
none-of-those
end_variable
begin_variable
var47
-1
2
NOT-pointing sat5 dir4
none-of-those
end_variable
begin_variable
var48
-1
2
NOT-pointing sat5 dir5
none-of-those
end_variable
begin_variable
var49
-1
2
NOT-pointing sat5 dir6
none-of-those
end_variable
begin_variable
var50
-1
2
NOT-pointing sat5 dir7
none-of-those
end_variable
begin_variable
var51
-1
2
NOT-pointing sat5 dir8
none-of-those
end_variable
begin_variable
var52
-1
2
NOT-pointing sat5 dir9
none-of-those
end_variable
begin_variable
var53
-1
2
NOT-pointing sat6 dir1
none-of-those
end_variable
begin_variable
var54
-1
2
NOT-pointing sat6 dir2
none-of-those
end_variable
begin_variable
var55
-1
2
NOT-pointing sat6 dir3
none-of-those
end_variable
begin_variable
var56
-1
2
NOT-pointing sat6 dir4
none-of-those
end_variable
begin_variable
var57
-1
2
NOT-pointing sat6 dir5
none-of-those
end_variable
begin_variable
var58
-1
2
NOT-pointing sat6 dir6
none-of-those
end_variable
begin_variable
var59
-1
2
NOT-pointing sat6 dir7
none-of-those
end_variable
begin_variable
var60
-1
2
NOT-pointing sat6 dir8
none-of-those
end_variable
begin_variable
var61
-1
2
NOT-pointing sat6 dir9
none-of-those
end_variable
begin_variable
var62
-1
2
NOT-pointing sat7 dir1
none-of-those
end_variable
begin_variable
var63
-1
2
NOT-pointing sat7 dir2
none-of-those
end_variable
begin_variable
var64
-1
2
NOT-pointing sat7 dir3
none-of-those
end_variable
begin_variable
var65
-1
2
NOT-pointing sat7 dir4
none-of-those
end_variable
begin_variable
var66
-1
2
NOT-pointing sat7 dir5
none-of-those
end_variable
begin_variable
var67
-1
2
NOT-pointing sat7 dir6
none-of-those
end_variable
begin_variable
var68
-1
2
NOT-pointing sat7 dir7
none-of-those
end_variable
begin_variable
var69
-1
2
NOT-pointing sat7 dir8
none-of-those
end_variable
begin_variable
var70
-1
2
NOT-pointing sat7 dir9
none-of-those
end_variable
begin_variable
var71
-1
2
NOT-pointing sat8 dir1
none-of-those
end_variable
begin_variable
var72
-1
2
NOT-pointing sat8 dir2
none-of-those
end_variable
begin_variable
var73
-1
2
NOT-pointing sat8 dir3
none-of-those
end_variable
begin_variable
var74
-1
2
NOT-pointing sat8 dir4
none-of-those
end_variable
begin_variable
var75
-1
2
NOT-pointing sat8 dir5
none-of-those
end_variable
begin_variable
var76
-1
2
NOT-pointing sat8 dir6
none-of-those
end_variable
begin_variable
var77
-1
2
NOT-pointing sat8 dir7
none-of-those
end_variable
begin_variable
var78
-1
2
NOT-pointing sat8 dir8
none-of-those
end_variable
begin_variable
var79
-1
2
NOT-pointing sat8 dir9
none-of-those
end_variable
begin_variable
var80
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var81
-1
2
calibrated ins10
none-of-those
end_variable
begin_variable
var82
-1
2
calibrated ins11
none-of-those
end_variable
begin_variable
var83
-1
2
calibrated ins12
none-of-those
end_variable
begin_variable
var84
-1
2
calibrated ins13
none-of-those
end_variable
begin_variable
var85
-1
2
calibrated ins14
none-of-those
end_variable
begin_variable
var86
-1
2
calibrated ins15
none-of-those
end_variable
begin_variable
var87
-1
2
calibrated ins16
none-of-those
end_variable
begin_variable
var88
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var89
-1
2
calibrated ins3
none-of-those
end_variable
begin_variable
var90
-1
2
calibrated ins4
none-of-those
end_variable
begin_variable
var91
-1
2
calibrated ins5
none-of-those
end_variable
begin_variable
var92
-1
2
calibrated ins6
none-of-those
end_variable
begin_variable
var93
-1
2
calibrated ins7
none-of-those
end_variable
begin_variable
var94
-1
2
calibrated ins8
none-of-those
end_variable
begin_variable
var95
-1
2
calibrated ins9
none-of-those
end_variable
begin_variable
var96
-1
2
calibration_target ins1 dir7
none-of-those
end_variable
begin_variable
var97
-1
2
calibration_target ins10 dir1
none-of-those
end_variable
begin_variable
var98
-1
2
calibration_target ins11 dir9
none-of-those
end_variable
begin_variable
var99
-1
2
calibration_target ins12 dir7
none-of-those
end_variable
begin_variable
var100
-1
2
calibration_target ins13 dir4
none-of-those
end_variable
begin_variable
var101
-1
2
calibration_target ins14 dir5
none-of-those
end_variable
begin_variable
var102
-1
2
calibration_target ins15 dir5
none-of-those
end_variable
begin_variable
var103
-1
2
calibration_target ins16 dir6
none-of-those
end_variable
begin_variable
var104
-1
2
calibration_target ins2 dir9
none-of-those
end_variable
begin_variable
var105
-1
2
calibration_target ins3 dir6
none-of-those
end_variable
begin_variable
var106
-1
2
calibration_target ins4 dir1
none-of-those
end_variable
begin_variable
var107
-1
2
calibration_target ins5 dir2
none-of-those
end_variable
begin_variable
var108
-1
2
calibration_target ins6 dir9
none-of-those
end_variable
begin_variable
var109
-1
2
calibration_target ins7 dir2
none-of-those
end_variable
begin_variable
var110
-1
2
calibration_target ins8 dir3
none-of-those
end_variable
begin_variable
var111
-1
2
calibration_target ins9 dir8
none-of-those
end_variable
begin_variable
var112
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var113
-1
2
have_image dir1 mod2
none-of-those
end_variable
begin_variable
var114
-1
2
have_image dir1 mod3
none-of-those
end_variable
begin_variable
var115
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var116
-1
2
have_image dir2 mod2
none-of-those
end_variable
begin_variable
var117
-1
2
have_image dir2 mod3
none-of-those
end_variable
begin_variable
var118
-1
2
have_image dir3 mod1
none-of-those
end_variable
begin_variable
var119
-1
2
have_image dir3 mod2
none-of-those
end_variable
begin_variable
var120
-1
2
have_image dir3 mod3
none-of-those
end_variable
begin_variable
var121
-1
2
have_image dir4 mod1
none-of-those
end_variable
begin_variable
var122
-1
2
have_image dir4 mod2
none-of-those
end_variable
begin_variable
var123
-1
2
have_image dir4 mod3
none-of-those
end_variable
begin_variable
var124
-1
2
have_image dir5 mod1
none-of-those
end_variable
begin_variable
var125
-1
2
have_image dir5 mod2
none-of-those
end_variable
begin_variable
var126
-1
2
have_image dir5 mod3
none-of-those
end_variable
begin_variable
var127
-1
2
have_image dir6 mod1
none-of-those
end_variable
begin_variable
var128
-1
2
have_image dir6 mod2
none-of-those
end_variable
begin_variable
var129
-1
2
have_image dir6 mod3
none-of-those
end_variable
begin_variable
var130
-1
2
have_image dir7 mod1
none-of-those
end_variable
begin_variable
var131
-1
2
have_image dir7 mod2
none-of-those
end_variable
begin_variable
var132
-1
2
have_image dir7 mod3
none-of-those
end_variable
begin_variable
var133
-1
2
have_image dir8 mod1
none-of-those
end_variable
begin_variable
var134
-1
2
have_image dir8 mod2
none-of-those
end_variable
begin_variable
var135
-1
2
have_image dir8 mod3
none-of-those
end_variable
begin_variable
var136
-1
2
have_image dir9 mod1
none-of-those
end_variable
begin_variable
var137
-1
2
have_image dir9 mod2
none-of-those
end_variable
begin_variable
var138
-1
2
have_image dir9 mod3
none-of-those
end_variable
begin_variable
var139
-1
2
on_board ins1 sat3
none-of-those
end_variable
begin_variable
var140
-1
2
on_board ins10 sat5
none-of-those
end_variable
begin_variable
var141
-1
2
on_board ins11 sat7
none-of-those
end_variable
begin_variable
var142
-1
2
on_board ins12 sat8
none-of-those
end_variable
begin_variable
var143
-1
2
on_board ins13 sat4
none-of-those
end_variable
begin_variable
var144
-1
2
on_board ins14 sat3
none-of-those
end_variable
begin_variable
var145
-1
2
on_board ins15 sat8
none-of-those
end_variable
begin_variable
var146
-1
2
on_board ins16 sat4
none-of-those
end_variable
begin_variable
var147
-1
2
on_board ins2 sat8
none-of-those
end_variable
begin_variable
var148
-1
2
on_board ins3 sat2
none-of-those
end_variable
begin_variable
var149
-1
2
on_board ins4 sat7
none-of-those
end_variable
begin_variable
var150
-1
2
on_board ins5 sat4
none-of-those
end_variable
begin_variable
var151
-1
2
on_board ins6 sat1
none-of-those
end_variable
begin_variable
var152
-1
2
on_board ins7 sat5
none-of-those
end_variable
begin_variable
var153
-1
2
on_board ins8 sat6
none-of-those
end_variable
begin_variable
var154
-1
2
on_board ins9 sat4
none-of-those
end_variable
begin_variable
var155
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var156
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var157
-1
2
power_avail sat3
none-of-those
end_variable
begin_variable
var158
-1
2
power_avail sat4
none-of-those
end_variable
begin_variable
var159
-1
2
power_avail sat5
none-of-those
end_variable
begin_variable
var160
-1
2
power_avail sat6
none-of-those
end_variable
begin_variable
var161
-1
2
power_avail sat7
none-of-those
end_variable
begin_variable
var162
-1
2
power_avail sat8
none-of-those
end_variable
begin_variable
var163
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var164
-1
2
power_on ins10
none-of-those
end_variable
begin_variable
var165
-1
2
power_on ins11
none-of-those
end_variable
begin_variable
var166
-1
2
power_on ins12
none-of-those
end_variable
begin_variable
var167
-1
2
power_on ins13
none-of-those
end_variable
begin_variable
var168
-1
2
power_on ins14
none-of-those
end_variable
begin_variable
var169
-1
2
power_on ins15
none-of-those
end_variable
begin_variable
var170
-1
2
power_on ins16
none-of-those
end_variable
begin_variable
var171
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var172
-1
2
power_on ins3
none-of-those
end_variable
begin_variable
var173
-1
2
power_on ins4
none-of-those
end_variable
begin_variable
var174
-1
2
power_on ins5
none-of-those
end_variable
begin_variable
var175
-1
2
power_on ins6
none-of-those
end_variable
begin_variable
var176
-1
2
power_on ins7
none-of-those
end_variable
begin_variable
var177
-1
2
power_on ins8
none-of-those
end_variable
begin_variable
var178
-1
2
power_on ins9
none-of-those
end_variable
begin_variable
var179
-1
2
supports ins1 mod2
none-of-those
end_variable
begin_variable
var180
-1
2
supports ins1 mod3
none-of-those
end_variable
begin_variable
var181
-1
2
supports ins10 mod1
none-of-those
end_variable
begin_variable
var182
-1
2
supports ins10 mod2
none-of-those
end_variable
begin_variable
var183
-1
2
supports ins10 mod3
none-of-those
end_variable
begin_variable
var184
-1
2
supports ins11 mod1
none-of-those
end_variable
begin_variable
var185
-1
2
supports ins11 mod3
none-of-those
end_variable
begin_variable
var186
-1
2
supports ins12 mod1
none-of-those
end_variable
begin_variable
var187
-1
2
supports ins12 mod2
none-of-those
end_variable
begin_variable
var188
-1
2
supports ins12 mod3
none-of-those
end_variable
begin_variable
var189
-1
2
supports ins13 mod1
none-of-those
end_variable
begin_variable
var190
-1
2
supports ins13 mod2
none-of-those
end_variable
begin_variable
var191
-1
2
supports ins14 mod1
none-of-those
end_variable
begin_variable
var192
-1
2
supports ins14 mod2
none-of-those
end_variable
begin_variable
var193
-1
2
supports ins14 mod3
none-of-those
end_variable
begin_variable
var194
-1
2
supports ins15 mod1
none-of-those
end_variable
begin_variable
var195
-1
2
supports ins15 mod2
none-of-those
end_variable
begin_variable
var196
-1
2
supports ins15 mod3
none-of-those
end_variable
begin_variable
var197
-1
2
supports ins16 mod2
none-of-those
end_variable
begin_variable
var198
-1
2
supports ins16 mod3
none-of-those
end_variable
begin_variable
var199
-1
2
supports ins2 mod1
none-of-those
end_variable
begin_variable
var200
-1
2
supports ins2 mod2
none-of-those
end_variable
begin_variable
var201
-1
2
supports ins3 mod1
none-of-those
end_variable
begin_variable
var202
-1
2
supports ins3 mod2
none-of-those
end_variable
begin_variable
var203
-1
2
supports ins4 mod1
none-of-those
end_variable
begin_variable
var204
-1
2
supports ins5 mod2
none-of-those
end_variable
begin_variable
var205
-1
2
supports ins5 mod3
none-of-those
end_variable
begin_variable
var206
-1
2
supports ins6 mod2
none-of-those
end_variable
begin_variable
var207
-1
2
supports ins7 mod1
none-of-those
end_variable
begin_variable
var208
-1
2
supports ins7 mod3
none-of-those
end_variable
begin_variable
var209
-1
2
supports ins8 mod2
none-of-those
end_variable
begin_variable
var210
-1
2
supports ins8 mod3
none-of-those
end_variable
begin_variable
var211
-1
2
supports ins9 mod1
none-of-those
end_variable
begin_variable
var212
-1
2
supports ins9 mod2
none-of-those
end_variable
begin_variable
var213
-1
2
supports ins9 mod3
none-of-those
end_variable
0
begin_state
6
3
6
7
4
8
1
8
0
0
0
0
0
0
1
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
28
0 2
1 8
3 8
4 3
5 0
6 3
7 0
112 0
113 0
117 0
118 0
119 0
120 0
121 0
123 0
124 0
125 0
126 0
127 0
128 0
130 0
131 0
132 0
133 0
134 0
135 0
136 0
137 0
end_goal
939
begin_operator
calibrate sat1 ins6 dir9
4
0 8
108 0
151 0
175 0
1
0 92 -1 0
1
end_operator
begin_operator
calibrate sat2 ins3 dir6
4
1 5
105 0
148 0
172 0
1
0 89 -1 0
1
end_operator
begin_operator
calibrate sat3 ins1 dir7
4
2 6
96 0
139 0
163 0
1
0 80 -1 0
1
end_operator
begin_operator
calibrate sat3 ins14 dir5
4
2 4
101 0
144 0
168 0
1
0 85 -1 0
1
end_operator
begin_operator
calibrate sat4 ins13 dir4
4
3 3
100 0
143 0
167 0
1
0 84 -1 0
1
end_operator
begin_operator
calibrate sat4 ins16 dir6
4
3 5
103 0
146 0
170 0
1
0 87 -1 0
1
end_operator
begin_operator
calibrate sat4 ins5 dir2
4
3 1
107 0
150 0
174 0
1
0 91 -1 0
1
end_operator
begin_operator
calibrate sat4 ins9 dir8
4
3 7
111 0
154 0
178 0
1
0 95 -1 0
1
end_operator
begin_operator
calibrate sat5 ins10 dir1
4
4 0
97 0
140 0
164 0
1
0 81 -1 0
1
end_operator
begin_operator
calibrate sat5 ins7 dir2
4
4 1
109 0
152 0
176 0
1
0 93 -1 0
1
end_operator
begin_operator
calibrate sat6 ins8 dir3
4
5 2
110 0
153 0
177 0
1
0 94 -1 0
1
end_operator
begin_operator
calibrate sat7 ins11 dir9
4
6 8
98 0
141 0
165 0
1
0 82 -1 0
1
end_operator
begin_operator
calibrate sat7 ins4 dir1
4
6 0
106 0
149 0
173 0
1
0 90 -1 0
1
end_operator
begin_operator
calibrate sat8 ins12 dir7
4
7 6
99 0
142 0
166 0
1
0 83 -1 0
1
end_operator
begin_operator
calibrate sat8 ins15 dir5
4
7 4
102 0
145 0
169 0
1
0 86 -1 0
1
end_operator
begin_operator
calibrate sat8 ins2 dir9
4
7 8
104 0
147 0
171 0
1
0 88 -1 0
1
end_operator
begin_operator
switch_off ins1 sat3
1
139 0
2
0 157 -1 0
0 163 0 1
1
end_operator
begin_operator
switch_off ins10 sat5
1
140 0
2
0 159 -1 0
0 164 0 1
1
end_operator
begin_operator
switch_off ins11 sat7
1
141 0
2
0 161 -1 0
0 165 0 1
1
end_operator
begin_operator
switch_off ins12 sat8
1
142 0
2
0 162 -1 0
0 166 0 1
1
end_operator
begin_operator
switch_off ins13 sat4
1
143 0
2
0 158 -1 0
0 167 0 1
1
end_operator
begin_operator
switch_off ins14 sat3
1
144 0
2
0 157 -1 0
0 168 0 1
1
end_operator
begin_operator
switch_off ins15 sat8
1
145 0
2
0 162 -1 0
0 169 0 1
1
end_operator
begin_operator
switch_off ins16 sat4
1
146 0
2
0 158 -1 0
0 170 0 1
1
end_operator
begin_operator
switch_off ins2 sat8
1
147 0
2
0 162 -1 0
0 171 0 1
1
end_operator
begin_operator
switch_off ins3 sat2
1
148 0
2
0 156 -1 0
0 172 0 1
1
end_operator
begin_operator
switch_off ins4 sat7
1
149 0
2
0 161 -1 0
0 173 0 1
1
end_operator
begin_operator
switch_off ins5 sat4
1
150 0
2
0 158 -1 0
0 174 0 1
1
end_operator
begin_operator
switch_off ins6 sat1
1
151 0
2
0 155 -1 0
0 175 0 1
1
end_operator
begin_operator
switch_off ins7 sat5
1
152 0
2
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
switch_off ins8 sat6
1
153 0
2
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
switch_off ins9 sat4
1
154 0
2
0 158 -1 0
0 178 0 1
1
end_operator
begin_operator
switch_on ins1 sat3
1
139 0
3
0 80 -1 1
0 157 0 1
0 163 -1 0
1
end_operator
begin_operator
switch_on ins10 sat5
1
140 0
3
0 81 -1 1
0 159 0 1
0 164 -1 0
1
end_operator
begin_operator
switch_on ins11 sat7
1
141 0
3
0 82 -1 1
0 161 0 1
0 165 -1 0
1
end_operator
begin_operator
switch_on ins12 sat8
1
142 0
3
0 83 -1 1
0 162 0 1
0 166 -1 0
1
end_operator
begin_operator
switch_on ins13 sat4
1
143 0
3
0 84 -1 1
0 158 0 1
0 167 -1 0
1
end_operator
begin_operator
switch_on ins14 sat3
1
144 0
3
0 85 -1 1
0 157 0 1
0 168 -1 0
1
end_operator
begin_operator
switch_on ins15 sat8
1
145 0
3
0 86 -1 1
0 162 0 1
0 169 -1 0
1
end_operator
begin_operator
switch_on ins16 sat4
1
146 0
3
0 87 -1 1
0 158 0 1
0 170 -1 0
1
end_operator
begin_operator
switch_on ins2 sat8
1
147 0
3
0 88 -1 1
0 162 0 1
0 171 -1 0
1
end_operator
begin_operator
switch_on ins3 sat2
1
148 0
3
0 89 -1 1
0 156 0 1
0 172 -1 0
1
end_operator
begin_operator
switch_on ins4 sat7
1
149 0
3
0 90 -1 1
0 161 0 1
0 173 -1 0
1
end_operator
begin_operator
switch_on ins5 sat4
1
150 0
3
0 91 -1 1
0 158 0 1
0 174 -1 0
1
end_operator
begin_operator
switch_on ins6 sat1
1
151 0
3
0 92 -1 1
0 155 0 1
0 175 -1 0
1
end_operator
begin_operator
switch_on ins7 sat5
1
152 0
3
0 93 -1 1
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
switch_on ins8 sat6
1
153 0
3
0 94 -1 1
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
switch_on ins9 sat4
1
154 0
3
0 95 -1 1
0 158 0 1
0 178 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins6 mod2
5
0 0
92 0
151 0
175 0
206 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins6 mod2
5
0 1
92 0
151 0
175 0
206 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins6 mod2
5
0 2
92 0
151 0
175 0
206 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins6 mod2
5
0 3
92 0
151 0
175 0
206 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins6 mod2
5
0 4
92 0
151 0
175 0
206 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat1 dir6 ins6 mod2
5
0 5
92 0
151 0
175 0
206 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat1 dir7 ins6 mod2
5
0 6
92 0
151 0
175 0
206 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat1 dir8 ins6 mod2
5
0 7
92 0
151 0
175 0
206 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat1 dir9 ins6 mod2
5
0 8
92 0
151 0
175 0
206 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins3 mod1
5
1 0
89 0
148 0
172 0
201 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins3 mod2
5
1 0
89 0
148 0
172 0
202 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins3 mod1
5
1 1
89 0
148 0
172 0
201 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins3 mod2
5
1 1
89 0
148 0
172 0
202 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins3 mod1
5
1 2
89 0
148 0
172 0
201 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins3 mod2
5
1 2
89 0
148 0
172 0
202 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins3 mod1
5
1 3
89 0
148 0
172 0
201 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins3 mod2
5
1 3
89 0
148 0
172 0
202 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins3 mod1
5
1 4
89 0
148 0
172 0
201 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins3 mod2
5
1 4
89 0
148 0
172 0
202 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins3 mod1
5
1 5
89 0
148 0
172 0
201 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat2 dir6 ins3 mod2
5
1 5
89 0
148 0
172 0
202 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins3 mod1
5
1 6
89 0
148 0
172 0
201 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat2 dir7 ins3 mod2
5
1 6
89 0
148 0
172 0
202 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat2 dir8 ins3 mod1
5
1 7
89 0
148 0
172 0
201 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat2 dir8 ins3 mod2
5
1 7
89 0
148 0
172 0
202 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat2 dir9 ins3 mod1
5
1 8
89 0
148 0
172 0
201 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat2 dir9 ins3 mod2
5
1 8
89 0
148 0
172 0
202 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins1 mod2
5
2 0
80 0
139 0
163 0
179 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins1 mod3
5
2 0
80 0
139 0
163 0
180 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins14 mod1
5
2 0
85 0
144 0
168 0
191 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins14 mod2
5
2 0
85 0
144 0
168 0
192 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins14 mod3
5
2 0
85 0
144 0
168 0
193 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins1 mod2
5
2 1
80 0
139 0
163 0
179 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins1 mod3
5
2 1
80 0
139 0
163 0
180 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins14 mod1
5
2 1
85 0
144 0
168 0
191 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins14 mod2
5
2 1
85 0
144 0
168 0
192 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins14 mod3
5
2 1
85 0
144 0
168 0
193 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins1 mod2
5
2 2
80 0
139 0
163 0
179 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins1 mod3
5
2 2
80 0
139 0
163 0
180 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins14 mod1
5
2 2
85 0
144 0
168 0
191 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins14 mod2
5
2 2
85 0
144 0
168 0
192 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins14 mod3
5
2 2
85 0
144 0
168 0
193 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins1 mod2
5
2 3
80 0
139 0
163 0
179 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins1 mod3
5
2 3
80 0
139 0
163 0
180 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins14 mod1
5
2 3
85 0
144 0
168 0
191 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins14 mod2
5
2 3
85 0
144 0
168 0
192 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins14 mod3
5
2 3
85 0
144 0
168 0
193 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins1 mod2
5
2 4
80 0
139 0
163 0
179 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins1 mod3
5
2 4
80 0
139 0
163 0
180 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins14 mod1
5
2 4
85 0
144 0
168 0
191 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins14 mod2
5
2 4
85 0
144 0
168 0
192 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins14 mod3
5
2 4
85 0
144 0
168 0
193 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins1 mod2
5
2 5
80 0
139 0
163 0
179 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins1 mod3
5
2 5
80 0
139 0
163 0
180 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins14 mod1
5
2 5
85 0
144 0
168 0
191 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins14 mod2
5
2 5
85 0
144 0
168 0
192 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat3 dir6 ins14 mod3
5
2 5
85 0
144 0
168 0
193 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins1 mod2
5
2 6
80 0
139 0
163 0
179 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins1 mod3
5
2 6
80 0
139 0
163 0
180 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins14 mod1
5
2 6
85 0
144 0
168 0
191 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins14 mod2
5
2 6
85 0
144 0
168 0
192 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat3 dir7 ins14 mod3
5
2 6
85 0
144 0
168 0
193 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins1 mod2
5
2 7
80 0
139 0
163 0
179 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins1 mod3
5
2 7
80 0
139 0
163 0
180 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins14 mod1
5
2 7
85 0
144 0
168 0
191 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins14 mod2
5
2 7
85 0
144 0
168 0
192 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat3 dir8 ins14 mod3
5
2 7
85 0
144 0
168 0
193 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins1 mod2
5
2 8
80 0
139 0
163 0
179 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins1 mod3
5
2 8
80 0
139 0
163 0
180 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins14 mod1
5
2 8
85 0
144 0
168 0
191 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins14 mod2
5
2 8
85 0
144 0
168 0
192 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat3 dir9 ins14 mod3
5
2 8
85 0
144 0
168 0
193 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins13 mod1
5
3 0
84 0
143 0
167 0
189 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins13 mod2
5
3 0
84 0
143 0
167 0
190 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins16 mod2
5
3 0
87 0
146 0
170 0
197 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins16 mod3
5
3 0
87 0
146 0
170 0
198 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins5 mod2
5
3 0
91 0
150 0
174 0
204 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins5 mod3
5
3 0
91 0
150 0
174 0
205 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins9 mod1
5
3 0
95 0
154 0
178 0
211 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins9 mod2
5
3 0
95 0
154 0
178 0
212 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins9 mod3
5
3 0
95 0
154 0
178 0
213 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins13 mod1
5
3 1
84 0
143 0
167 0
189 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins13 mod2
5
3 1
84 0
143 0
167 0
190 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins16 mod2
5
3 1
87 0
146 0
170 0
197 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins16 mod3
5
3 1
87 0
146 0
170 0
198 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins5 mod2
5
3 1
91 0
150 0
174 0
204 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins5 mod3
5
3 1
91 0
150 0
174 0
205 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins9 mod1
5
3 1
95 0
154 0
178 0
211 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins9 mod2
5
3 1
95 0
154 0
178 0
212 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins9 mod3
5
3 1
95 0
154 0
178 0
213 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins13 mod1
5
3 2
84 0
143 0
167 0
189 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins13 mod2
5
3 2
84 0
143 0
167 0
190 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins16 mod2
5
3 2
87 0
146 0
170 0
197 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins16 mod3
5
3 2
87 0
146 0
170 0
198 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins5 mod2
5
3 2
91 0
150 0
174 0
204 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins5 mod3
5
3 2
91 0
150 0
174 0
205 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins9 mod1
5
3 2
95 0
154 0
178 0
211 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins9 mod2
5
3 2
95 0
154 0
178 0
212 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins9 mod3
5
3 2
95 0
154 0
178 0
213 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins13 mod1
5
3 3
84 0
143 0
167 0
189 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins13 mod2
5
3 3
84 0
143 0
167 0
190 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins16 mod2
5
3 3
87 0
146 0
170 0
197 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins16 mod3
5
3 3
87 0
146 0
170 0
198 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins5 mod2
5
3 3
91 0
150 0
174 0
204 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins5 mod3
5
3 3
91 0
150 0
174 0
205 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins9 mod1
5
3 3
95 0
154 0
178 0
211 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins9 mod2
5
3 3
95 0
154 0
178 0
212 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins9 mod3
5
3 3
95 0
154 0
178 0
213 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins13 mod1
5
3 4
84 0
143 0
167 0
189 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins13 mod2
5
3 4
84 0
143 0
167 0
190 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins16 mod2
5
3 4
87 0
146 0
170 0
197 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins16 mod3
5
3 4
87 0
146 0
170 0
198 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins5 mod2
5
3 4
91 0
150 0
174 0
204 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins5 mod3
5
3 4
91 0
150 0
174 0
205 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins9 mod1
5
3 4
95 0
154 0
178 0
211 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins9 mod2
5
3 4
95 0
154 0
178 0
212 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins9 mod3
5
3 4
95 0
154 0
178 0
213 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins13 mod1
5
3 5
84 0
143 0
167 0
189 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins13 mod2
5
3 5
84 0
143 0
167 0
190 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins16 mod2
5
3 5
87 0
146 0
170 0
197 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins16 mod3
5
3 5
87 0
146 0
170 0
198 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins5 mod2
5
3 5
91 0
150 0
174 0
204 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins5 mod3
5
3 5
91 0
150 0
174 0
205 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins9 mod1
5
3 5
95 0
154 0
178 0
211 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins9 mod2
5
3 5
95 0
154 0
178 0
212 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat4 dir6 ins9 mod3
5
3 5
95 0
154 0
178 0
213 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins13 mod1
5
3 6
84 0
143 0
167 0
189 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins13 mod2
5
3 6
84 0
143 0
167 0
190 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins16 mod2
5
3 6
87 0
146 0
170 0
197 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins16 mod3
5
3 6
87 0
146 0
170 0
198 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins5 mod2
5
3 6
91 0
150 0
174 0
204 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins5 mod3
5
3 6
91 0
150 0
174 0
205 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins9 mod1
5
3 6
95 0
154 0
178 0
211 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins9 mod2
5
3 6
95 0
154 0
178 0
212 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat4 dir7 ins9 mod3
5
3 6
95 0
154 0
178 0
213 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins13 mod1
5
3 7
84 0
143 0
167 0
189 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins13 mod2
5
3 7
84 0
143 0
167 0
190 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins16 mod2
5
3 7
87 0
146 0
170 0
197 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins16 mod3
5
3 7
87 0
146 0
170 0
198 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins5 mod2
5
3 7
91 0
150 0
174 0
204 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins5 mod3
5
3 7
91 0
150 0
174 0
205 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins9 mod1
5
3 7
95 0
154 0
178 0
211 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins9 mod2
5
3 7
95 0
154 0
178 0
212 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat4 dir8 ins9 mod3
5
3 7
95 0
154 0
178 0
213 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins13 mod1
5
3 8
84 0
143 0
167 0
189 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins13 mod2
5
3 8
84 0
143 0
167 0
190 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins16 mod2
5
3 8
87 0
146 0
170 0
197 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins16 mod3
5
3 8
87 0
146 0
170 0
198 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins5 mod2
5
3 8
91 0
150 0
174 0
204 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins5 mod3
5
3 8
91 0
150 0
174 0
205 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins9 mod1
5
3 8
95 0
154 0
178 0
211 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins9 mod2
5
3 8
95 0
154 0
178 0
212 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat4 dir9 ins9 mod3
5
3 8
95 0
154 0
178 0
213 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins10 mod1
5
4 0
81 0
140 0
164 0
181 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins10 mod2
5
4 0
81 0
140 0
164 0
182 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins10 mod3
5
4 0
81 0
140 0
164 0
183 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins7 mod1
5
4 0
93 0
152 0
176 0
207 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat5 dir1 ins7 mod3
5
4 0
93 0
152 0
176 0
208 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins10 mod1
5
4 1
81 0
140 0
164 0
181 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins10 mod2
5
4 1
81 0
140 0
164 0
182 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins10 mod3
5
4 1
81 0
140 0
164 0
183 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins7 mod1
5
4 1
93 0
152 0
176 0
207 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat5 dir2 ins7 mod3
5
4 1
93 0
152 0
176 0
208 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins10 mod1
5
4 2
81 0
140 0
164 0
181 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins10 mod2
5
4 2
81 0
140 0
164 0
182 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins10 mod3
5
4 2
81 0
140 0
164 0
183 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins7 mod1
5
4 2
93 0
152 0
176 0
207 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat5 dir3 ins7 mod3
5
4 2
93 0
152 0
176 0
208 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins10 mod1
5
4 3
81 0
140 0
164 0
181 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins10 mod2
5
4 3
81 0
140 0
164 0
182 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins10 mod3
5
4 3
81 0
140 0
164 0
183 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins7 mod1
5
4 3
93 0
152 0
176 0
207 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat5 dir4 ins7 mod3
5
4 3
93 0
152 0
176 0
208 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins10 mod1
5
4 4
81 0
140 0
164 0
181 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins10 mod2
5
4 4
81 0
140 0
164 0
182 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins10 mod3
5
4 4
81 0
140 0
164 0
183 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins7 mod1
5
4 4
93 0
152 0
176 0
207 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat5 dir5 ins7 mod3
5
4 4
93 0
152 0
176 0
208 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins10 mod1
5
4 5
81 0
140 0
164 0
181 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins10 mod2
5
4 5
81 0
140 0
164 0
182 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins10 mod3
5
4 5
81 0
140 0
164 0
183 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins7 mod1
5
4 5
93 0
152 0
176 0
207 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat5 dir6 ins7 mod3
5
4 5
93 0
152 0
176 0
208 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins10 mod1
5
4 6
81 0
140 0
164 0
181 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins10 mod2
5
4 6
81 0
140 0
164 0
182 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins10 mod3
5
4 6
81 0
140 0
164 0
183 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins7 mod1
5
4 6
93 0
152 0
176 0
207 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat5 dir7 ins7 mod3
5
4 6
93 0
152 0
176 0
208 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins10 mod1
5
4 7
81 0
140 0
164 0
181 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins10 mod2
5
4 7
81 0
140 0
164 0
182 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins10 mod3
5
4 7
81 0
140 0
164 0
183 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins7 mod1
5
4 7
93 0
152 0
176 0
207 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat5 dir8 ins7 mod3
5
4 7
93 0
152 0
176 0
208 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins10 mod1
5
4 8
81 0
140 0
164 0
181 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins10 mod2
5
4 8
81 0
140 0
164 0
182 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins10 mod3
5
4 8
81 0
140 0
164 0
183 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins7 mod1
5
4 8
93 0
152 0
176 0
207 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat5 dir9 ins7 mod3
5
4 8
93 0
152 0
176 0
208 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins8 mod2
5
5 0
94 0
153 0
177 0
209 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat6 dir1 ins8 mod3
5
5 0
94 0
153 0
177 0
210 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins8 mod2
5
5 1
94 0
153 0
177 0
209 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat6 dir2 ins8 mod3
5
5 1
94 0
153 0
177 0
210 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins8 mod2
5
5 2
94 0
153 0
177 0
209 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat6 dir3 ins8 mod3
5
5 2
94 0
153 0
177 0
210 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins8 mod2
5
5 3
94 0
153 0
177 0
209 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat6 dir4 ins8 mod3
5
5 3
94 0
153 0
177 0
210 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins8 mod2
5
5 4
94 0
153 0
177 0
209 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat6 dir5 ins8 mod3
5
5 4
94 0
153 0
177 0
210 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins8 mod2
5
5 5
94 0
153 0
177 0
209 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat6 dir6 ins8 mod3
5
5 5
94 0
153 0
177 0
210 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins8 mod2
5
5 6
94 0
153 0
177 0
209 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat6 dir7 ins8 mod3
5
5 6
94 0
153 0
177 0
210 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins8 mod2
5
5 7
94 0
153 0
177 0
209 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat6 dir8 ins8 mod3
5
5 7
94 0
153 0
177 0
210 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins8 mod2
5
5 8
94 0
153 0
177 0
209 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat6 dir9 ins8 mod3
5
5 8
94 0
153 0
177 0
210 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins11 mod1
5
6 0
82 0
141 0
165 0
184 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins11 mod3
5
6 0
82 0
141 0
165 0
185 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat7 dir1 ins4 mod1
5
6 0
90 0
149 0
173 0
203 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins11 mod1
5
6 1
82 0
141 0
165 0
184 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins11 mod3
5
6 1
82 0
141 0
165 0
185 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat7 dir2 ins4 mod1
5
6 1
90 0
149 0
173 0
203 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins11 mod1
5
6 2
82 0
141 0
165 0
184 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins11 mod3
5
6 2
82 0
141 0
165 0
185 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat7 dir3 ins4 mod1
5
6 2
90 0
149 0
173 0
203 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins11 mod1
5
6 3
82 0
141 0
165 0
184 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins11 mod3
5
6 3
82 0
141 0
165 0
185 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat7 dir4 ins4 mod1
5
6 3
90 0
149 0
173 0
203 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins11 mod1
5
6 4
82 0
141 0
165 0
184 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins11 mod3
5
6 4
82 0
141 0
165 0
185 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat7 dir5 ins4 mod1
5
6 4
90 0
149 0
173 0
203 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins11 mod1
5
6 5
82 0
141 0
165 0
184 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins11 mod3
5
6 5
82 0
141 0
165 0
185 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat7 dir6 ins4 mod1
5
6 5
90 0
149 0
173 0
203 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins11 mod1
5
6 6
82 0
141 0
165 0
184 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins11 mod3
5
6 6
82 0
141 0
165 0
185 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat7 dir7 ins4 mod1
5
6 6
90 0
149 0
173 0
203 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins11 mod1
5
6 7
82 0
141 0
165 0
184 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins11 mod3
5
6 7
82 0
141 0
165 0
185 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat7 dir8 ins4 mod1
5
6 7
90 0
149 0
173 0
203 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins11 mod1
5
6 8
82 0
141 0
165 0
184 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins11 mod3
5
6 8
82 0
141 0
165 0
185 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat7 dir9 ins4 mod1
5
6 8
90 0
149 0
173 0
203 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins12 mod1
5
7 0
83 0
142 0
166 0
186 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins12 mod2
5
7 0
83 0
142 0
166 0
187 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins12 mod3
5
7 0
83 0
142 0
166 0
188 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins15 mod1
5
7 0
86 0
145 0
169 0
194 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins15 mod2
5
7 0
86 0
145 0
169 0
195 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins15 mod3
5
7 0
86 0
145 0
169 0
196 0
1
0 114 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins2 mod1
5
7 0
88 0
147 0
171 0
199 0
1
0 112 -1 0
1
end_operator
begin_operator
take_image sat8 dir1 ins2 mod2
5
7 0
88 0
147 0
171 0
200 0
1
0 113 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins12 mod1
5
7 1
83 0
142 0
166 0
186 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins12 mod2
5
7 1
83 0
142 0
166 0
187 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins12 mod3
5
7 1
83 0
142 0
166 0
188 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins15 mod1
5
7 1
86 0
145 0
169 0
194 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins15 mod2
5
7 1
86 0
145 0
169 0
195 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins15 mod3
5
7 1
86 0
145 0
169 0
196 0
1
0 117 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins2 mod1
5
7 1
88 0
147 0
171 0
199 0
1
0 115 -1 0
1
end_operator
begin_operator
take_image sat8 dir2 ins2 mod2
5
7 1
88 0
147 0
171 0
200 0
1
0 116 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins12 mod1
5
7 2
83 0
142 0
166 0
186 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins12 mod2
5
7 2
83 0
142 0
166 0
187 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins12 mod3
5
7 2
83 0
142 0
166 0
188 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins15 mod1
5
7 2
86 0
145 0
169 0
194 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins15 mod2
5
7 2
86 0
145 0
169 0
195 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins15 mod3
5
7 2
86 0
145 0
169 0
196 0
1
0 120 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins2 mod1
5
7 2
88 0
147 0
171 0
199 0
1
0 118 -1 0
1
end_operator
begin_operator
take_image sat8 dir3 ins2 mod2
5
7 2
88 0
147 0
171 0
200 0
1
0 119 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins12 mod1
5
7 3
83 0
142 0
166 0
186 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins12 mod2
5
7 3
83 0
142 0
166 0
187 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins12 mod3
5
7 3
83 0
142 0
166 0
188 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins15 mod1
5
7 3
86 0
145 0
169 0
194 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins15 mod2
5
7 3
86 0
145 0
169 0
195 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins15 mod3
5
7 3
86 0
145 0
169 0
196 0
1
0 123 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins2 mod1
5
7 3
88 0
147 0
171 0
199 0
1
0 121 -1 0
1
end_operator
begin_operator
take_image sat8 dir4 ins2 mod2
5
7 3
88 0
147 0
171 0
200 0
1
0 122 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins12 mod1
5
7 4
83 0
142 0
166 0
186 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins12 mod2
5
7 4
83 0
142 0
166 0
187 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins12 mod3
5
7 4
83 0
142 0
166 0
188 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins15 mod1
5
7 4
86 0
145 0
169 0
194 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins15 mod2
5
7 4
86 0
145 0
169 0
195 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins15 mod3
5
7 4
86 0
145 0
169 0
196 0
1
0 126 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins2 mod1
5
7 4
88 0
147 0
171 0
199 0
1
0 124 -1 0
1
end_operator
begin_operator
take_image sat8 dir5 ins2 mod2
5
7 4
88 0
147 0
171 0
200 0
1
0 125 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins12 mod1
5
7 5
83 0
142 0
166 0
186 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins12 mod2
5
7 5
83 0
142 0
166 0
187 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins12 mod3
5
7 5
83 0
142 0
166 0
188 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins15 mod1
5
7 5
86 0
145 0
169 0
194 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins15 mod2
5
7 5
86 0
145 0
169 0
195 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins15 mod3
5
7 5
86 0
145 0
169 0
196 0
1
0 129 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins2 mod1
5
7 5
88 0
147 0
171 0
199 0
1
0 127 -1 0
1
end_operator
begin_operator
take_image sat8 dir6 ins2 mod2
5
7 5
88 0
147 0
171 0
200 0
1
0 128 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins12 mod1
5
7 6
83 0
142 0
166 0
186 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins12 mod2
5
7 6
83 0
142 0
166 0
187 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins12 mod3
5
7 6
83 0
142 0
166 0
188 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins15 mod1
5
7 6
86 0
145 0
169 0
194 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins15 mod2
5
7 6
86 0
145 0
169 0
195 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins15 mod3
5
7 6
86 0
145 0
169 0
196 0
1
0 132 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins2 mod1
5
7 6
88 0
147 0
171 0
199 0
1
0 130 -1 0
1
end_operator
begin_operator
take_image sat8 dir7 ins2 mod2
5
7 6
88 0
147 0
171 0
200 0
1
0 131 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins12 mod1
5
7 7
83 0
142 0
166 0
186 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins12 mod2
5
7 7
83 0
142 0
166 0
187 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins12 mod3
5
7 7
83 0
142 0
166 0
188 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins15 mod1
5
7 7
86 0
145 0
169 0
194 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins15 mod2
5
7 7
86 0
145 0
169 0
195 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins15 mod3
5
7 7
86 0
145 0
169 0
196 0
1
0 135 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins2 mod1
5
7 7
88 0
147 0
171 0
199 0
1
0 133 -1 0
1
end_operator
begin_operator
take_image sat8 dir8 ins2 mod2
5
7 7
88 0
147 0
171 0
200 0
1
0 134 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins12 mod1
5
7 8
83 0
142 0
166 0
186 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins12 mod2
5
7 8
83 0
142 0
166 0
187 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins12 mod3
5
7 8
83 0
142 0
166 0
188 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins15 mod1
5
7 8
86 0
145 0
169 0
194 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins15 mod2
5
7 8
86 0
145 0
169 0
195 0
1
0 137 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins15 mod3
5
7 8
86 0
145 0
169 0
196 0
1
0 138 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins2 mod1
5
7 8
88 0
147 0
171 0
199 0
1
0 136 -1 0
1
end_operator
begin_operator
take_image sat8 dir9 ins2 mod2
5
7 8
88 0
147 0
171 0
200 0
1
0 137 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
3
0 0 1 0
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
3
0 0 2 0
0 8 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
3
0 0 3 0
0 8 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
3
0 0 4 0
0 8 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir6
0
3
0 0 5 0
0 8 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir7
0
3
0 0 6 0
0 8 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir8
0
3
0 0 7 0
0 8 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir9
0
3
0 0 8 0
0 8 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
3
0 0 0 1
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
3
0 0 2 1
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
3
0 0 3 1
0 9 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir5
0
3
0 0 4 1
0 9 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir6
0
3
0 0 5 1
0 9 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir7
0
3
0 0 6 1
0 9 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir8
0
3
0 0 7 1
0 9 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir9
0
3
0 0 8 1
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
3
0 0 0 2
0 8 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
3
0 0 1 2
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
3
0 0 3 2
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir5
0
3
0 0 4 2
0 10 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir6
0
3
0 0 5 2
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir7
0
3
0 0 6 2
0 10 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir8
0
3
0 0 7 2
0 10 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir9
0
3
0 0 8 2
0 10 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
3
0 0 0 3
0 8 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
3
0 0 1 3
0 9 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
3
0 0 2 3
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir5
0
3
0 0 4 3
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir6
0
3
0 0 5 3
0 11 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir7
0
3
0 0 6 3
0 11 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir8
0
3
0 0 7 3
0 11 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir9
0
3
0 0 8 3
0 11 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir1
0
3
0 0 0 4
0 8 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir2
0
3
0 0 1 4
0 9 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir3
0
3
0 0 2 4
0 10 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir4
0
3
0 0 3 4
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir6
0
3
0 0 5 4
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir7
0
3
0 0 6 4
0 12 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir8
0
3
0 0 7 4
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir9
0
3
0 0 8 4
0 12 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir1
0
3
0 0 0 5
0 8 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir2
0
3
0 0 1 5
0 9 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir3
0
3
0 0 2 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir4
0
3
0 0 3 5
0 11 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir5
0
3
0 0 4 5
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat1 dir6 dir7
0
3
0 0 6 5
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir8
0
3
0 0 7 5
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir6 dir9
0
3
0 0 8 5
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir7 dir1
0
3
0 0 0 6
0 8 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir2
0
3
0 0 1 6
0 9 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir3
0
3
0 0 2 6
0 10 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir4
0
3
0 0 3 6
0 11 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir5
0
3
0 0 4 6
0 12 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir6
0
3
0 0 5 6
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
turn_to sat1 dir7 dir8
0
3
0 0 7 6
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat1 dir7 dir9
0
3
0 0 8 6
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir8 dir1
0
3
0 0 0 7
0 8 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir2
0
3
0 0 1 7
0 9 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir3
0
3
0 0 2 7
0 10 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir4
0
3
0 0 3 7
0 11 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir5
0
3
0 0 4 7
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir6
0
3
0 0 5 7
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir7
0
3
0 0 6 7
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat1 dir8 dir9
0
3
0 0 8 7
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir9 dir1
0
3
0 0 0 8
0 8 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir2
0
3
0 0 1 8
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir3
0
3
0 0 2 8
0 10 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir4
0
3
0 0 3 8
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir5
0
3
0 0 4 8
0 12 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir6
0
3
0 0 5 8
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir7
0
3
0 0 6 8
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat1 dir9 dir8
0
3
0 0 7 8
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
3
0 1 1 0
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
3
0 1 2 0
0 17 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
3
0 1 3 0
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir5
0
3
0 1 4 0
0 17 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir6
0
3
0 1 5 0
0 17 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir7
0
3
0 1 6 0
0 17 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir8
0
3
0 1 7 0
0 17 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir9
0
3
0 1 8 0
0 17 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
3
0 1 0 1
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
3
0 1 2 1
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
3
0 1 3 1
0 18 0 1
0 20 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir5
0
3
0 1 4 1
0 18 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir6
0
3
0 1 5 1
0 18 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir7
0
3
0 1 6 1
0 18 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir8
0
3
0 1 7 1
0 18 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir9
0
3
0 1 8 1
0 18 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
3
0 1 0 2
0 17 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
3
0 1 1 2
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
3
0 1 3 2
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir5
0
3
0 1 4 2
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir6
0
3
0 1 5 2
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir7
0
3
0 1 6 2
0 19 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir8
0
3
0 1 7 2
0 19 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir9
0
3
0 1 8 2
0 19 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
3
0 1 0 3
0 17 -1 0
0 20 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
3
0 1 1 3
0 18 -1 0
0 20 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
3
0 1 2 3
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir5
0
3
0 1 4 3
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir6
0
3
0 1 5 3
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir7
0
3
0 1 6 3
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir8
0
3
0 1 7 3
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir9
0
3
0 1 8 3
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir1
0
3
0 1 0 4
0 17 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir2
0
3
0 1 1 4
0 18 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir3
0
3
0 1 2 4
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir4
0
3
0 1 3 4
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir6
0
3
0 1 5 4
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir7
0
3
0 1 6 4
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir8
0
3
0 1 7 4
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir9
0
3
0 1 8 4
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir1
0
3
0 1 0 5
0 17 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir2
0
3
0 1 1 5
0 18 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir3
0
3
0 1 2 5
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir4
0
3
0 1 3 5
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir5
0
3
0 1 4 5
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat2 dir6 dir7
0
3
0 1 6 5
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir8
0
3
0 1 7 5
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir6 dir9
0
3
0 1 8 5
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir7 dir1
0
3
0 1 0 6
0 17 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir2
0
3
0 1 1 6
0 18 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir3
0
3
0 1 2 6
0 19 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir4
0
3
0 1 3 6
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir5
0
3
0 1 4 6
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir6
0
3
0 1 5 6
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat2 dir7 dir8
0
3
0 1 7 6
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
turn_to sat2 dir7 dir9
0
3
0 1 8 6
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir8 dir1
0
3
0 1 0 7
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir2
0
3
0 1 1 7
0 18 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir3
0
3
0 1 2 7
0 19 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir4
0
3
0 1 3 7
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir5
0
3
0 1 4 7
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir6
0
3
0 1 5 7
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir7
0
3
0 1 6 7
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
turn_to sat2 dir8 dir9
0
3
0 1 8 7
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
turn_to sat2 dir9 dir1
0
3
0 1 0 8
0 17 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir2
0
3
0 1 1 8
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir3
0
3
0 1 2 8
0 19 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir4
0
3
0 1 3 8
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir5
0
3
0 1 4 8
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir6
0
3
0 1 5 8
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir7
0
3
0 1 6 8
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat2 dir9 dir8
0
3
0 1 7 8
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
3
0 2 1 0
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
3
0 2 2 0
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
3
0 2 3 0
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir5
0
3
0 2 4 0
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir6
0
3
0 2 5 0
0 26 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir7
0
3
0 2 6 0
0 26 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir8
0
3
0 2 7 0
0 26 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir9
0
3
0 2 8 0
0 26 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
3
0 2 0 1
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
3
0 2 2 1
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
3
0 2 3 1
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir5
0
3
0 2 4 1
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir6
0
3
0 2 5 1
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir7
0
3
0 2 6 1
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir8
0
3
0 2 7 1
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir9
0
3
0 2 8 1
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
3
0 2 0 2
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
3
0 2 1 2
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
3
0 2 3 2
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir5
0
3
0 2 4 2
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir6
0
3
0 2 5 2
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir7
0
3
0 2 6 2
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir8
0
3
0 2 7 2
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir9
0
3
0 2 8 2
0 28 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
3
0 2 0 3
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
3
0 2 1 3
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
3
0 2 2 3
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir5
0
3
0 2 4 3
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir6
0
3
0 2 5 3
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir7
0
3
0 2 6 3
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir8
0
3
0 2 7 3
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir9
0
3
0 2 8 3
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir1
0
3
0 2 0 4
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir2
0
3
0 2 1 4
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir3
0
3
0 2 2 4
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir4
0
3
0 2 3 4
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir6
0
3
0 2 5 4
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir7
0
3
0 2 6 4
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir8
0
3
0 2 7 4
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir9
0
3
0 2 8 4
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir1
0
3
0 2 0 5
0 26 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir2
0
3
0 2 1 5
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir3
0
3
0 2 2 5
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir4
0
3
0 2 3 5
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir5
0
3
0 2 4 5
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
turn_to sat3 dir6 dir7
0
3
0 2 6 5
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir8
0
3
0 2 7 5
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir6 dir9
0
3
0 2 8 5
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir7 dir1
0
3
0 2 0 6
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir2
0
3
0 2 1 6
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir3
0
3
0 2 2 6
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir4
0
3
0 2 3 6
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir5
0
3
0 2 4 6
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir6
0
3
0 2 5 6
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
turn_to sat3 dir7 dir8
0
3
0 2 7 6
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
turn_to sat3 dir7 dir9
0
3
0 2 8 6
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir8 dir1
0
3
0 2 0 7
0 26 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir2
0
3
0 2 1 7
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir3
0
3
0 2 2 7
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir4
0
3
0 2 3 7
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir5
0
3
0 2 4 7
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir6
0
3
0 2 5 7
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir7
0
3
0 2 6 7
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
turn_to sat3 dir8 dir9
0
3
0 2 8 7
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
turn_to sat3 dir9 dir1
0
3
0 2 0 8
0 26 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir2
0
3
0 2 1 8
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir3
0
3
0 2 2 8
0 28 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir4
0
3
0 2 3 8
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir5
0
3
0 2 4 8
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir6
0
3
0 2 5 8
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir7
0
3
0 2 6 8
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat3 dir9 dir8
0
3
0 2 7 8
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
3
0 3 1 0
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
3
0 3 2 0
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
3
0 3 3 0
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir5
0
3
0 3 4 0
0 35 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir6
0
3
0 3 5 0
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir7
0
3
0 3 6 0
0 35 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir8
0
3
0 3 7 0
0 35 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir9
0
3
0 3 8 0
0 35 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
3
0 3 0 1
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
3
0 3 2 1
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
3
0 3 3 1
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir5
0
3
0 3 4 1
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir6
0
3
0 3 5 1
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir7
0
3
0 3 6 1
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir8
0
3
0 3 7 1
0 36 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir9
0
3
0 3 8 1
0 36 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
3
0 3 0 2
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
3
0 3 1 2
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
3
0 3 3 2
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
3
0 3 4 2
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir6
0
3
0 3 5 2
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir7
0
3
0 3 6 2
0 37 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir8
0
3
0 3 7 2
0 37 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir9
0
3
0 3 8 2
0 37 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
3
0 3 0 3
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
3
0 3 1 3
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
3
0 3 2 3
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
3
0 3 4 3
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir6
0
3
0 3 5 3
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir7
0
3
0 3 6 3
0 38 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir8
0
3
0 3 7 3
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir9
0
3
0 3 8 3
0 38 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
3
0 3 0 4
0 35 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
3
0 3 1 4
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
3
0 3 2 4
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
3
0 3 3 4
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir6
0
3
0 3 5 4
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir7
0
3
0 3 6 4
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir8
0
3
0 3 7 4
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir9
0
3
0 3 8 4
0 39 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir1
0
3
0 3 0 5
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir2
0
3
0 3 1 5
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir3
0
3
0 3 2 5
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir4
0
3
0 3 3 5
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir5
0
3
0 3 4 5
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
turn_to sat4 dir6 dir7
0
3
0 3 6 5
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir8
0
3
0 3 7 5
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir6 dir9
0
3
0 3 8 5
0 40 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir7 dir1
0
3
0 3 0 6
0 35 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir2
0
3
0 3 1 6
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir3
0
3
0 3 2 6
0 37 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir4
0
3
0 3 3 6
0 38 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir5
0
3
0 3 4 6
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir6
0
3
0 3 5 6
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
turn_to sat4 dir7 dir8
0
3
0 3 7 6
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
turn_to sat4 dir7 dir9
0
3
0 3 8 6
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir8 dir1
0
3
0 3 0 7
0 35 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir2
0
3
0 3 1 7
0 36 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir3
0
3
0 3 2 7
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir4
0
3
0 3 3 7
0 38 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir5
0
3
0 3 4 7
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir6
0
3
0 3 5 7
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir7
0
3
0 3 6 7
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
turn_to sat4 dir8 dir9
0
3
0 3 8 7
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
turn_to sat4 dir9 dir1
0
3
0 3 0 8
0 35 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir2
0
3
0 3 1 8
0 36 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir3
0
3
0 3 2 8
0 37 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir4
0
3
0 3 3 8
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir5
0
3
0 3 4 8
0 39 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir6
0
3
0 3 5 8
0 40 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir7
0
3
0 3 6 8
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat4 dir9 dir8
0
3
0 3 7 8
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
turn_to sat5 dir1 dir2
0
3
0 4 1 0
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir3
0
3
0 4 2 0
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir4
0
3
0 4 3 0
0 44 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir5
0
3
0 4 4 0
0 44 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir6
0
3
0 4 5 0
0 44 0 1
0 49 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir7
0
3
0 4 6 0
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir8
0
3
0 4 7 0
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir1 dir9
0
3
0 4 8 0
0 44 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir1
0
3
0 4 0 1
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
turn_to sat5 dir2 dir3
0
3
0 4 2 1
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir4
0
3
0 4 3 1
0 45 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir5
0
3
0 4 4 1
0 45 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir6
0
3
0 4 5 1
0 45 0 1
0 49 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir7
0
3
0 4 6 1
0 45 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir8
0
3
0 4 7 1
0 45 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir2 dir9
0
3
0 4 8 1
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir1
0
3
0 4 0 2
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir2
0
3
0 4 1 2
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
turn_to sat5 dir3 dir4
0
3
0 4 3 2
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir5
0
3
0 4 4 2
0 46 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir6
0
3
0 4 5 2
0 46 0 1
0 49 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir7
0
3
0 4 6 2
0 46 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir8
0
3
0 4 7 2
0 46 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir3 dir9
0
3
0 4 8 2
0 46 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir1
0
3
0 4 0 3
0 44 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir2
0
3
0 4 1 3
0 45 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir3
0
3
0 4 2 3
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
turn_to sat5 dir4 dir5
0
3
0 4 4 3
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir6
0
3
0 4 5 3
0 47 0 1
0 49 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir7
0
3
0 4 6 3
0 47 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir8
0
3
0 4 7 3
0 47 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir4 dir9
0
3
0 4 8 3
0 47 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir1
0
3
0 4 0 4
0 44 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir2
0
3
0 4 1 4
0 45 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir3
0
3
0 4 2 4
0 46 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir4
0
3
0 4 3 4
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
turn_to sat5 dir5 dir6
0
3
0 4 5 4
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir7
0
3
0 4 6 4
0 48 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir8
0
3
0 4 7 4
0 48 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir5 dir9
0
3
0 4 8 4
0 48 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir1
0
3
0 4 0 5
0 44 -1 0
0 49 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir2
0
3
0 4 1 5
0 45 -1 0
0 49 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir3
0
3
0 4 2 5
0 46 -1 0
0 49 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir4
0
3
0 4 3 5
0 47 -1 0
0 49 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir5
0
3
0 4 4 5
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
turn_to sat5 dir6 dir7
0
3
0 4 6 5
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir8
0
3
0 4 7 5
0 49 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir6 dir9
0
3
0 4 8 5
0 49 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir7 dir1
0
3
0 4 0 6
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir2
0
3
0 4 1 6
0 45 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir3
0
3
0 4 2 6
0 46 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir4
0
3
0 4 3 6
0 47 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir5
0
3
0 4 4 6
0 48 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir6
0
3
0 4 5 6
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
turn_to sat5 dir7 dir8
0
3
0 4 7 6
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
turn_to sat5 dir7 dir9
0
3
0 4 8 6
0 50 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir8 dir1
0
3
0 4 0 7
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir2
0
3
0 4 1 7
0 45 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir3
0
3
0 4 2 7
0 46 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir4
0
3
0 4 3 7
0 47 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir5
0
3
0 4 4 7
0 48 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir6
0
3
0 4 5 7
0 49 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir7
0
3
0 4 6 7
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
turn_to sat5 dir8 dir9
0
3
0 4 8 7
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
turn_to sat5 dir9 dir1
0
3
0 4 0 8
0 44 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir2
0
3
0 4 1 8
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir3
0
3
0 4 2 8
0 46 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir4
0
3
0 4 3 8
0 47 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir5
0
3
0 4 4 8
0 48 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir6
0
3
0 4 5 8
0 49 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir7
0
3
0 4 6 8
0 50 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat5 dir9 dir8
0
3
0 4 7 8
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
turn_to sat6 dir1 dir2
0
3
0 5 1 0
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir3
0
3
0 5 2 0
0 53 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir4
0
3
0 5 3 0
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir5
0
3
0 5 4 0
0 53 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir6
0
3
0 5 5 0
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir7
0
3
0 5 6 0
0 53 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir8
0
3
0 5 7 0
0 53 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir1 dir9
0
3
0 5 8 0
0 53 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir1
0
3
0 5 0 1
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
turn_to sat6 dir2 dir3
0
3
0 5 2 1
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir4
0
3
0 5 3 1
0 54 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir5
0
3
0 5 4 1
0 54 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir6
0
3
0 5 5 1
0 54 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir7
0
3
0 5 6 1
0 54 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir8
0
3
0 5 7 1
0 54 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir2 dir9
0
3
0 5 8 1
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir1
0
3
0 5 0 2
0 53 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir2
0
3
0 5 1 2
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
turn_to sat6 dir3 dir4
0
3
0 5 3 2
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir5
0
3
0 5 4 2
0 55 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir6
0
3
0 5 5 2
0 55 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir7
0
3
0 5 6 2
0 55 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir8
0
3
0 5 7 2
0 55 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir3 dir9
0
3
0 5 8 2
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir1
0
3
0 5 0 3
0 53 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir2
0
3
0 5 1 3
0 54 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir3
0
3
0 5 2 3
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
turn_to sat6 dir4 dir5
0
3
0 5 4 3
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir6
0
3
0 5 5 3
0 56 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir7
0
3
0 5 6 3
0 56 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir8
0
3
0 5 7 3
0 56 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir4 dir9
0
3
0 5 8 3
0 56 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir1
0
3
0 5 0 4
0 53 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir2
0
3
0 5 1 4
0 54 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir3
0
3
0 5 2 4
0 55 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir4
0
3
0 5 3 4
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
turn_to sat6 dir5 dir6
0
3
0 5 5 4
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir7
0
3
0 5 6 4
0 57 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir8
0
3
0 5 7 4
0 57 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir5 dir9
0
3
0 5 8 4
0 57 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir1
0
3
0 5 0 5
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir2
0
3
0 5 1 5
0 54 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir3
0
3
0 5 2 5
0 55 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir4
0
3
0 5 3 5
0 56 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir5
0
3
0 5 4 5
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
turn_to sat6 dir6 dir7
0
3
0 5 6 5
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir8
0
3
0 5 7 5
0 58 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir6 dir9
0
3
0 5 8 5
0 58 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir7 dir1
0
3
0 5 0 6
0 53 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir2
0
3
0 5 1 6
0 54 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir3
0
3
0 5 2 6
0 55 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir4
0
3
0 5 3 6
0 56 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir5
0
3
0 5 4 6
0 57 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir6
0
3
0 5 5 6
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
turn_to sat6 dir7 dir8
0
3
0 5 7 6
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
turn_to sat6 dir7 dir9
0
3
0 5 8 6
0 59 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir8 dir1
0
3
0 5 0 7
0 53 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir2
0
3
0 5 1 7
0 54 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir3
0
3
0 5 2 7
0 55 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir4
0
3
0 5 3 7
0 56 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir5
0
3
0 5 4 7
0 57 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir6
0
3
0 5 5 7
0 58 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir7
0
3
0 5 6 7
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
turn_to sat6 dir8 dir9
0
3
0 5 8 7
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
turn_to sat6 dir9 dir1
0
3
0 5 0 8
0 53 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir2
0
3
0 5 1 8
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir3
0
3
0 5 2 8
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir4
0
3
0 5 3 8
0 56 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir5
0
3
0 5 4 8
0 57 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir6
0
3
0 5 5 8
0 58 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir7
0
3
0 5 6 8
0 59 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat6 dir9 dir8
0
3
0 5 7 8
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
turn_to sat7 dir1 dir2
0
3
0 6 1 0
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir3
0
3
0 6 2 0
0 62 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir4
0
3
0 6 3 0
0 62 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir5
0
3
0 6 4 0
0 62 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir6
0
3
0 6 5 0
0 62 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir7
0
3
0 6 6 0
0 62 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir8
0
3
0 6 7 0
0 62 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir1 dir9
0
3
0 6 8 0
0 62 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir1
0
3
0 6 0 1
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
turn_to sat7 dir2 dir3
0
3
0 6 2 1
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir4
0
3
0 6 3 1
0 63 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir5
0
3
0 6 4 1
0 63 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir6
0
3
0 6 5 1
0 63 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir7
0
3
0 6 6 1
0 63 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir8
0
3
0 6 7 1
0 63 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir2 dir9
0
3
0 6 8 1
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir1
0
3
0 6 0 2
0 62 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat7 dir3 dir2
0
3
0 6 1 2
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
turn_to sat7 dir3 dir4
0
3
0 6 3 2
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir5
0
3
0 6 4 2
0 64 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir6
0
3
0 6 5 2
0 64 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir7
0
3
0 6 6 2
0 64 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir8
0
3
0 6 7 2
0 64 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir3 dir9
0
3
0 6 8 2
0 64 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir1
0
3
0 6 0 3
0 62 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir2
0
3
0 6 1 3
0 63 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir3
0
3
0 6 2 3
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
turn_to sat7 dir4 dir5
0
3
0 6 4 3
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir6
0
3
0 6 5 3
0 65 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir7
0
3
0 6 6 3
0 65 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir8
0
3
0 6 7 3
0 65 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir4 dir9
0
3
0 6 8 3
0 65 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir1
0
3
0 6 0 4
0 62 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir2
0
3
0 6 1 4
0 63 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir3
0
3
0 6 2 4
0 64 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir4
0
3
0 6 3 4
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
turn_to sat7 dir5 dir6
0
3
0 6 5 4
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir7
0
3
0 6 6 4
0 66 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir8
0
3
0 6 7 4
0 66 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir5 dir9
0
3
0 6 8 4
0 66 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir1
0
3
0 6 0 5
0 62 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir2
0
3
0 6 1 5
0 63 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir3
0
3
0 6 2 5
0 64 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir4
0
3
0 6 3 5
0 65 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir5
0
3
0 6 4 5
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
turn_to sat7 dir6 dir7
0
3
0 6 6 5
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir8
0
3
0 6 7 5
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir6 dir9
0
3
0 6 8 5
0 67 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir7 dir1
0
3
0 6 0 6
0 62 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir2
0
3
0 6 1 6
0 63 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir3
0
3
0 6 2 6
0 64 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir4
0
3
0 6 3 6
0 65 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir5
0
3
0 6 4 6
0 66 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir6
0
3
0 6 5 6
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
turn_to sat7 dir7 dir8
0
3
0 6 7 6
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
turn_to sat7 dir7 dir9
0
3
0 6 8 6
0 68 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir8 dir1
0
3
0 6 0 7
0 62 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir2
0
3
0 6 1 7
0 63 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir3
0
3
0 6 2 7
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir4
0
3
0 6 3 7
0 65 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir5
0
3
0 6 4 7
0 66 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir6
0
3
0 6 5 7
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir7
0
3
0 6 6 7
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
turn_to sat7 dir8 dir9
0
3
0 6 8 7
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
turn_to sat7 dir9 dir1
0
3
0 6 0 8
0 62 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir2
0
3
0 6 1 8
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir3
0
3
0 6 2 8
0 64 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir4
0
3
0 6 3 8
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir5
0
3
0 6 4 8
0 66 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir6
0
3
0 6 5 8
0 67 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir7
0
3
0 6 6 8
0 68 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat7 dir9 dir8
0
3
0 6 7 8
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
turn_to sat8 dir1 dir2
0
3
0 7 1 0
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir3
0
3
0 7 2 0
0 71 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir4
0
3
0 7 3 0
0 71 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir5
0
3
0 7 4 0
0 71 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir6
0
3
0 7 5 0
0 71 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir7
0
3
0 7 6 0
0 71 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir8
0
3
0 7 7 0
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir1 dir9
0
3
0 7 8 0
0 71 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir1
0
3
0 7 0 1
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
turn_to sat8 dir2 dir3
0
3
0 7 2 1
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir4
0
3
0 7 3 1
0 72 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir5
0
3
0 7 4 1
0 72 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir6
0
3
0 7 5 1
0 72 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir7
0
3
0 7 6 1
0 72 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir8
0
3
0 7 7 1
0 72 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir2 dir9
0
3
0 7 8 1
0 72 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir1
0
3
0 7 0 2
0 71 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat8 dir3 dir2
0
3
0 7 1 2
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
turn_to sat8 dir3 dir4
0
3
0 7 3 2
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir5
0
3
0 7 4 2
0 73 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir6
0
3
0 7 5 2
0 73 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir7
0
3
0 7 6 2
0 73 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir8
0
3
0 7 7 2
0 73 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir3 dir9
0
3
0 7 8 2
0 73 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir1
0
3
0 7 0 3
0 71 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir2
0
3
0 7 1 3
0 72 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir3
0
3
0 7 2 3
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
turn_to sat8 dir4 dir5
0
3
0 7 4 3
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir6
0
3
0 7 5 3
0 74 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir7
0
3
0 7 6 3
0 74 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir8
0
3
0 7 7 3
0 74 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir4 dir9
0
3
0 7 8 3
0 74 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir1
0
3
0 7 0 4
0 71 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir2
0
3
0 7 1 4
0 72 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir3
0
3
0 7 2 4
0 73 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir4
0
3
0 7 3 4
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
turn_to sat8 dir5 dir6
0
3
0 7 5 4
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir7
0
3
0 7 6 4
0 75 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir8
0
3
0 7 7 4
0 75 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir5 dir9
0
3
0 7 8 4
0 75 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir1
0
3
0 7 0 5
0 71 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir2
0
3
0 7 1 5
0 72 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir3
0
3
0 7 2 5
0 73 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir4
0
3
0 7 3 5
0 74 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir5
0
3
0 7 4 5
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
turn_to sat8 dir6 dir7
0
3
0 7 6 5
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir8
0
3
0 7 7 5
0 76 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir6 dir9
0
3
0 7 8 5
0 76 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir7 dir1
0
3
0 7 0 6
0 71 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir2
0
3
0 7 1 6
0 72 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir3
0
3
0 7 2 6
0 73 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir4
0
3
0 7 3 6
0 74 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir5
0
3
0 7 4 6
0 75 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir6
0
3
0 7 5 6
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
turn_to sat8 dir7 dir8
0
3
0 7 7 6
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
turn_to sat8 dir7 dir9
0
3
0 7 8 6
0 77 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir8 dir1
0
3
0 7 0 7
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir2
0
3
0 7 1 7
0 72 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir3
0
3
0 7 2 7
0 73 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir4
0
3
0 7 3 7
0 74 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir5
0
3
0 7 4 7
0 75 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir6
0
3
0 7 5 7
0 76 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir7
0
3
0 7 6 7
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
turn_to sat8 dir8 dir9
0
3
0 7 8 7
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
turn_to sat8 dir9 dir1
0
3
0 7 0 8
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir2
0
3
0 7 1 8
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir3
0
3
0 7 2 8
0 73 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir4
0
3
0 7 3 8
0 74 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir5
0
3
0 7 4 8
0 75 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir6
0
3
0 7 5 8
0 76 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir7
0
3
0 7 6 8
0 77 -1 0
0 79 0 1
1
end_operator
begin_operator
turn_to sat8 dir9 dir8
0
3
0 7 7 8
0 78 -1 0
0 79 0 1
1
end_operator
0
