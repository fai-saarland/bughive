begin_version
3
end_version
begin_metric
1
end_metric
58
begin_variable
var0
-1
5
pointing sat1 dir1
pointing sat1 dir2
pointing sat1 dir3
pointing sat1 dir4
pointing sat1 dir5
end_variable
begin_variable
var1
-1
5
pointing sat2 dir1
pointing sat2 dir2
pointing sat2 dir3
pointing sat2 dir4
pointing sat2 dir5
end_variable
begin_variable
var2
-1
5
pointing sat3 dir1
pointing sat3 dir2
pointing sat3 dir3
pointing sat3 dir4
pointing sat3 dir5
end_variable
begin_variable
var3
-1
5
pointing sat4 dir1
pointing sat4 dir2
pointing sat4 dir3
pointing sat4 dir4
pointing sat4 dir5
end_variable
begin_variable
var4
-1
2
NOT-pointing sat1 dir1
none-of-those
end_variable
begin_variable
var5
-1
2
NOT-pointing sat1 dir2
none-of-those
end_variable
begin_variable
var6
-1
2
NOT-pointing sat1 dir3
none-of-those
end_variable
begin_variable
var7
-1
2
NOT-pointing sat1 dir4
none-of-those
end_variable
begin_variable
var8
-1
2
NOT-pointing sat1 dir5
none-of-those
end_variable
begin_variable
var9
-1
2
NOT-pointing sat2 dir1
none-of-those
end_variable
begin_variable
var10
-1
2
NOT-pointing sat2 dir2
none-of-those
end_variable
begin_variable
var11
-1
2
NOT-pointing sat2 dir3
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-pointing sat2 dir4
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-pointing sat2 dir5
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-pointing sat3 dir1
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-pointing sat3 dir2
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-pointing sat3 dir3
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-pointing sat3 dir4
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-pointing sat3 dir5
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-pointing sat4 dir1
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-pointing sat4 dir2
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-pointing sat4 dir3
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-pointing sat4 dir4
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-pointing sat4 dir5
none-of-those
end_variable
begin_variable
var24
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var25
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var26
-1
2
calibrated ins3
none-of-those
end_variable
begin_variable
var27
-1
2
calibrated ins4
none-of-those
end_variable
begin_variable
var28
-1
2
calibrated ins5
none-of-those
end_variable
begin_variable
var29
-1
2
calibration_target ins1 dir3
none-of-those
end_variable
begin_variable
var30
-1
2
calibration_target ins2 dir5
none-of-those
end_variable
begin_variable
var31
-1
2
calibration_target ins3 dir4
none-of-those
end_variable
begin_variable
var32
-1
2
calibration_target ins4 dir2
none-of-those
end_variable
begin_variable
var33
-1
2
calibration_target ins5 dir1
none-of-those
end_variable
begin_variable
var34
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var35
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var36
-1
2
have_image dir3 mod1
none-of-those
end_variable
begin_variable
var37
-1
2
have_image dir4 mod1
none-of-those
end_variable
begin_variable
var38
-1
2
have_image dir5 mod1
none-of-those
end_variable
begin_variable
var39
-1
2
on_board ins1 sat2
none-of-those
end_variable
begin_variable
var40
-1
2
on_board ins2 sat1
none-of-those
end_variable
begin_variable
var41
-1
2
on_board ins3 sat4
none-of-those
end_variable
begin_variable
var42
-1
2
on_board ins4 sat3
none-of-those
end_variable
begin_variable
var43
-1
2
on_board ins5 sat3
none-of-those
end_variable
begin_variable
var44
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var45
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var46
-1
2
power_avail sat3
none-of-those
end_variable
begin_variable
var47
-1
2
power_avail sat4
none-of-those
end_variable
begin_variable
var48
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var49
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var50
-1
2
power_on ins3
none-of-those
end_variable
begin_variable
var51
-1
2
power_on ins4
none-of-those
end_variable
begin_variable
var52
-1
2
power_on ins5
none-of-those
end_variable
begin_variable
var53
-1
2
supports ins1 mod1
none-of-those
end_variable
begin_variable
var54
-1
2
supports ins2 mod1
none-of-those
end_variable
begin_variable
var55
-1
2
supports ins3 mod1
none-of-those
end_variable
begin_variable
var56
-1
2
supports ins4 mod1
none-of-those
end_variable
begin_variable
var57
-1
2
supports ins5 mod1
none-of-those
end_variable
0
begin_state
4
0
3
4
0
0
0
0
1
1
0
0
0
0
0
0
0
1
0
0
0
0
0
1
1
1
1
1
1
0
0
0
0
0
1
1
1
1
1
0
0
0
0
0
0
0
0
0
1
1
1
1
1
0
0
0
0
0
end_state
begin_goal
8
0 4
1 3
2 1
34 0
35 0
36 0
37 0
38 0
end_goal
120
begin_operator
calibrate sat1 ins2 dir5
4
0 4
30 0
40 0
49 0
1
0 25 -1 0
1
end_operator
begin_operator
calibrate sat2 ins1 dir3
4
1 2
29 0
39 0
48 0
1
0 24 -1 0
1
end_operator
begin_operator
calibrate sat3 ins4 dir2
4
2 1
32 0
42 0
51 0
1
0 27 -1 0
1
end_operator
begin_operator
calibrate sat3 ins5 dir1
4
2 0
33 0
43 0
52 0
1
0 28 -1 0
1
end_operator
begin_operator
calibrate sat4 ins3 dir4
4
3 3
31 0
41 0
50 0
1
0 26 -1 0
1
end_operator
begin_operator
switch_off ins1 sat2
1
39 0
2
0 45 -1 0
0 48 0 1
1
end_operator
begin_operator
switch_off ins2 sat1
1
40 0
2
0 44 -1 0
0 49 0 1
1
end_operator
begin_operator
switch_off ins3 sat4
1
41 0
2
0 47 -1 0
0 50 0 1
1
end_operator
begin_operator
switch_off ins4 sat3
1
42 0
2
0 46 -1 0
0 51 0 1
1
end_operator
begin_operator
switch_off ins5 sat3
1
43 0
2
0 46 -1 0
0 52 0 1
1
end_operator
begin_operator
switch_on ins1 sat2
1
39 0
3
0 24 -1 1
0 45 0 1
0 48 -1 0
1
end_operator
begin_operator
switch_on ins2 sat1
1
40 0
3
0 25 -1 1
0 44 0 1
0 49 -1 0
1
end_operator
begin_operator
switch_on ins3 sat4
1
41 0
3
0 26 -1 1
0 47 0 1
0 50 -1 0
1
end_operator
begin_operator
switch_on ins4 sat3
1
42 0
3
0 27 -1 1
0 46 0 1
0 51 -1 0
1
end_operator
begin_operator
switch_on ins5 sat3
1
43 0
3
0 28 -1 1
0 46 0 1
0 52 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins2 mod1
5
0 0
25 0
40 0
49 0
54 0
1
0 34 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
5
0 1
25 0
40 0
49 0
54 0
1
0 35 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins2 mod1
5
0 2
25 0
40 0
49 0
54 0
1
0 36 -1 0
1
end_operator
begin_operator
take_image sat1 dir4 ins2 mod1
5
0 3
25 0
40 0
49 0
54 0
1
0 37 -1 0
1
end_operator
begin_operator
take_image sat1 dir5 ins2 mod1
5
0 4
25 0
40 0
49 0
54 0
1
0 38 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins1 mod1
5
1 0
24 0
39 0
48 0
53 0
1
0 34 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins1 mod1
5
1 1
24 0
39 0
48 0
53 0
1
0 35 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins1 mod1
5
1 2
24 0
39 0
48 0
53 0
1
0 36 -1 0
1
end_operator
begin_operator
take_image sat2 dir4 ins1 mod1
5
1 3
24 0
39 0
48 0
53 0
1
0 37 -1 0
1
end_operator
begin_operator
take_image sat2 dir5 ins1 mod1
5
1 4
24 0
39 0
48 0
53 0
1
0 38 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins4 mod1
5
2 0
27 0
42 0
51 0
56 0
1
0 34 -1 0
1
end_operator
begin_operator
take_image sat3 dir1 ins5 mod1
5
2 0
28 0
43 0
52 0
57 0
1
0 34 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins4 mod1
5
2 1
27 0
42 0
51 0
56 0
1
0 35 -1 0
1
end_operator
begin_operator
take_image sat3 dir2 ins5 mod1
5
2 1
28 0
43 0
52 0
57 0
1
0 35 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins4 mod1
5
2 2
27 0
42 0
51 0
56 0
1
0 36 -1 0
1
end_operator
begin_operator
take_image sat3 dir3 ins5 mod1
5
2 2
28 0
43 0
52 0
57 0
1
0 36 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins4 mod1
5
2 3
27 0
42 0
51 0
56 0
1
0 37 -1 0
1
end_operator
begin_operator
take_image sat3 dir4 ins5 mod1
5
2 3
28 0
43 0
52 0
57 0
1
0 37 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins4 mod1
5
2 4
27 0
42 0
51 0
56 0
1
0 38 -1 0
1
end_operator
begin_operator
take_image sat3 dir5 ins5 mod1
5
2 4
28 0
43 0
52 0
57 0
1
0 38 -1 0
1
end_operator
begin_operator
take_image sat4 dir1 ins3 mod1
5
3 0
26 0
41 0
50 0
55 0
1
0 34 -1 0
1
end_operator
begin_operator
take_image sat4 dir2 ins3 mod1
5
3 1
26 0
41 0
50 0
55 0
1
0 35 -1 0
1
end_operator
begin_operator
take_image sat4 dir3 ins3 mod1
5
3 2
26 0
41 0
50 0
55 0
1
0 36 -1 0
1
end_operator
begin_operator
take_image sat4 dir4 ins3 mod1
5
3 3
26 0
41 0
50 0
55 0
1
0 37 -1 0
1
end_operator
begin_operator
take_image sat4 dir5 ins3 mod1
5
3 4
26 0
41 0
50 0
55 0
1
0 38 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
3
0 0 1 0
0 4 0 1
0 5 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
3
0 0 2 0
0 4 0 1
0 6 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir4
0
3
0 0 3 0
0 4 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir5
0
3
0 0 4 0
0 4 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
3
0 0 0 1
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
3
0 0 2 1
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir4
0
3
0 0 3 1
0 5 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir5
0
3
0 0 4 1
0 5 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
3
0 0 0 2
0 4 -1 0
0 6 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
3
0 0 1 2
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir4
0
3
0 0 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir5
0
3
0 0 4 2
0 6 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir4 dir1
0
3
0 0 0 3
0 4 -1 0
0 7 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir2
0
3
0 0 1 3
0 5 -1 0
0 7 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir3
0
3
0 0 2 3
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
turn_to sat1 dir4 dir5
0
3
0 0 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
turn_to sat1 dir5 dir1
0
3
0 0 0 4
0 4 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir2
0
3
0 0 1 4
0 5 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir3
0
3
0 0 2 4
0 6 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat1 dir5 dir4
0
3
0 0 3 4
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
3
0 1 1 0
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
3
0 1 2 0
0 9 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir4
0
3
0 1 3 0
0 9 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir5
0
3
0 1 4 0
0 9 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
3
0 1 0 1
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
3
0 1 2 1
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir4
0
3
0 1 3 1
0 10 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir5
0
3
0 1 4 1
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
3
0 1 0 2
0 9 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
3
0 1 1 2
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir4
0
3
0 1 3 2
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir5
0
3
0 1 4 2
0 11 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat2 dir4 dir1
0
3
0 1 0 3
0 9 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir2
0
3
0 1 1 3
0 10 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir3
0
3
0 1 2 3
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
turn_to sat2 dir4 dir5
0
3
0 1 4 3
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
turn_to sat2 dir5 dir1
0
3
0 1 0 4
0 9 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir2
0
3
0 1 1 4
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir3
0
3
0 1 2 4
0 11 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat2 dir5 dir4
0
3
0 1 3 4
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
turn_to sat3 dir1 dir2
0
3
0 2 1 0
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir3
0
3
0 2 2 0
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir4
0
3
0 2 3 0
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat3 dir1 dir5
0
3
0 2 4 0
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir1
0
3
0 2 0 1
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
turn_to sat3 dir2 dir3
0
3
0 2 2 1
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir4
0
3
0 2 3 1
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat3 dir2 dir5
0
3
0 2 4 1
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir1
0
3
0 2 0 2
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir2
0
3
0 2 1 2
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
turn_to sat3 dir3 dir4
0
3
0 2 3 2
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
turn_to sat3 dir3 dir5
0
3
0 2 4 2
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat3 dir4 dir1
0
3
0 2 0 3
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir2
0
3
0 2 1 3
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir3
0
3
0 2 2 3
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
turn_to sat3 dir4 dir5
0
3
0 2 4 3
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
turn_to sat3 dir5 dir1
0
3
0 2 0 4
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir2
0
3
0 2 1 4
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir3
0
3
0 2 2 4
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat3 dir5 dir4
0
3
0 2 3 4
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
turn_to sat4 dir1 dir2
0
3
0 3 1 0
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir3
0
3
0 3 2 0
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir4
0
3
0 3 3 0
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat4 dir1 dir5
0
3
0 3 4 0
0 19 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir1
0
3
0 3 0 1
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
turn_to sat4 dir2 dir3
0
3
0 3 2 1
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir4
0
3
0 3 3 1
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat4 dir2 dir5
0
3
0 3 4 1
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir1
0
3
0 3 0 2
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir2
0
3
0 3 1 2
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
turn_to sat4 dir3 dir4
0
3
0 3 3 2
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
turn_to sat4 dir3 dir5
0
3
0 3 4 2
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat4 dir4 dir1
0
3
0 3 0 3
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir2
0
3
0 3 1 3
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir3
0
3
0 3 2 3
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
turn_to sat4 dir4 dir5
0
3
0 3 4 3
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
turn_to sat4 dir5 dir1
0
3
0 3 0 4
0 19 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir2
0
3
0 3 1 4
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir3
0
3
0 3 2 4
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
turn_to sat4 dir5 dir4
0
3
0 3 3 4
0 22 -1 0
0 23 0 1
1
end_operator
0
