begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
2
NOT-pointing sat1 dir1
NOT-pointing sat1 dir2
end_variable
begin_variable
var1
-1
2
pointing sat1 dir1
pointing sat1 dir2
end_variable
begin_variable
var2
-1
2
power_avail sat1
power_on ins1
end_variable
begin_variable
var3
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var4
-1
2
calibration_target ins1 dir2
none-of-those
end_variable
begin_variable
var5
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var6
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var7
-1
2
on_board ins1 sat1
none-of-those
end_variable
begin_variable
var8
-1
2
supports ins1 mod1
none-of-those
end_variable
0
begin_state
1
0
0
1
0
1
1
0
0
end_state
begin_goal
1
5 0
end_goal
7
begin_operator
calibrate sat1 ins1 dir2
4
1 1
2 1
4 0
7 0
1
0 3 -1 0
1
end_operator
begin_operator
switch_off ins1 sat1
1
7 0
1
0 2 1 0
1
end_operator
begin_operator
switch_on ins1 sat1
1
7 0
2
0 2 0 1
0 3 -1 1
1
end_operator
begin_operator
take_image sat1 dir1 ins1 mod1
5
1 0
2 1
3 0
7 0
8 0
1
0 5 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins1 mod1
5
1 1
2 1
3 0
7 0
8 0
1
0 6 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
2
0 0 0 1
0 1 1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
2
0 0 1 0
0 1 0 1
1
end_operator
0
