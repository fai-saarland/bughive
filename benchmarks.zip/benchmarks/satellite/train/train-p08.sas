begin_version
3
end_version
begin_metric
1
end_metric
26
begin_variable
var0
-1
3
pointing sat1 dir1
pointing sat1 dir2
pointing sat1 dir3
end_variable
begin_variable
var1
-1
3
pointing sat2 dir1
pointing sat2 dir2
pointing sat2 dir3
end_variable
begin_variable
var2
-1
2
NOT-pointing sat1 dir1
none-of-those
end_variable
begin_variable
var3
-1
2
NOT-pointing sat1 dir2
none-of-those
end_variable
begin_variable
var4
-1
2
NOT-pointing sat1 dir3
none-of-those
end_variable
begin_variable
var5
-1
2
NOT-pointing sat2 dir1
none-of-those
end_variable
begin_variable
var6
-1
2
NOT-pointing sat2 dir2
none-of-those
end_variable
begin_variable
var7
-1
2
NOT-pointing sat2 dir3
none-of-those
end_variable
begin_variable
var8
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var9
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var10
-1
2
calibration_target ins1 dir1
none-of-those
end_variable
begin_variable
var11
-1
2
calibration_target ins2 dir2
none-of-those
end_variable
begin_variable
var12
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var13
-1
2
have_image dir1 mod2
none-of-those
end_variable
begin_variable
var14
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var15
-1
2
have_image dir2 mod2
none-of-those
end_variable
begin_variable
var16
-1
2
have_image dir3 mod1
none-of-those
end_variable
begin_variable
var17
-1
2
have_image dir3 mod2
none-of-those
end_variable
begin_variable
var18
-1
2
on_board ins1 sat1
none-of-those
end_variable
begin_variable
var19
-1
2
on_board ins2 sat2
none-of-those
end_variable
begin_variable
var20
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var21
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var22
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var23
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var24
-1
2
supports ins1 mod2
none-of-those
end_variable
begin_variable
var25
-1
2
supports ins2 mod1
none-of-those
end_variable
0
begin_state
2
0
0
0
1
1
0
0
1
1
0
0
1
1
1
1
1
1
0
0
0
0
1
1
0
0
end_state
begin_goal
4
12 0
15 0
16 0
17 0
end_goal
24
begin_operator
calibrate sat1 ins1 dir1
4
0 0
10 0
18 0
22 0
1
0 8 -1 0
1
end_operator
begin_operator
calibrate sat2 ins2 dir2
4
1 1
11 0
19 0
23 0
1
0 9 -1 0
1
end_operator
begin_operator
switch_off ins1 sat1
1
18 0
2
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
switch_off ins2 sat2
1
19 0
2
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
switch_on ins1 sat1
1
18 0
3
0 8 -1 1
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
switch_on ins2 sat2
1
19 0
3
0 9 -1 1
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins1 mod2
5
0 0
8 0
18 0
22 0
24 0
1
0 13 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins1 mod2
5
0 1
8 0
18 0
22 0
24 0
1
0 15 -1 0
1
end_operator
begin_operator
take_image sat1 dir3 ins1 mod2
5
0 2
8 0
18 0
22 0
24 0
1
0 17 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins2 mod1
5
1 0
9 0
19 0
23 0
25 0
1
0 12 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins2 mod1
5
1 1
9 0
19 0
23 0
25 0
1
0 14 -1 0
1
end_operator
begin_operator
take_image sat2 dir3 ins2 mod1
5
1 2
9 0
19 0
23 0
25 0
1
0 16 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
3
0 0 1 0
0 2 0 1
0 3 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir3
0
3
0 0 2 0
0 2 0 1
0 4 -1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
3
0 0 0 1
0 2 -1 0
0 3 0 1
1
end_operator
begin_operator
turn_to sat1 dir2 dir3
0
3
0 0 2 1
0 3 0 1
0 4 -1 0
1
end_operator
begin_operator
turn_to sat1 dir3 dir1
0
3
0 0 0 2
0 2 -1 0
0 4 0 1
1
end_operator
begin_operator
turn_to sat1 dir3 dir2
0
3
0 0 1 2
0 3 -1 0
0 4 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
3
0 1 1 0
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
turn_to sat2 dir1 dir3
0
3
0 1 2 0
0 5 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
3
0 1 0 1
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
turn_to sat2 dir2 dir3
0
3
0 1 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
turn_to sat2 dir3 dir1
0
3
0 1 0 2
0 5 -1 0
0 7 0 1
1
end_operator
begin_operator
turn_to sat2 dir3 dir2
0
3
0 1 1 2
0 6 -1 0
0 7 0 1
1
end_operator
0
