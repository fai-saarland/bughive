begin_version
3
end_version
begin_metric
1
end_metric
18
begin_variable
var0
-1
2
NOT-pointing sat1 dir1
NOT-pointing sat1 dir2
end_variable
begin_variable
var1
-1
2
NOT-pointing sat2 dir1
NOT-pointing sat2 dir2
end_variable
begin_variable
var2
-1
2
pointing sat1 dir1
pointing sat1 dir2
end_variable
begin_variable
var3
-1
2
pointing sat2 dir1
pointing sat2 dir2
end_variable
begin_variable
var4
-1
2
calibrated ins1
none-of-those
end_variable
begin_variable
var5
-1
2
calibrated ins2
none-of-those
end_variable
begin_variable
var6
-1
2
calibration_target ins1 dir2
none-of-those
end_variable
begin_variable
var7
-1
2
calibration_target ins2 dir1
none-of-those
end_variable
begin_variable
var8
-1
2
have_image dir1 mod1
none-of-those
end_variable
begin_variable
var9
-1
2
have_image dir2 mod1
none-of-those
end_variable
begin_variable
var10
-1
2
on_board ins1 sat2
none-of-those
end_variable
begin_variable
var11
-1
2
on_board ins2 sat1
none-of-those
end_variable
begin_variable
var12
-1
2
power_avail sat1
none-of-those
end_variable
begin_variable
var13
-1
2
power_avail sat2
none-of-those
end_variable
begin_variable
var14
-1
2
power_on ins1
none-of-those
end_variable
begin_variable
var15
-1
2
power_on ins2
none-of-those
end_variable
begin_variable
var16
-1
2
supports ins1 mod1
none-of-those
end_variable
begin_variable
var17
-1
2
supports ins2 mod1
none-of-those
end_variable
0
begin_state
1
1
0
0
1
1
0
0
1
1
0
0
0
0
1
1
0
0
end_state
begin_goal
2
2 0
9 0
end_goal
14
begin_operator
calibrate sat1 ins2 dir1
4
2 0
7 0
11 0
15 0
1
0 5 -1 0
1
end_operator
begin_operator
calibrate sat2 ins1 dir2
4
3 1
6 0
10 0
14 0
1
0 4 -1 0
1
end_operator
begin_operator
switch_off ins1 sat2
1
10 0
2
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
switch_off ins2 sat1
1
11 0
2
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
switch_on ins1 sat2
1
10 0
3
0 4 -1 1
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
switch_on ins2 sat1
1
11 0
3
0 5 -1 1
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
take_image sat1 dir1 ins2 mod1
5
2 0
5 0
11 0
15 0
17 0
1
0 8 -1 0
1
end_operator
begin_operator
take_image sat1 dir2 ins2 mod1
5
2 1
5 0
11 0
15 0
17 0
1
0 9 -1 0
1
end_operator
begin_operator
take_image sat2 dir1 ins1 mod1
5
3 0
4 0
10 0
14 0
16 0
1
0 8 -1 0
1
end_operator
begin_operator
take_image sat2 dir2 ins1 mod1
5
3 1
4 0
10 0
14 0
16 0
1
0 9 -1 0
1
end_operator
begin_operator
turn_to sat1 dir1 dir2
0
2
0 0 0 1
0 2 1 0
1
end_operator
begin_operator
turn_to sat1 dir2 dir1
0
2
0 0 1 0
0 2 0 1
1
end_operator
begin_operator
turn_to sat2 dir1 dir2
0
2
0 1 0 1
0 3 1 0
1
end_operator
begin_operator
turn_to sat2 dir2 dir1
0
2
0 1 1 0
0 3 0 1
1
end_operator
0
