begin_version
3
end_version
begin_metric
1
end_metric
10
begin_variable
var0
-1
3
boarded p1
origin p1 f2
served p1
end_variable
begin_variable
var1
-1
3
boarded p2
origin p2 f1
served p2
end_variable
begin_variable
var2
-1
3
boarded p3
origin p3 f2
served p3
end_variable
begin_variable
var3
-1
3
boarded p4
origin p4 f1
served p4
end_variable
begin_variable
var4
-1
2
lift-at f1
lift-at f2
end_variable
begin_variable
var5
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var6
-1
2
destin p1 f1
none-of-those
end_variable
begin_variable
var7
-1
2
destin p2 f2
none-of-those
end_variable
begin_variable
var8
-1
2
destin p3 f1
none-of-those
end_variable
begin_variable
var9
-1
2
destin p4 f2
none-of-those
end_variable
0
begin_state
1
1
1
1
0
0
0
0
0
0
end_state
begin_goal
4
0 2
1 2
2 2
3 2
end_goal
10
begin_operator
board f1 p2
1
4 0
1
0 1 1 0
1
end_operator
begin_operator
board f1 p4
1
4 0
1
0 3 1 0
1
end_operator
begin_operator
board f2 p1
1
4 1
1
0 0 1 0
1
end_operator
begin_operator
board f2 p3
1
4 1
1
0 2 1 0
1
end_operator
begin_operator
depart f1 p1
2
4 0
6 0
1
0 0 0 2
1
end_operator
begin_operator
depart f1 p3
2
4 0
8 0
1
0 2 0 2
1
end_operator
begin_operator
depart f2 p2
2
4 1
7 0
1
0 1 0 2
1
end_operator
begin_operator
depart f2 p4
2
4 1
9 0
1
0 3 0 2
1
end_operator
begin_operator
down f2 f1
1
5 0
1
0 4 1 0
1
end_operator
begin_operator
up f1 f2
1
5 0
1
0 4 0 1
1
end_operator
0
