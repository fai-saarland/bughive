begin_version
3
end_version
begin_metric
1
end_metric
4
begin_variable
var0
-1
3
boarded p1
origin p1 f1
served p1
end_variable
begin_variable
var1
-1
2
lift-at f1
lift-at f2
end_variable
begin_variable
var2
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var3
-1
2
destin p1 f2
none-of-those
end_variable
0
begin_state
1
1
0
0
end_state
begin_goal
1
0 2
end_goal
4
begin_operator
board f1 p1
1
1 0
1
0 0 1 0
1
end_operator
begin_operator
depart f2 p1
2
1 1
3 0
1
0 0 0 2
1
end_operator
begin_operator
down f2 f1
1
2 0
1
0 1 1 0
1
end_operator
begin_operator
up f1 f2
1
2 0
1
0 1 0 1
1
end_operator
0
