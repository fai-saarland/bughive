begin_version
3
end_version
begin_metric
1
end_metric
60
begin_variable
var0
-1
32
empty-ferry
on car1
on car10
on car11
on car12
on car13
on car14
on car15
on car16
on car17
on car18
on car19
on car2
on car20
on car21
on car22
on car23
on car24
on car25
on car26
on car27
on car28
on car29
on car3
on car30
on car31
on car4
on car5
on car6
on car7
on car8
on car9
end_variable
begin_variable
var1
-1
28
at car26 loc1
at car26 loc10
at car26 loc11
at car26 loc12
at car26 loc13
at car26 loc14
at car26 loc15
at car26 loc16
at car26 loc17
at car26 loc18
at car26 loc19
at car26 loc2
at car26 loc20
at car26 loc21
at car26 loc22
at car26 loc23
at car26 loc24
at car26 loc25
at car26 loc26
at car26 loc27
at car26 loc3
at car26 loc4
at car26 loc5
at car26 loc6
at car26 loc7
at car26 loc8
at car26 loc9
none-of-those
end_variable
begin_variable
var2
-1
28
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc24
at car18 loc25
at car18 loc26
at car18 loc27
at car18 loc3
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
none-of-those
end_variable
begin_variable
var3
-1
28
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc24
at car7 loc25
at car7 loc26
at car7 loc27
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var4
-1
28
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc24
at car1 loc25
at car1 loc26
at car1 loc27
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var5
-1
28
at car27 loc1
at car27 loc10
at car27 loc11
at car27 loc12
at car27 loc13
at car27 loc14
at car27 loc15
at car27 loc16
at car27 loc17
at car27 loc18
at car27 loc19
at car27 loc2
at car27 loc20
at car27 loc21
at car27 loc22
at car27 loc23
at car27 loc24
at car27 loc25
at car27 loc26
at car27 loc27
at car27 loc3
at car27 loc4
at car27 loc5
at car27 loc6
at car27 loc7
at car27 loc8
at car27 loc9
none-of-those
end_variable
begin_variable
var6
-1
28
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc24
at car19 loc25
at car19 loc26
at car19 loc27
at car19 loc3
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
none-of-those
end_variable
begin_variable
var7
-1
28
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc24
at car8 loc25
at car8 loc26
at car8 loc27
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var8
-1
28
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc24
at car10 loc25
at car10 loc26
at car10 loc27
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var9
-1
28
at car28 loc1
at car28 loc10
at car28 loc11
at car28 loc12
at car28 loc13
at car28 loc14
at car28 loc15
at car28 loc16
at car28 loc17
at car28 loc18
at car28 loc19
at car28 loc2
at car28 loc20
at car28 loc21
at car28 loc22
at car28 loc23
at car28 loc24
at car28 loc25
at car28 loc26
at car28 loc27
at car28 loc3
at car28 loc4
at car28 loc5
at car28 loc6
at car28 loc7
at car28 loc8
at car28 loc9
none-of-those
end_variable
begin_variable
var10
-1
28
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc24
at car2 loc25
at car2 loc26
at car2 loc27
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var11
-1
28
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc24
at car9 loc25
at car9 loc26
at car9 loc27
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var12
-1
28
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc24
at car11 loc25
at car11 loc26
at car11 loc27
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var13
-1
28
at car29 loc1
at car29 loc10
at car29 loc11
at car29 loc12
at car29 loc13
at car29 loc14
at car29 loc15
at car29 loc16
at car29 loc17
at car29 loc18
at car29 loc19
at car29 loc2
at car29 loc20
at car29 loc21
at car29 loc22
at car29 loc23
at car29 loc24
at car29 loc25
at car29 loc26
at car29 loc27
at car29 loc3
at car29 loc4
at car29 loc5
at car29 loc6
at car29 loc7
at car29 loc8
at car29 loc9
none-of-those
end_variable
begin_variable
var14
-1
28
at car20 loc1
at car20 loc10
at car20 loc11
at car20 loc12
at car20 loc13
at car20 loc14
at car20 loc15
at car20 loc16
at car20 loc17
at car20 loc18
at car20 loc19
at car20 loc2
at car20 loc20
at car20 loc21
at car20 loc22
at car20 loc23
at car20 loc24
at car20 loc25
at car20 loc26
at car20 loc27
at car20 loc3
at car20 loc4
at car20 loc5
at car20 loc6
at car20 loc7
at car20 loc8
at car20 loc9
none-of-those
end_variable
begin_variable
var15
-1
27
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc24
at-ferry loc25
at-ferry loc26
at-ferry loc27
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var16
-1
28
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc24
at car12 loc25
at car12 loc26
at car12 loc27
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
none-of-those
end_variable
begin_variable
var17
-1
28
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc24
at car3 loc25
at car3 loc26
at car3 loc27
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var18
-1
28
at car21 loc1
at car21 loc10
at car21 loc11
at car21 loc12
at car21 loc13
at car21 loc14
at car21 loc15
at car21 loc16
at car21 loc17
at car21 loc18
at car21 loc19
at car21 loc2
at car21 loc20
at car21 loc21
at car21 loc22
at car21 loc23
at car21 loc24
at car21 loc25
at car21 loc26
at car21 loc27
at car21 loc3
at car21 loc4
at car21 loc5
at car21 loc6
at car21 loc7
at car21 loc8
at car21 loc9
none-of-those
end_variable
begin_variable
var19
-1
28
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc24
at car13 loc25
at car13 loc26
at car13 loc27
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
none-of-those
end_variable
begin_variable
var20
-1
28
at car30 loc1
at car30 loc10
at car30 loc11
at car30 loc12
at car30 loc13
at car30 loc14
at car30 loc15
at car30 loc16
at car30 loc17
at car30 loc18
at car30 loc19
at car30 loc2
at car30 loc20
at car30 loc21
at car30 loc22
at car30 loc23
at car30 loc24
at car30 loc25
at car30 loc26
at car30 loc27
at car30 loc3
at car30 loc4
at car30 loc5
at car30 loc6
at car30 loc7
at car30 loc8
at car30 loc9
none-of-those
end_variable
begin_variable
var21
-1
28
at car22 loc1
at car22 loc10
at car22 loc11
at car22 loc12
at car22 loc13
at car22 loc14
at car22 loc15
at car22 loc16
at car22 loc17
at car22 loc18
at car22 loc19
at car22 loc2
at car22 loc20
at car22 loc21
at car22 loc22
at car22 loc23
at car22 loc24
at car22 loc25
at car22 loc26
at car22 loc27
at car22 loc3
at car22 loc4
at car22 loc5
at car22 loc6
at car22 loc7
at car22 loc8
at car22 loc9
none-of-those
end_variable
begin_variable
var22
-1
28
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc24
at car14 loc25
at car14 loc26
at car14 loc27
at car14 loc3
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
none-of-those
end_variable
begin_variable
var23
-1
28
at car31 loc1
at car31 loc10
at car31 loc11
at car31 loc12
at car31 loc13
at car31 loc14
at car31 loc15
at car31 loc16
at car31 loc17
at car31 loc18
at car31 loc19
at car31 loc2
at car31 loc20
at car31 loc21
at car31 loc22
at car31 loc23
at car31 loc24
at car31 loc25
at car31 loc26
at car31 loc27
at car31 loc3
at car31 loc4
at car31 loc5
at car31 loc6
at car31 loc7
at car31 loc8
at car31 loc9
none-of-those
end_variable
begin_variable
var24
-1
28
at car23 loc1
at car23 loc10
at car23 loc11
at car23 loc12
at car23 loc13
at car23 loc14
at car23 loc15
at car23 loc16
at car23 loc17
at car23 loc18
at car23 loc19
at car23 loc2
at car23 loc20
at car23 loc21
at car23 loc22
at car23 loc23
at car23 loc24
at car23 loc25
at car23 loc26
at car23 loc27
at car23 loc3
at car23 loc4
at car23 loc5
at car23 loc6
at car23 loc7
at car23 loc8
at car23 loc9
none-of-those
end_variable
begin_variable
var25
-1
28
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc24
at car15 loc25
at car15 loc26
at car15 loc27
at car15 loc3
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
none-of-those
end_variable
begin_variable
var26
-1
28
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc24
at car4 loc25
at car4 loc26
at car4 loc27
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var27
-1
28
at car24 loc1
at car24 loc10
at car24 loc11
at car24 loc12
at car24 loc13
at car24 loc14
at car24 loc15
at car24 loc16
at car24 loc17
at car24 loc18
at car24 loc19
at car24 loc2
at car24 loc20
at car24 loc21
at car24 loc22
at car24 loc23
at car24 loc24
at car24 loc25
at car24 loc26
at car24 loc27
at car24 loc3
at car24 loc4
at car24 loc5
at car24 loc6
at car24 loc7
at car24 loc8
at car24 loc9
none-of-those
end_variable
begin_variable
var28
-1
28
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc24
at car16 loc25
at car16 loc26
at car16 loc27
at car16 loc3
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
none-of-those
end_variable
begin_variable
var29
-1
28
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc24
at car5 loc25
at car5 loc26
at car5 loc27
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var30
-1
28
at car25 loc1
at car25 loc10
at car25 loc11
at car25 loc12
at car25 loc13
at car25 loc14
at car25 loc15
at car25 loc16
at car25 loc17
at car25 loc18
at car25 loc19
at car25 loc2
at car25 loc20
at car25 loc21
at car25 loc22
at car25 loc23
at car25 loc24
at car25 loc25
at car25 loc26
at car25 loc27
at car25 loc3
at car25 loc4
at car25 loc5
at car25 loc6
at car25 loc7
at car25 loc8
at car25 loc9
none-of-those
end_variable
begin_variable
var31
-1
28
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc24
at car17 loc25
at car17 loc26
at car17 loc27
at car17 loc3
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
none-of-those
end_variable
begin_variable
var32
-1
28
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc24
at car6 loc25
at car6 loc26
at car6 loc27
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var47
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var48
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var49
-1
2
NOT-at-ferry loc24
none-of-those
end_variable
begin_variable
var50
-1
2
NOT-at-ferry loc25
none-of-those
end_variable
begin_variable
var51
-1
2
NOT-at-ferry loc26
none-of-those
end_variable
begin_variable
var52
-1
2
NOT-at-ferry loc27
none-of-those
end_variable
begin_variable
var53
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var54
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var55
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var56
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var57
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var58
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var59
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
22
10
14
0
25
7
12
23
8
25
12
6
22
21
8
8
26
0
7
3
24
26
9
17
18
11
10
15
5
16
5
5
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
31
1 7
2 11
3 25
4 3
5 17
6 2
7 11
8 1
9 21
10 9
11 18
12 7
13 18
14 19
16 14
17 18
18 10
19 8
20 24
21 12
22 4
23 10
24 23
25 8
26 10
27 12
28 5
29 25
30 25
31 20
32 23
end_goal
2376
begin_operator
board car1 loc1
1
15 0
2
0 0 0 1
0 4 0 27
1
end_operator
begin_operator
board car1 loc10
1
15 1
2
0 0 0 1
0 4 1 27
1
end_operator
begin_operator
board car1 loc11
1
15 2
2
0 0 0 1
0 4 2 27
1
end_operator
begin_operator
board car1 loc12
1
15 3
2
0 0 0 1
0 4 3 27
1
end_operator
begin_operator
board car1 loc13
1
15 4
2
0 0 0 1
0 4 4 27
1
end_operator
begin_operator
board car1 loc14
1
15 5
2
0 0 0 1
0 4 5 27
1
end_operator
begin_operator
board car1 loc15
1
15 6
2
0 0 0 1
0 4 6 27
1
end_operator
begin_operator
board car1 loc16
1
15 7
2
0 0 0 1
0 4 7 27
1
end_operator
begin_operator
board car1 loc17
1
15 8
2
0 0 0 1
0 4 8 27
1
end_operator
begin_operator
board car1 loc18
1
15 9
2
0 0 0 1
0 4 9 27
1
end_operator
begin_operator
board car1 loc19
1
15 10
2
0 0 0 1
0 4 10 27
1
end_operator
begin_operator
board car1 loc2
1
15 11
2
0 0 0 1
0 4 11 27
1
end_operator
begin_operator
board car1 loc20
1
15 12
2
0 0 0 1
0 4 12 27
1
end_operator
begin_operator
board car1 loc21
1
15 13
2
0 0 0 1
0 4 13 27
1
end_operator
begin_operator
board car1 loc22
1
15 14
2
0 0 0 1
0 4 14 27
1
end_operator
begin_operator
board car1 loc23
1
15 15
2
0 0 0 1
0 4 15 27
1
end_operator
begin_operator
board car1 loc24
1
15 16
2
0 0 0 1
0 4 16 27
1
end_operator
begin_operator
board car1 loc25
1
15 17
2
0 0 0 1
0 4 17 27
1
end_operator
begin_operator
board car1 loc26
1
15 18
2
0 0 0 1
0 4 18 27
1
end_operator
begin_operator
board car1 loc27
1
15 19
2
0 0 0 1
0 4 19 27
1
end_operator
begin_operator
board car1 loc3
1
15 20
2
0 0 0 1
0 4 20 27
1
end_operator
begin_operator
board car1 loc4
1
15 21
2
0 0 0 1
0 4 21 27
1
end_operator
begin_operator
board car1 loc5
1
15 22
2
0 0 0 1
0 4 22 27
1
end_operator
begin_operator
board car1 loc6
1
15 23
2
0 0 0 1
0 4 23 27
1
end_operator
begin_operator
board car1 loc7
1
15 24
2
0 0 0 1
0 4 24 27
1
end_operator
begin_operator
board car1 loc8
1
15 25
2
0 0 0 1
0 4 25 27
1
end_operator
begin_operator
board car1 loc9
1
15 26
2
0 0 0 1
0 4 26 27
1
end_operator
begin_operator
board car10 loc1
1
15 0
2
0 0 0 2
0 8 0 27
1
end_operator
begin_operator
board car10 loc10
1
15 1
2
0 0 0 2
0 8 1 27
1
end_operator
begin_operator
board car10 loc11
1
15 2
2
0 0 0 2
0 8 2 27
1
end_operator
begin_operator
board car10 loc12
1
15 3
2
0 0 0 2
0 8 3 27
1
end_operator
begin_operator
board car10 loc13
1
15 4
2
0 0 0 2
0 8 4 27
1
end_operator
begin_operator
board car10 loc14
1
15 5
2
0 0 0 2
0 8 5 27
1
end_operator
begin_operator
board car10 loc15
1
15 6
2
0 0 0 2
0 8 6 27
1
end_operator
begin_operator
board car10 loc16
1
15 7
2
0 0 0 2
0 8 7 27
1
end_operator
begin_operator
board car10 loc17
1
15 8
2
0 0 0 2
0 8 8 27
1
end_operator
begin_operator
board car10 loc18
1
15 9
2
0 0 0 2
0 8 9 27
1
end_operator
begin_operator
board car10 loc19
1
15 10
2
0 0 0 2
0 8 10 27
1
end_operator
begin_operator
board car10 loc2
1
15 11
2
0 0 0 2
0 8 11 27
1
end_operator
begin_operator
board car10 loc20
1
15 12
2
0 0 0 2
0 8 12 27
1
end_operator
begin_operator
board car10 loc21
1
15 13
2
0 0 0 2
0 8 13 27
1
end_operator
begin_operator
board car10 loc22
1
15 14
2
0 0 0 2
0 8 14 27
1
end_operator
begin_operator
board car10 loc23
1
15 15
2
0 0 0 2
0 8 15 27
1
end_operator
begin_operator
board car10 loc24
1
15 16
2
0 0 0 2
0 8 16 27
1
end_operator
begin_operator
board car10 loc25
1
15 17
2
0 0 0 2
0 8 17 27
1
end_operator
begin_operator
board car10 loc26
1
15 18
2
0 0 0 2
0 8 18 27
1
end_operator
begin_operator
board car10 loc27
1
15 19
2
0 0 0 2
0 8 19 27
1
end_operator
begin_operator
board car10 loc3
1
15 20
2
0 0 0 2
0 8 20 27
1
end_operator
begin_operator
board car10 loc4
1
15 21
2
0 0 0 2
0 8 21 27
1
end_operator
begin_operator
board car10 loc5
1
15 22
2
0 0 0 2
0 8 22 27
1
end_operator
begin_operator
board car10 loc6
1
15 23
2
0 0 0 2
0 8 23 27
1
end_operator
begin_operator
board car10 loc7
1
15 24
2
0 0 0 2
0 8 24 27
1
end_operator
begin_operator
board car10 loc8
1
15 25
2
0 0 0 2
0 8 25 27
1
end_operator
begin_operator
board car10 loc9
1
15 26
2
0 0 0 2
0 8 26 27
1
end_operator
begin_operator
board car11 loc1
1
15 0
2
0 0 0 3
0 12 0 27
1
end_operator
begin_operator
board car11 loc10
1
15 1
2
0 0 0 3
0 12 1 27
1
end_operator
begin_operator
board car11 loc11
1
15 2
2
0 0 0 3
0 12 2 27
1
end_operator
begin_operator
board car11 loc12
1
15 3
2
0 0 0 3
0 12 3 27
1
end_operator
begin_operator
board car11 loc13
1
15 4
2
0 0 0 3
0 12 4 27
1
end_operator
begin_operator
board car11 loc14
1
15 5
2
0 0 0 3
0 12 5 27
1
end_operator
begin_operator
board car11 loc15
1
15 6
2
0 0 0 3
0 12 6 27
1
end_operator
begin_operator
board car11 loc16
1
15 7
2
0 0 0 3
0 12 7 27
1
end_operator
begin_operator
board car11 loc17
1
15 8
2
0 0 0 3
0 12 8 27
1
end_operator
begin_operator
board car11 loc18
1
15 9
2
0 0 0 3
0 12 9 27
1
end_operator
begin_operator
board car11 loc19
1
15 10
2
0 0 0 3
0 12 10 27
1
end_operator
begin_operator
board car11 loc2
1
15 11
2
0 0 0 3
0 12 11 27
1
end_operator
begin_operator
board car11 loc20
1
15 12
2
0 0 0 3
0 12 12 27
1
end_operator
begin_operator
board car11 loc21
1
15 13
2
0 0 0 3
0 12 13 27
1
end_operator
begin_operator
board car11 loc22
1
15 14
2
0 0 0 3
0 12 14 27
1
end_operator
begin_operator
board car11 loc23
1
15 15
2
0 0 0 3
0 12 15 27
1
end_operator
begin_operator
board car11 loc24
1
15 16
2
0 0 0 3
0 12 16 27
1
end_operator
begin_operator
board car11 loc25
1
15 17
2
0 0 0 3
0 12 17 27
1
end_operator
begin_operator
board car11 loc26
1
15 18
2
0 0 0 3
0 12 18 27
1
end_operator
begin_operator
board car11 loc27
1
15 19
2
0 0 0 3
0 12 19 27
1
end_operator
begin_operator
board car11 loc3
1
15 20
2
0 0 0 3
0 12 20 27
1
end_operator
begin_operator
board car11 loc4
1
15 21
2
0 0 0 3
0 12 21 27
1
end_operator
begin_operator
board car11 loc5
1
15 22
2
0 0 0 3
0 12 22 27
1
end_operator
begin_operator
board car11 loc6
1
15 23
2
0 0 0 3
0 12 23 27
1
end_operator
begin_operator
board car11 loc7
1
15 24
2
0 0 0 3
0 12 24 27
1
end_operator
begin_operator
board car11 loc8
1
15 25
2
0 0 0 3
0 12 25 27
1
end_operator
begin_operator
board car11 loc9
1
15 26
2
0 0 0 3
0 12 26 27
1
end_operator
begin_operator
board car12 loc1
1
15 0
2
0 0 0 4
0 16 0 27
1
end_operator
begin_operator
board car12 loc10
1
15 1
2
0 0 0 4
0 16 1 27
1
end_operator
begin_operator
board car12 loc11
1
15 2
2
0 0 0 4
0 16 2 27
1
end_operator
begin_operator
board car12 loc12
1
15 3
2
0 0 0 4
0 16 3 27
1
end_operator
begin_operator
board car12 loc13
1
15 4
2
0 0 0 4
0 16 4 27
1
end_operator
begin_operator
board car12 loc14
1
15 5
2
0 0 0 4
0 16 5 27
1
end_operator
begin_operator
board car12 loc15
1
15 6
2
0 0 0 4
0 16 6 27
1
end_operator
begin_operator
board car12 loc16
1
15 7
2
0 0 0 4
0 16 7 27
1
end_operator
begin_operator
board car12 loc17
1
15 8
2
0 0 0 4
0 16 8 27
1
end_operator
begin_operator
board car12 loc18
1
15 9
2
0 0 0 4
0 16 9 27
1
end_operator
begin_operator
board car12 loc19
1
15 10
2
0 0 0 4
0 16 10 27
1
end_operator
begin_operator
board car12 loc2
1
15 11
2
0 0 0 4
0 16 11 27
1
end_operator
begin_operator
board car12 loc20
1
15 12
2
0 0 0 4
0 16 12 27
1
end_operator
begin_operator
board car12 loc21
1
15 13
2
0 0 0 4
0 16 13 27
1
end_operator
begin_operator
board car12 loc22
1
15 14
2
0 0 0 4
0 16 14 27
1
end_operator
begin_operator
board car12 loc23
1
15 15
2
0 0 0 4
0 16 15 27
1
end_operator
begin_operator
board car12 loc24
1
15 16
2
0 0 0 4
0 16 16 27
1
end_operator
begin_operator
board car12 loc25
1
15 17
2
0 0 0 4
0 16 17 27
1
end_operator
begin_operator
board car12 loc26
1
15 18
2
0 0 0 4
0 16 18 27
1
end_operator
begin_operator
board car12 loc27
1
15 19
2
0 0 0 4
0 16 19 27
1
end_operator
begin_operator
board car12 loc3
1
15 20
2
0 0 0 4
0 16 20 27
1
end_operator
begin_operator
board car12 loc4
1
15 21
2
0 0 0 4
0 16 21 27
1
end_operator
begin_operator
board car12 loc5
1
15 22
2
0 0 0 4
0 16 22 27
1
end_operator
begin_operator
board car12 loc6
1
15 23
2
0 0 0 4
0 16 23 27
1
end_operator
begin_operator
board car12 loc7
1
15 24
2
0 0 0 4
0 16 24 27
1
end_operator
begin_operator
board car12 loc8
1
15 25
2
0 0 0 4
0 16 25 27
1
end_operator
begin_operator
board car12 loc9
1
15 26
2
0 0 0 4
0 16 26 27
1
end_operator
begin_operator
board car13 loc1
1
15 0
2
0 0 0 5
0 19 0 27
1
end_operator
begin_operator
board car13 loc10
1
15 1
2
0 0 0 5
0 19 1 27
1
end_operator
begin_operator
board car13 loc11
1
15 2
2
0 0 0 5
0 19 2 27
1
end_operator
begin_operator
board car13 loc12
1
15 3
2
0 0 0 5
0 19 3 27
1
end_operator
begin_operator
board car13 loc13
1
15 4
2
0 0 0 5
0 19 4 27
1
end_operator
begin_operator
board car13 loc14
1
15 5
2
0 0 0 5
0 19 5 27
1
end_operator
begin_operator
board car13 loc15
1
15 6
2
0 0 0 5
0 19 6 27
1
end_operator
begin_operator
board car13 loc16
1
15 7
2
0 0 0 5
0 19 7 27
1
end_operator
begin_operator
board car13 loc17
1
15 8
2
0 0 0 5
0 19 8 27
1
end_operator
begin_operator
board car13 loc18
1
15 9
2
0 0 0 5
0 19 9 27
1
end_operator
begin_operator
board car13 loc19
1
15 10
2
0 0 0 5
0 19 10 27
1
end_operator
begin_operator
board car13 loc2
1
15 11
2
0 0 0 5
0 19 11 27
1
end_operator
begin_operator
board car13 loc20
1
15 12
2
0 0 0 5
0 19 12 27
1
end_operator
begin_operator
board car13 loc21
1
15 13
2
0 0 0 5
0 19 13 27
1
end_operator
begin_operator
board car13 loc22
1
15 14
2
0 0 0 5
0 19 14 27
1
end_operator
begin_operator
board car13 loc23
1
15 15
2
0 0 0 5
0 19 15 27
1
end_operator
begin_operator
board car13 loc24
1
15 16
2
0 0 0 5
0 19 16 27
1
end_operator
begin_operator
board car13 loc25
1
15 17
2
0 0 0 5
0 19 17 27
1
end_operator
begin_operator
board car13 loc26
1
15 18
2
0 0 0 5
0 19 18 27
1
end_operator
begin_operator
board car13 loc27
1
15 19
2
0 0 0 5
0 19 19 27
1
end_operator
begin_operator
board car13 loc3
1
15 20
2
0 0 0 5
0 19 20 27
1
end_operator
begin_operator
board car13 loc4
1
15 21
2
0 0 0 5
0 19 21 27
1
end_operator
begin_operator
board car13 loc5
1
15 22
2
0 0 0 5
0 19 22 27
1
end_operator
begin_operator
board car13 loc6
1
15 23
2
0 0 0 5
0 19 23 27
1
end_operator
begin_operator
board car13 loc7
1
15 24
2
0 0 0 5
0 19 24 27
1
end_operator
begin_operator
board car13 loc8
1
15 25
2
0 0 0 5
0 19 25 27
1
end_operator
begin_operator
board car13 loc9
1
15 26
2
0 0 0 5
0 19 26 27
1
end_operator
begin_operator
board car14 loc1
1
15 0
2
0 0 0 6
0 22 0 27
1
end_operator
begin_operator
board car14 loc10
1
15 1
2
0 0 0 6
0 22 1 27
1
end_operator
begin_operator
board car14 loc11
1
15 2
2
0 0 0 6
0 22 2 27
1
end_operator
begin_operator
board car14 loc12
1
15 3
2
0 0 0 6
0 22 3 27
1
end_operator
begin_operator
board car14 loc13
1
15 4
2
0 0 0 6
0 22 4 27
1
end_operator
begin_operator
board car14 loc14
1
15 5
2
0 0 0 6
0 22 5 27
1
end_operator
begin_operator
board car14 loc15
1
15 6
2
0 0 0 6
0 22 6 27
1
end_operator
begin_operator
board car14 loc16
1
15 7
2
0 0 0 6
0 22 7 27
1
end_operator
begin_operator
board car14 loc17
1
15 8
2
0 0 0 6
0 22 8 27
1
end_operator
begin_operator
board car14 loc18
1
15 9
2
0 0 0 6
0 22 9 27
1
end_operator
begin_operator
board car14 loc19
1
15 10
2
0 0 0 6
0 22 10 27
1
end_operator
begin_operator
board car14 loc2
1
15 11
2
0 0 0 6
0 22 11 27
1
end_operator
begin_operator
board car14 loc20
1
15 12
2
0 0 0 6
0 22 12 27
1
end_operator
begin_operator
board car14 loc21
1
15 13
2
0 0 0 6
0 22 13 27
1
end_operator
begin_operator
board car14 loc22
1
15 14
2
0 0 0 6
0 22 14 27
1
end_operator
begin_operator
board car14 loc23
1
15 15
2
0 0 0 6
0 22 15 27
1
end_operator
begin_operator
board car14 loc24
1
15 16
2
0 0 0 6
0 22 16 27
1
end_operator
begin_operator
board car14 loc25
1
15 17
2
0 0 0 6
0 22 17 27
1
end_operator
begin_operator
board car14 loc26
1
15 18
2
0 0 0 6
0 22 18 27
1
end_operator
begin_operator
board car14 loc27
1
15 19
2
0 0 0 6
0 22 19 27
1
end_operator
begin_operator
board car14 loc3
1
15 20
2
0 0 0 6
0 22 20 27
1
end_operator
begin_operator
board car14 loc4
1
15 21
2
0 0 0 6
0 22 21 27
1
end_operator
begin_operator
board car14 loc5
1
15 22
2
0 0 0 6
0 22 22 27
1
end_operator
begin_operator
board car14 loc6
1
15 23
2
0 0 0 6
0 22 23 27
1
end_operator
begin_operator
board car14 loc7
1
15 24
2
0 0 0 6
0 22 24 27
1
end_operator
begin_operator
board car14 loc8
1
15 25
2
0 0 0 6
0 22 25 27
1
end_operator
begin_operator
board car14 loc9
1
15 26
2
0 0 0 6
0 22 26 27
1
end_operator
begin_operator
board car15 loc1
1
15 0
2
0 0 0 7
0 25 0 27
1
end_operator
begin_operator
board car15 loc10
1
15 1
2
0 0 0 7
0 25 1 27
1
end_operator
begin_operator
board car15 loc11
1
15 2
2
0 0 0 7
0 25 2 27
1
end_operator
begin_operator
board car15 loc12
1
15 3
2
0 0 0 7
0 25 3 27
1
end_operator
begin_operator
board car15 loc13
1
15 4
2
0 0 0 7
0 25 4 27
1
end_operator
begin_operator
board car15 loc14
1
15 5
2
0 0 0 7
0 25 5 27
1
end_operator
begin_operator
board car15 loc15
1
15 6
2
0 0 0 7
0 25 6 27
1
end_operator
begin_operator
board car15 loc16
1
15 7
2
0 0 0 7
0 25 7 27
1
end_operator
begin_operator
board car15 loc17
1
15 8
2
0 0 0 7
0 25 8 27
1
end_operator
begin_operator
board car15 loc18
1
15 9
2
0 0 0 7
0 25 9 27
1
end_operator
begin_operator
board car15 loc19
1
15 10
2
0 0 0 7
0 25 10 27
1
end_operator
begin_operator
board car15 loc2
1
15 11
2
0 0 0 7
0 25 11 27
1
end_operator
begin_operator
board car15 loc20
1
15 12
2
0 0 0 7
0 25 12 27
1
end_operator
begin_operator
board car15 loc21
1
15 13
2
0 0 0 7
0 25 13 27
1
end_operator
begin_operator
board car15 loc22
1
15 14
2
0 0 0 7
0 25 14 27
1
end_operator
begin_operator
board car15 loc23
1
15 15
2
0 0 0 7
0 25 15 27
1
end_operator
begin_operator
board car15 loc24
1
15 16
2
0 0 0 7
0 25 16 27
1
end_operator
begin_operator
board car15 loc25
1
15 17
2
0 0 0 7
0 25 17 27
1
end_operator
begin_operator
board car15 loc26
1
15 18
2
0 0 0 7
0 25 18 27
1
end_operator
begin_operator
board car15 loc27
1
15 19
2
0 0 0 7
0 25 19 27
1
end_operator
begin_operator
board car15 loc3
1
15 20
2
0 0 0 7
0 25 20 27
1
end_operator
begin_operator
board car15 loc4
1
15 21
2
0 0 0 7
0 25 21 27
1
end_operator
begin_operator
board car15 loc5
1
15 22
2
0 0 0 7
0 25 22 27
1
end_operator
begin_operator
board car15 loc6
1
15 23
2
0 0 0 7
0 25 23 27
1
end_operator
begin_operator
board car15 loc7
1
15 24
2
0 0 0 7
0 25 24 27
1
end_operator
begin_operator
board car15 loc8
1
15 25
2
0 0 0 7
0 25 25 27
1
end_operator
begin_operator
board car15 loc9
1
15 26
2
0 0 0 7
0 25 26 27
1
end_operator
begin_operator
board car16 loc1
1
15 0
2
0 0 0 8
0 28 0 27
1
end_operator
begin_operator
board car16 loc10
1
15 1
2
0 0 0 8
0 28 1 27
1
end_operator
begin_operator
board car16 loc11
1
15 2
2
0 0 0 8
0 28 2 27
1
end_operator
begin_operator
board car16 loc12
1
15 3
2
0 0 0 8
0 28 3 27
1
end_operator
begin_operator
board car16 loc13
1
15 4
2
0 0 0 8
0 28 4 27
1
end_operator
begin_operator
board car16 loc14
1
15 5
2
0 0 0 8
0 28 5 27
1
end_operator
begin_operator
board car16 loc15
1
15 6
2
0 0 0 8
0 28 6 27
1
end_operator
begin_operator
board car16 loc16
1
15 7
2
0 0 0 8
0 28 7 27
1
end_operator
begin_operator
board car16 loc17
1
15 8
2
0 0 0 8
0 28 8 27
1
end_operator
begin_operator
board car16 loc18
1
15 9
2
0 0 0 8
0 28 9 27
1
end_operator
begin_operator
board car16 loc19
1
15 10
2
0 0 0 8
0 28 10 27
1
end_operator
begin_operator
board car16 loc2
1
15 11
2
0 0 0 8
0 28 11 27
1
end_operator
begin_operator
board car16 loc20
1
15 12
2
0 0 0 8
0 28 12 27
1
end_operator
begin_operator
board car16 loc21
1
15 13
2
0 0 0 8
0 28 13 27
1
end_operator
begin_operator
board car16 loc22
1
15 14
2
0 0 0 8
0 28 14 27
1
end_operator
begin_operator
board car16 loc23
1
15 15
2
0 0 0 8
0 28 15 27
1
end_operator
begin_operator
board car16 loc24
1
15 16
2
0 0 0 8
0 28 16 27
1
end_operator
begin_operator
board car16 loc25
1
15 17
2
0 0 0 8
0 28 17 27
1
end_operator
begin_operator
board car16 loc26
1
15 18
2
0 0 0 8
0 28 18 27
1
end_operator
begin_operator
board car16 loc27
1
15 19
2
0 0 0 8
0 28 19 27
1
end_operator
begin_operator
board car16 loc3
1
15 20
2
0 0 0 8
0 28 20 27
1
end_operator
begin_operator
board car16 loc4
1
15 21
2
0 0 0 8
0 28 21 27
1
end_operator
begin_operator
board car16 loc5
1
15 22
2
0 0 0 8
0 28 22 27
1
end_operator
begin_operator
board car16 loc6
1
15 23
2
0 0 0 8
0 28 23 27
1
end_operator
begin_operator
board car16 loc7
1
15 24
2
0 0 0 8
0 28 24 27
1
end_operator
begin_operator
board car16 loc8
1
15 25
2
0 0 0 8
0 28 25 27
1
end_operator
begin_operator
board car16 loc9
1
15 26
2
0 0 0 8
0 28 26 27
1
end_operator
begin_operator
board car17 loc1
1
15 0
2
0 0 0 9
0 31 0 27
1
end_operator
begin_operator
board car17 loc10
1
15 1
2
0 0 0 9
0 31 1 27
1
end_operator
begin_operator
board car17 loc11
1
15 2
2
0 0 0 9
0 31 2 27
1
end_operator
begin_operator
board car17 loc12
1
15 3
2
0 0 0 9
0 31 3 27
1
end_operator
begin_operator
board car17 loc13
1
15 4
2
0 0 0 9
0 31 4 27
1
end_operator
begin_operator
board car17 loc14
1
15 5
2
0 0 0 9
0 31 5 27
1
end_operator
begin_operator
board car17 loc15
1
15 6
2
0 0 0 9
0 31 6 27
1
end_operator
begin_operator
board car17 loc16
1
15 7
2
0 0 0 9
0 31 7 27
1
end_operator
begin_operator
board car17 loc17
1
15 8
2
0 0 0 9
0 31 8 27
1
end_operator
begin_operator
board car17 loc18
1
15 9
2
0 0 0 9
0 31 9 27
1
end_operator
begin_operator
board car17 loc19
1
15 10
2
0 0 0 9
0 31 10 27
1
end_operator
begin_operator
board car17 loc2
1
15 11
2
0 0 0 9
0 31 11 27
1
end_operator
begin_operator
board car17 loc20
1
15 12
2
0 0 0 9
0 31 12 27
1
end_operator
begin_operator
board car17 loc21
1
15 13
2
0 0 0 9
0 31 13 27
1
end_operator
begin_operator
board car17 loc22
1
15 14
2
0 0 0 9
0 31 14 27
1
end_operator
begin_operator
board car17 loc23
1
15 15
2
0 0 0 9
0 31 15 27
1
end_operator
begin_operator
board car17 loc24
1
15 16
2
0 0 0 9
0 31 16 27
1
end_operator
begin_operator
board car17 loc25
1
15 17
2
0 0 0 9
0 31 17 27
1
end_operator
begin_operator
board car17 loc26
1
15 18
2
0 0 0 9
0 31 18 27
1
end_operator
begin_operator
board car17 loc27
1
15 19
2
0 0 0 9
0 31 19 27
1
end_operator
begin_operator
board car17 loc3
1
15 20
2
0 0 0 9
0 31 20 27
1
end_operator
begin_operator
board car17 loc4
1
15 21
2
0 0 0 9
0 31 21 27
1
end_operator
begin_operator
board car17 loc5
1
15 22
2
0 0 0 9
0 31 22 27
1
end_operator
begin_operator
board car17 loc6
1
15 23
2
0 0 0 9
0 31 23 27
1
end_operator
begin_operator
board car17 loc7
1
15 24
2
0 0 0 9
0 31 24 27
1
end_operator
begin_operator
board car17 loc8
1
15 25
2
0 0 0 9
0 31 25 27
1
end_operator
begin_operator
board car17 loc9
1
15 26
2
0 0 0 9
0 31 26 27
1
end_operator
begin_operator
board car18 loc1
1
15 0
2
0 0 0 10
0 2 0 27
1
end_operator
begin_operator
board car18 loc10
1
15 1
2
0 0 0 10
0 2 1 27
1
end_operator
begin_operator
board car18 loc11
1
15 2
2
0 0 0 10
0 2 2 27
1
end_operator
begin_operator
board car18 loc12
1
15 3
2
0 0 0 10
0 2 3 27
1
end_operator
begin_operator
board car18 loc13
1
15 4
2
0 0 0 10
0 2 4 27
1
end_operator
begin_operator
board car18 loc14
1
15 5
2
0 0 0 10
0 2 5 27
1
end_operator
begin_operator
board car18 loc15
1
15 6
2
0 0 0 10
0 2 6 27
1
end_operator
begin_operator
board car18 loc16
1
15 7
2
0 0 0 10
0 2 7 27
1
end_operator
begin_operator
board car18 loc17
1
15 8
2
0 0 0 10
0 2 8 27
1
end_operator
begin_operator
board car18 loc18
1
15 9
2
0 0 0 10
0 2 9 27
1
end_operator
begin_operator
board car18 loc19
1
15 10
2
0 0 0 10
0 2 10 27
1
end_operator
begin_operator
board car18 loc2
1
15 11
2
0 0 0 10
0 2 11 27
1
end_operator
begin_operator
board car18 loc20
1
15 12
2
0 0 0 10
0 2 12 27
1
end_operator
begin_operator
board car18 loc21
1
15 13
2
0 0 0 10
0 2 13 27
1
end_operator
begin_operator
board car18 loc22
1
15 14
2
0 0 0 10
0 2 14 27
1
end_operator
begin_operator
board car18 loc23
1
15 15
2
0 0 0 10
0 2 15 27
1
end_operator
begin_operator
board car18 loc24
1
15 16
2
0 0 0 10
0 2 16 27
1
end_operator
begin_operator
board car18 loc25
1
15 17
2
0 0 0 10
0 2 17 27
1
end_operator
begin_operator
board car18 loc26
1
15 18
2
0 0 0 10
0 2 18 27
1
end_operator
begin_operator
board car18 loc27
1
15 19
2
0 0 0 10
0 2 19 27
1
end_operator
begin_operator
board car18 loc3
1
15 20
2
0 0 0 10
0 2 20 27
1
end_operator
begin_operator
board car18 loc4
1
15 21
2
0 0 0 10
0 2 21 27
1
end_operator
begin_operator
board car18 loc5
1
15 22
2
0 0 0 10
0 2 22 27
1
end_operator
begin_operator
board car18 loc6
1
15 23
2
0 0 0 10
0 2 23 27
1
end_operator
begin_operator
board car18 loc7
1
15 24
2
0 0 0 10
0 2 24 27
1
end_operator
begin_operator
board car18 loc8
1
15 25
2
0 0 0 10
0 2 25 27
1
end_operator
begin_operator
board car18 loc9
1
15 26
2
0 0 0 10
0 2 26 27
1
end_operator
begin_operator
board car19 loc1
1
15 0
2
0 0 0 11
0 6 0 27
1
end_operator
begin_operator
board car19 loc10
1
15 1
2
0 0 0 11
0 6 1 27
1
end_operator
begin_operator
board car19 loc11
1
15 2
2
0 0 0 11
0 6 2 27
1
end_operator
begin_operator
board car19 loc12
1
15 3
2
0 0 0 11
0 6 3 27
1
end_operator
begin_operator
board car19 loc13
1
15 4
2
0 0 0 11
0 6 4 27
1
end_operator
begin_operator
board car19 loc14
1
15 5
2
0 0 0 11
0 6 5 27
1
end_operator
begin_operator
board car19 loc15
1
15 6
2
0 0 0 11
0 6 6 27
1
end_operator
begin_operator
board car19 loc16
1
15 7
2
0 0 0 11
0 6 7 27
1
end_operator
begin_operator
board car19 loc17
1
15 8
2
0 0 0 11
0 6 8 27
1
end_operator
begin_operator
board car19 loc18
1
15 9
2
0 0 0 11
0 6 9 27
1
end_operator
begin_operator
board car19 loc19
1
15 10
2
0 0 0 11
0 6 10 27
1
end_operator
begin_operator
board car19 loc2
1
15 11
2
0 0 0 11
0 6 11 27
1
end_operator
begin_operator
board car19 loc20
1
15 12
2
0 0 0 11
0 6 12 27
1
end_operator
begin_operator
board car19 loc21
1
15 13
2
0 0 0 11
0 6 13 27
1
end_operator
begin_operator
board car19 loc22
1
15 14
2
0 0 0 11
0 6 14 27
1
end_operator
begin_operator
board car19 loc23
1
15 15
2
0 0 0 11
0 6 15 27
1
end_operator
begin_operator
board car19 loc24
1
15 16
2
0 0 0 11
0 6 16 27
1
end_operator
begin_operator
board car19 loc25
1
15 17
2
0 0 0 11
0 6 17 27
1
end_operator
begin_operator
board car19 loc26
1
15 18
2
0 0 0 11
0 6 18 27
1
end_operator
begin_operator
board car19 loc27
1
15 19
2
0 0 0 11
0 6 19 27
1
end_operator
begin_operator
board car19 loc3
1
15 20
2
0 0 0 11
0 6 20 27
1
end_operator
begin_operator
board car19 loc4
1
15 21
2
0 0 0 11
0 6 21 27
1
end_operator
begin_operator
board car19 loc5
1
15 22
2
0 0 0 11
0 6 22 27
1
end_operator
begin_operator
board car19 loc6
1
15 23
2
0 0 0 11
0 6 23 27
1
end_operator
begin_operator
board car19 loc7
1
15 24
2
0 0 0 11
0 6 24 27
1
end_operator
begin_operator
board car19 loc8
1
15 25
2
0 0 0 11
0 6 25 27
1
end_operator
begin_operator
board car19 loc9
1
15 26
2
0 0 0 11
0 6 26 27
1
end_operator
begin_operator
board car2 loc1
1
15 0
2
0 0 0 12
0 10 0 27
1
end_operator
begin_operator
board car2 loc10
1
15 1
2
0 0 0 12
0 10 1 27
1
end_operator
begin_operator
board car2 loc11
1
15 2
2
0 0 0 12
0 10 2 27
1
end_operator
begin_operator
board car2 loc12
1
15 3
2
0 0 0 12
0 10 3 27
1
end_operator
begin_operator
board car2 loc13
1
15 4
2
0 0 0 12
0 10 4 27
1
end_operator
begin_operator
board car2 loc14
1
15 5
2
0 0 0 12
0 10 5 27
1
end_operator
begin_operator
board car2 loc15
1
15 6
2
0 0 0 12
0 10 6 27
1
end_operator
begin_operator
board car2 loc16
1
15 7
2
0 0 0 12
0 10 7 27
1
end_operator
begin_operator
board car2 loc17
1
15 8
2
0 0 0 12
0 10 8 27
1
end_operator
begin_operator
board car2 loc18
1
15 9
2
0 0 0 12
0 10 9 27
1
end_operator
begin_operator
board car2 loc19
1
15 10
2
0 0 0 12
0 10 10 27
1
end_operator
begin_operator
board car2 loc2
1
15 11
2
0 0 0 12
0 10 11 27
1
end_operator
begin_operator
board car2 loc20
1
15 12
2
0 0 0 12
0 10 12 27
1
end_operator
begin_operator
board car2 loc21
1
15 13
2
0 0 0 12
0 10 13 27
1
end_operator
begin_operator
board car2 loc22
1
15 14
2
0 0 0 12
0 10 14 27
1
end_operator
begin_operator
board car2 loc23
1
15 15
2
0 0 0 12
0 10 15 27
1
end_operator
begin_operator
board car2 loc24
1
15 16
2
0 0 0 12
0 10 16 27
1
end_operator
begin_operator
board car2 loc25
1
15 17
2
0 0 0 12
0 10 17 27
1
end_operator
begin_operator
board car2 loc26
1
15 18
2
0 0 0 12
0 10 18 27
1
end_operator
begin_operator
board car2 loc27
1
15 19
2
0 0 0 12
0 10 19 27
1
end_operator
begin_operator
board car2 loc3
1
15 20
2
0 0 0 12
0 10 20 27
1
end_operator
begin_operator
board car2 loc4
1
15 21
2
0 0 0 12
0 10 21 27
1
end_operator
begin_operator
board car2 loc5
1
15 22
2
0 0 0 12
0 10 22 27
1
end_operator
begin_operator
board car2 loc6
1
15 23
2
0 0 0 12
0 10 23 27
1
end_operator
begin_operator
board car2 loc7
1
15 24
2
0 0 0 12
0 10 24 27
1
end_operator
begin_operator
board car2 loc8
1
15 25
2
0 0 0 12
0 10 25 27
1
end_operator
begin_operator
board car2 loc9
1
15 26
2
0 0 0 12
0 10 26 27
1
end_operator
begin_operator
board car20 loc1
1
15 0
2
0 0 0 13
0 14 0 27
1
end_operator
begin_operator
board car20 loc10
1
15 1
2
0 0 0 13
0 14 1 27
1
end_operator
begin_operator
board car20 loc11
1
15 2
2
0 0 0 13
0 14 2 27
1
end_operator
begin_operator
board car20 loc12
1
15 3
2
0 0 0 13
0 14 3 27
1
end_operator
begin_operator
board car20 loc13
1
15 4
2
0 0 0 13
0 14 4 27
1
end_operator
begin_operator
board car20 loc14
1
15 5
2
0 0 0 13
0 14 5 27
1
end_operator
begin_operator
board car20 loc15
1
15 6
2
0 0 0 13
0 14 6 27
1
end_operator
begin_operator
board car20 loc16
1
15 7
2
0 0 0 13
0 14 7 27
1
end_operator
begin_operator
board car20 loc17
1
15 8
2
0 0 0 13
0 14 8 27
1
end_operator
begin_operator
board car20 loc18
1
15 9
2
0 0 0 13
0 14 9 27
1
end_operator
begin_operator
board car20 loc19
1
15 10
2
0 0 0 13
0 14 10 27
1
end_operator
begin_operator
board car20 loc2
1
15 11
2
0 0 0 13
0 14 11 27
1
end_operator
begin_operator
board car20 loc20
1
15 12
2
0 0 0 13
0 14 12 27
1
end_operator
begin_operator
board car20 loc21
1
15 13
2
0 0 0 13
0 14 13 27
1
end_operator
begin_operator
board car20 loc22
1
15 14
2
0 0 0 13
0 14 14 27
1
end_operator
begin_operator
board car20 loc23
1
15 15
2
0 0 0 13
0 14 15 27
1
end_operator
begin_operator
board car20 loc24
1
15 16
2
0 0 0 13
0 14 16 27
1
end_operator
begin_operator
board car20 loc25
1
15 17
2
0 0 0 13
0 14 17 27
1
end_operator
begin_operator
board car20 loc26
1
15 18
2
0 0 0 13
0 14 18 27
1
end_operator
begin_operator
board car20 loc27
1
15 19
2
0 0 0 13
0 14 19 27
1
end_operator
begin_operator
board car20 loc3
1
15 20
2
0 0 0 13
0 14 20 27
1
end_operator
begin_operator
board car20 loc4
1
15 21
2
0 0 0 13
0 14 21 27
1
end_operator
begin_operator
board car20 loc5
1
15 22
2
0 0 0 13
0 14 22 27
1
end_operator
begin_operator
board car20 loc6
1
15 23
2
0 0 0 13
0 14 23 27
1
end_operator
begin_operator
board car20 loc7
1
15 24
2
0 0 0 13
0 14 24 27
1
end_operator
begin_operator
board car20 loc8
1
15 25
2
0 0 0 13
0 14 25 27
1
end_operator
begin_operator
board car20 loc9
1
15 26
2
0 0 0 13
0 14 26 27
1
end_operator
begin_operator
board car21 loc1
1
15 0
2
0 0 0 14
0 18 0 27
1
end_operator
begin_operator
board car21 loc10
1
15 1
2
0 0 0 14
0 18 1 27
1
end_operator
begin_operator
board car21 loc11
1
15 2
2
0 0 0 14
0 18 2 27
1
end_operator
begin_operator
board car21 loc12
1
15 3
2
0 0 0 14
0 18 3 27
1
end_operator
begin_operator
board car21 loc13
1
15 4
2
0 0 0 14
0 18 4 27
1
end_operator
begin_operator
board car21 loc14
1
15 5
2
0 0 0 14
0 18 5 27
1
end_operator
begin_operator
board car21 loc15
1
15 6
2
0 0 0 14
0 18 6 27
1
end_operator
begin_operator
board car21 loc16
1
15 7
2
0 0 0 14
0 18 7 27
1
end_operator
begin_operator
board car21 loc17
1
15 8
2
0 0 0 14
0 18 8 27
1
end_operator
begin_operator
board car21 loc18
1
15 9
2
0 0 0 14
0 18 9 27
1
end_operator
begin_operator
board car21 loc19
1
15 10
2
0 0 0 14
0 18 10 27
1
end_operator
begin_operator
board car21 loc2
1
15 11
2
0 0 0 14
0 18 11 27
1
end_operator
begin_operator
board car21 loc20
1
15 12
2
0 0 0 14
0 18 12 27
1
end_operator
begin_operator
board car21 loc21
1
15 13
2
0 0 0 14
0 18 13 27
1
end_operator
begin_operator
board car21 loc22
1
15 14
2
0 0 0 14
0 18 14 27
1
end_operator
begin_operator
board car21 loc23
1
15 15
2
0 0 0 14
0 18 15 27
1
end_operator
begin_operator
board car21 loc24
1
15 16
2
0 0 0 14
0 18 16 27
1
end_operator
begin_operator
board car21 loc25
1
15 17
2
0 0 0 14
0 18 17 27
1
end_operator
begin_operator
board car21 loc26
1
15 18
2
0 0 0 14
0 18 18 27
1
end_operator
begin_operator
board car21 loc27
1
15 19
2
0 0 0 14
0 18 19 27
1
end_operator
begin_operator
board car21 loc3
1
15 20
2
0 0 0 14
0 18 20 27
1
end_operator
begin_operator
board car21 loc4
1
15 21
2
0 0 0 14
0 18 21 27
1
end_operator
begin_operator
board car21 loc5
1
15 22
2
0 0 0 14
0 18 22 27
1
end_operator
begin_operator
board car21 loc6
1
15 23
2
0 0 0 14
0 18 23 27
1
end_operator
begin_operator
board car21 loc7
1
15 24
2
0 0 0 14
0 18 24 27
1
end_operator
begin_operator
board car21 loc8
1
15 25
2
0 0 0 14
0 18 25 27
1
end_operator
begin_operator
board car21 loc9
1
15 26
2
0 0 0 14
0 18 26 27
1
end_operator
begin_operator
board car22 loc1
1
15 0
2
0 0 0 15
0 21 0 27
1
end_operator
begin_operator
board car22 loc10
1
15 1
2
0 0 0 15
0 21 1 27
1
end_operator
begin_operator
board car22 loc11
1
15 2
2
0 0 0 15
0 21 2 27
1
end_operator
begin_operator
board car22 loc12
1
15 3
2
0 0 0 15
0 21 3 27
1
end_operator
begin_operator
board car22 loc13
1
15 4
2
0 0 0 15
0 21 4 27
1
end_operator
begin_operator
board car22 loc14
1
15 5
2
0 0 0 15
0 21 5 27
1
end_operator
begin_operator
board car22 loc15
1
15 6
2
0 0 0 15
0 21 6 27
1
end_operator
begin_operator
board car22 loc16
1
15 7
2
0 0 0 15
0 21 7 27
1
end_operator
begin_operator
board car22 loc17
1
15 8
2
0 0 0 15
0 21 8 27
1
end_operator
begin_operator
board car22 loc18
1
15 9
2
0 0 0 15
0 21 9 27
1
end_operator
begin_operator
board car22 loc19
1
15 10
2
0 0 0 15
0 21 10 27
1
end_operator
begin_operator
board car22 loc2
1
15 11
2
0 0 0 15
0 21 11 27
1
end_operator
begin_operator
board car22 loc20
1
15 12
2
0 0 0 15
0 21 12 27
1
end_operator
begin_operator
board car22 loc21
1
15 13
2
0 0 0 15
0 21 13 27
1
end_operator
begin_operator
board car22 loc22
1
15 14
2
0 0 0 15
0 21 14 27
1
end_operator
begin_operator
board car22 loc23
1
15 15
2
0 0 0 15
0 21 15 27
1
end_operator
begin_operator
board car22 loc24
1
15 16
2
0 0 0 15
0 21 16 27
1
end_operator
begin_operator
board car22 loc25
1
15 17
2
0 0 0 15
0 21 17 27
1
end_operator
begin_operator
board car22 loc26
1
15 18
2
0 0 0 15
0 21 18 27
1
end_operator
begin_operator
board car22 loc27
1
15 19
2
0 0 0 15
0 21 19 27
1
end_operator
begin_operator
board car22 loc3
1
15 20
2
0 0 0 15
0 21 20 27
1
end_operator
begin_operator
board car22 loc4
1
15 21
2
0 0 0 15
0 21 21 27
1
end_operator
begin_operator
board car22 loc5
1
15 22
2
0 0 0 15
0 21 22 27
1
end_operator
begin_operator
board car22 loc6
1
15 23
2
0 0 0 15
0 21 23 27
1
end_operator
begin_operator
board car22 loc7
1
15 24
2
0 0 0 15
0 21 24 27
1
end_operator
begin_operator
board car22 loc8
1
15 25
2
0 0 0 15
0 21 25 27
1
end_operator
begin_operator
board car22 loc9
1
15 26
2
0 0 0 15
0 21 26 27
1
end_operator
begin_operator
board car23 loc1
1
15 0
2
0 0 0 16
0 24 0 27
1
end_operator
begin_operator
board car23 loc10
1
15 1
2
0 0 0 16
0 24 1 27
1
end_operator
begin_operator
board car23 loc11
1
15 2
2
0 0 0 16
0 24 2 27
1
end_operator
begin_operator
board car23 loc12
1
15 3
2
0 0 0 16
0 24 3 27
1
end_operator
begin_operator
board car23 loc13
1
15 4
2
0 0 0 16
0 24 4 27
1
end_operator
begin_operator
board car23 loc14
1
15 5
2
0 0 0 16
0 24 5 27
1
end_operator
begin_operator
board car23 loc15
1
15 6
2
0 0 0 16
0 24 6 27
1
end_operator
begin_operator
board car23 loc16
1
15 7
2
0 0 0 16
0 24 7 27
1
end_operator
begin_operator
board car23 loc17
1
15 8
2
0 0 0 16
0 24 8 27
1
end_operator
begin_operator
board car23 loc18
1
15 9
2
0 0 0 16
0 24 9 27
1
end_operator
begin_operator
board car23 loc19
1
15 10
2
0 0 0 16
0 24 10 27
1
end_operator
begin_operator
board car23 loc2
1
15 11
2
0 0 0 16
0 24 11 27
1
end_operator
begin_operator
board car23 loc20
1
15 12
2
0 0 0 16
0 24 12 27
1
end_operator
begin_operator
board car23 loc21
1
15 13
2
0 0 0 16
0 24 13 27
1
end_operator
begin_operator
board car23 loc22
1
15 14
2
0 0 0 16
0 24 14 27
1
end_operator
begin_operator
board car23 loc23
1
15 15
2
0 0 0 16
0 24 15 27
1
end_operator
begin_operator
board car23 loc24
1
15 16
2
0 0 0 16
0 24 16 27
1
end_operator
begin_operator
board car23 loc25
1
15 17
2
0 0 0 16
0 24 17 27
1
end_operator
begin_operator
board car23 loc26
1
15 18
2
0 0 0 16
0 24 18 27
1
end_operator
begin_operator
board car23 loc27
1
15 19
2
0 0 0 16
0 24 19 27
1
end_operator
begin_operator
board car23 loc3
1
15 20
2
0 0 0 16
0 24 20 27
1
end_operator
begin_operator
board car23 loc4
1
15 21
2
0 0 0 16
0 24 21 27
1
end_operator
begin_operator
board car23 loc5
1
15 22
2
0 0 0 16
0 24 22 27
1
end_operator
begin_operator
board car23 loc6
1
15 23
2
0 0 0 16
0 24 23 27
1
end_operator
begin_operator
board car23 loc7
1
15 24
2
0 0 0 16
0 24 24 27
1
end_operator
begin_operator
board car23 loc8
1
15 25
2
0 0 0 16
0 24 25 27
1
end_operator
begin_operator
board car23 loc9
1
15 26
2
0 0 0 16
0 24 26 27
1
end_operator
begin_operator
board car24 loc1
1
15 0
2
0 0 0 17
0 27 0 27
1
end_operator
begin_operator
board car24 loc10
1
15 1
2
0 0 0 17
0 27 1 27
1
end_operator
begin_operator
board car24 loc11
1
15 2
2
0 0 0 17
0 27 2 27
1
end_operator
begin_operator
board car24 loc12
1
15 3
2
0 0 0 17
0 27 3 27
1
end_operator
begin_operator
board car24 loc13
1
15 4
2
0 0 0 17
0 27 4 27
1
end_operator
begin_operator
board car24 loc14
1
15 5
2
0 0 0 17
0 27 5 27
1
end_operator
begin_operator
board car24 loc15
1
15 6
2
0 0 0 17
0 27 6 27
1
end_operator
begin_operator
board car24 loc16
1
15 7
2
0 0 0 17
0 27 7 27
1
end_operator
begin_operator
board car24 loc17
1
15 8
2
0 0 0 17
0 27 8 27
1
end_operator
begin_operator
board car24 loc18
1
15 9
2
0 0 0 17
0 27 9 27
1
end_operator
begin_operator
board car24 loc19
1
15 10
2
0 0 0 17
0 27 10 27
1
end_operator
begin_operator
board car24 loc2
1
15 11
2
0 0 0 17
0 27 11 27
1
end_operator
begin_operator
board car24 loc20
1
15 12
2
0 0 0 17
0 27 12 27
1
end_operator
begin_operator
board car24 loc21
1
15 13
2
0 0 0 17
0 27 13 27
1
end_operator
begin_operator
board car24 loc22
1
15 14
2
0 0 0 17
0 27 14 27
1
end_operator
begin_operator
board car24 loc23
1
15 15
2
0 0 0 17
0 27 15 27
1
end_operator
begin_operator
board car24 loc24
1
15 16
2
0 0 0 17
0 27 16 27
1
end_operator
begin_operator
board car24 loc25
1
15 17
2
0 0 0 17
0 27 17 27
1
end_operator
begin_operator
board car24 loc26
1
15 18
2
0 0 0 17
0 27 18 27
1
end_operator
begin_operator
board car24 loc27
1
15 19
2
0 0 0 17
0 27 19 27
1
end_operator
begin_operator
board car24 loc3
1
15 20
2
0 0 0 17
0 27 20 27
1
end_operator
begin_operator
board car24 loc4
1
15 21
2
0 0 0 17
0 27 21 27
1
end_operator
begin_operator
board car24 loc5
1
15 22
2
0 0 0 17
0 27 22 27
1
end_operator
begin_operator
board car24 loc6
1
15 23
2
0 0 0 17
0 27 23 27
1
end_operator
begin_operator
board car24 loc7
1
15 24
2
0 0 0 17
0 27 24 27
1
end_operator
begin_operator
board car24 loc8
1
15 25
2
0 0 0 17
0 27 25 27
1
end_operator
begin_operator
board car24 loc9
1
15 26
2
0 0 0 17
0 27 26 27
1
end_operator
begin_operator
board car25 loc1
1
15 0
2
0 0 0 18
0 30 0 27
1
end_operator
begin_operator
board car25 loc10
1
15 1
2
0 0 0 18
0 30 1 27
1
end_operator
begin_operator
board car25 loc11
1
15 2
2
0 0 0 18
0 30 2 27
1
end_operator
begin_operator
board car25 loc12
1
15 3
2
0 0 0 18
0 30 3 27
1
end_operator
begin_operator
board car25 loc13
1
15 4
2
0 0 0 18
0 30 4 27
1
end_operator
begin_operator
board car25 loc14
1
15 5
2
0 0 0 18
0 30 5 27
1
end_operator
begin_operator
board car25 loc15
1
15 6
2
0 0 0 18
0 30 6 27
1
end_operator
begin_operator
board car25 loc16
1
15 7
2
0 0 0 18
0 30 7 27
1
end_operator
begin_operator
board car25 loc17
1
15 8
2
0 0 0 18
0 30 8 27
1
end_operator
begin_operator
board car25 loc18
1
15 9
2
0 0 0 18
0 30 9 27
1
end_operator
begin_operator
board car25 loc19
1
15 10
2
0 0 0 18
0 30 10 27
1
end_operator
begin_operator
board car25 loc2
1
15 11
2
0 0 0 18
0 30 11 27
1
end_operator
begin_operator
board car25 loc20
1
15 12
2
0 0 0 18
0 30 12 27
1
end_operator
begin_operator
board car25 loc21
1
15 13
2
0 0 0 18
0 30 13 27
1
end_operator
begin_operator
board car25 loc22
1
15 14
2
0 0 0 18
0 30 14 27
1
end_operator
begin_operator
board car25 loc23
1
15 15
2
0 0 0 18
0 30 15 27
1
end_operator
begin_operator
board car25 loc24
1
15 16
2
0 0 0 18
0 30 16 27
1
end_operator
begin_operator
board car25 loc25
1
15 17
2
0 0 0 18
0 30 17 27
1
end_operator
begin_operator
board car25 loc26
1
15 18
2
0 0 0 18
0 30 18 27
1
end_operator
begin_operator
board car25 loc27
1
15 19
2
0 0 0 18
0 30 19 27
1
end_operator
begin_operator
board car25 loc3
1
15 20
2
0 0 0 18
0 30 20 27
1
end_operator
begin_operator
board car25 loc4
1
15 21
2
0 0 0 18
0 30 21 27
1
end_operator
begin_operator
board car25 loc5
1
15 22
2
0 0 0 18
0 30 22 27
1
end_operator
begin_operator
board car25 loc6
1
15 23
2
0 0 0 18
0 30 23 27
1
end_operator
begin_operator
board car25 loc7
1
15 24
2
0 0 0 18
0 30 24 27
1
end_operator
begin_operator
board car25 loc8
1
15 25
2
0 0 0 18
0 30 25 27
1
end_operator
begin_operator
board car25 loc9
1
15 26
2
0 0 0 18
0 30 26 27
1
end_operator
begin_operator
board car26 loc1
1
15 0
2
0 0 0 19
0 1 0 27
1
end_operator
begin_operator
board car26 loc10
1
15 1
2
0 0 0 19
0 1 1 27
1
end_operator
begin_operator
board car26 loc11
1
15 2
2
0 0 0 19
0 1 2 27
1
end_operator
begin_operator
board car26 loc12
1
15 3
2
0 0 0 19
0 1 3 27
1
end_operator
begin_operator
board car26 loc13
1
15 4
2
0 0 0 19
0 1 4 27
1
end_operator
begin_operator
board car26 loc14
1
15 5
2
0 0 0 19
0 1 5 27
1
end_operator
begin_operator
board car26 loc15
1
15 6
2
0 0 0 19
0 1 6 27
1
end_operator
begin_operator
board car26 loc16
1
15 7
2
0 0 0 19
0 1 7 27
1
end_operator
begin_operator
board car26 loc17
1
15 8
2
0 0 0 19
0 1 8 27
1
end_operator
begin_operator
board car26 loc18
1
15 9
2
0 0 0 19
0 1 9 27
1
end_operator
begin_operator
board car26 loc19
1
15 10
2
0 0 0 19
0 1 10 27
1
end_operator
begin_operator
board car26 loc2
1
15 11
2
0 0 0 19
0 1 11 27
1
end_operator
begin_operator
board car26 loc20
1
15 12
2
0 0 0 19
0 1 12 27
1
end_operator
begin_operator
board car26 loc21
1
15 13
2
0 0 0 19
0 1 13 27
1
end_operator
begin_operator
board car26 loc22
1
15 14
2
0 0 0 19
0 1 14 27
1
end_operator
begin_operator
board car26 loc23
1
15 15
2
0 0 0 19
0 1 15 27
1
end_operator
begin_operator
board car26 loc24
1
15 16
2
0 0 0 19
0 1 16 27
1
end_operator
begin_operator
board car26 loc25
1
15 17
2
0 0 0 19
0 1 17 27
1
end_operator
begin_operator
board car26 loc26
1
15 18
2
0 0 0 19
0 1 18 27
1
end_operator
begin_operator
board car26 loc27
1
15 19
2
0 0 0 19
0 1 19 27
1
end_operator
begin_operator
board car26 loc3
1
15 20
2
0 0 0 19
0 1 20 27
1
end_operator
begin_operator
board car26 loc4
1
15 21
2
0 0 0 19
0 1 21 27
1
end_operator
begin_operator
board car26 loc5
1
15 22
2
0 0 0 19
0 1 22 27
1
end_operator
begin_operator
board car26 loc6
1
15 23
2
0 0 0 19
0 1 23 27
1
end_operator
begin_operator
board car26 loc7
1
15 24
2
0 0 0 19
0 1 24 27
1
end_operator
begin_operator
board car26 loc8
1
15 25
2
0 0 0 19
0 1 25 27
1
end_operator
begin_operator
board car26 loc9
1
15 26
2
0 0 0 19
0 1 26 27
1
end_operator
begin_operator
board car27 loc1
1
15 0
2
0 0 0 20
0 5 0 27
1
end_operator
begin_operator
board car27 loc10
1
15 1
2
0 0 0 20
0 5 1 27
1
end_operator
begin_operator
board car27 loc11
1
15 2
2
0 0 0 20
0 5 2 27
1
end_operator
begin_operator
board car27 loc12
1
15 3
2
0 0 0 20
0 5 3 27
1
end_operator
begin_operator
board car27 loc13
1
15 4
2
0 0 0 20
0 5 4 27
1
end_operator
begin_operator
board car27 loc14
1
15 5
2
0 0 0 20
0 5 5 27
1
end_operator
begin_operator
board car27 loc15
1
15 6
2
0 0 0 20
0 5 6 27
1
end_operator
begin_operator
board car27 loc16
1
15 7
2
0 0 0 20
0 5 7 27
1
end_operator
begin_operator
board car27 loc17
1
15 8
2
0 0 0 20
0 5 8 27
1
end_operator
begin_operator
board car27 loc18
1
15 9
2
0 0 0 20
0 5 9 27
1
end_operator
begin_operator
board car27 loc19
1
15 10
2
0 0 0 20
0 5 10 27
1
end_operator
begin_operator
board car27 loc2
1
15 11
2
0 0 0 20
0 5 11 27
1
end_operator
begin_operator
board car27 loc20
1
15 12
2
0 0 0 20
0 5 12 27
1
end_operator
begin_operator
board car27 loc21
1
15 13
2
0 0 0 20
0 5 13 27
1
end_operator
begin_operator
board car27 loc22
1
15 14
2
0 0 0 20
0 5 14 27
1
end_operator
begin_operator
board car27 loc23
1
15 15
2
0 0 0 20
0 5 15 27
1
end_operator
begin_operator
board car27 loc24
1
15 16
2
0 0 0 20
0 5 16 27
1
end_operator
begin_operator
board car27 loc25
1
15 17
2
0 0 0 20
0 5 17 27
1
end_operator
begin_operator
board car27 loc26
1
15 18
2
0 0 0 20
0 5 18 27
1
end_operator
begin_operator
board car27 loc27
1
15 19
2
0 0 0 20
0 5 19 27
1
end_operator
begin_operator
board car27 loc3
1
15 20
2
0 0 0 20
0 5 20 27
1
end_operator
begin_operator
board car27 loc4
1
15 21
2
0 0 0 20
0 5 21 27
1
end_operator
begin_operator
board car27 loc5
1
15 22
2
0 0 0 20
0 5 22 27
1
end_operator
begin_operator
board car27 loc6
1
15 23
2
0 0 0 20
0 5 23 27
1
end_operator
begin_operator
board car27 loc7
1
15 24
2
0 0 0 20
0 5 24 27
1
end_operator
begin_operator
board car27 loc8
1
15 25
2
0 0 0 20
0 5 25 27
1
end_operator
begin_operator
board car27 loc9
1
15 26
2
0 0 0 20
0 5 26 27
1
end_operator
begin_operator
board car28 loc1
1
15 0
2
0 0 0 21
0 9 0 27
1
end_operator
begin_operator
board car28 loc10
1
15 1
2
0 0 0 21
0 9 1 27
1
end_operator
begin_operator
board car28 loc11
1
15 2
2
0 0 0 21
0 9 2 27
1
end_operator
begin_operator
board car28 loc12
1
15 3
2
0 0 0 21
0 9 3 27
1
end_operator
begin_operator
board car28 loc13
1
15 4
2
0 0 0 21
0 9 4 27
1
end_operator
begin_operator
board car28 loc14
1
15 5
2
0 0 0 21
0 9 5 27
1
end_operator
begin_operator
board car28 loc15
1
15 6
2
0 0 0 21
0 9 6 27
1
end_operator
begin_operator
board car28 loc16
1
15 7
2
0 0 0 21
0 9 7 27
1
end_operator
begin_operator
board car28 loc17
1
15 8
2
0 0 0 21
0 9 8 27
1
end_operator
begin_operator
board car28 loc18
1
15 9
2
0 0 0 21
0 9 9 27
1
end_operator
begin_operator
board car28 loc19
1
15 10
2
0 0 0 21
0 9 10 27
1
end_operator
begin_operator
board car28 loc2
1
15 11
2
0 0 0 21
0 9 11 27
1
end_operator
begin_operator
board car28 loc20
1
15 12
2
0 0 0 21
0 9 12 27
1
end_operator
begin_operator
board car28 loc21
1
15 13
2
0 0 0 21
0 9 13 27
1
end_operator
begin_operator
board car28 loc22
1
15 14
2
0 0 0 21
0 9 14 27
1
end_operator
begin_operator
board car28 loc23
1
15 15
2
0 0 0 21
0 9 15 27
1
end_operator
begin_operator
board car28 loc24
1
15 16
2
0 0 0 21
0 9 16 27
1
end_operator
begin_operator
board car28 loc25
1
15 17
2
0 0 0 21
0 9 17 27
1
end_operator
begin_operator
board car28 loc26
1
15 18
2
0 0 0 21
0 9 18 27
1
end_operator
begin_operator
board car28 loc27
1
15 19
2
0 0 0 21
0 9 19 27
1
end_operator
begin_operator
board car28 loc3
1
15 20
2
0 0 0 21
0 9 20 27
1
end_operator
begin_operator
board car28 loc4
1
15 21
2
0 0 0 21
0 9 21 27
1
end_operator
begin_operator
board car28 loc5
1
15 22
2
0 0 0 21
0 9 22 27
1
end_operator
begin_operator
board car28 loc6
1
15 23
2
0 0 0 21
0 9 23 27
1
end_operator
begin_operator
board car28 loc7
1
15 24
2
0 0 0 21
0 9 24 27
1
end_operator
begin_operator
board car28 loc8
1
15 25
2
0 0 0 21
0 9 25 27
1
end_operator
begin_operator
board car28 loc9
1
15 26
2
0 0 0 21
0 9 26 27
1
end_operator
begin_operator
board car29 loc1
1
15 0
2
0 0 0 22
0 13 0 27
1
end_operator
begin_operator
board car29 loc10
1
15 1
2
0 0 0 22
0 13 1 27
1
end_operator
begin_operator
board car29 loc11
1
15 2
2
0 0 0 22
0 13 2 27
1
end_operator
begin_operator
board car29 loc12
1
15 3
2
0 0 0 22
0 13 3 27
1
end_operator
begin_operator
board car29 loc13
1
15 4
2
0 0 0 22
0 13 4 27
1
end_operator
begin_operator
board car29 loc14
1
15 5
2
0 0 0 22
0 13 5 27
1
end_operator
begin_operator
board car29 loc15
1
15 6
2
0 0 0 22
0 13 6 27
1
end_operator
begin_operator
board car29 loc16
1
15 7
2
0 0 0 22
0 13 7 27
1
end_operator
begin_operator
board car29 loc17
1
15 8
2
0 0 0 22
0 13 8 27
1
end_operator
begin_operator
board car29 loc18
1
15 9
2
0 0 0 22
0 13 9 27
1
end_operator
begin_operator
board car29 loc19
1
15 10
2
0 0 0 22
0 13 10 27
1
end_operator
begin_operator
board car29 loc2
1
15 11
2
0 0 0 22
0 13 11 27
1
end_operator
begin_operator
board car29 loc20
1
15 12
2
0 0 0 22
0 13 12 27
1
end_operator
begin_operator
board car29 loc21
1
15 13
2
0 0 0 22
0 13 13 27
1
end_operator
begin_operator
board car29 loc22
1
15 14
2
0 0 0 22
0 13 14 27
1
end_operator
begin_operator
board car29 loc23
1
15 15
2
0 0 0 22
0 13 15 27
1
end_operator
begin_operator
board car29 loc24
1
15 16
2
0 0 0 22
0 13 16 27
1
end_operator
begin_operator
board car29 loc25
1
15 17
2
0 0 0 22
0 13 17 27
1
end_operator
begin_operator
board car29 loc26
1
15 18
2
0 0 0 22
0 13 18 27
1
end_operator
begin_operator
board car29 loc27
1
15 19
2
0 0 0 22
0 13 19 27
1
end_operator
begin_operator
board car29 loc3
1
15 20
2
0 0 0 22
0 13 20 27
1
end_operator
begin_operator
board car29 loc4
1
15 21
2
0 0 0 22
0 13 21 27
1
end_operator
begin_operator
board car29 loc5
1
15 22
2
0 0 0 22
0 13 22 27
1
end_operator
begin_operator
board car29 loc6
1
15 23
2
0 0 0 22
0 13 23 27
1
end_operator
begin_operator
board car29 loc7
1
15 24
2
0 0 0 22
0 13 24 27
1
end_operator
begin_operator
board car29 loc8
1
15 25
2
0 0 0 22
0 13 25 27
1
end_operator
begin_operator
board car29 loc9
1
15 26
2
0 0 0 22
0 13 26 27
1
end_operator
begin_operator
board car3 loc1
1
15 0
2
0 0 0 23
0 17 0 27
1
end_operator
begin_operator
board car3 loc10
1
15 1
2
0 0 0 23
0 17 1 27
1
end_operator
begin_operator
board car3 loc11
1
15 2
2
0 0 0 23
0 17 2 27
1
end_operator
begin_operator
board car3 loc12
1
15 3
2
0 0 0 23
0 17 3 27
1
end_operator
begin_operator
board car3 loc13
1
15 4
2
0 0 0 23
0 17 4 27
1
end_operator
begin_operator
board car3 loc14
1
15 5
2
0 0 0 23
0 17 5 27
1
end_operator
begin_operator
board car3 loc15
1
15 6
2
0 0 0 23
0 17 6 27
1
end_operator
begin_operator
board car3 loc16
1
15 7
2
0 0 0 23
0 17 7 27
1
end_operator
begin_operator
board car3 loc17
1
15 8
2
0 0 0 23
0 17 8 27
1
end_operator
begin_operator
board car3 loc18
1
15 9
2
0 0 0 23
0 17 9 27
1
end_operator
begin_operator
board car3 loc19
1
15 10
2
0 0 0 23
0 17 10 27
1
end_operator
begin_operator
board car3 loc2
1
15 11
2
0 0 0 23
0 17 11 27
1
end_operator
begin_operator
board car3 loc20
1
15 12
2
0 0 0 23
0 17 12 27
1
end_operator
begin_operator
board car3 loc21
1
15 13
2
0 0 0 23
0 17 13 27
1
end_operator
begin_operator
board car3 loc22
1
15 14
2
0 0 0 23
0 17 14 27
1
end_operator
begin_operator
board car3 loc23
1
15 15
2
0 0 0 23
0 17 15 27
1
end_operator
begin_operator
board car3 loc24
1
15 16
2
0 0 0 23
0 17 16 27
1
end_operator
begin_operator
board car3 loc25
1
15 17
2
0 0 0 23
0 17 17 27
1
end_operator
begin_operator
board car3 loc26
1
15 18
2
0 0 0 23
0 17 18 27
1
end_operator
begin_operator
board car3 loc27
1
15 19
2
0 0 0 23
0 17 19 27
1
end_operator
begin_operator
board car3 loc3
1
15 20
2
0 0 0 23
0 17 20 27
1
end_operator
begin_operator
board car3 loc4
1
15 21
2
0 0 0 23
0 17 21 27
1
end_operator
begin_operator
board car3 loc5
1
15 22
2
0 0 0 23
0 17 22 27
1
end_operator
begin_operator
board car3 loc6
1
15 23
2
0 0 0 23
0 17 23 27
1
end_operator
begin_operator
board car3 loc7
1
15 24
2
0 0 0 23
0 17 24 27
1
end_operator
begin_operator
board car3 loc8
1
15 25
2
0 0 0 23
0 17 25 27
1
end_operator
begin_operator
board car3 loc9
1
15 26
2
0 0 0 23
0 17 26 27
1
end_operator
begin_operator
board car30 loc1
1
15 0
2
0 0 0 24
0 20 0 27
1
end_operator
begin_operator
board car30 loc10
1
15 1
2
0 0 0 24
0 20 1 27
1
end_operator
begin_operator
board car30 loc11
1
15 2
2
0 0 0 24
0 20 2 27
1
end_operator
begin_operator
board car30 loc12
1
15 3
2
0 0 0 24
0 20 3 27
1
end_operator
begin_operator
board car30 loc13
1
15 4
2
0 0 0 24
0 20 4 27
1
end_operator
begin_operator
board car30 loc14
1
15 5
2
0 0 0 24
0 20 5 27
1
end_operator
begin_operator
board car30 loc15
1
15 6
2
0 0 0 24
0 20 6 27
1
end_operator
begin_operator
board car30 loc16
1
15 7
2
0 0 0 24
0 20 7 27
1
end_operator
begin_operator
board car30 loc17
1
15 8
2
0 0 0 24
0 20 8 27
1
end_operator
begin_operator
board car30 loc18
1
15 9
2
0 0 0 24
0 20 9 27
1
end_operator
begin_operator
board car30 loc19
1
15 10
2
0 0 0 24
0 20 10 27
1
end_operator
begin_operator
board car30 loc2
1
15 11
2
0 0 0 24
0 20 11 27
1
end_operator
begin_operator
board car30 loc20
1
15 12
2
0 0 0 24
0 20 12 27
1
end_operator
begin_operator
board car30 loc21
1
15 13
2
0 0 0 24
0 20 13 27
1
end_operator
begin_operator
board car30 loc22
1
15 14
2
0 0 0 24
0 20 14 27
1
end_operator
begin_operator
board car30 loc23
1
15 15
2
0 0 0 24
0 20 15 27
1
end_operator
begin_operator
board car30 loc24
1
15 16
2
0 0 0 24
0 20 16 27
1
end_operator
begin_operator
board car30 loc25
1
15 17
2
0 0 0 24
0 20 17 27
1
end_operator
begin_operator
board car30 loc26
1
15 18
2
0 0 0 24
0 20 18 27
1
end_operator
begin_operator
board car30 loc27
1
15 19
2
0 0 0 24
0 20 19 27
1
end_operator
begin_operator
board car30 loc3
1
15 20
2
0 0 0 24
0 20 20 27
1
end_operator
begin_operator
board car30 loc4
1
15 21
2
0 0 0 24
0 20 21 27
1
end_operator
begin_operator
board car30 loc5
1
15 22
2
0 0 0 24
0 20 22 27
1
end_operator
begin_operator
board car30 loc6
1
15 23
2
0 0 0 24
0 20 23 27
1
end_operator
begin_operator
board car30 loc7
1
15 24
2
0 0 0 24
0 20 24 27
1
end_operator
begin_operator
board car30 loc8
1
15 25
2
0 0 0 24
0 20 25 27
1
end_operator
begin_operator
board car30 loc9
1
15 26
2
0 0 0 24
0 20 26 27
1
end_operator
begin_operator
board car31 loc1
1
15 0
2
0 0 0 25
0 23 0 27
1
end_operator
begin_operator
board car31 loc10
1
15 1
2
0 0 0 25
0 23 1 27
1
end_operator
begin_operator
board car31 loc11
1
15 2
2
0 0 0 25
0 23 2 27
1
end_operator
begin_operator
board car31 loc12
1
15 3
2
0 0 0 25
0 23 3 27
1
end_operator
begin_operator
board car31 loc13
1
15 4
2
0 0 0 25
0 23 4 27
1
end_operator
begin_operator
board car31 loc14
1
15 5
2
0 0 0 25
0 23 5 27
1
end_operator
begin_operator
board car31 loc15
1
15 6
2
0 0 0 25
0 23 6 27
1
end_operator
begin_operator
board car31 loc16
1
15 7
2
0 0 0 25
0 23 7 27
1
end_operator
begin_operator
board car31 loc17
1
15 8
2
0 0 0 25
0 23 8 27
1
end_operator
begin_operator
board car31 loc18
1
15 9
2
0 0 0 25
0 23 9 27
1
end_operator
begin_operator
board car31 loc19
1
15 10
2
0 0 0 25
0 23 10 27
1
end_operator
begin_operator
board car31 loc2
1
15 11
2
0 0 0 25
0 23 11 27
1
end_operator
begin_operator
board car31 loc20
1
15 12
2
0 0 0 25
0 23 12 27
1
end_operator
begin_operator
board car31 loc21
1
15 13
2
0 0 0 25
0 23 13 27
1
end_operator
begin_operator
board car31 loc22
1
15 14
2
0 0 0 25
0 23 14 27
1
end_operator
begin_operator
board car31 loc23
1
15 15
2
0 0 0 25
0 23 15 27
1
end_operator
begin_operator
board car31 loc24
1
15 16
2
0 0 0 25
0 23 16 27
1
end_operator
begin_operator
board car31 loc25
1
15 17
2
0 0 0 25
0 23 17 27
1
end_operator
begin_operator
board car31 loc26
1
15 18
2
0 0 0 25
0 23 18 27
1
end_operator
begin_operator
board car31 loc27
1
15 19
2
0 0 0 25
0 23 19 27
1
end_operator
begin_operator
board car31 loc3
1
15 20
2
0 0 0 25
0 23 20 27
1
end_operator
begin_operator
board car31 loc4
1
15 21
2
0 0 0 25
0 23 21 27
1
end_operator
begin_operator
board car31 loc5
1
15 22
2
0 0 0 25
0 23 22 27
1
end_operator
begin_operator
board car31 loc6
1
15 23
2
0 0 0 25
0 23 23 27
1
end_operator
begin_operator
board car31 loc7
1
15 24
2
0 0 0 25
0 23 24 27
1
end_operator
begin_operator
board car31 loc8
1
15 25
2
0 0 0 25
0 23 25 27
1
end_operator
begin_operator
board car31 loc9
1
15 26
2
0 0 0 25
0 23 26 27
1
end_operator
begin_operator
board car4 loc1
1
15 0
2
0 0 0 26
0 26 0 27
1
end_operator
begin_operator
board car4 loc10
1
15 1
2
0 0 0 26
0 26 1 27
1
end_operator
begin_operator
board car4 loc11
1
15 2
2
0 0 0 26
0 26 2 27
1
end_operator
begin_operator
board car4 loc12
1
15 3
2
0 0 0 26
0 26 3 27
1
end_operator
begin_operator
board car4 loc13
1
15 4
2
0 0 0 26
0 26 4 27
1
end_operator
begin_operator
board car4 loc14
1
15 5
2
0 0 0 26
0 26 5 27
1
end_operator
begin_operator
board car4 loc15
1
15 6
2
0 0 0 26
0 26 6 27
1
end_operator
begin_operator
board car4 loc16
1
15 7
2
0 0 0 26
0 26 7 27
1
end_operator
begin_operator
board car4 loc17
1
15 8
2
0 0 0 26
0 26 8 27
1
end_operator
begin_operator
board car4 loc18
1
15 9
2
0 0 0 26
0 26 9 27
1
end_operator
begin_operator
board car4 loc19
1
15 10
2
0 0 0 26
0 26 10 27
1
end_operator
begin_operator
board car4 loc2
1
15 11
2
0 0 0 26
0 26 11 27
1
end_operator
begin_operator
board car4 loc20
1
15 12
2
0 0 0 26
0 26 12 27
1
end_operator
begin_operator
board car4 loc21
1
15 13
2
0 0 0 26
0 26 13 27
1
end_operator
begin_operator
board car4 loc22
1
15 14
2
0 0 0 26
0 26 14 27
1
end_operator
begin_operator
board car4 loc23
1
15 15
2
0 0 0 26
0 26 15 27
1
end_operator
begin_operator
board car4 loc24
1
15 16
2
0 0 0 26
0 26 16 27
1
end_operator
begin_operator
board car4 loc25
1
15 17
2
0 0 0 26
0 26 17 27
1
end_operator
begin_operator
board car4 loc26
1
15 18
2
0 0 0 26
0 26 18 27
1
end_operator
begin_operator
board car4 loc27
1
15 19
2
0 0 0 26
0 26 19 27
1
end_operator
begin_operator
board car4 loc3
1
15 20
2
0 0 0 26
0 26 20 27
1
end_operator
begin_operator
board car4 loc4
1
15 21
2
0 0 0 26
0 26 21 27
1
end_operator
begin_operator
board car4 loc5
1
15 22
2
0 0 0 26
0 26 22 27
1
end_operator
begin_operator
board car4 loc6
1
15 23
2
0 0 0 26
0 26 23 27
1
end_operator
begin_operator
board car4 loc7
1
15 24
2
0 0 0 26
0 26 24 27
1
end_operator
begin_operator
board car4 loc8
1
15 25
2
0 0 0 26
0 26 25 27
1
end_operator
begin_operator
board car4 loc9
1
15 26
2
0 0 0 26
0 26 26 27
1
end_operator
begin_operator
board car5 loc1
1
15 0
2
0 0 0 27
0 29 0 27
1
end_operator
begin_operator
board car5 loc10
1
15 1
2
0 0 0 27
0 29 1 27
1
end_operator
begin_operator
board car5 loc11
1
15 2
2
0 0 0 27
0 29 2 27
1
end_operator
begin_operator
board car5 loc12
1
15 3
2
0 0 0 27
0 29 3 27
1
end_operator
begin_operator
board car5 loc13
1
15 4
2
0 0 0 27
0 29 4 27
1
end_operator
begin_operator
board car5 loc14
1
15 5
2
0 0 0 27
0 29 5 27
1
end_operator
begin_operator
board car5 loc15
1
15 6
2
0 0 0 27
0 29 6 27
1
end_operator
begin_operator
board car5 loc16
1
15 7
2
0 0 0 27
0 29 7 27
1
end_operator
begin_operator
board car5 loc17
1
15 8
2
0 0 0 27
0 29 8 27
1
end_operator
begin_operator
board car5 loc18
1
15 9
2
0 0 0 27
0 29 9 27
1
end_operator
begin_operator
board car5 loc19
1
15 10
2
0 0 0 27
0 29 10 27
1
end_operator
begin_operator
board car5 loc2
1
15 11
2
0 0 0 27
0 29 11 27
1
end_operator
begin_operator
board car5 loc20
1
15 12
2
0 0 0 27
0 29 12 27
1
end_operator
begin_operator
board car5 loc21
1
15 13
2
0 0 0 27
0 29 13 27
1
end_operator
begin_operator
board car5 loc22
1
15 14
2
0 0 0 27
0 29 14 27
1
end_operator
begin_operator
board car5 loc23
1
15 15
2
0 0 0 27
0 29 15 27
1
end_operator
begin_operator
board car5 loc24
1
15 16
2
0 0 0 27
0 29 16 27
1
end_operator
begin_operator
board car5 loc25
1
15 17
2
0 0 0 27
0 29 17 27
1
end_operator
begin_operator
board car5 loc26
1
15 18
2
0 0 0 27
0 29 18 27
1
end_operator
begin_operator
board car5 loc27
1
15 19
2
0 0 0 27
0 29 19 27
1
end_operator
begin_operator
board car5 loc3
1
15 20
2
0 0 0 27
0 29 20 27
1
end_operator
begin_operator
board car5 loc4
1
15 21
2
0 0 0 27
0 29 21 27
1
end_operator
begin_operator
board car5 loc5
1
15 22
2
0 0 0 27
0 29 22 27
1
end_operator
begin_operator
board car5 loc6
1
15 23
2
0 0 0 27
0 29 23 27
1
end_operator
begin_operator
board car5 loc7
1
15 24
2
0 0 0 27
0 29 24 27
1
end_operator
begin_operator
board car5 loc8
1
15 25
2
0 0 0 27
0 29 25 27
1
end_operator
begin_operator
board car5 loc9
1
15 26
2
0 0 0 27
0 29 26 27
1
end_operator
begin_operator
board car6 loc1
1
15 0
2
0 0 0 28
0 32 0 27
1
end_operator
begin_operator
board car6 loc10
1
15 1
2
0 0 0 28
0 32 1 27
1
end_operator
begin_operator
board car6 loc11
1
15 2
2
0 0 0 28
0 32 2 27
1
end_operator
begin_operator
board car6 loc12
1
15 3
2
0 0 0 28
0 32 3 27
1
end_operator
begin_operator
board car6 loc13
1
15 4
2
0 0 0 28
0 32 4 27
1
end_operator
begin_operator
board car6 loc14
1
15 5
2
0 0 0 28
0 32 5 27
1
end_operator
begin_operator
board car6 loc15
1
15 6
2
0 0 0 28
0 32 6 27
1
end_operator
begin_operator
board car6 loc16
1
15 7
2
0 0 0 28
0 32 7 27
1
end_operator
begin_operator
board car6 loc17
1
15 8
2
0 0 0 28
0 32 8 27
1
end_operator
begin_operator
board car6 loc18
1
15 9
2
0 0 0 28
0 32 9 27
1
end_operator
begin_operator
board car6 loc19
1
15 10
2
0 0 0 28
0 32 10 27
1
end_operator
begin_operator
board car6 loc2
1
15 11
2
0 0 0 28
0 32 11 27
1
end_operator
begin_operator
board car6 loc20
1
15 12
2
0 0 0 28
0 32 12 27
1
end_operator
begin_operator
board car6 loc21
1
15 13
2
0 0 0 28
0 32 13 27
1
end_operator
begin_operator
board car6 loc22
1
15 14
2
0 0 0 28
0 32 14 27
1
end_operator
begin_operator
board car6 loc23
1
15 15
2
0 0 0 28
0 32 15 27
1
end_operator
begin_operator
board car6 loc24
1
15 16
2
0 0 0 28
0 32 16 27
1
end_operator
begin_operator
board car6 loc25
1
15 17
2
0 0 0 28
0 32 17 27
1
end_operator
begin_operator
board car6 loc26
1
15 18
2
0 0 0 28
0 32 18 27
1
end_operator
begin_operator
board car6 loc27
1
15 19
2
0 0 0 28
0 32 19 27
1
end_operator
begin_operator
board car6 loc3
1
15 20
2
0 0 0 28
0 32 20 27
1
end_operator
begin_operator
board car6 loc4
1
15 21
2
0 0 0 28
0 32 21 27
1
end_operator
begin_operator
board car6 loc5
1
15 22
2
0 0 0 28
0 32 22 27
1
end_operator
begin_operator
board car6 loc6
1
15 23
2
0 0 0 28
0 32 23 27
1
end_operator
begin_operator
board car6 loc7
1
15 24
2
0 0 0 28
0 32 24 27
1
end_operator
begin_operator
board car6 loc8
1
15 25
2
0 0 0 28
0 32 25 27
1
end_operator
begin_operator
board car6 loc9
1
15 26
2
0 0 0 28
0 32 26 27
1
end_operator
begin_operator
board car7 loc1
1
15 0
2
0 0 0 29
0 3 0 27
1
end_operator
begin_operator
board car7 loc10
1
15 1
2
0 0 0 29
0 3 1 27
1
end_operator
begin_operator
board car7 loc11
1
15 2
2
0 0 0 29
0 3 2 27
1
end_operator
begin_operator
board car7 loc12
1
15 3
2
0 0 0 29
0 3 3 27
1
end_operator
begin_operator
board car7 loc13
1
15 4
2
0 0 0 29
0 3 4 27
1
end_operator
begin_operator
board car7 loc14
1
15 5
2
0 0 0 29
0 3 5 27
1
end_operator
begin_operator
board car7 loc15
1
15 6
2
0 0 0 29
0 3 6 27
1
end_operator
begin_operator
board car7 loc16
1
15 7
2
0 0 0 29
0 3 7 27
1
end_operator
begin_operator
board car7 loc17
1
15 8
2
0 0 0 29
0 3 8 27
1
end_operator
begin_operator
board car7 loc18
1
15 9
2
0 0 0 29
0 3 9 27
1
end_operator
begin_operator
board car7 loc19
1
15 10
2
0 0 0 29
0 3 10 27
1
end_operator
begin_operator
board car7 loc2
1
15 11
2
0 0 0 29
0 3 11 27
1
end_operator
begin_operator
board car7 loc20
1
15 12
2
0 0 0 29
0 3 12 27
1
end_operator
begin_operator
board car7 loc21
1
15 13
2
0 0 0 29
0 3 13 27
1
end_operator
begin_operator
board car7 loc22
1
15 14
2
0 0 0 29
0 3 14 27
1
end_operator
begin_operator
board car7 loc23
1
15 15
2
0 0 0 29
0 3 15 27
1
end_operator
begin_operator
board car7 loc24
1
15 16
2
0 0 0 29
0 3 16 27
1
end_operator
begin_operator
board car7 loc25
1
15 17
2
0 0 0 29
0 3 17 27
1
end_operator
begin_operator
board car7 loc26
1
15 18
2
0 0 0 29
0 3 18 27
1
end_operator
begin_operator
board car7 loc27
1
15 19
2
0 0 0 29
0 3 19 27
1
end_operator
begin_operator
board car7 loc3
1
15 20
2
0 0 0 29
0 3 20 27
1
end_operator
begin_operator
board car7 loc4
1
15 21
2
0 0 0 29
0 3 21 27
1
end_operator
begin_operator
board car7 loc5
1
15 22
2
0 0 0 29
0 3 22 27
1
end_operator
begin_operator
board car7 loc6
1
15 23
2
0 0 0 29
0 3 23 27
1
end_operator
begin_operator
board car7 loc7
1
15 24
2
0 0 0 29
0 3 24 27
1
end_operator
begin_operator
board car7 loc8
1
15 25
2
0 0 0 29
0 3 25 27
1
end_operator
begin_operator
board car7 loc9
1
15 26
2
0 0 0 29
0 3 26 27
1
end_operator
begin_operator
board car8 loc1
1
15 0
2
0 0 0 30
0 7 0 27
1
end_operator
begin_operator
board car8 loc10
1
15 1
2
0 0 0 30
0 7 1 27
1
end_operator
begin_operator
board car8 loc11
1
15 2
2
0 0 0 30
0 7 2 27
1
end_operator
begin_operator
board car8 loc12
1
15 3
2
0 0 0 30
0 7 3 27
1
end_operator
begin_operator
board car8 loc13
1
15 4
2
0 0 0 30
0 7 4 27
1
end_operator
begin_operator
board car8 loc14
1
15 5
2
0 0 0 30
0 7 5 27
1
end_operator
begin_operator
board car8 loc15
1
15 6
2
0 0 0 30
0 7 6 27
1
end_operator
begin_operator
board car8 loc16
1
15 7
2
0 0 0 30
0 7 7 27
1
end_operator
begin_operator
board car8 loc17
1
15 8
2
0 0 0 30
0 7 8 27
1
end_operator
begin_operator
board car8 loc18
1
15 9
2
0 0 0 30
0 7 9 27
1
end_operator
begin_operator
board car8 loc19
1
15 10
2
0 0 0 30
0 7 10 27
1
end_operator
begin_operator
board car8 loc2
1
15 11
2
0 0 0 30
0 7 11 27
1
end_operator
begin_operator
board car8 loc20
1
15 12
2
0 0 0 30
0 7 12 27
1
end_operator
begin_operator
board car8 loc21
1
15 13
2
0 0 0 30
0 7 13 27
1
end_operator
begin_operator
board car8 loc22
1
15 14
2
0 0 0 30
0 7 14 27
1
end_operator
begin_operator
board car8 loc23
1
15 15
2
0 0 0 30
0 7 15 27
1
end_operator
begin_operator
board car8 loc24
1
15 16
2
0 0 0 30
0 7 16 27
1
end_operator
begin_operator
board car8 loc25
1
15 17
2
0 0 0 30
0 7 17 27
1
end_operator
begin_operator
board car8 loc26
1
15 18
2
0 0 0 30
0 7 18 27
1
end_operator
begin_operator
board car8 loc27
1
15 19
2
0 0 0 30
0 7 19 27
1
end_operator
begin_operator
board car8 loc3
1
15 20
2
0 0 0 30
0 7 20 27
1
end_operator
begin_operator
board car8 loc4
1
15 21
2
0 0 0 30
0 7 21 27
1
end_operator
begin_operator
board car8 loc5
1
15 22
2
0 0 0 30
0 7 22 27
1
end_operator
begin_operator
board car8 loc6
1
15 23
2
0 0 0 30
0 7 23 27
1
end_operator
begin_operator
board car8 loc7
1
15 24
2
0 0 0 30
0 7 24 27
1
end_operator
begin_operator
board car8 loc8
1
15 25
2
0 0 0 30
0 7 25 27
1
end_operator
begin_operator
board car8 loc9
1
15 26
2
0 0 0 30
0 7 26 27
1
end_operator
begin_operator
board car9 loc1
1
15 0
2
0 0 0 31
0 11 0 27
1
end_operator
begin_operator
board car9 loc10
1
15 1
2
0 0 0 31
0 11 1 27
1
end_operator
begin_operator
board car9 loc11
1
15 2
2
0 0 0 31
0 11 2 27
1
end_operator
begin_operator
board car9 loc12
1
15 3
2
0 0 0 31
0 11 3 27
1
end_operator
begin_operator
board car9 loc13
1
15 4
2
0 0 0 31
0 11 4 27
1
end_operator
begin_operator
board car9 loc14
1
15 5
2
0 0 0 31
0 11 5 27
1
end_operator
begin_operator
board car9 loc15
1
15 6
2
0 0 0 31
0 11 6 27
1
end_operator
begin_operator
board car9 loc16
1
15 7
2
0 0 0 31
0 11 7 27
1
end_operator
begin_operator
board car9 loc17
1
15 8
2
0 0 0 31
0 11 8 27
1
end_operator
begin_operator
board car9 loc18
1
15 9
2
0 0 0 31
0 11 9 27
1
end_operator
begin_operator
board car9 loc19
1
15 10
2
0 0 0 31
0 11 10 27
1
end_operator
begin_operator
board car9 loc2
1
15 11
2
0 0 0 31
0 11 11 27
1
end_operator
begin_operator
board car9 loc20
1
15 12
2
0 0 0 31
0 11 12 27
1
end_operator
begin_operator
board car9 loc21
1
15 13
2
0 0 0 31
0 11 13 27
1
end_operator
begin_operator
board car9 loc22
1
15 14
2
0 0 0 31
0 11 14 27
1
end_operator
begin_operator
board car9 loc23
1
15 15
2
0 0 0 31
0 11 15 27
1
end_operator
begin_operator
board car9 loc24
1
15 16
2
0 0 0 31
0 11 16 27
1
end_operator
begin_operator
board car9 loc25
1
15 17
2
0 0 0 31
0 11 17 27
1
end_operator
begin_operator
board car9 loc26
1
15 18
2
0 0 0 31
0 11 18 27
1
end_operator
begin_operator
board car9 loc27
1
15 19
2
0 0 0 31
0 11 19 27
1
end_operator
begin_operator
board car9 loc3
1
15 20
2
0 0 0 31
0 11 20 27
1
end_operator
begin_operator
board car9 loc4
1
15 21
2
0 0 0 31
0 11 21 27
1
end_operator
begin_operator
board car9 loc5
1
15 22
2
0 0 0 31
0 11 22 27
1
end_operator
begin_operator
board car9 loc6
1
15 23
2
0 0 0 31
0 11 23 27
1
end_operator
begin_operator
board car9 loc7
1
15 24
2
0 0 0 31
0 11 24 27
1
end_operator
begin_operator
board car9 loc8
1
15 25
2
0 0 0 31
0 11 25 27
1
end_operator
begin_operator
board car9 loc9
1
15 26
2
0 0 0 31
0 11 26 27
1
end_operator
begin_operator
debark car1 loc1
1
15 0
2
0 0 1 0
0 4 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
15 1
2
0 0 1 0
0 4 -1 1
1
end_operator
begin_operator
debark car1 loc11
1
15 2
2
0 0 1 0
0 4 -1 2
1
end_operator
begin_operator
debark car1 loc12
1
15 3
2
0 0 1 0
0 4 -1 3
1
end_operator
begin_operator
debark car1 loc13
1
15 4
2
0 0 1 0
0 4 -1 4
1
end_operator
begin_operator
debark car1 loc14
1
15 5
2
0 0 1 0
0 4 -1 5
1
end_operator
begin_operator
debark car1 loc15
1
15 6
2
0 0 1 0
0 4 -1 6
1
end_operator
begin_operator
debark car1 loc16
1
15 7
2
0 0 1 0
0 4 -1 7
1
end_operator
begin_operator
debark car1 loc17
1
15 8
2
0 0 1 0
0 4 -1 8
1
end_operator
begin_operator
debark car1 loc18
1
15 9
2
0 0 1 0
0 4 -1 9
1
end_operator
begin_operator
debark car1 loc19
1
15 10
2
0 0 1 0
0 4 -1 10
1
end_operator
begin_operator
debark car1 loc2
1
15 11
2
0 0 1 0
0 4 -1 11
1
end_operator
begin_operator
debark car1 loc20
1
15 12
2
0 0 1 0
0 4 -1 12
1
end_operator
begin_operator
debark car1 loc21
1
15 13
2
0 0 1 0
0 4 -1 13
1
end_operator
begin_operator
debark car1 loc22
1
15 14
2
0 0 1 0
0 4 -1 14
1
end_operator
begin_operator
debark car1 loc23
1
15 15
2
0 0 1 0
0 4 -1 15
1
end_operator
begin_operator
debark car1 loc24
1
15 16
2
0 0 1 0
0 4 -1 16
1
end_operator
begin_operator
debark car1 loc25
1
15 17
2
0 0 1 0
0 4 -1 17
1
end_operator
begin_operator
debark car1 loc26
1
15 18
2
0 0 1 0
0 4 -1 18
1
end_operator
begin_operator
debark car1 loc27
1
15 19
2
0 0 1 0
0 4 -1 19
1
end_operator
begin_operator
debark car1 loc3
1
15 20
2
0 0 1 0
0 4 -1 20
1
end_operator
begin_operator
debark car1 loc4
1
15 21
2
0 0 1 0
0 4 -1 21
1
end_operator
begin_operator
debark car1 loc5
1
15 22
2
0 0 1 0
0 4 -1 22
1
end_operator
begin_operator
debark car1 loc6
1
15 23
2
0 0 1 0
0 4 -1 23
1
end_operator
begin_operator
debark car1 loc7
1
15 24
2
0 0 1 0
0 4 -1 24
1
end_operator
begin_operator
debark car1 loc8
1
15 25
2
0 0 1 0
0 4 -1 25
1
end_operator
begin_operator
debark car1 loc9
1
15 26
2
0 0 1 0
0 4 -1 26
1
end_operator
begin_operator
debark car10 loc1
1
15 0
2
0 0 2 0
0 8 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
15 1
2
0 0 2 0
0 8 -1 1
1
end_operator
begin_operator
debark car10 loc11
1
15 2
2
0 0 2 0
0 8 -1 2
1
end_operator
begin_operator
debark car10 loc12
1
15 3
2
0 0 2 0
0 8 -1 3
1
end_operator
begin_operator
debark car10 loc13
1
15 4
2
0 0 2 0
0 8 -1 4
1
end_operator
begin_operator
debark car10 loc14
1
15 5
2
0 0 2 0
0 8 -1 5
1
end_operator
begin_operator
debark car10 loc15
1
15 6
2
0 0 2 0
0 8 -1 6
1
end_operator
begin_operator
debark car10 loc16
1
15 7
2
0 0 2 0
0 8 -1 7
1
end_operator
begin_operator
debark car10 loc17
1
15 8
2
0 0 2 0
0 8 -1 8
1
end_operator
begin_operator
debark car10 loc18
1
15 9
2
0 0 2 0
0 8 -1 9
1
end_operator
begin_operator
debark car10 loc19
1
15 10
2
0 0 2 0
0 8 -1 10
1
end_operator
begin_operator
debark car10 loc2
1
15 11
2
0 0 2 0
0 8 -1 11
1
end_operator
begin_operator
debark car10 loc20
1
15 12
2
0 0 2 0
0 8 -1 12
1
end_operator
begin_operator
debark car10 loc21
1
15 13
2
0 0 2 0
0 8 -1 13
1
end_operator
begin_operator
debark car10 loc22
1
15 14
2
0 0 2 0
0 8 -1 14
1
end_operator
begin_operator
debark car10 loc23
1
15 15
2
0 0 2 0
0 8 -1 15
1
end_operator
begin_operator
debark car10 loc24
1
15 16
2
0 0 2 0
0 8 -1 16
1
end_operator
begin_operator
debark car10 loc25
1
15 17
2
0 0 2 0
0 8 -1 17
1
end_operator
begin_operator
debark car10 loc26
1
15 18
2
0 0 2 0
0 8 -1 18
1
end_operator
begin_operator
debark car10 loc27
1
15 19
2
0 0 2 0
0 8 -1 19
1
end_operator
begin_operator
debark car10 loc3
1
15 20
2
0 0 2 0
0 8 -1 20
1
end_operator
begin_operator
debark car10 loc4
1
15 21
2
0 0 2 0
0 8 -1 21
1
end_operator
begin_operator
debark car10 loc5
1
15 22
2
0 0 2 0
0 8 -1 22
1
end_operator
begin_operator
debark car10 loc6
1
15 23
2
0 0 2 0
0 8 -1 23
1
end_operator
begin_operator
debark car10 loc7
1
15 24
2
0 0 2 0
0 8 -1 24
1
end_operator
begin_operator
debark car10 loc8
1
15 25
2
0 0 2 0
0 8 -1 25
1
end_operator
begin_operator
debark car10 loc9
1
15 26
2
0 0 2 0
0 8 -1 26
1
end_operator
begin_operator
debark car11 loc1
1
15 0
2
0 0 3 0
0 12 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
15 1
2
0 0 3 0
0 12 -1 1
1
end_operator
begin_operator
debark car11 loc11
1
15 2
2
0 0 3 0
0 12 -1 2
1
end_operator
begin_operator
debark car11 loc12
1
15 3
2
0 0 3 0
0 12 -1 3
1
end_operator
begin_operator
debark car11 loc13
1
15 4
2
0 0 3 0
0 12 -1 4
1
end_operator
begin_operator
debark car11 loc14
1
15 5
2
0 0 3 0
0 12 -1 5
1
end_operator
begin_operator
debark car11 loc15
1
15 6
2
0 0 3 0
0 12 -1 6
1
end_operator
begin_operator
debark car11 loc16
1
15 7
2
0 0 3 0
0 12 -1 7
1
end_operator
begin_operator
debark car11 loc17
1
15 8
2
0 0 3 0
0 12 -1 8
1
end_operator
begin_operator
debark car11 loc18
1
15 9
2
0 0 3 0
0 12 -1 9
1
end_operator
begin_operator
debark car11 loc19
1
15 10
2
0 0 3 0
0 12 -1 10
1
end_operator
begin_operator
debark car11 loc2
1
15 11
2
0 0 3 0
0 12 -1 11
1
end_operator
begin_operator
debark car11 loc20
1
15 12
2
0 0 3 0
0 12 -1 12
1
end_operator
begin_operator
debark car11 loc21
1
15 13
2
0 0 3 0
0 12 -1 13
1
end_operator
begin_operator
debark car11 loc22
1
15 14
2
0 0 3 0
0 12 -1 14
1
end_operator
begin_operator
debark car11 loc23
1
15 15
2
0 0 3 0
0 12 -1 15
1
end_operator
begin_operator
debark car11 loc24
1
15 16
2
0 0 3 0
0 12 -1 16
1
end_operator
begin_operator
debark car11 loc25
1
15 17
2
0 0 3 0
0 12 -1 17
1
end_operator
begin_operator
debark car11 loc26
1
15 18
2
0 0 3 0
0 12 -1 18
1
end_operator
begin_operator
debark car11 loc27
1
15 19
2
0 0 3 0
0 12 -1 19
1
end_operator
begin_operator
debark car11 loc3
1
15 20
2
0 0 3 0
0 12 -1 20
1
end_operator
begin_operator
debark car11 loc4
1
15 21
2
0 0 3 0
0 12 -1 21
1
end_operator
begin_operator
debark car11 loc5
1
15 22
2
0 0 3 0
0 12 -1 22
1
end_operator
begin_operator
debark car11 loc6
1
15 23
2
0 0 3 0
0 12 -1 23
1
end_operator
begin_operator
debark car11 loc7
1
15 24
2
0 0 3 0
0 12 -1 24
1
end_operator
begin_operator
debark car11 loc8
1
15 25
2
0 0 3 0
0 12 -1 25
1
end_operator
begin_operator
debark car11 loc9
1
15 26
2
0 0 3 0
0 12 -1 26
1
end_operator
begin_operator
debark car12 loc1
1
15 0
2
0 0 4 0
0 16 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
15 1
2
0 0 4 0
0 16 -1 1
1
end_operator
begin_operator
debark car12 loc11
1
15 2
2
0 0 4 0
0 16 -1 2
1
end_operator
begin_operator
debark car12 loc12
1
15 3
2
0 0 4 0
0 16 -1 3
1
end_operator
begin_operator
debark car12 loc13
1
15 4
2
0 0 4 0
0 16 -1 4
1
end_operator
begin_operator
debark car12 loc14
1
15 5
2
0 0 4 0
0 16 -1 5
1
end_operator
begin_operator
debark car12 loc15
1
15 6
2
0 0 4 0
0 16 -1 6
1
end_operator
begin_operator
debark car12 loc16
1
15 7
2
0 0 4 0
0 16 -1 7
1
end_operator
begin_operator
debark car12 loc17
1
15 8
2
0 0 4 0
0 16 -1 8
1
end_operator
begin_operator
debark car12 loc18
1
15 9
2
0 0 4 0
0 16 -1 9
1
end_operator
begin_operator
debark car12 loc19
1
15 10
2
0 0 4 0
0 16 -1 10
1
end_operator
begin_operator
debark car12 loc2
1
15 11
2
0 0 4 0
0 16 -1 11
1
end_operator
begin_operator
debark car12 loc20
1
15 12
2
0 0 4 0
0 16 -1 12
1
end_operator
begin_operator
debark car12 loc21
1
15 13
2
0 0 4 0
0 16 -1 13
1
end_operator
begin_operator
debark car12 loc22
1
15 14
2
0 0 4 0
0 16 -1 14
1
end_operator
begin_operator
debark car12 loc23
1
15 15
2
0 0 4 0
0 16 -1 15
1
end_operator
begin_operator
debark car12 loc24
1
15 16
2
0 0 4 0
0 16 -1 16
1
end_operator
begin_operator
debark car12 loc25
1
15 17
2
0 0 4 0
0 16 -1 17
1
end_operator
begin_operator
debark car12 loc26
1
15 18
2
0 0 4 0
0 16 -1 18
1
end_operator
begin_operator
debark car12 loc27
1
15 19
2
0 0 4 0
0 16 -1 19
1
end_operator
begin_operator
debark car12 loc3
1
15 20
2
0 0 4 0
0 16 -1 20
1
end_operator
begin_operator
debark car12 loc4
1
15 21
2
0 0 4 0
0 16 -1 21
1
end_operator
begin_operator
debark car12 loc5
1
15 22
2
0 0 4 0
0 16 -1 22
1
end_operator
begin_operator
debark car12 loc6
1
15 23
2
0 0 4 0
0 16 -1 23
1
end_operator
begin_operator
debark car12 loc7
1
15 24
2
0 0 4 0
0 16 -1 24
1
end_operator
begin_operator
debark car12 loc8
1
15 25
2
0 0 4 0
0 16 -1 25
1
end_operator
begin_operator
debark car12 loc9
1
15 26
2
0 0 4 0
0 16 -1 26
1
end_operator
begin_operator
debark car13 loc1
1
15 0
2
0 0 5 0
0 19 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
15 1
2
0 0 5 0
0 19 -1 1
1
end_operator
begin_operator
debark car13 loc11
1
15 2
2
0 0 5 0
0 19 -1 2
1
end_operator
begin_operator
debark car13 loc12
1
15 3
2
0 0 5 0
0 19 -1 3
1
end_operator
begin_operator
debark car13 loc13
1
15 4
2
0 0 5 0
0 19 -1 4
1
end_operator
begin_operator
debark car13 loc14
1
15 5
2
0 0 5 0
0 19 -1 5
1
end_operator
begin_operator
debark car13 loc15
1
15 6
2
0 0 5 0
0 19 -1 6
1
end_operator
begin_operator
debark car13 loc16
1
15 7
2
0 0 5 0
0 19 -1 7
1
end_operator
begin_operator
debark car13 loc17
1
15 8
2
0 0 5 0
0 19 -1 8
1
end_operator
begin_operator
debark car13 loc18
1
15 9
2
0 0 5 0
0 19 -1 9
1
end_operator
begin_operator
debark car13 loc19
1
15 10
2
0 0 5 0
0 19 -1 10
1
end_operator
begin_operator
debark car13 loc2
1
15 11
2
0 0 5 0
0 19 -1 11
1
end_operator
begin_operator
debark car13 loc20
1
15 12
2
0 0 5 0
0 19 -1 12
1
end_operator
begin_operator
debark car13 loc21
1
15 13
2
0 0 5 0
0 19 -1 13
1
end_operator
begin_operator
debark car13 loc22
1
15 14
2
0 0 5 0
0 19 -1 14
1
end_operator
begin_operator
debark car13 loc23
1
15 15
2
0 0 5 0
0 19 -1 15
1
end_operator
begin_operator
debark car13 loc24
1
15 16
2
0 0 5 0
0 19 -1 16
1
end_operator
begin_operator
debark car13 loc25
1
15 17
2
0 0 5 0
0 19 -1 17
1
end_operator
begin_operator
debark car13 loc26
1
15 18
2
0 0 5 0
0 19 -1 18
1
end_operator
begin_operator
debark car13 loc27
1
15 19
2
0 0 5 0
0 19 -1 19
1
end_operator
begin_operator
debark car13 loc3
1
15 20
2
0 0 5 0
0 19 -1 20
1
end_operator
begin_operator
debark car13 loc4
1
15 21
2
0 0 5 0
0 19 -1 21
1
end_operator
begin_operator
debark car13 loc5
1
15 22
2
0 0 5 0
0 19 -1 22
1
end_operator
begin_operator
debark car13 loc6
1
15 23
2
0 0 5 0
0 19 -1 23
1
end_operator
begin_operator
debark car13 loc7
1
15 24
2
0 0 5 0
0 19 -1 24
1
end_operator
begin_operator
debark car13 loc8
1
15 25
2
0 0 5 0
0 19 -1 25
1
end_operator
begin_operator
debark car13 loc9
1
15 26
2
0 0 5 0
0 19 -1 26
1
end_operator
begin_operator
debark car14 loc1
1
15 0
2
0 0 6 0
0 22 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
15 1
2
0 0 6 0
0 22 -1 1
1
end_operator
begin_operator
debark car14 loc11
1
15 2
2
0 0 6 0
0 22 -1 2
1
end_operator
begin_operator
debark car14 loc12
1
15 3
2
0 0 6 0
0 22 -1 3
1
end_operator
begin_operator
debark car14 loc13
1
15 4
2
0 0 6 0
0 22 -1 4
1
end_operator
begin_operator
debark car14 loc14
1
15 5
2
0 0 6 0
0 22 -1 5
1
end_operator
begin_operator
debark car14 loc15
1
15 6
2
0 0 6 0
0 22 -1 6
1
end_operator
begin_operator
debark car14 loc16
1
15 7
2
0 0 6 0
0 22 -1 7
1
end_operator
begin_operator
debark car14 loc17
1
15 8
2
0 0 6 0
0 22 -1 8
1
end_operator
begin_operator
debark car14 loc18
1
15 9
2
0 0 6 0
0 22 -1 9
1
end_operator
begin_operator
debark car14 loc19
1
15 10
2
0 0 6 0
0 22 -1 10
1
end_operator
begin_operator
debark car14 loc2
1
15 11
2
0 0 6 0
0 22 -1 11
1
end_operator
begin_operator
debark car14 loc20
1
15 12
2
0 0 6 0
0 22 -1 12
1
end_operator
begin_operator
debark car14 loc21
1
15 13
2
0 0 6 0
0 22 -1 13
1
end_operator
begin_operator
debark car14 loc22
1
15 14
2
0 0 6 0
0 22 -1 14
1
end_operator
begin_operator
debark car14 loc23
1
15 15
2
0 0 6 0
0 22 -1 15
1
end_operator
begin_operator
debark car14 loc24
1
15 16
2
0 0 6 0
0 22 -1 16
1
end_operator
begin_operator
debark car14 loc25
1
15 17
2
0 0 6 0
0 22 -1 17
1
end_operator
begin_operator
debark car14 loc26
1
15 18
2
0 0 6 0
0 22 -1 18
1
end_operator
begin_operator
debark car14 loc27
1
15 19
2
0 0 6 0
0 22 -1 19
1
end_operator
begin_operator
debark car14 loc3
1
15 20
2
0 0 6 0
0 22 -1 20
1
end_operator
begin_operator
debark car14 loc4
1
15 21
2
0 0 6 0
0 22 -1 21
1
end_operator
begin_operator
debark car14 loc5
1
15 22
2
0 0 6 0
0 22 -1 22
1
end_operator
begin_operator
debark car14 loc6
1
15 23
2
0 0 6 0
0 22 -1 23
1
end_operator
begin_operator
debark car14 loc7
1
15 24
2
0 0 6 0
0 22 -1 24
1
end_operator
begin_operator
debark car14 loc8
1
15 25
2
0 0 6 0
0 22 -1 25
1
end_operator
begin_operator
debark car14 loc9
1
15 26
2
0 0 6 0
0 22 -1 26
1
end_operator
begin_operator
debark car15 loc1
1
15 0
2
0 0 7 0
0 25 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
15 1
2
0 0 7 0
0 25 -1 1
1
end_operator
begin_operator
debark car15 loc11
1
15 2
2
0 0 7 0
0 25 -1 2
1
end_operator
begin_operator
debark car15 loc12
1
15 3
2
0 0 7 0
0 25 -1 3
1
end_operator
begin_operator
debark car15 loc13
1
15 4
2
0 0 7 0
0 25 -1 4
1
end_operator
begin_operator
debark car15 loc14
1
15 5
2
0 0 7 0
0 25 -1 5
1
end_operator
begin_operator
debark car15 loc15
1
15 6
2
0 0 7 0
0 25 -1 6
1
end_operator
begin_operator
debark car15 loc16
1
15 7
2
0 0 7 0
0 25 -1 7
1
end_operator
begin_operator
debark car15 loc17
1
15 8
2
0 0 7 0
0 25 -1 8
1
end_operator
begin_operator
debark car15 loc18
1
15 9
2
0 0 7 0
0 25 -1 9
1
end_operator
begin_operator
debark car15 loc19
1
15 10
2
0 0 7 0
0 25 -1 10
1
end_operator
begin_operator
debark car15 loc2
1
15 11
2
0 0 7 0
0 25 -1 11
1
end_operator
begin_operator
debark car15 loc20
1
15 12
2
0 0 7 0
0 25 -1 12
1
end_operator
begin_operator
debark car15 loc21
1
15 13
2
0 0 7 0
0 25 -1 13
1
end_operator
begin_operator
debark car15 loc22
1
15 14
2
0 0 7 0
0 25 -1 14
1
end_operator
begin_operator
debark car15 loc23
1
15 15
2
0 0 7 0
0 25 -1 15
1
end_operator
begin_operator
debark car15 loc24
1
15 16
2
0 0 7 0
0 25 -1 16
1
end_operator
begin_operator
debark car15 loc25
1
15 17
2
0 0 7 0
0 25 -1 17
1
end_operator
begin_operator
debark car15 loc26
1
15 18
2
0 0 7 0
0 25 -1 18
1
end_operator
begin_operator
debark car15 loc27
1
15 19
2
0 0 7 0
0 25 -1 19
1
end_operator
begin_operator
debark car15 loc3
1
15 20
2
0 0 7 0
0 25 -1 20
1
end_operator
begin_operator
debark car15 loc4
1
15 21
2
0 0 7 0
0 25 -1 21
1
end_operator
begin_operator
debark car15 loc5
1
15 22
2
0 0 7 0
0 25 -1 22
1
end_operator
begin_operator
debark car15 loc6
1
15 23
2
0 0 7 0
0 25 -1 23
1
end_operator
begin_operator
debark car15 loc7
1
15 24
2
0 0 7 0
0 25 -1 24
1
end_operator
begin_operator
debark car15 loc8
1
15 25
2
0 0 7 0
0 25 -1 25
1
end_operator
begin_operator
debark car15 loc9
1
15 26
2
0 0 7 0
0 25 -1 26
1
end_operator
begin_operator
debark car16 loc1
1
15 0
2
0 0 8 0
0 28 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
15 1
2
0 0 8 0
0 28 -1 1
1
end_operator
begin_operator
debark car16 loc11
1
15 2
2
0 0 8 0
0 28 -1 2
1
end_operator
begin_operator
debark car16 loc12
1
15 3
2
0 0 8 0
0 28 -1 3
1
end_operator
begin_operator
debark car16 loc13
1
15 4
2
0 0 8 0
0 28 -1 4
1
end_operator
begin_operator
debark car16 loc14
1
15 5
2
0 0 8 0
0 28 -1 5
1
end_operator
begin_operator
debark car16 loc15
1
15 6
2
0 0 8 0
0 28 -1 6
1
end_operator
begin_operator
debark car16 loc16
1
15 7
2
0 0 8 0
0 28 -1 7
1
end_operator
begin_operator
debark car16 loc17
1
15 8
2
0 0 8 0
0 28 -1 8
1
end_operator
begin_operator
debark car16 loc18
1
15 9
2
0 0 8 0
0 28 -1 9
1
end_operator
begin_operator
debark car16 loc19
1
15 10
2
0 0 8 0
0 28 -1 10
1
end_operator
begin_operator
debark car16 loc2
1
15 11
2
0 0 8 0
0 28 -1 11
1
end_operator
begin_operator
debark car16 loc20
1
15 12
2
0 0 8 0
0 28 -1 12
1
end_operator
begin_operator
debark car16 loc21
1
15 13
2
0 0 8 0
0 28 -1 13
1
end_operator
begin_operator
debark car16 loc22
1
15 14
2
0 0 8 0
0 28 -1 14
1
end_operator
begin_operator
debark car16 loc23
1
15 15
2
0 0 8 0
0 28 -1 15
1
end_operator
begin_operator
debark car16 loc24
1
15 16
2
0 0 8 0
0 28 -1 16
1
end_operator
begin_operator
debark car16 loc25
1
15 17
2
0 0 8 0
0 28 -1 17
1
end_operator
begin_operator
debark car16 loc26
1
15 18
2
0 0 8 0
0 28 -1 18
1
end_operator
begin_operator
debark car16 loc27
1
15 19
2
0 0 8 0
0 28 -1 19
1
end_operator
begin_operator
debark car16 loc3
1
15 20
2
0 0 8 0
0 28 -1 20
1
end_operator
begin_operator
debark car16 loc4
1
15 21
2
0 0 8 0
0 28 -1 21
1
end_operator
begin_operator
debark car16 loc5
1
15 22
2
0 0 8 0
0 28 -1 22
1
end_operator
begin_operator
debark car16 loc6
1
15 23
2
0 0 8 0
0 28 -1 23
1
end_operator
begin_operator
debark car16 loc7
1
15 24
2
0 0 8 0
0 28 -1 24
1
end_operator
begin_operator
debark car16 loc8
1
15 25
2
0 0 8 0
0 28 -1 25
1
end_operator
begin_operator
debark car16 loc9
1
15 26
2
0 0 8 0
0 28 -1 26
1
end_operator
begin_operator
debark car17 loc1
1
15 0
2
0 0 9 0
0 31 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
15 1
2
0 0 9 0
0 31 -1 1
1
end_operator
begin_operator
debark car17 loc11
1
15 2
2
0 0 9 0
0 31 -1 2
1
end_operator
begin_operator
debark car17 loc12
1
15 3
2
0 0 9 0
0 31 -1 3
1
end_operator
begin_operator
debark car17 loc13
1
15 4
2
0 0 9 0
0 31 -1 4
1
end_operator
begin_operator
debark car17 loc14
1
15 5
2
0 0 9 0
0 31 -1 5
1
end_operator
begin_operator
debark car17 loc15
1
15 6
2
0 0 9 0
0 31 -1 6
1
end_operator
begin_operator
debark car17 loc16
1
15 7
2
0 0 9 0
0 31 -1 7
1
end_operator
begin_operator
debark car17 loc17
1
15 8
2
0 0 9 0
0 31 -1 8
1
end_operator
begin_operator
debark car17 loc18
1
15 9
2
0 0 9 0
0 31 -1 9
1
end_operator
begin_operator
debark car17 loc19
1
15 10
2
0 0 9 0
0 31 -1 10
1
end_operator
begin_operator
debark car17 loc2
1
15 11
2
0 0 9 0
0 31 -1 11
1
end_operator
begin_operator
debark car17 loc20
1
15 12
2
0 0 9 0
0 31 -1 12
1
end_operator
begin_operator
debark car17 loc21
1
15 13
2
0 0 9 0
0 31 -1 13
1
end_operator
begin_operator
debark car17 loc22
1
15 14
2
0 0 9 0
0 31 -1 14
1
end_operator
begin_operator
debark car17 loc23
1
15 15
2
0 0 9 0
0 31 -1 15
1
end_operator
begin_operator
debark car17 loc24
1
15 16
2
0 0 9 0
0 31 -1 16
1
end_operator
begin_operator
debark car17 loc25
1
15 17
2
0 0 9 0
0 31 -1 17
1
end_operator
begin_operator
debark car17 loc26
1
15 18
2
0 0 9 0
0 31 -1 18
1
end_operator
begin_operator
debark car17 loc27
1
15 19
2
0 0 9 0
0 31 -1 19
1
end_operator
begin_operator
debark car17 loc3
1
15 20
2
0 0 9 0
0 31 -1 20
1
end_operator
begin_operator
debark car17 loc4
1
15 21
2
0 0 9 0
0 31 -1 21
1
end_operator
begin_operator
debark car17 loc5
1
15 22
2
0 0 9 0
0 31 -1 22
1
end_operator
begin_operator
debark car17 loc6
1
15 23
2
0 0 9 0
0 31 -1 23
1
end_operator
begin_operator
debark car17 loc7
1
15 24
2
0 0 9 0
0 31 -1 24
1
end_operator
begin_operator
debark car17 loc8
1
15 25
2
0 0 9 0
0 31 -1 25
1
end_operator
begin_operator
debark car17 loc9
1
15 26
2
0 0 9 0
0 31 -1 26
1
end_operator
begin_operator
debark car18 loc1
1
15 0
2
0 0 10 0
0 2 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
15 1
2
0 0 10 0
0 2 -1 1
1
end_operator
begin_operator
debark car18 loc11
1
15 2
2
0 0 10 0
0 2 -1 2
1
end_operator
begin_operator
debark car18 loc12
1
15 3
2
0 0 10 0
0 2 -1 3
1
end_operator
begin_operator
debark car18 loc13
1
15 4
2
0 0 10 0
0 2 -1 4
1
end_operator
begin_operator
debark car18 loc14
1
15 5
2
0 0 10 0
0 2 -1 5
1
end_operator
begin_operator
debark car18 loc15
1
15 6
2
0 0 10 0
0 2 -1 6
1
end_operator
begin_operator
debark car18 loc16
1
15 7
2
0 0 10 0
0 2 -1 7
1
end_operator
begin_operator
debark car18 loc17
1
15 8
2
0 0 10 0
0 2 -1 8
1
end_operator
begin_operator
debark car18 loc18
1
15 9
2
0 0 10 0
0 2 -1 9
1
end_operator
begin_operator
debark car18 loc19
1
15 10
2
0 0 10 0
0 2 -1 10
1
end_operator
begin_operator
debark car18 loc2
1
15 11
2
0 0 10 0
0 2 -1 11
1
end_operator
begin_operator
debark car18 loc20
1
15 12
2
0 0 10 0
0 2 -1 12
1
end_operator
begin_operator
debark car18 loc21
1
15 13
2
0 0 10 0
0 2 -1 13
1
end_operator
begin_operator
debark car18 loc22
1
15 14
2
0 0 10 0
0 2 -1 14
1
end_operator
begin_operator
debark car18 loc23
1
15 15
2
0 0 10 0
0 2 -1 15
1
end_operator
begin_operator
debark car18 loc24
1
15 16
2
0 0 10 0
0 2 -1 16
1
end_operator
begin_operator
debark car18 loc25
1
15 17
2
0 0 10 0
0 2 -1 17
1
end_operator
begin_operator
debark car18 loc26
1
15 18
2
0 0 10 0
0 2 -1 18
1
end_operator
begin_operator
debark car18 loc27
1
15 19
2
0 0 10 0
0 2 -1 19
1
end_operator
begin_operator
debark car18 loc3
1
15 20
2
0 0 10 0
0 2 -1 20
1
end_operator
begin_operator
debark car18 loc4
1
15 21
2
0 0 10 0
0 2 -1 21
1
end_operator
begin_operator
debark car18 loc5
1
15 22
2
0 0 10 0
0 2 -1 22
1
end_operator
begin_operator
debark car18 loc6
1
15 23
2
0 0 10 0
0 2 -1 23
1
end_operator
begin_operator
debark car18 loc7
1
15 24
2
0 0 10 0
0 2 -1 24
1
end_operator
begin_operator
debark car18 loc8
1
15 25
2
0 0 10 0
0 2 -1 25
1
end_operator
begin_operator
debark car18 loc9
1
15 26
2
0 0 10 0
0 2 -1 26
1
end_operator
begin_operator
debark car19 loc1
1
15 0
2
0 0 11 0
0 6 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
15 1
2
0 0 11 0
0 6 -1 1
1
end_operator
begin_operator
debark car19 loc11
1
15 2
2
0 0 11 0
0 6 -1 2
1
end_operator
begin_operator
debark car19 loc12
1
15 3
2
0 0 11 0
0 6 -1 3
1
end_operator
begin_operator
debark car19 loc13
1
15 4
2
0 0 11 0
0 6 -1 4
1
end_operator
begin_operator
debark car19 loc14
1
15 5
2
0 0 11 0
0 6 -1 5
1
end_operator
begin_operator
debark car19 loc15
1
15 6
2
0 0 11 0
0 6 -1 6
1
end_operator
begin_operator
debark car19 loc16
1
15 7
2
0 0 11 0
0 6 -1 7
1
end_operator
begin_operator
debark car19 loc17
1
15 8
2
0 0 11 0
0 6 -1 8
1
end_operator
begin_operator
debark car19 loc18
1
15 9
2
0 0 11 0
0 6 -1 9
1
end_operator
begin_operator
debark car19 loc19
1
15 10
2
0 0 11 0
0 6 -1 10
1
end_operator
begin_operator
debark car19 loc2
1
15 11
2
0 0 11 0
0 6 -1 11
1
end_operator
begin_operator
debark car19 loc20
1
15 12
2
0 0 11 0
0 6 -1 12
1
end_operator
begin_operator
debark car19 loc21
1
15 13
2
0 0 11 0
0 6 -1 13
1
end_operator
begin_operator
debark car19 loc22
1
15 14
2
0 0 11 0
0 6 -1 14
1
end_operator
begin_operator
debark car19 loc23
1
15 15
2
0 0 11 0
0 6 -1 15
1
end_operator
begin_operator
debark car19 loc24
1
15 16
2
0 0 11 0
0 6 -1 16
1
end_operator
begin_operator
debark car19 loc25
1
15 17
2
0 0 11 0
0 6 -1 17
1
end_operator
begin_operator
debark car19 loc26
1
15 18
2
0 0 11 0
0 6 -1 18
1
end_operator
begin_operator
debark car19 loc27
1
15 19
2
0 0 11 0
0 6 -1 19
1
end_operator
begin_operator
debark car19 loc3
1
15 20
2
0 0 11 0
0 6 -1 20
1
end_operator
begin_operator
debark car19 loc4
1
15 21
2
0 0 11 0
0 6 -1 21
1
end_operator
begin_operator
debark car19 loc5
1
15 22
2
0 0 11 0
0 6 -1 22
1
end_operator
begin_operator
debark car19 loc6
1
15 23
2
0 0 11 0
0 6 -1 23
1
end_operator
begin_operator
debark car19 loc7
1
15 24
2
0 0 11 0
0 6 -1 24
1
end_operator
begin_operator
debark car19 loc8
1
15 25
2
0 0 11 0
0 6 -1 25
1
end_operator
begin_operator
debark car19 loc9
1
15 26
2
0 0 11 0
0 6 -1 26
1
end_operator
begin_operator
debark car2 loc1
1
15 0
2
0 0 12 0
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
15 1
2
0 0 12 0
0 10 -1 1
1
end_operator
begin_operator
debark car2 loc11
1
15 2
2
0 0 12 0
0 10 -1 2
1
end_operator
begin_operator
debark car2 loc12
1
15 3
2
0 0 12 0
0 10 -1 3
1
end_operator
begin_operator
debark car2 loc13
1
15 4
2
0 0 12 0
0 10 -1 4
1
end_operator
begin_operator
debark car2 loc14
1
15 5
2
0 0 12 0
0 10 -1 5
1
end_operator
begin_operator
debark car2 loc15
1
15 6
2
0 0 12 0
0 10 -1 6
1
end_operator
begin_operator
debark car2 loc16
1
15 7
2
0 0 12 0
0 10 -1 7
1
end_operator
begin_operator
debark car2 loc17
1
15 8
2
0 0 12 0
0 10 -1 8
1
end_operator
begin_operator
debark car2 loc18
1
15 9
2
0 0 12 0
0 10 -1 9
1
end_operator
begin_operator
debark car2 loc19
1
15 10
2
0 0 12 0
0 10 -1 10
1
end_operator
begin_operator
debark car2 loc2
1
15 11
2
0 0 12 0
0 10 -1 11
1
end_operator
begin_operator
debark car2 loc20
1
15 12
2
0 0 12 0
0 10 -1 12
1
end_operator
begin_operator
debark car2 loc21
1
15 13
2
0 0 12 0
0 10 -1 13
1
end_operator
begin_operator
debark car2 loc22
1
15 14
2
0 0 12 0
0 10 -1 14
1
end_operator
begin_operator
debark car2 loc23
1
15 15
2
0 0 12 0
0 10 -1 15
1
end_operator
begin_operator
debark car2 loc24
1
15 16
2
0 0 12 0
0 10 -1 16
1
end_operator
begin_operator
debark car2 loc25
1
15 17
2
0 0 12 0
0 10 -1 17
1
end_operator
begin_operator
debark car2 loc26
1
15 18
2
0 0 12 0
0 10 -1 18
1
end_operator
begin_operator
debark car2 loc27
1
15 19
2
0 0 12 0
0 10 -1 19
1
end_operator
begin_operator
debark car2 loc3
1
15 20
2
0 0 12 0
0 10 -1 20
1
end_operator
begin_operator
debark car2 loc4
1
15 21
2
0 0 12 0
0 10 -1 21
1
end_operator
begin_operator
debark car2 loc5
1
15 22
2
0 0 12 0
0 10 -1 22
1
end_operator
begin_operator
debark car2 loc6
1
15 23
2
0 0 12 0
0 10 -1 23
1
end_operator
begin_operator
debark car2 loc7
1
15 24
2
0 0 12 0
0 10 -1 24
1
end_operator
begin_operator
debark car2 loc8
1
15 25
2
0 0 12 0
0 10 -1 25
1
end_operator
begin_operator
debark car2 loc9
1
15 26
2
0 0 12 0
0 10 -1 26
1
end_operator
begin_operator
debark car20 loc1
1
15 0
2
0 0 13 0
0 14 -1 0
1
end_operator
begin_operator
debark car20 loc10
1
15 1
2
0 0 13 0
0 14 -1 1
1
end_operator
begin_operator
debark car20 loc11
1
15 2
2
0 0 13 0
0 14 -1 2
1
end_operator
begin_operator
debark car20 loc12
1
15 3
2
0 0 13 0
0 14 -1 3
1
end_operator
begin_operator
debark car20 loc13
1
15 4
2
0 0 13 0
0 14 -1 4
1
end_operator
begin_operator
debark car20 loc14
1
15 5
2
0 0 13 0
0 14 -1 5
1
end_operator
begin_operator
debark car20 loc15
1
15 6
2
0 0 13 0
0 14 -1 6
1
end_operator
begin_operator
debark car20 loc16
1
15 7
2
0 0 13 0
0 14 -1 7
1
end_operator
begin_operator
debark car20 loc17
1
15 8
2
0 0 13 0
0 14 -1 8
1
end_operator
begin_operator
debark car20 loc18
1
15 9
2
0 0 13 0
0 14 -1 9
1
end_operator
begin_operator
debark car20 loc19
1
15 10
2
0 0 13 0
0 14 -1 10
1
end_operator
begin_operator
debark car20 loc2
1
15 11
2
0 0 13 0
0 14 -1 11
1
end_operator
begin_operator
debark car20 loc20
1
15 12
2
0 0 13 0
0 14 -1 12
1
end_operator
begin_operator
debark car20 loc21
1
15 13
2
0 0 13 0
0 14 -1 13
1
end_operator
begin_operator
debark car20 loc22
1
15 14
2
0 0 13 0
0 14 -1 14
1
end_operator
begin_operator
debark car20 loc23
1
15 15
2
0 0 13 0
0 14 -1 15
1
end_operator
begin_operator
debark car20 loc24
1
15 16
2
0 0 13 0
0 14 -1 16
1
end_operator
begin_operator
debark car20 loc25
1
15 17
2
0 0 13 0
0 14 -1 17
1
end_operator
begin_operator
debark car20 loc26
1
15 18
2
0 0 13 0
0 14 -1 18
1
end_operator
begin_operator
debark car20 loc27
1
15 19
2
0 0 13 0
0 14 -1 19
1
end_operator
begin_operator
debark car20 loc3
1
15 20
2
0 0 13 0
0 14 -1 20
1
end_operator
begin_operator
debark car20 loc4
1
15 21
2
0 0 13 0
0 14 -1 21
1
end_operator
begin_operator
debark car20 loc5
1
15 22
2
0 0 13 0
0 14 -1 22
1
end_operator
begin_operator
debark car20 loc6
1
15 23
2
0 0 13 0
0 14 -1 23
1
end_operator
begin_operator
debark car20 loc7
1
15 24
2
0 0 13 0
0 14 -1 24
1
end_operator
begin_operator
debark car20 loc8
1
15 25
2
0 0 13 0
0 14 -1 25
1
end_operator
begin_operator
debark car20 loc9
1
15 26
2
0 0 13 0
0 14 -1 26
1
end_operator
begin_operator
debark car21 loc1
1
15 0
2
0 0 14 0
0 18 -1 0
1
end_operator
begin_operator
debark car21 loc10
1
15 1
2
0 0 14 0
0 18 -1 1
1
end_operator
begin_operator
debark car21 loc11
1
15 2
2
0 0 14 0
0 18 -1 2
1
end_operator
begin_operator
debark car21 loc12
1
15 3
2
0 0 14 0
0 18 -1 3
1
end_operator
begin_operator
debark car21 loc13
1
15 4
2
0 0 14 0
0 18 -1 4
1
end_operator
begin_operator
debark car21 loc14
1
15 5
2
0 0 14 0
0 18 -1 5
1
end_operator
begin_operator
debark car21 loc15
1
15 6
2
0 0 14 0
0 18 -1 6
1
end_operator
begin_operator
debark car21 loc16
1
15 7
2
0 0 14 0
0 18 -1 7
1
end_operator
begin_operator
debark car21 loc17
1
15 8
2
0 0 14 0
0 18 -1 8
1
end_operator
begin_operator
debark car21 loc18
1
15 9
2
0 0 14 0
0 18 -1 9
1
end_operator
begin_operator
debark car21 loc19
1
15 10
2
0 0 14 0
0 18 -1 10
1
end_operator
begin_operator
debark car21 loc2
1
15 11
2
0 0 14 0
0 18 -1 11
1
end_operator
begin_operator
debark car21 loc20
1
15 12
2
0 0 14 0
0 18 -1 12
1
end_operator
begin_operator
debark car21 loc21
1
15 13
2
0 0 14 0
0 18 -1 13
1
end_operator
begin_operator
debark car21 loc22
1
15 14
2
0 0 14 0
0 18 -1 14
1
end_operator
begin_operator
debark car21 loc23
1
15 15
2
0 0 14 0
0 18 -1 15
1
end_operator
begin_operator
debark car21 loc24
1
15 16
2
0 0 14 0
0 18 -1 16
1
end_operator
begin_operator
debark car21 loc25
1
15 17
2
0 0 14 0
0 18 -1 17
1
end_operator
begin_operator
debark car21 loc26
1
15 18
2
0 0 14 0
0 18 -1 18
1
end_operator
begin_operator
debark car21 loc27
1
15 19
2
0 0 14 0
0 18 -1 19
1
end_operator
begin_operator
debark car21 loc3
1
15 20
2
0 0 14 0
0 18 -1 20
1
end_operator
begin_operator
debark car21 loc4
1
15 21
2
0 0 14 0
0 18 -1 21
1
end_operator
begin_operator
debark car21 loc5
1
15 22
2
0 0 14 0
0 18 -1 22
1
end_operator
begin_operator
debark car21 loc6
1
15 23
2
0 0 14 0
0 18 -1 23
1
end_operator
begin_operator
debark car21 loc7
1
15 24
2
0 0 14 0
0 18 -1 24
1
end_operator
begin_operator
debark car21 loc8
1
15 25
2
0 0 14 0
0 18 -1 25
1
end_operator
begin_operator
debark car21 loc9
1
15 26
2
0 0 14 0
0 18 -1 26
1
end_operator
begin_operator
debark car22 loc1
1
15 0
2
0 0 15 0
0 21 -1 0
1
end_operator
begin_operator
debark car22 loc10
1
15 1
2
0 0 15 0
0 21 -1 1
1
end_operator
begin_operator
debark car22 loc11
1
15 2
2
0 0 15 0
0 21 -1 2
1
end_operator
begin_operator
debark car22 loc12
1
15 3
2
0 0 15 0
0 21 -1 3
1
end_operator
begin_operator
debark car22 loc13
1
15 4
2
0 0 15 0
0 21 -1 4
1
end_operator
begin_operator
debark car22 loc14
1
15 5
2
0 0 15 0
0 21 -1 5
1
end_operator
begin_operator
debark car22 loc15
1
15 6
2
0 0 15 0
0 21 -1 6
1
end_operator
begin_operator
debark car22 loc16
1
15 7
2
0 0 15 0
0 21 -1 7
1
end_operator
begin_operator
debark car22 loc17
1
15 8
2
0 0 15 0
0 21 -1 8
1
end_operator
begin_operator
debark car22 loc18
1
15 9
2
0 0 15 0
0 21 -1 9
1
end_operator
begin_operator
debark car22 loc19
1
15 10
2
0 0 15 0
0 21 -1 10
1
end_operator
begin_operator
debark car22 loc2
1
15 11
2
0 0 15 0
0 21 -1 11
1
end_operator
begin_operator
debark car22 loc20
1
15 12
2
0 0 15 0
0 21 -1 12
1
end_operator
begin_operator
debark car22 loc21
1
15 13
2
0 0 15 0
0 21 -1 13
1
end_operator
begin_operator
debark car22 loc22
1
15 14
2
0 0 15 0
0 21 -1 14
1
end_operator
begin_operator
debark car22 loc23
1
15 15
2
0 0 15 0
0 21 -1 15
1
end_operator
begin_operator
debark car22 loc24
1
15 16
2
0 0 15 0
0 21 -1 16
1
end_operator
begin_operator
debark car22 loc25
1
15 17
2
0 0 15 0
0 21 -1 17
1
end_operator
begin_operator
debark car22 loc26
1
15 18
2
0 0 15 0
0 21 -1 18
1
end_operator
begin_operator
debark car22 loc27
1
15 19
2
0 0 15 0
0 21 -1 19
1
end_operator
begin_operator
debark car22 loc3
1
15 20
2
0 0 15 0
0 21 -1 20
1
end_operator
begin_operator
debark car22 loc4
1
15 21
2
0 0 15 0
0 21 -1 21
1
end_operator
begin_operator
debark car22 loc5
1
15 22
2
0 0 15 0
0 21 -1 22
1
end_operator
begin_operator
debark car22 loc6
1
15 23
2
0 0 15 0
0 21 -1 23
1
end_operator
begin_operator
debark car22 loc7
1
15 24
2
0 0 15 0
0 21 -1 24
1
end_operator
begin_operator
debark car22 loc8
1
15 25
2
0 0 15 0
0 21 -1 25
1
end_operator
begin_operator
debark car22 loc9
1
15 26
2
0 0 15 0
0 21 -1 26
1
end_operator
begin_operator
debark car23 loc1
1
15 0
2
0 0 16 0
0 24 -1 0
1
end_operator
begin_operator
debark car23 loc10
1
15 1
2
0 0 16 0
0 24 -1 1
1
end_operator
begin_operator
debark car23 loc11
1
15 2
2
0 0 16 0
0 24 -1 2
1
end_operator
begin_operator
debark car23 loc12
1
15 3
2
0 0 16 0
0 24 -1 3
1
end_operator
begin_operator
debark car23 loc13
1
15 4
2
0 0 16 0
0 24 -1 4
1
end_operator
begin_operator
debark car23 loc14
1
15 5
2
0 0 16 0
0 24 -1 5
1
end_operator
begin_operator
debark car23 loc15
1
15 6
2
0 0 16 0
0 24 -1 6
1
end_operator
begin_operator
debark car23 loc16
1
15 7
2
0 0 16 0
0 24 -1 7
1
end_operator
begin_operator
debark car23 loc17
1
15 8
2
0 0 16 0
0 24 -1 8
1
end_operator
begin_operator
debark car23 loc18
1
15 9
2
0 0 16 0
0 24 -1 9
1
end_operator
begin_operator
debark car23 loc19
1
15 10
2
0 0 16 0
0 24 -1 10
1
end_operator
begin_operator
debark car23 loc2
1
15 11
2
0 0 16 0
0 24 -1 11
1
end_operator
begin_operator
debark car23 loc20
1
15 12
2
0 0 16 0
0 24 -1 12
1
end_operator
begin_operator
debark car23 loc21
1
15 13
2
0 0 16 0
0 24 -1 13
1
end_operator
begin_operator
debark car23 loc22
1
15 14
2
0 0 16 0
0 24 -1 14
1
end_operator
begin_operator
debark car23 loc23
1
15 15
2
0 0 16 0
0 24 -1 15
1
end_operator
begin_operator
debark car23 loc24
1
15 16
2
0 0 16 0
0 24 -1 16
1
end_operator
begin_operator
debark car23 loc25
1
15 17
2
0 0 16 0
0 24 -1 17
1
end_operator
begin_operator
debark car23 loc26
1
15 18
2
0 0 16 0
0 24 -1 18
1
end_operator
begin_operator
debark car23 loc27
1
15 19
2
0 0 16 0
0 24 -1 19
1
end_operator
begin_operator
debark car23 loc3
1
15 20
2
0 0 16 0
0 24 -1 20
1
end_operator
begin_operator
debark car23 loc4
1
15 21
2
0 0 16 0
0 24 -1 21
1
end_operator
begin_operator
debark car23 loc5
1
15 22
2
0 0 16 0
0 24 -1 22
1
end_operator
begin_operator
debark car23 loc6
1
15 23
2
0 0 16 0
0 24 -1 23
1
end_operator
begin_operator
debark car23 loc7
1
15 24
2
0 0 16 0
0 24 -1 24
1
end_operator
begin_operator
debark car23 loc8
1
15 25
2
0 0 16 0
0 24 -1 25
1
end_operator
begin_operator
debark car23 loc9
1
15 26
2
0 0 16 0
0 24 -1 26
1
end_operator
begin_operator
debark car24 loc1
1
15 0
2
0 0 17 0
0 27 -1 0
1
end_operator
begin_operator
debark car24 loc10
1
15 1
2
0 0 17 0
0 27 -1 1
1
end_operator
begin_operator
debark car24 loc11
1
15 2
2
0 0 17 0
0 27 -1 2
1
end_operator
begin_operator
debark car24 loc12
1
15 3
2
0 0 17 0
0 27 -1 3
1
end_operator
begin_operator
debark car24 loc13
1
15 4
2
0 0 17 0
0 27 -1 4
1
end_operator
begin_operator
debark car24 loc14
1
15 5
2
0 0 17 0
0 27 -1 5
1
end_operator
begin_operator
debark car24 loc15
1
15 6
2
0 0 17 0
0 27 -1 6
1
end_operator
begin_operator
debark car24 loc16
1
15 7
2
0 0 17 0
0 27 -1 7
1
end_operator
begin_operator
debark car24 loc17
1
15 8
2
0 0 17 0
0 27 -1 8
1
end_operator
begin_operator
debark car24 loc18
1
15 9
2
0 0 17 0
0 27 -1 9
1
end_operator
begin_operator
debark car24 loc19
1
15 10
2
0 0 17 0
0 27 -1 10
1
end_operator
begin_operator
debark car24 loc2
1
15 11
2
0 0 17 0
0 27 -1 11
1
end_operator
begin_operator
debark car24 loc20
1
15 12
2
0 0 17 0
0 27 -1 12
1
end_operator
begin_operator
debark car24 loc21
1
15 13
2
0 0 17 0
0 27 -1 13
1
end_operator
begin_operator
debark car24 loc22
1
15 14
2
0 0 17 0
0 27 -1 14
1
end_operator
begin_operator
debark car24 loc23
1
15 15
2
0 0 17 0
0 27 -1 15
1
end_operator
begin_operator
debark car24 loc24
1
15 16
2
0 0 17 0
0 27 -1 16
1
end_operator
begin_operator
debark car24 loc25
1
15 17
2
0 0 17 0
0 27 -1 17
1
end_operator
begin_operator
debark car24 loc26
1
15 18
2
0 0 17 0
0 27 -1 18
1
end_operator
begin_operator
debark car24 loc27
1
15 19
2
0 0 17 0
0 27 -1 19
1
end_operator
begin_operator
debark car24 loc3
1
15 20
2
0 0 17 0
0 27 -1 20
1
end_operator
begin_operator
debark car24 loc4
1
15 21
2
0 0 17 0
0 27 -1 21
1
end_operator
begin_operator
debark car24 loc5
1
15 22
2
0 0 17 0
0 27 -1 22
1
end_operator
begin_operator
debark car24 loc6
1
15 23
2
0 0 17 0
0 27 -1 23
1
end_operator
begin_operator
debark car24 loc7
1
15 24
2
0 0 17 0
0 27 -1 24
1
end_operator
begin_operator
debark car24 loc8
1
15 25
2
0 0 17 0
0 27 -1 25
1
end_operator
begin_operator
debark car24 loc9
1
15 26
2
0 0 17 0
0 27 -1 26
1
end_operator
begin_operator
debark car25 loc1
1
15 0
2
0 0 18 0
0 30 -1 0
1
end_operator
begin_operator
debark car25 loc10
1
15 1
2
0 0 18 0
0 30 -1 1
1
end_operator
begin_operator
debark car25 loc11
1
15 2
2
0 0 18 0
0 30 -1 2
1
end_operator
begin_operator
debark car25 loc12
1
15 3
2
0 0 18 0
0 30 -1 3
1
end_operator
begin_operator
debark car25 loc13
1
15 4
2
0 0 18 0
0 30 -1 4
1
end_operator
begin_operator
debark car25 loc14
1
15 5
2
0 0 18 0
0 30 -1 5
1
end_operator
begin_operator
debark car25 loc15
1
15 6
2
0 0 18 0
0 30 -1 6
1
end_operator
begin_operator
debark car25 loc16
1
15 7
2
0 0 18 0
0 30 -1 7
1
end_operator
begin_operator
debark car25 loc17
1
15 8
2
0 0 18 0
0 30 -1 8
1
end_operator
begin_operator
debark car25 loc18
1
15 9
2
0 0 18 0
0 30 -1 9
1
end_operator
begin_operator
debark car25 loc19
1
15 10
2
0 0 18 0
0 30 -1 10
1
end_operator
begin_operator
debark car25 loc2
1
15 11
2
0 0 18 0
0 30 -1 11
1
end_operator
begin_operator
debark car25 loc20
1
15 12
2
0 0 18 0
0 30 -1 12
1
end_operator
begin_operator
debark car25 loc21
1
15 13
2
0 0 18 0
0 30 -1 13
1
end_operator
begin_operator
debark car25 loc22
1
15 14
2
0 0 18 0
0 30 -1 14
1
end_operator
begin_operator
debark car25 loc23
1
15 15
2
0 0 18 0
0 30 -1 15
1
end_operator
begin_operator
debark car25 loc24
1
15 16
2
0 0 18 0
0 30 -1 16
1
end_operator
begin_operator
debark car25 loc25
1
15 17
2
0 0 18 0
0 30 -1 17
1
end_operator
begin_operator
debark car25 loc26
1
15 18
2
0 0 18 0
0 30 -1 18
1
end_operator
begin_operator
debark car25 loc27
1
15 19
2
0 0 18 0
0 30 -1 19
1
end_operator
begin_operator
debark car25 loc3
1
15 20
2
0 0 18 0
0 30 -1 20
1
end_operator
begin_operator
debark car25 loc4
1
15 21
2
0 0 18 0
0 30 -1 21
1
end_operator
begin_operator
debark car25 loc5
1
15 22
2
0 0 18 0
0 30 -1 22
1
end_operator
begin_operator
debark car25 loc6
1
15 23
2
0 0 18 0
0 30 -1 23
1
end_operator
begin_operator
debark car25 loc7
1
15 24
2
0 0 18 0
0 30 -1 24
1
end_operator
begin_operator
debark car25 loc8
1
15 25
2
0 0 18 0
0 30 -1 25
1
end_operator
begin_operator
debark car25 loc9
1
15 26
2
0 0 18 0
0 30 -1 26
1
end_operator
begin_operator
debark car26 loc1
1
15 0
2
0 0 19 0
0 1 -1 0
1
end_operator
begin_operator
debark car26 loc10
1
15 1
2
0 0 19 0
0 1 -1 1
1
end_operator
begin_operator
debark car26 loc11
1
15 2
2
0 0 19 0
0 1 -1 2
1
end_operator
begin_operator
debark car26 loc12
1
15 3
2
0 0 19 0
0 1 -1 3
1
end_operator
begin_operator
debark car26 loc13
1
15 4
2
0 0 19 0
0 1 -1 4
1
end_operator
begin_operator
debark car26 loc14
1
15 5
2
0 0 19 0
0 1 -1 5
1
end_operator
begin_operator
debark car26 loc15
1
15 6
2
0 0 19 0
0 1 -1 6
1
end_operator
begin_operator
debark car26 loc16
1
15 7
2
0 0 19 0
0 1 -1 7
1
end_operator
begin_operator
debark car26 loc17
1
15 8
2
0 0 19 0
0 1 -1 8
1
end_operator
begin_operator
debark car26 loc18
1
15 9
2
0 0 19 0
0 1 -1 9
1
end_operator
begin_operator
debark car26 loc19
1
15 10
2
0 0 19 0
0 1 -1 10
1
end_operator
begin_operator
debark car26 loc2
1
15 11
2
0 0 19 0
0 1 -1 11
1
end_operator
begin_operator
debark car26 loc20
1
15 12
2
0 0 19 0
0 1 -1 12
1
end_operator
begin_operator
debark car26 loc21
1
15 13
2
0 0 19 0
0 1 -1 13
1
end_operator
begin_operator
debark car26 loc22
1
15 14
2
0 0 19 0
0 1 -1 14
1
end_operator
begin_operator
debark car26 loc23
1
15 15
2
0 0 19 0
0 1 -1 15
1
end_operator
begin_operator
debark car26 loc24
1
15 16
2
0 0 19 0
0 1 -1 16
1
end_operator
begin_operator
debark car26 loc25
1
15 17
2
0 0 19 0
0 1 -1 17
1
end_operator
begin_operator
debark car26 loc26
1
15 18
2
0 0 19 0
0 1 -1 18
1
end_operator
begin_operator
debark car26 loc27
1
15 19
2
0 0 19 0
0 1 -1 19
1
end_operator
begin_operator
debark car26 loc3
1
15 20
2
0 0 19 0
0 1 -1 20
1
end_operator
begin_operator
debark car26 loc4
1
15 21
2
0 0 19 0
0 1 -1 21
1
end_operator
begin_operator
debark car26 loc5
1
15 22
2
0 0 19 0
0 1 -1 22
1
end_operator
begin_operator
debark car26 loc6
1
15 23
2
0 0 19 0
0 1 -1 23
1
end_operator
begin_operator
debark car26 loc7
1
15 24
2
0 0 19 0
0 1 -1 24
1
end_operator
begin_operator
debark car26 loc8
1
15 25
2
0 0 19 0
0 1 -1 25
1
end_operator
begin_operator
debark car26 loc9
1
15 26
2
0 0 19 0
0 1 -1 26
1
end_operator
begin_operator
debark car27 loc1
1
15 0
2
0 0 20 0
0 5 -1 0
1
end_operator
begin_operator
debark car27 loc10
1
15 1
2
0 0 20 0
0 5 -1 1
1
end_operator
begin_operator
debark car27 loc11
1
15 2
2
0 0 20 0
0 5 -1 2
1
end_operator
begin_operator
debark car27 loc12
1
15 3
2
0 0 20 0
0 5 -1 3
1
end_operator
begin_operator
debark car27 loc13
1
15 4
2
0 0 20 0
0 5 -1 4
1
end_operator
begin_operator
debark car27 loc14
1
15 5
2
0 0 20 0
0 5 -1 5
1
end_operator
begin_operator
debark car27 loc15
1
15 6
2
0 0 20 0
0 5 -1 6
1
end_operator
begin_operator
debark car27 loc16
1
15 7
2
0 0 20 0
0 5 -1 7
1
end_operator
begin_operator
debark car27 loc17
1
15 8
2
0 0 20 0
0 5 -1 8
1
end_operator
begin_operator
debark car27 loc18
1
15 9
2
0 0 20 0
0 5 -1 9
1
end_operator
begin_operator
debark car27 loc19
1
15 10
2
0 0 20 0
0 5 -1 10
1
end_operator
begin_operator
debark car27 loc2
1
15 11
2
0 0 20 0
0 5 -1 11
1
end_operator
begin_operator
debark car27 loc20
1
15 12
2
0 0 20 0
0 5 -1 12
1
end_operator
begin_operator
debark car27 loc21
1
15 13
2
0 0 20 0
0 5 -1 13
1
end_operator
begin_operator
debark car27 loc22
1
15 14
2
0 0 20 0
0 5 -1 14
1
end_operator
begin_operator
debark car27 loc23
1
15 15
2
0 0 20 0
0 5 -1 15
1
end_operator
begin_operator
debark car27 loc24
1
15 16
2
0 0 20 0
0 5 -1 16
1
end_operator
begin_operator
debark car27 loc25
1
15 17
2
0 0 20 0
0 5 -1 17
1
end_operator
begin_operator
debark car27 loc26
1
15 18
2
0 0 20 0
0 5 -1 18
1
end_operator
begin_operator
debark car27 loc27
1
15 19
2
0 0 20 0
0 5 -1 19
1
end_operator
begin_operator
debark car27 loc3
1
15 20
2
0 0 20 0
0 5 -1 20
1
end_operator
begin_operator
debark car27 loc4
1
15 21
2
0 0 20 0
0 5 -1 21
1
end_operator
begin_operator
debark car27 loc5
1
15 22
2
0 0 20 0
0 5 -1 22
1
end_operator
begin_operator
debark car27 loc6
1
15 23
2
0 0 20 0
0 5 -1 23
1
end_operator
begin_operator
debark car27 loc7
1
15 24
2
0 0 20 0
0 5 -1 24
1
end_operator
begin_operator
debark car27 loc8
1
15 25
2
0 0 20 0
0 5 -1 25
1
end_operator
begin_operator
debark car27 loc9
1
15 26
2
0 0 20 0
0 5 -1 26
1
end_operator
begin_operator
debark car28 loc1
1
15 0
2
0 0 21 0
0 9 -1 0
1
end_operator
begin_operator
debark car28 loc10
1
15 1
2
0 0 21 0
0 9 -1 1
1
end_operator
begin_operator
debark car28 loc11
1
15 2
2
0 0 21 0
0 9 -1 2
1
end_operator
begin_operator
debark car28 loc12
1
15 3
2
0 0 21 0
0 9 -1 3
1
end_operator
begin_operator
debark car28 loc13
1
15 4
2
0 0 21 0
0 9 -1 4
1
end_operator
begin_operator
debark car28 loc14
1
15 5
2
0 0 21 0
0 9 -1 5
1
end_operator
begin_operator
debark car28 loc15
1
15 6
2
0 0 21 0
0 9 -1 6
1
end_operator
begin_operator
debark car28 loc16
1
15 7
2
0 0 21 0
0 9 -1 7
1
end_operator
begin_operator
debark car28 loc17
1
15 8
2
0 0 21 0
0 9 -1 8
1
end_operator
begin_operator
debark car28 loc18
1
15 9
2
0 0 21 0
0 9 -1 9
1
end_operator
begin_operator
debark car28 loc19
1
15 10
2
0 0 21 0
0 9 -1 10
1
end_operator
begin_operator
debark car28 loc2
1
15 11
2
0 0 21 0
0 9 -1 11
1
end_operator
begin_operator
debark car28 loc20
1
15 12
2
0 0 21 0
0 9 -1 12
1
end_operator
begin_operator
debark car28 loc21
1
15 13
2
0 0 21 0
0 9 -1 13
1
end_operator
begin_operator
debark car28 loc22
1
15 14
2
0 0 21 0
0 9 -1 14
1
end_operator
begin_operator
debark car28 loc23
1
15 15
2
0 0 21 0
0 9 -1 15
1
end_operator
begin_operator
debark car28 loc24
1
15 16
2
0 0 21 0
0 9 -1 16
1
end_operator
begin_operator
debark car28 loc25
1
15 17
2
0 0 21 0
0 9 -1 17
1
end_operator
begin_operator
debark car28 loc26
1
15 18
2
0 0 21 0
0 9 -1 18
1
end_operator
begin_operator
debark car28 loc27
1
15 19
2
0 0 21 0
0 9 -1 19
1
end_operator
begin_operator
debark car28 loc3
1
15 20
2
0 0 21 0
0 9 -1 20
1
end_operator
begin_operator
debark car28 loc4
1
15 21
2
0 0 21 0
0 9 -1 21
1
end_operator
begin_operator
debark car28 loc5
1
15 22
2
0 0 21 0
0 9 -1 22
1
end_operator
begin_operator
debark car28 loc6
1
15 23
2
0 0 21 0
0 9 -1 23
1
end_operator
begin_operator
debark car28 loc7
1
15 24
2
0 0 21 0
0 9 -1 24
1
end_operator
begin_operator
debark car28 loc8
1
15 25
2
0 0 21 0
0 9 -1 25
1
end_operator
begin_operator
debark car28 loc9
1
15 26
2
0 0 21 0
0 9 -1 26
1
end_operator
begin_operator
debark car29 loc1
1
15 0
2
0 0 22 0
0 13 -1 0
1
end_operator
begin_operator
debark car29 loc10
1
15 1
2
0 0 22 0
0 13 -1 1
1
end_operator
begin_operator
debark car29 loc11
1
15 2
2
0 0 22 0
0 13 -1 2
1
end_operator
begin_operator
debark car29 loc12
1
15 3
2
0 0 22 0
0 13 -1 3
1
end_operator
begin_operator
debark car29 loc13
1
15 4
2
0 0 22 0
0 13 -1 4
1
end_operator
begin_operator
debark car29 loc14
1
15 5
2
0 0 22 0
0 13 -1 5
1
end_operator
begin_operator
debark car29 loc15
1
15 6
2
0 0 22 0
0 13 -1 6
1
end_operator
begin_operator
debark car29 loc16
1
15 7
2
0 0 22 0
0 13 -1 7
1
end_operator
begin_operator
debark car29 loc17
1
15 8
2
0 0 22 0
0 13 -1 8
1
end_operator
begin_operator
debark car29 loc18
1
15 9
2
0 0 22 0
0 13 -1 9
1
end_operator
begin_operator
debark car29 loc19
1
15 10
2
0 0 22 0
0 13 -1 10
1
end_operator
begin_operator
debark car29 loc2
1
15 11
2
0 0 22 0
0 13 -1 11
1
end_operator
begin_operator
debark car29 loc20
1
15 12
2
0 0 22 0
0 13 -1 12
1
end_operator
begin_operator
debark car29 loc21
1
15 13
2
0 0 22 0
0 13 -1 13
1
end_operator
begin_operator
debark car29 loc22
1
15 14
2
0 0 22 0
0 13 -1 14
1
end_operator
begin_operator
debark car29 loc23
1
15 15
2
0 0 22 0
0 13 -1 15
1
end_operator
begin_operator
debark car29 loc24
1
15 16
2
0 0 22 0
0 13 -1 16
1
end_operator
begin_operator
debark car29 loc25
1
15 17
2
0 0 22 0
0 13 -1 17
1
end_operator
begin_operator
debark car29 loc26
1
15 18
2
0 0 22 0
0 13 -1 18
1
end_operator
begin_operator
debark car29 loc27
1
15 19
2
0 0 22 0
0 13 -1 19
1
end_operator
begin_operator
debark car29 loc3
1
15 20
2
0 0 22 0
0 13 -1 20
1
end_operator
begin_operator
debark car29 loc4
1
15 21
2
0 0 22 0
0 13 -1 21
1
end_operator
begin_operator
debark car29 loc5
1
15 22
2
0 0 22 0
0 13 -1 22
1
end_operator
begin_operator
debark car29 loc6
1
15 23
2
0 0 22 0
0 13 -1 23
1
end_operator
begin_operator
debark car29 loc7
1
15 24
2
0 0 22 0
0 13 -1 24
1
end_operator
begin_operator
debark car29 loc8
1
15 25
2
0 0 22 0
0 13 -1 25
1
end_operator
begin_operator
debark car29 loc9
1
15 26
2
0 0 22 0
0 13 -1 26
1
end_operator
begin_operator
debark car3 loc1
1
15 0
2
0 0 23 0
0 17 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
15 1
2
0 0 23 0
0 17 -1 1
1
end_operator
begin_operator
debark car3 loc11
1
15 2
2
0 0 23 0
0 17 -1 2
1
end_operator
begin_operator
debark car3 loc12
1
15 3
2
0 0 23 0
0 17 -1 3
1
end_operator
begin_operator
debark car3 loc13
1
15 4
2
0 0 23 0
0 17 -1 4
1
end_operator
begin_operator
debark car3 loc14
1
15 5
2
0 0 23 0
0 17 -1 5
1
end_operator
begin_operator
debark car3 loc15
1
15 6
2
0 0 23 0
0 17 -1 6
1
end_operator
begin_operator
debark car3 loc16
1
15 7
2
0 0 23 0
0 17 -1 7
1
end_operator
begin_operator
debark car3 loc17
1
15 8
2
0 0 23 0
0 17 -1 8
1
end_operator
begin_operator
debark car3 loc18
1
15 9
2
0 0 23 0
0 17 -1 9
1
end_operator
begin_operator
debark car3 loc19
1
15 10
2
0 0 23 0
0 17 -1 10
1
end_operator
begin_operator
debark car3 loc2
1
15 11
2
0 0 23 0
0 17 -1 11
1
end_operator
begin_operator
debark car3 loc20
1
15 12
2
0 0 23 0
0 17 -1 12
1
end_operator
begin_operator
debark car3 loc21
1
15 13
2
0 0 23 0
0 17 -1 13
1
end_operator
begin_operator
debark car3 loc22
1
15 14
2
0 0 23 0
0 17 -1 14
1
end_operator
begin_operator
debark car3 loc23
1
15 15
2
0 0 23 0
0 17 -1 15
1
end_operator
begin_operator
debark car3 loc24
1
15 16
2
0 0 23 0
0 17 -1 16
1
end_operator
begin_operator
debark car3 loc25
1
15 17
2
0 0 23 0
0 17 -1 17
1
end_operator
begin_operator
debark car3 loc26
1
15 18
2
0 0 23 0
0 17 -1 18
1
end_operator
begin_operator
debark car3 loc27
1
15 19
2
0 0 23 0
0 17 -1 19
1
end_operator
begin_operator
debark car3 loc3
1
15 20
2
0 0 23 0
0 17 -1 20
1
end_operator
begin_operator
debark car3 loc4
1
15 21
2
0 0 23 0
0 17 -1 21
1
end_operator
begin_operator
debark car3 loc5
1
15 22
2
0 0 23 0
0 17 -1 22
1
end_operator
begin_operator
debark car3 loc6
1
15 23
2
0 0 23 0
0 17 -1 23
1
end_operator
begin_operator
debark car3 loc7
1
15 24
2
0 0 23 0
0 17 -1 24
1
end_operator
begin_operator
debark car3 loc8
1
15 25
2
0 0 23 0
0 17 -1 25
1
end_operator
begin_operator
debark car3 loc9
1
15 26
2
0 0 23 0
0 17 -1 26
1
end_operator
begin_operator
debark car30 loc1
1
15 0
2
0 0 24 0
0 20 -1 0
1
end_operator
begin_operator
debark car30 loc10
1
15 1
2
0 0 24 0
0 20 -1 1
1
end_operator
begin_operator
debark car30 loc11
1
15 2
2
0 0 24 0
0 20 -1 2
1
end_operator
begin_operator
debark car30 loc12
1
15 3
2
0 0 24 0
0 20 -1 3
1
end_operator
begin_operator
debark car30 loc13
1
15 4
2
0 0 24 0
0 20 -1 4
1
end_operator
begin_operator
debark car30 loc14
1
15 5
2
0 0 24 0
0 20 -1 5
1
end_operator
begin_operator
debark car30 loc15
1
15 6
2
0 0 24 0
0 20 -1 6
1
end_operator
begin_operator
debark car30 loc16
1
15 7
2
0 0 24 0
0 20 -1 7
1
end_operator
begin_operator
debark car30 loc17
1
15 8
2
0 0 24 0
0 20 -1 8
1
end_operator
begin_operator
debark car30 loc18
1
15 9
2
0 0 24 0
0 20 -1 9
1
end_operator
begin_operator
debark car30 loc19
1
15 10
2
0 0 24 0
0 20 -1 10
1
end_operator
begin_operator
debark car30 loc2
1
15 11
2
0 0 24 0
0 20 -1 11
1
end_operator
begin_operator
debark car30 loc20
1
15 12
2
0 0 24 0
0 20 -1 12
1
end_operator
begin_operator
debark car30 loc21
1
15 13
2
0 0 24 0
0 20 -1 13
1
end_operator
begin_operator
debark car30 loc22
1
15 14
2
0 0 24 0
0 20 -1 14
1
end_operator
begin_operator
debark car30 loc23
1
15 15
2
0 0 24 0
0 20 -1 15
1
end_operator
begin_operator
debark car30 loc24
1
15 16
2
0 0 24 0
0 20 -1 16
1
end_operator
begin_operator
debark car30 loc25
1
15 17
2
0 0 24 0
0 20 -1 17
1
end_operator
begin_operator
debark car30 loc26
1
15 18
2
0 0 24 0
0 20 -1 18
1
end_operator
begin_operator
debark car30 loc27
1
15 19
2
0 0 24 0
0 20 -1 19
1
end_operator
begin_operator
debark car30 loc3
1
15 20
2
0 0 24 0
0 20 -1 20
1
end_operator
begin_operator
debark car30 loc4
1
15 21
2
0 0 24 0
0 20 -1 21
1
end_operator
begin_operator
debark car30 loc5
1
15 22
2
0 0 24 0
0 20 -1 22
1
end_operator
begin_operator
debark car30 loc6
1
15 23
2
0 0 24 0
0 20 -1 23
1
end_operator
begin_operator
debark car30 loc7
1
15 24
2
0 0 24 0
0 20 -1 24
1
end_operator
begin_operator
debark car30 loc8
1
15 25
2
0 0 24 0
0 20 -1 25
1
end_operator
begin_operator
debark car30 loc9
1
15 26
2
0 0 24 0
0 20 -1 26
1
end_operator
begin_operator
debark car31 loc1
1
15 0
2
0 0 25 0
0 23 -1 0
1
end_operator
begin_operator
debark car31 loc10
1
15 1
2
0 0 25 0
0 23 -1 1
1
end_operator
begin_operator
debark car31 loc11
1
15 2
2
0 0 25 0
0 23 -1 2
1
end_operator
begin_operator
debark car31 loc12
1
15 3
2
0 0 25 0
0 23 -1 3
1
end_operator
begin_operator
debark car31 loc13
1
15 4
2
0 0 25 0
0 23 -1 4
1
end_operator
begin_operator
debark car31 loc14
1
15 5
2
0 0 25 0
0 23 -1 5
1
end_operator
begin_operator
debark car31 loc15
1
15 6
2
0 0 25 0
0 23 -1 6
1
end_operator
begin_operator
debark car31 loc16
1
15 7
2
0 0 25 0
0 23 -1 7
1
end_operator
begin_operator
debark car31 loc17
1
15 8
2
0 0 25 0
0 23 -1 8
1
end_operator
begin_operator
debark car31 loc18
1
15 9
2
0 0 25 0
0 23 -1 9
1
end_operator
begin_operator
debark car31 loc19
1
15 10
2
0 0 25 0
0 23 -1 10
1
end_operator
begin_operator
debark car31 loc2
1
15 11
2
0 0 25 0
0 23 -1 11
1
end_operator
begin_operator
debark car31 loc20
1
15 12
2
0 0 25 0
0 23 -1 12
1
end_operator
begin_operator
debark car31 loc21
1
15 13
2
0 0 25 0
0 23 -1 13
1
end_operator
begin_operator
debark car31 loc22
1
15 14
2
0 0 25 0
0 23 -1 14
1
end_operator
begin_operator
debark car31 loc23
1
15 15
2
0 0 25 0
0 23 -1 15
1
end_operator
begin_operator
debark car31 loc24
1
15 16
2
0 0 25 0
0 23 -1 16
1
end_operator
begin_operator
debark car31 loc25
1
15 17
2
0 0 25 0
0 23 -1 17
1
end_operator
begin_operator
debark car31 loc26
1
15 18
2
0 0 25 0
0 23 -1 18
1
end_operator
begin_operator
debark car31 loc27
1
15 19
2
0 0 25 0
0 23 -1 19
1
end_operator
begin_operator
debark car31 loc3
1
15 20
2
0 0 25 0
0 23 -1 20
1
end_operator
begin_operator
debark car31 loc4
1
15 21
2
0 0 25 0
0 23 -1 21
1
end_operator
begin_operator
debark car31 loc5
1
15 22
2
0 0 25 0
0 23 -1 22
1
end_operator
begin_operator
debark car31 loc6
1
15 23
2
0 0 25 0
0 23 -1 23
1
end_operator
begin_operator
debark car31 loc7
1
15 24
2
0 0 25 0
0 23 -1 24
1
end_operator
begin_operator
debark car31 loc8
1
15 25
2
0 0 25 0
0 23 -1 25
1
end_operator
begin_operator
debark car31 loc9
1
15 26
2
0 0 25 0
0 23 -1 26
1
end_operator
begin_operator
debark car4 loc1
1
15 0
2
0 0 26 0
0 26 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
15 1
2
0 0 26 0
0 26 -1 1
1
end_operator
begin_operator
debark car4 loc11
1
15 2
2
0 0 26 0
0 26 -1 2
1
end_operator
begin_operator
debark car4 loc12
1
15 3
2
0 0 26 0
0 26 -1 3
1
end_operator
begin_operator
debark car4 loc13
1
15 4
2
0 0 26 0
0 26 -1 4
1
end_operator
begin_operator
debark car4 loc14
1
15 5
2
0 0 26 0
0 26 -1 5
1
end_operator
begin_operator
debark car4 loc15
1
15 6
2
0 0 26 0
0 26 -1 6
1
end_operator
begin_operator
debark car4 loc16
1
15 7
2
0 0 26 0
0 26 -1 7
1
end_operator
begin_operator
debark car4 loc17
1
15 8
2
0 0 26 0
0 26 -1 8
1
end_operator
begin_operator
debark car4 loc18
1
15 9
2
0 0 26 0
0 26 -1 9
1
end_operator
begin_operator
debark car4 loc19
1
15 10
2
0 0 26 0
0 26 -1 10
1
end_operator
begin_operator
debark car4 loc2
1
15 11
2
0 0 26 0
0 26 -1 11
1
end_operator
begin_operator
debark car4 loc20
1
15 12
2
0 0 26 0
0 26 -1 12
1
end_operator
begin_operator
debark car4 loc21
1
15 13
2
0 0 26 0
0 26 -1 13
1
end_operator
begin_operator
debark car4 loc22
1
15 14
2
0 0 26 0
0 26 -1 14
1
end_operator
begin_operator
debark car4 loc23
1
15 15
2
0 0 26 0
0 26 -1 15
1
end_operator
begin_operator
debark car4 loc24
1
15 16
2
0 0 26 0
0 26 -1 16
1
end_operator
begin_operator
debark car4 loc25
1
15 17
2
0 0 26 0
0 26 -1 17
1
end_operator
begin_operator
debark car4 loc26
1
15 18
2
0 0 26 0
0 26 -1 18
1
end_operator
begin_operator
debark car4 loc27
1
15 19
2
0 0 26 0
0 26 -1 19
1
end_operator
begin_operator
debark car4 loc3
1
15 20
2
0 0 26 0
0 26 -1 20
1
end_operator
begin_operator
debark car4 loc4
1
15 21
2
0 0 26 0
0 26 -1 21
1
end_operator
begin_operator
debark car4 loc5
1
15 22
2
0 0 26 0
0 26 -1 22
1
end_operator
begin_operator
debark car4 loc6
1
15 23
2
0 0 26 0
0 26 -1 23
1
end_operator
begin_operator
debark car4 loc7
1
15 24
2
0 0 26 0
0 26 -1 24
1
end_operator
begin_operator
debark car4 loc8
1
15 25
2
0 0 26 0
0 26 -1 25
1
end_operator
begin_operator
debark car4 loc9
1
15 26
2
0 0 26 0
0 26 -1 26
1
end_operator
begin_operator
debark car5 loc1
1
15 0
2
0 0 27 0
0 29 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
15 1
2
0 0 27 0
0 29 -1 1
1
end_operator
begin_operator
debark car5 loc11
1
15 2
2
0 0 27 0
0 29 -1 2
1
end_operator
begin_operator
debark car5 loc12
1
15 3
2
0 0 27 0
0 29 -1 3
1
end_operator
begin_operator
debark car5 loc13
1
15 4
2
0 0 27 0
0 29 -1 4
1
end_operator
begin_operator
debark car5 loc14
1
15 5
2
0 0 27 0
0 29 -1 5
1
end_operator
begin_operator
debark car5 loc15
1
15 6
2
0 0 27 0
0 29 -1 6
1
end_operator
begin_operator
debark car5 loc16
1
15 7
2
0 0 27 0
0 29 -1 7
1
end_operator
begin_operator
debark car5 loc17
1
15 8
2
0 0 27 0
0 29 -1 8
1
end_operator
begin_operator
debark car5 loc18
1
15 9
2
0 0 27 0
0 29 -1 9
1
end_operator
begin_operator
debark car5 loc19
1
15 10
2
0 0 27 0
0 29 -1 10
1
end_operator
begin_operator
debark car5 loc2
1
15 11
2
0 0 27 0
0 29 -1 11
1
end_operator
begin_operator
debark car5 loc20
1
15 12
2
0 0 27 0
0 29 -1 12
1
end_operator
begin_operator
debark car5 loc21
1
15 13
2
0 0 27 0
0 29 -1 13
1
end_operator
begin_operator
debark car5 loc22
1
15 14
2
0 0 27 0
0 29 -1 14
1
end_operator
begin_operator
debark car5 loc23
1
15 15
2
0 0 27 0
0 29 -1 15
1
end_operator
begin_operator
debark car5 loc24
1
15 16
2
0 0 27 0
0 29 -1 16
1
end_operator
begin_operator
debark car5 loc25
1
15 17
2
0 0 27 0
0 29 -1 17
1
end_operator
begin_operator
debark car5 loc26
1
15 18
2
0 0 27 0
0 29 -1 18
1
end_operator
begin_operator
debark car5 loc27
1
15 19
2
0 0 27 0
0 29 -1 19
1
end_operator
begin_operator
debark car5 loc3
1
15 20
2
0 0 27 0
0 29 -1 20
1
end_operator
begin_operator
debark car5 loc4
1
15 21
2
0 0 27 0
0 29 -1 21
1
end_operator
begin_operator
debark car5 loc5
1
15 22
2
0 0 27 0
0 29 -1 22
1
end_operator
begin_operator
debark car5 loc6
1
15 23
2
0 0 27 0
0 29 -1 23
1
end_operator
begin_operator
debark car5 loc7
1
15 24
2
0 0 27 0
0 29 -1 24
1
end_operator
begin_operator
debark car5 loc8
1
15 25
2
0 0 27 0
0 29 -1 25
1
end_operator
begin_operator
debark car5 loc9
1
15 26
2
0 0 27 0
0 29 -1 26
1
end_operator
begin_operator
debark car6 loc1
1
15 0
2
0 0 28 0
0 32 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
15 1
2
0 0 28 0
0 32 -1 1
1
end_operator
begin_operator
debark car6 loc11
1
15 2
2
0 0 28 0
0 32 -1 2
1
end_operator
begin_operator
debark car6 loc12
1
15 3
2
0 0 28 0
0 32 -1 3
1
end_operator
begin_operator
debark car6 loc13
1
15 4
2
0 0 28 0
0 32 -1 4
1
end_operator
begin_operator
debark car6 loc14
1
15 5
2
0 0 28 0
0 32 -1 5
1
end_operator
begin_operator
debark car6 loc15
1
15 6
2
0 0 28 0
0 32 -1 6
1
end_operator
begin_operator
debark car6 loc16
1
15 7
2
0 0 28 0
0 32 -1 7
1
end_operator
begin_operator
debark car6 loc17
1
15 8
2
0 0 28 0
0 32 -1 8
1
end_operator
begin_operator
debark car6 loc18
1
15 9
2
0 0 28 0
0 32 -1 9
1
end_operator
begin_operator
debark car6 loc19
1
15 10
2
0 0 28 0
0 32 -1 10
1
end_operator
begin_operator
debark car6 loc2
1
15 11
2
0 0 28 0
0 32 -1 11
1
end_operator
begin_operator
debark car6 loc20
1
15 12
2
0 0 28 0
0 32 -1 12
1
end_operator
begin_operator
debark car6 loc21
1
15 13
2
0 0 28 0
0 32 -1 13
1
end_operator
begin_operator
debark car6 loc22
1
15 14
2
0 0 28 0
0 32 -1 14
1
end_operator
begin_operator
debark car6 loc23
1
15 15
2
0 0 28 0
0 32 -1 15
1
end_operator
begin_operator
debark car6 loc24
1
15 16
2
0 0 28 0
0 32 -1 16
1
end_operator
begin_operator
debark car6 loc25
1
15 17
2
0 0 28 0
0 32 -1 17
1
end_operator
begin_operator
debark car6 loc26
1
15 18
2
0 0 28 0
0 32 -1 18
1
end_operator
begin_operator
debark car6 loc27
1
15 19
2
0 0 28 0
0 32 -1 19
1
end_operator
begin_operator
debark car6 loc3
1
15 20
2
0 0 28 0
0 32 -1 20
1
end_operator
begin_operator
debark car6 loc4
1
15 21
2
0 0 28 0
0 32 -1 21
1
end_operator
begin_operator
debark car6 loc5
1
15 22
2
0 0 28 0
0 32 -1 22
1
end_operator
begin_operator
debark car6 loc6
1
15 23
2
0 0 28 0
0 32 -1 23
1
end_operator
begin_operator
debark car6 loc7
1
15 24
2
0 0 28 0
0 32 -1 24
1
end_operator
begin_operator
debark car6 loc8
1
15 25
2
0 0 28 0
0 32 -1 25
1
end_operator
begin_operator
debark car6 loc9
1
15 26
2
0 0 28 0
0 32 -1 26
1
end_operator
begin_operator
debark car7 loc1
1
15 0
2
0 0 29 0
0 3 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
15 1
2
0 0 29 0
0 3 -1 1
1
end_operator
begin_operator
debark car7 loc11
1
15 2
2
0 0 29 0
0 3 -1 2
1
end_operator
begin_operator
debark car7 loc12
1
15 3
2
0 0 29 0
0 3 -1 3
1
end_operator
begin_operator
debark car7 loc13
1
15 4
2
0 0 29 0
0 3 -1 4
1
end_operator
begin_operator
debark car7 loc14
1
15 5
2
0 0 29 0
0 3 -1 5
1
end_operator
begin_operator
debark car7 loc15
1
15 6
2
0 0 29 0
0 3 -1 6
1
end_operator
begin_operator
debark car7 loc16
1
15 7
2
0 0 29 0
0 3 -1 7
1
end_operator
begin_operator
debark car7 loc17
1
15 8
2
0 0 29 0
0 3 -1 8
1
end_operator
begin_operator
debark car7 loc18
1
15 9
2
0 0 29 0
0 3 -1 9
1
end_operator
begin_operator
debark car7 loc19
1
15 10
2
0 0 29 0
0 3 -1 10
1
end_operator
begin_operator
debark car7 loc2
1
15 11
2
0 0 29 0
0 3 -1 11
1
end_operator
begin_operator
debark car7 loc20
1
15 12
2
0 0 29 0
0 3 -1 12
1
end_operator
begin_operator
debark car7 loc21
1
15 13
2
0 0 29 0
0 3 -1 13
1
end_operator
begin_operator
debark car7 loc22
1
15 14
2
0 0 29 0
0 3 -1 14
1
end_operator
begin_operator
debark car7 loc23
1
15 15
2
0 0 29 0
0 3 -1 15
1
end_operator
begin_operator
debark car7 loc24
1
15 16
2
0 0 29 0
0 3 -1 16
1
end_operator
begin_operator
debark car7 loc25
1
15 17
2
0 0 29 0
0 3 -1 17
1
end_operator
begin_operator
debark car7 loc26
1
15 18
2
0 0 29 0
0 3 -1 18
1
end_operator
begin_operator
debark car7 loc27
1
15 19
2
0 0 29 0
0 3 -1 19
1
end_operator
begin_operator
debark car7 loc3
1
15 20
2
0 0 29 0
0 3 -1 20
1
end_operator
begin_operator
debark car7 loc4
1
15 21
2
0 0 29 0
0 3 -1 21
1
end_operator
begin_operator
debark car7 loc5
1
15 22
2
0 0 29 0
0 3 -1 22
1
end_operator
begin_operator
debark car7 loc6
1
15 23
2
0 0 29 0
0 3 -1 23
1
end_operator
begin_operator
debark car7 loc7
1
15 24
2
0 0 29 0
0 3 -1 24
1
end_operator
begin_operator
debark car7 loc8
1
15 25
2
0 0 29 0
0 3 -1 25
1
end_operator
begin_operator
debark car7 loc9
1
15 26
2
0 0 29 0
0 3 -1 26
1
end_operator
begin_operator
debark car8 loc1
1
15 0
2
0 0 30 0
0 7 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
15 1
2
0 0 30 0
0 7 -1 1
1
end_operator
begin_operator
debark car8 loc11
1
15 2
2
0 0 30 0
0 7 -1 2
1
end_operator
begin_operator
debark car8 loc12
1
15 3
2
0 0 30 0
0 7 -1 3
1
end_operator
begin_operator
debark car8 loc13
1
15 4
2
0 0 30 0
0 7 -1 4
1
end_operator
begin_operator
debark car8 loc14
1
15 5
2
0 0 30 0
0 7 -1 5
1
end_operator
begin_operator
debark car8 loc15
1
15 6
2
0 0 30 0
0 7 -1 6
1
end_operator
begin_operator
debark car8 loc16
1
15 7
2
0 0 30 0
0 7 -1 7
1
end_operator
begin_operator
debark car8 loc17
1
15 8
2
0 0 30 0
0 7 -1 8
1
end_operator
begin_operator
debark car8 loc18
1
15 9
2
0 0 30 0
0 7 -1 9
1
end_operator
begin_operator
debark car8 loc19
1
15 10
2
0 0 30 0
0 7 -1 10
1
end_operator
begin_operator
debark car8 loc2
1
15 11
2
0 0 30 0
0 7 -1 11
1
end_operator
begin_operator
debark car8 loc20
1
15 12
2
0 0 30 0
0 7 -1 12
1
end_operator
begin_operator
debark car8 loc21
1
15 13
2
0 0 30 0
0 7 -1 13
1
end_operator
begin_operator
debark car8 loc22
1
15 14
2
0 0 30 0
0 7 -1 14
1
end_operator
begin_operator
debark car8 loc23
1
15 15
2
0 0 30 0
0 7 -1 15
1
end_operator
begin_operator
debark car8 loc24
1
15 16
2
0 0 30 0
0 7 -1 16
1
end_operator
begin_operator
debark car8 loc25
1
15 17
2
0 0 30 0
0 7 -1 17
1
end_operator
begin_operator
debark car8 loc26
1
15 18
2
0 0 30 0
0 7 -1 18
1
end_operator
begin_operator
debark car8 loc27
1
15 19
2
0 0 30 0
0 7 -1 19
1
end_operator
begin_operator
debark car8 loc3
1
15 20
2
0 0 30 0
0 7 -1 20
1
end_operator
begin_operator
debark car8 loc4
1
15 21
2
0 0 30 0
0 7 -1 21
1
end_operator
begin_operator
debark car8 loc5
1
15 22
2
0 0 30 0
0 7 -1 22
1
end_operator
begin_operator
debark car8 loc6
1
15 23
2
0 0 30 0
0 7 -1 23
1
end_operator
begin_operator
debark car8 loc7
1
15 24
2
0 0 30 0
0 7 -1 24
1
end_operator
begin_operator
debark car8 loc8
1
15 25
2
0 0 30 0
0 7 -1 25
1
end_operator
begin_operator
debark car8 loc9
1
15 26
2
0 0 30 0
0 7 -1 26
1
end_operator
begin_operator
debark car9 loc1
1
15 0
2
0 0 31 0
0 11 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
15 1
2
0 0 31 0
0 11 -1 1
1
end_operator
begin_operator
debark car9 loc11
1
15 2
2
0 0 31 0
0 11 -1 2
1
end_operator
begin_operator
debark car9 loc12
1
15 3
2
0 0 31 0
0 11 -1 3
1
end_operator
begin_operator
debark car9 loc13
1
15 4
2
0 0 31 0
0 11 -1 4
1
end_operator
begin_operator
debark car9 loc14
1
15 5
2
0 0 31 0
0 11 -1 5
1
end_operator
begin_operator
debark car9 loc15
1
15 6
2
0 0 31 0
0 11 -1 6
1
end_operator
begin_operator
debark car9 loc16
1
15 7
2
0 0 31 0
0 11 -1 7
1
end_operator
begin_operator
debark car9 loc17
1
15 8
2
0 0 31 0
0 11 -1 8
1
end_operator
begin_operator
debark car9 loc18
1
15 9
2
0 0 31 0
0 11 -1 9
1
end_operator
begin_operator
debark car9 loc19
1
15 10
2
0 0 31 0
0 11 -1 10
1
end_operator
begin_operator
debark car9 loc2
1
15 11
2
0 0 31 0
0 11 -1 11
1
end_operator
begin_operator
debark car9 loc20
1
15 12
2
0 0 31 0
0 11 -1 12
1
end_operator
begin_operator
debark car9 loc21
1
15 13
2
0 0 31 0
0 11 -1 13
1
end_operator
begin_operator
debark car9 loc22
1
15 14
2
0 0 31 0
0 11 -1 14
1
end_operator
begin_operator
debark car9 loc23
1
15 15
2
0 0 31 0
0 11 -1 15
1
end_operator
begin_operator
debark car9 loc24
1
15 16
2
0 0 31 0
0 11 -1 16
1
end_operator
begin_operator
debark car9 loc25
1
15 17
2
0 0 31 0
0 11 -1 17
1
end_operator
begin_operator
debark car9 loc26
1
15 18
2
0 0 31 0
0 11 -1 18
1
end_operator
begin_operator
debark car9 loc27
1
15 19
2
0 0 31 0
0 11 -1 19
1
end_operator
begin_operator
debark car9 loc3
1
15 20
2
0 0 31 0
0 11 -1 20
1
end_operator
begin_operator
debark car9 loc4
1
15 21
2
0 0 31 0
0 11 -1 21
1
end_operator
begin_operator
debark car9 loc5
1
15 22
2
0 0 31 0
0 11 -1 22
1
end_operator
begin_operator
debark car9 loc6
1
15 23
2
0 0 31 0
0 11 -1 23
1
end_operator
begin_operator
debark car9 loc7
1
15 24
2
0 0 31 0
0 11 -1 24
1
end_operator
begin_operator
debark car9 loc8
1
15 25
2
0 0 31 0
0 11 -1 25
1
end_operator
begin_operator
debark car9 loc9
1
15 26
2
0 0 31 0
0 11 -1 26
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 15 0 1
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 15 0 2
0 33 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 15 0 3
0 33 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 15 0 4
0 33 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 15 0 5
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 15 0 6
0 33 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 15 0 7
0 33 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 15 0 8
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 15 0 9
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 15 0 10
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 15 0 11
0 33 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 15 0 12
0 33 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 15 0 13
0 33 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 15 0 14
0 33 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 15 0 15
0 33 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc1 loc24
0
3
0 15 0 16
0 33 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc1 loc25
0
3
0 15 0 17
0 33 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc1 loc26
0
3
0 15 0 18
0 33 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc1 loc27
0
3
0 15 0 19
0 33 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 15 0 20
0 33 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 15 0 21
0 33 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 15 0 22
0 33 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 15 0 23
0 33 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 15 0 24
0 33 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 15 0 25
0 33 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 15 0 26
0 33 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 15 1 0
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 15 1 2
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 15 1 3
0 34 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 15 1 4
0 34 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 15 1 5
0 34 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 15 1 6
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 15 1 7
0 34 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 15 1 8
0 34 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 15 1 9
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 15 1 10
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 15 1 11
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 15 1 12
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 15 1 13
0 34 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 15 1 14
0 34 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 15 1 15
0 34 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc10 loc24
0
3
0 15 1 16
0 34 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc10 loc25
0
3
0 15 1 17
0 34 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc10 loc26
0
3
0 15 1 18
0 34 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc10 loc27
0
3
0 15 1 19
0 34 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 15 1 20
0 34 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 15 1 21
0 34 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 15 1 22
0 34 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 15 1 23
0 34 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 15 1 24
0 34 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 15 1 25
0 34 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 15 1 26
0 34 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 15 2 0
0 33 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 15 2 1
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 15 2 3
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 15 2 4
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 15 2 5
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 15 2 6
0 35 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 15 2 7
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 15 2 8
0 35 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 15 2 9
0 35 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 15 2 10
0 35 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 15 2 11
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 15 2 12
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 15 2 13
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 15 2 14
0 35 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 15 2 15
0 35 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc11 loc24
0
3
0 15 2 16
0 35 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc11 loc25
0
3
0 15 2 17
0 35 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc11 loc26
0
3
0 15 2 18
0 35 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc11 loc27
0
3
0 15 2 19
0 35 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 15 2 20
0 35 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 15 2 21
0 35 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 15 2 22
0 35 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 15 2 23
0 35 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 15 2 24
0 35 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 15 2 25
0 35 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 15 2 26
0 35 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 15 3 0
0 33 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 15 3 1
0 34 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 15 3 2
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 15 3 4
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 15 3 5
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 15 3 6
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 15 3 7
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 15 3 8
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 15 3 9
0 36 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 15 3 10
0 36 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 15 3 11
0 36 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 15 3 12
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 15 3 13
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 15 3 14
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 15 3 15
0 36 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc12 loc24
0
3
0 15 3 16
0 36 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc12 loc25
0
3
0 15 3 17
0 36 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc12 loc26
0
3
0 15 3 18
0 36 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc12 loc27
0
3
0 15 3 19
0 36 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 15 3 20
0 36 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 15 3 21
0 36 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 15 3 22
0 36 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 15 3 23
0 36 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 15 3 24
0 36 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 15 3 25
0 36 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 15 3 26
0 36 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 15 4 0
0 33 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 15 4 1
0 34 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 15 4 2
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 15 4 3
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 15 4 5
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 15 4 6
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 15 4 7
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 15 4 8
0 37 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 15 4 9
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 15 4 10
0 37 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 15 4 11
0 37 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 15 4 12
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 15 4 13
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 15 4 14
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 15 4 15
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc13 loc24
0
3
0 15 4 16
0 37 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc13 loc25
0
3
0 15 4 17
0 37 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc13 loc26
0
3
0 15 4 18
0 37 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc13 loc27
0
3
0 15 4 19
0 37 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 15 4 20
0 37 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 15 4 21
0 37 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 15 4 22
0 37 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 15 4 23
0 37 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 15 4 24
0 37 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 15 4 25
0 37 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 15 4 26
0 37 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 15 5 0
0 33 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 15 5 1
0 34 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 15 5 2
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 15 5 3
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 15 5 4
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 15 5 6
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 15 5 7
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 15 5 8
0 38 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 15 5 9
0 38 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 15 5 10
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 15 5 11
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 15 5 12
0 38 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 15 5 13
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 15 5 14
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 15 5 15
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc14 loc24
0
3
0 15 5 16
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc14 loc25
0
3
0 15 5 17
0 38 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc14 loc26
0
3
0 15 5 18
0 38 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc14 loc27
0
3
0 15 5 19
0 38 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 15 5 20
0 38 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 15 5 21
0 38 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 15 5 22
0 38 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 15 5 23
0 38 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 15 5 24
0 38 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 15 5 25
0 38 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 15 5 26
0 38 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 15 6 0
0 33 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 15 6 1
0 34 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 15 6 2
0 35 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 15 6 3
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 15 6 4
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 15 6 5
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 15 6 7
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 15 6 8
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 15 6 9
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 15 6 10
0 39 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 15 6 11
0 39 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 15 6 12
0 39 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 15 6 13
0 39 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 15 6 14
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 15 6 15
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc15 loc24
0
3
0 15 6 16
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc15 loc25
0
3
0 15 6 17
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc15 loc26
0
3
0 15 6 18
0 39 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc15 loc27
0
3
0 15 6 19
0 39 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 15 6 20
0 39 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 15 6 21
0 39 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 15 6 22
0 39 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 15 6 23
0 39 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 15 6 24
0 39 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 15 6 25
0 39 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 15 6 26
0 39 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 15 7 0
0 33 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 15 7 1
0 34 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 15 7 2
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 15 7 3
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 15 7 4
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 15 7 5
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 15 7 6
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 15 7 8
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 15 7 9
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 15 7 10
0 40 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 15 7 11
0 40 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 15 7 12
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 15 7 13
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 15 7 14
0 40 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 15 7 15
0 40 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc16 loc24
0
3
0 15 7 16
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc16 loc25
0
3
0 15 7 17
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc16 loc26
0
3
0 15 7 18
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc16 loc27
0
3
0 15 7 19
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 15 7 20
0 40 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 15 7 21
0 40 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 15 7 22
0 40 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 15 7 23
0 40 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 15 7 24
0 40 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 15 7 25
0 40 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 15 7 26
0 40 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 15 8 0
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 15 8 1
0 34 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 15 8 2
0 35 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 15 8 3
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 15 8 4
0 37 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 15 8 5
0 38 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 15 8 6
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 15 8 7
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 15 8 9
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 15 8 10
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 15 8 11
0 41 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 15 8 12
0 41 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 15 8 13
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 15 8 14
0 41 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 15 8 15
0 41 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc17 loc24
0
3
0 15 8 16
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc17 loc25
0
3
0 15 8 17
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc17 loc26
0
3
0 15 8 18
0 41 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc17 loc27
0
3
0 15 8 19
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 15 8 20
0 41 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 15 8 21
0 41 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 15 8 22
0 41 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 15 8 23
0 41 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 15 8 24
0 41 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 15 8 25
0 41 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 15 8 26
0 41 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 15 9 0
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 15 9 1
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 15 9 2
0 35 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 15 9 3
0 36 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 15 9 4
0 37 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 15 9 5
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 15 9 6
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 15 9 7
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 15 9 8
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 15 9 10
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 15 9 11
0 42 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 15 9 12
0 42 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 15 9 13
0 42 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 15 9 14
0 42 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 15 9 15
0 42 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc18 loc24
0
3
0 15 9 16
0 42 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc18 loc25
0
3
0 15 9 17
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc18 loc26
0
3
0 15 9 18
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc18 loc27
0
3
0 15 9 19
0 42 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 15 9 20
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 15 9 21
0 42 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 15 9 22
0 42 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 15 9 23
0 42 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 15 9 24
0 42 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 15 9 25
0 42 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 15 9 26
0 42 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 15 10 0
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 15 10 1
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 15 10 2
0 35 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 15 10 3
0 36 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 15 10 4
0 37 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 15 10 5
0 38 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 15 10 6
0 39 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 15 10 7
0 40 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 15 10 8
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 15 10 9
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 15 10 11
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 15 10 12
0 43 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 15 10 13
0 43 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 15 10 14
0 43 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 15 10 15
0 43 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc19 loc24
0
3
0 15 10 16
0 43 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc19 loc25
0
3
0 15 10 17
0 43 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc19 loc26
0
3
0 15 10 18
0 43 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc19 loc27
0
3
0 15 10 19
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 15 10 20
0 43 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 15 10 21
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 15 10 22
0 43 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 15 10 23
0 43 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 15 10 24
0 43 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 15 10 25
0 43 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 15 10 26
0 43 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 15 11 0
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 15 11 1
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 15 11 2
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 15 11 3
0 36 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 15 11 4
0 37 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 15 11 5
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 15 11 6
0 39 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 15 11 7
0 40 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 15 11 8
0 41 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 15 11 9
0 42 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 15 11 10
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 15 11 12
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 15 11 13
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 15 11 14
0 44 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 15 11 15
0 44 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc2 loc24
0
3
0 15 11 16
0 44 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc2 loc25
0
3
0 15 11 17
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc2 loc26
0
3
0 15 11 18
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc2 loc27
0
3
0 15 11 19
0 44 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 15 11 20
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 15 11 21
0 44 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 15 11 22
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 15 11 23
0 44 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 15 11 24
0 44 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 15 11 25
0 44 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 15 11 26
0 44 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 15 12 0
0 33 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 15 12 1
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 15 12 2
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 15 12 3
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 15 12 4
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 15 12 5
0 38 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 15 12 6
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 15 12 7
0 40 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 15 12 8
0 41 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 15 12 9
0 42 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 15 12 10
0 43 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 15 12 11
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 15 12 13
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 15 12 14
0 45 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 15 12 15
0 45 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc20 loc24
0
3
0 15 12 16
0 45 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc20 loc25
0
3
0 15 12 17
0 45 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc20 loc26
0
3
0 15 12 18
0 45 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc20 loc27
0
3
0 15 12 19
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 15 12 20
0 45 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 15 12 21
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 15 12 22
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 15 12 23
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 15 12 24
0 45 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 15 12 25
0 45 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 15 12 26
0 45 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 15 13 0
0 33 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 15 13 1
0 34 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 15 13 2
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 15 13 3
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 15 13 4
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 15 13 5
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 15 13 6
0 39 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 15 13 7
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 15 13 8
0 41 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 15 13 9
0 42 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 15 13 10
0 43 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 15 13 11
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 15 13 12
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 15 13 14
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 15 13 15
0 46 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc21 loc24
0
3
0 15 13 16
0 46 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc21 loc25
0
3
0 15 13 17
0 46 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc21 loc26
0
3
0 15 13 18
0 46 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc21 loc27
0
3
0 15 13 19
0 46 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 15 13 20
0 46 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 15 13 21
0 46 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 15 13 22
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 15 13 23
0 46 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 15 13 24
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 15 13 25
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 15 13 26
0 46 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 15 14 0
0 33 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 15 14 1
0 34 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 15 14 2
0 35 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 15 14 3
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 15 14 4
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 15 14 5
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 15 14 6
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 15 14 7
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 15 14 8
0 41 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 15 14 9
0 42 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 15 14 10
0 43 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 15 14 11
0 44 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 15 14 12
0 45 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 15 14 13
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 15 14 15
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc22 loc24
0
3
0 15 14 16
0 47 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc22 loc25
0
3
0 15 14 17
0 47 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc22 loc26
0
3
0 15 14 18
0 47 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc22 loc27
0
3
0 15 14 19
0 47 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 15 14 20
0 47 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 15 14 21
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 15 14 22
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 15 14 23
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 15 14 24
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 15 14 25
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 15 14 26
0 47 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 15 15 0
0 33 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 15 15 1
0 34 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 15 15 2
0 35 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 15 15 3
0 36 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 15 15 4
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 15 15 5
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 15 15 6
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 15 15 7
0 40 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 15 15 8
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 15 15 9
0 42 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 15 15 10
0 43 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 15 15 11
0 44 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 15 15 12
0 45 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 15 15 13
0 46 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 15 15 14
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc23 loc24
0
3
0 15 15 16
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc23 loc25
0
3
0 15 15 17
0 48 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc23 loc26
0
3
0 15 15 18
0 48 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc23 loc27
0
3
0 15 15 19
0 48 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 15 15 20
0 48 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 15 15 21
0 48 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 15 15 22
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 15 15 23
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 15 15 24
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 15 15 25
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 15 15 26
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc24 loc1
0
3
0 15 16 0
0 33 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc10
0
3
0 15 16 1
0 34 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc11
0
3
0 15 16 2
0 35 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc12
0
3
0 15 16 3
0 36 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc13
0
3
0 15 16 4
0 37 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc14
0
3
0 15 16 5
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc15
0
3
0 15 16 6
0 39 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc16
0
3
0 15 16 7
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc17
0
3
0 15 16 8
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc18
0
3
0 15 16 9
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc19
0
3
0 15 16 10
0 43 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc2
0
3
0 15 16 11
0 44 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc20
0
3
0 15 16 12
0 45 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc21
0
3
0 15 16 13
0 46 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc22
0
3
0 15 16 14
0 47 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc23
0
3
0 15 16 15
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc24 loc25
0
3
0 15 16 17
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc24 loc26
0
3
0 15 16 18
0 49 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc24 loc27
0
3
0 15 16 19
0 49 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc24 loc3
0
3
0 15 16 20
0 49 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc24 loc4
0
3
0 15 16 21
0 49 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc24 loc5
0
3
0 15 16 22
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc24 loc6
0
3
0 15 16 23
0 49 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc24 loc7
0
3
0 15 16 24
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc24 loc8
0
3
0 15 16 25
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc24 loc9
0
3
0 15 16 26
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc25 loc1
0
3
0 15 17 0
0 33 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc10
0
3
0 15 17 1
0 34 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc11
0
3
0 15 17 2
0 35 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc12
0
3
0 15 17 3
0 36 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc13
0
3
0 15 17 4
0 37 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc14
0
3
0 15 17 5
0 38 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc15
0
3
0 15 17 6
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc16
0
3
0 15 17 7
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc17
0
3
0 15 17 8
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc18
0
3
0 15 17 9
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc19
0
3
0 15 17 10
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc2
0
3
0 15 17 11
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc20
0
3
0 15 17 12
0 45 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc21
0
3
0 15 17 13
0 46 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc22
0
3
0 15 17 14
0 47 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc23
0
3
0 15 17 15
0 48 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc24
0
3
0 15 17 16
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc25 loc26
0
3
0 15 17 18
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc25 loc27
0
3
0 15 17 19
0 50 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc25 loc3
0
3
0 15 17 20
0 50 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc25 loc4
0
3
0 15 17 21
0 50 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc25 loc5
0
3
0 15 17 22
0 50 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc25 loc6
0
3
0 15 17 23
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc25 loc7
0
3
0 15 17 24
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc25 loc8
0
3
0 15 17 25
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc25 loc9
0
3
0 15 17 26
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc26 loc1
0
3
0 15 18 0
0 33 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc10
0
3
0 15 18 1
0 34 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc11
0
3
0 15 18 2
0 35 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc12
0
3
0 15 18 3
0 36 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc13
0
3
0 15 18 4
0 37 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc14
0
3
0 15 18 5
0 38 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc15
0
3
0 15 18 6
0 39 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc16
0
3
0 15 18 7
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc17
0
3
0 15 18 8
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc18
0
3
0 15 18 9
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc19
0
3
0 15 18 10
0 43 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc2
0
3
0 15 18 11
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc20
0
3
0 15 18 12
0 45 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc21
0
3
0 15 18 13
0 46 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc22
0
3
0 15 18 14
0 47 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc23
0
3
0 15 18 15
0 48 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc24
0
3
0 15 18 16
0 49 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc25
0
3
0 15 18 17
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc26 loc27
0
3
0 15 18 19
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc26 loc3
0
3
0 15 18 20
0 51 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc26 loc4
0
3
0 15 18 21
0 51 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc26 loc5
0
3
0 15 18 22
0 51 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc26 loc6
0
3
0 15 18 23
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc26 loc7
0
3
0 15 18 24
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc26 loc8
0
3
0 15 18 25
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc26 loc9
0
3
0 15 18 26
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc27 loc1
0
3
0 15 19 0
0 33 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc10
0
3
0 15 19 1
0 34 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc11
0
3
0 15 19 2
0 35 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc12
0
3
0 15 19 3
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc13
0
3
0 15 19 4
0 37 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc14
0
3
0 15 19 5
0 38 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc15
0
3
0 15 19 6
0 39 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc16
0
3
0 15 19 7
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc17
0
3
0 15 19 8
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc18
0
3
0 15 19 9
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc19
0
3
0 15 19 10
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc2
0
3
0 15 19 11
0 44 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc20
0
3
0 15 19 12
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc21
0
3
0 15 19 13
0 46 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc22
0
3
0 15 19 14
0 47 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc23
0
3
0 15 19 15
0 48 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc24
0
3
0 15 19 16
0 49 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc25
0
3
0 15 19 17
0 50 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc26
0
3
0 15 19 18
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc27 loc3
0
3
0 15 19 20
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc27 loc4
0
3
0 15 19 21
0 52 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc27 loc5
0
3
0 15 19 22
0 52 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc27 loc6
0
3
0 15 19 23
0 52 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc27 loc7
0
3
0 15 19 24
0 52 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc27 loc8
0
3
0 15 19 25
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc27 loc9
0
3
0 15 19 26
0 52 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 15 20 0
0 33 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 15 20 1
0 34 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 15 20 2
0 35 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 15 20 3
0 36 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 15 20 4
0 37 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 15 20 5
0 38 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 15 20 6
0 39 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 15 20 7
0 40 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 15 20 8
0 41 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 15 20 9
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 15 20 10
0 43 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 15 20 11
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 15 20 12
0 45 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 15 20 13
0 46 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 15 20 14
0 47 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 15 20 15
0 48 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc24
0
3
0 15 20 16
0 49 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc25
0
3
0 15 20 17
0 50 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc26
0
3
0 15 20 18
0 51 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc27
0
3
0 15 20 19
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 15 20 21
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 15 20 22
0 53 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 15 20 23
0 53 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 15 20 24
0 53 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 15 20 25
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 15 20 26
0 53 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 15 21 0
0 33 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 15 21 1
0 34 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 15 21 2
0 35 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 15 21 3
0 36 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 15 21 4
0 37 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 15 21 5
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 15 21 6
0 39 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 15 21 7
0 40 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 15 21 8
0 41 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 15 21 9
0 42 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 15 21 10
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 15 21 11
0 44 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 15 21 12
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 15 21 13
0 46 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 15 21 14
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 15 21 15
0 48 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc24
0
3
0 15 21 16
0 49 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc25
0
3
0 15 21 17
0 50 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc26
0
3
0 15 21 18
0 51 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc27
0
3
0 15 21 19
0 52 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 15 21 20
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 15 21 22
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 15 21 23
0 54 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 15 21 24
0 54 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 15 21 25
0 54 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 15 21 26
0 54 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 15 22 0
0 33 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 15 22 1
0 34 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 15 22 2
0 35 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 15 22 3
0 36 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 15 22 4
0 37 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 15 22 5
0 38 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 15 22 6
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 15 22 7
0 40 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 15 22 8
0 41 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 15 22 9
0 42 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 15 22 10
0 43 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 15 22 11
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 15 22 12
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 15 22 13
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 15 22 14
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 15 22 15
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc24
0
3
0 15 22 16
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc25
0
3
0 15 22 17
0 50 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc26
0
3
0 15 22 18
0 51 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc27
0
3
0 15 22 19
0 52 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 15 22 20
0 53 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 15 22 21
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 15 22 23
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 15 22 24
0 55 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 15 22 25
0 55 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 15 22 26
0 55 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 15 23 0
0 33 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 15 23 1
0 34 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 15 23 2
0 35 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 15 23 3
0 36 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 15 23 4
0 37 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 15 23 5
0 38 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 15 23 6
0 39 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 15 23 7
0 40 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 15 23 8
0 41 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 15 23 9
0 42 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 15 23 10
0 43 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 15 23 11
0 44 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 15 23 12
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 15 23 13
0 46 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 15 23 14
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 15 23 15
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc24
0
3
0 15 23 16
0 49 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc25
0
3
0 15 23 17
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc26
0
3
0 15 23 18
0 51 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc27
0
3
0 15 23 19
0 52 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 15 23 20
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 15 23 21
0 54 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 15 23 22
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 15 23 24
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 15 23 25
0 56 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 15 23 26
0 56 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 15 24 0
0 33 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 15 24 1
0 34 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 15 24 2
0 35 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 15 24 3
0 36 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 15 24 4
0 37 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 15 24 5
0 38 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 15 24 6
0 39 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 15 24 7
0 40 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 15 24 8
0 41 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 15 24 9
0 42 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 15 24 10
0 43 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 15 24 11
0 44 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 15 24 12
0 45 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 15 24 13
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 15 24 14
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 15 24 15
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc24
0
3
0 15 24 16
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc25
0
3
0 15 24 17
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc26
0
3
0 15 24 18
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc27
0
3
0 15 24 19
0 52 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 15 24 20
0 53 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 15 24 21
0 54 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 15 24 22
0 55 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 15 24 23
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 15 24 25
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 15 24 26
0 57 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 15 25 0
0 33 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 15 25 1
0 34 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 15 25 2
0 35 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 15 25 3
0 36 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 15 25 4
0 37 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 15 25 5
0 38 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 15 25 6
0 39 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 15 25 7
0 40 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 15 25 8
0 41 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 15 25 9
0 42 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 15 25 10
0 43 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 15 25 11
0 44 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 15 25 12
0 45 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 15 25 13
0 46 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 15 25 14
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 15 25 15
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc24
0
3
0 15 25 16
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc25
0
3
0 15 25 17
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc26
0
3
0 15 25 18
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc27
0
3
0 15 25 19
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 15 25 20
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 15 25 21
0 54 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 15 25 22
0 55 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 15 25 23
0 56 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 15 25 24
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 15 25 26
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 15 26 0
0 33 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 15 26 1
0 34 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 15 26 2
0 35 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 15 26 3
0 36 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 15 26 4
0 37 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 15 26 5
0 38 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 15 26 6
0 39 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 15 26 7
0 40 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 15 26 8
0 41 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 15 26 9
0 42 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 15 26 10
0 43 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 15 26 11
0 44 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 15 26 12
0 45 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 15 26 13
0 46 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 15 26 14
0 47 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 15 26 15
0 48 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc24
0
3
0 15 26 16
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc25
0
3
0 15 26 17
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc26
0
3
0 15 26 18
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc27
0
3
0 15 26 19
0 52 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 15 26 20
0 53 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 15 26 21
0 54 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 15 26 22
0 55 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 15 26 23
0 56 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 15 26 24
0 57 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 15 26 25
0 58 0 1
0 59 -1 0
1
end_operator
0
