begin_version
3
end_version
begin_metric
1
end_metric
44
begin_variable
var0
-1
24
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
on car2
end_variable
begin_variable
var1
-1
24
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
on car1
end_variable
begin_variable
var2
-1
24
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
on car3
end_variable
begin_variable
var3
-1
24
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
on car10
end_variable
begin_variable
var4
-1
24
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
on car4
end_variable
begin_variable
var5
-1
24
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
on car11
end_variable
begin_variable
var6
-1
24
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
on car5
end_variable
begin_variable
var7
-1
24
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
on car12
end_variable
begin_variable
var8
-1
24
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
on car6
end_variable
begin_variable
var9
-1
24
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
on car13
end_variable
begin_variable
var10
-1
24
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
on car7
end_variable
begin_variable
var11
-1
24
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc3
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
on car14
end_variable
begin_variable
var12
-1
24
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
on car8
end_variable
begin_variable
var13
-1
24
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc3
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
on car15
end_variable
begin_variable
var14
-1
24
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
on car9
end_variable
begin_variable
var15
-1
24
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc3
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
on car16
end_variable
begin_variable
var16
-1
24
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc3
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
on car17
end_variable
begin_variable
var17
-1
24
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc3
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
on car18
end_variable
begin_variable
var18
-1
24
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc3
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
on car19
end_variable
begin_variable
var19
-1
23
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var20
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
begin_variable
var43
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
21
12
9
5
16
20
5
17
5
8
5
13
19
8
18
3
22
10
15
14
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
end_state
begin_goal
19
0 5
1 18
2 7
3 9
4 13
5 10
6 3
7 2
8 9
9 18
10 16
11 18
12 0
13 9
14 9
15 19
16 0
17 20
18 5
end_goal
1380
begin_operator
board car1 loc1
1
19 0
2
0 1 0 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc10
1
19 1
2
0 1 1 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc11
1
19 2
2
0 1 2 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc12
1
19 3
2
0 1 3 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc13
1
19 4
2
0 1 4 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc14
1
19 5
2
0 1 5 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc15
1
19 6
2
0 1 6 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc16
1
19 7
2
0 1 7 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc17
1
19 8
2
0 1 8 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc18
1
19 9
2
0 1 9 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc19
1
19 10
2
0 1 10 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc2
1
19 11
2
0 1 11 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc20
1
19 12
2
0 1 12 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc21
1
19 13
2
0 1 13 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc22
1
19 14
2
0 1 14 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc23
1
19 15
2
0 1 15 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc3
1
19 16
2
0 1 16 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc4
1
19 17
2
0 1 17 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc5
1
19 18
2
0 1 18 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc6
1
19 19
2
0 1 19 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc7
1
19 20
2
0 1 20 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc8
1
19 21
2
0 1 21 23
0 43 0 1
1
end_operator
begin_operator
board car1 loc9
1
19 22
2
0 1 22 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc1
1
19 0
2
0 3 0 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc10
1
19 1
2
0 3 1 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc11
1
19 2
2
0 3 2 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc12
1
19 3
2
0 3 3 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc13
1
19 4
2
0 3 4 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc14
1
19 5
2
0 3 5 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc15
1
19 6
2
0 3 6 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc16
1
19 7
2
0 3 7 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc17
1
19 8
2
0 3 8 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc18
1
19 9
2
0 3 9 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc19
1
19 10
2
0 3 10 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc2
1
19 11
2
0 3 11 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc20
1
19 12
2
0 3 12 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc21
1
19 13
2
0 3 13 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc22
1
19 14
2
0 3 14 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc23
1
19 15
2
0 3 15 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc3
1
19 16
2
0 3 16 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc4
1
19 17
2
0 3 17 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc5
1
19 18
2
0 3 18 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc6
1
19 19
2
0 3 19 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc7
1
19 20
2
0 3 20 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc8
1
19 21
2
0 3 21 23
0 43 0 1
1
end_operator
begin_operator
board car10 loc9
1
19 22
2
0 3 22 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc1
1
19 0
2
0 5 0 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc10
1
19 1
2
0 5 1 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc11
1
19 2
2
0 5 2 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc12
1
19 3
2
0 5 3 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc13
1
19 4
2
0 5 4 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc14
1
19 5
2
0 5 5 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc15
1
19 6
2
0 5 6 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc16
1
19 7
2
0 5 7 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc17
1
19 8
2
0 5 8 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc18
1
19 9
2
0 5 9 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc19
1
19 10
2
0 5 10 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc2
1
19 11
2
0 5 11 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc20
1
19 12
2
0 5 12 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc21
1
19 13
2
0 5 13 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc22
1
19 14
2
0 5 14 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc23
1
19 15
2
0 5 15 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc3
1
19 16
2
0 5 16 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc4
1
19 17
2
0 5 17 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc5
1
19 18
2
0 5 18 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc6
1
19 19
2
0 5 19 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc7
1
19 20
2
0 5 20 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc8
1
19 21
2
0 5 21 23
0 43 0 1
1
end_operator
begin_operator
board car11 loc9
1
19 22
2
0 5 22 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc1
1
19 0
2
0 7 0 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc10
1
19 1
2
0 7 1 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc11
1
19 2
2
0 7 2 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc12
1
19 3
2
0 7 3 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc13
1
19 4
2
0 7 4 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc14
1
19 5
2
0 7 5 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc15
1
19 6
2
0 7 6 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc16
1
19 7
2
0 7 7 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc17
1
19 8
2
0 7 8 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc18
1
19 9
2
0 7 9 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc19
1
19 10
2
0 7 10 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc2
1
19 11
2
0 7 11 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc20
1
19 12
2
0 7 12 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc21
1
19 13
2
0 7 13 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc22
1
19 14
2
0 7 14 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc23
1
19 15
2
0 7 15 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc3
1
19 16
2
0 7 16 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc4
1
19 17
2
0 7 17 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc5
1
19 18
2
0 7 18 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc6
1
19 19
2
0 7 19 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc7
1
19 20
2
0 7 20 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc8
1
19 21
2
0 7 21 23
0 43 0 1
1
end_operator
begin_operator
board car12 loc9
1
19 22
2
0 7 22 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc1
1
19 0
2
0 9 0 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc10
1
19 1
2
0 9 1 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc11
1
19 2
2
0 9 2 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc12
1
19 3
2
0 9 3 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc13
1
19 4
2
0 9 4 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc14
1
19 5
2
0 9 5 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc15
1
19 6
2
0 9 6 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc16
1
19 7
2
0 9 7 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc17
1
19 8
2
0 9 8 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc18
1
19 9
2
0 9 9 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc19
1
19 10
2
0 9 10 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc2
1
19 11
2
0 9 11 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc20
1
19 12
2
0 9 12 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc21
1
19 13
2
0 9 13 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc22
1
19 14
2
0 9 14 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc23
1
19 15
2
0 9 15 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc3
1
19 16
2
0 9 16 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc4
1
19 17
2
0 9 17 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc5
1
19 18
2
0 9 18 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc6
1
19 19
2
0 9 19 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc7
1
19 20
2
0 9 20 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc8
1
19 21
2
0 9 21 23
0 43 0 1
1
end_operator
begin_operator
board car13 loc9
1
19 22
2
0 9 22 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc1
1
19 0
2
0 11 0 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc10
1
19 1
2
0 11 1 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc11
1
19 2
2
0 11 2 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc12
1
19 3
2
0 11 3 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc13
1
19 4
2
0 11 4 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc14
1
19 5
2
0 11 5 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc15
1
19 6
2
0 11 6 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc16
1
19 7
2
0 11 7 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc17
1
19 8
2
0 11 8 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc18
1
19 9
2
0 11 9 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc19
1
19 10
2
0 11 10 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc2
1
19 11
2
0 11 11 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc20
1
19 12
2
0 11 12 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc21
1
19 13
2
0 11 13 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc22
1
19 14
2
0 11 14 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc23
1
19 15
2
0 11 15 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc3
1
19 16
2
0 11 16 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc4
1
19 17
2
0 11 17 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc5
1
19 18
2
0 11 18 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc6
1
19 19
2
0 11 19 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc7
1
19 20
2
0 11 20 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc8
1
19 21
2
0 11 21 23
0 43 0 1
1
end_operator
begin_operator
board car14 loc9
1
19 22
2
0 11 22 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc1
1
19 0
2
0 13 0 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc10
1
19 1
2
0 13 1 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc11
1
19 2
2
0 13 2 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc12
1
19 3
2
0 13 3 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc13
1
19 4
2
0 13 4 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc14
1
19 5
2
0 13 5 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc15
1
19 6
2
0 13 6 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc16
1
19 7
2
0 13 7 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc17
1
19 8
2
0 13 8 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc18
1
19 9
2
0 13 9 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc19
1
19 10
2
0 13 10 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc2
1
19 11
2
0 13 11 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc20
1
19 12
2
0 13 12 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc21
1
19 13
2
0 13 13 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc22
1
19 14
2
0 13 14 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc23
1
19 15
2
0 13 15 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc3
1
19 16
2
0 13 16 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc4
1
19 17
2
0 13 17 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc5
1
19 18
2
0 13 18 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc6
1
19 19
2
0 13 19 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc7
1
19 20
2
0 13 20 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc8
1
19 21
2
0 13 21 23
0 43 0 1
1
end_operator
begin_operator
board car15 loc9
1
19 22
2
0 13 22 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc1
1
19 0
2
0 15 0 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc10
1
19 1
2
0 15 1 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc11
1
19 2
2
0 15 2 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc12
1
19 3
2
0 15 3 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc13
1
19 4
2
0 15 4 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc14
1
19 5
2
0 15 5 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc15
1
19 6
2
0 15 6 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc16
1
19 7
2
0 15 7 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc17
1
19 8
2
0 15 8 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc18
1
19 9
2
0 15 9 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc19
1
19 10
2
0 15 10 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc2
1
19 11
2
0 15 11 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc20
1
19 12
2
0 15 12 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc21
1
19 13
2
0 15 13 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc22
1
19 14
2
0 15 14 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc23
1
19 15
2
0 15 15 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc3
1
19 16
2
0 15 16 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc4
1
19 17
2
0 15 17 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc5
1
19 18
2
0 15 18 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc6
1
19 19
2
0 15 19 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc7
1
19 20
2
0 15 20 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc8
1
19 21
2
0 15 21 23
0 43 0 1
1
end_operator
begin_operator
board car16 loc9
1
19 22
2
0 15 22 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc1
1
19 0
2
0 16 0 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc10
1
19 1
2
0 16 1 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc11
1
19 2
2
0 16 2 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc12
1
19 3
2
0 16 3 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc13
1
19 4
2
0 16 4 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc14
1
19 5
2
0 16 5 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc15
1
19 6
2
0 16 6 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc16
1
19 7
2
0 16 7 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc17
1
19 8
2
0 16 8 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc18
1
19 9
2
0 16 9 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc19
1
19 10
2
0 16 10 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc2
1
19 11
2
0 16 11 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc20
1
19 12
2
0 16 12 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc21
1
19 13
2
0 16 13 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc22
1
19 14
2
0 16 14 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc23
1
19 15
2
0 16 15 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc3
1
19 16
2
0 16 16 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc4
1
19 17
2
0 16 17 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc5
1
19 18
2
0 16 18 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc6
1
19 19
2
0 16 19 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc7
1
19 20
2
0 16 20 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc8
1
19 21
2
0 16 21 23
0 43 0 1
1
end_operator
begin_operator
board car17 loc9
1
19 22
2
0 16 22 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc1
1
19 0
2
0 17 0 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc10
1
19 1
2
0 17 1 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc11
1
19 2
2
0 17 2 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc12
1
19 3
2
0 17 3 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc13
1
19 4
2
0 17 4 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc14
1
19 5
2
0 17 5 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc15
1
19 6
2
0 17 6 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc16
1
19 7
2
0 17 7 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc17
1
19 8
2
0 17 8 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc18
1
19 9
2
0 17 9 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc19
1
19 10
2
0 17 10 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc2
1
19 11
2
0 17 11 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc20
1
19 12
2
0 17 12 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc21
1
19 13
2
0 17 13 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc22
1
19 14
2
0 17 14 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc23
1
19 15
2
0 17 15 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc3
1
19 16
2
0 17 16 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc4
1
19 17
2
0 17 17 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc5
1
19 18
2
0 17 18 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc6
1
19 19
2
0 17 19 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc7
1
19 20
2
0 17 20 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc8
1
19 21
2
0 17 21 23
0 43 0 1
1
end_operator
begin_operator
board car18 loc9
1
19 22
2
0 17 22 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc1
1
19 0
2
0 18 0 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc10
1
19 1
2
0 18 1 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc11
1
19 2
2
0 18 2 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc12
1
19 3
2
0 18 3 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc13
1
19 4
2
0 18 4 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc14
1
19 5
2
0 18 5 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc15
1
19 6
2
0 18 6 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc16
1
19 7
2
0 18 7 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc17
1
19 8
2
0 18 8 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc18
1
19 9
2
0 18 9 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc19
1
19 10
2
0 18 10 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc2
1
19 11
2
0 18 11 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc20
1
19 12
2
0 18 12 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc21
1
19 13
2
0 18 13 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc22
1
19 14
2
0 18 14 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc23
1
19 15
2
0 18 15 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc3
1
19 16
2
0 18 16 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc4
1
19 17
2
0 18 17 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc5
1
19 18
2
0 18 18 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc6
1
19 19
2
0 18 19 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc7
1
19 20
2
0 18 20 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc8
1
19 21
2
0 18 21 23
0 43 0 1
1
end_operator
begin_operator
board car19 loc9
1
19 22
2
0 18 22 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc1
1
19 0
2
0 0 0 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc10
1
19 1
2
0 0 1 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc11
1
19 2
2
0 0 2 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc12
1
19 3
2
0 0 3 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc13
1
19 4
2
0 0 4 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc14
1
19 5
2
0 0 5 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc15
1
19 6
2
0 0 6 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc16
1
19 7
2
0 0 7 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc17
1
19 8
2
0 0 8 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc18
1
19 9
2
0 0 9 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc19
1
19 10
2
0 0 10 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc2
1
19 11
2
0 0 11 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc20
1
19 12
2
0 0 12 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc21
1
19 13
2
0 0 13 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc22
1
19 14
2
0 0 14 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc23
1
19 15
2
0 0 15 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc3
1
19 16
2
0 0 16 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc4
1
19 17
2
0 0 17 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc5
1
19 18
2
0 0 18 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc6
1
19 19
2
0 0 19 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc7
1
19 20
2
0 0 20 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc8
1
19 21
2
0 0 21 23
0 43 0 1
1
end_operator
begin_operator
board car2 loc9
1
19 22
2
0 0 22 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc1
1
19 0
2
0 2 0 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc10
1
19 1
2
0 2 1 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc11
1
19 2
2
0 2 2 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc12
1
19 3
2
0 2 3 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc13
1
19 4
2
0 2 4 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc14
1
19 5
2
0 2 5 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc15
1
19 6
2
0 2 6 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc16
1
19 7
2
0 2 7 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc17
1
19 8
2
0 2 8 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc18
1
19 9
2
0 2 9 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc19
1
19 10
2
0 2 10 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc2
1
19 11
2
0 2 11 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc20
1
19 12
2
0 2 12 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc21
1
19 13
2
0 2 13 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc22
1
19 14
2
0 2 14 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc23
1
19 15
2
0 2 15 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc3
1
19 16
2
0 2 16 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc4
1
19 17
2
0 2 17 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc5
1
19 18
2
0 2 18 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc6
1
19 19
2
0 2 19 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc7
1
19 20
2
0 2 20 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc8
1
19 21
2
0 2 21 23
0 43 0 1
1
end_operator
begin_operator
board car3 loc9
1
19 22
2
0 2 22 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc1
1
19 0
2
0 4 0 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc10
1
19 1
2
0 4 1 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc11
1
19 2
2
0 4 2 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc12
1
19 3
2
0 4 3 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc13
1
19 4
2
0 4 4 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc14
1
19 5
2
0 4 5 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc15
1
19 6
2
0 4 6 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc16
1
19 7
2
0 4 7 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc17
1
19 8
2
0 4 8 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc18
1
19 9
2
0 4 9 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc19
1
19 10
2
0 4 10 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc2
1
19 11
2
0 4 11 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc20
1
19 12
2
0 4 12 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc21
1
19 13
2
0 4 13 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc22
1
19 14
2
0 4 14 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc23
1
19 15
2
0 4 15 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc3
1
19 16
2
0 4 16 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc4
1
19 17
2
0 4 17 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc5
1
19 18
2
0 4 18 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc6
1
19 19
2
0 4 19 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc7
1
19 20
2
0 4 20 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc8
1
19 21
2
0 4 21 23
0 43 0 1
1
end_operator
begin_operator
board car4 loc9
1
19 22
2
0 4 22 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc1
1
19 0
2
0 6 0 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc10
1
19 1
2
0 6 1 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc11
1
19 2
2
0 6 2 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc12
1
19 3
2
0 6 3 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc13
1
19 4
2
0 6 4 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc14
1
19 5
2
0 6 5 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc15
1
19 6
2
0 6 6 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc16
1
19 7
2
0 6 7 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc17
1
19 8
2
0 6 8 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc18
1
19 9
2
0 6 9 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc19
1
19 10
2
0 6 10 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc2
1
19 11
2
0 6 11 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc20
1
19 12
2
0 6 12 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc21
1
19 13
2
0 6 13 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc22
1
19 14
2
0 6 14 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc23
1
19 15
2
0 6 15 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc3
1
19 16
2
0 6 16 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc4
1
19 17
2
0 6 17 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc5
1
19 18
2
0 6 18 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc6
1
19 19
2
0 6 19 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc7
1
19 20
2
0 6 20 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc8
1
19 21
2
0 6 21 23
0 43 0 1
1
end_operator
begin_operator
board car5 loc9
1
19 22
2
0 6 22 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc1
1
19 0
2
0 8 0 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc10
1
19 1
2
0 8 1 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc11
1
19 2
2
0 8 2 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc12
1
19 3
2
0 8 3 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc13
1
19 4
2
0 8 4 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc14
1
19 5
2
0 8 5 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc15
1
19 6
2
0 8 6 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc16
1
19 7
2
0 8 7 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc17
1
19 8
2
0 8 8 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc18
1
19 9
2
0 8 9 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc19
1
19 10
2
0 8 10 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc2
1
19 11
2
0 8 11 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc20
1
19 12
2
0 8 12 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc21
1
19 13
2
0 8 13 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc22
1
19 14
2
0 8 14 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc23
1
19 15
2
0 8 15 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc3
1
19 16
2
0 8 16 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc4
1
19 17
2
0 8 17 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc5
1
19 18
2
0 8 18 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc6
1
19 19
2
0 8 19 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc7
1
19 20
2
0 8 20 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc8
1
19 21
2
0 8 21 23
0 43 0 1
1
end_operator
begin_operator
board car6 loc9
1
19 22
2
0 8 22 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc1
1
19 0
2
0 10 0 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc10
1
19 1
2
0 10 1 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc11
1
19 2
2
0 10 2 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc12
1
19 3
2
0 10 3 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc13
1
19 4
2
0 10 4 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc14
1
19 5
2
0 10 5 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc15
1
19 6
2
0 10 6 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc16
1
19 7
2
0 10 7 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc17
1
19 8
2
0 10 8 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc18
1
19 9
2
0 10 9 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc19
1
19 10
2
0 10 10 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc2
1
19 11
2
0 10 11 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc20
1
19 12
2
0 10 12 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc21
1
19 13
2
0 10 13 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc22
1
19 14
2
0 10 14 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc23
1
19 15
2
0 10 15 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc3
1
19 16
2
0 10 16 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc4
1
19 17
2
0 10 17 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc5
1
19 18
2
0 10 18 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc6
1
19 19
2
0 10 19 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc7
1
19 20
2
0 10 20 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc8
1
19 21
2
0 10 21 23
0 43 0 1
1
end_operator
begin_operator
board car7 loc9
1
19 22
2
0 10 22 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc1
1
19 0
2
0 12 0 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc10
1
19 1
2
0 12 1 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc11
1
19 2
2
0 12 2 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc12
1
19 3
2
0 12 3 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc13
1
19 4
2
0 12 4 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc14
1
19 5
2
0 12 5 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc15
1
19 6
2
0 12 6 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc16
1
19 7
2
0 12 7 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc17
1
19 8
2
0 12 8 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc18
1
19 9
2
0 12 9 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc19
1
19 10
2
0 12 10 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc2
1
19 11
2
0 12 11 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc20
1
19 12
2
0 12 12 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc21
1
19 13
2
0 12 13 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc22
1
19 14
2
0 12 14 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc23
1
19 15
2
0 12 15 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc3
1
19 16
2
0 12 16 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc4
1
19 17
2
0 12 17 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc5
1
19 18
2
0 12 18 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc6
1
19 19
2
0 12 19 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc7
1
19 20
2
0 12 20 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc8
1
19 21
2
0 12 21 23
0 43 0 1
1
end_operator
begin_operator
board car8 loc9
1
19 22
2
0 12 22 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc1
1
19 0
2
0 14 0 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc10
1
19 1
2
0 14 1 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc11
1
19 2
2
0 14 2 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc12
1
19 3
2
0 14 3 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc13
1
19 4
2
0 14 4 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc14
1
19 5
2
0 14 5 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc15
1
19 6
2
0 14 6 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc16
1
19 7
2
0 14 7 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc17
1
19 8
2
0 14 8 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc18
1
19 9
2
0 14 9 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc19
1
19 10
2
0 14 10 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc2
1
19 11
2
0 14 11 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc20
1
19 12
2
0 14 12 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc21
1
19 13
2
0 14 13 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc22
1
19 14
2
0 14 14 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc23
1
19 15
2
0 14 15 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc3
1
19 16
2
0 14 16 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc4
1
19 17
2
0 14 17 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc5
1
19 18
2
0 14 18 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc6
1
19 19
2
0 14 19 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc7
1
19 20
2
0 14 20 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc8
1
19 21
2
0 14 21 23
0 43 0 1
1
end_operator
begin_operator
board car9 loc9
1
19 22
2
0 14 22 23
0 43 0 1
1
end_operator
begin_operator
debark car1 loc1
1
19 0
2
0 1 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
19 1
2
0 1 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc11
1
19 2
2
0 1 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc12
1
19 3
2
0 1 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc13
1
19 4
2
0 1 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc14
1
19 5
2
0 1 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc15
1
19 6
2
0 1 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc16
1
19 7
2
0 1 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc17
1
19 8
2
0 1 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc18
1
19 9
2
0 1 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc19
1
19 10
2
0 1 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
19 11
2
0 1 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc20
1
19 12
2
0 1 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc21
1
19 13
2
0 1 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc22
1
19 14
2
0 1 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc23
1
19 15
2
0 1 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
19 16
2
0 1 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
19 17
2
0 1 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
19 18
2
0 1 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
19 19
2
0 1 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc7
1
19 20
2
0 1 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc8
1
19 21
2
0 1 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car1 loc9
1
19 22
2
0 1 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc1
1
19 0
2
0 3 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
19 1
2
0 3 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc11
1
19 2
2
0 3 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc12
1
19 3
2
0 3 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc13
1
19 4
2
0 3 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc14
1
19 5
2
0 3 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc15
1
19 6
2
0 3 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc16
1
19 7
2
0 3 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc17
1
19 8
2
0 3 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc18
1
19 9
2
0 3 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc19
1
19 10
2
0 3 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc2
1
19 11
2
0 3 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc20
1
19 12
2
0 3 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc21
1
19 13
2
0 3 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc22
1
19 14
2
0 3 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc23
1
19 15
2
0 3 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc3
1
19 16
2
0 3 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc4
1
19 17
2
0 3 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc5
1
19 18
2
0 3 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc6
1
19 19
2
0 3 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc7
1
19 20
2
0 3 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc8
1
19 21
2
0 3 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car10 loc9
1
19 22
2
0 3 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc1
1
19 0
2
0 5 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
19 1
2
0 5 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc11
1
19 2
2
0 5 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc12
1
19 3
2
0 5 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc13
1
19 4
2
0 5 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc14
1
19 5
2
0 5 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc15
1
19 6
2
0 5 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc16
1
19 7
2
0 5 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc17
1
19 8
2
0 5 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc18
1
19 9
2
0 5 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc19
1
19 10
2
0 5 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc2
1
19 11
2
0 5 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc20
1
19 12
2
0 5 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc21
1
19 13
2
0 5 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc22
1
19 14
2
0 5 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc23
1
19 15
2
0 5 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc3
1
19 16
2
0 5 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc4
1
19 17
2
0 5 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc5
1
19 18
2
0 5 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc6
1
19 19
2
0 5 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc7
1
19 20
2
0 5 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc8
1
19 21
2
0 5 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car11 loc9
1
19 22
2
0 5 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc1
1
19 0
2
0 7 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
19 1
2
0 7 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc11
1
19 2
2
0 7 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc12
1
19 3
2
0 7 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc13
1
19 4
2
0 7 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc14
1
19 5
2
0 7 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc15
1
19 6
2
0 7 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc16
1
19 7
2
0 7 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc17
1
19 8
2
0 7 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc18
1
19 9
2
0 7 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc19
1
19 10
2
0 7 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc2
1
19 11
2
0 7 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc20
1
19 12
2
0 7 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc21
1
19 13
2
0 7 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc22
1
19 14
2
0 7 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc23
1
19 15
2
0 7 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc3
1
19 16
2
0 7 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc4
1
19 17
2
0 7 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc5
1
19 18
2
0 7 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc6
1
19 19
2
0 7 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc7
1
19 20
2
0 7 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc8
1
19 21
2
0 7 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car12 loc9
1
19 22
2
0 7 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc1
1
19 0
2
0 9 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
19 1
2
0 9 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc11
1
19 2
2
0 9 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc12
1
19 3
2
0 9 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc13
1
19 4
2
0 9 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc14
1
19 5
2
0 9 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc15
1
19 6
2
0 9 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc16
1
19 7
2
0 9 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc17
1
19 8
2
0 9 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc18
1
19 9
2
0 9 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc19
1
19 10
2
0 9 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc2
1
19 11
2
0 9 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc20
1
19 12
2
0 9 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc21
1
19 13
2
0 9 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc22
1
19 14
2
0 9 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc23
1
19 15
2
0 9 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc3
1
19 16
2
0 9 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc4
1
19 17
2
0 9 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc5
1
19 18
2
0 9 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc6
1
19 19
2
0 9 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc7
1
19 20
2
0 9 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc8
1
19 21
2
0 9 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car13 loc9
1
19 22
2
0 9 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc1
1
19 0
2
0 11 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
19 1
2
0 11 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc11
1
19 2
2
0 11 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc12
1
19 3
2
0 11 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc13
1
19 4
2
0 11 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc14
1
19 5
2
0 11 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc15
1
19 6
2
0 11 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc16
1
19 7
2
0 11 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc17
1
19 8
2
0 11 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc18
1
19 9
2
0 11 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc19
1
19 10
2
0 11 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc2
1
19 11
2
0 11 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc20
1
19 12
2
0 11 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc21
1
19 13
2
0 11 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc22
1
19 14
2
0 11 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc23
1
19 15
2
0 11 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc3
1
19 16
2
0 11 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc4
1
19 17
2
0 11 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc5
1
19 18
2
0 11 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc6
1
19 19
2
0 11 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc7
1
19 20
2
0 11 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc8
1
19 21
2
0 11 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car14 loc9
1
19 22
2
0 11 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc1
1
19 0
2
0 13 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
19 1
2
0 13 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc11
1
19 2
2
0 13 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc12
1
19 3
2
0 13 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc13
1
19 4
2
0 13 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc14
1
19 5
2
0 13 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc15
1
19 6
2
0 13 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc16
1
19 7
2
0 13 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc17
1
19 8
2
0 13 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc18
1
19 9
2
0 13 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc19
1
19 10
2
0 13 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc2
1
19 11
2
0 13 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc20
1
19 12
2
0 13 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc21
1
19 13
2
0 13 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc22
1
19 14
2
0 13 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc23
1
19 15
2
0 13 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc3
1
19 16
2
0 13 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc4
1
19 17
2
0 13 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc5
1
19 18
2
0 13 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc6
1
19 19
2
0 13 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc7
1
19 20
2
0 13 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc8
1
19 21
2
0 13 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car15 loc9
1
19 22
2
0 13 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc1
1
19 0
2
0 15 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
19 1
2
0 15 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc11
1
19 2
2
0 15 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc12
1
19 3
2
0 15 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc13
1
19 4
2
0 15 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc14
1
19 5
2
0 15 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc15
1
19 6
2
0 15 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc16
1
19 7
2
0 15 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc17
1
19 8
2
0 15 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc18
1
19 9
2
0 15 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc19
1
19 10
2
0 15 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc2
1
19 11
2
0 15 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc20
1
19 12
2
0 15 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc21
1
19 13
2
0 15 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc22
1
19 14
2
0 15 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc23
1
19 15
2
0 15 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc3
1
19 16
2
0 15 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc4
1
19 17
2
0 15 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc5
1
19 18
2
0 15 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc6
1
19 19
2
0 15 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc7
1
19 20
2
0 15 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc8
1
19 21
2
0 15 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car16 loc9
1
19 22
2
0 15 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc1
1
19 0
2
0 16 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
19 1
2
0 16 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc11
1
19 2
2
0 16 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc12
1
19 3
2
0 16 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc13
1
19 4
2
0 16 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc14
1
19 5
2
0 16 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc15
1
19 6
2
0 16 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc16
1
19 7
2
0 16 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc17
1
19 8
2
0 16 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc18
1
19 9
2
0 16 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc19
1
19 10
2
0 16 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc2
1
19 11
2
0 16 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc20
1
19 12
2
0 16 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc21
1
19 13
2
0 16 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc22
1
19 14
2
0 16 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc23
1
19 15
2
0 16 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc3
1
19 16
2
0 16 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc4
1
19 17
2
0 16 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc5
1
19 18
2
0 16 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc6
1
19 19
2
0 16 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc7
1
19 20
2
0 16 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc8
1
19 21
2
0 16 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car17 loc9
1
19 22
2
0 16 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc1
1
19 0
2
0 17 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
19 1
2
0 17 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc11
1
19 2
2
0 17 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc12
1
19 3
2
0 17 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc13
1
19 4
2
0 17 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc14
1
19 5
2
0 17 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc15
1
19 6
2
0 17 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc16
1
19 7
2
0 17 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc17
1
19 8
2
0 17 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc18
1
19 9
2
0 17 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc19
1
19 10
2
0 17 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc2
1
19 11
2
0 17 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc20
1
19 12
2
0 17 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc21
1
19 13
2
0 17 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc22
1
19 14
2
0 17 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc23
1
19 15
2
0 17 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc3
1
19 16
2
0 17 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc4
1
19 17
2
0 17 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc5
1
19 18
2
0 17 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc6
1
19 19
2
0 17 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc7
1
19 20
2
0 17 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc8
1
19 21
2
0 17 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car18 loc9
1
19 22
2
0 17 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc1
1
19 0
2
0 18 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
19 1
2
0 18 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc11
1
19 2
2
0 18 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc12
1
19 3
2
0 18 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc13
1
19 4
2
0 18 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc14
1
19 5
2
0 18 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc15
1
19 6
2
0 18 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc16
1
19 7
2
0 18 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc17
1
19 8
2
0 18 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc18
1
19 9
2
0 18 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc19
1
19 10
2
0 18 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc2
1
19 11
2
0 18 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc20
1
19 12
2
0 18 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc21
1
19 13
2
0 18 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc22
1
19 14
2
0 18 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc23
1
19 15
2
0 18 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc3
1
19 16
2
0 18 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc4
1
19 17
2
0 18 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc5
1
19 18
2
0 18 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc6
1
19 19
2
0 18 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc7
1
19 20
2
0 18 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc8
1
19 21
2
0 18 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car19 loc9
1
19 22
2
0 18 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
19 0
2
0 0 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
19 1
2
0 0 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc11
1
19 2
2
0 0 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc12
1
19 3
2
0 0 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc13
1
19 4
2
0 0 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc14
1
19 5
2
0 0 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc15
1
19 6
2
0 0 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc16
1
19 7
2
0 0 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc17
1
19 8
2
0 0 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc18
1
19 9
2
0 0 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc19
1
19 10
2
0 0 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
19 11
2
0 0 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc20
1
19 12
2
0 0 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc21
1
19 13
2
0 0 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc22
1
19 14
2
0 0 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc23
1
19 15
2
0 0 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
19 16
2
0 0 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
19 17
2
0 0 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
19 18
2
0 0 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
19 19
2
0 0 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc7
1
19 20
2
0 0 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc8
1
19 21
2
0 0 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car2 loc9
1
19 22
2
0 0 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
19 0
2
0 2 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
19 1
2
0 2 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc11
1
19 2
2
0 2 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc12
1
19 3
2
0 2 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc13
1
19 4
2
0 2 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc14
1
19 5
2
0 2 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc15
1
19 6
2
0 2 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc16
1
19 7
2
0 2 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc17
1
19 8
2
0 2 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc18
1
19 9
2
0 2 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc19
1
19 10
2
0 2 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
19 11
2
0 2 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc20
1
19 12
2
0 2 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc21
1
19 13
2
0 2 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc22
1
19 14
2
0 2 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc23
1
19 15
2
0 2 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
19 16
2
0 2 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
19 17
2
0 2 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
19 18
2
0 2 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
19 19
2
0 2 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc7
1
19 20
2
0 2 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc8
1
19 21
2
0 2 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car3 loc9
1
19 22
2
0 2 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc1
1
19 0
2
0 4 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
19 1
2
0 4 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc11
1
19 2
2
0 4 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc12
1
19 3
2
0 4 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc13
1
19 4
2
0 4 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc14
1
19 5
2
0 4 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc15
1
19 6
2
0 4 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc16
1
19 7
2
0 4 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc17
1
19 8
2
0 4 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc18
1
19 9
2
0 4 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc19
1
19 10
2
0 4 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc2
1
19 11
2
0 4 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc20
1
19 12
2
0 4 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc21
1
19 13
2
0 4 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc22
1
19 14
2
0 4 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc23
1
19 15
2
0 4 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc3
1
19 16
2
0 4 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc4
1
19 17
2
0 4 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc5
1
19 18
2
0 4 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc6
1
19 19
2
0 4 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc7
1
19 20
2
0 4 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc8
1
19 21
2
0 4 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car4 loc9
1
19 22
2
0 4 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc1
1
19 0
2
0 6 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
19 1
2
0 6 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc11
1
19 2
2
0 6 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc12
1
19 3
2
0 6 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc13
1
19 4
2
0 6 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc14
1
19 5
2
0 6 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc15
1
19 6
2
0 6 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc16
1
19 7
2
0 6 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc17
1
19 8
2
0 6 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc18
1
19 9
2
0 6 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc19
1
19 10
2
0 6 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc2
1
19 11
2
0 6 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc20
1
19 12
2
0 6 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc21
1
19 13
2
0 6 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc22
1
19 14
2
0 6 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc23
1
19 15
2
0 6 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc3
1
19 16
2
0 6 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc4
1
19 17
2
0 6 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc5
1
19 18
2
0 6 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc6
1
19 19
2
0 6 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc7
1
19 20
2
0 6 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc8
1
19 21
2
0 6 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car5 loc9
1
19 22
2
0 6 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc1
1
19 0
2
0 8 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
19 1
2
0 8 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc11
1
19 2
2
0 8 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc12
1
19 3
2
0 8 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc13
1
19 4
2
0 8 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc14
1
19 5
2
0 8 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc15
1
19 6
2
0 8 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc16
1
19 7
2
0 8 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc17
1
19 8
2
0 8 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc18
1
19 9
2
0 8 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc19
1
19 10
2
0 8 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc2
1
19 11
2
0 8 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc20
1
19 12
2
0 8 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc21
1
19 13
2
0 8 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc22
1
19 14
2
0 8 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc23
1
19 15
2
0 8 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc3
1
19 16
2
0 8 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc4
1
19 17
2
0 8 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc5
1
19 18
2
0 8 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc6
1
19 19
2
0 8 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc7
1
19 20
2
0 8 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc8
1
19 21
2
0 8 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car6 loc9
1
19 22
2
0 8 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc1
1
19 0
2
0 10 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
19 1
2
0 10 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc11
1
19 2
2
0 10 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc12
1
19 3
2
0 10 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc13
1
19 4
2
0 10 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc14
1
19 5
2
0 10 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc15
1
19 6
2
0 10 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc16
1
19 7
2
0 10 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc17
1
19 8
2
0 10 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc18
1
19 9
2
0 10 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc19
1
19 10
2
0 10 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc2
1
19 11
2
0 10 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc20
1
19 12
2
0 10 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc21
1
19 13
2
0 10 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc22
1
19 14
2
0 10 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc23
1
19 15
2
0 10 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc3
1
19 16
2
0 10 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc4
1
19 17
2
0 10 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc5
1
19 18
2
0 10 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc6
1
19 19
2
0 10 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc7
1
19 20
2
0 10 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc8
1
19 21
2
0 10 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car7 loc9
1
19 22
2
0 10 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc1
1
19 0
2
0 12 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
19 1
2
0 12 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc11
1
19 2
2
0 12 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc12
1
19 3
2
0 12 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc13
1
19 4
2
0 12 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc14
1
19 5
2
0 12 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc15
1
19 6
2
0 12 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc16
1
19 7
2
0 12 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc17
1
19 8
2
0 12 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc18
1
19 9
2
0 12 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc19
1
19 10
2
0 12 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc2
1
19 11
2
0 12 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc20
1
19 12
2
0 12 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc21
1
19 13
2
0 12 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc22
1
19 14
2
0 12 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc23
1
19 15
2
0 12 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc3
1
19 16
2
0 12 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc4
1
19 17
2
0 12 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc5
1
19 18
2
0 12 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc6
1
19 19
2
0 12 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc7
1
19 20
2
0 12 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc8
1
19 21
2
0 12 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car8 loc9
1
19 22
2
0 12 23 22
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc1
1
19 0
2
0 14 23 0
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
19 1
2
0 14 23 1
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc11
1
19 2
2
0 14 23 2
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc12
1
19 3
2
0 14 23 3
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc13
1
19 4
2
0 14 23 4
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc14
1
19 5
2
0 14 23 5
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc15
1
19 6
2
0 14 23 6
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc16
1
19 7
2
0 14 23 7
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc17
1
19 8
2
0 14 23 8
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc18
1
19 9
2
0 14 23 9
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc19
1
19 10
2
0 14 23 10
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc2
1
19 11
2
0 14 23 11
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc20
1
19 12
2
0 14 23 12
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc21
1
19 13
2
0 14 23 13
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc22
1
19 14
2
0 14 23 14
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc23
1
19 15
2
0 14 23 15
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc3
1
19 16
2
0 14 23 16
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc4
1
19 17
2
0 14 23 17
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc5
1
19 18
2
0 14 23 18
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc6
1
19 19
2
0 14 23 19
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc7
1
19 20
2
0 14 23 20
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc8
1
19 21
2
0 14 23 21
0 43 -1 0
1
end_operator
begin_operator
debark car9 loc9
1
19 22
2
0 14 23 22
0 43 -1 0
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 19 0 1
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 19 0 2
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 19 0 3
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 19 0 4
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 19 0 5
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 19 0 6
0 20 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 19 0 7
0 20 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 19 0 8
0 20 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 19 0 9
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 19 0 10
0 20 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 19 0 11
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 19 0 12
0 20 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 19 0 13
0 20 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 19 0 14
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 19 0 15
0 20 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 19 0 16
0 20 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 19 0 17
0 20 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 19 0 18
0 20 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 19 0 19
0 20 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 19 0 20
0 20 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 19 0 21
0 20 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 19 0 22
0 20 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 19 1 0
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 19 1 2
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 19 1 3
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 19 1 4
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 19 1 5
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 19 1 6
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 19 1 7
0 21 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 19 1 8
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 19 1 9
0 21 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 19 1 10
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 19 1 11
0 21 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 19 1 12
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 19 1 13
0 21 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 19 1 14
0 21 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 19 1 15
0 21 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 19 1 16
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 19 1 17
0 21 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 19 1 18
0 21 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 19 1 19
0 21 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 19 1 20
0 21 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 19 1 21
0 21 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 19 1 22
0 21 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 19 2 0
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 19 2 1
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 19 2 3
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 19 2 4
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 19 2 5
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 19 2 6
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 19 2 7
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 19 2 8
0 22 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 19 2 9
0 22 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 19 2 10
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 19 2 11
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 19 2 12
0 22 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 19 2 13
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 19 2 14
0 22 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 19 2 15
0 22 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 19 2 16
0 22 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 19 2 17
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 19 2 18
0 22 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 19 2 19
0 22 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 19 2 20
0 22 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 19 2 21
0 22 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 19 2 22
0 22 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 19 3 0
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 19 3 1
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 19 3 2
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 19 3 4
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 19 3 5
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 19 3 6
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 19 3 7
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 19 3 8
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 19 3 9
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 19 3 10
0 23 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 19 3 11
0 23 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 19 3 12
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 19 3 13
0 23 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 19 3 14
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 19 3 15
0 23 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 19 3 16
0 23 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 19 3 17
0 23 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 19 3 18
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 19 3 19
0 23 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 19 3 20
0 23 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 19 3 21
0 23 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 19 3 22
0 23 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 19 4 0
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 19 4 1
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 19 4 2
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 19 4 3
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 19 4 5
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 19 4 6
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 19 4 7
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 19 4 8
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 19 4 9
0 24 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 19 4 10
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 19 4 11
0 24 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 19 4 12
0 24 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 19 4 13
0 24 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 19 4 14
0 24 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 19 4 15
0 24 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 19 4 16
0 24 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 19 4 17
0 24 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 19 4 18
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 19 4 19
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 19 4 20
0 24 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 19 4 21
0 24 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 19 4 22
0 24 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 19 5 0
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 19 5 1
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 19 5 2
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 19 5 3
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 19 5 4
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 19 5 6
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 19 5 7
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 19 5 8
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 19 5 9
0 25 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 19 5 10
0 25 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 19 5 11
0 25 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 19 5 12
0 25 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 19 5 13
0 25 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 19 5 14
0 25 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 19 5 15
0 25 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 19 5 16
0 25 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 19 5 17
0 25 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 19 5 18
0 25 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 19 5 19
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 19 5 20
0 25 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 19 5 21
0 25 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 19 5 22
0 25 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 19 6 0
0 20 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 19 6 1
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 19 6 2
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 19 6 3
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 19 6 4
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 19 6 5
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 19 6 7
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 19 6 8
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 19 6 9
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 19 6 10
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 19 6 11
0 26 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 19 6 12
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 19 6 13
0 26 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 19 6 14
0 26 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 19 6 15
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 19 6 16
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 19 6 17
0 26 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 19 6 18
0 26 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 19 6 19
0 26 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 19 6 20
0 26 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 19 6 21
0 26 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 19 6 22
0 26 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 19 7 0
0 20 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 19 7 1
0 21 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 19 7 2
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 19 7 3
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 19 7 4
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 19 7 5
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 19 7 6
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 19 7 8
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 19 7 9
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 19 7 10
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 19 7 11
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 19 7 12
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 19 7 13
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 19 7 14
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 19 7 15
0 27 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 19 7 16
0 27 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 19 7 17
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 19 7 18
0 27 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 19 7 19
0 27 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 19 7 20
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 19 7 21
0 27 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 19 7 22
0 27 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 19 8 0
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 19 8 1
0 21 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 19 8 2
0 22 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 19 8 3
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 19 8 4
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 19 8 5
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 19 8 6
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 19 8 7
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 19 8 9
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 19 8 10
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 19 8 11
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 19 8 12
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 19 8 13
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 19 8 14
0 28 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 19 8 15
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 19 8 16
0 28 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 19 8 17
0 28 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 19 8 18
0 28 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 19 8 19
0 28 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 19 8 20
0 28 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 19 8 21
0 28 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 19 8 22
0 28 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 19 9 0
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 19 9 1
0 21 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 19 9 2
0 22 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 19 9 3
0 23 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 19 9 4
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 19 9 5
0 25 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 19 9 6
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 19 9 7
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 19 9 8
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 19 9 10
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 19 9 11
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 19 9 12
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 19 9 13
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 19 9 14
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 19 9 15
0 29 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 19 9 16
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 19 9 17
0 29 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 19 9 18
0 29 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 19 9 19
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 19 9 20
0 29 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 19 9 21
0 29 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 19 9 22
0 29 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 19 10 0
0 20 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 19 10 1
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 19 10 2
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 19 10 3
0 23 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 19 10 4
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 19 10 5
0 25 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 19 10 6
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 19 10 7
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 19 10 8
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 19 10 9
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 19 10 11
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 19 10 12
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 19 10 13
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 19 10 14
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 19 10 15
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 19 10 16
0 30 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 19 10 17
0 30 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 19 10 18
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 19 10 19
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 19 10 20
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 19 10 21
0 30 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 19 10 22
0 30 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 19 11 0
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 19 11 1
0 21 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 19 11 2
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 19 11 3
0 23 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 19 11 4
0 24 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 19 11 5
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 19 11 6
0 26 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 19 11 7
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 19 11 8
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 19 11 9
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 19 11 10
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 19 11 12
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 19 11 13
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 19 11 14
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 19 11 15
0 31 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 19 11 16
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 19 11 17
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 19 11 18
0 31 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 19 11 19
0 31 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 19 11 20
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 19 11 21
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 19 11 22
0 31 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 19 12 0
0 20 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 19 12 1
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 19 12 2
0 22 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 19 12 3
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 19 12 4
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 19 12 5
0 25 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 19 12 6
0 26 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 19 12 7
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 19 12 8
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 19 12 9
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 19 12 10
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 19 12 11
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 19 12 13
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 19 12 14
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 19 12 15
0 32 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 19 12 16
0 32 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 19 12 17
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 19 12 18
0 32 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 19 12 19
0 32 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 19 12 20
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 19 12 21
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 19 12 22
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 19 13 0
0 20 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 19 13 1
0 21 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 19 13 2
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 19 13 3
0 23 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 19 13 4
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 19 13 5
0 25 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 19 13 6
0 26 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 19 13 7
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 19 13 8
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 19 13 9
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 19 13 10
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 19 13 11
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 19 13 12
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 19 13 14
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 19 13 15
0 33 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 19 13 16
0 33 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 19 13 17
0 33 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 19 13 18
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 19 13 19
0 33 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 19 13 20
0 33 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 19 13 21
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 19 13 22
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 19 14 0
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 19 14 1
0 21 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 19 14 2
0 22 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 19 14 3
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 19 14 4
0 24 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 19 14 5
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 19 14 6
0 26 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 19 14 7
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 19 14 8
0 28 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 19 14 9
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 19 14 10
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 19 14 11
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 19 14 12
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 19 14 13
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 19 14 15
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 19 14 16
0 34 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 19 14 17
0 34 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 19 14 18
0 34 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 19 14 19
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 19 14 20
0 34 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 19 14 21
0 34 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 19 14 22
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 19 15 0
0 20 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 19 15 1
0 21 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 19 15 2
0 22 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 19 15 3
0 23 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 19 15 4
0 24 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 19 15 5
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 19 15 6
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 19 15 7
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 19 15 8
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 19 15 9
0 29 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 19 15 10
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 19 15 11
0 31 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 19 15 12
0 32 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 19 15 13
0 33 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 19 15 14
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 19 15 16
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 19 15 17
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 19 15 18
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 19 15 19
0 35 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 19 15 20
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 19 15 21
0 35 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 19 15 22
0 35 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 19 16 0
0 20 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 19 16 1
0 21 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 19 16 2
0 22 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 19 16 3
0 23 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 19 16 4
0 24 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 19 16 5
0 25 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 19 16 6
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 19 16 7
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 19 16 8
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 19 16 9
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 19 16 10
0 30 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 19 16 11
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 19 16 12
0 32 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 19 16 13
0 33 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 19 16 14
0 34 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 19 16 15
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 19 16 17
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 19 16 18
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 19 16 19
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 19 16 20
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 19 16 21
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 19 16 22
0 36 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 19 17 0
0 20 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 19 17 1
0 21 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 19 17 2
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 19 17 3
0 23 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 19 17 4
0 24 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 19 17 5
0 25 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 19 17 6
0 26 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 19 17 7
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 19 17 8
0 28 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 19 17 9
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 19 17 10
0 30 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 19 17 11
0 31 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 19 17 12
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 19 17 13
0 33 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 19 17 14
0 34 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 19 17 15
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 19 17 16
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 19 17 18
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 19 17 19
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 19 17 20
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 19 17 21
0 37 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 19 17 22
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 19 18 0
0 20 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 19 18 1
0 21 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 19 18 2
0 22 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 19 18 3
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 19 18 4
0 24 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 19 18 5
0 25 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 19 18 6
0 26 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 19 18 7
0 27 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 19 18 8
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 19 18 9
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 19 18 10
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 19 18 11
0 31 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 19 18 12
0 32 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 19 18 13
0 33 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 19 18 14
0 34 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 19 18 15
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 19 18 16
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 19 18 17
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 19 18 19
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 19 18 20
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 19 18 21
0 38 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 19 18 22
0 38 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 19 19 0
0 20 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 19 19 1
0 21 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 19 19 2
0 22 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 19 19 3
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 19 19 4
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 19 19 5
0 25 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 19 19 6
0 26 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 19 19 7
0 27 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 19 19 8
0 28 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 19 19 9
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 19 19 10
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 19 19 11
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 19 19 12
0 32 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 19 19 13
0 33 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 19 19 14
0 34 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 19 19 15
0 35 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 19 19 16
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 19 19 17
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 19 19 18
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 19 19 20
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 19 19 21
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 19 19 22
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 19 20 0
0 20 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 19 20 1
0 21 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 19 20 2
0 22 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 19 20 3
0 23 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 19 20 4
0 24 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 19 20 5
0 25 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 19 20 6
0 26 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 19 20 7
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 19 20 8
0 28 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 19 20 9
0 29 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 19 20 10
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 19 20 11
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 19 20 12
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 19 20 13
0 33 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 19 20 14
0 34 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 19 20 15
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 19 20 16
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 19 20 17
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 19 20 18
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 19 20 19
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 19 20 21
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 19 20 22
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 19 21 0
0 20 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 19 21 1
0 21 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 19 21 2
0 22 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 19 21 3
0 23 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 19 21 4
0 24 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 19 21 5
0 25 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 19 21 6
0 26 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 19 21 7
0 27 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 19 21 8
0 28 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 19 21 9
0 29 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 19 21 10
0 30 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 19 21 11
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 19 21 12
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 19 21 13
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 19 21 14
0 34 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 19 21 15
0 35 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 19 21 16
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 19 21 17
0 37 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 19 21 18
0 38 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 19 21 19
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 19 21 20
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 19 21 22
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 19 22 0
0 20 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 19 22 1
0 21 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 19 22 2
0 22 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 19 22 3
0 23 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 19 22 4
0 24 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 19 22 5
0 25 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 19 22 6
0 26 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 19 22 7
0 27 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 19 22 8
0 28 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 19 22 9
0 29 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 19 22 10
0 30 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 19 22 11
0 31 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 19 22 12
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 19 22 13
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 19 22 14
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 19 22 15
0 35 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 19 22 16
0 36 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 19 22 17
0 37 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 19 22 18
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 19 22 19
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 19 22 20
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 19 22 21
0 41 0 1
0 42 -1 0
1
end_operator
0
