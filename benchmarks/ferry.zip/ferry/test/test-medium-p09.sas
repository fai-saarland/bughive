begin_version
3
end_version
begin_metric
1
end_metric
64
begin_variable
var0
-1
35
empty-ferry
on car1
on car10
on car11
on car12
on car13
on car14
on car15
on car16
on car17
on car18
on car19
on car2
on car20
on car21
on car22
on car23
on car24
on car25
on car26
on car27
on car28
on car29
on car3
on car30
on car31
on car32
on car33
on car34
on car4
on car5
on car6
on car7
on car8
on car9
end_variable
begin_variable
var1
-1
29
at car34 loc1
at car34 loc10
at car34 loc11
at car34 loc12
at car34 loc13
at car34 loc14
at car34 loc15
at car34 loc16
at car34 loc17
at car34 loc18
at car34 loc19
at car34 loc2
at car34 loc20
at car34 loc21
at car34 loc22
at car34 loc23
at car34 loc24
at car34 loc25
at car34 loc26
at car34 loc27
at car34 loc28
at car34 loc3
at car34 loc4
at car34 loc5
at car34 loc6
at car34 loc7
at car34 loc8
at car34 loc9
none-of-those
end_variable
begin_variable
var2
-1
29
at car26 loc1
at car26 loc10
at car26 loc11
at car26 loc12
at car26 loc13
at car26 loc14
at car26 loc15
at car26 loc16
at car26 loc17
at car26 loc18
at car26 loc19
at car26 loc2
at car26 loc20
at car26 loc21
at car26 loc22
at car26 loc23
at car26 loc24
at car26 loc25
at car26 loc26
at car26 loc27
at car26 loc28
at car26 loc3
at car26 loc4
at car26 loc5
at car26 loc6
at car26 loc7
at car26 loc8
at car26 loc9
none-of-those
end_variable
begin_variable
var3
-1
29
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc24
at car18 loc25
at car18 loc26
at car18 loc27
at car18 loc28
at car18 loc3
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
none-of-those
end_variable
begin_variable
var4
-1
29
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc24
at car1 loc25
at car1 loc26
at car1 loc27
at car1 loc28
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var5
-1
29
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc24
at car4 loc25
at car4 loc26
at car4 loc27
at car4 loc28
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var6
-1
29
at car27 loc1
at car27 loc10
at car27 loc11
at car27 loc12
at car27 loc13
at car27 loc14
at car27 loc15
at car27 loc16
at car27 loc17
at car27 loc18
at car27 loc19
at car27 loc2
at car27 loc20
at car27 loc21
at car27 loc22
at car27 loc23
at car27 loc24
at car27 loc25
at car27 loc26
at car27 loc27
at car27 loc28
at car27 loc3
at car27 loc4
at car27 loc5
at car27 loc6
at car27 loc7
at car27 loc8
at car27 loc9
none-of-those
end_variable
begin_variable
var7
-1
29
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc24
at car19 loc25
at car19 loc26
at car19 loc27
at car19 loc28
at car19 loc3
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
none-of-those
end_variable
begin_variable
var8
-1
29
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc24
at car10 loc25
at car10 loc26
at car10 loc27
at car10 loc28
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var9
-1
29
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc24
at car5 loc25
at car5 loc26
at car5 loc27
at car5 loc28
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var10
-1
29
at car28 loc1
at car28 loc10
at car28 loc11
at car28 loc12
at car28 loc13
at car28 loc14
at car28 loc15
at car28 loc16
at car28 loc17
at car28 loc18
at car28 loc19
at car28 loc2
at car28 loc20
at car28 loc21
at car28 loc22
at car28 loc23
at car28 loc24
at car28 loc25
at car28 loc26
at car28 loc27
at car28 loc28
at car28 loc3
at car28 loc4
at car28 loc5
at car28 loc6
at car28 loc7
at car28 loc8
at car28 loc9
none-of-those
end_variable
begin_variable
var11
-1
29
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc24
at car2 loc25
at car2 loc26
at car2 loc27
at car2 loc28
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var12
-1
29
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc24
at car11 loc25
at car11 loc26
at car11 loc27
at car11 loc28
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var13
-1
29
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc24
at car6 loc25
at car6 loc26
at car6 loc27
at car6 loc28
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var14
-1
29
at car29 loc1
at car29 loc10
at car29 loc11
at car29 loc12
at car29 loc13
at car29 loc14
at car29 loc15
at car29 loc16
at car29 loc17
at car29 loc18
at car29 loc19
at car29 loc2
at car29 loc20
at car29 loc21
at car29 loc22
at car29 loc23
at car29 loc24
at car29 loc25
at car29 loc26
at car29 loc27
at car29 loc28
at car29 loc3
at car29 loc4
at car29 loc5
at car29 loc6
at car29 loc7
at car29 loc8
at car29 loc9
none-of-those
end_variable
begin_variable
var15
-1
29
at car20 loc1
at car20 loc10
at car20 loc11
at car20 loc12
at car20 loc13
at car20 loc14
at car20 loc15
at car20 loc16
at car20 loc17
at car20 loc18
at car20 loc19
at car20 loc2
at car20 loc20
at car20 loc21
at car20 loc22
at car20 loc23
at car20 loc24
at car20 loc25
at car20 loc26
at car20 loc27
at car20 loc28
at car20 loc3
at car20 loc4
at car20 loc5
at car20 loc6
at car20 loc7
at car20 loc8
at car20 loc9
none-of-those
end_variable
begin_variable
var16
-1
29
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc24
at car12 loc25
at car12 loc26
at car12 loc27
at car12 loc28
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
none-of-those
end_variable
begin_variable
var17
-1
29
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc24
at car7 loc25
at car7 loc26
at car7 loc27
at car7 loc28
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var18
-1
29
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc24
at car3 loc25
at car3 loc26
at car3 loc27
at car3 loc28
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var19
-1
29
at car21 loc1
at car21 loc10
at car21 loc11
at car21 loc12
at car21 loc13
at car21 loc14
at car21 loc15
at car21 loc16
at car21 loc17
at car21 loc18
at car21 loc19
at car21 loc2
at car21 loc20
at car21 loc21
at car21 loc22
at car21 loc23
at car21 loc24
at car21 loc25
at car21 loc26
at car21 loc27
at car21 loc28
at car21 loc3
at car21 loc4
at car21 loc5
at car21 loc6
at car21 loc7
at car21 loc8
at car21 loc9
none-of-those
end_variable
begin_variable
var20
-1
29
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc24
at car13 loc25
at car13 loc26
at car13 loc27
at car13 loc28
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
none-of-those
end_variable
begin_variable
var21
-1
29
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc24
at car8 loc25
at car8 loc26
at car8 loc27
at car8 loc28
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var22
-1
29
at car30 loc1
at car30 loc10
at car30 loc11
at car30 loc12
at car30 loc13
at car30 loc14
at car30 loc15
at car30 loc16
at car30 loc17
at car30 loc18
at car30 loc19
at car30 loc2
at car30 loc20
at car30 loc21
at car30 loc22
at car30 loc23
at car30 loc24
at car30 loc25
at car30 loc26
at car30 loc27
at car30 loc28
at car30 loc3
at car30 loc4
at car30 loc5
at car30 loc6
at car30 loc7
at car30 loc8
at car30 loc9
none-of-those
end_variable
begin_variable
var23
-1
29
at car22 loc1
at car22 loc10
at car22 loc11
at car22 loc12
at car22 loc13
at car22 loc14
at car22 loc15
at car22 loc16
at car22 loc17
at car22 loc18
at car22 loc19
at car22 loc2
at car22 loc20
at car22 loc21
at car22 loc22
at car22 loc23
at car22 loc24
at car22 loc25
at car22 loc26
at car22 loc27
at car22 loc28
at car22 loc3
at car22 loc4
at car22 loc5
at car22 loc6
at car22 loc7
at car22 loc8
at car22 loc9
none-of-those
end_variable
begin_variable
var24
-1
29
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc24
at car14 loc25
at car14 loc26
at car14 loc27
at car14 loc28
at car14 loc3
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
none-of-those
end_variable
begin_variable
var25
-1
29
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc24
at car9 loc25
at car9 loc26
at car9 loc27
at car9 loc28
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var26
-1
29
at car31 loc1
at car31 loc10
at car31 loc11
at car31 loc12
at car31 loc13
at car31 loc14
at car31 loc15
at car31 loc16
at car31 loc17
at car31 loc18
at car31 loc19
at car31 loc2
at car31 loc20
at car31 loc21
at car31 loc22
at car31 loc23
at car31 loc24
at car31 loc25
at car31 loc26
at car31 loc27
at car31 loc28
at car31 loc3
at car31 loc4
at car31 loc5
at car31 loc6
at car31 loc7
at car31 loc8
at car31 loc9
none-of-those
end_variable
begin_variable
var27
-1
29
at car23 loc1
at car23 loc10
at car23 loc11
at car23 loc12
at car23 loc13
at car23 loc14
at car23 loc15
at car23 loc16
at car23 loc17
at car23 loc18
at car23 loc19
at car23 loc2
at car23 loc20
at car23 loc21
at car23 loc22
at car23 loc23
at car23 loc24
at car23 loc25
at car23 loc26
at car23 loc27
at car23 loc28
at car23 loc3
at car23 loc4
at car23 loc5
at car23 loc6
at car23 loc7
at car23 loc8
at car23 loc9
none-of-those
end_variable
begin_variable
var28
-1
29
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc24
at car15 loc25
at car15 loc26
at car15 loc27
at car15 loc28
at car15 loc3
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
none-of-those
end_variable
begin_variable
var29
-1
28
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc24
at-ferry loc25
at-ferry loc26
at-ferry loc27
at-ferry loc28
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var30
-1
29
at car32 loc1
at car32 loc10
at car32 loc11
at car32 loc12
at car32 loc13
at car32 loc14
at car32 loc15
at car32 loc16
at car32 loc17
at car32 loc18
at car32 loc19
at car32 loc2
at car32 loc20
at car32 loc21
at car32 loc22
at car32 loc23
at car32 loc24
at car32 loc25
at car32 loc26
at car32 loc27
at car32 loc28
at car32 loc3
at car32 loc4
at car32 loc5
at car32 loc6
at car32 loc7
at car32 loc8
at car32 loc9
none-of-those
end_variable
begin_variable
var31
-1
29
at car24 loc1
at car24 loc10
at car24 loc11
at car24 loc12
at car24 loc13
at car24 loc14
at car24 loc15
at car24 loc16
at car24 loc17
at car24 loc18
at car24 loc19
at car24 loc2
at car24 loc20
at car24 loc21
at car24 loc22
at car24 loc23
at car24 loc24
at car24 loc25
at car24 loc26
at car24 loc27
at car24 loc28
at car24 loc3
at car24 loc4
at car24 loc5
at car24 loc6
at car24 loc7
at car24 loc8
at car24 loc9
none-of-those
end_variable
begin_variable
var32
-1
29
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc24
at car16 loc25
at car16 loc26
at car16 loc27
at car16 loc28
at car16 loc3
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
none-of-those
end_variable
begin_variable
var33
-1
29
at car33 loc1
at car33 loc10
at car33 loc11
at car33 loc12
at car33 loc13
at car33 loc14
at car33 loc15
at car33 loc16
at car33 loc17
at car33 loc18
at car33 loc19
at car33 loc2
at car33 loc20
at car33 loc21
at car33 loc22
at car33 loc23
at car33 loc24
at car33 loc25
at car33 loc26
at car33 loc27
at car33 loc28
at car33 loc3
at car33 loc4
at car33 loc5
at car33 loc6
at car33 loc7
at car33 loc8
at car33 loc9
none-of-those
end_variable
begin_variable
var34
-1
29
at car25 loc1
at car25 loc10
at car25 loc11
at car25 loc12
at car25 loc13
at car25 loc14
at car25 loc15
at car25 loc16
at car25 loc17
at car25 loc18
at car25 loc19
at car25 loc2
at car25 loc20
at car25 loc21
at car25 loc22
at car25 loc23
at car25 loc24
at car25 loc25
at car25 loc26
at car25 loc27
at car25 loc28
at car25 loc3
at car25 loc4
at car25 loc5
at car25 loc6
at car25 loc7
at car25 loc8
at car25 loc9
none-of-those
end_variable
begin_variable
var35
-1
29
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc24
at car17 loc25
at car17 loc26
at car17 loc27
at car17 loc28
at car17 loc3
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var47
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var48
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var49
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var50
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var51
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var52
-1
2
NOT-at-ferry loc24
none-of-those
end_variable
begin_variable
var53
-1
2
NOT-at-ferry loc25
none-of-those
end_variable
begin_variable
var54
-1
2
NOT-at-ferry loc26
none-of-those
end_variable
begin_variable
var55
-1
2
NOT-at-ferry loc27
none-of-those
end_variable
begin_variable
var56
-1
2
NOT-at-ferry loc28
none-of-those
end_variable
begin_variable
var57
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var58
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var59
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var60
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var61
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var62
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var63
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
26
18
12
17
8
7
17
27
15
5
1
5
18
8
0
10
17
7
10
14
14
2
16
19
4
13
22
1
22
13
20
7
16
5
16
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
end_state
begin_goal
34
1 27
2 24
3 27
4 15
5 11
6 9
7 2
8 21
9 26
10 9
11 26
12 27
13 12
14 0
15 12
16 5
17 4
18 1
19 25
20 1
21 10
22 5
23 5
24 10
25 22
26 4
27 24
28 7
30 0
31 22
32 10
33 21
34 0
35 10
end_goal
2660
begin_operator
board car1 loc1
1
29 0
2
0 0 0 1
0 4 0 28
1
end_operator
begin_operator
board car1 loc10
1
29 1
2
0 0 0 1
0 4 1 28
1
end_operator
begin_operator
board car1 loc11
1
29 2
2
0 0 0 1
0 4 2 28
1
end_operator
begin_operator
board car1 loc12
1
29 3
2
0 0 0 1
0 4 3 28
1
end_operator
begin_operator
board car1 loc13
1
29 4
2
0 0 0 1
0 4 4 28
1
end_operator
begin_operator
board car1 loc14
1
29 5
2
0 0 0 1
0 4 5 28
1
end_operator
begin_operator
board car1 loc15
1
29 6
2
0 0 0 1
0 4 6 28
1
end_operator
begin_operator
board car1 loc16
1
29 7
2
0 0 0 1
0 4 7 28
1
end_operator
begin_operator
board car1 loc17
1
29 8
2
0 0 0 1
0 4 8 28
1
end_operator
begin_operator
board car1 loc18
1
29 9
2
0 0 0 1
0 4 9 28
1
end_operator
begin_operator
board car1 loc19
1
29 10
2
0 0 0 1
0 4 10 28
1
end_operator
begin_operator
board car1 loc2
1
29 11
2
0 0 0 1
0 4 11 28
1
end_operator
begin_operator
board car1 loc20
1
29 12
2
0 0 0 1
0 4 12 28
1
end_operator
begin_operator
board car1 loc21
1
29 13
2
0 0 0 1
0 4 13 28
1
end_operator
begin_operator
board car1 loc22
1
29 14
2
0 0 0 1
0 4 14 28
1
end_operator
begin_operator
board car1 loc23
1
29 15
2
0 0 0 1
0 4 15 28
1
end_operator
begin_operator
board car1 loc24
1
29 16
2
0 0 0 1
0 4 16 28
1
end_operator
begin_operator
board car1 loc25
1
29 17
2
0 0 0 1
0 4 17 28
1
end_operator
begin_operator
board car1 loc26
1
29 18
2
0 0 0 1
0 4 18 28
1
end_operator
begin_operator
board car1 loc27
1
29 19
2
0 0 0 1
0 4 19 28
1
end_operator
begin_operator
board car1 loc28
1
29 20
2
0 0 0 1
0 4 20 28
1
end_operator
begin_operator
board car1 loc3
1
29 21
2
0 0 0 1
0 4 21 28
1
end_operator
begin_operator
board car1 loc4
1
29 22
2
0 0 0 1
0 4 22 28
1
end_operator
begin_operator
board car1 loc5
1
29 23
2
0 0 0 1
0 4 23 28
1
end_operator
begin_operator
board car1 loc6
1
29 24
2
0 0 0 1
0 4 24 28
1
end_operator
begin_operator
board car1 loc7
1
29 25
2
0 0 0 1
0 4 25 28
1
end_operator
begin_operator
board car1 loc8
1
29 26
2
0 0 0 1
0 4 26 28
1
end_operator
begin_operator
board car1 loc9
1
29 27
2
0 0 0 1
0 4 27 28
1
end_operator
begin_operator
board car10 loc1
1
29 0
2
0 0 0 2
0 8 0 28
1
end_operator
begin_operator
board car10 loc10
1
29 1
2
0 0 0 2
0 8 1 28
1
end_operator
begin_operator
board car10 loc11
1
29 2
2
0 0 0 2
0 8 2 28
1
end_operator
begin_operator
board car10 loc12
1
29 3
2
0 0 0 2
0 8 3 28
1
end_operator
begin_operator
board car10 loc13
1
29 4
2
0 0 0 2
0 8 4 28
1
end_operator
begin_operator
board car10 loc14
1
29 5
2
0 0 0 2
0 8 5 28
1
end_operator
begin_operator
board car10 loc15
1
29 6
2
0 0 0 2
0 8 6 28
1
end_operator
begin_operator
board car10 loc16
1
29 7
2
0 0 0 2
0 8 7 28
1
end_operator
begin_operator
board car10 loc17
1
29 8
2
0 0 0 2
0 8 8 28
1
end_operator
begin_operator
board car10 loc18
1
29 9
2
0 0 0 2
0 8 9 28
1
end_operator
begin_operator
board car10 loc19
1
29 10
2
0 0 0 2
0 8 10 28
1
end_operator
begin_operator
board car10 loc2
1
29 11
2
0 0 0 2
0 8 11 28
1
end_operator
begin_operator
board car10 loc20
1
29 12
2
0 0 0 2
0 8 12 28
1
end_operator
begin_operator
board car10 loc21
1
29 13
2
0 0 0 2
0 8 13 28
1
end_operator
begin_operator
board car10 loc22
1
29 14
2
0 0 0 2
0 8 14 28
1
end_operator
begin_operator
board car10 loc23
1
29 15
2
0 0 0 2
0 8 15 28
1
end_operator
begin_operator
board car10 loc24
1
29 16
2
0 0 0 2
0 8 16 28
1
end_operator
begin_operator
board car10 loc25
1
29 17
2
0 0 0 2
0 8 17 28
1
end_operator
begin_operator
board car10 loc26
1
29 18
2
0 0 0 2
0 8 18 28
1
end_operator
begin_operator
board car10 loc27
1
29 19
2
0 0 0 2
0 8 19 28
1
end_operator
begin_operator
board car10 loc28
1
29 20
2
0 0 0 2
0 8 20 28
1
end_operator
begin_operator
board car10 loc3
1
29 21
2
0 0 0 2
0 8 21 28
1
end_operator
begin_operator
board car10 loc4
1
29 22
2
0 0 0 2
0 8 22 28
1
end_operator
begin_operator
board car10 loc5
1
29 23
2
0 0 0 2
0 8 23 28
1
end_operator
begin_operator
board car10 loc6
1
29 24
2
0 0 0 2
0 8 24 28
1
end_operator
begin_operator
board car10 loc7
1
29 25
2
0 0 0 2
0 8 25 28
1
end_operator
begin_operator
board car10 loc8
1
29 26
2
0 0 0 2
0 8 26 28
1
end_operator
begin_operator
board car10 loc9
1
29 27
2
0 0 0 2
0 8 27 28
1
end_operator
begin_operator
board car11 loc1
1
29 0
2
0 0 0 3
0 12 0 28
1
end_operator
begin_operator
board car11 loc10
1
29 1
2
0 0 0 3
0 12 1 28
1
end_operator
begin_operator
board car11 loc11
1
29 2
2
0 0 0 3
0 12 2 28
1
end_operator
begin_operator
board car11 loc12
1
29 3
2
0 0 0 3
0 12 3 28
1
end_operator
begin_operator
board car11 loc13
1
29 4
2
0 0 0 3
0 12 4 28
1
end_operator
begin_operator
board car11 loc14
1
29 5
2
0 0 0 3
0 12 5 28
1
end_operator
begin_operator
board car11 loc15
1
29 6
2
0 0 0 3
0 12 6 28
1
end_operator
begin_operator
board car11 loc16
1
29 7
2
0 0 0 3
0 12 7 28
1
end_operator
begin_operator
board car11 loc17
1
29 8
2
0 0 0 3
0 12 8 28
1
end_operator
begin_operator
board car11 loc18
1
29 9
2
0 0 0 3
0 12 9 28
1
end_operator
begin_operator
board car11 loc19
1
29 10
2
0 0 0 3
0 12 10 28
1
end_operator
begin_operator
board car11 loc2
1
29 11
2
0 0 0 3
0 12 11 28
1
end_operator
begin_operator
board car11 loc20
1
29 12
2
0 0 0 3
0 12 12 28
1
end_operator
begin_operator
board car11 loc21
1
29 13
2
0 0 0 3
0 12 13 28
1
end_operator
begin_operator
board car11 loc22
1
29 14
2
0 0 0 3
0 12 14 28
1
end_operator
begin_operator
board car11 loc23
1
29 15
2
0 0 0 3
0 12 15 28
1
end_operator
begin_operator
board car11 loc24
1
29 16
2
0 0 0 3
0 12 16 28
1
end_operator
begin_operator
board car11 loc25
1
29 17
2
0 0 0 3
0 12 17 28
1
end_operator
begin_operator
board car11 loc26
1
29 18
2
0 0 0 3
0 12 18 28
1
end_operator
begin_operator
board car11 loc27
1
29 19
2
0 0 0 3
0 12 19 28
1
end_operator
begin_operator
board car11 loc28
1
29 20
2
0 0 0 3
0 12 20 28
1
end_operator
begin_operator
board car11 loc3
1
29 21
2
0 0 0 3
0 12 21 28
1
end_operator
begin_operator
board car11 loc4
1
29 22
2
0 0 0 3
0 12 22 28
1
end_operator
begin_operator
board car11 loc5
1
29 23
2
0 0 0 3
0 12 23 28
1
end_operator
begin_operator
board car11 loc6
1
29 24
2
0 0 0 3
0 12 24 28
1
end_operator
begin_operator
board car11 loc7
1
29 25
2
0 0 0 3
0 12 25 28
1
end_operator
begin_operator
board car11 loc8
1
29 26
2
0 0 0 3
0 12 26 28
1
end_operator
begin_operator
board car11 loc9
1
29 27
2
0 0 0 3
0 12 27 28
1
end_operator
begin_operator
board car12 loc1
1
29 0
2
0 0 0 4
0 16 0 28
1
end_operator
begin_operator
board car12 loc10
1
29 1
2
0 0 0 4
0 16 1 28
1
end_operator
begin_operator
board car12 loc11
1
29 2
2
0 0 0 4
0 16 2 28
1
end_operator
begin_operator
board car12 loc12
1
29 3
2
0 0 0 4
0 16 3 28
1
end_operator
begin_operator
board car12 loc13
1
29 4
2
0 0 0 4
0 16 4 28
1
end_operator
begin_operator
board car12 loc14
1
29 5
2
0 0 0 4
0 16 5 28
1
end_operator
begin_operator
board car12 loc15
1
29 6
2
0 0 0 4
0 16 6 28
1
end_operator
begin_operator
board car12 loc16
1
29 7
2
0 0 0 4
0 16 7 28
1
end_operator
begin_operator
board car12 loc17
1
29 8
2
0 0 0 4
0 16 8 28
1
end_operator
begin_operator
board car12 loc18
1
29 9
2
0 0 0 4
0 16 9 28
1
end_operator
begin_operator
board car12 loc19
1
29 10
2
0 0 0 4
0 16 10 28
1
end_operator
begin_operator
board car12 loc2
1
29 11
2
0 0 0 4
0 16 11 28
1
end_operator
begin_operator
board car12 loc20
1
29 12
2
0 0 0 4
0 16 12 28
1
end_operator
begin_operator
board car12 loc21
1
29 13
2
0 0 0 4
0 16 13 28
1
end_operator
begin_operator
board car12 loc22
1
29 14
2
0 0 0 4
0 16 14 28
1
end_operator
begin_operator
board car12 loc23
1
29 15
2
0 0 0 4
0 16 15 28
1
end_operator
begin_operator
board car12 loc24
1
29 16
2
0 0 0 4
0 16 16 28
1
end_operator
begin_operator
board car12 loc25
1
29 17
2
0 0 0 4
0 16 17 28
1
end_operator
begin_operator
board car12 loc26
1
29 18
2
0 0 0 4
0 16 18 28
1
end_operator
begin_operator
board car12 loc27
1
29 19
2
0 0 0 4
0 16 19 28
1
end_operator
begin_operator
board car12 loc28
1
29 20
2
0 0 0 4
0 16 20 28
1
end_operator
begin_operator
board car12 loc3
1
29 21
2
0 0 0 4
0 16 21 28
1
end_operator
begin_operator
board car12 loc4
1
29 22
2
0 0 0 4
0 16 22 28
1
end_operator
begin_operator
board car12 loc5
1
29 23
2
0 0 0 4
0 16 23 28
1
end_operator
begin_operator
board car12 loc6
1
29 24
2
0 0 0 4
0 16 24 28
1
end_operator
begin_operator
board car12 loc7
1
29 25
2
0 0 0 4
0 16 25 28
1
end_operator
begin_operator
board car12 loc8
1
29 26
2
0 0 0 4
0 16 26 28
1
end_operator
begin_operator
board car12 loc9
1
29 27
2
0 0 0 4
0 16 27 28
1
end_operator
begin_operator
board car13 loc1
1
29 0
2
0 0 0 5
0 20 0 28
1
end_operator
begin_operator
board car13 loc10
1
29 1
2
0 0 0 5
0 20 1 28
1
end_operator
begin_operator
board car13 loc11
1
29 2
2
0 0 0 5
0 20 2 28
1
end_operator
begin_operator
board car13 loc12
1
29 3
2
0 0 0 5
0 20 3 28
1
end_operator
begin_operator
board car13 loc13
1
29 4
2
0 0 0 5
0 20 4 28
1
end_operator
begin_operator
board car13 loc14
1
29 5
2
0 0 0 5
0 20 5 28
1
end_operator
begin_operator
board car13 loc15
1
29 6
2
0 0 0 5
0 20 6 28
1
end_operator
begin_operator
board car13 loc16
1
29 7
2
0 0 0 5
0 20 7 28
1
end_operator
begin_operator
board car13 loc17
1
29 8
2
0 0 0 5
0 20 8 28
1
end_operator
begin_operator
board car13 loc18
1
29 9
2
0 0 0 5
0 20 9 28
1
end_operator
begin_operator
board car13 loc19
1
29 10
2
0 0 0 5
0 20 10 28
1
end_operator
begin_operator
board car13 loc2
1
29 11
2
0 0 0 5
0 20 11 28
1
end_operator
begin_operator
board car13 loc20
1
29 12
2
0 0 0 5
0 20 12 28
1
end_operator
begin_operator
board car13 loc21
1
29 13
2
0 0 0 5
0 20 13 28
1
end_operator
begin_operator
board car13 loc22
1
29 14
2
0 0 0 5
0 20 14 28
1
end_operator
begin_operator
board car13 loc23
1
29 15
2
0 0 0 5
0 20 15 28
1
end_operator
begin_operator
board car13 loc24
1
29 16
2
0 0 0 5
0 20 16 28
1
end_operator
begin_operator
board car13 loc25
1
29 17
2
0 0 0 5
0 20 17 28
1
end_operator
begin_operator
board car13 loc26
1
29 18
2
0 0 0 5
0 20 18 28
1
end_operator
begin_operator
board car13 loc27
1
29 19
2
0 0 0 5
0 20 19 28
1
end_operator
begin_operator
board car13 loc28
1
29 20
2
0 0 0 5
0 20 20 28
1
end_operator
begin_operator
board car13 loc3
1
29 21
2
0 0 0 5
0 20 21 28
1
end_operator
begin_operator
board car13 loc4
1
29 22
2
0 0 0 5
0 20 22 28
1
end_operator
begin_operator
board car13 loc5
1
29 23
2
0 0 0 5
0 20 23 28
1
end_operator
begin_operator
board car13 loc6
1
29 24
2
0 0 0 5
0 20 24 28
1
end_operator
begin_operator
board car13 loc7
1
29 25
2
0 0 0 5
0 20 25 28
1
end_operator
begin_operator
board car13 loc8
1
29 26
2
0 0 0 5
0 20 26 28
1
end_operator
begin_operator
board car13 loc9
1
29 27
2
0 0 0 5
0 20 27 28
1
end_operator
begin_operator
board car14 loc1
1
29 0
2
0 0 0 6
0 24 0 28
1
end_operator
begin_operator
board car14 loc10
1
29 1
2
0 0 0 6
0 24 1 28
1
end_operator
begin_operator
board car14 loc11
1
29 2
2
0 0 0 6
0 24 2 28
1
end_operator
begin_operator
board car14 loc12
1
29 3
2
0 0 0 6
0 24 3 28
1
end_operator
begin_operator
board car14 loc13
1
29 4
2
0 0 0 6
0 24 4 28
1
end_operator
begin_operator
board car14 loc14
1
29 5
2
0 0 0 6
0 24 5 28
1
end_operator
begin_operator
board car14 loc15
1
29 6
2
0 0 0 6
0 24 6 28
1
end_operator
begin_operator
board car14 loc16
1
29 7
2
0 0 0 6
0 24 7 28
1
end_operator
begin_operator
board car14 loc17
1
29 8
2
0 0 0 6
0 24 8 28
1
end_operator
begin_operator
board car14 loc18
1
29 9
2
0 0 0 6
0 24 9 28
1
end_operator
begin_operator
board car14 loc19
1
29 10
2
0 0 0 6
0 24 10 28
1
end_operator
begin_operator
board car14 loc2
1
29 11
2
0 0 0 6
0 24 11 28
1
end_operator
begin_operator
board car14 loc20
1
29 12
2
0 0 0 6
0 24 12 28
1
end_operator
begin_operator
board car14 loc21
1
29 13
2
0 0 0 6
0 24 13 28
1
end_operator
begin_operator
board car14 loc22
1
29 14
2
0 0 0 6
0 24 14 28
1
end_operator
begin_operator
board car14 loc23
1
29 15
2
0 0 0 6
0 24 15 28
1
end_operator
begin_operator
board car14 loc24
1
29 16
2
0 0 0 6
0 24 16 28
1
end_operator
begin_operator
board car14 loc25
1
29 17
2
0 0 0 6
0 24 17 28
1
end_operator
begin_operator
board car14 loc26
1
29 18
2
0 0 0 6
0 24 18 28
1
end_operator
begin_operator
board car14 loc27
1
29 19
2
0 0 0 6
0 24 19 28
1
end_operator
begin_operator
board car14 loc28
1
29 20
2
0 0 0 6
0 24 20 28
1
end_operator
begin_operator
board car14 loc3
1
29 21
2
0 0 0 6
0 24 21 28
1
end_operator
begin_operator
board car14 loc4
1
29 22
2
0 0 0 6
0 24 22 28
1
end_operator
begin_operator
board car14 loc5
1
29 23
2
0 0 0 6
0 24 23 28
1
end_operator
begin_operator
board car14 loc6
1
29 24
2
0 0 0 6
0 24 24 28
1
end_operator
begin_operator
board car14 loc7
1
29 25
2
0 0 0 6
0 24 25 28
1
end_operator
begin_operator
board car14 loc8
1
29 26
2
0 0 0 6
0 24 26 28
1
end_operator
begin_operator
board car14 loc9
1
29 27
2
0 0 0 6
0 24 27 28
1
end_operator
begin_operator
board car15 loc1
1
29 0
2
0 0 0 7
0 28 0 28
1
end_operator
begin_operator
board car15 loc10
1
29 1
2
0 0 0 7
0 28 1 28
1
end_operator
begin_operator
board car15 loc11
1
29 2
2
0 0 0 7
0 28 2 28
1
end_operator
begin_operator
board car15 loc12
1
29 3
2
0 0 0 7
0 28 3 28
1
end_operator
begin_operator
board car15 loc13
1
29 4
2
0 0 0 7
0 28 4 28
1
end_operator
begin_operator
board car15 loc14
1
29 5
2
0 0 0 7
0 28 5 28
1
end_operator
begin_operator
board car15 loc15
1
29 6
2
0 0 0 7
0 28 6 28
1
end_operator
begin_operator
board car15 loc16
1
29 7
2
0 0 0 7
0 28 7 28
1
end_operator
begin_operator
board car15 loc17
1
29 8
2
0 0 0 7
0 28 8 28
1
end_operator
begin_operator
board car15 loc18
1
29 9
2
0 0 0 7
0 28 9 28
1
end_operator
begin_operator
board car15 loc19
1
29 10
2
0 0 0 7
0 28 10 28
1
end_operator
begin_operator
board car15 loc2
1
29 11
2
0 0 0 7
0 28 11 28
1
end_operator
begin_operator
board car15 loc20
1
29 12
2
0 0 0 7
0 28 12 28
1
end_operator
begin_operator
board car15 loc21
1
29 13
2
0 0 0 7
0 28 13 28
1
end_operator
begin_operator
board car15 loc22
1
29 14
2
0 0 0 7
0 28 14 28
1
end_operator
begin_operator
board car15 loc23
1
29 15
2
0 0 0 7
0 28 15 28
1
end_operator
begin_operator
board car15 loc24
1
29 16
2
0 0 0 7
0 28 16 28
1
end_operator
begin_operator
board car15 loc25
1
29 17
2
0 0 0 7
0 28 17 28
1
end_operator
begin_operator
board car15 loc26
1
29 18
2
0 0 0 7
0 28 18 28
1
end_operator
begin_operator
board car15 loc27
1
29 19
2
0 0 0 7
0 28 19 28
1
end_operator
begin_operator
board car15 loc28
1
29 20
2
0 0 0 7
0 28 20 28
1
end_operator
begin_operator
board car15 loc3
1
29 21
2
0 0 0 7
0 28 21 28
1
end_operator
begin_operator
board car15 loc4
1
29 22
2
0 0 0 7
0 28 22 28
1
end_operator
begin_operator
board car15 loc5
1
29 23
2
0 0 0 7
0 28 23 28
1
end_operator
begin_operator
board car15 loc6
1
29 24
2
0 0 0 7
0 28 24 28
1
end_operator
begin_operator
board car15 loc7
1
29 25
2
0 0 0 7
0 28 25 28
1
end_operator
begin_operator
board car15 loc8
1
29 26
2
0 0 0 7
0 28 26 28
1
end_operator
begin_operator
board car15 loc9
1
29 27
2
0 0 0 7
0 28 27 28
1
end_operator
begin_operator
board car16 loc1
1
29 0
2
0 0 0 8
0 32 0 28
1
end_operator
begin_operator
board car16 loc10
1
29 1
2
0 0 0 8
0 32 1 28
1
end_operator
begin_operator
board car16 loc11
1
29 2
2
0 0 0 8
0 32 2 28
1
end_operator
begin_operator
board car16 loc12
1
29 3
2
0 0 0 8
0 32 3 28
1
end_operator
begin_operator
board car16 loc13
1
29 4
2
0 0 0 8
0 32 4 28
1
end_operator
begin_operator
board car16 loc14
1
29 5
2
0 0 0 8
0 32 5 28
1
end_operator
begin_operator
board car16 loc15
1
29 6
2
0 0 0 8
0 32 6 28
1
end_operator
begin_operator
board car16 loc16
1
29 7
2
0 0 0 8
0 32 7 28
1
end_operator
begin_operator
board car16 loc17
1
29 8
2
0 0 0 8
0 32 8 28
1
end_operator
begin_operator
board car16 loc18
1
29 9
2
0 0 0 8
0 32 9 28
1
end_operator
begin_operator
board car16 loc19
1
29 10
2
0 0 0 8
0 32 10 28
1
end_operator
begin_operator
board car16 loc2
1
29 11
2
0 0 0 8
0 32 11 28
1
end_operator
begin_operator
board car16 loc20
1
29 12
2
0 0 0 8
0 32 12 28
1
end_operator
begin_operator
board car16 loc21
1
29 13
2
0 0 0 8
0 32 13 28
1
end_operator
begin_operator
board car16 loc22
1
29 14
2
0 0 0 8
0 32 14 28
1
end_operator
begin_operator
board car16 loc23
1
29 15
2
0 0 0 8
0 32 15 28
1
end_operator
begin_operator
board car16 loc24
1
29 16
2
0 0 0 8
0 32 16 28
1
end_operator
begin_operator
board car16 loc25
1
29 17
2
0 0 0 8
0 32 17 28
1
end_operator
begin_operator
board car16 loc26
1
29 18
2
0 0 0 8
0 32 18 28
1
end_operator
begin_operator
board car16 loc27
1
29 19
2
0 0 0 8
0 32 19 28
1
end_operator
begin_operator
board car16 loc28
1
29 20
2
0 0 0 8
0 32 20 28
1
end_operator
begin_operator
board car16 loc3
1
29 21
2
0 0 0 8
0 32 21 28
1
end_operator
begin_operator
board car16 loc4
1
29 22
2
0 0 0 8
0 32 22 28
1
end_operator
begin_operator
board car16 loc5
1
29 23
2
0 0 0 8
0 32 23 28
1
end_operator
begin_operator
board car16 loc6
1
29 24
2
0 0 0 8
0 32 24 28
1
end_operator
begin_operator
board car16 loc7
1
29 25
2
0 0 0 8
0 32 25 28
1
end_operator
begin_operator
board car16 loc8
1
29 26
2
0 0 0 8
0 32 26 28
1
end_operator
begin_operator
board car16 loc9
1
29 27
2
0 0 0 8
0 32 27 28
1
end_operator
begin_operator
board car17 loc1
1
29 0
2
0 0 0 9
0 35 0 28
1
end_operator
begin_operator
board car17 loc10
1
29 1
2
0 0 0 9
0 35 1 28
1
end_operator
begin_operator
board car17 loc11
1
29 2
2
0 0 0 9
0 35 2 28
1
end_operator
begin_operator
board car17 loc12
1
29 3
2
0 0 0 9
0 35 3 28
1
end_operator
begin_operator
board car17 loc13
1
29 4
2
0 0 0 9
0 35 4 28
1
end_operator
begin_operator
board car17 loc14
1
29 5
2
0 0 0 9
0 35 5 28
1
end_operator
begin_operator
board car17 loc15
1
29 6
2
0 0 0 9
0 35 6 28
1
end_operator
begin_operator
board car17 loc16
1
29 7
2
0 0 0 9
0 35 7 28
1
end_operator
begin_operator
board car17 loc17
1
29 8
2
0 0 0 9
0 35 8 28
1
end_operator
begin_operator
board car17 loc18
1
29 9
2
0 0 0 9
0 35 9 28
1
end_operator
begin_operator
board car17 loc19
1
29 10
2
0 0 0 9
0 35 10 28
1
end_operator
begin_operator
board car17 loc2
1
29 11
2
0 0 0 9
0 35 11 28
1
end_operator
begin_operator
board car17 loc20
1
29 12
2
0 0 0 9
0 35 12 28
1
end_operator
begin_operator
board car17 loc21
1
29 13
2
0 0 0 9
0 35 13 28
1
end_operator
begin_operator
board car17 loc22
1
29 14
2
0 0 0 9
0 35 14 28
1
end_operator
begin_operator
board car17 loc23
1
29 15
2
0 0 0 9
0 35 15 28
1
end_operator
begin_operator
board car17 loc24
1
29 16
2
0 0 0 9
0 35 16 28
1
end_operator
begin_operator
board car17 loc25
1
29 17
2
0 0 0 9
0 35 17 28
1
end_operator
begin_operator
board car17 loc26
1
29 18
2
0 0 0 9
0 35 18 28
1
end_operator
begin_operator
board car17 loc27
1
29 19
2
0 0 0 9
0 35 19 28
1
end_operator
begin_operator
board car17 loc28
1
29 20
2
0 0 0 9
0 35 20 28
1
end_operator
begin_operator
board car17 loc3
1
29 21
2
0 0 0 9
0 35 21 28
1
end_operator
begin_operator
board car17 loc4
1
29 22
2
0 0 0 9
0 35 22 28
1
end_operator
begin_operator
board car17 loc5
1
29 23
2
0 0 0 9
0 35 23 28
1
end_operator
begin_operator
board car17 loc6
1
29 24
2
0 0 0 9
0 35 24 28
1
end_operator
begin_operator
board car17 loc7
1
29 25
2
0 0 0 9
0 35 25 28
1
end_operator
begin_operator
board car17 loc8
1
29 26
2
0 0 0 9
0 35 26 28
1
end_operator
begin_operator
board car17 loc9
1
29 27
2
0 0 0 9
0 35 27 28
1
end_operator
begin_operator
board car18 loc1
1
29 0
2
0 0 0 10
0 3 0 28
1
end_operator
begin_operator
board car18 loc10
1
29 1
2
0 0 0 10
0 3 1 28
1
end_operator
begin_operator
board car18 loc11
1
29 2
2
0 0 0 10
0 3 2 28
1
end_operator
begin_operator
board car18 loc12
1
29 3
2
0 0 0 10
0 3 3 28
1
end_operator
begin_operator
board car18 loc13
1
29 4
2
0 0 0 10
0 3 4 28
1
end_operator
begin_operator
board car18 loc14
1
29 5
2
0 0 0 10
0 3 5 28
1
end_operator
begin_operator
board car18 loc15
1
29 6
2
0 0 0 10
0 3 6 28
1
end_operator
begin_operator
board car18 loc16
1
29 7
2
0 0 0 10
0 3 7 28
1
end_operator
begin_operator
board car18 loc17
1
29 8
2
0 0 0 10
0 3 8 28
1
end_operator
begin_operator
board car18 loc18
1
29 9
2
0 0 0 10
0 3 9 28
1
end_operator
begin_operator
board car18 loc19
1
29 10
2
0 0 0 10
0 3 10 28
1
end_operator
begin_operator
board car18 loc2
1
29 11
2
0 0 0 10
0 3 11 28
1
end_operator
begin_operator
board car18 loc20
1
29 12
2
0 0 0 10
0 3 12 28
1
end_operator
begin_operator
board car18 loc21
1
29 13
2
0 0 0 10
0 3 13 28
1
end_operator
begin_operator
board car18 loc22
1
29 14
2
0 0 0 10
0 3 14 28
1
end_operator
begin_operator
board car18 loc23
1
29 15
2
0 0 0 10
0 3 15 28
1
end_operator
begin_operator
board car18 loc24
1
29 16
2
0 0 0 10
0 3 16 28
1
end_operator
begin_operator
board car18 loc25
1
29 17
2
0 0 0 10
0 3 17 28
1
end_operator
begin_operator
board car18 loc26
1
29 18
2
0 0 0 10
0 3 18 28
1
end_operator
begin_operator
board car18 loc27
1
29 19
2
0 0 0 10
0 3 19 28
1
end_operator
begin_operator
board car18 loc28
1
29 20
2
0 0 0 10
0 3 20 28
1
end_operator
begin_operator
board car18 loc3
1
29 21
2
0 0 0 10
0 3 21 28
1
end_operator
begin_operator
board car18 loc4
1
29 22
2
0 0 0 10
0 3 22 28
1
end_operator
begin_operator
board car18 loc5
1
29 23
2
0 0 0 10
0 3 23 28
1
end_operator
begin_operator
board car18 loc6
1
29 24
2
0 0 0 10
0 3 24 28
1
end_operator
begin_operator
board car18 loc7
1
29 25
2
0 0 0 10
0 3 25 28
1
end_operator
begin_operator
board car18 loc8
1
29 26
2
0 0 0 10
0 3 26 28
1
end_operator
begin_operator
board car18 loc9
1
29 27
2
0 0 0 10
0 3 27 28
1
end_operator
begin_operator
board car19 loc1
1
29 0
2
0 0 0 11
0 7 0 28
1
end_operator
begin_operator
board car19 loc10
1
29 1
2
0 0 0 11
0 7 1 28
1
end_operator
begin_operator
board car19 loc11
1
29 2
2
0 0 0 11
0 7 2 28
1
end_operator
begin_operator
board car19 loc12
1
29 3
2
0 0 0 11
0 7 3 28
1
end_operator
begin_operator
board car19 loc13
1
29 4
2
0 0 0 11
0 7 4 28
1
end_operator
begin_operator
board car19 loc14
1
29 5
2
0 0 0 11
0 7 5 28
1
end_operator
begin_operator
board car19 loc15
1
29 6
2
0 0 0 11
0 7 6 28
1
end_operator
begin_operator
board car19 loc16
1
29 7
2
0 0 0 11
0 7 7 28
1
end_operator
begin_operator
board car19 loc17
1
29 8
2
0 0 0 11
0 7 8 28
1
end_operator
begin_operator
board car19 loc18
1
29 9
2
0 0 0 11
0 7 9 28
1
end_operator
begin_operator
board car19 loc19
1
29 10
2
0 0 0 11
0 7 10 28
1
end_operator
begin_operator
board car19 loc2
1
29 11
2
0 0 0 11
0 7 11 28
1
end_operator
begin_operator
board car19 loc20
1
29 12
2
0 0 0 11
0 7 12 28
1
end_operator
begin_operator
board car19 loc21
1
29 13
2
0 0 0 11
0 7 13 28
1
end_operator
begin_operator
board car19 loc22
1
29 14
2
0 0 0 11
0 7 14 28
1
end_operator
begin_operator
board car19 loc23
1
29 15
2
0 0 0 11
0 7 15 28
1
end_operator
begin_operator
board car19 loc24
1
29 16
2
0 0 0 11
0 7 16 28
1
end_operator
begin_operator
board car19 loc25
1
29 17
2
0 0 0 11
0 7 17 28
1
end_operator
begin_operator
board car19 loc26
1
29 18
2
0 0 0 11
0 7 18 28
1
end_operator
begin_operator
board car19 loc27
1
29 19
2
0 0 0 11
0 7 19 28
1
end_operator
begin_operator
board car19 loc28
1
29 20
2
0 0 0 11
0 7 20 28
1
end_operator
begin_operator
board car19 loc3
1
29 21
2
0 0 0 11
0 7 21 28
1
end_operator
begin_operator
board car19 loc4
1
29 22
2
0 0 0 11
0 7 22 28
1
end_operator
begin_operator
board car19 loc5
1
29 23
2
0 0 0 11
0 7 23 28
1
end_operator
begin_operator
board car19 loc6
1
29 24
2
0 0 0 11
0 7 24 28
1
end_operator
begin_operator
board car19 loc7
1
29 25
2
0 0 0 11
0 7 25 28
1
end_operator
begin_operator
board car19 loc8
1
29 26
2
0 0 0 11
0 7 26 28
1
end_operator
begin_operator
board car19 loc9
1
29 27
2
0 0 0 11
0 7 27 28
1
end_operator
begin_operator
board car2 loc1
1
29 0
2
0 0 0 12
0 11 0 28
1
end_operator
begin_operator
board car2 loc10
1
29 1
2
0 0 0 12
0 11 1 28
1
end_operator
begin_operator
board car2 loc11
1
29 2
2
0 0 0 12
0 11 2 28
1
end_operator
begin_operator
board car2 loc12
1
29 3
2
0 0 0 12
0 11 3 28
1
end_operator
begin_operator
board car2 loc13
1
29 4
2
0 0 0 12
0 11 4 28
1
end_operator
begin_operator
board car2 loc14
1
29 5
2
0 0 0 12
0 11 5 28
1
end_operator
begin_operator
board car2 loc15
1
29 6
2
0 0 0 12
0 11 6 28
1
end_operator
begin_operator
board car2 loc16
1
29 7
2
0 0 0 12
0 11 7 28
1
end_operator
begin_operator
board car2 loc17
1
29 8
2
0 0 0 12
0 11 8 28
1
end_operator
begin_operator
board car2 loc18
1
29 9
2
0 0 0 12
0 11 9 28
1
end_operator
begin_operator
board car2 loc19
1
29 10
2
0 0 0 12
0 11 10 28
1
end_operator
begin_operator
board car2 loc2
1
29 11
2
0 0 0 12
0 11 11 28
1
end_operator
begin_operator
board car2 loc20
1
29 12
2
0 0 0 12
0 11 12 28
1
end_operator
begin_operator
board car2 loc21
1
29 13
2
0 0 0 12
0 11 13 28
1
end_operator
begin_operator
board car2 loc22
1
29 14
2
0 0 0 12
0 11 14 28
1
end_operator
begin_operator
board car2 loc23
1
29 15
2
0 0 0 12
0 11 15 28
1
end_operator
begin_operator
board car2 loc24
1
29 16
2
0 0 0 12
0 11 16 28
1
end_operator
begin_operator
board car2 loc25
1
29 17
2
0 0 0 12
0 11 17 28
1
end_operator
begin_operator
board car2 loc26
1
29 18
2
0 0 0 12
0 11 18 28
1
end_operator
begin_operator
board car2 loc27
1
29 19
2
0 0 0 12
0 11 19 28
1
end_operator
begin_operator
board car2 loc28
1
29 20
2
0 0 0 12
0 11 20 28
1
end_operator
begin_operator
board car2 loc3
1
29 21
2
0 0 0 12
0 11 21 28
1
end_operator
begin_operator
board car2 loc4
1
29 22
2
0 0 0 12
0 11 22 28
1
end_operator
begin_operator
board car2 loc5
1
29 23
2
0 0 0 12
0 11 23 28
1
end_operator
begin_operator
board car2 loc6
1
29 24
2
0 0 0 12
0 11 24 28
1
end_operator
begin_operator
board car2 loc7
1
29 25
2
0 0 0 12
0 11 25 28
1
end_operator
begin_operator
board car2 loc8
1
29 26
2
0 0 0 12
0 11 26 28
1
end_operator
begin_operator
board car2 loc9
1
29 27
2
0 0 0 12
0 11 27 28
1
end_operator
begin_operator
board car20 loc1
1
29 0
2
0 0 0 13
0 15 0 28
1
end_operator
begin_operator
board car20 loc10
1
29 1
2
0 0 0 13
0 15 1 28
1
end_operator
begin_operator
board car20 loc11
1
29 2
2
0 0 0 13
0 15 2 28
1
end_operator
begin_operator
board car20 loc12
1
29 3
2
0 0 0 13
0 15 3 28
1
end_operator
begin_operator
board car20 loc13
1
29 4
2
0 0 0 13
0 15 4 28
1
end_operator
begin_operator
board car20 loc14
1
29 5
2
0 0 0 13
0 15 5 28
1
end_operator
begin_operator
board car20 loc15
1
29 6
2
0 0 0 13
0 15 6 28
1
end_operator
begin_operator
board car20 loc16
1
29 7
2
0 0 0 13
0 15 7 28
1
end_operator
begin_operator
board car20 loc17
1
29 8
2
0 0 0 13
0 15 8 28
1
end_operator
begin_operator
board car20 loc18
1
29 9
2
0 0 0 13
0 15 9 28
1
end_operator
begin_operator
board car20 loc19
1
29 10
2
0 0 0 13
0 15 10 28
1
end_operator
begin_operator
board car20 loc2
1
29 11
2
0 0 0 13
0 15 11 28
1
end_operator
begin_operator
board car20 loc20
1
29 12
2
0 0 0 13
0 15 12 28
1
end_operator
begin_operator
board car20 loc21
1
29 13
2
0 0 0 13
0 15 13 28
1
end_operator
begin_operator
board car20 loc22
1
29 14
2
0 0 0 13
0 15 14 28
1
end_operator
begin_operator
board car20 loc23
1
29 15
2
0 0 0 13
0 15 15 28
1
end_operator
begin_operator
board car20 loc24
1
29 16
2
0 0 0 13
0 15 16 28
1
end_operator
begin_operator
board car20 loc25
1
29 17
2
0 0 0 13
0 15 17 28
1
end_operator
begin_operator
board car20 loc26
1
29 18
2
0 0 0 13
0 15 18 28
1
end_operator
begin_operator
board car20 loc27
1
29 19
2
0 0 0 13
0 15 19 28
1
end_operator
begin_operator
board car20 loc28
1
29 20
2
0 0 0 13
0 15 20 28
1
end_operator
begin_operator
board car20 loc3
1
29 21
2
0 0 0 13
0 15 21 28
1
end_operator
begin_operator
board car20 loc4
1
29 22
2
0 0 0 13
0 15 22 28
1
end_operator
begin_operator
board car20 loc5
1
29 23
2
0 0 0 13
0 15 23 28
1
end_operator
begin_operator
board car20 loc6
1
29 24
2
0 0 0 13
0 15 24 28
1
end_operator
begin_operator
board car20 loc7
1
29 25
2
0 0 0 13
0 15 25 28
1
end_operator
begin_operator
board car20 loc8
1
29 26
2
0 0 0 13
0 15 26 28
1
end_operator
begin_operator
board car20 loc9
1
29 27
2
0 0 0 13
0 15 27 28
1
end_operator
begin_operator
board car21 loc1
1
29 0
2
0 0 0 14
0 19 0 28
1
end_operator
begin_operator
board car21 loc10
1
29 1
2
0 0 0 14
0 19 1 28
1
end_operator
begin_operator
board car21 loc11
1
29 2
2
0 0 0 14
0 19 2 28
1
end_operator
begin_operator
board car21 loc12
1
29 3
2
0 0 0 14
0 19 3 28
1
end_operator
begin_operator
board car21 loc13
1
29 4
2
0 0 0 14
0 19 4 28
1
end_operator
begin_operator
board car21 loc14
1
29 5
2
0 0 0 14
0 19 5 28
1
end_operator
begin_operator
board car21 loc15
1
29 6
2
0 0 0 14
0 19 6 28
1
end_operator
begin_operator
board car21 loc16
1
29 7
2
0 0 0 14
0 19 7 28
1
end_operator
begin_operator
board car21 loc17
1
29 8
2
0 0 0 14
0 19 8 28
1
end_operator
begin_operator
board car21 loc18
1
29 9
2
0 0 0 14
0 19 9 28
1
end_operator
begin_operator
board car21 loc19
1
29 10
2
0 0 0 14
0 19 10 28
1
end_operator
begin_operator
board car21 loc2
1
29 11
2
0 0 0 14
0 19 11 28
1
end_operator
begin_operator
board car21 loc20
1
29 12
2
0 0 0 14
0 19 12 28
1
end_operator
begin_operator
board car21 loc21
1
29 13
2
0 0 0 14
0 19 13 28
1
end_operator
begin_operator
board car21 loc22
1
29 14
2
0 0 0 14
0 19 14 28
1
end_operator
begin_operator
board car21 loc23
1
29 15
2
0 0 0 14
0 19 15 28
1
end_operator
begin_operator
board car21 loc24
1
29 16
2
0 0 0 14
0 19 16 28
1
end_operator
begin_operator
board car21 loc25
1
29 17
2
0 0 0 14
0 19 17 28
1
end_operator
begin_operator
board car21 loc26
1
29 18
2
0 0 0 14
0 19 18 28
1
end_operator
begin_operator
board car21 loc27
1
29 19
2
0 0 0 14
0 19 19 28
1
end_operator
begin_operator
board car21 loc28
1
29 20
2
0 0 0 14
0 19 20 28
1
end_operator
begin_operator
board car21 loc3
1
29 21
2
0 0 0 14
0 19 21 28
1
end_operator
begin_operator
board car21 loc4
1
29 22
2
0 0 0 14
0 19 22 28
1
end_operator
begin_operator
board car21 loc5
1
29 23
2
0 0 0 14
0 19 23 28
1
end_operator
begin_operator
board car21 loc6
1
29 24
2
0 0 0 14
0 19 24 28
1
end_operator
begin_operator
board car21 loc7
1
29 25
2
0 0 0 14
0 19 25 28
1
end_operator
begin_operator
board car21 loc8
1
29 26
2
0 0 0 14
0 19 26 28
1
end_operator
begin_operator
board car21 loc9
1
29 27
2
0 0 0 14
0 19 27 28
1
end_operator
begin_operator
board car22 loc1
1
29 0
2
0 0 0 15
0 23 0 28
1
end_operator
begin_operator
board car22 loc10
1
29 1
2
0 0 0 15
0 23 1 28
1
end_operator
begin_operator
board car22 loc11
1
29 2
2
0 0 0 15
0 23 2 28
1
end_operator
begin_operator
board car22 loc12
1
29 3
2
0 0 0 15
0 23 3 28
1
end_operator
begin_operator
board car22 loc13
1
29 4
2
0 0 0 15
0 23 4 28
1
end_operator
begin_operator
board car22 loc14
1
29 5
2
0 0 0 15
0 23 5 28
1
end_operator
begin_operator
board car22 loc15
1
29 6
2
0 0 0 15
0 23 6 28
1
end_operator
begin_operator
board car22 loc16
1
29 7
2
0 0 0 15
0 23 7 28
1
end_operator
begin_operator
board car22 loc17
1
29 8
2
0 0 0 15
0 23 8 28
1
end_operator
begin_operator
board car22 loc18
1
29 9
2
0 0 0 15
0 23 9 28
1
end_operator
begin_operator
board car22 loc19
1
29 10
2
0 0 0 15
0 23 10 28
1
end_operator
begin_operator
board car22 loc2
1
29 11
2
0 0 0 15
0 23 11 28
1
end_operator
begin_operator
board car22 loc20
1
29 12
2
0 0 0 15
0 23 12 28
1
end_operator
begin_operator
board car22 loc21
1
29 13
2
0 0 0 15
0 23 13 28
1
end_operator
begin_operator
board car22 loc22
1
29 14
2
0 0 0 15
0 23 14 28
1
end_operator
begin_operator
board car22 loc23
1
29 15
2
0 0 0 15
0 23 15 28
1
end_operator
begin_operator
board car22 loc24
1
29 16
2
0 0 0 15
0 23 16 28
1
end_operator
begin_operator
board car22 loc25
1
29 17
2
0 0 0 15
0 23 17 28
1
end_operator
begin_operator
board car22 loc26
1
29 18
2
0 0 0 15
0 23 18 28
1
end_operator
begin_operator
board car22 loc27
1
29 19
2
0 0 0 15
0 23 19 28
1
end_operator
begin_operator
board car22 loc28
1
29 20
2
0 0 0 15
0 23 20 28
1
end_operator
begin_operator
board car22 loc3
1
29 21
2
0 0 0 15
0 23 21 28
1
end_operator
begin_operator
board car22 loc4
1
29 22
2
0 0 0 15
0 23 22 28
1
end_operator
begin_operator
board car22 loc5
1
29 23
2
0 0 0 15
0 23 23 28
1
end_operator
begin_operator
board car22 loc6
1
29 24
2
0 0 0 15
0 23 24 28
1
end_operator
begin_operator
board car22 loc7
1
29 25
2
0 0 0 15
0 23 25 28
1
end_operator
begin_operator
board car22 loc8
1
29 26
2
0 0 0 15
0 23 26 28
1
end_operator
begin_operator
board car22 loc9
1
29 27
2
0 0 0 15
0 23 27 28
1
end_operator
begin_operator
board car23 loc1
1
29 0
2
0 0 0 16
0 27 0 28
1
end_operator
begin_operator
board car23 loc10
1
29 1
2
0 0 0 16
0 27 1 28
1
end_operator
begin_operator
board car23 loc11
1
29 2
2
0 0 0 16
0 27 2 28
1
end_operator
begin_operator
board car23 loc12
1
29 3
2
0 0 0 16
0 27 3 28
1
end_operator
begin_operator
board car23 loc13
1
29 4
2
0 0 0 16
0 27 4 28
1
end_operator
begin_operator
board car23 loc14
1
29 5
2
0 0 0 16
0 27 5 28
1
end_operator
begin_operator
board car23 loc15
1
29 6
2
0 0 0 16
0 27 6 28
1
end_operator
begin_operator
board car23 loc16
1
29 7
2
0 0 0 16
0 27 7 28
1
end_operator
begin_operator
board car23 loc17
1
29 8
2
0 0 0 16
0 27 8 28
1
end_operator
begin_operator
board car23 loc18
1
29 9
2
0 0 0 16
0 27 9 28
1
end_operator
begin_operator
board car23 loc19
1
29 10
2
0 0 0 16
0 27 10 28
1
end_operator
begin_operator
board car23 loc2
1
29 11
2
0 0 0 16
0 27 11 28
1
end_operator
begin_operator
board car23 loc20
1
29 12
2
0 0 0 16
0 27 12 28
1
end_operator
begin_operator
board car23 loc21
1
29 13
2
0 0 0 16
0 27 13 28
1
end_operator
begin_operator
board car23 loc22
1
29 14
2
0 0 0 16
0 27 14 28
1
end_operator
begin_operator
board car23 loc23
1
29 15
2
0 0 0 16
0 27 15 28
1
end_operator
begin_operator
board car23 loc24
1
29 16
2
0 0 0 16
0 27 16 28
1
end_operator
begin_operator
board car23 loc25
1
29 17
2
0 0 0 16
0 27 17 28
1
end_operator
begin_operator
board car23 loc26
1
29 18
2
0 0 0 16
0 27 18 28
1
end_operator
begin_operator
board car23 loc27
1
29 19
2
0 0 0 16
0 27 19 28
1
end_operator
begin_operator
board car23 loc28
1
29 20
2
0 0 0 16
0 27 20 28
1
end_operator
begin_operator
board car23 loc3
1
29 21
2
0 0 0 16
0 27 21 28
1
end_operator
begin_operator
board car23 loc4
1
29 22
2
0 0 0 16
0 27 22 28
1
end_operator
begin_operator
board car23 loc5
1
29 23
2
0 0 0 16
0 27 23 28
1
end_operator
begin_operator
board car23 loc6
1
29 24
2
0 0 0 16
0 27 24 28
1
end_operator
begin_operator
board car23 loc7
1
29 25
2
0 0 0 16
0 27 25 28
1
end_operator
begin_operator
board car23 loc8
1
29 26
2
0 0 0 16
0 27 26 28
1
end_operator
begin_operator
board car23 loc9
1
29 27
2
0 0 0 16
0 27 27 28
1
end_operator
begin_operator
board car24 loc1
1
29 0
2
0 0 0 17
0 31 0 28
1
end_operator
begin_operator
board car24 loc10
1
29 1
2
0 0 0 17
0 31 1 28
1
end_operator
begin_operator
board car24 loc11
1
29 2
2
0 0 0 17
0 31 2 28
1
end_operator
begin_operator
board car24 loc12
1
29 3
2
0 0 0 17
0 31 3 28
1
end_operator
begin_operator
board car24 loc13
1
29 4
2
0 0 0 17
0 31 4 28
1
end_operator
begin_operator
board car24 loc14
1
29 5
2
0 0 0 17
0 31 5 28
1
end_operator
begin_operator
board car24 loc15
1
29 6
2
0 0 0 17
0 31 6 28
1
end_operator
begin_operator
board car24 loc16
1
29 7
2
0 0 0 17
0 31 7 28
1
end_operator
begin_operator
board car24 loc17
1
29 8
2
0 0 0 17
0 31 8 28
1
end_operator
begin_operator
board car24 loc18
1
29 9
2
0 0 0 17
0 31 9 28
1
end_operator
begin_operator
board car24 loc19
1
29 10
2
0 0 0 17
0 31 10 28
1
end_operator
begin_operator
board car24 loc2
1
29 11
2
0 0 0 17
0 31 11 28
1
end_operator
begin_operator
board car24 loc20
1
29 12
2
0 0 0 17
0 31 12 28
1
end_operator
begin_operator
board car24 loc21
1
29 13
2
0 0 0 17
0 31 13 28
1
end_operator
begin_operator
board car24 loc22
1
29 14
2
0 0 0 17
0 31 14 28
1
end_operator
begin_operator
board car24 loc23
1
29 15
2
0 0 0 17
0 31 15 28
1
end_operator
begin_operator
board car24 loc24
1
29 16
2
0 0 0 17
0 31 16 28
1
end_operator
begin_operator
board car24 loc25
1
29 17
2
0 0 0 17
0 31 17 28
1
end_operator
begin_operator
board car24 loc26
1
29 18
2
0 0 0 17
0 31 18 28
1
end_operator
begin_operator
board car24 loc27
1
29 19
2
0 0 0 17
0 31 19 28
1
end_operator
begin_operator
board car24 loc28
1
29 20
2
0 0 0 17
0 31 20 28
1
end_operator
begin_operator
board car24 loc3
1
29 21
2
0 0 0 17
0 31 21 28
1
end_operator
begin_operator
board car24 loc4
1
29 22
2
0 0 0 17
0 31 22 28
1
end_operator
begin_operator
board car24 loc5
1
29 23
2
0 0 0 17
0 31 23 28
1
end_operator
begin_operator
board car24 loc6
1
29 24
2
0 0 0 17
0 31 24 28
1
end_operator
begin_operator
board car24 loc7
1
29 25
2
0 0 0 17
0 31 25 28
1
end_operator
begin_operator
board car24 loc8
1
29 26
2
0 0 0 17
0 31 26 28
1
end_operator
begin_operator
board car24 loc9
1
29 27
2
0 0 0 17
0 31 27 28
1
end_operator
begin_operator
board car25 loc1
1
29 0
2
0 0 0 18
0 34 0 28
1
end_operator
begin_operator
board car25 loc10
1
29 1
2
0 0 0 18
0 34 1 28
1
end_operator
begin_operator
board car25 loc11
1
29 2
2
0 0 0 18
0 34 2 28
1
end_operator
begin_operator
board car25 loc12
1
29 3
2
0 0 0 18
0 34 3 28
1
end_operator
begin_operator
board car25 loc13
1
29 4
2
0 0 0 18
0 34 4 28
1
end_operator
begin_operator
board car25 loc14
1
29 5
2
0 0 0 18
0 34 5 28
1
end_operator
begin_operator
board car25 loc15
1
29 6
2
0 0 0 18
0 34 6 28
1
end_operator
begin_operator
board car25 loc16
1
29 7
2
0 0 0 18
0 34 7 28
1
end_operator
begin_operator
board car25 loc17
1
29 8
2
0 0 0 18
0 34 8 28
1
end_operator
begin_operator
board car25 loc18
1
29 9
2
0 0 0 18
0 34 9 28
1
end_operator
begin_operator
board car25 loc19
1
29 10
2
0 0 0 18
0 34 10 28
1
end_operator
begin_operator
board car25 loc2
1
29 11
2
0 0 0 18
0 34 11 28
1
end_operator
begin_operator
board car25 loc20
1
29 12
2
0 0 0 18
0 34 12 28
1
end_operator
begin_operator
board car25 loc21
1
29 13
2
0 0 0 18
0 34 13 28
1
end_operator
begin_operator
board car25 loc22
1
29 14
2
0 0 0 18
0 34 14 28
1
end_operator
begin_operator
board car25 loc23
1
29 15
2
0 0 0 18
0 34 15 28
1
end_operator
begin_operator
board car25 loc24
1
29 16
2
0 0 0 18
0 34 16 28
1
end_operator
begin_operator
board car25 loc25
1
29 17
2
0 0 0 18
0 34 17 28
1
end_operator
begin_operator
board car25 loc26
1
29 18
2
0 0 0 18
0 34 18 28
1
end_operator
begin_operator
board car25 loc27
1
29 19
2
0 0 0 18
0 34 19 28
1
end_operator
begin_operator
board car25 loc28
1
29 20
2
0 0 0 18
0 34 20 28
1
end_operator
begin_operator
board car25 loc3
1
29 21
2
0 0 0 18
0 34 21 28
1
end_operator
begin_operator
board car25 loc4
1
29 22
2
0 0 0 18
0 34 22 28
1
end_operator
begin_operator
board car25 loc5
1
29 23
2
0 0 0 18
0 34 23 28
1
end_operator
begin_operator
board car25 loc6
1
29 24
2
0 0 0 18
0 34 24 28
1
end_operator
begin_operator
board car25 loc7
1
29 25
2
0 0 0 18
0 34 25 28
1
end_operator
begin_operator
board car25 loc8
1
29 26
2
0 0 0 18
0 34 26 28
1
end_operator
begin_operator
board car25 loc9
1
29 27
2
0 0 0 18
0 34 27 28
1
end_operator
begin_operator
board car26 loc1
1
29 0
2
0 0 0 19
0 2 0 28
1
end_operator
begin_operator
board car26 loc10
1
29 1
2
0 0 0 19
0 2 1 28
1
end_operator
begin_operator
board car26 loc11
1
29 2
2
0 0 0 19
0 2 2 28
1
end_operator
begin_operator
board car26 loc12
1
29 3
2
0 0 0 19
0 2 3 28
1
end_operator
begin_operator
board car26 loc13
1
29 4
2
0 0 0 19
0 2 4 28
1
end_operator
begin_operator
board car26 loc14
1
29 5
2
0 0 0 19
0 2 5 28
1
end_operator
begin_operator
board car26 loc15
1
29 6
2
0 0 0 19
0 2 6 28
1
end_operator
begin_operator
board car26 loc16
1
29 7
2
0 0 0 19
0 2 7 28
1
end_operator
begin_operator
board car26 loc17
1
29 8
2
0 0 0 19
0 2 8 28
1
end_operator
begin_operator
board car26 loc18
1
29 9
2
0 0 0 19
0 2 9 28
1
end_operator
begin_operator
board car26 loc19
1
29 10
2
0 0 0 19
0 2 10 28
1
end_operator
begin_operator
board car26 loc2
1
29 11
2
0 0 0 19
0 2 11 28
1
end_operator
begin_operator
board car26 loc20
1
29 12
2
0 0 0 19
0 2 12 28
1
end_operator
begin_operator
board car26 loc21
1
29 13
2
0 0 0 19
0 2 13 28
1
end_operator
begin_operator
board car26 loc22
1
29 14
2
0 0 0 19
0 2 14 28
1
end_operator
begin_operator
board car26 loc23
1
29 15
2
0 0 0 19
0 2 15 28
1
end_operator
begin_operator
board car26 loc24
1
29 16
2
0 0 0 19
0 2 16 28
1
end_operator
begin_operator
board car26 loc25
1
29 17
2
0 0 0 19
0 2 17 28
1
end_operator
begin_operator
board car26 loc26
1
29 18
2
0 0 0 19
0 2 18 28
1
end_operator
begin_operator
board car26 loc27
1
29 19
2
0 0 0 19
0 2 19 28
1
end_operator
begin_operator
board car26 loc28
1
29 20
2
0 0 0 19
0 2 20 28
1
end_operator
begin_operator
board car26 loc3
1
29 21
2
0 0 0 19
0 2 21 28
1
end_operator
begin_operator
board car26 loc4
1
29 22
2
0 0 0 19
0 2 22 28
1
end_operator
begin_operator
board car26 loc5
1
29 23
2
0 0 0 19
0 2 23 28
1
end_operator
begin_operator
board car26 loc6
1
29 24
2
0 0 0 19
0 2 24 28
1
end_operator
begin_operator
board car26 loc7
1
29 25
2
0 0 0 19
0 2 25 28
1
end_operator
begin_operator
board car26 loc8
1
29 26
2
0 0 0 19
0 2 26 28
1
end_operator
begin_operator
board car26 loc9
1
29 27
2
0 0 0 19
0 2 27 28
1
end_operator
begin_operator
board car27 loc1
1
29 0
2
0 0 0 20
0 6 0 28
1
end_operator
begin_operator
board car27 loc10
1
29 1
2
0 0 0 20
0 6 1 28
1
end_operator
begin_operator
board car27 loc11
1
29 2
2
0 0 0 20
0 6 2 28
1
end_operator
begin_operator
board car27 loc12
1
29 3
2
0 0 0 20
0 6 3 28
1
end_operator
begin_operator
board car27 loc13
1
29 4
2
0 0 0 20
0 6 4 28
1
end_operator
begin_operator
board car27 loc14
1
29 5
2
0 0 0 20
0 6 5 28
1
end_operator
begin_operator
board car27 loc15
1
29 6
2
0 0 0 20
0 6 6 28
1
end_operator
begin_operator
board car27 loc16
1
29 7
2
0 0 0 20
0 6 7 28
1
end_operator
begin_operator
board car27 loc17
1
29 8
2
0 0 0 20
0 6 8 28
1
end_operator
begin_operator
board car27 loc18
1
29 9
2
0 0 0 20
0 6 9 28
1
end_operator
begin_operator
board car27 loc19
1
29 10
2
0 0 0 20
0 6 10 28
1
end_operator
begin_operator
board car27 loc2
1
29 11
2
0 0 0 20
0 6 11 28
1
end_operator
begin_operator
board car27 loc20
1
29 12
2
0 0 0 20
0 6 12 28
1
end_operator
begin_operator
board car27 loc21
1
29 13
2
0 0 0 20
0 6 13 28
1
end_operator
begin_operator
board car27 loc22
1
29 14
2
0 0 0 20
0 6 14 28
1
end_operator
begin_operator
board car27 loc23
1
29 15
2
0 0 0 20
0 6 15 28
1
end_operator
begin_operator
board car27 loc24
1
29 16
2
0 0 0 20
0 6 16 28
1
end_operator
begin_operator
board car27 loc25
1
29 17
2
0 0 0 20
0 6 17 28
1
end_operator
begin_operator
board car27 loc26
1
29 18
2
0 0 0 20
0 6 18 28
1
end_operator
begin_operator
board car27 loc27
1
29 19
2
0 0 0 20
0 6 19 28
1
end_operator
begin_operator
board car27 loc28
1
29 20
2
0 0 0 20
0 6 20 28
1
end_operator
begin_operator
board car27 loc3
1
29 21
2
0 0 0 20
0 6 21 28
1
end_operator
begin_operator
board car27 loc4
1
29 22
2
0 0 0 20
0 6 22 28
1
end_operator
begin_operator
board car27 loc5
1
29 23
2
0 0 0 20
0 6 23 28
1
end_operator
begin_operator
board car27 loc6
1
29 24
2
0 0 0 20
0 6 24 28
1
end_operator
begin_operator
board car27 loc7
1
29 25
2
0 0 0 20
0 6 25 28
1
end_operator
begin_operator
board car27 loc8
1
29 26
2
0 0 0 20
0 6 26 28
1
end_operator
begin_operator
board car27 loc9
1
29 27
2
0 0 0 20
0 6 27 28
1
end_operator
begin_operator
board car28 loc1
1
29 0
2
0 0 0 21
0 10 0 28
1
end_operator
begin_operator
board car28 loc10
1
29 1
2
0 0 0 21
0 10 1 28
1
end_operator
begin_operator
board car28 loc11
1
29 2
2
0 0 0 21
0 10 2 28
1
end_operator
begin_operator
board car28 loc12
1
29 3
2
0 0 0 21
0 10 3 28
1
end_operator
begin_operator
board car28 loc13
1
29 4
2
0 0 0 21
0 10 4 28
1
end_operator
begin_operator
board car28 loc14
1
29 5
2
0 0 0 21
0 10 5 28
1
end_operator
begin_operator
board car28 loc15
1
29 6
2
0 0 0 21
0 10 6 28
1
end_operator
begin_operator
board car28 loc16
1
29 7
2
0 0 0 21
0 10 7 28
1
end_operator
begin_operator
board car28 loc17
1
29 8
2
0 0 0 21
0 10 8 28
1
end_operator
begin_operator
board car28 loc18
1
29 9
2
0 0 0 21
0 10 9 28
1
end_operator
begin_operator
board car28 loc19
1
29 10
2
0 0 0 21
0 10 10 28
1
end_operator
begin_operator
board car28 loc2
1
29 11
2
0 0 0 21
0 10 11 28
1
end_operator
begin_operator
board car28 loc20
1
29 12
2
0 0 0 21
0 10 12 28
1
end_operator
begin_operator
board car28 loc21
1
29 13
2
0 0 0 21
0 10 13 28
1
end_operator
begin_operator
board car28 loc22
1
29 14
2
0 0 0 21
0 10 14 28
1
end_operator
begin_operator
board car28 loc23
1
29 15
2
0 0 0 21
0 10 15 28
1
end_operator
begin_operator
board car28 loc24
1
29 16
2
0 0 0 21
0 10 16 28
1
end_operator
begin_operator
board car28 loc25
1
29 17
2
0 0 0 21
0 10 17 28
1
end_operator
begin_operator
board car28 loc26
1
29 18
2
0 0 0 21
0 10 18 28
1
end_operator
begin_operator
board car28 loc27
1
29 19
2
0 0 0 21
0 10 19 28
1
end_operator
begin_operator
board car28 loc28
1
29 20
2
0 0 0 21
0 10 20 28
1
end_operator
begin_operator
board car28 loc3
1
29 21
2
0 0 0 21
0 10 21 28
1
end_operator
begin_operator
board car28 loc4
1
29 22
2
0 0 0 21
0 10 22 28
1
end_operator
begin_operator
board car28 loc5
1
29 23
2
0 0 0 21
0 10 23 28
1
end_operator
begin_operator
board car28 loc6
1
29 24
2
0 0 0 21
0 10 24 28
1
end_operator
begin_operator
board car28 loc7
1
29 25
2
0 0 0 21
0 10 25 28
1
end_operator
begin_operator
board car28 loc8
1
29 26
2
0 0 0 21
0 10 26 28
1
end_operator
begin_operator
board car28 loc9
1
29 27
2
0 0 0 21
0 10 27 28
1
end_operator
begin_operator
board car29 loc1
1
29 0
2
0 0 0 22
0 14 0 28
1
end_operator
begin_operator
board car29 loc10
1
29 1
2
0 0 0 22
0 14 1 28
1
end_operator
begin_operator
board car29 loc11
1
29 2
2
0 0 0 22
0 14 2 28
1
end_operator
begin_operator
board car29 loc12
1
29 3
2
0 0 0 22
0 14 3 28
1
end_operator
begin_operator
board car29 loc13
1
29 4
2
0 0 0 22
0 14 4 28
1
end_operator
begin_operator
board car29 loc14
1
29 5
2
0 0 0 22
0 14 5 28
1
end_operator
begin_operator
board car29 loc15
1
29 6
2
0 0 0 22
0 14 6 28
1
end_operator
begin_operator
board car29 loc16
1
29 7
2
0 0 0 22
0 14 7 28
1
end_operator
begin_operator
board car29 loc17
1
29 8
2
0 0 0 22
0 14 8 28
1
end_operator
begin_operator
board car29 loc18
1
29 9
2
0 0 0 22
0 14 9 28
1
end_operator
begin_operator
board car29 loc19
1
29 10
2
0 0 0 22
0 14 10 28
1
end_operator
begin_operator
board car29 loc2
1
29 11
2
0 0 0 22
0 14 11 28
1
end_operator
begin_operator
board car29 loc20
1
29 12
2
0 0 0 22
0 14 12 28
1
end_operator
begin_operator
board car29 loc21
1
29 13
2
0 0 0 22
0 14 13 28
1
end_operator
begin_operator
board car29 loc22
1
29 14
2
0 0 0 22
0 14 14 28
1
end_operator
begin_operator
board car29 loc23
1
29 15
2
0 0 0 22
0 14 15 28
1
end_operator
begin_operator
board car29 loc24
1
29 16
2
0 0 0 22
0 14 16 28
1
end_operator
begin_operator
board car29 loc25
1
29 17
2
0 0 0 22
0 14 17 28
1
end_operator
begin_operator
board car29 loc26
1
29 18
2
0 0 0 22
0 14 18 28
1
end_operator
begin_operator
board car29 loc27
1
29 19
2
0 0 0 22
0 14 19 28
1
end_operator
begin_operator
board car29 loc28
1
29 20
2
0 0 0 22
0 14 20 28
1
end_operator
begin_operator
board car29 loc3
1
29 21
2
0 0 0 22
0 14 21 28
1
end_operator
begin_operator
board car29 loc4
1
29 22
2
0 0 0 22
0 14 22 28
1
end_operator
begin_operator
board car29 loc5
1
29 23
2
0 0 0 22
0 14 23 28
1
end_operator
begin_operator
board car29 loc6
1
29 24
2
0 0 0 22
0 14 24 28
1
end_operator
begin_operator
board car29 loc7
1
29 25
2
0 0 0 22
0 14 25 28
1
end_operator
begin_operator
board car29 loc8
1
29 26
2
0 0 0 22
0 14 26 28
1
end_operator
begin_operator
board car29 loc9
1
29 27
2
0 0 0 22
0 14 27 28
1
end_operator
begin_operator
board car3 loc1
1
29 0
2
0 0 0 23
0 18 0 28
1
end_operator
begin_operator
board car3 loc10
1
29 1
2
0 0 0 23
0 18 1 28
1
end_operator
begin_operator
board car3 loc11
1
29 2
2
0 0 0 23
0 18 2 28
1
end_operator
begin_operator
board car3 loc12
1
29 3
2
0 0 0 23
0 18 3 28
1
end_operator
begin_operator
board car3 loc13
1
29 4
2
0 0 0 23
0 18 4 28
1
end_operator
begin_operator
board car3 loc14
1
29 5
2
0 0 0 23
0 18 5 28
1
end_operator
begin_operator
board car3 loc15
1
29 6
2
0 0 0 23
0 18 6 28
1
end_operator
begin_operator
board car3 loc16
1
29 7
2
0 0 0 23
0 18 7 28
1
end_operator
begin_operator
board car3 loc17
1
29 8
2
0 0 0 23
0 18 8 28
1
end_operator
begin_operator
board car3 loc18
1
29 9
2
0 0 0 23
0 18 9 28
1
end_operator
begin_operator
board car3 loc19
1
29 10
2
0 0 0 23
0 18 10 28
1
end_operator
begin_operator
board car3 loc2
1
29 11
2
0 0 0 23
0 18 11 28
1
end_operator
begin_operator
board car3 loc20
1
29 12
2
0 0 0 23
0 18 12 28
1
end_operator
begin_operator
board car3 loc21
1
29 13
2
0 0 0 23
0 18 13 28
1
end_operator
begin_operator
board car3 loc22
1
29 14
2
0 0 0 23
0 18 14 28
1
end_operator
begin_operator
board car3 loc23
1
29 15
2
0 0 0 23
0 18 15 28
1
end_operator
begin_operator
board car3 loc24
1
29 16
2
0 0 0 23
0 18 16 28
1
end_operator
begin_operator
board car3 loc25
1
29 17
2
0 0 0 23
0 18 17 28
1
end_operator
begin_operator
board car3 loc26
1
29 18
2
0 0 0 23
0 18 18 28
1
end_operator
begin_operator
board car3 loc27
1
29 19
2
0 0 0 23
0 18 19 28
1
end_operator
begin_operator
board car3 loc28
1
29 20
2
0 0 0 23
0 18 20 28
1
end_operator
begin_operator
board car3 loc3
1
29 21
2
0 0 0 23
0 18 21 28
1
end_operator
begin_operator
board car3 loc4
1
29 22
2
0 0 0 23
0 18 22 28
1
end_operator
begin_operator
board car3 loc5
1
29 23
2
0 0 0 23
0 18 23 28
1
end_operator
begin_operator
board car3 loc6
1
29 24
2
0 0 0 23
0 18 24 28
1
end_operator
begin_operator
board car3 loc7
1
29 25
2
0 0 0 23
0 18 25 28
1
end_operator
begin_operator
board car3 loc8
1
29 26
2
0 0 0 23
0 18 26 28
1
end_operator
begin_operator
board car3 loc9
1
29 27
2
0 0 0 23
0 18 27 28
1
end_operator
begin_operator
board car30 loc1
1
29 0
2
0 0 0 24
0 22 0 28
1
end_operator
begin_operator
board car30 loc10
1
29 1
2
0 0 0 24
0 22 1 28
1
end_operator
begin_operator
board car30 loc11
1
29 2
2
0 0 0 24
0 22 2 28
1
end_operator
begin_operator
board car30 loc12
1
29 3
2
0 0 0 24
0 22 3 28
1
end_operator
begin_operator
board car30 loc13
1
29 4
2
0 0 0 24
0 22 4 28
1
end_operator
begin_operator
board car30 loc14
1
29 5
2
0 0 0 24
0 22 5 28
1
end_operator
begin_operator
board car30 loc15
1
29 6
2
0 0 0 24
0 22 6 28
1
end_operator
begin_operator
board car30 loc16
1
29 7
2
0 0 0 24
0 22 7 28
1
end_operator
begin_operator
board car30 loc17
1
29 8
2
0 0 0 24
0 22 8 28
1
end_operator
begin_operator
board car30 loc18
1
29 9
2
0 0 0 24
0 22 9 28
1
end_operator
begin_operator
board car30 loc19
1
29 10
2
0 0 0 24
0 22 10 28
1
end_operator
begin_operator
board car30 loc2
1
29 11
2
0 0 0 24
0 22 11 28
1
end_operator
begin_operator
board car30 loc20
1
29 12
2
0 0 0 24
0 22 12 28
1
end_operator
begin_operator
board car30 loc21
1
29 13
2
0 0 0 24
0 22 13 28
1
end_operator
begin_operator
board car30 loc22
1
29 14
2
0 0 0 24
0 22 14 28
1
end_operator
begin_operator
board car30 loc23
1
29 15
2
0 0 0 24
0 22 15 28
1
end_operator
begin_operator
board car30 loc24
1
29 16
2
0 0 0 24
0 22 16 28
1
end_operator
begin_operator
board car30 loc25
1
29 17
2
0 0 0 24
0 22 17 28
1
end_operator
begin_operator
board car30 loc26
1
29 18
2
0 0 0 24
0 22 18 28
1
end_operator
begin_operator
board car30 loc27
1
29 19
2
0 0 0 24
0 22 19 28
1
end_operator
begin_operator
board car30 loc28
1
29 20
2
0 0 0 24
0 22 20 28
1
end_operator
begin_operator
board car30 loc3
1
29 21
2
0 0 0 24
0 22 21 28
1
end_operator
begin_operator
board car30 loc4
1
29 22
2
0 0 0 24
0 22 22 28
1
end_operator
begin_operator
board car30 loc5
1
29 23
2
0 0 0 24
0 22 23 28
1
end_operator
begin_operator
board car30 loc6
1
29 24
2
0 0 0 24
0 22 24 28
1
end_operator
begin_operator
board car30 loc7
1
29 25
2
0 0 0 24
0 22 25 28
1
end_operator
begin_operator
board car30 loc8
1
29 26
2
0 0 0 24
0 22 26 28
1
end_operator
begin_operator
board car30 loc9
1
29 27
2
0 0 0 24
0 22 27 28
1
end_operator
begin_operator
board car31 loc1
1
29 0
2
0 0 0 25
0 26 0 28
1
end_operator
begin_operator
board car31 loc10
1
29 1
2
0 0 0 25
0 26 1 28
1
end_operator
begin_operator
board car31 loc11
1
29 2
2
0 0 0 25
0 26 2 28
1
end_operator
begin_operator
board car31 loc12
1
29 3
2
0 0 0 25
0 26 3 28
1
end_operator
begin_operator
board car31 loc13
1
29 4
2
0 0 0 25
0 26 4 28
1
end_operator
begin_operator
board car31 loc14
1
29 5
2
0 0 0 25
0 26 5 28
1
end_operator
begin_operator
board car31 loc15
1
29 6
2
0 0 0 25
0 26 6 28
1
end_operator
begin_operator
board car31 loc16
1
29 7
2
0 0 0 25
0 26 7 28
1
end_operator
begin_operator
board car31 loc17
1
29 8
2
0 0 0 25
0 26 8 28
1
end_operator
begin_operator
board car31 loc18
1
29 9
2
0 0 0 25
0 26 9 28
1
end_operator
begin_operator
board car31 loc19
1
29 10
2
0 0 0 25
0 26 10 28
1
end_operator
begin_operator
board car31 loc2
1
29 11
2
0 0 0 25
0 26 11 28
1
end_operator
begin_operator
board car31 loc20
1
29 12
2
0 0 0 25
0 26 12 28
1
end_operator
begin_operator
board car31 loc21
1
29 13
2
0 0 0 25
0 26 13 28
1
end_operator
begin_operator
board car31 loc22
1
29 14
2
0 0 0 25
0 26 14 28
1
end_operator
begin_operator
board car31 loc23
1
29 15
2
0 0 0 25
0 26 15 28
1
end_operator
begin_operator
board car31 loc24
1
29 16
2
0 0 0 25
0 26 16 28
1
end_operator
begin_operator
board car31 loc25
1
29 17
2
0 0 0 25
0 26 17 28
1
end_operator
begin_operator
board car31 loc26
1
29 18
2
0 0 0 25
0 26 18 28
1
end_operator
begin_operator
board car31 loc27
1
29 19
2
0 0 0 25
0 26 19 28
1
end_operator
begin_operator
board car31 loc28
1
29 20
2
0 0 0 25
0 26 20 28
1
end_operator
begin_operator
board car31 loc3
1
29 21
2
0 0 0 25
0 26 21 28
1
end_operator
begin_operator
board car31 loc4
1
29 22
2
0 0 0 25
0 26 22 28
1
end_operator
begin_operator
board car31 loc5
1
29 23
2
0 0 0 25
0 26 23 28
1
end_operator
begin_operator
board car31 loc6
1
29 24
2
0 0 0 25
0 26 24 28
1
end_operator
begin_operator
board car31 loc7
1
29 25
2
0 0 0 25
0 26 25 28
1
end_operator
begin_operator
board car31 loc8
1
29 26
2
0 0 0 25
0 26 26 28
1
end_operator
begin_operator
board car31 loc9
1
29 27
2
0 0 0 25
0 26 27 28
1
end_operator
begin_operator
board car32 loc1
1
29 0
2
0 0 0 26
0 30 0 28
1
end_operator
begin_operator
board car32 loc10
1
29 1
2
0 0 0 26
0 30 1 28
1
end_operator
begin_operator
board car32 loc11
1
29 2
2
0 0 0 26
0 30 2 28
1
end_operator
begin_operator
board car32 loc12
1
29 3
2
0 0 0 26
0 30 3 28
1
end_operator
begin_operator
board car32 loc13
1
29 4
2
0 0 0 26
0 30 4 28
1
end_operator
begin_operator
board car32 loc14
1
29 5
2
0 0 0 26
0 30 5 28
1
end_operator
begin_operator
board car32 loc15
1
29 6
2
0 0 0 26
0 30 6 28
1
end_operator
begin_operator
board car32 loc16
1
29 7
2
0 0 0 26
0 30 7 28
1
end_operator
begin_operator
board car32 loc17
1
29 8
2
0 0 0 26
0 30 8 28
1
end_operator
begin_operator
board car32 loc18
1
29 9
2
0 0 0 26
0 30 9 28
1
end_operator
begin_operator
board car32 loc19
1
29 10
2
0 0 0 26
0 30 10 28
1
end_operator
begin_operator
board car32 loc2
1
29 11
2
0 0 0 26
0 30 11 28
1
end_operator
begin_operator
board car32 loc20
1
29 12
2
0 0 0 26
0 30 12 28
1
end_operator
begin_operator
board car32 loc21
1
29 13
2
0 0 0 26
0 30 13 28
1
end_operator
begin_operator
board car32 loc22
1
29 14
2
0 0 0 26
0 30 14 28
1
end_operator
begin_operator
board car32 loc23
1
29 15
2
0 0 0 26
0 30 15 28
1
end_operator
begin_operator
board car32 loc24
1
29 16
2
0 0 0 26
0 30 16 28
1
end_operator
begin_operator
board car32 loc25
1
29 17
2
0 0 0 26
0 30 17 28
1
end_operator
begin_operator
board car32 loc26
1
29 18
2
0 0 0 26
0 30 18 28
1
end_operator
begin_operator
board car32 loc27
1
29 19
2
0 0 0 26
0 30 19 28
1
end_operator
begin_operator
board car32 loc28
1
29 20
2
0 0 0 26
0 30 20 28
1
end_operator
begin_operator
board car32 loc3
1
29 21
2
0 0 0 26
0 30 21 28
1
end_operator
begin_operator
board car32 loc4
1
29 22
2
0 0 0 26
0 30 22 28
1
end_operator
begin_operator
board car32 loc5
1
29 23
2
0 0 0 26
0 30 23 28
1
end_operator
begin_operator
board car32 loc6
1
29 24
2
0 0 0 26
0 30 24 28
1
end_operator
begin_operator
board car32 loc7
1
29 25
2
0 0 0 26
0 30 25 28
1
end_operator
begin_operator
board car32 loc8
1
29 26
2
0 0 0 26
0 30 26 28
1
end_operator
begin_operator
board car32 loc9
1
29 27
2
0 0 0 26
0 30 27 28
1
end_operator
begin_operator
board car33 loc1
1
29 0
2
0 0 0 27
0 33 0 28
1
end_operator
begin_operator
board car33 loc10
1
29 1
2
0 0 0 27
0 33 1 28
1
end_operator
begin_operator
board car33 loc11
1
29 2
2
0 0 0 27
0 33 2 28
1
end_operator
begin_operator
board car33 loc12
1
29 3
2
0 0 0 27
0 33 3 28
1
end_operator
begin_operator
board car33 loc13
1
29 4
2
0 0 0 27
0 33 4 28
1
end_operator
begin_operator
board car33 loc14
1
29 5
2
0 0 0 27
0 33 5 28
1
end_operator
begin_operator
board car33 loc15
1
29 6
2
0 0 0 27
0 33 6 28
1
end_operator
begin_operator
board car33 loc16
1
29 7
2
0 0 0 27
0 33 7 28
1
end_operator
begin_operator
board car33 loc17
1
29 8
2
0 0 0 27
0 33 8 28
1
end_operator
begin_operator
board car33 loc18
1
29 9
2
0 0 0 27
0 33 9 28
1
end_operator
begin_operator
board car33 loc19
1
29 10
2
0 0 0 27
0 33 10 28
1
end_operator
begin_operator
board car33 loc2
1
29 11
2
0 0 0 27
0 33 11 28
1
end_operator
begin_operator
board car33 loc20
1
29 12
2
0 0 0 27
0 33 12 28
1
end_operator
begin_operator
board car33 loc21
1
29 13
2
0 0 0 27
0 33 13 28
1
end_operator
begin_operator
board car33 loc22
1
29 14
2
0 0 0 27
0 33 14 28
1
end_operator
begin_operator
board car33 loc23
1
29 15
2
0 0 0 27
0 33 15 28
1
end_operator
begin_operator
board car33 loc24
1
29 16
2
0 0 0 27
0 33 16 28
1
end_operator
begin_operator
board car33 loc25
1
29 17
2
0 0 0 27
0 33 17 28
1
end_operator
begin_operator
board car33 loc26
1
29 18
2
0 0 0 27
0 33 18 28
1
end_operator
begin_operator
board car33 loc27
1
29 19
2
0 0 0 27
0 33 19 28
1
end_operator
begin_operator
board car33 loc28
1
29 20
2
0 0 0 27
0 33 20 28
1
end_operator
begin_operator
board car33 loc3
1
29 21
2
0 0 0 27
0 33 21 28
1
end_operator
begin_operator
board car33 loc4
1
29 22
2
0 0 0 27
0 33 22 28
1
end_operator
begin_operator
board car33 loc5
1
29 23
2
0 0 0 27
0 33 23 28
1
end_operator
begin_operator
board car33 loc6
1
29 24
2
0 0 0 27
0 33 24 28
1
end_operator
begin_operator
board car33 loc7
1
29 25
2
0 0 0 27
0 33 25 28
1
end_operator
begin_operator
board car33 loc8
1
29 26
2
0 0 0 27
0 33 26 28
1
end_operator
begin_operator
board car33 loc9
1
29 27
2
0 0 0 27
0 33 27 28
1
end_operator
begin_operator
board car34 loc1
1
29 0
2
0 0 0 28
0 1 0 28
1
end_operator
begin_operator
board car34 loc10
1
29 1
2
0 0 0 28
0 1 1 28
1
end_operator
begin_operator
board car34 loc11
1
29 2
2
0 0 0 28
0 1 2 28
1
end_operator
begin_operator
board car34 loc12
1
29 3
2
0 0 0 28
0 1 3 28
1
end_operator
begin_operator
board car34 loc13
1
29 4
2
0 0 0 28
0 1 4 28
1
end_operator
begin_operator
board car34 loc14
1
29 5
2
0 0 0 28
0 1 5 28
1
end_operator
begin_operator
board car34 loc15
1
29 6
2
0 0 0 28
0 1 6 28
1
end_operator
begin_operator
board car34 loc16
1
29 7
2
0 0 0 28
0 1 7 28
1
end_operator
begin_operator
board car34 loc17
1
29 8
2
0 0 0 28
0 1 8 28
1
end_operator
begin_operator
board car34 loc18
1
29 9
2
0 0 0 28
0 1 9 28
1
end_operator
begin_operator
board car34 loc19
1
29 10
2
0 0 0 28
0 1 10 28
1
end_operator
begin_operator
board car34 loc2
1
29 11
2
0 0 0 28
0 1 11 28
1
end_operator
begin_operator
board car34 loc20
1
29 12
2
0 0 0 28
0 1 12 28
1
end_operator
begin_operator
board car34 loc21
1
29 13
2
0 0 0 28
0 1 13 28
1
end_operator
begin_operator
board car34 loc22
1
29 14
2
0 0 0 28
0 1 14 28
1
end_operator
begin_operator
board car34 loc23
1
29 15
2
0 0 0 28
0 1 15 28
1
end_operator
begin_operator
board car34 loc24
1
29 16
2
0 0 0 28
0 1 16 28
1
end_operator
begin_operator
board car34 loc25
1
29 17
2
0 0 0 28
0 1 17 28
1
end_operator
begin_operator
board car34 loc26
1
29 18
2
0 0 0 28
0 1 18 28
1
end_operator
begin_operator
board car34 loc27
1
29 19
2
0 0 0 28
0 1 19 28
1
end_operator
begin_operator
board car34 loc28
1
29 20
2
0 0 0 28
0 1 20 28
1
end_operator
begin_operator
board car34 loc3
1
29 21
2
0 0 0 28
0 1 21 28
1
end_operator
begin_operator
board car34 loc4
1
29 22
2
0 0 0 28
0 1 22 28
1
end_operator
begin_operator
board car34 loc5
1
29 23
2
0 0 0 28
0 1 23 28
1
end_operator
begin_operator
board car34 loc6
1
29 24
2
0 0 0 28
0 1 24 28
1
end_operator
begin_operator
board car34 loc7
1
29 25
2
0 0 0 28
0 1 25 28
1
end_operator
begin_operator
board car34 loc8
1
29 26
2
0 0 0 28
0 1 26 28
1
end_operator
begin_operator
board car34 loc9
1
29 27
2
0 0 0 28
0 1 27 28
1
end_operator
begin_operator
board car4 loc1
1
29 0
2
0 0 0 29
0 5 0 28
1
end_operator
begin_operator
board car4 loc10
1
29 1
2
0 0 0 29
0 5 1 28
1
end_operator
begin_operator
board car4 loc11
1
29 2
2
0 0 0 29
0 5 2 28
1
end_operator
begin_operator
board car4 loc12
1
29 3
2
0 0 0 29
0 5 3 28
1
end_operator
begin_operator
board car4 loc13
1
29 4
2
0 0 0 29
0 5 4 28
1
end_operator
begin_operator
board car4 loc14
1
29 5
2
0 0 0 29
0 5 5 28
1
end_operator
begin_operator
board car4 loc15
1
29 6
2
0 0 0 29
0 5 6 28
1
end_operator
begin_operator
board car4 loc16
1
29 7
2
0 0 0 29
0 5 7 28
1
end_operator
begin_operator
board car4 loc17
1
29 8
2
0 0 0 29
0 5 8 28
1
end_operator
begin_operator
board car4 loc18
1
29 9
2
0 0 0 29
0 5 9 28
1
end_operator
begin_operator
board car4 loc19
1
29 10
2
0 0 0 29
0 5 10 28
1
end_operator
begin_operator
board car4 loc2
1
29 11
2
0 0 0 29
0 5 11 28
1
end_operator
begin_operator
board car4 loc20
1
29 12
2
0 0 0 29
0 5 12 28
1
end_operator
begin_operator
board car4 loc21
1
29 13
2
0 0 0 29
0 5 13 28
1
end_operator
begin_operator
board car4 loc22
1
29 14
2
0 0 0 29
0 5 14 28
1
end_operator
begin_operator
board car4 loc23
1
29 15
2
0 0 0 29
0 5 15 28
1
end_operator
begin_operator
board car4 loc24
1
29 16
2
0 0 0 29
0 5 16 28
1
end_operator
begin_operator
board car4 loc25
1
29 17
2
0 0 0 29
0 5 17 28
1
end_operator
begin_operator
board car4 loc26
1
29 18
2
0 0 0 29
0 5 18 28
1
end_operator
begin_operator
board car4 loc27
1
29 19
2
0 0 0 29
0 5 19 28
1
end_operator
begin_operator
board car4 loc28
1
29 20
2
0 0 0 29
0 5 20 28
1
end_operator
begin_operator
board car4 loc3
1
29 21
2
0 0 0 29
0 5 21 28
1
end_operator
begin_operator
board car4 loc4
1
29 22
2
0 0 0 29
0 5 22 28
1
end_operator
begin_operator
board car4 loc5
1
29 23
2
0 0 0 29
0 5 23 28
1
end_operator
begin_operator
board car4 loc6
1
29 24
2
0 0 0 29
0 5 24 28
1
end_operator
begin_operator
board car4 loc7
1
29 25
2
0 0 0 29
0 5 25 28
1
end_operator
begin_operator
board car4 loc8
1
29 26
2
0 0 0 29
0 5 26 28
1
end_operator
begin_operator
board car4 loc9
1
29 27
2
0 0 0 29
0 5 27 28
1
end_operator
begin_operator
board car5 loc1
1
29 0
2
0 0 0 30
0 9 0 28
1
end_operator
begin_operator
board car5 loc10
1
29 1
2
0 0 0 30
0 9 1 28
1
end_operator
begin_operator
board car5 loc11
1
29 2
2
0 0 0 30
0 9 2 28
1
end_operator
begin_operator
board car5 loc12
1
29 3
2
0 0 0 30
0 9 3 28
1
end_operator
begin_operator
board car5 loc13
1
29 4
2
0 0 0 30
0 9 4 28
1
end_operator
begin_operator
board car5 loc14
1
29 5
2
0 0 0 30
0 9 5 28
1
end_operator
begin_operator
board car5 loc15
1
29 6
2
0 0 0 30
0 9 6 28
1
end_operator
begin_operator
board car5 loc16
1
29 7
2
0 0 0 30
0 9 7 28
1
end_operator
begin_operator
board car5 loc17
1
29 8
2
0 0 0 30
0 9 8 28
1
end_operator
begin_operator
board car5 loc18
1
29 9
2
0 0 0 30
0 9 9 28
1
end_operator
begin_operator
board car5 loc19
1
29 10
2
0 0 0 30
0 9 10 28
1
end_operator
begin_operator
board car5 loc2
1
29 11
2
0 0 0 30
0 9 11 28
1
end_operator
begin_operator
board car5 loc20
1
29 12
2
0 0 0 30
0 9 12 28
1
end_operator
begin_operator
board car5 loc21
1
29 13
2
0 0 0 30
0 9 13 28
1
end_operator
begin_operator
board car5 loc22
1
29 14
2
0 0 0 30
0 9 14 28
1
end_operator
begin_operator
board car5 loc23
1
29 15
2
0 0 0 30
0 9 15 28
1
end_operator
begin_operator
board car5 loc24
1
29 16
2
0 0 0 30
0 9 16 28
1
end_operator
begin_operator
board car5 loc25
1
29 17
2
0 0 0 30
0 9 17 28
1
end_operator
begin_operator
board car5 loc26
1
29 18
2
0 0 0 30
0 9 18 28
1
end_operator
begin_operator
board car5 loc27
1
29 19
2
0 0 0 30
0 9 19 28
1
end_operator
begin_operator
board car5 loc28
1
29 20
2
0 0 0 30
0 9 20 28
1
end_operator
begin_operator
board car5 loc3
1
29 21
2
0 0 0 30
0 9 21 28
1
end_operator
begin_operator
board car5 loc4
1
29 22
2
0 0 0 30
0 9 22 28
1
end_operator
begin_operator
board car5 loc5
1
29 23
2
0 0 0 30
0 9 23 28
1
end_operator
begin_operator
board car5 loc6
1
29 24
2
0 0 0 30
0 9 24 28
1
end_operator
begin_operator
board car5 loc7
1
29 25
2
0 0 0 30
0 9 25 28
1
end_operator
begin_operator
board car5 loc8
1
29 26
2
0 0 0 30
0 9 26 28
1
end_operator
begin_operator
board car5 loc9
1
29 27
2
0 0 0 30
0 9 27 28
1
end_operator
begin_operator
board car6 loc1
1
29 0
2
0 0 0 31
0 13 0 28
1
end_operator
begin_operator
board car6 loc10
1
29 1
2
0 0 0 31
0 13 1 28
1
end_operator
begin_operator
board car6 loc11
1
29 2
2
0 0 0 31
0 13 2 28
1
end_operator
begin_operator
board car6 loc12
1
29 3
2
0 0 0 31
0 13 3 28
1
end_operator
begin_operator
board car6 loc13
1
29 4
2
0 0 0 31
0 13 4 28
1
end_operator
begin_operator
board car6 loc14
1
29 5
2
0 0 0 31
0 13 5 28
1
end_operator
begin_operator
board car6 loc15
1
29 6
2
0 0 0 31
0 13 6 28
1
end_operator
begin_operator
board car6 loc16
1
29 7
2
0 0 0 31
0 13 7 28
1
end_operator
begin_operator
board car6 loc17
1
29 8
2
0 0 0 31
0 13 8 28
1
end_operator
begin_operator
board car6 loc18
1
29 9
2
0 0 0 31
0 13 9 28
1
end_operator
begin_operator
board car6 loc19
1
29 10
2
0 0 0 31
0 13 10 28
1
end_operator
begin_operator
board car6 loc2
1
29 11
2
0 0 0 31
0 13 11 28
1
end_operator
begin_operator
board car6 loc20
1
29 12
2
0 0 0 31
0 13 12 28
1
end_operator
begin_operator
board car6 loc21
1
29 13
2
0 0 0 31
0 13 13 28
1
end_operator
begin_operator
board car6 loc22
1
29 14
2
0 0 0 31
0 13 14 28
1
end_operator
begin_operator
board car6 loc23
1
29 15
2
0 0 0 31
0 13 15 28
1
end_operator
begin_operator
board car6 loc24
1
29 16
2
0 0 0 31
0 13 16 28
1
end_operator
begin_operator
board car6 loc25
1
29 17
2
0 0 0 31
0 13 17 28
1
end_operator
begin_operator
board car6 loc26
1
29 18
2
0 0 0 31
0 13 18 28
1
end_operator
begin_operator
board car6 loc27
1
29 19
2
0 0 0 31
0 13 19 28
1
end_operator
begin_operator
board car6 loc28
1
29 20
2
0 0 0 31
0 13 20 28
1
end_operator
begin_operator
board car6 loc3
1
29 21
2
0 0 0 31
0 13 21 28
1
end_operator
begin_operator
board car6 loc4
1
29 22
2
0 0 0 31
0 13 22 28
1
end_operator
begin_operator
board car6 loc5
1
29 23
2
0 0 0 31
0 13 23 28
1
end_operator
begin_operator
board car6 loc6
1
29 24
2
0 0 0 31
0 13 24 28
1
end_operator
begin_operator
board car6 loc7
1
29 25
2
0 0 0 31
0 13 25 28
1
end_operator
begin_operator
board car6 loc8
1
29 26
2
0 0 0 31
0 13 26 28
1
end_operator
begin_operator
board car6 loc9
1
29 27
2
0 0 0 31
0 13 27 28
1
end_operator
begin_operator
board car7 loc1
1
29 0
2
0 0 0 32
0 17 0 28
1
end_operator
begin_operator
board car7 loc10
1
29 1
2
0 0 0 32
0 17 1 28
1
end_operator
begin_operator
board car7 loc11
1
29 2
2
0 0 0 32
0 17 2 28
1
end_operator
begin_operator
board car7 loc12
1
29 3
2
0 0 0 32
0 17 3 28
1
end_operator
begin_operator
board car7 loc13
1
29 4
2
0 0 0 32
0 17 4 28
1
end_operator
begin_operator
board car7 loc14
1
29 5
2
0 0 0 32
0 17 5 28
1
end_operator
begin_operator
board car7 loc15
1
29 6
2
0 0 0 32
0 17 6 28
1
end_operator
begin_operator
board car7 loc16
1
29 7
2
0 0 0 32
0 17 7 28
1
end_operator
begin_operator
board car7 loc17
1
29 8
2
0 0 0 32
0 17 8 28
1
end_operator
begin_operator
board car7 loc18
1
29 9
2
0 0 0 32
0 17 9 28
1
end_operator
begin_operator
board car7 loc19
1
29 10
2
0 0 0 32
0 17 10 28
1
end_operator
begin_operator
board car7 loc2
1
29 11
2
0 0 0 32
0 17 11 28
1
end_operator
begin_operator
board car7 loc20
1
29 12
2
0 0 0 32
0 17 12 28
1
end_operator
begin_operator
board car7 loc21
1
29 13
2
0 0 0 32
0 17 13 28
1
end_operator
begin_operator
board car7 loc22
1
29 14
2
0 0 0 32
0 17 14 28
1
end_operator
begin_operator
board car7 loc23
1
29 15
2
0 0 0 32
0 17 15 28
1
end_operator
begin_operator
board car7 loc24
1
29 16
2
0 0 0 32
0 17 16 28
1
end_operator
begin_operator
board car7 loc25
1
29 17
2
0 0 0 32
0 17 17 28
1
end_operator
begin_operator
board car7 loc26
1
29 18
2
0 0 0 32
0 17 18 28
1
end_operator
begin_operator
board car7 loc27
1
29 19
2
0 0 0 32
0 17 19 28
1
end_operator
begin_operator
board car7 loc28
1
29 20
2
0 0 0 32
0 17 20 28
1
end_operator
begin_operator
board car7 loc3
1
29 21
2
0 0 0 32
0 17 21 28
1
end_operator
begin_operator
board car7 loc4
1
29 22
2
0 0 0 32
0 17 22 28
1
end_operator
begin_operator
board car7 loc5
1
29 23
2
0 0 0 32
0 17 23 28
1
end_operator
begin_operator
board car7 loc6
1
29 24
2
0 0 0 32
0 17 24 28
1
end_operator
begin_operator
board car7 loc7
1
29 25
2
0 0 0 32
0 17 25 28
1
end_operator
begin_operator
board car7 loc8
1
29 26
2
0 0 0 32
0 17 26 28
1
end_operator
begin_operator
board car7 loc9
1
29 27
2
0 0 0 32
0 17 27 28
1
end_operator
begin_operator
board car8 loc1
1
29 0
2
0 0 0 33
0 21 0 28
1
end_operator
begin_operator
board car8 loc10
1
29 1
2
0 0 0 33
0 21 1 28
1
end_operator
begin_operator
board car8 loc11
1
29 2
2
0 0 0 33
0 21 2 28
1
end_operator
begin_operator
board car8 loc12
1
29 3
2
0 0 0 33
0 21 3 28
1
end_operator
begin_operator
board car8 loc13
1
29 4
2
0 0 0 33
0 21 4 28
1
end_operator
begin_operator
board car8 loc14
1
29 5
2
0 0 0 33
0 21 5 28
1
end_operator
begin_operator
board car8 loc15
1
29 6
2
0 0 0 33
0 21 6 28
1
end_operator
begin_operator
board car8 loc16
1
29 7
2
0 0 0 33
0 21 7 28
1
end_operator
begin_operator
board car8 loc17
1
29 8
2
0 0 0 33
0 21 8 28
1
end_operator
begin_operator
board car8 loc18
1
29 9
2
0 0 0 33
0 21 9 28
1
end_operator
begin_operator
board car8 loc19
1
29 10
2
0 0 0 33
0 21 10 28
1
end_operator
begin_operator
board car8 loc2
1
29 11
2
0 0 0 33
0 21 11 28
1
end_operator
begin_operator
board car8 loc20
1
29 12
2
0 0 0 33
0 21 12 28
1
end_operator
begin_operator
board car8 loc21
1
29 13
2
0 0 0 33
0 21 13 28
1
end_operator
begin_operator
board car8 loc22
1
29 14
2
0 0 0 33
0 21 14 28
1
end_operator
begin_operator
board car8 loc23
1
29 15
2
0 0 0 33
0 21 15 28
1
end_operator
begin_operator
board car8 loc24
1
29 16
2
0 0 0 33
0 21 16 28
1
end_operator
begin_operator
board car8 loc25
1
29 17
2
0 0 0 33
0 21 17 28
1
end_operator
begin_operator
board car8 loc26
1
29 18
2
0 0 0 33
0 21 18 28
1
end_operator
begin_operator
board car8 loc27
1
29 19
2
0 0 0 33
0 21 19 28
1
end_operator
begin_operator
board car8 loc28
1
29 20
2
0 0 0 33
0 21 20 28
1
end_operator
begin_operator
board car8 loc3
1
29 21
2
0 0 0 33
0 21 21 28
1
end_operator
begin_operator
board car8 loc4
1
29 22
2
0 0 0 33
0 21 22 28
1
end_operator
begin_operator
board car8 loc5
1
29 23
2
0 0 0 33
0 21 23 28
1
end_operator
begin_operator
board car8 loc6
1
29 24
2
0 0 0 33
0 21 24 28
1
end_operator
begin_operator
board car8 loc7
1
29 25
2
0 0 0 33
0 21 25 28
1
end_operator
begin_operator
board car8 loc8
1
29 26
2
0 0 0 33
0 21 26 28
1
end_operator
begin_operator
board car8 loc9
1
29 27
2
0 0 0 33
0 21 27 28
1
end_operator
begin_operator
board car9 loc1
1
29 0
2
0 0 0 34
0 25 0 28
1
end_operator
begin_operator
board car9 loc10
1
29 1
2
0 0 0 34
0 25 1 28
1
end_operator
begin_operator
board car9 loc11
1
29 2
2
0 0 0 34
0 25 2 28
1
end_operator
begin_operator
board car9 loc12
1
29 3
2
0 0 0 34
0 25 3 28
1
end_operator
begin_operator
board car9 loc13
1
29 4
2
0 0 0 34
0 25 4 28
1
end_operator
begin_operator
board car9 loc14
1
29 5
2
0 0 0 34
0 25 5 28
1
end_operator
begin_operator
board car9 loc15
1
29 6
2
0 0 0 34
0 25 6 28
1
end_operator
begin_operator
board car9 loc16
1
29 7
2
0 0 0 34
0 25 7 28
1
end_operator
begin_operator
board car9 loc17
1
29 8
2
0 0 0 34
0 25 8 28
1
end_operator
begin_operator
board car9 loc18
1
29 9
2
0 0 0 34
0 25 9 28
1
end_operator
begin_operator
board car9 loc19
1
29 10
2
0 0 0 34
0 25 10 28
1
end_operator
begin_operator
board car9 loc2
1
29 11
2
0 0 0 34
0 25 11 28
1
end_operator
begin_operator
board car9 loc20
1
29 12
2
0 0 0 34
0 25 12 28
1
end_operator
begin_operator
board car9 loc21
1
29 13
2
0 0 0 34
0 25 13 28
1
end_operator
begin_operator
board car9 loc22
1
29 14
2
0 0 0 34
0 25 14 28
1
end_operator
begin_operator
board car9 loc23
1
29 15
2
0 0 0 34
0 25 15 28
1
end_operator
begin_operator
board car9 loc24
1
29 16
2
0 0 0 34
0 25 16 28
1
end_operator
begin_operator
board car9 loc25
1
29 17
2
0 0 0 34
0 25 17 28
1
end_operator
begin_operator
board car9 loc26
1
29 18
2
0 0 0 34
0 25 18 28
1
end_operator
begin_operator
board car9 loc27
1
29 19
2
0 0 0 34
0 25 19 28
1
end_operator
begin_operator
board car9 loc28
1
29 20
2
0 0 0 34
0 25 20 28
1
end_operator
begin_operator
board car9 loc3
1
29 21
2
0 0 0 34
0 25 21 28
1
end_operator
begin_operator
board car9 loc4
1
29 22
2
0 0 0 34
0 25 22 28
1
end_operator
begin_operator
board car9 loc5
1
29 23
2
0 0 0 34
0 25 23 28
1
end_operator
begin_operator
board car9 loc6
1
29 24
2
0 0 0 34
0 25 24 28
1
end_operator
begin_operator
board car9 loc7
1
29 25
2
0 0 0 34
0 25 25 28
1
end_operator
begin_operator
board car9 loc8
1
29 26
2
0 0 0 34
0 25 26 28
1
end_operator
begin_operator
board car9 loc9
1
29 27
2
0 0 0 34
0 25 27 28
1
end_operator
begin_operator
debark car1 loc1
1
29 0
2
0 0 1 0
0 4 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
29 1
2
0 0 1 0
0 4 -1 1
1
end_operator
begin_operator
debark car1 loc11
1
29 2
2
0 0 1 0
0 4 -1 2
1
end_operator
begin_operator
debark car1 loc12
1
29 3
2
0 0 1 0
0 4 -1 3
1
end_operator
begin_operator
debark car1 loc13
1
29 4
2
0 0 1 0
0 4 -1 4
1
end_operator
begin_operator
debark car1 loc14
1
29 5
2
0 0 1 0
0 4 -1 5
1
end_operator
begin_operator
debark car1 loc15
1
29 6
2
0 0 1 0
0 4 -1 6
1
end_operator
begin_operator
debark car1 loc16
1
29 7
2
0 0 1 0
0 4 -1 7
1
end_operator
begin_operator
debark car1 loc17
1
29 8
2
0 0 1 0
0 4 -1 8
1
end_operator
begin_operator
debark car1 loc18
1
29 9
2
0 0 1 0
0 4 -1 9
1
end_operator
begin_operator
debark car1 loc19
1
29 10
2
0 0 1 0
0 4 -1 10
1
end_operator
begin_operator
debark car1 loc2
1
29 11
2
0 0 1 0
0 4 -1 11
1
end_operator
begin_operator
debark car1 loc20
1
29 12
2
0 0 1 0
0 4 -1 12
1
end_operator
begin_operator
debark car1 loc21
1
29 13
2
0 0 1 0
0 4 -1 13
1
end_operator
begin_operator
debark car1 loc22
1
29 14
2
0 0 1 0
0 4 -1 14
1
end_operator
begin_operator
debark car1 loc23
1
29 15
2
0 0 1 0
0 4 -1 15
1
end_operator
begin_operator
debark car1 loc24
1
29 16
2
0 0 1 0
0 4 -1 16
1
end_operator
begin_operator
debark car1 loc25
1
29 17
2
0 0 1 0
0 4 -1 17
1
end_operator
begin_operator
debark car1 loc26
1
29 18
2
0 0 1 0
0 4 -1 18
1
end_operator
begin_operator
debark car1 loc27
1
29 19
2
0 0 1 0
0 4 -1 19
1
end_operator
begin_operator
debark car1 loc28
1
29 20
2
0 0 1 0
0 4 -1 20
1
end_operator
begin_operator
debark car1 loc3
1
29 21
2
0 0 1 0
0 4 -1 21
1
end_operator
begin_operator
debark car1 loc4
1
29 22
2
0 0 1 0
0 4 -1 22
1
end_operator
begin_operator
debark car1 loc5
1
29 23
2
0 0 1 0
0 4 -1 23
1
end_operator
begin_operator
debark car1 loc6
1
29 24
2
0 0 1 0
0 4 -1 24
1
end_operator
begin_operator
debark car1 loc7
1
29 25
2
0 0 1 0
0 4 -1 25
1
end_operator
begin_operator
debark car1 loc8
1
29 26
2
0 0 1 0
0 4 -1 26
1
end_operator
begin_operator
debark car1 loc9
1
29 27
2
0 0 1 0
0 4 -1 27
1
end_operator
begin_operator
debark car10 loc1
1
29 0
2
0 0 2 0
0 8 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
29 1
2
0 0 2 0
0 8 -1 1
1
end_operator
begin_operator
debark car10 loc11
1
29 2
2
0 0 2 0
0 8 -1 2
1
end_operator
begin_operator
debark car10 loc12
1
29 3
2
0 0 2 0
0 8 -1 3
1
end_operator
begin_operator
debark car10 loc13
1
29 4
2
0 0 2 0
0 8 -1 4
1
end_operator
begin_operator
debark car10 loc14
1
29 5
2
0 0 2 0
0 8 -1 5
1
end_operator
begin_operator
debark car10 loc15
1
29 6
2
0 0 2 0
0 8 -1 6
1
end_operator
begin_operator
debark car10 loc16
1
29 7
2
0 0 2 0
0 8 -1 7
1
end_operator
begin_operator
debark car10 loc17
1
29 8
2
0 0 2 0
0 8 -1 8
1
end_operator
begin_operator
debark car10 loc18
1
29 9
2
0 0 2 0
0 8 -1 9
1
end_operator
begin_operator
debark car10 loc19
1
29 10
2
0 0 2 0
0 8 -1 10
1
end_operator
begin_operator
debark car10 loc2
1
29 11
2
0 0 2 0
0 8 -1 11
1
end_operator
begin_operator
debark car10 loc20
1
29 12
2
0 0 2 0
0 8 -1 12
1
end_operator
begin_operator
debark car10 loc21
1
29 13
2
0 0 2 0
0 8 -1 13
1
end_operator
begin_operator
debark car10 loc22
1
29 14
2
0 0 2 0
0 8 -1 14
1
end_operator
begin_operator
debark car10 loc23
1
29 15
2
0 0 2 0
0 8 -1 15
1
end_operator
begin_operator
debark car10 loc24
1
29 16
2
0 0 2 0
0 8 -1 16
1
end_operator
begin_operator
debark car10 loc25
1
29 17
2
0 0 2 0
0 8 -1 17
1
end_operator
begin_operator
debark car10 loc26
1
29 18
2
0 0 2 0
0 8 -1 18
1
end_operator
begin_operator
debark car10 loc27
1
29 19
2
0 0 2 0
0 8 -1 19
1
end_operator
begin_operator
debark car10 loc28
1
29 20
2
0 0 2 0
0 8 -1 20
1
end_operator
begin_operator
debark car10 loc3
1
29 21
2
0 0 2 0
0 8 -1 21
1
end_operator
begin_operator
debark car10 loc4
1
29 22
2
0 0 2 0
0 8 -1 22
1
end_operator
begin_operator
debark car10 loc5
1
29 23
2
0 0 2 0
0 8 -1 23
1
end_operator
begin_operator
debark car10 loc6
1
29 24
2
0 0 2 0
0 8 -1 24
1
end_operator
begin_operator
debark car10 loc7
1
29 25
2
0 0 2 0
0 8 -1 25
1
end_operator
begin_operator
debark car10 loc8
1
29 26
2
0 0 2 0
0 8 -1 26
1
end_operator
begin_operator
debark car10 loc9
1
29 27
2
0 0 2 0
0 8 -1 27
1
end_operator
begin_operator
debark car11 loc1
1
29 0
2
0 0 3 0
0 12 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
29 1
2
0 0 3 0
0 12 -1 1
1
end_operator
begin_operator
debark car11 loc11
1
29 2
2
0 0 3 0
0 12 -1 2
1
end_operator
begin_operator
debark car11 loc12
1
29 3
2
0 0 3 0
0 12 -1 3
1
end_operator
begin_operator
debark car11 loc13
1
29 4
2
0 0 3 0
0 12 -1 4
1
end_operator
begin_operator
debark car11 loc14
1
29 5
2
0 0 3 0
0 12 -1 5
1
end_operator
begin_operator
debark car11 loc15
1
29 6
2
0 0 3 0
0 12 -1 6
1
end_operator
begin_operator
debark car11 loc16
1
29 7
2
0 0 3 0
0 12 -1 7
1
end_operator
begin_operator
debark car11 loc17
1
29 8
2
0 0 3 0
0 12 -1 8
1
end_operator
begin_operator
debark car11 loc18
1
29 9
2
0 0 3 0
0 12 -1 9
1
end_operator
begin_operator
debark car11 loc19
1
29 10
2
0 0 3 0
0 12 -1 10
1
end_operator
begin_operator
debark car11 loc2
1
29 11
2
0 0 3 0
0 12 -1 11
1
end_operator
begin_operator
debark car11 loc20
1
29 12
2
0 0 3 0
0 12 -1 12
1
end_operator
begin_operator
debark car11 loc21
1
29 13
2
0 0 3 0
0 12 -1 13
1
end_operator
begin_operator
debark car11 loc22
1
29 14
2
0 0 3 0
0 12 -1 14
1
end_operator
begin_operator
debark car11 loc23
1
29 15
2
0 0 3 0
0 12 -1 15
1
end_operator
begin_operator
debark car11 loc24
1
29 16
2
0 0 3 0
0 12 -1 16
1
end_operator
begin_operator
debark car11 loc25
1
29 17
2
0 0 3 0
0 12 -1 17
1
end_operator
begin_operator
debark car11 loc26
1
29 18
2
0 0 3 0
0 12 -1 18
1
end_operator
begin_operator
debark car11 loc27
1
29 19
2
0 0 3 0
0 12 -1 19
1
end_operator
begin_operator
debark car11 loc28
1
29 20
2
0 0 3 0
0 12 -1 20
1
end_operator
begin_operator
debark car11 loc3
1
29 21
2
0 0 3 0
0 12 -1 21
1
end_operator
begin_operator
debark car11 loc4
1
29 22
2
0 0 3 0
0 12 -1 22
1
end_operator
begin_operator
debark car11 loc5
1
29 23
2
0 0 3 0
0 12 -1 23
1
end_operator
begin_operator
debark car11 loc6
1
29 24
2
0 0 3 0
0 12 -1 24
1
end_operator
begin_operator
debark car11 loc7
1
29 25
2
0 0 3 0
0 12 -1 25
1
end_operator
begin_operator
debark car11 loc8
1
29 26
2
0 0 3 0
0 12 -1 26
1
end_operator
begin_operator
debark car11 loc9
1
29 27
2
0 0 3 0
0 12 -1 27
1
end_operator
begin_operator
debark car12 loc1
1
29 0
2
0 0 4 0
0 16 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
29 1
2
0 0 4 0
0 16 -1 1
1
end_operator
begin_operator
debark car12 loc11
1
29 2
2
0 0 4 0
0 16 -1 2
1
end_operator
begin_operator
debark car12 loc12
1
29 3
2
0 0 4 0
0 16 -1 3
1
end_operator
begin_operator
debark car12 loc13
1
29 4
2
0 0 4 0
0 16 -1 4
1
end_operator
begin_operator
debark car12 loc14
1
29 5
2
0 0 4 0
0 16 -1 5
1
end_operator
begin_operator
debark car12 loc15
1
29 6
2
0 0 4 0
0 16 -1 6
1
end_operator
begin_operator
debark car12 loc16
1
29 7
2
0 0 4 0
0 16 -1 7
1
end_operator
begin_operator
debark car12 loc17
1
29 8
2
0 0 4 0
0 16 -1 8
1
end_operator
begin_operator
debark car12 loc18
1
29 9
2
0 0 4 0
0 16 -1 9
1
end_operator
begin_operator
debark car12 loc19
1
29 10
2
0 0 4 0
0 16 -1 10
1
end_operator
begin_operator
debark car12 loc2
1
29 11
2
0 0 4 0
0 16 -1 11
1
end_operator
begin_operator
debark car12 loc20
1
29 12
2
0 0 4 0
0 16 -1 12
1
end_operator
begin_operator
debark car12 loc21
1
29 13
2
0 0 4 0
0 16 -1 13
1
end_operator
begin_operator
debark car12 loc22
1
29 14
2
0 0 4 0
0 16 -1 14
1
end_operator
begin_operator
debark car12 loc23
1
29 15
2
0 0 4 0
0 16 -1 15
1
end_operator
begin_operator
debark car12 loc24
1
29 16
2
0 0 4 0
0 16 -1 16
1
end_operator
begin_operator
debark car12 loc25
1
29 17
2
0 0 4 0
0 16 -1 17
1
end_operator
begin_operator
debark car12 loc26
1
29 18
2
0 0 4 0
0 16 -1 18
1
end_operator
begin_operator
debark car12 loc27
1
29 19
2
0 0 4 0
0 16 -1 19
1
end_operator
begin_operator
debark car12 loc28
1
29 20
2
0 0 4 0
0 16 -1 20
1
end_operator
begin_operator
debark car12 loc3
1
29 21
2
0 0 4 0
0 16 -1 21
1
end_operator
begin_operator
debark car12 loc4
1
29 22
2
0 0 4 0
0 16 -1 22
1
end_operator
begin_operator
debark car12 loc5
1
29 23
2
0 0 4 0
0 16 -1 23
1
end_operator
begin_operator
debark car12 loc6
1
29 24
2
0 0 4 0
0 16 -1 24
1
end_operator
begin_operator
debark car12 loc7
1
29 25
2
0 0 4 0
0 16 -1 25
1
end_operator
begin_operator
debark car12 loc8
1
29 26
2
0 0 4 0
0 16 -1 26
1
end_operator
begin_operator
debark car12 loc9
1
29 27
2
0 0 4 0
0 16 -1 27
1
end_operator
begin_operator
debark car13 loc1
1
29 0
2
0 0 5 0
0 20 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
29 1
2
0 0 5 0
0 20 -1 1
1
end_operator
begin_operator
debark car13 loc11
1
29 2
2
0 0 5 0
0 20 -1 2
1
end_operator
begin_operator
debark car13 loc12
1
29 3
2
0 0 5 0
0 20 -1 3
1
end_operator
begin_operator
debark car13 loc13
1
29 4
2
0 0 5 0
0 20 -1 4
1
end_operator
begin_operator
debark car13 loc14
1
29 5
2
0 0 5 0
0 20 -1 5
1
end_operator
begin_operator
debark car13 loc15
1
29 6
2
0 0 5 0
0 20 -1 6
1
end_operator
begin_operator
debark car13 loc16
1
29 7
2
0 0 5 0
0 20 -1 7
1
end_operator
begin_operator
debark car13 loc17
1
29 8
2
0 0 5 0
0 20 -1 8
1
end_operator
begin_operator
debark car13 loc18
1
29 9
2
0 0 5 0
0 20 -1 9
1
end_operator
begin_operator
debark car13 loc19
1
29 10
2
0 0 5 0
0 20 -1 10
1
end_operator
begin_operator
debark car13 loc2
1
29 11
2
0 0 5 0
0 20 -1 11
1
end_operator
begin_operator
debark car13 loc20
1
29 12
2
0 0 5 0
0 20 -1 12
1
end_operator
begin_operator
debark car13 loc21
1
29 13
2
0 0 5 0
0 20 -1 13
1
end_operator
begin_operator
debark car13 loc22
1
29 14
2
0 0 5 0
0 20 -1 14
1
end_operator
begin_operator
debark car13 loc23
1
29 15
2
0 0 5 0
0 20 -1 15
1
end_operator
begin_operator
debark car13 loc24
1
29 16
2
0 0 5 0
0 20 -1 16
1
end_operator
begin_operator
debark car13 loc25
1
29 17
2
0 0 5 0
0 20 -1 17
1
end_operator
begin_operator
debark car13 loc26
1
29 18
2
0 0 5 0
0 20 -1 18
1
end_operator
begin_operator
debark car13 loc27
1
29 19
2
0 0 5 0
0 20 -1 19
1
end_operator
begin_operator
debark car13 loc28
1
29 20
2
0 0 5 0
0 20 -1 20
1
end_operator
begin_operator
debark car13 loc3
1
29 21
2
0 0 5 0
0 20 -1 21
1
end_operator
begin_operator
debark car13 loc4
1
29 22
2
0 0 5 0
0 20 -1 22
1
end_operator
begin_operator
debark car13 loc5
1
29 23
2
0 0 5 0
0 20 -1 23
1
end_operator
begin_operator
debark car13 loc6
1
29 24
2
0 0 5 0
0 20 -1 24
1
end_operator
begin_operator
debark car13 loc7
1
29 25
2
0 0 5 0
0 20 -1 25
1
end_operator
begin_operator
debark car13 loc8
1
29 26
2
0 0 5 0
0 20 -1 26
1
end_operator
begin_operator
debark car13 loc9
1
29 27
2
0 0 5 0
0 20 -1 27
1
end_operator
begin_operator
debark car14 loc1
1
29 0
2
0 0 6 0
0 24 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
29 1
2
0 0 6 0
0 24 -1 1
1
end_operator
begin_operator
debark car14 loc11
1
29 2
2
0 0 6 0
0 24 -1 2
1
end_operator
begin_operator
debark car14 loc12
1
29 3
2
0 0 6 0
0 24 -1 3
1
end_operator
begin_operator
debark car14 loc13
1
29 4
2
0 0 6 0
0 24 -1 4
1
end_operator
begin_operator
debark car14 loc14
1
29 5
2
0 0 6 0
0 24 -1 5
1
end_operator
begin_operator
debark car14 loc15
1
29 6
2
0 0 6 0
0 24 -1 6
1
end_operator
begin_operator
debark car14 loc16
1
29 7
2
0 0 6 0
0 24 -1 7
1
end_operator
begin_operator
debark car14 loc17
1
29 8
2
0 0 6 0
0 24 -1 8
1
end_operator
begin_operator
debark car14 loc18
1
29 9
2
0 0 6 0
0 24 -1 9
1
end_operator
begin_operator
debark car14 loc19
1
29 10
2
0 0 6 0
0 24 -1 10
1
end_operator
begin_operator
debark car14 loc2
1
29 11
2
0 0 6 0
0 24 -1 11
1
end_operator
begin_operator
debark car14 loc20
1
29 12
2
0 0 6 0
0 24 -1 12
1
end_operator
begin_operator
debark car14 loc21
1
29 13
2
0 0 6 0
0 24 -1 13
1
end_operator
begin_operator
debark car14 loc22
1
29 14
2
0 0 6 0
0 24 -1 14
1
end_operator
begin_operator
debark car14 loc23
1
29 15
2
0 0 6 0
0 24 -1 15
1
end_operator
begin_operator
debark car14 loc24
1
29 16
2
0 0 6 0
0 24 -1 16
1
end_operator
begin_operator
debark car14 loc25
1
29 17
2
0 0 6 0
0 24 -1 17
1
end_operator
begin_operator
debark car14 loc26
1
29 18
2
0 0 6 0
0 24 -1 18
1
end_operator
begin_operator
debark car14 loc27
1
29 19
2
0 0 6 0
0 24 -1 19
1
end_operator
begin_operator
debark car14 loc28
1
29 20
2
0 0 6 0
0 24 -1 20
1
end_operator
begin_operator
debark car14 loc3
1
29 21
2
0 0 6 0
0 24 -1 21
1
end_operator
begin_operator
debark car14 loc4
1
29 22
2
0 0 6 0
0 24 -1 22
1
end_operator
begin_operator
debark car14 loc5
1
29 23
2
0 0 6 0
0 24 -1 23
1
end_operator
begin_operator
debark car14 loc6
1
29 24
2
0 0 6 0
0 24 -1 24
1
end_operator
begin_operator
debark car14 loc7
1
29 25
2
0 0 6 0
0 24 -1 25
1
end_operator
begin_operator
debark car14 loc8
1
29 26
2
0 0 6 0
0 24 -1 26
1
end_operator
begin_operator
debark car14 loc9
1
29 27
2
0 0 6 0
0 24 -1 27
1
end_operator
begin_operator
debark car15 loc1
1
29 0
2
0 0 7 0
0 28 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
29 1
2
0 0 7 0
0 28 -1 1
1
end_operator
begin_operator
debark car15 loc11
1
29 2
2
0 0 7 0
0 28 -1 2
1
end_operator
begin_operator
debark car15 loc12
1
29 3
2
0 0 7 0
0 28 -1 3
1
end_operator
begin_operator
debark car15 loc13
1
29 4
2
0 0 7 0
0 28 -1 4
1
end_operator
begin_operator
debark car15 loc14
1
29 5
2
0 0 7 0
0 28 -1 5
1
end_operator
begin_operator
debark car15 loc15
1
29 6
2
0 0 7 0
0 28 -1 6
1
end_operator
begin_operator
debark car15 loc16
1
29 7
2
0 0 7 0
0 28 -1 7
1
end_operator
begin_operator
debark car15 loc17
1
29 8
2
0 0 7 0
0 28 -1 8
1
end_operator
begin_operator
debark car15 loc18
1
29 9
2
0 0 7 0
0 28 -1 9
1
end_operator
begin_operator
debark car15 loc19
1
29 10
2
0 0 7 0
0 28 -1 10
1
end_operator
begin_operator
debark car15 loc2
1
29 11
2
0 0 7 0
0 28 -1 11
1
end_operator
begin_operator
debark car15 loc20
1
29 12
2
0 0 7 0
0 28 -1 12
1
end_operator
begin_operator
debark car15 loc21
1
29 13
2
0 0 7 0
0 28 -1 13
1
end_operator
begin_operator
debark car15 loc22
1
29 14
2
0 0 7 0
0 28 -1 14
1
end_operator
begin_operator
debark car15 loc23
1
29 15
2
0 0 7 0
0 28 -1 15
1
end_operator
begin_operator
debark car15 loc24
1
29 16
2
0 0 7 0
0 28 -1 16
1
end_operator
begin_operator
debark car15 loc25
1
29 17
2
0 0 7 0
0 28 -1 17
1
end_operator
begin_operator
debark car15 loc26
1
29 18
2
0 0 7 0
0 28 -1 18
1
end_operator
begin_operator
debark car15 loc27
1
29 19
2
0 0 7 0
0 28 -1 19
1
end_operator
begin_operator
debark car15 loc28
1
29 20
2
0 0 7 0
0 28 -1 20
1
end_operator
begin_operator
debark car15 loc3
1
29 21
2
0 0 7 0
0 28 -1 21
1
end_operator
begin_operator
debark car15 loc4
1
29 22
2
0 0 7 0
0 28 -1 22
1
end_operator
begin_operator
debark car15 loc5
1
29 23
2
0 0 7 0
0 28 -1 23
1
end_operator
begin_operator
debark car15 loc6
1
29 24
2
0 0 7 0
0 28 -1 24
1
end_operator
begin_operator
debark car15 loc7
1
29 25
2
0 0 7 0
0 28 -1 25
1
end_operator
begin_operator
debark car15 loc8
1
29 26
2
0 0 7 0
0 28 -1 26
1
end_operator
begin_operator
debark car15 loc9
1
29 27
2
0 0 7 0
0 28 -1 27
1
end_operator
begin_operator
debark car16 loc1
1
29 0
2
0 0 8 0
0 32 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
29 1
2
0 0 8 0
0 32 -1 1
1
end_operator
begin_operator
debark car16 loc11
1
29 2
2
0 0 8 0
0 32 -1 2
1
end_operator
begin_operator
debark car16 loc12
1
29 3
2
0 0 8 0
0 32 -1 3
1
end_operator
begin_operator
debark car16 loc13
1
29 4
2
0 0 8 0
0 32 -1 4
1
end_operator
begin_operator
debark car16 loc14
1
29 5
2
0 0 8 0
0 32 -1 5
1
end_operator
begin_operator
debark car16 loc15
1
29 6
2
0 0 8 0
0 32 -1 6
1
end_operator
begin_operator
debark car16 loc16
1
29 7
2
0 0 8 0
0 32 -1 7
1
end_operator
begin_operator
debark car16 loc17
1
29 8
2
0 0 8 0
0 32 -1 8
1
end_operator
begin_operator
debark car16 loc18
1
29 9
2
0 0 8 0
0 32 -1 9
1
end_operator
begin_operator
debark car16 loc19
1
29 10
2
0 0 8 0
0 32 -1 10
1
end_operator
begin_operator
debark car16 loc2
1
29 11
2
0 0 8 0
0 32 -1 11
1
end_operator
begin_operator
debark car16 loc20
1
29 12
2
0 0 8 0
0 32 -1 12
1
end_operator
begin_operator
debark car16 loc21
1
29 13
2
0 0 8 0
0 32 -1 13
1
end_operator
begin_operator
debark car16 loc22
1
29 14
2
0 0 8 0
0 32 -1 14
1
end_operator
begin_operator
debark car16 loc23
1
29 15
2
0 0 8 0
0 32 -1 15
1
end_operator
begin_operator
debark car16 loc24
1
29 16
2
0 0 8 0
0 32 -1 16
1
end_operator
begin_operator
debark car16 loc25
1
29 17
2
0 0 8 0
0 32 -1 17
1
end_operator
begin_operator
debark car16 loc26
1
29 18
2
0 0 8 0
0 32 -1 18
1
end_operator
begin_operator
debark car16 loc27
1
29 19
2
0 0 8 0
0 32 -1 19
1
end_operator
begin_operator
debark car16 loc28
1
29 20
2
0 0 8 0
0 32 -1 20
1
end_operator
begin_operator
debark car16 loc3
1
29 21
2
0 0 8 0
0 32 -1 21
1
end_operator
begin_operator
debark car16 loc4
1
29 22
2
0 0 8 0
0 32 -1 22
1
end_operator
begin_operator
debark car16 loc5
1
29 23
2
0 0 8 0
0 32 -1 23
1
end_operator
begin_operator
debark car16 loc6
1
29 24
2
0 0 8 0
0 32 -1 24
1
end_operator
begin_operator
debark car16 loc7
1
29 25
2
0 0 8 0
0 32 -1 25
1
end_operator
begin_operator
debark car16 loc8
1
29 26
2
0 0 8 0
0 32 -1 26
1
end_operator
begin_operator
debark car16 loc9
1
29 27
2
0 0 8 0
0 32 -1 27
1
end_operator
begin_operator
debark car17 loc1
1
29 0
2
0 0 9 0
0 35 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
29 1
2
0 0 9 0
0 35 -1 1
1
end_operator
begin_operator
debark car17 loc11
1
29 2
2
0 0 9 0
0 35 -1 2
1
end_operator
begin_operator
debark car17 loc12
1
29 3
2
0 0 9 0
0 35 -1 3
1
end_operator
begin_operator
debark car17 loc13
1
29 4
2
0 0 9 0
0 35 -1 4
1
end_operator
begin_operator
debark car17 loc14
1
29 5
2
0 0 9 0
0 35 -1 5
1
end_operator
begin_operator
debark car17 loc15
1
29 6
2
0 0 9 0
0 35 -1 6
1
end_operator
begin_operator
debark car17 loc16
1
29 7
2
0 0 9 0
0 35 -1 7
1
end_operator
begin_operator
debark car17 loc17
1
29 8
2
0 0 9 0
0 35 -1 8
1
end_operator
begin_operator
debark car17 loc18
1
29 9
2
0 0 9 0
0 35 -1 9
1
end_operator
begin_operator
debark car17 loc19
1
29 10
2
0 0 9 0
0 35 -1 10
1
end_operator
begin_operator
debark car17 loc2
1
29 11
2
0 0 9 0
0 35 -1 11
1
end_operator
begin_operator
debark car17 loc20
1
29 12
2
0 0 9 0
0 35 -1 12
1
end_operator
begin_operator
debark car17 loc21
1
29 13
2
0 0 9 0
0 35 -1 13
1
end_operator
begin_operator
debark car17 loc22
1
29 14
2
0 0 9 0
0 35 -1 14
1
end_operator
begin_operator
debark car17 loc23
1
29 15
2
0 0 9 0
0 35 -1 15
1
end_operator
begin_operator
debark car17 loc24
1
29 16
2
0 0 9 0
0 35 -1 16
1
end_operator
begin_operator
debark car17 loc25
1
29 17
2
0 0 9 0
0 35 -1 17
1
end_operator
begin_operator
debark car17 loc26
1
29 18
2
0 0 9 0
0 35 -1 18
1
end_operator
begin_operator
debark car17 loc27
1
29 19
2
0 0 9 0
0 35 -1 19
1
end_operator
begin_operator
debark car17 loc28
1
29 20
2
0 0 9 0
0 35 -1 20
1
end_operator
begin_operator
debark car17 loc3
1
29 21
2
0 0 9 0
0 35 -1 21
1
end_operator
begin_operator
debark car17 loc4
1
29 22
2
0 0 9 0
0 35 -1 22
1
end_operator
begin_operator
debark car17 loc5
1
29 23
2
0 0 9 0
0 35 -1 23
1
end_operator
begin_operator
debark car17 loc6
1
29 24
2
0 0 9 0
0 35 -1 24
1
end_operator
begin_operator
debark car17 loc7
1
29 25
2
0 0 9 0
0 35 -1 25
1
end_operator
begin_operator
debark car17 loc8
1
29 26
2
0 0 9 0
0 35 -1 26
1
end_operator
begin_operator
debark car17 loc9
1
29 27
2
0 0 9 0
0 35 -1 27
1
end_operator
begin_operator
debark car18 loc1
1
29 0
2
0 0 10 0
0 3 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
29 1
2
0 0 10 0
0 3 -1 1
1
end_operator
begin_operator
debark car18 loc11
1
29 2
2
0 0 10 0
0 3 -1 2
1
end_operator
begin_operator
debark car18 loc12
1
29 3
2
0 0 10 0
0 3 -1 3
1
end_operator
begin_operator
debark car18 loc13
1
29 4
2
0 0 10 0
0 3 -1 4
1
end_operator
begin_operator
debark car18 loc14
1
29 5
2
0 0 10 0
0 3 -1 5
1
end_operator
begin_operator
debark car18 loc15
1
29 6
2
0 0 10 0
0 3 -1 6
1
end_operator
begin_operator
debark car18 loc16
1
29 7
2
0 0 10 0
0 3 -1 7
1
end_operator
begin_operator
debark car18 loc17
1
29 8
2
0 0 10 0
0 3 -1 8
1
end_operator
begin_operator
debark car18 loc18
1
29 9
2
0 0 10 0
0 3 -1 9
1
end_operator
begin_operator
debark car18 loc19
1
29 10
2
0 0 10 0
0 3 -1 10
1
end_operator
begin_operator
debark car18 loc2
1
29 11
2
0 0 10 0
0 3 -1 11
1
end_operator
begin_operator
debark car18 loc20
1
29 12
2
0 0 10 0
0 3 -1 12
1
end_operator
begin_operator
debark car18 loc21
1
29 13
2
0 0 10 0
0 3 -1 13
1
end_operator
begin_operator
debark car18 loc22
1
29 14
2
0 0 10 0
0 3 -1 14
1
end_operator
begin_operator
debark car18 loc23
1
29 15
2
0 0 10 0
0 3 -1 15
1
end_operator
begin_operator
debark car18 loc24
1
29 16
2
0 0 10 0
0 3 -1 16
1
end_operator
begin_operator
debark car18 loc25
1
29 17
2
0 0 10 0
0 3 -1 17
1
end_operator
begin_operator
debark car18 loc26
1
29 18
2
0 0 10 0
0 3 -1 18
1
end_operator
begin_operator
debark car18 loc27
1
29 19
2
0 0 10 0
0 3 -1 19
1
end_operator
begin_operator
debark car18 loc28
1
29 20
2
0 0 10 0
0 3 -1 20
1
end_operator
begin_operator
debark car18 loc3
1
29 21
2
0 0 10 0
0 3 -1 21
1
end_operator
begin_operator
debark car18 loc4
1
29 22
2
0 0 10 0
0 3 -1 22
1
end_operator
begin_operator
debark car18 loc5
1
29 23
2
0 0 10 0
0 3 -1 23
1
end_operator
begin_operator
debark car18 loc6
1
29 24
2
0 0 10 0
0 3 -1 24
1
end_operator
begin_operator
debark car18 loc7
1
29 25
2
0 0 10 0
0 3 -1 25
1
end_operator
begin_operator
debark car18 loc8
1
29 26
2
0 0 10 0
0 3 -1 26
1
end_operator
begin_operator
debark car18 loc9
1
29 27
2
0 0 10 0
0 3 -1 27
1
end_operator
begin_operator
debark car19 loc1
1
29 0
2
0 0 11 0
0 7 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
29 1
2
0 0 11 0
0 7 -1 1
1
end_operator
begin_operator
debark car19 loc11
1
29 2
2
0 0 11 0
0 7 -1 2
1
end_operator
begin_operator
debark car19 loc12
1
29 3
2
0 0 11 0
0 7 -1 3
1
end_operator
begin_operator
debark car19 loc13
1
29 4
2
0 0 11 0
0 7 -1 4
1
end_operator
begin_operator
debark car19 loc14
1
29 5
2
0 0 11 0
0 7 -1 5
1
end_operator
begin_operator
debark car19 loc15
1
29 6
2
0 0 11 0
0 7 -1 6
1
end_operator
begin_operator
debark car19 loc16
1
29 7
2
0 0 11 0
0 7 -1 7
1
end_operator
begin_operator
debark car19 loc17
1
29 8
2
0 0 11 0
0 7 -1 8
1
end_operator
begin_operator
debark car19 loc18
1
29 9
2
0 0 11 0
0 7 -1 9
1
end_operator
begin_operator
debark car19 loc19
1
29 10
2
0 0 11 0
0 7 -1 10
1
end_operator
begin_operator
debark car19 loc2
1
29 11
2
0 0 11 0
0 7 -1 11
1
end_operator
begin_operator
debark car19 loc20
1
29 12
2
0 0 11 0
0 7 -1 12
1
end_operator
begin_operator
debark car19 loc21
1
29 13
2
0 0 11 0
0 7 -1 13
1
end_operator
begin_operator
debark car19 loc22
1
29 14
2
0 0 11 0
0 7 -1 14
1
end_operator
begin_operator
debark car19 loc23
1
29 15
2
0 0 11 0
0 7 -1 15
1
end_operator
begin_operator
debark car19 loc24
1
29 16
2
0 0 11 0
0 7 -1 16
1
end_operator
begin_operator
debark car19 loc25
1
29 17
2
0 0 11 0
0 7 -1 17
1
end_operator
begin_operator
debark car19 loc26
1
29 18
2
0 0 11 0
0 7 -1 18
1
end_operator
begin_operator
debark car19 loc27
1
29 19
2
0 0 11 0
0 7 -1 19
1
end_operator
begin_operator
debark car19 loc28
1
29 20
2
0 0 11 0
0 7 -1 20
1
end_operator
begin_operator
debark car19 loc3
1
29 21
2
0 0 11 0
0 7 -1 21
1
end_operator
begin_operator
debark car19 loc4
1
29 22
2
0 0 11 0
0 7 -1 22
1
end_operator
begin_operator
debark car19 loc5
1
29 23
2
0 0 11 0
0 7 -1 23
1
end_operator
begin_operator
debark car19 loc6
1
29 24
2
0 0 11 0
0 7 -1 24
1
end_operator
begin_operator
debark car19 loc7
1
29 25
2
0 0 11 0
0 7 -1 25
1
end_operator
begin_operator
debark car19 loc8
1
29 26
2
0 0 11 0
0 7 -1 26
1
end_operator
begin_operator
debark car19 loc9
1
29 27
2
0 0 11 0
0 7 -1 27
1
end_operator
begin_operator
debark car2 loc1
1
29 0
2
0 0 12 0
0 11 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
29 1
2
0 0 12 0
0 11 -1 1
1
end_operator
begin_operator
debark car2 loc11
1
29 2
2
0 0 12 0
0 11 -1 2
1
end_operator
begin_operator
debark car2 loc12
1
29 3
2
0 0 12 0
0 11 -1 3
1
end_operator
begin_operator
debark car2 loc13
1
29 4
2
0 0 12 0
0 11 -1 4
1
end_operator
begin_operator
debark car2 loc14
1
29 5
2
0 0 12 0
0 11 -1 5
1
end_operator
begin_operator
debark car2 loc15
1
29 6
2
0 0 12 0
0 11 -1 6
1
end_operator
begin_operator
debark car2 loc16
1
29 7
2
0 0 12 0
0 11 -1 7
1
end_operator
begin_operator
debark car2 loc17
1
29 8
2
0 0 12 0
0 11 -1 8
1
end_operator
begin_operator
debark car2 loc18
1
29 9
2
0 0 12 0
0 11 -1 9
1
end_operator
begin_operator
debark car2 loc19
1
29 10
2
0 0 12 0
0 11 -1 10
1
end_operator
begin_operator
debark car2 loc2
1
29 11
2
0 0 12 0
0 11 -1 11
1
end_operator
begin_operator
debark car2 loc20
1
29 12
2
0 0 12 0
0 11 -1 12
1
end_operator
begin_operator
debark car2 loc21
1
29 13
2
0 0 12 0
0 11 -1 13
1
end_operator
begin_operator
debark car2 loc22
1
29 14
2
0 0 12 0
0 11 -1 14
1
end_operator
begin_operator
debark car2 loc23
1
29 15
2
0 0 12 0
0 11 -1 15
1
end_operator
begin_operator
debark car2 loc24
1
29 16
2
0 0 12 0
0 11 -1 16
1
end_operator
begin_operator
debark car2 loc25
1
29 17
2
0 0 12 0
0 11 -1 17
1
end_operator
begin_operator
debark car2 loc26
1
29 18
2
0 0 12 0
0 11 -1 18
1
end_operator
begin_operator
debark car2 loc27
1
29 19
2
0 0 12 0
0 11 -1 19
1
end_operator
begin_operator
debark car2 loc28
1
29 20
2
0 0 12 0
0 11 -1 20
1
end_operator
begin_operator
debark car2 loc3
1
29 21
2
0 0 12 0
0 11 -1 21
1
end_operator
begin_operator
debark car2 loc4
1
29 22
2
0 0 12 0
0 11 -1 22
1
end_operator
begin_operator
debark car2 loc5
1
29 23
2
0 0 12 0
0 11 -1 23
1
end_operator
begin_operator
debark car2 loc6
1
29 24
2
0 0 12 0
0 11 -1 24
1
end_operator
begin_operator
debark car2 loc7
1
29 25
2
0 0 12 0
0 11 -1 25
1
end_operator
begin_operator
debark car2 loc8
1
29 26
2
0 0 12 0
0 11 -1 26
1
end_operator
begin_operator
debark car2 loc9
1
29 27
2
0 0 12 0
0 11 -1 27
1
end_operator
begin_operator
debark car20 loc1
1
29 0
2
0 0 13 0
0 15 -1 0
1
end_operator
begin_operator
debark car20 loc10
1
29 1
2
0 0 13 0
0 15 -1 1
1
end_operator
begin_operator
debark car20 loc11
1
29 2
2
0 0 13 0
0 15 -1 2
1
end_operator
begin_operator
debark car20 loc12
1
29 3
2
0 0 13 0
0 15 -1 3
1
end_operator
begin_operator
debark car20 loc13
1
29 4
2
0 0 13 0
0 15 -1 4
1
end_operator
begin_operator
debark car20 loc14
1
29 5
2
0 0 13 0
0 15 -1 5
1
end_operator
begin_operator
debark car20 loc15
1
29 6
2
0 0 13 0
0 15 -1 6
1
end_operator
begin_operator
debark car20 loc16
1
29 7
2
0 0 13 0
0 15 -1 7
1
end_operator
begin_operator
debark car20 loc17
1
29 8
2
0 0 13 0
0 15 -1 8
1
end_operator
begin_operator
debark car20 loc18
1
29 9
2
0 0 13 0
0 15 -1 9
1
end_operator
begin_operator
debark car20 loc19
1
29 10
2
0 0 13 0
0 15 -1 10
1
end_operator
begin_operator
debark car20 loc2
1
29 11
2
0 0 13 0
0 15 -1 11
1
end_operator
begin_operator
debark car20 loc20
1
29 12
2
0 0 13 0
0 15 -1 12
1
end_operator
begin_operator
debark car20 loc21
1
29 13
2
0 0 13 0
0 15 -1 13
1
end_operator
begin_operator
debark car20 loc22
1
29 14
2
0 0 13 0
0 15 -1 14
1
end_operator
begin_operator
debark car20 loc23
1
29 15
2
0 0 13 0
0 15 -1 15
1
end_operator
begin_operator
debark car20 loc24
1
29 16
2
0 0 13 0
0 15 -1 16
1
end_operator
begin_operator
debark car20 loc25
1
29 17
2
0 0 13 0
0 15 -1 17
1
end_operator
begin_operator
debark car20 loc26
1
29 18
2
0 0 13 0
0 15 -1 18
1
end_operator
begin_operator
debark car20 loc27
1
29 19
2
0 0 13 0
0 15 -1 19
1
end_operator
begin_operator
debark car20 loc28
1
29 20
2
0 0 13 0
0 15 -1 20
1
end_operator
begin_operator
debark car20 loc3
1
29 21
2
0 0 13 0
0 15 -1 21
1
end_operator
begin_operator
debark car20 loc4
1
29 22
2
0 0 13 0
0 15 -1 22
1
end_operator
begin_operator
debark car20 loc5
1
29 23
2
0 0 13 0
0 15 -1 23
1
end_operator
begin_operator
debark car20 loc6
1
29 24
2
0 0 13 0
0 15 -1 24
1
end_operator
begin_operator
debark car20 loc7
1
29 25
2
0 0 13 0
0 15 -1 25
1
end_operator
begin_operator
debark car20 loc8
1
29 26
2
0 0 13 0
0 15 -1 26
1
end_operator
begin_operator
debark car20 loc9
1
29 27
2
0 0 13 0
0 15 -1 27
1
end_operator
begin_operator
debark car21 loc1
1
29 0
2
0 0 14 0
0 19 -1 0
1
end_operator
begin_operator
debark car21 loc10
1
29 1
2
0 0 14 0
0 19 -1 1
1
end_operator
begin_operator
debark car21 loc11
1
29 2
2
0 0 14 0
0 19 -1 2
1
end_operator
begin_operator
debark car21 loc12
1
29 3
2
0 0 14 0
0 19 -1 3
1
end_operator
begin_operator
debark car21 loc13
1
29 4
2
0 0 14 0
0 19 -1 4
1
end_operator
begin_operator
debark car21 loc14
1
29 5
2
0 0 14 0
0 19 -1 5
1
end_operator
begin_operator
debark car21 loc15
1
29 6
2
0 0 14 0
0 19 -1 6
1
end_operator
begin_operator
debark car21 loc16
1
29 7
2
0 0 14 0
0 19 -1 7
1
end_operator
begin_operator
debark car21 loc17
1
29 8
2
0 0 14 0
0 19 -1 8
1
end_operator
begin_operator
debark car21 loc18
1
29 9
2
0 0 14 0
0 19 -1 9
1
end_operator
begin_operator
debark car21 loc19
1
29 10
2
0 0 14 0
0 19 -1 10
1
end_operator
begin_operator
debark car21 loc2
1
29 11
2
0 0 14 0
0 19 -1 11
1
end_operator
begin_operator
debark car21 loc20
1
29 12
2
0 0 14 0
0 19 -1 12
1
end_operator
begin_operator
debark car21 loc21
1
29 13
2
0 0 14 0
0 19 -1 13
1
end_operator
begin_operator
debark car21 loc22
1
29 14
2
0 0 14 0
0 19 -1 14
1
end_operator
begin_operator
debark car21 loc23
1
29 15
2
0 0 14 0
0 19 -1 15
1
end_operator
begin_operator
debark car21 loc24
1
29 16
2
0 0 14 0
0 19 -1 16
1
end_operator
begin_operator
debark car21 loc25
1
29 17
2
0 0 14 0
0 19 -1 17
1
end_operator
begin_operator
debark car21 loc26
1
29 18
2
0 0 14 0
0 19 -1 18
1
end_operator
begin_operator
debark car21 loc27
1
29 19
2
0 0 14 0
0 19 -1 19
1
end_operator
begin_operator
debark car21 loc28
1
29 20
2
0 0 14 0
0 19 -1 20
1
end_operator
begin_operator
debark car21 loc3
1
29 21
2
0 0 14 0
0 19 -1 21
1
end_operator
begin_operator
debark car21 loc4
1
29 22
2
0 0 14 0
0 19 -1 22
1
end_operator
begin_operator
debark car21 loc5
1
29 23
2
0 0 14 0
0 19 -1 23
1
end_operator
begin_operator
debark car21 loc6
1
29 24
2
0 0 14 0
0 19 -1 24
1
end_operator
begin_operator
debark car21 loc7
1
29 25
2
0 0 14 0
0 19 -1 25
1
end_operator
begin_operator
debark car21 loc8
1
29 26
2
0 0 14 0
0 19 -1 26
1
end_operator
begin_operator
debark car21 loc9
1
29 27
2
0 0 14 0
0 19 -1 27
1
end_operator
begin_operator
debark car22 loc1
1
29 0
2
0 0 15 0
0 23 -1 0
1
end_operator
begin_operator
debark car22 loc10
1
29 1
2
0 0 15 0
0 23 -1 1
1
end_operator
begin_operator
debark car22 loc11
1
29 2
2
0 0 15 0
0 23 -1 2
1
end_operator
begin_operator
debark car22 loc12
1
29 3
2
0 0 15 0
0 23 -1 3
1
end_operator
begin_operator
debark car22 loc13
1
29 4
2
0 0 15 0
0 23 -1 4
1
end_operator
begin_operator
debark car22 loc14
1
29 5
2
0 0 15 0
0 23 -1 5
1
end_operator
begin_operator
debark car22 loc15
1
29 6
2
0 0 15 0
0 23 -1 6
1
end_operator
begin_operator
debark car22 loc16
1
29 7
2
0 0 15 0
0 23 -1 7
1
end_operator
begin_operator
debark car22 loc17
1
29 8
2
0 0 15 0
0 23 -1 8
1
end_operator
begin_operator
debark car22 loc18
1
29 9
2
0 0 15 0
0 23 -1 9
1
end_operator
begin_operator
debark car22 loc19
1
29 10
2
0 0 15 0
0 23 -1 10
1
end_operator
begin_operator
debark car22 loc2
1
29 11
2
0 0 15 0
0 23 -1 11
1
end_operator
begin_operator
debark car22 loc20
1
29 12
2
0 0 15 0
0 23 -1 12
1
end_operator
begin_operator
debark car22 loc21
1
29 13
2
0 0 15 0
0 23 -1 13
1
end_operator
begin_operator
debark car22 loc22
1
29 14
2
0 0 15 0
0 23 -1 14
1
end_operator
begin_operator
debark car22 loc23
1
29 15
2
0 0 15 0
0 23 -1 15
1
end_operator
begin_operator
debark car22 loc24
1
29 16
2
0 0 15 0
0 23 -1 16
1
end_operator
begin_operator
debark car22 loc25
1
29 17
2
0 0 15 0
0 23 -1 17
1
end_operator
begin_operator
debark car22 loc26
1
29 18
2
0 0 15 0
0 23 -1 18
1
end_operator
begin_operator
debark car22 loc27
1
29 19
2
0 0 15 0
0 23 -1 19
1
end_operator
begin_operator
debark car22 loc28
1
29 20
2
0 0 15 0
0 23 -1 20
1
end_operator
begin_operator
debark car22 loc3
1
29 21
2
0 0 15 0
0 23 -1 21
1
end_operator
begin_operator
debark car22 loc4
1
29 22
2
0 0 15 0
0 23 -1 22
1
end_operator
begin_operator
debark car22 loc5
1
29 23
2
0 0 15 0
0 23 -1 23
1
end_operator
begin_operator
debark car22 loc6
1
29 24
2
0 0 15 0
0 23 -1 24
1
end_operator
begin_operator
debark car22 loc7
1
29 25
2
0 0 15 0
0 23 -1 25
1
end_operator
begin_operator
debark car22 loc8
1
29 26
2
0 0 15 0
0 23 -1 26
1
end_operator
begin_operator
debark car22 loc9
1
29 27
2
0 0 15 0
0 23 -1 27
1
end_operator
begin_operator
debark car23 loc1
1
29 0
2
0 0 16 0
0 27 -1 0
1
end_operator
begin_operator
debark car23 loc10
1
29 1
2
0 0 16 0
0 27 -1 1
1
end_operator
begin_operator
debark car23 loc11
1
29 2
2
0 0 16 0
0 27 -1 2
1
end_operator
begin_operator
debark car23 loc12
1
29 3
2
0 0 16 0
0 27 -1 3
1
end_operator
begin_operator
debark car23 loc13
1
29 4
2
0 0 16 0
0 27 -1 4
1
end_operator
begin_operator
debark car23 loc14
1
29 5
2
0 0 16 0
0 27 -1 5
1
end_operator
begin_operator
debark car23 loc15
1
29 6
2
0 0 16 0
0 27 -1 6
1
end_operator
begin_operator
debark car23 loc16
1
29 7
2
0 0 16 0
0 27 -1 7
1
end_operator
begin_operator
debark car23 loc17
1
29 8
2
0 0 16 0
0 27 -1 8
1
end_operator
begin_operator
debark car23 loc18
1
29 9
2
0 0 16 0
0 27 -1 9
1
end_operator
begin_operator
debark car23 loc19
1
29 10
2
0 0 16 0
0 27 -1 10
1
end_operator
begin_operator
debark car23 loc2
1
29 11
2
0 0 16 0
0 27 -1 11
1
end_operator
begin_operator
debark car23 loc20
1
29 12
2
0 0 16 0
0 27 -1 12
1
end_operator
begin_operator
debark car23 loc21
1
29 13
2
0 0 16 0
0 27 -1 13
1
end_operator
begin_operator
debark car23 loc22
1
29 14
2
0 0 16 0
0 27 -1 14
1
end_operator
begin_operator
debark car23 loc23
1
29 15
2
0 0 16 0
0 27 -1 15
1
end_operator
begin_operator
debark car23 loc24
1
29 16
2
0 0 16 0
0 27 -1 16
1
end_operator
begin_operator
debark car23 loc25
1
29 17
2
0 0 16 0
0 27 -1 17
1
end_operator
begin_operator
debark car23 loc26
1
29 18
2
0 0 16 0
0 27 -1 18
1
end_operator
begin_operator
debark car23 loc27
1
29 19
2
0 0 16 0
0 27 -1 19
1
end_operator
begin_operator
debark car23 loc28
1
29 20
2
0 0 16 0
0 27 -1 20
1
end_operator
begin_operator
debark car23 loc3
1
29 21
2
0 0 16 0
0 27 -1 21
1
end_operator
begin_operator
debark car23 loc4
1
29 22
2
0 0 16 0
0 27 -1 22
1
end_operator
begin_operator
debark car23 loc5
1
29 23
2
0 0 16 0
0 27 -1 23
1
end_operator
begin_operator
debark car23 loc6
1
29 24
2
0 0 16 0
0 27 -1 24
1
end_operator
begin_operator
debark car23 loc7
1
29 25
2
0 0 16 0
0 27 -1 25
1
end_operator
begin_operator
debark car23 loc8
1
29 26
2
0 0 16 0
0 27 -1 26
1
end_operator
begin_operator
debark car23 loc9
1
29 27
2
0 0 16 0
0 27 -1 27
1
end_operator
begin_operator
debark car24 loc1
1
29 0
2
0 0 17 0
0 31 -1 0
1
end_operator
begin_operator
debark car24 loc10
1
29 1
2
0 0 17 0
0 31 -1 1
1
end_operator
begin_operator
debark car24 loc11
1
29 2
2
0 0 17 0
0 31 -1 2
1
end_operator
begin_operator
debark car24 loc12
1
29 3
2
0 0 17 0
0 31 -1 3
1
end_operator
begin_operator
debark car24 loc13
1
29 4
2
0 0 17 0
0 31 -1 4
1
end_operator
begin_operator
debark car24 loc14
1
29 5
2
0 0 17 0
0 31 -1 5
1
end_operator
begin_operator
debark car24 loc15
1
29 6
2
0 0 17 0
0 31 -1 6
1
end_operator
begin_operator
debark car24 loc16
1
29 7
2
0 0 17 0
0 31 -1 7
1
end_operator
begin_operator
debark car24 loc17
1
29 8
2
0 0 17 0
0 31 -1 8
1
end_operator
begin_operator
debark car24 loc18
1
29 9
2
0 0 17 0
0 31 -1 9
1
end_operator
begin_operator
debark car24 loc19
1
29 10
2
0 0 17 0
0 31 -1 10
1
end_operator
begin_operator
debark car24 loc2
1
29 11
2
0 0 17 0
0 31 -1 11
1
end_operator
begin_operator
debark car24 loc20
1
29 12
2
0 0 17 0
0 31 -1 12
1
end_operator
begin_operator
debark car24 loc21
1
29 13
2
0 0 17 0
0 31 -1 13
1
end_operator
begin_operator
debark car24 loc22
1
29 14
2
0 0 17 0
0 31 -1 14
1
end_operator
begin_operator
debark car24 loc23
1
29 15
2
0 0 17 0
0 31 -1 15
1
end_operator
begin_operator
debark car24 loc24
1
29 16
2
0 0 17 0
0 31 -1 16
1
end_operator
begin_operator
debark car24 loc25
1
29 17
2
0 0 17 0
0 31 -1 17
1
end_operator
begin_operator
debark car24 loc26
1
29 18
2
0 0 17 0
0 31 -1 18
1
end_operator
begin_operator
debark car24 loc27
1
29 19
2
0 0 17 0
0 31 -1 19
1
end_operator
begin_operator
debark car24 loc28
1
29 20
2
0 0 17 0
0 31 -1 20
1
end_operator
begin_operator
debark car24 loc3
1
29 21
2
0 0 17 0
0 31 -1 21
1
end_operator
begin_operator
debark car24 loc4
1
29 22
2
0 0 17 0
0 31 -1 22
1
end_operator
begin_operator
debark car24 loc5
1
29 23
2
0 0 17 0
0 31 -1 23
1
end_operator
begin_operator
debark car24 loc6
1
29 24
2
0 0 17 0
0 31 -1 24
1
end_operator
begin_operator
debark car24 loc7
1
29 25
2
0 0 17 0
0 31 -1 25
1
end_operator
begin_operator
debark car24 loc8
1
29 26
2
0 0 17 0
0 31 -1 26
1
end_operator
begin_operator
debark car24 loc9
1
29 27
2
0 0 17 0
0 31 -1 27
1
end_operator
begin_operator
debark car25 loc1
1
29 0
2
0 0 18 0
0 34 -1 0
1
end_operator
begin_operator
debark car25 loc10
1
29 1
2
0 0 18 0
0 34 -1 1
1
end_operator
begin_operator
debark car25 loc11
1
29 2
2
0 0 18 0
0 34 -1 2
1
end_operator
begin_operator
debark car25 loc12
1
29 3
2
0 0 18 0
0 34 -1 3
1
end_operator
begin_operator
debark car25 loc13
1
29 4
2
0 0 18 0
0 34 -1 4
1
end_operator
begin_operator
debark car25 loc14
1
29 5
2
0 0 18 0
0 34 -1 5
1
end_operator
begin_operator
debark car25 loc15
1
29 6
2
0 0 18 0
0 34 -1 6
1
end_operator
begin_operator
debark car25 loc16
1
29 7
2
0 0 18 0
0 34 -1 7
1
end_operator
begin_operator
debark car25 loc17
1
29 8
2
0 0 18 0
0 34 -1 8
1
end_operator
begin_operator
debark car25 loc18
1
29 9
2
0 0 18 0
0 34 -1 9
1
end_operator
begin_operator
debark car25 loc19
1
29 10
2
0 0 18 0
0 34 -1 10
1
end_operator
begin_operator
debark car25 loc2
1
29 11
2
0 0 18 0
0 34 -1 11
1
end_operator
begin_operator
debark car25 loc20
1
29 12
2
0 0 18 0
0 34 -1 12
1
end_operator
begin_operator
debark car25 loc21
1
29 13
2
0 0 18 0
0 34 -1 13
1
end_operator
begin_operator
debark car25 loc22
1
29 14
2
0 0 18 0
0 34 -1 14
1
end_operator
begin_operator
debark car25 loc23
1
29 15
2
0 0 18 0
0 34 -1 15
1
end_operator
begin_operator
debark car25 loc24
1
29 16
2
0 0 18 0
0 34 -1 16
1
end_operator
begin_operator
debark car25 loc25
1
29 17
2
0 0 18 0
0 34 -1 17
1
end_operator
begin_operator
debark car25 loc26
1
29 18
2
0 0 18 0
0 34 -1 18
1
end_operator
begin_operator
debark car25 loc27
1
29 19
2
0 0 18 0
0 34 -1 19
1
end_operator
begin_operator
debark car25 loc28
1
29 20
2
0 0 18 0
0 34 -1 20
1
end_operator
begin_operator
debark car25 loc3
1
29 21
2
0 0 18 0
0 34 -1 21
1
end_operator
begin_operator
debark car25 loc4
1
29 22
2
0 0 18 0
0 34 -1 22
1
end_operator
begin_operator
debark car25 loc5
1
29 23
2
0 0 18 0
0 34 -1 23
1
end_operator
begin_operator
debark car25 loc6
1
29 24
2
0 0 18 0
0 34 -1 24
1
end_operator
begin_operator
debark car25 loc7
1
29 25
2
0 0 18 0
0 34 -1 25
1
end_operator
begin_operator
debark car25 loc8
1
29 26
2
0 0 18 0
0 34 -1 26
1
end_operator
begin_operator
debark car25 loc9
1
29 27
2
0 0 18 0
0 34 -1 27
1
end_operator
begin_operator
debark car26 loc1
1
29 0
2
0 0 19 0
0 2 -1 0
1
end_operator
begin_operator
debark car26 loc10
1
29 1
2
0 0 19 0
0 2 -1 1
1
end_operator
begin_operator
debark car26 loc11
1
29 2
2
0 0 19 0
0 2 -1 2
1
end_operator
begin_operator
debark car26 loc12
1
29 3
2
0 0 19 0
0 2 -1 3
1
end_operator
begin_operator
debark car26 loc13
1
29 4
2
0 0 19 0
0 2 -1 4
1
end_operator
begin_operator
debark car26 loc14
1
29 5
2
0 0 19 0
0 2 -1 5
1
end_operator
begin_operator
debark car26 loc15
1
29 6
2
0 0 19 0
0 2 -1 6
1
end_operator
begin_operator
debark car26 loc16
1
29 7
2
0 0 19 0
0 2 -1 7
1
end_operator
begin_operator
debark car26 loc17
1
29 8
2
0 0 19 0
0 2 -1 8
1
end_operator
begin_operator
debark car26 loc18
1
29 9
2
0 0 19 0
0 2 -1 9
1
end_operator
begin_operator
debark car26 loc19
1
29 10
2
0 0 19 0
0 2 -1 10
1
end_operator
begin_operator
debark car26 loc2
1
29 11
2
0 0 19 0
0 2 -1 11
1
end_operator
begin_operator
debark car26 loc20
1
29 12
2
0 0 19 0
0 2 -1 12
1
end_operator
begin_operator
debark car26 loc21
1
29 13
2
0 0 19 0
0 2 -1 13
1
end_operator
begin_operator
debark car26 loc22
1
29 14
2
0 0 19 0
0 2 -1 14
1
end_operator
begin_operator
debark car26 loc23
1
29 15
2
0 0 19 0
0 2 -1 15
1
end_operator
begin_operator
debark car26 loc24
1
29 16
2
0 0 19 0
0 2 -1 16
1
end_operator
begin_operator
debark car26 loc25
1
29 17
2
0 0 19 0
0 2 -1 17
1
end_operator
begin_operator
debark car26 loc26
1
29 18
2
0 0 19 0
0 2 -1 18
1
end_operator
begin_operator
debark car26 loc27
1
29 19
2
0 0 19 0
0 2 -1 19
1
end_operator
begin_operator
debark car26 loc28
1
29 20
2
0 0 19 0
0 2 -1 20
1
end_operator
begin_operator
debark car26 loc3
1
29 21
2
0 0 19 0
0 2 -1 21
1
end_operator
begin_operator
debark car26 loc4
1
29 22
2
0 0 19 0
0 2 -1 22
1
end_operator
begin_operator
debark car26 loc5
1
29 23
2
0 0 19 0
0 2 -1 23
1
end_operator
begin_operator
debark car26 loc6
1
29 24
2
0 0 19 0
0 2 -1 24
1
end_operator
begin_operator
debark car26 loc7
1
29 25
2
0 0 19 0
0 2 -1 25
1
end_operator
begin_operator
debark car26 loc8
1
29 26
2
0 0 19 0
0 2 -1 26
1
end_operator
begin_operator
debark car26 loc9
1
29 27
2
0 0 19 0
0 2 -1 27
1
end_operator
begin_operator
debark car27 loc1
1
29 0
2
0 0 20 0
0 6 -1 0
1
end_operator
begin_operator
debark car27 loc10
1
29 1
2
0 0 20 0
0 6 -1 1
1
end_operator
begin_operator
debark car27 loc11
1
29 2
2
0 0 20 0
0 6 -1 2
1
end_operator
begin_operator
debark car27 loc12
1
29 3
2
0 0 20 0
0 6 -1 3
1
end_operator
begin_operator
debark car27 loc13
1
29 4
2
0 0 20 0
0 6 -1 4
1
end_operator
begin_operator
debark car27 loc14
1
29 5
2
0 0 20 0
0 6 -1 5
1
end_operator
begin_operator
debark car27 loc15
1
29 6
2
0 0 20 0
0 6 -1 6
1
end_operator
begin_operator
debark car27 loc16
1
29 7
2
0 0 20 0
0 6 -1 7
1
end_operator
begin_operator
debark car27 loc17
1
29 8
2
0 0 20 0
0 6 -1 8
1
end_operator
begin_operator
debark car27 loc18
1
29 9
2
0 0 20 0
0 6 -1 9
1
end_operator
begin_operator
debark car27 loc19
1
29 10
2
0 0 20 0
0 6 -1 10
1
end_operator
begin_operator
debark car27 loc2
1
29 11
2
0 0 20 0
0 6 -1 11
1
end_operator
begin_operator
debark car27 loc20
1
29 12
2
0 0 20 0
0 6 -1 12
1
end_operator
begin_operator
debark car27 loc21
1
29 13
2
0 0 20 0
0 6 -1 13
1
end_operator
begin_operator
debark car27 loc22
1
29 14
2
0 0 20 0
0 6 -1 14
1
end_operator
begin_operator
debark car27 loc23
1
29 15
2
0 0 20 0
0 6 -1 15
1
end_operator
begin_operator
debark car27 loc24
1
29 16
2
0 0 20 0
0 6 -1 16
1
end_operator
begin_operator
debark car27 loc25
1
29 17
2
0 0 20 0
0 6 -1 17
1
end_operator
begin_operator
debark car27 loc26
1
29 18
2
0 0 20 0
0 6 -1 18
1
end_operator
begin_operator
debark car27 loc27
1
29 19
2
0 0 20 0
0 6 -1 19
1
end_operator
begin_operator
debark car27 loc28
1
29 20
2
0 0 20 0
0 6 -1 20
1
end_operator
begin_operator
debark car27 loc3
1
29 21
2
0 0 20 0
0 6 -1 21
1
end_operator
begin_operator
debark car27 loc4
1
29 22
2
0 0 20 0
0 6 -1 22
1
end_operator
begin_operator
debark car27 loc5
1
29 23
2
0 0 20 0
0 6 -1 23
1
end_operator
begin_operator
debark car27 loc6
1
29 24
2
0 0 20 0
0 6 -1 24
1
end_operator
begin_operator
debark car27 loc7
1
29 25
2
0 0 20 0
0 6 -1 25
1
end_operator
begin_operator
debark car27 loc8
1
29 26
2
0 0 20 0
0 6 -1 26
1
end_operator
begin_operator
debark car27 loc9
1
29 27
2
0 0 20 0
0 6 -1 27
1
end_operator
begin_operator
debark car28 loc1
1
29 0
2
0 0 21 0
0 10 -1 0
1
end_operator
begin_operator
debark car28 loc10
1
29 1
2
0 0 21 0
0 10 -1 1
1
end_operator
begin_operator
debark car28 loc11
1
29 2
2
0 0 21 0
0 10 -1 2
1
end_operator
begin_operator
debark car28 loc12
1
29 3
2
0 0 21 0
0 10 -1 3
1
end_operator
begin_operator
debark car28 loc13
1
29 4
2
0 0 21 0
0 10 -1 4
1
end_operator
begin_operator
debark car28 loc14
1
29 5
2
0 0 21 0
0 10 -1 5
1
end_operator
begin_operator
debark car28 loc15
1
29 6
2
0 0 21 0
0 10 -1 6
1
end_operator
begin_operator
debark car28 loc16
1
29 7
2
0 0 21 0
0 10 -1 7
1
end_operator
begin_operator
debark car28 loc17
1
29 8
2
0 0 21 0
0 10 -1 8
1
end_operator
begin_operator
debark car28 loc18
1
29 9
2
0 0 21 0
0 10 -1 9
1
end_operator
begin_operator
debark car28 loc19
1
29 10
2
0 0 21 0
0 10 -1 10
1
end_operator
begin_operator
debark car28 loc2
1
29 11
2
0 0 21 0
0 10 -1 11
1
end_operator
begin_operator
debark car28 loc20
1
29 12
2
0 0 21 0
0 10 -1 12
1
end_operator
begin_operator
debark car28 loc21
1
29 13
2
0 0 21 0
0 10 -1 13
1
end_operator
begin_operator
debark car28 loc22
1
29 14
2
0 0 21 0
0 10 -1 14
1
end_operator
begin_operator
debark car28 loc23
1
29 15
2
0 0 21 0
0 10 -1 15
1
end_operator
begin_operator
debark car28 loc24
1
29 16
2
0 0 21 0
0 10 -1 16
1
end_operator
begin_operator
debark car28 loc25
1
29 17
2
0 0 21 0
0 10 -1 17
1
end_operator
begin_operator
debark car28 loc26
1
29 18
2
0 0 21 0
0 10 -1 18
1
end_operator
begin_operator
debark car28 loc27
1
29 19
2
0 0 21 0
0 10 -1 19
1
end_operator
begin_operator
debark car28 loc28
1
29 20
2
0 0 21 0
0 10 -1 20
1
end_operator
begin_operator
debark car28 loc3
1
29 21
2
0 0 21 0
0 10 -1 21
1
end_operator
begin_operator
debark car28 loc4
1
29 22
2
0 0 21 0
0 10 -1 22
1
end_operator
begin_operator
debark car28 loc5
1
29 23
2
0 0 21 0
0 10 -1 23
1
end_operator
begin_operator
debark car28 loc6
1
29 24
2
0 0 21 0
0 10 -1 24
1
end_operator
begin_operator
debark car28 loc7
1
29 25
2
0 0 21 0
0 10 -1 25
1
end_operator
begin_operator
debark car28 loc8
1
29 26
2
0 0 21 0
0 10 -1 26
1
end_operator
begin_operator
debark car28 loc9
1
29 27
2
0 0 21 0
0 10 -1 27
1
end_operator
begin_operator
debark car29 loc1
1
29 0
2
0 0 22 0
0 14 -1 0
1
end_operator
begin_operator
debark car29 loc10
1
29 1
2
0 0 22 0
0 14 -1 1
1
end_operator
begin_operator
debark car29 loc11
1
29 2
2
0 0 22 0
0 14 -1 2
1
end_operator
begin_operator
debark car29 loc12
1
29 3
2
0 0 22 0
0 14 -1 3
1
end_operator
begin_operator
debark car29 loc13
1
29 4
2
0 0 22 0
0 14 -1 4
1
end_operator
begin_operator
debark car29 loc14
1
29 5
2
0 0 22 0
0 14 -1 5
1
end_operator
begin_operator
debark car29 loc15
1
29 6
2
0 0 22 0
0 14 -1 6
1
end_operator
begin_operator
debark car29 loc16
1
29 7
2
0 0 22 0
0 14 -1 7
1
end_operator
begin_operator
debark car29 loc17
1
29 8
2
0 0 22 0
0 14 -1 8
1
end_operator
begin_operator
debark car29 loc18
1
29 9
2
0 0 22 0
0 14 -1 9
1
end_operator
begin_operator
debark car29 loc19
1
29 10
2
0 0 22 0
0 14 -1 10
1
end_operator
begin_operator
debark car29 loc2
1
29 11
2
0 0 22 0
0 14 -1 11
1
end_operator
begin_operator
debark car29 loc20
1
29 12
2
0 0 22 0
0 14 -1 12
1
end_operator
begin_operator
debark car29 loc21
1
29 13
2
0 0 22 0
0 14 -1 13
1
end_operator
begin_operator
debark car29 loc22
1
29 14
2
0 0 22 0
0 14 -1 14
1
end_operator
begin_operator
debark car29 loc23
1
29 15
2
0 0 22 0
0 14 -1 15
1
end_operator
begin_operator
debark car29 loc24
1
29 16
2
0 0 22 0
0 14 -1 16
1
end_operator
begin_operator
debark car29 loc25
1
29 17
2
0 0 22 0
0 14 -1 17
1
end_operator
begin_operator
debark car29 loc26
1
29 18
2
0 0 22 0
0 14 -1 18
1
end_operator
begin_operator
debark car29 loc27
1
29 19
2
0 0 22 0
0 14 -1 19
1
end_operator
begin_operator
debark car29 loc28
1
29 20
2
0 0 22 0
0 14 -1 20
1
end_operator
begin_operator
debark car29 loc3
1
29 21
2
0 0 22 0
0 14 -1 21
1
end_operator
begin_operator
debark car29 loc4
1
29 22
2
0 0 22 0
0 14 -1 22
1
end_operator
begin_operator
debark car29 loc5
1
29 23
2
0 0 22 0
0 14 -1 23
1
end_operator
begin_operator
debark car29 loc6
1
29 24
2
0 0 22 0
0 14 -1 24
1
end_operator
begin_operator
debark car29 loc7
1
29 25
2
0 0 22 0
0 14 -1 25
1
end_operator
begin_operator
debark car29 loc8
1
29 26
2
0 0 22 0
0 14 -1 26
1
end_operator
begin_operator
debark car29 loc9
1
29 27
2
0 0 22 0
0 14 -1 27
1
end_operator
begin_operator
debark car3 loc1
1
29 0
2
0 0 23 0
0 18 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
29 1
2
0 0 23 0
0 18 -1 1
1
end_operator
begin_operator
debark car3 loc11
1
29 2
2
0 0 23 0
0 18 -1 2
1
end_operator
begin_operator
debark car3 loc12
1
29 3
2
0 0 23 0
0 18 -1 3
1
end_operator
begin_operator
debark car3 loc13
1
29 4
2
0 0 23 0
0 18 -1 4
1
end_operator
begin_operator
debark car3 loc14
1
29 5
2
0 0 23 0
0 18 -1 5
1
end_operator
begin_operator
debark car3 loc15
1
29 6
2
0 0 23 0
0 18 -1 6
1
end_operator
begin_operator
debark car3 loc16
1
29 7
2
0 0 23 0
0 18 -1 7
1
end_operator
begin_operator
debark car3 loc17
1
29 8
2
0 0 23 0
0 18 -1 8
1
end_operator
begin_operator
debark car3 loc18
1
29 9
2
0 0 23 0
0 18 -1 9
1
end_operator
begin_operator
debark car3 loc19
1
29 10
2
0 0 23 0
0 18 -1 10
1
end_operator
begin_operator
debark car3 loc2
1
29 11
2
0 0 23 0
0 18 -1 11
1
end_operator
begin_operator
debark car3 loc20
1
29 12
2
0 0 23 0
0 18 -1 12
1
end_operator
begin_operator
debark car3 loc21
1
29 13
2
0 0 23 0
0 18 -1 13
1
end_operator
begin_operator
debark car3 loc22
1
29 14
2
0 0 23 0
0 18 -1 14
1
end_operator
begin_operator
debark car3 loc23
1
29 15
2
0 0 23 0
0 18 -1 15
1
end_operator
begin_operator
debark car3 loc24
1
29 16
2
0 0 23 0
0 18 -1 16
1
end_operator
begin_operator
debark car3 loc25
1
29 17
2
0 0 23 0
0 18 -1 17
1
end_operator
begin_operator
debark car3 loc26
1
29 18
2
0 0 23 0
0 18 -1 18
1
end_operator
begin_operator
debark car3 loc27
1
29 19
2
0 0 23 0
0 18 -1 19
1
end_operator
begin_operator
debark car3 loc28
1
29 20
2
0 0 23 0
0 18 -1 20
1
end_operator
begin_operator
debark car3 loc3
1
29 21
2
0 0 23 0
0 18 -1 21
1
end_operator
begin_operator
debark car3 loc4
1
29 22
2
0 0 23 0
0 18 -1 22
1
end_operator
begin_operator
debark car3 loc5
1
29 23
2
0 0 23 0
0 18 -1 23
1
end_operator
begin_operator
debark car3 loc6
1
29 24
2
0 0 23 0
0 18 -1 24
1
end_operator
begin_operator
debark car3 loc7
1
29 25
2
0 0 23 0
0 18 -1 25
1
end_operator
begin_operator
debark car3 loc8
1
29 26
2
0 0 23 0
0 18 -1 26
1
end_operator
begin_operator
debark car3 loc9
1
29 27
2
0 0 23 0
0 18 -1 27
1
end_operator
begin_operator
debark car30 loc1
1
29 0
2
0 0 24 0
0 22 -1 0
1
end_operator
begin_operator
debark car30 loc10
1
29 1
2
0 0 24 0
0 22 -1 1
1
end_operator
begin_operator
debark car30 loc11
1
29 2
2
0 0 24 0
0 22 -1 2
1
end_operator
begin_operator
debark car30 loc12
1
29 3
2
0 0 24 0
0 22 -1 3
1
end_operator
begin_operator
debark car30 loc13
1
29 4
2
0 0 24 0
0 22 -1 4
1
end_operator
begin_operator
debark car30 loc14
1
29 5
2
0 0 24 0
0 22 -1 5
1
end_operator
begin_operator
debark car30 loc15
1
29 6
2
0 0 24 0
0 22 -1 6
1
end_operator
begin_operator
debark car30 loc16
1
29 7
2
0 0 24 0
0 22 -1 7
1
end_operator
begin_operator
debark car30 loc17
1
29 8
2
0 0 24 0
0 22 -1 8
1
end_operator
begin_operator
debark car30 loc18
1
29 9
2
0 0 24 0
0 22 -1 9
1
end_operator
begin_operator
debark car30 loc19
1
29 10
2
0 0 24 0
0 22 -1 10
1
end_operator
begin_operator
debark car30 loc2
1
29 11
2
0 0 24 0
0 22 -1 11
1
end_operator
begin_operator
debark car30 loc20
1
29 12
2
0 0 24 0
0 22 -1 12
1
end_operator
begin_operator
debark car30 loc21
1
29 13
2
0 0 24 0
0 22 -1 13
1
end_operator
begin_operator
debark car30 loc22
1
29 14
2
0 0 24 0
0 22 -1 14
1
end_operator
begin_operator
debark car30 loc23
1
29 15
2
0 0 24 0
0 22 -1 15
1
end_operator
begin_operator
debark car30 loc24
1
29 16
2
0 0 24 0
0 22 -1 16
1
end_operator
begin_operator
debark car30 loc25
1
29 17
2
0 0 24 0
0 22 -1 17
1
end_operator
begin_operator
debark car30 loc26
1
29 18
2
0 0 24 0
0 22 -1 18
1
end_operator
begin_operator
debark car30 loc27
1
29 19
2
0 0 24 0
0 22 -1 19
1
end_operator
begin_operator
debark car30 loc28
1
29 20
2
0 0 24 0
0 22 -1 20
1
end_operator
begin_operator
debark car30 loc3
1
29 21
2
0 0 24 0
0 22 -1 21
1
end_operator
begin_operator
debark car30 loc4
1
29 22
2
0 0 24 0
0 22 -1 22
1
end_operator
begin_operator
debark car30 loc5
1
29 23
2
0 0 24 0
0 22 -1 23
1
end_operator
begin_operator
debark car30 loc6
1
29 24
2
0 0 24 0
0 22 -1 24
1
end_operator
begin_operator
debark car30 loc7
1
29 25
2
0 0 24 0
0 22 -1 25
1
end_operator
begin_operator
debark car30 loc8
1
29 26
2
0 0 24 0
0 22 -1 26
1
end_operator
begin_operator
debark car30 loc9
1
29 27
2
0 0 24 0
0 22 -1 27
1
end_operator
begin_operator
debark car31 loc1
1
29 0
2
0 0 25 0
0 26 -1 0
1
end_operator
begin_operator
debark car31 loc10
1
29 1
2
0 0 25 0
0 26 -1 1
1
end_operator
begin_operator
debark car31 loc11
1
29 2
2
0 0 25 0
0 26 -1 2
1
end_operator
begin_operator
debark car31 loc12
1
29 3
2
0 0 25 0
0 26 -1 3
1
end_operator
begin_operator
debark car31 loc13
1
29 4
2
0 0 25 0
0 26 -1 4
1
end_operator
begin_operator
debark car31 loc14
1
29 5
2
0 0 25 0
0 26 -1 5
1
end_operator
begin_operator
debark car31 loc15
1
29 6
2
0 0 25 0
0 26 -1 6
1
end_operator
begin_operator
debark car31 loc16
1
29 7
2
0 0 25 0
0 26 -1 7
1
end_operator
begin_operator
debark car31 loc17
1
29 8
2
0 0 25 0
0 26 -1 8
1
end_operator
begin_operator
debark car31 loc18
1
29 9
2
0 0 25 0
0 26 -1 9
1
end_operator
begin_operator
debark car31 loc19
1
29 10
2
0 0 25 0
0 26 -1 10
1
end_operator
begin_operator
debark car31 loc2
1
29 11
2
0 0 25 0
0 26 -1 11
1
end_operator
begin_operator
debark car31 loc20
1
29 12
2
0 0 25 0
0 26 -1 12
1
end_operator
begin_operator
debark car31 loc21
1
29 13
2
0 0 25 0
0 26 -1 13
1
end_operator
begin_operator
debark car31 loc22
1
29 14
2
0 0 25 0
0 26 -1 14
1
end_operator
begin_operator
debark car31 loc23
1
29 15
2
0 0 25 0
0 26 -1 15
1
end_operator
begin_operator
debark car31 loc24
1
29 16
2
0 0 25 0
0 26 -1 16
1
end_operator
begin_operator
debark car31 loc25
1
29 17
2
0 0 25 0
0 26 -1 17
1
end_operator
begin_operator
debark car31 loc26
1
29 18
2
0 0 25 0
0 26 -1 18
1
end_operator
begin_operator
debark car31 loc27
1
29 19
2
0 0 25 0
0 26 -1 19
1
end_operator
begin_operator
debark car31 loc28
1
29 20
2
0 0 25 0
0 26 -1 20
1
end_operator
begin_operator
debark car31 loc3
1
29 21
2
0 0 25 0
0 26 -1 21
1
end_operator
begin_operator
debark car31 loc4
1
29 22
2
0 0 25 0
0 26 -1 22
1
end_operator
begin_operator
debark car31 loc5
1
29 23
2
0 0 25 0
0 26 -1 23
1
end_operator
begin_operator
debark car31 loc6
1
29 24
2
0 0 25 0
0 26 -1 24
1
end_operator
begin_operator
debark car31 loc7
1
29 25
2
0 0 25 0
0 26 -1 25
1
end_operator
begin_operator
debark car31 loc8
1
29 26
2
0 0 25 0
0 26 -1 26
1
end_operator
begin_operator
debark car31 loc9
1
29 27
2
0 0 25 0
0 26 -1 27
1
end_operator
begin_operator
debark car32 loc1
1
29 0
2
0 0 26 0
0 30 -1 0
1
end_operator
begin_operator
debark car32 loc10
1
29 1
2
0 0 26 0
0 30 -1 1
1
end_operator
begin_operator
debark car32 loc11
1
29 2
2
0 0 26 0
0 30 -1 2
1
end_operator
begin_operator
debark car32 loc12
1
29 3
2
0 0 26 0
0 30 -1 3
1
end_operator
begin_operator
debark car32 loc13
1
29 4
2
0 0 26 0
0 30 -1 4
1
end_operator
begin_operator
debark car32 loc14
1
29 5
2
0 0 26 0
0 30 -1 5
1
end_operator
begin_operator
debark car32 loc15
1
29 6
2
0 0 26 0
0 30 -1 6
1
end_operator
begin_operator
debark car32 loc16
1
29 7
2
0 0 26 0
0 30 -1 7
1
end_operator
begin_operator
debark car32 loc17
1
29 8
2
0 0 26 0
0 30 -1 8
1
end_operator
begin_operator
debark car32 loc18
1
29 9
2
0 0 26 0
0 30 -1 9
1
end_operator
begin_operator
debark car32 loc19
1
29 10
2
0 0 26 0
0 30 -1 10
1
end_operator
begin_operator
debark car32 loc2
1
29 11
2
0 0 26 0
0 30 -1 11
1
end_operator
begin_operator
debark car32 loc20
1
29 12
2
0 0 26 0
0 30 -1 12
1
end_operator
begin_operator
debark car32 loc21
1
29 13
2
0 0 26 0
0 30 -1 13
1
end_operator
begin_operator
debark car32 loc22
1
29 14
2
0 0 26 0
0 30 -1 14
1
end_operator
begin_operator
debark car32 loc23
1
29 15
2
0 0 26 0
0 30 -1 15
1
end_operator
begin_operator
debark car32 loc24
1
29 16
2
0 0 26 0
0 30 -1 16
1
end_operator
begin_operator
debark car32 loc25
1
29 17
2
0 0 26 0
0 30 -1 17
1
end_operator
begin_operator
debark car32 loc26
1
29 18
2
0 0 26 0
0 30 -1 18
1
end_operator
begin_operator
debark car32 loc27
1
29 19
2
0 0 26 0
0 30 -1 19
1
end_operator
begin_operator
debark car32 loc28
1
29 20
2
0 0 26 0
0 30 -1 20
1
end_operator
begin_operator
debark car32 loc3
1
29 21
2
0 0 26 0
0 30 -1 21
1
end_operator
begin_operator
debark car32 loc4
1
29 22
2
0 0 26 0
0 30 -1 22
1
end_operator
begin_operator
debark car32 loc5
1
29 23
2
0 0 26 0
0 30 -1 23
1
end_operator
begin_operator
debark car32 loc6
1
29 24
2
0 0 26 0
0 30 -1 24
1
end_operator
begin_operator
debark car32 loc7
1
29 25
2
0 0 26 0
0 30 -1 25
1
end_operator
begin_operator
debark car32 loc8
1
29 26
2
0 0 26 0
0 30 -1 26
1
end_operator
begin_operator
debark car32 loc9
1
29 27
2
0 0 26 0
0 30 -1 27
1
end_operator
begin_operator
debark car33 loc1
1
29 0
2
0 0 27 0
0 33 -1 0
1
end_operator
begin_operator
debark car33 loc10
1
29 1
2
0 0 27 0
0 33 -1 1
1
end_operator
begin_operator
debark car33 loc11
1
29 2
2
0 0 27 0
0 33 -1 2
1
end_operator
begin_operator
debark car33 loc12
1
29 3
2
0 0 27 0
0 33 -1 3
1
end_operator
begin_operator
debark car33 loc13
1
29 4
2
0 0 27 0
0 33 -1 4
1
end_operator
begin_operator
debark car33 loc14
1
29 5
2
0 0 27 0
0 33 -1 5
1
end_operator
begin_operator
debark car33 loc15
1
29 6
2
0 0 27 0
0 33 -1 6
1
end_operator
begin_operator
debark car33 loc16
1
29 7
2
0 0 27 0
0 33 -1 7
1
end_operator
begin_operator
debark car33 loc17
1
29 8
2
0 0 27 0
0 33 -1 8
1
end_operator
begin_operator
debark car33 loc18
1
29 9
2
0 0 27 0
0 33 -1 9
1
end_operator
begin_operator
debark car33 loc19
1
29 10
2
0 0 27 0
0 33 -1 10
1
end_operator
begin_operator
debark car33 loc2
1
29 11
2
0 0 27 0
0 33 -1 11
1
end_operator
begin_operator
debark car33 loc20
1
29 12
2
0 0 27 0
0 33 -1 12
1
end_operator
begin_operator
debark car33 loc21
1
29 13
2
0 0 27 0
0 33 -1 13
1
end_operator
begin_operator
debark car33 loc22
1
29 14
2
0 0 27 0
0 33 -1 14
1
end_operator
begin_operator
debark car33 loc23
1
29 15
2
0 0 27 0
0 33 -1 15
1
end_operator
begin_operator
debark car33 loc24
1
29 16
2
0 0 27 0
0 33 -1 16
1
end_operator
begin_operator
debark car33 loc25
1
29 17
2
0 0 27 0
0 33 -1 17
1
end_operator
begin_operator
debark car33 loc26
1
29 18
2
0 0 27 0
0 33 -1 18
1
end_operator
begin_operator
debark car33 loc27
1
29 19
2
0 0 27 0
0 33 -1 19
1
end_operator
begin_operator
debark car33 loc28
1
29 20
2
0 0 27 0
0 33 -1 20
1
end_operator
begin_operator
debark car33 loc3
1
29 21
2
0 0 27 0
0 33 -1 21
1
end_operator
begin_operator
debark car33 loc4
1
29 22
2
0 0 27 0
0 33 -1 22
1
end_operator
begin_operator
debark car33 loc5
1
29 23
2
0 0 27 0
0 33 -1 23
1
end_operator
begin_operator
debark car33 loc6
1
29 24
2
0 0 27 0
0 33 -1 24
1
end_operator
begin_operator
debark car33 loc7
1
29 25
2
0 0 27 0
0 33 -1 25
1
end_operator
begin_operator
debark car33 loc8
1
29 26
2
0 0 27 0
0 33 -1 26
1
end_operator
begin_operator
debark car33 loc9
1
29 27
2
0 0 27 0
0 33 -1 27
1
end_operator
begin_operator
debark car34 loc1
1
29 0
2
0 0 28 0
0 1 -1 0
1
end_operator
begin_operator
debark car34 loc10
1
29 1
2
0 0 28 0
0 1 -1 1
1
end_operator
begin_operator
debark car34 loc11
1
29 2
2
0 0 28 0
0 1 -1 2
1
end_operator
begin_operator
debark car34 loc12
1
29 3
2
0 0 28 0
0 1 -1 3
1
end_operator
begin_operator
debark car34 loc13
1
29 4
2
0 0 28 0
0 1 -1 4
1
end_operator
begin_operator
debark car34 loc14
1
29 5
2
0 0 28 0
0 1 -1 5
1
end_operator
begin_operator
debark car34 loc15
1
29 6
2
0 0 28 0
0 1 -1 6
1
end_operator
begin_operator
debark car34 loc16
1
29 7
2
0 0 28 0
0 1 -1 7
1
end_operator
begin_operator
debark car34 loc17
1
29 8
2
0 0 28 0
0 1 -1 8
1
end_operator
begin_operator
debark car34 loc18
1
29 9
2
0 0 28 0
0 1 -1 9
1
end_operator
begin_operator
debark car34 loc19
1
29 10
2
0 0 28 0
0 1 -1 10
1
end_operator
begin_operator
debark car34 loc2
1
29 11
2
0 0 28 0
0 1 -1 11
1
end_operator
begin_operator
debark car34 loc20
1
29 12
2
0 0 28 0
0 1 -1 12
1
end_operator
begin_operator
debark car34 loc21
1
29 13
2
0 0 28 0
0 1 -1 13
1
end_operator
begin_operator
debark car34 loc22
1
29 14
2
0 0 28 0
0 1 -1 14
1
end_operator
begin_operator
debark car34 loc23
1
29 15
2
0 0 28 0
0 1 -1 15
1
end_operator
begin_operator
debark car34 loc24
1
29 16
2
0 0 28 0
0 1 -1 16
1
end_operator
begin_operator
debark car34 loc25
1
29 17
2
0 0 28 0
0 1 -1 17
1
end_operator
begin_operator
debark car34 loc26
1
29 18
2
0 0 28 0
0 1 -1 18
1
end_operator
begin_operator
debark car34 loc27
1
29 19
2
0 0 28 0
0 1 -1 19
1
end_operator
begin_operator
debark car34 loc28
1
29 20
2
0 0 28 0
0 1 -1 20
1
end_operator
begin_operator
debark car34 loc3
1
29 21
2
0 0 28 0
0 1 -1 21
1
end_operator
begin_operator
debark car34 loc4
1
29 22
2
0 0 28 0
0 1 -1 22
1
end_operator
begin_operator
debark car34 loc5
1
29 23
2
0 0 28 0
0 1 -1 23
1
end_operator
begin_operator
debark car34 loc6
1
29 24
2
0 0 28 0
0 1 -1 24
1
end_operator
begin_operator
debark car34 loc7
1
29 25
2
0 0 28 0
0 1 -1 25
1
end_operator
begin_operator
debark car34 loc8
1
29 26
2
0 0 28 0
0 1 -1 26
1
end_operator
begin_operator
debark car34 loc9
1
29 27
2
0 0 28 0
0 1 -1 27
1
end_operator
begin_operator
debark car4 loc1
1
29 0
2
0 0 29 0
0 5 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
29 1
2
0 0 29 0
0 5 -1 1
1
end_operator
begin_operator
debark car4 loc11
1
29 2
2
0 0 29 0
0 5 -1 2
1
end_operator
begin_operator
debark car4 loc12
1
29 3
2
0 0 29 0
0 5 -1 3
1
end_operator
begin_operator
debark car4 loc13
1
29 4
2
0 0 29 0
0 5 -1 4
1
end_operator
begin_operator
debark car4 loc14
1
29 5
2
0 0 29 0
0 5 -1 5
1
end_operator
begin_operator
debark car4 loc15
1
29 6
2
0 0 29 0
0 5 -1 6
1
end_operator
begin_operator
debark car4 loc16
1
29 7
2
0 0 29 0
0 5 -1 7
1
end_operator
begin_operator
debark car4 loc17
1
29 8
2
0 0 29 0
0 5 -1 8
1
end_operator
begin_operator
debark car4 loc18
1
29 9
2
0 0 29 0
0 5 -1 9
1
end_operator
begin_operator
debark car4 loc19
1
29 10
2
0 0 29 0
0 5 -1 10
1
end_operator
begin_operator
debark car4 loc2
1
29 11
2
0 0 29 0
0 5 -1 11
1
end_operator
begin_operator
debark car4 loc20
1
29 12
2
0 0 29 0
0 5 -1 12
1
end_operator
begin_operator
debark car4 loc21
1
29 13
2
0 0 29 0
0 5 -1 13
1
end_operator
begin_operator
debark car4 loc22
1
29 14
2
0 0 29 0
0 5 -1 14
1
end_operator
begin_operator
debark car4 loc23
1
29 15
2
0 0 29 0
0 5 -1 15
1
end_operator
begin_operator
debark car4 loc24
1
29 16
2
0 0 29 0
0 5 -1 16
1
end_operator
begin_operator
debark car4 loc25
1
29 17
2
0 0 29 0
0 5 -1 17
1
end_operator
begin_operator
debark car4 loc26
1
29 18
2
0 0 29 0
0 5 -1 18
1
end_operator
begin_operator
debark car4 loc27
1
29 19
2
0 0 29 0
0 5 -1 19
1
end_operator
begin_operator
debark car4 loc28
1
29 20
2
0 0 29 0
0 5 -1 20
1
end_operator
begin_operator
debark car4 loc3
1
29 21
2
0 0 29 0
0 5 -1 21
1
end_operator
begin_operator
debark car4 loc4
1
29 22
2
0 0 29 0
0 5 -1 22
1
end_operator
begin_operator
debark car4 loc5
1
29 23
2
0 0 29 0
0 5 -1 23
1
end_operator
begin_operator
debark car4 loc6
1
29 24
2
0 0 29 0
0 5 -1 24
1
end_operator
begin_operator
debark car4 loc7
1
29 25
2
0 0 29 0
0 5 -1 25
1
end_operator
begin_operator
debark car4 loc8
1
29 26
2
0 0 29 0
0 5 -1 26
1
end_operator
begin_operator
debark car4 loc9
1
29 27
2
0 0 29 0
0 5 -1 27
1
end_operator
begin_operator
debark car5 loc1
1
29 0
2
0 0 30 0
0 9 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
29 1
2
0 0 30 0
0 9 -1 1
1
end_operator
begin_operator
debark car5 loc11
1
29 2
2
0 0 30 0
0 9 -1 2
1
end_operator
begin_operator
debark car5 loc12
1
29 3
2
0 0 30 0
0 9 -1 3
1
end_operator
begin_operator
debark car5 loc13
1
29 4
2
0 0 30 0
0 9 -1 4
1
end_operator
begin_operator
debark car5 loc14
1
29 5
2
0 0 30 0
0 9 -1 5
1
end_operator
begin_operator
debark car5 loc15
1
29 6
2
0 0 30 0
0 9 -1 6
1
end_operator
begin_operator
debark car5 loc16
1
29 7
2
0 0 30 0
0 9 -1 7
1
end_operator
begin_operator
debark car5 loc17
1
29 8
2
0 0 30 0
0 9 -1 8
1
end_operator
begin_operator
debark car5 loc18
1
29 9
2
0 0 30 0
0 9 -1 9
1
end_operator
begin_operator
debark car5 loc19
1
29 10
2
0 0 30 0
0 9 -1 10
1
end_operator
begin_operator
debark car5 loc2
1
29 11
2
0 0 30 0
0 9 -1 11
1
end_operator
begin_operator
debark car5 loc20
1
29 12
2
0 0 30 0
0 9 -1 12
1
end_operator
begin_operator
debark car5 loc21
1
29 13
2
0 0 30 0
0 9 -1 13
1
end_operator
begin_operator
debark car5 loc22
1
29 14
2
0 0 30 0
0 9 -1 14
1
end_operator
begin_operator
debark car5 loc23
1
29 15
2
0 0 30 0
0 9 -1 15
1
end_operator
begin_operator
debark car5 loc24
1
29 16
2
0 0 30 0
0 9 -1 16
1
end_operator
begin_operator
debark car5 loc25
1
29 17
2
0 0 30 0
0 9 -1 17
1
end_operator
begin_operator
debark car5 loc26
1
29 18
2
0 0 30 0
0 9 -1 18
1
end_operator
begin_operator
debark car5 loc27
1
29 19
2
0 0 30 0
0 9 -1 19
1
end_operator
begin_operator
debark car5 loc28
1
29 20
2
0 0 30 0
0 9 -1 20
1
end_operator
begin_operator
debark car5 loc3
1
29 21
2
0 0 30 0
0 9 -1 21
1
end_operator
begin_operator
debark car5 loc4
1
29 22
2
0 0 30 0
0 9 -1 22
1
end_operator
begin_operator
debark car5 loc5
1
29 23
2
0 0 30 0
0 9 -1 23
1
end_operator
begin_operator
debark car5 loc6
1
29 24
2
0 0 30 0
0 9 -1 24
1
end_operator
begin_operator
debark car5 loc7
1
29 25
2
0 0 30 0
0 9 -1 25
1
end_operator
begin_operator
debark car5 loc8
1
29 26
2
0 0 30 0
0 9 -1 26
1
end_operator
begin_operator
debark car5 loc9
1
29 27
2
0 0 30 0
0 9 -1 27
1
end_operator
begin_operator
debark car6 loc1
1
29 0
2
0 0 31 0
0 13 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
29 1
2
0 0 31 0
0 13 -1 1
1
end_operator
begin_operator
debark car6 loc11
1
29 2
2
0 0 31 0
0 13 -1 2
1
end_operator
begin_operator
debark car6 loc12
1
29 3
2
0 0 31 0
0 13 -1 3
1
end_operator
begin_operator
debark car6 loc13
1
29 4
2
0 0 31 0
0 13 -1 4
1
end_operator
begin_operator
debark car6 loc14
1
29 5
2
0 0 31 0
0 13 -1 5
1
end_operator
begin_operator
debark car6 loc15
1
29 6
2
0 0 31 0
0 13 -1 6
1
end_operator
begin_operator
debark car6 loc16
1
29 7
2
0 0 31 0
0 13 -1 7
1
end_operator
begin_operator
debark car6 loc17
1
29 8
2
0 0 31 0
0 13 -1 8
1
end_operator
begin_operator
debark car6 loc18
1
29 9
2
0 0 31 0
0 13 -1 9
1
end_operator
begin_operator
debark car6 loc19
1
29 10
2
0 0 31 0
0 13 -1 10
1
end_operator
begin_operator
debark car6 loc2
1
29 11
2
0 0 31 0
0 13 -1 11
1
end_operator
begin_operator
debark car6 loc20
1
29 12
2
0 0 31 0
0 13 -1 12
1
end_operator
begin_operator
debark car6 loc21
1
29 13
2
0 0 31 0
0 13 -1 13
1
end_operator
begin_operator
debark car6 loc22
1
29 14
2
0 0 31 0
0 13 -1 14
1
end_operator
begin_operator
debark car6 loc23
1
29 15
2
0 0 31 0
0 13 -1 15
1
end_operator
begin_operator
debark car6 loc24
1
29 16
2
0 0 31 0
0 13 -1 16
1
end_operator
begin_operator
debark car6 loc25
1
29 17
2
0 0 31 0
0 13 -1 17
1
end_operator
begin_operator
debark car6 loc26
1
29 18
2
0 0 31 0
0 13 -1 18
1
end_operator
begin_operator
debark car6 loc27
1
29 19
2
0 0 31 0
0 13 -1 19
1
end_operator
begin_operator
debark car6 loc28
1
29 20
2
0 0 31 0
0 13 -1 20
1
end_operator
begin_operator
debark car6 loc3
1
29 21
2
0 0 31 0
0 13 -1 21
1
end_operator
begin_operator
debark car6 loc4
1
29 22
2
0 0 31 0
0 13 -1 22
1
end_operator
begin_operator
debark car6 loc5
1
29 23
2
0 0 31 0
0 13 -1 23
1
end_operator
begin_operator
debark car6 loc6
1
29 24
2
0 0 31 0
0 13 -1 24
1
end_operator
begin_operator
debark car6 loc7
1
29 25
2
0 0 31 0
0 13 -1 25
1
end_operator
begin_operator
debark car6 loc8
1
29 26
2
0 0 31 0
0 13 -1 26
1
end_operator
begin_operator
debark car6 loc9
1
29 27
2
0 0 31 0
0 13 -1 27
1
end_operator
begin_operator
debark car7 loc1
1
29 0
2
0 0 32 0
0 17 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
29 1
2
0 0 32 0
0 17 -1 1
1
end_operator
begin_operator
debark car7 loc11
1
29 2
2
0 0 32 0
0 17 -1 2
1
end_operator
begin_operator
debark car7 loc12
1
29 3
2
0 0 32 0
0 17 -1 3
1
end_operator
begin_operator
debark car7 loc13
1
29 4
2
0 0 32 0
0 17 -1 4
1
end_operator
begin_operator
debark car7 loc14
1
29 5
2
0 0 32 0
0 17 -1 5
1
end_operator
begin_operator
debark car7 loc15
1
29 6
2
0 0 32 0
0 17 -1 6
1
end_operator
begin_operator
debark car7 loc16
1
29 7
2
0 0 32 0
0 17 -1 7
1
end_operator
begin_operator
debark car7 loc17
1
29 8
2
0 0 32 0
0 17 -1 8
1
end_operator
begin_operator
debark car7 loc18
1
29 9
2
0 0 32 0
0 17 -1 9
1
end_operator
begin_operator
debark car7 loc19
1
29 10
2
0 0 32 0
0 17 -1 10
1
end_operator
begin_operator
debark car7 loc2
1
29 11
2
0 0 32 0
0 17 -1 11
1
end_operator
begin_operator
debark car7 loc20
1
29 12
2
0 0 32 0
0 17 -1 12
1
end_operator
begin_operator
debark car7 loc21
1
29 13
2
0 0 32 0
0 17 -1 13
1
end_operator
begin_operator
debark car7 loc22
1
29 14
2
0 0 32 0
0 17 -1 14
1
end_operator
begin_operator
debark car7 loc23
1
29 15
2
0 0 32 0
0 17 -1 15
1
end_operator
begin_operator
debark car7 loc24
1
29 16
2
0 0 32 0
0 17 -1 16
1
end_operator
begin_operator
debark car7 loc25
1
29 17
2
0 0 32 0
0 17 -1 17
1
end_operator
begin_operator
debark car7 loc26
1
29 18
2
0 0 32 0
0 17 -1 18
1
end_operator
begin_operator
debark car7 loc27
1
29 19
2
0 0 32 0
0 17 -1 19
1
end_operator
begin_operator
debark car7 loc28
1
29 20
2
0 0 32 0
0 17 -1 20
1
end_operator
begin_operator
debark car7 loc3
1
29 21
2
0 0 32 0
0 17 -1 21
1
end_operator
begin_operator
debark car7 loc4
1
29 22
2
0 0 32 0
0 17 -1 22
1
end_operator
begin_operator
debark car7 loc5
1
29 23
2
0 0 32 0
0 17 -1 23
1
end_operator
begin_operator
debark car7 loc6
1
29 24
2
0 0 32 0
0 17 -1 24
1
end_operator
begin_operator
debark car7 loc7
1
29 25
2
0 0 32 0
0 17 -1 25
1
end_operator
begin_operator
debark car7 loc8
1
29 26
2
0 0 32 0
0 17 -1 26
1
end_operator
begin_operator
debark car7 loc9
1
29 27
2
0 0 32 0
0 17 -1 27
1
end_operator
begin_operator
debark car8 loc1
1
29 0
2
0 0 33 0
0 21 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
29 1
2
0 0 33 0
0 21 -1 1
1
end_operator
begin_operator
debark car8 loc11
1
29 2
2
0 0 33 0
0 21 -1 2
1
end_operator
begin_operator
debark car8 loc12
1
29 3
2
0 0 33 0
0 21 -1 3
1
end_operator
begin_operator
debark car8 loc13
1
29 4
2
0 0 33 0
0 21 -1 4
1
end_operator
begin_operator
debark car8 loc14
1
29 5
2
0 0 33 0
0 21 -1 5
1
end_operator
begin_operator
debark car8 loc15
1
29 6
2
0 0 33 0
0 21 -1 6
1
end_operator
begin_operator
debark car8 loc16
1
29 7
2
0 0 33 0
0 21 -1 7
1
end_operator
begin_operator
debark car8 loc17
1
29 8
2
0 0 33 0
0 21 -1 8
1
end_operator
begin_operator
debark car8 loc18
1
29 9
2
0 0 33 0
0 21 -1 9
1
end_operator
begin_operator
debark car8 loc19
1
29 10
2
0 0 33 0
0 21 -1 10
1
end_operator
begin_operator
debark car8 loc2
1
29 11
2
0 0 33 0
0 21 -1 11
1
end_operator
begin_operator
debark car8 loc20
1
29 12
2
0 0 33 0
0 21 -1 12
1
end_operator
begin_operator
debark car8 loc21
1
29 13
2
0 0 33 0
0 21 -1 13
1
end_operator
begin_operator
debark car8 loc22
1
29 14
2
0 0 33 0
0 21 -1 14
1
end_operator
begin_operator
debark car8 loc23
1
29 15
2
0 0 33 0
0 21 -1 15
1
end_operator
begin_operator
debark car8 loc24
1
29 16
2
0 0 33 0
0 21 -1 16
1
end_operator
begin_operator
debark car8 loc25
1
29 17
2
0 0 33 0
0 21 -1 17
1
end_operator
begin_operator
debark car8 loc26
1
29 18
2
0 0 33 0
0 21 -1 18
1
end_operator
begin_operator
debark car8 loc27
1
29 19
2
0 0 33 0
0 21 -1 19
1
end_operator
begin_operator
debark car8 loc28
1
29 20
2
0 0 33 0
0 21 -1 20
1
end_operator
begin_operator
debark car8 loc3
1
29 21
2
0 0 33 0
0 21 -1 21
1
end_operator
begin_operator
debark car8 loc4
1
29 22
2
0 0 33 0
0 21 -1 22
1
end_operator
begin_operator
debark car8 loc5
1
29 23
2
0 0 33 0
0 21 -1 23
1
end_operator
begin_operator
debark car8 loc6
1
29 24
2
0 0 33 0
0 21 -1 24
1
end_operator
begin_operator
debark car8 loc7
1
29 25
2
0 0 33 0
0 21 -1 25
1
end_operator
begin_operator
debark car8 loc8
1
29 26
2
0 0 33 0
0 21 -1 26
1
end_operator
begin_operator
debark car8 loc9
1
29 27
2
0 0 33 0
0 21 -1 27
1
end_operator
begin_operator
debark car9 loc1
1
29 0
2
0 0 34 0
0 25 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
29 1
2
0 0 34 0
0 25 -1 1
1
end_operator
begin_operator
debark car9 loc11
1
29 2
2
0 0 34 0
0 25 -1 2
1
end_operator
begin_operator
debark car9 loc12
1
29 3
2
0 0 34 0
0 25 -1 3
1
end_operator
begin_operator
debark car9 loc13
1
29 4
2
0 0 34 0
0 25 -1 4
1
end_operator
begin_operator
debark car9 loc14
1
29 5
2
0 0 34 0
0 25 -1 5
1
end_operator
begin_operator
debark car9 loc15
1
29 6
2
0 0 34 0
0 25 -1 6
1
end_operator
begin_operator
debark car9 loc16
1
29 7
2
0 0 34 0
0 25 -1 7
1
end_operator
begin_operator
debark car9 loc17
1
29 8
2
0 0 34 0
0 25 -1 8
1
end_operator
begin_operator
debark car9 loc18
1
29 9
2
0 0 34 0
0 25 -1 9
1
end_operator
begin_operator
debark car9 loc19
1
29 10
2
0 0 34 0
0 25 -1 10
1
end_operator
begin_operator
debark car9 loc2
1
29 11
2
0 0 34 0
0 25 -1 11
1
end_operator
begin_operator
debark car9 loc20
1
29 12
2
0 0 34 0
0 25 -1 12
1
end_operator
begin_operator
debark car9 loc21
1
29 13
2
0 0 34 0
0 25 -1 13
1
end_operator
begin_operator
debark car9 loc22
1
29 14
2
0 0 34 0
0 25 -1 14
1
end_operator
begin_operator
debark car9 loc23
1
29 15
2
0 0 34 0
0 25 -1 15
1
end_operator
begin_operator
debark car9 loc24
1
29 16
2
0 0 34 0
0 25 -1 16
1
end_operator
begin_operator
debark car9 loc25
1
29 17
2
0 0 34 0
0 25 -1 17
1
end_operator
begin_operator
debark car9 loc26
1
29 18
2
0 0 34 0
0 25 -1 18
1
end_operator
begin_operator
debark car9 loc27
1
29 19
2
0 0 34 0
0 25 -1 19
1
end_operator
begin_operator
debark car9 loc28
1
29 20
2
0 0 34 0
0 25 -1 20
1
end_operator
begin_operator
debark car9 loc3
1
29 21
2
0 0 34 0
0 25 -1 21
1
end_operator
begin_operator
debark car9 loc4
1
29 22
2
0 0 34 0
0 25 -1 22
1
end_operator
begin_operator
debark car9 loc5
1
29 23
2
0 0 34 0
0 25 -1 23
1
end_operator
begin_operator
debark car9 loc6
1
29 24
2
0 0 34 0
0 25 -1 24
1
end_operator
begin_operator
debark car9 loc7
1
29 25
2
0 0 34 0
0 25 -1 25
1
end_operator
begin_operator
debark car9 loc8
1
29 26
2
0 0 34 0
0 25 -1 26
1
end_operator
begin_operator
debark car9 loc9
1
29 27
2
0 0 34 0
0 25 -1 27
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 29 0 1
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 29 0 2
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 29 0 3
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 29 0 4
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 29 0 5
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 29 0 6
0 36 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 29 0 7
0 36 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 29 0 8
0 36 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 29 0 9
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 29 0 10
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 29 0 11
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 29 0 12
0 36 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 29 0 13
0 36 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 29 0 14
0 36 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 29 0 15
0 36 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc1 loc24
0
3
0 29 0 16
0 36 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc1 loc25
0
3
0 29 0 17
0 36 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc1 loc26
0
3
0 29 0 18
0 36 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc1 loc27
0
3
0 29 0 19
0 36 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc1 loc28
0
3
0 29 0 20
0 36 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 29 0 21
0 36 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 29 0 22
0 36 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 29 0 23
0 36 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 29 0 24
0 36 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 29 0 25
0 36 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 29 0 26
0 36 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 29 0 27
0 36 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 29 1 0
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 29 1 2
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 29 1 3
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 29 1 4
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 29 1 5
0 37 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 29 1 6
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 29 1 7
0 37 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 29 1 8
0 37 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 29 1 9
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 29 1 10
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 29 1 11
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 29 1 12
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 29 1 13
0 37 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 29 1 14
0 37 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 29 1 15
0 37 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc10 loc24
0
3
0 29 1 16
0 37 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc10 loc25
0
3
0 29 1 17
0 37 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc10 loc26
0
3
0 29 1 18
0 37 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc10 loc27
0
3
0 29 1 19
0 37 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc10 loc28
0
3
0 29 1 20
0 37 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 29 1 21
0 37 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 29 1 22
0 37 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 29 1 23
0 37 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 29 1 24
0 37 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 29 1 25
0 37 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 29 1 26
0 37 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 29 1 27
0 37 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 29 2 0
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 29 2 1
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 29 2 3
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 29 2 4
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 29 2 5
0 38 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 29 2 6
0 38 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 29 2 7
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 29 2 8
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 29 2 9
0 38 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 29 2 10
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 29 2 11
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 29 2 12
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 29 2 13
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 29 2 14
0 38 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 29 2 15
0 38 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc11 loc24
0
3
0 29 2 16
0 38 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc11 loc25
0
3
0 29 2 17
0 38 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc11 loc26
0
3
0 29 2 18
0 38 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc11 loc27
0
3
0 29 2 19
0 38 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc11 loc28
0
3
0 29 2 20
0 38 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 29 2 21
0 38 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 29 2 22
0 38 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 29 2 23
0 38 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 29 2 24
0 38 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 29 2 25
0 38 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 29 2 26
0 38 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 29 2 27
0 38 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 29 3 0
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 29 3 1
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 29 3 2
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 29 3 4
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 29 3 5
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 29 3 6
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 29 3 7
0 39 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 29 3 8
0 39 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 29 3 9
0 39 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 29 3 10
0 39 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 29 3 11
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 29 3 12
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 29 3 13
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 29 3 14
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 29 3 15
0 39 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc12 loc24
0
3
0 29 3 16
0 39 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc12 loc25
0
3
0 29 3 17
0 39 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc12 loc26
0
3
0 29 3 18
0 39 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc12 loc27
0
3
0 29 3 19
0 39 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc12 loc28
0
3
0 29 3 20
0 39 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 29 3 21
0 39 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 29 3 22
0 39 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 29 3 23
0 39 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 29 3 24
0 39 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 29 3 25
0 39 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 29 3 26
0 39 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 29 3 27
0 39 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 29 4 0
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 29 4 1
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 29 4 2
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 29 4 3
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 29 4 5
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 29 4 6
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 29 4 7
0 40 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 29 4 8
0 40 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 29 4 9
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 29 4 10
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 29 4 11
0 40 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 29 4 12
0 40 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 29 4 13
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 29 4 14
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 29 4 15
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc13 loc24
0
3
0 29 4 16
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc13 loc25
0
3
0 29 4 17
0 40 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc13 loc26
0
3
0 29 4 18
0 40 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc13 loc27
0
3
0 29 4 19
0 40 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc13 loc28
0
3
0 29 4 20
0 40 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 29 4 21
0 40 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 29 4 22
0 40 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 29 4 23
0 40 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 29 4 24
0 40 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 29 4 25
0 40 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 29 4 26
0 40 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 29 4 27
0 40 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 29 5 0
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 29 5 1
0 37 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 29 5 2
0 38 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 29 5 3
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 29 5 4
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 29 5 6
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 29 5 7
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 29 5 8
0 41 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 29 5 9
0 41 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 29 5 10
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 29 5 11
0 41 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 29 5 12
0 41 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 29 5 13
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 29 5 14
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 29 5 15
0 41 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc14 loc24
0
3
0 29 5 16
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc14 loc25
0
3
0 29 5 17
0 41 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc14 loc26
0
3
0 29 5 18
0 41 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc14 loc27
0
3
0 29 5 19
0 41 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc14 loc28
0
3
0 29 5 20
0 41 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 29 5 21
0 41 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 29 5 22
0 41 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 29 5 23
0 41 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 29 5 24
0 41 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 29 5 25
0 41 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 29 5 26
0 41 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 29 5 27
0 41 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 29 6 0
0 36 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 29 6 1
0 37 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 29 6 2
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 29 6 3
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 29 6 4
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 29 6 5
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 29 6 7
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 29 6 8
0 42 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 29 6 9
0 42 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 29 6 10
0 42 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 29 6 11
0 42 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 29 6 12
0 42 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 29 6 13
0 42 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 29 6 14
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 29 6 15
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc15 loc24
0
3
0 29 6 16
0 42 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc15 loc25
0
3
0 29 6 17
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc15 loc26
0
3
0 29 6 18
0 42 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc15 loc27
0
3
0 29 6 19
0 42 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc15 loc28
0
3
0 29 6 20
0 42 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 29 6 21
0 42 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 29 6 22
0 42 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 29 6 23
0 42 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 29 6 24
0 42 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 29 6 25
0 42 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 29 6 26
0 42 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 29 6 27
0 42 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 29 7 0
0 36 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 29 7 1
0 37 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 29 7 2
0 38 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 29 7 3
0 39 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 29 7 4
0 40 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 29 7 5
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 29 7 6
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 29 7 8
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 29 7 9
0 43 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 29 7 10
0 43 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 29 7 11
0 43 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 29 7 12
0 43 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 29 7 13
0 43 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 29 7 14
0 43 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 29 7 15
0 43 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc16 loc24
0
3
0 29 7 16
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc16 loc25
0
3
0 29 7 17
0 43 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc16 loc26
0
3
0 29 7 18
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc16 loc27
0
3
0 29 7 19
0 43 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc16 loc28
0
3
0 29 7 20
0 43 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 29 7 21
0 43 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 29 7 22
0 43 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 29 7 23
0 43 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 29 7 24
0 43 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 29 7 25
0 43 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 29 7 26
0 43 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 29 7 27
0 43 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 29 8 0
0 36 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 29 8 1
0 37 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 29 8 2
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 29 8 3
0 39 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 29 8 4
0 40 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 29 8 5
0 41 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 29 8 6
0 42 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 29 8 7
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 29 8 9
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 29 8 10
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 29 8 11
0 44 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 29 8 12
0 44 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 29 8 13
0 44 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 29 8 14
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 29 8 15
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc17 loc24
0
3
0 29 8 16
0 44 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc17 loc25
0
3
0 29 8 17
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc17 loc26
0
3
0 29 8 18
0 44 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc17 loc27
0
3
0 29 8 19
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc17 loc28
0
3
0 29 8 20
0 44 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 29 8 21
0 44 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 29 8 22
0 44 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 29 8 23
0 44 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 29 8 24
0 44 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 29 8 25
0 44 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 29 8 26
0 44 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 29 8 27
0 44 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 29 9 0
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 29 9 1
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 29 9 2
0 38 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 29 9 3
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 29 9 4
0 40 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 29 9 5
0 41 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 29 9 6
0 42 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 29 9 7
0 43 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 29 9 8
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 29 9 10
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 29 9 11
0 45 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 29 9 12
0 45 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 29 9 13
0 45 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 29 9 14
0 45 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 29 9 15
0 45 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc18 loc24
0
3
0 29 9 16
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc18 loc25
0
3
0 29 9 17
0 45 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc18 loc26
0
3
0 29 9 18
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc18 loc27
0
3
0 29 9 19
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc18 loc28
0
3
0 29 9 20
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 29 9 21
0 45 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 29 9 22
0 45 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 29 9 23
0 45 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 29 9 24
0 45 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 29 9 25
0 45 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 29 9 26
0 45 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 29 9 27
0 45 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 29 10 0
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 29 10 1
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 29 10 2
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 29 10 3
0 39 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 29 10 4
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 29 10 5
0 41 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 29 10 6
0 42 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 29 10 7
0 43 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 29 10 8
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 29 10 9
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 29 10 11
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 29 10 12
0 46 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 29 10 13
0 46 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 29 10 14
0 46 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 29 10 15
0 46 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc19 loc24
0
3
0 29 10 16
0 46 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc19 loc25
0
3
0 29 10 17
0 46 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc19 loc26
0
3
0 29 10 18
0 46 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc19 loc27
0
3
0 29 10 19
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc19 loc28
0
3
0 29 10 20
0 46 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 29 10 21
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 29 10 22
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 29 10 23
0 46 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 29 10 24
0 46 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 29 10 25
0 46 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 29 10 26
0 46 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 29 10 27
0 46 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 29 11 0
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 29 11 1
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 29 11 2
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 29 11 3
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 29 11 4
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 29 11 5
0 41 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 29 11 6
0 42 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 29 11 7
0 43 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 29 11 8
0 44 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 29 11 9
0 45 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 29 11 10
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 29 11 12
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 29 11 13
0 47 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 29 11 14
0 47 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 29 11 15
0 47 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc2 loc24
0
3
0 29 11 16
0 47 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc2 loc25
0
3
0 29 11 17
0 47 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc2 loc26
0
3
0 29 11 18
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc2 loc27
0
3
0 29 11 19
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc2 loc28
0
3
0 29 11 20
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 29 11 21
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 29 11 22
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 29 11 23
0 47 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 29 11 24
0 47 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 29 11 25
0 47 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 29 11 26
0 47 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 29 11 27
0 47 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 29 12 0
0 36 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 29 12 1
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 29 12 2
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 29 12 3
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 29 12 4
0 40 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 29 12 5
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 29 12 6
0 42 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 29 12 7
0 43 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 29 12 8
0 44 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 29 12 9
0 45 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 29 12 10
0 46 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 29 12 11
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 29 12 13
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 29 12 14
0 48 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 29 12 15
0 48 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc20 loc24
0
3
0 29 12 16
0 48 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc20 loc25
0
3
0 29 12 17
0 48 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc20 loc26
0
3
0 29 12 18
0 48 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc20 loc27
0
3
0 29 12 19
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc20 loc28
0
3
0 29 12 20
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 29 12 21
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 29 12 22
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 29 12 23
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 29 12 24
0 48 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 29 12 25
0 48 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 29 12 26
0 48 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 29 12 27
0 48 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 29 13 0
0 36 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 29 13 1
0 37 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 29 13 2
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 29 13 3
0 39 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 29 13 4
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 29 13 5
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 29 13 6
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 29 13 7
0 43 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 29 13 8
0 44 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 29 13 9
0 45 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 29 13 10
0 46 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 29 13 11
0 47 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 29 13 12
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 29 13 14
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 29 13 15
0 49 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc21 loc24
0
3
0 29 13 16
0 49 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc21 loc25
0
3
0 29 13 17
0 49 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc21 loc26
0
3
0 29 13 18
0 49 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc21 loc27
0
3
0 29 13 19
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc21 loc28
0
3
0 29 13 20
0 49 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 29 13 21
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 29 13 22
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 29 13 23
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 29 13 24
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 29 13 25
0 49 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 29 13 26
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 29 13 27
0 49 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 29 14 0
0 36 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 29 14 1
0 37 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 29 14 2
0 38 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 29 14 3
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 29 14 4
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 29 14 5
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 29 14 6
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 29 14 7
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 29 14 8
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 29 14 9
0 45 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 29 14 10
0 46 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 29 14 11
0 47 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 29 14 12
0 48 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 29 14 13
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 29 14 15
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc22 loc24
0
3
0 29 14 16
0 50 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc22 loc25
0
3
0 29 14 17
0 50 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc22 loc26
0
3
0 29 14 18
0 50 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc22 loc27
0
3
0 29 14 19
0 50 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc22 loc28
0
3
0 29 14 20
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 29 14 21
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 29 14 22
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 29 14 23
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 29 14 24
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 29 14 25
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 29 14 26
0 50 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 29 14 27
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 29 15 0
0 36 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 29 15 1
0 37 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 29 15 2
0 38 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 29 15 3
0 39 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 29 15 4
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 29 15 5
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 29 15 6
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 29 15 7
0 43 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 29 15 8
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 29 15 9
0 45 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 29 15 10
0 46 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 29 15 11
0 47 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 29 15 12
0 48 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 29 15 13
0 49 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 29 15 14
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc23 loc24
0
3
0 29 15 16
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc23 loc25
0
3
0 29 15 17
0 51 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc23 loc26
0
3
0 29 15 18
0 51 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc23 loc27
0
3
0 29 15 19
0 51 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc23 loc28
0
3
0 29 15 20
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 29 15 21
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 29 15 22
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 29 15 23
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 29 15 24
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 29 15 25
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 29 15 26
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 29 15 27
0 51 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc24 loc1
0
3
0 29 16 0
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc10
0
3
0 29 16 1
0 37 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc11
0
3
0 29 16 2
0 38 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc12
0
3
0 29 16 3
0 39 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc13
0
3
0 29 16 4
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc14
0
3
0 29 16 5
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc15
0
3
0 29 16 6
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc16
0
3
0 29 16 7
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc17
0
3
0 29 16 8
0 44 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc18
0
3
0 29 16 9
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc19
0
3
0 29 16 10
0 46 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc2
0
3
0 29 16 11
0 47 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc20
0
3
0 29 16 12
0 48 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc21
0
3
0 29 16 13
0 49 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc22
0
3
0 29 16 14
0 50 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc23
0
3
0 29 16 15
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc24 loc25
0
3
0 29 16 17
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc24 loc26
0
3
0 29 16 18
0 52 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc24 loc27
0
3
0 29 16 19
0 52 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc24 loc28
0
3
0 29 16 20
0 52 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc24 loc3
0
3
0 29 16 21
0 52 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc24 loc4
0
3
0 29 16 22
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc24 loc5
0
3
0 29 16 23
0 52 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc24 loc6
0
3
0 29 16 24
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc24 loc7
0
3
0 29 16 25
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc24 loc8
0
3
0 29 16 26
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc24 loc9
0
3
0 29 16 27
0 52 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc25 loc1
0
3
0 29 17 0
0 36 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc10
0
3
0 29 17 1
0 37 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc11
0
3
0 29 17 2
0 38 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc12
0
3
0 29 17 3
0 39 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc13
0
3
0 29 17 4
0 40 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc14
0
3
0 29 17 5
0 41 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc15
0
3
0 29 17 6
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc16
0
3
0 29 17 7
0 43 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc17
0
3
0 29 17 8
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc18
0
3
0 29 17 9
0 45 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc19
0
3
0 29 17 10
0 46 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc2
0
3
0 29 17 11
0 47 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc20
0
3
0 29 17 12
0 48 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc21
0
3
0 29 17 13
0 49 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc22
0
3
0 29 17 14
0 50 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc23
0
3
0 29 17 15
0 51 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc24
0
3
0 29 17 16
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc25 loc26
0
3
0 29 17 18
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc25 loc27
0
3
0 29 17 19
0 53 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc25 loc28
0
3
0 29 17 20
0 53 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc25 loc3
0
3
0 29 17 21
0 53 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc25 loc4
0
3
0 29 17 22
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc25 loc5
0
3
0 29 17 23
0 53 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc25 loc6
0
3
0 29 17 24
0 53 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc25 loc7
0
3
0 29 17 25
0 53 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc25 loc8
0
3
0 29 17 26
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc25 loc9
0
3
0 29 17 27
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc26 loc1
0
3
0 29 18 0
0 36 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc10
0
3
0 29 18 1
0 37 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc11
0
3
0 29 18 2
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc12
0
3
0 29 18 3
0 39 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc13
0
3
0 29 18 4
0 40 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc14
0
3
0 29 18 5
0 41 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc15
0
3
0 29 18 6
0 42 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc16
0
3
0 29 18 7
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc17
0
3
0 29 18 8
0 44 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc18
0
3
0 29 18 9
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc19
0
3
0 29 18 10
0 46 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc2
0
3
0 29 18 11
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc20
0
3
0 29 18 12
0 48 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc21
0
3
0 29 18 13
0 49 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc22
0
3
0 29 18 14
0 50 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc23
0
3
0 29 18 15
0 51 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc24
0
3
0 29 18 16
0 52 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc25
0
3
0 29 18 17
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc26 loc27
0
3
0 29 18 19
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc26 loc28
0
3
0 29 18 20
0 54 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc26 loc3
0
3
0 29 18 21
0 54 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc26 loc4
0
3
0 29 18 22
0 54 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc26 loc5
0
3
0 29 18 23
0 54 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc26 loc6
0
3
0 29 18 24
0 54 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc26 loc7
0
3
0 29 18 25
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc26 loc8
0
3
0 29 18 26
0 54 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc26 loc9
0
3
0 29 18 27
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc27 loc1
0
3
0 29 19 0
0 36 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc10
0
3
0 29 19 1
0 37 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc11
0
3
0 29 19 2
0 38 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc12
0
3
0 29 19 3
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc13
0
3
0 29 19 4
0 40 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc14
0
3
0 29 19 5
0 41 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc15
0
3
0 29 19 6
0 42 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc16
0
3
0 29 19 7
0 43 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc17
0
3
0 29 19 8
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc18
0
3
0 29 19 9
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc19
0
3
0 29 19 10
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc2
0
3
0 29 19 11
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc20
0
3
0 29 19 12
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc21
0
3
0 29 19 13
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc22
0
3
0 29 19 14
0 50 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc23
0
3
0 29 19 15
0 51 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc24
0
3
0 29 19 16
0 52 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc25
0
3
0 29 19 17
0 53 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc26
0
3
0 29 19 18
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc27 loc28
0
3
0 29 19 20
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc27 loc3
0
3
0 29 19 21
0 55 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc27 loc4
0
3
0 29 19 22
0 55 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc27 loc5
0
3
0 29 19 23
0 55 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc27 loc6
0
3
0 29 19 24
0 55 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc27 loc7
0
3
0 29 19 25
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc27 loc8
0
3
0 29 19 26
0 55 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc27 loc9
0
3
0 29 19 27
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc28 loc1
0
3
0 29 20 0
0 36 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc10
0
3
0 29 20 1
0 37 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc11
0
3
0 29 20 2
0 38 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc12
0
3
0 29 20 3
0 39 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc13
0
3
0 29 20 4
0 40 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc14
0
3
0 29 20 5
0 41 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc15
0
3
0 29 20 6
0 42 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc16
0
3
0 29 20 7
0 43 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc17
0
3
0 29 20 8
0 44 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc18
0
3
0 29 20 9
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc19
0
3
0 29 20 10
0 46 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc2
0
3
0 29 20 11
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc20
0
3
0 29 20 12
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc21
0
3
0 29 20 13
0 49 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc22
0
3
0 29 20 14
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc23
0
3
0 29 20 15
0 51 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc24
0
3
0 29 20 16
0 52 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc25
0
3
0 29 20 17
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc26
0
3
0 29 20 18
0 54 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc27
0
3
0 29 20 19
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc28 loc3
0
3
0 29 20 21
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc28 loc4
0
3
0 29 20 22
0 56 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc28 loc5
0
3
0 29 20 23
0 56 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc28 loc6
0
3
0 29 20 24
0 56 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc28 loc7
0
3
0 29 20 25
0 56 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc28 loc8
0
3
0 29 20 26
0 56 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc28 loc9
0
3
0 29 20 27
0 56 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 29 21 0
0 36 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 29 21 1
0 37 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 29 21 2
0 38 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 29 21 3
0 39 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 29 21 4
0 40 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 29 21 5
0 41 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 29 21 6
0 42 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 29 21 7
0 43 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 29 21 8
0 44 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 29 21 9
0 45 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 29 21 10
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 29 21 11
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 29 21 12
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 29 21 13
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 29 21 14
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 29 21 15
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc24
0
3
0 29 21 16
0 52 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc25
0
3
0 29 21 17
0 53 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc26
0
3
0 29 21 18
0 54 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc27
0
3
0 29 21 19
0 55 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc28
0
3
0 29 21 20
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 29 21 22
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 29 21 23
0 57 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 29 21 24
0 57 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 29 21 25
0 57 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 29 21 26
0 57 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 29 21 27
0 57 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 29 22 0
0 36 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 29 22 1
0 37 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 29 22 2
0 38 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 29 22 3
0 39 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 29 22 4
0 40 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 29 22 5
0 41 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 29 22 6
0 42 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 29 22 7
0 43 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 29 22 8
0 44 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 29 22 9
0 45 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 29 22 10
0 46 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 29 22 11
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 29 22 12
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 29 22 13
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 29 22 14
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 29 22 15
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc24
0
3
0 29 22 16
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc25
0
3
0 29 22 17
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc26
0
3
0 29 22 18
0 54 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc27
0
3
0 29 22 19
0 55 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc28
0
3
0 29 22 20
0 56 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 29 22 21
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 29 22 23
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 29 22 24
0 58 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 29 22 25
0 58 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 29 22 26
0 58 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 29 22 27
0 58 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 29 23 0
0 36 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 29 23 1
0 37 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 29 23 2
0 38 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 29 23 3
0 39 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 29 23 4
0 40 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 29 23 5
0 41 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 29 23 6
0 42 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 29 23 7
0 43 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 29 23 8
0 44 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 29 23 9
0 45 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 29 23 10
0 46 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 29 23 11
0 47 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 29 23 12
0 48 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 29 23 13
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 29 23 14
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 29 23 15
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc24
0
3
0 29 23 16
0 52 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc25
0
3
0 29 23 17
0 53 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc26
0
3
0 29 23 18
0 54 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc27
0
3
0 29 23 19
0 55 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc28
0
3
0 29 23 20
0 56 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 29 23 21
0 57 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 29 23 22
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 29 23 24
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 29 23 25
0 59 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 29 23 26
0 59 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 29 23 27
0 59 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 29 24 0
0 36 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 29 24 1
0 37 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 29 24 2
0 38 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 29 24 3
0 39 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 29 24 4
0 40 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 29 24 5
0 41 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 29 24 6
0 42 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 29 24 7
0 43 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 29 24 8
0 44 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 29 24 9
0 45 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 29 24 10
0 46 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 29 24 11
0 47 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 29 24 12
0 48 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 29 24 13
0 49 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 29 24 14
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 29 24 15
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc24
0
3
0 29 24 16
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc25
0
3
0 29 24 17
0 53 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc26
0
3
0 29 24 18
0 54 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc27
0
3
0 29 24 19
0 55 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc28
0
3
0 29 24 20
0 56 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 29 24 21
0 57 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 29 24 22
0 58 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 29 24 23
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 29 24 25
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 29 24 26
0 60 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 29 24 27
0 60 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 29 25 0
0 36 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 29 25 1
0 37 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 29 25 2
0 38 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 29 25 3
0 39 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 29 25 4
0 40 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 29 25 5
0 41 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 29 25 6
0 42 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 29 25 7
0 43 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 29 25 8
0 44 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 29 25 9
0 45 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 29 25 10
0 46 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 29 25 11
0 47 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 29 25 12
0 48 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 29 25 13
0 49 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 29 25 14
0 50 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 29 25 15
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc24
0
3
0 29 25 16
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc25
0
3
0 29 25 17
0 53 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc26
0
3
0 29 25 18
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc27
0
3
0 29 25 19
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc28
0
3
0 29 25 20
0 56 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 29 25 21
0 57 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 29 25 22
0 58 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 29 25 23
0 59 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 29 25 24
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 29 25 26
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 29 25 27
0 61 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 29 26 0
0 36 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 29 26 1
0 37 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 29 26 2
0 38 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 29 26 3
0 39 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 29 26 4
0 40 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 29 26 5
0 41 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 29 26 6
0 42 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 29 26 7
0 43 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 29 26 8
0 44 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 29 26 9
0 45 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 29 26 10
0 46 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 29 26 11
0 47 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 29 26 12
0 48 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 29 26 13
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 29 26 14
0 50 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 29 26 15
0 51 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc24
0
3
0 29 26 16
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc25
0
3
0 29 26 17
0 53 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc26
0
3
0 29 26 18
0 54 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc27
0
3
0 29 26 19
0 55 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc28
0
3
0 29 26 20
0 56 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 29 26 21
0 57 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 29 26 22
0 58 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 29 26 23
0 59 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 29 26 24
0 60 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 29 26 25
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 29 26 27
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 29 27 0
0 36 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 29 27 1
0 37 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 29 27 2
0 38 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 29 27 3
0 39 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 29 27 4
0 40 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 29 27 5
0 41 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 29 27 6
0 42 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 29 27 7
0 43 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 29 27 8
0 44 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 29 27 9
0 45 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 29 27 10
0 46 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 29 27 11
0 47 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 29 27 12
0 48 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 29 27 13
0 49 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 29 27 14
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 29 27 15
0 51 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc24
0
3
0 29 27 16
0 52 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc25
0
3
0 29 27 17
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc26
0
3
0 29 27 18
0 54 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc27
0
3
0 29 27 19
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc28
0
3
0 29 27 20
0 56 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 29 27 21
0 57 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 29 27 22
0 58 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 29 27 23
0 59 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 29 27 24
0 60 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 29 27 25
0 61 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 29 27 26
0 62 0 1
0 63 -1 0
1
end_operator
0
