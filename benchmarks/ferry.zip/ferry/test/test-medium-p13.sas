begin_version
3
end_version
begin_metric
1
end_metric
80
begin_variable
var0
-1
47
empty-ferry
on car1
on car10
on car11
on car12
on car13
on car14
on car15
on car16
on car17
on car18
on car19
on car2
on car20
on car21
on car22
on car23
on car24
on car25
on car26
on car27
on car28
on car29
on car3
on car30
on car31
on car32
on car33
on car34
on car35
on car36
on car37
on car38
on car39
on car4
on car40
on car41
on car42
on car43
on car44
on car45
on car46
on car5
on car6
on car7
on car8
on car9
end_variable
begin_variable
var1
-1
33
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc24
at car16 loc25
at car16 loc26
at car16 loc27
at car16 loc28
at car16 loc29
at car16 loc3
at car16 loc30
at car16 loc31
at car16 loc32
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
none-of-those
end_variable
begin_variable
var2
-1
33
at car23 loc1
at car23 loc10
at car23 loc11
at car23 loc12
at car23 loc13
at car23 loc14
at car23 loc15
at car23 loc16
at car23 loc17
at car23 loc18
at car23 loc19
at car23 loc2
at car23 loc20
at car23 loc21
at car23 loc22
at car23 loc23
at car23 loc24
at car23 loc25
at car23 loc26
at car23 loc27
at car23 loc28
at car23 loc29
at car23 loc3
at car23 loc30
at car23 loc31
at car23 loc32
at car23 loc4
at car23 loc5
at car23 loc6
at car23 loc7
at car23 loc8
at car23 loc9
none-of-those
end_variable
begin_variable
var3
-1
33
at car30 loc1
at car30 loc10
at car30 loc11
at car30 loc12
at car30 loc13
at car30 loc14
at car30 loc15
at car30 loc16
at car30 loc17
at car30 loc18
at car30 loc19
at car30 loc2
at car30 loc20
at car30 loc21
at car30 loc22
at car30 loc23
at car30 loc24
at car30 loc25
at car30 loc26
at car30 loc27
at car30 loc28
at car30 loc29
at car30 loc3
at car30 loc30
at car30 loc31
at car30 loc32
at car30 loc4
at car30 loc5
at car30 loc6
at car30 loc7
at car30 loc8
at car30 loc9
none-of-those
end_variable
begin_variable
var4
-1
33
at car38 loc1
at car38 loc10
at car38 loc11
at car38 loc12
at car38 loc13
at car38 loc14
at car38 loc15
at car38 loc16
at car38 loc17
at car38 loc18
at car38 loc19
at car38 loc2
at car38 loc20
at car38 loc21
at car38 loc22
at car38 loc23
at car38 loc24
at car38 loc25
at car38 loc26
at car38 loc27
at car38 loc28
at car38 loc29
at car38 loc3
at car38 loc30
at car38 loc31
at car38 loc32
at car38 loc4
at car38 loc5
at car38 loc6
at car38 loc7
at car38 loc8
at car38 loc9
none-of-those
end_variable
begin_variable
var5
-1
33
at car45 loc1
at car45 loc10
at car45 loc11
at car45 loc12
at car45 loc13
at car45 loc14
at car45 loc15
at car45 loc16
at car45 loc17
at car45 loc18
at car45 loc19
at car45 loc2
at car45 loc20
at car45 loc21
at car45 loc22
at car45 loc23
at car45 loc24
at car45 loc25
at car45 loc26
at car45 loc27
at car45 loc28
at car45 loc29
at car45 loc3
at car45 loc30
at car45 loc31
at car45 loc32
at car45 loc4
at car45 loc5
at car45 loc6
at car45 loc7
at car45 loc8
at car45 loc9
none-of-those
end_variable
begin_variable
var6
-1
33
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc24
at car1 loc25
at car1 loc26
at car1 loc27
at car1 loc28
at car1 loc29
at car1 loc3
at car1 loc30
at car1 loc31
at car1 loc32
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var7
-1
33
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc24
at car17 loc25
at car17 loc26
at car17 loc27
at car17 loc28
at car17 loc29
at car17 loc3
at car17 loc30
at car17 loc31
at car17 loc32
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
none-of-those
end_variable
begin_variable
var8
-1
33
at car24 loc1
at car24 loc10
at car24 loc11
at car24 loc12
at car24 loc13
at car24 loc14
at car24 loc15
at car24 loc16
at car24 loc17
at car24 loc18
at car24 loc19
at car24 loc2
at car24 loc20
at car24 loc21
at car24 loc22
at car24 loc23
at car24 loc24
at car24 loc25
at car24 loc26
at car24 loc27
at car24 loc28
at car24 loc29
at car24 loc3
at car24 loc30
at car24 loc31
at car24 loc32
at car24 loc4
at car24 loc5
at car24 loc6
at car24 loc7
at car24 loc8
at car24 loc9
none-of-those
end_variable
begin_variable
var9
-1
33
at car31 loc1
at car31 loc10
at car31 loc11
at car31 loc12
at car31 loc13
at car31 loc14
at car31 loc15
at car31 loc16
at car31 loc17
at car31 loc18
at car31 loc19
at car31 loc2
at car31 loc20
at car31 loc21
at car31 loc22
at car31 loc23
at car31 loc24
at car31 loc25
at car31 loc26
at car31 loc27
at car31 loc28
at car31 loc29
at car31 loc3
at car31 loc30
at car31 loc31
at car31 loc32
at car31 loc4
at car31 loc5
at car31 loc6
at car31 loc7
at car31 loc8
at car31 loc9
none-of-those
end_variable
begin_variable
var10
-1
33
at car39 loc1
at car39 loc10
at car39 loc11
at car39 loc12
at car39 loc13
at car39 loc14
at car39 loc15
at car39 loc16
at car39 loc17
at car39 loc18
at car39 loc19
at car39 loc2
at car39 loc20
at car39 loc21
at car39 loc22
at car39 loc23
at car39 loc24
at car39 loc25
at car39 loc26
at car39 loc27
at car39 loc28
at car39 loc29
at car39 loc3
at car39 loc30
at car39 loc31
at car39 loc32
at car39 loc4
at car39 loc5
at car39 loc6
at car39 loc7
at car39 loc8
at car39 loc9
none-of-those
end_variable
begin_variable
var11
-1
33
at car46 loc1
at car46 loc10
at car46 loc11
at car46 loc12
at car46 loc13
at car46 loc14
at car46 loc15
at car46 loc16
at car46 loc17
at car46 loc18
at car46 loc19
at car46 loc2
at car46 loc20
at car46 loc21
at car46 loc22
at car46 loc23
at car46 loc24
at car46 loc25
at car46 loc26
at car46 loc27
at car46 loc28
at car46 loc29
at car46 loc3
at car46 loc30
at car46 loc31
at car46 loc32
at car46 loc4
at car46 loc5
at car46 loc6
at car46 loc7
at car46 loc8
at car46 loc9
none-of-those
end_variable
begin_variable
var12
-1
33
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc24
at car10 loc25
at car10 loc26
at car10 loc27
at car10 loc28
at car10 loc29
at car10 loc3
at car10 loc30
at car10 loc31
at car10 loc32
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var13
-1
33
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc24
at car18 loc25
at car18 loc26
at car18 loc27
at car18 loc28
at car18 loc29
at car18 loc3
at car18 loc30
at car18 loc31
at car18 loc32
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
none-of-those
end_variable
begin_variable
var14
-1
33
at car25 loc1
at car25 loc10
at car25 loc11
at car25 loc12
at car25 loc13
at car25 loc14
at car25 loc15
at car25 loc16
at car25 loc17
at car25 loc18
at car25 loc19
at car25 loc2
at car25 loc20
at car25 loc21
at car25 loc22
at car25 loc23
at car25 loc24
at car25 loc25
at car25 loc26
at car25 loc27
at car25 loc28
at car25 loc29
at car25 loc3
at car25 loc30
at car25 loc31
at car25 loc32
at car25 loc4
at car25 loc5
at car25 loc6
at car25 loc7
at car25 loc8
at car25 loc9
none-of-those
end_variable
begin_variable
var15
-1
33
at car32 loc1
at car32 loc10
at car32 loc11
at car32 loc12
at car32 loc13
at car32 loc14
at car32 loc15
at car32 loc16
at car32 loc17
at car32 loc18
at car32 loc19
at car32 loc2
at car32 loc20
at car32 loc21
at car32 loc22
at car32 loc23
at car32 loc24
at car32 loc25
at car32 loc26
at car32 loc27
at car32 loc28
at car32 loc29
at car32 loc3
at car32 loc30
at car32 loc31
at car32 loc32
at car32 loc4
at car32 loc5
at car32 loc6
at car32 loc7
at car32 loc8
at car32 loc9
none-of-those
end_variable
begin_variable
var16
-1
33
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc24
at car4 loc25
at car4 loc26
at car4 loc27
at car4 loc28
at car4 loc29
at car4 loc3
at car4 loc30
at car4 loc31
at car4 loc32
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var17
-1
33
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc24
at car5 loc25
at car5 loc26
at car5 loc27
at car5 loc28
at car5 loc29
at car5 loc3
at car5 loc30
at car5 loc31
at car5 loc32
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var18
-1
33
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc24
at car11 loc25
at car11 loc26
at car11 loc27
at car11 loc28
at car11 loc29
at car11 loc3
at car11 loc30
at car11 loc31
at car11 loc32
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var19
-1
33
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc24
at car19 loc25
at car19 loc26
at car19 loc27
at car19 loc28
at car19 loc29
at car19 loc3
at car19 loc30
at car19 loc31
at car19 loc32
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
none-of-those
end_variable
begin_variable
var20
-1
33
at car26 loc1
at car26 loc10
at car26 loc11
at car26 loc12
at car26 loc13
at car26 loc14
at car26 loc15
at car26 loc16
at car26 loc17
at car26 loc18
at car26 loc19
at car26 loc2
at car26 loc20
at car26 loc21
at car26 loc22
at car26 loc23
at car26 loc24
at car26 loc25
at car26 loc26
at car26 loc27
at car26 loc28
at car26 loc29
at car26 loc3
at car26 loc30
at car26 loc31
at car26 loc32
at car26 loc4
at car26 loc5
at car26 loc6
at car26 loc7
at car26 loc8
at car26 loc9
none-of-those
end_variable
begin_variable
var21
-1
33
at car33 loc1
at car33 loc10
at car33 loc11
at car33 loc12
at car33 loc13
at car33 loc14
at car33 loc15
at car33 loc16
at car33 loc17
at car33 loc18
at car33 loc19
at car33 loc2
at car33 loc20
at car33 loc21
at car33 loc22
at car33 loc23
at car33 loc24
at car33 loc25
at car33 loc26
at car33 loc27
at car33 loc28
at car33 loc29
at car33 loc3
at car33 loc30
at car33 loc31
at car33 loc32
at car33 loc4
at car33 loc5
at car33 loc6
at car33 loc7
at car33 loc8
at car33 loc9
none-of-those
end_variable
begin_variable
var22
-1
33
at car40 loc1
at car40 loc10
at car40 loc11
at car40 loc12
at car40 loc13
at car40 loc14
at car40 loc15
at car40 loc16
at car40 loc17
at car40 loc18
at car40 loc19
at car40 loc2
at car40 loc20
at car40 loc21
at car40 loc22
at car40 loc23
at car40 loc24
at car40 loc25
at car40 loc26
at car40 loc27
at car40 loc28
at car40 loc29
at car40 loc3
at car40 loc30
at car40 loc31
at car40 loc32
at car40 loc4
at car40 loc5
at car40 loc6
at car40 loc7
at car40 loc8
at car40 loc9
none-of-those
end_variable
begin_variable
var23
-1
33
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc24
at car6 loc25
at car6 loc26
at car6 loc27
at car6 loc28
at car6 loc29
at car6 loc3
at car6 loc30
at car6 loc31
at car6 loc32
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var24
-1
33
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc24
at car12 loc25
at car12 loc26
at car12 loc27
at car12 loc28
at car12 loc29
at car12 loc3
at car12 loc30
at car12 loc31
at car12 loc32
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
none-of-those
end_variable
begin_variable
var25
-1
33
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc24
at car2 loc25
at car2 loc26
at car2 loc27
at car2 loc28
at car2 loc29
at car2 loc3
at car2 loc30
at car2 loc31
at car2 loc32
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var26
-1
33
at car27 loc1
at car27 loc10
at car27 loc11
at car27 loc12
at car27 loc13
at car27 loc14
at car27 loc15
at car27 loc16
at car27 loc17
at car27 loc18
at car27 loc19
at car27 loc2
at car27 loc20
at car27 loc21
at car27 loc22
at car27 loc23
at car27 loc24
at car27 loc25
at car27 loc26
at car27 loc27
at car27 loc28
at car27 loc29
at car27 loc3
at car27 loc30
at car27 loc31
at car27 loc32
at car27 loc4
at car27 loc5
at car27 loc6
at car27 loc7
at car27 loc8
at car27 loc9
none-of-those
end_variable
begin_variable
var27
-1
33
at car34 loc1
at car34 loc10
at car34 loc11
at car34 loc12
at car34 loc13
at car34 loc14
at car34 loc15
at car34 loc16
at car34 loc17
at car34 loc18
at car34 loc19
at car34 loc2
at car34 loc20
at car34 loc21
at car34 loc22
at car34 loc23
at car34 loc24
at car34 loc25
at car34 loc26
at car34 loc27
at car34 loc28
at car34 loc29
at car34 loc3
at car34 loc30
at car34 loc31
at car34 loc32
at car34 loc4
at car34 loc5
at car34 loc6
at car34 loc7
at car34 loc8
at car34 loc9
none-of-those
end_variable
begin_variable
var28
-1
33
at car41 loc1
at car41 loc10
at car41 loc11
at car41 loc12
at car41 loc13
at car41 loc14
at car41 loc15
at car41 loc16
at car41 loc17
at car41 loc18
at car41 loc19
at car41 loc2
at car41 loc20
at car41 loc21
at car41 loc22
at car41 loc23
at car41 loc24
at car41 loc25
at car41 loc26
at car41 loc27
at car41 loc28
at car41 loc29
at car41 loc3
at car41 loc30
at car41 loc31
at car41 loc32
at car41 loc4
at car41 loc5
at car41 loc6
at car41 loc7
at car41 loc8
at car41 loc9
none-of-those
end_variable
begin_variable
var29
-1
33
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc24
at car7 loc25
at car7 loc26
at car7 loc27
at car7 loc28
at car7 loc29
at car7 loc3
at car7 loc30
at car7 loc31
at car7 loc32
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var30
-1
33
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc24
at car13 loc25
at car13 loc26
at car13 loc27
at car13 loc28
at car13 loc29
at car13 loc3
at car13 loc30
at car13 loc31
at car13 loc32
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
none-of-those
end_variable
begin_variable
var31
-1
33
at car20 loc1
at car20 loc10
at car20 loc11
at car20 loc12
at car20 loc13
at car20 loc14
at car20 loc15
at car20 loc16
at car20 loc17
at car20 loc18
at car20 loc19
at car20 loc2
at car20 loc20
at car20 loc21
at car20 loc22
at car20 loc23
at car20 loc24
at car20 loc25
at car20 loc26
at car20 loc27
at car20 loc28
at car20 loc29
at car20 loc3
at car20 loc30
at car20 loc31
at car20 loc32
at car20 loc4
at car20 loc5
at car20 loc6
at car20 loc7
at car20 loc8
at car20 loc9
none-of-those
end_variable
begin_variable
var32
-1
33
at car28 loc1
at car28 loc10
at car28 loc11
at car28 loc12
at car28 loc13
at car28 loc14
at car28 loc15
at car28 loc16
at car28 loc17
at car28 loc18
at car28 loc19
at car28 loc2
at car28 loc20
at car28 loc21
at car28 loc22
at car28 loc23
at car28 loc24
at car28 loc25
at car28 loc26
at car28 loc27
at car28 loc28
at car28 loc29
at car28 loc3
at car28 loc30
at car28 loc31
at car28 loc32
at car28 loc4
at car28 loc5
at car28 loc6
at car28 loc7
at car28 loc8
at car28 loc9
none-of-those
end_variable
begin_variable
var33
-1
33
at car35 loc1
at car35 loc10
at car35 loc11
at car35 loc12
at car35 loc13
at car35 loc14
at car35 loc15
at car35 loc16
at car35 loc17
at car35 loc18
at car35 loc19
at car35 loc2
at car35 loc20
at car35 loc21
at car35 loc22
at car35 loc23
at car35 loc24
at car35 loc25
at car35 loc26
at car35 loc27
at car35 loc28
at car35 loc29
at car35 loc3
at car35 loc30
at car35 loc31
at car35 loc32
at car35 loc4
at car35 loc5
at car35 loc6
at car35 loc7
at car35 loc8
at car35 loc9
none-of-those
end_variable
begin_variable
var34
-1
33
at car42 loc1
at car42 loc10
at car42 loc11
at car42 loc12
at car42 loc13
at car42 loc14
at car42 loc15
at car42 loc16
at car42 loc17
at car42 loc18
at car42 loc19
at car42 loc2
at car42 loc20
at car42 loc21
at car42 loc22
at car42 loc23
at car42 loc24
at car42 loc25
at car42 loc26
at car42 loc27
at car42 loc28
at car42 loc29
at car42 loc3
at car42 loc30
at car42 loc31
at car42 loc32
at car42 loc4
at car42 loc5
at car42 loc6
at car42 loc7
at car42 loc8
at car42 loc9
none-of-those
end_variable
begin_variable
var35
-1
33
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc24
at car8 loc25
at car8 loc26
at car8 loc27
at car8 loc28
at car8 loc29
at car8 loc3
at car8 loc30
at car8 loc31
at car8 loc32
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var36
-1
33
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc24
at car14 loc25
at car14 loc26
at car14 loc27
at car14 loc28
at car14 loc29
at car14 loc3
at car14 loc30
at car14 loc31
at car14 loc32
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
none-of-those
end_variable
begin_variable
var37
-1
33
at car21 loc1
at car21 loc10
at car21 loc11
at car21 loc12
at car21 loc13
at car21 loc14
at car21 loc15
at car21 loc16
at car21 loc17
at car21 loc18
at car21 loc19
at car21 loc2
at car21 loc20
at car21 loc21
at car21 loc22
at car21 loc23
at car21 loc24
at car21 loc25
at car21 loc26
at car21 loc27
at car21 loc28
at car21 loc29
at car21 loc3
at car21 loc30
at car21 loc31
at car21 loc32
at car21 loc4
at car21 loc5
at car21 loc6
at car21 loc7
at car21 loc8
at car21 loc9
none-of-those
end_variable
begin_variable
var38
-1
33
at car29 loc1
at car29 loc10
at car29 loc11
at car29 loc12
at car29 loc13
at car29 loc14
at car29 loc15
at car29 loc16
at car29 loc17
at car29 loc18
at car29 loc19
at car29 loc2
at car29 loc20
at car29 loc21
at car29 loc22
at car29 loc23
at car29 loc24
at car29 loc25
at car29 loc26
at car29 loc27
at car29 loc28
at car29 loc29
at car29 loc3
at car29 loc30
at car29 loc31
at car29 loc32
at car29 loc4
at car29 loc5
at car29 loc6
at car29 loc7
at car29 loc8
at car29 loc9
none-of-those
end_variable
begin_variable
var39
-1
33
at car36 loc1
at car36 loc10
at car36 loc11
at car36 loc12
at car36 loc13
at car36 loc14
at car36 loc15
at car36 loc16
at car36 loc17
at car36 loc18
at car36 loc19
at car36 loc2
at car36 loc20
at car36 loc21
at car36 loc22
at car36 loc23
at car36 loc24
at car36 loc25
at car36 loc26
at car36 loc27
at car36 loc28
at car36 loc29
at car36 loc3
at car36 loc30
at car36 loc31
at car36 loc32
at car36 loc4
at car36 loc5
at car36 loc6
at car36 loc7
at car36 loc8
at car36 loc9
none-of-those
end_variable
begin_variable
var40
-1
33
at car43 loc1
at car43 loc10
at car43 loc11
at car43 loc12
at car43 loc13
at car43 loc14
at car43 loc15
at car43 loc16
at car43 loc17
at car43 loc18
at car43 loc19
at car43 loc2
at car43 loc20
at car43 loc21
at car43 loc22
at car43 loc23
at car43 loc24
at car43 loc25
at car43 loc26
at car43 loc27
at car43 loc28
at car43 loc29
at car43 loc3
at car43 loc30
at car43 loc31
at car43 loc32
at car43 loc4
at car43 loc5
at car43 loc6
at car43 loc7
at car43 loc8
at car43 loc9
none-of-those
end_variable
begin_variable
var41
-1
33
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc24
at car9 loc25
at car9 loc26
at car9 loc27
at car9 loc28
at car9 loc29
at car9 loc3
at car9 loc30
at car9 loc31
at car9 loc32
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var42
-1
33
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc24
at car15 loc25
at car15 loc26
at car15 loc27
at car15 loc28
at car15 loc29
at car15 loc3
at car15 loc30
at car15 loc31
at car15 loc32
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
none-of-those
end_variable
begin_variable
var43
-1
33
at car22 loc1
at car22 loc10
at car22 loc11
at car22 loc12
at car22 loc13
at car22 loc14
at car22 loc15
at car22 loc16
at car22 loc17
at car22 loc18
at car22 loc19
at car22 loc2
at car22 loc20
at car22 loc21
at car22 loc22
at car22 loc23
at car22 loc24
at car22 loc25
at car22 loc26
at car22 loc27
at car22 loc28
at car22 loc29
at car22 loc3
at car22 loc30
at car22 loc31
at car22 loc32
at car22 loc4
at car22 loc5
at car22 loc6
at car22 loc7
at car22 loc8
at car22 loc9
none-of-those
end_variable
begin_variable
var44
-1
33
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc24
at car3 loc25
at car3 loc26
at car3 loc27
at car3 loc28
at car3 loc29
at car3 loc3
at car3 loc30
at car3 loc31
at car3 loc32
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var45
-1
33
at car37 loc1
at car37 loc10
at car37 loc11
at car37 loc12
at car37 loc13
at car37 loc14
at car37 loc15
at car37 loc16
at car37 loc17
at car37 loc18
at car37 loc19
at car37 loc2
at car37 loc20
at car37 loc21
at car37 loc22
at car37 loc23
at car37 loc24
at car37 loc25
at car37 loc26
at car37 loc27
at car37 loc28
at car37 loc29
at car37 loc3
at car37 loc30
at car37 loc31
at car37 loc32
at car37 loc4
at car37 loc5
at car37 loc6
at car37 loc7
at car37 loc8
at car37 loc9
none-of-those
end_variable
begin_variable
var46
-1
33
at car44 loc1
at car44 loc10
at car44 loc11
at car44 loc12
at car44 loc13
at car44 loc14
at car44 loc15
at car44 loc16
at car44 loc17
at car44 loc18
at car44 loc19
at car44 loc2
at car44 loc20
at car44 loc21
at car44 loc22
at car44 loc23
at car44 loc24
at car44 loc25
at car44 loc26
at car44 loc27
at car44 loc28
at car44 loc29
at car44 loc3
at car44 loc30
at car44 loc31
at car44 loc32
at car44 loc4
at car44 loc5
at car44 loc6
at car44 loc7
at car44 loc8
at car44 loc9
none-of-those
end_variable
begin_variable
var47
-1
32
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc24
at-ferry loc25
at-ferry loc26
at-ferry loc27
at-ferry loc28
at-ferry loc29
at-ferry loc3
at-ferry loc30
at-ferry loc31
at-ferry loc32
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var48
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var49
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var50
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var51
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var52
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var53
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var54
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var55
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var56
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var57
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var58
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var59
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var60
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var61
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var62
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var63
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var64
-1
2
NOT-at-ferry loc24
none-of-those
end_variable
begin_variable
var65
-1
2
NOT-at-ferry loc25
none-of-those
end_variable
begin_variable
var66
-1
2
NOT-at-ferry loc26
none-of-those
end_variable
begin_variable
var67
-1
2
NOT-at-ferry loc27
none-of-those
end_variable
begin_variable
var68
-1
2
NOT-at-ferry loc28
none-of-those
end_variable
begin_variable
var69
-1
2
NOT-at-ferry loc29
none-of-those
end_variable
begin_variable
var70
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var71
-1
2
NOT-at-ferry loc30
none-of-those
end_variable
begin_variable
var72
-1
2
NOT-at-ferry loc31
none-of-those
end_variable
begin_variable
var73
-1
2
NOT-at-ferry loc32
none-of-those
end_variable
begin_variable
var74
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var75
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var76
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var77
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var78
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var79
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
19
22
25
17
23
14
26
30
2
29
5
10
3
25
20
7
21
8
21
2
26
10
6
6
5
4
29
3
10
8
10
18
10
19
17
29
24
19
29
5
17
15
24
29
21
10
22
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
end_state
begin_goal
46
1 26
2 14
3 5
4 14
5 18
6 6
7 8
8 15
9 21
10 27
11 15
12 12
13 13
14 5
15 31
16 29
17 20
18 20
19 11
20 11
21 25
22 7
23 30
24 3
25 29
26 11
27 4
28 14
29 8
30 18
31 22
32 4
33 1
34 25
35 25
36 0
37 21
38 16
39 13
40 0
41 26
42 27
43 8
44 12
45 6
46 19
end_goal
3936
begin_operator
board car1 loc1
1
47 0
2
0 0 0 1
0 6 0 32
1
end_operator
begin_operator
board car1 loc10
1
47 1
2
0 0 0 1
0 6 1 32
1
end_operator
begin_operator
board car1 loc11
1
47 2
2
0 0 0 1
0 6 2 32
1
end_operator
begin_operator
board car1 loc12
1
47 3
2
0 0 0 1
0 6 3 32
1
end_operator
begin_operator
board car1 loc13
1
47 4
2
0 0 0 1
0 6 4 32
1
end_operator
begin_operator
board car1 loc14
1
47 5
2
0 0 0 1
0 6 5 32
1
end_operator
begin_operator
board car1 loc15
1
47 6
2
0 0 0 1
0 6 6 32
1
end_operator
begin_operator
board car1 loc16
1
47 7
2
0 0 0 1
0 6 7 32
1
end_operator
begin_operator
board car1 loc17
1
47 8
2
0 0 0 1
0 6 8 32
1
end_operator
begin_operator
board car1 loc18
1
47 9
2
0 0 0 1
0 6 9 32
1
end_operator
begin_operator
board car1 loc19
1
47 10
2
0 0 0 1
0 6 10 32
1
end_operator
begin_operator
board car1 loc2
1
47 11
2
0 0 0 1
0 6 11 32
1
end_operator
begin_operator
board car1 loc20
1
47 12
2
0 0 0 1
0 6 12 32
1
end_operator
begin_operator
board car1 loc21
1
47 13
2
0 0 0 1
0 6 13 32
1
end_operator
begin_operator
board car1 loc22
1
47 14
2
0 0 0 1
0 6 14 32
1
end_operator
begin_operator
board car1 loc23
1
47 15
2
0 0 0 1
0 6 15 32
1
end_operator
begin_operator
board car1 loc24
1
47 16
2
0 0 0 1
0 6 16 32
1
end_operator
begin_operator
board car1 loc25
1
47 17
2
0 0 0 1
0 6 17 32
1
end_operator
begin_operator
board car1 loc26
1
47 18
2
0 0 0 1
0 6 18 32
1
end_operator
begin_operator
board car1 loc27
1
47 19
2
0 0 0 1
0 6 19 32
1
end_operator
begin_operator
board car1 loc28
1
47 20
2
0 0 0 1
0 6 20 32
1
end_operator
begin_operator
board car1 loc29
1
47 21
2
0 0 0 1
0 6 21 32
1
end_operator
begin_operator
board car1 loc3
1
47 22
2
0 0 0 1
0 6 22 32
1
end_operator
begin_operator
board car1 loc30
1
47 23
2
0 0 0 1
0 6 23 32
1
end_operator
begin_operator
board car1 loc31
1
47 24
2
0 0 0 1
0 6 24 32
1
end_operator
begin_operator
board car1 loc32
1
47 25
2
0 0 0 1
0 6 25 32
1
end_operator
begin_operator
board car1 loc4
1
47 26
2
0 0 0 1
0 6 26 32
1
end_operator
begin_operator
board car1 loc5
1
47 27
2
0 0 0 1
0 6 27 32
1
end_operator
begin_operator
board car1 loc6
1
47 28
2
0 0 0 1
0 6 28 32
1
end_operator
begin_operator
board car1 loc7
1
47 29
2
0 0 0 1
0 6 29 32
1
end_operator
begin_operator
board car1 loc8
1
47 30
2
0 0 0 1
0 6 30 32
1
end_operator
begin_operator
board car1 loc9
1
47 31
2
0 0 0 1
0 6 31 32
1
end_operator
begin_operator
board car10 loc1
1
47 0
2
0 0 0 2
0 12 0 32
1
end_operator
begin_operator
board car10 loc10
1
47 1
2
0 0 0 2
0 12 1 32
1
end_operator
begin_operator
board car10 loc11
1
47 2
2
0 0 0 2
0 12 2 32
1
end_operator
begin_operator
board car10 loc12
1
47 3
2
0 0 0 2
0 12 3 32
1
end_operator
begin_operator
board car10 loc13
1
47 4
2
0 0 0 2
0 12 4 32
1
end_operator
begin_operator
board car10 loc14
1
47 5
2
0 0 0 2
0 12 5 32
1
end_operator
begin_operator
board car10 loc15
1
47 6
2
0 0 0 2
0 12 6 32
1
end_operator
begin_operator
board car10 loc16
1
47 7
2
0 0 0 2
0 12 7 32
1
end_operator
begin_operator
board car10 loc17
1
47 8
2
0 0 0 2
0 12 8 32
1
end_operator
begin_operator
board car10 loc18
1
47 9
2
0 0 0 2
0 12 9 32
1
end_operator
begin_operator
board car10 loc19
1
47 10
2
0 0 0 2
0 12 10 32
1
end_operator
begin_operator
board car10 loc2
1
47 11
2
0 0 0 2
0 12 11 32
1
end_operator
begin_operator
board car10 loc20
1
47 12
2
0 0 0 2
0 12 12 32
1
end_operator
begin_operator
board car10 loc21
1
47 13
2
0 0 0 2
0 12 13 32
1
end_operator
begin_operator
board car10 loc22
1
47 14
2
0 0 0 2
0 12 14 32
1
end_operator
begin_operator
board car10 loc23
1
47 15
2
0 0 0 2
0 12 15 32
1
end_operator
begin_operator
board car10 loc24
1
47 16
2
0 0 0 2
0 12 16 32
1
end_operator
begin_operator
board car10 loc25
1
47 17
2
0 0 0 2
0 12 17 32
1
end_operator
begin_operator
board car10 loc26
1
47 18
2
0 0 0 2
0 12 18 32
1
end_operator
begin_operator
board car10 loc27
1
47 19
2
0 0 0 2
0 12 19 32
1
end_operator
begin_operator
board car10 loc28
1
47 20
2
0 0 0 2
0 12 20 32
1
end_operator
begin_operator
board car10 loc29
1
47 21
2
0 0 0 2
0 12 21 32
1
end_operator
begin_operator
board car10 loc3
1
47 22
2
0 0 0 2
0 12 22 32
1
end_operator
begin_operator
board car10 loc30
1
47 23
2
0 0 0 2
0 12 23 32
1
end_operator
begin_operator
board car10 loc31
1
47 24
2
0 0 0 2
0 12 24 32
1
end_operator
begin_operator
board car10 loc32
1
47 25
2
0 0 0 2
0 12 25 32
1
end_operator
begin_operator
board car10 loc4
1
47 26
2
0 0 0 2
0 12 26 32
1
end_operator
begin_operator
board car10 loc5
1
47 27
2
0 0 0 2
0 12 27 32
1
end_operator
begin_operator
board car10 loc6
1
47 28
2
0 0 0 2
0 12 28 32
1
end_operator
begin_operator
board car10 loc7
1
47 29
2
0 0 0 2
0 12 29 32
1
end_operator
begin_operator
board car10 loc8
1
47 30
2
0 0 0 2
0 12 30 32
1
end_operator
begin_operator
board car10 loc9
1
47 31
2
0 0 0 2
0 12 31 32
1
end_operator
begin_operator
board car11 loc1
1
47 0
2
0 0 0 3
0 18 0 32
1
end_operator
begin_operator
board car11 loc10
1
47 1
2
0 0 0 3
0 18 1 32
1
end_operator
begin_operator
board car11 loc11
1
47 2
2
0 0 0 3
0 18 2 32
1
end_operator
begin_operator
board car11 loc12
1
47 3
2
0 0 0 3
0 18 3 32
1
end_operator
begin_operator
board car11 loc13
1
47 4
2
0 0 0 3
0 18 4 32
1
end_operator
begin_operator
board car11 loc14
1
47 5
2
0 0 0 3
0 18 5 32
1
end_operator
begin_operator
board car11 loc15
1
47 6
2
0 0 0 3
0 18 6 32
1
end_operator
begin_operator
board car11 loc16
1
47 7
2
0 0 0 3
0 18 7 32
1
end_operator
begin_operator
board car11 loc17
1
47 8
2
0 0 0 3
0 18 8 32
1
end_operator
begin_operator
board car11 loc18
1
47 9
2
0 0 0 3
0 18 9 32
1
end_operator
begin_operator
board car11 loc19
1
47 10
2
0 0 0 3
0 18 10 32
1
end_operator
begin_operator
board car11 loc2
1
47 11
2
0 0 0 3
0 18 11 32
1
end_operator
begin_operator
board car11 loc20
1
47 12
2
0 0 0 3
0 18 12 32
1
end_operator
begin_operator
board car11 loc21
1
47 13
2
0 0 0 3
0 18 13 32
1
end_operator
begin_operator
board car11 loc22
1
47 14
2
0 0 0 3
0 18 14 32
1
end_operator
begin_operator
board car11 loc23
1
47 15
2
0 0 0 3
0 18 15 32
1
end_operator
begin_operator
board car11 loc24
1
47 16
2
0 0 0 3
0 18 16 32
1
end_operator
begin_operator
board car11 loc25
1
47 17
2
0 0 0 3
0 18 17 32
1
end_operator
begin_operator
board car11 loc26
1
47 18
2
0 0 0 3
0 18 18 32
1
end_operator
begin_operator
board car11 loc27
1
47 19
2
0 0 0 3
0 18 19 32
1
end_operator
begin_operator
board car11 loc28
1
47 20
2
0 0 0 3
0 18 20 32
1
end_operator
begin_operator
board car11 loc29
1
47 21
2
0 0 0 3
0 18 21 32
1
end_operator
begin_operator
board car11 loc3
1
47 22
2
0 0 0 3
0 18 22 32
1
end_operator
begin_operator
board car11 loc30
1
47 23
2
0 0 0 3
0 18 23 32
1
end_operator
begin_operator
board car11 loc31
1
47 24
2
0 0 0 3
0 18 24 32
1
end_operator
begin_operator
board car11 loc32
1
47 25
2
0 0 0 3
0 18 25 32
1
end_operator
begin_operator
board car11 loc4
1
47 26
2
0 0 0 3
0 18 26 32
1
end_operator
begin_operator
board car11 loc5
1
47 27
2
0 0 0 3
0 18 27 32
1
end_operator
begin_operator
board car11 loc6
1
47 28
2
0 0 0 3
0 18 28 32
1
end_operator
begin_operator
board car11 loc7
1
47 29
2
0 0 0 3
0 18 29 32
1
end_operator
begin_operator
board car11 loc8
1
47 30
2
0 0 0 3
0 18 30 32
1
end_operator
begin_operator
board car11 loc9
1
47 31
2
0 0 0 3
0 18 31 32
1
end_operator
begin_operator
board car12 loc1
1
47 0
2
0 0 0 4
0 24 0 32
1
end_operator
begin_operator
board car12 loc10
1
47 1
2
0 0 0 4
0 24 1 32
1
end_operator
begin_operator
board car12 loc11
1
47 2
2
0 0 0 4
0 24 2 32
1
end_operator
begin_operator
board car12 loc12
1
47 3
2
0 0 0 4
0 24 3 32
1
end_operator
begin_operator
board car12 loc13
1
47 4
2
0 0 0 4
0 24 4 32
1
end_operator
begin_operator
board car12 loc14
1
47 5
2
0 0 0 4
0 24 5 32
1
end_operator
begin_operator
board car12 loc15
1
47 6
2
0 0 0 4
0 24 6 32
1
end_operator
begin_operator
board car12 loc16
1
47 7
2
0 0 0 4
0 24 7 32
1
end_operator
begin_operator
board car12 loc17
1
47 8
2
0 0 0 4
0 24 8 32
1
end_operator
begin_operator
board car12 loc18
1
47 9
2
0 0 0 4
0 24 9 32
1
end_operator
begin_operator
board car12 loc19
1
47 10
2
0 0 0 4
0 24 10 32
1
end_operator
begin_operator
board car12 loc2
1
47 11
2
0 0 0 4
0 24 11 32
1
end_operator
begin_operator
board car12 loc20
1
47 12
2
0 0 0 4
0 24 12 32
1
end_operator
begin_operator
board car12 loc21
1
47 13
2
0 0 0 4
0 24 13 32
1
end_operator
begin_operator
board car12 loc22
1
47 14
2
0 0 0 4
0 24 14 32
1
end_operator
begin_operator
board car12 loc23
1
47 15
2
0 0 0 4
0 24 15 32
1
end_operator
begin_operator
board car12 loc24
1
47 16
2
0 0 0 4
0 24 16 32
1
end_operator
begin_operator
board car12 loc25
1
47 17
2
0 0 0 4
0 24 17 32
1
end_operator
begin_operator
board car12 loc26
1
47 18
2
0 0 0 4
0 24 18 32
1
end_operator
begin_operator
board car12 loc27
1
47 19
2
0 0 0 4
0 24 19 32
1
end_operator
begin_operator
board car12 loc28
1
47 20
2
0 0 0 4
0 24 20 32
1
end_operator
begin_operator
board car12 loc29
1
47 21
2
0 0 0 4
0 24 21 32
1
end_operator
begin_operator
board car12 loc3
1
47 22
2
0 0 0 4
0 24 22 32
1
end_operator
begin_operator
board car12 loc30
1
47 23
2
0 0 0 4
0 24 23 32
1
end_operator
begin_operator
board car12 loc31
1
47 24
2
0 0 0 4
0 24 24 32
1
end_operator
begin_operator
board car12 loc32
1
47 25
2
0 0 0 4
0 24 25 32
1
end_operator
begin_operator
board car12 loc4
1
47 26
2
0 0 0 4
0 24 26 32
1
end_operator
begin_operator
board car12 loc5
1
47 27
2
0 0 0 4
0 24 27 32
1
end_operator
begin_operator
board car12 loc6
1
47 28
2
0 0 0 4
0 24 28 32
1
end_operator
begin_operator
board car12 loc7
1
47 29
2
0 0 0 4
0 24 29 32
1
end_operator
begin_operator
board car12 loc8
1
47 30
2
0 0 0 4
0 24 30 32
1
end_operator
begin_operator
board car12 loc9
1
47 31
2
0 0 0 4
0 24 31 32
1
end_operator
begin_operator
board car13 loc1
1
47 0
2
0 0 0 5
0 30 0 32
1
end_operator
begin_operator
board car13 loc10
1
47 1
2
0 0 0 5
0 30 1 32
1
end_operator
begin_operator
board car13 loc11
1
47 2
2
0 0 0 5
0 30 2 32
1
end_operator
begin_operator
board car13 loc12
1
47 3
2
0 0 0 5
0 30 3 32
1
end_operator
begin_operator
board car13 loc13
1
47 4
2
0 0 0 5
0 30 4 32
1
end_operator
begin_operator
board car13 loc14
1
47 5
2
0 0 0 5
0 30 5 32
1
end_operator
begin_operator
board car13 loc15
1
47 6
2
0 0 0 5
0 30 6 32
1
end_operator
begin_operator
board car13 loc16
1
47 7
2
0 0 0 5
0 30 7 32
1
end_operator
begin_operator
board car13 loc17
1
47 8
2
0 0 0 5
0 30 8 32
1
end_operator
begin_operator
board car13 loc18
1
47 9
2
0 0 0 5
0 30 9 32
1
end_operator
begin_operator
board car13 loc19
1
47 10
2
0 0 0 5
0 30 10 32
1
end_operator
begin_operator
board car13 loc2
1
47 11
2
0 0 0 5
0 30 11 32
1
end_operator
begin_operator
board car13 loc20
1
47 12
2
0 0 0 5
0 30 12 32
1
end_operator
begin_operator
board car13 loc21
1
47 13
2
0 0 0 5
0 30 13 32
1
end_operator
begin_operator
board car13 loc22
1
47 14
2
0 0 0 5
0 30 14 32
1
end_operator
begin_operator
board car13 loc23
1
47 15
2
0 0 0 5
0 30 15 32
1
end_operator
begin_operator
board car13 loc24
1
47 16
2
0 0 0 5
0 30 16 32
1
end_operator
begin_operator
board car13 loc25
1
47 17
2
0 0 0 5
0 30 17 32
1
end_operator
begin_operator
board car13 loc26
1
47 18
2
0 0 0 5
0 30 18 32
1
end_operator
begin_operator
board car13 loc27
1
47 19
2
0 0 0 5
0 30 19 32
1
end_operator
begin_operator
board car13 loc28
1
47 20
2
0 0 0 5
0 30 20 32
1
end_operator
begin_operator
board car13 loc29
1
47 21
2
0 0 0 5
0 30 21 32
1
end_operator
begin_operator
board car13 loc3
1
47 22
2
0 0 0 5
0 30 22 32
1
end_operator
begin_operator
board car13 loc30
1
47 23
2
0 0 0 5
0 30 23 32
1
end_operator
begin_operator
board car13 loc31
1
47 24
2
0 0 0 5
0 30 24 32
1
end_operator
begin_operator
board car13 loc32
1
47 25
2
0 0 0 5
0 30 25 32
1
end_operator
begin_operator
board car13 loc4
1
47 26
2
0 0 0 5
0 30 26 32
1
end_operator
begin_operator
board car13 loc5
1
47 27
2
0 0 0 5
0 30 27 32
1
end_operator
begin_operator
board car13 loc6
1
47 28
2
0 0 0 5
0 30 28 32
1
end_operator
begin_operator
board car13 loc7
1
47 29
2
0 0 0 5
0 30 29 32
1
end_operator
begin_operator
board car13 loc8
1
47 30
2
0 0 0 5
0 30 30 32
1
end_operator
begin_operator
board car13 loc9
1
47 31
2
0 0 0 5
0 30 31 32
1
end_operator
begin_operator
board car14 loc1
1
47 0
2
0 0 0 6
0 36 0 32
1
end_operator
begin_operator
board car14 loc10
1
47 1
2
0 0 0 6
0 36 1 32
1
end_operator
begin_operator
board car14 loc11
1
47 2
2
0 0 0 6
0 36 2 32
1
end_operator
begin_operator
board car14 loc12
1
47 3
2
0 0 0 6
0 36 3 32
1
end_operator
begin_operator
board car14 loc13
1
47 4
2
0 0 0 6
0 36 4 32
1
end_operator
begin_operator
board car14 loc14
1
47 5
2
0 0 0 6
0 36 5 32
1
end_operator
begin_operator
board car14 loc15
1
47 6
2
0 0 0 6
0 36 6 32
1
end_operator
begin_operator
board car14 loc16
1
47 7
2
0 0 0 6
0 36 7 32
1
end_operator
begin_operator
board car14 loc17
1
47 8
2
0 0 0 6
0 36 8 32
1
end_operator
begin_operator
board car14 loc18
1
47 9
2
0 0 0 6
0 36 9 32
1
end_operator
begin_operator
board car14 loc19
1
47 10
2
0 0 0 6
0 36 10 32
1
end_operator
begin_operator
board car14 loc2
1
47 11
2
0 0 0 6
0 36 11 32
1
end_operator
begin_operator
board car14 loc20
1
47 12
2
0 0 0 6
0 36 12 32
1
end_operator
begin_operator
board car14 loc21
1
47 13
2
0 0 0 6
0 36 13 32
1
end_operator
begin_operator
board car14 loc22
1
47 14
2
0 0 0 6
0 36 14 32
1
end_operator
begin_operator
board car14 loc23
1
47 15
2
0 0 0 6
0 36 15 32
1
end_operator
begin_operator
board car14 loc24
1
47 16
2
0 0 0 6
0 36 16 32
1
end_operator
begin_operator
board car14 loc25
1
47 17
2
0 0 0 6
0 36 17 32
1
end_operator
begin_operator
board car14 loc26
1
47 18
2
0 0 0 6
0 36 18 32
1
end_operator
begin_operator
board car14 loc27
1
47 19
2
0 0 0 6
0 36 19 32
1
end_operator
begin_operator
board car14 loc28
1
47 20
2
0 0 0 6
0 36 20 32
1
end_operator
begin_operator
board car14 loc29
1
47 21
2
0 0 0 6
0 36 21 32
1
end_operator
begin_operator
board car14 loc3
1
47 22
2
0 0 0 6
0 36 22 32
1
end_operator
begin_operator
board car14 loc30
1
47 23
2
0 0 0 6
0 36 23 32
1
end_operator
begin_operator
board car14 loc31
1
47 24
2
0 0 0 6
0 36 24 32
1
end_operator
begin_operator
board car14 loc32
1
47 25
2
0 0 0 6
0 36 25 32
1
end_operator
begin_operator
board car14 loc4
1
47 26
2
0 0 0 6
0 36 26 32
1
end_operator
begin_operator
board car14 loc5
1
47 27
2
0 0 0 6
0 36 27 32
1
end_operator
begin_operator
board car14 loc6
1
47 28
2
0 0 0 6
0 36 28 32
1
end_operator
begin_operator
board car14 loc7
1
47 29
2
0 0 0 6
0 36 29 32
1
end_operator
begin_operator
board car14 loc8
1
47 30
2
0 0 0 6
0 36 30 32
1
end_operator
begin_operator
board car14 loc9
1
47 31
2
0 0 0 6
0 36 31 32
1
end_operator
begin_operator
board car15 loc1
1
47 0
2
0 0 0 7
0 42 0 32
1
end_operator
begin_operator
board car15 loc10
1
47 1
2
0 0 0 7
0 42 1 32
1
end_operator
begin_operator
board car15 loc11
1
47 2
2
0 0 0 7
0 42 2 32
1
end_operator
begin_operator
board car15 loc12
1
47 3
2
0 0 0 7
0 42 3 32
1
end_operator
begin_operator
board car15 loc13
1
47 4
2
0 0 0 7
0 42 4 32
1
end_operator
begin_operator
board car15 loc14
1
47 5
2
0 0 0 7
0 42 5 32
1
end_operator
begin_operator
board car15 loc15
1
47 6
2
0 0 0 7
0 42 6 32
1
end_operator
begin_operator
board car15 loc16
1
47 7
2
0 0 0 7
0 42 7 32
1
end_operator
begin_operator
board car15 loc17
1
47 8
2
0 0 0 7
0 42 8 32
1
end_operator
begin_operator
board car15 loc18
1
47 9
2
0 0 0 7
0 42 9 32
1
end_operator
begin_operator
board car15 loc19
1
47 10
2
0 0 0 7
0 42 10 32
1
end_operator
begin_operator
board car15 loc2
1
47 11
2
0 0 0 7
0 42 11 32
1
end_operator
begin_operator
board car15 loc20
1
47 12
2
0 0 0 7
0 42 12 32
1
end_operator
begin_operator
board car15 loc21
1
47 13
2
0 0 0 7
0 42 13 32
1
end_operator
begin_operator
board car15 loc22
1
47 14
2
0 0 0 7
0 42 14 32
1
end_operator
begin_operator
board car15 loc23
1
47 15
2
0 0 0 7
0 42 15 32
1
end_operator
begin_operator
board car15 loc24
1
47 16
2
0 0 0 7
0 42 16 32
1
end_operator
begin_operator
board car15 loc25
1
47 17
2
0 0 0 7
0 42 17 32
1
end_operator
begin_operator
board car15 loc26
1
47 18
2
0 0 0 7
0 42 18 32
1
end_operator
begin_operator
board car15 loc27
1
47 19
2
0 0 0 7
0 42 19 32
1
end_operator
begin_operator
board car15 loc28
1
47 20
2
0 0 0 7
0 42 20 32
1
end_operator
begin_operator
board car15 loc29
1
47 21
2
0 0 0 7
0 42 21 32
1
end_operator
begin_operator
board car15 loc3
1
47 22
2
0 0 0 7
0 42 22 32
1
end_operator
begin_operator
board car15 loc30
1
47 23
2
0 0 0 7
0 42 23 32
1
end_operator
begin_operator
board car15 loc31
1
47 24
2
0 0 0 7
0 42 24 32
1
end_operator
begin_operator
board car15 loc32
1
47 25
2
0 0 0 7
0 42 25 32
1
end_operator
begin_operator
board car15 loc4
1
47 26
2
0 0 0 7
0 42 26 32
1
end_operator
begin_operator
board car15 loc5
1
47 27
2
0 0 0 7
0 42 27 32
1
end_operator
begin_operator
board car15 loc6
1
47 28
2
0 0 0 7
0 42 28 32
1
end_operator
begin_operator
board car15 loc7
1
47 29
2
0 0 0 7
0 42 29 32
1
end_operator
begin_operator
board car15 loc8
1
47 30
2
0 0 0 7
0 42 30 32
1
end_operator
begin_operator
board car15 loc9
1
47 31
2
0 0 0 7
0 42 31 32
1
end_operator
begin_operator
board car16 loc1
1
47 0
2
0 0 0 8
0 1 0 32
1
end_operator
begin_operator
board car16 loc10
1
47 1
2
0 0 0 8
0 1 1 32
1
end_operator
begin_operator
board car16 loc11
1
47 2
2
0 0 0 8
0 1 2 32
1
end_operator
begin_operator
board car16 loc12
1
47 3
2
0 0 0 8
0 1 3 32
1
end_operator
begin_operator
board car16 loc13
1
47 4
2
0 0 0 8
0 1 4 32
1
end_operator
begin_operator
board car16 loc14
1
47 5
2
0 0 0 8
0 1 5 32
1
end_operator
begin_operator
board car16 loc15
1
47 6
2
0 0 0 8
0 1 6 32
1
end_operator
begin_operator
board car16 loc16
1
47 7
2
0 0 0 8
0 1 7 32
1
end_operator
begin_operator
board car16 loc17
1
47 8
2
0 0 0 8
0 1 8 32
1
end_operator
begin_operator
board car16 loc18
1
47 9
2
0 0 0 8
0 1 9 32
1
end_operator
begin_operator
board car16 loc19
1
47 10
2
0 0 0 8
0 1 10 32
1
end_operator
begin_operator
board car16 loc2
1
47 11
2
0 0 0 8
0 1 11 32
1
end_operator
begin_operator
board car16 loc20
1
47 12
2
0 0 0 8
0 1 12 32
1
end_operator
begin_operator
board car16 loc21
1
47 13
2
0 0 0 8
0 1 13 32
1
end_operator
begin_operator
board car16 loc22
1
47 14
2
0 0 0 8
0 1 14 32
1
end_operator
begin_operator
board car16 loc23
1
47 15
2
0 0 0 8
0 1 15 32
1
end_operator
begin_operator
board car16 loc24
1
47 16
2
0 0 0 8
0 1 16 32
1
end_operator
begin_operator
board car16 loc25
1
47 17
2
0 0 0 8
0 1 17 32
1
end_operator
begin_operator
board car16 loc26
1
47 18
2
0 0 0 8
0 1 18 32
1
end_operator
begin_operator
board car16 loc27
1
47 19
2
0 0 0 8
0 1 19 32
1
end_operator
begin_operator
board car16 loc28
1
47 20
2
0 0 0 8
0 1 20 32
1
end_operator
begin_operator
board car16 loc29
1
47 21
2
0 0 0 8
0 1 21 32
1
end_operator
begin_operator
board car16 loc3
1
47 22
2
0 0 0 8
0 1 22 32
1
end_operator
begin_operator
board car16 loc30
1
47 23
2
0 0 0 8
0 1 23 32
1
end_operator
begin_operator
board car16 loc31
1
47 24
2
0 0 0 8
0 1 24 32
1
end_operator
begin_operator
board car16 loc32
1
47 25
2
0 0 0 8
0 1 25 32
1
end_operator
begin_operator
board car16 loc4
1
47 26
2
0 0 0 8
0 1 26 32
1
end_operator
begin_operator
board car16 loc5
1
47 27
2
0 0 0 8
0 1 27 32
1
end_operator
begin_operator
board car16 loc6
1
47 28
2
0 0 0 8
0 1 28 32
1
end_operator
begin_operator
board car16 loc7
1
47 29
2
0 0 0 8
0 1 29 32
1
end_operator
begin_operator
board car16 loc8
1
47 30
2
0 0 0 8
0 1 30 32
1
end_operator
begin_operator
board car16 loc9
1
47 31
2
0 0 0 8
0 1 31 32
1
end_operator
begin_operator
board car17 loc1
1
47 0
2
0 0 0 9
0 7 0 32
1
end_operator
begin_operator
board car17 loc10
1
47 1
2
0 0 0 9
0 7 1 32
1
end_operator
begin_operator
board car17 loc11
1
47 2
2
0 0 0 9
0 7 2 32
1
end_operator
begin_operator
board car17 loc12
1
47 3
2
0 0 0 9
0 7 3 32
1
end_operator
begin_operator
board car17 loc13
1
47 4
2
0 0 0 9
0 7 4 32
1
end_operator
begin_operator
board car17 loc14
1
47 5
2
0 0 0 9
0 7 5 32
1
end_operator
begin_operator
board car17 loc15
1
47 6
2
0 0 0 9
0 7 6 32
1
end_operator
begin_operator
board car17 loc16
1
47 7
2
0 0 0 9
0 7 7 32
1
end_operator
begin_operator
board car17 loc17
1
47 8
2
0 0 0 9
0 7 8 32
1
end_operator
begin_operator
board car17 loc18
1
47 9
2
0 0 0 9
0 7 9 32
1
end_operator
begin_operator
board car17 loc19
1
47 10
2
0 0 0 9
0 7 10 32
1
end_operator
begin_operator
board car17 loc2
1
47 11
2
0 0 0 9
0 7 11 32
1
end_operator
begin_operator
board car17 loc20
1
47 12
2
0 0 0 9
0 7 12 32
1
end_operator
begin_operator
board car17 loc21
1
47 13
2
0 0 0 9
0 7 13 32
1
end_operator
begin_operator
board car17 loc22
1
47 14
2
0 0 0 9
0 7 14 32
1
end_operator
begin_operator
board car17 loc23
1
47 15
2
0 0 0 9
0 7 15 32
1
end_operator
begin_operator
board car17 loc24
1
47 16
2
0 0 0 9
0 7 16 32
1
end_operator
begin_operator
board car17 loc25
1
47 17
2
0 0 0 9
0 7 17 32
1
end_operator
begin_operator
board car17 loc26
1
47 18
2
0 0 0 9
0 7 18 32
1
end_operator
begin_operator
board car17 loc27
1
47 19
2
0 0 0 9
0 7 19 32
1
end_operator
begin_operator
board car17 loc28
1
47 20
2
0 0 0 9
0 7 20 32
1
end_operator
begin_operator
board car17 loc29
1
47 21
2
0 0 0 9
0 7 21 32
1
end_operator
begin_operator
board car17 loc3
1
47 22
2
0 0 0 9
0 7 22 32
1
end_operator
begin_operator
board car17 loc30
1
47 23
2
0 0 0 9
0 7 23 32
1
end_operator
begin_operator
board car17 loc31
1
47 24
2
0 0 0 9
0 7 24 32
1
end_operator
begin_operator
board car17 loc32
1
47 25
2
0 0 0 9
0 7 25 32
1
end_operator
begin_operator
board car17 loc4
1
47 26
2
0 0 0 9
0 7 26 32
1
end_operator
begin_operator
board car17 loc5
1
47 27
2
0 0 0 9
0 7 27 32
1
end_operator
begin_operator
board car17 loc6
1
47 28
2
0 0 0 9
0 7 28 32
1
end_operator
begin_operator
board car17 loc7
1
47 29
2
0 0 0 9
0 7 29 32
1
end_operator
begin_operator
board car17 loc8
1
47 30
2
0 0 0 9
0 7 30 32
1
end_operator
begin_operator
board car17 loc9
1
47 31
2
0 0 0 9
0 7 31 32
1
end_operator
begin_operator
board car18 loc1
1
47 0
2
0 0 0 10
0 13 0 32
1
end_operator
begin_operator
board car18 loc10
1
47 1
2
0 0 0 10
0 13 1 32
1
end_operator
begin_operator
board car18 loc11
1
47 2
2
0 0 0 10
0 13 2 32
1
end_operator
begin_operator
board car18 loc12
1
47 3
2
0 0 0 10
0 13 3 32
1
end_operator
begin_operator
board car18 loc13
1
47 4
2
0 0 0 10
0 13 4 32
1
end_operator
begin_operator
board car18 loc14
1
47 5
2
0 0 0 10
0 13 5 32
1
end_operator
begin_operator
board car18 loc15
1
47 6
2
0 0 0 10
0 13 6 32
1
end_operator
begin_operator
board car18 loc16
1
47 7
2
0 0 0 10
0 13 7 32
1
end_operator
begin_operator
board car18 loc17
1
47 8
2
0 0 0 10
0 13 8 32
1
end_operator
begin_operator
board car18 loc18
1
47 9
2
0 0 0 10
0 13 9 32
1
end_operator
begin_operator
board car18 loc19
1
47 10
2
0 0 0 10
0 13 10 32
1
end_operator
begin_operator
board car18 loc2
1
47 11
2
0 0 0 10
0 13 11 32
1
end_operator
begin_operator
board car18 loc20
1
47 12
2
0 0 0 10
0 13 12 32
1
end_operator
begin_operator
board car18 loc21
1
47 13
2
0 0 0 10
0 13 13 32
1
end_operator
begin_operator
board car18 loc22
1
47 14
2
0 0 0 10
0 13 14 32
1
end_operator
begin_operator
board car18 loc23
1
47 15
2
0 0 0 10
0 13 15 32
1
end_operator
begin_operator
board car18 loc24
1
47 16
2
0 0 0 10
0 13 16 32
1
end_operator
begin_operator
board car18 loc25
1
47 17
2
0 0 0 10
0 13 17 32
1
end_operator
begin_operator
board car18 loc26
1
47 18
2
0 0 0 10
0 13 18 32
1
end_operator
begin_operator
board car18 loc27
1
47 19
2
0 0 0 10
0 13 19 32
1
end_operator
begin_operator
board car18 loc28
1
47 20
2
0 0 0 10
0 13 20 32
1
end_operator
begin_operator
board car18 loc29
1
47 21
2
0 0 0 10
0 13 21 32
1
end_operator
begin_operator
board car18 loc3
1
47 22
2
0 0 0 10
0 13 22 32
1
end_operator
begin_operator
board car18 loc30
1
47 23
2
0 0 0 10
0 13 23 32
1
end_operator
begin_operator
board car18 loc31
1
47 24
2
0 0 0 10
0 13 24 32
1
end_operator
begin_operator
board car18 loc32
1
47 25
2
0 0 0 10
0 13 25 32
1
end_operator
begin_operator
board car18 loc4
1
47 26
2
0 0 0 10
0 13 26 32
1
end_operator
begin_operator
board car18 loc5
1
47 27
2
0 0 0 10
0 13 27 32
1
end_operator
begin_operator
board car18 loc6
1
47 28
2
0 0 0 10
0 13 28 32
1
end_operator
begin_operator
board car18 loc7
1
47 29
2
0 0 0 10
0 13 29 32
1
end_operator
begin_operator
board car18 loc8
1
47 30
2
0 0 0 10
0 13 30 32
1
end_operator
begin_operator
board car18 loc9
1
47 31
2
0 0 0 10
0 13 31 32
1
end_operator
begin_operator
board car19 loc1
1
47 0
2
0 0 0 11
0 19 0 32
1
end_operator
begin_operator
board car19 loc10
1
47 1
2
0 0 0 11
0 19 1 32
1
end_operator
begin_operator
board car19 loc11
1
47 2
2
0 0 0 11
0 19 2 32
1
end_operator
begin_operator
board car19 loc12
1
47 3
2
0 0 0 11
0 19 3 32
1
end_operator
begin_operator
board car19 loc13
1
47 4
2
0 0 0 11
0 19 4 32
1
end_operator
begin_operator
board car19 loc14
1
47 5
2
0 0 0 11
0 19 5 32
1
end_operator
begin_operator
board car19 loc15
1
47 6
2
0 0 0 11
0 19 6 32
1
end_operator
begin_operator
board car19 loc16
1
47 7
2
0 0 0 11
0 19 7 32
1
end_operator
begin_operator
board car19 loc17
1
47 8
2
0 0 0 11
0 19 8 32
1
end_operator
begin_operator
board car19 loc18
1
47 9
2
0 0 0 11
0 19 9 32
1
end_operator
begin_operator
board car19 loc19
1
47 10
2
0 0 0 11
0 19 10 32
1
end_operator
begin_operator
board car19 loc2
1
47 11
2
0 0 0 11
0 19 11 32
1
end_operator
begin_operator
board car19 loc20
1
47 12
2
0 0 0 11
0 19 12 32
1
end_operator
begin_operator
board car19 loc21
1
47 13
2
0 0 0 11
0 19 13 32
1
end_operator
begin_operator
board car19 loc22
1
47 14
2
0 0 0 11
0 19 14 32
1
end_operator
begin_operator
board car19 loc23
1
47 15
2
0 0 0 11
0 19 15 32
1
end_operator
begin_operator
board car19 loc24
1
47 16
2
0 0 0 11
0 19 16 32
1
end_operator
begin_operator
board car19 loc25
1
47 17
2
0 0 0 11
0 19 17 32
1
end_operator
begin_operator
board car19 loc26
1
47 18
2
0 0 0 11
0 19 18 32
1
end_operator
begin_operator
board car19 loc27
1
47 19
2
0 0 0 11
0 19 19 32
1
end_operator
begin_operator
board car19 loc28
1
47 20
2
0 0 0 11
0 19 20 32
1
end_operator
begin_operator
board car19 loc29
1
47 21
2
0 0 0 11
0 19 21 32
1
end_operator
begin_operator
board car19 loc3
1
47 22
2
0 0 0 11
0 19 22 32
1
end_operator
begin_operator
board car19 loc30
1
47 23
2
0 0 0 11
0 19 23 32
1
end_operator
begin_operator
board car19 loc31
1
47 24
2
0 0 0 11
0 19 24 32
1
end_operator
begin_operator
board car19 loc32
1
47 25
2
0 0 0 11
0 19 25 32
1
end_operator
begin_operator
board car19 loc4
1
47 26
2
0 0 0 11
0 19 26 32
1
end_operator
begin_operator
board car19 loc5
1
47 27
2
0 0 0 11
0 19 27 32
1
end_operator
begin_operator
board car19 loc6
1
47 28
2
0 0 0 11
0 19 28 32
1
end_operator
begin_operator
board car19 loc7
1
47 29
2
0 0 0 11
0 19 29 32
1
end_operator
begin_operator
board car19 loc8
1
47 30
2
0 0 0 11
0 19 30 32
1
end_operator
begin_operator
board car19 loc9
1
47 31
2
0 0 0 11
0 19 31 32
1
end_operator
begin_operator
board car2 loc1
1
47 0
2
0 0 0 12
0 25 0 32
1
end_operator
begin_operator
board car2 loc10
1
47 1
2
0 0 0 12
0 25 1 32
1
end_operator
begin_operator
board car2 loc11
1
47 2
2
0 0 0 12
0 25 2 32
1
end_operator
begin_operator
board car2 loc12
1
47 3
2
0 0 0 12
0 25 3 32
1
end_operator
begin_operator
board car2 loc13
1
47 4
2
0 0 0 12
0 25 4 32
1
end_operator
begin_operator
board car2 loc14
1
47 5
2
0 0 0 12
0 25 5 32
1
end_operator
begin_operator
board car2 loc15
1
47 6
2
0 0 0 12
0 25 6 32
1
end_operator
begin_operator
board car2 loc16
1
47 7
2
0 0 0 12
0 25 7 32
1
end_operator
begin_operator
board car2 loc17
1
47 8
2
0 0 0 12
0 25 8 32
1
end_operator
begin_operator
board car2 loc18
1
47 9
2
0 0 0 12
0 25 9 32
1
end_operator
begin_operator
board car2 loc19
1
47 10
2
0 0 0 12
0 25 10 32
1
end_operator
begin_operator
board car2 loc2
1
47 11
2
0 0 0 12
0 25 11 32
1
end_operator
begin_operator
board car2 loc20
1
47 12
2
0 0 0 12
0 25 12 32
1
end_operator
begin_operator
board car2 loc21
1
47 13
2
0 0 0 12
0 25 13 32
1
end_operator
begin_operator
board car2 loc22
1
47 14
2
0 0 0 12
0 25 14 32
1
end_operator
begin_operator
board car2 loc23
1
47 15
2
0 0 0 12
0 25 15 32
1
end_operator
begin_operator
board car2 loc24
1
47 16
2
0 0 0 12
0 25 16 32
1
end_operator
begin_operator
board car2 loc25
1
47 17
2
0 0 0 12
0 25 17 32
1
end_operator
begin_operator
board car2 loc26
1
47 18
2
0 0 0 12
0 25 18 32
1
end_operator
begin_operator
board car2 loc27
1
47 19
2
0 0 0 12
0 25 19 32
1
end_operator
begin_operator
board car2 loc28
1
47 20
2
0 0 0 12
0 25 20 32
1
end_operator
begin_operator
board car2 loc29
1
47 21
2
0 0 0 12
0 25 21 32
1
end_operator
begin_operator
board car2 loc3
1
47 22
2
0 0 0 12
0 25 22 32
1
end_operator
begin_operator
board car2 loc30
1
47 23
2
0 0 0 12
0 25 23 32
1
end_operator
begin_operator
board car2 loc31
1
47 24
2
0 0 0 12
0 25 24 32
1
end_operator
begin_operator
board car2 loc32
1
47 25
2
0 0 0 12
0 25 25 32
1
end_operator
begin_operator
board car2 loc4
1
47 26
2
0 0 0 12
0 25 26 32
1
end_operator
begin_operator
board car2 loc5
1
47 27
2
0 0 0 12
0 25 27 32
1
end_operator
begin_operator
board car2 loc6
1
47 28
2
0 0 0 12
0 25 28 32
1
end_operator
begin_operator
board car2 loc7
1
47 29
2
0 0 0 12
0 25 29 32
1
end_operator
begin_operator
board car2 loc8
1
47 30
2
0 0 0 12
0 25 30 32
1
end_operator
begin_operator
board car2 loc9
1
47 31
2
0 0 0 12
0 25 31 32
1
end_operator
begin_operator
board car20 loc1
1
47 0
2
0 0 0 13
0 31 0 32
1
end_operator
begin_operator
board car20 loc10
1
47 1
2
0 0 0 13
0 31 1 32
1
end_operator
begin_operator
board car20 loc11
1
47 2
2
0 0 0 13
0 31 2 32
1
end_operator
begin_operator
board car20 loc12
1
47 3
2
0 0 0 13
0 31 3 32
1
end_operator
begin_operator
board car20 loc13
1
47 4
2
0 0 0 13
0 31 4 32
1
end_operator
begin_operator
board car20 loc14
1
47 5
2
0 0 0 13
0 31 5 32
1
end_operator
begin_operator
board car20 loc15
1
47 6
2
0 0 0 13
0 31 6 32
1
end_operator
begin_operator
board car20 loc16
1
47 7
2
0 0 0 13
0 31 7 32
1
end_operator
begin_operator
board car20 loc17
1
47 8
2
0 0 0 13
0 31 8 32
1
end_operator
begin_operator
board car20 loc18
1
47 9
2
0 0 0 13
0 31 9 32
1
end_operator
begin_operator
board car20 loc19
1
47 10
2
0 0 0 13
0 31 10 32
1
end_operator
begin_operator
board car20 loc2
1
47 11
2
0 0 0 13
0 31 11 32
1
end_operator
begin_operator
board car20 loc20
1
47 12
2
0 0 0 13
0 31 12 32
1
end_operator
begin_operator
board car20 loc21
1
47 13
2
0 0 0 13
0 31 13 32
1
end_operator
begin_operator
board car20 loc22
1
47 14
2
0 0 0 13
0 31 14 32
1
end_operator
begin_operator
board car20 loc23
1
47 15
2
0 0 0 13
0 31 15 32
1
end_operator
begin_operator
board car20 loc24
1
47 16
2
0 0 0 13
0 31 16 32
1
end_operator
begin_operator
board car20 loc25
1
47 17
2
0 0 0 13
0 31 17 32
1
end_operator
begin_operator
board car20 loc26
1
47 18
2
0 0 0 13
0 31 18 32
1
end_operator
begin_operator
board car20 loc27
1
47 19
2
0 0 0 13
0 31 19 32
1
end_operator
begin_operator
board car20 loc28
1
47 20
2
0 0 0 13
0 31 20 32
1
end_operator
begin_operator
board car20 loc29
1
47 21
2
0 0 0 13
0 31 21 32
1
end_operator
begin_operator
board car20 loc3
1
47 22
2
0 0 0 13
0 31 22 32
1
end_operator
begin_operator
board car20 loc30
1
47 23
2
0 0 0 13
0 31 23 32
1
end_operator
begin_operator
board car20 loc31
1
47 24
2
0 0 0 13
0 31 24 32
1
end_operator
begin_operator
board car20 loc32
1
47 25
2
0 0 0 13
0 31 25 32
1
end_operator
begin_operator
board car20 loc4
1
47 26
2
0 0 0 13
0 31 26 32
1
end_operator
begin_operator
board car20 loc5
1
47 27
2
0 0 0 13
0 31 27 32
1
end_operator
begin_operator
board car20 loc6
1
47 28
2
0 0 0 13
0 31 28 32
1
end_operator
begin_operator
board car20 loc7
1
47 29
2
0 0 0 13
0 31 29 32
1
end_operator
begin_operator
board car20 loc8
1
47 30
2
0 0 0 13
0 31 30 32
1
end_operator
begin_operator
board car20 loc9
1
47 31
2
0 0 0 13
0 31 31 32
1
end_operator
begin_operator
board car21 loc1
1
47 0
2
0 0 0 14
0 37 0 32
1
end_operator
begin_operator
board car21 loc10
1
47 1
2
0 0 0 14
0 37 1 32
1
end_operator
begin_operator
board car21 loc11
1
47 2
2
0 0 0 14
0 37 2 32
1
end_operator
begin_operator
board car21 loc12
1
47 3
2
0 0 0 14
0 37 3 32
1
end_operator
begin_operator
board car21 loc13
1
47 4
2
0 0 0 14
0 37 4 32
1
end_operator
begin_operator
board car21 loc14
1
47 5
2
0 0 0 14
0 37 5 32
1
end_operator
begin_operator
board car21 loc15
1
47 6
2
0 0 0 14
0 37 6 32
1
end_operator
begin_operator
board car21 loc16
1
47 7
2
0 0 0 14
0 37 7 32
1
end_operator
begin_operator
board car21 loc17
1
47 8
2
0 0 0 14
0 37 8 32
1
end_operator
begin_operator
board car21 loc18
1
47 9
2
0 0 0 14
0 37 9 32
1
end_operator
begin_operator
board car21 loc19
1
47 10
2
0 0 0 14
0 37 10 32
1
end_operator
begin_operator
board car21 loc2
1
47 11
2
0 0 0 14
0 37 11 32
1
end_operator
begin_operator
board car21 loc20
1
47 12
2
0 0 0 14
0 37 12 32
1
end_operator
begin_operator
board car21 loc21
1
47 13
2
0 0 0 14
0 37 13 32
1
end_operator
begin_operator
board car21 loc22
1
47 14
2
0 0 0 14
0 37 14 32
1
end_operator
begin_operator
board car21 loc23
1
47 15
2
0 0 0 14
0 37 15 32
1
end_operator
begin_operator
board car21 loc24
1
47 16
2
0 0 0 14
0 37 16 32
1
end_operator
begin_operator
board car21 loc25
1
47 17
2
0 0 0 14
0 37 17 32
1
end_operator
begin_operator
board car21 loc26
1
47 18
2
0 0 0 14
0 37 18 32
1
end_operator
begin_operator
board car21 loc27
1
47 19
2
0 0 0 14
0 37 19 32
1
end_operator
begin_operator
board car21 loc28
1
47 20
2
0 0 0 14
0 37 20 32
1
end_operator
begin_operator
board car21 loc29
1
47 21
2
0 0 0 14
0 37 21 32
1
end_operator
begin_operator
board car21 loc3
1
47 22
2
0 0 0 14
0 37 22 32
1
end_operator
begin_operator
board car21 loc30
1
47 23
2
0 0 0 14
0 37 23 32
1
end_operator
begin_operator
board car21 loc31
1
47 24
2
0 0 0 14
0 37 24 32
1
end_operator
begin_operator
board car21 loc32
1
47 25
2
0 0 0 14
0 37 25 32
1
end_operator
begin_operator
board car21 loc4
1
47 26
2
0 0 0 14
0 37 26 32
1
end_operator
begin_operator
board car21 loc5
1
47 27
2
0 0 0 14
0 37 27 32
1
end_operator
begin_operator
board car21 loc6
1
47 28
2
0 0 0 14
0 37 28 32
1
end_operator
begin_operator
board car21 loc7
1
47 29
2
0 0 0 14
0 37 29 32
1
end_operator
begin_operator
board car21 loc8
1
47 30
2
0 0 0 14
0 37 30 32
1
end_operator
begin_operator
board car21 loc9
1
47 31
2
0 0 0 14
0 37 31 32
1
end_operator
begin_operator
board car22 loc1
1
47 0
2
0 0 0 15
0 43 0 32
1
end_operator
begin_operator
board car22 loc10
1
47 1
2
0 0 0 15
0 43 1 32
1
end_operator
begin_operator
board car22 loc11
1
47 2
2
0 0 0 15
0 43 2 32
1
end_operator
begin_operator
board car22 loc12
1
47 3
2
0 0 0 15
0 43 3 32
1
end_operator
begin_operator
board car22 loc13
1
47 4
2
0 0 0 15
0 43 4 32
1
end_operator
begin_operator
board car22 loc14
1
47 5
2
0 0 0 15
0 43 5 32
1
end_operator
begin_operator
board car22 loc15
1
47 6
2
0 0 0 15
0 43 6 32
1
end_operator
begin_operator
board car22 loc16
1
47 7
2
0 0 0 15
0 43 7 32
1
end_operator
begin_operator
board car22 loc17
1
47 8
2
0 0 0 15
0 43 8 32
1
end_operator
begin_operator
board car22 loc18
1
47 9
2
0 0 0 15
0 43 9 32
1
end_operator
begin_operator
board car22 loc19
1
47 10
2
0 0 0 15
0 43 10 32
1
end_operator
begin_operator
board car22 loc2
1
47 11
2
0 0 0 15
0 43 11 32
1
end_operator
begin_operator
board car22 loc20
1
47 12
2
0 0 0 15
0 43 12 32
1
end_operator
begin_operator
board car22 loc21
1
47 13
2
0 0 0 15
0 43 13 32
1
end_operator
begin_operator
board car22 loc22
1
47 14
2
0 0 0 15
0 43 14 32
1
end_operator
begin_operator
board car22 loc23
1
47 15
2
0 0 0 15
0 43 15 32
1
end_operator
begin_operator
board car22 loc24
1
47 16
2
0 0 0 15
0 43 16 32
1
end_operator
begin_operator
board car22 loc25
1
47 17
2
0 0 0 15
0 43 17 32
1
end_operator
begin_operator
board car22 loc26
1
47 18
2
0 0 0 15
0 43 18 32
1
end_operator
begin_operator
board car22 loc27
1
47 19
2
0 0 0 15
0 43 19 32
1
end_operator
begin_operator
board car22 loc28
1
47 20
2
0 0 0 15
0 43 20 32
1
end_operator
begin_operator
board car22 loc29
1
47 21
2
0 0 0 15
0 43 21 32
1
end_operator
begin_operator
board car22 loc3
1
47 22
2
0 0 0 15
0 43 22 32
1
end_operator
begin_operator
board car22 loc30
1
47 23
2
0 0 0 15
0 43 23 32
1
end_operator
begin_operator
board car22 loc31
1
47 24
2
0 0 0 15
0 43 24 32
1
end_operator
begin_operator
board car22 loc32
1
47 25
2
0 0 0 15
0 43 25 32
1
end_operator
begin_operator
board car22 loc4
1
47 26
2
0 0 0 15
0 43 26 32
1
end_operator
begin_operator
board car22 loc5
1
47 27
2
0 0 0 15
0 43 27 32
1
end_operator
begin_operator
board car22 loc6
1
47 28
2
0 0 0 15
0 43 28 32
1
end_operator
begin_operator
board car22 loc7
1
47 29
2
0 0 0 15
0 43 29 32
1
end_operator
begin_operator
board car22 loc8
1
47 30
2
0 0 0 15
0 43 30 32
1
end_operator
begin_operator
board car22 loc9
1
47 31
2
0 0 0 15
0 43 31 32
1
end_operator
begin_operator
board car23 loc1
1
47 0
2
0 0 0 16
0 2 0 32
1
end_operator
begin_operator
board car23 loc10
1
47 1
2
0 0 0 16
0 2 1 32
1
end_operator
begin_operator
board car23 loc11
1
47 2
2
0 0 0 16
0 2 2 32
1
end_operator
begin_operator
board car23 loc12
1
47 3
2
0 0 0 16
0 2 3 32
1
end_operator
begin_operator
board car23 loc13
1
47 4
2
0 0 0 16
0 2 4 32
1
end_operator
begin_operator
board car23 loc14
1
47 5
2
0 0 0 16
0 2 5 32
1
end_operator
begin_operator
board car23 loc15
1
47 6
2
0 0 0 16
0 2 6 32
1
end_operator
begin_operator
board car23 loc16
1
47 7
2
0 0 0 16
0 2 7 32
1
end_operator
begin_operator
board car23 loc17
1
47 8
2
0 0 0 16
0 2 8 32
1
end_operator
begin_operator
board car23 loc18
1
47 9
2
0 0 0 16
0 2 9 32
1
end_operator
begin_operator
board car23 loc19
1
47 10
2
0 0 0 16
0 2 10 32
1
end_operator
begin_operator
board car23 loc2
1
47 11
2
0 0 0 16
0 2 11 32
1
end_operator
begin_operator
board car23 loc20
1
47 12
2
0 0 0 16
0 2 12 32
1
end_operator
begin_operator
board car23 loc21
1
47 13
2
0 0 0 16
0 2 13 32
1
end_operator
begin_operator
board car23 loc22
1
47 14
2
0 0 0 16
0 2 14 32
1
end_operator
begin_operator
board car23 loc23
1
47 15
2
0 0 0 16
0 2 15 32
1
end_operator
begin_operator
board car23 loc24
1
47 16
2
0 0 0 16
0 2 16 32
1
end_operator
begin_operator
board car23 loc25
1
47 17
2
0 0 0 16
0 2 17 32
1
end_operator
begin_operator
board car23 loc26
1
47 18
2
0 0 0 16
0 2 18 32
1
end_operator
begin_operator
board car23 loc27
1
47 19
2
0 0 0 16
0 2 19 32
1
end_operator
begin_operator
board car23 loc28
1
47 20
2
0 0 0 16
0 2 20 32
1
end_operator
begin_operator
board car23 loc29
1
47 21
2
0 0 0 16
0 2 21 32
1
end_operator
begin_operator
board car23 loc3
1
47 22
2
0 0 0 16
0 2 22 32
1
end_operator
begin_operator
board car23 loc30
1
47 23
2
0 0 0 16
0 2 23 32
1
end_operator
begin_operator
board car23 loc31
1
47 24
2
0 0 0 16
0 2 24 32
1
end_operator
begin_operator
board car23 loc32
1
47 25
2
0 0 0 16
0 2 25 32
1
end_operator
begin_operator
board car23 loc4
1
47 26
2
0 0 0 16
0 2 26 32
1
end_operator
begin_operator
board car23 loc5
1
47 27
2
0 0 0 16
0 2 27 32
1
end_operator
begin_operator
board car23 loc6
1
47 28
2
0 0 0 16
0 2 28 32
1
end_operator
begin_operator
board car23 loc7
1
47 29
2
0 0 0 16
0 2 29 32
1
end_operator
begin_operator
board car23 loc8
1
47 30
2
0 0 0 16
0 2 30 32
1
end_operator
begin_operator
board car23 loc9
1
47 31
2
0 0 0 16
0 2 31 32
1
end_operator
begin_operator
board car24 loc1
1
47 0
2
0 0 0 17
0 8 0 32
1
end_operator
begin_operator
board car24 loc10
1
47 1
2
0 0 0 17
0 8 1 32
1
end_operator
begin_operator
board car24 loc11
1
47 2
2
0 0 0 17
0 8 2 32
1
end_operator
begin_operator
board car24 loc12
1
47 3
2
0 0 0 17
0 8 3 32
1
end_operator
begin_operator
board car24 loc13
1
47 4
2
0 0 0 17
0 8 4 32
1
end_operator
begin_operator
board car24 loc14
1
47 5
2
0 0 0 17
0 8 5 32
1
end_operator
begin_operator
board car24 loc15
1
47 6
2
0 0 0 17
0 8 6 32
1
end_operator
begin_operator
board car24 loc16
1
47 7
2
0 0 0 17
0 8 7 32
1
end_operator
begin_operator
board car24 loc17
1
47 8
2
0 0 0 17
0 8 8 32
1
end_operator
begin_operator
board car24 loc18
1
47 9
2
0 0 0 17
0 8 9 32
1
end_operator
begin_operator
board car24 loc19
1
47 10
2
0 0 0 17
0 8 10 32
1
end_operator
begin_operator
board car24 loc2
1
47 11
2
0 0 0 17
0 8 11 32
1
end_operator
begin_operator
board car24 loc20
1
47 12
2
0 0 0 17
0 8 12 32
1
end_operator
begin_operator
board car24 loc21
1
47 13
2
0 0 0 17
0 8 13 32
1
end_operator
begin_operator
board car24 loc22
1
47 14
2
0 0 0 17
0 8 14 32
1
end_operator
begin_operator
board car24 loc23
1
47 15
2
0 0 0 17
0 8 15 32
1
end_operator
begin_operator
board car24 loc24
1
47 16
2
0 0 0 17
0 8 16 32
1
end_operator
begin_operator
board car24 loc25
1
47 17
2
0 0 0 17
0 8 17 32
1
end_operator
begin_operator
board car24 loc26
1
47 18
2
0 0 0 17
0 8 18 32
1
end_operator
begin_operator
board car24 loc27
1
47 19
2
0 0 0 17
0 8 19 32
1
end_operator
begin_operator
board car24 loc28
1
47 20
2
0 0 0 17
0 8 20 32
1
end_operator
begin_operator
board car24 loc29
1
47 21
2
0 0 0 17
0 8 21 32
1
end_operator
begin_operator
board car24 loc3
1
47 22
2
0 0 0 17
0 8 22 32
1
end_operator
begin_operator
board car24 loc30
1
47 23
2
0 0 0 17
0 8 23 32
1
end_operator
begin_operator
board car24 loc31
1
47 24
2
0 0 0 17
0 8 24 32
1
end_operator
begin_operator
board car24 loc32
1
47 25
2
0 0 0 17
0 8 25 32
1
end_operator
begin_operator
board car24 loc4
1
47 26
2
0 0 0 17
0 8 26 32
1
end_operator
begin_operator
board car24 loc5
1
47 27
2
0 0 0 17
0 8 27 32
1
end_operator
begin_operator
board car24 loc6
1
47 28
2
0 0 0 17
0 8 28 32
1
end_operator
begin_operator
board car24 loc7
1
47 29
2
0 0 0 17
0 8 29 32
1
end_operator
begin_operator
board car24 loc8
1
47 30
2
0 0 0 17
0 8 30 32
1
end_operator
begin_operator
board car24 loc9
1
47 31
2
0 0 0 17
0 8 31 32
1
end_operator
begin_operator
board car25 loc1
1
47 0
2
0 0 0 18
0 14 0 32
1
end_operator
begin_operator
board car25 loc10
1
47 1
2
0 0 0 18
0 14 1 32
1
end_operator
begin_operator
board car25 loc11
1
47 2
2
0 0 0 18
0 14 2 32
1
end_operator
begin_operator
board car25 loc12
1
47 3
2
0 0 0 18
0 14 3 32
1
end_operator
begin_operator
board car25 loc13
1
47 4
2
0 0 0 18
0 14 4 32
1
end_operator
begin_operator
board car25 loc14
1
47 5
2
0 0 0 18
0 14 5 32
1
end_operator
begin_operator
board car25 loc15
1
47 6
2
0 0 0 18
0 14 6 32
1
end_operator
begin_operator
board car25 loc16
1
47 7
2
0 0 0 18
0 14 7 32
1
end_operator
begin_operator
board car25 loc17
1
47 8
2
0 0 0 18
0 14 8 32
1
end_operator
begin_operator
board car25 loc18
1
47 9
2
0 0 0 18
0 14 9 32
1
end_operator
begin_operator
board car25 loc19
1
47 10
2
0 0 0 18
0 14 10 32
1
end_operator
begin_operator
board car25 loc2
1
47 11
2
0 0 0 18
0 14 11 32
1
end_operator
begin_operator
board car25 loc20
1
47 12
2
0 0 0 18
0 14 12 32
1
end_operator
begin_operator
board car25 loc21
1
47 13
2
0 0 0 18
0 14 13 32
1
end_operator
begin_operator
board car25 loc22
1
47 14
2
0 0 0 18
0 14 14 32
1
end_operator
begin_operator
board car25 loc23
1
47 15
2
0 0 0 18
0 14 15 32
1
end_operator
begin_operator
board car25 loc24
1
47 16
2
0 0 0 18
0 14 16 32
1
end_operator
begin_operator
board car25 loc25
1
47 17
2
0 0 0 18
0 14 17 32
1
end_operator
begin_operator
board car25 loc26
1
47 18
2
0 0 0 18
0 14 18 32
1
end_operator
begin_operator
board car25 loc27
1
47 19
2
0 0 0 18
0 14 19 32
1
end_operator
begin_operator
board car25 loc28
1
47 20
2
0 0 0 18
0 14 20 32
1
end_operator
begin_operator
board car25 loc29
1
47 21
2
0 0 0 18
0 14 21 32
1
end_operator
begin_operator
board car25 loc3
1
47 22
2
0 0 0 18
0 14 22 32
1
end_operator
begin_operator
board car25 loc30
1
47 23
2
0 0 0 18
0 14 23 32
1
end_operator
begin_operator
board car25 loc31
1
47 24
2
0 0 0 18
0 14 24 32
1
end_operator
begin_operator
board car25 loc32
1
47 25
2
0 0 0 18
0 14 25 32
1
end_operator
begin_operator
board car25 loc4
1
47 26
2
0 0 0 18
0 14 26 32
1
end_operator
begin_operator
board car25 loc5
1
47 27
2
0 0 0 18
0 14 27 32
1
end_operator
begin_operator
board car25 loc6
1
47 28
2
0 0 0 18
0 14 28 32
1
end_operator
begin_operator
board car25 loc7
1
47 29
2
0 0 0 18
0 14 29 32
1
end_operator
begin_operator
board car25 loc8
1
47 30
2
0 0 0 18
0 14 30 32
1
end_operator
begin_operator
board car25 loc9
1
47 31
2
0 0 0 18
0 14 31 32
1
end_operator
begin_operator
board car26 loc1
1
47 0
2
0 0 0 19
0 20 0 32
1
end_operator
begin_operator
board car26 loc10
1
47 1
2
0 0 0 19
0 20 1 32
1
end_operator
begin_operator
board car26 loc11
1
47 2
2
0 0 0 19
0 20 2 32
1
end_operator
begin_operator
board car26 loc12
1
47 3
2
0 0 0 19
0 20 3 32
1
end_operator
begin_operator
board car26 loc13
1
47 4
2
0 0 0 19
0 20 4 32
1
end_operator
begin_operator
board car26 loc14
1
47 5
2
0 0 0 19
0 20 5 32
1
end_operator
begin_operator
board car26 loc15
1
47 6
2
0 0 0 19
0 20 6 32
1
end_operator
begin_operator
board car26 loc16
1
47 7
2
0 0 0 19
0 20 7 32
1
end_operator
begin_operator
board car26 loc17
1
47 8
2
0 0 0 19
0 20 8 32
1
end_operator
begin_operator
board car26 loc18
1
47 9
2
0 0 0 19
0 20 9 32
1
end_operator
begin_operator
board car26 loc19
1
47 10
2
0 0 0 19
0 20 10 32
1
end_operator
begin_operator
board car26 loc2
1
47 11
2
0 0 0 19
0 20 11 32
1
end_operator
begin_operator
board car26 loc20
1
47 12
2
0 0 0 19
0 20 12 32
1
end_operator
begin_operator
board car26 loc21
1
47 13
2
0 0 0 19
0 20 13 32
1
end_operator
begin_operator
board car26 loc22
1
47 14
2
0 0 0 19
0 20 14 32
1
end_operator
begin_operator
board car26 loc23
1
47 15
2
0 0 0 19
0 20 15 32
1
end_operator
begin_operator
board car26 loc24
1
47 16
2
0 0 0 19
0 20 16 32
1
end_operator
begin_operator
board car26 loc25
1
47 17
2
0 0 0 19
0 20 17 32
1
end_operator
begin_operator
board car26 loc26
1
47 18
2
0 0 0 19
0 20 18 32
1
end_operator
begin_operator
board car26 loc27
1
47 19
2
0 0 0 19
0 20 19 32
1
end_operator
begin_operator
board car26 loc28
1
47 20
2
0 0 0 19
0 20 20 32
1
end_operator
begin_operator
board car26 loc29
1
47 21
2
0 0 0 19
0 20 21 32
1
end_operator
begin_operator
board car26 loc3
1
47 22
2
0 0 0 19
0 20 22 32
1
end_operator
begin_operator
board car26 loc30
1
47 23
2
0 0 0 19
0 20 23 32
1
end_operator
begin_operator
board car26 loc31
1
47 24
2
0 0 0 19
0 20 24 32
1
end_operator
begin_operator
board car26 loc32
1
47 25
2
0 0 0 19
0 20 25 32
1
end_operator
begin_operator
board car26 loc4
1
47 26
2
0 0 0 19
0 20 26 32
1
end_operator
begin_operator
board car26 loc5
1
47 27
2
0 0 0 19
0 20 27 32
1
end_operator
begin_operator
board car26 loc6
1
47 28
2
0 0 0 19
0 20 28 32
1
end_operator
begin_operator
board car26 loc7
1
47 29
2
0 0 0 19
0 20 29 32
1
end_operator
begin_operator
board car26 loc8
1
47 30
2
0 0 0 19
0 20 30 32
1
end_operator
begin_operator
board car26 loc9
1
47 31
2
0 0 0 19
0 20 31 32
1
end_operator
begin_operator
board car27 loc1
1
47 0
2
0 0 0 20
0 26 0 32
1
end_operator
begin_operator
board car27 loc10
1
47 1
2
0 0 0 20
0 26 1 32
1
end_operator
begin_operator
board car27 loc11
1
47 2
2
0 0 0 20
0 26 2 32
1
end_operator
begin_operator
board car27 loc12
1
47 3
2
0 0 0 20
0 26 3 32
1
end_operator
begin_operator
board car27 loc13
1
47 4
2
0 0 0 20
0 26 4 32
1
end_operator
begin_operator
board car27 loc14
1
47 5
2
0 0 0 20
0 26 5 32
1
end_operator
begin_operator
board car27 loc15
1
47 6
2
0 0 0 20
0 26 6 32
1
end_operator
begin_operator
board car27 loc16
1
47 7
2
0 0 0 20
0 26 7 32
1
end_operator
begin_operator
board car27 loc17
1
47 8
2
0 0 0 20
0 26 8 32
1
end_operator
begin_operator
board car27 loc18
1
47 9
2
0 0 0 20
0 26 9 32
1
end_operator
begin_operator
board car27 loc19
1
47 10
2
0 0 0 20
0 26 10 32
1
end_operator
begin_operator
board car27 loc2
1
47 11
2
0 0 0 20
0 26 11 32
1
end_operator
begin_operator
board car27 loc20
1
47 12
2
0 0 0 20
0 26 12 32
1
end_operator
begin_operator
board car27 loc21
1
47 13
2
0 0 0 20
0 26 13 32
1
end_operator
begin_operator
board car27 loc22
1
47 14
2
0 0 0 20
0 26 14 32
1
end_operator
begin_operator
board car27 loc23
1
47 15
2
0 0 0 20
0 26 15 32
1
end_operator
begin_operator
board car27 loc24
1
47 16
2
0 0 0 20
0 26 16 32
1
end_operator
begin_operator
board car27 loc25
1
47 17
2
0 0 0 20
0 26 17 32
1
end_operator
begin_operator
board car27 loc26
1
47 18
2
0 0 0 20
0 26 18 32
1
end_operator
begin_operator
board car27 loc27
1
47 19
2
0 0 0 20
0 26 19 32
1
end_operator
begin_operator
board car27 loc28
1
47 20
2
0 0 0 20
0 26 20 32
1
end_operator
begin_operator
board car27 loc29
1
47 21
2
0 0 0 20
0 26 21 32
1
end_operator
begin_operator
board car27 loc3
1
47 22
2
0 0 0 20
0 26 22 32
1
end_operator
begin_operator
board car27 loc30
1
47 23
2
0 0 0 20
0 26 23 32
1
end_operator
begin_operator
board car27 loc31
1
47 24
2
0 0 0 20
0 26 24 32
1
end_operator
begin_operator
board car27 loc32
1
47 25
2
0 0 0 20
0 26 25 32
1
end_operator
begin_operator
board car27 loc4
1
47 26
2
0 0 0 20
0 26 26 32
1
end_operator
begin_operator
board car27 loc5
1
47 27
2
0 0 0 20
0 26 27 32
1
end_operator
begin_operator
board car27 loc6
1
47 28
2
0 0 0 20
0 26 28 32
1
end_operator
begin_operator
board car27 loc7
1
47 29
2
0 0 0 20
0 26 29 32
1
end_operator
begin_operator
board car27 loc8
1
47 30
2
0 0 0 20
0 26 30 32
1
end_operator
begin_operator
board car27 loc9
1
47 31
2
0 0 0 20
0 26 31 32
1
end_operator
begin_operator
board car28 loc1
1
47 0
2
0 0 0 21
0 32 0 32
1
end_operator
begin_operator
board car28 loc10
1
47 1
2
0 0 0 21
0 32 1 32
1
end_operator
begin_operator
board car28 loc11
1
47 2
2
0 0 0 21
0 32 2 32
1
end_operator
begin_operator
board car28 loc12
1
47 3
2
0 0 0 21
0 32 3 32
1
end_operator
begin_operator
board car28 loc13
1
47 4
2
0 0 0 21
0 32 4 32
1
end_operator
begin_operator
board car28 loc14
1
47 5
2
0 0 0 21
0 32 5 32
1
end_operator
begin_operator
board car28 loc15
1
47 6
2
0 0 0 21
0 32 6 32
1
end_operator
begin_operator
board car28 loc16
1
47 7
2
0 0 0 21
0 32 7 32
1
end_operator
begin_operator
board car28 loc17
1
47 8
2
0 0 0 21
0 32 8 32
1
end_operator
begin_operator
board car28 loc18
1
47 9
2
0 0 0 21
0 32 9 32
1
end_operator
begin_operator
board car28 loc19
1
47 10
2
0 0 0 21
0 32 10 32
1
end_operator
begin_operator
board car28 loc2
1
47 11
2
0 0 0 21
0 32 11 32
1
end_operator
begin_operator
board car28 loc20
1
47 12
2
0 0 0 21
0 32 12 32
1
end_operator
begin_operator
board car28 loc21
1
47 13
2
0 0 0 21
0 32 13 32
1
end_operator
begin_operator
board car28 loc22
1
47 14
2
0 0 0 21
0 32 14 32
1
end_operator
begin_operator
board car28 loc23
1
47 15
2
0 0 0 21
0 32 15 32
1
end_operator
begin_operator
board car28 loc24
1
47 16
2
0 0 0 21
0 32 16 32
1
end_operator
begin_operator
board car28 loc25
1
47 17
2
0 0 0 21
0 32 17 32
1
end_operator
begin_operator
board car28 loc26
1
47 18
2
0 0 0 21
0 32 18 32
1
end_operator
begin_operator
board car28 loc27
1
47 19
2
0 0 0 21
0 32 19 32
1
end_operator
begin_operator
board car28 loc28
1
47 20
2
0 0 0 21
0 32 20 32
1
end_operator
begin_operator
board car28 loc29
1
47 21
2
0 0 0 21
0 32 21 32
1
end_operator
begin_operator
board car28 loc3
1
47 22
2
0 0 0 21
0 32 22 32
1
end_operator
begin_operator
board car28 loc30
1
47 23
2
0 0 0 21
0 32 23 32
1
end_operator
begin_operator
board car28 loc31
1
47 24
2
0 0 0 21
0 32 24 32
1
end_operator
begin_operator
board car28 loc32
1
47 25
2
0 0 0 21
0 32 25 32
1
end_operator
begin_operator
board car28 loc4
1
47 26
2
0 0 0 21
0 32 26 32
1
end_operator
begin_operator
board car28 loc5
1
47 27
2
0 0 0 21
0 32 27 32
1
end_operator
begin_operator
board car28 loc6
1
47 28
2
0 0 0 21
0 32 28 32
1
end_operator
begin_operator
board car28 loc7
1
47 29
2
0 0 0 21
0 32 29 32
1
end_operator
begin_operator
board car28 loc8
1
47 30
2
0 0 0 21
0 32 30 32
1
end_operator
begin_operator
board car28 loc9
1
47 31
2
0 0 0 21
0 32 31 32
1
end_operator
begin_operator
board car29 loc1
1
47 0
2
0 0 0 22
0 38 0 32
1
end_operator
begin_operator
board car29 loc10
1
47 1
2
0 0 0 22
0 38 1 32
1
end_operator
begin_operator
board car29 loc11
1
47 2
2
0 0 0 22
0 38 2 32
1
end_operator
begin_operator
board car29 loc12
1
47 3
2
0 0 0 22
0 38 3 32
1
end_operator
begin_operator
board car29 loc13
1
47 4
2
0 0 0 22
0 38 4 32
1
end_operator
begin_operator
board car29 loc14
1
47 5
2
0 0 0 22
0 38 5 32
1
end_operator
begin_operator
board car29 loc15
1
47 6
2
0 0 0 22
0 38 6 32
1
end_operator
begin_operator
board car29 loc16
1
47 7
2
0 0 0 22
0 38 7 32
1
end_operator
begin_operator
board car29 loc17
1
47 8
2
0 0 0 22
0 38 8 32
1
end_operator
begin_operator
board car29 loc18
1
47 9
2
0 0 0 22
0 38 9 32
1
end_operator
begin_operator
board car29 loc19
1
47 10
2
0 0 0 22
0 38 10 32
1
end_operator
begin_operator
board car29 loc2
1
47 11
2
0 0 0 22
0 38 11 32
1
end_operator
begin_operator
board car29 loc20
1
47 12
2
0 0 0 22
0 38 12 32
1
end_operator
begin_operator
board car29 loc21
1
47 13
2
0 0 0 22
0 38 13 32
1
end_operator
begin_operator
board car29 loc22
1
47 14
2
0 0 0 22
0 38 14 32
1
end_operator
begin_operator
board car29 loc23
1
47 15
2
0 0 0 22
0 38 15 32
1
end_operator
begin_operator
board car29 loc24
1
47 16
2
0 0 0 22
0 38 16 32
1
end_operator
begin_operator
board car29 loc25
1
47 17
2
0 0 0 22
0 38 17 32
1
end_operator
begin_operator
board car29 loc26
1
47 18
2
0 0 0 22
0 38 18 32
1
end_operator
begin_operator
board car29 loc27
1
47 19
2
0 0 0 22
0 38 19 32
1
end_operator
begin_operator
board car29 loc28
1
47 20
2
0 0 0 22
0 38 20 32
1
end_operator
begin_operator
board car29 loc29
1
47 21
2
0 0 0 22
0 38 21 32
1
end_operator
begin_operator
board car29 loc3
1
47 22
2
0 0 0 22
0 38 22 32
1
end_operator
begin_operator
board car29 loc30
1
47 23
2
0 0 0 22
0 38 23 32
1
end_operator
begin_operator
board car29 loc31
1
47 24
2
0 0 0 22
0 38 24 32
1
end_operator
begin_operator
board car29 loc32
1
47 25
2
0 0 0 22
0 38 25 32
1
end_operator
begin_operator
board car29 loc4
1
47 26
2
0 0 0 22
0 38 26 32
1
end_operator
begin_operator
board car29 loc5
1
47 27
2
0 0 0 22
0 38 27 32
1
end_operator
begin_operator
board car29 loc6
1
47 28
2
0 0 0 22
0 38 28 32
1
end_operator
begin_operator
board car29 loc7
1
47 29
2
0 0 0 22
0 38 29 32
1
end_operator
begin_operator
board car29 loc8
1
47 30
2
0 0 0 22
0 38 30 32
1
end_operator
begin_operator
board car29 loc9
1
47 31
2
0 0 0 22
0 38 31 32
1
end_operator
begin_operator
board car3 loc1
1
47 0
2
0 0 0 23
0 44 0 32
1
end_operator
begin_operator
board car3 loc10
1
47 1
2
0 0 0 23
0 44 1 32
1
end_operator
begin_operator
board car3 loc11
1
47 2
2
0 0 0 23
0 44 2 32
1
end_operator
begin_operator
board car3 loc12
1
47 3
2
0 0 0 23
0 44 3 32
1
end_operator
begin_operator
board car3 loc13
1
47 4
2
0 0 0 23
0 44 4 32
1
end_operator
begin_operator
board car3 loc14
1
47 5
2
0 0 0 23
0 44 5 32
1
end_operator
begin_operator
board car3 loc15
1
47 6
2
0 0 0 23
0 44 6 32
1
end_operator
begin_operator
board car3 loc16
1
47 7
2
0 0 0 23
0 44 7 32
1
end_operator
begin_operator
board car3 loc17
1
47 8
2
0 0 0 23
0 44 8 32
1
end_operator
begin_operator
board car3 loc18
1
47 9
2
0 0 0 23
0 44 9 32
1
end_operator
begin_operator
board car3 loc19
1
47 10
2
0 0 0 23
0 44 10 32
1
end_operator
begin_operator
board car3 loc2
1
47 11
2
0 0 0 23
0 44 11 32
1
end_operator
begin_operator
board car3 loc20
1
47 12
2
0 0 0 23
0 44 12 32
1
end_operator
begin_operator
board car3 loc21
1
47 13
2
0 0 0 23
0 44 13 32
1
end_operator
begin_operator
board car3 loc22
1
47 14
2
0 0 0 23
0 44 14 32
1
end_operator
begin_operator
board car3 loc23
1
47 15
2
0 0 0 23
0 44 15 32
1
end_operator
begin_operator
board car3 loc24
1
47 16
2
0 0 0 23
0 44 16 32
1
end_operator
begin_operator
board car3 loc25
1
47 17
2
0 0 0 23
0 44 17 32
1
end_operator
begin_operator
board car3 loc26
1
47 18
2
0 0 0 23
0 44 18 32
1
end_operator
begin_operator
board car3 loc27
1
47 19
2
0 0 0 23
0 44 19 32
1
end_operator
begin_operator
board car3 loc28
1
47 20
2
0 0 0 23
0 44 20 32
1
end_operator
begin_operator
board car3 loc29
1
47 21
2
0 0 0 23
0 44 21 32
1
end_operator
begin_operator
board car3 loc3
1
47 22
2
0 0 0 23
0 44 22 32
1
end_operator
begin_operator
board car3 loc30
1
47 23
2
0 0 0 23
0 44 23 32
1
end_operator
begin_operator
board car3 loc31
1
47 24
2
0 0 0 23
0 44 24 32
1
end_operator
begin_operator
board car3 loc32
1
47 25
2
0 0 0 23
0 44 25 32
1
end_operator
begin_operator
board car3 loc4
1
47 26
2
0 0 0 23
0 44 26 32
1
end_operator
begin_operator
board car3 loc5
1
47 27
2
0 0 0 23
0 44 27 32
1
end_operator
begin_operator
board car3 loc6
1
47 28
2
0 0 0 23
0 44 28 32
1
end_operator
begin_operator
board car3 loc7
1
47 29
2
0 0 0 23
0 44 29 32
1
end_operator
begin_operator
board car3 loc8
1
47 30
2
0 0 0 23
0 44 30 32
1
end_operator
begin_operator
board car3 loc9
1
47 31
2
0 0 0 23
0 44 31 32
1
end_operator
begin_operator
board car30 loc1
1
47 0
2
0 0 0 24
0 3 0 32
1
end_operator
begin_operator
board car30 loc10
1
47 1
2
0 0 0 24
0 3 1 32
1
end_operator
begin_operator
board car30 loc11
1
47 2
2
0 0 0 24
0 3 2 32
1
end_operator
begin_operator
board car30 loc12
1
47 3
2
0 0 0 24
0 3 3 32
1
end_operator
begin_operator
board car30 loc13
1
47 4
2
0 0 0 24
0 3 4 32
1
end_operator
begin_operator
board car30 loc14
1
47 5
2
0 0 0 24
0 3 5 32
1
end_operator
begin_operator
board car30 loc15
1
47 6
2
0 0 0 24
0 3 6 32
1
end_operator
begin_operator
board car30 loc16
1
47 7
2
0 0 0 24
0 3 7 32
1
end_operator
begin_operator
board car30 loc17
1
47 8
2
0 0 0 24
0 3 8 32
1
end_operator
begin_operator
board car30 loc18
1
47 9
2
0 0 0 24
0 3 9 32
1
end_operator
begin_operator
board car30 loc19
1
47 10
2
0 0 0 24
0 3 10 32
1
end_operator
begin_operator
board car30 loc2
1
47 11
2
0 0 0 24
0 3 11 32
1
end_operator
begin_operator
board car30 loc20
1
47 12
2
0 0 0 24
0 3 12 32
1
end_operator
begin_operator
board car30 loc21
1
47 13
2
0 0 0 24
0 3 13 32
1
end_operator
begin_operator
board car30 loc22
1
47 14
2
0 0 0 24
0 3 14 32
1
end_operator
begin_operator
board car30 loc23
1
47 15
2
0 0 0 24
0 3 15 32
1
end_operator
begin_operator
board car30 loc24
1
47 16
2
0 0 0 24
0 3 16 32
1
end_operator
begin_operator
board car30 loc25
1
47 17
2
0 0 0 24
0 3 17 32
1
end_operator
begin_operator
board car30 loc26
1
47 18
2
0 0 0 24
0 3 18 32
1
end_operator
begin_operator
board car30 loc27
1
47 19
2
0 0 0 24
0 3 19 32
1
end_operator
begin_operator
board car30 loc28
1
47 20
2
0 0 0 24
0 3 20 32
1
end_operator
begin_operator
board car30 loc29
1
47 21
2
0 0 0 24
0 3 21 32
1
end_operator
begin_operator
board car30 loc3
1
47 22
2
0 0 0 24
0 3 22 32
1
end_operator
begin_operator
board car30 loc30
1
47 23
2
0 0 0 24
0 3 23 32
1
end_operator
begin_operator
board car30 loc31
1
47 24
2
0 0 0 24
0 3 24 32
1
end_operator
begin_operator
board car30 loc32
1
47 25
2
0 0 0 24
0 3 25 32
1
end_operator
begin_operator
board car30 loc4
1
47 26
2
0 0 0 24
0 3 26 32
1
end_operator
begin_operator
board car30 loc5
1
47 27
2
0 0 0 24
0 3 27 32
1
end_operator
begin_operator
board car30 loc6
1
47 28
2
0 0 0 24
0 3 28 32
1
end_operator
begin_operator
board car30 loc7
1
47 29
2
0 0 0 24
0 3 29 32
1
end_operator
begin_operator
board car30 loc8
1
47 30
2
0 0 0 24
0 3 30 32
1
end_operator
begin_operator
board car30 loc9
1
47 31
2
0 0 0 24
0 3 31 32
1
end_operator
begin_operator
board car31 loc1
1
47 0
2
0 0 0 25
0 9 0 32
1
end_operator
begin_operator
board car31 loc10
1
47 1
2
0 0 0 25
0 9 1 32
1
end_operator
begin_operator
board car31 loc11
1
47 2
2
0 0 0 25
0 9 2 32
1
end_operator
begin_operator
board car31 loc12
1
47 3
2
0 0 0 25
0 9 3 32
1
end_operator
begin_operator
board car31 loc13
1
47 4
2
0 0 0 25
0 9 4 32
1
end_operator
begin_operator
board car31 loc14
1
47 5
2
0 0 0 25
0 9 5 32
1
end_operator
begin_operator
board car31 loc15
1
47 6
2
0 0 0 25
0 9 6 32
1
end_operator
begin_operator
board car31 loc16
1
47 7
2
0 0 0 25
0 9 7 32
1
end_operator
begin_operator
board car31 loc17
1
47 8
2
0 0 0 25
0 9 8 32
1
end_operator
begin_operator
board car31 loc18
1
47 9
2
0 0 0 25
0 9 9 32
1
end_operator
begin_operator
board car31 loc19
1
47 10
2
0 0 0 25
0 9 10 32
1
end_operator
begin_operator
board car31 loc2
1
47 11
2
0 0 0 25
0 9 11 32
1
end_operator
begin_operator
board car31 loc20
1
47 12
2
0 0 0 25
0 9 12 32
1
end_operator
begin_operator
board car31 loc21
1
47 13
2
0 0 0 25
0 9 13 32
1
end_operator
begin_operator
board car31 loc22
1
47 14
2
0 0 0 25
0 9 14 32
1
end_operator
begin_operator
board car31 loc23
1
47 15
2
0 0 0 25
0 9 15 32
1
end_operator
begin_operator
board car31 loc24
1
47 16
2
0 0 0 25
0 9 16 32
1
end_operator
begin_operator
board car31 loc25
1
47 17
2
0 0 0 25
0 9 17 32
1
end_operator
begin_operator
board car31 loc26
1
47 18
2
0 0 0 25
0 9 18 32
1
end_operator
begin_operator
board car31 loc27
1
47 19
2
0 0 0 25
0 9 19 32
1
end_operator
begin_operator
board car31 loc28
1
47 20
2
0 0 0 25
0 9 20 32
1
end_operator
begin_operator
board car31 loc29
1
47 21
2
0 0 0 25
0 9 21 32
1
end_operator
begin_operator
board car31 loc3
1
47 22
2
0 0 0 25
0 9 22 32
1
end_operator
begin_operator
board car31 loc30
1
47 23
2
0 0 0 25
0 9 23 32
1
end_operator
begin_operator
board car31 loc31
1
47 24
2
0 0 0 25
0 9 24 32
1
end_operator
begin_operator
board car31 loc32
1
47 25
2
0 0 0 25
0 9 25 32
1
end_operator
begin_operator
board car31 loc4
1
47 26
2
0 0 0 25
0 9 26 32
1
end_operator
begin_operator
board car31 loc5
1
47 27
2
0 0 0 25
0 9 27 32
1
end_operator
begin_operator
board car31 loc6
1
47 28
2
0 0 0 25
0 9 28 32
1
end_operator
begin_operator
board car31 loc7
1
47 29
2
0 0 0 25
0 9 29 32
1
end_operator
begin_operator
board car31 loc8
1
47 30
2
0 0 0 25
0 9 30 32
1
end_operator
begin_operator
board car31 loc9
1
47 31
2
0 0 0 25
0 9 31 32
1
end_operator
begin_operator
board car32 loc1
1
47 0
2
0 0 0 26
0 15 0 32
1
end_operator
begin_operator
board car32 loc10
1
47 1
2
0 0 0 26
0 15 1 32
1
end_operator
begin_operator
board car32 loc11
1
47 2
2
0 0 0 26
0 15 2 32
1
end_operator
begin_operator
board car32 loc12
1
47 3
2
0 0 0 26
0 15 3 32
1
end_operator
begin_operator
board car32 loc13
1
47 4
2
0 0 0 26
0 15 4 32
1
end_operator
begin_operator
board car32 loc14
1
47 5
2
0 0 0 26
0 15 5 32
1
end_operator
begin_operator
board car32 loc15
1
47 6
2
0 0 0 26
0 15 6 32
1
end_operator
begin_operator
board car32 loc16
1
47 7
2
0 0 0 26
0 15 7 32
1
end_operator
begin_operator
board car32 loc17
1
47 8
2
0 0 0 26
0 15 8 32
1
end_operator
begin_operator
board car32 loc18
1
47 9
2
0 0 0 26
0 15 9 32
1
end_operator
begin_operator
board car32 loc19
1
47 10
2
0 0 0 26
0 15 10 32
1
end_operator
begin_operator
board car32 loc2
1
47 11
2
0 0 0 26
0 15 11 32
1
end_operator
begin_operator
board car32 loc20
1
47 12
2
0 0 0 26
0 15 12 32
1
end_operator
begin_operator
board car32 loc21
1
47 13
2
0 0 0 26
0 15 13 32
1
end_operator
begin_operator
board car32 loc22
1
47 14
2
0 0 0 26
0 15 14 32
1
end_operator
begin_operator
board car32 loc23
1
47 15
2
0 0 0 26
0 15 15 32
1
end_operator
begin_operator
board car32 loc24
1
47 16
2
0 0 0 26
0 15 16 32
1
end_operator
begin_operator
board car32 loc25
1
47 17
2
0 0 0 26
0 15 17 32
1
end_operator
begin_operator
board car32 loc26
1
47 18
2
0 0 0 26
0 15 18 32
1
end_operator
begin_operator
board car32 loc27
1
47 19
2
0 0 0 26
0 15 19 32
1
end_operator
begin_operator
board car32 loc28
1
47 20
2
0 0 0 26
0 15 20 32
1
end_operator
begin_operator
board car32 loc29
1
47 21
2
0 0 0 26
0 15 21 32
1
end_operator
begin_operator
board car32 loc3
1
47 22
2
0 0 0 26
0 15 22 32
1
end_operator
begin_operator
board car32 loc30
1
47 23
2
0 0 0 26
0 15 23 32
1
end_operator
begin_operator
board car32 loc31
1
47 24
2
0 0 0 26
0 15 24 32
1
end_operator
begin_operator
board car32 loc32
1
47 25
2
0 0 0 26
0 15 25 32
1
end_operator
begin_operator
board car32 loc4
1
47 26
2
0 0 0 26
0 15 26 32
1
end_operator
begin_operator
board car32 loc5
1
47 27
2
0 0 0 26
0 15 27 32
1
end_operator
begin_operator
board car32 loc6
1
47 28
2
0 0 0 26
0 15 28 32
1
end_operator
begin_operator
board car32 loc7
1
47 29
2
0 0 0 26
0 15 29 32
1
end_operator
begin_operator
board car32 loc8
1
47 30
2
0 0 0 26
0 15 30 32
1
end_operator
begin_operator
board car32 loc9
1
47 31
2
0 0 0 26
0 15 31 32
1
end_operator
begin_operator
board car33 loc1
1
47 0
2
0 0 0 27
0 21 0 32
1
end_operator
begin_operator
board car33 loc10
1
47 1
2
0 0 0 27
0 21 1 32
1
end_operator
begin_operator
board car33 loc11
1
47 2
2
0 0 0 27
0 21 2 32
1
end_operator
begin_operator
board car33 loc12
1
47 3
2
0 0 0 27
0 21 3 32
1
end_operator
begin_operator
board car33 loc13
1
47 4
2
0 0 0 27
0 21 4 32
1
end_operator
begin_operator
board car33 loc14
1
47 5
2
0 0 0 27
0 21 5 32
1
end_operator
begin_operator
board car33 loc15
1
47 6
2
0 0 0 27
0 21 6 32
1
end_operator
begin_operator
board car33 loc16
1
47 7
2
0 0 0 27
0 21 7 32
1
end_operator
begin_operator
board car33 loc17
1
47 8
2
0 0 0 27
0 21 8 32
1
end_operator
begin_operator
board car33 loc18
1
47 9
2
0 0 0 27
0 21 9 32
1
end_operator
begin_operator
board car33 loc19
1
47 10
2
0 0 0 27
0 21 10 32
1
end_operator
begin_operator
board car33 loc2
1
47 11
2
0 0 0 27
0 21 11 32
1
end_operator
begin_operator
board car33 loc20
1
47 12
2
0 0 0 27
0 21 12 32
1
end_operator
begin_operator
board car33 loc21
1
47 13
2
0 0 0 27
0 21 13 32
1
end_operator
begin_operator
board car33 loc22
1
47 14
2
0 0 0 27
0 21 14 32
1
end_operator
begin_operator
board car33 loc23
1
47 15
2
0 0 0 27
0 21 15 32
1
end_operator
begin_operator
board car33 loc24
1
47 16
2
0 0 0 27
0 21 16 32
1
end_operator
begin_operator
board car33 loc25
1
47 17
2
0 0 0 27
0 21 17 32
1
end_operator
begin_operator
board car33 loc26
1
47 18
2
0 0 0 27
0 21 18 32
1
end_operator
begin_operator
board car33 loc27
1
47 19
2
0 0 0 27
0 21 19 32
1
end_operator
begin_operator
board car33 loc28
1
47 20
2
0 0 0 27
0 21 20 32
1
end_operator
begin_operator
board car33 loc29
1
47 21
2
0 0 0 27
0 21 21 32
1
end_operator
begin_operator
board car33 loc3
1
47 22
2
0 0 0 27
0 21 22 32
1
end_operator
begin_operator
board car33 loc30
1
47 23
2
0 0 0 27
0 21 23 32
1
end_operator
begin_operator
board car33 loc31
1
47 24
2
0 0 0 27
0 21 24 32
1
end_operator
begin_operator
board car33 loc32
1
47 25
2
0 0 0 27
0 21 25 32
1
end_operator
begin_operator
board car33 loc4
1
47 26
2
0 0 0 27
0 21 26 32
1
end_operator
begin_operator
board car33 loc5
1
47 27
2
0 0 0 27
0 21 27 32
1
end_operator
begin_operator
board car33 loc6
1
47 28
2
0 0 0 27
0 21 28 32
1
end_operator
begin_operator
board car33 loc7
1
47 29
2
0 0 0 27
0 21 29 32
1
end_operator
begin_operator
board car33 loc8
1
47 30
2
0 0 0 27
0 21 30 32
1
end_operator
begin_operator
board car33 loc9
1
47 31
2
0 0 0 27
0 21 31 32
1
end_operator
begin_operator
board car34 loc1
1
47 0
2
0 0 0 28
0 27 0 32
1
end_operator
begin_operator
board car34 loc10
1
47 1
2
0 0 0 28
0 27 1 32
1
end_operator
begin_operator
board car34 loc11
1
47 2
2
0 0 0 28
0 27 2 32
1
end_operator
begin_operator
board car34 loc12
1
47 3
2
0 0 0 28
0 27 3 32
1
end_operator
begin_operator
board car34 loc13
1
47 4
2
0 0 0 28
0 27 4 32
1
end_operator
begin_operator
board car34 loc14
1
47 5
2
0 0 0 28
0 27 5 32
1
end_operator
begin_operator
board car34 loc15
1
47 6
2
0 0 0 28
0 27 6 32
1
end_operator
begin_operator
board car34 loc16
1
47 7
2
0 0 0 28
0 27 7 32
1
end_operator
begin_operator
board car34 loc17
1
47 8
2
0 0 0 28
0 27 8 32
1
end_operator
begin_operator
board car34 loc18
1
47 9
2
0 0 0 28
0 27 9 32
1
end_operator
begin_operator
board car34 loc19
1
47 10
2
0 0 0 28
0 27 10 32
1
end_operator
begin_operator
board car34 loc2
1
47 11
2
0 0 0 28
0 27 11 32
1
end_operator
begin_operator
board car34 loc20
1
47 12
2
0 0 0 28
0 27 12 32
1
end_operator
begin_operator
board car34 loc21
1
47 13
2
0 0 0 28
0 27 13 32
1
end_operator
begin_operator
board car34 loc22
1
47 14
2
0 0 0 28
0 27 14 32
1
end_operator
begin_operator
board car34 loc23
1
47 15
2
0 0 0 28
0 27 15 32
1
end_operator
begin_operator
board car34 loc24
1
47 16
2
0 0 0 28
0 27 16 32
1
end_operator
begin_operator
board car34 loc25
1
47 17
2
0 0 0 28
0 27 17 32
1
end_operator
begin_operator
board car34 loc26
1
47 18
2
0 0 0 28
0 27 18 32
1
end_operator
begin_operator
board car34 loc27
1
47 19
2
0 0 0 28
0 27 19 32
1
end_operator
begin_operator
board car34 loc28
1
47 20
2
0 0 0 28
0 27 20 32
1
end_operator
begin_operator
board car34 loc29
1
47 21
2
0 0 0 28
0 27 21 32
1
end_operator
begin_operator
board car34 loc3
1
47 22
2
0 0 0 28
0 27 22 32
1
end_operator
begin_operator
board car34 loc30
1
47 23
2
0 0 0 28
0 27 23 32
1
end_operator
begin_operator
board car34 loc31
1
47 24
2
0 0 0 28
0 27 24 32
1
end_operator
begin_operator
board car34 loc32
1
47 25
2
0 0 0 28
0 27 25 32
1
end_operator
begin_operator
board car34 loc4
1
47 26
2
0 0 0 28
0 27 26 32
1
end_operator
begin_operator
board car34 loc5
1
47 27
2
0 0 0 28
0 27 27 32
1
end_operator
begin_operator
board car34 loc6
1
47 28
2
0 0 0 28
0 27 28 32
1
end_operator
begin_operator
board car34 loc7
1
47 29
2
0 0 0 28
0 27 29 32
1
end_operator
begin_operator
board car34 loc8
1
47 30
2
0 0 0 28
0 27 30 32
1
end_operator
begin_operator
board car34 loc9
1
47 31
2
0 0 0 28
0 27 31 32
1
end_operator
begin_operator
board car35 loc1
1
47 0
2
0 0 0 29
0 33 0 32
1
end_operator
begin_operator
board car35 loc10
1
47 1
2
0 0 0 29
0 33 1 32
1
end_operator
begin_operator
board car35 loc11
1
47 2
2
0 0 0 29
0 33 2 32
1
end_operator
begin_operator
board car35 loc12
1
47 3
2
0 0 0 29
0 33 3 32
1
end_operator
begin_operator
board car35 loc13
1
47 4
2
0 0 0 29
0 33 4 32
1
end_operator
begin_operator
board car35 loc14
1
47 5
2
0 0 0 29
0 33 5 32
1
end_operator
begin_operator
board car35 loc15
1
47 6
2
0 0 0 29
0 33 6 32
1
end_operator
begin_operator
board car35 loc16
1
47 7
2
0 0 0 29
0 33 7 32
1
end_operator
begin_operator
board car35 loc17
1
47 8
2
0 0 0 29
0 33 8 32
1
end_operator
begin_operator
board car35 loc18
1
47 9
2
0 0 0 29
0 33 9 32
1
end_operator
begin_operator
board car35 loc19
1
47 10
2
0 0 0 29
0 33 10 32
1
end_operator
begin_operator
board car35 loc2
1
47 11
2
0 0 0 29
0 33 11 32
1
end_operator
begin_operator
board car35 loc20
1
47 12
2
0 0 0 29
0 33 12 32
1
end_operator
begin_operator
board car35 loc21
1
47 13
2
0 0 0 29
0 33 13 32
1
end_operator
begin_operator
board car35 loc22
1
47 14
2
0 0 0 29
0 33 14 32
1
end_operator
begin_operator
board car35 loc23
1
47 15
2
0 0 0 29
0 33 15 32
1
end_operator
begin_operator
board car35 loc24
1
47 16
2
0 0 0 29
0 33 16 32
1
end_operator
begin_operator
board car35 loc25
1
47 17
2
0 0 0 29
0 33 17 32
1
end_operator
begin_operator
board car35 loc26
1
47 18
2
0 0 0 29
0 33 18 32
1
end_operator
begin_operator
board car35 loc27
1
47 19
2
0 0 0 29
0 33 19 32
1
end_operator
begin_operator
board car35 loc28
1
47 20
2
0 0 0 29
0 33 20 32
1
end_operator
begin_operator
board car35 loc29
1
47 21
2
0 0 0 29
0 33 21 32
1
end_operator
begin_operator
board car35 loc3
1
47 22
2
0 0 0 29
0 33 22 32
1
end_operator
begin_operator
board car35 loc30
1
47 23
2
0 0 0 29
0 33 23 32
1
end_operator
begin_operator
board car35 loc31
1
47 24
2
0 0 0 29
0 33 24 32
1
end_operator
begin_operator
board car35 loc32
1
47 25
2
0 0 0 29
0 33 25 32
1
end_operator
begin_operator
board car35 loc4
1
47 26
2
0 0 0 29
0 33 26 32
1
end_operator
begin_operator
board car35 loc5
1
47 27
2
0 0 0 29
0 33 27 32
1
end_operator
begin_operator
board car35 loc6
1
47 28
2
0 0 0 29
0 33 28 32
1
end_operator
begin_operator
board car35 loc7
1
47 29
2
0 0 0 29
0 33 29 32
1
end_operator
begin_operator
board car35 loc8
1
47 30
2
0 0 0 29
0 33 30 32
1
end_operator
begin_operator
board car35 loc9
1
47 31
2
0 0 0 29
0 33 31 32
1
end_operator
begin_operator
board car36 loc1
1
47 0
2
0 0 0 30
0 39 0 32
1
end_operator
begin_operator
board car36 loc10
1
47 1
2
0 0 0 30
0 39 1 32
1
end_operator
begin_operator
board car36 loc11
1
47 2
2
0 0 0 30
0 39 2 32
1
end_operator
begin_operator
board car36 loc12
1
47 3
2
0 0 0 30
0 39 3 32
1
end_operator
begin_operator
board car36 loc13
1
47 4
2
0 0 0 30
0 39 4 32
1
end_operator
begin_operator
board car36 loc14
1
47 5
2
0 0 0 30
0 39 5 32
1
end_operator
begin_operator
board car36 loc15
1
47 6
2
0 0 0 30
0 39 6 32
1
end_operator
begin_operator
board car36 loc16
1
47 7
2
0 0 0 30
0 39 7 32
1
end_operator
begin_operator
board car36 loc17
1
47 8
2
0 0 0 30
0 39 8 32
1
end_operator
begin_operator
board car36 loc18
1
47 9
2
0 0 0 30
0 39 9 32
1
end_operator
begin_operator
board car36 loc19
1
47 10
2
0 0 0 30
0 39 10 32
1
end_operator
begin_operator
board car36 loc2
1
47 11
2
0 0 0 30
0 39 11 32
1
end_operator
begin_operator
board car36 loc20
1
47 12
2
0 0 0 30
0 39 12 32
1
end_operator
begin_operator
board car36 loc21
1
47 13
2
0 0 0 30
0 39 13 32
1
end_operator
begin_operator
board car36 loc22
1
47 14
2
0 0 0 30
0 39 14 32
1
end_operator
begin_operator
board car36 loc23
1
47 15
2
0 0 0 30
0 39 15 32
1
end_operator
begin_operator
board car36 loc24
1
47 16
2
0 0 0 30
0 39 16 32
1
end_operator
begin_operator
board car36 loc25
1
47 17
2
0 0 0 30
0 39 17 32
1
end_operator
begin_operator
board car36 loc26
1
47 18
2
0 0 0 30
0 39 18 32
1
end_operator
begin_operator
board car36 loc27
1
47 19
2
0 0 0 30
0 39 19 32
1
end_operator
begin_operator
board car36 loc28
1
47 20
2
0 0 0 30
0 39 20 32
1
end_operator
begin_operator
board car36 loc29
1
47 21
2
0 0 0 30
0 39 21 32
1
end_operator
begin_operator
board car36 loc3
1
47 22
2
0 0 0 30
0 39 22 32
1
end_operator
begin_operator
board car36 loc30
1
47 23
2
0 0 0 30
0 39 23 32
1
end_operator
begin_operator
board car36 loc31
1
47 24
2
0 0 0 30
0 39 24 32
1
end_operator
begin_operator
board car36 loc32
1
47 25
2
0 0 0 30
0 39 25 32
1
end_operator
begin_operator
board car36 loc4
1
47 26
2
0 0 0 30
0 39 26 32
1
end_operator
begin_operator
board car36 loc5
1
47 27
2
0 0 0 30
0 39 27 32
1
end_operator
begin_operator
board car36 loc6
1
47 28
2
0 0 0 30
0 39 28 32
1
end_operator
begin_operator
board car36 loc7
1
47 29
2
0 0 0 30
0 39 29 32
1
end_operator
begin_operator
board car36 loc8
1
47 30
2
0 0 0 30
0 39 30 32
1
end_operator
begin_operator
board car36 loc9
1
47 31
2
0 0 0 30
0 39 31 32
1
end_operator
begin_operator
board car37 loc1
1
47 0
2
0 0 0 31
0 45 0 32
1
end_operator
begin_operator
board car37 loc10
1
47 1
2
0 0 0 31
0 45 1 32
1
end_operator
begin_operator
board car37 loc11
1
47 2
2
0 0 0 31
0 45 2 32
1
end_operator
begin_operator
board car37 loc12
1
47 3
2
0 0 0 31
0 45 3 32
1
end_operator
begin_operator
board car37 loc13
1
47 4
2
0 0 0 31
0 45 4 32
1
end_operator
begin_operator
board car37 loc14
1
47 5
2
0 0 0 31
0 45 5 32
1
end_operator
begin_operator
board car37 loc15
1
47 6
2
0 0 0 31
0 45 6 32
1
end_operator
begin_operator
board car37 loc16
1
47 7
2
0 0 0 31
0 45 7 32
1
end_operator
begin_operator
board car37 loc17
1
47 8
2
0 0 0 31
0 45 8 32
1
end_operator
begin_operator
board car37 loc18
1
47 9
2
0 0 0 31
0 45 9 32
1
end_operator
begin_operator
board car37 loc19
1
47 10
2
0 0 0 31
0 45 10 32
1
end_operator
begin_operator
board car37 loc2
1
47 11
2
0 0 0 31
0 45 11 32
1
end_operator
begin_operator
board car37 loc20
1
47 12
2
0 0 0 31
0 45 12 32
1
end_operator
begin_operator
board car37 loc21
1
47 13
2
0 0 0 31
0 45 13 32
1
end_operator
begin_operator
board car37 loc22
1
47 14
2
0 0 0 31
0 45 14 32
1
end_operator
begin_operator
board car37 loc23
1
47 15
2
0 0 0 31
0 45 15 32
1
end_operator
begin_operator
board car37 loc24
1
47 16
2
0 0 0 31
0 45 16 32
1
end_operator
begin_operator
board car37 loc25
1
47 17
2
0 0 0 31
0 45 17 32
1
end_operator
begin_operator
board car37 loc26
1
47 18
2
0 0 0 31
0 45 18 32
1
end_operator
begin_operator
board car37 loc27
1
47 19
2
0 0 0 31
0 45 19 32
1
end_operator
begin_operator
board car37 loc28
1
47 20
2
0 0 0 31
0 45 20 32
1
end_operator
begin_operator
board car37 loc29
1
47 21
2
0 0 0 31
0 45 21 32
1
end_operator
begin_operator
board car37 loc3
1
47 22
2
0 0 0 31
0 45 22 32
1
end_operator
begin_operator
board car37 loc30
1
47 23
2
0 0 0 31
0 45 23 32
1
end_operator
begin_operator
board car37 loc31
1
47 24
2
0 0 0 31
0 45 24 32
1
end_operator
begin_operator
board car37 loc32
1
47 25
2
0 0 0 31
0 45 25 32
1
end_operator
begin_operator
board car37 loc4
1
47 26
2
0 0 0 31
0 45 26 32
1
end_operator
begin_operator
board car37 loc5
1
47 27
2
0 0 0 31
0 45 27 32
1
end_operator
begin_operator
board car37 loc6
1
47 28
2
0 0 0 31
0 45 28 32
1
end_operator
begin_operator
board car37 loc7
1
47 29
2
0 0 0 31
0 45 29 32
1
end_operator
begin_operator
board car37 loc8
1
47 30
2
0 0 0 31
0 45 30 32
1
end_operator
begin_operator
board car37 loc9
1
47 31
2
0 0 0 31
0 45 31 32
1
end_operator
begin_operator
board car38 loc1
1
47 0
2
0 0 0 32
0 4 0 32
1
end_operator
begin_operator
board car38 loc10
1
47 1
2
0 0 0 32
0 4 1 32
1
end_operator
begin_operator
board car38 loc11
1
47 2
2
0 0 0 32
0 4 2 32
1
end_operator
begin_operator
board car38 loc12
1
47 3
2
0 0 0 32
0 4 3 32
1
end_operator
begin_operator
board car38 loc13
1
47 4
2
0 0 0 32
0 4 4 32
1
end_operator
begin_operator
board car38 loc14
1
47 5
2
0 0 0 32
0 4 5 32
1
end_operator
begin_operator
board car38 loc15
1
47 6
2
0 0 0 32
0 4 6 32
1
end_operator
begin_operator
board car38 loc16
1
47 7
2
0 0 0 32
0 4 7 32
1
end_operator
begin_operator
board car38 loc17
1
47 8
2
0 0 0 32
0 4 8 32
1
end_operator
begin_operator
board car38 loc18
1
47 9
2
0 0 0 32
0 4 9 32
1
end_operator
begin_operator
board car38 loc19
1
47 10
2
0 0 0 32
0 4 10 32
1
end_operator
begin_operator
board car38 loc2
1
47 11
2
0 0 0 32
0 4 11 32
1
end_operator
begin_operator
board car38 loc20
1
47 12
2
0 0 0 32
0 4 12 32
1
end_operator
begin_operator
board car38 loc21
1
47 13
2
0 0 0 32
0 4 13 32
1
end_operator
begin_operator
board car38 loc22
1
47 14
2
0 0 0 32
0 4 14 32
1
end_operator
begin_operator
board car38 loc23
1
47 15
2
0 0 0 32
0 4 15 32
1
end_operator
begin_operator
board car38 loc24
1
47 16
2
0 0 0 32
0 4 16 32
1
end_operator
begin_operator
board car38 loc25
1
47 17
2
0 0 0 32
0 4 17 32
1
end_operator
begin_operator
board car38 loc26
1
47 18
2
0 0 0 32
0 4 18 32
1
end_operator
begin_operator
board car38 loc27
1
47 19
2
0 0 0 32
0 4 19 32
1
end_operator
begin_operator
board car38 loc28
1
47 20
2
0 0 0 32
0 4 20 32
1
end_operator
begin_operator
board car38 loc29
1
47 21
2
0 0 0 32
0 4 21 32
1
end_operator
begin_operator
board car38 loc3
1
47 22
2
0 0 0 32
0 4 22 32
1
end_operator
begin_operator
board car38 loc30
1
47 23
2
0 0 0 32
0 4 23 32
1
end_operator
begin_operator
board car38 loc31
1
47 24
2
0 0 0 32
0 4 24 32
1
end_operator
begin_operator
board car38 loc32
1
47 25
2
0 0 0 32
0 4 25 32
1
end_operator
begin_operator
board car38 loc4
1
47 26
2
0 0 0 32
0 4 26 32
1
end_operator
begin_operator
board car38 loc5
1
47 27
2
0 0 0 32
0 4 27 32
1
end_operator
begin_operator
board car38 loc6
1
47 28
2
0 0 0 32
0 4 28 32
1
end_operator
begin_operator
board car38 loc7
1
47 29
2
0 0 0 32
0 4 29 32
1
end_operator
begin_operator
board car38 loc8
1
47 30
2
0 0 0 32
0 4 30 32
1
end_operator
begin_operator
board car38 loc9
1
47 31
2
0 0 0 32
0 4 31 32
1
end_operator
begin_operator
board car39 loc1
1
47 0
2
0 0 0 33
0 10 0 32
1
end_operator
begin_operator
board car39 loc10
1
47 1
2
0 0 0 33
0 10 1 32
1
end_operator
begin_operator
board car39 loc11
1
47 2
2
0 0 0 33
0 10 2 32
1
end_operator
begin_operator
board car39 loc12
1
47 3
2
0 0 0 33
0 10 3 32
1
end_operator
begin_operator
board car39 loc13
1
47 4
2
0 0 0 33
0 10 4 32
1
end_operator
begin_operator
board car39 loc14
1
47 5
2
0 0 0 33
0 10 5 32
1
end_operator
begin_operator
board car39 loc15
1
47 6
2
0 0 0 33
0 10 6 32
1
end_operator
begin_operator
board car39 loc16
1
47 7
2
0 0 0 33
0 10 7 32
1
end_operator
begin_operator
board car39 loc17
1
47 8
2
0 0 0 33
0 10 8 32
1
end_operator
begin_operator
board car39 loc18
1
47 9
2
0 0 0 33
0 10 9 32
1
end_operator
begin_operator
board car39 loc19
1
47 10
2
0 0 0 33
0 10 10 32
1
end_operator
begin_operator
board car39 loc2
1
47 11
2
0 0 0 33
0 10 11 32
1
end_operator
begin_operator
board car39 loc20
1
47 12
2
0 0 0 33
0 10 12 32
1
end_operator
begin_operator
board car39 loc21
1
47 13
2
0 0 0 33
0 10 13 32
1
end_operator
begin_operator
board car39 loc22
1
47 14
2
0 0 0 33
0 10 14 32
1
end_operator
begin_operator
board car39 loc23
1
47 15
2
0 0 0 33
0 10 15 32
1
end_operator
begin_operator
board car39 loc24
1
47 16
2
0 0 0 33
0 10 16 32
1
end_operator
begin_operator
board car39 loc25
1
47 17
2
0 0 0 33
0 10 17 32
1
end_operator
begin_operator
board car39 loc26
1
47 18
2
0 0 0 33
0 10 18 32
1
end_operator
begin_operator
board car39 loc27
1
47 19
2
0 0 0 33
0 10 19 32
1
end_operator
begin_operator
board car39 loc28
1
47 20
2
0 0 0 33
0 10 20 32
1
end_operator
begin_operator
board car39 loc29
1
47 21
2
0 0 0 33
0 10 21 32
1
end_operator
begin_operator
board car39 loc3
1
47 22
2
0 0 0 33
0 10 22 32
1
end_operator
begin_operator
board car39 loc30
1
47 23
2
0 0 0 33
0 10 23 32
1
end_operator
begin_operator
board car39 loc31
1
47 24
2
0 0 0 33
0 10 24 32
1
end_operator
begin_operator
board car39 loc32
1
47 25
2
0 0 0 33
0 10 25 32
1
end_operator
begin_operator
board car39 loc4
1
47 26
2
0 0 0 33
0 10 26 32
1
end_operator
begin_operator
board car39 loc5
1
47 27
2
0 0 0 33
0 10 27 32
1
end_operator
begin_operator
board car39 loc6
1
47 28
2
0 0 0 33
0 10 28 32
1
end_operator
begin_operator
board car39 loc7
1
47 29
2
0 0 0 33
0 10 29 32
1
end_operator
begin_operator
board car39 loc8
1
47 30
2
0 0 0 33
0 10 30 32
1
end_operator
begin_operator
board car39 loc9
1
47 31
2
0 0 0 33
0 10 31 32
1
end_operator
begin_operator
board car4 loc1
1
47 0
2
0 0 0 34
0 16 0 32
1
end_operator
begin_operator
board car4 loc10
1
47 1
2
0 0 0 34
0 16 1 32
1
end_operator
begin_operator
board car4 loc11
1
47 2
2
0 0 0 34
0 16 2 32
1
end_operator
begin_operator
board car4 loc12
1
47 3
2
0 0 0 34
0 16 3 32
1
end_operator
begin_operator
board car4 loc13
1
47 4
2
0 0 0 34
0 16 4 32
1
end_operator
begin_operator
board car4 loc14
1
47 5
2
0 0 0 34
0 16 5 32
1
end_operator
begin_operator
board car4 loc15
1
47 6
2
0 0 0 34
0 16 6 32
1
end_operator
begin_operator
board car4 loc16
1
47 7
2
0 0 0 34
0 16 7 32
1
end_operator
begin_operator
board car4 loc17
1
47 8
2
0 0 0 34
0 16 8 32
1
end_operator
begin_operator
board car4 loc18
1
47 9
2
0 0 0 34
0 16 9 32
1
end_operator
begin_operator
board car4 loc19
1
47 10
2
0 0 0 34
0 16 10 32
1
end_operator
begin_operator
board car4 loc2
1
47 11
2
0 0 0 34
0 16 11 32
1
end_operator
begin_operator
board car4 loc20
1
47 12
2
0 0 0 34
0 16 12 32
1
end_operator
begin_operator
board car4 loc21
1
47 13
2
0 0 0 34
0 16 13 32
1
end_operator
begin_operator
board car4 loc22
1
47 14
2
0 0 0 34
0 16 14 32
1
end_operator
begin_operator
board car4 loc23
1
47 15
2
0 0 0 34
0 16 15 32
1
end_operator
begin_operator
board car4 loc24
1
47 16
2
0 0 0 34
0 16 16 32
1
end_operator
begin_operator
board car4 loc25
1
47 17
2
0 0 0 34
0 16 17 32
1
end_operator
begin_operator
board car4 loc26
1
47 18
2
0 0 0 34
0 16 18 32
1
end_operator
begin_operator
board car4 loc27
1
47 19
2
0 0 0 34
0 16 19 32
1
end_operator
begin_operator
board car4 loc28
1
47 20
2
0 0 0 34
0 16 20 32
1
end_operator
begin_operator
board car4 loc29
1
47 21
2
0 0 0 34
0 16 21 32
1
end_operator
begin_operator
board car4 loc3
1
47 22
2
0 0 0 34
0 16 22 32
1
end_operator
begin_operator
board car4 loc30
1
47 23
2
0 0 0 34
0 16 23 32
1
end_operator
begin_operator
board car4 loc31
1
47 24
2
0 0 0 34
0 16 24 32
1
end_operator
begin_operator
board car4 loc32
1
47 25
2
0 0 0 34
0 16 25 32
1
end_operator
begin_operator
board car4 loc4
1
47 26
2
0 0 0 34
0 16 26 32
1
end_operator
begin_operator
board car4 loc5
1
47 27
2
0 0 0 34
0 16 27 32
1
end_operator
begin_operator
board car4 loc6
1
47 28
2
0 0 0 34
0 16 28 32
1
end_operator
begin_operator
board car4 loc7
1
47 29
2
0 0 0 34
0 16 29 32
1
end_operator
begin_operator
board car4 loc8
1
47 30
2
0 0 0 34
0 16 30 32
1
end_operator
begin_operator
board car4 loc9
1
47 31
2
0 0 0 34
0 16 31 32
1
end_operator
begin_operator
board car40 loc1
1
47 0
2
0 0 0 35
0 22 0 32
1
end_operator
begin_operator
board car40 loc10
1
47 1
2
0 0 0 35
0 22 1 32
1
end_operator
begin_operator
board car40 loc11
1
47 2
2
0 0 0 35
0 22 2 32
1
end_operator
begin_operator
board car40 loc12
1
47 3
2
0 0 0 35
0 22 3 32
1
end_operator
begin_operator
board car40 loc13
1
47 4
2
0 0 0 35
0 22 4 32
1
end_operator
begin_operator
board car40 loc14
1
47 5
2
0 0 0 35
0 22 5 32
1
end_operator
begin_operator
board car40 loc15
1
47 6
2
0 0 0 35
0 22 6 32
1
end_operator
begin_operator
board car40 loc16
1
47 7
2
0 0 0 35
0 22 7 32
1
end_operator
begin_operator
board car40 loc17
1
47 8
2
0 0 0 35
0 22 8 32
1
end_operator
begin_operator
board car40 loc18
1
47 9
2
0 0 0 35
0 22 9 32
1
end_operator
begin_operator
board car40 loc19
1
47 10
2
0 0 0 35
0 22 10 32
1
end_operator
begin_operator
board car40 loc2
1
47 11
2
0 0 0 35
0 22 11 32
1
end_operator
begin_operator
board car40 loc20
1
47 12
2
0 0 0 35
0 22 12 32
1
end_operator
begin_operator
board car40 loc21
1
47 13
2
0 0 0 35
0 22 13 32
1
end_operator
begin_operator
board car40 loc22
1
47 14
2
0 0 0 35
0 22 14 32
1
end_operator
begin_operator
board car40 loc23
1
47 15
2
0 0 0 35
0 22 15 32
1
end_operator
begin_operator
board car40 loc24
1
47 16
2
0 0 0 35
0 22 16 32
1
end_operator
begin_operator
board car40 loc25
1
47 17
2
0 0 0 35
0 22 17 32
1
end_operator
begin_operator
board car40 loc26
1
47 18
2
0 0 0 35
0 22 18 32
1
end_operator
begin_operator
board car40 loc27
1
47 19
2
0 0 0 35
0 22 19 32
1
end_operator
begin_operator
board car40 loc28
1
47 20
2
0 0 0 35
0 22 20 32
1
end_operator
begin_operator
board car40 loc29
1
47 21
2
0 0 0 35
0 22 21 32
1
end_operator
begin_operator
board car40 loc3
1
47 22
2
0 0 0 35
0 22 22 32
1
end_operator
begin_operator
board car40 loc30
1
47 23
2
0 0 0 35
0 22 23 32
1
end_operator
begin_operator
board car40 loc31
1
47 24
2
0 0 0 35
0 22 24 32
1
end_operator
begin_operator
board car40 loc32
1
47 25
2
0 0 0 35
0 22 25 32
1
end_operator
begin_operator
board car40 loc4
1
47 26
2
0 0 0 35
0 22 26 32
1
end_operator
begin_operator
board car40 loc5
1
47 27
2
0 0 0 35
0 22 27 32
1
end_operator
begin_operator
board car40 loc6
1
47 28
2
0 0 0 35
0 22 28 32
1
end_operator
begin_operator
board car40 loc7
1
47 29
2
0 0 0 35
0 22 29 32
1
end_operator
begin_operator
board car40 loc8
1
47 30
2
0 0 0 35
0 22 30 32
1
end_operator
begin_operator
board car40 loc9
1
47 31
2
0 0 0 35
0 22 31 32
1
end_operator
begin_operator
board car41 loc1
1
47 0
2
0 0 0 36
0 28 0 32
1
end_operator
begin_operator
board car41 loc10
1
47 1
2
0 0 0 36
0 28 1 32
1
end_operator
begin_operator
board car41 loc11
1
47 2
2
0 0 0 36
0 28 2 32
1
end_operator
begin_operator
board car41 loc12
1
47 3
2
0 0 0 36
0 28 3 32
1
end_operator
begin_operator
board car41 loc13
1
47 4
2
0 0 0 36
0 28 4 32
1
end_operator
begin_operator
board car41 loc14
1
47 5
2
0 0 0 36
0 28 5 32
1
end_operator
begin_operator
board car41 loc15
1
47 6
2
0 0 0 36
0 28 6 32
1
end_operator
begin_operator
board car41 loc16
1
47 7
2
0 0 0 36
0 28 7 32
1
end_operator
begin_operator
board car41 loc17
1
47 8
2
0 0 0 36
0 28 8 32
1
end_operator
begin_operator
board car41 loc18
1
47 9
2
0 0 0 36
0 28 9 32
1
end_operator
begin_operator
board car41 loc19
1
47 10
2
0 0 0 36
0 28 10 32
1
end_operator
begin_operator
board car41 loc2
1
47 11
2
0 0 0 36
0 28 11 32
1
end_operator
begin_operator
board car41 loc20
1
47 12
2
0 0 0 36
0 28 12 32
1
end_operator
begin_operator
board car41 loc21
1
47 13
2
0 0 0 36
0 28 13 32
1
end_operator
begin_operator
board car41 loc22
1
47 14
2
0 0 0 36
0 28 14 32
1
end_operator
begin_operator
board car41 loc23
1
47 15
2
0 0 0 36
0 28 15 32
1
end_operator
begin_operator
board car41 loc24
1
47 16
2
0 0 0 36
0 28 16 32
1
end_operator
begin_operator
board car41 loc25
1
47 17
2
0 0 0 36
0 28 17 32
1
end_operator
begin_operator
board car41 loc26
1
47 18
2
0 0 0 36
0 28 18 32
1
end_operator
begin_operator
board car41 loc27
1
47 19
2
0 0 0 36
0 28 19 32
1
end_operator
begin_operator
board car41 loc28
1
47 20
2
0 0 0 36
0 28 20 32
1
end_operator
begin_operator
board car41 loc29
1
47 21
2
0 0 0 36
0 28 21 32
1
end_operator
begin_operator
board car41 loc3
1
47 22
2
0 0 0 36
0 28 22 32
1
end_operator
begin_operator
board car41 loc30
1
47 23
2
0 0 0 36
0 28 23 32
1
end_operator
begin_operator
board car41 loc31
1
47 24
2
0 0 0 36
0 28 24 32
1
end_operator
begin_operator
board car41 loc32
1
47 25
2
0 0 0 36
0 28 25 32
1
end_operator
begin_operator
board car41 loc4
1
47 26
2
0 0 0 36
0 28 26 32
1
end_operator
begin_operator
board car41 loc5
1
47 27
2
0 0 0 36
0 28 27 32
1
end_operator
begin_operator
board car41 loc6
1
47 28
2
0 0 0 36
0 28 28 32
1
end_operator
begin_operator
board car41 loc7
1
47 29
2
0 0 0 36
0 28 29 32
1
end_operator
begin_operator
board car41 loc8
1
47 30
2
0 0 0 36
0 28 30 32
1
end_operator
begin_operator
board car41 loc9
1
47 31
2
0 0 0 36
0 28 31 32
1
end_operator
begin_operator
board car42 loc1
1
47 0
2
0 0 0 37
0 34 0 32
1
end_operator
begin_operator
board car42 loc10
1
47 1
2
0 0 0 37
0 34 1 32
1
end_operator
begin_operator
board car42 loc11
1
47 2
2
0 0 0 37
0 34 2 32
1
end_operator
begin_operator
board car42 loc12
1
47 3
2
0 0 0 37
0 34 3 32
1
end_operator
begin_operator
board car42 loc13
1
47 4
2
0 0 0 37
0 34 4 32
1
end_operator
begin_operator
board car42 loc14
1
47 5
2
0 0 0 37
0 34 5 32
1
end_operator
begin_operator
board car42 loc15
1
47 6
2
0 0 0 37
0 34 6 32
1
end_operator
begin_operator
board car42 loc16
1
47 7
2
0 0 0 37
0 34 7 32
1
end_operator
begin_operator
board car42 loc17
1
47 8
2
0 0 0 37
0 34 8 32
1
end_operator
begin_operator
board car42 loc18
1
47 9
2
0 0 0 37
0 34 9 32
1
end_operator
begin_operator
board car42 loc19
1
47 10
2
0 0 0 37
0 34 10 32
1
end_operator
begin_operator
board car42 loc2
1
47 11
2
0 0 0 37
0 34 11 32
1
end_operator
begin_operator
board car42 loc20
1
47 12
2
0 0 0 37
0 34 12 32
1
end_operator
begin_operator
board car42 loc21
1
47 13
2
0 0 0 37
0 34 13 32
1
end_operator
begin_operator
board car42 loc22
1
47 14
2
0 0 0 37
0 34 14 32
1
end_operator
begin_operator
board car42 loc23
1
47 15
2
0 0 0 37
0 34 15 32
1
end_operator
begin_operator
board car42 loc24
1
47 16
2
0 0 0 37
0 34 16 32
1
end_operator
begin_operator
board car42 loc25
1
47 17
2
0 0 0 37
0 34 17 32
1
end_operator
begin_operator
board car42 loc26
1
47 18
2
0 0 0 37
0 34 18 32
1
end_operator
begin_operator
board car42 loc27
1
47 19
2
0 0 0 37
0 34 19 32
1
end_operator
begin_operator
board car42 loc28
1
47 20
2
0 0 0 37
0 34 20 32
1
end_operator
begin_operator
board car42 loc29
1
47 21
2
0 0 0 37
0 34 21 32
1
end_operator
begin_operator
board car42 loc3
1
47 22
2
0 0 0 37
0 34 22 32
1
end_operator
begin_operator
board car42 loc30
1
47 23
2
0 0 0 37
0 34 23 32
1
end_operator
begin_operator
board car42 loc31
1
47 24
2
0 0 0 37
0 34 24 32
1
end_operator
begin_operator
board car42 loc32
1
47 25
2
0 0 0 37
0 34 25 32
1
end_operator
begin_operator
board car42 loc4
1
47 26
2
0 0 0 37
0 34 26 32
1
end_operator
begin_operator
board car42 loc5
1
47 27
2
0 0 0 37
0 34 27 32
1
end_operator
begin_operator
board car42 loc6
1
47 28
2
0 0 0 37
0 34 28 32
1
end_operator
begin_operator
board car42 loc7
1
47 29
2
0 0 0 37
0 34 29 32
1
end_operator
begin_operator
board car42 loc8
1
47 30
2
0 0 0 37
0 34 30 32
1
end_operator
begin_operator
board car42 loc9
1
47 31
2
0 0 0 37
0 34 31 32
1
end_operator
begin_operator
board car43 loc1
1
47 0
2
0 0 0 38
0 40 0 32
1
end_operator
begin_operator
board car43 loc10
1
47 1
2
0 0 0 38
0 40 1 32
1
end_operator
begin_operator
board car43 loc11
1
47 2
2
0 0 0 38
0 40 2 32
1
end_operator
begin_operator
board car43 loc12
1
47 3
2
0 0 0 38
0 40 3 32
1
end_operator
begin_operator
board car43 loc13
1
47 4
2
0 0 0 38
0 40 4 32
1
end_operator
begin_operator
board car43 loc14
1
47 5
2
0 0 0 38
0 40 5 32
1
end_operator
begin_operator
board car43 loc15
1
47 6
2
0 0 0 38
0 40 6 32
1
end_operator
begin_operator
board car43 loc16
1
47 7
2
0 0 0 38
0 40 7 32
1
end_operator
begin_operator
board car43 loc17
1
47 8
2
0 0 0 38
0 40 8 32
1
end_operator
begin_operator
board car43 loc18
1
47 9
2
0 0 0 38
0 40 9 32
1
end_operator
begin_operator
board car43 loc19
1
47 10
2
0 0 0 38
0 40 10 32
1
end_operator
begin_operator
board car43 loc2
1
47 11
2
0 0 0 38
0 40 11 32
1
end_operator
begin_operator
board car43 loc20
1
47 12
2
0 0 0 38
0 40 12 32
1
end_operator
begin_operator
board car43 loc21
1
47 13
2
0 0 0 38
0 40 13 32
1
end_operator
begin_operator
board car43 loc22
1
47 14
2
0 0 0 38
0 40 14 32
1
end_operator
begin_operator
board car43 loc23
1
47 15
2
0 0 0 38
0 40 15 32
1
end_operator
begin_operator
board car43 loc24
1
47 16
2
0 0 0 38
0 40 16 32
1
end_operator
begin_operator
board car43 loc25
1
47 17
2
0 0 0 38
0 40 17 32
1
end_operator
begin_operator
board car43 loc26
1
47 18
2
0 0 0 38
0 40 18 32
1
end_operator
begin_operator
board car43 loc27
1
47 19
2
0 0 0 38
0 40 19 32
1
end_operator
begin_operator
board car43 loc28
1
47 20
2
0 0 0 38
0 40 20 32
1
end_operator
begin_operator
board car43 loc29
1
47 21
2
0 0 0 38
0 40 21 32
1
end_operator
begin_operator
board car43 loc3
1
47 22
2
0 0 0 38
0 40 22 32
1
end_operator
begin_operator
board car43 loc30
1
47 23
2
0 0 0 38
0 40 23 32
1
end_operator
begin_operator
board car43 loc31
1
47 24
2
0 0 0 38
0 40 24 32
1
end_operator
begin_operator
board car43 loc32
1
47 25
2
0 0 0 38
0 40 25 32
1
end_operator
begin_operator
board car43 loc4
1
47 26
2
0 0 0 38
0 40 26 32
1
end_operator
begin_operator
board car43 loc5
1
47 27
2
0 0 0 38
0 40 27 32
1
end_operator
begin_operator
board car43 loc6
1
47 28
2
0 0 0 38
0 40 28 32
1
end_operator
begin_operator
board car43 loc7
1
47 29
2
0 0 0 38
0 40 29 32
1
end_operator
begin_operator
board car43 loc8
1
47 30
2
0 0 0 38
0 40 30 32
1
end_operator
begin_operator
board car43 loc9
1
47 31
2
0 0 0 38
0 40 31 32
1
end_operator
begin_operator
board car44 loc1
1
47 0
2
0 0 0 39
0 46 0 32
1
end_operator
begin_operator
board car44 loc10
1
47 1
2
0 0 0 39
0 46 1 32
1
end_operator
begin_operator
board car44 loc11
1
47 2
2
0 0 0 39
0 46 2 32
1
end_operator
begin_operator
board car44 loc12
1
47 3
2
0 0 0 39
0 46 3 32
1
end_operator
begin_operator
board car44 loc13
1
47 4
2
0 0 0 39
0 46 4 32
1
end_operator
begin_operator
board car44 loc14
1
47 5
2
0 0 0 39
0 46 5 32
1
end_operator
begin_operator
board car44 loc15
1
47 6
2
0 0 0 39
0 46 6 32
1
end_operator
begin_operator
board car44 loc16
1
47 7
2
0 0 0 39
0 46 7 32
1
end_operator
begin_operator
board car44 loc17
1
47 8
2
0 0 0 39
0 46 8 32
1
end_operator
begin_operator
board car44 loc18
1
47 9
2
0 0 0 39
0 46 9 32
1
end_operator
begin_operator
board car44 loc19
1
47 10
2
0 0 0 39
0 46 10 32
1
end_operator
begin_operator
board car44 loc2
1
47 11
2
0 0 0 39
0 46 11 32
1
end_operator
begin_operator
board car44 loc20
1
47 12
2
0 0 0 39
0 46 12 32
1
end_operator
begin_operator
board car44 loc21
1
47 13
2
0 0 0 39
0 46 13 32
1
end_operator
begin_operator
board car44 loc22
1
47 14
2
0 0 0 39
0 46 14 32
1
end_operator
begin_operator
board car44 loc23
1
47 15
2
0 0 0 39
0 46 15 32
1
end_operator
begin_operator
board car44 loc24
1
47 16
2
0 0 0 39
0 46 16 32
1
end_operator
begin_operator
board car44 loc25
1
47 17
2
0 0 0 39
0 46 17 32
1
end_operator
begin_operator
board car44 loc26
1
47 18
2
0 0 0 39
0 46 18 32
1
end_operator
begin_operator
board car44 loc27
1
47 19
2
0 0 0 39
0 46 19 32
1
end_operator
begin_operator
board car44 loc28
1
47 20
2
0 0 0 39
0 46 20 32
1
end_operator
begin_operator
board car44 loc29
1
47 21
2
0 0 0 39
0 46 21 32
1
end_operator
begin_operator
board car44 loc3
1
47 22
2
0 0 0 39
0 46 22 32
1
end_operator
begin_operator
board car44 loc30
1
47 23
2
0 0 0 39
0 46 23 32
1
end_operator
begin_operator
board car44 loc31
1
47 24
2
0 0 0 39
0 46 24 32
1
end_operator
begin_operator
board car44 loc32
1
47 25
2
0 0 0 39
0 46 25 32
1
end_operator
begin_operator
board car44 loc4
1
47 26
2
0 0 0 39
0 46 26 32
1
end_operator
begin_operator
board car44 loc5
1
47 27
2
0 0 0 39
0 46 27 32
1
end_operator
begin_operator
board car44 loc6
1
47 28
2
0 0 0 39
0 46 28 32
1
end_operator
begin_operator
board car44 loc7
1
47 29
2
0 0 0 39
0 46 29 32
1
end_operator
begin_operator
board car44 loc8
1
47 30
2
0 0 0 39
0 46 30 32
1
end_operator
begin_operator
board car44 loc9
1
47 31
2
0 0 0 39
0 46 31 32
1
end_operator
begin_operator
board car45 loc1
1
47 0
2
0 0 0 40
0 5 0 32
1
end_operator
begin_operator
board car45 loc10
1
47 1
2
0 0 0 40
0 5 1 32
1
end_operator
begin_operator
board car45 loc11
1
47 2
2
0 0 0 40
0 5 2 32
1
end_operator
begin_operator
board car45 loc12
1
47 3
2
0 0 0 40
0 5 3 32
1
end_operator
begin_operator
board car45 loc13
1
47 4
2
0 0 0 40
0 5 4 32
1
end_operator
begin_operator
board car45 loc14
1
47 5
2
0 0 0 40
0 5 5 32
1
end_operator
begin_operator
board car45 loc15
1
47 6
2
0 0 0 40
0 5 6 32
1
end_operator
begin_operator
board car45 loc16
1
47 7
2
0 0 0 40
0 5 7 32
1
end_operator
begin_operator
board car45 loc17
1
47 8
2
0 0 0 40
0 5 8 32
1
end_operator
begin_operator
board car45 loc18
1
47 9
2
0 0 0 40
0 5 9 32
1
end_operator
begin_operator
board car45 loc19
1
47 10
2
0 0 0 40
0 5 10 32
1
end_operator
begin_operator
board car45 loc2
1
47 11
2
0 0 0 40
0 5 11 32
1
end_operator
begin_operator
board car45 loc20
1
47 12
2
0 0 0 40
0 5 12 32
1
end_operator
begin_operator
board car45 loc21
1
47 13
2
0 0 0 40
0 5 13 32
1
end_operator
begin_operator
board car45 loc22
1
47 14
2
0 0 0 40
0 5 14 32
1
end_operator
begin_operator
board car45 loc23
1
47 15
2
0 0 0 40
0 5 15 32
1
end_operator
begin_operator
board car45 loc24
1
47 16
2
0 0 0 40
0 5 16 32
1
end_operator
begin_operator
board car45 loc25
1
47 17
2
0 0 0 40
0 5 17 32
1
end_operator
begin_operator
board car45 loc26
1
47 18
2
0 0 0 40
0 5 18 32
1
end_operator
begin_operator
board car45 loc27
1
47 19
2
0 0 0 40
0 5 19 32
1
end_operator
begin_operator
board car45 loc28
1
47 20
2
0 0 0 40
0 5 20 32
1
end_operator
begin_operator
board car45 loc29
1
47 21
2
0 0 0 40
0 5 21 32
1
end_operator
begin_operator
board car45 loc3
1
47 22
2
0 0 0 40
0 5 22 32
1
end_operator
begin_operator
board car45 loc30
1
47 23
2
0 0 0 40
0 5 23 32
1
end_operator
begin_operator
board car45 loc31
1
47 24
2
0 0 0 40
0 5 24 32
1
end_operator
begin_operator
board car45 loc32
1
47 25
2
0 0 0 40
0 5 25 32
1
end_operator
begin_operator
board car45 loc4
1
47 26
2
0 0 0 40
0 5 26 32
1
end_operator
begin_operator
board car45 loc5
1
47 27
2
0 0 0 40
0 5 27 32
1
end_operator
begin_operator
board car45 loc6
1
47 28
2
0 0 0 40
0 5 28 32
1
end_operator
begin_operator
board car45 loc7
1
47 29
2
0 0 0 40
0 5 29 32
1
end_operator
begin_operator
board car45 loc8
1
47 30
2
0 0 0 40
0 5 30 32
1
end_operator
begin_operator
board car45 loc9
1
47 31
2
0 0 0 40
0 5 31 32
1
end_operator
begin_operator
board car46 loc1
1
47 0
2
0 0 0 41
0 11 0 32
1
end_operator
begin_operator
board car46 loc10
1
47 1
2
0 0 0 41
0 11 1 32
1
end_operator
begin_operator
board car46 loc11
1
47 2
2
0 0 0 41
0 11 2 32
1
end_operator
begin_operator
board car46 loc12
1
47 3
2
0 0 0 41
0 11 3 32
1
end_operator
begin_operator
board car46 loc13
1
47 4
2
0 0 0 41
0 11 4 32
1
end_operator
begin_operator
board car46 loc14
1
47 5
2
0 0 0 41
0 11 5 32
1
end_operator
begin_operator
board car46 loc15
1
47 6
2
0 0 0 41
0 11 6 32
1
end_operator
begin_operator
board car46 loc16
1
47 7
2
0 0 0 41
0 11 7 32
1
end_operator
begin_operator
board car46 loc17
1
47 8
2
0 0 0 41
0 11 8 32
1
end_operator
begin_operator
board car46 loc18
1
47 9
2
0 0 0 41
0 11 9 32
1
end_operator
begin_operator
board car46 loc19
1
47 10
2
0 0 0 41
0 11 10 32
1
end_operator
begin_operator
board car46 loc2
1
47 11
2
0 0 0 41
0 11 11 32
1
end_operator
begin_operator
board car46 loc20
1
47 12
2
0 0 0 41
0 11 12 32
1
end_operator
begin_operator
board car46 loc21
1
47 13
2
0 0 0 41
0 11 13 32
1
end_operator
begin_operator
board car46 loc22
1
47 14
2
0 0 0 41
0 11 14 32
1
end_operator
begin_operator
board car46 loc23
1
47 15
2
0 0 0 41
0 11 15 32
1
end_operator
begin_operator
board car46 loc24
1
47 16
2
0 0 0 41
0 11 16 32
1
end_operator
begin_operator
board car46 loc25
1
47 17
2
0 0 0 41
0 11 17 32
1
end_operator
begin_operator
board car46 loc26
1
47 18
2
0 0 0 41
0 11 18 32
1
end_operator
begin_operator
board car46 loc27
1
47 19
2
0 0 0 41
0 11 19 32
1
end_operator
begin_operator
board car46 loc28
1
47 20
2
0 0 0 41
0 11 20 32
1
end_operator
begin_operator
board car46 loc29
1
47 21
2
0 0 0 41
0 11 21 32
1
end_operator
begin_operator
board car46 loc3
1
47 22
2
0 0 0 41
0 11 22 32
1
end_operator
begin_operator
board car46 loc30
1
47 23
2
0 0 0 41
0 11 23 32
1
end_operator
begin_operator
board car46 loc31
1
47 24
2
0 0 0 41
0 11 24 32
1
end_operator
begin_operator
board car46 loc32
1
47 25
2
0 0 0 41
0 11 25 32
1
end_operator
begin_operator
board car46 loc4
1
47 26
2
0 0 0 41
0 11 26 32
1
end_operator
begin_operator
board car46 loc5
1
47 27
2
0 0 0 41
0 11 27 32
1
end_operator
begin_operator
board car46 loc6
1
47 28
2
0 0 0 41
0 11 28 32
1
end_operator
begin_operator
board car46 loc7
1
47 29
2
0 0 0 41
0 11 29 32
1
end_operator
begin_operator
board car46 loc8
1
47 30
2
0 0 0 41
0 11 30 32
1
end_operator
begin_operator
board car46 loc9
1
47 31
2
0 0 0 41
0 11 31 32
1
end_operator
begin_operator
board car5 loc1
1
47 0
2
0 0 0 42
0 17 0 32
1
end_operator
begin_operator
board car5 loc10
1
47 1
2
0 0 0 42
0 17 1 32
1
end_operator
begin_operator
board car5 loc11
1
47 2
2
0 0 0 42
0 17 2 32
1
end_operator
begin_operator
board car5 loc12
1
47 3
2
0 0 0 42
0 17 3 32
1
end_operator
begin_operator
board car5 loc13
1
47 4
2
0 0 0 42
0 17 4 32
1
end_operator
begin_operator
board car5 loc14
1
47 5
2
0 0 0 42
0 17 5 32
1
end_operator
begin_operator
board car5 loc15
1
47 6
2
0 0 0 42
0 17 6 32
1
end_operator
begin_operator
board car5 loc16
1
47 7
2
0 0 0 42
0 17 7 32
1
end_operator
begin_operator
board car5 loc17
1
47 8
2
0 0 0 42
0 17 8 32
1
end_operator
begin_operator
board car5 loc18
1
47 9
2
0 0 0 42
0 17 9 32
1
end_operator
begin_operator
board car5 loc19
1
47 10
2
0 0 0 42
0 17 10 32
1
end_operator
begin_operator
board car5 loc2
1
47 11
2
0 0 0 42
0 17 11 32
1
end_operator
begin_operator
board car5 loc20
1
47 12
2
0 0 0 42
0 17 12 32
1
end_operator
begin_operator
board car5 loc21
1
47 13
2
0 0 0 42
0 17 13 32
1
end_operator
begin_operator
board car5 loc22
1
47 14
2
0 0 0 42
0 17 14 32
1
end_operator
begin_operator
board car5 loc23
1
47 15
2
0 0 0 42
0 17 15 32
1
end_operator
begin_operator
board car5 loc24
1
47 16
2
0 0 0 42
0 17 16 32
1
end_operator
begin_operator
board car5 loc25
1
47 17
2
0 0 0 42
0 17 17 32
1
end_operator
begin_operator
board car5 loc26
1
47 18
2
0 0 0 42
0 17 18 32
1
end_operator
begin_operator
board car5 loc27
1
47 19
2
0 0 0 42
0 17 19 32
1
end_operator
begin_operator
board car5 loc28
1
47 20
2
0 0 0 42
0 17 20 32
1
end_operator
begin_operator
board car5 loc29
1
47 21
2
0 0 0 42
0 17 21 32
1
end_operator
begin_operator
board car5 loc3
1
47 22
2
0 0 0 42
0 17 22 32
1
end_operator
begin_operator
board car5 loc30
1
47 23
2
0 0 0 42
0 17 23 32
1
end_operator
begin_operator
board car5 loc31
1
47 24
2
0 0 0 42
0 17 24 32
1
end_operator
begin_operator
board car5 loc32
1
47 25
2
0 0 0 42
0 17 25 32
1
end_operator
begin_operator
board car5 loc4
1
47 26
2
0 0 0 42
0 17 26 32
1
end_operator
begin_operator
board car5 loc5
1
47 27
2
0 0 0 42
0 17 27 32
1
end_operator
begin_operator
board car5 loc6
1
47 28
2
0 0 0 42
0 17 28 32
1
end_operator
begin_operator
board car5 loc7
1
47 29
2
0 0 0 42
0 17 29 32
1
end_operator
begin_operator
board car5 loc8
1
47 30
2
0 0 0 42
0 17 30 32
1
end_operator
begin_operator
board car5 loc9
1
47 31
2
0 0 0 42
0 17 31 32
1
end_operator
begin_operator
board car6 loc1
1
47 0
2
0 0 0 43
0 23 0 32
1
end_operator
begin_operator
board car6 loc10
1
47 1
2
0 0 0 43
0 23 1 32
1
end_operator
begin_operator
board car6 loc11
1
47 2
2
0 0 0 43
0 23 2 32
1
end_operator
begin_operator
board car6 loc12
1
47 3
2
0 0 0 43
0 23 3 32
1
end_operator
begin_operator
board car6 loc13
1
47 4
2
0 0 0 43
0 23 4 32
1
end_operator
begin_operator
board car6 loc14
1
47 5
2
0 0 0 43
0 23 5 32
1
end_operator
begin_operator
board car6 loc15
1
47 6
2
0 0 0 43
0 23 6 32
1
end_operator
begin_operator
board car6 loc16
1
47 7
2
0 0 0 43
0 23 7 32
1
end_operator
begin_operator
board car6 loc17
1
47 8
2
0 0 0 43
0 23 8 32
1
end_operator
begin_operator
board car6 loc18
1
47 9
2
0 0 0 43
0 23 9 32
1
end_operator
begin_operator
board car6 loc19
1
47 10
2
0 0 0 43
0 23 10 32
1
end_operator
begin_operator
board car6 loc2
1
47 11
2
0 0 0 43
0 23 11 32
1
end_operator
begin_operator
board car6 loc20
1
47 12
2
0 0 0 43
0 23 12 32
1
end_operator
begin_operator
board car6 loc21
1
47 13
2
0 0 0 43
0 23 13 32
1
end_operator
begin_operator
board car6 loc22
1
47 14
2
0 0 0 43
0 23 14 32
1
end_operator
begin_operator
board car6 loc23
1
47 15
2
0 0 0 43
0 23 15 32
1
end_operator
begin_operator
board car6 loc24
1
47 16
2
0 0 0 43
0 23 16 32
1
end_operator
begin_operator
board car6 loc25
1
47 17
2
0 0 0 43
0 23 17 32
1
end_operator
begin_operator
board car6 loc26
1
47 18
2
0 0 0 43
0 23 18 32
1
end_operator
begin_operator
board car6 loc27
1
47 19
2
0 0 0 43
0 23 19 32
1
end_operator
begin_operator
board car6 loc28
1
47 20
2
0 0 0 43
0 23 20 32
1
end_operator
begin_operator
board car6 loc29
1
47 21
2
0 0 0 43
0 23 21 32
1
end_operator
begin_operator
board car6 loc3
1
47 22
2
0 0 0 43
0 23 22 32
1
end_operator
begin_operator
board car6 loc30
1
47 23
2
0 0 0 43
0 23 23 32
1
end_operator
begin_operator
board car6 loc31
1
47 24
2
0 0 0 43
0 23 24 32
1
end_operator
begin_operator
board car6 loc32
1
47 25
2
0 0 0 43
0 23 25 32
1
end_operator
begin_operator
board car6 loc4
1
47 26
2
0 0 0 43
0 23 26 32
1
end_operator
begin_operator
board car6 loc5
1
47 27
2
0 0 0 43
0 23 27 32
1
end_operator
begin_operator
board car6 loc6
1
47 28
2
0 0 0 43
0 23 28 32
1
end_operator
begin_operator
board car6 loc7
1
47 29
2
0 0 0 43
0 23 29 32
1
end_operator
begin_operator
board car6 loc8
1
47 30
2
0 0 0 43
0 23 30 32
1
end_operator
begin_operator
board car6 loc9
1
47 31
2
0 0 0 43
0 23 31 32
1
end_operator
begin_operator
board car7 loc1
1
47 0
2
0 0 0 44
0 29 0 32
1
end_operator
begin_operator
board car7 loc10
1
47 1
2
0 0 0 44
0 29 1 32
1
end_operator
begin_operator
board car7 loc11
1
47 2
2
0 0 0 44
0 29 2 32
1
end_operator
begin_operator
board car7 loc12
1
47 3
2
0 0 0 44
0 29 3 32
1
end_operator
begin_operator
board car7 loc13
1
47 4
2
0 0 0 44
0 29 4 32
1
end_operator
begin_operator
board car7 loc14
1
47 5
2
0 0 0 44
0 29 5 32
1
end_operator
begin_operator
board car7 loc15
1
47 6
2
0 0 0 44
0 29 6 32
1
end_operator
begin_operator
board car7 loc16
1
47 7
2
0 0 0 44
0 29 7 32
1
end_operator
begin_operator
board car7 loc17
1
47 8
2
0 0 0 44
0 29 8 32
1
end_operator
begin_operator
board car7 loc18
1
47 9
2
0 0 0 44
0 29 9 32
1
end_operator
begin_operator
board car7 loc19
1
47 10
2
0 0 0 44
0 29 10 32
1
end_operator
begin_operator
board car7 loc2
1
47 11
2
0 0 0 44
0 29 11 32
1
end_operator
begin_operator
board car7 loc20
1
47 12
2
0 0 0 44
0 29 12 32
1
end_operator
begin_operator
board car7 loc21
1
47 13
2
0 0 0 44
0 29 13 32
1
end_operator
begin_operator
board car7 loc22
1
47 14
2
0 0 0 44
0 29 14 32
1
end_operator
begin_operator
board car7 loc23
1
47 15
2
0 0 0 44
0 29 15 32
1
end_operator
begin_operator
board car7 loc24
1
47 16
2
0 0 0 44
0 29 16 32
1
end_operator
begin_operator
board car7 loc25
1
47 17
2
0 0 0 44
0 29 17 32
1
end_operator
begin_operator
board car7 loc26
1
47 18
2
0 0 0 44
0 29 18 32
1
end_operator
begin_operator
board car7 loc27
1
47 19
2
0 0 0 44
0 29 19 32
1
end_operator
begin_operator
board car7 loc28
1
47 20
2
0 0 0 44
0 29 20 32
1
end_operator
begin_operator
board car7 loc29
1
47 21
2
0 0 0 44
0 29 21 32
1
end_operator
begin_operator
board car7 loc3
1
47 22
2
0 0 0 44
0 29 22 32
1
end_operator
begin_operator
board car7 loc30
1
47 23
2
0 0 0 44
0 29 23 32
1
end_operator
begin_operator
board car7 loc31
1
47 24
2
0 0 0 44
0 29 24 32
1
end_operator
begin_operator
board car7 loc32
1
47 25
2
0 0 0 44
0 29 25 32
1
end_operator
begin_operator
board car7 loc4
1
47 26
2
0 0 0 44
0 29 26 32
1
end_operator
begin_operator
board car7 loc5
1
47 27
2
0 0 0 44
0 29 27 32
1
end_operator
begin_operator
board car7 loc6
1
47 28
2
0 0 0 44
0 29 28 32
1
end_operator
begin_operator
board car7 loc7
1
47 29
2
0 0 0 44
0 29 29 32
1
end_operator
begin_operator
board car7 loc8
1
47 30
2
0 0 0 44
0 29 30 32
1
end_operator
begin_operator
board car7 loc9
1
47 31
2
0 0 0 44
0 29 31 32
1
end_operator
begin_operator
board car8 loc1
1
47 0
2
0 0 0 45
0 35 0 32
1
end_operator
begin_operator
board car8 loc10
1
47 1
2
0 0 0 45
0 35 1 32
1
end_operator
begin_operator
board car8 loc11
1
47 2
2
0 0 0 45
0 35 2 32
1
end_operator
begin_operator
board car8 loc12
1
47 3
2
0 0 0 45
0 35 3 32
1
end_operator
begin_operator
board car8 loc13
1
47 4
2
0 0 0 45
0 35 4 32
1
end_operator
begin_operator
board car8 loc14
1
47 5
2
0 0 0 45
0 35 5 32
1
end_operator
begin_operator
board car8 loc15
1
47 6
2
0 0 0 45
0 35 6 32
1
end_operator
begin_operator
board car8 loc16
1
47 7
2
0 0 0 45
0 35 7 32
1
end_operator
begin_operator
board car8 loc17
1
47 8
2
0 0 0 45
0 35 8 32
1
end_operator
begin_operator
board car8 loc18
1
47 9
2
0 0 0 45
0 35 9 32
1
end_operator
begin_operator
board car8 loc19
1
47 10
2
0 0 0 45
0 35 10 32
1
end_operator
begin_operator
board car8 loc2
1
47 11
2
0 0 0 45
0 35 11 32
1
end_operator
begin_operator
board car8 loc20
1
47 12
2
0 0 0 45
0 35 12 32
1
end_operator
begin_operator
board car8 loc21
1
47 13
2
0 0 0 45
0 35 13 32
1
end_operator
begin_operator
board car8 loc22
1
47 14
2
0 0 0 45
0 35 14 32
1
end_operator
begin_operator
board car8 loc23
1
47 15
2
0 0 0 45
0 35 15 32
1
end_operator
begin_operator
board car8 loc24
1
47 16
2
0 0 0 45
0 35 16 32
1
end_operator
begin_operator
board car8 loc25
1
47 17
2
0 0 0 45
0 35 17 32
1
end_operator
begin_operator
board car8 loc26
1
47 18
2
0 0 0 45
0 35 18 32
1
end_operator
begin_operator
board car8 loc27
1
47 19
2
0 0 0 45
0 35 19 32
1
end_operator
begin_operator
board car8 loc28
1
47 20
2
0 0 0 45
0 35 20 32
1
end_operator
begin_operator
board car8 loc29
1
47 21
2
0 0 0 45
0 35 21 32
1
end_operator
begin_operator
board car8 loc3
1
47 22
2
0 0 0 45
0 35 22 32
1
end_operator
begin_operator
board car8 loc30
1
47 23
2
0 0 0 45
0 35 23 32
1
end_operator
begin_operator
board car8 loc31
1
47 24
2
0 0 0 45
0 35 24 32
1
end_operator
begin_operator
board car8 loc32
1
47 25
2
0 0 0 45
0 35 25 32
1
end_operator
begin_operator
board car8 loc4
1
47 26
2
0 0 0 45
0 35 26 32
1
end_operator
begin_operator
board car8 loc5
1
47 27
2
0 0 0 45
0 35 27 32
1
end_operator
begin_operator
board car8 loc6
1
47 28
2
0 0 0 45
0 35 28 32
1
end_operator
begin_operator
board car8 loc7
1
47 29
2
0 0 0 45
0 35 29 32
1
end_operator
begin_operator
board car8 loc8
1
47 30
2
0 0 0 45
0 35 30 32
1
end_operator
begin_operator
board car8 loc9
1
47 31
2
0 0 0 45
0 35 31 32
1
end_operator
begin_operator
board car9 loc1
1
47 0
2
0 0 0 46
0 41 0 32
1
end_operator
begin_operator
board car9 loc10
1
47 1
2
0 0 0 46
0 41 1 32
1
end_operator
begin_operator
board car9 loc11
1
47 2
2
0 0 0 46
0 41 2 32
1
end_operator
begin_operator
board car9 loc12
1
47 3
2
0 0 0 46
0 41 3 32
1
end_operator
begin_operator
board car9 loc13
1
47 4
2
0 0 0 46
0 41 4 32
1
end_operator
begin_operator
board car9 loc14
1
47 5
2
0 0 0 46
0 41 5 32
1
end_operator
begin_operator
board car9 loc15
1
47 6
2
0 0 0 46
0 41 6 32
1
end_operator
begin_operator
board car9 loc16
1
47 7
2
0 0 0 46
0 41 7 32
1
end_operator
begin_operator
board car9 loc17
1
47 8
2
0 0 0 46
0 41 8 32
1
end_operator
begin_operator
board car9 loc18
1
47 9
2
0 0 0 46
0 41 9 32
1
end_operator
begin_operator
board car9 loc19
1
47 10
2
0 0 0 46
0 41 10 32
1
end_operator
begin_operator
board car9 loc2
1
47 11
2
0 0 0 46
0 41 11 32
1
end_operator
begin_operator
board car9 loc20
1
47 12
2
0 0 0 46
0 41 12 32
1
end_operator
begin_operator
board car9 loc21
1
47 13
2
0 0 0 46
0 41 13 32
1
end_operator
begin_operator
board car9 loc22
1
47 14
2
0 0 0 46
0 41 14 32
1
end_operator
begin_operator
board car9 loc23
1
47 15
2
0 0 0 46
0 41 15 32
1
end_operator
begin_operator
board car9 loc24
1
47 16
2
0 0 0 46
0 41 16 32
1
end_operator
begin_operator
board car9 loc25
1
47 17
2
0 0 0 46
0 41 17 32
1
end_operator
begin_operator
board car9 loc26
1
47 18
2
0 0 0 46
0 41 18 32
1
end_operator
begin_operator
board car9 loc27
1
47 19
2
0 0 0 46
0 41 19 32
1
end_operator
begin_operator
board car9 loc28
1
47 20
2
0 0 0 46
0 41 20 32
1
end_operator
begin_operator
board car9 loc29
1
47 21
2
0 0 0 46
0 41 21 32
1
end_operator
begin_operator
board car9 loc3
1
47 22
2
0 0 0 46
0 41 22 32
1
end_operator
begin_operator
board car9 loc30
1
47 23
2
0 0 0 46
0 41 23 32
1
end_operator
begin_operator
board car9 loc31
1
47 24
2
0 0 0 46
0 41 24 32
1
end_operator
begin_operator
board car9 loc32
1
47 25
2
0 0 0 46
0 41 25 32
1
end_operator
begin_operator
board car9 loc4
1
47 26
2
0 0 0 46
0 41 26 32
1
end_operator
begin_operator
board car9 loc5
1
47 27
2
0 0 0 46
0 41 27 32
1
end_operator
begin_operator
board car9 loc6
1
47 28
2
0 0 0 46
0 41 28 32
1
end_operator
begin_operator
board car9 loc7
1
47 29
2
0 0 0 46
0 41 29 32
1
end_operator
begin_operator
board car9 loc8
1
47 30
2
0 0 0 46
0 41 30 32
1
end_operator
begin_operator
board car9 loc9
1
47 31
2
0 0 0 46
0 41 31 32
1
end_operator
begin_operator
debark car1 loc1
1
47 0
2
0 0 1 0
0 6 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
47 1
2
0 0 1 0
0 6 -1 1
1
end_operator
begin_operator
debark car1 loc11
1
47 2
2
0 0 1 0
0 6 -1 2
1
end_operator
begin_operator
debark car1 loc12
1
47 3
2
0 0 1 0
0 6 -1 3
1
end_operator
begin_operator
debark car1 loc13
1
47 4
2
0 0 1 0
0 6 -1 4
1
end_operator
begin_operator
debark car1 loc14
1
47 5
2
0 0 1 0
0 6 -1 5
1
end_operator
begin_operator
debark car1 loc15
1
47 6
2
0 0 1 0
0 6 -1 6
1
end_operator
begin_operator
debark car1 loc16
1
47 7
2
0 0 1 0
0 6 -1 7
1
end_operator
begin_operator
debark car1 loc17
1
47 8
2
0 0 1 0
0 6 -1 8
1
end_operator
begin_operator
debark car1 loc18
1
47 9
2
0 0 1 0
0 6 -1 9
1
end_operator
begin_operator
debark car1 loc19
1
47 10
2
0 0 1 0
0 6 -1 10
1
end_operator
begin_operator
debark car1 loc2
1
47 11
2
0 0 1 0
0 6 -1 11
1
end_operator
begin_operator
debark car1 loc20
1
47 12
2
0 0 1 0
0 6 -1 12
1
end_operator
begin_operator
debark car1 loc21
1
47 13
2
0 0 1 0
0 6 -1 13
1
end_operator
begin_operator
debark car1 loc22
1
47 14
2
0 0 1 0
0 6 -1 14
1
end_operator
begin_operator
debark car1 loc23
1
47 15
2
0 0 1 0
0 6 -1 15
1
end_operator
begin_operator
debark car1 loc24
1
47 16
2
0 0 1 0
0 6 -1 16
1
end_operator
begin_operator
debark car1 loc25
1
47 17
2
0 0 1 0
0 6 -1 17
1
end_operator
begin_operator
debark car1 loc26
1
47 18
2
0 0 1 0
0 6 -1 18
1
end_operator
begin_operator
debark car1 loc27
1
47 19
2
0 0 1 0
0 6 -1 19
1
end_operator
begin_operator
debark car1 loc28
1
47 20
2
0 0 1 0
0 6 -1 20
1
end_operator
begin_operator
debark car1 loc29
1
47 21
2
0 0 1 0
0 6 -1 21
1
end_operator
begin_operator
debark car1 loc3
1
47 22
2
0 0 1 0
0 6 -1 22
1
end_operator
begin_operator
debark car1 loc30
1
47 23
2
0 0 1 0
0 6 -1 23
1
end_operator
begin_operator
debark car1 loc31
1
47 24
2
0 0 1 0
0 6 -1 24
1
end_operator
begin_operator
debark car1 loc32
1
47 25
2
0 0 1 0
0 6 -1 25
1
end_operator
begin_operator
debark car1 loc4
1
47 26
2
0 0 1 0
0 6 -1 26
1
end_operator
begin_operator
debark car1 loc5
1
47 27
2
0 0 1 0
0 6 -1 27
1
end_operator
begin_operator
debark car1 loc6
1
47 28
2
0 0 1 0
0 6 -1 28
1
end_operator
begin_operator
debark car1 loc7
1
47 29
2
0 0 1 0
0 6 -1 29
1
end_operator
begin_operator
debark car1 loc8
1
47 30
2
0 0 1 0
0 6 -1 30
1
end_operator
begin_operator
debark car1 loc9
1
47 31
2
0 0 1 0
0 6 -1 31
1
end_operator
begin_operator
debark car10 loc1
1
47 0
2
0 0 2 0
0 12 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
47 1
2
0 0 2 0
0 12 -1 1
1
end_operator
begin_operator
debark car10 loc11
1
47 2
2
0 0 2 0
0 12 -1 2
1
end_operator
begin_operator
debark car10 loc12
1
47 3
2
0 0 2 0
0 12 -1 3
1
end_operator
begin_operator
debark car10 loc13
1
47 4
2
0 0 2 0
0 12 -1 4
1
end_operator
begin_operator
debark car10 loc14
1
47 5
2
0 0 2 0
0 12 -1 5
1
end_operator
begin_operator
debark car10 loc15
1
47 6
2
0 0 2 0
0 12 -1 6
1
end_operator
begin_operator
debark car10 loc16
1
47 7
2
0 0 2 0
0 12 -1 7
1
end_operator
begin_operator
debark car10 loc17
1
47 8
2
0 0 2 0
0 12 -1 8
1
end_operator
begin_operator
debark car10 loc18
1
47 9
2
0 0 2 0
0 12 -1 9
1
end_operator
begin_operator
debark car10 loc19
1
47 10
2
0 0 2 0
0 12 -1 10
1
end_operator
begin_operator
debark car10 loc2
1
47 11
2
0 0 2 0
0 12 -1 11
1
end_operator
begin_operator
debark car10 loc20
1
47 12
2
0 0 2 0
0 12 -1 12
1
end_operator
begin_operator
debark car10 loc21
1
47 13
2
0 0 2 0
0 12 -1 13
1
end_operator
begin_operator
debark car10 loc22
1
47 14
2
0 0 2 0
0 12 -1 14
1
end_operator
begin_operator
debark car10 loc23
1
47 15
2
0 0 2 0
0 12 -1 15
1
end_operator
begin_operator
debark car10 loc24
1
47 16
2
0 0 2 0
0 12 -1 16
1
end_operator
begin_operator
debark car10 loc25
1
47 17
2
0 0 2 0
0 12 -1 17
1
end_operator
begin_operator
debark car10 loc26
1
47 18
2
0 0 2 0
0 12 -1 18
1
end_operator
begin_operator
debark car10 loc27
1
47 19
2
0 0 2 0
0 12 -1 19
1
end_operator
begin_operator
debark car10 loc28
1
47 20
2
0 0 2 0
0 12 -1 20
1
end_operator
begin_operator
debark car10 loc29
1
47 21
2
0 0 2 0
0 12 -1 21
1
end_operator
begin_operator
debark car10 loc3
1
47 22
2
0 0 2 0
0 12 -1 22
1
end_operator
begin_operator
debark car10 loc30
1
47 23
2
0 0 2 0
0 12 -1 23
1
end_operator
begin_operator
debark car10 loc31
1
47 24
2
0 0 2 0
0 12 -1 24
1
end_operator
begin_operator
debark car10 loc32
1
47 25
2
0 0 2 0
0 12 -1 25
1
end_operator
begin_operator
debark car10 loc4
1
47 26
2
0 0 2 0
0 12 -1 26
1
end_operator
begin_operator
debark car10 loc5
1
47 27
2
0 0 2 0
0 12 -1 27
1
end_operator
begin_operator
debark car10 loc6
1
47 28
2
0 0 2 0
0 12 -1 28
1
end_operator
begin_operator
debark car10 loc7
1
47 29
2
0 0 2 0
0 12 -1 29
1
end_operator
begin_operator
debark car10 loc8
1
47 30
2
0 0 2 0
0 12 -1 30
1
end_operator
begin_operator
debark car10 loc9
1
47 31
2
0 0 2 0
0 12 -1 31
1
end_operator
begin_operator
debark car11 loc1
1
47 0
2
0 0 3 0
0 18 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
47 1
2
0 0 3 0
0 18 -1 1
1
end_operator
begin_operator
debark car11 loc11
1
47 2
2
0 0 3 0
0 18 -1 2
1
end_operator
begin_operator
debark car11 loc12
1
47 3
2
0 0 3 0
0 18 -1 3
1
end_operator
begin_operator
debark car11 loc13
1
47 4
2
0 0 3 0
0 18 -1 4
1
end_operator
begin_operator
debark car11 loc14
1
47 5
2
0 0 3 0
0 18 -1 5
1
end_operator
begin_operator
debark car11 loc15
1
47 6
2
0 0 3 0
0 18 -1 6
1
end_operator
begin_operator
debark car11 loc16
1
47 7
2
0 0 3 0
0 18 -1 7
1
end_operator
begin_operator
debark car11 loc17
1
47 8
2
0 0 3 0
0 18 -1 8
1
end_operator
begin_operator
debark car11 loc18
1
47 9
2
0 0 3 0
0 18 -1 9
1
end_operator
begin_operator
debark car11 loc19
1
47 10
2
0 0 3 0
0 18 -1 10
1
end_operator
begin_operator
debark car11 loc2
1
47 11
2
0 0 3 0
0 18 -1 11
1
end_operator
begin_operator
debark car11 loc20
1
47 12
2
0 0 3 0
0 18 -1 12
1
end_operator
begin_operator
debark car11 loc21
1
47 13
2
0 0 3 0
0 18 -1 13
1
end_operator
begin_operator
debark car11 loc22
1
47 14
2
0 0 3 0
0 18 -1 14
1
end_operator
begin_operator
debark car11 loc23
1
47 15
2
0 0 3 0
0 18 -1 15
1
end_operator
begin_operator
debark car11 loc24
1
47 16
2
0 0 3 0
0 18 -1 16
1
end_operator
begin_operator
debark car11 loc25
1
47 17
2
0 0 3 0
0 18 -1 17
1
end_operator
begin_operator
debark car11 loc26
1
47 18
2
0 0 3 0
0 18 -1 18
1
end_operator
begin_operator
debark car11 loc27
1
47 19
2
0 0 3 0
0 18 -1 19
1
end_operator
begin_operator
debark car11 loc28
1
47 20
2
0 0 3 0
0 18 -1 20
1
end_operator
begin_operator
debark car11 loc29
1
47 21
2
0 0 3 0
0 18 -1 21
1
end_operator
begin_operator
debark car11 loc3
1
47 22
2
0 0 3 0
0 18 -1 22
1
end_operator
begin_operator
debark car11 loc30
1
47 23
2
0 0 3 0
0 18 -1 23
1
end_operator
begin_operator
debark car11 loc31
1
47 24
2
0 0 3 0
0 18 -1 24
1
end_operator
begin_operator
debark car11 loc32
1
47 25
2
0 0 3 0
0 18 -1 25
1
end_operator
begin_operator
debark car11 loc4
1
47 26
2
0 0 3 0
0 18 -1 26
1
end_operator
begin_operator
debark car11 loc5
1
47 27
2
0 0 3 0
0 18 -1 27
1
end_operator
begin_operator
debark car11 loc6
1
47 28
2
0 0 3 0
0 18 -1 28
1
end_operator
begin_operator
debark car11 loc7
1
47 29
2
0 0 3 0
0 18 -1 29
1
end_operator
begin_operator
debark car11 loc8
1
47 30
2
0 0 3 0
0 18 -1 30
1
end_operator
begin_operator
debark car11 loc9
1
47 31
2
0 0 3 0
0 18 -1 31
1
end_operator
begin_operator
debark car12 loc1
1
47 0
2
0 0 4 0
0 24 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
47 1
2
0 0 4 0
0 24 -1 1
1
end_operator
begin_operator
debark car12 loc11
1
47 2
2
0 0 4 0
0 24 -1 2
1
end_operator
begin_operator
debark car12 loc12
1
47 3
2
0 0 4 0
0 24 -1 3
1
end_operator
begin_operator
debark car12 loc13
1
47 4
2
0 0 4 0
0 24 -1 4
1
end_operator
begin_operator
debark car12 loc14
1
47 5
2
0 0 4 0
0 24 -1 5
1
end_operator
begin_operator
debark car12 loc15
1
47 6
2
0 0 4 0
0 24 -1 6
1
end_operator
begin_operator
debark car12 loc16
1
47 7
2
0 0 4 0
0 24 -1 7
1
end_operator
begin_operator
debark car12 loc17
1
47 8
2
0 0 4 0
0 24 -1 8
1
end_operator
begin_operator
debark car12 loc18
1
47 9
2
0 0 4 0
0 24 -1 9
1
end_operator
begin_operator
debark car12 loc19
1
47 10
2
0 0 4 0
0 24 -1 10
1
end_operator
begin_operator
debark car12 loc2
1
47 11
2
0 0 4 0
0 24 -1 11
1
end_operator
begin_operator
debark car12 loc20
1
47 12
2
0 0 4 0
0 24 -1 12
1
end_operator
begin_operator
debark car12 loc21
1
47 13
2
0 0 4 0
0 24 -1 13
1
end_operator
begin_operator
debark car12 loc22
1
47 14
2
0 0 4 0
0 24 -1 14
1
end_operator
begin_operator
debark car12 loc23
1
47 15
2
0 0 4 0
0 24 -1 15
1
end_operator
begin_operator
debark car12 loc24
1
47 16
2
0 0 4 0
0 24 -1 16
1
end_operator
begin_operator
debark car12 loc25
1
47 17
2
0 0 4 0
0 24 -1 17
1
end_operator
begin_operator
debark car12 loc26
1
47 18
2
0 0 4 0
0 24 -1 18
1
end_operator
begin_operator
debark car12 loc27
1
47 19
2
0 0 4 0
0 24 -1 19
1
end_operator
begin_operator
debark car12 loc28
1
47 20
2
0 0 4 0
0 24 -1 20
1
end_operator
begin_operator
debark car12 loc29
1
47 21
2
0 0 4 0
0 24 -1 21
1
end_operator
begin_operator
debark car12 loc3
1
47 22
2
0 0 4 0
0 24 -1 22
1
end_operator
begin_operator
debark car12 loc30
1
47 23
2
0 0 4 0
0 24 -1 23
1
end_operator
begin_operator
debark car12 loc31
1
47 24
2
0 0 4 0
0 24 -1 24
1
end_operator
begin_operator
debark car12 loc32
1
47 25
2
0 0 4 0
0 24 -1 25
1
end_operator
begin_operator
debark car12 loc4
1
47 26
2
0 0 4 0
0 24 -1 26
1
end_operator
begin_operator
debark car12 loc5
1
47 27
2
0 0 4 0
0 24 -1 27
1
end_operator
begin_operator
debark car12 loc6
1
47 28
2
0 0 4 0
0 24 -1 28
1
end_operator
begin_operator
debark car12 loc7
1
47 29
2
0 0 4 0
0 24 -1 29
1
end_operator
begin_operator
debark car12 loc8
1
47 30
2
0 0 4 0
0 24 -1 30
1
end_operator
begin_operator
debark car12 loc9
1
47 31
2
0 0 4 0
0 24 -1 31
1
end_operator
begin_operator
debark car13 loc1
1
47 0
2
0 0 5 0
0 30 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
47 1
2
0 0 5 0
0 30 -1 1
1
end_operator
begin_operator
debark car13 loc11
1
47 2
2
0 0 5 0
0 30 -1 2
1
end_operator
begin_operator
debark car13 loc12
1
47 3
2
0 0 5 0
0 30 -1 3
1
end_operator
begin_operator
debark car13 loc13
1
47 4
2
0 0 5 0
0 30 -1 4
1
end_operator
begin_operator
debark car13 loc14
1
47 5
2
0 0 5 0
0 30 -1 5
1
end_operator
begin_operator
debark car13 loc15
1
47 6
2
0 0 5 0
0 30 -1 6
1
end_operator
begin_operator
debark car13 loc16
1
47 7
2
0 0 5 0
0 30 -1 7
1
end_operator
begin_operator
debark car13 loc17
1
47 8
2
0 0 5 0
0 30 -1 8
1
end_operator
begin_operator
debark car13 loc18
1
47 9
2
0 0 5 0
0 30 -1 9
1
end_operator
begin_operator
debark car13 loc19
1
47 10
2
0 0 5 0
0 30 -1 10
1
end_operator
begin_operator
debark car13 loc2
1
47 11
2
0 0 5 0
0 30 -1 11
1
end_operator
begin_operator
debark car13 loc20
1
47 12
2
0 0 5 0
0 30 -1 12
1
end_operator
begin_operator
debark car13 loc21
1
47 13
2
0 0 5 0
0 30 -1 13
1
end_operator
begin_operator
debark car13 loc22
1
47 14
2
0 0 5 0
0 30 -1 14
1
end_operator
begin_operator
debark car13 loc23
1
47 15
2
0 0 5 0
0 30 -1 15
1
end_operator
begin_operator
debark car13 loc24
1
47 16
2
0 0 5 0
0 30 -1 16
1
end_operator
begin_operator
debark car13 loc25
1
47 17
2
0 0 5 0
0 30 -1 17
1
end_operator
begin_operator
debark car13 loc26
1
47 18
2
0 0 5 0
0 30 -1 18
1
end_operator
begin_operator
debark car13 loc27
1
47 19
2
0 0 5 0
0 30 -1 19
1
end_operator
begin_operator
debark car13 loc28
1
47 20
2
0 0 5 0
0 30 -1 20
1
end_operator
begin_operator
debark car13 loc29
1
47 21
2
0 0 5 0
0 30 -1 21
1
end_operator
begin_operator
debark car13 loc3
1
47 22
2
0 0 5 0
0 30 -1 22
1
end_operator
begin_operator
debark car13 loc30
1
47 23
2
0 0 5 0
0 30 -1 23
1
end_operator
begin_operator
debark car13 loc31
1
47 24
2
0 0 5 0
0 30 -1 24
1
end_operator
begin_operator
debark car13 loc32
1
47 25
2
0 0 5 0
0 30 -1 25
1
end_operator
begin_operator
debark car13 loc4
1
47 26
2
0 0 5 0
0 30 -1 26
1
end_operator
begin_operator
debark car13 loc5
1
47 27
2
0 0 5 0
0 30 -1 27
1
end_operator
begin_operator
debark car13 loc6
1
47 28
2
0 0 5 0
0 30 -1 28
1
end_operator
begin_operator
debark car13 loc7
1
47 29
2
0 0 5 0
0 30 -1 29
1
end_operator
begin_operator
debark car13 loc8
1
47 30
2
0 0 5 0
0 30 -1 30
1
end_operator
begin_operator
debark car13 loc9
1
47 31
2
0 0 5 0
0 30 -1 31
1
end_operator
begin_operator
debark car14 loc1
1
47 0
2
0 0 6 0
0 36 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
47 1
2
0 0 6 0
0 36 -1 1
1
end_operator
begin_operator
debark car14 loc11
1
47 2
2
0 0 6 0
0 36 -1 2
1
end_operator
begin_operator
debark car14 loc12
1
47 3
2
0 0 6 0
0 36 -1 3
1
end_operator
begin_operator
debark car14 loc13
1
47 4
2
0 0 6 0
0 36 -1 4
1
end_operator
begin_operator
debark car14 loc14
1
47 5
2
0 0 6 0
0 36 -1 5
1
end_operator
begin_operator
debark car14 loc15
1
47 6
2
0 0 6 0
0 36 -1 6
1
end_operator
begin_operator
debark car14 loc16
1
47 7
2
0 0 6 0
0 36 -1 7
1
end_operator
begin_operator
debark car14 loc17
1
47 8
2
0 0 6 0
0 36 -1 8
1
end_operator
begin_operator
debark car14 loc18
1
47 9
2
0 0 6 0
0 36 -1 9
1
end_operator
begin_operator
debark car14 loc19
1
47 10
2
0 0 6 0
0 36 -1 10
1
end_operator
begin_operator
debark car14 loc2
1
47 11
2
0 0 6 0
0 36 -1 11
1
end_operator
begin_operator
debark car14 loc20
1
47 12
2
0 0 6 0
0 36 -1 12
1
end_operator
begin_operator
debark car14 loc21
1
47 13
2
0 0 6 0
0 36 -1 13
1
end_operator
begin_operator
debark car14 loc22
1
47 14
2
0 0 6 0
0 36 -1 14
1
end_operator
begin_operator
debark car14 loc23
1
47 15
2
0 0 6 0
0 36 -1 15
1
end_operator
begin_operator
debark car14 loc24
1
47 16
2
0 0 6 0
0 36 -1 16
1
end_operator
begin_operator
debark car14 loc25
1
47 17
2
0 0 6 0
0 36 -1 17
1
end_operator
begin_operator
debark car14 loc26
1
47 18
2
0 0 6 0
0 36 -1 18
1
end_operator
begin_operator
debark car14 loc27
1
47 19
2
0 0 6 0
0 36 -1 19
1
end_operator
begin_operator
debark car14 loc28
1
47 20
2
0 0 6 0
0 36 -1 20
1
end_operator
begin_operator
debark car14 loc29
1
47 21
2
0 0 6 0
0 36 -1 21
1
end_operator
begin_operator
debark car14 loc3
1
47 22
2
0 0 6 0
0 36 -1 22
1
end_operator
begin_operator
debark car14 loc30
1
47 23
2
0 0 6 0
0 36 -1 23
1
end_operator
begin_operator
debark car14 loc31
1
47 24
2
0 0 6 0
0 36 -1 24
1
end_operator
begin_operator
debark car14 loc32
1
47 25
2
0 0 6 0
0 36 -1 25
1
end_operator
begin_operator
debark car14 loc4
1
47 26
2
0 0 6 0
0 36 -1 26
1
end_operator
begin_operator
debark car14 loc5
1
47 27
2
0 0 6 0
0 36 -1 27
1
end_operator
begin_operator
debark car14 loc6
1
47 28
2
0 0 6 0
0 36 -1 28
1
end_operator
begin_operator
debark car14 loc7
1
47 29
2
0 0 6 0
0 36 -1 29
1
end_operator
begin_operator
debark car14 loc8
1
47 30
2
0 0 6 0
0 36 -1 30
1
end_operator
begin_operator
debark car14 loc9
1
47 31
2
0 0 6 0
0 36 -1 31
1
end_operator
begin_operator
debark car15 loc1
1
47 0
2
0 0 7 0
0 42 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
47 1
2
0 0 7 0
0 42 -1 1
1
end_operator
begin_operator
debark car15 loc11
1
47 2
2
0 0 7 0
0 42 -1 2
1
end_operator
begin_operator
debark car15 loc12
1
47 3
2
0 0 7 0
0 42 -1 3
1
end_operator
begin_operator
debark car15 loc13
1
47 4
2
0 0 7 0
0 42 -1 4
1
end_operator
begin_operator
debark car15 loc14
1
47 5
2
0 0 7 0
0 42 -1 5
1
end_operator
begin_operator
debark car15 loc15
1
47 6
2
0 0 7 0
0 42 -1 6
1
end_operator
begin_operator
debark car15 loc16
1
47 7
2
0 0 7 0
0 42 -1 7
1
end_operator
begin_operator
debark car15 loc17
1
47 8
2
0 0 7 0
0 42 -1 8
1
end_operator
begin_operator
debark car15 loc18
1
47 9
2
0 0 7 0
0 42 -1 9
1
end_operator
begin_operator
debark car15 loc19
1
47 10
2
0 0 7 0
0 42 -1 10
1
end_operator
begin_operator
debark car15 loc2
1
47 11
2
0 0 7 0
0 42 -1 11
1
end_operator
begin_operator
debark car15 loc20
1
47 12
2
0 0 7 0
0 42 -1 12
1
end_operator
begin_operator
debark car15 loc21
1
47 13
2
0 0 7 0
0 42 -1 13
1
end_operator
begin_operator
debark car15 loc22
1
47 14
2
0 0 7 0
0 42 -1 14
1
end_operator
begin_operator
debark car15 loc23
1
47 15
2
0 0 7 0
0 42 -1 15
1
end_operator
begin_operator
debark car15 loc24
1
47 16
2
0 0 7 0
0 42 -1 16
1
end_operator
begin_operator
debark car15 loc25
1
47 17
2
0 0 7 0
0 42 -1 17
1
end_operator
begin_operator
debark car15 loc26
1
47 18
2
0 0 7 0
0 42 -1 18
1
end_operator
begin_operator
debark car15 loc27
1
47 19
2
0 0 7 0
0 42 -1 19
1
end_operator
begin_operator
debark car15 loc28
1
47 20
2
0 0 7 0
0 42 -1 20
1
end_operator
begin_operator
debark car15 loc29
1
47 21
2
0 0 7 0
0 42 -1 21
1
end_operator
begin_operator
debark car15 loc3
1
47 22
2
0 0 7 0
0 42 -1 22
1
end_operator
begin_operator
debark car15 loc30
1
47 23
2
0 0 7 0
0 42 -1 23
1
end_operator
begin_operator
debark car15 loc31
1
47 24
2
0 0 7 0
0 42 -1 24
1
end_operator
begin_operator
debark car15 loc32
1
47 25
2
0 0 7 0
0 42 -1 25
1
end_operator
begin_operator
debark car15 loc4
1
47 26
2
0 0 7 0
0 42 -1 26
1
end_operator
begin_operator
debark car15 loc5
1
47 27
2
0 0 7 0
0 42 -1 27
1
end_operator
begin_operator
debark car15 loc6
1
47 28
2
0 0 7 0
0 42 -1 28
1
end_operator
begin_operator
debark car15 loc7
1
47 29
2
0 0 7 0
0 42 -1 29
1
end_operator
begin_operator
debark car15 loc8
1
47 30
2
0 0 7 0
0 42 -1 30
1
end_operator
begin_operator
debark car15 loc9
1
47 31
2
0 0 7 0
0 42 -1 31
1
end_operator
begin_operator
debark car16 loc1
1
47 0
2
0 0 8 0
0 1 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
47 1
2
0 0 8 0
0 1 -1 1
1
end_operator
begin_operator
debark car16 loc11
1
47 2
2
0 0 8 0
0 1 -1 2
1
end_operator
begin_operator
debark car16 loc12
1
47 3
2
0 0 8 0
0 1 -1 3
1
end_operator
begin_operator
debark car16 loc13
1
47 4
2
0 0 8 0
0 1 -1 4
1
end_operator
begin_operator
debark car16 loc14
1
47 5
2
0 0 8 0
0 1 -1 5
1
end_operator
begin_operator
debark car16 loc15
1
47 6
2
0 0 8 0
0 1 -1 6
1
end_operator
begin_operator
debark car16 loc16
1
47 7
2
0 0 8 0
0 1 -1 7
1
end_operator
begin_operator
debark car16 loc17
1
47 8
2
0 0 8 0
0 1 -1 8
1
end_operator
begin_operator
debark car16 loc18
1
47 9
2
0 0 8 0
0 1 -1 9
1
end_operator
begin_operator
debark car16 loc19
1
47 10
2
0 0 8 0
0 1 -1 10
1
end_operator
begin_operator
debark car16 loc2
1
47 11
2
0 0 8 0
0 1 -1 11
1
end_operator
begin_operator
debark car16 loc20
1
47 12
2
0 0 8 0
0 1 -1 12
1
end_operator
begin_operator
debark car16 loc21
1
47 13
2
0 0 8 0
0 1 -1 13
1
end_operator
begin_operator
debark car16 loc22
1
47 14
2
0 0 8 0
0 1 -1 14
1
end_operator
begin_operator
debark car16 loc23
1
47 15
2
0 0 8 0
0 1 -1 15
1
end_operator
begin_operator
debark car16 loc24
1
47 16
2
0 0 8 0
0 1 -1 16
1
end_operator
begin_operator
debark car16 loc25
1
47 17
2
0 0 8 0
0 1 -1 17
1
end_operator
begin_operator
debark car16 loc26
1
47 18
2
0 0 8 0
0 1 -1 18
1
end_operator
begin_operator
debark car16 loc27
1
47 19
2
0 0 8 0
0 1 -1 19
1
end_operator
begin_operator
debark car16 loc28
1
47 20
2
0 0 8 0
0 1 -1 20
1
end_operator
begin_operator
debark car16 loc29
1
47 21
2
0 0 8 0
0 1 -1 21
1
end_operator
begin_operator
debark car16 loc3
1
47 22
2
0 0 8 0
0 1 -1 22
1
end_operator
begin_operator
debark car16 loc30
1
47 23
2
0 0 8 0
0 1 -1 23
1
end_operator
begin_operator
debark car16 loc31
1
47 24
2
0 0 8 0
0 1 -1 24
1
end_operator
begin_operator
debark car16 loc32
1
47 25
2
0 0 8 0
0 1 -1 25
1
end_operator
begin_operator
debark car16 loc4
1
47 26
2
0 0 8 0
0 1 -1 26
1
end_operator
begin_operator
debark car16 loc5
1
47 27
2
0 0 8 0
0 1 -1 27
1
end_operator
begin_operator
debark car16 loc6
1
47 28
2
0 0 8 0
0 1 -1 28
1
end_operator
begin_operator
debark car16 loc7
1
47 29
2
0 0 8 0
0 1 -1 29
1
end_operator
begin_operator
debark car16 loc8
1
47 30
2
0 0 8 0
0 1 -1 30
1
end_operator
begin_operator
debark car16 loc9
1
47 31
2
0 0 8 0
0 1 -1 31
1
end_operator
begin_operator
debark car17 loc1
1
47 0
2
0 0 9 0
0 7 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
47 1
2
0 0 9 0
0 7 -1 1
1
end_operator
begin_operator
debark car17 loc11
1
47 2
2
0 0 9 0
0 7 -1 2
1
end_operator
begin_operator
debark car17 loc12
1
47 3
2
0 0 9 0
0 7 -1 3
1
end_operator
begin_operator
debark car17 loc13
1
47 4
2
0 0 9 0
0 7 -1 4
1
end_operator
begin_operator
debark car17 loc14
1
47 5
2
0 0 9 0
0 7 -1 5
1
end_operator
begin_operator
debark car17 loc15
1
47 6
2
0 0 9 0
0 7 -1 6
1
end_operator
begin_operator
debark car17 loc16
1
47 7
2
0 0 9 0
0 7 -1 7
1
end_operator
begin_operator
debark car17 loc17
1
47 8
2
0 0 9 0
0 7 -1 8
1
end_operator
begin_operator
debark car17 loc18
1
47 9
2
0 0 9 0
0 7 -1 9
1
end_operator
begin_operator
debark car17 loc19
1
47 10
2
0 0 9 0
0 7 -1 10
1
end_operator
begin_operator
debark car17 loc2
1
47 11
2
0 0 9 0
0 7 -1 11
1
end_operator
begin_operator
debark car17 loc20
1
47 12
2
0 0 9 0
0 7 -1 12
1
end_operator
begin_operator
debark car17 loc21
1
47 13
2
0 0 9 0
0 7 -1 13
1
end_operator
begin_operator
debark car17 loc22
1
47 14
2
0 0 9 0
0 7 -1 14
1
end_operator
begin_operator
debark car17 loc23
1
47 15
2
0 0 9 0
0 7 -1 15
1
end_operator
begin_operator
debark car17 loc24
1
47 16
2
0 0 9 0
0 7 -1 16
1
end_operator
begin_operator
debark car17 loc25
1
47 17
2
0 0 9 0
0 7 -1 17
1
end_operator
begin_operator
debark car17 loc26
1
47 18
2
0 0 9 0
0 7 -1 18
1
end_operator
begin_operator
debark car17 loc27
1
47 19
2
0 0 9 0
0 7 -1 19
1
end_operator
begin_operator
debark car17 loc28
1
47 20
2
0 0 9 0
0 7 -1 20
1
end_operator
begin_operator
debark car17 loc29
1
47 21
2
0 0 9 0
0 7 -1 21
1
end_operator
begin_operator
debark car17 loc3
1
47 22
2
0 0 9 0
0 7 -1 22
1
end_operator
begin_operator
debark car17 loc30
1
47 23
2
0 0 9 0
0 7 -1 23
1
end_operator
begin_operator
debark car17 loc31
1
47 24
2
0 0 9 0
0 7 -1 24
1
end_operator
begin_operator
debark car17 loc32
1
47 25
2
0 0 9 0
0 7 -1 25
1
end_operator
begin_operator
debark car17 loc4
1
47 26
2
0 0 9 0
0 7 -1 26
1
end_operator
begin_operator
debark car17 loc5
1
47 27
2
0 0 9 0
0 7 -1 27
1
end_operator
begin_operator
debark car17 loc6
1
47 28
2
0 0 9 0
0 7 -1 28
1
end_operator
begin_operator
debark car17 loc7
1
47 29
2
0 0 9 0
0 7 -1 29
1
end_operator
begin_operator
debark car17 loc8
1
47 30
2
0 0 9 0
0 7 -1 30
1
end_operator
begin_operator
debark car17 loc9
1
47 31
2
0 0 9 0
0 7 -1 31
1
end_operator
begin_operator
debark car18 loc1
1
47 0
2
0 0 10 0
0 13 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
47 1
2
0 0 10 0
0 13 -1 1
1
end_operator
begin_operator
debark car18 loc11
1
47 2
2
0 0 10 0
0 13 -1 2
1
end_operator
begin_operator
debark car18 loc12
1
47 3
2
0 0 10 0
0 13 -1 3
1
end_operator
begin_operator
debark car18 loc13
1
47 4
2
0 0 10 0
0 13 -1 4
1
end_operator
begin_operator
debark car18 loc14
1
47 5
2
0 0 10 0
0 13 -1 5
1
end_operator
begin_operator
debark car18 loc15
1
47 6
2
0 0 10 0
0 13 -1 6
1
end_operator
begin_operator
debark car18 loc16
1
47 7
2
0 0 10 0
0 13 -1 7
1
end_operator
begin_operator
debark car18 loc17
1
47 8
2
0 0 10 0
0 13 -1 8
1
end_operator
begin_operator
debark car18 loc18
1
47 9
2
0 0 10 0
0 13 -1 9
1
end_operator
begin_operator
debark car18 loc19
1
47 10
2
0 0 10 0
0 13 -1 10
1
end_operator
begin_operator
debark car18 loc2
1
47 11
2
0 0 10 0
0 13 -1 11
1
end_operator
begin_operator
debark car18 loc20
1
47 12
2
0 0 10 0
0 13 -1 12
1
end_operator
begin_operator
debark car18 loc21
1
47 13
2
0 0 10 0
0 13 -1 13
1
end_operator
begin_operator
debark car18 loc22
1
47 14
2
0 0 10 0
0 13 -1 14
1
end_operator
begin_operator
debark car18 loc23
1
47 15
2
0 0 10 0
0 13 -1 15
1
end_operator
begin_operator
debark car18 loc24
1
47 16
2
0 0 10 0
0 13 -1 16
1
end_operator
begin_operator
debark car18 loc25
1
47 17
2
0 0 10 0
0 13 -1 17
1
end_operator
begin_operator
debark car18 loc26
1
47 18
2
0 0 10 0
0 13 -1 18
1
end_operator
begin_operator
debark car18 loc27
1
47 19
2
0 0 10 0
0 13 -1 19
1
end_operator
begin_operator
debark car18 loc28
1
47 20
2
0 0 10 0
0 13 -1 20
1
end_operator
begin_operator
debark car18 loc29
1
47 21
2
0 0 10 0
0 13 -1 21
1
end_operator
begin_operator
debark car18 loc3
1
47 22
2
0 0 10 0
0 13 -1 22
1
end_operator
begin_operator
debark car18 loc30
1
47 23
2
0 0 10 0
0 13 -1 23
1
end_operator
begin_operator
debark car18 loc31
1
47 24
2
0 0 10 0
0 13 -1 24
1
end_operator
begin_operator
debark car18 loc32
1
47 25
2
0 0 10 0
0 13 -1 25
1
end_operator
begin_operator
debark car18 loc4
1
47 26
2
0 0 10 0
0 13 -1 26
1
end_operator
begin_operator
debark car18 loc5
1
47 27
2
0 0 10 0
0 13 -1 27
1
end_operator
begin_operator
debark car18 loc6
1
47 28
2
0 0 10 0
0 13 -1 28
1
end_operator
begin_operator
debark car18 loc7
1
47 29
2
0 0 10 0
0 13 -1 29
1
end_operator
begin_operator
debark car18 loc8
1
47 30
2
0 0 10 0
0 13 -1 30
1
end_operator
begin_operator
debark car18 loc9
1
47 31
2
0 0 10 0
0 13 -1 31
1
end_operator
begin_operator
debark car19 loc1
1
47 0
2
0 0 11 0
0 19 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
47 1
2
0 0 11 0
0 19 -1 1
1
end_operator
begin_operator
debark car19 loc11
1
47 2
2
0 0 11 0
0 19 -1 2
1
end_operator
begin_operator
debark car19 loc12
1
47 3
2
0 0 11 0
0 19 -1 3
1
end_operator
begin_operator
debark car19 loc13
1
47 4
2
0 0 11 0
0 19 -1 4
1
end_operator
begin_operator
debark car19 loc14
1
47 5
2
0 0 11 0
0 19 -1 5
1
end_operator
begin_operator
debark car19 loc15
1
47 6
2
0 0 11 0
0 19 -1 6
1
end_operator
begin_operator
debark car19 loc16
1
47 7
2
0 0 11 0
0 19 -1 7
1
end_operator
begin_operator
debark car19 loc17
1
47 8
2
0 0 11 0
0 19 -1 8
1
end_operator
begin_operator
debark car19 loc18
1
47 9
2
0 0 11 0
0 19 -1 9
1
end_operator
begin_operator
debark car19 loc19
1
47 10
2
0 0 11 0
0 19 -1 10
1
end_operator
begin_operator
debark car19 loc2
1
47 11
2
0 0 11 0
0 19 -1 11
1
end_operator
begin_operator
debark car19 loc20
1
47 12
2
0 0 11 0
0 19 -1 12
1
end_operator
begin_operator
debark car19 loc21
1
47 13
2
0 0 11 0
0 19 -1 13
1
end_operator
begin_operator
debark car19 loc22
1
47 14
2
0 0 11 0
0 19 -1 14
1
end_operator
begin_operator
debark car19 loc23
1
47 15
2
0 0 11 0
0 19 -1 15
1
end_operator
begin_operator
debark car19 loc24
1
47 16
2
0 0 11 0
0 19 -1 16
1
end_operator
begin_operator
debark car19 loc25
1
47 17
2
0 0 11 0
0 19 -1 17
1
end_operator
begin_operator
debark car19 loc26
1
47 18
2
0 0 11 0
0 19 -1 18
1
end_operator
begin_operator
debark car19 loc27
1
47 19
2
0 0 11 0
0 19 -1 19
1
end_operator
begin_operator
debark car19 loc28
1
47 20
2
0 0 11 0
0 19 -1 20
1
end_operator
begin_operator
debark car19 loc29
1
47 21
2
0 0 11 0
0 19 -1 21
1
end_operator
begin_operator
debark car19 loc3
1
47 22
2
0 0 11 0
0 19 -1 22
1
end_operator
begin_operator
debark car19 loc30
1
47 23
2
0 0 11 0
0 19 -1 23
1
end_operator
begin_operator
debark car19 loc31
1
47 24
2
0 0 11 0
0 19 -1 24
1
end_operator
begin_operator
debark car19 loc32
1
47 25
2
0 0 11 0
0 19 -1 25
1
end_operator
begin_operator
debark car19 loc4
1
47 26
2
0 0 11 0
0 19 -1 26
1
end_operator
begin_operator
debark car19 loc5
1
47 27
2
0 0 11 0
0 19 -1 27
1
end_operator
begin_operator
debark car19 loc6
1
47 28
2
0 0 11 0
0 19 -1 28
1
end_operator
begin_operator
debark car19 loc7
1
47 29
2
0 0 11 0
0 19 -1 29
1
end_operator
begin_operator
debark car19 loc8
1
47 30
2
0 0 11 0
0 19 -1 30
1
end_operator
begin_operator
debark car19 loc9
1
47 31
2
0 0 11 0
0 19 -1 31
1
end_operator
begin_operator
debark car2 loc1
1
47 0
2
0 0 12 0
0 25 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
47 1
2
0 0 12 0
0 25 -1 1
1
end_operator
begin_operator
debark car2 loc11
1
47 2
2
0 0 12 0
0 25 -1 2
1
end_operator
begin_operator
debark car2 loc12
1
47 3
2
0 0 12 0
0 25 -1 3
1
end_operator
begin_operator
debark car2 loc13
1
47 4
2
0 0 12 0
0 25 -1 4
1
end_operator
begin_operator
debark car2 loc14
1
47 5
2
0 0 12 0
0 25 -1 5
1
end_operator
begin_operator
debark car2 loc15
1
47 6
2
0 0 12 0
0 25 -1 6
1
end_operator
begin_operator
debark car2 loc16
1
47 7
2
0 0 12 0
0 25 -1 7
1
end_operator
begin_operator
debark car2 loc17
1
47 8
2
0 0 12 0
0 25 -1 8
1
end_operator
begin_operator
debark car2 loc18
1
47 9
2
0 0 12 0
0 25 -1 9
1
end_operator
begin_operator
debark car2 loc19
1
47 10
2
0 0 12 0
0 25 -1 10
1
end_operator
begin_operator
debark car2 loc2
1
47 11
2
0 0 12 0
0 25 -1 11
1
end_operator
begin_operator
debark car2 loc20
1
47 12
2
0 0 12 0
0 25 -1 12
1
end_operator
begin_operator
debark car2 loc21
1
47 13
2
0 0 12 0
0 25 -1 13
1
end_operator
begin_operator
debark car2 loc22
1
47 14
2
0 0 12 0
0 25 -1 14
1
end_operator
begin_operator
debark car2 loc23
1
47 15
2
0 0 12 0
0 25 -1 15
1
end_operator
begin_operator
debark car2 loc24
1
47 16
2
0 0 12 0
0 25 -1 16
1
end_operator
begin_operator
debark car2 loc25
1
47 17
2
0 0 12 0
0 25 -1 17
1
end_operator
begin_operator
debark car2 loc26
1
47 18
2
0 0 12 0
0 25 -1 18
1
end_operator
begin_operator
debark car2 loc27
1
47 19
2
0 0 12 0
0 25 -1 19
1
end_operator
begin_operator
debark car2 loc28
1
47 20
2
0 0 12 0
0 25 -1 20
1
end_operator
begin_operator
debark car2 loc29
1
47 21
2
0 0 12 0
0 25 -1 21
1
end_operator
begin_operator
debark car2 loc3
1
47 22
2
0 0 12 0
0 25 -1 22
1
end_operator
begin_operator
debark car2 loc30
1
47 23
2
0 0 12 0
0 25 -1 23
1
end_operator
begin_operator
debark car2 loc31
1
47 24
2
0 0 12 0
0 25 -1 24
1
end_operator
begin_operator
debark car2 loc32
1
47 25
2
0 0 12 0
0 25 -1 25
1
end_operator
begin_operator
debark car2 loc4
1
47 26
2
0 0 12 0
0 25 -1 26
1
end_operator
begin_operator
debark car2 loc5
1
47 27
2
0 0 12 0
0 25 -1 27
1
end_operator
begin_operator
debark car2 loc6
1
47 28
2
0 0 12 0
0 25 -1 28
1
end_operator
begin_operator
debark car2 loc7
1
47 29
2
0 0 12 0
0 25 -1 29
1
end_operator
begin_operator
debark car2 loc8
1
47 30
2
0 0 12 0
0 25 -1 30
1
end_operator
begin_operator
debark car2 loc9
1
47 31
2
0 0 12 0
0 25 -1 31
1
end_operator
begin_operator
debark car20 loc1
1
47 0
2
0 0 13 0
0 31 -1 0
1
end_operator
begin_operator
debark car20 loc10
1
47 1
2
0 0 13 0
0 31 -1 1
1
end_operator
begin_operator
debark car20 loc11
1
47 2
2
0 0 13 0
0 31 -1 2
1
end_operator
begin_operator
debark car20 loc12
1
47 3
2
0 0 13 0
0 31 -1 3
1
end_operator
begin_operator
debark car20 loc13
1
47 4
2
0 0 13 0
0 31 -1 4
1
end_operator
begin_operator
debark car20 loc14
1
47 5
2
0 0 13 0
0 31 -1 5
1
end_operator
begin_operator
debark car20 loc15
1
47 6
2
0 0 13 0
0 31 -1 6
1
end_operator
begin_operator
debark car20 loc16
1
47 7
2
0 0 13 0
0 31 -1 7
1
end_operator
begin_operator
debark car20 loc17
1
47 8
2
0 0 13 0
0 31 -1 8
1
end_operator
begin_operator
debark car20 loc18
1
47 9
2
0 0 13 0
0 31 -1 9
1
end_operator
begin_operator
debark car20 loc19
1
47 10
2
0 0 13 0
0 31 -1 10
1
end_operator
begin_operator
debark car20 loc2
1
47 11
2
0 0 13 0
0 31 -1 11
1
end_operator
begin_operator
debark car20 loc20
1
47 12
2
0 0 13 0
0 31 -1 12
1
end_operator
begin_operator
debark car20 loc21
1
47 13
2
0 0 13 0
0 31 -1 13
1
end_operator
begin_operator
debark car20 loc22
1
47 14
2
0 0 13 0
0 31 -1 14
1
end_operator
begin_operator
debark car20 loc23
1
47 15
2
0 0 13 0
0 31 -1 15
1
end_operator
begin_operator
debark car20 loc24
1
47 16
2
0 0 13 0
0 31 -1 16
1
end_operator
begin_operator
debark car20 loc25
1
47 17
2
0 0 13 0
0 31 -1 17
1
end_operator
begin_operator
debark car20 loc26
1
47 18
2
0 0 13 0
0 31 -1 18
1
end_operator
begin_operator
debark car20 loc27
1
47 19
2
0 0 13 0
0 31 -1 19
1
end_operator
begin_operator
debark car20 loc28
1
47 20
2
0 0 13 0
0 31 -1 20
1
end_operator
begin_operator
debark car20 loc29
1
47 21
2
0 0 13 0
0 31 -1 21
1
end_operator
begin_operator
debark car20 loc3
1
47 22
2
0 0 13 0
0 31 -1 22
1
end_operator
begin_operator
debark car20 loc30
1
47 23
2
0 0 13 0
0 31 -1 23
1
end_operator
begin_operator
debark car20 loc31
1
47 24
2
0 0 13 0
0 31 -1 24
1
end_operator
begin_operator
debark car20 loc32
1
47 25
2
0 0 13 0
0 31 -1 25
1
end_operator
begin_operator
debark car20 loc4
1
47 26
2
0 0 13 0
0 31 -1 26
1
end_operator
begin_operator
debark car20 loc5
1
47 27
2
0 0 13 0
0 31 -1 27
1
end_operator
begin_operator
debark car20 loc6
1
47 28
2
0 0 13 0
0 31 -1 28
1
end_operator
begin_operator
debark car20 loc7
1
47 29
2
0 0 13 0
0 31 -1 29
1
end_operator
begin_operator
debark car20 loc8
1
47 30
2
0 0 13 0
0 31 -1 30
1
end_operator
begin_operator
debark car20 loc9
1
47 31
2
0 0 13 0
0 31 -1 31
1
end_operator
begin_operator
debark car21 loc1
1
47 0
2
0 0 14 0
0 37 -1 0
1
end_operator
begin_operator
debark car21 loc10
1
47 1
2
0 0 14 0
0 37 -1 1
1
end_operator
begin_operator
debark car21 loc11
1
47 2
2
0 0 14 0
0 37 -1 2
1
end_operator
begin_operator
debark car21 loc12
1
47 3
2
0 0 14 0
0 37 -1 3
1
end_operator
begin_operator
debark car21 loc13
1
47 4
2
0 0 14 0
0 37 -1 4
1
end_operator
begin_operator
debark car21 loc14
1
47 5
2
0 0 14 0
0 37 -1 5
1
end_operator
begin_operator
debark car21 loc15
1
47 6
2
0 0 14 0
0 37 -1 6
1
end_operator
begin_operator
debark car21 loc16
1
47 7
2
0 0 14 0
0 37 -1 7
1
end_operator
begin_operator
debark car21 loc17
1
47 8
2
0 0 14 0
0 37 -1 8
1
end_operator
begin_operator
debark car21 loc18
1
47 9
2
0 0 14 0
0 37 -1 9
1
end_operator
begin_operator
debark car21 loc19
1
47 10
2
0 0 14 0
0 37 -1 10
1
end_operator
begin_operator
debark car21 loc2
1
47 11
2
0 0 14 0
0 37 -1 11
1
end_operator
begin_operator
debark car21 loc20
1
47 12
2
0 0 14 0
0 37 -1 12
1
end_operator
begin_operator
debark car21 loc21
1
47 13
2
0 0 14 0
0 37 -1 13
1
end_operator
begin_operator
debark car21 loc22
1
47 14
2
0 0 14 0
0 37 -1 14
1
end_operator
begin_operator
debark car21 loc23
1
47 15
2
0 0 14 0
0 37 -1 15
1
end_operator
begin_operator
debark car21 loc24
1
47 16
2
0 0 14 0
0 37 -1 16
1
end_operator
begin_operator
debark car21 loc25
1
47 17
2
0 0 14 0
0 37 -1 17
1
end_operator
begin_operator
debark car21 loc26
1
47 18
2
0 0 14 0
0 37 -1 18
1
end_operator
begin_operator
debark car21 loc27
1
47 19
2
0 0 14 0
0 37 -1 19
1
end_operator
begin_operator
debark car21 loc28
1
47 20
2
0 0 14 0
0 37 -1 20
1
end_operator
begin_operator
debark car21 loc29
1
47 21
2
0 0 14 0
0 37 -1 21
1
end_operator
begin_operator
debark car21 loc3
1
47 22
2
0 0 14 0
0 37 -1 22
1
end_operator
begin_operator
debark car21 loc30
1
47 23
2
0 0 14 0
0 37 -1 23
1
end_operator
begin_operator
debark car21 loc31
1
47 24
2
0 0 14 0
0 37 -1 24
1
end_operator
begin_operator
debark car21 loc32
1
47 25
2
0 0 14 0
0 37 -1 25
1
end_operator
begin_operator
debark car21 loc4
1
47 26
2
0 0 14 0
0 37 -1 26
1
end_operator
begin_operator
debark car21 loc5
1
47 27
2
0 0 14 0
0 37 -1 27
1
end_operator
begin_operator
debark car21 loc6
1
47 28
2
0 0 14 0
0 37 -1 28
1
end_operator
begin_operator
debark car21 loc7
1
47 29
2
0 0 14 0
0 37 -1 29
1
end_operator
begin_operator
debark car21 loc8
1
47 30
2
0 0 14 0
0 37 -1 30
1
end_operator
begin_operator
debark car21 loc9
1
47 31
2
0 0 14 0
0 37 -1 31
1
end_operator
begin_operator
debark car22 loc1
1
47 0
2
0 0 15 0
0 43 -1 0
1
end_operator
begin_operator
debark car22 loc10
1
47 1
2
0 0 15 0
0 43 -1 1
1
end_operator
begin_operator
debark car22 loc11
1
47 2
2
0 0 15 0
0 43 -1 2
1
end_operator
begin_operator
debark car22 loc12
1
47 3
2
0 0 15 0
0 43 -1 3
1
end_operator
begin_operator
debark car22 loc13
1
47 4
2
0 0 15 0
0 43 -1 4
1
end_operator
begin_operator
debark car22 loc14
1
47 5
2
0 0 15 0
0 43 -1 5
1
end_operator
begin_operator
debark car22 loc15
1
47 6
2
0 0 15 0
0 43 -1 6
1
end_operator
begin_operator
debark car22 loc16
1
47 7
2
0 0 15 0
0 43 -1 7
1
end_operator
begin_operator
debark car22 loc17
1
47 8
2
0 0 15 0
0 43 -1 8
1
end_operator
begin_operator
debark car22 loc18
1
47 9
2
0 0 15 0
0 43 -1 9
1
end_operator
begin_operator
debark car22 loc19
1
47 10
2
0 0 15 0
0 43 -1 10
1
end_operator
begin_operator
debark car22 loc2
1
47 11
2
0 0 15 0
0 43 -1 11
1
end_operator
begin_operator
debark car22 loc20
1
47 12
2
0 0 15 0
0 43 -1 12
1
end_operator
begin_operator
debark car22 loc21
1
47 13
2
0 0 15 0
0 43 -1 13
1
end_operator
begin_operator
debark car22 loc22
1
47 14
2
0 0 15 0
0 43 -1 14
1
end_operator
begin_operator
debark car22 loc23
1
47 15
2
0 0 15 0
0 43 -1 15
1
end_operator
begin_operator
debark car22 loc24
1
47 16
2
0 0 15 0
0 43 -1 16
1
end_operator
begin_operator
debark car22 loc25
1
47 17
2
0 0 15 0
0 43 -1 17
1
end_operator
begin_operator
debark car22 loc26
1
47 18
2
0 0 15 0
0 43 -1 18
1
end_operator
begin_operator
debark car22 loc27
1
47 19
2
0 0 15 0
0 43 -1 19
1
end_operator
begin_operator
debark car22 loc28
1
47 20
2
0 0 15 0
0 43 -1 20
1
end_operator
begin_operator
debark car22 loc29
1
47 21
2
0 0 15 0
0 43 -1 21
1
end_operator
begin_operator
debark car22 loc3
1
47 22
2
0 0 15 0
0 43 -1 22
1
end_operator
begin_operator
debark car22 loc30
1
47 23
2
0 0 15 0
0 43 -1 23
1
end_operator
begin_operator
debark car22 loc31
1
47 24
2
0 0 15 0
0 43 -1 24
1
end_operator
begin_operator
debark car22 loc32
1
47 25
2
0 0 15 0
0 43 -1 25
1
end_operator
begin_operator
debark car22 loc4
1
47 26
2
0 0 15 0
0 43 -1 26
1
end_operator
begin_operator
debark car22 loc5
1
47 27
2
0 0 15 0
0 43 -1 27
1
end_operator
begin_operator
debark car22 loc6
1
47 28
2
0 0 15 0
0 43 -1 28
1
end_operator
begin_operator
debark car22 loc7
1
47 29
2
0 0 15 0
0 43 -1 29
1
end_operator
begin_operator
debark car22 loc8
1
47 30
2
0 0 15 0
0 43 -1 30
1
end_operator
begin_operator
debark car22 loc9
1
47 31
2
0 0 15 0
0 43 -1 31
1
end_operator
begin_operator
debark car23 loc1
1
47 0
2
0 0 16 0
0 2 -1 0
1
end_operator
begin_operator
debark car23 loc10
1
47 1
2
0 0 16 0
0 2 -1 1
1
end_operator
begin_operator
debark car23 loc11
1
47 2
2
0 0 16 0
0 2 -1 2
1
end_operator
begin_operator
debark car23 loc12
1
47 3
2
0 0 16 0
0 2 -1 3
1
end_operator
begin_operator
debark car23 loc13
1
47 4
2
0 0 16 0
0 2 -1 4
1
end_operator
begin_operator
debark car23 loc14
1
47 5
2
0 0 16 0
0 2 -1 5
1
end_operator
begin_operator
debark car23 loc15
1
47 6
2
0 0 16 0
0 2 -1 6
1
end_operator
begin_operator
debark car23 loc16
1
47 7
2
0 0 16 0
0 2 -1 7
1
end_operator
begin_operator
debark car23 loc17
1
47 8
2
0 0 16 0
0 2 -1 8
1
end_operator
begin_operator
debark car23 loc18
1
47 9
2
0 0 16 0
0 2 -1 9
1
end_operator
begin_operator
debark car23 loc19
1
47 10
2
0 0 16 0
0 2 -1 10
1
end_operator
begin_operator
debark car23 loc2
1
47 11
2
0 0 16 0
0 2 -1 11
1
end_operator
begin_operator
debark car23 loc20
1
47 12
2
0 0 16 0
0 2 -1 12
1
end_operator
begin_operator
debark car23 loc21
1
47 13
2
0 0 16 0
0 2 -1 13
1
end_operator
begin_operator
debark car23 loc22
1
47 14
2
0 0 16 0
0 2 -1 14
1
end_operator
begin_operator
debark car23 loc23
1
47 15
2
0 0 16 0
0 2 -1 15
1
end_operator
begin_operator
debark car23 loc24
1
47 16
2
0 0 16 0
0 2 -1 16
1
end_operator
begin_operator
debark car23 loc25
1
47 17
2
0 0 16 0
0 2 -1 17
1
end_operator
begin_operator
debark car23 loc26
1
47 18
2
0 0 16 0
0 2 -1 18
1
end_operator
begin_operator
debark car23 loc27
1
47 19
2
0 0 16 0
0 2 -1 19
1
end_operator
begin_operator
debark car23 loc28
1
47 20
2
0 0 16 0
0 2 -1 20
1
end_operator
begin_operator
debark car23 loc29
1
47 21
2
0 0 16 0
0 2 -1 21
1
end_operator
begin_operator
debark car23 loc3
1
47 22
2
0 0 16 0
0 2 -1 22
1
end_operator
begin_operator
debark car23 loc30
1
47 23
2
0 0 16 0
0 2 -1 23
1
end_operator
begin_operator
debark car23 loc31
1
47 24
2
0 0 16 0
0 2 -1 24
1
end_operator
begin_operator
debark car23 loc32
1
47 25
2
0 0 16 0
0 2 -1 25
1
end_operator
begin_operator
debark car23 loc4
1
47 26
2
0 0 16 0
0 2 -1 26
1
end_operator
begin_operator
debark car23 loc5
1
47 27
2
0 0 16 0
0 2 -1 27
1
end_operator
begin_operator
debark car23 loc6
1
47 28
2
0 0 16 0
0 2 -1 28
1
end_operator
begin_operator
debark car23 loc7
1
47 29
2
0 0 16 0
0 2 -1 29
1
end_operator
begin_operator
debark car23 loc8
1
47 30
2
0 0 16 0
0 2 -1 30
1
end_operator
begin_operator
debark car23 loc9
1
47 31
2
0 0 16 0
0 2 -1 31
1
end_operator
begin_operator
debark car24 loc1
1
47 0
2
0 0 17 0
0 8 -1 0
1
end_operator
begin_operator
debark car24 loc10
1
47 1
2
0 0 17 0
0 8 -1 1
1
end_operator
begin_operator
debark car24 loc11
1
47 2
2
0 0 17 0
0 8 -1 2
1
end_operator
begin_operator
debark car24 loc12
1
47 3
2
0 0 17 0
0 8 -1 3
1
end_operator
begin_operator
debark car24 loc13
1
47 4
2
0 0 17 0
0 8 -1 4
1
end_operator
begin_operator
debark car24 loc14
1
47 5
2
0 0 17 0
0 8 -1 5
1
end_operator
begin_operator
debark car24 loc15
1
47 6
2
0 0 17 0
0 8 -1 6
1
end_operator
begin_operator
debark car24 loc16
1
47 7
2
0 0 17 0
0 8 -1 7
1
end_operator
begin_operator
debark car24 loc17
1
47 8
2
0 0 17 0
0 8 -1 8
1
end_operator
begin_operator
debark car24 loc18
1
47 9
2
0 0 17 0
0 8 -1 9
1
end_operator
begin_operator
debark car24 loc19
1
47 10
2
0 0 17 0
0 8 -1 10
1
end_operator
begin_operator
debark car24 loc2
1
47 11
2
0 0 17 0
0 8 -1 11
1
end_operator
begin_operator
debark car24 loc20
1
47 12
2
0 0 17 0
0 8 -1 12
1
end_operator
begin_operator
debark car24 loc21
1
47 13
2
0 0 17 0
0 8 -1 13
1
end_operator
begin_operator
debark car24 loc22
1
47 14
2
0 0 17 0
0 8 -1 14
1
end_operator
begin_operator
debark car24 loc23
1
47 15
2
0 0 17 0
0 8 -1 15
1
end_operator
begin_operator
debark car24 loc24
1
47 16
2
0 0 17 0
0 8 -1 16
1
end_operator
begin_operator
debark car24 loc25
1
47 17
2
0 0 17 0
0 8 -1 17
1
end_operator
begin_operator
debark car24 loc26
1
47 18
2
0 0 17 0
0 8 -1 18
1
end_operator
begin_operator
debark car24 loc27
1
47 19
2
0 0 17 0
0 8 -1 19
1
end_operator
begin_operator
debark car24 loc28
1
47 20
2
0 0 17 0
0 8 -1 20
1
end_operator
begin_operator
debark car24 loc29
1
47 21
2
0 0 17 0
0 8 -1 21
1
end_operator
begin_operator
debark car24 loc3
1
47 22
2
0 0 17 0
0 8 -1 22
1
end_operator
begin_operator
debark car24 loc30
1
47 23
2
0 0 17 0
0 8 -1 23
1
end_operator
begin_operator
debark car24 loc31
1
47 24
2
0 0 17 0
0 8 -1 24
1
end_operator
begin_operator
debark car24 loc32
1
47 25
2
0 0 17 0
0 8 -1 25
1
end_operator
begin_operator
debark car24 loc4
1
47 26
2
0 0 17 0
0 8 -1 26
1
end_operator
begin_operator
debark car24 loc5
1
47 27
2
0 0 17 0
0 8 -1 27
1
end_operator
begin_operator
debark car24 loc6
1
47 28
2
0 0 17 0
0 8 -1 28
1
end_operator
begin_operator
debark car24 loc7
1
47 29
2
0 0 17 0
0 8 -1 29
1
end_operator
begin_operator
debark car24 loc8
1
47 30
2
0 0 17 0
0 8 -1 30
1
end_operator
begin_operator
debark car24 loc9
1
47 31
2
0 0 17 0
0 8 -1 31
1
end_operator
begin_operator
debark car25 loc1
1
47 0
2
0 0 18 0
0 14 -1 0
1
end_operator
begin_operator
debark car25 loc10
1
47 1
2
0 0 18 0
0 14 -1 1
1
end_operator
begin_operator
debark car25 loc11
1
47 2
2
0 0 18 0
0 14 -1 2
1
end_operator
begin_operator
debark car25 loc12
1
47 3
2
0 0 18 0
0 14 -1 3
1
end_operator
begin_operator
debark car25 loc13
1
47 4
2
0 0 18 0
0 14 -1 4
1
end_operator
begin_operator
debark car25 loc14
1
47 5
2
0 0 18 0
0 14 -1 5
1
end_operator
begin_operator
debark car25 loc15
1
47 6
2
0 0 18 0
0 14 -1 6
1
end_operator
begin_operator
debark car25 loc16
1
47 7
2
0 0 18 0
0 14 -1 7
1
end_operator
begin_operator
debark car25 loc17
1
47 8
2
0 0 18 0
0 14 -1 8
1
end_operator
begin_operator
debark car25 loc18
1
47 9
2
0 0 18 0
0 14 -1 9
1
end_operator
begin_operator
debark car25 loc19
1
47 10
2
0 0 18 0
0 14 -1 10
1
end_operator
begin_operator
debark car25 loc2
1
47 11
2
0 0 18 0
0 14 -1 11
1
end_operator
begin_operator
debark car25 loc20
1
47 12
2
0 0 18 0
0 14 -1 12
1
end_operator
begin_operator
debark car25 loc21
1
47 13
2
0 0 18 0
0 14 -1 13
1
end_operator
begin_operator
debark car25 loc22
1
47 14
2
0 0 18 0
0 14 -1 14
1
end_operator
begin_operator
debark car25 loc23
1
47 15
2
0 0 18 0
0 14 -1 15
1
end_operator
begin_operator
debark car25 loc24
1
47 16
2
0 0 18 0
0 14 -1 16
1
end_operator
begin_operator
debark car25 loc25
1
47 17
2
0 0 18 0
0 14 -1 17
1
end_operator
begin_operator
debark car25 loc26
1
47 18
2
0 0 18 0
0 14 -1 18
1
end_operator
begin_operator
debark car25 loc27
1
47 19
2
0 0 18 0
0 14 -1 19
1
end_operator
begin_operator
debark car25 loc28
1
47 20
2
0 0 18 0
0 14 -1 20
1
end_operator
begin_operator
debark car25 loc29
1
47 21
2
0 0 18 0
0 14 -1 21
1
end_operator
begin_operator
debark car25 loc3
1
47 22
2
0 0 18 0
0 14 -1 22
1
end_operator
begin_operator
debark car25 loc30
1
47 23
2
0 0 18 0
0 14 -1 23
1
end_operator
begin_operator
debark car25 loc31
1
47 24
2
0 0 18 0
0 14 -1 24
1
end_operator
begin_operator
debark car25 loc32
1
47 25
2
0 0 18 0
0 14 -1 25
1
end_operator
begin_operator
debark car25 loc4
1
47 26
2
0 0 18 0
0 14 -1 26
1
end_operator
begin_operator
debark car25 loc5
1
47 27
2
0 0 18 0
0 14 -1 27
1
end_operator
begin_operator
debark car25 loc6
1
47 28
2
0 0 18 0
0 14 -1 28
1
end_operator
begin_operator
debark car25 loc7
1
47 29
2
0 0 18 0
0 14 -1 29
1
end_operator
begin_operator
debark car25 loc8
1
47 30
2
0 0 18 0
0 14 -1 30
1
end_operator
begin_operator
debark car25 loc9
1
47 31
2
0 0 18 0
0 14 -1 31
1
end_operator
begin_operator
debark car26 loc1
1
47 0
2
0 0 19 0
0 20 -1 0
1
end_operator
begin_operator
debark car26 loc10
1
47 1
2
0 0 19 0
0 20 -1 1
1
end_operator
begin_operator
debark car26 loc11
1
47 2
2
0 0 19 0
0 20 -1 2
1
end_operator
begin_operator
debark car26 loc12
1
47 3
2
0 0 19 0
0 20 -1 3
1
end_operator
begin_operator
debark car26 loc13
1
47 4
2
0 0 19 0
0 20 -1 4
1
end_operator
begin_operator
debark car26 loc14
1
47 5
2
0 0 19 0
0 20 -1 5
1
end_operator
begin_operator
debark car26 loc15
1
47 6
2
0 0 19 0
0 20 -1 6
1
end_operator
begin_operator
debark car26 loc16
1
47 7
2
0 0 19 0
0 20 -1 7
1
end_operator
begin_operator
debark car26 loc17
1
47 8
2
0 0 19 0
0 20 -1 8
1
end_operator
begin_operator
debark car26 loc18
1
47 9
2
0 0 19 0
0 20 -1 9
1
end_operator
begin_operator
debark car26 loc19
1
47 10
2
0 0 19 0
0 20 -1 10
1
end_operator
begin_operator
debark car26 loc2
1
47 11
2
0 0 19 0
0 20 -1 11
1
end_operator
begin_operator
debark car26 loc20
1
47 12
2
0 0 19 0
0 20 -1 12
1
end_operator
begin_operator
debark car26 loc21
1
47 13
2
0 0 19 0
0 20 -1 13
1
end_operator
begin_operator
debark car26 loc22
1
47 14
2
0 0 19 0
0 20 -1 14
1
end_operator
begin_operator
debark car26 loc23
1
47 15
2
0 0 19 0
0 20 -1 15
1
end_operator
begin_operator
debark car26 loc24
1
47 16
2
0 0 19 0
0 20 -1 16
1
end_operator
begin_operator
debark car26 loc25
1
47 17
2
0 0 19 0
0 20 -1 17
1
end_operator
begin_operator
debark car26 loc26
1
47 18
2
0 0 19 0
0 20 -1 18
1
end_operator
begin_operator
debark car26 loc27
1
47 19
2
0 0 19 0
0 20 -1 19
1
end_operator
begin_operator
debark car26 loc28
1
47 20
2
0 0 19 0
0 20 -1 20
1
end_operator
begin_operator
debark car26 loc29
1
47 21
2
0 0 19 0
0 20 -1 21
1
end_operator
begin_operator
debark car26 loc3
1
47 22
2
0 0 19 0
0 20 -1 22
1
end_operator
begin_operator
debark car26 loc30
1
47 23
2
0 0 19 0
0 20 -1 23
1
end_operator
begin_operator
debark car26 loc31
1
47 24
2
0 0 19 0
0 20 -1 24
1
end_operator
begin_operator
debark car26 loc32
1
47 25
2
0 0 19 0
0 20 -1 25
1
end_operator
begin_operator
debark car26 loc4
1
47 26
2
0 0 19 0
0 20 -1 26
1
end_operator
begin_operator
debark car26 loc5
1
47 27
2
0 0 19 0
0 20 -1 27
1
end_operator
begin_operator
debark car26 loc6
1
47 28
2
0 0 19 0
0 20 -1 28
1
end_operator
begin_operator
debark car26 loc7
1
47 29
2
0 0 19 0
0 20 -1 29
1
end_operator
begin_operator
debark car26 loc8
1
47 30
2
0 0 19 0
0 20 -1 30
1
end_operator
begin_operator
debark car26 loc9
1
47 31
2
0 0 19 0
0 20 -1 31
1
end_operator
begin_operator
debark car27 loc1
1
47 0
2
0 0 20 0
0 26 -1 0
1
end_operator
begin_operator
debark car27 loc10
1
47 1
2
0 0 20 0
0 26 -1 1
1
end_operator
begin_operator
debark car27 loc11
1
47 2
2
0 0 20 0
0 26 -1 2
1
end_operator
begin_operator
debark car27 loc12
1
47 3
2
0 0 20 0
0 26 -1 3
1
end_operator
begin_operator
debark car27 loc13
1
47 4
2
0 0 20 0
0 26 -1 4
1
end_operator
begin_operator
debark car27 loc14
1
47 5
2
0 0 20 0
0 26 -1 5
1
end_operator
begin_operator
debark car27 loc15
1
47 6
2
0 0 20 0
0 26 -1 6
1
end_operator
begin_operator
debark car27 loc16
1
47 7
2
0 0 20 0
0 26 -1 7
1
end_operator
begin_operator
debark car27 loc17
1
47 8
2
0 0 20 0
0 26 -1 8
1
end_operator
begin_operator
debark car27 loc18
1
47 9
2
0 0 20 0
0 26 -1 9
1
end_operator
begin_operator
debark car27 loc19
1
47 10
2
0 0 20 0
0 26 -1 10
1
end_operator
begin_operator
debark car27 loc2
1
47 11
2
0 0 20 0
0 26 -1 11
1
end_operator
begin_operator
debark car27 loc20
1
47 12
2
0 0 20 0
0 26 -1 12
1
end_operator
begin_operator
debark car27 loc21
1
47 13
2
0 0 20 0
0 26 -1 13
1
end_operator
begin_operator
debark car27 loc22
1
47 14
2
0 0 20 0
0 26 -1 14
1
end_operator
begin_operator
debark car27 loc23
1
47 15
2
0 0 20 0
0 26 -1 15
1
end_operator
begin_operator
debark car27 loc24
1
47 16
2
0 0 20 0
0 26 -1 16
1
end_operator
begin_operator
debark car27 loc25
1
47 17
2
0 0 20 0
0 26 -1 17
1
end_operator
begin_operator
debark car27 loc26
1
47 18
2
0 0 20 0
0 26 -1 18
1
end_operator
begin_operator
debark car27 loc27
1
47 19
2
0 0 20 0
0 26 -1 19
1
end_operator
begin_operator
debark car27 loc28
1
47 20
2
0 0 20 0
0 26 -1 20
1
end_operator
begin_operator
debark car27 loc29
1
47 21
2
0 0 20 0
0 26 -1 21
1
end_operator
begin_operator
debark car27 loc3
1
47 22
2
0 0 20 0
0 26 -1 22
1
end_operator
begin_operator
debark car27 loc30
1
47 23
2
0 0 20 0
0 26 -1 23
1
end_operator
begin_operator
debark car27 loc31
1
47 24
2
0 0 20 0
0 26 -1 24
1
end_operator
begin_operator
debark car27 loc32
1
47 25
2
0 0 20 0
0 26 -1 25
1
end_operator
begin_operator
debark car27 loc4
1
47 26
2
0 0 20 0
0 26 -1 26
1
end_operator
begin_operator
debark car27 loc5
1
47 27
2
0 0 20 0
0 26 -1 27
1
end_operator
begin_operator
debark car27 loc6
1
47 28
2
0 0 20 0
0 26 -1 28
1
end_operator
begin_operator
debark car27 loc7
1
47 29
2
0 0 20 0
0 26 -1 29
1
end_operator
begin_operator
debark car27 loc8
1
47 30
2
0 0 20 0
0 26 -1 30
1
end_operator
begin_operator
debark car27 loc9
1
47 31
2
0 0 20 0
0 26 -1 31
1
end_operator
begin_operator
debark car28 loc1
1
47 0
2
0 0 21 0
0 32 -1 0
1
end_operator
begin_operator
debark car28 loc10
1
47 1
2
0 0 21 0
0 32 -1 1
1
end_operator
begin_operator
debark car28 loc11
1
47 2
2
0 0 21 0
0 32 -1 2
1
end_operator
begin_operator
debark car28 loc12
1
47 3
2
0 0 21 0
0 32 -1 3
1
end_operator
begin_operator
debark car28 loc13
1
47 4
2
0 0 21 0
0 32 -1 4
1
end_operator
begin_operator
debark car28 loc14
1
47 5
2
0 0 21 0
0 32 -1 5
1
end_operator
begin_operator
debark car28 loc15
1
47 6
2
0 0 21 0
0 32 -1 6
1
end_operator
begin_operator
debark car28 loc16
1
47 7
2
0 0 21 0
0 32 -1 7
1
end_operator
begin_operator
debark car28 loc17
1
47 8
2
0 0 21 0
0 32 -1 8
1
end_operator
begin_operator
debark car28 loc18
1
47 9
2
0 0 21 0
0 32 -1 9
1
end_operator
begin_operator
debark car28 loc19
1
47 10
2
0 0 21 0
0 32 -1 10
1
end_operator
begin_operator
debark car28 loc2
1
47 11
2
0 0 21 0
0 32 -1 11
1
end_operator
begin_operator
debark car28 loc20
1
47 12
2
0 0 21 0
0 32 -1 12
1
end_operator
begin_operator
debark car28 loc21
1
47 13
2
0 0 21 0
0 32 -1 13
1
end_operator
begin_operator
debark car28 loc22
1
47 14
2
0 0 21 0
0 32 -1 14
1
end_operator
begin_operator
debark car28 loc23
1
47 15
2
0 0 21 0
0 32 -1 15
1
end_operator
begin_operator
debark car28 loc24
1
47 16
2
0 0 21 0
0 32 -1 16
1
end_operator
begin_operator
debark car28 loc25
1
47 17
2
0 0 21 0
0 32 -1 17
1
end_operator
begin_operator
debark car28 loc26
1
47 18
2
0 0 21 0
0 32 -1 18
1
end_operator
begin_operator
debark car28 loc27
1
47 19
2
0 0 21 0
0 32 -1 19
1
end_operator
begin_operator
debark car28 loc28
1
47 20
2
0 0 21 0
0 32 -1 20
1
end_operator
begin_operator
debark car28 loc29
1
47 21
2
0 0 21 0
0 32 -1 21
1
end_operator
begin_operator
debark car28 loc3
1
47 22
2
0 0 21 0
0 32 -1 22
1
end_operator
begin_operator
debark car28 loc30
1
47 23
2
0 0 21 0
0 32 -1 23
1
end_operator
begin_operator
debark car28 loc31
1
47 24
2
0 0 21 0
0 32 -1 24
1
end_operator
begin_operator
debark car28 loc32
1
47 25
2
0 0 21 0
0 32 -1 25
1
end_operator
begin_operator
debark car28 loc4
1
47 26
2
0 0 21 0
0 32 -1 26
1
end_operator
begin_operator
debark car28 loc5
1
47 27
2
0 0 21 0
0 32 -1 27
1
end_operator
begin_operator
debark car28 loc6
1
47 28
2
0 0 21 0
0 32 -1 28
1
end_operator
begin_operator
debark car28 loc7
1
47 29
2
0 0 21 0
0 32 -1 29
1
end_operator
begin_operator
debark car28 loc8
1
47 30
2
0 0 21 0
0 32 -1 30
1
end_operator
begin_operator
debark car28 loc9
1
47 31
2
0 0 21 0
0 32 -1 31
1
end_operator
begin_operator
debark car29 loc1
1
47 0
2
0 0 22 0
0 38 -1 0
1
end_operator
begin_operator
debark car29 loc10
1
47 1
2
0 0 22 0
0 38 -1 1
1
end_operator
begin_operator
debark car29 loc11
1
47 2
2
0 0 22 0
0 38 -1 2
1
end_operator
begin_operator
debark car29 loc12
1
47 3
2
0 0 22 0
0 38 -1 3
1
end_operator
begin_operator
debark car29 loc13
1
47 4
2
0 0 22 0
0 38 -1 4
1
end_operator
begin_operator
debark car29 loc14
1
47 5
2
0 0 22 0
0 38 -1 5
1
end_operator
begin_operator
debark car29 loc15
1
47 6
2
0 0 22 0
0 38 -1 6
1
end_operator
begin_operator
debark car29 loc16
1
47 7
2
0 0 22 0
0 38 -1 7
1
end_operator
begin_operator
debark car29 loc17
1
47 8
2
0 0 22 0
0 38 -1 8
1
end_operator
begin_operator
debark car29 loc18
1
47 9
2
0 0 22 0
0 38 -1 9
1
end_operator
begin_operator
debark car29 loc19
1
47 10
2
0 0 22 0
0 38 -1 10
1
end_operator
begin_operator
debark car29 loc2
1
47 11
2
0 0 22 0
0 38 -1 11
1
end_operator
begin_operator
debark car29 loc20
1
47 12
2
0 0 22 0
0 38 -1 12
1
end_operator
begin_operator
debark car29 loc21
1
47 13
2
0 0 22 0
0 38 -1 13
1
end_operator
begin_operator
debark car29 loc22
1
47 14
2
0 0 22 0
0 38 -1 14
1
end_operator
begin_operator
debark car29 loc23
1
47 15
2
0 0 22 0
0 38 -1 15
1
end_operator
begin_operator
debark car29 loc24
1
47 16
2
0 0 22 0
0 38 -1 16
1
end_operator
begin_operator
debark car29 loc25
1
47 17
2
0 0 22 0
0 38 -1 17
1
end_operator
begin_operator
debark car29 loc26
1
47 18
2
0 0 22 0
0 38 -1 18
1
end_operator
begin_operator
debark car29 loc27
1
47 19
2
0 0 22 0
0 38 -1 19
1
end_operator
begin_operator
debark car29 loc28
1
47 20
2
0 0 22 0
0 38 -1 20
1
end_operator
begin_operator
debark car29 loc29
1
47 21
2
0 0 22 0
0 38 -1 21
1
end_operator
begin_operator
debark car29 loc3
1
47 22
2
0 0 22 0
0 38 -1 22
1
end_operator
begin_operator
debark car29 loc30
1
47 23
2
0 0 22 0
0 38 -1 23
1
end_operator
begin_operator
debark car29 loc31
1
47 24
2
0 0 22 0
0 38 -1 24
1
end_operator
begin_operator
debark car29 loc32
1
47 25
2
0 0 22 0
0 38 -1 25
1
end_operator
begin_operator
debark car29 loc4
1
47 26
2
0 0 22 0
0 38 -1 26
1
end_operator
begin_operator
debark car29 loc5
1
47 27
2
0 0 22 0
0 38 -1 27
1
end_operator
begin_operator
debark car29 loc6
1
47 28
2
0 0 22 0
0 38 -1 28
1
end_operator
begin_operator
debark car29 loc7
1
47 29
2
0 0 22 0
0 38 -1 29
1
end_operator
begin_operator
debark car29 loc8
1
47 30
2
0 0 22 0
0 38 -1 30
1
end_operator
begin_operator
debark car29 loc9
1
47 31
2
0 0 22 0
0 38 -1 31
1
end_operator
begin_operator
debark car3 loc1
1
47 0
2
0 0 23 0
0 44 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
47 1
2
0 0 23 0
0 44 -1 1
1
end_operator
begin_operator
debark car3 loc11
1
47 2
2
0 0 23 0
0 44 -1 2
1
end_operator
begin_operator
debark car3 loc12
1
47 3
2
0 0 23 0
0 44 -1 3
1
end_operator
begin_operator
debark car3 loc13
1
47 4
2
0 0 23 0
0 44 -1 4
1
end_operator
begin_operator
debark car3 loc14
1
47 5
2
0 0 23 0
0 44 -1 5
1
end_operator
begin_operator
debark car3 loc15
1
47 6
2
0 0 23 0
0 44 -1 6
1
end_operator
begin_operator
debark car3 loc16
1
47 7
2
0 0 23 0
0 44 -1 7
1
end_operator
begin_operator
debark car3 loc17
1
47 8
2
0 0 23 0
0 44 -1 8
1
end_operator
begin_operator
debark car3 loc18
1
47 9
2
0 0 23 0
0 44 -1 9
1
end_operator
begin_operator
debark car3 loc19
1
47 10
2
0 0 23 0
0 44 -1 10
1
end_operator
begin_operator
debark car3 loc2
1
47 11
2
0 0 23 0
0 44 -1 11
1
end_operator
begin_operator
debark car3 loc20
1
47 12
2
0 0 23 0
0 44 -1 12
1
end_operator
begin_operator
debark car3 loc21
1
47 13
2
0 0 23 0
0 44 -1 13
1
end_operator
begin_operator
debark car3 loc22
1
47 14
2
0 0 23 0
0 44 -1 14
1
end_operator
begin_operator
debark car3 loc23
1
47 15
2
0 0 23 0
0 44 -1 15
1
end_operator
begin_operator
debark car3 loc24
1
47 16
2
0 0 23 0
0 44 -1 16
1
end_operator
begin_operator
debark car3 loc25
1
47 17
2
0 0 23 0
0 44 -1 17
1
end_operator
begin_operator
debark car3 loc26
1
47 18
2
0 0 23 0
0 44 -1 18
1
end_operator
begin_operator
debark car3 loc27
1
47 19
2
0 0 23 0
0 44 -1 19
1
end_operator
begin_operator
debark car3 loc28
1
47 20
2
0 0 23 0
0 44 -1 20
1
end_operator
begin_operator
debark car3 loc29
1
47 21
2
0 0 23 0
0 44 -1 21
1
end_operator
begin_operator
debark car3 loc3
1
47 22
2
0 0 23 0
0 44 -1 22
1
end_operator
begin_operator
debark car3 loc30
1
47 23
2
0 0 23 0
0 44 -1 23
1
end_operator
begin_operator
debark car3 loc31
1
47 24
2
0 0 23 0
0 44 -1 24
1
end_operator
begin_operator
debark car3 loc32
1
47 25
2
0 0 23 0
0 44 -1 25
1
end_operator
begin_operator
debark car3 loc4
1
47 26
2
0 0 23 0
0 44 -1 26
1
end_operator
begin_operator
debark car3 loc5
1
47 27
2
0 0 23 0
0 44 -1 27
1
end_operator
begin_operator
debark car3 loc6
1
47 28
2
0 0 23 0
0 44 -1 28
1
end_operator
begin_operator
debark car3 loc7
1
47 29
2
0 0 23 0
0 44 -1 29
1
end_operator
begin_operator
debark car3 loc8
1
47 30
2
0 0 23 0
0 44 -1 30
1
end_operator
begin_operator
debark car3 loc9
1
47 31
2
0 0 23 0
0 44 -1 31
1
end_operator
begin_operator
debark car30 loc1
1
47 0
2
0 0 24 0
0 3 -1 0
1
end_operator
begin_operator
debark car30 loc10
1
47 1
2
0 0 24 0
0 3 -1 1
1
end_operator
begin_operator
debark car30 loc11
1
47 2
2
0 0 24 0
0 3 -1 2
1
end_operator
begin_operator
debark car30 loc12
1
47 3
2
0 0 24 0
0 3 -1 3
1
end_operator
begin_operator
debark car30 loc13
1
47 4
2
0 0 24 0
0 3 -1 4
1
end_operator
begin_operator
debark car30 loc14
1
47 5
2
0 0 24 0
0 3 -1 5
1
end_operator
begin_operator
debark car30 loc15
1
47 6
2
0 0 24 0
0 3 -1 6
1
end_operator
begin_operator
debark car30 loc16
1
47 7
2
0 0 24 0
0 3 -1 7
1
end_operator
begin_operator
debark car30 loc17
1
47 8
2
0 0 24 0
0 3 -1 8
1
end_operator
begin_operator
debark car30 loc18
1
47 9
2
0 0 24 0
0 3 -1 9
1
end_operator
begin_operator
debark car30 loc19
1
47 10
2
0 0 24 0
0 3 -1 10
1
end_operator
begin_operator
debark car30 loc2
1
47 11
2
0 0 24 0
0 3 -1 11
1
end_operator
begin_operator
debark car30 loc20
1
47 12
2
0 0 24 0
0 3 -1 12
1
end_operator
begin_operator
debark car30 loc21
1
47 13
2
0 0 24 0
0 3 -1 13
1
end_operator
begin_operator
debark car30 loc22
1
47 14
2
0 0 24 0
0 3 -1 14
1
end_operator
begin_operator
debark car30 loc23
1
47 15
2
0 0 24 0
0 3 -1 15
1
end_operator
begin_operator
debark car30 loc24
1
47 16
2
0 0 24 0
0 3 -1 16
1
end_operator
begin_operator
debark car30 loc25
1
47 17
2
0 0 24 0
0 3 -1 17
1
end_operator
begin_operator
debark car30 loc26
1
47 18
2
0 0 24 0
0 3 -1 18
1
end_operator
begin_operator
debark car30 loc27
1
47 19
2
0 0 24 0
0 3 -1 19
1
end_operator
begin_operator
debark car30 loc28
1
47 20
2
0 0 24 0
0 3 -1 20
1
end_operator
begin_operator
debark car30 loc29
1
47 21
2
0 0 24 0
0 3 -1 21
1
end_operator
begin_operator
debark car30 loc3
1
47 22
2
0 0 24 0
0 3 -1 22
1
end_operator
begin_operator
debark car30 loc30
1
47 23
2
0 0 24 0
0 3 -1 23
1
end_operator
begin_operator
debark car30 loc31
1
47 24
2
0 0 24 0
0 3 -1 24
1
end_operator
begin_operator
debark car30 loc32
1
47 25
2
0 0 24 0
0 3 -1 25
1
end_operator
begin_operator
debark car30 loc4
1
47 26
2
0 0 24 0
0 3 -1 26
1
end_operator
begin_operator
debark car30 loc5
1
47 27
2
0 0 24 0
0 3 -1 27
1
end_operator
begin_operator
debark car30 loc6
1
47 28
2
0 0 24 0
0 3 -1 28
1
end_operator
begin_operator
debark car30 loc7
1
47 29
2
0 0 24 0
0 3 -1 29
1
end_operator
begin_operator
debark car30 loc8
1
47 30
2
0 0 24 0
0 3 -1 30
1
end_operator
begin_operator
debark car30 loc9
1
47 31
2
0 0 24 0
0 3 -1 31
1
end_operator
begin_operator
debark car31 loc1
1
47 0
2
0 0 25 0
0 9 -1 0
1
end_operator
begin_operator
debark car31 loc10
1
47 1
2
0 0 25 0
0 9 -1 1
1
end_operator
begin_operator
debark car31 loc11
1
47 2
2
0 0 25 0
0 9 -1 2
1
end_operator
begin_operator
debark car31 loc12
1
47 3
2
0 0 25 0
0 9 -1 3
1
end_operator
begin_operator
debark car31 loc13
1
47 4
2
0 0 25 0
0 9 -1 4
1
end_operator
begin_operator
debark car31 loc14
1
47 5
2
0 0 25 0
0 9 -1 5
1
end_operator
begin_operator
debark car31 loc15
1
47 6
2
0 0 25 0
0 9 -1 6
1
end_operator
begin_operator
debark car31 loc16
1
47 7
2
0 0 25 0
0 9 -1 7
1
end_operator
begin_operator
debark car31 loc17
1
47 8
2
0 0 25 0
0 9 -1 8
1
end_operator
begin_operator
debark car31 loc18
1
47 9
2
0 0 25 0
0 9 -1 9
1
end_operator
begin_operator
debark car31 loc19
1
47 10
2
0 0 25 0
0 9 -1 10
1
end_operator
begin_operator
debark car31 loc2
1
47 11
2
0 0 25 0
0 9 -1 11
1
end_operator
begin_operator
debark car31 loc20
1
47 12
2
0 0 25 0
0 9 -1 12
1
end_operator
begin_operator
debark car31 loc21
1
47 13
2
0 0 25 0
0 9 -1 13
1
end_operator
begin_operator
debark car31 loc22
1
47 14
2
0 0 25 0
0 9 -1 14
1
end_operator
begin_operator
debark car31 loc23
1
47 15
2
0 0 25 0
0 9 -1 15
1
end_operator
begin_operator
debark car31 loc24
1
47 16
2
0 0 25 0
0 9 -1 16
1
end_operator
begin_operator
debark car31 loc25
1
47 17
2
0 0 25 0
0 9 -1 17
1
end_operator
begin_operator
debark car31 loc26
1
47 18
2
0 0 25 0
0 9 -1 18
1
end_operator
begin_operator
debark car31 loc27
1
47 19
2
0 0 25 0
0 9 -1 19
1
end_operator
begin_operator
debark car31 loc28
1
47 20
2
0 0 25 0
0 9 -1 20
1
end_operator
begin_operator
debark car31 loc29
1
47 21
2
0 0 25 0
0 9 -1 21
1
end_operator
begin_operator
debark car31 loc3
1
47 22
2
0 0 25 0
0 9 -1 22
1
end_operator
begin_operator
debark car31 loc30
1
47 23
2
0 0 25 0
0 9 -1 23
1
end_operator
begin_operator
debark car31 loc31
1
47 24
2
0 0 25 0
0 9 -1 24
1
end_operator
begin_operator
debark car31 loc32
1
47 25
2
0 0 25 0
0 9 -1 25
1
end_operator
begin_operator
debark car31 loc4
1
47 26
2
0 0 25 0
0 9 -1 26
1
end_operator
begin_operator
debark car31 loc5
1
47 27
2
0 0 25 0
0 9 -1 27
1
end_operator
begin_operator
debark car31 loc6
1
47 28
2
0 0 25 0
0 9 -1 28
1
end_operator
begin_operator
debark car31 loc7
1
47 29
2
0 0 25 0
0 9 -1 29
1
end_operator
begin_operator
debark car31 loc8
1
47 30
2
0 0 25 0
0 9 -1 30
1
end_operator
begin_operator
debark car31 loc9
1
47 31
2
0 0 25 0
0 9 -1 31
1
end_operator
begin_operator
debark car32 loc1
1
47 0
2
0 0 26 0
0 15 -1 0
1
end_operator
begin_operator
debark car32 loc10
1
47 1
2
0 0 26 0
0 15 -1 1
1
end_operator
begin_operator
debark car32 loc11
1
47 2
2
0 0 26 0
0 15 -1 2
1
end_operator
begin_operator
debark car32 loc12
1
47 3
2
0 0 26 0
0 15 -1 3
1
end_operator
begin_operator
debark car32 loc13
1
47 4
2
0 0 26 0
0 15 -1 4
1
end_operator
begin_operator
debark car32 loc14
1
47 5
2
0 0 26 0
0 15 -1 5
1
end_operator
begin_operator
debark car32 loc15
1
47 6
2
0 0 26 0
0 15 -1 6
1
end_operator
begin_operator
debark car32 loc16
1
47 7
2
0 0 26 0
0 15 -1 7
1
end_operator
begin_operator
debark car32 loc17
1
47 8
2
0 0 26 0
0 15 -1 8
1
end_operator
begin_operator
debark car32 loc18
1
47 9
2
0 0 26 0
0 15 -1 9
1
end_operator
begin_operator
debark car32 loc19
1
47 10
2
0 0 26 0
0 15 -1 10
1
end_operator
begin_operator
debark car32 loc2
1
47 11
2
0 0 26 0
0 15 -1 11
1
end_operator
begin_operator
debark car32 loc20
1
47 12
2
0 0 26 0
0 15 -1 12
1
end_operator
begin_operator
debark car32 loc21
1
47 13
2
0 0 26 0
0 15 -1 13
1
end_operator
begin_operator
debark car32 loc22
1
47 14
2
0 0 26 0
0 15 -1 14
1
end_operator
begin_operator
debark car32 loc23
1
47 15
2
0 0 26 0
0 15 -1 15
1
end_operator
begin_operator
debark car32 loc24
1
47 16
2
0 0 26 0
0 15 -1 16
1
end_operator
begin_operator
debark car32 loc25
1
47 17
2
0 0 26 0
0 15 -1 17
1
end_operator
begin_operator
debark car32 loc26
1
47 18
2
0 0 26 0
0 15 -1 18
1
end_operator
begin_operator
debark car32 loc27
1
47 19
2
0 0 26 0
0 15 -1 19
1
end_operator
begin_operator
debark car32 loc28
1
47 20
2
0 0 26 0
0 15 -1 20
1
end_operator
begin_operator
debark car32 loc29
1
47 21
2
0 0 26 0
0 15 -1 21
1
end_operator
begin_operator
debark car32 loc3
1
47 22
2
0 0 26 0
0 15 -1 22
1
end_operator
begin_operator
debark car32 loc30
1
47 23
2
0 0 26 0
0 15 -1 23
1
end_operator
begin_operator
debark car32 loc31
1
47 24
2
0 0 26 0
0 15 -1 24
1
end_operator
begin_operator
debark car32 loc32
1
47 25
2
0 0 26 0
0 15 -1 25
1
end_operator
begin_operator
debark car32 loc4
1
47 26
2
0 0 26 0
0 15 -1 26
1
end_operator
begin_operator
debark car32 loc5
1
47 27
2
0 0 26 0
0 15 -1 27
1
end_operator
begin_operator
debark car32 loc6
1
47 28
2
0 0 26 0
0 15 -1 28
1
end_operator
begin_operator
debark car32 loc7
1
47 29
2
0 0 26 0
0 15 -1 29
1
end_operator
begin_operator
debark car32 loc8
1
47 30
2
0 0 26 0
0 15 -1 30
1
end_operator
begin_operator
debark car32 loc9
1
47 31
2
0 0 26 0
0 15 -1 31
1
end_operator
begin_operator
debark car33 loc1
1
47 0
2
0 0 27 0
0 21 -1 0
1
end_operator
begin_operator
debark car33 loc10
1
47 1
2
0 0 27 0
0 21 -1 1
1
end_operator
begin_operator
debark car33 loc11
1
47 2
2
0 0 27 0
0 21 -1 2
1
end_operator
begin_operator
debark car33 loc12
1
47 3
2
0 0 27 0
0 21 -1 3
1
end_operator
begin_operator
debark car33 loc13
1
47 4
2
0 0 27 0
0 21 -1 4
1
end_operator
begin_operator
debark car33 loc14
1
47 5
2
0 0 27 0
0 21 -1 5
1
end_operator
begin_operator
debark car33 loc15
1
47 6
2
0 0 27 0
0 21 -1 6
1
end_operator
begin_operator
debark car33 loc16
1
47 7
2
0 0 27 0
0 21 -1 7
1
end_operator
begin_operator
debark car33 loc17
1
47 8
2
0 0 27 0
0 21 -1 8
1
end_operator
begin_operator
debark car33 loc18
1
47 9
2
0 0 27 0
0 21 -1 9
1
end_operator
begin_operator
debark car33 loc19
1
47 10
2
0 0 27 0
0 21 -1 10
1
end_operator
begin_operator
debark car33 loc2
1
47 11
2
0 0 27 0
0 21 -1 11
1
end_operator
begin_operator
debark car33 loc20
1
47 12
2
0 0 27 0
0 21 -1 12
1
end_operator
begin_operator
debark car33 loc21
1
47 13
2
0 0 27 0
0 21 -1 13
1
end_operator
begin_operator
debark car33 loc22
1
47 14
2
0 0 27 0
0 21 -1 14
1
end_operator
begin_operator
debark car33 loc23
1
47 15
2
0 0 27 0
0 21 -1 15
1
end_operator
begin_operator
debark car33 loc24
1
47 16
2
0 0 27 0
0 21 -1 16
1
end_operator
begin_operator
debark car33 loc25
1
47 17
2
0 0 27 0
0 21 -1 17
1
end_operator
begin_operator
debark car33 loc26
1
47 18
2
0 0 27 0
0 21 -1 18
1
end_operator
begin_operator
debark car33 loc27
1
47 19
2
0 0 27 0
0 21 -1 19
1
end_operator
begin_operator
debark car33 loc28
1
47 20
2
0 0 27 0
0 21 -1 20
1
end_operator
begin_operator
debark car33 loc29
1
47 21
2
0 0 27 0
0 21 -1 21
1
end_operator
begin_operator
debark car33 loc3
1
47 22
2
0 0 27 0
0 21 -1 22
1
end_operator
begin_operator
debark car33 loc30
1
47 23
2
0 0 27 0
0 21 -1 23
1
end_operator
begin_operator
debark car33 loc31
1
47 24
2
0 0 27 0
0 21 -1 24
1
end_operator
begin_operator
debark car33 loc32
1
47 25
2
0 0 27 0
0 21 -1 25
1
end_operator
begin_operator
debark car33 loc4
1
47 26
2
0 0 27 0
0 21 -1 26
1
end_operator
begin_operator
debark car33 loc5
1
47 27
2
0 0 27 0
0 21 -1 27
1
end_operator
begin_operator
debark car33 loc6
1
47 28
2
0 0 27 0
0 21 -1 28
1
end_operator
begin_operator
debark car33 loc7
1
47 29
2
0 0 27 0
0 21 -1 29
1
end_operator
begin_operator
debark car33 loc8
1
47 30
2
0 0 27 0
0 21 -1 30
1
end_operator
begin_operator
debark car33 loc9
1
47 31
2
0 0 27 0
0 21 -1 31
1
end_operator
begin_operator
debark car34 loc1
1
47 0
2
0 0 28 0
0 27 -1 0
1
end_operator
begin_operator
debark car34 loc10
1
47 1
2
0 0 28 0
0 27 -1 1
1
end_operator
begin_operator
debark car34 loc11
1
47 2
2
0 0 28 0
0 27 -1 2
1
end_operator
begin_operator
debark car34 loc12
1
47 3
2
0 0 28 0
0 27 -1 3
1
end_operator
begin_operator
debark car34 loc13
1
47 4
2
0 0 28 0
0 27 -1 4
1
end_operator
begin_operator
debark car34 loc14
1
47 5
2
0 0 28 0
0 27 -1 5
1
end_operator
begin_operator
debark car34 loc15
1
47 6
2
0 0 28 0
0 27 -1 6
1
end_operator
begin_operator
debark car34 loc16
1
47 7
2
0 0 28 0
0 27 -1 7
1
end_operator
begin_operator
debark car34 loc17
1
47 8
2
0 0 28 0
0 27 -1 8
1
end_operator
begin_operator
debark car34 loc18
1
47 9
2
0 0 28 0
0 27 -1 9
1
end_operator
begin_operator
debark car34 loc19
1
47 10
2
0 0 28 0
0 27 -1 10
1
end_operator
begin_operator
debark car34 loc2
1
47 11
2
0 0 28 0
0 27 -1 11
1
end_operator
begin_operator
debark car34 loc20
1
47 12
2
0 0 28 0
0 27 -1 12
1
end_operator
begin_operator
debark car34 loc21
1
47 13
2
0 0 28 0
0 27 -1 13
1
end_operator
begin_operator
debark car34 loc22
1
47 14
2
0 0 28 0
0 27 -1 14
1
end_operator
begin_operator
debark car34 loc23
1
47 15
2
0 0 28 0
0 27 -1 15
1
end_operator
begin_operator
debark car34 loc24
1
47 16
2
0 0 28 0
0 27 -1 16
1
end_operator
begin_operator
debark car34 loc25
1
47 17
2
0 0 28 0
0 27 -1 17
1
end_operator
begin_operator
debark car34 loc26
1
47 18
2
0 0 28 0
0 27 -1 18
1
end_operator
begin_operator
debark car34 loc27
1
47 19
2
0 0 28 0
0 27 -1 19
1
end_operator
begin_operator
debark car34 loc28
1
47 20
2
0 0 28 0
0 27 -1 20
1
end_operator
begin_operator
debark car34 loc29
1
47 21
2
0 0 28 0
0 27 -1 21
1
end_operator
begin_operator
debark car34 loc3
1
47 22
2
0 0 28 0
0 27 -1 22
1
end_operator
begin_operator
debark car34 loc30
1
47 23
2
0 0 28 0
0 27 -1 23
1
end_operator
begin_operator
debark car34 loc31
1
47 24
2
0 0 28 0
0 27 -1 24
1
end_operator
begin_operator
debark car34 loc32
1
47 25
2
0 0 28 0
0 27 -1 25
1
end_operator
begin_operator
debark car34 loc4
1
47 26
2
0 0 28 0
0 27 -1 26
1
end_operator
begin_operator
debark car34 loc5
1
47 27
2
0 0 28 0
0 27 -1 27
1
end_operator
begin_operator
debark car34 loc6
1
47 28
2
0 0 28 0
0 27 -1 28
1
end_operator
begin_operator
debark car34 loc7
1
47 29
2
0 0 28 0
0 27 -1 29
1
end_operator
begin_operator
debark car34 loc8
1
47 30
2
0 0 28 0
0 27 -1 30
1
end_operator
begin_operator
debark car34 loc9
1
47 31
2
0 0 28 0
0 27 -1 31
1
end_operator
begin_operator
debark car35 loc1
1
47 0
2
0 0 29 0
0 33 -1 0
1
end_operator
begin_operator
debark car35 loc10
1
47 1
2
0 0 29 0
0 33 -1 1
1
end_operator
begin_operator
debark car35 loc11
1
47 2
2
0 0 29 0
0 33 -1 2
1
end_operator
begin_operator
debark car35 loc12
1
47 3
2
0 0 29 0
0 33 -1 3
1
end_operator
begin_operator
debark car35 loc13
1
47 4
2
0 0 29 0
0 33 -1 4
1
end_operator
begin_operator
debark car35 loc14
1
47 5
2
0 0 29 0
0 33 -1 5
1
end_operator
begin_operator
debark car35 loc15
1
47 6
2
0 0 29 0
0 33 -1 6
1
end_operator
begin_operator
debark car35 loc16
1
47 7
2
0 0 29 0
0 33 -1 7
1
end_operator
begin_operator
debark car35 loc17
1
47 8
2
0 0 29 0
0 33 -1 8
1
end_operator
begin_operator
debark car35 loc18
1
47 9
2
0 0 29 0
0 33 -1 9
1
end_operator
begin_operator
debark car35 loc19
1
47 10
2
0 0 29 0
0 33 -1 10
1
end_operator
begin_operator
debark car35 loc2
1
47 11
2
0 0 29 0
0 33 -1 11
1
end_operator
begin_operator
debark car35 loc20
1
47 12
2
0 0 29 0
0 33 -1 12
1
end_operator
begin_operator
debark car35 loc21
1
47 13
2
0 0 29 0
0 33 -1 13
1
end_operator
begin_operator
debark car35 loc22
1
47 14
2
0 0 29 0
0 33 -1 14
1
end_operator
begin_operator
debark car35 loc23
1
47 15
2
0 0 29 0
0 33 -1 15
1
end_operator
begin_operator
debark car35 loc24
1
47 16
2
0 0 29 0
0 33 -1 16
1
end_operator
begin_operator
debark car35 loc25
1
47 17
2
0 0 29 0
0 33 -1 17
1
end_operator
begin_operator
debark car35 loc26
1
47 18
2
0 0 29 0
0 33 -1 18
1
end_operator
begin_operator
debark car35 loc27
1
47 19
2
0 0 29 0
0 33 -1 19
1
end_operator
begin_operator
debark car35 loc28
1
47 20
2
0 0 29 0
0 33 -1 20
1
end_operator
begin_operator
debark car35 loc29
1
47 21
2
0 0 29 0
0 33 -1 21
1
end_operator
begin_operator
debark car35 loc3
1
47 22
2
0 0 29 0
0 33 -1 22
1
end_operator
begin_operator
debark car35 loc30
1
47 23
2
0 0 29 0
0 33 -1 23
1
end_operator
begin_operator
debark car35 loc31
1
47 24
2
0 0 29 0
0 33 -1 24
1
end_operator
begin_operator
debark car35 loc32
1
47 25
2
0 0 29 0
0 33 -1 25
1
end_operator
begin_operator
debark car35 loc4
1
47 26
2
0 0 29 0
0 33 -1 26
1
end_operator
begin_operator
debark car35 loc5
1
47 27
2
0 0 29 0
0 33 -1 27
1
end_operator
begin_operator
debark car35 loc6
1
47 28
2
0 0 29 0
0 33 -1 28
1
end_operator
begin_operator
debark car35 loc7
1
47 29
2
0 0 29 0
0 33 -1 29
1
end_operator
begin_operator
debark car35 loc8
1
47 30
2
0 0 29 0
0 33 -1 30
1
end_operator
begin_operator
debark car35 loc9
1
47 31
2
0 0 29 0
0 33 -1 31
1
end_operator
begin_operator
debark car36 loc1
1
47 0
2
0 0 30 0
0 39 -1 0
1
end_operator
begin_operator
debark car36 loc10
1
47 1
2
0 0 30 0
0 39 -1 1
1
end_operator
begin_operator
debark car36 loc11
1
47 2
2
0 0 30 0
0 39 -1 2
1
end_operator
begin_operator
debark car36 loc12
1
47 3
2
0 0 30 0
0 39 -1 3
1
end_operator
begin_operator
debark car36 loc13
1
47 4
2
0 0 30 0
0 39 -1 4
1
end_operator
begin_operator
debark car36 loc14
1
47 5
2
0 0 30 0
0 39 -1 5
1
end_operator
begin_operator
debark car36 loc15
1
47 6
2
0 0 30 0
0 39 -1 6
1
end_operator
begin_operator
debark car36 loc16
1
47 7
2
0 0 30 0
0 39 -1 7
1
end_operator
begin_operator
debark car36 loc17
1
47 8
2
0 0 30 0
0 39 -1 8
1
end_operator
begin_operator
debark car36 loc18
1
47 9
2
0 0 30 0
0 39 -1 9
1
end_operator
begin_operator
debark car36 loc19
1
47 10
2
0 0 30 0
0 39 -1 10
1
end_operator
begin_operator
debark car36 loc2
1
47 11
2
0 0 30 0
0 39 -1 11
1
end_operator
begin_operator
debark car36 loc20
1
47 12
2
0 0 30 0
0 39 -1 12
1
end_operator
begin_operator
debark car36 loc21
1
47 13
2
0 0 30 0
0 39 -1 13
1
end_operator
begin_operator
debark car36 loc22
1
47 14
2
0 0 30 0
0 39 -1 14
1
end_operator
begin_operator
debark car36 loc23
1
47 15
2
0 0 30 0
0 39 -1 15
1
end_operator
begin_operator
debark car36 loc24
1
47 16
2
0 0 30 0
0 39 -1 16
1
end_operator
begin_operator
debark car36 loc25
1
47 17
2
0 0 30 0
0 39 -1 17
1
end_operator
begin_operator
debark car36 loc26
1
47 18
2
0 0 30 0
0 39 -1 18
1
end_operator
begin_operator
debark car36 loc27
1
47 19
2
0 0 30 0
0 39 -1 19
1
end_operator
begin_operator
debark car36 loc28
1
47 20
2
0 0 30 0
0 39 -1 20
1
end_operator
begin_operator
debark car36 loc29
1
47 21
2
0 0 30 0
0 39 -1 21
1
end_operator
begin_operator
debark car36 loc3
1
47 22
2
0 0 30 0
0 39 -1 22
1
end_operator
begin_operator
debark car36 loc30
1
47 23
2
0 0 30 0
0 39 -1 23
1
end_operator
begin_operator
debark car36 loc31
1
47 24
2
0 0 30 0
0 39 -1 24
1
end_operator
begin_operator
debark car36 loc32
1
47 25
2
0 0 30 0
0 39 -1 25
1
end_operator
begin_operator
debark car36 loc4
1
47 26
2
0 0 30 0
0 39 -1 26
1
end_operator
begin_operator
debark car36 loc5
1
47 27
2
0 0 30 0
0 39 -1 27
1
end_operator
begin_operator
debark car36 loc6
1
47 28
2
0 0 30 0
0 39 -1 28
1
end_operator
begin_operator
debark car36 loc7
1
47 29
2
0 0 30 0
0 39 -1 29
1
end_operator
begin_operator
debark car36 loc8
1
47 30
2
0 0 30 0
0 39 -1 30
1
end_operator
begin_operator
debark car36 loc9
1
47 31
2
0 0 30 0
0 39 -1 31
1
end_operator
begin_operator
debark car37 loc1
1
47 0
2
0 0 31 0
0 45 -1 0
1
end_operator
begin_operator
debark car37 loc10
1
47 1
2
0 0 31 0
0 45 -1 1
1
end_operator
begin_operator
debark car37 loc11
1
47 2
2
0 0 31 0
0 45 -1 2
1
end_operator
begin_operator
debark car37 loc12
1
47 3
2
0 0 31 0
0 45 -1 3
1
end_operator
begin_operator
debark car37 loc13
1
47 4
2
0 0 31 0
0 45 -1 4
1
end_operator
begin_operator
debark car37 loc14
1
47 5
2
0 0 31 0
0 45 -1 5
1
end_operator
begin_operator
debark car37 loc15
1
47 6
2
0 0 31 0
0 45 -1 6
1
end_operator
begin_operator
debark car37 loc16
1
47 7
2
0 0 31 0
0 45 -1 7
1
end_operator
begin_operator
debark car37 loc17
1
47 8
2
0 0 31 0
0 45 -1 8
1
end_operator
begin_operator
debark car37 loc18
1
47 9
2
0 0 31 0
0 45 -1 9
1
end_operator
begin_operator
debark car37 loc19
1
47 10
2
0 0 31 0
0 45 -1 10
1
end_operator
begin_operator
debark car37 loc2
1
47 11
2
0 0 31 0
0 45 -1 11
1
end_operator
begin_operator
debark car37 loc20
1
47 12
2
0 0 31 0
0 45 -1 12
1
end_operator
begin_operator
debark car37 loc21
1
47 13
2
0 0 31 0
0 45 -1 13
1
end_operator
begin_operator
debark car37 loc22
1
47 14
2
0 0 31 0
0 45 -1 14
1
end_operator
begin_operator
debark car37 loc23
1
47 15
2
0 0 31 0
0 45 -1 15
1
end_operator
begin_operator
debark car37 loc24
1
47 16
2
0 0 31 0
0 45 -1 16
1
end_operator
begin_operator
debark car37 loc25
1
47 17
2
0 0 31 0
0 45 -1 17
1
end_operator
begin_operator
debark car37 loc26
1
47 18
2
0 0 31 0
0 45 -1 18
1
end_operator
begin_operator
debark car37 loc27
1
47 19
2
0 0 31 0
0 45 -1 19
1
end_operator
begin_operator
debark car37 loc28
1
47 20
2
0 0 31 0
0 45 -1 20
1
end_operator
begin_operator
debark car37 loc29
1
47 21
2
0 0 31 0
0 45 -1 21
1
end_operator
begin_operator
debark car37 loc3
1
47 22
2
0 0 31 0
0 45 -1 22
1
end_operator
begin_operator
debark car37 loc30
1
47 23
2
0 0 31 0
0 45 -1 23
1
end_operator
begin_operator
debark car37 loc31
1
47 24
2
0 0 31 0
0 45 -1 24
1
end_operator
begin_operator
debark car37 loc32
1
47 25
2
0 0 31 0
0 45 -1 25
1
end_operator
begin_operator
debark car37 loc4
1
47 26
2
0 0 31 0
0 45 -1 26
1
end_operator
begin_operator
debark car37 loc5
1
47 27
2
0 0 31 0
0 45 -1 27
1
end_operator
begin_operator
debark car37 loc6
1
47 28
2
0 0 31 0
0 45 -1 28
1
end_operator
begin_operator
debark car37 loc7
1
47 29
2
0 0 31 0
0 45 -1 29
1
end_operator
begin_operator
debark car37 loc8
1
47 30
2
0 0 31 0
0 45 -1 30
1
end_operator
begin_operator
debark car37 loc9
1
47 31
2
0 0 31 0
0 45 -1 31
1
end_operator
begin_operator
debark car38 loc1
1
47 0
2
0 0 32 0
0 4 -1 0
1
end_operator
begin_operator
debark car38 loc10
1
47 1
2
0 0 32 0
0 4 -1 1
1
end_operator
begin_operator
debark car38 loc11
1
47 2
2
0 0 32 0
0 4 -1 2
1
end_operator
begin_operator
debark car38 loc12
1
47 3
2
0 0 32 0
0 4 -1 3
1
end_operator
begin_operator
debark car38 loc13
1
47 4
2
0 0 32 0
0 4 -1 4
1
end_operator
begin_operator
debark car38 loc14
1
47 5
2
0 0 32 0
0 4 -1 5
1
end_operator
begin_operator
debark car38 loc15
1
47 6
2
0 0 32 0
0 4 -1 6
1
end_operator
begin_operator
debark car38 loc16
1
47 7
2
0 0 32 0
0 4 -1 7
1
end_operator
begin_operator
debark car38 loc17
1
47 8
2
0 0 32 0
0 4 -1 8
1
end_operator
begin_operator
debark car38 loc18
1
47 9
2
0 0 32 0
0 4 -1 9
1
end_operator
begin_operator
debark car38 loc19
1
47 10
2
0 0 32 0
0 4 -1 10
1
end_operator
begin_operator
debark car38 loc2
1
47 11
2
0 0 32 0
0 4 -1 11
1
end_operator
begin_operator
debark car38 loc20
1
47 12
2
0 0 32 0
0 4 -1 12
1
end_operator
begin_operator
debark car38 loc21
1
47 13
2
0 0 32 0
0 4 -1 13
1
end_operator
begin_operator
debark car38 loc22
1
47 14
2
0 0 32 0
0 4 -1 14
1
end_operator
begin_operator
debark car38 loc23
1
47 15
2
0 0 32 0
0 4 -1 15
1
end_operator
begin_operator
debark car38 loc24
1
47 16
2
0 0 32 0
0 4 -1 16
1
end_operator
begin_operator
debark car38 loc25
1
47 17
2
0 0 32 0
0 4 -1 17
1
end_operator
begin_operator
debark car38 loc26
1
47 18
2
0 0 32 0
0 4 -1 18
1
end_operator
begin_operator
debark car38 loc27
1
47 19
2
0 0 32 0
0 4 -1 19
1
end_operator
begin_operator
debark car38 loc28
1
47 20
2
0 0 32 0
0 4 -1 20
1
end_operator
begin_operator
debark car38 loc29
1
47 21
2
0 0 32 0
0 4 -1 21
1
end_operator
begin_operator
debark car38 loc3
1
47 22
2
0 0 32 0
0 4 -1 22
1
end_operator
begin_operator
debark car38 loc30
1
47 23
2
0 0 32 0
0 4 -1 23
1
end_operator
begin_operator
debark car38 loc31
1
47 24
2
0 0 32 0
0 4 -1 24
1
end_operator
begin_operator
debark car38 loc32
1
47 25
2
0 0 32 0
0 4 -1 25
1
end_operator
begin_operator
debark car38 loc4
1
47 26
2
0 0 32 0
0 4 -1 26
1
end_operator
begin_operator
debark car38 loc5
1
47 27
2
0 0 32 0
0 4 -1 27
1
end_operator
begin_operator
debark car38 loc6
1
47 28
2
0 0 32 0
0 4 -1 28
1
end_operator
begin_operator
debark car38 loc7
1
47 29
2
0 0 32 0
0 4 -1 29
1
end_operator
begin_operator
debark car38 loc8
1
47 30
2
0 0 32 0
0 4 -1 30
1
end_operator
begin_operator
debark car38 loc9
1
47 31
2
0 0 32 0
0 4 -1 31
1
end_operator
begin_operator
debark car39 loc1
1
47 0
2
0 0 33 0
0 10 -1 0
1
end_operator
begin_operator
debark car39 loc10
1
47 1
2
0 0 33 0
0 10 -1 1
1
end_operator
begin_operator
debark car39 loc11
1
47 2
2
0 0 33 0
0 10 -1 2
1
end_operator
begin_operator
debark car39 loc12
1
47 3
2
0 0 33 0
0 10 -1 3
1
end_operator
begin_operator
debark car39 loc13
1
47 4
2
0 0 33 0
0 10 -1 4
1
end_operator
begin_operator
debark car39 loc14
1
47 5
2
0 0 33 0
0 10 -1 5
1
end_operator
begin_operator
debark car39 loc15
1
47 6
2
0 0 33 0
0 10 -1 6
1
end_operator
begin_operator
debark car39 loc16
1
47 7
2
0 0 33 0
0 10 -1 7
1
end_operator
begin_operator
debark car39 loc17
1
47 8
2
0 0 33 0
0 10 -1 8
1
end_operator
begin_operator
debark car39 loc18
1
47 9
2
0 0 33 0
0 10 -1 9
1
end_operator
begin_operator
debark car39 loc19
1
47 10
2
0 0 33 0
0 10 -1 10
1
end_operator
begin_operator
debark car39 loc2
1
47 11
2
0 0 33 0
0 10 -1 11
1
end_operator
begin_operator
debark car39 loc20
1
47 12
2
0 0 33 0
0 10 -1 12
1
end_operator
begin_operator
debark car39 loc21
1
47 13
2
0 0 33 0
0 10 -1 13
1
end_operator
begin_operator
debark car39 loc22
1
47 14
2
0 0 33 0
0 10 -1 14
1
end_operator
begin_operator
debark car39 loc23
1
47 15
2
0 0 33 0
0 10 -1 15
1
end_operator
begin_operator
debark car39 loc24
1
47 16
2
0 0 33 0
0 10 -1 16
1
end_operator
begin_operator
debark car39 loc25
1
47 17
2
0 0 33 0
0 10 -1 17
1
end_operator
begin_operator
debark car39 loc26
1
47 18
2
0 0 33 0
0 10 -1 18
1
end_operator
begin_operator
debark car39 loc27
1
47 19
2
0 0 33 0
0 10 -1 19
1
end_operator
begin_operator
debark car39 loc28
1
47 20
2
0 0 33 0
0 10 -1 20
1
end_operator
begin_operator
debark car39 loc29
1
47 21
2
0 0 33 0
0 10 -1 21
1
end_operator
begin_operator
debark car39 loc3
1
47 22
2
0 0 33 0
0 10 -1 22
1
end_operator
begin_operator
debark car39 loc30
1
47 23
2
0 0 33 0
0 10 -1 23
1
end_operator
begin_operator
debark car39 loc31
1
47 24
2
0 0 33 0
0 10 -1 24
1
end_operator
begin_operator
debark car39 loc32
1
47 25
2
0 0 33 0
0 10 -1 25
1
end_operator
begin_operator
debark car39 loc4
1
47 26
2
0 0 33 0
0 10 -1 26
1
end_operator
begin_operator
debark car39 loc5
1
47 27
2
0 0 33 0
0 10 -1 27
1
end_operator
begin_operator
debark car39 loc6
1
47 28
2
0 0 33 0
0 10 -1 28
1
end_operator
begin_operator
debark car39 loc7
1
47 29
2
0 0 33 0
0 10 -1 29
1
end_operator
begin_operator
debark car39 loc8
1
47 30
2
0 0 33 0
0 10 -1 30
1
end_operator
begin_operator
debark car39 loc9
1
47 31
2
0 0 33 0
0 10 -1 31
1
end_operator
begin_operator
debark car4 loc1
1
47 0
2
0 0 34 0
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
47 1
2
0 0 34 0
0 16 -1 1
1
end_operator
begin_operator
debark car4 loc11
1
47 2
2
0 0 34 0
0 16 -1 2
1
end_operator
begin_operator
debark car4 loc12
1
47 3
2
0 0 34 0
0 16 -1 3
1
end_operator
begin_operator
debark car4 loc13
1
47 4
2
0 0 34 0
0 16 -1 4
1
end_operator
begin_operator
debark car4 loc14
1
47 5
2
0 0 34 0
0 16 -1 5
1
end_operator
begin_operator
debark car4 loc15
1
47 6
2
0 0 34 0
0 16 -1 6
1
end_operator
begin_operator
debark car4 loc16
1
47 7
2
0 0 34 0
0 16 -1 7
1
end_operator
begin_operator
debark car4 loc17
1
47 8
2
0 0 34 0
0 16 -1 8
1
end_operator
begin_operator
debark car4 loc18
1
47 9
2
0 0 34 0
0 16 -1 9
1
end_operator
begin_operator
debark car4 loc19
1
47 10
2
0 0 34 0
0 16 -1 10
1
end_operator
begin_operator
debark car4 loc2
1
47 11
2
0 0 34 0
0 16 -1 11
1
end_operator
begin_operator
debark car4 loc20
1
47 12
2
0 0 34 0
0 16 -1 12
1
end_operator
begin_operator
debark car4 loc21
1
47 13
2
0 0 34 0
0 16 -1 13
1
end_operator
begin_operator
debark car4 loc22
1
47 14
2
0 0 34 0
0 16 -1 14
1
end_operator
begin_operator
debark car4 loc23
1
47 15
2
0 0 34 0
0 16 -1 15
1
end_operator
begin_operator
debark car4 loc24
1
47 16
2
0 0 34 0
0 16 -1 16
1
end_operator
begin_operator
debark car4 loc25
1
47 17
2
0 0 34 0
0 16 -1 17
1
end_operator
begin_operator
debark car4 loc26
1
47 18
2
0 0 34 0
0 16 -1 18
1
end_operator
begin_operator
debark car4 loc27
1
47 19
2
0 0 34 0
0 16 -1 19
1
end_operator
begin_operator
debark car4 loc28
1
47 20
2
0 0 34 0
0 16 -1 20
1
end_operator
begin_operator
debark car4 loc29
1
47 21
2
0 0 34 0
0 16 -1 21
1
end_operator
begin_operator
debark car4 loc3
1
47 22
2
0 0 34 0
0 16 -1 22
1
end_operator
begin_operator
debark car4 loc30
1
47 23
2
0 0 34 0
0 16 -1 23
1
end_operator
begin_operator
debark car4 loc31
1
47 24
2
0 0 34 0
0 16 -1 24
1
end_operator
begin_operator
debark car4 loc32
1
47 25
2
0 0 34 0
0 16 -1 25
1
end_operator
begin_operator
debark car4 loc4
1
47 26
2
0 0 34 0
0 16 -1 26
1
end_operator
begin_operator
debark car4 loc5
1
47 27
2
0 0 34 0
0 16 -1 27
1
end_operator
begin_operator
debark car4 loc6
1
47 28
2
0 0 34 0
0 16 -1 28
1
end_operator
begin_operator
debark car4 loc7
1
47 29
2
0 0 34 0
0 16 -1 29
1
end_operator
begin_operator
debark car4 loc8
1
47 30
2
0 0 34 0
0 16 -1 30
1
end_operator
begin_operator
debark car4 loc9
1
47 31
2
0 0 34 0
0 16 -1 31
1
end_operator
begin_operator
debark car40 loc1
1
47 0
2
0 0 35 0
0 22 -1 0
1
end_operator
begin_operator
debark car40 loc10
1
47 1
2
0 0 35 0
0 22 -1 1
1
end_operator
begin_operator
debark car40 loc11
1
47 2
2
0 0 35 0
0 22 -1 2
1
end_operator
begin_operator
debark car40 loc12
1
47 3
2
0 0 35 0
0 22 -1 3
1
end_operator
begin_operator
debark car40 loc13
1
47 4
2
0 0 35 0
0 22 -1 4
1
end_operator
begin_operator
debark car40 loc14
1
47 5
2
0 0 35 0
0 22 -1 5
1
end_operator
begin_operator
debark car40 loc15
1
47 6
2
0 0 35 0
0 22 -1 6
1
end_operator
begin_operator
debark car40 loc16
1
47 7
2
0 0 35 0
0 22 -1 7
1
end_operator
begin_operator
debark car40 loc17
1
47 8
2
0 0 35 0
0 22 -1 8
1
end_operator
begin_operator
debark car40 loc18
1
47 9
2
0 0 35 0
0 22 -1 9
1
end_operator
begin_operator
debark car40 loc19
1
47 10
2
0 0 35 0
0 22 -1 10
1
end_operator
begin_operator
debark car40 loc2
1
47 11
2
0 0 35 0
0 22 -1 11
1
end_operator
begin_operator
debark car40 loc20
1
47 12
2
0 0 35 0
0 22 -1 12
1
end_operator
begin_operator
debark car40 loc21
1
47 13
2
0 0 35 0
0 22 -1 13
1
end_operator
begin_operator
debark car40 loc22
1
47 14
2
0 0 35 0
0 22 -1 14
1
end_operator
begin_operator
debark car40 loc23
1
47 15
2
0 0 35 0
0 22 -1 15
1
end_operator
begin_operator
debark car40 loc24
1
47 16
2
0 0 35 0
0 22 -1 16
1
end_operator
begin_operator
debark car40 loc25
1
47 17
2
0 0 35 0
0 22 -1 17
1
end_operator
begin_operator
debark car40 loc26
1
47 18
2
0 0 35 0
0 22 -1 18
1
end_operator
begin_operator
debark car40 loc27
1
47 19
2
0 0 35 0
0 22 -1 19
1
end_operator
begin_operator
debark car40 loc28
1
47 20
2
0 0 35 0
0 22 -1 20
1
end_operator
begin_operator
debark car40 loc29
1
47 21
2
0 0 35 0
0 22 -1 21
1
end_operator
begin_operator
debark car40 loc3
1
47 22
2
0 0 35 0
0 22 -1 22
1
end_operator
begin_operator
debark car40 loc30
1
47 23
2
0 0 35 0
0 22 -1 23
1
end_operator
begin_operator
debark car40 loc31
1
47 24
2
0 0 35 0
0 22 -1 24
1
end_operator
begin_operator
debark car40 loc32
1
47 25
2
0 0 35 0
0 22 -1 25
1
end_operator
begin_operator
debark car40 loc4
1
47 26
2
0 0 35 0
0 22 -1 26
1
end_operator
begin_operator
debark car40 loc5
1
47 27
2
0 0 35 0
0 22 -1 27
1
end_operator
begin_operator
debark car40 loc6
1
47 28
2
0 0 35 0
0 22 -1 28
1
end_operator
begin_operator
debark car40 loc7
1
47 29
2
0 0 35 0
0 22 -1 29
1
end_operator
begin_operator
debark car40 loc8
1
47 30
2
0 0 35 0
0 22 -1 30
1
end_operator
begin_operator
debark car40 loc9
1
47 31
2
0 0 35 0
0 22 -1 31
1
end_operator
begin_operator
debark car41 loc1
1
47 0
2
0 0 36 0
0 28 -1 0
1
end_operator
begin_operator
debark car41 loc10
1
47 1
2
0 0 36 0
0 28 -1 1
1
end_operator
begin_operator
debark car41 loc11
1
47 2
2
0 0 36 0
0 28 -1 2
1
end_operator
begin_operator
debark car41 loc12
1
47 3
2
0 0 36 0
0 28 -1 3
1
end_operator
begin_operator
debark car41 loc13
1
47 4
2
0 0 36 0
0 28 -1 4
1
end_operator
begin_operator
debark car41 loc14
1
47 5
2
0 0 36 0
0 28 -1 5
1
end_operator
begin_operator
debark car41 loc15
1
47 6
2
0 0 36 0
0 28 -1 6
1
end_operator
begin_operator
debark car41 loc16
1
47 7
2
0 0 36 0
0 28 -1 7
1
end_operator
begin_operator
debark car41 loc17
1
47 8
2
0 0 36 0
0 28 -1 8
1
end_operator
begin_operator
debark car41 loc18
1
47 9
2
0 0 36 0
0 28 -1 9
1
end_operator
begin_operator
debark car41 loc19
1
47 10
2
0 0 36 0
0 28 -1 10
1
end_operator
begin_operator
debark car41 loc2
1
47 11
2
0 0 36 0
0 28 -1 11
1
end_operator
begin_operator
debark car41 loc20
1
47 12
2
0 0 36 0
0 28 -1 12
1
end_operator
begin_operator
debark car41 loc21
1
47 13
2
0 0 36 0
0 28 -1 13
1
end_operator
begin_operator
debark car41 loc22
1
47 14
2
0 0 36 0
0 28 -1 14
1
end_operator
begin_operator
debark car41 loc23
1
47 15
2
0 0 36 0
0 28 -1 15
1
end_operator
begin_operator
debark car41 loc24
1
47 16
2
0 0 36 0
0 28 -1 16
1
end_operator
begin_operator
debark car41 loc25
1
47 17
2
0 0 36 0
0 28 -1 17
1
end_operator
begin_operator
debark car41 loc26
1
47 18
2
0 0 36 0
0 28 -1 18
1
end_operator
begin_operator
debark car41 loc27
1
47 19
2
0 0 36 0
0 28 -1 19
1
end_operator
begin_operator
debark car41 loc28
1
47 20
2
0 0 36 0
0 28 -1 20
1
end_operator
begin_operator
debark car41 loc29
1
47 21
2
0 0 36 0
0 28 -1 21
1
end_operator
begin_operator
debark car41 loc3
1
47 22
2
0 0 36 0
0 28 -1 22
1
end_operator
begin_operator
debark car41 loc30
1
47 23
2
0 0 36 0
0 28 -1 23
1
end_operator
begin_operator
debark car41 loc31
1
47 24
2
0 0 36 0
0 28 -1 24
1
end_operator
begin_operator
debark car41 loc32
1
47 25
2
0 0 36 0
0 28 -1 25
1
end_operator
begin_operator
debark car41 loc4
1
47 26
2
0 0 36 0
0 28 -1 26
1
end_operator
begin_operator
debark car41 loc5
1
47 27
2
0 0 36 0
0 28 -1 27
1
end_operator
begin_operator
debark car41 loc6
1
47 28
2
0 0 36 0
0 28 -1 28
1
end_operator
begin_operator
debark car41 loc7
1
47 29
2
0 0 36 0
0 28 -1 29
1
end_operator
begin_operator
debark car41 loc8
1
47 30
2
0 0 36 0
0 28 -1 30
1
end_operator
begin_operator
debark car41 loc9
1
47 31
2
0 0 36 0
0 28 -1 31
1
end_operator
begin_operator
debark car42 loc1
1
47 0
2
0 0 37 0
0 34 -1 0
1
end_operator
begin_operator
debark car42 loc10
1
47 1
2
0 0 37 0
0 34 -1 1
1
end_operator
begin_operator
debark car42 loc11
1
47 2
2
0 0 37 0
0 34 -1 2
1
end_operator
begin_operator
debark car42 loc12
1
47 3
2
0 0 37 0
0 34 -1 3
1
end_operator
begin_operator
debark car42 loc13
1
47 4
2
0 0 37 0
0 34 -1 4
1
end_operator
begin_operator
debark car42 loc14
1
47 5
2
0 0 37 0
0 34 -1 5
1
end_operator
begin_operator
debark car42 loc15
1
47 6
2
0 0 37 0
0 34 -1 6
1
end_operator
begin_operator
debark car42 loc16
1
47 7
2
0 0 37 0
0 34 -1 7
1
end_operator
begin_operator
debark car42 loc17
1
47 8
2
0 0 37 0
0 34 -1 8
1
end_operator
begin_operator
debark car42 loc18
1
47 9
2
0 0 37 0
0 34 -1 9
1
end_operator
begin_operator
debark car42 loc19
1
47 10
2
0 0 37 0
0 34 -1 10
1
end_operator
begin_operator
debark car42 loc2
1
47 11
2
0 0 37 0
0 34 -1 11
1
end_operator
begin_operator
debark car42 loc20
1
47 12
2
0 0 37 0
0 34 -1 12
1
end_operator
begin_operator
debark car42 loc21
1
47 13
2
0 0 37 0
0 34 -1 13
1
end_operator
begin_operator
debark car42 loc22
1
47 14
2
0 0 37 0
0 34 -1 14
1
end_operator
begin_operator
debark car42 loc23
1
47 15
2
0 0 37 0
0 34 -1 15
1
end_operator
begin_operator
debark car42 loc24
1
47 16
2
0 0 37 0
0 34 -1 16
1
end_operator
begin_operator
debark car42 loc25
1
47 17
2
0 0 37 0
0 34 -1 17
1
end_operator
begin_operator
debark car42 loc26
1
47 18
2
0 0 37 0
0 34 -1 18
1
end_operator
begin_operator
debark car42 loc27
1
47 19
2
0 0 37 0
0 34 -1 19
1
end_operator
begin_operator
debark car42 loc28
1
47 20
2
0 0 37 0
0 34 -1 20
1
end_operator
begin_operator
debark car42 loc29
1
47 21
2
0 0 37 0
0 34 -1 21
1
end_operator
begin_operator
debark car42 loc3
1
47 22
2
0 0 37 0
0 34 -1 22
1
end_operator
begin_operator
debark car42 loc30
1
47 23
2
0 0 37 0
0 34 -1 23
1
end_operator
begin_operator
debark car42 loc31
1
47 24
2
0 0 37 0
0 34 -1 24
1
end_operator
begin_operator
debark car42 loc32
1
47 25
2
0 0 37 0
0 34 -1 25
1
end_operator
begin_operator
debark car42 loc4
1
47 26
2
0 0 37 0
0 34 -1 26
1
end_operator
begin_operator
debark car42 loc5
1
47 27
2
0 0 37 0
0 34 -1 27
1
end_operator
begin_operator
debark car42 loc6
1
47 28
2
0 0 37 0
0 34 -1 28
1
end_operator
begin_operator
debark car42 loc7
1
47 29
2
0 0 37 0
0 34 -1 29
1
end_operator
begin_operator
debark car42 loc8
1
47 30
2
0 0 37 0
0 34 -1 30
1
end_operator
begin_operator
debark car42 loc9
1
47 31
2
0 0 37 0
0 34 -1 31
1
end_operator
begin_operator
debark car43 loc1
1
47 0
2
0 0 38 0
0 40 -1 0
1
end_operator
begin_operator
debark car43 loc10
1
47 1
2
0 0 38 0
0 40 -1 1
1
end_operator
begin_operator
debark car43 loc11
1
47 2
2
0 0 38 0
0 40 -1 2
1
end_operator
begin_operator
debark car43 loc12
1
47 3
2
0 0 38 0
0 40 -1 3
1
end_operator
begin_operator
debark car43 loc13
1
47 4
2
0 0 38 0
0 40 -1 4
1
end_operator
begin_operator
debark car43 loc14
1
47 5
2
0 0 38 0
0 40 -1 5
1
end_operator
begin_operator
debark car43 loc15
1
47 6
2
0 0 38 0
0 40 -1 6
1
end_operator
begin_operator
debark car43 loc16
1
47 7
2
0 0 38 0
0 40 -1 7
1
end_operator
begin_operator
debark car43 loc17
1
47 8
2
0 0 38 0
0 40 -1 8
1
end_operator
begin_operator
debark car43 loc18
1
47 9
2
0 0 38 0
0 40 -1 9
1
end_operator
begin_operator
debark car43 loc19
1
47 10
2
0 0 38 0
0 40 -1 10
1
end_operator
begin_operator
debark car43 loc2
1
47 11
2
0 0 38 0
0 40 -1 11
1
end_operator
begin_operator
debark car43 loc20
1
47 12
2
0 0 38 0
0 40 -1 12
1
end_operator
begin_operator
debark car43 loc21
1
47 13
2
0 0 38 0
0 40 -1 13
1
end_operator
begin_operator
debark car43 loc22
1
47 14
2
0 0 38 0
0 40 -1 14
1
end_operator
begin_operator
debark car43 loc23
1
47 15
2
0 0 38 0
0 40 -1 15
1
end_operator
begin_operator
debark car43 loc24
1
47 16
2
0 0 38 0
0 40 -1 16
1
end_operator
begin_operator
debark car43 loc25
1
47 17
2
0 0 38 0
0 40 -1 17
1
end_operator
begin_operator
debark car43 loc26
1
47 18
2
0 0 38 0
0 40 -1 18
1
end_operator
begin_operator
debark car43 loc27
1
47 19
2
0 0 38 0
0 40 -1 19
1
end_operator
begin_operator
debark car43 loc28
1
47 20
2
0 0 38 0
0 40 -1 20
1
end_operator
begin_operator
debark car43 loc29
1
47 21
2
0 0 38 0
0 40 -1 21
1
end_operator
begin_operator
debark car43 loc3
1
47 22
2
0 0 38 0
0 40 -1 22
1
end_operator
begin_operator
debark car43 loc30
1
47 23
2
0 0 38 0
0 40 -1 23
1
end_operator
begin_operator
debark car43 loc31
1
47 24
2
0 0 38 0
0 40 -1 24
1
end_operator
begin_operator
debark car43 loc32
1
47 25
2
0 0 38 0
0 40 -1 25
1
end_operator
begin_operator
debark car43 loc4
1
47 26
2
0 0 38 0
0 40 -1 26
1
end_operator
begin_operator
debark car43 loc5
1
47 27
2
0 0 38 0
0 40 -1 27
1
end_operator
begin_operator
debark car43 loc6
1
47 28
2
0 0 38 0
0 40 -1 28
1
end_operator
begin_operator
debark car43 loc7
1
47 29
2
0 0 38 0
0 40 -1 29
1
end_operator
begin_operator
debark car43 loc8
1
47 30
2
0 0 38 0
0 40 -1 30
1
end_operator
begin_operator
debark car43 loc9
1
47 31
2
0 0 38 0
0 40 -1 31
1
end_operator
begin_operator
debark car44 loc1
1
47 0
2
0 0 39 0
0 46 -1 0
1
end_operator
begin_operator
debark car44 loc10
1
47 1
2
0 0 39 0
0 46 -1 1
1
end_operator
begin_operator
debark car44 loc11
1
47 2
2
0 0 39 0
0 46 -1 2
1
end_operator
begin_operator
debark car44 loc12
1
47 3
2
0 0 39 0
0 46 -1 3
1
end_operator
begin_operator
debark car44 loc13
1
47 4
2
0 0 39 0
0 46 -1 4
1
end_operator
begin_operator
debark car44 loc14
1
47 5
2
0 0 39 0
0 46 -1 5
1
end_operator
begin_operator
debark car44 loc15
1
47 6
2
0 0 39 0
0 46 -1 6
1
end_operator
begin_operator
debark car44 loc16
1
47 7
2
0 0 39 0
0 46 -1 7
1
end_operator
begin_operator
debark car44 loc17
1
47 8
2
0 0 39 0
0 46 -1 8
1
end_operator
begin_operator
debark car44 loc18
1
47 9
2
0 0 39 0
0 46 -1 9
1
end_operator
begin_operator
debark car44 loc19
1
47 10
2
0 0 39 0
0 46 -1 10
1
end_operator
begin_operator
debark car44 loc2
1
47 11
2
0 0 39 0
0 46 -1 11
1
end_operator
begin_operator
debark car44 loc20
1
47 12
2
0 0 39 0
0 46 -1 12
1
end_operator
begin_operator
debark car44 loc21
1
47 13
2
0 0 39 0
0 46 -1 13
1
end_operator
begin_operator
debark car44 loc22
1
47 14
2
0 0 39 0
0 46 -1 14
1
end_operator
begin_operator
debark car44 loc23
1
47 15
2
0 0 39 0
0 46 -1 15
1
end_operator
begin_operator
debark car44 loc24
1
47 16
2
0 0 39 0
0 46 -1 16
1
end_operator
begin_operator
debark car44 loc25
1
47 17
2
0 0 39 0
0 46 -1 17
1
end_operator
begin_operator
debark car44 loc26
1
47 18
2
0 0 39 0
0 46 -1 18
1
end_operator
begin_operator
debark car44 loc27
1
47 19
2
0 0 39 0
0 46 -1 19
1
end_operator
begin_operator
debark car44 loc28
1
47 20
2
0 0 39 0
0 46 -1 20
1
end_operator
begin_operator
debark car44 loc29
1
47 21
2
0 0 39 0
0 46 -1 21
1
end_operator
begin_operator
debark car44 loc3
1
47 22
2
0 0 39 0
0 46 -1 22
1
end_operator
begin_operator
debark car44 loc30
1
47 23
2
0 0 39 0
0 46 -1 23
1
end_operator
begin_operator
debark car44 loc31
1
47 24
2
0 0 39 0
0 46 -1 24
1
end_operator
begin_operator
debark car44 loc32
1
47 25
2
0 0 39 0
0 46 -1 25
1
end_operator
begin_operator
debark car44 loc4
1
47 26
2
0 0 39 0
0 46 -1 26
1
end_operator
begin_operator
debark car44 loc5
1
47 27
2
0 0 39 0
0 46 -1 27
1
end_operator
begin_operator
debark car44 loc6
1
47 28
2
0 0 39 0
0 46 -1 28
1
end_operator
begin_operator
debark car44 loc7
1
47 29
2
0 0 39 0
0 46 -1 29
1
end_operator
begin_operator
debark car44 loc8
1
47 30
2
0 0 39 0
0 46 -1 30
1
end_operator
begin_operator
debark car44 loc9
1
47 31
2
0 0 39 0
0 46 -1 31
1
end_operator
begin_operator
debark car45 loc1
1
47 0
2
0 0 40 0
0 5 -1 0
1
end_operator
begin_operator
debark car45 loc10
1
47 1
2
0 0 40 0
0 5 -1 1
1
end_operator
begin_operator
debark car45 loc11
1
47 2
2
0 0 40 0
0 5 -1 2
1
end_operator
begin_operator
debark car45 loc12
1
47 3
2
0 0 40 0
0 5 -1 3
1
end_operator
begin_operator
debark car45 loc13
1
47 4
2
0 0 40 0
0 5 -1 4
1
end_operator
begin_operator
debark car45 loc14
1
47 5
2
0 0 40 0
0 5 -1 5
1
end_operator
begin_operator
debark car45 loc15
1
47 6
2
0 0 40 0
0 5 -1 6
1
end_operator
begin_operator
debark car45 loc16
1
47 7
2
0 0 40 0
0 5 -1 7
1
end_operator
begin_operator
debark car45 loc17
1
47 8
2
0 0 40 0
0 5 -1 8
1
end_operator
begin_operator
debark car45 loc18
1
47 9
2
0 0 40 0
0 5 -1 9
1
end_operator
begin_operator
debark car45 loc19
1
47 10
2
0 0 40 0
0 5 -1 10
1
end_operator
begin_operator
debark car45 loc2
1
47 11
2
0 0 40 0
0 5 -1 11
1
end_operator
begin_operator
debark car45 loc20
1
47 12
2
0 0 40 0
0 5 -1 12
1
end_operator
begin_operator
debark car45 loc21
1
47 13
2
0 0 40 0
0 5 -1 13
1
end_operator
begin_operator
debark car45 loc22
1
47 14
2
0 0 40 0
0 5 -1 14
1
end_operator
begin_operator
debark car45 loc23
1
47 15
2
0 0 40 0
0 5 -1 15
1
end_operator
begin_operator
debark car45 loc24
1
47 16
2
0 0 40 0
0 5 -1 16
1
end_operator
begin_operator
debark car45 loc25
1
47 17
2
0 0 40 0
0 5 -1 17
1
end_operator
begin_operator
debark car45 loc26
1
47 18
2
0 0 40 0
0 5 -1 18
1
end_operator
begin_operator
debark car45 loc27
1
47 19
2
0 0 40 0
0 5 -1 19
1
end_operator
begin_operator
debark car45 loc28
1
47 20
2
0 0 40 0
0 5 -1 20
1
end_operator
begin_operator
debark car45 loc29
1
47 21
2
0 0 40 0
0 5 -1 21
1
end_operator
begin_operator
debark car45 loc3
1
47 22
2
0 0 40 0
0 5 -1 22
1
end_operator
begin_operator
debark car45 loc30
1
47 23
2
0 0 40 0
0 5 -1 23
1
end_operator
begin_operator
debark car45 loc31
1
47 24
2
0 0 40 0
0 5 -1 24
1
end_operator
begin_operator
debark car45 loc32
1
47 25
2
0 0 40 0
0 5 -1 25
1
end_operator
begin_operator
debark car45 loc4
1
47 26
2
0 0 40 0
0 5 -1 26
1
end_operator
begin_operator
debark car45 loc5
1
47 27
2
0 0 40 0
0 5 -1 27
1
end_operator
begin_operator
debark car45 loc6
1
47 28
2
0 0 40 0
0 5 -1 28
1
end_operator
begin_operator
debark car45 loc7
1
47 29
2
0 0 40 0
0 5 -1 29
1
end_operator
begin_operator
debark car45 loc8
1
47 30
2
0 0 40 0
0 5 -1 30
1
end_operator
begin_operator
debark car45 loc9
1
47 31
2
0 0 40 0
0 5 -1 31
1
end_operator
begin_operator
debark car46 loc1
1
47 0
2
0 0 41 0
0 11 -1 0
1
end_operator
begin_operator
debark car46 loc10
1
47 1
2
0 0 41 0
0 11 -1 1
1
end_operator
begin_operator
debark car46 loc11
1
47 2
2
0 0 41 0
0 11 -1 2
1
end_operator
begin_operator
debark car46 loc12
1
47 3
2
0 0 41 0
0 11 -1 3
1
end_operator
begin_operator
debark car46 loc13
1
47 4
2
0 0 41 0
0 11 -1 4
1
end_operator
begin_operator
debark car46 loc14
1
47 5
2
0 0 41 0
0 11 -1 5
1
end_operator
begin_operator
debark car46 loc15
1
47 6
2
0 0 41 0
0 11 -1 6
1
end_operator
begin_operator
debark car46 loc16
1
47 7
2
0 0 41 0
0 11 -1 7
1
end_operator
begin_operator
debark car46 loc17
1
47 8
2
0 0 41 0
0 11 -1 8
1
end_operator
begin_operator
debark car46 loc18
1
47 9
2
0 0 41 0
0 11 -1 9
1
end_operator
begin_operator
debark car46 loc19
1
47 10
2
0 0 41 0
0 11 -1 10
1
end_operator
begin_operator
debark car46 loc2
1
47 11
2
0 0 41 0
0 11 -1 11
1
end_operator
begin_operator
debark car46 loc20
1
47 12
2
0 0 41 0
0 11 -1 12
1
end_operator
begin_operator
debark car46 loc21
1
47 13
2
0 0 41 0
0 11 -1 13
1
end_operator
begin_operator
debark car46 loc22
1
47 14
2
0 0 41 0
0 11 -1 14
1
end_operator
begin_operator
debark car46 loc23
1
47 15
2
0 0 41 0
0 11 -1 15
1
end_operator
begin_operator
debark car46 loc24
1
47 16
2
0 0 41 0
0 11 -1 16
1
end_operator
begin_operator
debark car46 loc25
1
47 17
2
0 0 41 0
0 11 -1 17
1
end_operator
begin_operator
debark car46 loc26
1
47 18
2
0 0 41 0
0 11 -1 18
1
end_operator
begin_operator
debark car46 loc27
1
47 19
2
0 0 41 0
0 11 -1 19
1
end_operator
begin_operator
debark car46 loc28
1
47 20
2
0 0 41 0
0 11 -1 20
1
end_operator
begin_operator
debark car46 loc29
1
47 21
2
0 0 41 0
0 11 -1 21
1
end_operator
begin_operator
debark car46 loc3
1
47 22
2
0 0 41 0
0 11 -1 22
1
end_operator
begin_operator
debark car46 loc30
1
47 23
2
0 0 41 0
0 11 -1 23
1
end_operator
begin_operator
debark car46 loc31
1
47 24
2
0 0 41 0
0 11 -1 24
1
end_operator
begin_operator
debark car46 loc32
1
47 25
2
0 0 41 0
0 11 -1 25
1
end_operator
begin_operator
debark car46 loc4
1
47 26
2
0 0 41 0
0 11 -1 26
1
end_operator
begin_operator
debark car46 loc5
1
47 27
2
0 0 41 0
0 11 -1 27
1
end_operator
begin_operator
debark car46 loc6
1
47 28
2
0 0 41 0
0 11 -1 28
1
end_operator
begin_operator
debark car46 loc7
1
47 29
2
0 0 41 0
0 11 -1 29
1
end_operator
begin_operator
debark car46 loc8
1
47 30
2
0 0 41 0
0 11 -1 30
1
end_operator
begin_operator
debark car46 loc9
1
47 31
2
0 0 41 0
0 11 -1 31
1
end_operator
begin_operator
debark car5 loc1
1
47 0
2
0 0 42 0
0 17 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
47 1
2
0 0 42 0
0 17 -1 1
1
end_operator
begin_operator
debark car5 loc11
1
47 2
2
0 0 42 0
0 17 -1 2
1
end_operator
begin_operator
debark car5 loc12
1
47 3
2
0 0 42 0
0 17 -1 3
1
end_operator
begin_operator
debark car5 loc13
1
47 4
2
0 0 42 0
0 17 -1 4
1
end_operator
begin_operator
debark car5 loc14
1
47 5
2
0 0 42 0
0 17 -1 5
1
end_operator
begin_operator
debark car5 loc15
1
47 6
2
0 0 42 0
0 17 -1 6
1
end_operator
begin_operator
debark car5 loc16
1
47 7
2
0 0 42 0
0 17 -1 7
1
end_operator
begin_operator
debark car5 loc17
1
47 8
2
0 0 42 0
0 17 -1 8
1
end_operator
begin_operator
debark car5 loc18
1
47 9
2
0 0 42 0
0 17 -1 9
1
end_operator
begin_operator
debark car5 loc19
1
47 10
2
0 0 42 0
0 17 -1 10
1
end_operator
begin_operator
debark car5 loc2
1
47 11
2
0 0 42 0
0 17 -1 11
1
end_operator
begin_operator
debark car5 loc20
1
47 12
2
0 0 42 0
0 17 -1 12
1
end_operator
begin_operator
debark car5 loc21
1
47 13
2
0 0 42 0
0 17 -1 13
1
end_operator
begin_operator
debark car5 loc22
1
47 14
2
0 0 42 0
0 17 -1 14
1
end_operator
begin_operator
debark car5 loc23
1
47 15
2
0 0 42 0
0 17 -1 15
1
end_operator
begin_operator
debark car5 loc24
1
47 16
2
0 0 42 0
0 17 -1 16
1
end_operator
begin_operator
debark car5 loc25
1
47 17
2
0 0 42 0
0 17 -1 17
1
end_operator
begin_operator
debark car5 loc26
1
47 18
2
0 0 42 0
0 17 -1 18
1
end_operator
begin_operator
debark car5 loc27
1
47 19
2
0 0 42 0
0 17 -1 19
1
end_operator
begin_operator
debark car5 loc28
1
47 20
2
0 0 42 0
0 17 -1 20
1
end_operator
begin_operator
debark car5 loc29
1
47 21
2
0 0 42 0
0 17 -1 21
1
end_operator
begin_operator
debark car5 loc3
1
47 22
2
0 0 42 0
0 17 -1 22
1
end_operator
begin_operator
debark car5 loc30
1
47 23
2
0 0 42 0
0 17 -1 23
1
end_operator
begin_operator
debark car5 loc31
1
47 24
2
0 0 42 0
0 17 -1 24
1
end_operator
begin_operator
debark car5 loc32
1
47 25
2
0 0 42 0
0 17 -1 25
1
end_operator
begin_operator
debark car5 loc4
1
47 26
2
0 0 42 0
0 17 -1 26
1
end_operator
begin_operator
debark car5 loc5
1
47 27
2
0 0 42 0
0 17 -1 27
1
end_operator
begin_operator
debark car5 loc6
1
47 28
2
0 0 42 0
0 17 -1 28
1
end_operator
begin_operator
debark car5 loc7
1
47 29
2
0 0 42 0
0 17 -1 29
1
end_operator
begin_operator
debark car5 loc8
1
47 30
2
0 0 42 0
0 17 -1 30
1
end_operator
begin_operator
debark car5 loc9
1
47 31
2
0 0 42 0
0 17 -1 31
1
end_operator
begin_operator
debark car6 loc1
1
47 0
2
0 0 43 0
0 23 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
47 1
2
0 0 43 0
0 23 -1 1
1
end_operator
begin_operator
debark car6 loc11
1
47 2
2
0 0 43 0
0 23 -1 2
1
end_operator
begin_operator
debark car6 loc12
1
47 3
2
0 0 43 0
0 23 -1 3
1
end_operator
begin_operator
debark car6 loc13
1
47 4
2
0 0 43 0
0 23 -1 4
1
end_operator
begin_operator
debark car6 loc14
1
47 5
2
0 0 43 0
0 23 -1 5
1
end_operator
begin_operator
debark car6 loc15
1
47 6
2
0 0 43 0
0 23 -1 6
1
end_operator
begin_operator
debark car6 loc16
1
47 7
2
0 0 43 0
0 23 -1 7
1
end_operator
begin_operator
debark car6 loc17
1
47 8
2
0 0 43 0
0 23 -1 8
1
end_operator
begin_operator
debark car6 loc18
1
47 9
2
0 0 43 0
0 23 -1 9
1
end_operator
begin_operator
debark car6 loc19
1
47 10
2
0 0 43 0
0 23 -1 10
1
end_operator
begin_operator
debark car6 loc2
1
47 11
2
0 0 43 0
0 23 -1 11
1
end_operator
begin_operator
debark car6 loc20
1
47 12
2
0 0 43 0
0 23 -1 12
1
end_operator
begin_operator
debark car6 loc21
1
47 13
2
0 0 43 0
0 23 -1 13
1
end_operator
begin_operator
debark car6 loc22
1
47 14
2
0 0 43 0
0 23 -1 14
1
end_operator
begin_operator
debark car6 loc23
1
47 15
2
0 0 43 0
0 23 -1 15
1
end_operator
begin_operator
debark car6 loc24
1
47 16
2
0 0 43 0
0 23 -1 16
1
end_operator
begin_operator
debark car6 loc25
1
47 17
2
0 0 43 0
0 23 -1 17
1
end_operator
begin_operator
debark car6 loc26
1
47 18
2
0 0 43 0
0 23 -1 18
1
end_operator
begin_operator
debark car6 loc27
1
47 19
2
0 0 43 0
0 23 -1 19
1
end_operator
begin_operator
debark car6 loc28
1
47 20
2
0 0 43 0
0 23 -1 20
1
end_operator
begin_operator
debark car6 loc29
1
47 21
2
0 0 43 0
0 23 -1 21
1
end_operator
begin_operator
debark car6 loc3
1
47 22
2
0 0 43 0
0 23 -1 22
1
end_operator
begin_operator
debark car6 loc30
1
47 23
2
0 0 43 0
0 23 -1 23
1
end_operator
begin_operator
debark car6 loc31
1
47 24
2
0 0 43 0
0 23 -1 24
1
end_operator
begin_operator
debark car6 loc32
1
47 25
2
0 0 43 0
0 23 -1 25
1
end_operator
begin_operator
debark car6 loc4
1
47 26
2
0 0 43 0
0 23 -1 26
1
end_operator
begin_operator
debark car6 loc5
1
47 27
2
0 0 43 0
0 23 -1 27
1
end_operator
begin_operator
debark car6 loc6
1
47 28
2
0 0 43 0
0 23 -1 28
1
end_operator
begin_operator
debark car6 loc7
1
47 29
2
0 0 43 0
0 23 -1 29
1
end_operator
begin_operator
debark car6 loc8
1
47 30
2
0 0 43 0
0 23 -1 30
1
end_operator
begin_operator
debark car6 loc9
1
47 31
2
0 0 43 0
0 23 -1 31
1
end_operator
begin_operator
debark car7 loc1
1
47 0
2
0 0 44 0
0 29 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
47 1
2
0 0 44 0
0 29 -1 1
1
end_operator
begin_operator
debark car7 loc11
1
47 2
2
0 0 44 0
0 29 -1 2
1
end_operator
begin_operator
debark car7 loc12
1
47 3
2
0 0 44 0
0 29 -1 3
1
end_operator
begin_operator
debark car7 loc13
1
47 4
2
0 0 44 0
0 29 -1 4
1
end_operator
begin_operator
debark car7 loc14
1
47 5
2
0 0 44 0
0 29 -1 5
1
end_operator
begin_operator
debark car7 loc15
1
47 6
2
0 0 44 0
0 29 -1 6
1
end_operator
begin_operator
debark car7 loc16
1
47 7
2
0 0 44 0
0 29 -1 7
1
end_operator
begin_operator
debark car7 loc17
1
47 8
2
0 0 44 0
0 29 -1 8
1
end_operator
begin_operator
debark car7 loc18
1
47 9
2
0 0 44 0
0 29 -1 9
1
end_operator
begin_operator
debark car7 loc19
1
47 10
2
0 0 44 0
0 29 -1 10
1
end_operator
begin_operator
debark car7 loc2
1
47 11
2
0 0 44 0
0 29 -1 11
1
end_operator
begin_operator
debark car7 loc20
1
47 12
2
0 0 44 0
0 29 -1 12
1
end_operator
begin_operator
debark car7 loc21
1
47 13
2
0 0 44 0
0 29 -1 13
1
end_operator
begin_operator
debark car7 loc22
1
47 14
2
0 0 44 0
0 29 -1 14
1
end_operator
begin_operator
debark car7 loc23
1
47 15
2
0 0 44 0
0 29 -1 15
1
end_operator
begin_operator
debark car7 loc24
1
47 16
2
0 0 44 0
0 29 -1 16
1
end_operator
begin_operator
debark car7 loc25
1
47 17
2
0 0 44 0
0 29 -1 17
1
end_operator
begin_operator
debark car7 loc26
1
47 18
2
0 0 44 0
0 29 -1 18
1
end_operator
begin_operator
debark car7 loc27
1
47 19
2
0 0 44 0
0 29 -1 19
1
end_operator
begin_operator
debark car7 loc28
1
47 20
2
0 0 44 0
0 29 -1 20
1
end_operator
begin_operator
debark car7 loc29
1
47 21
2
0 0 44 0
0 29 -1 21
1
end_operator
begin_operator
debark car7 loc3
1
47 22
2
0 0 44 0
0 29 -1 22
1
end_operator
begin_operator
debark car7 loc30
1
47 23
2
0 0 44 0
0 29 -1 23
1
end_operator
begin_operator
debark car7 loc31
1
47 24
2
0 0 44 0
0 29 -1 24
1
end_operator
begin_operator
debark car7 loc32
1
47 25
2
0 0 44 0
0 29 -1 25
1
end_operator
begin_operator
debark car7 loc4
1
47 26
2
0 0 44 0
0 29 -1 26
1
end_operator
begin_operator
debark car7 loc5
1
47 27
2
0 0 44 0
0 29 -1 27
1
end_operator
begin_operator
debark car7 loc6
1
47 28
2
0 0 44 0
0 29 -1 28
1
end_operator
begin_operator
debark car7 loc7
1
47 29
2
0 0 44 0
0 29 -1 29
1
end_operator
begin_operator
debark car7 loc8
1
47 30
2
0 0 44 0
0 29 -1 30
1
end_operator
begin_operator
debark car7 loc9
1
47 31
2
0 0 44 0
0 29 -1 31
1
end_operator
begin_operator
debark car8 loc1
1
47 0
2
0 0 45 0
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
47 1
2
0 0 45 0
0 35 -1 1
1
end_operator
begin_operator
debark car8 loc11
1
47 2
2
0 0 45 0
0 35 -1 2
1
end_operator
begin_operator
debark car8 loc12
1
47 3
2
0 0 45 0
0 35 -1 3
1
end_operator
begin_operator
debark car8 loc13
1
47 4
2
0 0 45 0
0 35 -1 4
1
end_operator
begin_operator
debark car8 loc14
1
47 5
2
0 0 45 0
0 35 -1 5
1
end_operator
begin_operator
debark car8 loc15
1
47 6
2
0 0 45 0
0 35 -1 6
1
end_operator
begin_operator
debark car8 loc16
1
47 7
2
0 0 45 0
0 35 -1 7
1
end_operator
begin_operator
debark car8 loc17
1
47 8
2
0 0 45 0
0 35 -1 8
1
end_operator
begin_operator
debark car8 loc18
1
47 9
2
0 0 45 0
0 35 -1 9
1
end_operator
begin_operator
debark car8 loc19
1
47 10
2
0 0 45 0
0 35 -1 10
1
end_operator
begin_operator
debark car8 loc2
1
47 11
2
0 0 45 0
0 35 -1 11
1
end_operator
begin_operator
debark car8 loc20
1
47 12
2
0 0 45 0
0 35 -1 12
1
end_operator
begin_operator
debark car8 loc21
1
47 13
2
0 0 45 0
0 35 -1 13
1
end_operator
begin_operator
debark car8 loc22
1
47 14
2
0 0 45 0
0 35 -1 14
1
end_operator
begin_operator
debark car8 loc23
1
47 15
2
0 0 45 0
0 35 -1 15
1
end_operator
begin_operator
debark car8 loc24
1
47 16
2
0 0 45 0
0 35 -1 16
1
end_operator
begin_operator
debark car8 loc25
1
47 17
2
0 0 45 0
0 35 -1 17
1
end_operator
begin_operator
debark car8 loc26
1
47 18
2
0 0 45 0
0 35 -1 18
1
end_operator
begin_operator
debark car8 loc27
1
47 19
2
0 0 45 0
0 35 -1 19
1
end_operator
begin_operator
debark car8 loc28
1
47 20
2
0 0 45 0
0 35 -1 20
1
end_operator
begin_operator
debark car8 loc29
1
47 21
2
0 0 45 0
0 35 -1 21
1
end_operator
begin_operator
debark car8 loc3
1
47 22
2
0 0 45 0
0 35 -1 22
1
end_operator
begin_operator
debark car8 loc30
1
47 23
2
0 0 45 0
0 35 -1 23
1
end_operator
begin_operator
debark car8 loc31
1
47 24
2
0 0 45 0
0 35 -1 24
1
end_operator
begin_operator
debark car8 loc32
1
47 25
2
0 0 45 0
0 35 -1 25
1
end_operator
begin_operator
debark car8 loc4
1
47 26
2
0 0 45 0
0 35 -1 26
1
end_operator
begin_operator
debark car8 loc5
1
47 27
2
0 0 45 0
0 35 -1 27
1
end_operator
begin_operator
debark car8 loc6
1
47 28
2
0 0 45 0
0 35 -1 28
1
end_operator
begin_operator
debark car8 loc7
1
47 29
2
0 0 45 0
0 35 -1 29
1
end_operator
begin_operator
debark car8 loc8
1
47 30
2
0 0 45 0
0 35 -1 30
1
end_operator
begin_operator
debark car8 loc9
1
47 31
2
0 0 45 0
0 35 -1 31
1
end_operator
begin_operator
debark car9 loc1
1
47 0
2
0 0 46 0
0 41 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
47 1
2
0 0 46 0
0 41 -1 1
1
end_operator
begin_operator
debark car9 loc11
1
47 2
2
0 0 46 0
0 41 -1 2
1
end_operator
begin_operator
debark car9 loc12
1
47 3
2
0 0 46 0
0 41 -1 3
1
end_operator
begin_operator
debark car9 loc13
1
47 4
2
0 0 46 0
0 41 -1 4
1
end_operator
begin_operator
debark car9 loc14
1
47 5
2
0 0 46 0
0 41 -1 5
1
end_operator
begin_operator
debark car9 loc15
1
47 6
2
0 0 46 0
0 41 -1 6
1
end_operator
begin_operator
debark car9 loc16
1
47 7
2
0 0 46 0
0 41 -1 7
1
end_operator
begin_operator
debark car9 loc17
1
47 8
2
0 0 46 0
0 41 -1 8
1
end_operator
begin_operator
debark car9 loc18
1
47 9
2
0 0 46 0
0 41 -1 9
1
end_operator
begin_operator
debark car9 loc19
1
47 10
2
0 0 46 0
0 41 -1 10
1
end_operator
begin_operator
debark car9 loc2
1
47 11
2
0 0 46 0
0 41 -1 11
1
end_operator
begin_operator
debark car9 loc20
1
47 12
2
0 0 46 0
0 41 -1 12
1
end_operator
begin_operator
debark car9 loc21
1
47 13
2
0 0 46 0
0 41 -1 13
1
end_operator
begin_operator
debark car9 loc22
1
47 14
2
0 0 46 0
0 41 -1 14
1
end_operator
begin_operator
debark car9 loc23
1
47 15
2
0 0 46 0
0 41 -1 15
1
end_operator
begin_operator
debark car9 loc24
1
47 16
2
0 0 46 0
0 41 -1 16
1
end_operator
begin_operator
debark car9 loc25
1
47 17
2
0 0 46 0
0 41 -1 17
1
end_operator
begin_operator
debark car9 loc26
1
47 18
2
0 0 46 0
0 41 -1 18
1
end_operator
begin_operator
debark car9 loc27
1
47 19
2
0 0 46 0
0 41 -1 19
1
end_operator
begin_operator
debark car9 loc28
1
47 20
2
0 0 46 0
0 41 -1 20
1
end_operator
begin_operator
debark car9 loc29
1
47 21
2
0 0 46 0
0 41 -1 21
1
end_operator
begin_operator
debark car9 loc3
1
47 22
2
0 0 46 0
0 41 -1 22
1
end_operator
begin_operator
debark car9 loc30
1
47 23
2
0 0 46 0
0 41 -1 23
1
end_operator
begin_operator
debark car9 loc31
1
47 24
2
0 0 46 0
0 41 -1 24
1
end_operator
begin_operator
debark car9 loc32
1
47 25
2
0 0 46 0
0 41 -1 25
1
end_operator
begin_operator
debark car9 loc4
1
47 26
2
0 0 46 0
0 41 -1 26
1
end_operator
begin_operator
debark car9 loc5
1
47 27
2
0 0 46 0
0 41 -1 27
1
end_operator
begin_operator
debark car9 loc6
1
47 28
2
0 0 46 0
0 41 -1 28
1
end_operator
begin_operator
debark car9 loc7
1
47 29
2
0 0 46 0
0 41 -1 29
1
end_operator
begin_operator
debark car9 loc8
1
47 30
2
0 0 46 0
0 41 -1 30
1
end_operator
begin_operator
debark car9 loc9
1
47 31
2
0 0 46 0
0 41 -1 31
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 47 0 1
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 47 0 2
0 48 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 47 0 3
0 48 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 47 0 4
0 48 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 47 0 5
0 48 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 47 0 6
0 48 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 47 0 7
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 47 0 8
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 47 0 9
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 47 0 10
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 47 0 11
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 47 0 12
0 48 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 47 0 13
0 48 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 47 0 14
0 48 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 47 0 15
0 48 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc1 loc24
0
3
0 47 0 16
0 48 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc1 loc25
0
3
0 47 0 17
0 48 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc1 loc26
0
3
0 47 0 18
0 48 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc1 loc27
0
3
0 47 0 19
0 48 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc1 loc28
0
3
0 47 0 20
0 48 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc1 loc29
0
3
0 47 0 21
0 48 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 47 0 22
0 48 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc1 loc30
0
3
0 47 0 23
0 48 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc1 loc31
0
3
0 47 0 24
0 48 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc1 loc32
0
3
0 47 0 25
0 48 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 47 0 26
0 48 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 47 0 27
0 48 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 47 0 28
0 48 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 47 0 29
0 48 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 47 0 30
0 48 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 47 0 31
0 48 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 47 1 0
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 47 1 2
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 47 1 3
0 49 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 47 1 4
0 49 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 47 1 5
0 49 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 47 1 6
0 49 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 47 1 7
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 47 1 8
0 49 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 47 1 9
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 47 1 10
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 47 1 11
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 47 1 12
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 47 1 13
0 49 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 47 1 14
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 47 1 15
0 49 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc10 loc24
0
3
0 47 1 16
0 49 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc10 loc25
0
3
0 47 1 17
0 49 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc10 loc26
0
3
0 47 1 18
0 49 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc10 loc27
0
3
0 47 1 19
0 49 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc10 loc28
0
3
0 47 1 20
0 49 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc10 loc29
0
3
0 47 1 21
0 49 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 47 1 22
0 49 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc10 loc30
0
3
0 47 1 23
0 49 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc10 loc31
0
3
0 47 1 24
0 49 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc10 loc32
0
3
0 47 1 25
0 49 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 47 1 26
0 49 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 47 1 27
0 49 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 47 1 28
0 49 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 47 1 29
0 49 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 47 1 30
0 49 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 47 1 31
0 49 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 47 2 0
0 48 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 47 2 1
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 47 2 3
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 47 2 4
0 50 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 47 2 5
0 50 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 47 2 6
0 50 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 47 2 7
0 50 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 47 2 8
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 47 2 9
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 47 2 10
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 47 2 11
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 47 2 12
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 47 2 13
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 47 2 14
0 50 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 47 2 15
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc11 loc24
0
3
0 47 2 16
0 50 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc11 loc25
0
3
0 47 2 17
0 50 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc11 loc26
0
3
0 47 2 18
0 50 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc11 loc27
0
3
0 47 2 19
0 50 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc11 loc28
0
3
0 47 2 20
0 50 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc11 loc29
0
3
0 47 2 21
0 50 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 47 2 22
0 50 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc11 loc30
0
3
0 47 2 23
0 50 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc11 loc31
0
3
0 47 2 24
0 50 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc11 loc32
0
3
0 47 2 25
0 50 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 47 2 26
0 50 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 47 2 27
0 50 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 47 2 28
0 50 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 47 2 29
0 50 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 47 2 30
0 50 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 47 2 31
0 50 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 47 3 0
0 48 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 47 3 1
0 49 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 47 3 2
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 47 3 4
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 47 3 5
0 51 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 47 3 6
0 51 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 47 3 7
0 51 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 47 3 8
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 47 3 9
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 47 3 10
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 47 3 11
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 47 3 12
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 47 3 13
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 47 3 14
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 47 3 15
0 51 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc12 loc24
0
3
0 47 3 16
0 51 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc12 loc25
0
3
0 47 3 17
0 51 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc12 loc26
0
3
0 47 3 18
0 51 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc12 loc27
0
3
0 47 3 19
0 51 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc12 loc28
0
3
0 47 3 20
0 51 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc12 loc29
0
3
0 47 3 21
0 51 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 47 3 22
0 51 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc12 loc30
0
3
0 47 3 23
0 51 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc12 loc31
0
3
0 47 3 24
0 51 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc12 loc32
0
3
0 47 3 25
0 51 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 47 3 26
0 51 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 47 3 27
0 51 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 47 3 28
0 51 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 47 3 29
0 51 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 47 3 30
0 51 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 47 3 31
0 51 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 47 4 0
0 48 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 47 4 1
0 49 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 47 4 2
0 50 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 47 4 3
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 47 4 5
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 47 4 6
0 52 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 47 4 7
0 52 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 47 4 8
0 52 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 47 4 9
0 52 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 47 4 10
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 47 4 11
0 52 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 47 4 12
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 47 4 13
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 47 4 14
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 47 4 15
0 52 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc13 loc24
0
3
0 47 4 16
0 52 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc13 loc25
0
3
0 47 4 17
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc13 loc26
0
3
0 47 4 18
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc13 loc27
0
3
0 47 4 19
0 52 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc13 loc28
0
3
0 47 4 20
0 52 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc13 loc29
0
3
0 47 4 21
0 52 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 47 4 22
0 52 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc13 loc30
0
3
0 47 4 23
0 52 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc13 loc31
0
3
0 47 4 24
0 52 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc13 loc32
0
3
0 47 4 25
0 52 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 47 4 26
0 52 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 47 4 27
0 52 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 47 4 28
0 52 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 47 4 29
0 52 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 47 4 30
0 52 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 47 4 31
0 52 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 47 5 0
0 48 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 47 5 1
0 49 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 47 5 2
0 50 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 47 5 3
0 51 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 47 5 4
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 47 5 6
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 47 5 7
0 53 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 47 5 8
0 53 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 47 5 9
0 53 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 47 5 10
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 47 5 11
0 53 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 47 5 12
0 53 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 47 5 13
0 53 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 47 5 14
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 47 5 15
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc14 loc24
0
3
0 47 5 16
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc14 loc25
0
3
0 47 5 17
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc14 loc26
0
3
0 47 5 18
0 53 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc14 loc27
0
3
0 47 5 19
0 53 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc14 loc28
0
3
0 47 5 20
0 53 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc14 loc29
0
3
0 47 5 21
0 53 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 47 5 22
0 53 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc14 loc30
0
3
0 47 5 23
0 53 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc14 loc31
0
3
0 47 5 24
0 53 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc14 loc32
0
3
0 47 5 25
0 53 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 47 5 26
0 53 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 47 5 27
0 53 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 47 5 28
0 53 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 47 5 29
0 53 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 47 5 30
0 53 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 47 5 31
0 53 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 47 6 0
0 48 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 47 6 1
0 49 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 47 6 2
0 50 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 47 6 3
0 51 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 47 6 4
0 52 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 47 6 5
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 47 6 7
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 47 6 8
0 54 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 47 6 9
0 54 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 47 6 10
0 54 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 47 6 11
0 54 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 47 6 12
0 54 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 47 6 13
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 47 6 14
0 54 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 47 6 15
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc15 loc24
0
3
0 47 6 16
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc15 loc25
0
3
0 47 6 17
0 54 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc15 loc26
0
3
0 47 6 18
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc15 loc27
0
3
0 47 6 19
0 54 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc15 loc28
0
3
0 47 6 20
0 54 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc15 loc29
0
3
0 47 6 21
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 47 6 22
0 54 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc15 loc30
0
3
0 47 6 23
0 54 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc15 loc31
0
3
0 47 6 24
0 54 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc15 loc32
0
3
0 47 6 25
0 54 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 47 6 26
0 54 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 47 6 27
0 54 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 47 6 28
0 54 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 47 6 29
0 54 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 47 6 30
0 54 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 47 6 31
0 54 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 47 7 0
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 47 7 1
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 47 7 2
0 50 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 47 7 3
0 51 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 47 7 4
0 52 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 47 7 5
0 53 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 47 7 6
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 47 7 8
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 47 7 9
0 55 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 47 7 10
0 55 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 47 7 11
0 55 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 47 7 12
0 55 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 47 7 13
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 47 7 14
0 55 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 47 7 15
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc16 loc24
0
3
0 47 7 16
0 55 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc16 loc25
0
3
0 47 7 17
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc16 loc26
0
3
0 47 7 18
0 55 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc16 loc27
0
3
0 47 7 19
0 55 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc16 loc28
0
3
0 47 7 20
0 55 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc16 loc29
0
3
0 47 7 21
0 55 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 47 7 22
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc16 loc30
0
3
0 47 7 23
0 55 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc16 loc31
0
3
0 47 7 24
0 55 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc16 loc32
0
3
0 47 7 25
0 55 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 47 7 26
0 55 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 47 7 27
0 55 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 47 7 28
0 55 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 47 7 29
0 55 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 47 7 30
0 55 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 47 7 31
0 55 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 47 8 0
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 47 8 1
0 49 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 47 8 2
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 47 8 3
0 51 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 47 8 4
0 52 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 47 8 5
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 47 8 6
0 54 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 47 8 7
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 47 8 9
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 47 8 10
0 56 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 47 8 11
0 56 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 47 8 12
0 56 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 47 8 13
0 56 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 47 8 14
0 56 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 47 8 15
0 56 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc17 loc24
0
3
0 47 8 16
0 56 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc17 loc25
0
3
0 47 8 17
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc17 loc26
0
3
0 47 8 18
0 56 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc17 loc27
0
3
0 47 8 19
0 56 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc17 loc28
0
3
0 47 8 20
0 56 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc17 loc29
0
3
0 47 8 21
0 56 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 47 8 22
0 56 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc17 loc30
0
3
0 47 8 23
0 56 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc17 loc31
0
3
0 47 8 24
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc17 loc32
0
3
0 47 8 25
0 56 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 47 8 26
0 56 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 47 8 27
0 56 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 47 8 28
0 56 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 47 8 29
0 56 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 47 8 30
0 56 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 47 8 31
0 56 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 47 9 0
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 47 9 1
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 47 9 2
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 47 9 3
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 47 9 4
0 52 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 47 9 5
0 53 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 47 9 6
0 54 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 47 9 7
0 55 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 47 9 8
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 47 9 10
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 47 9 11
0 57 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 47 9 12
0 57 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 47 9 13
0 57 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 47 9 14
0 57 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 47 9 15
0 57 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc18 loc24
0
3
0 47 9 16
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc18 loc25
0
3
0 47 9 17
0 57 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc18 loc26
0
3
0 47 9 18
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc18 loc27
0
3
0 47 9 19
0 57 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc18 loc28
0
3
0 47 9 20
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc18 loc29
0
3
0 47 9 21
0 57 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 47 9 22
0 57 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc18 loc30
0
3
0 47 9 23
0 57 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc18 loc31
0
3
0 47 9 24
0 57 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc18 loc32
0
3
0 47 9 25
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 47 9 26
0 57 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 47 9 27
0 57 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 47 9 28
0 57 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 47 9 29
0 57 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 47 9 30
0 57 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 47 9 31
0 57 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 47 10 0
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 47 10 1
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 47 10 2
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 47 10 3
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 47 10 4
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 47 10 5
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 47 10 6
0 54 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 47 10 7
0 55 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 47 10 8
0 56 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 47 10 9
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 47 10 11
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 47 10 12
0 58 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 47 10 13
0 58 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 47 10 14
0 58 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 47 10 15
0 58 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc19 loc24
0
3
0 47 10 16
0 58 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc19 loc25
0
3
0 47 10 17
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc19 loc26
0
3
0 47 10 18
0 58 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc19 loc27
0
3
0 47 10 19
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc19 loc28
0
3
0 47 10 20
0 58 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc19 loc29
0
3
0 47 10 21
0 58 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 47 10 22
0 58 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc19 loc30
0
3
0 47 10 23
0 58 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc19 loc31
0
3
0 47 10 24
0 58 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc19 loc32
0
3
0 47 10 25
0 58 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 47 10 26
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 47 10 27
0 58 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 47 10 28
0 58 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 47 10 29
0 58 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 47 10 30
0 58 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 47 10 31
0 58 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 47 11 0
0 48 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 47 11 1
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 47 11 2
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 47 11 3
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 47 11 4
0 52 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 47 11 5
0 53 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 47 11 6
0 54 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 47 11 7
0 55 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 47 11 8
0 56 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 47 11 9
0 57 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 47 11 10
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 47 11 12
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 47 11 13
0 59 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 47 11 14
0 59 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 47 11 15
0 59 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc2 loc24
0
3
0 47 11 16
0 59 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc2 loc25
0
3
0 47 11 17
0 59 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc2 loc26
0
3
0 47 11 18
0 59 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc2 loc27
0
3
0 47 11 19
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc2 loc28
0
3
0 47 11 20
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc2 loc29
0
3
0 47 11 21
0 59 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 47 11 22
0 59 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc2 loc30
0
3
0 47 11 23
0 59 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc2 loc31
0
3
0 47 11 24
0 59 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc2 loc32
0
3
0 47 11 25
0 59 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 47 11 26
0 59 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 47 11 27
0 59 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 47 11 28
0 59 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 47 11 29
0 59 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 47 11 30
0 59 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 47 11 31
0 59 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 47 12 0
0 48 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 47 12 1
0 49 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 47 12 2
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 47 12 3
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 47 12 4
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 47 12 5
0 53 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 47 12 6
0 54 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 47 12 7
0 55 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 47 12 8
0 56 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 47 12 9
0 57 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 47 12 10
0 58 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 47 12 11
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 47 12 13
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 47 12 14
0 60 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 47 12 15
0 60 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc20 loc24
0
3
0 47 12 16
0 60 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc20 loc25
0
3
0 47 12 17
0 60 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc20 loc26
0
3
0 47 12 18
0 60 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc20 loc27
0
3
0 47 12 19
0 60 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc20 loc28
0
3
0 47 12 20
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc20 loc29
0
3
0 47 12 21
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 47 12 22
0 60 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc20 loc30
0
3
0 47 12 23
0 60 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc20 loc31
0
3
0 47 12 24
0 60 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc20 loc32
0
3
0 47 12 25
0 60 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 47 12 26
0 60 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 47 12 27
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 47 12 28
0 60 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 47 12 29
0 60 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 47 12 30
0 60 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 47 12 31
0 60 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 47 13 0
0 48 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 47 13 1
0 49 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 47 13 2
0 50 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 47 13 3
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 47 13 4
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 47 13 5
0 53 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 47 13 6
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 47 13 7
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 47 13 8
0 56 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 47 13 9
0 57 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 47 13 10
0 58 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 47 13 11
0 59 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 47 13 12
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 47 13 14
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 47 13 15
0 61 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc21 loc24
0
3
0 47 13 16
0 61 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc21 loc25
0
3
0 47 13 17
0 61 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc21 loc26
0
3
0 47 13 18
0 61 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc21 loc27
0
3
0 47 13 19
0 61 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc21 loc28
0
3
0 47 13 20
0 61 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc21 loc29
0
3
0 47 13 21
0 61 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 47 13 22
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc21 loc30
0
3
0 47 13 23
0 61 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc21 loc31
0
3
0 47 13 24
0 61 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc21 loc32
0
3
0 47 13 25
0 61 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 47 13 26
0 61 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 47 13 27
0 61 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 47 13 28
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 47 13 29
0 61 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 47 13 30
0 61 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 47 13 31
0 61 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 47 14 0
0 48 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 47 14 1
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 47 14 2
0 50 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 47 14 3
0 51 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 47 14 4
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 47 14 5
0 53 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 47 14 6
0 54 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 47 14 7
0 55 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 47 14 8
0 56 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 47 14 9
0 57 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 47 14 10
0 58 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 47 14 11
0 59 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 47 14 12
0 60 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 47 14 13
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 47 14 15
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
sail loc22 loc24
0
3
0 47 14 16
0 62 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc22 loc25
0
3
0 47 14 17
0 62 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc22 loc26
0
3
0 47 14 18
0 62 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc22 loc27
0
3
0 47 14 19
0 62 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc22 loc28
0
3
0 47 14 20
0 62 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc22 loc29
0
3
0 47 14 21
0 62 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 47 14 22
0 62 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc22 loc30
0
3
0 47 14 23
0 62 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc22 loc31
0
3
0 47 14 24
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc22 loc32
0
3
0 47 14 25
0 62 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 47 14 26
0 62 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 47 14 27
0 62 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 47 14 28
0 62 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 47 14 29
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 47 14 30
0 62 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 47 14 31
0 62 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 47 15 0
0 48 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 47 15 1
0 49 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 47 15 2
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 47 15 3
0 51 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 47 15 4
0 52 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 47 15 5
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 47 15 6
0 54 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 47 15 7
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 47 15 8
0 56 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 47 15 9
0 57 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 47 15 10
0 58 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 47 15 11
0 59 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 47 15 12
0 60 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 47 15 13
0 61 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 47 15 14
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
sail loc23 loc24
0
3
0 47 15 16
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
sail loc23 loc25
0
3
0 47 15 17
0 63 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc23 loc26
0
3
0 47 15 18
0 63 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc23 loc27
0
3
0 47 15 19
0 63 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc23 loc28
0
3
0 47 15 20
0 63 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc23 loc29
0
3
0 47 15 21
0 63 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 47 15 22
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc23 loc30
0
3
0 47 15 23
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc23 loc31
0
3
0 47 15 24
0 63 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc23 loc32
0
3
0 47 15 25
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 47 15 26
0 63 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 47 15 27
0 63 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 47 15 28
0 63 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 47 15 29
0 63 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 47 15 30
0 63 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 47 15 31
0 63 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc24 loc1
0
3
0 47 16 0
0 48 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc10
0
3
0 47 16 1
0 49 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc11
0
3
0 47 16 2
0 50 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc12
0
3
0 47 16 3
0 51 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc13
0
3
0 47 16 4
0 52 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc14
0
3
0 47 16 5
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc15
0
3
0 47 16 6
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc16
0
3
0 47 16 7
0 55 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc17
0
3
0 47 16 8
0 56 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc18
0
3
0 47 16 9
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc19
0
3
0 47 16 10
0 58 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc2
0
3
0 47 16 11
0 59 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc20
0
3
0 47 16 12
0 60 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc21
0
3
0 47 16 13
0 61 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc22
0
3
0 47 16 14
0 62 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc23
0
3
0 47 16 15
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
sail loc24 loc25
0
3
0 47 16 17
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
sail loc24 loc26
0
3
0 47 16 18
0 64 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc24 loc27
0
3
0 47 16 19
0 64 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc24 loc28
0
3
0 47 16 20
0 64 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc24 loc29
0
3
0 47 16 21
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc24 loc3
0
3
0 47 16 22
0 64 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc24 loc30
0
3
0 47 16 23
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc24 loc31
0
3
0 47 16 24
0 64 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc24 loc32
0
3
0 47 16 25
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc24 loc4
0
3
0 47 16 26
0 64 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc24 loc5
0
3
0 47 16 27
0 64 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc24 loc6
0
3
0 47 16 28
0 64 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc24 loc7
0
3
0 47 16 29
0 64 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc24 loc8
0
3
0 47 16 30
0 64 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc24 loc9
0
3
0 47 16 31
0 64 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc25 loc1
0
3
0 47 17 0
0 48 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc10
0
3
0 47 17 1
0 49 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc11
0
3
0 47 17 2
0 50 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc12
0
3
0 47 17 3
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc13
0
3
0 47 17 4
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc14
0
3
0 47 17 5
0 53 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc15
0
3
0 47 17 6
0 54 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc16
0
3
0 47 17 7
0 55 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc17
0
3
0 47 17 8
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc18
0
3
0 47 17 9
0 57 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc19
0
3
0 47 17 10
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc2
0
3
0 47 17 11
0 59 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc20
0
3
0 47 17 12
0 60 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc21
0
3
0 47 17 13
0 61 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc22
0
3
0 47 17 14
0 62 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc23
0
3
0 47 17 15
0 63 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc24
0
3
0 47 17 16
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
sail loc25 loc26
0
3
0 47 17 18
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
sail loc25 loc27
0
3
0 47 17 19
0 65 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc25 loc28
0
3
0 47 17 20
0 65 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc25 loc29
0
3
0 47 17 21
0 65 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc25 loc3
0
3
0 47 17 22
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc25 loc30
0
3
0 47 17 23
0 65 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc25 loc31
0
3
0 47 17 24
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc25 loc32
0
3
0 47 17 25
0 65 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc25 loc4
0
3
0 47 17 26
0 65 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc25 loc5
0
3
0 47 17 27
0 65 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc25 loc6
0
3
0 47 17 28
0 65 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc25 loc7
0
3
0 47 17 29
0 65 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc25 loc8
0
3
0 47 17 30
0 65 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc25 loc9
0
3
0 47 17 31
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc26 loc1
0
3
0 47 18 0
0 48 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc10
0
3
0 47 18 1
0 49 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc11
0
3
0 47 18 2
0 50 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc12
0
3
0 47 18 3
0 51 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc13
0
3
0 47 18 4
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc14
0
3
0 47 18 5
0 53 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc15
0
3
0 47 18 6
0 54 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc16
0
3
0 47 18 7
0 55 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc17
0
3
0 47 18 8
0 56 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc18
0
3
0 47 18 9
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc19
0
3
0 47 18 10
0 58 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc2
0
3
0 47 18 11
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc20
0
3
0 47 18 12
0 60 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc21
0
3
0 47 18 13
0 61 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc22
0
3
0 47 18 14
0 62 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc23
0
3
0 47 18 15
0 63 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc24
0
3
0 47 18 16
0 64 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc25
0
3
0 47 18 17
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
sail loc26 loc27
0
3
0 47 18 19
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
sail loc26 loc28
0
3
0 47 18 20
0 66 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc26 loc29
0
3
0 47 18 21
0 66 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc26 loc3
0
3
0 47 18 22
0 66 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc26 loc30
0
3
0 47 18 23
0 66 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc26 loc31
0
3
0 47 18 24
0 66 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc26 loc32
0
3
0 47 18 25
0 66 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc26 loc4
0
3
0 47 18 26
0 66 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc26 loc5
0
3
0 47 18 27
0 66 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc26 loc6
0
3
0 47 18 28
0 66 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc26 loc7
0
3
0 47 18 29
0 66 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc26 loc8
0
3
0 47 18 30
0 66 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc26 loc9
0
3
0 47 18 31
0 66 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc27 loc1
0
3
0 47 19 0
0 48 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc10
0
3
0 47 19 1
0 49 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc11
0
3
0 47 19 2
0 50 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc12
0
3
0 47 19 3
0 51 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc13
0
3
0 47 19 4
0 52 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc14
0
3
0 47 19 5
0 53 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc15
0
3
0 47 19 6
0 54 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc16
0
3
0 47 19 7
0 55 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc17
0
3
0 47 19 8
0 56 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc18
0
3
0 47 19 9
0 57 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc19
0
3
0 47 19 10
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc2
0
3
0 47 19 11
0 59 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc20
0
3
0 47 19 12
0 60 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc21
0
3
0 47 19 13
0 61 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc22
0
3
0 47 19 14
0 62 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc23
0
3
0 47 19 15
0 63 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc24
0
3
0 47 19 16
0 64 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc25
0
3
0 47 19 17
0 65 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc26
0
3
0 47 19 18
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
sail loc27 loc28
0
3
0 47 19 20
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
sail loc27 loc29
0
3
0 47 19 21
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc27 loc3
0
3
0 47 19 22
0 67 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc27 loc30
0
3
0 47 19 23
0 67 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc27 loc31
0
3
0 47 19 24
0 67 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc27 loc32
0
3
0 47 19 25
0 67 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc27 loc4
0
3
0 47 19 26
0 67 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc27 loc5
0
3
0 47 19 27
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc27 loc6
0
3
0 47 19 28
0 67 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc27 loc7
0
3
0 47 19 29
0 67 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc27 loc8
0
3
0 47 19 30
0 67 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc27 loc9
0
3
0 47 19 31
0 67 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc28 loc1
0
3
0 47 20 0
0 48 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc10
0
3
0 47 20 1
0 49 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc11
0
3
0 47 20 2
0 50 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc12
0
3
0 47 20 3
0 51 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc13
0
3
0 47 20 4
0 52 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc14
0
3
0 47 20 5
0 53 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc15
0
3
0 47 20 6
0 54 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc16
0
3
0 47 20 7
0 55 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc17
0
3
0 47 20 8
0 56 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc18
0
3
0 47 20 9
0 57 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc19
0
3
0 47 20 10
0 58 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc2
0
3
0 47 20 11
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc20
0
3
0 47 20 12
0 60 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc21
0
3
0 47 20 13
0 61 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc22
0
3
0 47 20 14
0 62 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc23
0
3
0 47 20 15
0 63 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc24
0
3
0 47 20 16
0 64 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc25
0
3
0 47 20 17
0 65 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc26
0
3
0 47 20 18
0 66 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc27
0
3
0 47 20 19
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
sail loc28 loc29
0
3
0 47 20 21
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
sail loc28 loc3
0
3
0 47 20 22
0 68 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc28 loc30
0
3
0 47 20 23
0 68 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc28 loc31
0
3
0 47 20 24
0 68 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc28 loc32
0
3
0 47 20 25
0 68 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc28 loc4
0
3
0 47 20 26
0 68 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc28 loc5
0
3
0 47 20 27
0 68 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc28 loc6
0
3
0 47 20 28
0 68 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc28 loc7
0
3
0 47 20 29
0 68 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc28 loc8
0
3
0 47 20 30
0 68 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc28 loc9
0
3
0 47 20 31
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc29 loc1
0
3
0 47 21 0
0 48 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc10
0
3
0 47 21 1
0 49 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc11
0
3
0 47 21 2
0 50 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc12
0
3
0 47 21 3
0 51 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc13
0
3
0 47 21 4
0 52 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc14
0
3
0 47 21 5
0 53 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc15
0
3
0 47 21 6
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc16
0
3
0 47 21 7
0 55 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc17
0
3
0 47 21 8
0 56 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc18
0
3
0 47 21 9
0 57 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc19
0
3
0 47 21 10
0 58 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc2
0
3
0 47 21 11
0 59 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc20
0
3
0 47 21 12
0 60 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc21
0
3
0 47 21 13
0 61 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc22
0
3
0 47 21 14
0 62 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc23
0
3
0 47 21 15
0 63 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc24
0
3
0 47 21 16
0 64 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc25
0
3
0 47 21 17
0 65 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc26
0
3
0 47 21 18
0 66 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc27
0
3
0 47 21 19
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc28
0
3
0 47 21 20
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
sail loc29 loc3
0
3
0 47 21 22
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
sail loc29 loc30
0
3
0 47 21 23
0 69 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc29 loc31
0
3
0 47 21 24
0 69 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc29 loc32
0
3
0 47 21 25
0 69 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc29 loc4
0
3
0 47 21 26
0 69 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc29 loc5
0
3
0 47 21 27
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc29 loc6
0
3
0 47 21 28
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc29 loc7
0
3
0 47 21 29
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc29 loc8
0
3
0 47 21 30
0 69 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc29 loc9
0
3
0 47 21 31
0 69 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 47 22 0
0 48 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 47 22 1
0 49 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 47 22 2
0 50 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 47 22 3
0 51 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 47 22 4
0 52 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 47 22 5
0 53 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 47 22 6
0 54 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 47 22 7
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 47 22 8
0 56 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 47 22 9
0 57 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 47 22 10
0 58 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 47 22 11
0 59 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 47 22 12
0 60 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 47 22 13
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 47 22 14
0 62 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 47 22 15
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc24
0
3
0 47 22 16
0 64 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc25
0
3
0 47 22 17
0 65 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc26
0
3
0 47 22 18
0 66 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc27
0
3
0 47 22 19
0 67 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc28
0
3
0 47 22 20
0 68 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc29
0
3
0 47 22 21
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
sail loc3 loc30
0
3
0 47 22 23
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
sail loc3 loc31
0
3
0 47 22 24
0 70 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc3 loc32
0
3
0 47 22 25
0 70 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 47 22 26
0 70 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 47 22 27
0 70 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 47 22 28
0 70 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 47 22 29
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 47 22 30
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 47 22 31
0 70 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc30 loc1
0
3
0 47 23 0
0 48 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc10
0
3
0 47 23 1
0 49 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc11
0
3
0 47 23 2
0 50 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc12
0
3
0 47 23 3
0 51 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc13
0
3
0 47 23 4
0 52 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc14
0
3
0 47 23 5
0 53 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc15
0
3
0 47 23 6
0 54 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc16
0
3
0 47 23 7
0 55 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc17
0
3
0 47 23 8
0 56 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc18
0
3
0 47 23 9
0 57 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc19
0
3
0 47 23 10
0 58 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc2
0
3
0 47 23 11
0 59 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc20
0
3
0 47 23 12
0 60 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc21
0
3
0 47 23 13
0 61 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc22
0
3
0 47 23 14
0 62 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc23
0
3
0 47 23 15
0 63 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc24
0
3
0 47 23 16
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc25
0
3
0 47 23 17
0 65 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc26
0
3
0 47 23 18
0 66 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc27
0
3
0 47 23 19
0 67 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc28
0
3
0 47 23 20
0 68 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc29
0
3
0 47 23 21
0 69 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc3
0
3
0 47 23 22
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
sail loc30 loc31
0
3
0 47 23 24
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
sail loc30 loc32
0
3
0 47 23 25
0 71 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc30 loc4
0
3
0 47 23 26
0 71 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc30 loc5
0
3
0 47 23 27
0 71 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc30 loc6
0
3
0 47 23 28
0 71 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc30 loc7
0
3
0 47 23 29
0 71 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc30 loc8
0
3
0 47 23 30
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc30 loc9
0
3
0 47 23 31
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc31 loc1
0
3
0 47 24 0
0 48 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc10
0
3
0 47 24 1
0 49 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc11
0
3
0 47 24 2
0 50 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc12
0
3
0 47 24 3
0 51 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc13
0
3
0 47 24 4
0 52 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc14
0
3
0 47 24 5
0 53 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc15
0
3
0 47 24 6
0 54 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc16
0
3
0 47 24 7
0 55 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc17
0
3
0 47 24 8
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc18
0
3
0 47 24 9
0 57 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc19
0
3
0 47 24 10
0 58 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc2
0
3
0 47 24 11
0 59 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc20
0
3
0 47 24 12
0 60 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc21
0
3
0 47 24 13
0 61 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc22
0
3
0 47 24 14
0 62 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc23
0
3
0 47 24 15
0 63 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc24
0
3
0 47 24 16
0 64 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc25
0
3
0 47 24 17
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc26
0
3
0 47 24 18
0 66 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc27
0
3
0 47 24 19
0 67 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc28
0
3
0 47 24 20
0 68 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc29
0
3
0 47 24 21
0 69 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc3
0
3
0 47 24 22
0 70 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc30
0
3
0 47 24 23
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
sail loc31 loc32
0
3
0 47 24 25
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
sail loc31 loc4
0
3
0 47 24 26
0 72 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc31 loc5
0
3
0 47 24 27
0 72 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc31 loc6
0
3
0 47 24 28
0 72 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc31 loc7
0
3
0 47 24 29
0 72 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc31 loc8
0
3
0 47 24 30
0 72 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc31 loc9
0
3
0 47 24 31
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc32 loc1
0
3
0 47 25 0
0 48 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc10
0
3
0 47 25 1
0 49 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc11
0
3
0 47 25 2
0 50 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc12
0
3
0 47 25 3
0 51 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc13
0
3
0 47 25 4
0 52 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc14
0
3
0 47 25 5
0 53 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc15
0
3
0 47 25 6
0 54 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc16
0
3
0 47 25 7
0 55 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc17
0
3
0 47 25 8
0 56 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc18
0
3
0 47 25 9
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc19
0
3
0 47 25 10
0 58 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc2
0
3
0 47 25 11
0 59 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc20
0
3
0 47 25 12
0 60 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc21
0
3
0 47 25 13
0 61 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc22
0
3
0 47 25 14
0 62 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc23
0
3
0 47 25 15
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc24
0
3
0 47 25 16
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc25
0
3
0 47 25 17
0 65 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc26
0
3
0 47 25 18
0 66 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc27
0
3
0 47 25 19
0 67 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc28
0
3
0 47 25 20
0 68 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc29
0
3
0 47 25 21
0 69 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc3
0
3
0 47 25 22
0 70 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc30
0
3
0 47 25 23
0 71 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc31
0
3
0 47 25 24
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
sail loc32 loc4
0
3
0 47 25 26
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
sail loc32 loc5
0
3
0 47 25 27
0 73 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc32 loc6
0
3
0 47 25 28
0 73 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc32 loc7
0
3
0 47 25 29
0 73 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc32 loc8
0
3
0 47 25 30
0 73 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc32 loc9
0
3
0 47 25 31
0 73 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 47 26 0
0 48 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 47 26 1
0 49 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 47 26 2
0 50 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 47 26 3
0 51 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 47 26 4
0 52 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 47 26 5
0 53 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 47 26 6
0 54 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 47 26 7
0 55 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 47 26 8
0 56 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 47 26 9
0 57 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 47 26 10
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 47 26 11
0 59 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 47 26 12
0 60 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 47 26 13
0 61 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 47 26 14
0 62 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 47 26 15
0 63 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc24
0
3
0 47 26 16
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc25
0
3
0 47 26 17
0 65 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc26
0
3
0 47 26 18
0 66 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc27
0
3
0 47 26 19
0 67 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc28
0
3
0 47 26 20
0 68 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc29
0
3
0 47 26 21
0 69 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 47 26 22
0 70 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc30
0
3
0 47 26 23
0 71 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc31
0
3
0 47 26 24
0 72 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc32
0
3
0 47 26 25
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 47 26 27
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 47 26 28
0 74 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 47 26 29
0 74 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 47 26 30
0 74 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 47 26 31
0 74 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 47 27 0
0 48 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 47 27 1
0 49 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 47 27 2
0 50 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 47 27 3
0 51 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 47 27 4
0 52 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 47 27 5
0 53 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 47 27 6
0 54 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 47 27 7
0 55 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 47 27 8
0 56 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 47 27 9
0 57 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 47 27 10
0 58 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 47 27 11
0 59 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 47 27 12
0 60 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 47 27 13
0 61 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 47 27 14
0 62 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 47 27 15
0 63 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc24
0
3
0 47 27 16
0 64 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc25
0
3
0 47 27 17
0 65 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc26
0
3
0 47 27 18
0 66 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc27
0
3
0 47 27 19
0 67 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc28
0
3
0 47 27 20
0 68 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc29
0
3
0 47 27 21
0 69 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 47 27 22
0 70 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc30
0
3
0 47 27 23
0 71 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc31
0
3
0 47 27 24
0 72 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc32
0
3
0 47 27 25
0 73 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 47 27 26
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 47 27 28
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 47 27 29
0 75 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 47 27 30
0 75 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 47 27 31
0 75 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 47 28 0
0 48 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 47 28 1
0 49 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 47 28 2
0 50 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 47 28 3
0 51 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 47 28 4
0 52 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 47 28 5
0 53 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 47 28 6
0 54 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 47 28 7
0 55 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 47 28 8
0 56 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 47 28 9
0 57 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 47 28 10
0 58 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 47 28 11
0 59 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 47 28 12
0 60 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 47 28 13
0 61 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 47 28 14
0 62 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 47 28 15
0 63 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc24
0
3
0 47 28 16
0 64 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc25
0
3
0 47 28 17
0 65 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc26
0
3
0 47 28 18
0 66 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc27
0
3
0 47 28 19
0 67 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc28
0
3
0 47 28 20
0 68 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc29
0
3
0 47 28 21
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 47 28 22
0 70 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc30
0
3
0 47 28 23
0 71 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc31
0
3
0 47 28 24
0 72 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc32
0
3
0 47 28 25
0 73 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 47 28 26
0 74 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 47 28 27
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 47 28 29
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 47 28 30
0 76 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 47 28 31
0 76 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 47 29 0
0 48 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 47 29 1
0 49 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 47 29 2
0 50 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 47 29 3
0 51 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 47 29 4
0 52 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 47 29 5
0 53 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 47 29 6
0 54 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 47 29 7
0 55 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 47 29 8
0 56 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 47 29 9
0 57 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 47 29 10
0 58 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 47 29 11
0 59 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 47 29 12
0 60 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 47 29 13
0 61 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 47 29 14
0 62 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 47 29 15
0 63 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc24
0
3
0 47 29 16
0 64 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc25
0
3
0 47 29 17
0 65 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc26
0
3
0 47 29 18
0 66 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc27
0
3
0 47 29 19
0 67 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc28
0
3
0 47 29 20
0 68 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc29
0
3
0 47 29 21
0 69 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 47 29 22
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc30
0
3
0 47 29 23
0 71 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc31
0
3
0 47 29 24
0 72 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc32
0
3
0 47 29 25
0 73 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 47 29 26
0 74 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 47 29 27
0 75 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 47 29 28
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 47 29 30
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 47 29 31
0 77 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 47 30 0
0 48 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 47 30 1
0 49 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 47 30 2
0 50 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 47 30 3
0 51 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 47 30 4
0 52 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 47 30 5
0 53 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 47 30 6
0 54 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 47 30 7
0 55 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 47 30 8
0 56 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 47 30 9
0 57 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 47 30 10
0 58 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 47 30 11
0 59 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 47 30 12
0 60 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 47 30 13
0 61 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 47 30 14
0 62 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 47 30 15
0 63 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc24
0
3
0 47 30 16
0 64 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc25
0
3
0 47 30 17
0 65 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc26
0
3
0 47 30 18
0 66 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc27
0
3
0 47 30 19
0 67 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc28
0
3
0 47 30 20
0 68 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc29
0
3
0 47 30 21
0 69 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 47 30 22
0 70 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc30
0
3
0 47 30 23
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc31
0
3
0 47 30 24
0 72 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc32
0
3
0 47 30 25
0 73 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 47 30 26
0 74 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 47 30 27
0 75 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 47 30 28
0 76 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 47 30 29
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 47 30 31
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 47 31 0
0 48 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 47 31 1
0 49 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 47 31 2
0 50 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 47 31 3
0 51 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 47 31 4
0 52 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 47 31 5
0 53 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 47 31 6
0 54 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 47 31 7
0 55 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 47 31 8
0 56 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 47 31 9
0 57 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 47 31 10
0 58 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 47 31 11
0 59 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 47 31 12
0 60 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 47 31 13
0 61 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 47 31 14
0 62 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 47 31 15
0 63 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc24
0
3
0 47 31 16
0 64 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc25
0
3
0 47 31 17
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc26
0
3
0 47 31 18
0 66 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc27
0
3
0 47 31 19
0 67 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc28
0
3
0 47 31 20
0 68 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc29
0
3
0 47 31 21
0 69 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 47 31 22
0 70 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc30
0
3
0 47 31 23
0 71 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc31
0
3
0 47 31 24
0 72 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc32
0
3
0 47 31 25
0 73 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 47 31 26
0 74 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 47 31 27
0 75 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 47 31 28
0 76 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 47 31 29
0 77 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 47 31 30
0 78 0 1
0 79 -1 0
1
end_operator
0
