begin_version
3
end_version
begin_metric
1
end_metric
116
begin_variable
var0
-1
74
empty-ferry
on car1
on car10
on car11
on car12
on car13
on car14
on car15
on car16
on car17
on car18
on car19
on car2
on car20
on car21
on car22
on car23
on car24
on car25
on car26
on car27
on car28
on car29
on car3
on car30
on car31
on car32
on car33
on car34
on car35
on car36
on car37
on car38
on car39
on car4
on car40
on car41
on car42
on car43
on car44
on car45
on car46
on car47
on car48
on car49
on car5
on car50
on car51
on car52
on car53
on car54
on car55
on car56
on car57
on car58
on car59
on car6
on car60
on car61
on car62
on car63
on car64
on car65
on car66
on car67
on car68
on car69
on car7
on car70
on car71
on car72
on car73
on car8
on car9
end_variable
begin_variable
var1
-1
42
at car31 loc1
at car31 loc10
at car31 loc11
at car31 loc12
at car31 loc13
at car31 loc14
at car31 loc15
at car31 loc16
at car31 loc17
at car31 loc18
at car31 loc19
at car31 loc2
at car31 loc20
at car31 loc21
at car31 loc22
at car31 loc23
at car31 loc24
at car31 loc25
at car31 loc26
at car31 loc27
at car31 loc28
at car31 loc29
at car31 loc3
at car31 loc30
at car31 loc31
at car31 loc32
at car31 loc33
at car31 loc34
at car31 loc35
at car31 loc36
at car31 loc37
at car31 loc38
at car31 loc39
at car31 loc4
at car31 loc40
at car31 loc41
at car31 loc5
at car31 loc6
at car31 loc7
at car31 loc8
at car31 loc9
none-of-those
end_variable
begin_variable
var2
-1
42
at car54 loc1
at car54 loc10
at car54 loc11
at car54 loc12
at car54 loc13
at car54 loc14
at car54 loc15
at car54 loc16
at car54 loc17
at car54 loc18
at car54 loc19
at car54 loc2
at car54 loc20
at car54 loc21
at car54 loc22
at car54 loc23
at car54 loc24
at car54 loc25
at car54 loc26
at car54 loc27
at car54 loc28
at car54 loc29
at car54 loc3
at car54 loc30
at car54 loc31
at car54 loc32
at car54 loc33
at car54 loc34
at car54 loc35
at car54 loc36
at car54 loc37
at car54 loc38
at car54 loc39
at car54 loc4
at car54 loc40
at car54 loc41
at car54 loc5
at car54 loc6
at car54 loc7
at car54 loc8
at car54 loc9
none-of-those
end_variable
begin_variable
var3
-1
42
at car26 loc1
at car26 loc10
at car26 loc11
at car26 loc12
at car26 loc13
at car26 loc14
at car26 loc15
at car26 loc16
at car26 loc17
at car26 loc18
at car26 loc19
at car26 loc2
at car26 loc20
at car26 loc21
at car26 loc22
at car26 loc23
at car26 loc24
at car26 loc25
at car26 loc26
at car26 loc27
at car26 loc28
at car26 loc29
at car26 loc3
at car26 loc30
at car26 loc31
at car26 loc32
at car26 loc33
at car26 loc34
at car26 loc35
at car26 loc36
at car26 loc37
at car26 loc38
at car26 loc39
at car26 loc4
at car26 loc40
at car26 loc41
at car26 loc5
at car26 loc6
at car26 loc7
at car26 loc8
at car26 loc9
none-of-those
end_variable
begin_variable
var4
-1
42
at car49 loc1
at car49 loc10
at car49 loc11
at car49 loc12
at car49 loc13
at car49 loc14
at car49 loc15
at car49 loc16
at car49 loc17
at car49 loc18
at car49 loc19
at car49 loc2
at car49 loc20
at car49 loc21
at car49 loc22
at car49 loc23
at car49 loc24
at car49 loc25
at car49 loc26
at car49 loc27
at car49 loc28
at car49 loc29
at car49 loc3
at car49 loc30
at car49 loc31
at car49 loc32
at car49 loc33
at car49 loc34
at car49 loc35
at car49 loc36
at car49 loc37
at car49 loc38
at car49 loc39
at car49 loc4
at car49 loc40
at car49 loc41
at car49 loc5
at car49 loc6
at car49 loc7
at car49 loc8
at car49 loc9
none-of-those
end_variable
begin_variable
var5
-1
42
at car71 loc1
at car71 loc10
at car71 loc11
at car71 loc12
at car71 loc13
at car71 loc14
at car71 loc15
at car71 loc16
at car71 loc17
at car71 loc18
at car71 loc19
at car71 loc2
at car71 loc20
at car71 loc21
at car71 loc22
at car71 loc23
at car71 loc24
at car71 loc25
at car71 loc26
at car71 loc27
at car71 loc28
at car71 loc29
at car71 loc3
at car71 loc30
at car71 loc31
at car71 loc32
at car71 loc33
at car71 loc34
at car71 loc35
at car71 loc36
at car71 loc37
at car71 loc38
at car71 loc39
at car71 loc4
at car71 loc40
at car71 loc41
at car71 loc5
at car71 loc6
at car71 loc7
at car71 loc8
at car71 loc9
none-of-those
end_variable
begin_variable
var6
-1
42
at car20 loc1
at car20 loc10
at car20 loc11
at car20 loc12
at car20 loc13
at car20 loc14
at car20 loc15
at car20 loc16
at car20 loc17
at car20 loc18
at car20 loc19
at car20 loc2
at car20 loc20
at car20 loc21
at car20 loc22
at car20 loc23
at car20 loc24
at car20 loc25
at car20 loc26
at car20 loc27
at car20 loc28
at car20 loc29
at car20 loc3
at car20 loc30
at car20 loc31
at car20 loc32
at car20 loc33
at car20 loc34
at car20 loc35
at car20 loc36
at car20 loc37
at car20 loc38
at car20 loc39
at car20 loc4
at car20 loc40
at car20 loc41
at car20 loc5
at car20 loc6
at car20 loc7
at car20 loc8
at car20 loc9
none-of-those
end_variable
begin_variable
var7
-1
42
at car43 loc1
at car43 loc10
at car43 loc11
at car43 loc12
at car43 loc13
at car43 loc14
at car43 loc15
at car43 loc16
at car43 loc17
at car43 loc18
at car43 loc19
at car43 loc2
at car43 loc20
at car43 loc21
at car43 loc22
at car43 loc23
at car43 loc24
at car43 loc25
at car43 loc26
at car43 loc27
at car43 loc28
at car43 loc29
at car43 loc3
at car43 loc30
at car43 loc31
at car43 loc32
at car43 loc33
at car43 loc34
at car43 loc35
at car43 loc36
at car43 loc37
at car43 loc38
at car43 loc39
at car43 loc4
at car43 loc40
at car43 loc41
at car43 loc5
at car43 loc6
at car43 loc7
at car43 loc8
at car43 loc9
none-of-those
end_variable
begin_variable
var8
-1
42
at car66 loc1
at car66 loc10
at car66 loc11
at car66 loc12
at car66 loc13
at car66 loc14
at car66 loc15
at car66 loc16
at car66 loc17
at car66 loc18
at car66 loc19
at car66 loc2
at car66 loc20
at car66 loc21
at car66 loc22
at car66 loc23
at car66 loc24
at car66 loc25
at car66 loc26
at car66 loc27
at car66 loc28
at car66 loc29
at car66 loc3
at car66 loc30
at car66 loc31
at car66 loc32
at car66 loc33
at car66 loc34
at car66 loc35
at car66 loc36
at car66 loc37
at car66 loc38
at car66 loc39
at car66 loc4
at car66 loc40
at car66 loc41
at car66 loc5
at car66 loc6
at car66 loc7
at car66 loc8
at car66 loc9
none-of-those
end_variable
begin_variable
var9
-1
42
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc24
at car15 loc25
at car15 loc26
at car15 loc27
at car15 loc28
at car15 loc29
at car15 loc3
at car15 loc30
at car15 loc31
at car15 loc32
at car15 loc33
at car15 loc34
at car15 loc35
at car15 loc36
at car15 loc37
at car15 loc38
at car15 loc39
at car15 loc4
at car15 loc40
at car15 loc41
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
none-of-those
end_variable
begin_variable
var10
-1
42
at car38 loc1
at car38 loc10
at car38 loc11
at car38 loc12
at car38 loc13
at car38 loc14
at car38 loc15
at car38 loc16
at car38 loc17
at car38 loc18
at car38 loc19
at car38 loc2
at car38 loc20
at car38 loc21
at car38 loc22
at car38 loc23
at car38 loc24
at car38 loc25
at car38 loc26
at car38 loc27
at car38 loc28
at car38 loc29
at car38 loc3
at car38 loc30
at car38 loc31
at car38 loc32
at car38 loc33
at car38 loc34
at car38 loc35
at car38 loc36
at car38 loc37
at car38 loc38
at car38 loc39
at car38 loc4
at car38 loc40
at car38 loc41
at car38 loc5
at car38 loc6
at car38 loc7
at car38 loc8
at car38 loc9
none-of-those
end_variable
begin_variable
var11
-1
42
at car60 loc1
at car60 loc10
at car60 loc11
at car60 loc12
at car60 loc13
at car60 loc14
at car60 loc15
at car60 loc16
at car60 loc17
at car60 loc18
at car60 loc19
at car60 loc2
at car60 loc20
at car60 loc21
at car60 loc22
at car60 loc23
at car60 loc24
at car60 loc25
at car60 loc26
at car60 loc27
at car60 loc28
at car60 loc29
at car60 loc3
at car60 loc30
at car60 loc31
at car60 loc32
at car60 loc33
at car60 loc34
at car60 loc35
at car60 loc36
at car60 loc37
at car60 loc38
at car60 loc39
at car60 loc4
at car60 loc40
at car60 loc41
at car60 loc5
at car60 loc6
at car60 loc7
at car60 loc8
at car60 loc9
none-of-those
end_variable
begin_variable
var12
-1
42
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc24
at car1 loc25
at car1 loc26
at car1 loc27
at car1 loc28
at car1 loc29
at car1 loc3
at car1 loc30
at car1 loc31
at car1 loc32
at car1 loc33
at car1 loc34
at car1 loc35
at car1 loc36
at car1 loc37
at car1 loc38
at car1 loc39
at car1 loc4
at car1 loc40
at car1 loc41
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
none-of-those
end_variable
begin_variable
var13
-1
42
at car32 loc1
at car32 loc10
at car32 loc11
at car32 loc12
at car32 loc13
at car32 loc14
at car32 loc15
at car32 loc16
at car32 loc17
at car32 loc18
at car32 loc19
at car32 loc2
at car32 loc20
at car32 loc21
at car32 loc22
at car32 loc23
at car32 loc24
at car32 loc25
at car32 loc26
at car32 loc27
at car32 loc28
at car32 loc29
at car32 loc3
at car32 loc30
at car32 loc31
at car32 loc32
at car32 loc33
at car32 loc34
at car32 loc35
at car32 loc36
at car32 loc37
at car32 loc38
at car32 loc39
at car32 loc4
at car32 loc40
at car32 loc41
at car32 loc5
at car32 loc6
at car32 loc7
at car32 loc8
at car32 loc9
none-of-those
end_variable
begin_variable
var14
-1
42
at car55 loc1
at car55 loc10
at car55 loc11
at car55 loc12
at car55 loc13
at car55 loc14
at car55 loc15
at car55 loc16
at car55 loc17
at car55 loc18
at car55 loc19
at car55 loc2
at car55 loc20
at car55 loc21
at car55 loc22
at car55 loc23
at car55 loc24
at car55 loc25
at car55 loc26
at car55 loc27
at car55 loc28
at car55 loc29
at car55 loc3
at car55 loc30
at car55 loc31
at car55 loc32
at car55 loc33
at car55 loc34
at car55 loc35
at car55 loc36
at car55 loc37
at car55 loc38
at car55 loc39
at car55 loc4
at car55 loc40
at car55 loc41
at car55 loc5
at car55 loc6
at car55 loc7
at car55 loc8
at car55 loc9
none-of-those
end_variable
begin_variable
var15
-1
42
at car27 loc1
at car27 loc10
at car27 loc11
at car27 loc12
at car27 loc13
at car27 loc14
at car27 loc15
at car27 loc16
at car27 loc17
at car27 loc18
at car27 loc19
at car27 loc2
at car27 loc20
at car27 loc21
at car27 loc22
at car27 loc23
at car27 loc24
at car27 loc25
at car27 loc26
at car27 loc27
at car27 loc28
at car27 loc29
at car27 loc3
at car27 loc30
at car27 loc31
at car27 loc32
at car27 loc33
at car27 loc34
at car27 loc35
at car27 loc36
at car27 loc37
at car27 loc38
at car27 loc39
at car27 loc4
at car27 loc40
at car27 loc41
at car27 loc5
at car27 loc6
at car27 loc7
at car27 loc8
at car27 loc9
none-of-those
end_variable
begin_variable
var16
-1
42
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc24
at car5 loc25
at car5 loc26
at car5 loc27
at car5 loc28
at car5 loc29
at car5 loc3
at car5 loc30
at car5 loc31
at car5 loc32
at car5 loc33
at car5 loc34
at car5 loc35
at car5 loc36
at car5 loc37
at car5 loc38
at car5 loc39
at car5 loc4
at car5 loc40
at car5 loc41
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
none-of-those
end_variable
begin_variable
var17
-1
42
at car72 loc1
at car72 loc10
at car72 loc11
at car72 loc12
at car72 loc13
at car72 loc14
at car72 loc15
at car72 loc16
at car72 loc17
at car72 loc18
at car72 loc19
at car72 loc2
at car72 loc20
at car72 loc21
at car72 loc22
at car72 loc23
at car72 loc24
at car72 loc25
at car72 loc26
at car72 loc27
at car72 loc28
at car72 loc29
at car72 loc3
at car72 loc30
at car72 loc31
at car72 loc32
at car72 loc33
at car72 loc34
at car72 loc35
at car72 loc36
at car72 loc37
at car72 loc38
at car72 loc39
at car72 loc4
at car72 loc40
at car72 loc41
at car72 loc5
at car72 loc6
at car72 loc7
at car72 loc8
at car72 loc9
none-of-those
end_variable
begin_variable
var18
-1
42
at car21 loc1
at car21 loc10
at car21 loc11
at car21 loc12
at car21 loc13
at car21 loc14
at car21 loc15
at car21 loc16
at car21 loc17
at car21 loc18
at car21 loc19
at car21 loc2
at car21 loc20
at car21 loc21
at car21 loc22
at car21 loc23
at car21 loc24
at car21 loc25
at car21 loc26
at car21 loc27
at car21 loc28
at car21 loc29
at car21 loc3
at car21 loc30
at car21 loc31
at car21 loc32
at car21 loc33
at car21 loc34
at car21 loc35
at car21 loc36
at car21 loc37
at car21 loc38
at car21 loc39
at car21 loc4
at car21 loc40
at car21 loc41
at car21 loc5
at car21 loc6
at car21 loc7
at car21 loc8
at car21 loc9
none-of-those
end_variable
begin_variable
var19
-1
42
at car44 loc1
at car44 loc10
at car44 loc11
at car44 loc12
at car44 loc13
at car44 loc14
at car44 loc15
at car44 loc16
at car44 loc17
at car44 loc18
at car44 loc19
at car44 loc2
at car44 loc20
at car44 loc21
at car44 loc22
at car44 loc23
at car44 loc24
at car44 loc25
at car44 loc26
at car44 loc27
at car44 loc28
at car44 loc29
at car44 loc3
at car44 loc30
at car44 loc31
at car44 loc32
at car44 loc33
at car44 loc34
at car44 loc35
at car44 loc36
at car44 loc37
at car44 loc38
at car44 loc39
at car44 loc4
at car44 loc40
at car44 loc41
at car44 loc5
at car44 loc6
at car44 loc7
at car44 loc8
at car44 loc9
none-of-those
end_variable
begin_variable
var20
-1
42
at car67 loc1
at car67 loc10
at car67 loc11
at car67 loc12
at car67 loc13
at car67 loc14
at car67 loc15
at car67 loc16
at car67 loc17
at car67 loc18
at car67 loc19
at car67 loc2
at car67 loc20
at car67 loc21
at car67 loc22
at car67 loc23
at car67 loc24
at car67 loc25
at car67 loc26
at car67 loc27
at car67 loc28
at car67 loc29
at car67 loc3
at car67 loc30
at car67 loc31
at car67 loc32
at car67 loc33
at car67 loc34
at car67 loc35
at car67 loc36
at car67 loc37
at car67 loc38
at car67 loc39
at car67 loc4
at car67 loc40
at car67 loc41
at car67 loc5
at car67 loc6
at car67 loc7
at car67 loc8
at car67 loc9
none-of-those
end_variable
begin_variable
var21
-1
42
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc24
at car16 loc25
at car16 loc26
at car16 loc27
at car16 loc28
at car16 loc29
at car16 loc3
at car16 loc30
at car16 loc31
at car16 loc32
at car16 loc33
at car16 loc34
at car16 loc35
at car16 loc36
at car16 loc37
at car16 loc38
at car16 loc39
at car16 loc4
at car16 loc40
at car16 loc41
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
none-of-those
end_variable
begin_variable
var22
-1
42
at car39 loc1
at car39 loc10
at car39 loc11
at car39 loc12
at car39 loc13
at car39 loc14
at car39 loc15
at car39 loc16
at car39 loc17
at car39 loc18
at car39 loc19
at car39 loc2
at car39 loc20
at car39 loc21
at car39 loc22
at car39 loc23
at car39 loc24
at car39 loc25
at car39 loc26
at car39 loc27
at car39 loc28
at car39 loc29
at car39 loc3
at car39 loc30
at car39 loc31
at car39 loc32
at car39 loc33
at car39 loc34
at car39 loc35
at car39 loc36
at car39 loc37
at car39 loc38
at car39 loc39
at car39 loc4
at car39 loc40
at car39 loc41
at car39 loc5
at car39 loc6
at car39 loc7
at car39 loc8
at car39 loc9
none-of-those
end_variable
begin_variable
var23
-1
42
at car61 loc1
at car61 loc10
at car61 loc11
at car61 loc12
at car61 loc13
at car61 loc14
at car61 loc15
at car61 loc16
at car61 loc17
at car61 loc18
at car61 loc19
at car61 loc2
at car61 loc20
at car61 loc21
at car61 loc22
at car61 loc23
at car61 loc24
at car61 loc25
at car61 loc26
at car61 loc27
at car61 loc28
at car61 loc29
at car61 loc3
at car61 loc30
at car61 loc31
at car61 loc32
at car61 loc33
at car61 loc34
at car61 loc35
at car61 loc36
at car61 loc37
at car61 loc38
at car61 loc39
at car61 loc4
at car61 loc40
at car61 loc41
at car61 loc5
at car61 loc6
at car61 loc7
at car61 loc8
at car61 loc9
none-of-those
end_variable
begin_variable
var24
-1
42
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc24
at car10 loc25
at car10 loc26
at car10 loc27
at car10 loc28
at car10 loc29
at car10 loc3
at car10 loc30
at car10 loc31
at car10 loc32
at car10 loc33
at car10 loc34
at car10 loc35
at car10 loc36
at car10 loc37
at car10 loc38
at car10 loc39
at car10 loc4
at car10 loc40
at car10 loc41
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
none-of-those
end_variable
begin_variable
var25
-1
42
at car33 loc1
at car33 loc10
at car33 loc11
at car33 loc12
at car33 loc13
at car33 loc14
at car33 loc15
at car33 loc16
at car33 loc17
at car33 loc18
at car33 loc19
at car33 loc2
at car33 loc20
at car33 loc21
at car33 loc22
at car33 loc23
at car33 loc24
at car33 loc25
at car33 loc26
at car33 loc27
at car33 loc28
at car33 loc29
at car33 loc3
at car33 loc30
at car33 loc31
at car33 loc32
at car33 loc33
at car33 loc34
at car33 loc35
at car33 loc36
at car33 loc37
at car33 loc38
at car33 loc39
at car33 loc4
at car33 loc40
at car33 loc41
at car33 loc5
at car33 loc6
at car33 loc7
at car33 loc8
at car33 loc9
none-of-those
end_variable
begin_variable
var26
-1
42
at car56 loc1
at car56 loc10
at car56 loc11
at car56 loc12
at car56 loc13
at car56 loc14
at car56 loc15
at car56 loc16
at car56 loc17
at car56 loc18
at car56 loc19
at car56 loc2
at car56 loc20
at car56 loc21
at car56 loc22
at car56 loc23
at car56 loc24
at car56 loc25
at car56 loc26
at car56 loc27
at car56 loc28
at car56 loc29
at car56 loc3
at car56 loc30
at car56 loc31
at car56 loc32
at car56 loc33
at car56 loc34
at car56 loc35
at car56 loc36
at car56 loc37
at car56 loc38
at car56 loc39
at car56 loc4
at car56 loc40
at car56 loc41
at car56 loc5
at car56 loc6
at car56 loc7
at car56 loc8
at car56 loc9
none-of-those
end_variable
begin_variable
var27
-1
42
at car28 loc1
at car28 loc10
at car28 loc11
at car28 loc12
at car28 loc13
at car28 loc14
at car28 loc15
at car28 loc16
at car28 loc17
at car28 loc18
at car28 loc19
at car28 loc2
at car28 loc20
at car28 loc21
at car28 loc22
at car28 loc23
at car28 loc24
at car28 loc25
at car28 loc26
at car28 loc27
at car28 loc28
at car28 loc29
at car28 loc3
at car28 loc30
at car28 loc31
at car28 loc32
at car28 loc33
at car28 loc34
at car28 loc35
at car28 loc36
at car28 loc37
at car28 loc38
at car28 loc39
at car28 loc4
at car28 loc40
at car28 loc41
at car28 loc5
at car28 loc6
at car28 loc7
at car28 loc8
at car28 loc9
none-of-those
end_variable
begin_variable
var28
-1
42
at car50 loc1
at car50 loc10
at car50 loc11
at car50 loc12
at car50 loc13
at car50 loc14
at car50 loc15
at car50 loc16
at car50 loc17
at car50 loc18
at car50 loc19
at car50 loc2
at car50 loc20
at car50 loc21
at car50 loc22
at car50 loc23
at car50 loc24
at car50 loc25
at car50 loc26
at car50 loc27
at car50 loc28
at car50 loc29
at car50 loc3
at car50 loc30
at car50 loc31
at car50 loc32
at car50 loc33
at car50 loc34
at car50 loc35
at car50 loc36
at car50 loc37
at car50 loc38
at car50 loc39
at car50 loc4
at car50 loc40
at car50 loc41
at car50 loc5
at car50 loc6
at car50 loc7
at car50 loc8
at car50 loc9
none-of-those
end_variable
begin_variable
var29
-1
42
at car73 loc1
at car73 loc10
at car73 loc11
at car73 loc12
at car73 loc13
at car73 loc14
at car73 loc15
at car73 loc16
at car73 loc17
at car73 loc18
at car73 loc19
at car73 loc2
at car73 loc20
at car73 loc21
at car73 loc22
at car73 loc23
at car73 loc24
at car73 loc25
at car73 loc26
at car73 loc27
at car73 loc28
at car73 loc29
at car73 loc3
at car73 loc30
at car73 loc31
at car73 loc32
at car73 loc33
at car73 loc34
at car73 loc35
at car73 loc36
at car73 loc37
at car73 loc38
at car73 loc39
at car73 loc4
at car73 loc40
at car73 loc41
at car73 loc5
at car73 loc6
at car73 loc7
at car73 loc8
at car73 loc9
none-of-those
end_variable
begin_variable
var30
-1
42
at car22 loc1
at car22 loc10
at car22 loc11
at car22 loc12
at car22 loc13
at car22 loc14
at car22 loc15
at car22 loc16
at car22 loc17
at car22 loc18
at car22 loc19
at car22 loc2
at car22 loc20
at car22 loc21
at car22 loc22
at car22 loc23
at car22 loc24
at car22 loc25
at car22 loc26
at car22 loc27
at car22 loc28
at car22 loc29
at car22 loc3
at car22 loc30
at car22 loc31
at car22 loc32
at car22 loc33
at car22 loc34
at car22 loc35
at car22 loc36
at car22 loc37
at car22 loc38
at car22 loc39
at car22 loc4
at car22 loc40
at car22 loc41
at car22 loc5
at car22 loc6
at car22 loc7
at car22 loc8
at car22 loc9
none-of-those
end_variable
begin_variable
var31
-1
42
at car45 loc1
at car45 loc10
at car45 loc11
at car45 loc12
at car45 loc13
at car45 loc14
at car45 loc15
at car45 loc16
at car45 loc17
at car45 loc18
at car45 loc19
at car45 loc2
at car45 loc20
at car45 loc21
at car45 loc22
at car45 loc23
at car45 loc24
at car45 loc25
at car45 loc26
at car45 loc27
at car45 loc28
at car45 loc29
at car45 loc3
at car45 loc30
at car45 loc31
at car45 loc32
at car45 loc33
at car45 loc34
at car45 loc35
at car45 loc36
at car45 loc37
at car45 loc38
at car45 loc39
at car45 loc4
at car45 loc40
at car45 loc41
at car45 loc5
at car45 loc6
at car45 loc7
at car45 loc8
at car45 loc9
none-of-those
end_variable
begin_variable
var32
-1
42
at car68 loc1
at car68 loc10
at car68 loc11
at car68 loc12
at car68 loc13
at car68 loc14
at car68 loc15
at car68 loc16
at car68 loc17
at car68 loc18
at car68 loc19
at car68 loc2
at car68 loc20
at car68 loc21
at car68 loc22
at car68 loc23
at car68 loc24
at car68 loc25
at car68 loc26
at car68 loc27
at car68 loc28
at car68 loc29
at car68 loc3
at car68 loc30
at car68 loc31
at car68 loc32
at car68 loc33
at car68 loc34
at car68 loc35
at car68 loc36
at car68 loc37
at car68 loc38
at car68 loc39
at car68 loc4
at car68 loc40
at car68 loc41
at car68 loc5
at car68 loc6
at car68 loc7
at car68 loc8
at car68 loc9
none-of-those
end_variable
begin_variable
var33
-1
42
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc24
at car17 loc25
at car17 loc26
at car17 loc27
at car17 loc28
at car17 loc29
at car17 loc3
at car17 loc30
at car17 loc31
at car17 loc32
at car17 loc33
at car17 loc34
at car17 loc35
at car17 loc36
at car17 loc37
at car17 loc38
at car17 loc39
at car17 loc4
at car17 loc40
at car17 loc41
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
none-of-those
end_variable
begin_variable
var34
-1
42
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc24
at car4 loc25
at car4 loc26
at car4 loc27
at car4 loc28
at car4 loc29
at car4 loc3
at car4 loc30
at car4 loc31
at car4 loc32
at car4 loc33
at car4 loc34
at car4 loc35
at car4 loc36
at car4 loc37
at car4 loc38
at car4 loc39
at car4 loc4
at car4 loc40
at car4 loc41
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
none-of-those
end_variable
begin_variable
var35
-1
42
at car62 loc1
at car62 loc10
at car62 loc11
at car62 loc12
at car62 loc13
at car62 loc14
at car62 loc15
at car62 loc16
at car62 loc17
at car62 loc18
at car62 loc19
at car62 loc2
at car62 loc20
at car62 loc21
at car62 loc22
at car62 loc23
at car62 loc24
at car62 loc25
at car62 loc26
at car62 loc27
at car62 loc28
at car62 loc29
at car62 loc3
at car62 loc30
at car62 loc31
at car62 loc32
at car62 loc33
at car62 loc34
at car62 loc35
at car62 loc36
at car62 loc37
at car62 loc38
at car62 loc39
at car62 loc4
at car62 loc40
at car62 loc41
at car62 loc5
at car62 loc6
at car62 loc7
at car62 loc8
at car62 loc9
none-of-those
end_variable
begin_variable
var36
-1
42
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc24
at car11 loc25
at car11 loc26
at car11 loc27
at car11 loc28
at car11 loc29
at car11 loc3
at car11 loc30
at car11 loc31
at car11 loc32
at car11 loc33
at car11 loc34
at car11 loc35
at car11 loc36
at car11 loc37
at car11 loc38
at car11 loc39
at car11 loc4
at car11 loc40
at car11 loc41
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
none-of-those
end_variable
begin_variable
var37
-1
42
at car34 loc1
at car34 loc10
at car34 loc11
at car34 loc12
at car34 loc13
at car34 loc14
at car34 loc15
at car34 loc16
at car34 loc17
at car34 loc18
at car34 loc19
at car34 loc2
at car34 loc20
at car34 loc21
at car34 loc22
at car34 loc23
at car34 loc24
at car34 loc25
at car34 loc26
at car34 loc27
at car34 loc28
at car34 loc29
at car34 loc3
at car34 loc30
at car34 loc31
at car34 loc32
at car34 loc33
at car34 loc34
at car34 loc35
at car34 loc36
at car34 loc37
at car34 loc38
at car34 loc39
at car34 loc4
at car34 loc40
at car34 loc41
at car34 loc5
at car34 loc6
at car34 loc7
at car34 loc8
at car34 loc9
none-of-those
end_variable
begin_variable
var38
-1
42
at car57 loc1
at car57 loc10
at car57 loc11
at car57 loc12
at car57 loc13
at car57 loc14
at car57 loc15
at car57 loc16
at car57 loc17
at car57 loc18
at car57 loc19
at car57 loc2
at car57 loc20
at car57 loc21
at car57 loc22
at car57 loc23
at car57 loc24
at car57 loc25
at car57 loc26
at car57 loc27
at car57 loc28
at car57 loc29
at car57 loc3
at car57 loc30
at car57 loc31
at car57 loc32
at car57 loc33
at car57 loc34
at car57 loc35
at car57 loc36
at car57 loc37
at car57 loc38
at car57 loc39
at car57 loc4
at car57 loc40
at car57 loc41
at car57 loc5
at car57 loc6
at car57 loc7
at car57 loc8
at car57 loc9
none-of-those
end_variable
begin_variable
var39
-1
42
at car29 loc1
at car29 loc10
at car29 loc11
at car29 loc12
at car29 loc13
at car29 loc14
at car29 loc15
at car29 loc16
at car29 loc17
at car29 loc18
at car29 loc19
at car29 loc2
at car29 loc20
at car29 loc21
at car29 loc22
at car29 loc23
at car29 loc24
at car29 loc25
at car29 loc26
at car29 loc27
at car29 loc28
at car29 loc29
at car29 loc3
at car29 loc30
at car29 loc31
at car29 loc32
at car29 loc33
at car29 loc34
at car29 loc35
at car29 loc36
at car29 loc37
at car29 loc38
at car29 loc39
at car29 loc4
at car29 loc40
at car29 loc41
at car29 loc5
at car29 loc6
at car29 loc7
at car29 loc8
at car29 loc9
none-of-those
end_variable
begin_variable
var40
-1
42
at car51 loc1
at car51 loc10
at car51 loc11
at car51 loc12
at car51 loc13
at car51 loc14
at car51 loc15
at car51 loc16
at car51 loc17
at car51 loc18
at car51 loc19
at car51 loc2
at car51 loc20
at car51 loc21
at car51 loc22
at car51 loc23
at car51 loc24
at car51 loc25
at car51 loc26
at car51 loc27
at car51 loc28
at car51 loc29
at car51 loc3
at car51 loc30
at car51 loc31
at car51 loc32
at car51 loc33
at car51 loc34
at car51 loc35
at car51 loc36
at car51 loc37
at car51 loc38
at car51 loc39
at car51 loc4
at car51 loc40
at car51 loc41
at car51 loc5
at car51 loc6
at car51 loc7
at car51 loc8
at car51 loc9
none-of-those
end_variable
begin_variable
var41
-1
42
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc24
at car8 loc25
at car8 loc26
at car8 loc27
at car8 loc28
at car8 loc29
at car8 loc3
at car8 loc30
at car8 loc31
at car8 loc32
at car8 loc33
at car8 loc34
at car8 loc35
at car8 loc36
at car8 loc37
at car8 loc38
at car8 loc39
at car8 loc4
at car8 loc40
at car8 loc41
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
none-of-those
end_variable
begin_variable
var42
-1
42
at car23 loc1
at car23 loc10
at car23 loc11
at car23 loc12
at car23 loc13
at car23 loc14
at car23 loc15
at car23 loc16
at car23 loc17
at car23 loc18
at car23 loc19
at car23 loc2
at car23 loc20
at car23 loc21
at car23 loc22
at car23 loc23
at car23 loc24
at car23 loc25
at car23 loc26
at car23 loc27
at car23 loc28
at car23 loc29
at car23 loc3
at car23 loc30
at car23 loc31
at car23 loc32
at car23 loc33
at car23 loc34
at car23 loc35
at car23 loc36
at car23 loc37
at car23 loc38
at car23 loc39
at car23 loc4
at car23 loc40
at car23 loc41
at car23 loc5
at car23 loc6
at car23 loc7
at car23 loc8
at car23 loc9
none-of-those
end_variable
begin_variable
var43
-1
42
at car46 loc1
at car46 loc10
at car46 loc11
at car46 loc12
at car46 loc13
at car46 loc14
at car46 loc15
at car46 loc16
at car46 loc17
at car46 loc18
at car46 loc19
at car46 loc2
at car46 loc20
at car46 loc21
at car46 loc22
at car46 loc23
at car46 loc24
at car46 loc25
at car46 loc26
at car46 loc27
at car46 loc28
at car46 loc29
at car46 loc3
at car46 loc30
at car46 loc31
at car46 loc32
at car46 loc33
at car46 loc34
at car46 loc35
at car46 loc36
at car46 loc37
at car46 loc38
at car46 loc39
at car46 loc4
at car46 loc40
at car46 loc41
at car46 loc5
at car46 loc6
at car46 loc7
at car46 loc8
at car46 loc9
none-of-those
end_variable
begin_variable
var44
-1
42
at car69 loc1
at car69 loc10
at car69 loc11
at car69 loc12
at car69 loc13
at car69 loc14
at car69 loc15
at car69 loc16
at car69 loc17
at car69 loc18
at car69 loc19
at car69 loc2
at car69 loc20
at car69 loc21
at car69 loc22
at car69 loc23
at car69 loc24
at car69 loc25
at car69 loc26
at car69 loc27
at car69 loc28
at car69 loc29
at car69 loc3
at car69 loc30
at car69 loc31
at car69 loc32
at car69 loc33
at car69 loc34
at car69 loc35
at car69 loc36
at car69 loc37
at car69 loc38
at car69 loc39
at car69 loc4
at car69 loc40
at car69 loc41
at car69 loc5
at car69 loc6
at car69 loc7
at car69 loc8
at car69 loc9
none-of-those
end_variable
begin_variable
var45
-1
42
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc24
at car18 loc25
at car18 loc26
at car18 loc27
at car18 loc28
at car18 loc29
at car18 loc3
at car18 loc30
at car18 loc31
at car18 loc32
at car18 loc33
at car18 loc34
at car18 loc35
at car18 loc36
at car18 loc37
at car18 loc38
at car18 loc39
at car18 loc4
at car18 loc40
at car18 loc41
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
none-of-those
end_variable
begin_variable
var46
-1
42
at car40 loc1
at car40 loc10
at car40 loc11
at car40 loc12
at car40 loc13
at car40 loc14
at car40 loc15
at car40 loc16
at car40 loc17
at car40 loc18
at car40 loc19
at car40 loc2
at car40 loc20
at car40 loc21
at car40 loc22
at car40 loc23
at car40 loc24
at car40 loc25
at car40 loc26
at car40 loc27
at car40 loc28
at car40 loc29
at car40 loc3
at car40 loc30
at car40 loc31
at car40 loc32
at car40 loc33
at car40 loc34
at car40 loc35
at car40 loc36
at car40 loc37
at car40 loc38
at car40 loc39
at car40 loc4
at car40 loc40
at car40 loc41
at car40 loc5
at car40 loc6
at car40 loc7
at car40 loc8
at car40 loc9
none-of-those
end_variable
begin_variable
var47
-1
42
at car63 loc1
at car63 loc10
at car63 loc11
at car63 loc12
at car63 loc13
at car63 loc14
at car63 loc15
at car63 loc16
at car63 loc17
at car63 loc18
at car63 loc19
at car63 loc2
at car63 loc20
at car63 loc21
at car63 loc22
at car63 loc23
at car63 loc24
at car63 loc25
at car63 loc26
at car63 loc27
at car63 loc28
at car63 loc29
at car63 loc3
at car63 loc30
at car63 loc31
at car63 loc32
at car63 loc33
at car63 loc34
at car63 loc35
at car63 loc36
at car63 loc37
at car63 loc38
at car63 loc39
at car63 loc4
at car63 loc40
at car63 loc41
at car63 loc5
at car63 loc6
at car63 loc7
at car63 loc8
at car63 loc9
none-of-those
end_variable
begin_variable
var48
-1
42
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc24
at car12 loc25
at car12 loc26
at car12 loc27
at car12 loc28
at car12 loc29
at car12 loc3
at car12 loc30
at car12 loc31
at car12 loc32
at car12 loc33
at car12 loc34
at car12 loc35
at car12 loc36
at car12 loc37
at car12 loc38
at car12 loc39
at car12 loc4
at car12 loc40
at car12 loc41
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
none-of-those
end_variable
begin_variable
var49
-1
42
at car35 loc1
at car35 loc10
at car35 loc11
at car35 loc12
at car35 loc13
at car35 loc14
at car35 loc15
at car35 loc16
at car35 loc17
at car35 loc18
at car35 loc19
at car35 loc2
at car35 loc20
at car35 loc21
at car35 loc22
at car35 loc23
at car35 loc24
at car35 loc25
at car35 loc26
at car35 loc27
at car35 loc28
at car35 loc29
at car35 loc3
at car35 loc30
at car35 loc31
at car35 loc32
at car35 loc33
at car35 loc34
at car35 loc35
at car35 loc36
at car35 loc37
at car35 loc38
at car35 loc39
at car35 loc4
at car35 loc40
at car35 loc41
at car35 loc5
at car35 loc6
at car35 loc7
at car35 loc8
at car35 loc9
none-of-those
end_variable
begin_variable
var50
-1
42
at car58 loc1
at car58 loc10
at car58 loc11
at car58 loc12
at car58 loc13
at car58 loc14
at car58 loc15
at car58 loc16
at car58 loc17
at car58 loc18
at car58 loc19
at car58 loc2
at car58 loc20
at car58 loc21
at car58 loc22
at car58 loc23
at car58 loc24
at car58 loc25
at car58 loc26
at car58 loc27
at car58 loc28
at car58 loc29
at car58 loc3
at car58 loc30
at car58 loc31
at car58 loc32
at car58 loc33
at car58 loc34
at car58 loc35
at car58 loc36
at car58 loc37
at car58 loc38
at car58 loc39
at car58 loc4
at car58 loc40
at car58 loc41
at car58 loc5
at car58 loc6
at car58 loc7
at car58 loc8
at car58 loc9
none-of-those
end_variable
begin_variable
var51
-1
42
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc24
at car3 loc25
at car3 loc26
at car3 loc27
at car3 loc28
at car3 loc29
at car3 loc3
at car3 loc30
at car3 loc31
at car3 loc32
at car3 loc33
at car3 loc34
at car3 loc35
at car3 loc36
at car3 loc37
at car3 loc38
at car3 loc39
at car3 loc4
at car3 loc40
at car3 loc41
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
none-of-those
end_variable
begin_variable
var52
-1
42
at car52 loc1
at car52 loc10
at car52 loc11
at car52 loc12
at car52 loc13
at car52 loc14
at car52 loc15
at car52 loc16
at car52 loc17
at car52 loc18
at car52 loc19
at car52 loc2
at car52 loc20
at car52 loc21
at car52 loc22
at car52 loc23
at car52 loc24
at car52 loc25
at car52 loc26
at car52 loc27
at car52 loc28
at car52 loc29
at car52 loc3
at car52 loc30
at car52 loc31
at car52 loc32
at car52 loc33
at car52 loc34
at car52 loc35
at car52 loc36
at car52 loc37
at car52 loc38
at car52 loc39
at car52 loc4
at car52 loc40
at car52 loc41
at car52 loc5
at car52 loc6
at car52 loc7
at car52 loc8
at car52 loc9
none-of-those
end_variable
begin_variable
var53
-1
42
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc24
at car9 loc25
at car9 loc26
at car9 loc27
at car9 loc28
at car9 loc29
at car9 loc3
at car9 loc30
at car9 loc31
at car9 loc32
at car9 loc33
at car9 loc34
at car9 loc35
at car9 loc36
at car9 loc37
at car9 loc38
at car9 loc39
at car9 loc4
at car9 loc40
at car9 loc41
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
none-of-those
end_variable
begin_variable
var54
-1
42
at car24 loc1
at car24 loc10
at car24 loc11
at car24 loc12
at car24 loc13
at car24 loc14
at car24 loc15
at car24 loc16
at car24 loc17
at car24 loc18
at car24 loc19
at car24 loc2
at car24 loc20
at car24 loc21
at car24 loc22
at car24 loc23
at car24 loc24
at car24 loc25
at car24 loc26
at car24 loc27
at car24 loc28
at car24 loc29
at car24 loc3
at car24 loc30
at car24 loc31
at car24 loc32
at car24 loc33
at car24 loc34
at car24 loc35
at car24 loc36
at car24 loc37
at car24 loc38
at car24 loc39
at car24 loc4
at car24 loc40
at car24 loc41
at car24 loc5
at car24 loc6
at car24 loc7
at car24 loc8
at car24 loc9
none-of-those
end_variable
begin_variable
var55
-1
42
at car47 loc1
at car47 loc10
at car47 loc11
at car47 loc12
at car47 loc13
at car47 loc14
at car47 loc15
at car47 loc16
at car47 loc17
at car47 loc18
at car47 loc19
at car47 loc2
at car47 loc20
at car47 loc21
at car47 loc22
at car47 loc23
at car47 loc24
at car47 loc25
at car47 loc26
at car47 loc27
at car47 loc28
at car47 loc29
at car47 loc3
at car47 loc30
at car47 loc31
at car47 loc32
at car47 loc33
at car47 loc34
at car47 loc35
at car47 loc36
at car47 loc37
at car47 loc38
at car47 loc39
at car47 loc4
at car47 loc40
at car47 loc41
at car47 loc5
at car47 loc6
at car47 loc7
at car47 loc8
at car47 loc9
none-of-those
end_variable
begin_variable
var56
-1
42
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc24
at car7 loc25
at car7 loc26
at car7 loc27
at car7 loc28
at car7 loc29
at car7 loc3
at car7 loc30
at car7 loc31
at car7 loc32
at car7 loc33
at car7 loc34
at car7 loc35
at car7 loc36
at car7 loc37
at car7 loc38
at car7 loc39
at car7 loc4
at car7 loc40
at car7 loc41
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
none-of-those
end_variable
begin_variable
var57
-1
42
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc24
at car19 loc25
at car19 loc26
at car19 loc27
at car19 loc28
at car19 loc29
at car19 loc3
at car19 loc30
at car19 loc31
at car19 loc32
at car19 loc33
at car19 loc34
at car19 loc35
at car19 loc36
at car19 loc37
at car19 loc38
at car19 loc39
at car19 loc4
at car19 loc40
at car19 loc41
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
none-of-those
end_variable
begin_variable
var58
-1
42
at car41 loc1
at car41 loc10
at car41 loc11
at car41 loc12
at car41 loc13
at car41 loc14
at car41 loc15
at car41 loc16
at car41 loc17
at car41 loc18
at car41 loc19
at car41 loc2
at car41 loc20
at car41 loc21
at car41 loc22
at car41 loc23
at car41 loc24
at car41 loc25
at car41 loc26
at car41 loc27
at car41 loc28
at car41 loc29
at car41 loc3
at car41 loc30
at car41 loc31
at car41 loc32
at car41 loc33
at car41 loc34
at car41 loc35
at car41 loc36
at car41 loc37
at car41 loc38
at car41 loc39
at car41 loc4
at car41 loc40
at car41 loc41
at car41 loc5
at car41 loc6
at car41 loc7
at car41 loc8
at car41 loc9
none-of-those
end_variable
begin_variable
var59
-1
42
at car64 loc1
at car64 loc10
at car64 loc11
at car64 loc12
at car64 loc13
at car64 loc14
at car64 loc15
at car64 loc16
at car64 loc17
at car64 loc18
at car64 loc19
at car64 loc2
at car64 loc20
at car64 loc21
at car64 loc22
at car64 loc23
at car64 loc24
at car64 loc25
at car64 loc26
at car64 loc27
at car64 loc28
at car64 loc29
at car64 loc3
at car64 loc30
at car64 loc31
at car64 loc32
at car64 loc33
at car64 loc34
at car64 loc35
at car64 loc36
at car64 loc37
at car64 loc38
at car64 loc39
at car64 loc4
at car64 loc40
at car64 loc41
at car64 loc5
at car64 loc6
at car64 loc7
at car64 loc8
at car64 loc9
none-of-those
end_variable
begin_variable
var60
-1
42
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc24
at car13 loc25
at car13 loc26
at car13 loc27
at car13 loc28
at car13 loc29
at car13 loc3
at car13 loc30
at car13 loc31
at car13 loc32
at car13 loc33
at car13 loc34
at car13 loc35
at car13 loc36
at car13 loc37
at car13 loc38
at car13 loc39
at car13 loc4
at car13 loc40
at car13 loc41
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
none-of-those
end_variable
begin_variable
var61
-1
42
at car36 loc1
at car36 loc10
at car36 loc11
at car36 loc12
at car36 loc13
at car36 loc14
at car36 loc15
at car36 loc16
at car36 loc17
at car36 loc18
at car36 loc19
at car36 loc2
at car36 loc20
at car36 loc21
at car36 loc22
at car36 loc23
at car36 loc24
at car36 loc25
at car36 loc26
at car36 loc27
at car36 loc28
at car36 loc29
at car36 loc3
at car36 loc30
at car36 loc31
at car36 loc32
at car36 loc33
at car36 loc34
at car36 loc35
at car36 loc36
at car36 loc37
at car36 loc38
at car36 loc39
at car36 loc4
at car36 loc40
at car36 loc41
at car36 loc5
at car36 loc6
at car36 loc7
at car36 loc8
at car36 loc9
none-of-those
end_variable
begin_variable
var62
-1
42
at car59 loc1
at car59 loc10
at car59 loc11
at car59 loc12
at car59 loc13
at car59 loc14
at car59 loc15
at car59 loc16
at car59 loc17
at car59 loc18
at car59 loc19
at car59 loc2
at car59 loc20
at car59 loc21
at car59 loc22
at car59 loc23
at car59 loc24
at car59 loc25
at car59 loc26
at car59 loc27
at car59 loc28
at car59 loc29
at car59 loc3
at car59 loc30
at car59 loc31
at car59 loc32
at car59 loc33
at car59 loc34
at car59 loc35
at car59 loc36
at car59 loc37
at car59 loc38
at car59 loc39
at car59 loc4
at car59 loc40
at car59 loc41
at car59 loc5
at car59 loc6
at car59 loc7
at car59 loc8
at car59 loc9
none-of-those
end_variable
begin_variable
var63
-1
42
at car30 loc1
at car30 loc10
at car30 loc11
at car30 loc12
at car30 loc13
at car30 loc14
at car30 loc15
at car30 loc16
at car30 loc17
at car30 loc18
at car30 loc19
at car30 loc2
at car30 loc20
at car30 loc21
at car30 loc22
at car30 loc23
at car30 loc24
at car30 loc25
at car30 loc26
at car30 loc27
at car30 loc28
at car30 loc29
at car30 loc3
at car30 loc30
at car30 loc31
at car30 loc32
at car30 loc33
at car30 loc34
at car30 loc35
at car30 loc36
at car30 loc37
at car30 loc38
at car30 loc39
at car30 loc4
at car30 loc40
at car30 loc41
at car30 loc5
at car30 loc6
at car30 loc7
at car30 loc8
at car30 loc9
none-of-those
end_variable
begin_variable
var64
-1
42
at car53 loc1
at car53 loc10
at car53 loc11
at car53 loc12
at car53 loc13
at car53 loc14
at car53 loc15
at car53 loc16
at car53 loc17
at car53 loc18
at car53 loc19
at car53 loc2
at car53 loc20
at car53 loc21
at car53 loc22
at car53 loc23
at car53 loc24
at car53 loc25
at car53 loc26
at car53 loc27
at car53 loc28
at car53 loc29
at car53 loc3
at car53 loc30
at car53 loc31
at car53 loc32
at car53 loc33
at car53 loc34
at car53 loc35
at car53 loc36
at car53 loc37
at car53 loc38
at car53 loc39
at car53 loc4
at car53 loc40
at car53 loc41
at car53 loc5
at car53 loc6
at car53 loc7
at car53 loc8
at car53 loc9
none-of-those
end_variable
begin_variable
var65
-1
41
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc24
at-ferry loc25
at-ferry loc26
at-ferry loc27
at-ferry loc28
at-ferry loc29
at-ferry loc3
at-ferry loc30
at-ferry loc31
at-ferry loc32
at-ferry loc33
at-ferry loc34
at-ferry loc35
at-ferry loc36
at-ferry loc37
at-ferry loc38
at-ferry loc39
at-ferry loc4
at-ferry loc40
at-ferry loc41
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var66
-1
42
at car25 loc1
at car25 loc10
at car25 loc11
at car25 loc12
at car25 loc13
at car25 loc14
at car25 loc15
at car25 loc16
at car25 loc17
at car25 loc18
at car25 loc19
at car25 loc2
at car25 loc20
at car25 loc21
at car25 loc22
at car25 loc23
at car25 loc24
at car25 loc25
at car25 loc26
at car25 loc27
at car25 loc28
at car25 loc29
at car25 loc3
at car25 loc30
at car25 loc31
at car25 loc32
at car25 loc33
at car25 loc34
at car25 loc35
at car25 loc36
at car25 loc37
at car25 loc38
at car25 loc39
at car25 loc4
at car25 loc40
at car25 loc41
at car25 loc5
at car25 loc6
at car25 loc7
at car25 loc8
at car25 loc9
none-of-those
end_variable
begin_variable
var67
-1
42
at car48 loc1
at car48 loc10
at car48 loc11
at car48 loc12
at car48 loc13
at car48 loc14
at car48 loc15
at car48 loc16
at car48 loc17
at car48 loc18
at car48 loc19
at car48 loc2
at car48 loc20
at car48 loc21
at car48 loc22
at car48 loc23
at car48 loc24
at car48 loc25
at car48 loc26
at car48 loc27
at car48 loc28
at car48 loc29
at car48 loc3
at car48 loc30
at car48 loc31
at car48 loc32
at car48 loc33
at car48 loc34
at car48 loc35
at car48 loc36
at car48 loc37
at car48 loc38
at car48 loc39
at car48 loc4
at car48 loc40
at car48 loc41
at car48 loc5
at car48 loc6
at car48 loc7
at car48 loc8
at car48 loc9
none-of-those
end_variable
begin_variable
var68
-1
42
at car70 loc1
at car70 loc10
at car70 loc11
at car70 loc12
at car70 loc13
at car70 loc14
at car70 loc15
at car70 loc16
at car70 loc17
at car70 loc18
at car70 loc19
at car70 loc2
at car70 loc20
at car70 loc21
at car70 loc22
at car70 loc23
at car70 loc24
at car70 loc25
at car70 loc26
at car70 loc27
at car70 loc28
at car70 loc29
at car70 loc3
at car70 loc30
at car70 loc31
at car70 loc32
at car70 loc33
at car70 loc34
at car70 loc35
at car70 loc36
at car70 loc37
at car70 loc38
at car70 loc39
at car70 loc4
at car70 loc40
at car70 loc41
at car70 loc5
at car70 loc6
at car70 loc7
at car70 loc8
at car70 loc9
none-of-those
end_variable
begin_variable
var69
-1
42
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc24
at car2 loc25
at car2 loc26
at car2 loc27
at car2 loc28
at car2 loc29
at car2 loc3
at car2 loc30
at car2 loc31
at car2 loc32
at car2 loc33
at car2 loc34
at car2 loc35
at car2 loc36
at car2 loc37
at car2 loc38
at car2 loc39
at car2 loc4
at car2 loc40
at car2 loc41
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
none-of-those
end_variable
begin_variable
var70
-1
42
at car42 loc1
at car42 loc10
at car42 loc11
at car42 loc12
at car42 loc13
at car42 loc14
at car42 loc15
at car42 loc16
at car42 loc17
at car42 loc18
at car42 loc19
at car42 loc2
at car42 loc20
at car42 loc21
at car42 loc22
at car42 loc23
at car42 loc24
at car42 loc25
at car42 loc26
at car42 loc27
at car42 loc28
at car42 loc29
at car42 loc3
at car42 loc30
at car42 loc31
at car42 loc32
at car42 loc33
at car42 loc34
at car42 loc35
at car42 loc36
at car42 loc37
at car42 loc38
at car42 loc39
at car42 loc4
at car42 loc40
at car42 loc41
at car42 loc5
at car42 loc6
at car42 loc7
at car42 loc8
at car42 loc9
none-of-those
end_variable
begin_variable
var71
-1
42
at car65 loc1
at car65 loc10
at car65 loc11
at car65 loc12
at car65 loc13
at car65 loc14
at car65 loc15
at car65 loc16
at car65 loc17
at car65 loc18
at car65 loc19
at car65 loc2
at car65 loc20
at car65 loc21
at car65 loc22
at car65 loc23
at car65 loc24
at car65 loc25
at car65 loc26
at car65 loc27
at car65 loc28
at car65 loc29
at car65 loc3
at car65 loc30
at car65 loc31
at car65 loc32
at car65 loc33
at car65 loc34
at car65 loc35
at car65 loc36
at car65 loc37
at car65 loc38
at car65 loc39
at car65 loc4
at car65 loc40
at car65 loc41
at car65 loc5
at car65 loc6
at car65 loc7
at car65 loc8
at car65 loc9
none-of-those
end_variable
begin_variable
var72
-1
42
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc24
at car14 loc25
at car14 loc26
at car14 loc27
at car14 loc28
at car14 loc29
at car14 loc3
at car14 loc30
at car14 loc31
at car14 loc32
at car14 loc33
at car14 loc34
at car14 loc35
at car14 loc36
at car14 loc37
at car14 loc38
at car14 loc39
at car14 loc4
at car14 loc40
at car14 loc41
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
none-of-those
end_variable
begin_variable
var73
-1
42
at car37 loc1
at car37 loc10
at car37 loc11
at car37 loc12
at car37 loc13
at car37 loc14
at car37 loc15
at car37 loc16
at car37 loc17
at car37 loc18
at car37 loc19
at car37 loc2
at car37 loc20
at car37 loc21
at car37 loc22
at car37 loc23
at car37 loc24
at car37 loc25
at car37 loc26
at car37 loc27
at car37 loc28
at car37 loc29
at car37 loc3
at car37 loc30
at car37 loc31
at car37 loc32
at car37 loc33
at car37 loc34
at car37 loc35
at car37 loc36
at car37 loc37
at car37 loc38
at car37 loc39
at car37 loc4
at car37 loc40
at car37 loc41
at car37 loc5
at car37 loc6
at car37 loc7
at car37 loc8
at car37 loc9
none-of-those
end_variable
begin_variable
var74
-1
42
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc24
at car6 loc25
at car6 loc26
at car6 loc27
at car6 loc28
at car6 loc29
at car6 loc3
at car6 loc30
at car6 loc31
at car6 loc32
at car6 loc33
at car6 loc34
at car6 loc35
at car6 loc36
at car6 loc37
at car6 loc38
at car6 loc39
at car6 loc4
at car6 loc40
at car6 loc41
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
none-of-those
end_variable
begin_variable
var75
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var76
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var77
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var78
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var79
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var80
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var81
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var82
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var83
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var84
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var85
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var86
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var87
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var88
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var89
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var90
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var91
-1
2
NOT-at-ferry loc24
none-of-those
end_variable
begin_variable
var92
-1
2
NOT-at-ferry loc25
none-of-those
end_variable
begin_variable
var93
-1
2
NOT-at-ferry loc26
none-of-those
end_variable
begin_variable
var94
-1
2
NOT-at-ferry loc27
none-of-those
end_variable
begin_variable
var95
-1
2
NOT-at-ferry loc28
none-of-those
end_variable
begin_variable
var96
-1
2
NOT-at-ferry loc29
none-of-those
end_variable
begin_variable
var97
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var98
-1
2
NOT-at-ferry loc30
none-of-those
end_variable
begin_variable
var99
-1
2
NOT-at-ferry loc31
none-of-those
end_variable
begin_variable
var100
-1
2
NOT-at-ferry loc32
none-of-those
end_variable
begin_variable
var101
-1
2
NOT-at-ferry loc33
none-of-those
end_variable
begin_variable
var102
-1
2
NOT-at-ferry loc34
none-of-those
end_variable
begin_variable
var103
-1
2
NOT-at-ferry loc35
none-of-those
end_variable
begin_variable
var104
-1
2
NOT-at-ferry loc36
none-of-those
end_variable
begin_variable
var105
-1
2
NOT-at-ferry loc37
none-of-those
end_variable
begin_variable
var106
-1
2
NOT-at-ferry loc38
none-of-those
end_variable
begin_variable
var107
-1
2
NOT-at-ferry loc39
none-of-those
end_variable
begin_variable
var108
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var109
-1
2
NOT-at-ferry loc40
none-of-those
end_variable
begin_variable
var110
-1
2
NOT-at-ferry loc41
none-of-those
end_variable
begin_variable
var111
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var112
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var113
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var114
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var115
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
0
begin_state
0
39
38
20
24
21
38
37
30
37
3
4
32
14
16
6
4
39
13
20
5
5
23
38
4
17
11
27
3
40
33
1
36
30
8
9
11
26
39
1
34
28
3
31
7
36
22
26
11
27
38
35
33
17
15
9
15
36
9
12
39
39
18
12
23
23
34
40
7
18
28
24
35
30
23
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
73
1 15
2 30
3 18
4 9
5 31
6 35
7 8
8 32
9 2
10 16
11 40
12 27
13 1
14 29
15 15
16 40
17 11
18 36
19 13
20 9
21 36
22 24
23 15
24 15
25 9
26 21
27 14
28 0
29 18
30 3
31 8
32 11
33 31
34 16
35 11
36 35
37 2
38 36
39 32
40 36
41 19
42 11
43 21
44 4
45 28
46 4
47 31
48 40
49 34
50 1
51 2
52 35
53 36
54 14
55 30
56 38
57 23
58 6
59 28
60 22
61 8
62 26
63 14
64 10
66 1
67 3
68 26
69 12
70 35
71 38
72 37
73 28
74 20
end_goal
7626
begin_operator
board car1 loc1
1
65 0
2
0 0 0 1
0 12 0 41
1
end_operator
begin_operator
board car1 loc10
1
65 1
2
0 0 0 1
0 12 1 41
1
end_operator
begin_operator
board car1 loc11
1
65 2
2
0 0 0 1
0 12 2 41
1
end_operator
begin_operator
board car1 loc12
1
65 3
2
0 0 0 1
0 12 3 41
1
end_operator
begin_operator
board car1 loc13
1
65 4
2
0 0 0 1
0 12 4 41
1
end_operator
begin_operator
board car1 loc14
1
65 5
2
0 0 0 1
0 12 5 41
1
end_operator
begin_operator
board car1 loc15
1
65 6
2
0 0 0 1
0 12 6 41
1
end_operator
begin_operator
board car1 loc16
1
65 7
2
0 0 0 1
0 12 7 41
1
end_operator
begin_operator
board car1 loc17
1
65 8
2
0 0 0 1
0 12 8 41
1
end_operator
begin_operator
board car1 loc18
1
65 9
2
0 0 0 1
0 12 9 41
1
end_operator
begin_operator
board car1 loc19
1
65 10
2
0 0 0 1
0 12 10 41
1
end_operator
begin_operator
board car1 loc2
1
65 11
2
0 0 0 1
0 12 11 41
1
end_operator
begin_operator
board car1 loc20
1
65 12
2
0 0 0 1
0 12 12 41
1
end_operator
begin_operator
board car1 loc21
1
65 13
2
0 0 0 1
0 12 13 41
1
end_operator
begin_operator
board car1 loc22
1
65 14
2
0 0 0 1
0 12 14 41
1
end_operator
begin_operator
board car1 loc23
1
65 15
2
0 0 0 1
0 12 15 41
1
end_operator
begin_operator
board car1 loc24
1
65 16
2
0 0 0 1
0 12 16 41
1
end_operator
begin_operator
board car1 loc25
1
65 17
2
0 0 0 1
0 12 17 41
1
end_operator
begin_operator
board car1 loc26
1
65 18
2
0 0 0 1
0 12 18 41
1
end_operator
begin_operator
board car1 loc27
1
65 19
2
0 0 0 1
0 12 19 41
1
end_operator
begin_operator
board car1 loc28
1
65 20
2
0 0 0 1
0 12 20 41
1
end_operator
begin_operator
board car1 loc29
1
65 21
2
0 0 0 1
0 12 21 41
1
end_operator
begin_operator
board car1 loc3
1
65 22
2
0 0 0 1
0 12 22 41
1
end_operator
begin_operator
board car1 loc30
1
65 23
2
0 0 0 1
0 12 23 41
1
end_operator
begin_operator
board car1 loc31
1
65 24
2
0 0 0 1
0 12 24 41
1
end_operator
begin_operator
board car1 loc32
1
65 25
2
0 0 0 1
0 12 25 41
1
end_operator
begin_operator
board car1 loc33
1
65 26
2
0 0 0 1
0 12 26 41
1
end_operator
begin_operator
board car1 loc34
1
65 27
2
0 0 0 1
0 12 27 41
1
end_operator
begin_operator
board car1 loc35
1
65 28
2
0 0 0 1
0 12 28 41
1
end_operator
begin_operator
board car1 loc36
1
65 29
2
0 0 0 1
0 12 29 41
1
end_operator
begin_operator
board car1 loc37
1
65 30
2
0 0 0 1
0 12 30 41
1
end_operator
begin_operator
board car1 loc38
1
65 31
2
0 0 0 1
0 12 31 41
1
end_operator
begin_operator
board car1 loc39
1
65 32
2
0 0 0 1
0 12 32 41
1
end_operator
begin_operator
board car1 loc4
1
65 33
2
0 0 0 1
0 12 33 41
1
end_operator
begin_operator
board car1 loc40
1
65 34
2
0 0 0 1
0 12 34 41
1
end_operator
begin_operator
board car1 loc41
1
65 35
2
0 0 0 1
0 12 35 41
1
end_operator
begin_operator
board car1 loc5
1
65 36
2
0 0 0 1
0 12 36 41
1
end_operator
begin_operator
board car1 loc6
1
65 37
2
0 0 0 1
0 12 37 41
1
end_operator
begin_operator
board car1 loc7
1
65 38
2
0 0 0 1
0 12 38 41
1
end_operator
begin_operator
board car1 loc8
1
65 39
2
0 0 0 1
0 12 39 41
1
end_operator
begin_operator
board car1 loc9
1
65 40
2
0 0 0 1
0 12 40 41
1
end_operator
begin_operator
board car10 loc1
1
65 0
2
0 0 0 2
0 24 0 41
1
end_operator
begin_operator
board car10 loc10
1
65 1
2
0 0 0 2
0 24 1 41
1
end_operator
begin_operator
board car10 loc11
1
65 2
2
0 0 0 2
0 24 2 41
1
end_operator
begin_operator
board car10 loc12
1
65 3
2
0 0 0 2
0 24 3 41
1
end_operator
begin_operator
board car10 loc13
1
65 4
2
0 0 0 2
0 24 4 41
1
end_operator
begin_operator
board car10 loc14
1
65 5
2
0 0 0 2
0 24 5 41
1
end_operator
begin_operator
board car10 loc15
1
65 6
2
0 0 0 2
0 24 6 41
1
end_operator
begin_operator
board car10 loc16
1
65 7
2
0 0 0 2
0 24 7 41
1
end_operator
begin_operator
board car10 loc17
1
65 8
2
0 0 0 2
0 24 8 41
1
end_operator
begin_operator
board car10 loc18
1
65 9
2
0 0 0 2
0 24 9 41
1
end_operator
begin_operator
board car10 loc19
1
65 10
2
0 0 0 2
0 24 10 41
1
end_operator
begin_operator
board car10 loc2
1
65 11
2
0 0 0 2
0 24 11 41
1
end_operator
begin_operator
board car10 loc20
1
65 12
2
0 0 0 2
0 24 12 41
1
end_operator
begin_operator
board car10 loc21
1
65 13
2
0 0 0 2
0 24 13 41
1
end_operator
begin_operator
board car10 loc22
1
65 14
2
0 0 0 2
0 24 14 41
1
end_operator
begin_operator
board car10 loc23
1
65 15
2
0 0 0 2
0 24 15 41
1
end_operator
begin_operator
board car10 loc24
1
65 16
2
0 0 0 2
0 24 16 41
1
end_operator
begin_operator
board car10 loc25
1
65 17
2
0 0 0 2
0 24 17 41
1
end_operator
begin_operator
board car10 loc26
1
65 18
2
0 0 0 2
0 24 18 41
1
end_operator
begin_operator
board car10 loc27
1
65 19
2
0 0 0 2
0 24 19 41
1
end_operator
begin_operator
board car10 loc28
1
65 20
2
0 0 0 2
0 24 20 41
1
end_operator
begin_operator
board car10 loc29
1
65 21
2
0 0 0 2
0 24 21 41
1
end_operator
begin_operator
board car10 loc3
1
65 22
2
0 0 0 2
0 24 22 41
1
end_operator
begin_operator
board car10 loc30
1
65 23
2
0 0 0 2
0 24 23 41
1
end_operator
begin_operator
board car10 loc31
1
65 24
2
0 0 0 2
0 24 24 41
1
end_operator
begin_operator
board car10 loc32
1
65 25
2
0 0 0 2
0 24 25 41
1
end_operator
begin_operator
board car10 loc33
1
65 26
2
0 0 0 2
0 24 26 41
1
end_operator
begin_operator
board car10 loc34
1
65 27
2
0 0 0 2
0 24 27 41
1
end_operator
begin_operator
board car10 loc35
1
65 28
2
0 0 0 2
0 24 28 41
1
end_operator
begin_operator
board car10 loc36
1
65 29
2
0 0 0 2
0 24 29 41
1
end_operator
begin_operator
board car10 loc37
1
65 30
2
0 0 0 2
0 24 30 41
1
end_operator
begin_operator
board car10 loc38
1
65 31
2
0 0 0 2
0 24 31 41
1
end_operator
begin_operator
board car10 loc39
1
65 32
2
0 0 0 2
0 24 32 41
1
end_operator
begin_operator
board car10 loc4
1
65 33
2
0 0 0 2
0 24 33 41
1
end_operator
begin_operator
board car10 loc40
1
65 34
2
0 0 0 2
0 24 34 41
1
end_operator
begin_operator
board car10 loc41
1
65 35
2
0 0 0 2
0 24 35 41
1
end_operator
begin_operator
board car10 loc5
1
65 36
2
0 0 0 2
0 24 36 41
1
end_operator
begin_operator
board car10 loc6
1
65 37
2
0 0 0 2
0 24 37 41
1
end_operator
begin_operator
board car10 loc7
1
65 38
2
0 0 0 2
0 24 38 41
1
end_operator
begin_operator
board car10 loc8
1
65 39
2
0 0 0 2
0 24 39 41
1
end_operator
begin_operator
board car10 loc9
1
65 40
2
0 0 0 2
0 24 40 41
1
end_operator
begin_operator
board car11 loc1
1
65 0
2
0 0 0 3
0 36 0 41
1
end_operator
begin_operator
board car11 loc10
1
65 1
2
0 0 0 3
0 36 1 41
1
end_operator
begin_operator
board car11 loc11
1
65 2
2
0 0 0 3
0 36 2 41
1
end_operator
begin_operator
board car11 loc12
1
65 3
2
0 0 0 3
0 36 3 41
1
end_operator
begin_operator
board car11 loc13
1
65 4
2
0 0 0 3
0 36 4 41
1
end_operator
begin_operator
board car11 loc14
1
65 5
2
0 0 0 3
0 36 5 41
1
end_operator
begin_operator
board car11 loc15
1
65 6
2
0 0 0 3
0 36 6 41
1
end_operator
begin_operator
board car11 loc16
1
65 7
2
0 0 0 3
0 36 7 41
1
end_operator
begin_operator
board car11 loc17
1
65 8
2
0 0 0 3
0 36 8 41
1
end_operator
begin_operator
board car11 loc18
1
65 9
2
0 0 0 3
0 36 9 41
1
end_operator
begin_operator
board car11 loc19
1
65 10
2
0 0 0 3
0 36 10 41
1
end_operator
begin_operator
board car11 loc2
1
65 11
2
0 0 0 3
0 36 11 41
1
end_operator
begin_operator
board car11 loc20
1
65 12
2
0 0 0 3
0 36 12 41
1
end_operator
begin_operator
board car11 loc21
1
65 13
2
0 0 0 3
0 36 13 41
1
end_operator
begin_operator
board car11 loc22
1
65 14
2
0 0 0 3
0 36 14 41
1
end_operator
begin_operator
board car11 loc23
1
65 15
2
0 0 0 3
0 36 15 41
1
end_operator
begin_operator
board car11 loc24
1
65 16
2
0 0 0 3
0 36 16 41
1
end_operator
begin_operator
board car11 loc25
1
65 17
2
0 0 0 3
0 36 17 41
1
end_operator
begin_operator
board car11 loc26
1
65 18
2
0 0 0 3
0 36 18 41
1
end_operator
begin_operator
board car11 loc27
1
65 19
2
0 0 0 3
0 36 19 41
1
end_operator
begin_operator
board car11 loc28
1
65 20
2
0 0 0 3
0 36 20 41
1
end_operator
begin_operator
board car11 loc29
1
65 21
2
0 0 0 3
0 36 21 41
1
end_operator
begin_operator
board car11 loc3
1
65 22
2
0 0 0 3
0 36 22 41
1
end_operator
begin_operator
board car11 loc30
1
65 23
2
0 0 0 3
0 36 23 41
1
end_operator
begin_operator
board car11 loc31
1
65 24
2
0 0 0 3
0 36 24 41
1
end_operator
begin_operator
board car11 loc32
1
65 25
2
0 0 0 3
0 36 25 41
1
end_operator
begin_operator
board car11 loc33
1
65 26
2
0 0 0 3
0 36 26 41
1
end_operator
begin_operator
board car11 loc34
1
65 27
2
0 0 0 3
0 36 27 41
1
end_operator
begin_operator
board car11 loc35
1
65 28
2
0 0 0 3
0 36 28 41
1
end_operator
begin_operator
board car11 loc36
1
65 29
2
0 0 0 3
0 36 29 41
1
end_operator
begin_operator
board car11 loc37
1
65 30
2
0 0 0 3
0 36 30 41
1
end_operator
begin_operator
board car11 loc38
1
65 31
2
0 0 0 3
0 36 31 41
1
end_operator
begin_operator
board car11 loc39
1
65 32
2
0 0 0 3
0 36 32 41
1
end_operator
begin_operator
board car11 loc4
1
65 33
2
0 0 0 3
0 36 33 41
1
end_operator
begin_operator
board car11 loc40
1
65 34
2
0 0 0 3
0 36 34 41
1
end_operator
begin_operator
board car11 loc41
1
65 35
2
0 0 0 3
0 36 35 41
1
end_operator
begin_operator
board car11 loc5
1
65 36
2
0 0 0 3
0 36 36 41
1
end_operator
begin_operator
board car11 loc6
1
65 37
2
0 0 0 3
0 36 37 41
1
end_operator
begin_operator
board car11 loc7
1
65 38
2
0 0 0 3
0 36 38 41
1
end_operator
begin_operator
board car11 loc8
1
65 39
2
0 0 0 3
0 36 39 41
1
end_operator
begin_operator
board car11 loc9
1
65 40
2
0 0 0 3
0 36 40 41
1
end_operator
begin_operator
board car12 loc1
1
65 0
2
0 0 0 4
0 48 0 41
1
end_operator
begin_operator
board car12 loc10
1
65 1
2
0 0 0 4
0 48 1 41
1
end_operator
begin_operator
board car12 loc11
1
65 2
2
0 0 0 4
0 48 2 41
1
end_operator
begin_operator
board car12 loc12
1
65 3
2
0 0 0 4
0 48 3 41
1
end_operator
begin_operator
board car12 loc13
1
65 4
2
0 0 0 4
0 48 4 41
1
end_operator
begin_operator
board car12 loc14
1
65 5
2
0 0 0 4
0 48 5 41
1
end_operator
begin_operator
board car12 loc15
1
65 6
2
0 0 0 4
0 48 6 41
1
end_operator
begin_operator
board car12 loc16
1
65 7
2
0 0 0 4
0 48 7 41
1
end_operator
begin_operator
board car12 loc17
1
65 8
2
0 0 0 4
0 48 8 41
1
end_operator
begin_operator
board car12 loc18
1
65 9
2
0 0 0 4
0 48 9 41
1
end_operator
begin_operator
board car12 loc19
1
65 10
2
0 0 0 4
0 48 10 41
1
end_operator
begin_operator
board car12 loc2
1
65 11
2
0 0 0 4
0 48 11 41
1
end_operator
begin_operator
board car12 loc20
1
65 12
2
0 0 0 4
0 48 12 41
1
end_operator
begin_operator
board car12 loc21
1
65 13
2
0 0 0 4
0 48 13 41
1
end_operator
begin_operator
board car12 loc22
1
65 14
2
0 0 0 4
0 48 14 41
1
end_operator
begin_operator
board car12 loc23
1
65 15
2
0 0 0 4
0 48 15 41
1
end_operator
begin_operator
board car12 loc24
1
65 16
2
0 0 0 4
0 48 16 41
1
end_operator
begin_operator
board car12 loc25
1
65 17
2
0 0 0 4
0 48 17 41
1
end_operator
begin_operator
board car12 loc26
1
65 18
2
0 0 0 4
0 48 18 41
1
end_operator
begin_operator
board car12 loc27
1
65 19
2
0 0 0 4
0 48 19 41
1
end_operator
begin_operator
board car12 loc28
1
65 20
2
0 0 0 4
0 48 20 41
1
end_operator
begin_operator
board car12 loc29
1
65 21
2
0 0 0 4
0 48 21 41
1
end_operator
begin_operator
board car12 loc3
1
65 22
2
0 0 0 4
0 48 22 41
1
end_operator
begin_operator
board car12 loc30
1
65 23
2
0 0 0 4
0 48 23 41
1
end_operator
begin_operator
board car12 loc31
1
65 24
2
0 0 0 4
0 48 24 41
1
end_operator
begin_operator
board car12 loc32
1
65 25
2
0 0 0 4
0 48 25 41
1
end_operator
begin_operator
board car12 loc33
1
65 26
2
0 0 0 4
0 48 26 41
1
end_operator
begin_operator
board car12 loc34
1
65 27
2
0 0 0 4
0 48 27 41
1
end_operator
begin_operator
board car12 loc35
1
65 28
2
0 0 0 4
0 48 28 41
1
end_operator
begin_operator
board car12 loc36
1
65 29
2
0 0 0 4
0 48 29 41
1
end_operator
begin_operator
board car12 loc37
1
65 30
2
0 0 0 4
0 48 30 41
1
end_operator
begin_operator
board car12 loc38
1
65 31
2
0 0 0 4
0 48 31 41
1
end_operator
begin_operator
board car12 loc39
1
65 32
2
0 0 0 4
0 48 32 41
1
end_operator
begin_operator
board car12 loc4
1
65 33
2
0 0 0 4
0 48 33 41
1
end_operator
begin_operator
board car12 loc40
1
65 34
2
0 0 0 4
0 48 34 41
1
end_operator
begin_operator
board car12 loc41
1
65 35
2
0 0 0 4
0 48 35 41
1
end_operator
begin_operator
board car12 loc5
1
65 36
2
0 0 0 4
0 48 36 41
1
end_operator
begin_operator
board car12 loc6
1
65 37
2
0 0 0 4
0 48 37 41
1
end_operator
begin_operator
board car12 loc7
1
65 38
2
0 0 0 4
0 48 38 41
1
end_operator
begin_operator
board car12 loc8
1
65 39
2
0 0 0 4
0 48 39 41
1
end_operator
begin_operator
board car12 loc9
1
65 40
2
0 0 0 4
0 48 40 41
1
end_operator
begin_operator
board car13 loc1
1
65 0
2
0 0 0 5
0 60 0 41
1
end_operator
begin_operator
board car13 loc10
1
65 1
2
0 0 0 5
0 60 1 41
1
end_operator
begin_operator
board car13 loc11
1
65 2
2
0 0 0 5
0 60 2 41
1
end_operator
begin_operator
board car13 loc12
1
65 3
2
0 0 0 5
0 60 3 41
1
end_operator
begin_operator
board car13 loc13
1
65 4
2
0 0 0 5
0 60 4 41
1
end_operator
begin_operator
board car13 loc14
1
65 5
2
0 0 0 5
0 60 5 41
1
end_operator
begin_operator
board car13 loc15
1
65 6
2
0 0 0 5
0 60 6 41
1
end_operator
begin_operator
board car13 loc16
1
65 7
2
0 0 0 5
0 60 7 41
1
end_operator
begin_operator
board car13 loc17
1
65 8
2
0 0 0 5
0 60 8 41
1
end_operator
begin_operator
board car13 loc18
1
65 9
2
0 0 0 5
0 60 9 41
1
end_operator
begin_operator
board car13 loc19
1
65 10
2
0 0 0 5
0 60 10 41
1
end_operator
begin_operator
board car13 loc2
1
65 11
2
0 0 0 5
0 60 11 41
1
end_operator
begin_operator
board car13 loc20
1
65 12
2
0 0 0 5
0 60 12 41
1
end_operator
begin_operator
board car13 loc21
1
65 13
2
0 0 0 5
0 60 13 41
1
end_operator
begin_operator
board car13 loc22
1
65 14
2
0 0 0 5
0 60 14 41
1
end_operator
begin_operator
board car13 loc23
1
65 15
2
0 0 0 5
0 60 15 41
1
end_operator
begin_operator
board car13 loc24
1
65 16
2
0 0 0 5
0 60 16 41
1
end_operator
begin_operator
board car13 loc25
1
65 17
2
0 0 0 5
0 60 17 41
1
end_operator
begin_operator
board car13 loc26
1
65 18
2
0 0 0 5
0 60 18 41
1
end_operator
begin_operator
board car13 loc27
1
65 19
2
0 0 0 5
0 60 19 41
1
end_operator
begin_operator
board car13 loc28
1
65 20
2
0 0 0 5
0 60 20 41
1
end_operator
begin_operator
board car13 loc29
1
65 21
2
0 0 0 5
0 60 21 41
1
end_operator
begin_operator
board car13 loc3
1
65 22
2
0 0 0 5
0 60 22 41
1
end_operator
begin_operator
board car13 loc30
1
65 23
2
0 0 0 5
0 60 23 41
1
end_operator
begin_operator
board car13 loc31
1
65 24
2
0 0 0 5
0 60 24 41
1
end_operator
begin_operator
board car13 loc32
1
65 25
2
0 0 0 5
0 60 25 41
1
end_operator
begin_operator
board car13 loc33
1
65 26
2
0 0 0 5
0 60 26 41
1
end_operator
begin_operator
board car13 loc34
1
65 27
2
0 0 0 5
0 60 27 41
1
end_operator
begin_operator
board car13 loc35
1
65 28
2
0 0 0 5
0 60 28 41
1
end_operator
begin_operator
board car13 loc36
1
65 29
2
0 0 0 5
0 60 29 41
1
end_operator
begin_operator
board car13 loc37
1
65 30
2
0 0 0 5
0 60 30 41
1
end_operator
begin_operator
board car13 loc38
1
65 31
2
0 0 0 5
0 60 31 41
1
end_operator
begin_operator
board car13 loc39
1
65 32
2
0 0 0 5
0 60 32 41
1
end_operator
begin_operator
board car13 loc4
1
65 33
2
0 0 0 5
0 60 33 41
1
end_operator
begin_operator
board car13 loc40
1
65 34
2
0 0 0 5
0 60 34 41
1
end_operator
begin_operator
board car13 loc41
1
65 35
2
0 0 0 5
0 60 35 41
1
end_operator
begin_operator
board car13 loc5
1
65 36
2
0 0 0 5
0 60 36 41
1
end_operator
begin_operator
board car13 loc6
1
65 37
2
0 0 0 5
0 60 37 41
1
end_operator
begin_operator
board car13 loc7
1
65 38
2
0 0 0 5
0 60 38 41
1
end_operator
begin_operator
board car13 loc8
1
65 39
2
0 0 0 5
0 60 39 41
1
end_operator
begin_operator
board car13 loc9
1
65 40
2
0 0 0 5
0 60 40 41
1
end_operator
begin_operator
board car14 loc1
1
65 0
2
0 0 0 6
0 72 0 41
1
end_operator
begin_operator
board car14 loc10
1
65 1
2
0 0 0 6
0 72 1 41
1
end_operator
begin_operator
board car14 loc11
1
65 2
2
0 0 0 6
0 72 2 41
1
end_operator
begin_operator
board car14 loc12
1
65 3
2
0 0 0 6
0 72 3 41
1
end_operator
begin_operator
board car14 loc13
1
65 4
2
0 0 0 6
0 72 4 41
1
end_operator
begin_operator
board car14 loc14
1
65 5
2
0 0 0 6
0 72 5 41
1
end_operator
begin_operator
board car14 loc15
1
65 6
2
0 0 0 6
0 72 6 41
1
end_operator
begin_operator
board car14 loc16
1
65 7
2
0 0 0 6
0 72 7 41
1
end_operator
begin_operator
board car14 loc17
1
65 8
2
0 0 0 6
0 72 8 41
1
end_operator
begin_operator
board car14 loc18
1
65 9
2
0 0 0 6
0 72 9 41
1
end_operator
begin_operator
board car14 loc19
1
65 10
2
0 0 0 6
0 72 10 41
1
end_operator
begin_operator
board car14 loc2
1
65 11
2
0 0 0 6
0 72 11 41
1
end_operator
begin_operator
board car14 loc20
1
65 12
2
0 0 0 6
0 72 12 41
1
end_operator
begin_operator
board car14 loc21
1
65 13
2
0 0 0 6
0 72 13 41
1
end_operator
begin_operator
board car14 loc22
1
65 14
2
0 0 0 6
0 72 14 41
1
end_operator
begin_operator
board car14 loc23
1
65 15
2
0 0 0 6
0 72 15 41
1
end_operator
begin_operator
board car14 loc24
1
65 16
2
0 0 0 6
0 72 16 41
1
end_operator
begin_operator
board car14 loc25
1
65 17
2
0 0 0 6
0 72 17 41
1
end_operator
begin_operator
board car14 loc26
1
65 18
2
0 0 0 6
0 72 18 41
1
end_operator
begin_operator
board car14 loc27
1
65 19
2
0 0 0 6
0 72 19 41
1
end_operator
begin_operator
board car14 loc28
1
65 20
2
0 0 0 6
0 72 20 41
1
end_operator
begin_operator
board car14 loc29
1
65 21
2
0 0 0 6
0 72 21 41
1
end_operator
begin_operator
board car14 loc3
1
65 22
2
0 0 0 6
0 72 22 41
1
end_operator
begin_operator
board car14 loc30
1
65 23
2
0 0 0 6
0 72 23 41
1
end_operator
begin_operator
board car14 loc31
1
65 24
2
0 0 0 6
0 72 24 41
1
end_operator
begin_operator
board car14 loc32
1
65 25
2
0 0 0 6
0 72 25 41
1
end_operator
begin_operator
board car14 loc33
1
65 26
2
0 0 0 6
0 72 26 41
1
end_operator
begin_operator
board car14 loc34
1
65 27
2
0 0 0 6
0 72 27 41
1
end_operator
begin_operator
board car14 loc35
1
65 28
2
0 0 0 6
0 72 28 41
1
end_operator
begin_operator
board car14 loc36
1
65 29
2
0 0 0 6
0 72 29 41
1
end_operator
begin_operator
board car14 loc37
1
65 30
2
0 0 0 6
0 72 30 41
1
end_operator
begin_operator
board car14 loc38
1
65 31
2
0 0 0 6
0 72 31 41
1
end_operator
begin_operator
board car14 loc39
1
65 32
2
0 0 0 6
0 72 32 41
1
end_operator
begin_operator
board car14 loc4
1
65 33
2
0 0 0 6
0 72 33 41
1
end_operator
begin_operator
board car14 loc40
1
65 34
2
0 0 0 6
0 72 34 41
1
end_operator
begin_operator
board car14 loc41
1
65 35
2
0 0 0 6
0 72 35 41
1
end_operator
begin_operator
board car14 loc5
1
65 36
2
0 0 0 6
0 72 36 41
1
end_operator
begin_operator
board car14 loc6
1
65 37
2
0 0 0 6
0 72 37 41
1
end_operator
begin_operator
board car14 loc7
1
65 38
2
0 0 0 6
0 72 38 41
1
end_operator
begin_operator
board car14 loc8
1
65 39
2
0 0 0 6
0 72 39 41
1
end_operator
begin_operator
board car14 loc9
1
65 40
2
0 0 0 6
0 72 40 41
1
end_operator
begin_operator
board car15 loc1
1
65 0
2
0 0 0 7
0 9 0 41
1
end_operator
begin_operator
board car15 loc10
1
65 1
2
0 0 0 7
0 9 1 41
1
end_operator
begin_operator
board car15 loc11
1
65 2
2
0 0 0 7
0 9 2 41
1
end_operator
begin_operator
board car15 loc12
1
65 3
2
0 0 0 7
0 9 3 41
1
end_operator
begin_operator
board car15 loc13
1
65 4
2
0 0 0 7
0 9 4 41
1
end_operator
begin_operator
board car15 loc14
1
65 5
2
0 0 0 7
0 9 5 41
1
end_operator
begin_operator
board car15 loc15
1
65 6
2
0 0 0 7
0 9 6 41
1
end_operator
begin_operator
board car15 loc16
1
65 7
2
0 0 0 7
0 9 7 41
1
end_operator
begin_operator
board car15 loc17
1
65 8
2
0 0 0 7
0 9 8 41
1
end_operator
begin_operator
board car15 loc18
1
65 9
2
0 0 0 7
0 9 9 41
1
end_operator
begin_operator
board car15 loc19
1
65 10
2
0 0 0 7
0 9 10 41
1
end_operator
begin_operator
board car15 loc2
1
65 11
2
0 0 0 7
0 9 11 41
1
end_operator
begin_operator
board car15 loc20
1
65 12
2
0 0 0 7
0 9 12 41
1
end_operator
begin_operator
board car15 loc21
1
65 13
2
0 0 0 7
0 9 13 41
1
end_operator
begin_operator
board car15 loc22
1
65 14
2
0 0 0 7
0 9 14 41
1
end_operator
begin_operator
board car15 loc23
1
65 15
2
0 0 0 7
0 9 15 41
1
end_operator
begin_operator
board car15 loc24
1
65 16
2
0 0 0 7
0 9 16 41
1
end_operator
begin_operator
board car15 loc25
1
65 17
2
0 0 0 7
0 9 17 41
1
end_operator
begin_operator
board car15 loc26
1
65 18
2
0 0 0 7
0 9 18 41
1
end_operator
begin_operator
board car15 loc27
1
65 19
2
0 0 0 7
0 9 19 41
1
end_operator
begin_operator
board car15 loc28
1
65 20
2
0 0 0 7
0 9 20 41
1
end_operator
begin_operator
board car15 loc29
1
65 21
2
0 0 0 7
0 9 21 41
1
end_operator
begin_operator
board car15 loc3
1
65 22
2
0 0 0 7
0 9 22 41
1
end_operator
begin_operator
board car15 loc30
1
65 23
2
0 0 0 7
0 9 23 41
1
end_operator
begin_operator
board car15 loc31
1
65 24
2
0 0 0 7
0 9 24 41
1
end_operator
begin_operator
board car15 loc32
1
65 25
2
0 0 0 7
0 9 25 41
1
end_operator
begin_operator
board car15 loc33
1
65 26
2
0 0 0 7
0 9 26 41
1
end_operator
begin_operator
board car15 loc34
1
65 27
2
0 0 0 7
0 9 27 41
1
end_operator
begin_operator
board car15 loc35
1
65 28
2
0 0 0 7
0 9 28 41
1
end_operator
begin_operator
board car15 loc36
1
65 29
2
0 0 0 7
0 9 29 41
1
end_operator
begin_operator
board car15 loc37
1
65 30
2
0 0 0 7
0 9 30 41
1
end_operator
begin_operator
board car15 loc38
1
65 31
2
0 0 0 7
0 9 31 41
1
end_operator
begin_operator
board car15 loc39
1
65 32
2
0 0 0 7
0 9 32 41
1
end_operator
begin_operator
board car15 loc4
1
65 33
2
0 0 0 7
0 9 33 41
1
end_operator
begin_operator
board car15 loc40
1
65 34
2
0 0 0 7
0 9 34 41
1
end_operator
begin_operator
board car15 loc41
1
65 35
2
0 0 0 7
0 9 35 41
1
end_operator
begin_operator
board car15 loc5
1
65 36
2
0 0 0 7
0 9 36 41
1
end_operator
begin_operator
board car15 loc6
1
65 37
2
0 0 0 7
0 9 37 41
1
end_operator
begin_operator
board car15 loc7
1
65 38
2
0 0 0 7
0 9 38 41
1
end_operator
begin_operator
board car15 loc8
1
65 39
2
0 0 0 7
0 9 39 41
1
end_operator
begin_operator
board car15 loc9
1
65 40
2
0 0 0 7
0 9 40 41
1
end_operator
begin_operator
board car16 loc1
1
65 0
2
0 0 0 8
0 21 0 41
1
end_operator
begin_operator
board car16 loc10
1
65 1
2
0 0 0 8
0 21 1 41
1
end_operator
begin_operator
board car16 loc11
1
65 2
2
0 0 0 8
0 21 2 41
1
end_operator
begin_operator
board car16 loc12
1
65 3
2
0 0 0 8
0 21 3 41
1
end_operator
begin_operator
board car16 loc13
1
65 4
2
0 0 0 8
0 21 4 41
1
end_operator
begin_operator
board car16 loc14
1
65 5
2
0 0 0 8
0 21 5 41
1
end_operator
begin_operator
board car16 loc15
1
65 6
2
0 0 0 8
0 21 6 41
1
end_operator
begin_operator
board car16 loc16
1
65 7
2
0 0 0 8
0 21 7 41
1
end_operator
begin_operator
board car16 loc17
1
65 8
2
0 0 0 8
0 21 8 41
1
end_operator
begin_operator
board car16 loc18
1
65 9
2
0 0 0 8
0 21 9 41
1
end_operator
begin_operator
board car16 loc19
1
65 10
2
0 0 0 8
0 21 10 41
1
end_operator
begin_operator
board car16 loc2
1
65 11
2
0 0 0 8
0 21 11 41
1
end_operator
begin_operator
board car16 loc20
1
65 12
2
0 0 0 8
0 21 12 41
1
end_operator
begin_operator
board car16 loc21
1
65 13
2
0 0 0 8
0 21 13 41
1
end_operator
begin_operator
board car16 loc22
1
65 14
2
0 0 0 8
0 21 14 41
1
end_operator
begin_operator
board car16 loc23
1
65 15
2
0 0 0 8
0 21 15 41
1
end_operator
begin_operator
board car16 loc24
1
65 16
2
0 0 0 8
0 21 16 41
1
end_operator
begin_operator
board car16 loc25
1
65 17
2
0 0 0 8
0 21 17 41
1
end_operator
begin_operator
board car16 loc26
1
65 18
2
0 0 0 8
0 21 18 41
1
end_operator
begin_operator
board car16 loc27
1
65 19
2
0 0 0 8
0 21 19 41
1
end_operator
begin_operator
board car16 loc28
1
65 20
2
0 0 0 8
0 21 20 41
1
end_operator
begin_operator
board car16 loc29
1
65 21
2
0 0 0 8
0 21 21 41
1
end_operator
begin_operator
board car16 loc3
1
65 22
2
0 0 0 8
0 21 22 41
1
end_operator
begin_operator
board car16 loc30
1
65 23
2
0 0 0 8
0 21 23 41
1
end_operator
begin_operator
board car16 loc31
1
65 24
2
0 0 0 8
0 21 24 41
1
end_operator
begin_operator
board car16 loc32
1
65 25
2
0 0 0 8
0 21 25 41
1
end_operator
begin_operator
board car16 loc33
1
65 26
2
0 0 0 8
0 21 26 41
1
end_operator
begin_operator
board car16 loc34
1
65 27
2
0 0 0 8
0 21 27 41
1
end_operator
begin_operator
board car16 loc35
1
65 28
2
0 0 0 8
0 21 28 41
1
end_operator
begin_operator
board car16 loc36
1
65 29
2
0 0 0 8
0 21 29 41
1
end_operator
begin_operator
board car16 loc37
1
65 30
2
0 0 0 8
0 21 30 41
1
end_operator
begin_operator
board car16 loc38
1
65 31
2
0 0 0 8
0 21 31 41
1
end_operator
begin_operator
board car16 loc39
1
65 32
2
0 0 0 8
0 21 32 41
1
end_operator
begin_operator
board car16 loc4
1
65 33
2
0 0 0 8
0 21 33 41
1
end_operator
begin_operator
board car16 loc40
1
65 34
2
0 0 0 8
0 21 34 41
1
end_operator
begin_operator
board car16 loc41
1
65 35
2
0 0 0 8
0 21 35 41
1
end_operator
begin_operator
board car16 loc5
1
65 36
2
0 0 0 8
0 21 36 41
1
end_operator
begin_operator
board car16 loc6
1
65 37
2
0 0 0 8
0 21 37 41
1
end_operator
begin_operator
board car16 loc7
1
65 38
2
0 0 0 8
0 21 38 41
1
end_operator
begin_operator
board car16 loc8
1
65 39
2
0 0 0 8
0 21 39 41
1
end_operator
begin_operator
board car16 loc9
1
65 40
2
0 0 0 8
0 21 40 41
1
end_operator
begin_operator
board car17 loc1
1
65 0
2
0 0 0 9
0 33 0 41
1
end_operator
begin_operator
board car17 loc10
1
65 1
2
0 0 0 9
0 33 1 41
1
end_operator
begin_operator
board car17 loc11
1
65 2
2
0 0 0 9
0 33 2 41
1
end_operator
begin_operator
board car17 loc12
1
65 3
2
0 0 0 9
0 33 3 41
1
end_operator
begin_operator
board car17 loc13
1
65 4
2
0 0 0 9
0 33 4 41
1
end_operator
begin_operator
board car17 loc14
1
65 5
2
0 0 0 9
0 33 5 41
1
end_operator
begin_operator
board car17 loc15
1
65 6
2
0 0 0 9
0 33 6 41
1
end_operator
begin_operator
board car17 loc16
1
65 7
2
0 0 0 9
0 33 7 41
1
end_operator
begin_operator
board car17 loc17
1
65 8
2
0 0 0 9
0 33 8 41
1
end_operator
begin_operator
board car17 loc18
1
65 9
2
0 0 0 9
0 33 9 41
1
end_operator
begin_operator
board car17 loc19
1
65 10
2
0 0 0 9
0 33 10 41
1
end_operator
begin_operator
board car17 loc2
1
65 11
2
0 0 0 9
0 33 11 41
1
end_operator
begin_operator
board car17 loc20
1
65 12
2
0 0 0 9
0 33 12 41
1
end_operator
begin_operator
board car17 loc21
1
65 13
2
0 0 0 9
0 33 13 41
1
end_operator
begin_operator
board car17 loc22
1
65 14
2
0 0 0 9
0 33 14 41
1
end_operator
begin_operator
board car17 loc23
1
65 15
2
0 0 0 9
0 33 15 41
1
end_operator
begin_operator
board car17 loc24
1
65 16
2
0 0 0 9
0 33 16 41
1
end_operator
begin_operator
board car17 loc25
1
65 17
2
0 0 0 9
0 33 17 41
1
end_operator
begin_operator
board car17 loc26
1
65 18
2
0 0 0 9
0 33 18 41
1
end_operator
begin_operator
board car17 loc27
1
65 19
2
0 0 0 9
0 33 19 41
1
end_operator
begin_operator
board car17 loc28
1
65 20
2
0 0 0 9
0 33 20 41
1
end_operator
begin_operator
board car17 loc29
1
65 21
2
0 0 0 9
0 33 21 41
1
end_operator
begin_operator
board car17 loc3
1
65 22
2
0 0 0 9
0 33 22 41
1
end_operator
begin_operator
board car17 loc30
1
65 23
2
0 0 0 9
0 33 23 41
1
end_operator
begin_operator
board car17 loc31
1
65 24
2
0 0 0 9
0 33 24 41
1
end_operator
begin_operator
board car17 loc32
1
65 25
2
0 0 0 9
0 33 25 41
1
end_operator
begin_operator
board car17 loc33
1
65 26
2
0 0 0 9
0 33 26 41
1
end_operator
begin_operator
board car17 loc34
1
65 27
2
0 0 0 9
0 33 27 41
1
end_operator
begin_operator
board car17 loc35
1
65 28
2
0 0 0 9
0 33 28 41
1
end_operator
begin_operator
board car17 loc36
1
65 29
2
0 0 0 9
0 33 29 41
1
end_operator
begin_operator
board car17 loc37
1
65 30
2
0 0 0 9
0 33 30 41
1
end_operator
begin_operator
board car17 loc38
1
65 31
2
0 0 0 9
0 33 31 41
1
end_operator
begin_operator
board car17 loc39
1
65 32
2
0 0 0 9
0 33 32 41
1
end_operator
begin_operator
board car17 loc4
1
65 33
2
0 0 0 9
0 33 33 41
1
end_operator
begin_operator
board car17 loc40
1
65 34
2
0 0 0 9
0 33 34 41
1
end_operator
begin_operator
board car17 loc41
1
65 35
2
0 0 0 9
0 33 35 41
1
end_operator
begin_operator
board car17 loc5
1
65 36
2
0 0 0 9
0 33 36 41
1
end_operator
begin_operator
board car17 loc6
1
65 37
2
0 0 0 9
0 33 37 41
1
end_operator
begin_operator
board car17 loc7
1
65 38
2
0 0 0 9
0 33 38 41
1
end_operator
begin_operator
board car17 loc8
1
65 39
2
0 0 0 9
0 33 39 41
1
end_operator
begin_operator
board car17 loc9
1
65 40
2
0 0 0 9
0 33 40 41
1
end_operator
begin_operator
board car18 loc1
1
65 0
2
0 0 0 10
0 45 0 41
1
end_operator
begin_operator
board car18 loc10
1
65 1
2
0 0 0 10
0 45 1 41
1
end_operator
begin_operator
board car18 loc11
1
65 2
2
0 0 0 10
0 45 2 41
1
end_operator
begin_operator
board car18 loc12
1
65 3
2
0 0 0 10
0 45 3 41
1
end_operator
begin_operator
board car18 loc13
1
65 4
2
0 0 0 10
0 45 4 41
1
end_operator
begin_operator
board car18 loc14
1
65 5
2
0 0 0 10
0 45 5 41
1
end_operator
begin_operator
board car18 loc15
1
65 6
2
0 0 0 10
0 45 6 41
1
end_operator
begin_operator
board car18 loc16
1
65 7
2
0 0 0 10
0 45 7 41
1
end_operator
begin_operator
board car18 loc17
1
65 8
2
0 0 0 10
0 45 8 41
1
end_operator
begin_operator
board car18 loc18
1
65 9
2
0 0 0 10
0 45 9 41
1
end_operator
begin_operator
board car18 loc19
1
65 10
2
0 0 0 10
0 45 10 41
1
end_operator
begin_operator
board car18 loc2
1
65 11
2
0 0 0 10
0 45 11 41
1
end_operator
begin_operator
board car18 loc20
1
65 12
2
0 0 0 10
0 45 12 41
1
end_operator
begin_operator
board car18 loc21
1
65 13
2
0 0 0 10
0 45 13 41
1
end_operator
begin_operator
board car18 loc22
1
65 14
2
0 0 0 10
0 45 14 41
1
end_operator
begin_operator
board car18 loc23
1
65 15
2
0 0 0 10
0 45 15 41
1
end_operator
begin_operator
board car18 loc24
1
65 16
2
0 0 0 10
0 45 16 41
1
end_operator
begin_operator
board car18 loc25
1
65 17
2
0 0 0 10
0 45 17 41
1
end_operator
begin_operator
board car18 loc26
1
65 18
2
0 0 0 10
0 45 18 41
1
end_operator
begin_operator
board car18 loc27
1
65 19
2
0 0 0 10
0 45 19 41
1
end_operator
begin_operator
board car18 loc28
1
65 20
2
0 0 0 10
0 45 20 41
1
end_operator
begin_operator
board car18 loc29
1
65 21
2
0 0 0 10
0 45 21 41
1
end_operator
begin_operator
board car18 loc3
1
65 22
2
0 0 0 10
0 45 22 41
1
end_operator
begin_operator
board car18 loc30
1
65 23
2
0 0 0 10
0 45 23 41
1
end_operator
begin_operator
board car18 loc31
1
65 24
2
0 0 0 10
0 45 24 41
1
end_operator
begin_operator
board car18 loc32
1
65 25
2
0 0 0 10
0 45 25 41
1
end_operator
begin_operator
board car18 loc33
1
65 26
2
0 0 0 10
0 45 26 41
1
end_operator
begin_operator
board car18 loc34
1
65 27
2
0 0 0 10
0 45 27 41
1
end_operator
begin_operator
board car18 loc35
1
65 28
2
0 0 0 10
0 45 28 41
1
end_operator
begin_operator
board car18 loc36
1
65 29
2
0 0 0 10
0 45 29 41
1
end_operator
begin_operator
board car18 loc37
1
65 30
2
0 0 0 10
0 45 30 41
1
end_operator
begin_operator
board car18 loc38
1
65 31
2
0 0 0 10
0 45 31 41
1
end_operator
begin_operator
board car18 loc39
1
65 32
2
0 0 0 10
0 45 32 41
1
end_operator
begin_operator
board car18 loc4
1
65 33
2
0 0 0 10
0 45 33 41
1
end_operator
begin_operator
board car18 loc40
1
65 34
2
0 0 0 10
0 45 34 41
1
end_operator
begin_operator
board car18 loc41
1
65 35
2
0 0 0 10
0 45 35 41
1
end_operator
begin_operator
board car18 loc5
1
65 36
2
0 0 0 10
0 45 36 41
1
end_operator
begin_operator
board car18 loc6
1
65 37
2
0 0 0 10
0 45 37 41
1
end_operator
begin_operator
board car18 loc7
1
65 38
2
0 0 0 10
0 45 38 41
1
end_operator
begin_operator
board car18 loc8
1
65 39
2
0 0 0 10
0 45 39 41
1
end_operator
begin_operator
board car18 loc9
1
65 40
2
0 0 0 10
0 45 40 41
1
end_operator
begin_operator
board car19 loc1
1
65 0
2
0 0 0 11
0 57 0 41
1
end_operator
begin_operator
board car19 loc10
1
65 1
2
0 0 0 11
0 57 1 41
1
end_operator
begin_operator
board car19 loc11
1
65 2
2
0 0 0 11
0 57 2 41
1
end_operator
begin_operator
board car19 loc12
1
65 3
2
0 0 0 11
0 57 3 41
1
end_operator
begin_operator
board car19 loc13
1
65 4
2
0 0 0 11
0 57 4 41
1
end_operator
begin_operator
board car19 loc14
1
65 5
2
0 0 0 11
0 57 5 41
1
end_operator
begin_operator
board car19 loc15
1
65 6
2
0 0 0 11
0 57 6 41
1
end_operator
begin_operator
board car19 loc16
1
65 7
2
0 0 0 11
0 57 7 41
1
end_operator
begin_operator
board car19 loc17
1
65 8
2
0 0 0 11
0 57 8 41
1
end_operator
begin_operator
board car19 loc18
1
65 9
2
0 0 0 11
0 57 9 41
1
end_operator
begin_operator
board car19 loc19
1
65 10
2
0 0 0 11
0 57 10 41
1
end_operator
begin_operator
board car19 loc2
1
65 11
2
0 0 0 11
0 57 11 41
1
end_operator
begin_operator
board car19 loc20
1
65 12
2
0 0 0 11
0 57 12 41
1
end_operator
begin_operator
board car19 loc21
1
65 13
2
0 0 0 11
0 57 13 41
1
end_operator
begin_operator
board car19 loc22
1
65 14
2
0 0 0 11
0 57 14 41
1
end_operator
begin_operator
board car19 loc23
1
65 15
2
0 0 0 11
0 57 15 41
1
end_operator
begin_operator
board car19 loc24
1
65 16
2
0 0 0 11
0 57 16 41
1
end_operator
begin_operator
board car19 loc25
1
65 17
2
0 0 0 11
0 57 17 41
1
end_operator
begin_operator
board car19 loc26
1
65 18
2
0 0 0 11
0 57 18 41
1
end_operator
begin_operator
board car19 loc27
1
65 19
2
0 0 0 11
0 57 19 41
1
end_operator
begin_operator
board car19 loc28
1
65 20
2
0 0 0 11
0 57 20 41
1
end_operator
begin_operator
board car19 loc29
1
65 21
2
0 0 0 11
0 57 21 41
1
end_operator
begin_operator
board car19 loc3
1
65 22
2
0 0 0 11
0 57 22 41
1
end_operator
begin_operator
board car19 loc30
1
65 23
2
0 0 0 11
0 57 23 41
1
end_operator
begin_operator
board car19 loc31
1
65 24
2
0 0 0 11
0 57 24 41
1
end_operator
begin_operator
board car19 loc32
1
65 25
2
0 0 0 11
0 57 25 41
1
end_operator
begin_operator
board car19 loc33
1
65 26
2
0 0 0 11
0 57 26 41
1
end_operator
begin_operator
board car19 loc34
1
65 27
2
0 0 0 11
0 57 27 41
1
end_operator
begin_operator
board car19 loc35
1
65 28
2
0 0 0 11
0 57 28 41
1
end_operator
begin_operator
board car19 loc36
1
65 29
2
0 0 0 11
0 57 29 41
1
end_operator
begin_operator
board car19 loc37
1
65 30
2
0 0 0 11
0 57 30 41
1
end_operator
begin_operator
board car19 loc38
1
65 31
2
0 0 0 11
0 57 31 41
1
end_operator
begin_operator
board car19 loc39
1
65 32
2
0 0 0 11
0 57 32 41
1
end_operator
begin_operator
board car19 loc4
1
65 33
2
0 0 0 11
0 57 33 41
1
end_operator
begin_operator
board car19 loc40
1
65 34
2
0 0 0 11
0 57 34 41
1
end_operator
begin_operator
board car19 loc41
1
65 35
2
0 0 0 11
0 57 35 41
1
end_operator
begin_operator
board car19 loc5
1
65 36
2
0 0 0 11
0 57 36 41
1
end_operator
begin_operator
board car19 loc6
1
65 37
2
0 0 0 11
0 57 37 41
1
end_operator
begin_operator
board car19 loc7
1
65 38
2
0 0 0 11
0 57 38 41
1
end_operator
begin_operator
board car19 loc8
1
65 39
2
0 0 0 11
0 57 39 41
1
end_operator
begin_operator
board car19 loc9
1
65 40
2
0 0 0 11
0 57 40 41
1
end_operator
begin_operator
board car2 loc1
1
65 0
2
0 0 0 12
0 69 0 41
1
end_operator
begin_operator
board car2 loc10
1
65 1
2
0 0 0 12
0 69 1 41
1
end_operator
begin_operator
board car2 loc11
1
65 2
2
0 0 0 12
0 69 2 41
1
end_operator
begin_operator
board car2 loc12
1
65 3
2
0 0 0 12
0 69 3 41
1
end_operator
begin_operator
board car2 loc13
1
65 4
2
0 0 0 12
0 69 4 41
1
end_operator
begin_operator
board car2 loc14
1
65 5
2
0 0 0 12
0 69 5 41
1
end_operator
begin_operator
board car2 loc15
1
65 6
2
0 0 0 12
0 69 6 41
1
end_operator
begin_operator
board car2 loc16
1
65 7
2
0 0 0 12
0 69 7 41
1
end_operator
begin_operator
board car2 loc17
1
65 8
2
0 0 0 12
0 69 8 41
1
end_operator
begin_operator
board car2 loc18
1
65 9
2
0 0 0 12
0 69 9 41
1
end_operator
begin_operator
board car2 loc19
1
65 10
2
0 0 0 12
0 69 10 41
1
end_operator
begin_operator
board car2 loc2
1
65 11
2
0 0 0 12
0 69 11 41
1
end_operator
begin_operator
board car2 loc20
1
65 12
2
0 0 0 12
0 69 12 41
1
end_operator
begin_operator
board car2 loc21
1
65 13
2
0 0 0 12
0 69 13 41
1
end_operator
begin_operator
board car2 loc22
1
65 14
2
0 0 0 12
0 69 14 41
1
end_operator
begin_operator
board car2 loc23
1
65 15
2
0 0 0 12
0 69 15 41
1
end_operator
begin_operator
board car2 loc24
1
65 16
2
0 0 0 12
0 69 16 41
1
end_operator
begin_operator
board car2 loc25
1
65 17
2
0 0 0 12
0 69 17 41
1
end_operator
begin_operator
board car2 loc26
1
65 18
2
0 0 0 12
0 69 18 41
1
end_operator
begin_operator
board car2 loc27
1
65 19
2
0 0 0 12
0 69 19 41
1
end_operator
begin_operator
board car2 loc28
1
65 20
2
0 0 0 12
0 69 20 41
1
end_operator
begin_operator
board car2 loc29
1
65 21
2
0 0 0 12
0 69 21 41
1
end_operator
begin_operator
board car2 loc3
1
65 22
2
0 0 0 12
0 69 22 41
1
end_operator
begin_operator
board car2 loc30
1
65 23
2
0 0 0 12
0 69 23 41
1
end_operator
begin_operator
board car2 loc31
1
65 24
2
0 0 0 12
0 69 24 41
1
end_operator
begin_operator
board car2 loc32
1
65 25
2
0 0 0 12
0 69 25 41
1
end_operator
begin_operator
board car2 loc33
1
65 26
2
0 0 0 12
0 69 26 41
1
end_operator
begin_operator
board car2 loc34
1
65 27
2
0 0 0 12
0 69 27 41
1
end_operator
begin_operator
board car2 loc35
1
65 28
2
0 0 0 12
0 69 28 41
1
end_operator
begin_operator
board car2 loc36
1
65 29
2
0 0 0 12
0 69 29 41
1
end_operator
begin_operator
board car2 loc37
1
65 30
2
0 0 0 12
0 69 30 41
1
end_operator
begin_operator
board car2 loc38
1
65 31
2
0 0 0 12
0 69 31 41
1
end_operator
begin_operator
board car2 loc39
1
65 32
2
0 0 0 12
0 69 32 41
1
end_operator
begin_operator
board car2 loc4
1
65 33
2
0 0 0 12
0 69 33 41
1
end_operator
begin_operator
board car2 loc40
1
65 34
2
0 0 0 12
0 69 34 41
1
end_operator
begin_operator
board car2 loc41
1
65 35
2
0 0 0 12
0 69 35 41
1
end_operator
begin_operator
board car2 loc5
1
65 36
2
0 0 0 12
0 69 36 41
1
end_operator
begin_operator
board car2 loc6
1
65 37
2
0 0 0 12
0 69 37 41
1
end_operator
begin_operator
board car2 loc7
1
65 38
2
0 0 0 12
0 69 38 41
1
end_operator
begin_operator
board car2 loc8
1
65 39
2
0 0 0 12
0 69 39 41
1
end_operator
begin_operator
board car2 loc9
1
65 40
2
0 0 0 12
0 69 40 41
1
end_operator
begin_operator
board car20 loc1
1
65 0
2
0 0 0 13
0 6 0 41
1
end_operator
begin_operator
board car20 loc10
1
65 1
2
0 0 0 13
0 6 1 41
1
end_operator
begin_operator
board car20 loc11
1
65 2
2
0 0 0 13
0 6 2 41
1
end_operator
begin_operator
board car20 loc12
1
65 3
2
0 0 0 13
0 6 3 41
1
end_operator
begin_operator
board car20 loc13
1
65 4
2
0 0 0 13
0 6 4 41
1
end_operator
begin_operator
board car20 loc14
1
65 5
2
0 0 0 13
0 6 5 41
1
end_operator
begin_operator
board car20 loc15
1
65 6
2
0 0 0 13
0 6 6 41
1
end_operator
begin_operator
board car20 loc16
1
65 7
2
0 0 0 13
0 6 7 41
1
end_operator
begin_operator
board car20 loc17
1
65 8
2
0 0 0 13
0 6 8 41
1
end_operator
begin_operator
board car20 loc18
1
65 9
2
0 0 0 13
0 6 9 41
1
end_operator
begin_operator
board car20 loc19
1
65 10
2
0 0 0 13
0 6 10 41
1
end_operator
begin_operator
board car20 loc2
1
65 11
2
0 0 0 13
0 6 11 41
1
end_operator
begin_operator
board car20 loc20
1
65 12
2
0 0 0 13
0 6 12 41
1
end_operator
begin_operator
board car20 loc21
1
65 13
2
0 0 0 13
0 6 13 41
1
end_operator
begin_operator
board car20 loc22
1
65 14
2
0 0 0 13
0 6 14 41
1
end_operator
begin_operator
board car20 loc23
1
65 15
2
0 0 0 13
0 6 15 41
1
end_operator
begin_operator
board car20 loc24
1
65 16
2
0 0 0 13
0 6 16 41
1
end_operator
begin_operator
board car20 loc25
1
65 17
2
0 0 0 13
0 6 17 41
1
end_operator
begin_operator
board car20 loc26
1
65 18
2
0 0 0 13
0 6 18 41
1
end_operator
begin_operator
board car20 loc27
1
65 19
2
0 0 0 13
0 6 19 41
1
end_operator
begin_operator
board car20 loc28
1
65 20
2
0 0 0 13
0 6 20 41
1
end_operator
begin_operator
board car20 loc29
1
65 21
2
0 0 0 13
0 6 21 41
1
end_operator
begin_operator
board car20 loc3
1
65 22
2
0 0 0 13
0 6 22 41
1
end_operator
begin_operator
board car20 loc30
1
65 23
2
0 0 0 13
0 6 23 41
1
end_operator
begin_operator
board car20 loc31
1
65 24
2
0 0 0 13
0 6 24 41
1
end_operator
begin_operator
board car20 loc32
1
65 25
2
0 0 0 13
0 6 25 41
1
end_operator
begin_operator
board car20 loc33
1
65 26
2
0 0 0 13
0 6 26 41
1
end_operator
begin_operator
board car20 loc34
1
65 27
2
0 0 0 13
0 6 27 41
1
end_operator
begin_operator
board car20 loc35
1
65 28
2
0 0 0 13
0 6 28 41
1
end_operator
begin_operator
board car20 loc36
1
65 29
2
0 0 0 13
0 6 29 41
1
end_operator
begin_operator
board car20 loc37
1
65 30
2
0 0 0 13
0 6 30 41
1
end_operator
begin_operator
board car20 loc38
1
65 31
2
0 0 0 13
0 6 31 41
1
end_operator
begin_operator
board car20 loc39
1
65 32
2
0 0 0 13
0 6 32 41
1
end_operator
begin_operator
board car20 loc4
1
65 33
2
0 0 0 13
0 6 33 41
1
end_operator
begin_operator
board car20 loc40
1
65 34
2
0 0 0 13
0 6 34 41
1
end_operator
begin_operator
board car20 loc41
1
65 35
2
0 0 0 13
0 6 35 41
1
end_operator
begin_operator
board car20 loc5
1
65 36
2
0 0 0 13
0 6 36 41
1
end_operator
begin_operator
board car20 loc6
1
65 37
2
0 0 0 13
0 6 37 41
1
end_operator
begin_operator
board car20 loc7
1
65 38
2
0 0 0 13
0 6 38 41
1
end_operator
begin_operator
board car20 loc8
1
65 39
2
0 0 0 13
0 6 39 41
1
end_operator
begin_operator
board car20 loc9
1
65 40
2
0 0 0 13
0 6 40 41
1
end_operator
begin_operator
board car21 loc1
1
65 0
2
0 0 0 14
0 18 0 41
1
end_operator
begin_operator
board car21 loc10
1
65 1
2
0 0 0 14
0 18 1 41
1
end_operator
begin_operator
board car21 loc11
1
65 2
2
0 0 0 14
0 18 2 41
1
end_operator
begin_operator
board car21 loc12
1
65 3
2
0 0 0 14
0 18 3 41
1
end_operator
begin_operator
board car21 loc13
1
65 4
2
0 0 0 14
0 18 4 41
1
end_operator
begin_operator
board car21 loc14
1
65 5
2
0 0 0 14
0 18 5 41
1
end_operator
begin_operator
board car21 loc15
1
65 6
2
0 0 0 14
0 18 6 41
1
end_operator
begin_operator
board car21 loc16
1
65 7
2
0 0 0 14
0 18 7 41
1
end_operator
begin_operator
board car21 loc17
1
65 8
2
0 0 0 14
0 18 8 41
1
end_operator
begin_operator
board car21 loc18
1
65 9
2
0 0 0 14
0 18 9 41
1
end_operator
begin_operator
board car21 loc19
1
65 10
2
0 0 0 14
0 18 10 41
1
end_operator
begin_operator
board car21 loc2
1
65 11
2
0 0 0 14
0 18 11 41
1
end_operator
begin_operator
board car21 loc20
1
65 12
2
0 0 0 14
0 18 12 41
1
end_operator
begin_operator
board car21 loc21
1
65 13
2
0 0 0 14
0 18 13 41
1
end_operator
begin_operator
board car21 loc22
1
65 14
2
0 0 0 14
0 18 14 41
1
end_operator
begin_operator
board car21 loc23
1
65 15
2
0 0 0 14
0 18 15 41
1
end_operator
begin_operator
board car21 loc24
1
65 16
2
0 0 0 14
0 18 16 41
1
end_operator
begin_operator
board car21 loc25
1
65 17
2
0 0 0 14
0 18 17 41
1
end_operator
begin_operator
board car21 loc26
1
65 18
2
0 0 0 14
0 18 18 41
1
end_operator
begin_operator
board car21 loc27
1
65 19
2
0 0 0 14
0 18 19 41
1
end_operator
begin_operator
board car21 loc28
1
65 20
2
0 0 0 14
0 18 20 41
1
end_operator
begin_operator
board car21 loc29
1
65 21
2
0 0 0 14
0 18 21 41
1
end_operator
begin_operator
board car21 loc3
1
65 22
2
0 0 0 14
0 18 22 41
1
end_operator
begin_operator
board car21 loc30
1
65 23
2
0 0 0 14
0 18 23 41
1
end_operator
begin_operator
board car21 loc31
1
65 24
2
0 0 0 14
0 18 24 41
1
end_operator
begin_operator
board car21 loc32
1
65 25
2
0 0 0 14
0 18 25 41
1
end_operator
begin_operator
board car21 loc33
1
65 26
2
0 0 0 14
0 18 26 41
1
end_operator
begin_operator
board car21 loc34
1
65 27
2
0 0 0 14
0 18 27 41
1
end_operator
begin_operator
board car21 loc35
1
65 28
2
0 0 0 14
0 18 28 41
1
end_operator
begin_operator
board car21 loc36
1
65 29
2
0 0 0 14
0 18 29 41
1
end_operator
begin_operator
board car21 loc37
1
65 30
2
0 0 0 14
0 18 30 41
1
end_operator
begin_operator
board car21 loc38
1
65 31
2
0 0 0 14
0 18 31 41
1
end_operator
begin_operator
board car21 loc39
1
65 32
2
0 0 0 14
0 18 32 41
1
end_operator
begin_operator
board car21 loc4
1
65 33
2
0 0 0 14
0 18 33 41
1
end_operator
begin_operator
board car21 loc40
1
65 34
2
0 0 0 14
0 18 34 41
1
end_operator
begin_operator
board car21 loc41
1
65 35
2
0 0 0 14
0 18 35 41
1
end_operator
begin_operator
board car21 loc5
1
65 36
2
0 0 0 14
0 18 36 41
1
end_operator
begin_operator
board car21 loc6
1
65 37
2
0 0 0 14
0 18 37 41
1
end_operator
begin_operator
board car21 loc7
1
65 38
2
0 0 0 14
0 18 38 41
1
end_operator
begin_operator
board car21 loc8
1
65 39
2
0 0 0 14
0 18 39 41
1
end_operator
begin_operator
board car21 loc9
1
65 40
2
0 0 0 14
0 18 40 41
1
end_operator
begin_operator
board car22 loc1
1
65 0
2
0 0 0 15
0 30 0 41
1
end_operator
begin_operator
board car22 loc10
1
65 1
2
0 0 0 15
0 30 1 41
1
end_operator
begin_operator
board car22 loc11
1
65 2
2
0 0 0 15
0 30 2 41
1
end_operator
begin_operator
board car22 loc12
1
65 3
2
0 0 0 15
0 30 3 41
1
end_operator
begin_operator
board car22 loc13
1
65 4
2
0 0 0 15
0 30 4 41
1
end_operator
begin_operator
board car22 loc14
1
65 5
2
0 0 0 15
0 30 5 41
1
end_operator
begin_operator
board car22 loc15
1
65 6
2
0 0 0 15
0 30 6 41
1
end_operator
begin_operator
board car22 loc16
1
65 7
2
0 0 0 15
0 30 7 41
1
end_operator
begin_operator
board car22 loc17
1
65 8
2
0 0 0 15
0 30 8 41
1
end_operator
begin_operator
board car22 loc18
1
65 9
2
0 0 0 15
0 30 9 41
1
end_operator
begin_operator
board car22 loc19
1
65 10
2
0 0 0 15
0 30 10 41
1
end_operator
begin_operator
board car22 loc2
1
65 11
2
0 0 0 15
0 30 11 41
1
end_operator
begin_operator
board car22 loc20
1
65 12
2
0 0 0 15
0 30 12 41
1
end_operator
begin_operator
board car22 loc21
1
65 13
2
0 0 0 15
0 30 13 41
1
end_operator
begin_operator
board car22 loc22
1
65 14
2
0 0 0 15
0 30 14 41
1
end_operator
begin_operator
board car22 loc23
1
65 15
2
0 0 0 15
0 30 15 41
1
end_operator
begin_operator
board car22 loc24
1
65 16
2
0 0 0 15
0 30 16 41
1
end_operator
begin_operator
board car22 loc25
1
65 17
2
0 0 0 15
0 30 17 41
1
end_operator
begin_operator
board car22 loc26
1
65 18
2
0 0 0 15
0 30 18 41
1
end_operator
begin_operator
board car22 loc27
1
65 19
2
0 0 0 15
0 30 19 41
1
end_operator
begin_operator
board car22 loc28
1
65 20
2
0 0 0 15
0 30 20 41
1
end_operator
begin_operator
board car22 loc29
1
65 21
2
0 0 0 15
0 30 21 41
1
end_operator
begin_operator
board car22 loc3
1
65 22
2
0 0 0 15
0 30 22 41
1
end_operator
begin_operator
board car22 loc30
1
65 23
2
0 0 0 15
0 30 23 41
1
end_operator
begin_operator
board car22 loc31
1
65 24
2
0 0 0 15
0 30 24 41
1
end_operator
begin_operator
board car22 loc32
1
65 25
2
0 0 0 15
0 30 25 41
1
end_operator
begin_operator
board car22 loc33
1
65 26
2
0 0 0 15
0 30 26 41
1
end_operator
begin_operator
board car22 loc34
1
65 27
2
0 0 0 15
0 30 27 41
1
end_operator
begin_operator
board car22 loc35
1
65 28
2
0 0 0 15
0 30 28 41
1
end_operator
begin_operator
board car22 loc36
1
65 29
2
0 0 0 15
0 30 29 41
1
end_operator
begin_operator
board car22 loc37
1
65 30
2
0 0 0 15
0 30 30 41
1
end_operator
begin_operator
board car22 loc38
1
65 31
2
0 0 0 15
0 30 31 41
1
end_operator
begin_operator
board car22 loc39
1
65 32
2
0 0 0 15
0 30 32 41
1
end_operator
begin_operator
board car22 loc4
1
65 33
2
0 0 0 15
0 30 33 41
1
end_operator
begin_operator
board car22 loc40
1
65 34
2
0 0 0 15
0 30 34 41
1
end_operator
begin_operator
board car22 loc41
1
65 35
2
0 0 0 15
0 30 35 41
1
end_operator
begin_operator
board car22 loc5
1
65 36
2
0 0 0 15
0 30 36 41
1
end_operator
begin_operator
board car22 loc6
1
65 37
2
0 0 0 15
0 30 37 41
1
end_operator
begin_operator
board car22 loc7
1
65 38
2
0 0 0 15
0 30 38 41
1
end_operator
begin_operator
board car22 loc8
1
65 39
2
0 0 0 15
0 30 39 41
1
end_operator
begin_operator
board car22 loc9
1
65 40
2
0 0 0 15
0 30 40 41
1
end_operator
begin_operator
board car23 loc1
1
65 0
2
0 0 0 16
0 42 0 41
1
end_operator
begin_operator
board car23 loc10
1
65 1
2
0 0 0 16
0 42 1 41
1
end_operator
begin_operator
board car23 loc11
1
65 2
2
0 0 0 16
0 42 2 41
1
end_operator
begin_operator
board car23 loc12
1
65 3
2
0 0 0 16
0 42 3 41
1
end_operator
begin_operator
board car23 loc13
1
65 4
2
0 0 0 16
0 42 4 41
1
end_operator
begin_operator
board car23 loc14
1
65 5
2
0 0 0 16
0 42 5 41
1
end_operator
begin_operator
board car23 loc15
1
65 6
2
0 0 0 16
0 42 6 41
1
end_operator
begin_operator
board car23 loc16
1
65 7
2
0 0 0 16
0 42 7 41
1
end_operator
begin_operator
board car23 loc17
1
65 8
2
0 0 0 16
0 42 8 41
1
end_operator
begin_operator
board car23 loc18
1
65 9
2
0 0 0 16
0 42 9 41
1
end_operator
begin_operator
board car23 loc19
1
65 10
2
0 0 0 16
0 42 10 41
1
end_operator
begin_operator
board car23 loc2
1
65 11
2
0 0 0 16
0 42 11 41
1
end_operator
begin_operator
board car23 loc20
1
65 12
2
0 0 0 16
0 42 12 41
1
end_operator
begin_operator
board car23 loc21
1
65 13
2
0 0 0 16
0 42 13 41
1
end_operator
begin_operator
board car23 loc22
1
65 14
2
0 0 0 16
0 42 14 41
1
end_operator
begin_operator
board car23 loc23
1
65 15
2
0 0 0 16
0 42 15 41
1
end_operator
begin_operator
board car23 loc24
1
65 16
2
0 0 0 16
0 42 16 41
1
end_operator
begin_operator
board car23 loc25
1
65 17
2
0 0 0 16
0 42 17 41
1
end_operator
begin_operator
board car23 loc26
1
65 18
2
0 0 0 16
0 42 18 41
1
end_operator
begin_operator
board car23 loc27
1
65 19
2
0 0 0 16
0 42 19 41
1
end_operator
begin_operator
board car23 loc28
1
65 20
2
0 0 0 16
0 42 20 41
1
end_operator
begin_operator
board car23 loc29
1
65 21
2
0 0 0 16
0 42 21 41
1
end_operator
begin_operator
board car23 loc3
1
65 22
2
0 0 0 16
0 42 22 41
1
end_operator
begin_operator
board car23 loc30
1
65 23
2
0 0 0 16
0 42 23 41
1
end_operator
begin_operator
board car23 loc31
1
65 24
2
0 0 0 16
0 42 24 41
1
end_operator
begin_operator
board car23 loc32
1
65 25
2
0 0 0 16
0 42 25 41
1
end_operator
begin_operator
board car23 loc33
1
65 26
2
0 0 0 16
0 42 26 41
1
end_operator
begin_operator
board car23 loc34
1
65 27
2
0 0 0 16
0 42 27 41
1
end_operator
begin_operator
board car23 loc35
1
65 28
2
0 0 0 16
0 42 28 41
1
end_operator
begin_operator
board car23 loc36
1
65 29
2
0 0 0 16
0 42 29 41
1
end_operator
begin_operator
board car23 loc37
1
65 30
2
0 0 0 16
0 42 30 41
1
end_operator
begin_operator
board car23 loc38
1
65 31
2
0 0 0 16
0 42 31 41
1
end_operator
begin_operator
board car23 loc39
1
65 32
2
0 0 0 16
0 42 32 41
1
end_operator
begin_operator
board car23 loc4
1
65 33
2
0 0 0 16
0 42 33 41
1
end_operator
begin_operator
board car23 loc40
1
65 34
2
0 0 0 16
0 42 34 41
1
end_operator
begin_operator
board car23 loc41
1
65 35
2
0 0 0 16
0 42 35 41
1
end_operator
begin_operator
board car23 loc5
1
65 36
2
0 0 0 16
0 42 36 41
1
end_operator
begin_operator
board car23 loc6
1
65 37
2
0 0 0 16
0 42 37 41
1
end_operator
begin_operator
board car23 loc7
1
65 38
2
0 0 0 16
0 42 38 41
1
end_operator
begin_operator
board car23 loc8
1
65 39
2
0 0 0 16
0 42 39 41
1
end_operator
begin_operator
board car23 loc9
1
65 40
2
0 0 0 16
0 42 40 41
1
end_operator
begin_operator
board car24 loc1
1
65 0
2
0 0 0 17
0 54 0 41
1
end_operator
begin_operator
board car24 loc10
1
65 1
2
0 0 0 17
0 54 1 41
1
end_operator
begin_operator
board car24 loc11
1
65 2
2
0 0 0 17
0 54 2 41
1
end_operator
begin_operator
board car24 loc12
1
65 3
2
0 0 0 17
0 54 3 41
1
end_operator
begin_operator
board car24 loc13
1
65 4
2
0 0 0 17
0 54 4 41
1
end_operator
begin_operator
board car24 loc14
1
65 5
2
0 0 0 17
0 54 5 41
1
end_operator
begin_operator
board car24 loc15
1
65 6
2
0 0 0 17
0 54 6 41
1
end_operator
begin_operator
board car24 loc16
1
65 7
2
0 0 0 17
0 54 7 41
1
end_operator
begin_operator
board car24 loc17
1
65 8
2
0 0 0 17
0 54 8 41
1
end_operator
begin_operator
board car24 loc18
1
65 9
2
0 0 0 17
0 54 9 41
1
end_operator
begin_operator
board car24 loc19
1
65 10
2
0 0 0 17
0 54 10 41
1
end_operator
begin_operator
board car24 loc2
1
65 11
2
0 0 0 17
0 54 11 41
1
end_operator
begin_operator
board car24 loc20
1
65 12
2
0 0 0 17
0 54 12 41
1
end_operator
begin_operator
board car24 loc21
1
65 13
2
0 0 0 17
0 54 13 41
1
end_operator
begin_operator
board car24 loc22
1
65 14
2
0 0 0 17
0 54 14 41
1
end_operator
begin_operator
board car24 loc23
1
65 15
2
0 0 0 17
0 54 15 41
1
end_operator
begin_operator
board car24 loc24
1
65 16
2
0 0 0 17
0 54 16 41
1
end_operator
begin_operator
board car24 loc25
1
65 17
2
0 0 0 17
0 54 17 41
1
end_operator
begin_operator
board car24 loc26
1
65 18
2
0 0 0 17
0 54 18 41
1
end_operator
begin_operator
board car24 loc27
1
65 19
2
0 0 0 17
0 54 19 41
1
end_operator
begin_operator
board car24 loc28
1
65 20
2
0 0 0 17
0 54 20 41
1
end_operator
begin_operator
board car24 loc29
1
65 21
2
0 0 0 17
0 54 21 41
1
end_operator
begin_operator
board car24 loc3
1
65 22
2
0 0 0 17
0 54 22 41
1
end_operator
begin_operator
board car24 loc30
1
65 23
2
0 0 0 17
0 54 23 41
1
end_operator
begin_operator
board car24 loc31
1
65 24
2
0 0 0 17
0 54 24 41
1
end_operator
begin_operator
board car24 loc32
1
65 25
2
0 0 0 17
0 54 25 41
1
end_operator
begin_operator
board car24 loc33
1
65 26
2
0 0 0 17
0 54 26 41
1
end_operator
begin_operator
board car24 loc34
1
65 27
2
0 0 0 17
0 54 27 41
1
end_operator
begin_operator
board car24 loc35
1
65 28
2
0 0 0 17
0 54 28 41
1
end_operator
begin_operator
board car24 loc36
1
65 29
2
0 0 0 17
0 54 29 41
1
end_operator
begin_operator
board car24 loc37
1
65 30
2
0 0 0 17
0 54 30 41
1
end_operator
begin_operator
board car24 loc38
1
65 31
2
0 0 0 17
0 54 31 41
1
end_operator
begin_operator
board car24 loc39
1
65 32
2
0 0 0 17
0 54 32 41
1
end_operator
begin_operator
board car24 loc4
1
65 33
2
0 0 0 17
0 54 33 41
1
end_operator
begin_operator
board car24 loc40
1
65 34
2
0 0 0 17
0 54 34 41
1
end_operator
begin_operator
board car24 loc41
1
65 35
2
0 0 0 17
0 54 35 41
1
end_operator
begin_operator
board car24 loc5
1
65 36
2
0 0 0 17
0 54 36 41
1
end_operator
begin_operator
board car24 loc6
1
65 37
2
0 0 0 17
0 54 37 41
1
end_operator
begin_operator
board car24 loc7
1
65 38
2
0 0 0 17
0 54 38 41
1
end_operator
begin_operator
board car24 loc8
1
65 39
2
0 0 0 17
0 54 39 41
1
end_operator
begin_operator
board car24 loc9
1
65 40
2
0 0 0 17
0 54 40 41
1
end_operator
begin_operator
board car25 loc1
1
65 0
2
0 0 0 18
0 66 0 41
1
end_operator
begin_operator
board car25 loc10
1
65 1
2
0 0 0 18
0 66 1 41
1
end_operator
begin_operator
board car25 loc11
1
65 2
2
0 0 0 18
0 66 2 41
1
end_operator
begin_operator
board car25 loc12
1
65 3
2
0 0 0 18
0 66 3 41
1
end_operator
begin_operator
board car25 loc13
1
65 4
2
0 0 0 18
0 66 4 41
1
end_operator
begin_operator
board car25 loc14
1
65 5
2
0 0 0 18
0 66 5 41
1
end_operator
begin_operator
board car25 loc15
1
65 6
2
0 0 0 18
0 66 6 41
1
end_operator
begin_operator
board car25 loc16
1
65 7
2
0 0 0 18
0 66 7 41
1
end_operator
begin_operator
board car25 loc17
1
65 8
2
0 0 0 18
0 66 8 41
1
end_operator
begin_operator
board car25 loc18
1
65 9
2
0 0 0 18
0 66 9 41
1
end_operator
begin_operator
board car25 loc19
1
65 10
2
0 0 0 18
0 66 10 41
1
end_operator
begin_operator
board car25 loc2
1
65 11
2
0 0 0 18
0 66 11 41
1
end_operator
begin_operator
board car25 loc20
1
65 12
2
0 0 0 18
0 66 12 41
1
end_operator
begin_operator
board car25 loc21
1
65 13
2
0 0 0 18
0 66 13 41
1
end_operator
begin_operator
board car25 loc22
1
65 14
2
0 0 0 18
0 66 14 41
1
end_operator
begin_operator
board car25 loc23
1
65 15
2
0 0 0 18
0 66 15 41
1
end_operator
begin_operator
board car25 loc24
1
65 16
2
0 0 0 18
0 66 16 41
1
end_operator
begin_operator
board car25 loc25
1
65 17
2
0 0 0 18
0 66 17 41
1
end_operator
begin_operator
board car25 loc26
1
65 18
2
0 0 0 18
0 66 18 41
1
end_operator
begin_operator
board car25 loc27
1
65 19
2
0 0 0 18
0 66 19 41
1
end_operator
begin_operator
board car25 loc28
1
65 20
2
0 0 0 18
0 66 20 41
1
end_operator
begin_operator
board car25 loc29
1
65 21
2
0 0 0 18
0 66 21 41
1
end_operator
begin_operator
board car25 loc3
1
65 22
2
0 0 0 18
0 66 22 41
1
end_operator
begin_operator
board car25 loc30
1
65 23
2
0 0 0 18
0 66 23 41
1
end_operator
begin_operator
board car25 loc31
1
65 24
2
0 0 0 18
0 66 24 41
1
end_operator
begin_operator
board car25 loc32
1
65 25
2
0 0 0 18
0 66 25 41
1
end_operator
begin_operator
board car25 loc33
1
65 26
2
0 0 0 18
0 66 26 41
1
end_operator
begin_operator
board car25 loc34
1
65 27
2
0 0 0 18
0 66 27 41
1
end_operator
begin_operator
board car25 loc35
1
65 28
2
0 0 0 18
0 66 28 41
1
end_operator
begin_operator
board car25 loc36
1
65 29
2
0 0 0 18
0 66 29 41
1
end_operator
begin_operator
board car25 loc37
1
65 30
2
0 0 0 18
0 66 30 41
1
end_operator
begin_operator
board car25 loc38
1
65 31
2
0 0 0 18
0 66 31 41
1
end_operator
begin_operator
board car25 loc39
1
65 32
2
0 0 0 18
0 66 32 41
1
end_operator
begin_operator
board car25 loc4
1
65 33
2
0 0 0 18
0 66 33 41
1
end_operator
begin_operator
board car25 loc40
1
65 34
2
0 0 0 18
0 66 34 41
1
end_operator
begin_operator
board car25 loc41
1
65 35
2
0 0 0 18
0 66 35 41
1
end_operator
begin_operator
board car25 loc5
1
65 36
2
0 0 0 18
0 66 36 41
1
end_operator
begin_operator
board car25 loc6
1
65 37
2
0 0 0 18
0 66 37 41
1
end_operator
begin_operator
board car25 loc7
1
65 38
2
0 0 0 18
0 66 38 41
1
end_operator
begin_operator
board car25 loc8
1
65 39
2
0 0 0 18
0 66 39 41
1
end_operator
begin_operator
board car25 loc9
1
65 40
2
0 0 0 18
0 66 40 41
1
end_operator
begin_operator
board car26 loc1
1
65 0
2
0 0 0 19
0 3 0 41
1
end_operator
begin_operator
board car26 loc10
1
65 1
2
0 0 0 19
0 3 1 41
1
end_operator
begin_operator
board car26 loc11
1
65 2
2
0 0 0 19
0 3 2 41
1
end_operator
begin_operator
board car26 loc12
1
65 3
2
0 0 0 19
0 3 3 41
1
end_operator
begin_operator
board car26 loc13
1
65 4
2
0 0 0 19
0 3 4 41
1
end_operator
begin_operator
board car26 loc14
1
65 5
2
0 0 0 19
0 3 5 41
1
end_operator
begin_operator
board car26 loc15
1
65 6
2
0 0 0 19
0 3 6 41
1
end_operator
begin_operator
board car26 loc16
1
65 7
2
0 0 0 19
0 3 7 41
1
end_operator
begin_operator
board car26 loc17
1
65 8
2
0 0 0 19
0 3 8 41
1
end_operator
begin_operator
board car26 loc18
1
65 9
2
0 0 0 19
0 3 9 41
1
end_operator
begin_operator
board car26 loc19
1
65 10
2
0 0 0 19
0 3 10 41
1
end_operator
begin_operator
board car26 loc2
1
65 11
2
0 0 0 19
0 3 11 41
1
end_operator
begin_operator
board car26 loc20
1
65 12
2
0 0 0 19
0 3 12 41
1
end_operator
begin_operator
board car26 loc21
1
65 13
2
0 0 0 19
0 3 13 41
1
end_operator
begin_operator
board car26 loc22
1
65 14
2
0 0 0 19
0 3 14 41
1
end_operator
begin_operator
board car26 loc23
1
65 15
2
0 0 0 19
0 3 15 41
1
end_operator
begin_operator
board car26 loc24
1
65 16
2
0 0 0 19
0 3 16 41
1
end_operator
begin_operator
board car26 loc25
1
65 17
2
0 0 0 19
0 3 17 41
1
end_operator
begin_operator
board car26 loc26
1
65 18
2
0 0 0 19
0 3 18 41
1
end_operator
begin_operator
board car26 loc27
1
65 19
2
0 0 0 19
0 3 19 41
1
end_operator
begin_operator
board car26 loc28
1
65 20
2
0 0 0 19
0 3 20 41
1
end_operator
begin_operator
board car26 loc29
1
65 21
2
0 0 0 19
0 3 21 41
1
end_operator
begin_operator
board car26 loc3
1
65 22
2
0 0 0 19
0 3 22 41
1
end_operator
begin_operator
board car26 loc30
1
65 23
2
0 0 0 19
0 3 23 41
1
end_operator
begin_operator
board car26 loc31
1
65 24
2
0 0 0 19
0 3 24 41
1
end_operator
begin_operator
board car26 loc32
1
65 25
2
0 0 0 19
0 3 25 41
1
end_operator
begin_operator
board car26 loc33
1
65 26
2
0 0 0 19
0 3 26 41
1
end_operator
begin_operator
board car26 loc34
1
65 27
2
0 0 0 19
0 3 27 41
1
end_operator
begin_operator
board car26 loc35
1
65 28
2
0 0 0 19
0 3 28 41
1
end_operator
begin_operator
board car26 loc36
1
65 29
2
0 0 0 19
0 3 29 41
1
end_operator
begin_operator
board car26 loc37
1
65 30
2
0 0 0 19
0 3 30 41
1
end_operator
begin_operator
board car26 loc38
1
65 31
2
0 0 0 19
0 3 31 41
1
end_operator
begin_operator
board car26 loc39
1
65 32
2
0 0 0 19
0 3 32 41
1
end_operator
begin_operator
board car26 loc4
1
65 33
2
0 0 0 19
0 3 33 41
1
end_operator
begin_operator
board car26 loc40
1
65 34
2
0 0 0 19
0 3 34 41
1
end_operator
begin_operator
board car26 loc41
1
65 35
2
0 0 0 19
0 3 35 41
1
end_operator
begin_operator
board car26 loc5
1
65 36
2
0 0 0 19
0 3 36 41
1
end_operator
begin_operator
board car26 loc6
1
65 37
2
0 0 0 19
0 3 37 41
1
end_operator
begin_operator
board car26 loc7
1
65 38
2
0 0 0 19
0 3 38 41
1
end_operator
begin_operator
board car26 loc8
1
65 39
2
0 0 0 19
0 3 39 41
1
end_operator
begin_operator
board car26 loc9
1
65 40
2
0 0 0 19
0 3 40 41
1
end_operator
begin_operator
board car27 loc1
1
65 0
2
0 0 0 20
0 15 0 41
1
end_operator
begin_operator
board car27 loc10
1
65 1
2
0 0 0 20
0 15 1 41
1
end_operator
begin_operator
board car27 loc11
1
65 2
2
0 0 0 20
0 15 2 41
1
end_operator
begin_operator
board car27 loc12
1
65 3
2
0 0 0 20
0 15 3 41
1
end_operator
begin_operator
board car27 loc13
1
65 4
2
0 0 0 20
0 15 4 41
1
end_operator
begin_operator
board car27 loc14
1
65 5
2
0 0 0 20
0 15 5 41
1
end_operator
begin_operator
board car27 loc15
1
65 6
2
0 0 0 20
0 15 6 41
1
end_operator
begin_operator
board car27 loc16
1
65 7
2
0 0 0 20
0 15 7 41
1
end_operator
begin_operator
board car27 loc17
1
65 8
2
0 0 0 20
0 15 8 41
1
end_operator
begin_operator
board car27 loc18
1
65 9
2
0 0 0 20
0 15 9 41
1
end_operator
begin_operator
board car27 loc19
1
65 10
2
0 0 0 20
0 15 10 41
1
end_operator
begin_operator
board car27 loc2
1
65 11
2
0 0 0 20
0 15 11 41
1
end_operator
begin_operator
board car27 loc20
1
65 12
2
0 0 0 20
0 15 12 41
1
end_operator
begin_operator
board car27 loc21
1
65 13
2
0 0 0 20
0 15 13 41
1
end_operator
begin_operator
board car27 loc22
1
65 14
2
0 0 0 20
0 15 14 41
1
end_operator
begin_operator
board car27 loc23
1
65 15
2
0 0 0 20
0 15 15 41
1
end_operator
begin_operator
board car27 loc24
1
65 16
2
0 0 0 20
0 15 16 41
1
end_operator
begin_operator
board car27 loc25
1
65 17
2
0 0 0 20
0 15 17 41
1
end_operator
begin_operator
board car27 loc26
1
65 18
2
0 0 0 20
0 15 18 41
1
end_operator
begin_operator
board car27 loc27
1
65 19
2
0 0 0 20
0 15 19 41
1
end_operator
begin_operator
board car27 loc28
1
65 20
2
0 0 0 20
0 15 20 41
1
end_operator
begin_operator
board car27 loc29
1
65 21
2
0 0 0 20
0 15 21 41
1
end_operator
begin_operator
board car27 loc3
1
65 22
2
0 0 0 20
0 15 22 41
1
end_operator
begin_operator
board car27 loc30
1
65 23
2
0 0 0 20
0 15 23 41
1
end_operator
begin_operator
board car27 loc31
1
65 24
2
0 0 0 20
0 15 24 41
1
end_operator
begin_operator
board car27 loc32
1
65 25
2
0 0 0 20
0 15 25 41
1
end_operator
begin_operator
board car27 loc33
1
65 26
2
0 0 0 20
0 15 26 41
1
end_operator
begin_operator
board car27 loc34
1
65 27
2
0 0 0 20
0 15 27 41
1
end_operator
begin_operator
board car27 loc35
1
65 28
2
0 0 0 20
0 15 28 41
1
end_operator
begin_operator
board car27 loc36
1
65 29
2
0 0 0 20
0 15 29 41
1
end_operator
begin_operator
board car27 loc37
1
65 30
2
0 0 0 20
0 15 30 41
1
end_operator
begin_operator
board car27 loc38
1
65 31
2
0 0 0 20
0 15 31 41
1
end_operator
begin_operator
board car27 loc39
1
65 32
2
0 0 0 20
0 15 32 41
1
end_operator
begin_operator
board car27 loc4
1
65 33
2
0 0 0 20
0 15 33 41
1
end_operator
begin_operator
board car27 loc40
1
65 34
2
0 0 0 20
0 15 34 41
1
end_operator
begin_operator
board car27 loc41
1
65 35
2
0 0 0 20
0 15 35 41
1
end_operator
begin_operator
board car27 loc5
1
65 36
2
0 0 0 20
0 15 36 41
1
end_operator
begin_operator
board car27 loc6
1
65 37
2
0 0 0 20
0 15 37 41
1
end_operator
begin_operator
board car27 loc7
1
65 38
2
0 0 0 20
0 15 38 41
1
end_operator
begin_operator
board car27 loc8
1
65 39
2
0 0 0 20
0 15 39 41
1
end_operator
begin_operator
board car27 loc9
1
65 40
2
0 0 0 20
0 15 40 41
1
end_operator
begin_operator
board car28 loc1
1
65 0
2
0 0 0 21
0 27 0 41
1
end_operator
begin_operator
board car28 loc10
1
65 1
2
0 0 0 21
0 27 1 41
1
end_operator
begin_operator
board car28 loc11
1
65 2
2
0 0 0 21
0 27 2 41
1
end_operator
begin_operator
board car28 loc12
1
65 3
2
0 0 0 21
0 27 3 41
1
end_operator
begin_operator
board car28 loc13
1
65 4
2
0 0 0 21
0 27 4 41
1
end_operator
begin_operator
board car28 loc14
1
65 5
2
0 0 0 21
0 27 5 41
1
end_operator
begin_operator
board car28 loc15
1
65 6
2
0 0 0 21
0 27 6 41
1
end_operator
begin_operator
board car28 loc16
1
65 7
2
0 0 0 21
0 27 7 41
1
end_operator
begin_operator
board car28 loc17
1
65 8
2
0 0 0 21
0 27 8 41
1
end_operator
begin_operator
board car28 loc18
1
65 9
2
0 0 0 21
0 27 9 41
1
end_operator
begin_operator
board car28 loc19
1
65 10
2
0 0 0 21
0 27 10 41
1
end_operator
begin_operator
board car28 loc2
1
65 11
2
0 0 0 21
0 27 11 41
1
end_operator
begin_operator
board car28 loc20
1
65 12
2
0 0 0 21
0 27 12 41
1
end_operator
begin_operator
board car28 loc21
1
65 13
2
0 0 0 21
0 27 13 41
1
end_operator
begin_operator
board car28 loc22
1
65 14
2
0 0 0 21
0 27 14 41
1
end_operator
begin_operator
board car28 loc23
1
65 15
2
0 0 0 21
0 27 15 41
1
end_operator
begin_operator
board car28 loc24
1
65 16
2
0 0 0 21
0 27 16 41
1
end_operator
begin_operator
board car28 loc25
1
65 17
2
0 0 0 21
0 27 17 41
1
end_operator
begin_operator
board car28 loc26
1
65 18
2
0 0 0 21
0 27 18 41
1
end_operator
begin_operator
board car28 loc27
1
65 19
2
0 0 0 21
0 27 19 41
1
end_operator
begin_operator
board car28 loc28
1
65 20
2
0 0 0 21
0 27 20 41
1
end_operator
begin_operator
board car28 loc29
1
65 21
2
0 0 0 21
0 27 21 41
1
end_operator
begin_operator
board car28 loc3
1
65 22
2
0 0 0 21
0 27 22 41
1
end_operator
begin_operator
board car28 loc30
1
65 23
2
0 0 0 21
0 27 23 41
1
end_operator
begin_operator
board car28 loc31
1
65 24
2
0 0 0 21
0 27 24 41
1
end_operator
begin_operator
board car28 loc32
1
65 25
2
0 0 0 21
0 27 25 41
1
end_operator
begin_operator
board car28 loc33
1
65 26
2
0 0 0 21
0 27 26 41
1
end_operator
begin_operator
board car28 loc34
1
65 27
2
0 0 0 21
0 27 27 41
1
end_operator
begin_operator
board car28 loc35
1
65 28
2
0 0 0 21
0 27 28 41
1
end_operator
begin_operator
board car28 loc36
1
65 29
2
0 0 0 21
0 27 29 41
1
end_operator
begin_operator
board car28 loc37
1
65 30
2
0 0 0 21
0 27 30 41
1
end_operator
begin_operator
board car28 loc38
1
65 31
2
0 0 0 21
0 27 31 41
1
end_operator
begin_operator
board car28 loc39
1
65 32
2
0 0 0 21
0 27 32 41
1
end_operator
begin_operator
board car28 loc4
1
65 33
2
0 0 0 21
0 27 33 41
1
end_operator
begin_operator
board car28 loc40
1
65 34
2
0 0 0 21
0 27 34 41
1
end_operator
begin_operator
board car28 loc41
1
65 35
2
0 0 0 21
0 27 35 41
1
end_operator
begin_operator
board car28 loc5
1
65 36
2
0 0 0 21
0 27 36 41
1
end_operator
begin_operator
board car28 loc6
1
65 37
2
0 0 0 21
0 27 37 41
1
end_operator
begin_operator
board car28 loc7
1
65 38
2
0 0 0 21
0 27 38 41
1
end_operator
begin_operator
board car28 loc8
1
65 39
2
0 0 0 21
0 27 39 41
1
end_operator
begin_operator
board car28 loc9
1
65 40
2
0 0 0 21
0 27 40 41
1
end_operator
begin_operator
board car29 loc1
1
65 0
2
0 0 0 22
0 39 0 41
1
end_operator
begin_operator
board car29 loc10
1
65 1
2
0 0 0 22
0 39 1 41
1
end_operator
begin_operator
board car29 loc11
1
65 2
2
0 0 0 22
0 39 2 41
1
end_operator
begin_operator
board car29 loc12
1
65 3
2
0 0 0 22
0 39 3 41
1
end_operator
begin_operator
board car29 loc13
1
65 4
2
0 0 0 22
0 39 4 41
1
end_operator
begin_operator
board car29 loc14
1
65 5
2
0 0 0 22
0 39 5 41
1
end_operator
begin_operator
board car29 loc15
1
65 6
2
0 0 0 22
0 39 6 41
1
end_operator
begin_operator
board car29 loc16
1
65 7
2
0 0 0 22
0 39 7 41
1
end_operator
begin_operator
board car29 loc17
1
65 8
2
0 0 0 22
0 39 8 41
1
end_operator
begin_operator
board car29 loc18
1
65 9
2
0 0 0 22
0 39 9 41
1
end_operator
begin_operator
board car29 loc19
1
65 10
2
0 0 0 22
0 39 10 41
1
end_operator
begin_operator
board car29 loc2
1
65 11
2
0 0 0 22
0 39 11 41
1
end_operator
begin_operator
board car29 loc20
1
65 12
2
0 0 0 22
0 39 12 41
1
end_operator
begin_operator
board car29 loc21
1
65 13
2
0 0 0 22
0 39 13 41
1
end_operator
begin_operator
board car29 loc22
1
65 14
2
0 0 0 22
0 39 14 41
1
end_operator
begin_operator
board car29 loc23
1
65 15
2
0 0 0 22
0 39 15 41
1
end_operator
begin_operator
board car29 loc24
1
65 16
2
0 0 0 22
0 39 16 41
1
end_operator
begin_operator
board car29 loc25
1
65 17
2
0 0 0 22
0 39 17 41
1
end_operator
begin_operator
board car29 loc26
1
65 18
2
0 0 0 22
0 39 18 41
1
end_operator
begin_operator
board car29 loc27
1
65 19
2
0 0 0 22
0 39 19 41
1
end_operator
begin_operator
board car29 loc28
1
65 20
2
0 0 0 22
0 39 20 41
1
end_operator
begin_operator
board car29 loc29
1
65 21
2
0 0 0 22
0 39 21 41
1
end_operator
begin_operator
board car29 loc3
1
65 22
2
0 0 0 22
0 39 22 41
1
end_operator
begin_operator
board car29 loc30
1
65 23
2
0 0 0 22
0 39 23 41
1
end_operator
begin_operator
board car29 loc31
1
65 24
2
0 0 0 22
0 39 24 41
1
end_operator
begin_operator
board car29 loc32
1
65 25
2
0 0 0 22
0 39 25 41
1
end_operator
begin_operator
board car29 loc33
1
65 26
2
0 0 0 22
0 39 26 41
1
end_operator
begin_operator
board car29 loc34
1
65 27
2
0 0 0 22
0 39 27 41
1
end_operator
begin_operator
board car29 loc35
1
65 28
2
0 0 0 22
0 39 28 41
1
end_operator
begin_operator
board car29 loc36
1
65 29
2
0 0 0 22
0 39 29 41
1
end_operator
begin_operator
board car29 loc37
1
65 30
2
0 0 0 22
0 39 30 41
1
end_operator
begin_operator
board car29 loc38
1
65 31
2
0 0 0 22
0 39 31 41
1
end_operator
begin_operator
board car29 loc39
1
65 32
2
0 0 0 22
0 39 32 41
1
end_operator
begin_operator
board car29 loc4
1
65 33
2
0 0 0 22
0 39 33 41
1
end_operator
begin_operator
board car29 loc40
1
65 34
2
0 0 0 22
0 39 34 41
1
end_operator
begin_operator
board car29 loc41
1
65 35
2
0 0 0 22
0 39 35 41
1
end_operator
begin_operator
board car29 loc5
1
65 36
2
0 0 0 22
0 39 36 41
1
end_operator
begin_operator
board car29 loc6
1
65 37
2
0 0 0 22
0 39 37 41
1
end_operator
begin_operator
board car29 loc7
1
65 38
2
0 0 0 22
0 39 38 41
1
end_operator
begin_operator
board car29 loc8
1
65 39
2
0 0 0 22
0 39 39 41
1
end_operator
begin_operator
board car29 loc9
1
65 40
2
0 0 0 22
0 39 40 41
1
end_operator
begin_operator
board car3 loc1
1
65 0
2
0 0 0 23
0 51 0 41
1
end_operator
begin_operator
board car3 loc10
1
65 1
2
0 0 0 23
0 51 1 41
1
end_operator
begin_operator
board car3 loc11
1
65 2
2
0 0 0 23
0 51 2 41
1
end_operator
begin_operator
board car3 loc12
1
65 3
2
0 0 0 23
0 51 3 41
1
end_operator
begin_operator
board car3 loc13
1
65 4
2
0 0 0 23
0 51 4 41
1
end_operator
begin_operator
board car3 loc14
1
65 5
2
0 0 0 23
0 51 5 41
1
end_operator
begin_operator
board car3 loc15
1
65 6
2
0 0 0 23
0 51 6 41
1
end_operator
begin_operator
board car3 loc16
1
65 7
2
0 0 0 23
0 51 7 41
1
end_operator
begin_operator
board car3 loc17
1
65 8
2
0 0 0 23
0 51 8 41
1
end_operator
begin_operator
board car3 loc18
1
65 9
2
0 0 0 23
0 51 9 41
1
end_operator
begin_operator
board car3 loc19
1
65 10
2
0 0 0 23
0 51 10 41
1
end_operator
begin_operator
board car3 loc2
1
65 11
2
0 0 0 23
0 51 11 41
1
end_operator
begin_operator
board car3 loc20
1
65 12
2
0 0 0 23
0 51 12 41
1
end_operator
begin_operator
board car3 loc21
1
65 13
2
0 0 0 23
0 51 13 41
1
end_operator
begin_operator
board car3 loc22
1
65 14
2
0 0 0 23
0 51 14 41
1
end_operator
begin_operator
board car3 loc23
1
65 15
2
0 0 0 23
0 51 15 41
1
end_operator
begin_operator
board car3 loc24
1
65 16
2
0 0 0 23
0 51 16 41
1
end_operator
begin_operator
board car3 loc25
1
65 17
2
0 0 0 23
0 51 17 41
1
end_operator
begin_operator
board car3 loc26
1
65 18
2
0 0 0 23
0 51 18 41
1
end_operator
begin_operator
board car3 loc27
1
65 19
2
0 0 0 23
0 51 19 41
1
end_operator
begin_operator
board car3 loc28
1
65 20
2
0 0 0 23
0 51 20 41
1
end_operator
begin_operator
board car3 loc29
1
65 21
2
0 0 0 23
0 51 21 41
1
end_operator
begin_operator
board car3 loc3
1
65 22
2
0 0 0 23
0 51 22 41
1
end_operator
begin_operator
board car3 loc30
1
65 23
2
0 0 0 23
0 51 23 41
1
end_operator
begin_operator
board car3 loc31
1
65 24
2
0 0 0 23
0 51 24 41
1
end_operator
begin_operator
board car3 loc32
1
65 25
2
0 0 0 23
0 51 25 41
1
end_operator
begin_operator
board car3 loc33
1
65 26
2
0 0 0 23
0 51 26 41
1
end_operator
begin_operator
board car3 loc34
1
65 27
2
0 0 0 23
0 51 27 41
1
end_operator
begin_operator
board car3 loc35
1
65 28
2
0 0 0 23
0 51 28 41
1
end_operator
begin_operator
board car3 loc36
1
65 29
2
0 0 0 23
0 51 29 41
1
end_operator
begin_operator
board car3 loc37
1
65 30
2
0 0 0 23
0 51 30 41
1
end_operator
begin_operator
board car3 loc38
1
65 31
2
0 0 0 23
0 51 31 41
1
end_operator
begin_operator
board car3 loc39
1
65 32
2
0 0 0 23
0 51 32 41
1
end_operator
begin_operator
board car3 loc4
1
65 33
2
0 0 0 23
0 51 33 41
1
end_operator
begin_operator
board car3 loc40
1
65 34
2
0 0 0 23
0 51 34 41
1
end_operator
begin_operator
board car3 loc41
1
65 35
2
0 0 0 23
0 51 35 41
1
end_operator
begin_operator
board car3 loc5
1
65 36
2
0 0 0 23
0 51 36 41
1
end_operator
begin_operator
board car3 loc6
1
65 37
2
0 0 0 23
0 51 37 41
1
end_operator
begin_operator
board car3 loc7
1
65 38
2
0 0 0 23
0 51 38 41
1
end_operator
begin_operator
board car3 loc8
1
65 39
2
0 0 0 23
0 51 39 41
1
end_operator
begin_operator
board car3 loc9
1
65 40
2
0 0 0 23
0 51 40 41
1
end_operator
begin_operator
board car30 loc1
1
65 0
2
0 0 0 24
0 63 0 41
1
end_operator
begin_operator
board car30 loc10
1
65 1
2
0 0 0 24
0 63 1 41
1
end_operator
begin_operator
board car30 loc11
1
65 2
2
0 0 0 24
0 63 2 41
1
end_operator
begin_operator
board car30 loc12
1
65 3
2
0 0 0 24
0 63 3 41
1
end_operator
begin_operator
board car30 loc13
1
65 4
2
0 0 0 24
0 63 4 41
1
end_operator
begin_operator
board car30 loc14
1
65 5
2
0 0 0 24
0 63 5 41
1
end_operator
begin_operator
board car30 loc15
1
65 6
2
0 0 0 24
0 63 6 41
1
end_operator
begin_operator
board car30 loc16
1
65 7
2
0 0 0 24
0 63 7 41
1
end_operator
begin_operator
board car30 loc17
1
65 8
2
0 0 0 24
0 63 8 41
1
end_operator
begin_operator
board car30 loc18
1
65 9
2
0 0 0 24
0 63 9 41
1
end_operator
begin_operator
board car30 loc19
1
65 10
2
0 0 0 24
0 63 10 41
1
end_operator
begin_operator
board car30 loc2
1
65 11
2
0 0 0 24
0 63 11 41
1
end_operator
begin_operator
board car30 loc20
1
65 12
2
0 0 0 24
0 63 12 41
1
end_operator
begin_operator
board car30 loc21
1
65 13
2
0 0 0 24
0 63 13 41
1
end_operator
begin_operator
board car30 loc22
1
65 14
2
0 0 0 24
0 63 14 41
1
end_operator
begin_operator
board car30 loc23
1
65 15
2
0 0 0 24
0 63 15 41
1
end_operator
begin_operator
board car30 loc24
1
65 16
2
0 0 0 24
0 63 16 41
1
end_operator
begin_operator
board car30 loc25
1
65 17
2
0 0 0 24
0 63 17 41
1
end_operator
begin_operator
board car30 loc26
1
65 18
2
0 0 0 24
0 63 18 41
1
end_operator
begin_operator
board car30 loc27
1
65 19
2
0 0 0 24
0 63 19 41
1
end_operator
begin_operator
board car30 loc28
1
65 20
2
0 0 0 24
0 63 20 41
1
end_operator
begin_operator
board car30 loc29
1
65 21
2
0 0 0 24
0 63 21 41
1
end_operator
begin_operator
board car30 loc3
1
65 22
2
0 0 0 24
0 63 22 41
1
end_operator
begin_operator
board car30 loc30
1
65 23
2
0 0 0 24
0 63 23 41
1
end_operator
begin_operator
board car30 loc31
1
65 24
2
0 0 0 24
0 63 24 41
1
end_operator
begin_operator
board car30 loc32
1
65 25
2
0 0 0 24
0 63 25 41
1
end_operator
begin_operator
board car30 loc33
1
65 26
2
0 0 0 24
0 63 26 41
1
end_operator
begin_operator
board car30 loc34
1
65 27
2
0 0 0 24
0 63 27 41
1
end_operator
begin_operator
board car30 loc35
1
65 28
2
0 0 0 24
0 63 28 41
1
end_operator
begin_operator
board car30 loc36
1
65 29
2
0 0 0 24
0 63 29 41
1
end_operator
begin_operator
board car30 loc37
1
65 30
2
0 0 0 24
0 63 30 41
1
end_operator
begin_operator
board car30 loc38
1
65 31
2
0 0 0 24
0 63 31 41
1
end_operator
begin_operator
board car30 loc39
1
65 32
2
0 0 0 24
0 63 32 41
1
end_operator
begin_operator
board car30 loc4
1
65 33
2
0 0 0 24
0 63 33 41
1
end_operator
begin_operator
board car30 loc40
1
65 34
2
0 0 0 24
0 63 34 41
1
end_operator
begin_operator
board car30 loc41
1
65 35
2
0 0 0 24
0 63 35 41
1
end_operator
begin_operator
board car30 loc5
1
65 36
2
0 0 0 24
0 63 36 41
1
end_operator
begin_operator
board car30 loc6
1
65 37
2
0 0 0 24
0 63 37 41
1
end_operator
begin_operator
board car30 loc7
1
65 38
2
0 0 0 24
0 63 38 41
1
end_operator
begin_operator
board car30 loc8
1
65 39
2
0 0 0 24
0 63 39 41
1
end_operator
begin_operator
board car30 loc9
1
65 40
2
0 0 0 24
0 63 40 41
1
end_operator
begin_operator
board car31 loc1
1
65 0
2
0 0 0 25
0 1 0 41
1
end_operator
begin_operator
board car31 loc10
1
65 1
2
0 0 0 25
0 1 1 41
1
end_operator
begin_operator
board car31 loc11
1
65 2
2
0 0 0 25
0 1 2 41
1
end_operator
begin_operator
board car31 loc12
1
65 3
2
0 0 0 25
0 1 3 41
1
end_operator
begin_operator
board car31 loc13
1
65 4
2
0 0 0 25
0 1 4 41
1
end_operator
begin_operator
board car31 loc14
1
65 5
2
0 0 0 25
0 1 5 41
1
end_operator
begin_operator
board car31 loc15
1
65 6
2
0 0 0 25
0 1 6 41
1
end_operator
begin_operator
board car31 loc16
1
65 7
2
0 0 0 25
0 1 7 41
1
end_operator
begin_operator
board car31 loc17
1
65 8
2
0 0 0 25
0 1 8 41
1
end_operator
begin_operator
board car31 loc18
1
65 9
2
0 0 0 25
0 1 9 41
1
end_operator
begin_operator
board car31 loc19
1
65 10
2
0 0 0 25
0 1 10 41
1
end_operator
begin_operator
board car31 loc2
1
65 11
2
0 0 0 25
0 1 11 41
1
end_operator
begin_operator
board car31 loc20
1
65 12
2
0 0 0 25
0 1 12 41
1
end_operator
begin_operator
board car31 loc21
1
65 13
2
0 0 0 25
0 1 13 41
1
end_operator
begin_operator
board car31 loc22
1
65 14
2
0 0 0 25
0 1 14 41
1
end_operator
begin_operator
board car31 loc23
1
65 15
2
0 0 0 25
0 1 15 41
1
end_operator
begin_operator
board car31 loc24
1
65 16
2
0 0 0 25
0 1 16 41
1
end_operator
begin_operator
board car31 loc25
1
65 17
2
0 0 0 25
0 1 17 41
1
end_operator
begin_operator
board car31 loc26
1
65 18
2
0 0 0 25
0 1 18 41
1
end_operator
begin_operator
board car31 loc27
1
65 19
2
0 0 0 25
0 1 19 41
1
end_operator
begin_operator
board car31 loc28
1
65 20
2
0 0 0 25
0 1 20 41
1
end_operator
begin_operator
board car31 loc29
1
65 21
2
0 0 0 25
0 1 21 41
1
end_operator
begin_operator
board car31 loc3
1
65 22
2
0 0 0 25
0 1 22 41
1
end_operator
begin_operator
board car31 loc30
1
65 23
2
0 0 0 25
0 1 23 41
1
end_operator
begin_operator
board car31 loc31
1
65 24
2
0 0 0 25
0 1 24 41
1
end_operator
begin_operator
board car31 loc32
1
65 25
2
0 0 0 25
0 1 25 41
1
end_operator
begin_operator
board car31 loc33
1
65 26
2
0 0 0 25
0 1 26 41
1
end_operator
begin_operator
board car31 loc34
1
65 27
2
0 0 0 25
0 1 27 41
1
end_operator
begin_operator
board car31 loc35
1
65 28
2
0 0 0 25
0 1 28 41
1
end_operator
begin_operator
board car31 loc36
1
65 29
2
0 0 0 25
0 1 29 41
1
end_operator
begin_operator
board car31 loc37
1
65 30
2
0 0 0 25
0 1 30 41
1
end_operator
begin_operator
board car31 loc38
1
65 31
2
0 0 0 25
0 1 31 41
1
end_operator
begin_operator
board car31 loc39
1
65 32
2
0 0 0 25
0 1 32 41
1
end_operator
begin_operator
board car31 loc4
1
65 33
2
0 0 0 25
0 1 33 41
1
end_operator
begin_operator
board car31 loc40
1
65 34
2
0 0 0 25
0 1 34 41
1
end_operator
begin_operator
board car31 loc41
1
65 35
2
0 0 0 25
0 1 35 41
1
end_operator
begin_operator
board car31 loc5
1
65 36
2
0 0 0 25
0 1 36 41
1
end_operator
begin_operator
board car31 loc6
1
65 37
2
0 0 0 25
0 1 37 41
1
end_operator
begin_operator
board car31 loc7
1
65 38
2
0 0 0 25
0 1 38 41
1
end_operator
begin_operator
board car31 loc8
1
65 39
2
0 0 0 25
0 1 39 41
1
end_operator
begin_operator
board car31 loc9
1
65 40
2
0 0 0 25
0 1 40 41
1
end_operator
begin_operator
board car32 loc1
1
65 0
2
0 0 0 26
0 13 0 41
1
end_operator
begin_operator
board car32 loc10
1
65 1
2
0 0 0 26
0 13 1 41
1
end_operator
begin_operator
board car32 loc11
1
65 2
2
0 0 0 26
0 13 2 41
1
end_operator
begin_operator
board car32 loc12
1
65 3
2
0 0 0 26
0 13 3 41
1
end_operator
begin_operator
board car32 loc13
1
65 4
2
0 0 0 26
0 13 4 41
1
end_operator
begin_operator
board car32 loc14
1
65 5
2
0 0 0 26
0 13 5 41
1
end_operator
begin_operator
board car32 loc15
1
65 6
2
0 0 0 26
0 13 6 41
1
end_operator
begin_operator
board car32 loc16
1
65 7
2
0 0 0 26
0 13 7 41
1
end_operator
begin_operator
board car32 loc17
1
65 8
2
0 0 0 26
0 13 8 41
1
end_operator
begin_operator
board car32 loc18
1
65 9
2
0 0 0 26
0 13 9 41
1
end_operator
begin_operator
board car32 loc19
1
65 10
2
0 0 0 26
0 13 10 41
1
end_operator
begin_operator
board car32 loc2
1
65 11
2
0 0 0 26
0 13 11 41
1
end_operator
begin_operator
board car32 loc20
1
65 12
2
0 0 0 26
0 13 12 41
1
end_operator
begin_operator
board car32 loc21
1
65 13
2
0 0 0 26
0 13 13 41
1
end_operator
begin_operator
board car32 loc22
1
65 14
2
0 0 0 26
0 13 14 41
1
end_operator
begin_operator
board car32 loc23
1
65 15
2
0 0 0 26
0 13 15 41
1
end_operator
begin_operator
board car32 loc24
1
65 16
2
0 0 0 26
0 13 16 41
1
end_operator
begin_operator
board car32 loc25
1
65 17
2
0 0 0 26
0 13 17 41
1
end_operator
begin_operator
board car32 loc26
1
65 18
2
0 0 0 26
0 13 18 41
1
end_operator
begin_operator
board car32 loc27
1
65 19
2
0 0 0 26
0 13 19 41
1
end_operator
begin_operator
board car32 loc28
1
65 20
2
0 0 0 26
0 13 20 41
1
end_operator
begin_operator
board car32 loc29
1
65 21
2
0 0 0 26
0 13 21 41
1
end_operator
begin_operator
board car32 loc3
1
65 22
2
0 0 0 26
0 13 22 41
1
end_operator
begin_operator
board car32 loc30
1
65 23
2
0 0 0 26
0 13 23 41
1
end_operator
begin_operator
board car32 loc31
1
65 24
2
0 0 0 26
0 13 24 41
1
end_operator
begin_operator
board car32 loc32
1
65 25
2
0 0 0 26
0 13 25 41
1
end_operator
begin_operator
board car32 loc33
1
65 26
2
0 0 0 26
0 13 26 41
1
end_operator
begin_operator
board car32 loc34
1
65 27
2
0 0 0 26
0 13 27 41
1
end_operator
begin_operator
board car32 loc35
1
65 28
2
0 0 0 26
0 13 28 41
1
end_operator
begin_operator
board car32 loc36
1
65 29
2
0 0 0 26
0 13 29 41
1
end_operator
begin_operator
board car32 loc37
1
65 30
2
0 0 0 26
0 13 30 41
1
end_operator
begin_operator
board car32 loc38
1
65 31
2
0 0 0 26
0 13 31 41
1
end_operator
begin_operator
board car32 loc39
1
65 32
2
0 0 0 26
0 13 32 41
1
end_operator
begin_operator
board car32 loc4
1
65 33
2
0 0 0 26
0 13 33 41
1
end_operator
begin_operator
board car32 loc40
1
65 34
2
0 0 0 26
0 13 34 41
1
end_operator
begin_operator
board car32 loc41
1
65 35
2
0 0 0 26
0 13 35 41
1
end_operator
begin_operator
board car32 loc5
1
65 36
2
0 0 0 26
0 13 36 41
1
end_operator
begin_operator
board car32 loc6
1
65 37
2
0 0 0 26
0 13 37 41
1
end_operator
begin_operator
board car32 loc7
1
65 38
2
0 0 0 26
0 13 38 41
1
end_operator
begin_operator
board car32 loc8
1
65 39
2
0 0 0 26
0 13 39 41
1
end_operator
begin_operator
board car32 loc9
1
65 40
2
0 0 0 26
0 13 40 41
1
end_operator
begin_operator
board car33 loc1
1
65 0
2
0 0 0 27
0 25 0 41
1
end_operator
begin_operator
board car33 loc10
1
65 1
2
0 0 0 27
0 25 1 41
1
end_operator
begin_operator
board car33 loc11
1
65 2
2
0 0 0 27
0 25 2 41
1
end_operator
begin_operator
board car33 loc12
1
65 3
2
0 0 0 27
0 25 3 41
1
end_operator
begin_operator
board car33 loc13
1
65 4
2
0 0 0 27
0 25 4 41
1
end_operator
begin_operator
board car33 loc14
1
65 5
2
0 0 0 27
0 25 5 41
1
end_operator
begin_operator
board car33 loc15
1
65 6
2
0 0 0 27
0 25 6 41
1
end_operator
begin_operator
board car33 loc16
1
65 7
2
0 0 0 27
0 25 7 41
1
end_operator
begin_operator
board car33 loc17
1
65 8
2
0 0 0 27
0 25 8 41
1
end_operator
begin_operator
board car33 loc18
1
65 9
2
0 0 0 27
0 25 9 41
1
end_operator
begin_operator
board car33 loc19
1
65 10
2
0 0 0 27
0 25 10 41
1
end_operator
begin_operator
board car33 loc2
1
65 11
2
0 0 0 27
0 25 11 41
1
end_operator
begin_operator
board car33 loc20
1
65 12
2
0 0 0 27
0 25 12 41
1
end_operator
begin_operator
board car33 loc21
1
65 13
2
0 0 0 27
0 25 13 41
1
end_operator
begin_operator
board car33 loc22
1
65 14
2
0 0 0 27
0 25 14 41
1
end_operator
begin_operator
board car33 loc23
1
65 15
2
0 0 0 27
0 25 15 41
1
end_operator
begin_operator
board car33 loc24
1
65 16
2
0 0 0 27
0 25 16 41
1
end_operator
begin_operator
board car33 loc25
1
65 17
2
0 0 0 27
0 25 17 41
1
end_operator
begin_operator
board car33 loc26
1
65 18
2
0 0 0 27
0 25 18 41
1
end_operator
begin_operator
board car33 loc27
1
65 19
2
0 0 0 27
0 25 19 41
1
end_operator
begin_operator
board car33 loc28
1
65 20
2
0 0 0 27
0 25 20 41
1
end_operator
begin_operator
board car33 loc29
1
65 21
2
0 0 0 27
0 25 21 41
1
end_operator
begin_operator
board car33 loc3
1
65 22
2
0 0 0 27
0 25 22 41
1
end_operator
begin_operator
board car33 loc30
1
65 23
2
0 0 0 27
0 25 23 41
1
end_operator
begin_operator
board car33 loc31
1
65 24
2
0 0 0 27
0 25 24 41
1
end_operator
begin_operator
board car33 loc32
1
65 25
2
0 0 0 27
0 25 25 41
1
end_operator
begin_operator
board car33 loc33
1
65 26
2
0 0 0 27
0 25 26 41
1
end_operator
begin_operator
board car33 loc34
1
65 27
2
0 0 0 27
0 25 27 41
1
end_operator
begin_operator
board car33 loc35
1
65 28
2
0 0 0 27
0 25 28 41
1
end_operator
begin_operator
board car33 loc36
1
65 29
2
0 0 0 27
0 25 29 41
1
end_operator
begin_operator
board car33 loc37
1
65 30
2
0 0 0 27
0 25 30 41
1
end_operator
begin_operator
board car33 loc38
1
65 31
2
0 0 0 27
0 25 31 41
1
end_operator
begin_operator
board car33 loc39
1
65 32
2
0 0 0 27
0 25 32 41
1
end_operator
begin_operator
board car33 loc4
1
65 33
2
0 0 0 27
0 25 33 41
1
end_operator
begin_operator
board car33 loc40
1
65 34
2
0 0 0 27
0 25 34 41
1
end_operator
begin_operator
board car33 loc41
1
65 35
2
0 0 0 27
0 25 35 41
1
end_operator
begin_operator
board car33 loc5
1
65 36
2
0 0 0 27
0 25 36 41
1
end_operator
begin_operator
board car33 loc6
1
65 37
2
0 0 0 27
0 25 37 41
1
end_operator
begin_operator
board car33 loc7
1
65 38
2
0 0 0 27
0 25 38 41
1
end_operator
begin_operator
board car33 loc8
1
65 39
2
0 0 0 27
0 25 39 41
1
end_operator
begin_operator
board car33 loc9
1
65 40
2
0 0 0 27
0 25 40 41
1
end_operator
begin_operator
board car34 loc1
1
65 0
2
0 0 0 28
0 37 0 41
1
end_operator
begin_operator
board car34 loc10
1
65 1
2
0 0 0 28
0 37 1 41
1
end_operator
begin_operator
board car34 loc11
1
65 2
2
0 0 0 28
0 37 2 41
1
end_operator
begin_operator
board car34 loc12
1
65 3
2
0 0 0 28
0 37 3 41
1
end_operator
begin_operator
board car34 loc13
1
65 4
2
0 0 0 28
0 37 4 41
1
end_operator
begin_operator
board car34 loc14
1
65 5
2
0 0 0 28
0 37 5 41
1
end_operator
begin_operator
board car34 loc15
1
65 6
2
0 0 0 28
0 37 6 41
1
end_operator
begin_operator
board car34 loc16
1
65 7
2
0 0 0 28
0 37 7 41
1
end_operator
begin_operator
board car34 loc17
1
65 8
2
0 0 0 28
0 37 8 41
1
end_operator
begin_operator
board car34 loc18
1
65 9
2
0 0 0 28
0 37 9 41
1
end_operator
begin_operator
board car34 loc19
1
65 10
2
0 0 0 28
0 37 10 41
1
end_operator
begin_operator
board car34 loc2
1
65 11
2
0 0 0 28
0 37 11 41
1
end_operator
begin_operator
board car34 loc20
1
65 12
2
0 0 0 28
0 37 12 41
1
end_operator
begin_operator
board car34 loc21
1
65 13
2
0 0 0 28
0 37 13 41
1
end_operator
begin_operator
board car34 loc22
1
65 14
2
0 0 0 28
0 37 14 41
1
end_operator
begin_operator
board car34 loc23
1
65 15
2
0 0 0 28
0 37 15 41
1
end_operator
begin_operator
board car34 loc24
1
65 16
2
0 0 0 28
0 37 16 41
1
end_operator
begin_operator
board car34 loc25
1
65 17
2
0 0 0 28
0 37 17 41
1
end_operator
begin_operator
board car34 loc26
1
65 18
2
0 0 0 28
0 37 18 41
1
end_operator
begin_operator
board car34 loc27
1
65 19
2
0 0 0 28
0 37 19 41
1
end_operator
begin_operator
board car34 loc28
1
65 20
2
0 0 0 28
0 37 20 41
1
end_operator
begin_operator
board car34 loc29
1
65 21
2
0 0 0 28
0 37 21 41
1
end_operator
begin_operator
board car34 loc3
1
65 22
2
0 0 0 28
0 37 22 41
1
end_operator
begin_operator
board car34 loc30
1
65 23
2
0 0 0 28
0 37 23 41
1
end_operator
begin_operator
board car34 loc31
1
65 24
2
0 0 0 28
0 37 24 41
1
end_operator
begin_operator
board car34 loc32
1
65 25
2
0 0 0 28
0 37 25 41
1
end_operator
begin_operator
board car34 loc33
1
65 26
2
0 0 0 28
0 37 26 41
1
end_operator
begin_operator
board car34 loc34
1
65 27
2
0 0 0 28
0 37 27 41
1
end_operator
begin_operator
board car34 loc35
1
65 28
2
0 0 0 28
0 37 28 41
1
end_operator
begin_operator
board car34 loc36
1
65 29
2
0 0 0 28
0 37 29 41
1
end_operator
begin_operator
board car34 loc37
1
65 30
2
0 0 0 28
0 37 30 41
1
end_operator
begin_operator
board car34 loc38
1
65 31
2
0 0 0 28
0 37 31 41
1
end_operator
begin_operator
board car34 loc39
1
65 32
2
0 0 0 28
0 37 32 41
1
end_operator
begin_operator
board car34 loc4
1
65 33
2
0 0 0 28
0 37 33 41
1
end_operator
begin_operator
board car34 loc40
1
65 34
2
0 0 0 28
0 37 34 41
1
end_operator
begin_operator
board car34 loc41
1
65 35
2
0 0 0 28
0 37 35 41
1
end_operator
begin_operator
board car34 loc5
1
65 36
2
0 0 0 28
0 37 36 41
1
end_operator
begin_operator
board car34 loc6
1
65 37
2
0 0 0 28
0 37 37 41
1
end_operator
begin_operator
board car34 loc7
1
65 38
2
0 0 0 28
0 37 38 41
1
end_operator
begin_operator
board car34 loc8
1
65 39
2
0 0 0 28
0 37 39 41
1
end_operator
begin_operator
board car34 loc9
1
65 40
2
0 0 0 28
0 37 40 41
1
end_operator
begin_operator
board car35 loc1
1
65 0
2
0 0 0 29
0 49 0 41
1
end_operator
begin_operator
board car35 loc10
1
65 1
2
0 0 0 29
0 49 1 41
1
end_operator
begin_operator
board car35 loc11
1
65 2
2
0 0 0 29
0 49 2 41
1
end_operator
begin_operator
board car35 loc12
1
65 3
2
0 0 0 29
0 49 3 41
1
end_operator
begin_operator
board car35 loc13
1
65 4
2
0 0 0 29
0 49 4 41
1
end_operator
begin_operator
board car35 loc14
1
65 5
2
0 0 0 29
0 49 5 41
1
end_operator
begin_operator
board car35 loc15
1
65 6
2
0 0 0 29
0 49 6 41
1
end_operator
begin_operator
board car35 loc16
1
65 7
2
0 0 0 29
0 49 7 41
1
end_operator
begin_operator
board car35 loc17
1
65 8
2
0 0 0 29
0 49 8 41
1
end_operator
begin_operator
board car35 loc18
1
65 9
2
0 0 0 29
0 49 9 41
1
end_operator
begin_operator
board car35 loc19
1
65 10
2
0 0 0 29
0 49 10 41
1
end_operator
begin_operator
board car35 loc2
1
65 11
2
0 0 0 29
0 49 11 41
1
end_operator
begin_operator
board car35 loc20
1
65 12
2
0 0 0 29
0 49 12 41
1
end_operator
begin_operator
board car35 loc21
1
65 13
2
0 0 0 29
0 49 13 41
1
end_operator
begin_operator
board car35 loc22
1
65 14
2
0 0 0 29
0 49 14 41
1
end_operator
begin_operator
board car35 loc23
1
65 15
2
0 0 0 29
0 49 15 41
1
end_operator
begin_operator
board car35 loc24
1
65 16
2
0 0 0 29
0 49 16 41
1
end_operator
begin_operator
board car35 loc25
1
65 17
2
0 0 0 29
0 49 17 41
1
end_operator
begin_operator
board car35 loc26
1
65 18
2
0 0 0 29
0 49 18 41
1
end_operator
begin_operator
board car35 loc27
1
65 19
2
0 0 0 29
0 49 19 41
1
end_operator
begin_operator
board car35 loc28
1
65 20
2
0 0 0 29
0 49 20 41
1
end_operator
begin_operator
board car35 loc29
1
65 21
2
0 0 0 29
0 49 21 41
1
end_operator
begin_operator
board car35 loc3
1
65 22
2
0 0 0 29
0 49 22 41
1
end_operator
begin_operator
board car35 loc30
1
65 23
2
0 0 0 29
0 49 23 41
1
end_operator
begin_operator
board car35 loc31
1
65 24
2
0 0 0 29
0 49 24 41
1
end_operator
begin_operator
board car35 loc32
1
65 25
2
0 0 0 29
0 49 25 41
1
end_operator
begin_operator
board car35 loc33
1
65 26
2
0 0 0 29
0 49 26 41
1
end_operator
begin_operator
board car35 loc34
1
65 27
2
0 0 0 29
0 49 27 41
1
end_operator
begin_operator
board car35 loc35
1
65 28
2
0 0 0 29
0 49 28 41
1
end_operator
begin_operator
board car35 loc36
1
65 29
2
0 0 0 29
0 49 29 41
1
end_operator
begin_operator
board car35 loc37
1
65 30
2
0 0 0 29
0 49 30 41
1
end_operator
begin_operator
board car35 loc38
1
65 31
2
0 0 0 29
0 49 31 41
1
end_operator
begin_operator
board car35 loc39
1
65 32
2
0 0 0 29
0 49 32 41
1
end_operator
begin_operator
board car35 loc4
1
65 33
2
0 0 0 29
0 49 33 41
1
end_operator
begin_operator
board car35 loc40
1
65 34
2
0 0 0 29
0 49 34 41
1
end_operator
begin_operator
board car35 loc41
1
65 35
2
0 0 0 29
0 49 35 41
1
end_operator
begin_operator
board car35 loc5
1
65 36
2
0 0 0 29
0 49 36 41
1
end_operator
begin_operator
board car35 loc6
1
65 37
2
0 0 0 29
0 49 37 41
1
end_operator
begin_operator
board car35 loc7
1
65 38
2
0 0 0 29
0 49 38 41
1
end_operator
begin_operator
board car35 loc8
1
65 39
2
0 0 0 29
0 49 39 41
1
end_operator
begin_operator
board car35 loc9
1
65 40
2
0 0 0 29
0 49 40 41
1
end_operator
begin_operator
board car36 loc1
1
65 0
2
0 0 0 30
0 61 0 41
1
end_operator
begin_operator
board car36 loc10
1
65 1
2
0 0 0 30
0 61 1 41
1
end_operator
begin_operator
board car36 loc11
1
65 2
2
0 0 0 30
0 61 2 41
1
end_operator
begin_operator
board car36 loc12
1
65 3
2
0 0 0 30
0 61 3 41
1
end_operator
begin_operator
board car36 loc13
1
65 4
2
0 0 0 30
0 61 4 41
1
end_operator
begin_operator
board car36 loc14
1
65 5
2
0 0 0 30
0 61 5 41
1
end_operator
begin_operator
board car36 loc15
1
65 6
2
0 0 0 30
0 61 6 41
1
end_operator
begin_operator
board car36 loc16
1
65 7
2
0 0 0 30
0 61 7 41
1
end_operator
begin_operator
board car36 loc17
1
65 8
2
0 0 0 30
0 61 8 41
1
end_operator
begin_operator
board car36 loc18
1
65 9
2
0 0 0 30
0 61 9 41
1
end_operator
begin_operator
board car36 loc19
1
65 10
2
0 0 0 30
0 61 10 41
1
end_operator
begin_operator
board car36 loc2
1
65 11
2
0 0 0 30
0 61 11 41
1
end_operator
begin_operator
board car36 loc20
1
65 12
2
0 0 0 30
0 61 12 41
1
end_operator
begin_operator
board car36 loc21
1
65 13
2
0 0 0 30
0 61 13 41
1
end_operator
begin_operator
board car36 loc22
1
65 14
2
0 0 0 30
0 61 14 41
1
end_operator
begin_operator
board car36 loc23
1
65 15
2
0 0 0 30
0 61 15 41
1
end_operator
begin_operator
board car36 loc24
1
65 16
2
0 0 0 30
0 61 16 41
1
end_operator
begin_operator
board car36 loc25
1
65 17
2
0 0 0 30
0 61 17 41
1
end_operator
begin_operator
board car36 loc26
1
65 18
2
0 0 0 30
0 61 18 41
1
end_operator
begin_operator
board car36 loc27
1
65 19
2
0 0 0 30
0 61 19 41
1
end_operator
begin_operator
board car36 loc28
1
65 20
2
0 0 0 30
0 61 20 41
1
end_operator
begin_operator
board car36 loc29
1
65 21
2
0 0 0 30
0 61 21 41
1
end_operator
begin_operator
board car36 loc3
1
65 22
2
0 0 0 30
0 61 22 41
1
end_operator
begin_operator
board car36 loc30
1
65 23
2
0 0 0 30
0 61 23 41
1
end_operator
begin_operator
board car36 loc31
1
65 24
2
0 0 0 30
0 61 24 41
1
end_operator
begin_operator
board car36 loc32
1
65 25
2
0 0 0 30
0 61 25 41
1
end_operator
begin_operator
board car36 loc33
1
65 26
2
0 0 0 30
0 61 26 41
1
end_operator
begin_operator
board car36 loc34
1
65 27
2
0 0 0 30
0 61 27 41
1
end_operator
begin_operator
board car36 loc35
1
65 28
2
0 0 0 30
0 61 28 41
1
end_operator
begin_operator
board car36 loc36
1
65 29
2
0 0 0 30
0 61 29 41
1
end_operator
begin_operator
board car36 loc37
1
65 30
2
0 0 0 30
0 61 30 41
1
end_operator
begin_operator
board car36 loc38
1
65 31
2
0 0 0 30
0 61 31 41
1
end_operator
begin_operator
board car36 loc39
1
65 32
2
0 0 0 30
0 61 32 41
1
end_operator
begin_operator
board car36 loc4
1
65 33
2
0 0 0 30
0 61 33 41
1
end_operator
begin_operator
board car36 loc40
1
65 34
2
0 0 0 30
0 61 34 41
1
end_operator
begin_operator
board car36 loc41
1
65 35
2
0 0 0 30
0 61 35 41
1
end_operator
begin_operator
board car36 loc5
1
65 36
2
0 0 0 30
0 61 36 41
1
end_operator
begin_operator
board car36 loc6
1
65 37
2
0 0 0 30
0 61 37 41
1
end_operator
begin_operator
board car36 loc7
1
65 38
2
0 0 0 30
0 61 38 41
1
end_operator
begin_operator
board car36 loc8
1
65 39
2
0 0 0 30
0 61 39 41
1
end_operator
begin_operator
board car36 loc9
1
65 40
2
0 0 0 30
0 61 40 41
1
end_operator
begin_operator
board car37 loc1
1
65 0
2
0 0 0 31
0 73 0 41
1
end_operator
begin_operator
board car37 loc10
1
65 1
2
0 0 0 31
0 73 1 41
1
end_operator
begin_operator
board car37 loc11
1
65 2
2
0 0 0 31
0 73 2 41
1
end_operator
begin_operator
board car37 loc12
1
65 3
2
0 0 0 31
0 73 3 41
1
end_operator
begin_operator
board car37 loc13
1
65 4
2
0 0 0 31
0 73 4 41
1
end_operator
begin_operator
board car37 loc14
1
65 5
2
0 0 0 31
0 73 5 41
1
end_operator
begin_operator
board car37 loc15
1
65 6
2
0 0 0 31
0 73 6 41
1
end_operator
begin_operator
board car37 loc16
1
65 7
2
0 0 0 31
0 73 7 41
1
end_operator
begin_operator
board car37 loc17
1
65 8
2
0 0 0 31
0 73 8 41
1
end_operator
begin_operator
board car37 loc18
1
65 9
2
0 0 0 31
0 73 9 41
1
end_operator
begin_operator
board car37 loc19
1
65 10
2
0 0 0 31
0 73 10 41
1
end_operator
begin_operator
board car37 loc2
1
65 11
2
0 0 0 31
0 73 11 41
1
end_operator
begin_operator
board car37 loc20
1
65 12
2
0 0 0 31
0 73 12 41
1
end_operator
begin_operator
board car37 loc21
1
65 13
2
0 0 0 31
0 73 13 41
1
end_operator
begin_operator
board car37 loc22
1
65 14
2
0 0 0 31
0 73 14 41
1
end_operator
begin_operator
board car37 loc23
1
65 15
2
0 0 0 31
0 73 15 41
1
end_operator
begin_operator
board car37 loc24
1
65 16
2
0 0 0 31
0 73 16 41
1
end_operator
begin_operator
board car37 loc25
1
65 17
2
0 0 0 31
0 73 17 41
1
end_operator
begin_operator
board car37 loc26
1
65 18
2
0 0 0 31
0 73 18 41
1
end_operator
begin_operator
board car37 loc27
1
65 19
2
0 0 0 31
0 73 19 41
1
end_operator
begin_operator
board car37 loc28
1
65 20
2
0 0 0 31
0 73 20 41
1
end_operator
begin_operator
board car37 loc29
1
65 21
2
0 0 0 31
0 73 21 41
1
end_operator
begin_operator
board car37 loc3
1
65 22
2
0 0 0 31
0 73 22 41
1
end_operator
begin_operator
board car37 loc30
1
65 23
2
0 0 0 31
0 73 23 41
1
end_operator
begin_operator
board car37 loc31
1
65 24
2
0 0 0 31
0 73 24 41
1
end_operator
begin_operator
board car37 loc32
1
65 25
2
0 0 0 31
0 73 25 41
1
end_operator
begin_operator
board car37 loc33
1
65 26
2
0 0 0 31
0 73 26 41
1
end_operator
begin_operator
board car37 loc34
1
65 27
2
0 0 0 31
0 73 27 41
1
end_operator
begin_operator
board car37 loc35
1
65 28
2
0 0 0 31
0 73 28 41
1
end_operator
begin_operator
board car37 loc36
1
65 29
2
0 0 0 31
0 73 29 41
1
end_operator
begin_operator
board car37 loc37
1
65 30
2
0 0 0 31
0 73 30 41
1
end_operator
begin_operator
board car37 loc38
1
65 31
2
0 0 0 31
0 73 31 41
1
end_operator
begin_operator
board car37 loc39
1
65 32
2
0 0 0 31
0 73 32 41
1
end_operator
begin_operator
board car37 loc4
1
65 33
2
0 0 0 31
0 73 33 41
1
end_operator
begin_operator
board car37 loc40
1
65 34
2
0 0 0 31
0 73 34 41
1
end_operator
begin_operator
board car37 loc41
1
65 35
2
0 0 0 31
0 73 35 41
1
end_operator
begin_operator
board car37 loc5
1
65 36
2
0 0 0 31
0 73 36 41
1
end_operator
begin_operator
board car37 loc6
1
65 37
2
0 0 0 31
0 73 37 41
1
end_operator
begin_operator
board car37 loc7
1
65 38
2
0 0 0 31
0 73 38 41
1
end_operator
begin_operator
board car37 loc8
1
65 39
2
0 0 0 31
0 73 39 41
1
end_operator
begin_operator
board car37 loc9
1
65 40
2
0 0 0 31
0 73 40 41
1
end_operator
begin_operator
board car38 loc1
1
65 0
2
0 0 0 32
0 10 0 41
1
end_operator
begin_operator
board car38 loc10
1
65 1
2
0 0 0 32
0 10 1 41
1
end_operator
begin_operator
board car38 loc11
1
65 2
2
0 0 0 32
0 10 2 41
1
end_operator
begin_operator
board car38 loc12
1
65 3
2
0 0 0 32
0 10 3 41
1
end_operator
begin_operator
board car38 loc13
1
65 4
2
0 0 0 32
0 10 4 41
1
end_operator
begin_operator
board car38 loc14
1
65 5
2
0 0 0 32
0 10 5 41
1
end_operator
begin_operator
board car38 loc15
1
65 6
2
0 0 0 32
0 10 6 41
1
end_operator
begin_operator
board car38 loc16
1
65 7
2
0 0 0 32
0 10 7 41
1
end_operator
begin_operator
board car38 loc17
1
65 8
2
0 0 0 32
0 10 8 41
1
end_operator
begin_operator
board car38 loc18
1
65 9
2
0 0 0 32
0 10 9 41
1
end_operator
begin_operator
board car38 loc19
1
65 10
2
0 0 0 32
0 10 10 41
1
end_operator
begin_operator
board car38 loc2
1
65 11
2
0 0 0 32
0 10 11 41
1
end_operator
begin_operator
board car38 loc20
1
65 12
2
0 0 0 32
0 10 12 41
1
end_operator
begin_operator
board car38 loc21
1
65 13
2
0 0 0 32
0 10 13 41
1
end_operator
begin_operator
board car38 loc22
1
65 14
2
0 0 0 32
0 10 14 41
1
end_operator
begin_operator
board car38 loc23
1
65 15
2
0 0 0 32
0 10 15 41
1
end_operator
begin_operator
board car38 loc24
1
65 16
2
0 0 0 32
0 10 16 41
1
end_operator
begin_operator
board car38 loc25
1
65 17
2
0 0 0 32
0 10 17 41
1
end_operator
begin_operator
board car38 loc26
1
65 18
2
0 0 0 32
0 10 18 41
1
end_operator
begin_operator
board car38 loc27
1
65 19
2
0 0 0 32
0 10 19 41
1
end_operator
begin_operator
board car38 loc28
1
65 20
2
0 0 0 32
0 10 20 41
1
end_operator
begin_operator
board car38 loc29
1
65 21
2
0 0 0 32
0 10 21 41
1
end_operator
begin_operator
board car38 loc3
1
65 22
2
0 0 0 32
0 10 22 41
1
end_operator
begin_operator
board car38 loc30
1
65 23
2
0 0 0 32
0 10 23 41
1
end_operator
begin_operator
board car38 loc31
1
65 24
2
0 0 0 32
0 10 24 41
1
end_operator
begin_operator
board car38 loc32
1
65 25
2
0 0 0 32
0 10 25 41
1
end_operator
begin_operator
board car38 loc33
1
65 26
2
0 0 0 32
0 10 26 41
1
end_operator
begin_operator
board car38 loc34
1
65 27
2
0 0 0 32
0 10 27 41
1
end_operator
begin_operator
board car38 loc35
1
65 28
2
0 0 0 32
0 10 28 41
1
end_operator
begin_operator
board car38 loc36
1
65 29
2
0 0 0 32
0 10 29 41
1
end_operator
begin_operator
board car38 loc37
1
65 30
2
0 0 0 32
0 10 30 41
1
end_operator
begin_operator
board car38 loc38
1
65 31
2
0 0 0 32
0 10 31 41
1
end_operator
begin_operator
board car38 loc39
1
65 32
2
0 0 0 32
0 10 32 41
1
end_operator
begin_operator
board car38 loc4
1
65 33
2
0 0 0 32
0 10 33 41
1
end_operator
begin_operator
board car38 loc40
1
65 34
2
0 0 0 32
0 10 34 41
1
end_operator
begin_operator
board car38 loc41
1
65 35
2
0 0 0 32
0 10 35 41
1
end_operator
begin_operator
board car38 loc5
1
65 36
2
0 0 0 32
0 10 36 41
1
end_operator
begin_operator
board car38 loc6
1
65 37
2
0 0 0 32
0 10 37 41
1
end_operator
begin_operator
board car38 loc7
1
65 38
2
0 0 0 32
0 10 38 41
1
end_operator
begin_operator
board car38 loc8
1
65 39
2
0 0 0 32
0 10 39 41
1
end_operator
begin_operator
board car38 loc9
1
65 40
2
0 0 0 32
0 10 40 41
1
end_operator
begin_operator
board car39 loc1
1
65 0
2
0 0 0 33
0 22 0 41
1
end_operator
begin_operator
board car39 loc10
1
65 1
2
0 0 0 33
0 22 1 41
1
end_operator
begin_operator
board car39 loc11
1
65 2
2
0 0 0 33
0 22 2 41
1
end_operator
begin_operator
board car39 loc12
1
65 3
2
0 0 0 33
0 22 3 41
1
end_operator
begin_operator
board car39 loc13
1
65 4
2
0 0 0 33
0 22 4 41
1
end_operator
begin_operator
board car39 loc14
1
65 5
2
0 0 0 33
0 22 5 41
1
end_operator
begin_operator
board car39 loc15
1
65 6
2
0 0 0 33
0 22 6 41
1
end_operator
begin_operator
board car39 loc16
1
65 7
2
0 0 0 33
0 22 7 41
1
end_operator
begin_operator
board car39 loc17
1
65 8
2
0 0 0 33
0 22 8 41
1
end_operator
begin_operator
board car39 loc18
1
65 9
2
0 0 0 33
0 22 9 41
1
end_operator
begin_operator
board car39 loc19
1
65 10
2
0 0 0 33
0 22 10 41
1
end_operator
begin_operator
board car39 loc2
1
65 11
2
0 0 0 33
0 22 11 41
1
end_operator
begin_operator
board car39 loc20
1
65 12
2
0 0 0 33
0 22 12 41
1
end_operator
begin_operator
board car39 loc21
1
65 13
2
0 0 0 33
0 22 13 41
1
end_operator
begin_operator
board car39 loc22
1
65 14
2
0 0 0 33
0 22 14 41
1
end_operator
begin_operator
board car39 loc23
1
65 15
2
0 0 0 33
0 22 15 41
1
end_operator
begin_operator
board car39 loc24
1
65 16
2
0 0 0 33
0 22 16 41
1
end_operator
begin_operator
board car39 loc25
1
65 17
2
0 0 0 33
0 22 17 41
1
end_operator
begin_operator
board car39 loc26
1
65 18
2
0 0 0 33
0 22 18 41
1
end_operator
begin_operator
board car39 loc27
1
65 19
2
0 0 0 33
0 22 19 41
1
end_operator
begin_operator
board car39 loc28
1
65 20
2
0 0 0 33
0 22 20 41
1
end_operator
begin_operator
board car39 loc29
1
65 21
2
0 0 0 33
0 22 21 41
1
end_operator
begin_operator
board car39 loc3
1
65 22
2
0 0 0 33
0 22 22 41
1
end_operator
begin_operator
board car39 loc30
1
65 23
2
0 0 0 33
0 22 23 41
1
end_operator
begin_operator
board car39 loc31
1
65 24
2
0 0 0 33
0 22 24 41
1
end_operator
begin_operator
board car39 loc32
1
65 25
2
0 0 0 33
0 22 25 41
1
end_operator
begin_operator
board car39 loc33
1
65 26
2
0 0 0 33
0 22 26 41
1
end_operator
begin_operator
board car39 loc34
1
65 27
2
0 0 0 33
0 22 27 41
1
end_operator
begin_operator
board car39 loc35
1
65 28
2
0 0 0 33
0 22 28 41
1
end_operator
begin_operator
board car39 loc36
1
65 29
2
0 0 0 33
0 22 29 41
1
end_operator
begin_operator
board car39 loc37
1
65 30
2
0 0 0 33
0 22 30 41
1
end_operator
begin_operator
board car39 loc38
1
65 31
2
0 0 0 33
0 22 31 41
1
end_operator
begin_operator
board car39 loc39
1
65 32
2
0 0 0 33
0 22 32 41
1
end_operator
begin_operator
board car39 loc4
1
65 33
2
0 0 0 33
0 22 33 41
1
end_operator
begin_operator
board car39 loc40
1
65 34
2
0 0 0 33
0 22 34 41
1
end_operator
begin_operator
board car39 loc41
1
65 35
2
0 0 0 33
0 22 35 41
1
end_operator
begin_operator
board car39 loc5
1
65 36
2
0 0 0 33
0 22 36 41
1
end_operator
begin_operator
board car39 loc6
1
65 37
2
0 0 0 33
0 22 37 41
1
end_operator
begin_operator
board car39 loc7
1
65 38
2
0 0 0 33
0 22 38 41
1
end_operator
begin_operator
board car39 loc8
1
65 39
2
0 0 0 33
0 22 39 41
1
end_operator
begin_operator
board car39 loc9
1
65 40
2
0 0 0 33
0 22 40 41
1
end_operator
begin_operator
board car4 loc1
1
65 0
2
0 0 0 34
0 34 0 41
1
end_operator
begin_operator
board car4 loc10
1
65 1
2
0 0 0 34
0 34 1 41
1
end_operator
begin_operator
board car4 loc11
1
65 2
2
0 0 0 34
0 34 2 41
1
end_operator
begin_operator
board car4 loc12
1
65 3
2
0 0 0 34
0 34 3 41
1
end_operator
begin_operator
board car4 loc13
1
65 4
2
0 0 0 34
0 34 4 41
1
end_operator
begin_operator
board car4 loc14
1
65 5
2
0 0 0 34
0 34 5 41
1
end_operator
begin_operator
board car4 loc15
1
65 6
2
0 0 0 34
0 34 6 41
1
end_operator
begin_operator
board car4 loc16
1
65 7
2
0 0 0 34
0 34 7 41
1
end_operator
begin_operator
board car4 loc17
1
65 8
2
0 0 0 34
0 34 8 41
1
end_operator
begin_operator
board car4 loc18
1
65 9
2
0 0 0 34
0 34 9 41
1
end_operator
begin_operator
board car4 loc19
1
65 10
2
0 0 0 34
0 34 10 41
1
end_operator
begin_operator
board car4 loc2
1
65 11
2
0 0 0 34
0 34 11 41
1
end_operator
begin_operator
board car4 loc20
1
65 12
2
0 0 0 34
0 34 12 41
1
end_operator
begin_operator
board car4 loc21
1
65 13
2
0 0 0 34
0 34 13 41
1
end_operator
begin_operator
board car4 loc22
1
65 14
2
0 0 0 34
0 34 14 41
1
end_operator
begin_operator
board car4 loc23
1
65 15
2
0 0 0 34
0 34 15 41
1
end_operator
begin_operator
board car4 loc24
1
65 16
2
0 0 0 34
0 34 16 41
1
end_operator
begin_operator
board car4 loc25
1
65 17
2
0 0 0 34
0 34 17 41
1
end_operator
begin_operator
board car4 loc26
1
65 18
2
0 0 0 34
0 34 18 41
1
end_operator
begin_operator
board car4 loc27
1
65 19
2
0 0 0 34
0 34 19 41
1
end_operator
begin_operator
board car4 loc28
1
65 20
2
0 0 0 34
0 34 20 41
1
end_operator
begin_operator
board car4 loc29
1
65 21
2
0 0 0 34
0 34 21 41
1
end_operator
begin_operator
board car4 loc3
1
65 22
2
0 0 0 34
0 34 22 41
1
end_operator
begin_operator
board car4 loc30
1
65 23
2
0 0 0 34
0 34 23 41
1
end_operator
begin_operator
board car4 loc31
1
65 24
2
0 0 0 34
0 34 24 41
1
end_operator
begin_operator
board car4 loc32
1
65 25
2
0 0 0 34
0 34 25 41
1
end_operator
begin_operator
board car4 loc33
1
65 26
2
0 0 0 34
0 34 26 41
1
end_operator
begin_operator
board car4 loc34
1
65 27
2
0 0 0 34
0 34 27 41
1
end_operator
begin_operator
board car4 loc35
1
65 28
2
0 0 0 34
0 34 28 41
1
end_operator
begin_operator
board car4 loc36
1
65 29
2
0 0 0 34
0 34 29 41
1
end_operator
begin_operator
board car4 loc37
1
65 30
2
0 0 0 34
0 34 30 41
1
end_operator
begin_operator
board car4 loc38
1
65 31
2
0 0 0 34
0 34 31 41
1
end_operator
begin_operator
board car4 loc39
1
65 32
2
0 0 0 34
0 34 32 41
1
end_operator
begin_operator
board car4 loc4
1
65 33
2
0 0 0 34
0 34 33 41
1
end_operator
begin_operator
board car4 loc40
1
65 34
2
0 0 0 34
0 34 34 41
1
end_operator
begin_operator
board car4 loc41
1
65 35
2
0 0 0 34
0 34 35 41
1
end_operator
begin_operator
board car4 loc5
1
65 36
2
0 0 0 34
0 34 36 41
1
end_operator
begin_operator
board car4 loc6
1
65 37
2
0 0 0 34
0 34 37 41
1
end_operator
begin_operator
board car4 loc7
1
65 38
2
0 0 0 34
0 34 38 41
1
end_operator
begin_operator
board car4 loc8
1
65 39
2
0 0 0 34
0 34 39 41
1
end_operator
begin_operator
board car4 loc9
1
65 40
2
0 0 0 34
0 34 40 41
1
end_operator
begin_operator
board car40 loc1
1
65 0
2
0 0 0 35
0 46 0 41
1
end_operator
begin_operator
board car40 loc10
1
65 1
2
0 0 0 35
0 46 1 41
1
end_operator
begin_operator
board car40 loc11
1
65 2
2
0 0 0 35
0 46 2 41
1
end_operator
begin_operator
board car40 loc12
1
65 3
2
0 0 0 35
0 46 3 41
1
end_operator
begin_operator
board car40 loc13
1
65 4
2
0 0 0 35
0 46 4 41
1
end_operator
begin_operator
board car40 loc14
1
65 5
2
0 0 0 35
0 46 5 41
1
end_operator
begin_operator
board car40 loc15
1
65 6
2
0 0 0 35
0 46 6 41
1
end_operator
begin_operator
board car40 loc16
1
65 7
2
0 0 0 35
0 46 7 41
1
end_operator
begin_operator
board car40 loc17
1
65 8
2
0 0 0 35
0 46 8 41
1
end_operator
begin_operator
board car40 loc18
1
65 9
2
0 0 0 35
0 46 9 41
1
end_operator
begin_operator
board car40 loc19
1
65 10
2
0 0 0 35
0 46 10 41
1
end_operator
begin_operator
board car40 loc2
1
65 11
2
0 0 0 35
0 46 11 41
1
end_operator
begin_operator
board car40 loc20
1
65 12
2
0 0 0 35
0 46 12 41
1
end_operator
begin_operator
board car40 loc21
1
65 13
2
0 0 0 35
0 46 13 41
1
end_operator
begin_operator
board car40 loc22
1
65 14
2
0 0 0 35
0 46 14 41
1
end_operator
begin_operator
board car40 loc23
1
65 15
2
0 0 0 35
0 46 15 41
1
end_operator
begin_operator
board car40 loc24
1
65 16
2
0 0 0 35
0 46 16 41
1
end_operator
begin_operator
board car40 loc25
1
65 17
2
0 0 0 35
0 46 17 41
1
end_operator
begin_operator
board car40 loc26
1
65 18
2
0 0 0 35
0 46 18 41
1
end_operator
begin_operator
board car40 loc27
1
65 19
2
0 0 0 35
0 46 19 41
1
end_operator
begin_operator
board car40 loc28
1
65 20
2
0 0 0 35
0 46 20 41
1
end_operator
begin_operator
board car40 loc29
1
65 21
2
0 0 0 35
0 46 21 41
1
end_operator
begin_operator
board car40 loc3
1
65 22
2
0 0 0 35
0 46 22 41
1
end_operator
begin_operator
board car40 loc30
1
65 23
2
0 0 0 35
0 46 23 41
1
end_operator
begin_operator
board car40 loc31
1
65 24
2
0 0 0 35
0 46 24 41
1
end_operator
begin_operator
board car40 loc32
1
65 25
2
0 0 0 35
0 46 25 41
1
end_operator
begin_operator
board car40 loc33
1
65 26
2
0 0 0 35
0 46 26 41
1
end_operator
begin_operator
board car40 loc34
1
65 27
2
0 0 0 35
0 46 27 41
1
end_operator
begin_operator
board car40 loc35
1
65 28
2
0 0 0 35
0 46 28 41
1
end_operator
begin_operator
board car40 loc36
1
65 29
2
0 0 0 35
0 46 29 41
1
end_operator
begin_operator
board car40 loc37
1
65 30
2
0 0 0 35
0 46 30 41
1
end_operator
begin_operator
board car40 loc38
1
65 31
2
0 0 0 35
0 46 31 41
1
end_operator
begin_operator
board car40 loc39
1
65 32
2
0 0 0 35
0 46 32 41
1
end_operator
begin_operator
board car40 loc4
1
65 33
2
0 0 0 35
0 46 33 41
1
end_operator
begin_operator
board car40 loc40
1
65 34
2
0 0 0 35
0 46 34 41
1
end_operator
begin_operator
board car40 loc41
1
65 35
2
0 0 0 35
0 46 35 41
1
end_operator
begin_operator
board car40 loc5
1
65 36
2
0 0 0 35
0 46 36 41
1
end_operator
begin_operator
board car40 loc6
1
65 37
2
0 0 0 35
0 46 37 41
1
end_operator
begin_operator
board car40 loc7
1
65 38
2
0 0 0 35
0 46 38 41
1
end_operator
begin_operator
board car40 loc8
1
65 39
2
0 0 0 35
0 46 39 41
1
end_operator
begin_operator
board car40 loc9
1
65 40
2
0 0 0 35
0 46 40 41
1
end_operator
begin_operator
board car41 loc1
1
65 0
2
0 0 0 36
0 58 0 41
1
end_operator
begin_operator
board car41 loc10
1
65 1
2
0 0 0 36
0 58 1 41
1
end_operator
begin_operator
board car41 loc11
1
65 2
2
0 0 0 36
0 58 2 41
1
end_operator
begin_operator
board car41 loc12
1
65 3
2
0 0 0 36
0 58 3 41
1
end_operator
begin_operator
board car41 loc13
1
65 4
2
0 0 0 36
0 58 4 41
1
end_operator
begin_operator
board car41 loc14
1
65 5
2
0 0 0 36
0 58 5 41
1
end_operator
begin_operator
board car41 loc15
1
65 6
2
0 0 0 36
0 58 6 41
1
end_operator
begin_operator
board car41 loc16
1
65 7
2
0 0 0 36
0 58 7 41
1
end_operator
begin_operator
board car41 loc17
1
65 8
2
0 0 0 36
0 58 8 41
1
end_operator
begin_operator
board car41 loc18
1
65 9
2
0 0 0 36
0 58 9 41
1
end_operator
begin_operator
board car41 loc19
1
65 10
2
0 0 0 36
0 58 10 41
1
end_operator
begin_operator
board car41 loc2
1
65 11
2
0 0 0 36
0 58 11 41
1
end_operator
begin_operator
board car41 loc20
1
65 12
2
0 0 0 36
0 58 12 41
1
end_operator
begin_operator
board car41 loc21
1
65 13
2
0 0 0 36
0 58 13 41
1
end_operator
begin_operator
board car41 loc22
1
65 14
2
0 0 0 36
0 58 14 41
1
end_operator
begin_operator
board car41 loc23
1
65 15
2
0 0 0 36
0 58 15 41
1
end_operator
begin_operator
board car41 loc24
1
65 16
2
0 0 0 36
0 58 16 41
1
end_operator
begin_operator
board car41 loc25
1
65 17
2
0 0 0 36
0 58 17 41
1
end_operator
begin_operator
board car41 loc26
1
65 18
2
0 0 0 36
0 58 18 41
1
end_operator
begin_operator
board car41 loc27
1
65 19
2
0 0 0 36
0 58 19 41
1
end_operator
begin_operator
board car41 loc28
1
65 20
2
0 0 0 36
0 58 20 41
1
end_operator
begin_operator
board car41 loc29
1
65 21
2
0 0 0 36
0 58 21 41
1
end_operator
begin_operator
board car41 loc3
1
65 22
2
0 0 0 36
0 58 22 41
1
end_operator
begin_operator
board car41 loc30
1
65 23
2
0 0 0 36
0 58 23 41
1
end_operator
begin_operator
board car41 loc31
1
65 24
2
0 0 0 36
0 58 24 41
1
end_operator
begin_operator
board car41 loc32
1
65 25
2
0 0 0 36
0 58 25 41
1
end_operator
begin_operator
board car41 loc33
1
65 26
2
0 0 0 36
0 58 26 41
1
end_operator
begin_operator
board car41 loc34
1
65 27
2
0 0 0 36
0 58 27 41
1
end_operator
begin_operator
board car41 loc35
1
65 28
2
0 0 0 36
0 58 28 41
1
end_operator
begin_operator
board car41 loc36
1
65 29
2
0 0 0 36
0 58 29 41
1
end_operator
begin_operator
board car41 loc37
1
65 30
2
0 0 0 36
0 58 30 41
1
end_operator
begin_operator
board car41 loc38
1
65 31
2
0 0 0 36
0 58 31 41
1
end_operator
begin_operator
board car41 loc39
1
65 32
2
0 0 0 36
0 58 32 41
1
end_operator
begin_operator
board car41 loc4
1
65 33
2
0 0 0 36
0 58 33 41
1
end_operator
begin_operator
board car41 loc40
1
65 34
2
0 0 0 36
0 58 34 41
1
end_operator
begin_operator
board car41 loc41
1
65 35
2
0 0 0 36
0 58 35 41
1
end_operator
begin_operator
board car41 loc5
1
65 36
2
0 0 0 36
0 58 36 41
1
end_operator
begin_operator
board car41 loc6
1
65 37
2
0 0 0 36
0 58 37 41
1
end_operator
begin_operator
board car41 loc7
1
65 38
2
0 0 0 36
0 58 38 41
1
end_operator
begin_operator
board car41 loc8
1
65 39
2
0 0 0 36
0 58 39 41
1
end_operator
begin_operator
board car41 loc9
1
65 40
2
0 0 0 36
0 58 40 41
1
end_operator
begin_operator
board car42 loc1
1
65 0
2
0 0 0 37
0 70 0 41
1
end_operator
begin_operator
board car42 loc10
1
65 1
2
0 0 0 37
0 70 1 41
1
end_operator
begin_operator
board car42 loc11
1
65 2
2
0 0 0 37
0 70 2 41
1
end_operator
begin_operator
board car42 loc12
1
65 3
2
0 0 0 37
0 70 3 41
1
end_operator
begin_operator
board car42 loc13
1
65 4
2
0 0 0 37
0 70 4 41
1
end_operator
begin_operator
board car42 loc14
1
65 5
2
0 0 0 37
0 70 5 41
1
end_operator
begin_operator
board car42 loc15
1
65 6
2
0 0 0 37
0 70 6 41
1
end_operator
begin_operator
board car42 loc16
1
65 7
2
0 0 0 37
0 70 7 41
1
end_operator
begin_operator
board car42 loc17
1
65 8
2
0 0 0 37
0 70 8 41
1
end_operator
begin_operator
board car42 loc18
1
65 9
2
0 0 0 37
0 70 9 41
1
end_operator
begin_operator
board car42 loc19
1
65 10
2
0 0 0 37
0 70 10 41
1
end_operator
begin_operator
board car42 loc2
1
65 11
2
0 0 0 37
0 70 11 41
1
end_operator
begin_operator
board car42 loc20
1
65 12
2
0 0 0 37
0 70 12 41
1
end_operator
begin_operator
board car42 loc21
1
65 13
2
0 0 0 37
0 70 13 41
1
end_operator
begin_operator
board car42 loc22
1
65 14
2
0 0 0 37
0 70 14 41
1
end_operator
begin_operator
board car42 loc23
1
65 15
2
0 0 0 37
0 70 15 41
1
end_operator
begin_operator
board car42 loc24
1
65 16
2
0 0 0 37
0 70 16 41
1
end_operator
begin_operator
board car42 loc25
1
65 17
2
0 0 0 37
0 70 17 41
1
end_operator
begin_operator
board car42 loc26
1
65 18
2
0 0 0 37
0 70 18 41
1
end_operator
begin_operator
board car42 loc27
1
65 19
2
0 0 0 37
0 70 19 41
1
end_operator
begin_operator
board car42 loc28
1
65 20
2
0 0 0 37
0 70 20 41
1
end_operator
begin_operator
board car42 loc29
1
65 21
2
0 0 0 37
0 70 21 41
1
end_operator
begin_operator
board car42 loc3
1
65 22
2
0 0 0 37
0 70 22 41
1
end_operator
begin_operator
board car42 loc30
1
65 23
2
0 0 0 37
0 70 23 41
1
end_operator
begin_operator
board car42 loc31
1
65 24
2
0 0 0 37
0 70 24 41
1
end_operator
begin_operator
board car42 loc32
1
65 25
2
0 0 0 37
0 70 25 41
1
end_operator
begin_operator
board car42 loc33
1
65 26
2
0 0 0 37
0 70 26 41
1
end_operator
begin_operator
board car42 loc34
1
65 27
2
0 0 0 37
0 70 27 41
1
end_operator
begin_operator
board car42 loc35
1
65 28
2
0 0 0 37
0 70 28 41
1
end_operator
begin_operator
board car42 loc36
1
65 29
2
0 0 0 37
0 70 29 41
1
end_operator
begin_operator
board car42 loc37
1
65 30
2
0 0 0 37
0 70 30 41
1
end_operator
begin_operator
board car42 loc38
1
65 31
2
0 0 0 37
0 70 31 41
1
end_operator
begin_operator
board car42 loc39
1
65 32
2
0 0 0 37
0 70 32 41
1
end_operator
begin_operator
board car42 loc4
1
65 33
2
0 0 0 37
0 70 33 41
1
end_operator
begin_operator
board car42 loc40
1
65 34
2
0 0 0 37
0 70 34 41
1
end_operator
begin_operator
board car42 loc41
1
65 35
2
0 0 0 37
0 70 35 41
1
end_operator
begin_operator
board car42 loc5
1
65 36
2
0 0 0 37
0 70 36 41
1
end_operator
begin_operator
board car42 loc6
1
65 37
2
0 0 0 37
0 70 37 41
1
end_operator
begin_operator
board car42 loc7
1
65 38
2
0 0 0 37
0 70 38 41
1
end_operator
begin_operator
board car42 loc8
1
65 39
2
0 0 0 37
0 70 39 41
1
end_operator
begin_operator
board car42 loc9
1
65 40
2
0 0 0 37
0 70 40 41
1
end_operator
begin_operator
board car43 loc1
1
65 0
2
0 0 0 38
0 7 0 41
1
end_operator
begin_operator
board car43 loc10
1
65 1
2
0 0 0 38
0 7 1 41
1
end_operator
begin_operator
board car43 loc11
1
65 2
2
0 0 0 38
0 7 2 41
1
end_operator
begin_operator
board car43 loc12
1
65 3
2
0 0 0 38
0 7 3 41
1
end_operator
begin_operator
board car43 loc13
1
65 4
2
0 0 0 38
0 7 4 41
1
end_operator
begin_operator
board car43 loc14
1
65 5
2
0 0 0 38
0 7 5 41
1
end_operator
begin_operator
board car43 loc15
1
65 6
2
0 0 0 38
0 7 6 41
1
end_operator
begin_operator
board car43 loc16
1
65 7
2
0 0 0 38
0 7 7 41
1
end_operator
begin_operator
board car43 loc17
1
65 8
2
0 0 0 38
0 7 8 41
1
end_operator
begin_operator
board car43 loc18
1
65 9
2
0 0 0 38
0 7 9 41
1
end_operator
begin_operator
board car43 loc19
1
65 10
2
0 0 0 38
0 7 10 41
1
end_operator
begin_operator
board car43 loc2
1
65 11
2
0 0 0 38
0 7 11 41
1
end_operator
begin_operator
board car43 loc20
1
65 12
2
0 0 0 38
0 7 12 41
1
end_operator
begin_operator
board car43 loc21
1
65 13
2
0 0 0 38
0 7 13 41
1
end_operator
begin_operator
board car43 loc22
1
65 14
2
0 0 0 38
0 7 14 41
1
end_operator
begin_operator
board car43 loc23
1
65 15
2
0 0 0 38
0 7 15 41
1
end_operator
begin_operator
board car43 loc24
1
65 16
2
0 0 0 38
0 7 16 41
1
end_operator
begin_operator
board car43 loc25
1
65 17
2
0 0 0 38
0 7 17 41
1
end_operator
begin_operator
board car43 loc26
1
65 18
2
0 0 0 38
0 7 18 41
1
end_operator
begin_operator
board car43 loc27
1
65 19
2
0 0 0 38
0 7 19 41
1
end_operator
begin_operator
board car43 loc28
1
65 20
2
0 0 0 38
0 7 20 41
1
end_operator
begin_operator
board car43 loc29
1
65 21
2
0 0 0 38
0 7 21 41
1
end_operator
begin_operator
board car43 loc3
1
65 22
2
0 0 0 38
0 7 22 41
1
end_operator
begin_operator
board car43 loc30
1
65 23
2
0 0 0 38
0 7 23 41
1
end_operator
begin_operator
board car43 loc31
1
65 24
2
0 0 0 38
0 7 24 41
1
end_operator
begin_operator
board car43 loc32
1
65 25
2
0 0 0 38
0 7 25 41
1
end_operator
begin_operator
board car43 loc33
1
65 26
2
0 0 0 38
0 7 26 41
1
end_operator
begin_operator
board car43 loc34
1
65 27
2
0 0 0 38
0 7 27 41
1
end_operator
begin_operator
board car43 loc35
1
65 28
2
0 0 0 38
0 7 28 41
1
end_operator
begin_operator
board car43 loc36
1
65 29
2
0 0 0 38
0 7 29 41
1
end_operator
begin_operator
board car43 loc37
1
65 30
2
0 0 0 38
0 7 30 41
1
end_operator
begin_operator
board car43 loc38
1
65 31
2
0 0 0 38
0 7 31 41
1
end_operator
begin_operator
board car43 loc39
1
65 32
2
0 0 0 38
0 7 32 41
1
end_operator
begin_operator
board car43 loc4
1
65 33
2
0 0 0 38
0 7 33 41
1
end_operator
begin_operator
board car43 loc40
1
65 34
2
0 0 0 38
0 7 34 41
1
end_operator
begin_operator
board car43 loc41
1
65 35
2
0 0 0 38
0 7 35 41
1
end_operator
begin_operator
board car43 loc5
1
65 36
2
0 0 0 38
0 7 36 41
1
end_operator
begin_operator
board car43 loc6
1
65 37
2
0 0 0 38
0 7 37 41
1
end_operator
begin_operator
board car43 loc7
1
65 38
2
0 0 0 38
0 7 38 41
1
end_operator
begin_operator
board car43 loc8
1
65 39
2
0 0 0 38
0 7 39 41
1
end_operator
begin_operator
board car43 loc9
1
65 40
2
0 0 0 38
0 7 40 41
1
end_operator
begin_operator
board car44 loc1
1
65 0
2
0 0 0 39
0 19 0 41
1
end_operator
begin_operator
board car44 loc10
1
65 1
2
0 0 0 39
0 19 1 41
1
end_operator
begin_operator
board car44 loc11
1
65 2
2
0 0 0 39
0 19 2 41
1
end_operator
begin_operator
board car44 loc12
1
65 3
2
0 0 0 39
0 19 3 41
1
end_operator
begin_operator
board car44 loc13
1
65 4
2
0 0 0 39
0 19 4 41
1
end_operator
begin_operator
board car44 loc14
1
65 5
2
0 0 0 39
0 19 5 41
1
end_operator
begin_operator
board car44 loc15
1
65 6
2
0 0 0 39
0 19 6 41
1
end_operator
begin_operator
board car44 loc16
1
65 7
2
0 0 0 39
0 19 7 41
1
end_operator
begin_operator
board car44 loc17
1
65 8
2
0 0 0 39
0 19 8 41
1
end_operator
begin_operator
board car44 loc18
1
65 9
2
0 0 0 39
0 19 9 41
1
end_operator
begin_operator
board car44 loc19
1
65 10
2
0 0 0 39
0 19 10 41
1
end_operator
begin_operator
board car44 loc2
1
65 11
2
0 0 0 39
0 19 11 41
1
end_operator
begin_operator
board car44 loc20
1
65 12
2
0 0 0 39
0 19 12 41
1
end_operator
begin_operator
board car44 loc21
1
65 13
2
0 0 0 39
0 19 13 41
1
end_operator
begin_operator
board car44 loc22
1
65 14
2
0 0 0 39
0 19 14 41
1
end_operator
begin_operator
board car44 loc23
1
65 15
2
0 0 0 39
0 19 15 41
1
end_operator
begin_operator
board car44 loc24
1
65 16
2
0 0 0 39
0 19 16 41
1
end_operator
begin_operator
board car44 loc25
1
65 17
2
0 0 0 39
0 19 17 41
1
end_operator
begin_operator
board car44 loc26
1
65 18
2
0 0 0 39
0 19 18 41
1
end_operator
begin_operator
board car44 loc27
1
65 19
2
0 0 0 39
0 19 19 41
1
end_operator
begin_operator
board car44 loc28
1
65 20
2
0 0 0 39
0 19 20 41
1
end_operator
begin_operator
board car44 loc29
1
65 21
2
0 0 0 39
0 19 21 41
1
end_operator
begin_operator
board car44 loc3
1
65 22
2
0 0 0 39
0 19 22 41
1
end_operator
begin_operator
board car44 loc30
1
65 23
2
0 0 0 39
0 19 23 41
1
end_operator
begin_operator
board car44 loc31
1
65 24
2
0 0 0 39
0 19 24 41
1
end_operator
begin_operator
board car44 loc32
1
65 25
2
0 0 0 39
0 19 25 41
1
end_operator
begin_operator
board car44 loc33
1
65 26
2
0 0 0 39
0 19 26 41
1
end_operator
begin_operator
board car44 loc34
1
65 27
2
0 0 0 39
0 19 27 41
1
end_operator
begin_operator
board car44 loc35
1
65 28
2
0 0 0 39
0 19 28 41
1
end_operator
begin_operator
board car44 loc36
1
65 29
2
0 0 0 39
0 19 29 41
1
end_operator
begin_operator
board car44 loc37
1
65 30
2
0 0 0 39
0 19 30 41
1
end_operator
begin_operator
board car44 loc38
1
65 31
2
0 0 0 39
0 19 31 41
1
end_operator
begin_operator
board car44 loc39
1
65 32
2
0 0 0 39
0 19 32 41
1
end_operator
begin_operator
board car44 loc4
1
65 33
2
0 0 0 39
0 19 33 41
1
end_operator
begin_operator
board car44 loc40
1
65 34
2
0 0 0 39
0 19 34 41
1
end_operator
begin_operator
board car44 loc41
1
65 35
2
0 0 0 39
0 19 35 41
1
end_operator
begin_operator
board car44 loc5
1
65 36
2
0 0 0 39
0 19 36 41
1
end_operator
begin_operator
board car44 loc6
1
65 37
2
0 0 0 39
0 19 37 41
1
end_operator
begin_operator
board car44 loc7
1
65 38
2
0 0 0 39
0 19 38 41
1
end_operator
begin_operator
board car44 loc8
1
65 39
2
0 0 0 39
0 19 39 41
1
end_operator
begin_operator
board car44 loc9
1
65 40
2
0 0 0 39
0 19 40 41
1
end_operator
begin_operator
board car45 loc1
1
65 0
2
0 0 0 40
0 31 0 41
1
end_operator
begin_operator
board car45 loc10
1
65 1
2
0 0 0 40
0 31 1 41
1
end_operator
begin_operator
board car45 loc11
1
65 2
2
0 0 0 40
0 31 2 41
1
end_operator
begin_operator
board car45 loc12
1
65 3
2
0 0 0 40
0 31 3 41
1
end_operator
begin_operator
board car45 loc13
1
65 4
2
0 0 0 40
0 31 4 41
1
end_operator
begin_operator
board car45 loc14
1
65 5
2
0 0 0 40
0 31 5 41
1
end_operator
begin_operator
board car45 loc15
1
65 6
2
0 0 0 40
0 31 6 41
1
end_operator
begin_operator
board car45 loc16
1
65 7
2
0 0 0 40
0 31 7 41
1
end_operator
begin_operator
board car45 loc17
1
65 8
2
0 0 0 40
0 31 8 41
1
end_operator
begin_operator
board car45 loc18
1
65 9
2
0 0 0 40
0 31 9 41
1
end_operator
begin_operator
board car45 loc19
1
65 10
2
0 0 0 40
0 31 10 41
1
end_operator
begin_operator
board car45 loc2
1
65 11
2
0 0 0 40
0 31 11 41
1
end_operator
begin_operator
board car45 loc20
1
65 12
2
0 0 0 40
0 31 12 41
1
end_operator
begin_operator
board car45 loc21
1
65 13
2
0 0 0 40
0 31 13 41
1
end_operator
begin_operator
board car45 loc22
1
65 14
2
0 0 0 40
0 31 14 41
1
end_operator
begin_operator
board car45 loc23
1
65 15
2
0 0 0 40
0 31 15 41
1
end_operator
begin_operator
board car45 loc24
1
65 16
2
0 0 0 40
0 31 16 41
1
end_operator
begin_operator
board car45 loc25
1
65 17
2
0 0 0 40
0 31 17 41
1
end_operator
begin_operator
board car45 loc26
1
65 18
2
0 0 0 40
0 31 18 41
1
end_operator
begin_operator
board car45 loc27
1
65 19
2
0 0 0 40
0 31 19 41
1
end_operator
begin_operator
board car45 loc28
1
65 20
2
0 0 0 40
0 31 20 41
1
end_operator
begin_operator
board car45 loc29
1
65 21
2
0 0 0 40
0 31 21 41
1
end_operator
begin_operator
board car45 loc3
1
65 22
2
0 0 0 40
0 31 22 41
1
end_operator
begin_operator
board car45 loc30
1
65 23
2
0 0 0 40
0 31 23 41
1
end_operator
begin_operator
board car45 loc31
1
65 24
2
0 0 0 40
0 31 24 41
1
end_operator
begin_operator
board car45 loc32
1
65 25
2
0 0 0 40
0 31 25 41
1
end_operator
begin_operator
board car45 loc33
1
65 26
2
0 0 0 40
0 31 26 41
1
end_operator
begin_operator
board car45 loc34
1
65 27
2
0 0 0 40
0 31 27 41
1
end_operator
begin_operator
board car45 loc35
1
65 28
2
0 0 0 40
0 31 28 41
1
end_operator
begin_operator
board car45 loc36
1
65 29
2
0 0 0 40
0 31 29 41
1
end_operator
begin_operator
board car45 loc37
1
65 30
2
0 0 0 40
0 31 30 41
1
end_operator
begin_operator
board car45 loc38
1
65 31
2
0 0 0 40
0 31 31 41
1
end_operator
begin_operator
board car45 loc39
1
65 32
2
0 0 0 40
0 31 32 41
1
end_operator
begin_operator
board car45 loc4
1
65 33
2
0 0 0 40
0 31 33 41
1
end_operator
begin_operator
board car45 loc40
1
65 34
2
0 0 0 40
0 31 34 41
1
end_operator
begin_operator
board car45 loc41
1
65 35
2
0 0 0 40
0 31 35 41
1
end_operator
begin_operator
board car45 loc5
1
65 36
2
0 0 0 40
0 31 36 41
1
end_operator
begin_operator
board car45 loc6
1
65 37
2
0 0 0 40
0 31 37 41
1
end_operator
begin_operator
board car45 loc7
1
65 38
2
0 0 0 40
0 31 38 41
1
end_operator
begin_operator
board car45 loc8
1
65 39
2
0 0 0 40
0 31 39 41
1
end_operator
begin_operator
board car45 loc9
1
65 40
2
0 0 0 40
0 31 40 41
1
end_operator
begin_operator
board car46 loc1
1
65 0
2
0 0 0 41
0 43 0 41
1
end_operator
begin_operator
board car46 loc10
1
65 1
2
0 0 0 41
0 43 1 41
1
end_operator
begin_operator
board car46 loc11
1
65 2
2
0 0 0 41
0 43 2 41
1
end_operator
begin_operator
board car46 loc12
1
65 3
2
0 0 0 41
0 43 3 41
1
end_operator
begin_operator
board car46 loc13
1
65 4
2
0 0 0 41
0 43 4 41
1
end_operator
begin_operator
board car46 loc14
1
65 5
2
0 0 0 41
0 43 5 41
1
end_operator
begin_operator
board car46 loc15
1
65 6
2
0 0 0 41
0 43 6 41
1
end_operator
begin_operator
board car46 loc16
1
65 7
2
0 0 0 41
0 43 7 41
1
end_operator
begin_operator
board car46 loc17
1
65 8
2
0 0 0 41
0 43 8 41
1
end_operator
begin_operator
board car46 loc18
1
65 9
2
0 0 0 41
0 43 9 41
1
end_operator
begin_operator
board car46 loc19
1
65 10
2
0 0 0 41
0 43 10 41
1
end_operator
begin_operator
board car46 loc2
1
65 11
2
0 0 0 41
0 43 11 41
1
end_operator
begin_operator
board car46 loc20
1
65 12
2
0 0 0 41
0 43 12 41
1
end_operator
begin_operator
board car46 loc21
1
65 13
2
0 0 0 41
0 43 13 41
1
end_operator
begin_operator
board car46 loc22
1
65 14
2
0 0 0 41
0 43 14 41
1
end_operator
begin_operator
board car46 loc23
1
65 15
2
0 0 0 41
0 43 15 41
1
end_operator
begin_operator
board car46 loc24
1
65 16
2
0 0 0 41
0 43 16 41
1
end_operator
begin_operator
board car46 loc25
1
65 17
2
0 0 0 41
0 43 17 41
1
end_operator
begin_operator
board car46 loc26
1
65 18
2
0 0 0 41
0 43 18 41
1
end_operator
begin_operator
board car46 loc27
1
65 19
2
0 0 0 41
0 43 19 41
1
end_operator
begin_operator
board car46 loc28
1
65 20
2
0 0 0 41
0 43 20 41
1
end_operator
begin_operator
board car46 loc29
1
65 21
2
0 0 0 41
0 43 21 41
1
end_operator
begin_operator
board car46 loc3
1
65 22
2
0 0 0 41
0 43 22 41
1
end_operator
begin_operator
board car46 loc30
1
65 23
2
0 0 0 41
0 43 23 41
1
end_operator
begin_operator
board car46 loc31
1
65 24
2
0 0 0 41
0 43 24 41
1
end_operator
begin_operator
board car46 loc32
1
65 25
2
0 0 0 41
0 43 25 41
1
end_operator
begin_operator
board car46 loc33
1
65 26
2
0 0 0 41
0 43 26 41
1
end_operator
begin_operator
board car46 loc34
1
65 27
2
0 0 0 41
0 43 27 41
1
end_operator
begin_operator
board car46 loc35
1
65 28
2
0 0 0 41
0 43 28 41
1
end_operator
begin_operator
board car46 loc36
1
65 29
2
0 0 0 41
0 43 29 41
1
end_operator
begin_operator
board car46 loc37
1
65 30
2
0 0 0 41
0 43 30 41
1
end_operator
begin_operator
board car46 loc38
1
65 31
2
0 0 0 41
0 43 31 41
1
end_operator
begin_operator
board car46 loc39
1
65 32
2
0 0 0 41
0 43 32 41
1
end_operator
begin_operator
board car46 loc4
1
65 33
2
0 0 0 41
0 43 33 41
1
end_operator
begin_operator
board car46 loc40
1
65 34
2
0 0 0 41
0 43 34 41
1
end_operator
begin_operator
board car46 loc41
1
65 35
2
0 0 0 41
0 43 35 41
1
end_operator
begin_operator
board car46 loc5
1
65 36
2
0 0 0 41
0 43 36 41
1
end_operator
begin_operator
board car46 loc6
1
65 37
2
0 0 0 41
0 43 37 41
1
end_operator
begin_operator
board car46 loc7
1
65 38
2
0 0 0 41
0 43 38 41
1
end_operator
begin_operator
board car46 loc8
1
65 39
2
0 0 0 41
0 43 39 41
1
end_operator
begin_operator
board car46 loc9
1
65 40
2
0 0 0 41
0 43 40 41
1
end_operator
begin_operator
board car47 loc1
1
65 0
2
0 0 0 42
0 55 0 41
1
end_operator
begin_operator
board car47 loc10
1
65 1
2
0 0 0 42
0 55 1 41
1
end_operator
begin_operator
board car47 loc11
1
65 2
2
0 0 0 42
0 55 2 41
1
end_operator
begin_operator
board car47 loc12
1
65 3
2
0 0 0 42
0 55 3 41
1
end_operator
begin_operator
board car47 loc13
1
65 4
2
0 0 0 42
0 55 4 41
1
end_operator
begin_operator
board car47 loc14
1
65 5
2
0 0 0 42
0 55 5 41
1
end_operator
begin_operator
board car47 loc15
1
65 6
2
0 0 0 42
0 55 6 41
1
end_operator
begin_operator
board car47 loc16
1
65 7
2
0 0 0 42
0 55 7 41
1
end_operator
begin_operator
board car47 loc17
1
65 8
2
0 0 0 42
0 55 8 41
1
end_operator
begin_operator
board car47 loc18
1
65 9
2
0 0 0 42
0 55 9 41
1
end_operator
begin_operator
board car47 loc19
1
65 10
2
0 0 0 42
0 55 10 41
1
end_operator
begin_operator
board car47 loc2
1
65 11
2
0 0 0 42
0 55 11 41
1
end_operator
begin_operator
board car47 loc20
1
65 12
2
0 0 0 42
0 55 12 41
1
end_operator
begin_operator
board car47 loc21
1
65 13
2
0 0 0 42
0 55 13 41
1
end_operator
begin_operator
board car47 loc22
1
65 14
2
0 0 0 42
0 55 14 41
1
end_operator
begin_operator
board car47 loc23
1
65 15
2
0 0 0 42
0 55 15 41
1
end_operator
begin_operator
board car47 loc24
1
65 16
2
0 0 0 42
0 55 16 41
1
end_operator
begin_operator
board car47 loc25
1
65 17
2
0 0 0 42
0 55 17 41
1
end_operator
begin_operator
board car47 loc26
1
65 18
2
0 0 0 42
0 55 18 41
1
end_operator
begin_operator
board car47 loc27
1
65 19
2
0 0 0 42
0 55 19 41
1
end_operator
begin_operator
board car47 loc28
1
65 20
2
0 0 0 42
0 55 20 41
1
end_operator
begin_operator
board car47 loc29
1
65 21
2
0 0 0 42
0 55 21 41
1
end_operator
begin_operator
board car47 loc3
1
65 22
2
0 0 0 42
0 55 22 41
1
end_operator
begin_operator
board car47 loc30
1
65 23
2
0 0 0 42
0 55 23 41
1
end_operator
begin_operator
board car47 loc31
1
65 24
2
0 0 0 42
0 55 24 41
1
end_operator
begin_operator
board car47 loc32
1
65 25
2
0 0 0 42
0 55 25 41
1
end_operator
begin_operator
board car47 loc33
1
65 26
2
0 0 0 42
0 55 26 41
1
end_operator
begin_operator
board car47 loc34
1
65 27
2
0 0 0 42
0 55 27 41
1
end_operator
begin_operator
board car47 loc35
1
65 28
2
0 0 0 42
0 55 28 41
1
end_operator
begin_operator
board car47 loc36
1
65 29
2
0 0 0 42
0 55 29 41
1
end_operator
begin_operator
board car47 loc37
1
65 30
2
0 0 0 42
0 55 30 41
1
end_operator
begin_operator
board car47 loc38
1
65 31
2
0 0 0 42
0 55 31 41
1
end_operator
begin_operator
board car47 loc39
1
65 32
2
0 0 0 42
0 55 32 41
1
end_operator
begin_operator
board car47 loc4
1
65 33
2
0 0 0 42
0 55 33 41
1
end_operator
begin_operator
board car47 loc40
1
65 34
2
0 0 0 42
0 55 34 41
1
end_operator
begin_operator
board car47 loc41
1
65 35
2
0 0 0 42
0 55 35 41
1
end_operator
begin_operator
board car47 loc5
1
65 36
2
0 0 0 42
0 55 36 41
1
end_operator
begin_operator
board car47 loc6
1
65 37
2
0 0 0 42
0 55 37 41
1
end_operator
begin_operator
board car47 loc7
1
65 38
2
0 0 0 42
0 55 38 41
1
end_operator
begin_operator
board car47 loc8
1
65 39
2
0 0 0 42
0 55 39 41
1
end_operator
begin_operator
board car47 loc9
1
65 40
2
0 0 0 42
0 55 40 41
1
end_operator
begin_operator
board car48 loc1
1
65 0
2
0 0 0 43
0 67 0 41
1
end_operator
begin_operator
board car48 loc10
1
65 1
2
0 0 0 43
0 67 1 41
1
end_operator
begin_operator
board car48 loc11
1
65 2
2
0 0 0 43
0 67 2 41
1
end_operator
begin_operator
board car48 loc12
1
65 3
2
0 0 0 43
0 67 3 41
1
end_operator
begin_operator
board car48 loc13
1
65 4
2
0 0 0 43
0 67 4 41
1
end_operator
begin_operator
board car48 loc14
1
65 5
2
0 0 0 43
0 67 5 41
1
end_operator
begin_operator
board car48 loc15
1
65 6
2
0 0 0 43
0 67 6 41
1
end_operator
begin_operator
board car48 loc16
1
65 7
2
0 0 0 43
0 67 7 41
1
end_operator
begin_operator
board car48 loc17
1
65 8
2
0 0 0 43
0 67 8 41
1
end_operator
begin_operator
board car48 loc18
1
65 9
2
0 0 0 43
0 67 9 41
1
end_operator
begin_operator
board car48 loc19
1
65 10
2
0 0 0 43
0 67 10 41
1
end_operator
begin_operator
board car48 loc2
1
65 11
2
0 0 0 43
0 67 11 41
1
end_operator
begin_operator
board car48 loc20
1
65 12
2
0 0 0 43
0 67 12 41
1
end_operator
begin_operator
board car48 loc21
1
65 13
2
0 0 0 43
0 67 13 41
1
end_operator
begin_operator
board car48 loc22
1
65 14
2
0 0 0 43
0 67 14 41
1
end_operator
begin_operator
board car48 loc23
1
65 15
2
0 0 0 43
0 67 15 41
1
end_operator
begin_operator
board car48 loc24
1
65 16
2
0 0 0 43
0 67 16 41
1
end_operator
begin_operator
board car48 loc25
1
65 17
2
0 0 0 43
0 67 17 41
1
end_operator
begin_operator
board car48 loc26
1
65 18
2
0 0 0 43
0 67 18 41
1
end_operator
begin_operator
board car48 loc27
1
65 19
2
0 0 0 43
0 67 19 41
1
end_operator
begin_operator
board car48 loc28
1
65 20
2
0 0 0 43
0 67 20 41
1
end_operator
begin_operator
board car48 loc29
1
65 21
2
0 0 0 43
0 67 21 41
1
end_operator
begin_operator
board car48 loc3
1
65 22
2
0 0 0 43
0 67 22 41
1
end_operator
begin_operator
board car48 loc30
1
65 23
2
0 0 0 43
0 67 23 41
1
end_operator
begin_operator
board car48 loc31
1
65 24
2
0 0 0 43
0 67 24 41
1
end_operator
begin_operator
board car48 loc32
1
65 25
2
0 0 0 43
0 67 25 41
1
end_operator
begin_operator
board car48 loc33
1
65 26
2
0 0 0 43
0 67 26 41
1
end_operator
begin_operator
board car48 loc34
1
65 27
2
0 0 0 43
0 67 27 41
1
end_operator
begin_operator
board car48 loc35
1
65 28
2
0 0 0 43
0 67 28 41
1
end_operator
begin_operator
board car48 loc36
1
65 29
2
0 0 0 43
0 67 29 41
1
end_operator
begin_operator
board car48 loc37
1
65 30
2
0 0 0 43
0 67 30 41
1
end_operator
begin_operator
board car48 loc38
1
65 31
2
0 0 0 43
0 67 31 41
1
end_operator
begin_operator
board car48 loc39
1
65 32
2
0 0 0 43
0 67 32 41
1
end_operator
begin_operator
board car48 loc4
1
65 33
2
0 0 0 43
0 67 33 41
1
end_operator
begin_operator
board car48 loc40
1
65 34
2
0 0 0 43
0 67 34 41
1
end_operator
begin_operator
board car48 loc41
1
65 35
2
0 0 0 43
0 67 35 41
1
end_operator
begin_operator
board car48 loc5
1
65 36
2
0 0 0 43
0 67 36 41
1
end_operator
begin_operator
board car48 loc6
1
65 37
2
0 0 0 43
0 67 37 41
1
end_operator
begin_operator
board car48 loc7
1
65 38
2
0 0 0 43
0 67 38 41
1
end_operator
begin_operator
board car48 loc8
1
65 39
2
0 0 0 43
0 67 39 41
1
end_operator
begin_operator
board car48 loc9
1
65 40
2
0 0 0 43
0 67 40 41
1
end_operator
begin_operator
board car49 loc1
1
65 0
2
0 0 0 44
0 4 0 41
1
end_operator
begin_operator
board car49 loc10
1
65 1
2
0 0 0 44
0 4 1 41
1
end_operator
begin_operator
board car49 loc11
1
65 2
2
0 0 0 44
0 4 2 41
1
end_operator
begin_operator
board car49 loc12
1
65 3
2
0 0 0 44
0 4 3 41
1
end_operator
begin_operator
board car49 loc13
1
65 4
2
0 0 0 44
0 4 4 41
1
end_operator
begin_operator
board car49 loc14
1
65 5
2
0 0 0 44
0 4 5 41
1
end_operator
begin_operator
board car49 loc15
1
65 6
2
0 0 0 44
0 4 6 41
1
end_operator
begin_operator
board car49 loc16
1
65 7
2
0 0 0 44
0 4 7 41
1
end_operator
begin_operator
board car49 loc17
1
65 8
2
0 0 0 44
0 4 8 41
1
end_operator
begin_operator
board car49 loc18
1
65 9
2
0 0 0 44
0 4 9 41
1
end_operator
begin_operator
board car49 loc19
1
65 10
2
0 0 0 44
0 4 10 41
1
end_operator
begin_operator
board car49 loc2
1
65 11
2
0 0 0 44
0 4 11 41
1
end_operator
begin_operator
board car49 loc20
1
65 12
2
0 0 0 44
0 4 12 41
1
end_operator
begin_operator
board car49 loc21
1
65 13
2
0 0 0 44
0 4 13 41
1
end_operator
begin_operator
board car49 loc22
1
65 14
2
0 0 0 44
0 4 14 41
1
end_operator
begin_operator
board car49 loc23
1
65 15
2
0 0 0 44
0 4 15 41
1
end_operator
begin_operator
board car49 loc24
1
65 16
2
0 0 0 44
0 4 16 41
1
end_operator
begin_operator
board car49 loc25
1
65 17
2
0 0 0 44
0 4 17 41
1
end_operator
begin_operator
board car49 loc26
1
65 18
2
0 0 0 44
0 4 18 41
1
end_operator
begin_operator
board car49 loc27
1
65 19
2
0 0 0 44
0 4 19 41
1
end_operator
begin_operator
board car49 loc28
1
65 20
2
0 0 0 44
0 4 20 41
1
end_operator
begin_operator
board car49 loc29
1
65 21
2
0 0 0 44
0 4 21 41
1
end_operator
begin_operator
board car49 loc3
1
65 22
2
0 0 0 44
0 4 22 41
1
end_operator
begin_operator
board car49 loc30
1
65 23
2
0 0 0 44
0 4 23 41
1
end_operator
begin_operator
board car49 loc31
1
65 24
2
0 0 0 44
0 4 24 41
1
end_operator
begin_operator
board car49 loc32
1
65 25
2
0 0 0 44
0 4 25 41
1
end_operator
begin_operator
board car49 loc33
1
65 26
2
0 0 0 44
0 4 26 41
1
end_operator
begin_operator
board car49 loc34
1
65 27
2
0 0 0 44
0 4 27 41
1
end_operator
begin_operator
board car49 loc35
1
65 28
2
0 0 0 44
0 4 28 41
1
end_operator
begin_operator
board car49 loc36
1
65 29
2
0 0 0 44
0 4 29 41
1
end_operator
begin_operator
board car49 loc37
1
65 30
2
0 0 0 44
0 4 30 41
1
end_operator
begin_operator
board car49 loc38
1
65 31
2
0 0 0 44
0 4 31 41
1
end_operator
begin_operator
board car49 loc39
1
65 32
2
0 0 0 44
0 4 32 41
1
end_operator
begin_operator
board car49 loc4
1
65 33
2
0 0 0 44
0 4 33 41
1
end_operator
begin_operator
board car49 loc40
1
65 34
2
0 0 0 44
0 4 34 41
1
end_operator
begin_operator
board car49 loc41
1
65 35
2
0 0 0 44
0 4 35 41
1
end_operator
begin_operator
board car49 loc5
1
65 36
2
0 0 0 44
0 4 36 41
1
end_operator
begin_operator
board car49 loc6
1
65 37
2
0 0 0 44
0 4 37 41
1
end_operator
begin_operator
board car49 loc7
1
65 38
2
0 0 0 44
0 4 38 41
1
end_operator
begin_operator
board car49 loc8
1
65 39
2
0 0 0 44
0 4 39 41
1
end_operator
begin_operator
board car49 loc9
1
65 40
2
0 0 0 44
0 4 40 41
1
end_operator
begin_operator
board car5 loc1
1
65 0
2
0 0 0 45
0 16 0 41
1
end_operator
begin_operator
board car5 loc10
1
65 1
2
0 0 0 45
0 16 1 41
1
end_operator
begin_operator
board car5 loc11
1
65 2
2
0 0 0 45
0 16 2 41
1
end_operator
begin_operator
board car5 loc12
1
65 3
2
0 0 0 45
0 16 3 41
1
end_operator
begin_operator
board car5 loc13
1
65 4
2
0 0 0 45
0 16 4 41
1
end_operator
begin_operator
board car5 loc14
1
65 5
2
0 0 0 45
0 16 5 41
1
end_operator
begin_operator
board car5 loc15
1
65 6
2
0 0 0 45
0 16 6 41
1
end_operator
begin_operator
board car5 loc16
1
65 7
2
0 0 0 45
0 16 7 41
1
end_operator
begin_operator
board car5 loc17
1
65 8
2
0 0 0 45
0 16 8 41
1
end_operator
begin_operator
board car5 loc18
1
65 9
2
0 0 0 45
0 16 9 41
1
end_operator
begin_operator
board car5 loc19
1
65 10
2
0 0 0 45
0 16 10 41
1
end_operator
begin_operator
board car5 loc2
1
65 11
2
0 0 0 45
0 16 11 41
1
end_operator
begin_operator
board car5 loc20
1
65 12
2
0 0 0 45
0 16 12 41
1
end_operator
begin_operator
board car5 loc21
1
65 13
2
0 0 0 45
0 16 13 41
1
end_operator
begin_operator
board car5 loc22
1
65 14
2
0 0 0 45
0 16 14 41
1
end_operator
begin_operator
board car5 loc23
1
65 15
2
0 0 0 45
0 16 15 41
1
end_operator
begin_operator
board car5 loc24
1
65 16
2
0 0 0 45
0 16 16 41
1
end_operator
begin_operator
board car5 loc25
1
65 17
2
0 0 0 45
0 16 17 41
1
end_operator
begin_operator
board car5 loc26
1
65 18
2
0 0 0 45
0 16 18 41
1
end_operator
begin_operator
board car5 loc27
1
65 19
2
0 0 0 45
0 16 19 41
1
end_operator
begin_operator
board car5 loc28
1
65 20
2
0 0 0 45
0 16 20 41
1
end_operator
begin_operator
board car5 loc29
1
65 21
2
0 0 0 45
0 16 21 41
1
end_operator
begin_operator
board car5 loc3
1
65 22
2
0 0 0 45
0 16 22 41
1
end_operator
begin_operator
board car5 loc30
1
65 23
2
0 0 0 45
0 16 23 41
1
end_operator
begin_operator
board car5 loc31
1
65 24
2
0 0 0 45
0 16 24 41
1
end_operator
begin_operator
board car5 loc32
1
65 25
2
0 0 0 45
0 16 25 41
1
end_operator
begin_operator
board car5 loc33
1
65 26
2
0 0 0 45
0 16 26 41
1
end_operator
begin_operator
board car5 loc34
1
65 27
2
0 0 0 45
0 16 27 41
1
end_operator
begin_operator
board car5 loc35
1
65 28
2
0 0 0 45
0 16 28 41
1
end_operator
begin_operator
board car5 loc36
1
65 29
2
0 0 0 45
0 16 29 41
1
end_operator
begin_operator
board car5 loc37
1
65 30
2
0 0 0 45
0 16 30 41
1
end_operator
begin_operator
board car5 loc38
1
65 31
2
0 0 0 45
0 16 31 41
1
end_operator
begin_operator
board car5 loc39
1
65 32
2
0 0 0 45
0 16 32 41
1
end_operator
begin_operator
board car5 loc4
1
65 33
2
0 0 0 45
0 16 33 41
1
end_operator
begin_operator
board car5 loc40
1
65 34
2
0 0 0 45
0 16 34 41
1
end_operator
begin_operator
board car5 loc41
1
65 35
2
0 0 0 45
0 16 35 41
1
end_operator
begin_operator
board car5 loc5
1
65 36
2
0 0 0 45
0 16 36 41
1
end_operator
begin_operator
board car5 loc6
1
65 37
2
0 0 0 45
0 16 37 41
1
end_operator
begin_operator
board car5 loc7
1
65 38
2
0 0 0 45
0 16 38 41
1
end_operator
begin_operator
board car5 loc8
1
65 39
2
0 0 0 45
0 16 39 41
1
end_operator
begin_operator
board car5 loc9
1
65 40
2
0 0 0 45
0 16 40 41
1
end_operator
begin_operator
board car50 loc1
1
65 0
2
0 0 0 46
0 28 0 41
1
end_operator
begin_operator
board car50 loc10
1
65 1
2
0 0 0 46
0 28 1 41
1
end_operator
begin_operator
board car50 loc11
1
65 2
2
0 0 0 46
0 28 2 41
1
end_operator
begin_operator
board car50 loc12
1
65 3
2
0 0 0 46
0 28 3 41
1
end_operator
begin_operator
board car50 loc13
1
65 4
2
0 0 0 46
0 28 4 41
1
end_operator
begin_operator
board car50 loc14
1
65 5
2
0 0 0 46
0 28 5 41
1
end_operator
begin_operator
board car50 loc15
1
65 6
2
0 0 0 46
0 28 6 41
1
end_operator
begin_operator
board car50 loc16
1
65 7
2
0 0 0 46
0 28 7 41
1
end_operator
begin_operator
board car50 loc17
1
65 8
2
0 0 0 46
0 28 8 41
1
end_operator
begin_operator
board car50 loc18
1
65 9
2
0 0 0 46
0 28 9 41
1
end_operator
begin_operator
board car50 loc19
1
65 10
2
0 0 0 46
0 28 10 41
1
end_operator
begin_operator
board car50 loc2
1
65 11
2
0 0 0 46
0 28 11 41
1
end_operator
begin_operator
board car50 loc20
1
65 12
2
0 0 0 46
0 28 12 41
1
end_operator
begin_operator
board car50 loc21
1
65 13
2
0 0 0 46
0 28 13 41
1
end_operator
begin_operator
board car50 loc22
1
65 14
2
0 0 0 46
0 28 14 41
1
end_operator
begin_operator
board car50 loc23
1
65 15
2
0 0 0 46
0 28 15 41
1
end_operator
begin_operator
board car50 loc24
1
65 16
2
0 0 0 46
0 28 16 41
1
end_operator
begin_operator
board car50 loc25
1
65 17
2
0 0 0 46
0 28 17 41
1
end_operator
begin_operator
board car50 loc26
1
65 18
2
0 0 0 46
0 28 18 41
1
end_operator
begin_operator
board car50 loc27
1
65 19
2
0 0 0 46
0 28 19 41
1
end_operator
begin_operator
board car50 loc28
1
65 20
2
0 0 0 46
0 28 20 41
1
end_operator
begin_operator
board car50 loc29
1
65 21
2
0 0 0 46
0 28 21 41
1
end_operator
begin_operator
board car50 loc3
1
65 22
2
0 0 0 46
0 28 22 41
1
end_operator
begin_operator
board car50 loc30
1
65 23
2
0 0 0 46
0 28 23 41
1
end_operator
begin_operator
board car50 loc31
1
65 24
2
0 0 0 46
0 28 24 41
1
end_operator
begin_operator
board car50 loc32
1
65 25
2
0 0 0 46
0 28 25 41
1
end_operator
begin_operator
board car50 loc33
1
65 26
2
0 0 0 46
0 28 26 41
1
end_operator
begin_operator
board car50 loc34
1
65 27
2
0 0 0 46
0 28 27 41
1
end_operator
begin_operator
board car50 loc35
1
65 28
2
0 0 0 46
0 28 28 41
1
end_operator
begin_operator
board car50 loc36
1
65 29
2
0 0 0 46
0 28 29 41
1
end_operator
begin_operator
board car50 loc37
1
65 30
2
0 0 0 46
0 28 30 41
1
end_operator
begin_operator
board car50 loc38
1
65 31
2
0 0 0 46
0 28 31 41
1
end_operator
begin_operator
board car50 loc39
1
65 32
2
0 0 0 46
0 28 32 41
1
end_operator
begin_operator
board car50 loc4
1
65 33
2
0 0 0 46
0 28 33 41
1
end_operator
begin_operator
board car50 loc40
1
65 34
2
0 0 0 46
0 28 34 41
1
end_operator
begin_operator
board car50 loc41
1
65 35
2
0 0 0 46
0 28 35 41
1
end_operator
begin_operator
board car50 loc5
1
65 36
2
0 0 0 46
0 28 36 41
1
end_operator
begin_operator
board car50 loc6
1
65 37
2
0 0 0 46
0 28 37 41
1
end_operator
begin_operator
board car50 loc7
1
65 38
2
0 0 0 46
0 28 38 41
1
end_operator
begin_operator
board car50 loc8
1
65 39
2
0 0 0 46
0 28 39 41
1
end_operator
begin_operator
board car50 loc9
1
65 40
2
0 0 0 46
0 28 40 41
1
end_operator
begin_operator
board car51 loc1
1
65 0
2
0 0 0 47
0 40 0 41
1
end_operator
begin_operator
board car51 loc10
1
65 1
2
0 0 0 47
0 40 1 41
1
end_operator
begin_operator
board car51 loc11
1
65 2
2
0 0 0 47
0 40 2 41
1
end_operator
begin_operator
board car51 loc12
1
65 3
2
0 0 0 47
0 40 3 41
1
end_operator
begin_operator
board car51 loc13
1
65 4
2
0 0 0 47
0 40 4 41
1
end_operator
begin_operator
board car51 loc14
1
65 5
2
0 0 0 47
0 40 5 41
1
end_operator
begin_operator
board car51 loc15
1
65 6
2
0 0 0 47
0 40 6 41
1
end_operator
begin_operator
board car51 loc16
1
65 7
2
0 0 0 47
0 40 7 41
1
end_operator
begin_operator
board car51 loc17
1
65 8
2
0 0 0 47
0 40 8 41
1
end_operator
begin_operator
board car51 loc18
1
65 9
2
0 0 0 47
0 40 9 41
1
end_operator
begin_operator
board car51 loc19
1
65 10
2
0 0 0 47
0 40 10 41
1
end_operator
begin_operator
board car51 loc2
1
65 11
2
0 0 0 47
0 40 11 41
1
end_operator
begin_operator
board car51 loc20
1
65 12
2
0 0 0 47
0 40 12 41
1
end_operator
begin_operator
board car51 loc21
1
65 13
2
0 0 0 47
0 40 13 41
1
end_operator
begin_operator
board car51 loc22
1
65 14
2
0 0 0 47
0 40 14 41
1
end_operator
begin_operator
board car51 loc23
1
65 15
2
0 0 0 47
0 40 15 41
1
end_operator
begin_operator
board car51 loc24
1
65 16
2
0 0 0 47
0 40 16 41
1
end_operator
begin_operator
board car51 loc25
1
65 17
2
0 0 0 47
0 40 17 41
1
end_operator
begin_operator
board car51 loc26
1
65 18
2
0 0 0 47
0 40 18 41
1
end_operator
begin_operator
board car51 loc27
1
65 19
2
0 0 0 47
0 40 19 41
1
end_operator
begin_operator
board car51 loc28
1
65 20
2
0 0 0 47
0 40 20 41
1
end_operator
begin_operator
board car51 loc29
1
65 21
2
0 0 0 47
0 40 21 41
1
end_operator
begin_operator
board car51 loc3
1
65 22
2
0 0 0 47
0 40 22 41
1
end_operator
begin_operator
board car51 loc30
1
65 23
2
0 0 0 47
0 40 23 41
1
end_operator
begin_operator
board car51 loc31
1
65 24
2
0 0 0 47
0 40 24 41
1
end_operator
begin_operator
board car51 loc32
1
65 25
2
0 0 0 47
0 40 25 41
1
end_operator
begin_operator
board car51 loc33
1
65 26
2
0 0 0 47
0 40 26 41
1
end_operator
begin_operator
board car51 loc34
1
65 27
2
0 0 0 47
0 40 27 41
1
end_operator
begin_operator
board car51 loc35
1
65 28
2
0 0 0 47
0 40 28 41
1
end_operator
begin_operator
board car51 loc36
1
65 29
2
0 0 0 47
0 40 29 41
1
end_operator
begin_operator
board car51 loc37
1
65 30
2
0 0 0 47
0 40 30 41
1
end_operator
begin_operator
board car51 loc38
1
65 31
2
0 0 0 47
0 40 31 41
1
end_operator
begin_operator
board car51 loc39
1
65 32
2
0 0 0 47
0 40 32 41
1
end_operator
begin_operator
board car51 loc4
1
65 33
2
0 0 0 47
0 40 33 41
1
end_operator
begin_operator
board car51 loc40
1
65 34
2
0 0 0 47
0 40 34 41
1
end_operator
begin_operator
board car51 loc41
1
65 35
2
0 0 0 47
0 40 35 41
1
end_operator
begin_operator
board car51 loc5
1
65 36
2
0 0 0 47
0 40 36 41
1
end_operator
begin_operator
board car51 loc6
1
65 37
2
0 0 0 47
0 40 37 41
1
end_operator
begin_operator
board car51 loc7
1
65 38
2
0 0 0 47
0 40 38 41
1
end_operator
begin_operator
board car51 loc8
1
65 39
2
0 0 0 47
0 40 39 41
1
end_operator
begin_operator
board car51 loc9
1
65 40
2
0 0 0 47
0 40 40 41
1
end_operator
begin_operator
board car52 loc1
1
65 0
2
0 0 0 48
0 52 0 41
1
end_operator
begin_operator
board car52 loc10
1
65 1
2
0 0 0 48
0 52 1 41
1
end_operator
begin_operator
board car52 loc11
1
65 2
2
0 0 0 48
0 52 2 41
1
end_operator
begin_operator
board car52 loc12
1
65 3
2
0 0 0 48
0 52 3 41
1
end_operator
begin_operator
board car52 loc13
1
65 4
2
0 0 0 48
0 52 4 41
1
end_operator
begin_operator
board car52 loc14
1
65 5
2
0 0 0 48
0 52 5 41
1
end_operator
begin_operator
board car52 loc15
1
65 6
2
0 0 0 48
0 52 6 41
1
end_operator
begin_operator
board car52 loc16
1
65 7
2
0 0 0 48
0 52 7 41
1
end_operator
begin_operator
board car52 loc17
1
65 8
2
0 0 0 48
0 52 8 41
1
end_operator
begin_operator
board car52 loc18
1
65 9
2
0 0 0 48
0 52 9 41
1
end_operator
begin_operator
board car52 loc19
1
65 10
2
0 0 0 48
0 52 10 41
1
end_operator
begin_operator
board car52 loc2
1
65 11
2
0 0 0 48
0 52 11 41
1
end_operator
begin_operator
board car52 loc20
1
65 12
2
0 0 0 48
0 52 12 41
1
end_operator
begin_operator
board car52 loc21
1
65 13
2
0 0 0 48
0 52 13 41
1
end_operator
begin_operator
board car52 loc22
1
65 14
2
0 0 0 48
0 52 14 41
1
end_operator
begin_operator
board car52 loc23
1
65 15
2
0 0 0 48
0 52 15 41
1
end_operator
begin_operator
board car52 loc24
1
65 16
2
0 0 0 48
0 52 16 41
1
end_operator
begin_operator
board car52 loc25
1
65 17
2
0 0 0 48
0 52 17 41
1
end_operator
begin_operator
board car52 loc26
1
65 18
2
0 0 0 48
0 52 18 41
1
end_operator
begin_operator
board car52 loc27
1
65 19
2
0 0 0 48
0 52 19 41
1
end_operator
begin_operator
board car52 loc28
1
65 20
2
0 0 0 48
0 52 20 41
1
end_operator
begin_operator
board car52 loc29
1
65 21
2
0 0 0 48
0 52 21 41
1
end_operator
begin_operator
board car52 loc3
1
65 22
2
0 0 0 48
0 52 22 41
1
end_operator
begin_operator
board car52 loc30
1
65 23
2
0 0 0 48
0 52 23 41
1
end_operator
begin_operator
board car52 loc31
1
65 24
2
0 0 0 48
0 52 24 41
1
end_operator
begin_operator
board car52 loc32
1
65 25
2
0 0 0 48
0 52 25 41
1
end_operator
begin_operator
board car52 loc33
1
65 26
2
0 0 0 48
0 52 26 41
1
end_operator
begin_operator
board car52 loc34
1
65 27
2
0 0 0 48
0 52 27 41
1
end_operator
begin_operator
board car52 loc35
1
65 28
2
0 0 0 48
0 52 28 41
1
end_operator
begin_operator
board car52 loc36
1
65 29
2
0 0 0 48
0 52 29 41
1
end_operator
begin_operator
board car52 loc37
1
65 30
2
0 0 0 48
0 52 30 41
1
end_operator
begin_operator
board car52 loc38
1
65 31
2
0 0 0 48
0 52 31 41
1
end_operator
begin_operator
board car52 loc39
1
65 32
2
0 0 0 48
0 52 32 41
1
end_operator
begin_operator
board car52 loc4
1
65 33
2
0 0 0 48
0 52 33 41
1
end_operator
begin_operator
board car52 loc40
1
65 34
2
0 0 0 48
0 52 34 41
1
end_operator
begin_operator
board car52 loc41
1
65 35
2
0 0 0 48
0 52 35 41
1
end_operator
begin_operator
board car52 loc5
1
65 36
2
0 0 0 48
0 52 36 41
1
end_operator
begin_operator
board car52 loc6
1
65 37
2
0 0 0 48
0 52 37 41
1
end_operator
begin_operator
board car52 loc7
1
65 38
2
0 0 0 48
0 52 38 41
1
end_operator
begin_operator
board car52 loc8
1
65 39
2
0 0 0 48
0 52 39 41
1
end_operator
begin_operator
board car52 loc9
1
65 40
2
0 0 0 48
0 52 40 41
1
end_operator
begin_operator
board car53 loc1
1
65 0
2
0 0 0 49
0 64 0 41
1
end_operator
begin_operator
board car53 loc10
1
65 1
2
0 0 0 49
0 64 1 41
1
end_operator
begin_operator
board car53 loc11
1
65 2
2
0 0 0 49
0 64 2 41
1
end_operator
begin_operator
board car53 loc12
1
65 3
2
0 0 0 49
0 64 3 41
1
end_operator
begin_operator
board car53 loc13
1
65 4
2
0 0 0 49
0 64 4 41
1
end_operator
begin_operator
board car53 loc14
1
65 5
2
0 0 0 49
0 64 5 41
1
end_operator
begin_operator
board car53 loc15
1
65 6
2
0 0 0 49
0 64 6 41
1
end_operator
begin_operator
board car53 loc16
1
65 7
2
0 0 0 49
0 64 7 41
1
end_operator
begin_operator
board car53 loc17
1
65 8
2
0 0 0 49
0 64 8 41
1
end_operator
begin_operator
board car53 loc18
1
65 9
2
0 0 0 49
0 64 9 41
1
end_operator
begin_operator
board car53 loc19
1
65 10
2
0 0 0 49
0 64 10 41
1
end_operator
begin_operator
board car53 loc2
1
65 11
2
0 0 0 49
0 64 11 41
1
end_operator
begin_operator
board car53 loc20
1
65 12
2
0 0 0 49
0 64 12 41
1
end_operator
begin_operator
board car53 loc21
1
65 13
2
0 0 0 49
0 64 13 41
1
end_operator
begin_operator
board car53 loc22
1
65 14
2
0 0 0 49
0 64 14 41
1
end_operator
begin_operator
board car53 loc23
1
65 15
2
0 0 0 49
0 64 15 41
1
end_operator
begin_operator
board car53 loc24
1
65 16
2
0 0 0 49
0 64 16 41
1
end_operator
begin_operator
board car53 loc25
1
65 17
2
0 0 0 49
0 64 17 41
1
end_operator
begin_operator
board car53 loc26
1
65 18
2
0 0 0 49
0 64 18 41
1
end_operator
begin_operator
board car53 loc27
1
65 19
2
0 0 0 49
0 64 19 41
1
end_operator
begin_operator
board car53 loc28
1
65 20
2
0 0 0 49
0 64 20 41
1
end_operator
begin_operator
board car53 loc29
1
65 21
2
0 0 0 49
0 64 21 41
1
end_operator
begin_operator
board car53 loc3
1
65 22
2
0 0 0 49
0 64 22 41
1
end_operator
begin_operator
board car53 loc30
1
65 23
2
0 0 0 49
0 64 23 41
1
end_operator
begin_operator
board car53 loc31
1
65 24
2
0 0 0 49
0 64 24 41
1
end_operator
begin_operator
board car53 loc32
1
65 25
2
0 0 0 49
0 64 25 41
1
end_operator
begin_operator
board car53 loc33
1
65 26
2
0 0 0 49
0 64 26 41
1
end_operator
begin_operator
board car53 loc34
1
65 27
2
0 0 0 49
0 64 27 41
1
end_operator
begin_operator
board car53 loc35
1
65 28
2
0 0 0 49
0 64 28 41
1
end_operator
begin_operator
board car53 loc36
1
65 29
2
0 0 0 49
0 64 29 41
1
end_operator
begin_operator
board car53 loc37
1
65 30
2
0 0 0 49
0 64 30 41
1
end_operator
begin_operator
board car53 loc38
1
65 31
2
0 0 0 49
0 64 31 41
1
end_operator
begin_operator
board car53 loc39
1
65 32
2
0 0 0 49
0 64 32 41
1
end_operator
begin_operator
board car53 loc4
1
65 33
2
0 0 0 49
0 64 33 41
1
end_operator
begin_operator
board car53 loc40
1
65 34
2
0 0 0 49
0 64 34 41
1
end_operator
begin_operator
board car53 loc41
1
65 35
2
0 0 0 49
0 64 35 41
1
end_operator
begin_operator
board car53 loc5
1
65 36
2
0 0 0 49
0 64 36 41
1
end_operator
begin_operator
board car53 loc6
1
65 37
2
0 0 0 49
0 64 37 41
1
end_operator
begin_operator
board car53 loc7
1
65 38
2
0 0 0 49
0 64 38 41
1
end_operator
begin_operator
board car53 loc8
1
65 39
2
0 0 0 49
0 64 39 41
1
end_operator
begin_operator
board car53 loc9
1
65 40
2
0 0 0 49
0 64 40 41
1
end_operator
begin_operator
board car54 loc1
1
65 0
2
0 0 0 50
0 2 0 41
1
end_operator
begin_operator
board car54 loc10
1
65 1
2
0 0 0 50
0 2 1 41
1
end_operator
begin_operator
board car54 loc11
1
65 2
2
0 0 0 50
0 2 2 41
1
end_operator
begin_operator
board car54 loc12
1
65 3
2
0 0 0 50
0 2 3 41
1
end_operator
begin_operator
board car54 loc13
1
65 4
2
0 0 0 50
0 2 4 41
1
end_operator
begin_operator
board car54 loc14
1
65 5
2
0 0 0 50
0 2 5 41
1
end_operator
begin_operator
board car54 loc15
1
65 6
2
0 0 0 50
0 2 6 41
1
end_operator
begin_operator
board car54 loc16
1
65 7
2
0 0 0 50
0 2 7 41
1
end_operator
begin_operator
board car54 loc17
1
65 8
2
0 0 0 50
0 2 8 41
1
end_operator
begin_operator
board car54 loc18
1
65 9
2
0 0 0 50
0 2 9 41
1
end_operator
begin_operator
board car54 loc19
1
65 10
2
0 0 0 50
0 2 10 41
1
end_operator
begin_operator
board car54 loc2
1
65 11
2
0 0 0 50
0 2 11 41
1
end_operator
begin_operator
board car54 loc20
1
65 12
2
0 0 0 50
0 2 12 41
1
end_operator
begin_operator
board car54 loc21
1
65 13
2
0 0 0 50
0 2 13 41
1
end_operator
begin_operator
board car54 loc22
1
65 14
2
0 0 0 50
0 2 14 41
1
end_operator
begin_operator
board car54 loc23
1
65 15
2
0 0 0 50
0 2 15 41
1
end_operator
begin_operator
board car54 loc24
1
65 16
2
0 0 0 50
0 2 16 41
1
end_operator
begin_operator
board car54 loc25
1
65 17
2
0 0 0 50
0 2 17 41
1
end_operator
begin_operator
board car54 loc26
1
65 18
2
0 0 0 50
0 2 18 41
1
end_operator
begin_operator
board car54 loc27
1
65 19
2
0 0 0 50
0 2 19 41
1
end_operator
begin_operator
board car54 loc28
1
65 20
2
0 0 0 50
0 2 20 41
1
end_operator
begin_operator
board car54 loc29
1
65 21
2
0 0 0 50
0 2 21 41
1
end_operator
begin_operator
board car54 loc3
1
65 22
2
0 0 0 50
0 2 22 41
1
end_operator
begin_operator
board car54 loc30
1
65 23
2
0 0 0 50
0 2 23 41
1
end_operator
begin_operator
board car54 loc31
1
65 24
2
0 0 0 50
0 2 24 41
1
end_operator
begin_operator
board car54 loc32
1
65 25
2
0 0 0 50
0 2 25 41
1
end_operator
begin_operator
board car54 loc33
1
65 26
2
0 0 0 50
0 2 26 41
1
end_operator
begin_operator
board car54 loc34
1
65 27
2
0 0 0 50
0 2 27 41
1
end_operator
begin_operator
board car54 loc35
1
65 28
2
0 0 0 50
0 2 28 41
1
end_operator
begin_operator
board car54 loc36
1
65 29
2
0 0 0 50
0 2 29 41
1
end_operator
begin_operator
board car54 loc37
1
65 30
2
0 0 0 50
0 2 30 41
1
end_operator
begin_operator
board car54 loc38
1
65 31
2
0 0 0 50
0 2 31 41
1
end_operator
begin_operator
board car54 loc39
1
65 32
2
0 0 0 50
0 2 32 41
1
end_operator
begin_operator
board car54 loc4
1
65 33
2
0 0 0 50
0 2 33 41
1
end_operator
begin_operator
board car54 loc40
1
65 34
2
0 0 0 50
0 2 34 41
1
end_operator
begin_operator
board car54 loc41
1
65 35
2
0 0 0 50
0 2 35 41
1
end_operator
begin_operator
board car54 loc5
1
65 36
2
0 0 0 50
0 2 36 41
1
end_operator
begin_operator
board car54 loc6
1
65 37
2
0 0 0 50
0 2 37 41
1
end_operator
begin_operator
board car54 loc7
1
65 38
2
0 0 0 50
0 2 38 41
1
end_operator
begin_operator
board car54 loc8
1
65 39
2
0 0 0 50
0 2 39 41
1
end_operator
begin_operator
board car54 loc9
1
65 40
2
0 0 0 50
0 2 40 41
1
end_operator
begin_operator
board car55 loc1
1
65 0
2
0 0 0 51
0 14 0 41
1
end_operator
begin_operator
board car55 loc10
1
65 1
2
0 0 0 51
0 14 1 41
1
end_operator
begin_operator
board car55 loc11
1
65 2
2
0 0 0 51
0 14 2 41
1
end_operator
begin_operator
board car55 loc12
1
65 3
2
0 0 0 51
0 14 3 41
1
end_operator
begin_operator
board car55 loc13
1
65 4
2
0 0 0 51
0 14 4 41
1
end_operator
begin_operator
board car55 loc14
1
65 5
2
0 0 0 51
0 14 5 41
1
end_operator
begin_operator
board car55 loc15
1
65 6
2
0 0 0 51
0 14 6 41
1
end_operator
begin_operator
board car55 loc16
1
65 7
2
0 0 0 51
0 14 7 41
1
end_operator
begin_operator
board car55 loc17
1
65 8
2
0 0 0 51
0 14 8 41
1
end_operator
begin_operator
board car55 loc18
1
65 9
2
0 0 0 51
0 14 9 41
1
end_operator
begin_operator
board car55 loc19
1
65 10
2
0 0 0 51
0 14 10 41
1
end_operator
begin_operator
board car55 loc2
1
65 11
2
0 0 0 51
0 14 11 41
1
end_operator
begin_operator
board car55 loc20
1
65 12
2
0 0 0 51
0 14 12 41
1
end_operator
begin_operator
board car55 loc21
1
65 13
2
0 0 0 51
0 14 13 41
1
end_operator
begin_operator
board car55 loc22
1
65 14
2
0 0 0 51
0 14 14 41
1
end_operator
begin_operator
board car55 loc23
1
65 15
2
0 0 0 51
0 14 15 41
1
end_operator
begin_operator
board car55 loc24
1
65 16
2
0 0 0 51
0 14 16 41
1
end_operator
begin_operator
board car55 loc25
1
65 17
2
0 0 0 51
0 14 17 41
1
end_operator
begin_operator
board car55 loc26
1
65 18
2
0 0 0 51
0 14 18 41
1
end_operator
begin_operator
board car55 loc27
1
65 19
2
0 0 0 51
0 14 19 41
1
end_operator
begin_operator
board car55 loc28
1
65 20
2
0 0 0 51
0 14 20 41
1
end_operator
begin_operator
board car55 loc29
1
65 21
2
0 0 0 51
0 14 21 41
1
end_operator
begin_operator
board car55 loc3
1
65 22
2
0 0 0 51
0 14 22 41
1
end_operator
begin_operator
board car55 loc30
1
65 23
2
0 0 0 51
0 14 23 41
1
end_operator
begin_operator
board car55 loc31
1
65 24
2
0 0 0 51
0 14 24 41
1
end_operator
begin_operator
board car55 loc32
1
65 25
2
0 0 0 51
0 14 25 41
1
end_operator
begin_operator
board car55 loc33
1
65 26
2
0 0 0 51
0 14 26 41
1
end_operator
begin_operator
board car55 loc34
1
65 27
2
0 0 0 51
0 14 27 41
1
end_operator
begin_operator
board car55 loc35
1
65 28
2
0 0 0 51
0 14 28 41
1
end_operator
begin_operator
board car55 loc36
1
65 29
2
0 0 0 51
0 14 29 41
1
end_operator
begin_operator
board car55 loc37
1
65 30
2
0 0 0 51
0 14 30 41
1
end_operator
begin_operator
board car55 loc38
1
65 31
2
0 0 0 51
0 14 31 41
1
end_operator
begin_operator
board car55 loc39
1
65 32
2
0 0 0 51
0 14 32 41
1
end_operator
begin_operator
board car55 loc4
1
65 33
2
0 0 0 51
0 14 33 41
1
end_operator
begin_operator
board car55 loc40
1
65 34
2
0 0 0 51
0 14 34 41
1
end_operator
begin_operator
board car55 loc41
1
65 35
2
0 0 0 51
0 14 35 41
1
end_operator
begin_operator
board car55 loc5
1
65 36
2
0 0 0 51
0 14 36 41
1
end_operator
begin_operator
board car55 loc6
1
65 37
2
0 0 0 51
0 14 37 41
1
end_operator
begin_operator
board car55 loc7
1
65 38
2
0 0 0 51
0 14 38 41
1
end_operator
begin_operator
board car55 loc8
1
65 39
2
0 0 0 51
0 14 39 41
1
end_operator
begin_operator
board car55 loc9
1
65 40
2
0 0 0 51
0 14 40 41
1
end_operator
begin_operator
board car56 loc1
1
65 0
2
0 0 0 52
0 26 0 41
1
end_operator
begin_operator
board car56 loc10
1
65 1
2
0 0 0 52
0 26 1 41
1
end_operator
begin_operator
board car56 loc11
1
65 2
2
0 0 0 52
0 26 2 41
1
end_operator
begin_operator
board car56 loc12
1
65 3
2
0 0 0 52
0 26 3 41
1
end_operator
begin_operator
board car56 loc13
1
65 4
2
0 0 0 52
0 26 4 41
1
end_operator
begin_operator
board car56 loc14
1
65 5
2
0 0 0 52
0 26 5 41
1
end_operator
begin_operator
board car56 loc15
1
65 6
2
0 0 0 52
0 26 6 41
1
end_operator
begin_operator
board car56 loc16
1
65 7
2
0 0 0 52
0 26 7 41
1
end_operator
begin_operator
board car56 loc17
1
65 8
2
0 0 0 52
0 26 8 41
1
end_operator
begin_operator
board car56 loc18
1
65 9
2
0 0 0 52
0 26 9 41
1
end_operator
begin_operator
board car56 loc19
1
65 10
2
0 0 0 52
0 26 10 41
1
end_operator
begin_operator
board car56 loc2
1
65 11
2
0 0 0 52
0 26 11 41
1
end_operator
begin_operator
board car56 loc20
1
65 12
2
0 0 0 52
0 26 12 41
1
end_operator
begin_operator
board car56 loc21
1
65 13
2
0 0 0 52
0 26 13 41
1
end_operator
begin_operator
board car56 loc22
1
65 14
2
0 0 0 52
0 26 14 41
1
end_operator
begin_operator
board car56 loc23
1
65 15
2
0 0 0 52
0 26 15 41
1
end_operator
begin_operator
board car56 loc24
1
65 16
2
0 0 0 52
0 26 16 41
1
end_operator
begin_operator
board car56 loc25
1
65 17
2
0 0 0 52
0 26 17 41
1
end_operator
begin_operator
board car56 loc26
1
65 18
2
0 0 0 52
0 26 18 41
1
end_operator
begin_operator
board car56 loc27
1
65 19
2
0 0 0 52
0 26 19 41
1
end_operator
begin_operator
board car56 loc28
1
65 20
2
0 0 0 52
0 26 20 41
1
end_operator
begin_operator
board car56 loc29
1
65 21
2
0 0 0 52
0 26 21 41
1
end_operator
begin_operator
board car56 loc3
1
65 22
2
0 0 0 52
0 26 22 41
1
end_operator
begin_operator
board car56 loc30
1
65 23
2
0 0 0 52
0 26 23 41
1
end_operator
begin_operator
board car56 loc31
1
65 24
2
0 0 0 52
0 26 24 41
1
end_operator
begin_operator
board car56 loc32
1
65 25
2
0 0 0 52
0 26 25 41
1
end_operator
begin_operator
board car56 loc33
1
65 26
2
0 0 0 52
0 26 26 41
1
end_operator
begin_operator
board car56 loc34
1
65 27
2
0 0 0 52
0 26 27 41
1
end_operator
begin_operator
board car56 loc35
1
65 28
2
0 0 0 52
0 26 28 41
1
end_operator
begin_operator
board car56 loc36
1
65 29
2
0 0 0 52
0 26 29 41
1
end_operator
begin_operator
board car56 loc37
1
65 30
2
0 0 0 52
0 26 30 41
1
end_operator
begin_operator
board car56 loc38
1
65 31
2
0 0 0 52
0 26 31 41
1
end_operator
begin_operator
board car56 loc39
1
65 32
2
0 0 0 52
0 26 32 41
1
end_operator
begin_operator
board car56 loc4
1
65 33
2
0 0 0 52
0 26 33 41
1
end_operator
begin_operator
board car56 loc40
1
65 34
2
0 0 0 52
0 26 34 41
1
end_operator
begin_operator
board car56 loc41
1
65 35
2
0 0 0 52
0 26 35 41
1
end_operator
begin_operator
board car56 loc5
1
65 36
2
0 0 0 52
0 26 36 41
1
end_operator
begin_operator
board car56 loc6
1
65 37
2
0 0 0 52
0 26 37 41
1
end_operator
begin_operator
board car56 loc7
1
65 38
2
0 0 0 52
0 26 38 41
1
end_operator
begin_operator
board car56 loc8
1
65 39
2
0 0 0 52
0 26 39 41
1
end_operator
begin_operator
board car56 loc9
1
65 40
2
0 0 0 52
0 26 40 41
1
end_operator
begin_operator
board car57 loc1
1
65 0
2
0 0 0 53
0 38 0 41
1
end_operator
begin_operator
board car57 loc10
1
65 1
2
0 0 0 53
0 38 1 41
1
end_operator
begin_operator
board car57 loc11
1
65 2
2
0 0 0 53
0 38 2 41
1
end_operator
begin_operator
board car57 loc12
1
65 3
2
0 0 0 53
0 38 3 41
1
end_operator
begin_operator
board car57 loc13
1
65 4
2
0 0 0 53
0 38 4 41
1
end_operator
begin_operator
board car57 loc14
1
65 5
2
0 0 0 53
0 38 5 41
1
end_operator
begin_operator
board car57 loc15
1
65 6
2
0 0 0 53
0 38 6 41
1
end_operator
begin_operator
board car57 loc16
1
65 7
2
0 0 0 53
0 38 7 41
1
end_operator
begin_operator
board car57 loc17
1
65 8
2
0 0 0 53
0 38 8 41
1
end_operator
begin_operator
board car57 loc18
1
65 9
2
0 0 0 53
0 38 9 41
1
end_operator
begin_operator
board car57 loc19
1
65 10
2
0 0 0 53
0 38 10 41
1
end_operator
begin_operator
board car57 loc2
1
65 11
2
0 0 0 53
0 38 11 41
1
end_operator
begin_operator
board car57 loc20
1
65 12
2
0 0 0 53
0 38 12 41
1
end_operator
begin_operator
board car57 loc21
1
65 13
2
0 0 0 53
0 38 13 41
1
end_operator
begin_operator
board car57 loc22
1
65 14
2
0 0 0 53
0 38 14 41
1
end_operator
begin_operator
board car57 loc23
1
65 15
2
0 0 0 53
0 38 15 41
1
end_operator
begin_operator
board car57 loc24
1
65 16
2
0 0 0 53
0 38 16 41
1
end_operator
begin_operator
board car57 loc25
1
65 17
2
0 0 0 53
0 38 17 41
1
end_operator
begin_operator
board car57 loc26
1
65 18
2
0 0 0 53
0 38 18 41
1
end_operator
begin_operator
board car57 loc27
1
65 19
2
0 0 0 53
0 38 19 41
1
end_operator
begin_operator
board car57 loc28
1
65 20
2
0 0 0 53
0 38 20 41
1
end_operator
begin_operator
board car57 loc29
1
65 21
2
0 0 0 53
0 38 21 41
1
end_operator
begin_operator
board car57 loc3
1
65 22
2
0 0 0 53
0 38 22 41
1
end_operator
begin_operator
board car57 loc30
1
65 23
2
0 0 0 53
0 38 23 41
1
end_operator
begin_operator
board car57 loc31
1
65 24
2
0 0 0 53
0 38 24 41
1
end_operator
begin_operator
board car57 loc32
1
65 25
2
0 0 0 53
0 38 25 41
1
end_operator
begin_operator
board car57 loc33
1
65 26
2
0 0 0 53
0 38 26 41
1
end_operator
begin_operator
board car57 loc34
1
65 27
2
0 0 0 53
0 38 27 41
1
end_operator
begin_operator
board car57 loc35
1
65 28
2
0 0 0 53
0 38 28 41
1
end_operator
begin_operator
board car57 loc36
1
65 29
2
0 0 0 53
0 38 29 41
1
end_operator
begin_operator
board car57 loc37
1
65 30
2
0 0 0 53
0 38 30 41
1
end_operator
begin_operator
board car57 loc38
1
65 31
2
0 0 0 53
0 38 31 41
1
end_operator
begin_operator
board car57 loc39
1
65 32
2
0 0 0 53
0 38 32 41
1
end_operator
begin_operator
board car57 loc4
1
65 33
2
0 0 0 53
0 38 33 41
1
end_operator
begin_operator
board car57 loc40
1
65 34
2
0 0 0 53
0 38 34 41
1
end_operator
begin_operator
board car57 loc41
1
65 35
2
0 0 0 53
0 38 35 41
1
end_operator
begin_operator
board car57 loc5
1
65 36
2
0 0 0 53
0 38 36 41
1
end_operator
begin_operator
board car57 loc6
1
65 37
2
0 0 0 53
0 38 37 41
1
end_operator
begin_operator
board car57 loc7
1
65 38
2
0 0 0 53
0 38 38 41
1
end_operator
begin_operator
board car57 loc8
1
65 39
2
0 0 0 53
0 38 39 41
1
end_operator
begin_operator
board car57 loc9
1
65 40
2
0 0 0 53
0 38 40 41
1
end_operator
begin_operator
board car58 loc1
1
65 0
2
0 0 0 54
0 50 0 41
1
end_operator
begin_operator
board car58 loc10
1
65 1
2
0 0 0 54
0 50 1 41
1
end_operator
begin_operator
board car58 loc11
1
65 2
2
0 0 0 54
0 50 2 41
1
end_operator
begin_operator
board car58 loc12
1
65 3
2
0 0 0 54
0 50 3 41
1
end_operator
begin_operator
board car58 loc13
1
65 4
2
0 0 0 54
0 50 4 41
1
end_operator
begin_operator
board car58 loc14
1
65 5
2
0 0 0 54
0 50 5 41
1
end_operator
begin_operator
board car58 loc15
1
65 6
2
0 0 0 54
0 50 6 41
1
end_operator
begin_operator
board car58 loc16
1
65 7
2
0 0 0 54
0 50 7 41
1
end_operator
begin_operator
board car58 loc17
1
65 8
2
0 0 0 54
0 50 8 41
1
end_operator
begin_operator
board car58 loc18
1
65 9
2
0 0 0 54
0 50 9 41
1
end_operator
begin_operator
board car58 loc19
1
65 10
2
0 0 0 54
0 50 10 41
1
end_operator
begin_operator
board car58 loc2
1
65 11
2
0 0 0 54
0 50 11 41
1
end_operator
begin_operator
board car58 loc20
1
65 12
2
0 0 0 54
0 50 12 41
1
end_operator
begin_operator
board car58 loc21
1
65 13
2
0 0 0 54
0 50 13 41
1
end_operator
begin_operator
board car58 loc22
1
65 14
2
0 0 0 54
0 50 14 41
1
end_operator
begin_operator
board car58 loc23
1
65 15
2
0 0 0 54
0 50 15 41
1
end_operator
begin_operator
board car58 loc24
1
65 16
2
0 0 0 54
0 50 16 41
1
end_operator
begin_operator
board car58 loc25
1
65 17
2
0 0 0 54
0 50 17 41
1
end_operator
begin_operator
board car58 loc26
1
65 18
2
0 0 0 54
0 50 18 41
1
end_operator
begin_operator
board car58 loc27
1
65 19
2
0 0 0 54
0 50 19 41
1
end_operator
begin_operator
board car58 loc28
1
65 20
2
0 0 0 54
0 50 20 41
1
end_operator
begin_operator
board car58 loc29
1
65 21
2
0 0 0 54
0 50 21 41
1
end_operator
begin_operator
board car58 loc3
1
65 22
2
0 0 0 54
0 50 22 41
1
end_operator
begin_operator
board car58 loc30
1
65 23
2
0 0 0 54
0 50 23 41
1
end_operator
begin_operator
board car58 loc31
1
65 24
2
0 0 0 54
0 50 24 41
1
end_operator
begin_operator
board car58 loc32
1
65 25
2
0 0 0 54
0 50 25 41
1
end_operator
begin_operator
board car58 loc33
1
65 26
2
0 0 0 54
0 50 26 41
1
end_operator
begin_operator
board car58 loc34
1
65 27
2
0 0 0 54
0 50 27 41
1
end_operator
begin_operator
board car58 loc35
1
65 28
2
0 0 0 54
0 50 28 41
1
end_operator
begin_operator
board car58 loc36
1
65 29
2
0 0 0 54
0 50 29 41
1
end_operator
begin_operator
board car58 loc37
1
65 30
2
0 0 0 54
0 50 30 41
1
end_operator
begin_operator
board car58 loc38
1
65 31
2
0 0 0 54
0 50 31 41
1
end_operator
begin_operator
board car58 loc39
1
65 32
2
0 0 0 54
0 50 32 41
1
end_operator
begin_operator
board car58 loc4
1
65 33
2
0 0 0 54
0 50 33 41
1
end_operator
begin_operator
board car58 loc40
1
65 34
2
0 0 0 54
0 50 34 41
1
end_operator
begin_operator
board car58 loc41
1
65 35
2
0 0 0 54
0 50 35 41
1
end_operator
begin_operator
board car58 loc5
1
65 36
2
0 0 0 54
0 50 36 41
1
end_operator
begin_operator
board car58 loc6
1
65 37
2
0 0 0 54
0 50 37 41
1
end_operator
begin_operator
board car58 loc7
1
65 38
2
0 0 0 54
0 50 38 41
1
end_operator
begin_operator
board car58 loc8
1
65 39
2
0 0 0 54
0 50 39 41
1
end_operator
begin_operator
board car58 loc9
1
65 40
2
0 0 0 54
0 50 40 41
1
end_operator
begin_operator
board car59 loc1
1
65 0
2
0 0 0 55
0 62 0 41
1
end_operator
begin_operator
board car59 loc10
1
65 1
2
0 0 0 55
0 62 1 41
1
end_operator
begin_operator
board car59 loc11
1
65 2
2
0 0 0 55
0 62 2 41
1
end_operator
begin_operator
board car59 loc12
1
65 3
2
0 0 0 55
0 62 3 41
1
end_operator
begin_operator
board car59 loc13
1
65 4
2
0 0 0 55
0 62 4 41
1
end_operator
begin_operator
board car59 loc14
1
65 5
2
0 0 0 55
0 62 5 41
1
end_operator
begin_operator
board car59 loc15
1
65 6
2
0 0 0 55
0 62 6 41
1
end_operator
begin_operator
board car59 loc16
1
65 7
2
0 0 0 55
0 62 7 41
1
end_operator
begin_operator
board car59 loc17
1
65 8
2
0 0 0 55
0 62 8 41
1
end_operator
begin_operator
board car59 loc18
1
65 9
2
0 0 0 55
0 62 9 41
1
end_operator
begin_operator
board car59 loc19
1
65 10
2
0 0 0 55
0 62 10 41
1
end_operator
begin_operator
board car59 loc2
1
65 11
2
0 0 0 55
0 62 11 41
1
end_operator
begin_operator
board car59 loc20
1
65 12
2
0 0 0 55
0 62 12 41
1
end_operator
begin_operator
board car59 loc21
1
65 13
2
0 0 0 55
0 62 13 41
1
end_operator
begin_operator
board car59 loc22
1
65 14
2
0 0 0 55
0 62 14 41
1
end_operator
begin_operator
board car59 loc23
1
65 15
2
0 0 0 55
0 62 15 41
1
end_operator
begin_operator
board car59 loc24
1
65 16
2
0 0 0 55
0 62 16 41
1
end_operator
begin_operator
board car59 loc25
1
65 17
2
0 0 0 55
0 62 17 41
1
end_operator
begin_operator
board car59 loc26
1
65 18
2
0 0 0 55
0 62 18 41
1
end_operator
begin_operator
board car59 loc27
1
65 19
2
0 0 0 55
0 62 19 41
1
end_operator
begin_operator
board car59 loc28
1
65 20
2
0 0 0 55
0 62 20 41
1
end_operator
begin_operator
board car59 loc29
1
65 21
2
0 0 0 55
0 62 21 41
1
end_operator
begin_operator
board car59 loc3
1
65 22
2
0 0 0 55
0 62 22 41
1
end_operator
begin_operator
board car59 loc30
1
65 23
2
0 0 0 55
0 62 23 41
1
end_operator
begin_operator
board car59 loc31
1
65 24
2
0 0 0 55
0 62 24 41
1
end_operator
begin_operator
board car59 loc32
1
65 25
2
0 0 0 55
0 62 25 41
1
end_operator
begin_operator
board car59 loc33
1
65 26
2
0 0 0 55
0 62 26 41
1
end_operator
begin_operator
board car59 loc34
1
65 27
2
0 0 0 55
0 62 27 41
1
end_operator
begin_operator
board car59 loc35
1
65 28
2
0 0 0 55
0 62 28 41
1
end_operator
begin_operator
board car59 loc36
1
65 29
2
0 0 0 55
0 62 29 41
1
end_operator
begin_operator
board car59 loc37
1
65 30
2
0 0 0 55
0 62 30 41
1
end_operator
begin_operator
board car59 loc38
1
65 31
2
0 0 0 55
0 62 31 41
1
end_operator
begin_operator
board car59 loc39
1
65 32
2
0 0 0 55
0 62 32 41
1
end_operator
begin_operator
board car59 loc4
1
65 33
2
0 0 0 55
0 62 33 41
1
end_operator
begin_operator
board car59 loc40
1
65 34
2
0 0 0 55
0 62 34 41
1
end_operator
begin_operator
board car59 loc41
1
65 35
2
0 0 0 55
0 62 35 41
1
end_operator
begin_operator
board car59 loc5
1
65 36
2
0 0 0 55
0 62 36 41
1
end_operator
begin_operator
board car59 loc6
1
65 37
2
0 0 0 55
0 62 37 41
1
end_operator
begin_operator
board car59 loc7
1
65 38
2
0 0 0 55
0 62 38 41
1
end_operator
begin_operator
board car59 loc8
1
65 39
2
0 0 0 55
0 62 39 41
1
end_operator
begin_operator
board car59 loc9
1
65 40
2
0 0 0 55
0 62 40 41
1
end_operator
begin_operator
board car6 loc1
1
65 0
2
0 0 0 56
0 74 0 41
1
end_operator
begin_operator
board car6 loc10
1
65 1
2
0 0 0 56
0 74 1 41
1
end_operator
begin_operator
board car6 loc11
1
65 2
2
0 0 0 56
0 74 2 41
1
end_operator
begin_operator
board car6 loc12
1
65 3
2
0 0 0 56
0 74 3 41
1
end_operator
begin_operator
board car6 loc13
1
65 4
2
0 0 0 56
0 74 4 41
1
end_operator
begin_operator
board car6 loc14
1
65 5
2
0 0 0 56
0 74 5 41
1
end_operator
begin_operator
board car6 loc15
1
65 6
2
0 0 0 56
0 74 6 41
1
end_operator
begin_operator
board car6 loc16
1
65 7
2
0 0 0 56
0 74 7 41
1
end_operator
begin_operator
board car6 loc17
1
65 8
2
0 0 0 56
0 74 8 41
1
end_operator
begin_operator
board car6 loc18
1
65 9
2
0 0 0 56
0 74 9 41
1
end_operator
begin_operator
board car6 loc19
1
65 10
2
0 0 0 56
0 74 10 41
1
end_operator
begin_operator
board car6 loc2
1
65 11
2
0 0 0 56
0 74 11 41
1
end_operator
begin_operator
board car6 loc20
1
65 12
2
0 0 0 56
0 74 12 41
1
end_operator
begin_operator
board car6 loc21
1
65 13
2
0 0 0 56
0 74 13 41
1
end_operator
begin_operator
board car6 loc22
1
65 14
2
0 0 0 56
0 74 14 41
1
end_operator
begin_operator
board car6 loc23
1
65 15
2
0 0 0 56
0 74 15 41
1
end_operator
begin_operator
board car6 loc24
1
65 16
2
0 0 0 56
0 74 16 41
1
end_operator
begin_operator
board car6 loc25
1
65 17
2
0 0 0 56
0 74 17 41
1
end_operator
begin_operator
board car6 loc26
1
65 18
2
0 0 0 56
0 74 18 41
1
end_operator
begin_operator
board car6 loc27
1
65 19
2
0 0 0 56
0 74 19 41
1
end_operator
begin_operator
board car6 loc28
1
65 20
2
0 0 0 56
0 74 20 41
1
end_operator
begin_operator
board car6 loc29
1
65 21
2
0 0 0 56
0 74 21 41
1
end_operator
begin_operator
board car6 loc3
1
65 22
2
0 0 0 56
0 74 22 41
1
end_operator
begin_operator
board car6 loc30
1
65 23
2
0 0 0 56
0 74 23 41
1
end_operator
begin_operator
board car6 loc31
1
65 24
2
0 0 0 56
0 74 24 41
1
end_operator
begin_operator
board car6 loc32
1
65 25
2
0 0 0 56
0 74 25 41
1
end_operator
begin_operator
board car6 loc33
1
65 26
2
0 0 0 56
0 74 26 41
1
end_operator
begin_operator
board car6 loc34
1
65 27
2
0 0 0 56
0 74 27 41
1
end_operator
begin_operator
board car6 loc35
1
65 28
2
0 0 0 56
0 74 28 41
1
end_operator
begin_operator
board car6 loc36
1
65 29
2
0 0 0 56
0 74 29 41
1
end_operator
begin_operator
board car6 loc37
1
65 30
2
0 0 0 56
0 74 30 41
1
end_operator
begin_operator
board car6 loc38
1
65 31
2
0 0 0 56
0 74 31 41
1
end_operator
begin_operator
board car6 loc39
1
65 32
2
0 0 0 56
0 74 32 41
1
end_operator
begin_operator
board car6 loc4
1
65 33
2
0 0 0 56
0 74 33 41
1
end_operator
begin_operator
board car6 loc40
1
65 34
2
0 0 0 56
0 74 34 41
1
end_operator
begin_operator
board car6 loc41
1
65 35
2
0 0 0 56
0 74 35 41
1
end_operator
begin_operator
board car6 loc5
1
65 36
2
0 0 0 56
0 74 36 41
1
end_operator
begin_operator
board car6 loc6
1
65 37
2
0 0 0 56
0 74 37 41
1
end_operator
begin_operator
board car6 loc7
1
65 38
2
0 0 0 56
0 74 38 41
1
end_operator
begin_operator
board car6 loc8
1
65 39
2
0 0 0 56
0 74 39 41
1
end_operator
begin_operator
board car6 loc9
1
65 40
2
0 0 0 56
0 74 40 41
1
end_operator
begin_operator
board car60 loc1
1
65 0
2
0 0 0 57
0 11 0 41
1
end_operator
begin_operator
board car60 loc10
1
65 1
2
0 0 0 57
0 11 1 41
1
end_operator
begin_operator
board car60 loc11
1
65 2
2
0 0 0 57
0 11 2 41
1
end_operator
begin_operator
board car60 loc12
1
65 3
2
0 0 0 57
0 11 3 41
1
end_operator
begin_operator
board car60 loc13
1
65 4
2
0 0 0 57
0 11 4 41
1
end_operator
begin_operator
board car60 loc14
1
65 5
2
0 0 0 57
0 11 5 41
1
end_operator
begin_operator
board car60 loc15
1
65 6
2
0 0 0 57
0 11 6 41
1
end_operator
begin_operator
board car60 loc16
1
65 7
2
0 0 0 57
0 11 7 41
1
end_operator
begin_operator
board car60 loc17
1
65 8
2
0 0 0 57
0 11 8 41
1
end_operator
begin_operator
board car60 loc18
1
65 9
2
0 0 0 57
0 11 9 41
1
end_operator
begin_operator
board car60 loc19
1
65 10
2
0 0 0 57
0 11 10 41
1
end_operator
begin_operator
board car60 loc2
1
65 11
2
0 0 0 57
0 11 11 41
1
end_operator
begin_operator
board car60 loc20
1
65 12
2
0 0 0 57
0 11 12 41
1
end_operator
begin_operator
board car60 loc21
1
65 13
2
0 0 0 57
0 11 13 41
1
end_operator
begin_operator
board car60 loc22
1
65 14
2
0 0 0 57
0 11 14 41
1
end_operator
begin_operator
board car60 loc23
1
65 15
2
0 0 0 57
0 11 15 41
1
end_operator
begin_operator
board car60 loc24
1
65 16
2
0 0 0 57
0 11 16 41
1
end_operator
begin_operator
board car60 loc25
1
65 17
2
0 0 0 57
0 11 17 41
1
end_operator
begin_operator
board car60 loc26
1
65 18
2
0 0 0 57
0 11 18 41
1
end_operator
begin_operator
board car60 loc27
1
65 19
2
0 0 0 57
0 11 19 41
1
end_operator
begin_operator
board car60 loc28
1
65 20
2
0 0 0 57
0 11 20 41
1
end_operator
begin_operator
board car60 loc29
1
65 21
2
0 0 0 57
0 11 21 41
1
end_operator
begin_operator
board car60 loc3
1
65 22
2
0 0 0 57
0 11 22 41
1
end_operator
begin_operator
board car60 loc30
1
65 23
2
0 0 0 57
0 11 23 41
1
end_operator
begin_operator
board car60 loc31
1
65 24
2
0 0 0 57
0 11 24 41
1
end_operator
begin_operator
board car60 loc32
1
65 25
2
0 0 0 57
0 11 25 41
1
end_operator
begin_operator
board car60 loc33
1
65 26
2
0 0 0 57
0 11 26 41
1
end_operator
begin_operator
board car60 loc34
1
65 27
2
0 0 0 57
0 11 27 41
1
end_operator
begin_operator
board car60 loc35
1
65 28
2
0 0 0 57
0 11 28 41
1
end_operator
begin_operator
board car60 loc36
1
65 29
2
0 0 0 57
0 11 29 41
1
end_operator
begin_operator
board car60 loc37
1
65 30
2
0 0 0 57
0 11 30 41
1
end_operator
begin_operator
board car60 loc38
1
65 31
2
0 0 0 57
0 11 31 41
1
end_operator
begin_operator
board car60 loc39
1
65 32
2
0 0 0 57
0 11 32 41
1
end_operator
begin_operator
board car60 loc4
1
65 33
2
0 0 0 57
0 11 33 41
1
end_operator
begin_operator
board car60 loc40
1
65 34
2
0 0 0 57
0 11 34 41
1
end_operator
begin_operator
board car60 loc41
1
65 35
2
0 0 0 57
0 11 35 41
1
end_operator
begin_operator
board car60 loc5
1
65 36
2
0 0 0 57
0 11 36 41
1
end_operator
begin_operator
board car60 loc6
1
65 37
2
0 0 0 57
0 11 37 41
1
end_operator
begin_operator
board car60 loc7
1
65 38
2
0 0 0 57
0 11 38 41
1
end_operator
begin_operator
board car60 loc8
1
65 39
2
0 0 0 57
0 11 39 41
1
end_operator
begin_operator
board car60 loc9
1
65 40
2
0 0 0 57
0 11 40 41
1
end_operator
begin_operator
board car61 loc1
1
65 0
2
0 0 0 58
0 23 0 41
1
end_operator
begin_operator
board car61 loc10
1
65 1
2
0 0 0 58
0 23 1 41
1
end_operator
begin_operator
board car61 loc11
1
65 2
2
0 0 0 58
0 23 2 41
1
end_operator
begin_operator
board car61 loc12
1
65 3
2
0 0 0 58
0 23 3 41
1
end_operator
begin_operator
board car61 loc13
1
65 4
2
0 0 0 58
0 23 4 41
1
end_operator
begin_operator
board car61 loc14
1
65 5
2
0 0 0 58
0 23 5 41
1
end_operator
begin_operator
board car61 loc15
1
65 6
2
0 0 0 58
0 23 6 41
1
end_operator
begin_operator
board car61 loc16
1
65 7
2
0 0 0 58
0 23 7 41
1
end_operator
begin_operator
board car61 loc17
1
65 8
2
0 0 0 58
0 23 8 41
1
end_operator
begin_operator
board car61 loc18
1
65 9
2
0 0 0 58
0 23 9 41
1
end_operator
begin_operator
board car61 loc19
1
65 10
2
0 0 0 58
0 23 10 41
1
end_operator
begin_operator
board car61 loc2
1
65 11
2
0 0 0 58
0 23 11 41
1
end_operator
begin_operator
board car61 loc20
1
65 12
2
0 0 0 58
0 23 12 41
1
end_operator
begin_operator
board car61 loc21
1
65 13
2
0 0 0 58
0 23 13 41
1
end_operator
begin_operator
board car61 loc22
1
65 14
2
0 0 0 58
0 23 14 41
1
end_operator
begin_operator
board car61 loc23
1
65 15
2
0 0 0 58
0 23 15 41
1
end_operator
begin_operator
board car61 loc24
1
65 16
2
0 0 0 58
0 23 16 41
1
end_operator
begin_operator
board car61 loc25
1
65 17
2
0 0 0 58
0 23 17 41
1
end_operator
begin_operator
board car61 loc26
1
65 18
2
0 0 0 58
0 23 18 41
1
end_operator
begin_operator
board car61 loc27
1
65 19
2
0 0 0 58
0 23 19 41
1
end_operator
begin_operator
board car61 loc28
1
65 20
2
0 0 0 58
0 23 20 41
1
end_operator
begin_operator
board car61 loc29
1
65 21
2
0 0 0 58
0 23 21 41
1
end_operator
begin_operator
board car61 loc3
1
65 22
2
0 0 0 58
0 23 22 41
1
end_operator
begin_operator
board car61 loc30
1
65 23
2
0 0 0 58
0 23 23 41
1
end_operator
begin_operator
board car61 loc31
1
65 24
2
0 0 0 58
0 23 24 41
1
end_operator
begin_operator
board car61 loc32
1
65 25
2
0 0 0 58
0 23 25 41
1
end_operator
begin_operator
board car61 loc33
1
65 26
2
0 0 0 58
0 23 26 41
1
end_operator
begin_operator
board car61 loc34
1
65 27
2
0 0 0 58
0 23 27 41
1
end_operator
begin_operator
board car61 loc35
1
65 28
2
0 0 0 58
0 23 28 41
1
end_operator
begin_operator
board car61 loc36
1
65 29
2
0 0 0 58
0 23 29 41
1
end_operator
begin_operator
board car61 loc37
1
65 30
2
0 0 0 58
0 23 30 41
1
end_operator
begin_operator
board car61 loc38
1
65 31
2
0 0 0 58
0 23 31 41
1
end_operator
begin_operator
board car61 loc39
1
65 32
2
0 0 0 58
0 23 32 41
1
end_operator
begin_operator
board car61 loc4
1
65 33
2
0 0 0 58
0 23 33 41
1
end_operator
begin_operator
board car61 loc40
1
65 34
2
0 0 0 58
0 23 34 41
1
end_operator
begin_operator
board car61 loc41
1
65 35
2
0 0 0 58
0 23 35 41
1
end_operator
begin_operator
board car61 loc5
1
65 36
2
0 0 0 58
0 23 36 41
1
end_operator
begin_operator
board car61 loc6
1
65 37
2
0 0 0 58
0 23 37 41
1
end_operator
begin_operator
board car61 loc7
1
65 38
2
0 0 0 58
0 23 38 41
1
end_operator
begin_operator
board car61 loc8
1
65 39
2
0 0 0 58
0 23 39 41
1
end_operator
begin_operator
board car61 loc9
1
65 40
2
0 0 0 58
0 23 40 41
1
end_operator
begin_operator
board car62 loc1
1
65 0
2
0 0 0 59
0 35 0 41
1
end_operator
begin_operator
board car62 loc10
1
65 1
2
0 0 0 59
0 35 1 41
1
end_operator
begin_operator
board car62 loc11
1
65 2
2
0 0 0 59
0 35 2 41
1
end_operator
begin_operator
board car62 loc12
1
65 3
2
0 0 0 59
0 35 3 41
1
end_operator
begin_operator
board car62 loc13
1
65 4
2
0 0 0 59
0 35 4 41
1
end_operator
begin_operator
board car62 loc14
1
65 5
2
0 0 0 59
0 35 5 41
1
end_operator
begin_operator
board car62 loc15
1
65 6
2
0 0 0 59
0 35 6 41
1
end_operator
begin_operator
board car62 loc16
1
65 7
2
0 0 0 59
0 35 7 41
1
end_operator
begin_operator
board car62 loc17
1
65 8
2
0 0 0 59
0 35 8 41
1
end_operator
begin_operator
board car62 loc18
1
65 9
2
0 0 0 59
0 35 9 41
1
end_operator
begin_operator
board car62 loc19
1
65 10
2
0 0 0 59
0 35 10 41
1
end_operator
begin_operator
board car62 loc2
1
65 11
2
0 0 0 59
0 35 11 41
1
end_operator
begin_operator
board car62 loc20
1
65 12
2
0 0 0 59
0 35 12 41
1
end_operator
begin_operator
board car62 loc21
1
65 13
2
0 0 0 59
0 35 13 41
1
end_operator
begin_operator
board car62 loc22
1
65 14
2
0 0 0 59
0 35 14 41
1
end_operator
begin_operator
board car62 loc23
1
65 15
2
0 0 0 59
0 35 15 41
1
end_operator
begin_operator
board car62 loc24
1
65 16
2
0 0 0 59
0 35 16 41
1
end_operator
begin_operator
board car62 loc25
1
65 17
2
0 0 0 59
0 35 17 41
1
end_operator
begin_operator
board car62 loc26
1
65 18
2
0 0 0 59
0 35 18 41
1
end_operator
begin_operator
board car62 loc27
1
65 19
2
0 0 0 59
0 35 19 41
1
end_operator
begin_operator
board car62 loc28
1
65 20
2
0 0 0 59
0 35 20 41
1
end_operator
begin_operator
board car62 loc29
1
65 21
2
0 0 0 59
0 35 21 41
1
end_operator
begin_operator
board car62 loc3
1
65 22
2
0 0 0 59
0 35 22 41
1
end_operator
begin_operator
board car62 loc30
1
65 23
2
0 0 0 59
0 35 23 41
1
end_operator
begin_operator
board car62 loc31
1
65 24
2
0 0 0 59
0 35 24 41
1
end_operator
begin_operator
board car62 loc32
1
65 25
2
0 0 0 59
0 35 25 41
1
end_operator
begin_operator
board car62 loc33
1
65 26
2
0 0 0 59
0 35 26 41
1
end_operator
begin_operator
board car62 loc34
1
65 27
2
0 0 0 59
0 35 27 41
1
end_operator
begin_operator
board car62 loc35
1
65 28
2
0 0 0 59
0 35 28 41
1
end_operator
begin_operator
board car62 loc36
1
65 29
2
0 0 0 59
0 35 29 41
1
end_operator
begin_operator
board car62 loc37
1
65 30
2
0 0 0 59
0 35 30 41
1
end_operator
begin_operator
board car62 loc38
1
65 31
2
0 0 0 59
0 35 31 41
1
end_operator
begin_operator
board car62 loc39
1
65 32
2
0 0 0 59
0 35 32 41
1
end_operator
begin_operator
board car62 loc4
1
65 33
2
0 0 0 59
0 35 33 41
1
end_operator
begin_operator
board car62 loc40
1
65 34
2
0 0 0 59
0 35 34 41
1
end_operator
begin_operator
board car62 loc41
1
65 35
2
0 0 0 59
0 35 35 41
1
end_operator
begin_operator
board car62 loc5
1
65 36
2
0 0 0 59
0 35 36 41
1
end_operator
begin_operator
board car62 loc6
1
65 37
2
0 0 0 59
0 35 37 41
1
end_operator
begin_operator
board car62 loc7
1
65 38
2
0 0 0 59
0 35 38 41
1
end_operator
begin_operator
board car62 loc8
1
65 39
2
0 0 0 59
0 35 39 41
1
end_operator
begin_operator
board car62 loc9
1
65 40
2
0 0 0 59
0 35 40 41
1
end_operator
begin_operator
board car63 loc1
1
65 0
2
0 0 0 60
0 47 0 41
1
end_operator
begin_operator
board car63 loc10
1
65 1
2
0 0 0 60
0 47 1 41
1
end_operator
begin_operator
board car63 loc11
1
65 2
2
0 0 0 60
0 47 2 41
1
end_operator
begin_operator
board car63 loc12
1
65 3
2
0 0 0 60
0 47 3 41
1
end_operator
begin_operator
board car63 loc13
1
65 4
2
0 0 0 60
0 47 4 41
1
end_operator
begin_operator
board car63 loc14
1
65 5
2
0 0 0 60
0 47 5 41
1
end_operator
begin_operator
board car63 loc15
1
65 6
2
0 0 0 60
0 47 6 41
1
end_operator
begin_operator
board car63 loc16
1
65 7
2
0 0 0 60
0 47 7 41
1
end_operator
begin_operator
board car63 loc17
1
65 8
2
0 0 0 60
0 47 8 41
1
end_operator
begin_operator
board car63 loc18
1
65 9
2
0 0 0 60
0 47 9 41
1
end_operator
begin_operator
board car63 loc19
1
65 10
2
0 0 0 60
0 47 10 41
1
end_operator
begin_operator
board car63 loc2
1
65 11
2
0 0 0 60
0 47 11 41
1
end_operator
begin_operator
board car63 loc20
1
65 12
2
0 0 0 60
0 47 12 41
1
end_operator
begin_operator
board car63 loc21
1
65 13
2
0 0 0 60
0 47 13 41
1
end_operator
begin_operator
board car63 loc22
1
65 14
2
0 0 0 60
0 47 14 41
1
end_operator
begin_operator
board car63 loc23
1
65 15
2
0 0 0 60
0 47 15 41
1
end_operator
begin_operator
board car63 loc24
1
65 16
2
0 0 0 60
0 47 16 41
1
end_operator
begin_operator
board car63 loc25
1
65 17
2
0 0 0 60
0 47 17 41
1
end_operator
begin_operator
board car63 loc26
1
65 18
2
0 0 0 60
0 47 18 41
1
end_operator
begin_operator
board car63 loc27
1
65 19
2
0 0 0 60
0 47 19 41
1
end_operator
begin_operator
board car63 loc28
1
65 20
2
0 0 0 60
0 47 20 41
1
end_operator
begin_operator
board car63 loc29
1
65 21
2
0 0 0 60
0 47 21 41
1
end_operator
begin_operator
board car63 loc3
1
65 22
2
0 0 0 60
0 47 22 41
1
end_operator
begin_operator
board car63 loc30
1
65 23
2
0 0 0 60
0 47 23 41
1
end_operator
begin_operator
board car63 loc31
1
65 24
2
0 0 0 60
0 47 24 41
1
end_operator
begin_operator
board car63 loc32
1
65 25
2
0 0 0 60
0 47 25 41
1
end_operator
begin_operator
board car63 loc33
1
65 26
2
0 0 0 60
0 47 26 41
1
end_operator
begin_operator
board car63 loc34
1
65 27
2
0 0 0 60
0 47 27 41
1
end_operator
begin_operator
board car63 loc35
1
65 28
2
0 0 0 60
0 47 28 41
1
end_operator
begin_operator
board car63 loc36
1
65 29
2
0 0 0 60
0 47 29 41
1
end_operator
begin_operator
board car63 loc37
1
65 30
2
0 0 0 60
0 47 30 41
1
end_operator
begin_operator
board car63 loc38
1
65 31
2
0 0 0 60
0 47 31 41
1
end_operator
begin_operator
board car63 loc39
1
65 32
2
0 0 0 60
0 47 32 41
1
end_operator
begin_operator
board car63 loc4
1
65 33
2
0 0 0 60
0 47 33 41
1
end_operator
begin_operator
board car63 loc40
1
65 34
2
0 0 0 60
0 47 34 41
1
end_operator
begin_operator
board car63 loc41
1
65 35
2
0 0 0 60
0 47 35 41
1
end_operator
begin_operator
board car63 loc5
1
65 36
2
0 0 0 60
0 47 36 41
1
end_operator
begin_operator
board car63 loc6
1
65 37
2
0 0 0 60
0 47 37 41
1
end_operator
begin_operator
board car63 loc7
1
65 38
2
0 0 0 60
0 47 38 41
1
end_operator
begin_operator
board car63 loc8
1
65 39
2
0 0 0 60
0 47 39 41
1
end_operator
begin_operator
board car63 loc9
1
65 40
2
0 0 0 60
0 47 40 41
1
end_operator
begin_operator
board car64 loc1
1
65 0
2
0 0 0 61
0 59 0 41
1
end_operator
begin_operator
board car64 loc10
1
65 1
2
0 0 0 61
0 59 1 41
1
end_operator
begin_operator
board car64 loc11
1
65 2
2
0 0 0 61
0 59 2 41
1
end_operator
begin_operator
board car64 loc12
1
65 3
2
0 0 0 61
0 59 3 41
1
end_operator
begin_operator
board car64 loc13
1
65 4
2
0 0 0 61
0 59 4 41
1
end_operator
begin_operator
board car64 loc14
1
65 5
2
0 0 0 61
0 59 5 41
1
end_operator
begin_operator
board car64 loc15
1
65 6
2
0 0 0 61
0 59 6 41
1
end_operator
begin_operator
board car64 loc16
1
65 7
2
0 0 0 61
0 59 7 41
1
end_operator
begin_operator
board car64 loc17
1
65 8
2
0 0 0 61
0 59 8 41
1
end_operator
begin_operator
board car64 loc18
1
65 9
2
0 0 0 61
0 59 9 41
1
end_operator
begin_operator
board car64 loc19
1
65 10
2
0 0 0 61
0 59 10 41
1
end_operator
begin_operator
board car64 loc2
1
65 11
2
0 0 0 61
0 59 11 41
1
end_operator
begin_operator
board car64 loc20
1
65 12
2
0 0 0 61
0 59 12 41
1
end_operator
begin_operator
board car64 loc21
1
65 13
2
0 0 0 61
0 59 13 41
1
end_operator
begin_operator
board car64 loc22
1
65 14
2
0 0 0 61
0 59 14 41
1
end_operator
begin_operator
board car64 loc23
1
65 15
2
0 0 0 61
0 59 15 41
1
end_operator
begin_operator
board car64 loc24
1
65 16
2
0 0 0 61
0 59 16 41
1
end_operator
begin_operator
board car64 loc25
1
65 17
2
0 0 0 61
0 59 17 41
1
end_operator
begin_operator
board car64 loc26
1
65 18
2
0 0 0 61
0 59 18 41
1
end_operator
begin_operator
board car64 loc27
1
65 19
2
0 0 0 61
0 59 19 41
1
end_operator
begin_operator
board car64 loc28
1
65 20
2
0 0 0 61
0 59 20 41
1
end_operator
begin_operator
board car64 loc29
1
65 21
2
0 0 0 61
0 59 21 41
1
end_operator
begin_operator
board car64 loc3
1
65 22
2
0 0 0 61
0 59 22 41
1
end_operator
begin_operator
board car64 loc30
1
65 23
2
0 0 0 61
0 59 23 41
1
end_operator
begin_operator
board car64 loc31
1
65 24
2
0 0 0 61
0 59 24 41
1
end_operator
begin_operator
board car64 loc32
1
65 25
2
0 0 0 61
0 59 25 41
1
end_operator
begin_operator
board car64 loc33
1
65 26
2
0 0 0 61
0 59 26 41
1
end_operator
begin_operator
board car64 loc34
1
65 27
2
0 0 0 61
0 59 27 41
1
end_operator
begin_operator
board car64 loc35
1
65 28
2
0 0 0 61
0 59 28 41
1
end_operator
begin_operator
board car64 loc36
1
65 29
2
0 0 0 61
0 59 29 41
1
end_operator
begin_operator
board car64 loc37
1
65 30
2
0 0 0 61
0 59 30 41
1
end_operator
begin_operator
board car64 loc38
1
65 31
2
0 0 0 61
0 59 31 41
1
end_operator
begin_operator
board car64 loc39
1
65 32
2
0 0 0 61
0 59 32 41
1
end_operator
begin_operator
board car64 loc4
1
65 33
2
0 0 0 61
0 59 33 41
1
end_operator
begin_operator
board car64 loc40
1
65 34
2
0 0 0 61
0 59 34 41
1
end_operator
begin_operator
board car64 loc41
1
65 35
2
0 0 0 61
0 59 35 41
1
end_operator
begin_operator
board car64 loc5
1
65 36
2
0 0 0 61
0 59 36 41
1
end_operator
begin_operator
board car64 loc6
1
65 37
2
0 0 0 61
0 59 37 41
1
end_operator
begin_operator
board car64 loc7
1
65 38
2
0 0 0 61
0 59 38 41
1
end_operator
begin_operator
board car64 loc8
1
65 39
2
0 0 0 61
0 59 39 41
1
end_operator
begin_operator
board car64 loc9
1
65 40
2
0 0 0 61
0 59 40 41
1
end_operator
begin_operator
board car65 loc1
1
65 0
2
0 0 0 62
0 71 0 41
1
end_operator
begin_operator
board car65 loc10
1
65 1
2
0 0 0 62
0 71 1 41
1
end_operator
begin_operator
board car65 loc11
1
65 2
2
0 0 0 62
0 71 2 41
1
end_operator
begin_operator
board car65 loc12
1
65 3
2
0 0 0 62
0 71 3 41
1
end_operator
begin_operator
board car65 loc13
1
65 4
2
0 0 0 62
0 71 4 41
1
end_operator
begin_operator
board car65 loc14
1
65 5
2
0 0 0 62
0 71 5 41
1
end_operator
begin_operator
board car65 loc15
1
65 6
2
0 0 0 62
0 71 6 41
1
end_operator
begin_operator
board car65 loc16
1
65 7
2
0 0 0 62
0 71 7 41
1
end_operator
begin_operator
board car65 loc17
1
65 8
2
0 0 0 62
0 71 8 41
1
end_operator
begin_operator
board car65 loc18
1
65 9
2
0 0 0 62
0 71 9 41
1
end_operator
begin_operator
board car65 loc19
1
65 10
2
0 0 0 62
0 71 10 41
1
end_operator
begin_operator
board car65 loc2
1
65 11
2
0 0 0 62
0 71 11 41
1
end_operator
begin_operator
board car65 loc20
1
65 12
2
0 0 0 62
0 71 12 41
1
end_operator
begin_operator
board car65 loc21
1
65 13
2
0 0 0 62
0 71 13 41
1
end_operator
begin_operator
board car65 loc22
1
65 14
2
0 0 0 62
0 71 14 41
1
end_operator
begin_operator
board car65 loc23
1
65 15
2
0 0 0 62
0 71 15 41
1
end_operator
begin_operator
board car65 loc24
1
65 16
2
0 0 0 62
0 71 16 41
1
end_operator
begin_operator
board car65 loc25
1
65 17
2
0 0 0 62
0 71 17 41
1
end_operator
begin_operator
board car65 loc26
1
65 18
2
0 0 0 62
0 71 18 41
1
end_operator
begin_operator
board car65 loc27
1
65 19
2
0 0 0 62
0 71 19 41
1
end_operator
begin_operator
board car65 loc28
1
65 20
2
0 0 0 62
0 71 20 41
1
end_operator
begin_operator
board car65 loc29
1
65 21
2
0 0 0 62
0 71 21 41
1
end_operator
begin_operator
board car65 loc3
1
65 22
2
0 0 0 62
0 71 22 41
1
end_operator
begin_operator
board car65 loc30
1
65 23
2
0 0 0 62
0 71 23 41
1
end_operator
begin_operator
board car65 loc31
1
65 24
2
0 0 0 62
0 71 24 41
1
end_operator
begin_operator
board car65 loc32
1
65 25
2
0 0 0 62
0 71 25 41
1
end_operator
begin_operator
board car65 loc33
1
65 26
2
0 0 0 62
0 71 26 41
1
end_operator
begin_operator
board car65 loc34
1
65 27
2
0 0 0 62
0 71 27 41
1
end_operator
begin_operator
board car65 loc35
1
65 28
2
0 0 0 62
0 71 28 41
1
end_operator
begin_operator
board car65 loc36
1
65 29
2
0 0 0 62
0 71 29 41
1
end_operator
begin_operator
board car65 loc37
1
65 30
2
0 0 0 62
0 71 30 41
1
end_operator
begin_operator
board car65 loc38
1
65 31
2
0 0 0 62
0 71 31 41
1
end_operator
begin_operator
board car65 loc39
1
65 32
2
0 0 0 62
0 71 32 41
1
end_operator
begin_operator
board car65 loc4
1
65 33
2
0 0 0 62
0 71 33 41
1
end_operator
begin_operator
board car65 loc40
1
65 34
2
0 0 0 62
0 71 34 41
1
end_operator
begin_operator
board car65 loc41
1
65 35
2
0 0 0 62
0 71 35 41
1
end_operator
begin_operator
board car65 loc5
1
65 36
2
0 0 0 62
0 71 36 41
1
end_operator
begin_operator
board car65 loc6
1
65 37
2
0 0 0 62
0 71 37 41
1
end_operator
begin_operator
board car65 loc7
1
65 38
2
0 0 0 62
0 71 38 41
1
end_operator
begin_operator
board car65 loc8
1
65 39
2
0 0 0 62
0 71 39 41
1
end_operator
begin_operator
board car65 loc9
1
65 40
2
0 0 0 62
0 71 40 41
1
end_operator
begin_operator
board car66 loc1
1
65 0
2
0 0 0 63
0 8 0 41
1
end_operator
begin_operator
board car66 loc10
1
65 1
2
0 0 0 63
0 8 1 41
1
end_operator
begin_operator
board car66 loc11
1
65 2
2
0 0 0 63
0 8 2 41
1
end_operator
begin_operator
board car66 loc12
1
65 3
2
0 0 0 63
0 8 3 41
1
end_operator
begin_operator
board car66 loc13
1
65 4
2
0 0 0 63
0 8 4 41
1
end_operator
begin_operator
board car66 loc14
1
65 5
2
0 0 0 63
0 8 5 41
1
end_operator
begin_operator
board car66 loc15
1
65 6
2
0 0 0 63
0 8 6 41
1
end_operator
begin_operator
board car66 loc16
1
65 7
2
0 0 0 63
0 8 7 41
1
end_operator
begin_operator
board car66 loc17
1
65 8
2
0 0 0 63
0 8 8 41
1
end_operator
begin_operator
board car66 loc18
1
65 9
2
0 0 0 63
0 8 9 41
1
end_operator
begin_operator
board car66 loc19
1
65 10
2
0 0 0 63
0 8 10 41
1
end_operator
begin_operator
board car66 loc2
1
65 11
2
0 0 0 63
0 8 11 41
1
end_operator
begin_operator
board car66 loc20
1
65 12
2
0 0 0 63
0 8 12 41
1
end_operator
begin_operator
board car66 loc21
1
65 13
2
0 0 0 63
0 8 13 41
1
end_operator
begin_operator
board car66 loc22
1
65 14
2
0 0 0 63
0 8 14 41
1
end_operator
begin_operator
board car66 loc23
1
65 15
2
0 0 0 63
0 8 15 41
1
end_operator
begin_operator
board car66 loc24
1
65 16
2
0 0 0 63
0 8 16 41
1
end_operator
begin_operator
board car66 loc25
1
65 17
2
0 0 0 63
0 8 17 41
1
end_operator
begin_operator
board car66 loc26
1
65 18
2
0 0 0 63
0 8 18 41
1
end_operator
begin_operator
board car66 loc27
1
65 19
2
0 0 0 63
0 8 19 41
1
end_operator
begin_operator
board car66 loc28
1
65 20
2
0 0 0 63
0 8 20 41
1
end_operator
begin_operator
board car66 loc29
1
65 21
2
0 0 0 63
0 8 21 41
1
end_operator
begin_operator
board car66 loc3
1
65 22
2
0 0 0 63
0 8 22 41
1
end_operator
begin_operator
board car66 loc30
1
65 23
2
0 0 0 63
0 8 23 41
1
end_operator
begin_operator
board car66 loc31
1
65 24
2
0 0 0 63
0 8 24 41
1
end_operator
begin_operator
board car66 loc32
1
65 25
2
0 0 0 63
0 8 25 41
1
end_operator
begin_operator
board car66 loc33
1
65 26
2
0 0 0 63
0 8 26 41
1
end_operator
begin_operator
board car66 loc34
1
65 27
2
0 0 0 63
0 8 27 41
1
end_operator
begin_operator
board car66 loc35
1
65 28
2
0 0 0 63
0 8 28 41
1
end_operator
begin_operator
board car66 loc36
1
65 29
2
0 0 0 63
0 8 29 41
1
end_operator
begin_operator
board car66 loc37
1
65 30
2
0 0 0 63
0 8 30 41
1
end_operator
begin_operator
board car66 loc38
1
65 31
2
0 0 0 63
0 8 31 41
1
end_operator
begin_operator
board car66 loc39
1
65 32
2
0 0 0 63
0 8 32 41
1
end_operator
begin_operator
board car66 loc4
1
65 33
2
0 0 0 63
0 8 33 41
1
end_operator
begin_operator
board car66 loc40
1
65 34
2
0 0 0 63
0 8 34 41
1
end_operator
begin_operator
board car66 loc41
1
65 35
2
0 0 0 63
0 8 35 41
1
end_operator
begin_operator
board car66 loc5
1
65 36
2
0 0 0 63
0 8 36 41
1
end_operator
begin_operator
board car66 loc6
1
65 37
2
0 0 0 63
0 8 37 41
1
end_operator
begin_operator
board car66 loc7
1
65 38
2
0 0 0 63
0 8 38 41
1
end_operator
begin_operator
board car66 loc8
1
65 39
2
0 0 0 63
0 8 39 41
1
end_operator
begin_operator
board car66 loc9
1
65 40
2
0 0 0 63
0 8 40 41
1
end_operator
begin_operator
board car67 loc1
1
65 0
2
0 0 0 64
0 20 0 41
1
end_operator
begin_operator
board car67 loc10
1
65 1
2
0 0 0 64
0 20 1 41
1
end_operator
begin_operator
board car67 loc11
1
65 2
2
0 0 0 64
0 20 2 41
1
end_operator
begin_operator
board car67 loc12
1
65 3
2
0 0 0 64
0 20 3 41
1
end_operator
begin_operator
board car67 loc13
1
65 4
2
0 0 0 64
0 20 4 41
1
end_operator
begin_operator
board car67 loc14
1
65 5
2
0 0 0 64
0 20 5 41
1
end_operator
begin_operator
board car67 loc15
1
65 6
2
0 0 0 64
0 20 6 41
1
end_operator
begin_operator
board car67 loc16
1
65 7
2
0 0 0 64
0 20 7 41
1
end_operator
begin_operator
board car67 loc17
1
65 8
2
0 0 0 64
0 20 8 41
1
end_operator
begin_operator
board car67 loc18
1
65 9
2
0 0 0 64
0 20 9 41
1
end_operator
begin_operator
board car67 loc19
1
65 10
2
0 0 0 64
0 20 10 41
1
end_operator
begin_operator
board car67 loc2
1
65 11
2
0 0 0 64
0 20 11 41
1
end_operator
begin_operator
board car67 loc20
1
65 12
2
0 0 0 64
0 20 12 41
1
end_operator
begin_operator
board car67 loc21
1
65 13
2
0 0 0 64
0 20 13 41
1
end_operator
begin_operator
board car67 loc22
1
65 14
2
0 0 0 64
0 20 14 41
1
end_operator
begin_operator
board car67 loc23
1
65 15
2
0 0 0 64
0 20 15 41
1
end_operator
begin_operator
board car67 loc24
1
65 16
2
0 0 0 64
0 20 16 41
1
end_operator
begin_operator
board car67 loc25
1
65 17
2
0 0 0 64
0 20 17 41
1
end_operator
begin_operator
board car67 loc26
1
65 18
2
0 0 0 64
0 20 18 41
1
end_operator
begin_operator
board car67 loc27
1
65 19
2
0 0 0 64
0 20 19 41
1
end_operator
begin_operator
board car67 loc28
1
65 20
2
0 0 0 64
0 20 20 41
1
end_operator
begin_operator
board car67 loc29
1
65 21
2
0 0 0 64
0 20 21 41
1
end_operator
begin_operator
board car67 loc3
1
65 22
2
0 0 0 64
0 20 22 41
1
end_operator
begin_operator
board car67 loc30
1
65 23
2
0 0 0 64
0 20 23 41
1
end_operator
begin_operator
board car67 loc31
1
65 24
2
0 0 0 64
0 20 24 41
1
end_operator
begin_operator
board car67 loc32
1
65 25
2
0 0 0 64
0 20 25 41
1
end_operator
begin_operator
board car67 loc33
1
65 26
2
0 0 0 64
0 20 26 41
1
end_operator
begin_operator
board car67 loc34
1
65 27
2
0 0 0 64
0 20 27 41
1
end_operator
begin_operator
board car67 loc35
1
65 28
2
0 0 0 64
0 20 28 41
1
end_operator
begin_operator
board car67 loc36
1
65 29
2
0 0 0 64
0 20 29 41
1
end_operator
begin_operator
board car67 loc37
1
65 30
2
0 0 0 64
0 20 30 41
1
end_operator
begin_operator
board car67 loc38
1
65 31
2
0 0 0 64
0 20 31 41
1
end_operator
begin_operator
board car67 loc39
1
65 32
2
0 0 0 64
0 20 32 41
1
end_operator
begin_operator
board car67 loc4
1
65 33
2
0 0 0 64
0 20 33 41
1
end_operator
begin_operator
board car67 loc40
1
65 34
2
0 0 0 64
0 20 34 41
1
end_operator
begin_operator
board car67 loc41
1
65 35
2
0 0 0 64
0 20 35 41
1
end_operator
begin_operator
board car67 loc5
1
65 36
2
0 0 0 64
0 20 36 41
1
end_operator
begin_operator
board car67 loc6
1
65 37
2
0 0 0 64
0 20 37 41
1
end_operator
begin_operator
board car67 loc7
1
65 38
2
0 0 0 64
0 20 38 41
1
end_operator
begin_operator
board car67 loc8
1
65 39
2
0 0 0 64
0 20 39 41
1
end_operator
begin_operator
board car67 loc9
1
65 40
2
0 0 0 64
0 20 40 41
1
end_operator
begin_operator
board car68 loc1
1
65 0
2
0 0 0 65
0 32 0 41
1
end_operator
begin_operator
board car68 loc10
1
65 1
2
0 0 0 65
0 32 1 41
1
end_operator
begin_operator
board car68 loc11
1
65 2
2
0 0 0 65
0 32 2 41
1
end_operator
begin_operator
board car68 loc12
1
65 3
2
0 0 0 65
0 32 3 41
1
end_operator
begin_operator
board car68 loc13
1
65 4
2
0 0 0 65
0 32 4 41
1
end_operator
begin_operator
board car68 loc14
1
65 5
2
0 0 0 65
0 32 5 41
1
end_operator
begin_operator
board car68 loc15
1
65 6
2
0 0 0 65
0 32 6 41
1
end_operator
begin_operator
board car68 loc16
1
65 7
2
0 0 0 65
0 32 7 41
1
end_operator
begin_operator
board car68 loc17
1
65 8
2
0 0 0 65
0 32 8 41
1
end_operator
begin_operator
board car68 loc18
1
65 9
2
0 0 0 65
0 32 9 41
1
end_operator
begin_operator
board car68 loc19
1
65 10
2
0 0 0 65
0 32 10 41
1
end_operator
begin_operator
board car68 loc2
1
65 11
2
0 0 0 65
0 32 11 41
1
end_operator
begin_operator
board car68 loc20
1
65 12
2
0 0 0 65
0 32 12 41
1
end_operator
begin_operator
board car68 loc21
1
65 13
2
0 0 0 65
0 32 13 41
1
end_operator
begin_operator
board car68 loc22
1
65 14
2
0 0 0 65
0 32 14 41
1
end_operator
begin_operator
board car68 loc23
1
65 15
2
0 0 0 65
0 32 15 41
1
end_operator
begin_operator
board car68 loc24
1
65 16
2
0 0 0 65
0 32 16 41
1
end_operator
begin_operator
board car68 loc25
1
65 17
2
0 0 0 65
0 32 17 41
1
end_operator
begin_operator
board car68 loc26
1
65 18
2
0 0 0 65
0 32 18 41
1
end_operator
begin_operator
board car68 loc27
1
65 19
2
0 0 0 65
0 32 19 41
1
end_operator
begin_operator
board car68 loc28
1
65 20
2
0 0 0 65
0 32 20 41
1
end_operator
begin_operator
board car68 loc29
1
65 21
2
0 0 0 65
0 32 21 41
1
end_operator
begin_operator
board car68 loc3
1
65 22
2
0 0 0 65
0 32 22 41
1
end_operator
begin_operator
board car68 loc30
1
65 23
2
0 0 0 65
0 32 23 41
1
end_operator
begin_operator
board car68 loc31
1
65 24
2
0 0 0 65
0 32 24 41
1
end_operator
begin_operator
board car68 loc32
1
65 25
2
0 0 0 65
0 32 25 41
1
end_operator
begin_operator
board car68 loc33
1
65 26
2
0 0 0 65
0 32 26 41
1
end_operator
begin_operator
board car68 loc34
1
65 27
2
0 0 0 65
0 32 27 41
1
end_operator
begin_operator
board car68 loc35
1
65 28
2
0 0 0 65
0 32 28 41
1
end_operator
begin_operator
board car68 loc36
1
65 29
2
0 0 0 65
0 32 29 41
1
end_operator
begin_operator
board car68 loc37
1
65 30
2
0 0 0 65
0 32 30 41
1
end_operator
begin_operator
board car68 loc38
1
65 31
2
0 0 0 65
0 32 31 41
1
end_operator
begin_operator
board car68 loc39
1
65 32
2
0 0 0 65
0 32 32 41
1
end_operator
begin_operator
board car68 loc4
1
65 33
2
0 0 0 65
0 32 33 41
1
end_operator
begin_operator
board car68 loc40
1
65 34
2
0 0 0 65
0 32 34 41
1
end_operator
begin_operator
board car68 loc41
1
65 35
2
0 0 0 65
0 32 35 41
1
end_operator
begin_operator
board car68 loc5
1
65 36
2
0 0 0 65
0 32 36 41
1
end_operator
begin_operator
board car68 loc6
1
65 37
2
0 0 0 65
0 32 37 41
1
end_operator
begin_operator
board car68 loc7
1
65 38
2
0 0 0 65
0 32 38 41
1
end_operator
begin_operator
board car68 loc8
1
65 39
2
0 0 0 65
0 32 39 41
1
end_operator
begin_operator
board car68 loc9
1
65 40
2
0 0 0 65
0 32 40 41
1
end_operator
begin_operator
board car69 loc1
1
65 0
2
0 0 0 66
0 44 0 41
1
end_operator
begin_operator
board car69 loc10
1
65 1
2
0 0 0 66
0 44 1 41
1
end_operator
begin_operator
board car69 loc11
1
65 2
2
0 0 0 66
0 44 2 41
1
end_operator
begin_operator
board car69 loc12
1
65 3
2
0 0 0 66
0 44 3 41
1
end_operator
begin_operator
board car69 loc13
1
65 4
2
0 0 0 66
0 44 4 41
1
end_operator
begin_operator
board car69 loc14
1
65 5
2
0 0 0 66
0 44 5 41
1
end_operator
begin_operator
board car69 loc15
1
65 6
2
0 0 0 66
0 44 6 41
1
end_operator
begin_operator
board car69 loc16
1
65 7
2
0 0 0 66
0 44 7 41
1
end_operator
begin_operator
board car69 loc17
1
65 8
2
0 0 0 66
0 44 8 41
1
end_operator
begin_operator
board car69 loc18
1
65 9
2
0 0 0 66
0 44 9 41
1
end_operator
begin_operator
board car69 loc19
1
65 10
2
0 0 0 66
0 44 10 41
1
end_operator
begin_operator
board car69 loc2
1
65 11
2
0 0 0 66
0 44 11 41
1
end_operator
begin_operator
board car69 loc20
1
65 12
2
0 0 0 66
0 44 12 41
1
end_operator
begin_operator
board car69 loc21
1
65 13
2
0 0 0 66
0 44 13 41
1
end_operator
begin_operator
board car69 loc22
1
65 14
2
0 0 0 66
0 44 14 41
1
end_operator
begin_operator
board car69 loc23
1
65 15
2
0 0 0 66
0 44 15 41
1
end_operator
begin_operator
board car69 loc24
1
65 16
2
0 0 0 66
0 44 16 41
1
end_operator
begin_operator
board car69 loc25
1
65 17
2
0 0 0 66
0 44 17 41
1
end_operator
begin_operator
board car69 loc26
1
65 18
2
0 0 0 66
0 44 18 41
1
end_operator
begin_operator
board car69 loc27
1
65 19
2
0 0 0 66
0 44 19 41
1
end_operator
begin_operator
board car69 loc28
1
65 20
2
0 0 0 66
0 44 20 41
1
end_operator
begin_operator
board car69 loc29
1
65 21
2
0 0 0 66
0 44 21 41
1
end_operator
begin_operator
board car69 loc3
1
65 22
2
0 0 0 66
0 44 22 41
1
end_operator
begin_operator
board car69 loc30
1
65 23
2
0 0 0 66
0 44 23 41
1
end_operator
begin_operator
board car69 loc31
1
65 24
2
0 0 0 66
0 44 24 41
1
end_operator
begin_operator
board car69 loc32
1
65 25
2
0 0 0 66
0 44 25 41
1
end_operator
begin_operator
board car69 loc33
1
65 26
2
0 0 0 66
0 44 26 41
1
end_operator
begin_operator
board car69 loc34
1
65 27
2
0 0 0 66
0 44 27 41
1
end_operator
begin_operator
board car69 loc35
1
65 28
2
0 0 0 66
0 44 28 41
1
end_operator
begin_operator
board car69 loc36
1
65 29
2
0 0 0 66
0 44 29 41
1
end_operator
begin_operator
board car69 loc37
1
65 30
2
0 0 0 66
0 44 30 41
1
end_operator
begin_operator
board car69 loc38
1
65 31
2
0 0 0 66
0 44 31 41
1
end_operator
begin_operator
board car69 loc39
1
65 32
2
0 0 0 66
0 44 32 41
1
end_operator
begin_operator
board car69 loc4
1
65 33
2
0 0 0 66
0 44 33 41
1
end_operator
begin_operator
board car69 loc40
1
65 34
2
0 0 0 66
0 44 34 41
1
end_operator
begin_operator
board car69 loc41
1
65 35
2
0 0 0 66
0 44 35 41
1
end_operator
begin_operator
board car69 loc5
1
65 36
2
0 0 0 66
0 44 36 41
1
end_operator
begin_operator
board car69 loc6
1
65 37
2
0 0 0 66
0 44 37 41
1
end_operator
begin_operator
board car69 loc7
1
65 38
2
0 0 0 66
0 44 38 41
1
end_operator
begin_operator
board car69 loc8
1
65 39
2
0 0 0 66
0 44 39 41
1
end_operator
begin_operator
board car69 loc9
1
65 40
2
0 0 0 66
0 44 40 41
1
end_operator
begin_operator
board car7 loc1
1
65 0
2
0 0 0 67
0 56 0 41
1
end_operator
begin_operator
board car7 loc10
1
65 1
2
0 0 0 67
0 56 1 41
1
end_operator
begin_operator
board car7 loc11
1
65 2
2
0 0 0 67
0 56 2 41
1
end_operator
begin_operator
board car7 loc12
1
65 3
2
0 0 0 67
0 56 3 41
1
end_operator
begin_operator
board car7 loc13
1
65 4
2
0 0 0 67
0 56 4 41
1
end_operator
begin_operator
board car7 loc14
1
65 5
2
0 0 0 67
0 56 5 41
1
end_operator
begin_operator
board car7 loc15
1
65 6
2
0 0 0 67
0 56 6 41
1
end_operator
begin_operator
board car7 loc16
1
65 7
2
0 0 0 67
0 56 7 41
1
end_operator
begin_operator
board car7 loc17
1
65 8
2
0 0 0 67
0 56 8 41
1
end_operator
begin_operator
board car7 loc18
1
65 9
2
0 0 0 67
0 56 9 41
1
end_operator
begin_operator
board car7 loc19
1
65 10
2
0 0 0 67
0 56 10 41
1
end_operator
begin_operator
board car7 loc2
1
65 11
2
0 0 0 67
0 56 11 41
1
end_operator
begin_operator
board car7 loc20
1
65 12
2
0 0 0 67
0 56 12 41
1
end_operator
begin_operator
board car7 loc21
1
65 13
2
0 0 0 67
0 56 13 41
1
end_operator
begin_operator
board car7 loc22
1
65 14
2
0 0 0 67
0 56 14 41
1
end_operator
begin_operator
board car7 loc23
1
65 15
2
0 0 0 67
0 56 15 41
1
end_operator
begin_operator
board car7 loc24
1
65 16
2
0 0 0 67
0 56 16 41
1
end_operator
begin_operator
board car7 loc25
1
65 17
2
0 0 0 67
0 56 17 41
1
end_operator
begin_operator
board car7 loc26
1
65 18
2
0 0 0 67
0 56 18 41
1
end_operator
begin_operator
board car7 loc27
1
65 19
2
0 0 0 67
0 56 19 41
1
end_operator
begin_operator
board car7 loc28
1
65 20
2
0 0 0 67
0 56 20 41
1
end_operator
begin_operator
board car7 loc29
1
65 21
2
0 0 0 67
0 56 21 41
1
end_operator
begin_operator
board car7 loc3
1
65 22
2
0 0 0 67
0 56 22 41
1
end_operator
begin_operator
board car7 loc30
1
65 23
2
0 0 0 67
0 56 23 41
1
end_operator
begin_operator
board car7 loc31
1
65 24
2
0 0 0 67
0 56 24 41
1
end_operator
begin_operator
board car7 loc32
1
65 25
2
0 0 0 67
0 56 25 41
1
end_operator
begin_operator
board car7 loc33
1
65 26
2
0 0 0 67
0 56 26 41
1
end_operator
begin_operator
board car7 loc34
1
65 27
2
0 0 0 67
0 56 27 41
1
end_operator
begin_operator
board car7 loc35
1
65 28
2
0 0 0 67
0 56 28 41
1
end_operator
begin_operator
board car7 loc36
1
65 29
2
0 0 0 67
0 56 29 41
1
end_operator
begin_operator
board car7 loc37
1
65 30
2
0 0 0 67
0 56 30 41
1
end_operator
begin_operator
board car7 loc38
1
65 31
2
0 0 0 67
0 56 31 41
1
end_operator
begin_operator
board car7 loc39
1
65 32
2
0 0 0 67
0 56 32 41
1
end_operator
begin_operator
board car7 loc4
1
65 33
2
0 0 0 67
0 56 33 41
1
end_operator
begin_operator
board car7 loc40
1
65 34
2
0 0 0 67
0 56 34 41
1
end_operator
begin_operator
board car7 loc41
1
65 35
2
0 0 0 67
0 56 35 41
1
end_operator
begin_operator
board car7 loc5
1
65 36
2
0 0 0 67
0 56 36 41
1
end_operator
begin_operator
board car7 loc6
1
65 37
2
0 0 0 67
0 56 37 41
1
end_operator
begin_operator
board car7 loc7
1
65 38
2
0 0 0 67
0 56 38 41
1
end_operator
begin_operator
board car7 loc8
1
65 39
2
0 0 0 67
0 56 39 41
1
end_operator
begin_operator
board car7 loc9
1
65 40
2
0 0 0 67
0 56 40 41
1
end_operator
begin_operator
board car70 loc1
1
65 0
2
0 0 0 68
0 68 0 41
1
end_operator
begin_operator
board car70 loc10
1
65 1
2
0 0 0 68
0 68 1 41
1
end_operator
begin_operator
board car70 loc11
1
65 2
2
0 0 0 68
0 68 2 41
1
end_operator
begin_operator
board car70 loc12
1
65 3
2
0 0 0 68
0 68 3 41
1
end_operator
begin_operator
board car70 loc13
1
65 4
2
0 0 0 68
0 68 4 41
1
end_operator
begin_operator
board car70 loc14
1
65 5
2
0 0 0 68
0 68 5 41
1
end_operator
begin_operator
board car70 loc15
1
65 6
2
0 0 0 68
0 68 6 41
1
end_operator
begin_operator
board car70 loc16
1
65 7
2
0 0 0 68
0 68 7 41
1
end_operator
begin_operator
board car70 loc17
1
65 8
2
0 0 0 68
0 68 8 41
1
end_operator
begin_operator
board car70 loc18
1
65 9
2
0 0 0 68
0 68 9 41
1
end_operator
begin_operator
board car70 loc19
1
65 10
2
0 0 0 68
0 68 10 41
1
end_operator
begin_operator
board car70 loc2
1
65 11
2
0 0 0 68
0 68 11 41
1
end_operator
begin_operator
board car70 loc20
1
65 12
2
0 0 0 68
0 68 12 41
1
end_operator
begin_operator
board car70 loc21
1
65 13
2
0 0 0 68
0 68 13 41
1
end_operator
begin_operator
board car70 loc22
1
65 14
2
0 0 0 68
0 68 14 41
1
end_operator
begin_operator
board car70 loc23
1
65 15
2
0 0 0 68
0 68 15 41
1
end_operator
begin_operator
board car70 loc24
1
65 16
2
0 0 0 68
0 68 16 41
1
end_operator
begin_operator
board car70 loc25
1
65 17
2
0 0 0 68
0 68 17 41
1
end_operator
begin_operator
board car70 loc26
1
65 18
2
0 0 0 68
0 68 18 41
1
end_operator
begin_operator
board car70 loc27
1
65 19
2
0 0 0 68
0 68 19 41
1
end_operator
begin_operator
board car70 loc28
1
65 20
2
0 0 0 68
0 68 20 41
1
end_operator
begin_operator
board car70 loc29
1
65 21
2
0 0 0 68
0 68 21 41
1
end_operator
begin_operator
board car70 loc3
1
65 22
2
0 0 0 68
0 68 22 41
1
end_operator
begin_operator
board car70 loc30
1
65 23
2
0 0 0 68
0 68 23 41
1
end_operator
begin_operator
board car70 loc31
1
65 24
2
0 0 0 68
0 68 24 41
1
end_operator
begin_operator
board car70 loc32
1
65 25
2
0 0 0 68
0 68 25 41
1
end_operator
begin_operator
board car70 loc33
1
65 26
2
0 0 0 68
0 68 26 41
1
end_operator
begin_operator
board car70 loc34
1
65 27
2
0 0 0 68
0 68 27 41
1
end_operator
begin_operator
board car70 loc35
1
65 28
2
0 0 0 68
0 68 28 41
1
end_operator
begin_operator
board car70 loc36
1
65 29
2
0 0 0 68
0 68 29 41
1
end_operator
begin_operator
board car70 loc37
1
65 30
2
0 0 0 68
0 68 30 41
1
end_operator
begin_operator
board car70 loc38
1
65 31
2
0 0 0 68
0 68 31 41
1
end_operator
begin_operator
board car70 loc39
1
65 32
2
0 0 0 68
0 68 32 41
1
end_operator
begin_operator
board car70 loc4
1
65 33
2
0 0 0 68
0 68 33 41
1
end_operator
begin_operator
board car70 loc40
1
65 34
2
0 0 0 68
0 68 34 41
1
end_operator
begin_operator
board car70 loc41
1
65 35
2
0 0 0 68
0 68 35 41
1
end_operator
begin_operator
board car70 loc5
1
65 36
2
0 0 0 68
0 68 36 41
1
end_operator
begin_operator
board car70 loc6
1
65 37
2
0 0 0 68
0 68 37 41
1
end_operator
begin_operator
board car70 loc7
1
65 38
2
0 0 0 68
0 68 38 41
1
end_operator
begin_operator
board car70 loc8
1
65 39
2
0 0 0 68
0 68 39 41
1
end_operator
begin_operator
board car70 loc9
1
65 40
2
0 0 0 68
0 68 40 41
1
end_operator
begin_operator
board car71 loc1
1
65 0
2
0 0 0 69
0 5 0 41
1
end_operator
begin_operator
board car71 loc10
1
65 1
2
0 0 0 69
0 5 1 41
1
end_operator
begin_operator
board car71 loc11
1
65 2
2
0 0 0 69
0 5 2 41
1
end_operator
begin_operator
board car71 loc12
1
65 3
2
0 0 0 69
0 5 3 41
1
end_operator
begin_operator
board car71 loc13
1
65 4
2
0 0 0 69
0 5 4 41
1
end_operator
begin_operator
board car71 loc14
1
65 5
2
0 0 0 69
0 5 5 41
1
end_operator
begin_operator
board car71 loc15
1
65 6
2
0 0 0 69
0 5 6 41
1
end_operator
begin_operator
board car71 loc16
1
65 7
2
0 0 0 69
0 5 7 41
1
end_operator
begin_operator
board car71 loc17
1
65 8
2
0 0 0 69
0 5 8 41
1
end_operator
begin_operator
board car71 loc18
1
65 9
2
0 0 0 69
0 5 9 41
1
end_operator
begin_operator
board car71 loc19
1
65 10
2
0 0 0 69
0 5 10 41
1
end_operator
begin_operator
board car71 loc2
1
65 11
2
0 0 0 69
0 5 11 41
1
end_operator
begin_operator
board car71 loc20
1
65 12
2
0 0 0 69
0 5 12 41
1
end_operator
begin_operator
board car71 loc21
1
65 13
2
0 0 0 69
0 5 13 41
1
end_operator
begin_operator
board car71 loc22
1
65 14
2
0 0 0 69
0 5 14 41
1
end_operator
begin_operator
board car71 loc23
1
65 15
2
0 0 0 69
0 5 15 41
1
end_operator
begin_operator
board car71 loc24
1
65 16
2
0 0 0 69
0 5 16 41
1
end_operator
begin_operator
board car71 loc25
1
65 17
2
0 0 0 69
0 5 17 41
1
end_operator
begin_operator
board car71 loc26
1
65 18
2
0 0 0 69
0 5 18 41
1
end_operator
begin_operator
board car71 loc27
1
65 19
2
0 0 0 69
0 5 19 41
1
end_operator
begin_operator
board car71 loc28
1
65 20
2
0 0 0 69
0 5 20 41
1
end_operator
begin_operator
board car71 loc29
1
65 21
2
0 0 0 69
0 5 21 41
1
end_operator
begin_operator
board car71 loc3
1
65 22
2
0 0 0 69
0 5 22 41
1
end_operator
begin_operator
board car71 loc30
1
65 23
2
0 0 0 69
0 5 23 41
1
end_operator
begin_operator
board car71 loc31
1
65 24
2
0 0 0 69
0 5 24 41
1
end_operator
begin_operator
board car71 loc32
1
65 25
2
0 0 0 69
0 5 25 41
1
end_operator
begin_operator
board car71 loc33
1
65 26
2
0 0 0 69
0 5 26 41
1
end_operator
begin_operator
board car71 loc34
1
65 27
2
0 0 0 69
0 5 27 41
1
end_operator
begin_operator
board car71 loc35
1
65 28
2
0 0 0 69
0 5 28 41
1
end_operator
begin_operator
board car71 loc36
1
65 29
2
0 0 0 69
0 5 29 41
1
end_operator
begin_operator
board car71 loc37
1
65 30
2
0 0 0 69
0 5 30 41
1
end_operator
begin_operator
board car71 loc38
1
65 31
2
0 0 0 69
0 5 31 41
1
end_operator
begin_operator
board car71 loc39
1
65 32
2
0 0 0 69
0 5 32 41
1
end_operator
begin_operator
board car71 loc4
1
65 33
2
0 0 0 69
0 5 33 41
1
end_operator
begin_operator
board car71 loc40
1
65 34
2
0 0 0 69
0 5 34 41
1
end_operator
begin_operator
board car71 loc41
1
65 35
2
0 0 0 69
0 5 35 41
1
end_operator
begin_operator
board car71 loc5
1
65 36
2
0 0 0 69
0 5 36 41
1
end_operator
begin_operator
board car71 loc6
1
65 37
2
0 0 0 69
0 5 37 41
1
end_operator
begin_operator
board car71 loc7
1
65 38
2
0 0 0 69
0 5 38 41
1
end_operator
begin_operator
board car71 loc8
1
65 39
2
0 0 0 69
0 5 39 41
1
end_operator
begin_operator
board car71 loc9
1
65 40
2
0 0 0 69
0 5 40 41
1
end_operator
begin_operator
board car72 loc1
1
65 0
2
0 0 0 70
0 17 0 41
1
end_operator
begin_operator
board car72 loc10
1
65 1
2
0 0 0 70
0 17 1 41
1
end_operator
begin_operator
board car72 loc11
1
65 2
2
0 0 0 70
0 17 2 41
1
end_operator
begin_operator
board car72 loc12
1
65 3
2
0 0 0 70
0 17 3 41
1
end_operator
begin_operator
board car72 loc13
1
65 4
2
0 0 0 70
0 17 4 41
1
end_operator
begin_operator
board car72 loc14
1
65 5
2
0 0 0 70
0 17 5 41
1
end_operator
begin_operator
board car72 loc15
1
65 6
2
0 0 0 70
0 17 6 41
1
end_operator
begin_operator
board car72 loc16
1
65 7
2
0 0 0 70
0 17 7 41
1
end_operator
begin_operator
board car72 loc17
1
65 8
2
0 0 0 70
0 17 8 41
1
end_operator
begin_operator
board car72 loc18
1
65 9
2
0 0 0 70
0 17 9 41
1
end_operator
begin_operator
board car72 loc19
1
65 10
2
0 0 0 70
0 17 10 41
1
end_operator
begin_operator
board car72 loc2
1
65 11
2
0 0 0 70
0 17 11 41
1
end_operator
begin_operator
board car72 loc20
1
65 12
2
0 0 0 70
0 17 12 41
1
end_operator
begin_operator
board car72 loc21
1
65 13
2
0 0 0 70
0 17 13 41
1
end_operator
begin_operator
board car72 loc22
1
65 14
2
0 0 0 70
0 17 14 41
1
end_operator
begin_operator
board car72 loc23
1
65 15
2
0 0 0 70
0 17 15 41
1
end_operator
begin_operator
board car72 loc24
1
65 16
2
0 0 0 70
0 17 16 41
1
end_operator
begin_operator
board car72 loc25
1
65 17
2
0 0 0 70
0 17 17 41
1
end_operator
begin_operator
board car72 loc26
1
65 18
2
0 0 0 70
0 17 18 41
1
end_operator
begin_operator
board car72 loc27
1
65 19
2
0 0 0 70
0 17 19 41
1
end_operator
begin_operator
board car72 loc28
1
65 20
2
0 0 0 70
0 17 20 41
1
end_operator
begin_operator
board car72 loc29
1
65 21
2
0 0 0 70
0 17 21 41
1
end_operator
begin_operator
board car72 loc3
1
65 22
2
0 0 0 70
0 17 22 41
1
end_operator
begin_operator
board car72 loc30
1
65 23
2
0 0 0 70
0 17 23 41
1
end_operator
begin_operator
board car72 loc31
1
65 24
2
0 0 0 70
0 17 24 41
1
end_operator
begin_operator
board car72 loc32
1
65 25
2
0 0 0 70
0 17 25 41
1
end_operator
begin_operator
board car72 loc33
1
65 26
2
0 0 0 70
0 17 26 41
1
end_operator
begin_operator
board car72 loc34
1
65 27
2
0 0 0 70
0 17 27 41
1
end_operator
begin_operator
board car72 loc35
1
65 28
2
0 0 0 70
0 17 28 41
1
end_operator
begin_operator
board car72 loc36
1
65 29
2
0 0 0 70
0 17 29 41
1
end_operator
begin_operator
board car72 loc37
1
65 30
2
0 0 0 70
0 17 30 41
1
end_operator
begin_operator
board car72 loc38
1
65 31
2
0 0 0 70
0 17 31 41
1
end_operator
begin_operator
board car72 loc39
1
65 32
2
0 0 0 70
0 17 32 41
1
end_operator
begin_operator
board car72 loc4
1
65 33
2
0 0 0 70
0 17 33 41
1
end_operator
begin_operator
board car72 loc40
1
65 34
2
0 0 0 70
0 17 34 41
1
end_operator
begin_operator
board car72 loc41
1
65 35
2
0 0 0 70
0 17 35 41
1
end_operator
begin_operator
board car72 loc5
1
65 36
2
0 0 0 70
0 17 36 41
1
end_operator
begin_operator
board car72 loc6
1
65 37
2
0 0 0 70
0 17 37 41
1
end_operator
begin_operator
board car72 loc7
1
65 38
2
0 0 0 70
0 17 38 41
1
end_operator
begin_operator
board car72 loc8
1
65 39
2
0 0 0 70
0 17 39 41
1
end_operator
begin_operator
board car72 loc9
1
65 40
2
0 0 0 70
0 17 40 41
1
end_operator
begin_operator
board car73 loc1
1
65 0
2
0 0 0 71
0 29 0 41
1
end_operator
begin_operator
board car73 loc10
1
65 1
2
0 0 0 71
0 29 1 41
1
end_operator
begin_operator
board car73 loc11
1
65 2
2
0 0 0 71
0 29 2 41
1
end_operator
begin_operator
board car73 loc12
1
65 3
2
0 0 0 71
0 29 3 41
1
end_operator
begin_operator
board car73 loc13
1
65 4
2
0 0 0 71
0 29 4 41
1
end_operator
begin_operator
board car73 loc14
1
65 5
2
0 0 0 71
0 29 5 41
1
end_operator
begin_operator
board car73 loc15
1
65 6
2
0 0 0 71
0 29 6 41
1
end_operator
begin_operator
board car73 loc16
1
65 7
2
0 0 0 71
0 29 7 41
1
end_operator
begin_operator
board car73 loc17
1
65 8
2
0 0 0 71
0 29 8 41
1
end_operator
begin_operator
board car73 loc18
1
65 9
2
0 0 0 71
0 29 9 41
1
end_operator
begin_operator
board car73 loc19
1
65 10
2
0 0 0 71
0 29 10 41
1
end_operator
begin_operator
board car73 loc2
1
65 11
2
0 0 0 71
0 29 11 41
1
end_operator
begin_operator
board car73 loc20
1
65 12
2
0 0 0 71
0 29 12 41
1
end_operator
begin_operator
board car73 loc21
1
65 13
2
0 0 0 71
0 29 13 41
1
end_operator
begin_operator
board car73 loc22
1
65 14
2
0 0 0 71
0 29 14 41
1
end_operator
begin_operator
board car73 loc23
1
65 15
2
0 0 0 71
0 29 15 41
1
end_operator
begin_operator
board car73 loc24
1
65 16
2
0 0 0 71
0 29 16 41
1
end_operator
begin_operator
board car73 loc25
1
65 17
2
0 0 0 71
0 29 17 41
1
end_operator
begin_operator
board car73 loc26
1
65 18
2
0 0 0 71
0 29 18 41
1
end_operator
begin_operator
board car73 loc27
1
65 19
2
0 0 0 71
0 29 19 41
1
end_operator
begin_operator
board car73 loc28
1
65 20
2
0 0 0 71
0 29 20 41
1
end_operator
begin_operator
board car73 loc29
1
65 21
2
0 0 0 71
0 29 21 41
1
end_operator
begin_operator
board car73 loc3
1
65 22
2
0 0 0 71
0 29 22 41
1
end_operator
begin_operator
board car73 loc30
1
65 23
2
0 0 0 71
0 29 23 41
1
end_operator
begin_operator
board car73 loc31
1
65 24
2
0 0 0 71
0 29 24 41
1
end_operator
begin_operator
board car73 loc32
1
65 25
2
0 0 0 71
0 29 25 41
1
end_operator
begin_operator
board car73 loc33
1
65 26
2
0 0 0 71
0 29 26 41
1
end_operator
begin_operator
board car73 loc34
1
65 27
2
0 0 0 71
0 29 27 41
1
end_operator
begin_operator
board car73 loc35
1
65 28
2
0 0 0 71
0 29 28 41
1
end_operator
begin_operator
board car73 loc36
1
65 29
2
0 0 0 71
0 29 29 41
1
end_operator
begin_operator
board car73 loc37
1
65 30
2
0 0 0 71
0 29 30 41
1
end_operator
begin_operator
board car73 loc38
1
65 31
2
0 0 0 71
0 29 31 41
1
end_operator
begin_operator
board car73 loc39
1
65 32
2
0 0 0 71
0 29 32 41
1
end_operator
begin_operator
board car73 loc4
1
65 33
2
0 0 0 71
0 29 33 41
1
end_operator
begin_operator
board car73 loc40
1
65 34
2
0 0 0 71
0 29 34 41
1
end_operator
begin_operator
board car73 loc41
1
65 35
2
0 0 0 71
0 29 35 41
1
end_operator
begin_operator
board car73 loc5
1
65 36
2
0 0 0 71
0 29 36 41
1
end_operator
begin_operator
board car73 loc6
1
65 37
2
0 0 0 71
0 29 37 41
1
end_operator
begin_operator
board car73 loc7
1
65 38
2
0 0 0 71
0 29 38 41
1
end_operator
begin_operator
board car73 loc8
1
65 39
2
0 0 0 71
0 29 39 41
1
end_operator
begin_operator
board car73 loc9
1
65 40
2
0 0 0 71
0 29 40 41
1
end_operator
begin_operator
board car8 loc1
1
65 0
2
0 0 0 72
0 41 0 41
1
end_operator
begin_operator
board car8 loc10
1
65 1
2
0 0 0 72
0 41 1 41
1
end_operator
begin_operator
board car8 loc11
1
65 2
2
0 0 0 72
0 41 2 41
1
end_operator
begin_operator
board car8 loc12
1
65 3
2
0 0 0 72
0 41 3 41
1
end_operator
begin_operator
board car8 loc13
1
65 4
2
0 0 0 72
0 41 4 41
1
end_operator
begin_operator
board car8 loc14
1
65 5
2
0 0 0 72
0 41 5 41
1
end_operator
begin_operator
board car8 loc15
1
65 6
2
0 0 0 72
0 41 6 41
1
end_operator
begin_operator
board car8 loc16
1
65 7
2
0 0 0 72
0 41 7 41
1
end_operator
begin_operator
board car8 loc17
1
65 8
2
0 0 0 72
0 41 8 41
1
end_operator
begin_operator
board car8 loc18
1
65 9
2
0 0 0 72
0 41 9 41
1
end_operator
begin_operator
board car8 loc19
1
65 10
2
0 0 0 72
0 41 10 41
1
end_operator
begin_operator
board car8 loc2
1
65 11
2
0 0 0 72
0 41 11 41
1
end_operator
begin_operator
board car8 loc20
1
65 12
2
0 0 0 72
0 41 12 41
1
end_operator
begin_operator
board car8 loc21
1
65 13
2
0 0 0 72
0 41 13 41
1
end_operator
begin_operator
board car8 loc22
1
65 14
2
0 0 0 72
0 41 14 41
1
end_operator
begin_operator
board car8 loc23
1
65 15
2
0 0 0 72
0 41 15 41
1
end_operator
begin_operator
board car8 loc24
1
65 16
2
0 0 0 72
0 41 16 41
1
end_operator
begin_operator
board car8 loc25
1
65 17
2
0 0 0 72
0 41 17 41
1
end_operator
begin_operator
board car8 loc26
1
65 18
2
0 0 0 72
0 41 18 41
1
end_operator
begin_operator
board car8 loc27
1
65 19
2
0 0 0 72
0 41 19 41
1
end_operator
begin_operator
board car8 loc28
1
65 20
2
0 0 0 72
0 41 20 41
1
end_operator
begin_operator
board car8 loc29
1
65 21
2
0 0 0 72
0 41 21 41
1
end_operator
begin_operator
board car8 loc3
1
65 22
2
0 0 0 72
0 41 22 41
1
end_operator
begin_operator
board car8 loc30
1
65 23
2
0 0 0 72
0 41 23 41
1
end_operator
begin_operator
board car8 loc31
1
65 24
2
0 0 0 72
0 41 24 41
1
end_operator
begin_operator
board car8 loc32
1
65 25
2
0 0 0 72
0 41 25 41
1
end_operator
begin_operator
board car8 loc33
1
65 26
2
0 0 0 72
0 41 26 41
1
end_operator
begin_operator
board car8 loc34
1
65 27
2
0 0 0 72
0 41 27 41
1
end_operator
begin_operator
board car8 loc35
1
65 28
2
0 0 0 72
0 41 28 41
1
end_operator
begin_operator
board car8 loc36
1
65 29
2
0 0 0 72
0 41 29 41
1
end_operator
begin_operator
board car8 loc37
1
65 30
2
0 0 0 72
0 41 30 41
1
end_operator
begin_operator
board car8 loc38
1
65 31
2
0 0 0 72
0 41 31 41
1
end_operator
begin_operator
board car8 loc39
1
65 32
2
0 0 0 72
0 41 32 41
1
end_operator
begin_operator
board car8 loc4
1
65 33
2
0 0 0 72
0 41 33 41
1
end_operator
begin_operator
board car8 loc40
1
65 34
2
0 0 0 72
0 41 34 41
1
end_operator
begin_operator
board car8 loc41
1
65 35
2
0 0 0 72
0 41 35 41
1
end_operator
begin_operator
board car8 loc5
1
65 36
2
0 0 0 72
0 41 36 41
1
end_operator
begin_operator
board car8 loc6
1
65 37
2
0 0 0 72
0 41 37 41
1
end_operator
begin_operator
board car8 loc7
1
65 38
2
0 0 0 72
0 41 38 41
1
end_operator
begin_operator
board car8 loc8
1
65 39
2
0 0 0 72
0 41 39 41
1
end_operator
begin_operator
board car8 loc9
1
65 40
2
0 0 0 72
0 41 40 41
1
end_operator
begin_operator
board car9 loc1
1
65 0
2
0 0 0 73
0 53 0 41
1
end_operator
begin_operator
board car9 loc10
1
65 1
2
0 0 0 73
0 53 1 41
1
end_operator
begin_operator
board car9 loc11
1
65 2
2
0 0 0 73
0 53 2 41
1
end_operator
begin_operator
board car9 loc12
1
65 3
2
0 0 0 73
0 53 3 41
1
end_operator
begin_operator
board car9 loc13
1
65 4
2
0 0 0 73
0 53 4 41
1
end_operator
begin_operator
board car9 loc14
1
65 5
2
0 0 0 73
0 53 5 41
1
end_operator
begin_operator
board car9 loc15
1
65 6
2
0 0 0 73
0 53 6 41
1
end_operator
begin_operator
board car9 loc16
1
65 7
2
0 0 0 73
0 53 7 41
1
end_operator
begin_operator
board car9 loc17
1
65 8
2
0 0 0 73
0 53 8 41
1
end_operator
begin_operator
board car9 loc18
1
65 9
2
0 0 0 73
0 53 9 41
1
end_operator
begin_operator
board car9 loc19
1
65 10
2
0 0 0 73
0 53 10 41
1
end_operator
begin_operator
board car9 loc2
1
65 11
2
0 0 0 73
0 53 11 41
1
end_operator
begin_operator
board car9 loc20
1
65 12
2
0 0 0 73
0 53 12 41
1
end_operator
begin_operator
board car9 loc21
1
65 13
2
0 0 0 73
0 53 13 41
1
end_operator
begin_operator
board car9 loc22
1
65 14
2
0 0 0 73
0 53 14 41
1
end_operator
begin_operator
board car9 loc23
1
65 15
2
0 0 0 73
0 53 15 41
1
end_operator
begin_operator
board car9 loc24
1
65 16
2
0 0 0 73
0 53 16 41
1
end_operator
begin_operator
board car9 loc25
1
65 17
2
0 0 0 73
0 53 17 41
1
end_operator
begin_operator
board car9 loc26
1
65 18
2
0 0 0 73
0 53 18 41
1
end_operator
begin_operator
board car9 loc27
1
65 19
2
0 0 0 73
0 53 19 41
1
end_operator
begin_operator
board car9 loc28
1
65 20
2
0 0 0 73
0 53 20 41
1
end_operator
begin_operator
board car9 loc29
1
65 21
2
0 0 0 73
0 53 21 41
1
end_operator
begin_operator
board car9 loc3
1
65 22
2
0 0 0 73
0 53 22 41
1
end_operator
begin_operator
board car9 loc30
1
65 23
2
0 0 0 73
0 53 23 41
1
end_operator
begin_operator
board car9 loc31
1
65 24
2
0 0 0 73
0 53 24 41
1
end_operator
begin_operator
board car9 loc32
1
65 25
2
0 0 0 73
0 53 25 41
1
end_operator
begin_operator
board car9 loc33
1
65 26
2
0 0 0 73
0 53 26 41
1
end_operator
begin_operator
board car9 loc34
1
65 27
2
0 0 0 73
0 53 27 41
1
end_operator
begin_operator
board car9 loc35
1
65 28
2
0 0 0 73
0 53 28 41
1
end_operator
begin_operator
board car9 loc36
1
65 29
2
0 0 0 73
0 53 29 41
1
end_operator
begin_operator
board car9 loc37
1
65 30
2
0 0 0 73
0 53 30 41
1
end_operator
begin_operator
board car9 loc38
1
65 31
2
0 0 0 73
0 53 31 41
1
end_operator
begin_operator
board car9 loc39
1
65 32
2
0 0 0 73
0 53 32 41
1
end_operator
begin_operator
board car9 loc4
1
65 33
2
0 0 0 73
0 53 33 41
1
end_operator
begin_operator
board car9 loc40
1
65 34
2
0 0 0 73
0 53 34 41
1
end_operator
begin_operator
board car9 loc41
1
65 35
2
0 0 0 73
0 53 35 41
1
end_operator
begin_operator
board car9 loc5
1
65 36
2
0 0 0 73
0 53 36 41
1
end_operator
begin_operator
board car9 loc6
1
65 37
2
0 0 0 73
0 53 37 41
1
end_operator
begin_operator
board car9 loc7
1
65 38
2
0 0 0 73
0 53 38 41
1
end_operator
begin_operator
board car9 loc8
1
65 39
2
0 0 0 73
0 53 39 41
1
end_operator
begin_operator
board car9 loc9
1
65 40
2
0 0 0 73
0 53 40 41
1
end_operator
begin_operator
debark car1 loc1
1
65 0
2
0 0 1 0
0 12 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
65 1
2
0 0 1 0
0 12 -1 1
1
end_operator
begin_operator
debark car1 loc11
1
65 2
2
0 0 1 0
0 12 -1 2
1
end_operator
begin_operator
debark car1 loc12
1
65 3
2
0 0 1 0
0 12 -1 3
1
end_operator
begin_operator
debark car1 loc13
1
65 4
2
0 0 1 0
0 12 -1 4
1
end_operator
begin_operator
debark car1 loc14
1
65 5
2
0 0 1 0
0 12 -1 5
1
end_operator
begin_operator
debark car1 loc15
1
65 6
2
0 0 1 0
0 12 -1 6
1
end_operator
begin_operator
debark car1 loc16
1
65 7
2
0 0 1 0
0 12 -1 7
1
end_operator
begin_operator
debark car1 loc17
1
65 8
2
0 0 1 0
0 12 -1 8
1
end_operator
begin_operator
debark car1 loc18
1
65 9
2
0 0 1 0
0 12 -1 9
1
end_operator
begin_operator
debark car1 loc19
1
65 10
2
0 0 1 0
0 12 -1 10
1
end_operator
begin_operator
debark car1 loc2
1
65 11
2
0 0 1 0
0 12 -1 11
1
end_operator
begin_operator
debark car1 loc20
1
65 12
2
0 0 1 0
0 12 -1 12
1
end_operator
begin_operator
debark car1 loc21
1
65 13
2
0 0 1 0
0 12 -1 13
1
end_operator
begin_operator
debark car1 loc22
1
65 14
2
0 0 1 0
0 12 -1 14
1
end_operator
begin_operator
debark car1 loc23
1
65 15
2
0 0 1 0
0 12 -1 15
1
end_operator
begin_operator
debark car1 loc24
1
65 16
2
0 0 1 0
0 12 -1 16
1
end_operator
begin_operator
debark car1 loc25
1
65 17
2
0 0 1 0
0 12 -1 17
1
end_operator
begin_operator
debark car1 loc26
1
65 18
2
0 0 1 0
0 12 -1 18
1
end_operator
begin_operator
debark car1 loc27
1
65 19
2
0 0 1 0
0 12 -1 19
1
end_operator
begin_operator
debark car1 loc28
1
65 20
2
0 0 1 0
0 12 -1 20
1
end_operator
begin_operator
debark car1 loc29
1
65 21
2
0 0 1 0
0 12 -1 21
1
end_operator
begin_operator
debark car1 loc3
1
65 22
2
0 0 1 0
0 12 -1 22
1
end_operator
begin_operator
debark car1 loc30
1
65 23
2
0 0 1 0
0 12 -1 23
1
end_operator
begin_operator
debark car1 loc31
1
65 24
2
0 0 1 0
0 12 -1 24
1
end_operator
begin_operator
debark car1 loc32
1
65 25
2
0 0 1 0
0 12 -1 25
1
end_operator
begin_operator
debark car1 loc33
1
65 26
2
0 0 1 0
0 12 -1 26
1
end_operator
begin_operator
debark car1 loc34
1
65 27
2
0 0 1 0
0 12 -1 27
1
end_operator
begin_operator
debark car1 loc35
1
65 28
2
0 0 1 0
0 12 -1 28
1
end_operator
begin_operator
debark car1 loc36
1
65 29
2
0 0 1 0
0 12 -1 29
1
end_operator
begin_operator
debark car1 loc37
1
65 30
2
0 0 1 0
0 12 -1 30
1
end_operator
begin_operator
debark car1 loc38
1
65 31
2
0 0 1 0
0 12 -1 31
1
end_operator
begin_operator
debark car1 loc39
1
65 32
2
0 0 1 0
0 12 -1 32
1
end_operator
begin_operator
debark car1 loc4
1
65 33
2
0 0 1 0
0 12 -1 33
1
end_operator
begin_operator
debark car1 loc40
1
65 34
2
0 0 1 0
0 12 -1 34
1
end_operator
begin_operator
debark car1 loc41
1
65 35
2
0 0 1 0
0 12 -1 35
1
end_operator
begin_operator
debark car1 loc5
1
65 36
2
0 0 1 0
0 12 -1 36
1
end_operator
begin_operator
debark car1 loc6
1
65 37
2
0 0 1 0
0 12 -1 37
1
end_operator
begin_operator
debark car1 loc7
1
65 38
2
0 0 1 0
0 12 -1 38
1
end_operator
begin_operator
debark car1 loc8
1
65 39
2
0 0 1 0
0 12 -1 39
1
end_operator
begin_operator
debark car1 loc9
1
65 40
2
0 0 1 0
0 12 -1 40
1
end_operator
begin_operator
debark car10 loc1
1
65 0
2
0 0 2 0
0 24 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
65 1
2
0 0 2 0
0 24 -1 1
1
end_operator
begin_operator
debark car10 loc11
1
65 2
2
0 0 2 0
0 24 -1 2
1
end_operator
begin_operator
debark car10 loc12
1
65 3
2
0 0 2 0
0 24 -1 3
1
end_operator
begin_operator
debark car10 loc13
1
65 4
2
0 0 2 0
0 24 -1 4
1
end_operator
begin_operator
debark car10 loc14
1
65 5
2
0 0 2 0
0 24 -1 5
1
end_operator
begin_operator
debark car10 loc15
1
65 6
2
0 0 2 0
0 24 -1 6
1
end_operator
begin_operator
debark car10 loc16
1
65 7
2
0 0 2 0
0 24 -1 7
1
end_operator
begin_operator
debark car10 loc17
1
65 8
2
0 0 2 0
0 24 -1 8
1
end_operator
begin_operator
debark car10 loc18
1
65 9
2
0 0 2 0
0 24 -1 9
1
end_operator
begin_operator
debark car10 loc19
1
65 10
2
0 0 2 0
0 24 -1 10
1
end_operator
begin_operator
debark car10 loc2
1
65 11
2
0 0 2 0
0 24 -1 11
1
end_operator
begin_operator
debark car10 loc20
1
65 12
2
0 0 2 0
0 24 -1 12
1
end_operator
begin_operator
debark car10 loc21
1
65 13
2
0 0 2 0
0 24 -1 13
1
end_operator
begin_operator
debark car10 loc22
1
65 14
2
0 0 2 0
0 24 -1 14
1
end_operator
begin_operator
debark car10 loc23
1
65 15
2
0 0 2 0
0 24 -1 15
1
end_operator
begin_operator
debark car10 loc24
1
65 16
2
0 0 2 0
0 24 -1 16
1
end_operator
begin_operator
debark car10 loc25
1
65 17
2
0 0 2 0
0 24 -1 17
1
end_operator
begin_operator
debark car10 loc26
1
65 18
2
0 0 2 0
0 24 -1 18
1
end_operator
begin_operator
debark car10 loc27
1
65 19
2
0 0 2 0
0 24 -1 19
1
end_operator
begin_operator
debark car10 loc28
1
65 20
2
0 0 2 0
0 24 -1 20
1
end_operator
begin_operator
debark car10 loc29
1
65 21
2
0 0 2 0
0 24 -1 21
1
end_operator
begin_operator
debark car10 loc3
1
65 22
2
0 0 2 0
0 24 -1 22
1
end_operator
begin_operator
debark car10 loc30
1
65 23
2
0 0 2 0
0 24 -1 23
1
end_operator
begin_operator
debark car10 loc31
1
65 24
2
0 0 2 0
0 24 -1 24
1
end_operator
begin_operator
debark car10 loc32
1
65 25
2
0 0 2 0
0 24 -1 25
1
end_operator
begin_operator
debark car10 loc33
1
65 26
2
0 0 2 0
0 24 -1 26
1
end_operator
begin_operator
debark car10 loc34
1
65 27
2
0 0 2 0
0 24 -1 27
1
end_operator
begin_operator
debark car10 loc35
1
65 28
2
0 0 2 0
0 24 -1 28
1
end_operator
begin_operator
debark car10 loc36
1
65 29
2
0 0 2 0
0 24 -1 29
1
end_operator
begin_operator
debark car10 loc37
1
65 30
2
0 0 2 0
0 24 -1 30
1
end_operator
begin_operator
debark car10 loc38
1
65 31
2
0 0 2 0
0 24 -1 31
1
end_operator
begin_operator
debark car10 loc39
1
65 32
2
0 0 2 0
0 24 -1 32
1
end_operator
begin_operator
debark car10 loc4
1
65 33
2
0 0 2 0
0 24 -1 33
1
end_operator
begin_operator
debark car10 loc40
1
65 34
2
0 0 2 0
0 24 -1 34
1
end_operator
begin_operator
debark car10 loc41
1
65 35
2
0 0 2 0
0 24 -1 35
1
end_operator
begin_operator
debark car10 loc5
1
65 36
2
0 0 2 0
0 24 -1 36
1
end_operator
begin_operator
debark car10 loc6
1
65 37
2
0 0 2 0
0 24 -1 37
1
end_operator
begin_operator
debark car10 loc7
1
65 38
2
0 0 2 0
0 24 -1 38
1
end_operator
begin_operator
debark car10 loc8
1
65 39
2
0 0 2 0
0 24 -1 39
1
end_operator
begin_operator
debark car10 loc9
1
65 40
2
0 0 2 0
0 24 -1 40
1
end_operator
begin_operator
debark car11 loc1
1
65 0
2
0 0 3 0
0 36 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
65 1
2
0 0 3 0
0 36 -1 1
1
end_operator
begin_operator
debark car11 loc11
1
65 2
2
0 0 3 0
0 36 -1 2
1
end_operator
begin_operator
debark car11 loc12
1
65 3
2
0 0 3 0
0 36 -1 3
1
end_operator
begin_operator
debark car11 loc13
1
65 4
2
0 0 3 0
0 36 -1 4
1
end_operator
begin_operator
debark car11 loc14
1
65 5
2
0 0 3 0
0 36 -1 5
1
end_operator
begin_operator
debark car11 loc15
1
65 6
2
0 0 3 0
0 36 -1 6
1
end_operator
begin_operator
debark car11 loc16
1
65 7
2
0 0 3 0
0 36 -1 7
1
end_operator
begin_operator
debark car11 loc17
1
65 8
2
0 0 3 0
0 36 -1 8
1
end_operator
begin_operator
debark car11 loc18
1
65 9
2
0 0 3 0
0 36 -1 9
1
end_operator
begin_operator
debark car11 loc19
1
65 10
2
0 0 3 0
0 36 -1 10
1
end_operator
begin_operator
debark car11 loc2
1
65 11
2
0 0 3 0
0 36 -1 11
1
end_operator
begin_operator
debark car11 loc20
1
65 12
2
0 0 3 0
0 36 -1 12
1
end_operator
begin_operator
debark car11 loc21
1
65 13
2
0 0 3 0
0 36 -1 13
1
end_operator
begin_operator
debark car11 loc22
1
65 14
2
0 0 3 0
0 36 -1 14
1
end_operator
begin_operator
debark car11 loc23
1
65 15
2
0 0 3 0
0 36 -1 15
1
end_operator
begin_operator
debark car11 loc24
1
65 16
2
0 0 3 0
0 36 -1 16
1
end_operator
begin_operator
debark car11 loc25
1
65 17
2
0 0 3 0
0 36 -1 17
1
end_operator
begin_operator
debark car11 loc26
1
65 18
2
0 0 3 0
0 36 -1 18
1
end_operator
begin_operator
debark car11 loc27
1
65 19
2
0 0 3 0
0 36 -1 19
1
end_operator
begin_operator
debark car11 loc28
1
65 20
2
0 0 3 0
0 36 -1 20
1
end_operator
begin_operator
debark car11 loc29
1
65 21
2
0 0 3 0
0 36 -1 21
1
end_operator
begin_operator
debark car11 loc3
1
65 22
2
0 0 3 0
0 36 -1 22
1
end_operator
begin_operator
debark car11 loc30
1
65 23
2
0 0 3 0
0 36 -1 23
1
end_operator
begin_operator
debark car11 loc31
1
65 24
2
0 0 3 0
0 36 -1 24
1
end_operator
begin_operator
debark car11 loc32
1
65 25
2
0 0 3 0
0 36 -1 25
1
end_operator
begin_operator
debark car11 loc33
1
65 26
2
0 0 3 0
0 36 -1 26
1
end_operator
begin_operator
debark car11 loc34
1
65 27
2
0 0 3 0
0 36 -1 27
1
end_operator
begin_operator
debark car11 loc35
1
65 28
2
0 0 3 0
0 36 -1 28
1
end_operator
begin_operator
debark car11 loc36
1
65 29
2
0 0 3 0
0 36 -1 29
1
end_operator
begin_operator
debark car11 loc37
1
65 30
2
0 0 3 0
0 36 -1 30
1
end_operator
begin_operator
debark car11 loc38
1
65 31
2
0 0 3 0
0 36 -1 31
1
end_operator
begin_operator
debark car11 loc39
1
65 32
2
0 0 3 0
0 36 -1 32
1
end_operator
begin_operator
debark car11 loc4
1
65 33
2
0 0 3 0
0 36 -1 33
1
end_operator
begin_operator
debark car11 loc40
1
65 34
2
0 0 3 0
0 36 -1 34
1
end_operator
begin_operator
debark car11 loc41
1
65 35
2
0 0 3 0
0 36 -1 35
1
end_operator
begin_operator
debark car11 loc5
1
65 36
2
0 0 3 0
0 36 -1 36
1
end_operator
begin_operator
debark car11 loc6
1
65 37
2
0 0 3 0
0 36 -1 37
1
end_operator
begin_operator
debark car11 loc7
1
65 38
2
0 0 3 0
0 36 -1 38
1
end_operator
begin_operator
debark car11 loc8
1
65 39
2
0 0 3 0
0 36 -1 39
1
end_operator
begin_operator
debark car11 loc9
1
65 40
2
0 0 3 0
0 36 -1 40
1
end_operator
begin_operator
debark car12 loc1
1
65 0
2
0 0 4 0
0 48 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
65 1
2
0 0 4 0
0 48 -1 1
1
end_operator
begin_operator
debark car12 loc11
1
65 2
2
0 0 4 0
0 48 -1 2
1
end_operator
begin_operator
debark car12 loc12
1
65 3
2
0 0 4 0
0 48 -1 3
1
end_operator
begin_operator
debark car12 loc13
1
65 4
2
0 0 4 0
0 48 -1 4
1
end_operator
begin_operator
debark car12 loc14
1
65 5
2
0 0 4 0
0 48 -1 5
1
end_operator
begin_operator
debark car12 loc15
1
65 6
2
0 0 4 0
0 48 -1 6
1
end_operator
begin_operator
debark car12 loc16
1
65 7
2
0 0 4 0
0 48 -1 7
1
end_operator
begin_operator
debark car12 loc17
1
65 8
2
0 0 4 0
0 48 -1 8
1
end_operator
begin_operator
debark car12 loc18
1
65 9
2
0 0 4 0
0 48 -1 9
1
end_operator
begin_operator
debark car12 loc19
1
65 10
2
0 0 4 0
0 48 -1 10
1
end_operator
begin_operator
debark car12 loc2
1
65 11
2
0 0 4 0
0 48 -1 11
1
end_operator
begin_operator
debark car12 loc20
1
65 12
2
0 0 4 0
0 48 -1 12
1
end_operator
begin_operator
debark car12 loc21
1
65 13
2
0 0 4 0
0 48 -1 13
1
end_operator
begin_operator
debark car12 loc22
1
65 14
2
0 0 4 0
0 48 -1 14
1
end_operator
begin_operator
debark car12 loc23
1
65 15
2
0 0 4 0
0 48 -1 15
1
end_operator
begin_operator
debark car12 loc24
1
65 16
2
0 0 4 0
0 48 -1 16
1
end_operator
begin_operator
debark car12 loc25
1
65 17
2
0 0 4 0
0 48 -1 17
1
end_operator
begin_operator
debark car12 loc26
1
65 18
2
0 0 4 0
0 48 -1 18
1
end_operator
begin_operator
debark car12 loc27
1
65 19
2
0 0 4 0
0 48 -1 19
1
end_operator
begin_operator
debark car12 loc28
1
65 20
2
0 0 4 0
0 48 -1 20
1
end_operator
begin_operator
debark car12 loc29
1
65 21
2
0 0 4 0
0 48 -1 21
1
end_operator
begin_operator
debark car12 loc3
1
65 22
2
0 0 4 0
0 48 -1 22
1
end_operator
begin_operator
debark car12 loc30
1
65 23
2
0 0 4 0
0 48 -1 23
1
end_operator
begin_operator
debark car12 loc31
1
65 24
2
0 0 4 0
0 48 -1 24
1
end_operator
begin_operator
debark car12 loc32
1
65 25
2
0 0 4 0
0 48 -1 25
1
end_operator
begin_operator
debark car12 loc33
1
65 26
2
0 0 4 0
0 48 -1 26
1
end_operator
begin_operator
debark car12 loc34
1
65 27
2
0 0 4 0
0 48 -1 27
1
end_operator
begin_operator
debark car12 loc35
1
65 28
2
0 0 4 0
0 48 -1 28
1
end_operator
begin_operator
debark car12 loc36
1
65 29
2
0 0 4 0
0 48 -1 29
1
end_operator
begin_operator
debark car12 loc37
1
65 30
2
0 0 4 0
0 48 -1 30
1
end_operator
begin_operator
debark car12 loc38
1
65 31
2
0 0 4 0
0 48 -1 31
1
end_operator
begin_operator
debark car12 loc39
1
65 32
2
0 0 4 0
0 48 -1 32
1
end_operator
begin_operator
debark car12 loc4
1
65 33
2
0 0 4 0
0 48 -1 33
1
end_operator
begin_operator
debark car12 loc40
1
65 34
2
0 0 4 0
0 48 -1 34
1
end_operator
begin_operator
debark car12 loc41
1
65 35
2
0 0 4 0
0 48 -1 35
1
end_operator
begin_operator
debark car12 loc5
1
65 36
2
0 0 4 0
0 48 -1 36
1
end_operator
begin_operator
debark car12 loc6
1
65 37
2
0 0 4 0
0 48 -1 37
1
end_operator
begin_operator
debark car12 loc7
1
65 38
2
0 0 4 0
0 48 -1 38
1
end_operator
begin_operator
debark car12 loc8
1
65 39
2
0 0 4 0
0 48 -1 39
1
end_operator
begin_operator
debark car12 loc9
1
65 40
2
0 0 4 0
0 48 -1 40
1
end_operator
begin_operator
debark car13 loc1
1
65 0
2
0 0 5 0
0 60 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
65 1
2
0 0 5 0
0 60 -1 1
1
end_operator
begin_operator
debark car13 loc11
1
65 2
2
0 0 5 0
0 60 -1 2
1
end_operator
begin_operator
debark car13 loc12
1
65 3
2
0 0 5 0
0 60 -1 3
1
end_operator
begin_operator
debark car13 loc13
1
65 4
2
0 0 5 0
0 60 -1 4
1
end_operator
begin_operator
debark car13 loc14
1
65 5
2
0 0 5 0
0 60 -1 5
1
end_operator
begin_operator
debark car13 loc15
1
65 6
2
0 0 5 0
0 60 -1 6
1
end_operator
begin_operator
debark car13 loc16
1
65 7
2
0 0 5 0
0 60 -1 7
1
end_operator
begin_operator
debark car13 loc17
1
65 8
2
0 0 5 0
0 60 -1 8
1
end_operator
begin_operator
debark car13 loc18
1
65 9
2
0 0 5 0
0 60 -1 9
1
end_operator
begin_operator
debark car13 loc19
1
65 10
2
0 0 5 0
0 60 -1 10
1
end_operator
begin_operator
debark car13 loc2
1
65 11
2
0 0 5 0
0 60 -1 11
1
end_operator
begin_operator
debark car13 loc20
1
65 12
2
0 0 5 0
0 60 -1 12
1
end_operator
begin_operator
debark car13 loc21
1
65 13
2
0 0 5 0
0 60 -1 13
1
end_operator
begin_operator
debark car13 loc22
1
65 14
2
0 0 5 0
0 60 -1 14
1
end_operator
begin_operator
debark car13 loc23
1
65 15
2
0 0 5 0
0 60 -1 15
1
end_operator
begin_operator
debark car13 loc24
1
65 16
2
0 0 5 0
0 60 -1 16
1
end_operator
begin_operator
debark car13 loc25
1
65 17
2
0 0 5 0
0 60 -1 17
1
end_operator
begin_operator
debark car13 loc26
1
65 18
2
0 0 5 0
0 60 -1 18
1
end_operator
begin_operator
debark car13 loc27
1
65 19
2
0 0 5 0
0 60 -1 19
1
end_operator
begin_operator
debark car13 loc28
1
65 20
2
0 0 5 0
0 60 -1 20
1
end_operator
begin_operator
debark car13 loc29
1
65 21
2
0 0 5 0
0 60 -1 21
1
end_operator
begin_operator
debark car13 loc3
1
65 22
2
0 0 5 0
0 60 -1 22
1
end_operator
begin_operator
debark car13 loc30
1
65 23
2
0 0 5 0
0 60 -1 23
1
end_operator
begin_operator
debark car13 loc31
1
65 24
2
0 0 5 0
0 60 -1 24
1
end_operator
begin_operator
debark car13 loc32
1
65 25
2
0 0 5 0
0 60 -1 25
1
end_operator
begin_operator
debark car13 loc33
1
65 26
2
0 0 5 0
0 60 -1 26
1
end_operator
begin_operator
debark car13 loc34
1
65 27
2
0 0 5 0
0 60 -1 27
1
end_operator
begin_operator
debark car13 loc35
1
65 28
2
0 0 5 0
0 60 -1 28
1
end_operator
begin_operator
debark car13 loc36
1
65 29
2
0 0 5 0
0 60 -1 29
1
end_operator
begin_operator
debark car13 loc37
1
65 30
2
0 0 5 0
0 60 -1 30
1
end_operator
begin_operator
debark car13 loc38
1
65 31
2
0 0 5 0
0 60 -1 31
1
end_operator
begin_operator
debark car13 loc39
1
65 32
2
0 0 5 0
0 60 -1 32
1
end_operator
begin_operator
debark car13 loc4
1
65 33
2
0 0 5 0
0 60 -1 33
1
end_operator
begin_operator
debark car13 loc40
1
65 34
2
0 0 5 0
0 60 -1 34
1
end_operator
begin_operator
debark car13 loc41
1
65 35
2
0 0 5 0
0 60 -1 35
1
end_operator
begin_operator
debark car13 loc5
1
65 36
2
0 0 5 0
0 60 -1 36
1
end_operator
begin_operator
debark car13 loc6
1
65 37
2
0 0 5 0
0 60 -1 37
1
end_operator
begin_operator
debark car13 loc7
1
65 38
2
0 0 5 0
0 60 -1 38
1
end_operator
begin_operator
debark car13 loc8
1
65 39
2
0 0 5 0
0 60 -1 39
1
end_operator
begin_operator
debark car13 loc9
1
65 40
2
0 0 5 0
0 60 -1 40
1
end_operator
begin_operator
debark car14 loc1
1
65 0
2
0 0 6 0
0 72 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
65 1
2
0 0 6 0
0 72 -1 1
1
end_operator
begin_operator
debark car14 loc11
1
65 2
2
0 0 6 0
0 72 -1 2
1
end_operator
begin_operator
debark car14 loc12
1
65 3
2
0 0 6 0
0 72 -1 3
1
end_operator
begin_operator
debark car14 loc13
1
65 4
2
0 0 6 0
0 72 -1 4
1
end_operator
begin_operator
debark car14 loc14
1
65 5
2
0 0 6 0
0 72 -1 5
1
end_operator
begin_operator
debark car14 loc15
1
65 6
2
0 0 6 0
0 72 -1 6
1
end_operator
begin_operator
debark car14 loc16
1
65 7
2
0 0 6 0
0 72 -1 7
1
end_operator
begin_operator
debark car14 loc17
1
65 8
2
0 0 6 0
0 72 -1 8
1
end_operator
begin_operator
debark car14 loc18
1
65 9
2
0 0 6 0
0 72 -1 9
1
end_operator
begin_operator
debark car14 loc19
1
65 10
2
0 0 6 0
0 72 -1 10
1
end_operator
begin_operator
debark car14 loc2
1
65 11
2
0 0 6 0
0 72 -1 11
1
end_operator
begin_operator
debark car14 loc20
1
65 12
2
0 0 6 0
0 72 -1 12
1
end_operator
begin_operator
debark car14 loc21
1
65 13
2
0 0 6 0
0 72 -1 13
1
end_operator
begin_operator
debark car14 loc22
1
65 14
2
0 0 6 0
0 72 -1 14
1
end_operator
begin_operator
debark car14 loc23
1
65 15
2
0 0 6 0
0 72 -1 15
1
end_operator
begin_operator
debark car14 loc24
1
65 16
2
0 0 6 0
0 72 -1 16
1
end_operator
begin_operator
debark car14 loc25
1
65 17
2
0 0 6 0
0 72 -1 17
1
end_operator
begin_operator
debark car14 loc26
1
65 18
2
0 0 6 0
0 72 -1 18
1
end_operator
begin_operator
debark car14 loc27
1
65 19
2
0 0 6 0
0 72 -1 19
1
end_operator
begin_operator
debark car14 loc28
1
65 20
2
0 0 6 0
0 72 -1 20
1
end_operator
begin_operator
debark car14 loc29
1
65 21
2
0 0 6 0
0 72 -1 21
1
end_operator
begin_operator
debark car14 loc3
1
65 22
2
0 0 6 0
0 72 -1 22
1
end_operator
begin_operator
debark car14 loc30
1
65 23
2
0 0 6 0
0 72 -1 23
1
end_operator
begin_operator
debark car14 loc31
1
65 24
2
0 0 6 0
0 72 -1 24
1
end_operator
begin_operator
debark car14 loc32
1
65 25
2
0 0 6 0
0 72 -1 25
1
end_operator
begin_operator
debark car14 loc33
1
65 26
2
0 0 6 0
0 72 -1 26
1
end_operator
begin_operator
debark car14 loc34
1
65 27
2
0 0 6 0
0 72 -1 27
1
end_operator
begin_operator
debark car14 loc35
1
65 28
2
0 0 6 0
0 72 -1 28
1
end_operator
begin_operator
debark car14 loc36
1
65 29
2
0 0 6 0
0 72 -1 29
1
end_operator
begin_operator
debark car14 loc37
1
65 30
2
0 0 6 0
0 72 -1 30
1
end_operator
begin_operator
debark car14 loc38
1
65 31
2
0 0 6 0
0 72 -1 31
1
end_operator
begin_operator
debark car14 loc39
1
65 32
2
0 0 6 0
0 72 -1 32
1
end_operator
begin_operator
debark car14 loc4
1
65 33
2
0 0 6 0
0 72 -1 33
1
end_operator
begin_operator
debark car14 loc40
1
65 34
2
0 0 6 0
0 72 -1 34
1
end_operator
begin_operator
debark car14 loc41
1
65 35
2
0 0 6 0
0 72 -1 35
1
end_operator
begin_operator
debark car14 loc5
1
65 36
2
0 0 6 0
0 72 -1 36
1
end_operator
begin_operator
debark car14 loc6
1
65 37
2
0 0 6 0
0 72 -1 37
1
end_operator
begin_operator
debark car14 loc7
1
65 38
2
0 0 6 0
0 72 -1 38
1
end_operator
begin_operator
debark car14 loc8
1
65 39
2
0 0 6 0
0 72 -1 39
1
end_operator
begin_operator
debark car14 loc9
1
65 40
2
0 0 6 0
0 72 -1 40
1
end_operator
begin_operator
debark car15 loc1
1
65 0
2
0 0 7 0
0 9 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
65 1
2
0 0 7 0
0 9 -1 1
1
end_operator
begin_operator
debark car15 loc11
1
65 2
2
0 0 7 0
0 9 -1 2
1
end_operator
begin_operator
debark car15 loc12
1
65 3
2
0 0 7 0
0 9 -1 3
1
end_operator
begin_operator
debark car15 loc13
1
65 4
2
0 0 7 0
0 9 -1 4
1
end_operator
begin_operator
debark car15 loc14
1
65 5
2
0 0 7 0
0 9 -1 5
1
end_operator
begin_operator
debark car15 loc15
1
65 6
2
0 0 7 0
0 9 -1 6
1
end_operator
begin_operator
debark car15 loc16
1
65 7
2
0 0 7 0
0 9 -1 7
1
end_operator
begin_operator
debark car15 loc17
1
65 8
2
0 0 7 0
0 9 -1 8
1
end_operator
begin_operator
debark car15 loc18
1
65 9
2
0 0 7 0
0 9 -1 9
1
end_operator
begin_operator
debark car15 loc19
1
65 10
2
0 0 7 0
0 9 -1 10
1
end_operator
begin_operator
debark car15 loc2
1
65 11
2
0 0 7 0
0 9 -1 11
1
end_operator
begin_operator
debark car15 loc20
1
65 12
2
0 0 7 0
0 9 -1 12
1
end_operator
begin_operator
debark car15 loc21
1
65 13
2
0 0 7 0
0 9 -1 13
1
end_operator
begin_operator
debark car15 loc22
1
65 14
2
0 0 7 0
0 9 -1 14
1
end_operator
begin_operator
debark car15 loc23
1
65 15
2
0 0 7 0
0 9 -1 15
1
end_operator
begin_operator
debark car15 loc24
1
65 16
2
0 0 7 0
0 9 -1 16
1
end_operator
begin_operator
debark car15 loc25
1
65 17
2
0 0 7 0
0 9 -1 17
1
end_operator
begin_operator
debark car15 loc26
1
65 18
2
0 0 7 0
0 9 -1 18
1
end_operator
begin_operator
debark car15 loc27
1
65 19
2
0 0 7 0
0 9 -1 19
1
end_operator
begin_operator
debark car15 loc28
1
65 20
2
0 0 7 0
0 9 -1 20
1
end_operator
begin_operator
debark car15 loc29
1
65 21
2
0 0 7 0
0 9 -1 21
1
end_operator
begin_operator
debark car15 loc3
1
65 22
2
0 0 7 0
0 9 -1 22
1
end_operator
begin_operator
debark car15 loc30
1
65 23
2
0 0 7 0
0 9 -1 23
1
end_operator
begin_operator
debark car15 loc31
1
65 24
2
0 0 7 0
0 9 -1 24
1
end_operator
begin_operator
debark car15 loc32
1
65 25
2
0 0 7 0
0 9 -1 25
1
end_operator
begin_operator
debark car15 loc33
1
65 26
2
0 0 7 0
0 9 -1 26
1
end_operator
begin_operator
debark car15 loc34
1
65 27
2
0 0 7 0
0 9 -1 27
1
end_operator
begin_operator
debark car15 loc35
1
65 28
2
0 0 7 0
0 9 -1 28
1
end_operator
begin_operator
debark car15 loc36
1
65 29
2
0 0 7 0
0 9 -1 29
1
end_operator
begin_operator
debark car15 loc37
1
65 30
2
0 0 7 0
0 9 -1 30
1
end_operator
begin_operator
debark car15 loc38
1
65 31
2
0 0 7 0
0 9 -1 31
1
end_operator
begin_operator
debark car15 loc39
1
65 32
2
0 0 7 0
0 9 -1 32
1
end_operator
begin_operator
debark car15 loc4
1
65 33
2
0 0 7 0
0 9 -1 33
1
end_operator
begin_operator
debark car15 loc40
1
65 34
2
0 0 7 0
0 9 -1 34
1
end_operator
begin_operator
debark car15 loc41
1
65 35
2
0 0 7 0
0 9 -1 35
1
end_operator
begin_operator
debark car15 loc5
1
65 36
2
0 0 7 0
0 9 -1 36
1
end_operator
begin_operator
debark car15 loc6
1
65 37
2
0 0 7 0
0 9 -1 37
1
end_operator
begin_operator
debark car15 loc7
1
65 38
2
0 0 7 0
0 9 -1 38
1
end_operator
begin_operator
debark car15 loc8
1
65 39
2
0 0 7 0
0 9 -1 39
1
end_operator
begin_operator
debark car15 loc9
1
65 40
2
0 0 7 0
0 9 -1 40
1
end_operator
begin_operator
debark car16 loc1
1
65 0
2
0 0 8 0
0 21 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
65 1
2
0 0 8 0
0 21 -1 1
1
end_operator
begin_operator
debark car16 loc11
1
65 2
2
0 0 8 0
0 21 -1 2
1
end_operator
begin_operator
debark car16 loc12
1
65 3
2
0 0 8 0
0 21 -1 3
1
end_operator
begin_operator
debark car16 loc13
1
65 4
2
0 0 8 0
0 21 -1 4
1
end_operator
begin_operator
debark car16 loc14
1
65 5
2
0 0 8 0
0 21 -1 5
1
end_operator
begin_operator
debark car16 loc15
1
65 6
2
0 0 8 0
0 21 -1 6
1
end_operator
begin_operator
debark car16 loc16
1
65 7
2
0 0 8 0
0 21 -1 7
1
end_operator
begin_operator
debark car16 loc17
1
65 8
2
0 0 8 0
0 21 -1 8
1
end_operator
begin_operator
debark car16 loc18
1
65 9
2
0 0 8 0
0 21 -1 9
1
end_operator
begin_operator
debark car16 loc19
1
65 10
2
0 0 8 0
0 21 -1 10
1
end_operator
begin_operator
debark car16 loc2
1
65 11
2
0 0 8 0
0 21 -1 11
1
end_operator
begin_operator
debark car16 loc20
1
65 12
2
0 0 8 0
0 21 -1 12
1
end_operator
begin_operator
debark car16 loc21
1
65 13
2
0 0 8 0
0 21 -1 13
1
end_operator
begin_operator
debark car16 loc22
1
65 14
2
0 0 8 0
0 21 -1 14
1
end_operator
begin_operator
debark car16 loc23
1
65 15
2
0 0 8 0
0 21 -1 15
1
end_operator
begin_operator
debark car16 loc24
1
65 16
2
0 0 8 0
0 21 -1 16
1
end_operator
begin_operator
debark car16 loc25
1
65 17
2
0 0 8 0
0 21 -1 17
1
end_operator
begin_operator
debark car16 loc26
1
65 18
2
0 0 8 0
0 21 -1 18
1
end_operator
begin_operator
debark car16 loc27
1
65 19
2
0 0 8 0
0 21 -1 19
1
end_operator
begin_operator
debark car16 loc28
1
65 20
2
0 0 8 0
0 21 -1 20
1
end_operator
begin_operator
debark car16 loc29
1
65 21
2
0 0 8 0
0 21 -1 21
1
end_operator
begin_operator
debark car16 loc3
1
65 22
2
0 0 8 0
0 21 -1 22
1
end_operator
begin_operator
debark car16 loc30
1
65 23
2
0 0 8 0
0 21 -1 23
1
end_operator
begin_operator
debark car16 loc31
1
65 24
2
0 0 8 0
0 21 -1 24
1
end_operator
begin_operator
debark car16 loc32
1
65 25
2
0 0 8 0
0 21 -1 25
1
end_operator
begin_operator
debark car16 loc33
1
65 26
2
0 0 8 0
0 21 -1 26
1
end_operator
begin_operator
debark car16 loc34
1
65 27
2
0 0 8 0
0 21 -1 27
1
end_operator
begin_operator
debark car16 loc35
1
65 28
2
0 0 8 0
0 21 -1 28
1
end_operator
begin_operator
debark car16 loc36
1
65 29
2
0 0 8 0
0 21 -1 29
1
end_operator
begin_operator
debark car16 loc37
1
65 30
2
0 0 8 0
0 21 -1 30
1
end_operator
begin_operator
debark car16 loc38
1
65 31
2
0 0 8 0
0 21 -1 31
1
end_operator
begin_operator
debark car16 loc39
1
65 32
2
0 0 8 0
0 21 -1 32
1
end_operator
begin_operator
debark car16 loc4
1
65 33
2
0 0 8 0
0 21 -1 33
1
end_operator
begin_operator
debark car16 loc40
1
65 34
2
0 0 8 0
0 21 -1 34
1
end_operator
begin_operator
debark car16 loc41
1
65 35
2
0 0 8 0
0 21 -1 35
1
end_operator
begin_operator
debark car16 loc5
1
65 36
2
0 0 8 0
0 21 -1 36
1
end_operator
begin_operator
debark car16 loc6
1
65 37
2
0 0 8 0
0 21 -1 37
1
end_operator
begin_operator
debark car16 loc7
1
65 38
2
0 0 8 0
0 21 -1 38
1
end_operator
begin_operator
debark car16 loc8
1
65 39
2
0 0 8 0
0 21 -1 39
1
end_operator
begin_operator
debark car16 loc9
1
65 40
2
0 0 8 0
0 21 -1 40
1
end_operator
begin_operator
debark car17 loc1
1
65 0
2
0 0 9 0
0 33 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
65 1
2
0 0 9 0
0 33 -1 1
1
end_operator
begin_operator
debark car17 loc11
1
65 2
2
0 0 9 0
0 33 -1 2
1
end_operator
begin_operator
debark car17 loc12
1
65 3
2
0 0 9 0
0 33 -1 3
1
end_operator
begin_operator
debark car17 loc13
1
65 4
2
0 0 9 0
0 33 -1 4
1
end_operator
begin_operator
debark car17 loc14
1
65 5
2
0 0 9 0
0 33 -1 5
1
end_operator
begin_operator
debark car17 loc15
1
65 6
2
0 0 9 0
0 33 -1 6
1
end_operator
begin_operator
debark car17 loc16
1
65 7
2
0 0 9 0
0 33 -1 7
1
end_operator
begin_operator
debark car17 loc17
1
65 8
2
0 0 9 0
0 33 -1 8
1
end_operator
begin_operator
debark car17 loc18
1
65 9
2
0 0 9 0
0 33 -1 9
1
end_operator
begin_operator
debark car17 loc19
1
65 10
2
0 0 9 0
0 33 -1 10
1
end_operator
begin_operator
debark car17 loc2
1
65 11
2
0 0 9 0
0 33 -1 11
1
end_operator
begin_operator
debark car17 loc20
1
65 12
2
0 0 9 0
0 33 -1 12
1
end_operator
begin_operator
debark car17 loc21
1
65 13
2
0 0 9 0
0 33 -1 13
1
end_operator
begin_operator
debark car17 loc22
1
65 14
2
0 0 9 0
0 33 -1 14
1
end_operator
begin_operator
debark car17 loc23
1
65 15
2
0 0 9 0
0 33 -1 15
1
end_operator
begin_operator
debark car17 loc24
1
65 16
2
0 0 9 0
0 33 -1 16
1
end_operator
begin_operator
debark car17 loc25
1
65 17
2
0 0 9 0
0 33 -1 17
1
end_operator
begin_operator
debark car17 loc26
1
65 18
2
0 0 9 0
0 33 -1 18
1
end_operator
begin_operator
debark car17 loc27
1
65 19
2
0 0 9 0
0 33 -1 19
1
end_operator
begin_operator
debark car17 loc28
1
65 20
2
0 0 9 0
0 33 -1 20
1
end_operator
begin_operator
debark car17 loc29
1
65 21
2
0 0 9 0
0 33 -1 21
1
end_operator
begin_operator
debark car17 loc3
1
65 22
2
0 0 9 0
0 33 -1 22
1
end_operator
begin_operator
debark car17 loc30
1
65 23
2
0 0 9 0
0 33 -1 23
1
end_operator
begin_operator
debark car17 loc31
1
65 24
2
0 0 9 0
0 33 -1 24
1
end_operator
begin_operator
debark car17 loc32
1
65 25
2
0 0 9 0
0 33 -1 25
1
end_operator
begin_operator
debark car17 loc33
1
65 26
2
0 0 9 0
0 33 -1 26
1
end_operator
begin_operator
debark car17 loc34
1
65 27
2
0 0 9 0
0 33 -1 27
1
end_operator
begin_operator
debark car17 loc35
1
65 28
2
0 0 9 0
0 33 -1 28
1
end_operator
begin_operator
debark car17 loc36
1
65 29
2
0 0 9 0
0 33 -1 29
1
end_operator
begin_operator
debark car17 loc37
1
65 30
2
0 0 9 0
0 33 -1 30
1
end_operator
begin_operator
debark car17 loc38
1
65 31
2
0 0 9 0
0 33 -1 31
1
end_operator
begin_operator
debark car17 loc39
1
65 32
2
0 0 9 0
0 33 -1 32
1
end_operator
begin_operator
debark car17 loc4
1
65 33
2
0 0 9 0
0 33 -1 33
1
end_operator
begin_operator
debark car17 loc40
1
65 34
2
0 0 9 0
0 33 -1 34
1
end_operator
begin_operator
debark car17 loc41
1
65 35
2
0 0 9 0
0 33 -1 35
1
end_operator
begin_operator
debark car17 loc5
1
65 36
2
0 0 9 0
0 33 -1 36
1
end_operator
begin_operator
debark car17 loc6
1
65 37
2
0 0 9 0
0 33 -1 37
1
end_operator
begin_operator
debark car17 loc7
1
65 38
2
0 0 9 0
0 33 -1 38
1
end_operator
begin_operator
debark car17 loc8
1
65 39
2
0 0 9 0
0 33 -1 39
1
end_operator
begin_operator
debark car17 loc9
1
65 40
2
0 0 9 0
0 33 -1 40
1
end_operator
begin_operator
debark car18 loc1
1
65 0
2
0 0 10 0
0 45 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
65 1
2
0 0 10 0
0 45 -1 1
1
end_operator
begin_operator
debark car18 loc11
1
65 2
2
0 0 10 0
0 45 -1 2
1
end_operator
begin_operator
debark car18 loc12
1
65 3
2
0 0 10 0
0 45 -1 3
1
end_operator
begin_operator
debark car18 loc13
1
65 4
2
0 0 10 0
0 45 -1 4
1
end_operator
begin_operator
debark car18 loc14
1
65 5
2
0 0 10 0
0 45 -1 5
1
end_operator
begin_operator
debark car18 loc15
1
65 6
2
0 0 10 0
0 45 -1 6
1
end_operator
begin_operator
debark car18 loc16
1
65 7
2
0 0 10 0
0 45 -1 7
1
end_operator
begin_operator
debark car18 loc17
1
65 8
2
0 0 10 0
0 45 -1 8
1
end_operator
begin_operator
debark car18 loc18
1
65 9
2
0 0 10 0
0 45 -1 9
1
end_operator
begin_operator
debark car18 loc19
1
65 10
2
0 0 10 0
0 45 -1 10
1
end_operator
begin_operator
debark car18 loc2
1
65 11
2
0 0 10 0
0 45 -1 11
1
end_operator
begin_operator
debark car18 loc20
1
65 12
2
0 0 10 0
0 45 -1 12
1
end_operator
begin_operator
debark car18 loc21
1
65 13
2
0 0 10 0
0 45 -1 13
1
end_operator
begin_operator
debark car18 loc22
1
65 14
2
0 0 10 0
0 45 -1 14
1
end_operator
begin_operator
debark car18 loc23
1
65 15
2
0 0 10 0
0 45 -1 15
1
end_operator
begin_operator
debark car18 loc24
1
65 16
2
0 0 10 0
0 45 -1 16
1
end_operator
begin_operator
debark car18 loc25
1
65 17
2
0 0 10 0
0 45 -1 17
1
end_operator
begin_operator
debark car18 loc26
1
65 18
2
0 0 10 0
0 45 -1 18
1
end_operator
begin_operator
debark car18 loc27
1
65 19
2
0 0 10 0
0 45 -1 19
1
end_operator
begin_operator
debark car18 loc28
1
65 20
2
0 0 10 0
0 45 -1 20
1
end_operator
begin_operator
debark car18 loc29
1
65 21
2
0 0 10 0
0 45 -1 21
1
end_operator
begin_operator
debark car18 loc3
1
65 22
2
0 0 10 0
0 45 -1 22
1
end_operator
begin_operator
debark car18 loc30
1
65 23
2
0 0 10 0
0 45 -1 23
1
end_operator
begin_operator
debark car18 loc31
1
65 24
2
0 0 10 0
0 45 -1 24
1
end_operator
begin_operator
debark car18 loc32
1
65 25
2
0 0 10 0
0 45 -1 25
1
end_operator
begin_operator
debark car18 loc33
1
65 26
2
0 0 10 0
0 45 -1 26
1
end_operator
begin_operator
debark car18 loc34
1
65 27
2
0 0 10 0
0 45 -1 27
1
end_operator
begin_operator
debark car18 loc35
1
65 28
2
0 0 10 0
0 45 -1 28
1
end_operator
begin_operator
debark car18 loc36
1
65 29
2
0 0 10 0
0 45 -1 29
1
end_operator
begin_operator
debark car18 loc37
1
65 30
2
0 0 10 0
0 45 -1 30
1
end_operator
begin_operator
debark car18 loc38
1
65 31
2
0 0 10 0
0 45 -1 31
1
end_operator
begin_operator
debark car18 loc39
1
65 32
2
0 0 10 0
0 45 -1 32
1
end_operator
begin_operator
debark car18 loc4
1
65 33
2
0 0 10 0
0 45 -1 33
1
end_operator
begin_operator
debark car18 loc40
1
65 34
2
0 0 10 0
0 45 -1 34
1
end_operator
begin_operator
debark car18 loc41
1
65 35
2
0 0 10 0
0 45 -1 35
1
end_operator
begin_operator
debark car18 loc5
1
65 36
2
0 0 10 0
0 45 -1 36
1
end_operator
begin_operator
debark car18 loc6
1
65 37
2
0 0 10 0
0 45 -1 37
1
end_operator
begin_operator
debark car18 loc7
1
65 38
2
0 0 10 0
0 45 -1 38
1
end_operator
begin_operator
debark car18 loc8
1
65 39
2
0 0 10 0
0 45 -1 39
1
end_operator
begin_operator
debark car18 loc9
1
65 40
2
0 0 10 0
0 45 -1 40
1
end_operator
begin_operator
debark car19 loc1
1
65 0
2
0 0 11 0
0 57 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
65 1
2
0 0 11 0
0 57 -1 1
1
end_operator
begin_operator
debark car19 loc11
1
65 2
2
0 0 11 0
0 57 -1 2
1
end_operator
begin_operator
debark car19 loc12
1
65 3
2
0 0 11 0
0 57 -1 3
1
end_operator
begin_operator
debark car19 loc13
1
65 4
2
0 0 11 0
0 57 -1 4
1
end_operator
begin_operator
debark car19 loc14
1
65 5
2
0 0 11 0
0 57 -1 5
1
end_operator
begin_operator
debark car19 loc15
1
65 6
2
0 0 11 0
0 57 -1 6
1
end_operator
begin_operator
debark car19 loc16
1
65 7
2
0 0 11 0
0 57 -1 7
1
end_operator
begin_operator
debark car19 loc17
1
65 8
2
0 0 11 0
0 57 -1 8
1
end_operator
begin_operator
debark car19 loc18
1
65 9
2
0 0 11 0
0 57 -1 9
1
end_operator
begin_operator
debark car19 loc19
1
65 10
2
0 0 11 0
0 57 -1 10
1
end_operator
begin_operator
debark car19 loc2
1
65 11
2
0 0 11 0
0 57 -1 11
1
end_operator
begin_operator
debark car19 loc20
1
65 12
2
0 0 11 0
0 57 -1 12
1
end_operator
begin_operator
debark car19 loc21
1
65 13
2
0 0 11 0
0 57 -1 13
1
end_operator
begin_operator
debark car19 loc22
1
65 14
2
0 0 11 0
0 57 -1 14
1
end_operator
begin_operator
debark car19 loc23
1
65 15
2
0 0 11 0
0 57 -1 15
1
end_operator
begin_operator
debark car19 loc24
1
65 16
2
0 0 11 0
0 57 -1 16
1
end_operator
begin_operator
debark car19 loc25
1
65 17
2
0 0 11 0
0 57 -1 17
1
end_operator
begin_operator
debark car19 loc26
1
65 18
2
0 0 11 0
0 57 -1 18
1
end_operator
begin_operator
debark car19 loc27
1
65 19
2
0 0 11 0
0 57 -1 19
1
end_operator
begin_operator
debark car19 loc28
1
65 20
2
0 0 11 0
0 57 -1 20
1
end_operator
begin_operator
debark car19 loc29
1
65 21
2
0 0 11 0
0 57 -1 21
1
end_operator
begin_operator
debark car19 loc3
1
65 22
2
0 0 11 0
0 57 -1 22
1
end_operator
begin_operator
debark car19 loc30
1
65 23
2
0 0 11 0
0 57 -1 23
1
end_operator
begin_operator
debark car19 loc31
1
65 24
2
0 0 11 0
0 57 -1 24
1
end_operator
begin_operator
debark car19 loc32
1
65 25
2
0 0 11 0
0 57 -1 25
1
end_operator
begin_operator
debark car19 loc33
1
65 26
2
0 0 11 0
0 57 -1 26
1
end_operator
begin_operator
debark car19 loc34
1
65 27
2
0 0 11 0
0 57 -1 27
1
end_operator
begin_operator
debark car19 loc35
1
65 28
2
0 0 11 0
0 57 -1 28
1
end_operator
begin_operator
debark car19 loc36
1
65 29
2
0 0 11 0
0 57 -1 29
1
end_operator
begin_operator
debark car19 loc37
1
65 30
2
0 0 11 0
0 57 -1 30
1
end_operator
begin_operator
debark car19 loc38
1
65 31
2
0 0 11 0
0 57 -1 31
1
end_operator
begin_operator
debark car19 loc39
1
65 32
2
0 0 11 0
0 57 -1 32
1
end_operator
begin_operator
debark car19 loc4
1
65 33
2
0 0 11 0
0 57 -1 33
1
end_operator
begin_operator
debark car19 loc40
1
65 34
2
0 0 11 0
0 57 -1 34
1
end_operator
begin_operator
debark car19 loc41
1
65 35
2
0 0 11 0
0 57 -1 35
1
end_operator
begin_operator
debark car19 loc5
1
65 36
2
0 0 11 0
0 57 -1 36
1
end_operator
begin_operator
debark car19 loc6
1
65 37
2
0 0 11 0
0 57 -1 37
1
end_operator
begin_operator
debark car19 loc7
1
65 38
2
0 0 11 0
0 57 -1 38
1
end_operator
begin_operator
debark car19 loc8
1
65 39
2
0 0 11 0
0 57 -1 39
1
end_operator
begin_operator
debark car19 loc9
1
65 40
2
0 0 11 0
0 57 -1 40
1
end_operator
begin_operator
debark car2 loc1
1
65 0
2
0 0 12 0
0 69 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
65 1
2
0 0 12 0
0 69 -1 1
1
end_operator
begin_operator
debark car2 loc11
1
65 2
2
0 0 12 0
0 69 -1 2
1
end_operator
begin_operator
debark car2 loc12
1
65 3
2
0 0 12 0
0 69 -1 3
1
end_operator
begin_operator
debark car2 loc13
1
65 4
2
0 0 12 0
0 69 -1 4
1
end_operator
begin_operator
debark car2 loc14
1
65 5
2
0 0 12 0
0 69 -1 5
1
end_operator
begin_operator
debark car2 loc15
1
65 6
2
0 0 12 0
0 69 -1 6
1
end_operator
begin_operator
debark car2 loc16
1
65 7
2
0 0 12 0
0 69 -1 7
1
end_operator
begin_operator
debark car2 loc17
1
65 8
2
0 0 12 0
0 69 -1 8
1
end_operator
begin_operator
debark car2 loc18
1
65 9
2
0 0 12 0
0 69 -1 9
1
end_operator
begin_operator
debark car2 loc19
1
65 10
2
0 0 12 0
0 69 -1 10
1
end_operator
begin_operator
debark car2 loc2
1
65 11
2
0 0 12 0
0 69 -1 11
1
end_operator
begin_operator
debark car2 loc20
1
65 12
2
0 0 12 0
0 69 -1 12
1
end_operator
begin_operator
debark car2 loc21
1
65 13
2
0 0 12 0
0 69 -1 13
1
end_operator
begin_operator
debark car2 loc22
1
65 14
2
0 0 12 0
0 69 -1 14
1
end_operator
begin_operator
debark car2 loc23
1
65 15
2
0 0 12 0
0 69 -1 15
1
end_operator
begin_operator
debark car2 loc24
1
65 16
2
0 0 12 0
0 69 -1 16
1
end_operator
begin_operator
debark car2 loc25
1
65 17
2
0 0 12 0
0 69 -1 17
1
end_operator
begin_operator
debark car2 loc26
1
65 18
2
0 0 12 0
0 69 -1 18
1
end_operator
begin_operator
debark car2 loc27
1
65 19
2
0 0 12 0
0 69 -1 19
1
end_operator
begin_operator
debark car2 loc28
1
65 20
2
0 0 12 0
0 69 -1 20
1
end_operator
begin_operator
debark car2 loc29
1
65 21
2
0 0 12 0
0 69 -1 21
1
end_operator
begin_operator
debark car2 loc3
1
65 22
2
0 0 12 0
0 69 -1 22
1
end_operator
begin_operator
debark car2 loc30
1
65 23
2
0 0 12 0
0 69 -1 23
1
end_operator
begin_operator
debark car2 loc31
1
65 24
2
0 0 12 0
0 69 -1 24
1
end_operator
begin_operator
debark car2 loc32
1
65 25
2
0 0 12 0
0 69 -1 25
1
end_operator
begin_operator
debark car2 loc33
1
65 26
2
0 0 12 0
0 69 -1 26
1
end_operator
begin_operator
debark car2 loc34
1
65 27
2
0 0 12 0
0 69 -1 27
1
end_operator
begin_operator
debark car2 loc35
1
65 28
2
0 0 12 0
0 69 -1 28
1
end_operator
begin_operator
debark car2 loc36
1
65 29
2
0 0 12 0
0 69 -1 29
1
end_operator
begin_operator
debark car2 loc37
1
65 30
2
0 0 12 0
0 69 -1 30
1
end_operator
begin_operator
debark car2 loc38
1
65 31
2
0 0 12 0
0 69 -1 31
1
end_operator
begin_operator
debark car2 loc39
1
65 32
2
0 0 12 0
0 69 -1 32
1
end_operator
begin_operator
debark car2 loc4
1
65 33
2
0 0 12 0
0 69 -1 33
1
end_operator
begin_operator
debark car2 loc40
1
65 34
2
0 0 12 0
0 69 -1 34
1
end_operator
begin_operator
debark car2 loc41
1
65 35
2
0 0 12 0
0 69 -1 35
1
end_operator
begin_operator
debark car2 loc5
1
65 36
2
0 0 12 0
0 69 -1 36
1
end_operator
begin_operator
debark car2 loc6
1
65 37
2
0 0 12 0
0 69 -1 37
1
end_operator
begin_operator
debark car2 loc7
1
65 38
2
0 0 12 0
0 69 -1 38
1
end_operator
begin_operator
debark car2 loc8
1
65 39
2
0 0 12 0
0 69 -1 39
1
end_operator
begin_operator
debark car2 loc9
1
65 40
2
0 0 12 0
0 69 -1 40
1
end_operator
begin_operator
debark car20 loc1
1
65 0
2
0 0 13 0
0 6 -1 0
1
end_operator
begin_operator
debark car20 loc10
1
65 1
2
0 0 13 0
0 6 -1 1
1
end_operator
begin_operator
debark car20 loc11
1
65 2
2
0 0 13 0
0 6 -1 2
1
end_operator
begin_operator
debark car20 loc12
1
65 3
2
0 0 13 0
0 6 -1 3
1
end_operator
begin_operator
debark car20 loc13
1
65 4
2
0 0 13 0
0 6 -1 4
1
end_operator
begin_operator
debark car20 loc14
1
65 5
2
0 0 13 0
0 6 -1 5
1
end_operator
begin_operator
debark car20 loc15
1
65 6
2
0 0 13 0
0 6 -1 6
1
end_operator
begin_operator
debark car20 loc16
1
65 7
2
0 0 13 0
0 6 -1 7
1
end_operator
begin_operator
debark car20 loc17
1
65 8
2
0 0 13 0
0 6 -1 8
1
end_operator
begin_operator
debark car20 loc18
1
65 9
2
0 0 13 0
0 6 -1 9
1
end_operator
begin_operator
debark car20 loc19
1
65 10
2
0 0 13 0
0 6 -1 10
1
end_operator
begin_operator
debark car20 loc2
1
65 11
2
0 0 13 0
0 6 -1 11
1
end_operator
begin_operator
debark car20 loc20
1
65 12
2
0 0 13 0
0 6 -1 12
1
end_operator
begin_operator
debark car20 loc21
1
65 13
2
0 0 13 0
0 6 -1 13
1
end_operator
begin_operator
debark car20 loc22
1
65 14
2
0 0 13 0
0 6 -1 14
1
end_operator
begin_operator
debark car20 loc23
1
65 15
2
0 0 13 0
0 6 -1 15
1
end_operator
begin_operator
debark car20 loc24
1
65 16
2
0 0 13 0
0 6 -1 16
1
end_operator
begin_operator
debark car20 loc25
1
65 17
2
0 0 13 0
0 6 -1 17
1
end_operator
begin_operator
debark car20 loc26
1
65 18
2
0 0 13 0
0 6 -1 18
1
end_operator
begin_operator
debark car20 loc27
1
65 19
2
0 0 13 0
0 6 -1 19
1
end_operator
begin_operator
debark car20 loc28
1
65 20
2
0 0 13 0
0 6 -1 20
1
end_operator
begin_operator
debark car20 loc29
1
65 21
2
0 0 13 0
0 6 -1 21
1
end_operator
begin_operator
debark car20 loc3
1
65 22
2
0 0 13 0
0 6 -1 22
1
end_operator
begin_operator
debark car20 loc30
1
65 23
2
0 0 13 0
0 6 -1 23
1
end_operator
begin_operator
debark car20 loc31
1
65 24
2
0 0 13 0
0 6 -1 24
1
end_operator
begin_operator
debark car20 loc32
1
65 25
2
0 0 13 0
0 6 -1 25
1
end_operator
begin_operator
debark car20 loc33
1
65 26
2
0 0 13 0
0 6 -1 26
1
end_operator
begin_operator
debark car20 loc34
1
65 27
2
0 0 13 0
0 6 -1 27
1
end_operator
begin_operator
debark car20 loc35
1
65 28
2
0 0 13 0
0 6 -1 28
1
end_operator
begin_operator
debark car20 loc36
1
65 29
2
0 0 13 0
0 6 -1 29
1
end_operator
begin_operator
debark car20 loc37
1
65 30
2
0 0 13 0
0 6 -1 30
1
end_operator
begin_operator
debark car20 loc38
1
65 31
2
0 0 13 0
0 6 -1 31
1
end_operator
begin_operator
debark car20 loc39
1
65 32
2
0 0 13 0
0 6 -1 32
1
end_operator
begin_operator
debark car20 loc4
1
65 33
2
0 0 13 0
0 6 -1 33
1
end_operator
begin_operator
debark car20 loc40
1
65 34
2
0 0 13 0
0 6 -1 34
1
end_operator
begin_operator
debark car20 loc41
1
65 35
2
0 0 13 0
0 6 -1 35
1
end_operator
begin_operator
debark car20 loc5
1
65 36
2
0 0 13 0
0 6 -1 36
1
end_operator
begin_operator
debark car20 loc6
1
65 37
2
0 0 13 0
0 6 -1 37
1
end_operator
begin_operator
debark car20 loc7
1
65 38
2
0 0 13 0
0 6 -1 38
1
end_operator
begin_operator
debark car20 loc8
1
65 39
2
0 0 13 0
0 6 -1 39
1
end_operator
begin_operator
debark car20 loc9
1
65 40
2
0 0 13 0
0 6 -1 40
1
end_operator
begin_operator
debark car21 loc1
1
65 0
2
0 0 14 0
0 18 -1 0
1
end_operator
begin_operator
debark car21 loc10
1
65 1
2
0 0 14 0
0 18 -1 1
1
end_operator
begin_operator
debark car21 loc11
1
65 2
2
0 0 14 0
0 18 -1 2
1
end_operator
begin_operator
debark car21 loc12
1
65 3
2
0 0 14 0
0 18 -1 3
1
end_operator
begin_operator
debark car21 loc13
1
65 4
2
0 0 14 0
0 18 -1 4
1
end_operator
begin_operator
debark car21 loc14
1
65 5
2
0 0 14 0
0 18 -1 5
1
end_operator
begin_operator
debark car21 loc15
1
65 6
2
0 0 14 0
0 18 -1 6
1
end_operator
begin_operator
debark car21 loc16
1
65 7
2
0 0 14 0
0 18 -1 7
1
end_operator
begin_operator
debark car21 loc17
1
65 8
2
0 0 14 0
0 18 -1 8
1
end_operator
begin_operator
debark car21 loc18
1
65 9
2
0 0 14 0
0 18 -1 9
1
end_operator
begin_operator
debark car21 loc19
1
65 10
2
0 0 14 0
0 18 -1 10
1
end_operator
begin_operator
debark car21 loc2
1
65 11
2
0 0 14 0
0 18 -1 11
1
end_operator
begin_operator
debark car21 loc20
1
65 12
2
0 0 14 0
0 18 -1 12
1
end_operator
begin_operator
debark car21 loc21
1
65 13
2
0 0 14 0
0 18 -1 13
1
end_operator
begin_operator
debark car21 loc22
1
65 14
2
0 0 14 0
0 18 -1 14
1
end_operator
begin_operator
debark car21 loc23
1
65 15
2
0 0 14 0
0 18 -1 15
1
end_operator
begin_operator
debark car21 loc24
1
65 16
2
0 0 14 0
0 18 -1 16
1
end_operator
begin_operator
debark car21 loc25
1
65 17
2
0 0 14 0
0 18 -1 17
1
end_operator
begin_operator
debark car21 loc26
1
65 18
2
0 0 14 0
0 18 -1 18
1
end_operator
begin_operator
debark car21 loc27
1
65 19
2
0 0 14 0
0 18 -1 19
1
end_operator
begin_operator
debark car21 loc28
1
65 20
2
0 0 14 0
0 18 -1 20
1
end_operator
begin_operator
debark car21 loc29
1
65 21
2
0 0 14 0
0 18 -1 21
1
end_operator
begin_operator
debark car21 loc3
1
65 22
2
0 0 14 0
0 18 -1 22
1
end_operator
begin_operator
debark car21 loc30
1
65 23
2
0 0 14 0
0 18 -1 23
1
end_operator
begin_operator
debark car21 loc31
1
65 24
2
0 0 14 0
0 18 -1 24
1
end_operator
begin_operator
debark car21 loc32
1
65 25
2
0 0 14 0
0 18 -1 25
1
end_operator
begin_operator
debark car21 loc33
1
65 26
2
0 0 14 0
0 18 -1 26
1
end_operator
begin_operator
debark car21 loc34
1
65 27
2
0 0 14 0
0 18 -1 27
1
end_operator
begin_operator
debark car21 loc35
1
65 28
2
0 0 14 0
0 18 -1 28
1
end_operator
begin_operator
debark car21 loc36
1
65 29
2
0 0 14 0
0 18 -1 29
1
end_operator
begin_operator
debark car21 loc37
1
65 30
2
0 0 14 0
0 18 -1 30
1
end_operator
begin_operator
debark car21 loc38
1
65 31
2
0 0 14 0
0 18 -1 31
1
end_operator
begin_operator
debark car21 loc39
1
65 32
2
0 0 14 0
0 18 -1 32
1
end_operator
begin_operator
debark car21 loc4
1
65 33
2
0 0 14 0
0 18 -1 33
1
end_operator
begin_operator
debark car21 loc40
1
65 34
2
0 0 14 0
0 18 -1 34
1
end_operator
begin_operator
debark car21 loc41
1
65 35
2
0 0 14 0
0 18 -1 35
1
end_operator
begin_operator
debark car21 loc5
1
65 36
2
0 0 14 0
0 18 -1 36
1
end_operator
begin_operator
debark car21 loc6
1
65 37
2
0 0 14 0
0 18 -1 37
1
end_operator
begin_operator
debark car21 loc7
1
65 38
2
0 0 14 0
0 18 -1 38
1
end_operator
begin_operator
debark car21 loc8
1
65 39
2
0 0 14 0
0 18 -1 39
1
end_operator
begin_operator
debark car21 loc9
1
65 40
2
0 0 14 0
0 18 -1 40
1
end_operator
begin_operator
debark car22 loc1
1
65 0
2
0 0 15 0
0 30 -1 0
1
end_operator
begin_operator
debark car22 loc10
1
65 1
2
0 0 15 0
0 30 -1 1
1
end_operator
begin_operator
debark car22 loc11
1
65 2
2
0 0 15 0
0 30 -1 2
1
end_operator
begin_operator
debark car22 loc12
1
65 3
2
0 0 15 0
0 30 -1 3
1
end_operator
begin_operator
debark car22 loc13
1
65 4
2
0 0 15 0
0 30 -1 4
1
end_operator
begin_operator
debark car22 loc14
1
65 5
2
0 0 15 0
0 30 -1 5
1
end_operator
begin_operator
debark car22 loc15
1
65 6
2
0 0 15 0
0 30 -1 6
1
end_operator
begin_operator
debark car22 loc16
1
65 7
2
0 0 15 0
0 30 -1 7
1
end_operator
begin_operator
debark car22 loc17
1
65 8
2
0 0 15 0
0 30 -1 8
1
end_operator
begin_operator
debark car22 loc18
1
65 9
2
0 0 15 0
0 30 -1 9
1
end_operator
begin_operator
debark car22 loc19
1
65 10
2
0 0 15 0
0 30 -1 10
1
end_operator
begin_operator
debark car22 loc2
1
65 11
2
0 0 15 0
0 30 -1 11
1
end_operator
begin_operator
debark car22 loc20
1
65 12
2
0 0 15 0
0 30 -1 12
1
end_operator
begin_operator
debark car22 loc21
1
65 13
2
0 0 15 0
0 30 -1 13
1
end_operator
begin_operator
debark car22 loc22
1
65 14
2
0 0 15 0
0 30 -1 14
1
end_operator
begin_operator
debark car22 loc23
1
65 15
2
0 0 15 0
0 30 -1 15
1
end_operator
begin_operator
debark car22 loc24
1
65 16
2
0 0 15 0
0 30 -1 16
1
end_operator
begin_operator
debark car22 loc25
1
65 17
2
0 0 15 0
0 30 -1 17
1
end_operator
begin_operator
debark car22 loc26
1
65 18
2
0 0 15 0
0 30 -1 18
1
end_operator
begin_operator
debark car22 loc27
1
65 19
2
0 0 15 0
0 30 -1 19
1
end_operator
begin_operator
debark car22 loc28
1
65 20
2
0 0 15 0
0 30 -1 20
1
end_operator
begin_operator
debark car22 loc29
1
65 21
2
0 0 15 0
0 30 -1 21
1
end_operator
begin_operator
debark car22 loc3
1
65 22
2
0 0 15 0
0 30 -1 22
1
end_operator
begin_operator
debark car22 loc30
1
65 23
2
0 0 15 0
0 30 -1 23
1
end_operator
begin_operator
debark car22 loc31
1
65 24
2
0 0 15 0
0 30 -1 24
1
end_operator
begin_operator
debark car22 loc32
1
65 25
2
0 0 15 0
0 30 -1 25
1
end_operator
begin_operator
debark car22 loc33
1
65 26
2
0 0 15 0
0 30 -1 26
1
end_operator
begin_operator
debark car22 loc34
1
65 27
2
0 0 15 0
0 30 -1 27
1
end_operator
begin_operator
debark car22 loc35
1
65 28
2
0 0 15 0
0 30 -1 28
1
end_operator
begin_operator
debark car22 loc36
1
65 29
2
0 0 15 0
0 30 -1 29
1
end_operator
begin_operator
debark car22 loc37
1
65 30
2
0 0 15 0
0 30 -1 30
1
end_operator
begin_operator
debark car22 loc38
1
65 31
2
0 0 15 0
0 30 -1 31
1
end_operator
begin_operator
debark car22 loc39
1
65 32
2
0 0 15 0
0 30 -1 32
1
end_operator
begin_operator
debark car22 loc4
1
65 33
2
0 0 15 0
0 30 -1 33
1
end_operator
begin_operator
debark car22 loc40
1
65 34
2
0 0 15 0
0 30 -1 34
1
end_operator
begin_operator
debark car22 loc41
1
65 35
2
0 0 15 0
0 30 -1 35
1
end_operator
begin_operator
debark car22 loc5
1
65 36
2
0 0 15 0
0 30 -1 36
1
end_operator
begin_operator
debark car22 loc6
1
65 37
2
0 0 15 0
0 30 -1 37
1
end_operator
begin_operator
debark car22 loc7
1
65 38
2
0 0 15 0
0 30 -1 38
1
end_operator
begin_operator
debark car22 loc8
1
65 39
2
0 0 15 0
0 30 -1 39
1
end_operator
begin_operator
debark car22 loc9
1
65 40
2
0 0 15 0
0 30 -1 40
1
end_operator
begin_operator
debark car23 loc1
1
65 0
2
0 0 16 0
0 42 -1 0
1
end_operator
begin_operator
debark car23 loc10
1
65 1
2
0 0 16 0
0 42 -1 1
1
end_operator
begin_operator
debark car23 loc11
1
65 2
2
0 0 16 0
0 42 -1 2
1
end_operator
begin_operator
debark car23 loc12
1
65 3
2
0 0 16 0
0 42 -1 3
1
end_operator
begin_operator
debark car23 loc13
1
65 4
2
0 0 16 0
0 42 -1 4
1
end_operator
begin_operator
debark car23 loc14
1
65 5
2
0 0 16 0
0 42 -1 5
1
end_operator
begin_operator
debark car23 loc15
1
65 6
2
0 0 16 0
0 42 -1 6
1
end_operator
begin_operator
debark car23 loc16
1
65 7
2
0 0 16 0
0 42 -1 7
1
end_operator
begin_operator
debark car23 loc17
1
65 8
2
0 0 16 0
0 42 -1 8
1
end_operator
begin_operator
debark car23 loc18
1
65 9
2
0 0 16 0
0 42 -1 9
1
end_operator
begin_operator
debark car23 loc19
1
65 10
2
0 0 16 0
0 42 -1 10
1
end_operator
begin_operator
debark car23 loc2
1
65 11
2
0 0 16 0
0 42 -1 11
1
end_operator
begin_operator
debark car23 loc20
1
65 12
2
0 0 16 0
0 42 -1 12
1
end_operator
begin_operator
debark car23 loc21
1
65 13
2
0 0 16 0
0 42 -1 13
1
end_operator
begin_operator
debark car23 loc22
1
65 14
2
0 0 16 0
0 42 -1 14
1
end_operator
begin_operator
debark car23 loc23
1
65 15
2
0 0 16 0
0 42 -1 15
1
end_operator
begin_operator
debark car23 loc24
1
65 16
2
0 0 16 0
0 42 -1 16
1
end_operator
begin_operator
debark car23 loc25
1
65 17
2
0 0 16 0
0 42 -1 17
1
end_operator
begin_operator
debark car23 loc26
1
65 18
2
0 0 16 0
0 42 -1 18
1
end_operator
begin_operator
debark car23 loc27
1
65 19
2
0 0 16 0
0 42 -1 19
1
end_operator
begin_operator
debark car23 loc28
1
65 20
2
0 0 16 0
0 42 -1 20
1
end_operator
begin_operator
debark car23 loc29
1
65 21
2
0 0 16 0
0 42 -1 21
1
end_operator
begin_operator
debark car23 loc3
1
65 22
2
0 0 16 0
0 42 -1 22
1
end_operator
begin_operator
debark car23 loc30
1
65 23
2
0 0 16 0
0 42 -1 23
1
end_operator
begin_operator
debark car23 loc31
1
65 24
2
0 0 16 0
0 42 -1 24
1
end_operator
begin_operator
debark car23 loc32
1
65 25
2
0 0 16 0
0 42 -1 25
1
end_operator
begin_operator
debark car23 loc33
1
65 26
2
0 0 16 0
0 42 -1 26
1
end_operator
begin_operator
debark car23 loc34
1
65 27
2
0 0 16 0
0 42 -1 27
1
end_operator
begin_operator
debark car23 loc35
1
65 28
2
0 0 16 0
0 42 -1 28
1
end_operator
begin_operator
debark car23 loc36
1
65 29
2
0 0 16 0
0 42 -1 29
1
end_operator
begin_operator
debark car23 loc37
1
65 30
2
0 0 16 0
0 42 -1 30
1
end_operator
begin_operator
debark car23 loc38
1
65 31
2
0 0 16 0
0 42 -1 31
1
end_operator
begin_operator
debark car23 loc39
1
65 32
2
0 0 16 0
0 42 -1 32
1
end_operator
begin_operator
debark car23 loc4
1
65 33
2
0 0 16 0
0 42 -1 33
1
end_operator
begin_operator
debark car23 loc40
1
65 34
2
0 0 16 0
0 42 -1 34
1
end_operator
begin_operator
debark car23 loc41
1
65 35
2
0 0 16 0
0 42 -1 35
1
end_operator
begin_operator
debark car23 loc5
1
65 36
2
0 0 16 0
0 42 -1 36
1
end_operator
begin_operator
debark car23 loc6
1
65 37
2
0 0 16 0
0 42 -1 37
1
end_operator
begin_operator
debark car23 loc7
1
65 38
2
0 0 16 0
0 42 -1 38
1
end_operator
begin_operator
debark car23 loc8
1
65 39
2
0 0 16 0
0 42 -1 39
1
end_operator
begin_operator
debark car23 loc9
1
65 40
2
0 0 16 0
0 42 -1 40
1
end_operator
begin_operator
debark car24 loc1
1
65 0
2
0 0 17 0
0 54 -1 0
1
end_operator
begin_operator
debark car24 loc10
1
65 1
2
0 0 17 0
0 54 -1 1
1
end_operator
begin_operator
debark car24 loc11
1
65 2
2
0 0 17 0
0 54 -1 2
1
end_operator
begin_operator
debark car24 loc12
1
65 3
2
0 0 17 0
0 54 -1 3
1
end_operator
begin_operator
debark car24 loc13
1
65 4
2
0 0 17 0
0 54 -1 4
1
end_operator
begin_operator
debark car24 loc14
1
65 5
2
0 0 17 0
0 54 -1 5
1
end_operator
begin_operator
debark car24 loc15
1
65 6
2
0 0 17 0
0 54 -1 6
1
end_operator
begin_operator
debark car24 loc16
1
65 7
2
0 0 17 0
0 54 -1 7
1
end_operator
begin_operator
debark car24 loc17
1
65 8
2
0 0 17 0
0 54 -1 8
1
end_operator
begin_operator
debark car24 loc18
1
65 9
2
0 0 17 0
0 54 -1 9
1
end_operator
begin_operator
debark car24 loc19
1
65 10
2
0 0 17 0
0 54 -1 10
1
end_operator
begin_operator
debark car24 loc2
1
65 11
2
0 0 17 0
0 54 -1 11
1
end_operator
begin_operator
debark car24 loc20
1
65 12
2
0 0 17 0
0 54 -1 12
1
end_operator
begin_operator
debark car24 loc21
1
65 13
2
0 0 17 0
0 54 -1 13
1
end_operator
begin_operator
debark car24 loc22
1
65 14
2
0 0 17 0
0 54 -1 14
1
end_operator
begin_operator
debark car24 loc23
1
65 15
2
0 0 17 0
0 54 -1 15
1
end_operator
begin_operator
debark car24 loc24
1
65 16
2
0 0 17 0
0 54 -1 16
1
end_operator
begin_operator
debark car24 loc25
1
65 17
2
0 0 17 0
0 54 -1 17
1
end_operator
begin_operator
debark car24 loc26
1
65 18
2
0 0 17 0
0 54 -1 18
1
end_operator
begin_operator
debark car24 loc27
1
65 19
2
0 0 17 0
0 54 -1 19
1
end_operator
begin_operator
debark car24 loc28
1
65 20
2
0 0 17 0
0 54 -1 20
1
end_operator
begin_operator
debark car24 loc29
1
65 21
2
0 0 17 0
0 54 -1 21
1
end_operator
begin_operator
debark car24 loc3
1
65 22
2
0 0 17 0
0 54 -1 22
1
end_operator
begin_operator
debark car24 loc30
1
65 23
2
0 0 17 0
0 54 -1 23
1
end_operator
begin_operator
debark car24 loc31
1
65 24
2
0 0 17 0
0 54 -1 24
1
end_operator
begin_operator
debark car24 loc32
1
65 25
2
0 0 17 0
0 54 -1 25
1
end_operator
begin_operator
debark car24 loc33
1
65 26
2
0 0 17 0
0 54 -1 26
1
end_operator
begin_operator
debark car24 loc34
1
65 27
2
0 0 17 0
0 54 -1 27
1
end_operator
begin_operator
debark car24 loc35
1
65 28
2
0 0 17 0
0 54 -1 28
1
end_operator
begin_operator
debark car24 loc36
1
65 29
2
0 0 17 0
0 54 -1 29
1
end_operator
begin_operator
debark car24 loc37
1
65 30
2
0 0 17 0
0 54 -1 30
1
end_operator
begin_operator
debark car24 loc38
1
65 31
2
0 0 17 0
0 54 -1 31
1
end_operator
begin_operator
debark car24 loc39
1
65 32
2
0 0 17 0
0 54 -1 32
1
end_operator
begin_operator
debark car24 loc4
1
65 33
2
0 0 17 0
0 54 -1 33
1
end_operator
begin_operator
debark car24 loc40
1
65 34
2
0 0 17 0
0 54 -1 34
1
end_operator
begin_operator
debark car24 loc41
1
65 35
2
0 0 17 0
0 54 -1 35
1
end_operator
begin_operator
debark car24 loc5
1
65 36
2
0 0 17 0
0 54 -1 36
1
end_operator
begin_operator
debark car24 loc6
1
65 37
2
0 0 17 0
0 54 -1 37
1
end_operator
begin_operator
debark car24 loc7
1
65 38
2
0 0 17 0
0 54 -1 38
1
end_operator
begin_operator
debark car24 loc8
1
65 39
2
0 0 17 0
0 54 -1 39
1
end_operator
begin_operator
debark car24 loc9
1
65 40
2
0 0 17 0
0 54 -1 40
1
end_operator
begin_operator
debark car25 loc1
1
65 0
2
0 0 18 0
0 66 -1 0
1
end_operator
begin_operator
debark car25 loc10
1
65 1
2
0 0 18 0
0 66 -1 1
1
end_operator
begin_operator
debark car25 loc11
1
65 2
2
0 0 18 0
0 66 -1 2
1
end_operator
begin_operator
debark car25 loc12
1
65 3
2
0 0 18 0
0 66 -1 3
1
end_operator
begin_operator
debark car25 loc13
1
65 4
2
0 0 18 0
0 66 -1 4
1
end_operator
begin_operator
debark car25 loc14
1
65 5
2
0 0 18 0
0 66 -1 5
1
end_operator
begin_operator
debark car25 loc15
1
65 6
2
0 0 18 0
0 66 -1 6
1
end_operator
begin_operator
debark car25 loc16
1
65 7
2
0 0 18 0
0 66 -1 7
1
end_operator
begin_operator
debark car25 loc17
1
65 8
2
0 0 18 0
0 66 -1 8
1
end_operator
begin_operator
debark car25 loc18
1
65 9
2
0 0 18 0
0 66 -1 9
1
end_operator
begin_operator
debark car25 loc19
1
65 10
2
0 0 18 0
0 66 -1 10
1
end_operator
begin_operator
debark car25 loc2
1
65 11
2
0 0 18 0
0 66 -1 11
1
end_operator
begin_operator
debark car25 loc20
1
65 12
2
0 0 18 0
0 66 -1 12
1
end_operator
begin_operator
debark car25 loc21
1
65 13
2
0 0 18 0
0 66 -1 13
1
end_operator
begin_operator
debark car25 loc22
1
65 14
2
0 0 18 0
0 66 -1 14
1
end_operator
begin_operator
debark car25 loc23
1
65 15
2
0 0 18 0
0 66 -1 15
1
end_operator
begin_operator
debark car25 loc24
1
65 16
2
0 0 18 0
0 66 -1 16
1
end_operator
begin_operator
debark car25 loc25
1
65 17
2
0 0 18 0
0 66 -1 17
1
end_operator
begin_operator
debark car25 loc26
1
65 18
2
0 0 18 0
0 66 -1 18
1
end_operator
begin_operator
debark car25 loc27
1
65 19
2
0 0 18 0
0 66 -1 19
1
end_operator
begin_operator
debark car25 loc28
1
65 20
2
0 0 18 0
0 66 -1 20
1
end_operator
begin_operator
debark car25 loc29
1
65 21
2
0 0 18 0
0 66 -1 21
1
end_operator
begin_operator
debark car25 loc3
1
65 22
2
0 0 18 0
0 66 -1 22
1
end_operator
begin_operator
debark car25 loc30
1
65 23
2
0 0 18 0
0 66 -1 23
1
end_operator
begin_operator
debark car25 loc31
1
65 24
2
0 0 18 0
0 66 -1 24
1
end_operator
begin_operator
debark car25 loc32
1
65 25
2
0 0 18 0
0 66 -1 25
1
end_operator
begin_operator
debark car25 loc33
1
65 26
2
0 0 18 0
0 66 -1 26
1
end_operator
begin_operator
debark car25 loc34
1
65 27
2
0 0 18 0
0 66 -1 27
1
end_operator
begin_operator
debark car25 loc35
1
65 28
2
0 0 18 0
0 66 -1 28
1
end_operator
begin_operator
debark car25 loc36
1
65 29
2
0 0 18 0
0 66 -1 29
1
end_operator
begin_operator
debark car25 loc37
1
65 30
2
0 0 18 0
0 66 -1 30
1
end_operator
begin_operator
debark car25 loc38
1
65 31
2
0 0 18 0
0 66 -1 31
1
end_operator
begin_operator
debark car25 loc39
1
65 32
2
0 0 18 0
0 66 -1 32
1
end_operator
begin_operator
debark car25 loc4
1
65 33
2
0 0 18 0
0 66 -1 33
1
end_operator
begin_operator
debark car25 loc40
1
65 34
2
0 0 18 0
0 66 -1 34
1
end_operator
begin_operator
debark car25 loc41
1
65 35
2
0 0 18 0
0 66 -1 35
1
end_operator
begin_operator
debark car25 loc5
1
65 36
2
0 0 18 0
0 66 -1 36
1
end_operator
begin_operator
debark car25 loc6
1
65 37
2
0 0 18 0
0 66 -1 37
1
end_operator
begin_operator
debark car25 loc7
1
65 38
2
0 0 18 0
0 66 -1 38
1
end_operator
begin_operator
debark car25 loc8
1
65 39
2
0 0 18 0
0 66 -1 39
1
end_operator
begin_operator
debark car25 loc9
1
65 40
2
0 0 18 0
0 66 -1 40
1
end_operator
begin_operator
debark car26 loc1
1
65 0
2
0 0 19 0
0 3 -1 0
1
end_operator
begin_operator
debark car26 loc10
1
65 1
2
0 0 19 0
0 3 -1 1
1
end_operator
begin_operator
debark car26 loc11
1
65 2
2
0 0 19 0
0 3 -1 2
1
end_operator
begin_operator
debark car26 loc12
1
65 3
2
0 0 19 0
0 3 -1 3
1
end_operator
begin_operator
debark car26 loc13
1
65 4
2
0 0 19 0
0 3 -1 4
1
end_operator
begin_operator
debark car26 loc14
1
65 5
2
0 0 19 0
0 3 -1 5
1
end_operator
begin_operator
debark car26 loc15
1
65 6
2
0 0 19 0
0 3 -1 6
1
end_operator
begin_operator
debark car26 loc16
1
65 7
2
0 0 19 0
0 3 -1 7
1
end_operator
begin_operator
debark car26 loc17
1
65 8
2
0 0 19 0
0 3 -1 8
1
end_operator
begin_operator
debark car26 loc18
1
65 9
2
0 0 19 0
0 3 -1 9
1
end_operator
begin_operator
debark car26 loc19
1
65 10
2
0 0 19 0
0 3 -1 10
1
end_operator
begin_operator
debark car26 loc2
1
65 11
2
0 0 19 0
0 3 -1 11
1
end_operator
begin_operator
debark car26 loc20
1
65 12
2
0 0 19 0
0 3 -1 12
1
end_operator
begin_operator
debark car26 loc21
1
65 13
2
0 0 19 0
0 3 -1 13
1
end_operator
begin_operator
debark car26 loc22
1
65 14
2
0 0 19 0
0 3 -1 14
1
end_operator
begin_operator
debark car26 loc23
1
65 15
2
0 0 19 0
0 3 -1 15
1
end_operator
begin_operator
debark car26 loc24
1
65 16
2
0 0 19 0
0 3 -1 16
1
end_operator
begin_operator
debark car26 loc25
1
65 17
2
0 0 19 0
0 3 -1 17
1
end_operator
begin_operator
debark car26 loc26
1
65 18
2
0 0 19 0
0 3 -1 18
1
end_operator
begin_operator
debark car26 loc27
1
65 19
2
0 0 19 0
0 3 -1 19
1
end_operator
begin_operator
debark car26 loc28
1
65 20
2
0 0 19 0
0 3 -1 20
1
end_operator
begin_operator
debark car26 loc29
1
65 21
2
0 0 19 0
0 3 -1 21
1
end_operator
begin_operator
debark car26 loc3
1
65 22
2
0 0 19 0
0 3 -1 22
1
end_operator
begin_operator
debark car26 loc30
1
65 23
2
0 0 19 0
0 3 -1 23
1
end_operator
begin_operator
debark car26 loc31
1
65 24
2
0 0 19 0
0 3 -1 24
1
end_operator
begin_operator
debark car26 loc32
1
65 25
2
0 0 19 0
0 3 -1 25
1
end_operator
begin_operator
debark car26 loc33
1
65 26
2
0 0 19 0
0 3 -1 26
1
end_operator
begin_operator
debark car26 loc34
1
65 27
2
0 0 19 0
0 3 -1 27
1
end_operator
begin_operator
debark car26 loc35
1
65 28
2
0 0 19 0
0 3 -1 28
1
end_operator
begin_operator
debark car26 loc36
1
65 29
2
0 0 19 0
0 3 -1 29
1
end_operator
begin_operator
debark car26 loc37
1
65 30
2
0 0 19 0
0 3 -1 30
1
end_operator
begin_operator
debark car26 loc38
1
65 31
2
0 0 19 0
0 3 -1 31
1
end_operator
begin_operator
debark car26 loc39
1
65 32
2
0 0 19 0
0 3 -1 32
1
end_operator
begin_operator
debark car26 loc4
1
65 33
2
0 0 19 0
0 3 -1 33
1
end_operator
begin_operator
debark car26 loc40
1
65 34
2
0 0 19 0
0 3 -1 34
1
end_operator
begin_operator
debark car26 loc41
1
65 35
2
0 0 19 0
0 3 -1 35
1
end_operator
begin_operator
debark car26 loc5
1
65 36
2
0 0 19 0
0 3 -1 36
1
end_operator
begin_operator
debark car26 loc6
1
65 37
2
0 0 19 0
0 3 -1 37
1
end_operator
begin_operator
debark car26 loc7
1
65 38
2
0 0 19 0
0 3 -1 38
1
end_operator
begin_operator
debark car26 loc8
1
65 39
2
0 0 19 0
0 3 -1 39
1
end_operator
begin_operator
debark car26 loc9
1
65 40
2
0 0 19 0
0 3 -1 40
1
end_operator
begin_operator
debark car27 loc1
1
65 0
2
0 0 20 0
0 15 -1 0
1
end_operator
begin_operator
debark car27 loc10
1
65 1
2
0 0 20 0
0 15 -1 1
1
end_operator
begin_operator
debark car27 loc11
1
65 2
2
0 0 20 0
0 15 -1 2
1
end_operator
begin_operator
debark car27 loc12
1
65 3
2
0 0 20 0
0 15 -1 3
1
end_operator
begin_operator
debark car27 loc13
1
65 4
2
0 0 20 0
0 15 -1 4
1
end_operator
begin_operator
debark car27 loc14
1
65 5
2
0 0 20 0
0 15 -1 5
1
end_operator
begin_operator
debark car27 loc15
1
65 6
2
0 0 20 0
0 15 -1 6
1
end_operator
begin_operator
debark car27 loc16
1
65 7
2
0 0 20 0
0 15 -1 7
1
end_operator
begin_operator
debark car27 loc17
1
65 8
2
0 0 20 0
0 15 -1 8
1
end_operator
begin_operator
debark car27 loc18
1
65 9
2
0 0 20 0
0 15 -1 9
1
end_operator
begin_operator
debark car27 loc19
1
65 10
2
0 0 20 0
0 15 -1 10
1
end_operator
begin_operator
debark car27 loc2
1
65 11
2
0 0 20 0
0 15 -1 11
1
end_operator
begin_operator
debark car27 loc20
1
65 12
2
0 0 20 0
0 15 -1 12
1
end_operator
begin_operator
debark car27 loc21
1
65 13
2
0 0 20 0
0 15 -1 13
1
end_operator
begin_operator
debark car27 loc22
1
65 14
2
0 0 20 0
0 15 -1 14
1
end_operator
begin_operator
debark car27 loc23
1
65 15
2
0 0 20 0
0 15 -1 15
1
end_operator
begin_operator
debark car27 loc24
1
65 16
2
0 0 20 0
0 15 -1 16
1
end_operator
begin_operator
debark car27 loc25
1
65 17
2
0 0 20 0
0 15 -1 17
1
end_operator
begin_operator
debark car27 loc26
1
65 18
2
0 0 20 0
0 15 -1 18
1
end_operator
begin_operator
debark car27 loc27
1
65 19
2
0 0 20 0
0 15 -1 19
1
end_operator
begin_operator
debark car27 loc28
1
65 20
2
0 0 20 0
0 15 -1 20
1
end_operator
begin_operator
debark car27 loc29
1
65 21
2
0 0 20 0
0 15 -1 21
1
end_operator
begin_operator
debark car27 loc3
1
65 22
2
0 0 20 0
0 15 -1 22
1
end_operator
begin_operator
debark car27 loc30
1
65 23
2
0 0 20 0
0 15 -1 23
1
end_operator
begin_operator
debark car27 loc31
1
65 24
2
0 0 20 0
0 15 -1 24
1
end_operator
begin_operator
debark car27 loc32
1
65 25
2
0 0 20 0
0 15 -1 25
1
end_operator
begin_operator
debark car27 loc33
1
65 26
2
0 0 20 0
0 15 -1 26
1
end_operator
begin_operator
debark car27 loc34
1
65 27
2
0 0 20 0
0 15 -1 27
1
end_operator
begin_operator
debark car27 loc35
1
65 28
2
0 0 20 0
0 15 -1 28
1
end_operator
begin_operator
debark car27 loc36
1
65 29
2
0 0 20 0
0 15 -1 29
1
end_operator
begin_operator
debark car27 loc37
1
65 30
2
0 0 20 0
0 15 -1 30
1
end_operator
begin_operator
debark car27 loc38
1
65 31
2
0 0 20 0
0 15 -1 31
1
end_operator
begin_operator
debark car27 loc39
1
65 32
2
0 0 20 0
0 15 -1 32
1
end_operator
begin_operator
debark car27 loc4
1
65 33
2
0 0 20 0
0 15 -1 33
1
end_operator
begin_operator
debark car27 loc40
1
65 34
2
0 0 20 0
0 15 -1 34
1
end_operator
begin_operator
debark car27 loc41
1
65 35
2
0 0 20 0
0 15 -1 35
1
end_operator
begin_operator
debark car27 loc5
1
65 36
2
0 0 20 0
0 15 -1 36
1
end_operator
begin_operator
debark car27 loc6
1
65 37
2
0 0 20 0
0 15 -1 37
1
end_operator
begin_operator
debark car27 loc7
1
65 38
2
0 0 20 0
0 15 -1 38
1
end_operator
begin_operator
debark car27 loc8
1
65 39
2
0 0 20 0
0 15 -1 39
1
end_operator
begin_operator
debark car27 loc9
1
65 40
2
0 0 20 0
0 15 -1 40
1
end_operator
begin_operator
debark car28 loc1
1
65 0
2
0 0 21 0
0 27 -1 0
1
end_operator
begin_operator
debark car28 loc10
1
65 1
2
0 0 21 0
0 27 -1 1
1
end_operator
begin_operator
debark car28 loc11
1
65 2
2
0 0 21 0
0 27 -1 2
1
end_operator
begin_operator
debark car28 loc12
1
65 3
2
0 0 21 0
0 27 -1 3
1
end_operator
begin_operator
debark car28 loc13
1
65 4
2
0 0 21 0
0 27 -1 4
1
end_operator
begin_operator
debark car28 loc14
1
65 5
2
0 0 21 0
0 27 -1 5
1
end_operator
begin_operator
debark car28 loc15
1
65 6
2
0 0 21 0
0 27 -1 6
1
end_operator
begin_operator
debark car28 loc16
1
65 7
2
0 0 21 0
0 27 -1 7
1
end_operator
begin_operator
debark car28 loc17
1
65 8
2
0 0 21 0
0 27 -1 8
1
end_operator
begin_operator
debark car28 loc18
1
65 9
2
0 0 21 0
0 27 -1 9
1
end_operator
begin_operator
debark car28 loc19
1
65 10
2
0 0 21 0
0 27 -1 10
1
end_operator
begin_operator
debark car28 loc2
1
65 11
2
0 0 21 0
0 27 -1 11
1
end_operator
begin_operator
debark car28 loc20
1
65 12
2
0 0 21 0
0 27 -1 12
1
end_operator
begin_operator
debark car28 loc21
1
65 13
2
0 0 21 0
0 27 -1 13
1
end_operator
begin_operator
debark car28 loc22
1
65 14
2
0 0 21 0
0 27 -1 14
1
end_operator
begin_operator
debark car28 loc23
1
65 15
2
0 0 21 0
0 27 -1 15
1
end_operator
begin_operator
debark car28 loc24
1
65 16
2
0 0 21 0
0 27 -1 16
1
end_operator
begin_operator
debark car28 loc25
1
65 17
2
0 0 21 0
0 27 -1 17
1
end_operator
begin_operator
debark car28 loc26
1
65 18
2
0 0 21 0
0 27 -1 18
1
end_operator
begin_operator
debark car28 loc27
1
65 19
2
0 0 21 0
0 27 -1 19
1
end_operator
begin_operator
debark car28 loc28
1
65 20
2
0 0 21 0
0 27 -1 20
1
end_operator
begin_operator
debark car28 loc29
1
65 21
2
0 0 21 0
0 27 -1 21
1
end_operator
begin_operator
debark car28 loc3
1
65 22
2
0 0 21 0
0 27 -1 22
1
end_operator
begin_operator
debark car28 loc30
1
65 23
2
0 0 21 0
0 27 -1 23
1
end_operator
begin_operator
debark car28 loc31
1
65 24
2
0 0 21 0
0 27 -1 24
1
end_operator
begin_operator
debark car28 loc32
1
65 25
2
0 0 21 0
0 27 -1 25
1
end_operator
begin_operator
debark car28 loc33
1
65 26
2
0 0 21 0
0 27 -1 26
1
end_operator
begin_operator
debark car28 loc34
1
65 27
2
0 0 21 0
0 27 -1 27
1
end_operator
begin_operator
debark car28 loc35
1
65 28
2
0 0 21 0
0 27 -1 28
1
end_operator
begin_operator
debark car28 loc36
1
65 29
2
0 0 21 0
0 27 -1 29
1
end_operator
begin_operator
debark car28 loc37
1
65 30
2
0 0 21 0
0 27 -1 30
1
end_operator
begin_operator
debark car28 loc38
1
65 31
2
0 0 21 0
0 27 -1 31
1
end_operator
begin_operator
debark car28 loc39
1
65 32
2
0 0 21 0
0 27 -1 32
1
end_operator
begin_operator
debark car28 loc4
1
65 33
2
0 0 21 0
0 27 -1 33
1
end_operator
begin_operator
debark car28 loc40
1
65 34
2
0 0 21 0
0 27 -1 34
1
end_operator
begin_operator
debark car28 loc41
1
65 35
2
0 0 21 0
0 27 -1 35
1
end_operator
begin_operator
debark car28 loc5
1
65 36
2
0 0 21 0
0 27 -1 36
1
end_operator
begin_operator
debark car28 loc6
1
65 37
2
0 0 21 0
0 27 -1 37
1
end_operator
begin_operator
debark car28 loc7
1
65 38
2
0 0 21 0
0 27 -1 38
1
end_operator
begin_operator
debark car28 loc8
1
65 39
2
0 0 21 0
0 27 -1 39
1
end_operator
begin_operator
debark car28 loc9
1
65 40
2
0 0 21 0
0 27 -1 40
1
end_operator
begin_operator
debark car29 loc1
1
65 0
2
0 0 22 0
0 39 -1 0
1
end_operator
begin_operator
debark car29 loc10
1
65 1
2
0 0 22 0
0 39 -1 1
1
end_operator
begin_operator
debark car29 loc11
1
65 2
2
0 0 22 0
0 39 -1 2
1
end_operator
begin_operator
debark car29 loc12
1
65 3
2
0 0 22 0
0 39 -1 3
1
end_operator
begin_operator
debark car29 loc13
1
65 4
2
0 0 22 0
0 39 -1 4
1
end_operator
begin_operator
debark car29 loc14
1
65 5
2
0 0 22 0
0 39 -1 5
1
end_operator
begin_operator
debark car29 loc15
1
65 6
2
0 0 22 0
0 39 -1 6
1
end_operator
begin_operator
debark car29 loc16
1
65 7
2
0 0 22 0
0 39 -1 7
1
end_operator
begin_operator
debark car29 loc17
1
65 8
2
0 0 22 0
0 39 -1 8
1
end_operator
begin_operator
debark car29 loc18
1
65 9
2
0 0 22 0
0 39 -1 9
1
end_operator
begin_operator
debark car29 loc19
1
65 10
2
0 0 22 0
0 39 -1 10
1
end_operator
begin_operator
debark car29 loc2
1
65 11
2
0 0 22 0
0 39 -1 11
1
end_operator
begin_operator
debark car29 loc20
1
65 12
2
0 0 22 0
0 39 -1 12
1
end_operator
begin_operator
debark car29 loc21
1
65 13
2
0 0 22 0
0 39 -1 13
1
end_operator
begin_operator
debark car29 loc22
1
65 14
2
0 0 22 0
0 39 -1 14
1
end_operator
begin_operator
debark car29 loc23
1
65 15
2
0 0 22 0
0 39 -1 15
1
end_operator
begin_operator
debark car29 loc24
1
65 16
2
0 0 22 0
0 39 -1 16
1
end_operator
begin_operator
debark car29 loc25
1
65 17
2
0 0 22 0
0 39 -1 17
1
end_operator
begin_operator
debark car29 loc26
1
65 18
2
0 0 22 0
0 39 -1 18
1
end_operator
begin_operator
debark car29 loc27
1
65 19
2
0 0 22 0
0 39 -1 19
1
end_operator
begin_operator
debark car29 loc28
1
65 20
2
0 0 22 0
0 39 -1 20
1
end_operator
begin_operator
debark car29 loc29
1
65 21
2
0 0 22 0
0 39 -1 21
1
end_operator
begin_operator
debark car29 loc3
1
65 22
2
0 0 22 0
0 39 -1 22
1
end_operator
begin_operator
debark car29 loc30
1
65 23
2
0 0 22 0
0 39 -1 23
1
end_operator
begin_operator
debark car29 loc31
1
65 24
2
0 0 22 0
0 39 -1 24
1
end_operator
begin_operator
debark car29 loc32
1
65 25
2
0 0 22 0
0 39 -1 25
1
end_operator
begin_operator
debark car29 loc33
1
65 26
2
0 0 22 0
0 39 -1 26
1
end_operator
begin_operator
debark car29 loc34
1
65 27
2
0 0 22 0
0 39 -1 27
1
end_operator
begin_operator
debark car29 loc35
1
65 28
2
0 0 22 0
0 39 -1 28
1
end_operator
begin_operator
debark car29 loc36
1
65 29
2
0 0 22 0
0 39 -1 29
1
end_operator
begin_operator
debark car29 loc37
1
65 30
2
0 0 22 0
0 39 -1 30
1
end_operator
begin_operator
debark car29 loc38
1
65 31
2
0 0 22 0
0 39 -1 31
1
end_operator
begin_operator
debark car29 loc39
1
65 32
2
0 0 22 0
0 39 -1 32
1
end_operator
begin_operator
debark car29 loc4
1
65 33
2
0 0 22 0
0 39 -1 33
1
end_operator
begin_operator
debark car29 loc40
1
65 34
2
0 0 22 0
0 39 -1 34
1
end_operator
begin_operator
debark car29 loc41
1
65 35
2
0 0 22 0
0 39 -1 35
1
end_operator
begin_operator
debark car29 loc5
1
65 36
2
0 0 22 0
0 39 -1 36
1
end_operator
begin_operator
debark car29 loc6
1
65 37
2
0 0 22 0
0 39 -1 37
1
end_operator
begin_operator
debark car29 loc7
1
65 38
2
0 0 22 0
0 39 -1 38
1
end_operator
begin_operator
debark car29 loc8
1
65 39
2
0 0 22 0
0 39 -1 39
1
end_operator
begin_operator
debark car29 loc9
1
65 40
2
0 0 22 0
0 39 -1 40
1
end_operator
begin_operator
debark car3 loc1
1
65 0
2
0 0 23 0
0 51 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
65 1
2
0 0 23 0
0 51 -1 1
1
end_operator
begin_operator
debark car3 loc11
1
65 2
2
0 0 23 0
0 51 -1 2
1
end_operator
begin_operator
debark car3 loc12
1
65 3
2
0 0 23 0
0 51 -1 3
1
end_operator
begin_operator
debark car3 loc13
1
65 4
2
0 0 23 0
0 51 -1 4
1
end_operator
begin_operator
debark car3 loc14
1
65 5
2
0 0 23 0
0 51 -1 5
1
end_operator
begin_operator
debark car3 loc15
1
65 6
2
0 0 23 0
0 51 -1 6
1
end_operator
begin_operator
debark car3 loc16
1
65 7
2
0 0 23 0
0 51 -1 7
1
end_operator
begin_operator
debark car3 loc17
1
65 8
2
0 0 23 0
0 51 -1 8
1
end_operator
begin_operator
debark car3 loc18
1
65 9
2
0 0 23 0
0 51 -1 9
1
end_operator
begin_operator
debark car3 loc19
1
65 10
2
0 0 23 0
0 51 -1 10
1
end_operator
begin_operator
debark car3 loc2
1
65 11
2
0 0 23 0
0 51 -1 11
1
end_operator
begin_operator
debark car3 loc20
1
65 12
2
0 0 23 0
0 51 -1 12
1
end_operator
begin_operator
debark car3 loc21
1
65 13
2
0 0 23 0
0 51 -1 13
1
end_operator
begin_operator
debark car3 loc22
1
65 14
2
0 0 23 0
0 51 -1 14
1
end_operator
begin_operator
debark car3 loc23
1
65 15
2
0 0 23 0
0 51 -1 15
1
end_operator
begin_operator
debark car3 loc24
1
65 16
2
0 0 23 0
0 51 -1 16
1
end_operator
begin_operator
debark car3 loc25
1
65 17
2
0 0 23 0
0 51 -1 17
1
end_operator
begin_operator
debark car3 loc26
1
65 18
2
0 0 23 0
0 51 -1 18
1
end_operator
begin_operator
debark car3 loc27
1
65 19
2
0 0 23 0
0 51 -1 19
1
end_operator
begin_operator
debark car3 loc28
1
65 20
2
0 0 23 0
0 51 -1 20
1
end_operator
begin_operator
debark car3 loc29
1
65 21
2
0 0 23 0
0 51 -1 21
1
end_operator
begin_operator
debark car3 loc3
1
65 22
2
0 0 23 0
0 51 -1 22
1
end_operator
begin_operator
debark car3 loc30
1
65 23
2
0 0 23 0
0 51 -1 23
1
end_operator
begin_operator
debark car3 loc31
1
65 24
2
0 0 23 0
0 51 -1 24
1
end_operator
begin_operator
debark car3 loc32
1
65 25
2
0 0 23 0
0 51 -1 25
1
end_operator
begin_operator
debark car3 loc33
1
65 26
2
0 0 23 0
0 51 -1 26
1
end_operator
begin_operator
debark car3 loc34
1
65 27
2
0 0 23 0
0 51 -1 27
1
end_operator
begin_operator
debark car3 loc35
1
65 28
2
0 0 23 0
0 51 -1 28
1
end_operator
begin_operator
debark car3 loc36
1
65 29
2
0 0 23 0
0 51 -1 29
1
end_operator
begin_operator
debark car3 loc37
1
65 30
2
0 0 23 0
0 51 -1 30
1
end_operator
begin_operator
debark car3 loc38
1
65 31
2
0 0 23 0
0 51 -1 31
1
end_operator
begin_operator
debark car3 loc39
1
65 32
2
0 0 23 0
0 51 -1 32
1
end_operator
begin_operator
debark car3 loc4
1
65 33
2
0 0 23 0
0 51 -1 33
1
end_operator
begin_operator
debark car3 loc40
1
65 34
2
0 0 23 0
0 51 -1 34
1
end_operator
begin_operator
debark car3 loc41
1
65 35
2
0 0 23 0
0 51 -1 35
1
end_operator
begin_operator
debark car3 loc5
1
65 36
2
0 0 23 0
0 51 -1 36
1
end_operator
begin_operator
debark car3 loc6
1
65 37
2
0 0 23 0
0 51 -1 37
1
end_operator
begin_operator
debark car3 loc7
1
65 38
2
0 0 23 0
0 51 -1 38
1
end_operator
begin_operator
debark car3 loc8
1
65 39
2
0 0 23 0
0 51 -1 39
1
end_operator
begin_operator
debark car3 loc9
1
65 40
2
0 0 23 0
0 51 -1 40
1
end_operator
begin_operator
debark car30 loc1
1
65 0
2
0 0 24 0
0 63 -1 0
1
end_operator
begin_operator
debark car30 loc10
1
65 1
2
0 0 24 0
0 63 -1 1
1
end_operator
begin_operator
debark car30 loc11
1
65 2
2
0 0 24 0
0 63 -1 2
1
end_operator
begin_operator
debark car30 loc12
1
65 3
2
0 0 24 0
0 63 -1 3
1
end_operator
begin_operator
debark car30 loc13
1
65 4
2
0 0 24 0
0 63 -1 4
1
end_operator
begin_operator
debark car30 loc14
1
65 5
2
0 0 24 0
0 63 -1 5
1
end_operator
begin_operator
debark car30 loc15
1
65 6
2
0 0 24 0
0 63 -1 6
1
end_operator
begin_operator
debark car30 loc16
1
65 7
2
0 0 24 0
0 63 -1 7
1
end_operator
begin_operator
debark car30 loc17
1
65 8
2
0 0 24 0
0 63 -1 8
1
end_operator
begin_operator
debark car30 loc18
1
65 9
2
0 0 24 0
0 63 -1 9
1
end_operator
begin_operator
debark car30 loc19
1
65 10
2
0 0 24 0
0 63 -1 10
1
end_operator
begin_operator
debark car30 loc2
1
65 11
2
0 0 24 0
0 63 -1 11
1
end_operator
begin_operator
debark car30 loc20
1
65 12
2
0 0 24 0
0 63 -1 12
1
end_operator
begin_operator
debark car30 loc21
1
65 13
2
0 0 24 0
0 63 -1 13
1
end_operator
begin_operator
debark car30 loc22
1
65 14
2
0 0 24 0
0 63 -1 14
1
end_operator
begin_operator
debark car30 loc23
1
65 15
2
0 0 24 0
0 63 -1 15
1
end_operator
begin_operator
debark car30 loc24
1
65 16
2
0 0 24 0
0 63 -1 16
1
end_operator
begin_operator
debark car30 loc25
1
65 17
2
0 0 24 0
0 63 -1 17
1
end_operator
begin_operator
debark car30 loc26
1
65 18
2
0 0 24 0
0 63 -1 18
1
end_operator
begin_operator
debark car30 loc27
1
65 19
2
0 0 24 0
0 63 -1 19
1
end_operator
begin_operator
debark car30 loc28
1
65 20
2
0 0 24 0
0 63 -1 20
1
end_operator
begin_operator
debark car30 loc29
1
65 21
2
0 0 24 0
0 63 -1 21
1
end_operator
begin_operator
debark car30 loc3
1
65 22
2
0 0 24 0
0 63 -1 22
1
end_operator
begin_operator
debark car30 loc30
1
65 23
2
0 0 24 0
0 63 -1 23
1
end_operator
begin_operator
debark car30 loc31
1
65 24
2
0 0 24 0
0 63 -1 24
1
end_operator
begin_operator
debark car30 loc32
1
65 25
2
0 0 24 0
0 63 -1 25
1
end_operator
begin_operator
debark car30 loc33
1
65 26
2
0 0 24 0
0 63 -1 26
1
end_operator
begin_operator
debark car30 loc34
1
65 27
2
0 0 24 0
0 63 -1 27
1
end_operator
begin_operator
debark car30 loc35
1
65 28
2
0 0 24 0
0 63 -1 28
1
end_operator
begin_operator
debark car30 loc36
1
65 29
2
0 0 24 0
0 63 -1 29
1
end_operator
begin_operator
debark car30 loc37
1
65 30
2
0 0 24 0
0 63 -1 30
1
end_operator
begin_operator
debark car30 loc38
1
65 31
2
0 0 24 0
0 63 -1 31
1
end_operator
begin_operator
debark car30 loc39
1
65 32
2
0 0 24 0
0 63 -1 32
1
end_operator
begin_operator
debark car30 loc4
1
65 33
2
0 0 24 0
0 63 -1 33
1
end_operator
begin_operator
debark car30 loc40
1
65 34
2
0 0 24 0
0 63 -1 34
1
end_operator
begin_operator
debark car30 loc41
1
65 35
2
0 0 24 0
0 63 -1 35
1
end_operator
begin_operator
debark car30 loc5
1
65 36
2
0 0 24 0
0 63 -1 36
1
end_operator
begin_operator
debark car30 loc6
1
65 37
2
0 0 24 0
0 63 -1 37
1
end_operator
begin_operator
debark car30 loc7
1
65 38
2
0 0 24 0
0 63 -1 38
1
end_operator
begin_operator
debark car30 loc8
1
65 39
2
0 0 24 0
0 63 -1 39
1
end_operator
begin_operator
debark car30 loc9
1
65 40
2
0 0 24 0
0 63 -1 40
1
end_operator
begin_operator
debark car31 loc1
1
65 0
2
0 0 25 0
0 1 -1 0
1
end_operator
begin_operator
debark car31 loc10
1
65 1
2
0 0 25 0
0 1 -1 1
1
end_operator
begin_operator
debark car31 loc11
1
65 2
2
0 0 25 0
0 1 -1 2
1
end_operator
begin_operator
debark car31 loc12
1
65 3
2
0 0 25 0
0 1 -1 3
1
end_operator
begin_operator
debark car31 loc13
1
65 4
2
0 0 25 0
0 1 -1 4
1
end_operator
begin_operator
debark car31 loc14
1
65 5
2
0 0 25 0
0 1 -1 5
1
end_operator
begin_operator
debark car31 loc15
1
65 6
2
0 0 25 0
0 1 -1 6
1
end_operator
begin_operator
debark car31 loc16
1
65 7
2
0 0 25 0
0 1 -1 7
1
end_operator
begin_operator
debark car31 loc17
1
65 8
2
0 0 25 0
0 1 -1 8
1
end_operator
begin_operator
debark car31 loc18
1
65 9
2
0 0 25 0
0 1 -1 9
1
end_operator
begin_operator
debark car31 loc19
1
65 10
2
0 0 25 0
0 1 -1 10
1
end_operator
begin_operator
debark car31 loc2
1
65 11
2
0 0 25 0
0 1 -1 11
1
end_operator
begin_operator
debark car31 loc20
1
65 12
2
0 0 25 0
0 1 -1 12
1
end_operator
begin_operator
debark car31 loc21
1
65 13
2
0 0 25 0
0 1 -1 13
1
end_operator
begin_operator
debark car31 loc22
1
65 14
2
0 0 25 0
0 1 -1 14
1
end_operator
begin_operator
debark car31 loc23
1
65 15
2
0 0 25 0
0 1 -1 15
1
end_operator
begin_operator
debark car31 loc24
1
65 16
2
0 0 25 0
0 1 -1 16
1
end_operator
begin_operator
debark car31 loc25
1
65 17
2
0 0 25 0
0 1 -1 17
1
end_operator
begin_operator
debark car31 loc26
1
65 18
2
0 0 25 0
0 1 -1 18
1
end_operator
begin_operator
debark car31 loc27
1
65 19
2
0 0 25 0
0 1 -1 19
1
end_operator
begin_operator
debark car31 loc28
1
65 20
2
0 0 25 0
0 1 -1 20
1
end_operator
begin_operator
debark car31 loc29
1
65 21
2
0 0 25 0
0 1 -1 21
1
end_operator
begin_operator
debark car31 loc3
1
65 22
2
0 0 25 0
0 1 -1 22
1
end_operator
begin_operator
debark car31 loc30
1
65 23
2
0 0 25 0
0 1 -1 23
1
end_operator
begin_operator
debark car31 loc31
1
65 24
2
0 0 25 0
0 1 -1 24
1
end_operator
begin_operator
debark car31 loc32
1
65 25
2
0 0 25 0
0 1 -1 25
1
end_operator
begin_operator
debark car31 loc33
1
65 26
2
0 0 25 0
0 1 -1 26
1
end_operator
begin_operator
debark car31 loc34
1
65 27
2
0 0 25 0
0 1 -1 27
1
end_operator
begin_operator
debark car31 loc35
1
65 28
2
0 0 25 0
0 1 -1 28
1
end_operator
begin_operator
debark car31 loc36
1
65 29
2
0 0 25 0
0 1 -1 29
1
end_operator
begin_operator
debark car31 loc37
1
65 30
2
0 0 25 0
0 1 -1 30
1
end_operator
begin_operator
debark car31 loc38
1
65 31
2
0 0 25 0
0 1 -1 31
1
end_operator
begin_operator
debark car31 loc39
1
65 32
2
0 0 25 0
0 1 -1 32
1
end_operator
begin_operator
debark car31 loc4
1
65 33
2
0 0 25 0
0 1 -1 33
1
end_operator
begin_operator
debark car31 loc40
1
65 34
2
0 0 25 0
0 1 -1 34
1
end_operator
begin_operator
debark car31 loc41
1
65 35
2
0 0 25 0
0 1 -1 35
1
end_operator
begin_operator
debark car31 loc5
1
65 36
2
0 0 25 0
0 1 -1 36
1
end_operator
begin_operator
debark car31 loc6
1
65 37
2
0 0 25 0
0 1 -1 37
1
end_operator
begin_operator
debark car31 loc7
1
65 38
2
0 0 25 0
0 1 -1 38
1
end_operator
begin_operator
debark car31 loc8
1
65 39
2
0 0 25 0
0 1 -1 39
1
end_operator
begin_operator
debark car31 loc9
1
65 40
2
0 0 25 0
0 1 -1 40
1
end_operator
begin_operator
debark car32 loc1
1
65 0
2
0 0 26 0
0 13 -1 0
1
end_operator
begin_operator
debark car32 loc10
1
65 1
2
0 0 26 0
0 13 -1 1
1
end_operator
begin_operator
debark car32 loc11
1
65 2
2
0 0 26 0
0 13 -1 2
1
end_operator
begin_operator
debark car32 loc12
1
65 3
2
0 0 26 0
0 13 -1 3
1
end_operator
begin_operator
debark car32 loc13
1
65 4
2
0 0 26 0
0 13 -1 4
1
end_operator
begin_operator
debark car32 loc14
1
65 5
2
0 0 26 0
0 13 -1 5
1
end_operator
begin_operator
debark car32 loc15
1
65 6
2
0 0 26 0
0 13 -1 6
1
end_operator
begin_operator
debark car32 loc16
1
65 7
2
0 0 26 0
0 13 -1 7
1
end_operator
begin_operator
debark car32 loc17
1
65 8
2
0 0 26 0
0 13 -1 8
1
end_operator
begin_operator
debark car32 loc18
1
65 9
2
0 0 26 0
0 13 -1 9
1
end_operator
begin_operator
debark car32 loc19
1
65 10
2
0 0 26 0
0 13 -1 10
1
end_operator
begin_operator
debark car32 loc2
1
65 11
2
0 0 26 0
0 13 -1 11
1
end_operator
begin_operator
debark car32 loc20
1
65 12
2
0 0 26 0
0 13 -1 12
1
end_operator
begin_operator
debark car32 loc21
1
65 13
2
0 0 26 0
0 13 -1 13
1
end_operator
begin_operator
debark car32 loc22
1
65 14
2
0 0 26 0
0 13 -1 14
1
end_operator
begin_operator
debark car32 loc23
1
65 15
2
0 0 26 0
0 13 -1 15
1
end_operator
begin_operator
debark car32 loc24
1
65 16
2
0 0 26 0
0 13 -1 16
1
end_operator
begin_operator
debark car32 loc25
1
65 17
2
0 0 26 0
0 13 -1 17
1
end_operator
begin_operator
debark car32 loc26
1
65 18
2
0 0 26 0
0 13 -1 18
1
end_operator
begin_operator
debark car32 loc27
1
65 19
2
0 0 26 0
0 13 -1 19
1
end_operator
begin_operator
debark car32 loc28
1
65 20
2
0 0 26 0
0 13 -1 20
1
end_operator
begin_operator
debark car32 loc29
1
65 21
2
0 0 26 0
0 13 -1 21
1
end_operator
begin_operator
debark car32 loc3
1
65 22
2
0 0 26 0
0 13 -1 22
1
end_operator
begin_operator
debark car32 loc30
1
65 23
2
0 0 26 0
0 13 -1 23
1
end_operator
begin_operator
debark car32 loc31
1
65 24
2
0 0 26 0
0 13 -1 24
1
end_operator
begin_operator
debark car32 loc32
1
65 25
2
0 0 26 0
0 13 -1 25
1
end_operator
begin_operator
debark car32 loc33
1
65 26
2
0 0 26 0
0 13 -1 26
1
end_operator
begin_operator
debark car32 loc34
1
65 27
2
0 0 26 0
0 13 -1 27
1
end_operator
begin_operator
debark car32 loc35
1
65 28
2
0 0 26 0
0 13 -1 28
1
end_operator
begin_operator
debark car32 loc36
1
65 29
2
0 0 26 0
0 13 -1 29
1
end_operator
begin_operator
debark car32 loc37
1
65 30
2
0 0 26 0
0 13 -1 30
1
end_operator
begin_operator
debark car32 loc38
1
65 31
2
0 0 26 0
0 13 -1 31
1
end_operator
begin_operator
debark car32 loc39
1
65 32
2
0 0 26 0
0 13 -1 32
1
end_operator
begin_operator
debark car32 loc4
1
65 33
2
0 0 26 0
0 13 -1 33
1
end_operator
begin_operator
debark car32 loc40
1
65 34
2
0 0 26 0
0 13 -1 34
1
end_operator
begin_operator
debark car32 loc41
1
65 35
2
0 0 26 0
0 13 -1 35
1
end_operator
begin_operator
debark car32 loc5
1
65 36
2
0 0 26 0
0 13 -1 36
1
end_operator
begin_operator
debark car32 loc6
1
65 37
2
0 0 26 0
0 13 -1 37
1
end_operator
begin_operator
debark car32 loc7
1
65 38
2
0 0 26 0
0 13 -1 38
1
end_operator
begin_operator
debark car32 loc8
1
65 39
2
0 0 26 0
0 13 -1 39
1
end_operator
begin_operator
debark car32 loc9
1
65 40
2
0 0 26 0
0 13 -1 40
1
end_operator
begin_operator
debark car33 loc1
1
65 0
2
0 0 27 0
0 25 -1 0
1
end_operator
begin_operator
debark car33 loc10
1
65 1
2
0 0 27 0
0 25 -1 1
1
end_operator
begin_operator
debark car33 loc11
1
65 2
2
0 0 27 0
0 25 -1 2
1
end_operator
begin_operator
debark car33 loc12
1
65 3
2
0 0 27 0
0 25 -1 3
1
end_operator
begin_operator
debark car33 loc13
1
65 4
2
0 0 27 0
0 25 -1 4
1
end_operator
begin_operator
debark car33 loc14
1
65 5
2
0 0 27 0
0 25 -1 5
1
end_operator
begin_operator
debark car33 loc15
1
65 6
2
0 0 27 0
0 25 -1 6
1
end_operator
begin_operator
debark car33 loc16
1
65 7
2
0 0 27 0
0 25 -1 7
1
end_operator
begin_operator
debark car33 loc17
1
65 8
2
0 0 27 0
0 25 -1 8
1
end_operator
begin_operator
debark car33 loc18
1
65 9
2
0 0 27 0
0 25 -1 9
1
end_operator
begin_operator
debark car33 loc19
1
65 10
2
0 0 27 0
0 25 -1 10
1
end_operator
begin_operator
debark car33 loc2
1
65 11
2
0 0 27 0
0 25 -1 11
1
end_operator
begin_operator
debark car33 loc20
1
65 12
2
0 0 27 0
0 25 -1 12
1
end_operator
begin_operator
debark car33 loc21
1
65 13
2
0 0 27 0
0 25 -1 13
1
end_operator
begin_operator
debark car33 loc22
1
65 14
2
0 0 27 0
0 25 -1 14
1
end_operator
begin_operator
debark car33 loc23
1
65 15
2
0 0 27 0
0 25 -1 15
1
end_operator
begin_operator
debark car33 loc24
1
65 16
2
0 0 27 0
0 25 -1 16
1
end_operator
begin_operator
debark car33 loc25
1
65 17
2
0 0 27 0
0 25 -1 17
1
end_operator
begin_operator
debark car33 loc26
1
65 18
2
0 0 27 0
0 25 -1 18
1
end_operator
begin_operator
debark car33 loc27
1
65 19
2
0 0 27 0
0 25 -1 19
1
end_operator
begin_operator
debark car33 loc28
1
65 20
2
0 0 27 0
0 25 -1 20
1
end_operator
begin_operator
debark car33 loc29
1
65 21
2
0 0 27 0
0 25 -1 21
1
end_operator
begin_operator
debark car33 loc3
1
65 22
2
0 0 27 0
0 25 -1 22
1
end_operator
begin_operator
debark car33 loc30
1
65 23
2
0 0 27 0
0 25 -1 23
1
end_operator
begin_operator
debark car33 loc31
1
65 24
2
0 0 27 0
0 25 -1 24
1
end_operator
begin_operator
debark car33 loc32
1
65 25
2
0 0 27 0
0 25 -1 25
1
end_operator
begin_operator
debark car33 loc33
1
65 26
2
0 0 27 0
0 25 -1 26
1
end_operator
begin_operator
debark car33 loc34
1
65 27
2
0 0 27 0
0 25 -1 27
1
end_operator
begin_operator
debark car33 loc35
1
65 28
2
0 0 27 0
0 25 -1 28
1
end_operator
begin_operator
debark car33 loc36
1
65 29
2
0 0 27 0
0 25 -1 29
1
end_operator
begin_operator
debark car33 loc37
1
65 30
2
0 0 27 0
0 25 -1 30
1
end_operator
begin_operator
debark car33 loc38
1
65 31
2
0 0 27 0
0 25 -1 31
1
end_operator
begin_operator
debark car33 loc39
1
65 32
2
0 0 27 0
0 25 -1 32
1
end_operator
begin_operator
debark car33 loc4
1
65 33
2
0 0 27 0
0 25 -1 33
1
end_operator
begin_operator
debark car33 loc40
1
65 34
2
0 0 27 0
0 25 -1 34
1
end_operator
begin_operator
debark car33 loc41
1
65 35
2
0 0 27 0
0 25 -1 35
1
end_operator
begin_operator
debark car33 loc5
1
65 36
2
0 0 27 0
0 25 -1 36
1
end_operator
begin_operator
debark car33 loc6
1
65 37
2
0 0 27 0
0 25 -1 37
1
end_operator
begin_operator
debark car33 loc7
1
65 38
2
0 0 27 0
0 25 -1 38
1
end_operator
begin_operator
debark car33 loc8
1
65 39
2
0 0 27 0
0 25 -1 39
1
end_operator
begin_operator
debark car33 loc9
1
65 40
2
0 0 27 0
0 25 -1 40
1
end_operator
begin_operator
debark car34 loc1
1
65 0
2
0 0 28 0
0 37 -1 0
1
end_operator
begin_operator
debark car34 loc10
1
65 1
2
0 0 28 0
0 37 -1 1
1
end_operator
begin_operator
debark car34 loc11
1
65 2
2
0 0 28 0
0 37 -1 2
1
end_operator
begin_operator
debark car34 loc12
1
65 3
2
0 0 28 0
0 37 -1 3
1
end_operator
begin_operator
debark car34 loc13
1
65 4
2
0 0 28 0
0 37 -1 4
1
end_operator
begin_operator
debark car34 loc14
1
65 5
2
0 0 28 0
0 37 -1 5
1
end_operator
begin_operator
debark car34 loc15
1
65 6
2
0 0 28 0
0 37 -1 6
1
end_operator
begin_operator
debark car34 loc16
1
65 7
2
0 0 28 0
0 37 -1 7
1
end_operator
begin_operator
debark car34 loc17
1
65 8
2
0 0 28 0
0 37 -1 8
1
end_operator
begin_operator
debark car34 loc18
1
65 9
2
0 0 28 0
0 37 -1 9
1
end_operator
begin_operator
debark car34 loc19
1
65 10
2
0 0 28 0
0 37 -1 10
1
end_operator
begin_operator
debark car34 loc2
1
65 11
2
0 0 28 0
0 37 -1 11
1
end_operator
begin_operator
debark car34 loc20
1
65 12
2
0 0 28 0
0 37 -1 12
1
end_operator
begin_operator
debark car34 loc21
1
65 13
2
0 0 28 0
0 37 -1 13
1
end_operator
begin_operator
debark car34 loc22
1
65 14
2
0 0 28 0
0 37 -1 14
1
end_operator
begin_operator
debark car34 loc23
1
65 15
2
0 0 28 0
0 37 -1 15
1
end_operator
begin_operator
debark car34 loc24
1
65 16
2
0 0 28 0
0 37 -1 16
1
end_operator
begin_operator
debark car34 loc25
1
65 17
2
0 0 28 0
0 37 -1 17
1
end_operator
begin_operator
debark car34 loc26
1
65 18
2
0 0 28 0
0 37 -1 18
1
end_operator
begin_operator
debark car34 loc27
1
65 19
2
0 0 28 0
0 37 -1 19
1
end_operator
begin_operator
debark car34 loc28
1
65 20
2
0 0 28 0
0 37 -1 20
1
end_operator
begin_operator
debark car34 loc29
1
65 21
2
0 0 28 0
0 37 -1 21
1
end_operator
begin_operator
debark car34 loc3
1
65 22
2
0 0 28 0
0 37 -1 22
1
end_operator
begin_operator
debark car34 loc30
1
65 23
2
0 0 28 0
0 37 -1 23
1
end_operator
begin_operator
debark car34 loc31
1
65 24
2
0 0 28 0
0 37 -1 24
1
end_operator
begin_operator
debark car34 loc32
1
65 25
2
0 0 28 0
0 37 -1 25
1
end_operator
begin_operator
debark car34 loc33
1
65 26
2
0 0 28 0
0 37 -1 26
1
end_operator
begin_operator
debark car34 loc34
1
65 27
2
0 0 28 0
0 37 -1 27
1
end_operator
begin_operator
debark car34 loc35
1
65 28
2
0 0 28 0
0 37 -1 28
1
end_operator
begin_operator
debark car34 loc36
1
65 29
2
0 0 28 0
0 37 -1 29
1
end_operator
begin_operator
debark car34 loc37
1
65 30
2
0 0 28 0
0 37 -1 30
1
end_operator
begin_operator
debark car34 loc38
1
65 31
2
0 0 28 0
0 37 -1 31
1
end_operator
begin_operator
debark car34 loc39
1
65 32
2
0 0 28 0
0 37 -1 32
1
end_operator
begin_operator
debark car34 loc4
1
65 33
2
0 0 28 0
0 37 -1 33
1
end_operator
begin_operator
debark car34 loc40
1
65 34
2
0 0 28 0
0 37 -1 34
1
end_operator
begin_operator
debark car34 loc41
1
65 35
2
0 0 28 0
0 37 -1 35
1
end_operator
begin_operator
debark car34 loc5
1
65 36
2
0 0 28 0
0 37 -1 36
1
end_operator
begin_operator
debark car34 loc6
1
65 37
2
0 0 28 0
0 37 -1 37
1
end_operator
begin_operator
debark car34 loc7
1
65 38
2
0 0 28 0
0 37 -1 38
1
end_operator
begin_operator
debark car34 loc8
1
65 39
2
0 0 28 0
0 37 -1 39
1
end_operator
begin_operator
debark car34 loc9
1
65 40
2
0 0 28 0
0 37 -1 40
1
end_operator
begin_operator
debark car35 loc1
1
65 0
2
0 0 29 0
0 49 -1 0
1
end_operator
begin_operator
debark car35 loc10
1
65 1
2
0 0 29 0
0 49 -1 1
1
end_operator
begin_operator
debark car35 loc11
1
65 2
2
0 0 29 0
0 49 -1 2
1
end_operator
begin_operator
debark car35 loc12
1
65 3
2
0 0 29 0
0 49 -1 3
1
end_operator
begin_operator
debark car35 loc13
1
65 4
2
0 0 29 0
0 49 -1 4
1
end_operator
begin_operator
debark car35 loc14
1
65 5
2
0 0 29 0
0 49 -1 5
1
end_operator
begin_operator
debark car35 loc15
1
65 6
2
0 0 29 0
0 49 -1 6
1
end_operator
begin_operator
debark car35 loc16
1
65 7
2
0 0 29 0
0 49 -1 7
1
end_operator
begin_operator
debark car35 loc17
1
65 8
2
0 0 29 0
0 49 -1 8
1
end_operator
begin_operator
debark car35 loc18
1
65 9
2
0 0 29 0
0 49 -1 9
1
end_operator
begin_operator
debark car35 loc19
1
65 10
2
0 0 29 0
0 49 -1 10
1
end_operator
begin_operator
debark car35 loc2
1
65 11
2
0 0 29 0
0 49 -1 11
1
end_operator
begin_operator
debark car35 loc20
1
65 12
2
0 0 29 0
0 49 -1 12
1
end_operator
begin_operator
debark car35 loc21
1
65 13
2
0 0 29 0
0 49 -1 13
1
end_operator
begin_operator
debark car35 loc22
1
65 14
2
0 0 29 0
0 49 -1 14
1
end_operator
begin_operator
debark car35 loc23
1
65 15
2
0 0 29 0
0 49 -1 15
1
end_operator
begin_operator
debark car35 loc24
1
65 16
2
0 0 29 0
0 49 -1 16
1
end_operator
begin_operator
debark car35 loc25
1
65 17
2
0 0 29 0
0 49 -1 17
1
end_operator
begin_operator
debark car35 loc26
1
65 18
2
0 0 29 0
0 49 -1 18
1
end_operator
begin_operator
debark car35 loc27
1
65 19
2
0 0 29 0
0 49 -1 19
1
end_operator
begin_operator
debark car35 loc28
1
65 20
2
0 0 29 0
0 49 -1 20
1
end_operator
begin_operator
debark car35 loc29
1
65 21
2
0 0 29 0
0 49 -1 21
1
end_operator
begin_operator
debark car35 loc3
1
65 22
2
0 0 29 0
0 49 -1 22
1
end_operator
begin_operator
debark car35 loc30
1
65 23
2
0 0 29 0
0 49 -1 23
1
end_operator
begin_operator
debark car35 loc31
1
65 24
2
0 0 29 0
0 49 -1 24
1
end_operator
begin_operator
debark car35 loc32
1
65 25
2
0 0 29 0
0 49 -1 25
1
end_operator
begin_operator
debark car35 loc33
1
65 26
2
0 0 29 0
0 49 -1 26
1
end_operator
begin_operator
debark car35 loc34
1
65 27
2
0 0 29 0
0 49 -1 27
1
end_operator
begin_operator
debark car35 loc35
1
65 28
2
0 0 29 0
0 49 -1 28
1
end_operator
begin_operator
debark car35 loc36
1
65 29
2
0 0 29 0
0 49 -1 29
1
end_operator
begin_operator
debark car35 loc37
1
65 30
2
0 0 29 0
0 49 -1 30
1
end_operator
begin_operator
debark car35 loc38
1
65 31
2
0 0 29 0
0 49 -1 31
1
end_operator
begin_operator
debark car35 loc39
1
65 32
2
0 0 29 0
0 49 -1 32
1
end_operator
begin_operator
debark car35 loc4
1
65 33
2
0 0 29 0
0 49 -1 33
1
end_operator
begin_operator
debark car35 loc40
1
65 34
2
0 0 29 0
0 49 -1 34
1
end_operator
begin_operator
debark car35 loc41
1
65 35
2
0 0 29 0
0 49 -1 35
1
end_operator
begin_operator
debark car35 loc5
1
65 36
2
0 0 29 0
0 49 -1 36
1
end_operator
begin_operator
debark car35 loc6
1
65 37
2
0 0 29 0
0 49 -1 37
1
end_operator
begin_operator
debark car35 loc7
1
65 38
2
0 0 29 0
0 49 -1 38
1
end_operator
begin_operator
debark car35 loc8
1
65 39
2
0 0 29 0
0 49 -1 39
1
end_operator
begin_operator
debark car35 loc9
1
65 40
2
0 0 29 0
0 49 -1 40
1
end_operator
begin_operator
debark car36 loc1
1
65 0
2
0 0 30 0
0 61 -1 0
1
end_operator
begin_operator
debark car36 loc10
1
65 1
2
0 0 30 0
0 61 -1 1
1
end_operator
begin_operator
debark car36 loc11
1
65 2
2
0 0 30 0
0 61 -1 2
1
end_operator
begin_operator
debark car36 loc12
1
65 3
2
0 0 30 0
0 61 -1 3
1
end_operator
begin_operator
debark car36 loc13
1
65 4
2
0 0 30 0
0 61 -1 4
1
end_operator
begin_operator
debark car36 loc14
1
65 5
2
0 0 30 0
0 61 -1 5
1
end_operator
begin_operator
debark car36 loc15
1
65 6
2
0 0 30 0
0 61 -1 6
1
end_operator
begin_operator
debark car36 loc16
1
65 7
2
0 0 30 0
0 61 -1 7
1
end_operator
begin_operator
debark car36 loc17
1
65 8
2
0 0 30 0
0 61 -1 8
1
end_operator
begin_operator
debark car36 loc18
1
65 9
2
0 0 30 0
0 61 -1 9
1
end_operator
begin_operator
debark car36 loc19
1
65 10
2
0 0 30 0
0 61 -1 10
1
end_operator
begin_operator
debark car36 loc2
1
65 11
2
0 0 30 0
0 61 -1 11
1
end_operator
begin_operator
debark car36 loc20
1
65 12
2
0 0 30 0
0 61 -1 12
1
end_operator
begin_operator
debark car36 loc21
1
65 13
2
0 0 30 0
0 61 -1 13
1
end_operator
begin_operator
debark car36 loc22
1
65 14
2
0 0 30 0
0 61 -1 14
1
end_operator
begin_operator
debark car36 loc23
1
65 15
2
0 0 30 0
0 61 -1 15
1
end_operator
begin_operator
debark car36 loc24
1
65 16
2
0 0 30 0
0 61 -1 16
1
end_operator
begin_operator
debark car36 loc25
1
65 17
2
0 0 30 0
0 61 -1 17
1
end_operator
begin_operator
debark car36 loc26
1
65 18
2
0 0 30 0
0 61 -1 18
1
end_operator
begin_operator
debark car36 loc27
1
65 19
2
0 0 30 0
0 61 -1 19
1
end_operator
begin_operator
debark car36 loc28
1
65 20
2
0 0 30 0
0 61 -1 20
1
end_operator
begin_operator
debark car36 loc29
1
65 21
2
0 0 30 0
0 61 -1 21
1
end_operator
begin_operator
debark car36 loc3
1
65 22
2
0 0 30 0
0 61 -1 22
1
end_operator
begin_operator
debark car36 loc30
1
65 23
2
0 0 30 0
0 61 -1 23
1
end_operator
begin_operator
debark car36 loc31
1
65 24
2
0 0 30 0
0 61 -1 24
1
end_operator
begin_operator
debark car36 loc32
1
65 25
2
0 0 30 0
0 61 -1 25
1
end_operator
begin_operator
debark car36 loc33
1
65 26
2
0 0 30 0
0 61 -1 26
1
end_operator
begin_operator
debark car36 loc34
1
65 27
2
0 0 30 0
0 61 -1 27
1
end_operator
begin_operator
debark car36 loc35
1
65 28
2
0 0 30 0
0 61 -1 28
1
end_operator
begin_operator
debark car36 loc36
1
65 29
2
0 0 30 0
0 61 -1 29
1
end_operator
begin_operator
debark car36 loc37
1
65 30
2
0 0 30 0
0 61 -1 30
1
end_operator
begin_operator
debark car36 loc38
1
65 31
2
0 0 30 0
0 61 -1 31
1
end_operator
begin_operator
debark car36 loc39
1
65 32
2
0 0 30 0
0 61 -1 32
1
end_operator
begin_operator
debark car36 loc4
1
65 33
2
0 0 30 0
0 61 -1 33
1
end_operator
begin_operator
debark car36 loc40
1
65 34
2
0 0 30 0
0 61 -1 34
1
end_operator
begin_operator
debark car36 loc41
1
65 35
2
0 0 30 0
0 61 -1 35
1
end_operator
begin_operator
debark car36 loc5
1
65 36
2
0 0 30 0
0 61 -1 36
1
end_operator
begin_operator
debark car36 loc6
1
65 37
2
0 0 30 0
0 61 -1 37
1
end_operator
begin_operator
debark car36 loc7
1
65 38
2
0 0 30 0
0 61 -1 38
1
end_operator
begin_operator
debark car36 loc8
1
65 39
2
0 0 30 0
0 61 -1 39
1
end_operator
begin_operator
debark car36 loc9
1
65 40
2
0 0 30 0
0 61 -1 40
1
end_operator
begin_operator
debark car37 loc1
1
65 0
2
0 0 31 0
0 73 -1 0
1
end_operator
begin_operator
debark car37 loc10
1
65 1
2
0 0 31 0
0 73 -1 1
1
end_operator
begin_operator
debark car37 loc11
1
65 2
2
0 0 31 0
0 73 -1 2
1
end_operator
begin_operator
debark car37 loc12
1
65 3
2
0 0 31 0
0 73 -1 3
1
end_operator
begin_operator
debark car37 loc13
1
65 4
2
0 0 31 0
0 73 -1 4
1
end_operator
begin_operator
debark car37 loc14
1
65 5
2
0 0 31 0
0 73 -1 5
1
end_operator
begin_operator
debark car37 loc15
1
65 6
2
0 0 31 0
0 73 -1 6
1
end_operator
begin_operator
debark car37 loc16
1
65 7
2
0 0 31 0
0 73 -1 7
1
end_operator
begin_operator
debark car37 loc17
1
65 8
2
0 0 31 0
0 73 -1 8
1
end_operator
begin_operator
debark car37 loc18
1
65 9
2
0 0 31 0
0 73 -1 9
1
end_operator
begin_operator
debark car37 loc19
1
65 10
2
0 0 31 0
0 73 -1 10
1
end_operator
begin_operator
debark car37 loc2
1
65 11
2
0 0 31 0
0 73 -1 11
1
end_operator
begin_operator
debark car37 loc20
1
65 12
2
0 0 31 0
0 73 -1 12
1
end_operator
begin_operator
debark car37 loc21
1
65 13
2
0 0 31 0
0 73 -1 13
1
end_operator
begin_operator
debark car37 loc22
1
65 14
2
0 0 31 0
0 73 -1 14
1
end_operator
begin_operator
debark car37 loc23
1
65 15
2
0 0 31 0
0 73 -1 15
1
end_operator
begin_operator
debark car37 loc24
1
65 16
2
0 0 31 0
0 73 -1 16
1
end_operator
begin_operator
debark car37 loc25
1
65 17
2
0 0 31 0
0 73 -1 17
1
end_operator
begin_operator
debark car37 loc26
1
65 18
2
0 0 31 0
0 73 -1 18
1
end_operator
begin_operator
debark car37 loc27
1
65 19
2
0 0 31 0
0 73 -1 19
1
end_operator
begin_operator
debark car37 loc28
1
65 20
2
0 0 31 0
0 73 -1 20
1
end_operator
begin_operator
debark car37 loc29
1
65 21
2
0 0 31 0
0 73 -1 21
1
end_operator
begin_operator
debark car37 loc3
1
65 22
2
0 0 31 0
0 73 -1 22
1
end_operator
begin_operator
debark car37 loc30
1
65 23
2
0 0 31 0
0 73 -1 23
1
end_operator
begin_operator
debark car37 loc31
1
65 24
2
0 0 31 0
0 73 -1 24
1
end_operator
begin_operator
debark car37 loc32
1
65 25
2
0 0 31 0
0 73 -1 25
1
end_operator
begin_operator
debark car37 loc33
1
65 26
2
0 0 31 0
0 73 -1 26
1
end_operator
begin_operator
debark car37 loc34
1
65 27
2
0 0 31 0
0 73 -1 27
1
end_operator
begin_operator
debark car37 loc35
1
65 28
2
0 0 31 0
0 73 -1 28
1
end_operator
begin_operator
debark car37 loc36
1
65 29
2
0 0 31 0
0 73 -1 29
1
end_operator
begin_operator
debark car37 loc37
1
65 30
2
0 0 31 0
0 73 -1 30
1
end_operator
begin_operator
debark car37 loc38
1
65 31
2
0 0 31 0
0 73 -1 31
1
end_operator
begin_operator
debark car37 loc39
1
65 32
2
0 0 31 0
0 73 -1 32
1
end_operator
begin_operator
debark car37 loc4
1
65 33
2
0 0 31 0
0 73 -1 33
1
end_operator
begin_operator
debark car37 loc40
1
65 34
2
0 0 31 0
0 73 -1 34
1
end_operator
begin_operator
debark car37 loc41
1
65 35
2
0 0 31 0
0 73 -1 35
1
end_operator
begin_operator
debark car37 loc5
1
65 36
2
0 0 31 0
0 73 -1 36
1
end_operator
begin_operator
debark car37 loc6
1
65 37
2
0 0 31 0
0 73 -1 37
1
end_operator
begin_operator
debark car37 loc7
1
65 38
2
0 0 31 0
0 73 -1 38
1
end_operator
begin_operator
debark car37 loc8
1
65 39
2
0 0 31 0
0 73 -1 39
1
end_operator
begin_operator
debark car37 loc9
1
65 40
2
0 0 31 0
0 73 -1 40
1
end_operator
begin_operator
debark car38 loc1
1
65 0
2
0 0 32 0
0 10 -1 0
1
end_operator
begin_operator
debark car38 loc10
1
65 1
2
0 0 32 0
0 10 -1 1
1
end_operator
begin_operator
debark car38 loc11
1
65 2
2
0 0 32 0
0 10 -1 2
1
end_operator
begin_operator
debark car38 loc12
1
65 3
2
0 0 32 0
0 10 -1 3
1
end_operator
begin_operator
debark car38 loc13
1
65 4
2
0 0 32 0
0 10 -1 4
1
end_operator
begin_operator
debark car38 loc14
1
65 5
2
0 0 32 0
0 10 -1 5
1
end_operator
begin_operator
debark car38 loc15
1
65 6
2
0 0 32 0
0 10 -1 6
1
end_operator
begin_operator
debark car38 loc16
1
65 7
2
0 0 32 0
0 10 -1 7
1
end_operator
begin_operator
debark car38 loc17
1
65 8
2
0 0 32 0
0 10 -1 8
1
end_operator
begin_operator
debark car38 loc18
1
65 9
2
0 0 32 0
0 10 -1 9
1
end_operator
begin_operator
debark car38 loc19
1
65 10
2
0 0 32 0
0 10 -1 10
1
end_operator
begin_operator
debark car38 loc2
1
65 11
2
0 0 32 0
0 10 -1 11
1
end_operator
begin_operator
debark car38 loc20
1
65 12
2
0 0 32 0
0 10 -1 12
1
end_operator
begin_operator
debark car38 loc21
1
65 13
2
0 0 32 0
0 10 -1 13
1
end_operator
begin_operator
debark car38 loc22
1
65 14
2
0 0 32 0
0 10 -1 14
1
end_operator
begin_operator
debark car38 loc23
1
65 15
2
0 0 32 0
0 10 -1 15
1
end_operator
begin_operator
debark car38 loc24
1
65 16
2
0 0 32 0
0 10 -1 16
1
end_operator
begin_operator
debark car38 loc25
1
65 17
2
0 0 32 0
0 10 -1 17
1
end_operator
begin_operator
debark car38 loc26
1
65 18
2
0 0 32 0
0 10 -1 18
1
end_operator
begin_operator
debark car38 loc27
1
65 19
2
0 0 32 0
0 10 -1 19
1
end_operator
begin_operator
debark car38 loc28
1
65 20
2
0 0 32 0
0 10 -1 20
1
end_operator
begin_operator
debark car38 loc29
1
65 21
2
0 0 32 0
0 10 -1 21
1
end_operator
begin_operator
debark car38 loc3
1
65 22
2
0 0 32 0
0 10 -1 22
1
end_operator
begin_operator
debark car38 loc30
1
65 23
2
0 0 32 0
0 10 -1 23
1
end_operator
begin_operator
debark car38 loc31
1
65 24
2
0 0 32 0
0 10 -1 24
1
end_operator
begin_operator
debark car38 loc32
1
65 25
2
0 0 32 0
0 10 -1 25
1
end_operator
begin_operator
debark car38 loc33
1
65 26
2
0 0 32 0
0 10 -1 26
1
end_operator
begin_operator
debark car38 loc34
1
65 27
2
0 0 32 0
0 10 -1 27
1
end_operator
begin_operator
debark car38 loc35
1
65 28
2
0 0 32 0
0 10 -1 28
1
end_operator
begin_operator
debark car38 loc36
1
65 29
2
0 0 32 0
0 10 -1 29
1
end_operator
begin_operator
debark car38 loc37
1
65 30
2
0 0 32 0
0 10 -1 30
1
end_operator
begin_operator
debark car38 loc38
1
65 31
2
0 0 32 0
0 10 -1 31
1
end_operator
begin_operator
debark car38 loc39
1
65 32
2
0 0 32 0
0 10 -1 32
1
end_operator
begin_operator
debark car38 loc4
1
65 33
2
0 0 32 0
0 10 -1 33
1
end_operator
begin_operator
debark car38 loc40
1
65 34
2
0 0 32 0
0 10 -1 34
1
end_operator
begin_operator
debark car38 loc41
1
65 35
2
0 0 32 0
0 10 -1 35
1
end_operator
begin_operator
debark car38 loc5
1
65 36
2
0 0 32 0
0 10 -1 36
1
end_operator
begin_operator
debark car38 loc6
1
65 37
2
0 0 32 0
0 10 -1 37
1
end_operator
begin_operator
debark car38 loc7
1
65 38
2
0 0 32 0
0 10 -1 38
1
end_operator
begin_operator
debark car38 loc8
1
65 39
2
0 0 32 0
0 10 -1 39
1
end_operator
begin_operator
debark car38 loc9
1
65 40
2
0 0 32 0
0 10 -1 40
1
end_operator
begin_operator
debark car39 loc1
1
65 0
2
0 0 33 0
0 22 -1 0
1
end_operator
begin_operator
debark car39 loc10
1
65 1
2
0 0 33 0
0 22 -1 1
1
end_operator
begin_operator
debark car39 loc11
1
65 2
2
0 0 33 0
0 22 -1 2
1
end_operator
begin_operator
debark car39 loc12
1
65 3
2
0 0 33 0
0 22 -1 3
1
end_operator
begin_operator
debark car39 loc13
1
65 4
2
0 0 33 0
0 22 -1 4
1
end_operator
begin_operator
debark car39 loc14
1
65 5
2
0 0 33 0
0 22 -1 5
1
end_operator
begin_operator
debark car39 loc15
1
65 6
2
0 0 33 0
0 22 -1 6
1
end_operator
begin_operator
debark car39 loc16
1
65 7
2
0 0 33 0
0 22 -1 7
1
end_operator
begin_operator
debark car39 loc17
1
65 8
2
0 0 33 0
0 22 -1 8
1
end_operator
begin_operator
debark car39 loc18
1
65 9
2
0 0 33 0
0 22 -1 9
1
end_operator
begin_operator
debark car39 loc19
1
65 10
2
0 0 33 0
0 22 -1 10
1
end_operator
begin_operator
debark car39 loc2
1
65 11
2
0 0 33 0
0 22 -1 11
1
end_operator
begin_operator
debark car39 loc20
1
65 12
2
0 0 33 0
0 22 -1 12
1
end_operator
begin_operator
debark car39 loc21
1
65 13
2
0 0 33 0
0 22 -1 13
1
end_operator
begin_operator
debark car39 loc22
1
65 14
2
0 0 33 0
0 22 -1 14
1
end_operator
begin_operator
debark car39 loc23
1
65 15
2
0 0 33 0
0 22 -1 15
1
end_operator
begin_operator
debark car39 loc24
1
65 16
2
0 0 33 0
0 22 -1 16
1
end_operator
begin_operator
debark car39 loc25
1
65 17
2
0 0 33 0
0 22 -1 17
1
end_operator
begin_operator
debark car39 loc26
1
65 18
2
0 0 33 0
0 22 -1 18
1
end_operator
begin_operator
debark car39 loc27
1
65 19
2
0 0 33 0
0 22 -1 19
1
end_operator
begin_operator
debark car39 loc28
1
65 20
2
0 0 33 0
0 22 -1 20
1
end_operator
begin_operator
debark car39 loc29
1
65 21
2
0 0 33 0
0 22 -1 21
1
end_operator
begin_operator
debark car39 loc3
1
65 22
2
0 0 33 0
0 22 -1 22
1
end_operator
begin_operator
debark car39 loc30
1
65 23
2
0 0 33 0
0 22 -1 23
1
end_operator
begin_operator
debark car39 loc31
1
65 24
2
0 0 33 0
0 22 -1 24
1
end_operator
begin_operator
debark car39 loc32
1
65 25
2
0 0 33 0
0 22 -1 25
1
end_operator
begin_operator
debark car39 loc33
1
65 26
2
0 0 33 0
0 22 -1 26
1
end_operator
begin_operator
debark car39 loc34
1
65 27
2
0 0 33 0
0 22 -1 27
1
end_operator
begin_operator
debark car39 loc35
1
65 28
2
0 0 33 0
0 22 -1 28
1
end_operator
begin_operator
debark car39 loc36
1
65 29
2
0 0 33 0
0 22 -1 29
1
end_operator
begin_operator
debark car39 loc37
1
65 30
2
0 0 33 0
0 22 -1 30
1
end_operator
begin_operator
debark car39 loc38
1
65 31
2
0 0 33 0
0 22 -1 31
1
end_operator
begin_operator
debark car39 loc39
1
65 32
2
0 0 33 0
0 22 -1 32
1
end_operator
begin_operator
debark car39 loc4
1
65 33
2
0 0 33 0
0 22 -1 33
1
end_operator
begin_operator
debark car39 loc40
1
65 34
2
0 0 33 0
0 22 -1 34
1
end_operator
begin_operator
debark car39 loc41
1
65 35
2
0 0 33 0
0 22 -1 35
1
end_operator
begin_operator
debark car39 loc5
1
65 36
2
0 0 33 0
0 22 -1 36
1
end_operator
begin_operator
debark car39 loc6
1
65 37
2
0 0 33 0
0 22 -1 37
1
end_operator
begin_operator
debark car39 loc7
1
65 38
2
0 0 33 0
0 22 -1 38
1
end_operator
begin_operator
debark car39 loc8
1
65 39
2
0 0 33 0
0 22 -1 39
1
end_operator
begin_operator
debark car39 loc9
1
65 40
2
0 0 33 0
0 22 -1 40
1
end_operator
begin_operator
debark car4 loc1
1
65 0
2
0 0 34 0
0 34 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
65 1
2
0 0 34 0
0 34 -1 1
1
end_operator
begin_operator
debark car4 loc11
1
65 2
2
0 0 34 0
0 34 -1 2
1
end_operator
begin_operator
debark car4 loc12
1
65 3
2
0 0 34 0
0 34 -1 3
1
end_operator
begin_operator
debark car4 loc13
1
65 4
2
0 0 34 0
0 34 -1 4
1
end_operator
begin_operator
debark car4 loc14
1
65 5
2
0 0 34 0
0 34 -1 5
1
end_operator
begin_operator
debark car4 loc15
1
65 6
2
0 0 34 0
0 34 -1 6
1
end_operator
begin_operator
debark car4 loc16
1
65 7
2
0 0 34 0
0 34 -1 7
1
end_operator
begin_operator
debark car4 loc17
1
65 8
2
0 0 34 0
0 34 -1 8
1
end_operator
begin_operator
debark car4 loc18
1
65 9
2
0 0 34 0
0 34 -1 9
1
end_operator
begin_operator
debark car4 loc19
1
65 10
2
0 0 34 0
0 34 -1 10
1
end_operator
begin_operator
debark car4 loc2
1
65 11
2
0 0 34 0
0 34 -1 11
1
end_operator
begin_operator
debark car4 loc20
1
65 12
2
0 0 34 0
0 34 -1 12
1
end_operator
begin_operator
debark car4 loc21
1
65 13
2
0 0 34 0
0 34 -1 13
1
end_operator
begin_operator
debark car4 loc22
1
65 14
2
0 0 34 0
0 34 -1 14
1
end_operator
begin_operator
debark car4 loc23
1
65 15
2
0 0 34 0
0 34 -1 15
1
end_operator
begin_operator
debark car4 loc24
1
65 16
2
0 0 34 0
0 34 -1 16
1
end_operator
begin_operator
debark car4 loc25
1
65 17
2
0 0 34 0
0 34 -1 17
1
end_operator
begin_operator
debark car4 loc26
1
65 18
2
0 0 34 0
0 34 -1 18
1
end_operator
begin_operator
debark car4 loc27
1
65 19
2
0 0 34 0
0 34 -1 19
1
end_operator
begin_operator
debark car4 loc28
1
65 20
2
0 0 34 0
0 34 -1 20
1
end_operator
begin_operator
debark car4 loc29
1
65 21
2
0 0 34 0
0 34 -1 21
1
end_operator
begin_operator
debark car4 loc3
1
65 22
2
0 0 34 0
0 34 -1 22
1
end_operator
begin_operator
debark car4 loc30
1
65 23
2
0 0 34 0
0 34 -1 23
1
end_operator
begin_operator
debark car4 loc31
1
65 24
2
0 0 34 0
0 34 -1 24
1
end_operator
begin_operator
debark car4 loc32
1
65 25
2
0 0 34 0
0 34 -1 25
1
end_operator
begin_operator
debark car4 loc33
1
65 26
2
0 0 34 0
0 34 -1 26
1
end_operator
begin_operator
debark car4 loc34
1
65 27
2
0 0 34 0
0 34 -1 27
1
end_operator
begin_operator
debark car4 loc35
1
65 28
2
0 0 34 0
0 34 -1 28
1
end_operator
begin_operator
debark car4 loc36
1
65 29
2
0 0 34 0
0 34 -1 29
1
end_operator
begin_operator
debark car4 loc37
1
65 30
2
0 0 34 0
0 34 -1 30
1
end_operator
begin_operator
debark car4 loc38
1
65 31
2
0 0 34 0
0 34 -1 31
1
end_operator
begin_operator
debark car4 loc39
1
65 32
2
0 0 34 0
0 34 -1 32
1
end_operator
begin_operator
debark car4 loc4
1
65 33
2
0 0 34 0
0 34 -1 33
1
end_operator
begin_operator
debark car4 loc40
1
65 34
2
0 0 34 0
0 34 -1 34
1
end_operator
begin_operator
debark car4 loc41
1
65 35
2
0 0 34 0
0 34 -1 35
1
end_operator
begin_operator
debark car4 loc5
1
65 36
2
0 0 34 0
0 34 -1 36
1
end_operator
begin_operator
debark car4 loc6
1
65 37
2
0 0 34 0
0 34 -1 37
1
end_operator
begin_operator
debark car4 loc7
1
65 38
2
0 0 34 0
0 34 -1 38
1
end_operator
begin_operator
debark car4 loc8
1
65 39
2
0 0 34 0
0 34 -1 39
1
end_operator
begin_operator
debark car4 loc9
1
65 40
2
0 0 34 0
0 34 -1 40
1
end_operator
begin_operator
debark car40 loc1
1
65 0
2
0 0 35 0
0 46 -1 0
1
end_operator
begin_operator
debark car40 loc10
1
65 1
2
0 0 35 0
0 46 -1 1
1
end_operator
begin_operator
debark car40 loc11
1
65 2
2
0 0 35 0
0 46 -1 2
1
end_operator
begin_operator
debark car40 loc12
1
65 3
2
0 0 35 0
0 46 -1 3
1
end_operator
begin_operator
debark car40 loc13
1
65 4
2
0 0 35 0
0 46 -1 4
1
end_operator
begin_operator
debark car40 loc14
1
65 5
2
0 0 35 0
0 46 -1 5
1
end_operator
begin_operator
debark car40 loc15
1
65 6
2
0 0 35 0
0 46 -1 6
1
end_operator
begin_operator
debark car40 loc16
1
65 7
2
0 0 35 0
0 46 -1 7
1
end_operator
begin_operator
debark car40 loc17
1
65 8
2
0 0 35 0
0 46 -1 8
1
end_operator
begin_operator
debark car40 loc18
1
65 9
2
0 0 35 0
0 46 -1 9
1
end_operator
begin_operator
debark car40 loc19
1
65 10
2
0 0 35 0
0 46 -1 10
1
end_operator
begin_operator
debark car40 loc2
1
65 11
2
0 0 35 0
0 46 -1 11
1
end_operator
begin_operator
debark car40 loc20
1
65 12
2
0 0 35 0
0 46 -1 12
1
end_operator
begin_operator
debark car40 loc21
1
65 13
2
0 0 35 0
0 46 -1 13
1
end_operator
begin_operator
debark car40 loc22
1
65 14
2
0 0 35 0
0 46 -1 14
1
end_operator
begin_operator
debark car40 loc23
1
65 15
2
0 0 35 0
0 46 -1 15
1
end_operator
begin_operator
debark car40 loc24
1
65 16
2
0 0 35 0
0 46 -1 16
1
end_operator
begin_operator
debark car40 loc25
1
65 17
2
0 0 35 0
0 46 -1 17
1
end_operator
begin_operator
debark car40 loc26
1
65 18
2
0 0 35 0
0 46 -1 18
1
end_operator
begin_operator
debark car40 loc27
1
65 19
2
0 0 35 0
0 46 -1 19
1
end_operator
begin_operator
debark car40 loc28
1
65 20
2
0 0 35 0
0 46 -1 20
1
end_operator
begin_operator
debark car40 loc29
1
65 21
2
0 0 35 0
0 46 -1 21
1
end_operator
begin_operator
debark car40 loc3
1
65 22
2
0 0 35 0
0 46 -1 22
1
end_operator
begin_operator
debark car40 loc30
1
65 23
2
0 0 35 0
0 46 -1 23
1
end_operator
begin_operator
debark car40 loc31
1
65 24
2
0 0 35 0
0 46 -1 24
1
end_operator
begin_operator
debark car40 loc32
1
65 25
2
0 0 35 0
0 46 -1 25
1
end_operator
begin_operator
debark car40 loc33
1
65 26
2
0 0 35 0
0 46 -1 26
1
end_operator
begin_operator
debark car40 loc34
1
65 27
2
0 0 35 0
0 46 -1 27
1
end_operator
begin_operator
debark car40 loc35
1
65 28
2
0 0 35 0
0 46 -1 28
1
end_operator
begin_operator
debark car40 loc36
1
65 29
2
0 0 35 0
0 46 -1 29
1
end_operator
begin_operator
debark car40 loc37
1
65 30
2
0 0 35 0
0 46 -1 30
1
end_operator
begin_operator
debark car40 loc38
1
65 31
2
0 0 35 0
0 46 -1 31
1
end_operator
begin_operator
debark car40 loc39
1
65 32
2
0 0 35 0
0 46 -1 32
1
end_operator
begin_operator
debark car40 loc4
1
65 33
2
0 0 35 0
0 46 -1 33
1
end_operator
begin_operator
debark car40 loc40
1
65 34
2
0 0 35 0
0 46 -1 34
1
end_operator
begin_operator
debark car40 loc41
1
65 35
2
0 0 35 0
0 46 -1 35
1
end_operator
begin_operator
debark car40 loc5
1
65 36
2
0 0 35 0
0 46 -1 36
1
end_operator
begin_operator
debark car40 loc6
1
65 37
2
0 0 35 0
0 46 -1 37
1
end_operator
begin_operator
debark car40 loc7
1
65 38
2
0 0 35 0
0 46 -1 38
1
end_operator
begin_operator
debark car40 loc8
1
65 39
2
0 0 35 0
0 46 -1 39
1
end_operator
begin_operator
debark car40 loc9
1
65 40
2
0 0 35 0
0 46 -1 40
1
end_operator
begin_operator
debark car41 loc1
1
65 0
2
0 0 36 0
0 58 -1 0
1
end_operator
begin_operator
debark car41 loc10
1
65 1
2
0 0 36 0
0 58 -1 1
1
end_operator
begin_operator
debark car41 loc11
1
65 2
2
0 0 36 0
0 58 -1 2
1
end_operator
begin_operator
debark car41 loc12
1
65 3
2
0 0 36 0
0 58 -1 3
1
end_operator
begin_operator
debark car41 loc13
1
65 4
2
0 0 36 0
0 58 -1 4
1
end_operator
begin_operator
debark car41 loc14
1
65 5
2
0 0 36 0
0 58 -1 5
1
end_operator
begin_operator
debark car41 loc15
1
65 6
2
0 0 36 0
0 58 -1 6
1
end_operator
begin_operator
debark car41 loc16
1
65 7
2
0 0 36 0
0 58 -1 7
1
end_operator
begin_operator
debark car41 loc17
1
65 8
2
0 0 36 0
0 58 -1 8
1
end_operator
begin_operator
debark car41 loc18
1
65 9
2
0 0 36 0
0 58 -1 9
1
end_operator
begin_operator
debark car41 loc19
1
65 10
2
0 0 36 0
0 58 -1 10
1
end_operator
begin_operator
debark car41 loc2
1
65 11
2
0 0 36 0
0 58 -1 11
1
end_operator
begin_operator
debark car41 loc20
1
65 12
2
0 0 36 0
0 58 -1 12
1
end_operator
begin_operator
debark car41 loc21
1
65 13
2
0 0 36 0
0 58 -1 13
1
end_operator
begin_operator
debark car41 loc22
1
65 14
2
0 0 36 0
0 58 -1 14
1
end_operator
begin_operator
debark car41 loc23
1
65 15
2
0 0 36 0
0 58 -1 15
1
end_operator
begin_operator
debark car41 loc24
1
65 16
2
0 0 36 0
0 58 -1 16
1
end_operator
begin_operator
debark car41 loc25
1
65 17
2
0 0 36 0
0 58 -1 17
1
end_operator
begin_operator
debark car41 loc26
1
65 18
2
0 0 36 0
0 58 -1 18
1
end_operator
begin_operator
debark car41 loc27
1
65 19
2
0 0 36 0
0 58 -1 19
1
end_operator
begin_operator
debark car41 loc28
1
65 20
2
0 0 36 0
0 58 -1 20
1
end_operator
begin_operator
debark car41 loc29
1
65 21
2
0 0 36 0
0 58 -1 21
1
end_operator
begin_operator
debark car41 loc3
1
65 22
2
0 0 36 0
0 58 -1 22
1
end_operator
begin_operator
debark car41 loc30
1
65 23
2
0 0 36 0
0 58 -1 23
1
end_operator
begin_operator
debark car41 loc31
1
65 24
2
0 0 36 0
0 58 -1 24
1
end_operator
begin_operator
debark car41 loc32
1
65 25
2
0 0 36 0
0 58 -1 25
1
end_operator
begin_operator
debark car41 loc33
1
65 26
2
0 0 36 0
0 58 -1 26
1
end_operator
begin_operator
debark car41 loc34
1
65 27
2
0 0 36 0
0 58 -1 27
1
end_operator
begin_operator
debark car41 loc35
1
65 28
2
0 0 36 0
0 58 -1 28
1
end_operator
begin_operator
debark car41 loc36
1
65 29
2
0 0 36 0
0 58 -1 29
1
end_operator
begin_operator
debark car41 loc37
1
65 30
2
0 0 36 0
0 58 -1 30
1
end_operator
begin_operator
debark car41 loc38
1
65 31
2
0 0 36 0
0 58 -1 31
1
end_operator
begin_operator
debark car41 loc39
1
65 32
2
0 0 36 0
0 58 -1 32
1
end_operator
begin_operator
debark car41 loc4
1
65 33
2
0 0 36 0
0 58 -1 33
1
end_operator
begin_operator
debark car41 loc40
1
65 34
2
0 0 36 0
0 58 -1 34
1
end_operator
begin_operator
debark car41 loc41
1
65 35
2
0 0 36 0
0 58 -1 35
1
end_operator
begin_operator
debark car41 loc5
1
65 36
2
0 0 36 0
0 58 -1 36
1
end_operator
begin_operator
debark car41 loc6
1
65 37
2
0 0 36 0
0 58 -1 37
1
end_operator
begin_operator
debark car41 loc7
1
65 38
2
0 0 36 0
0 58 -1 38
1
end_operator
begin_operator
debark car41 loc8
1
65 39
2
0 0 36 0
0 58 -1 39
1
end_operator
begin_operator
debark car41 loc9
1
65 40
2
0 0 36 0
0 58 -1 40
1
end_operator
begin_operator
debark car42 loc1
1
65 0
2
0 0 37 0
0 70 -1 0
1
end_operator
begin_operator
debark car42 loc10
1
65 1
2
0 0 37 0
0 70 -1 1
1
end_operator
begin_operator
debark car42 loc11
1
65 2
2
0 0 37 0
0 70 -1 2
1
end_operator
begin_operator
debark car42 loc12
1
65 3
2
0 0 37 0
0 70 -1 3
1
end_operator
begin_operator
debark car42 loc13
1
65 4
2
0 0 37 0
0 70 -1 4
1
end_operator
begin_operator
debark car42 loc14
1
65 5
2
0 0 37 0
0 70 -1 5
1
end_operator
begin_operator
debark car42 loc15
1
65 6
2
0 0 37 0
0 70 -1 6
1
end_operator
begin_operator
debark car42 loc16
1
65 7
2
0 0 37 0
0 70 -1 7
1
end_operator
begin_operator
debark car42 loc17
1
65 8
2
0 0 37 0
0 70 -1 8
1
end_operator
begin_operator
debark car42 loc18
1
65 9
2
0 0 37 0
0 70 -1 9
1
end_operator
begin_operator
debark car42 loc19
1
65 10
2
0 0 37 0
0 70 -1 10
1
end_operator
begin_operator
debark car42 loc2
1
65 11
2
0 0 37 0
0 70 -1 11
1
end_operator
begin_operator
debark car42 loc20
1
65 12
2
0 0 37 0
0 70 -1 12
1
end_operator
begin_operator
debark car42 loc21
1
65 13
2
0 0 37 0
0 70 -1 13
1
end_operator
begin_operator
debark car42 loc22
1
65 14
2
0 0 37 0
0 70 -1 14
1
end_operator
begin_operator
debark car42 loc23
1
65 15
2
0 0 37 0
0 70 -1 15
1
end_operator
begin_operator
debark car42 loc24
1
65 16
2
0 0 37 0
0 70 -1 16
1
end_operator
begin_operator
debark car42 loc25
1
65 17
2
0 0 37 0
0 70 -1 17
1
end_operator
begin_operator
debark car42 loc26
1
65 18
2
0 0 37 0
0 70 -1 18
1
end_operator
begin_operator
debark car42 loc27
1
65 19
2
0 0 37 0
0 70 -1 19
1
end_operator
begin_operator
debark car42 loc28
1
65 20
2
0 0 37 0
0 70 -1 20
1
end_operator
begin_operator
debark car42 loc29
1
65 21
2
0 0 37 0
0 70 -1 21
1
end_operator
begin_operator
debark car42 loc3
1
65 22
2
0 0 37 0
0 70 -1 22
1
end_operator
begin_operator
debark car42 loc30
1
65 23
2
0 0 37 0
0 70 -1 23
1
end_operator
begin_operator
debark car42 loc31
1
65 24
2
0 0 37 0
0 70 -1 24
1
end_operator
begin_operator
debark car42 loc32
1
65 25
2
0 0 37 0
0 70 -1 25
1
end_operator
begin_operator
debark car42 loc33
1
65 26
2
0 0 37 0
0 70 -1 26
1
end_operator
begin_operator
debark car42 loc34
1
65 27
2
0 0 37 0
0 70 -1 27
1
end_operator
begin_operator
debark car42 loc35
1
65 28
2
0 0 37 0
0 70 -1 28
1
end_operator
begin_operator
debark car42 loc36
1
65 29
2
0 0 37 0
0 70 -1 29
1
end_operator
begin_operator
debark car42 loc37
1
65 30
2
0 0 37 0
0 70 -1 30
1
end_operator
begin_operator
debark car42 loc38
1
65 31
2
0 0 37 0
0 70 -1 31
1
end_operator
begin_operator
debark car42 loc39
1
65 32
2
0 0 37 0
0 70 -1 32
1
end_operator
begin_operator
debark car42 loc4
1
65 33
2
0 0 37 0
0 70 -1 33
1
end_operator
begin_operator
debark car42 loc40
1
65 34
2
0 0 37 0
0 70 -1 34
1
end_operator
begin_operator
debark car42 loc41
1
65 35
2
0 0 37 0
0 70 -1 35
1
end_operator
begin_operator
debark car42 loc5
1
65 36
2
0 0 37 0
0 70 -1 36
1
end_operator
begin_operator
debark car42 loc6
1
65 37
2
0 0 37 0
0 70 -1 37
1
end_operator
begin_operator
debark car42 loc7
1
65 38
2
0 0 37 0
0 70 -1 38
1
end_operator
begin_operator
debark car42 loc8
1
65 39
2
0 0 37 0
0 70 -1 39
1
end_operator
begin_operator
debark car42 loc9
1
65 40
2
0 0 37 0
0 70 -1 40
1
end_operator
begin_operator
debark car43 loc1
1
65 0
2
0 0 38 0
0 7 -1 0
1
end_operator
begin_operator
debark car43 loc10
1
65 1
2
0 0 38 0
0 7 -1 1
1
end_operator
begin_operator
debark car43 loc11
1
65 2
2
0 0 38 0
0 7 -1 2
1
end_operator
begin_operator
debark car43 loc12
1
65 3
2
0 0 38 0
0 7 -1 3
1
end_operator
begin_operator
debark car43 loc13
1
65 4
2
0 0 38 0
0 7 -1 4
1
end_operator
begin_operator
debark car43 loc14
1
65 5
2
0 0 38 0
0 7 -1 5
1
end_operator
begin_operator
debark car43 loc15
1
65 6
2
0 0 38 0
0 7 -1 6
1
end_operator
begin_operator
debark car43 loc16
1
65 7
2
0 0 38 0
0 7 -1 7
1
end_operator
begin_operator
debark car43 loc17
1
65 8
2
0 0 38 0
0 7 -1 8
1
end_operator
begin_operator
debark car43 loc18
1
65 9
2
0 0 38 0
0 7 -1 9
1
end_operator
begin_operator
debark car43 loc19
1
65 10
2
0 0 38 0
0 7 -1 10
1
end_operator
begin_operator
debark car43 loc2
1
65 11
2
0 0 38 0
0 7 -1 11
1
end_operator
begin_operator
debark car43 loc20
1
65 12
2
0 0 38 0
0 7 -1 12
1
end_operator
begin_operator
debark car43 loc21
1
65 13
2
0 0 38 0
0 7 -1 13
1
end_operator
begin_operator
debark car43 loc22
1
65 14
2
0 0 38 0
0 7 -1 14
1
end_operator
begin_operator
debark car43 loc23
1
65 15
2
0 0 38 0
0 7 -1 15
1
end_operator
begin_operator
debark car43 loc24
1
65 16
2
0 0 38 0
0 7 -1 16
1
end_operator
begin_operator
debark car43 loc25
1
65 17
2
0 0 38 0
0 7 -1 17
1
end_operator
begin_operator
debark car43 loc26
1
65 18
2
0 0 38 0
0 7 -1 18
1
end_operator
begin_operator
debark car43 loc27
1
65 19
2
0 0 38 0
0 7 -1 19
1
end_operator
begin_operator
debark car43 loc28
1
65 20
2
0 0 38 0
0 7 -1 20
1
end_operator
begin_operator
debark car43 loc29
1
65 21
2
0 0 38 0
0 7 -1 21
1
end_operator
begin_operator
debark car43 loc3
1
65 22
2
0 0 38 0
0 7 -1 22
1
end_operator
begin_operator
debark car43 loc30
1
65 23
2
0 0 38 0
0 7 -1 23
1
end_operator
begin_operator
debark car43 loc31
1
65 24
2
0 0 38 0
0 7 -1 24
1
end_operator
begin_operator
debark car43 loc32
1
65 25
2
0 0 38 0
0 7 -1 25
1
end_operator
begin_operator
debark car43 loc33
1
65 26
2
0 0 38 0
0 7 -1 26
1
end_operator
begin_operator
debark car43 loc34
1
65 27
2
0 0 38 0
0 7 -1 27
1
end_operator
begin_operator
debark car43 loc35
1
65 28
2
0 0 38 0
0 7 -1 28
1
end_operator
begin_operator
debark car43 loc36
1
65 29
2
0 0 38 0
0 7 -1 29
1
end_operator
begin_operator
debark car43 loc37
1
65 30
2
0 0 38 0
0 7 -1 30
1
end_operator
begin_operator
debark car43 loc38
1
65 31
2
0 0 38 0
0 7 -1 31
1
end_operator
begin_operator
debark car43 loc39
1
65 32
2
0 0 38 0
0 7 -1 32
1
end_operator
begin_operator
debark car43 loc4
1
65 33
2
0 0 38 0
0 7 -1 33
1
end_operator
begin_operator
debark car43 loc40
1
65 34
2
0 0 38 0
0 7 -1 34
1
end_operator
begin_operator
debark car43 loc41
1
65 35
2
0 0 38 0
0 7 -1 35
1
end_operator
begin_operator
debark car43 loc5
1
65 36
2
0 0 38 0
0 7 -1 36
1
end_operator
begin_operator
debark car43 loc6
1
65 37
2
0 0 38 0
0 7 -1 37
1
end_operator
begin_operator
debark car43 loc7
1
65 38
2
0 0 38 0
0 7 -1 38
1
end_operator
begin_operator
debark car43 loc8
1
65 39
2
0 0 38 0
0 7 -1 39
1
end_operator
begin_operator
debark car43 loc9
1
65 40
2
0 0 38 0
0 7 -1 40
1
end_operator
begin_operator
debark car44 loc1
1
65 0
2
0 0 39 0
0 19 -1 0
1
end_operator
begin_operator
debark car44 loc10
1
65 1
2
0 0 39 0
0 19 -1 1
1
end_operator
begin_operator
debark car44 loc11
1
65 2
2
0 0 39 0
0 19 -1 2
1
end_operator
begin_operator
debark car44 loc12
1
65 3
2
0 0 39 0
0 19 -1 3
1
end_operator
begin_operator
debark car44 loc13
1
65 4
2
0 0 39 0
0 19 -1 4
1
end_operator
begin_operator
debark car44 loc14
1
65 5
2
0 0 39 0
0 19 -1 5
1
end_operator
begin_operator
debark car44 loc15
1
65 6
2
0 0 39 0
0 19 -1 6
1
end_operator
begin_operator
debark car44 loc16
1
65 7
2
0 0 39 0
0 19 -1 7
1
end_operator
begin_operator
debark car44 loc17
1
65 8
2
0 0 39 0
0 19 -1 8
1
end_operator
begin_operator
debark car44 loc18
1
65 9
2
0 0 39 0
0 19 -1 9
1
end_operator
begin_operator
debark car44 loc19
1
65 10
2
0 0 39 0
0 19 -1 10
1
end_operator
begin_operator
debark car44 loc2
1
65 11
2
0 0 39 0
0 19 -1 11
1
end_operator
begin_operator
debark car44 loc20
1
65 12
2
0 0 39 0
0 19 -1 12
1
end_operator
begin_operator
debark car44 loc21
1
65 13
2
0 0 39 0
0 19 -1 13
1
end_operator
begin_operator
debark car44 loc22
1
65 14
2
0 0 39 0
0 19 -1 14
1
end_operator
begin_operator
debark car44 loc23
1
65 15
2
0 0 39 0
0 19 -1 15
1
end_operator
begin_operator
debark car44 loc24
1
65 16
2
0 0 39 0
0 19 -1 16
1
end_operator
begin_operator
debark car44 loc25
1
65 17
2
0 0 39 0
0 19 -1 17
1
end_operator
begin_operator
debark car44 loc26
1
65 18
2
0 0 39 0
0 19 -1 18
1
end_operator
begin_operator
debark car44 loc27
1
65 19
2
0 0 39 0
0 19 -1 19
1
end_operator
begin_operator
debark car44 loc28
1
65 20
2
0 0 39 0
0 19 -1 20
1
end_operator
begin_operator
debark car44 loc29
1
65 21
2
0 0 39 0
0 19 -1 21
1
end_operator
begin_operator
debark car44 loc3
1
65 22
2
0 0 39 0
0 19 -1 22
1
end_operator
begin_operator
debark car44 loc30
1
65 23
2
0 0 39 0
0 19 -1 23
1
end_operator
begin_operator
debark car44 loc31
1
65 24
2
0 0 39 0
0 19 -1 24
1
end_operator
begin_operator
debark car44 loc32
1
65 25
2
0 0 39 0
0 19 -1 25
1
end_operator
begin_operator
debark car44 loc33
1
65 26
2
0 0 39 0
0 19 -1 26
1
end_operator
begin_operator
debark car44 loc34
1
65 27
2
0 0 39 0
0 19 -1 27
1
end_operator
begin_operator
debark car44 loc35
1
65 28
2
0 0 39 0
0 19 -1 28
1
end_operator
begin_operator
debark car44 loc36
1
65 29
2
0 0 39 0
0 19 -1 29
1
end_operator
begin_operator
debark car44 loc37
1
65 30
2
0 0 39 0
0 19 -1 30
1
end_operator
begin_operator
debark car44 loc38
1
65 31
2
0 0 39 0
0 19 -1 31
1
end_operator
begin_operator
debark car44 loc39
1
65 32
2
0 0 39 0
0 19 -1 32
1
end_operator
begin_operator
debark car44 loc4
1
65 33
2
0 0 39 0
0 19 -1 33
1
end_operator
begin_operator
debark car44 loc40
1
65 34
2
0 0 39 0
0 19 -1 34
1
end_operator
begin_operator
debark car44 loc41
1
65 35
2
0 0 39 0
0 19 -1 35
1
end_operator
begin_operator
debark car44 loc5
1
65 36
2
0 0 39 0
0 19 -1 36
1
end_operator
begin_operator
debark car44 loc6
1
65 37
2
0 0 39 0
0 19 -1 37
1
end_operator
begin_operator
debark car44 loc7
1
65 38
2
0 0 39 0
0 19 -1 38
1
end_operator
begin_operator
debark car44 loc8
1
65 39
2
0 0 39 0
0 19 -1 39
1
end_operator
begin_operator
debark car44 loc9
1
65 40
2
0 0 39 0
0 19 -1 40
1
end_operator
begin_operator
debark car45 loc1
1
65 0
2
0 0 40 0
0 31 -1 0
1
end_operator
begin_operator
debark car45 loc10
1
65 1
2
0 0 40 0
0 31 -1 1
1
end_operator
begin_operator
debark car45 loc11
1
65 2
2
0 0 40 0
0 31 -1 2
1
end_operator
begin_operator
debark car45 loc12
1
65 3
2
0 0 40 0
0 31 -1 3
1
end_operator
begin_operator
debark car45 loc13
1
65 4
2
0 0 40 0
0 31 -1 4
1
end_operator
begin_operator
debark car45 loc14
1
65 5
2
0 0 40 0
0 31 -1 5
1
end_operator
begin_operator
debark car45 loc15
1
65 6
2
0 0 40 0
0 31 -1 6
1
end_operator
begin_operator
debark car45 loc16
1
65 7
2
0 0 40 0
0 31 -1 7
1
end_operator
begin_operator
debark car45 loc17
1
65 8
2
0 0 40 0
0 31 -1 8
1
end_operator
begin_operator
debark car45 loc18
1
65 9
2
0 0 40 0
0 31 -1 9
1
end_operator
begin_operator
debark car45 loc19
1
65 10
2
0 0 40 0
0 31 -1 10
1
end_operator
begin_operator
debark car45 loc2
1
65 11
2
0 0 40 0
0 31 -1 11
1
end_operator
begin_operator
debark car45 loc20
1
65 12
2
0 0 40 0
0 31 -1 12
1
end_operator
begin_operator
debark car45 loc21
1
65 13
2
0 0 40 0
0 31 -1 13
1
end_operator
begin_operator
debark car45 loc22
1
65 14
2
0 0 40 0
0 31 -1 14
1
end_operator
begin_operator
debark car45 loc23
1
65 15
2
0 0 40 0
0 31 -1 15
1
end_operator
begin_operator
debark car45 loc24
1
65 16
2
0 0 40 0
0 31 -1 16
1
end_operator
begin_operator
debark car45 loc25
1
65 17
2
0 0 40 0
0 31 -1 17
1
end_operator
begin_operator
debark car45 loc26
1
65 18
2
0 0 40 0
0 31 -1 18
1
end_operator
begin_operator
debark car45 loc27
1
65 19
2
0 0 40 0
0 31 -1 19
1
end_operator
begin_operator
debark car45 loc28
1
65 20
2
0 0 40 0
0 31 -1 20
1
end_operator
begin_operator
debark car45 loc29
1
65 21
2
0 0 40 0
0 31 -1 21
1
end_operator
begin_operator
debark car45 loc3
1
65 22
2
0 0 40 0
0 31 -1 22
1
end_operator
begin_operator
debark car45 loc30
1
65 23
2
0 0 40 0
0 31 -1 23
1
end_operator
begin_operator
debark car45 loc31
1
65 24
2
0 0 40 0
0 31 -1 24
1
end_operator
begin_operator
debark car45 loc32
1
65 25
2
0 0 40 0
0 31 -1 25
1
end_operator
begin_operator
debark car45 loc33
1
65 26
2
0 0 40 0
0 31 -1 26
1
end_operator
begin_operator
debark car45 loc34
1
65 27
2
0 0 40 0
0 31 -1 27
1
end_operator
begin_operator
debark car45 loc35
1
65 28
2
0 0 40 0
0 31 -1 28
1
end_operator
begin_operator
debark car45 loc36
1
65 29
2
0 0 40 0
0 31 -1 29
1
end_operator
begin_operator
debark car45 loc37
1
65 30
2
0 0 40 0
0 31 -1 30
1
end_operator
begin_operator
debark car45 loc38
1
65 31
2
0 0 40 0
0 31 -1 31
1
end_operator
begin_operator
debark car45 loc39
1
65 32
2
0 0 40 0
0 31 -1 32
1
end_operator
begin_operator
debark car45 loc4
1
65 33
2
0 0 40 0
0 31 -1 33
1
end_operator
begin_operator
debark car45 loc40
1
65 34
2
0 0 40 0
0 31 -1 34
1
end_operator
begin_operator
debark car45 loc41
1
65 35
2
0 0 40 0
0 31 -1 35
1
end_operator
begin_operator
debark car45 loc5
1
65 36
2
0 0 40 0
0 31 -1 36
1
end_operator
begin_operator
debark car45 loc6
1
65 37
2
0 0 40 0
0 31 -1 37
1
end_operator
begin_operator
debark car45 loc7
1
65 38
2
0 0 40 0
0 31 -1 38
1
end_operator
begin_operator
debark car45 loc8
1
65 39
2
0 0 40 0
0 31 -1 39
1
end_operator
begin_operator
debark car45 loc9
1
65 40
2
0 0 40 0
0 31 -1 40
1
end_operator
begin_operator
debark car46 loc1
1
65 0
2
0 0 41 0
0 43 -1 0
1
end_operator
begin_operator
debark car46 loc10
1
65 1
2
0 0 41 0
0 43 -1 1
1
end_operator
begin_operator
debark car46 loc11
1
65 2
2
0 0 41 0
0 43 -1 2
1
end_operator
begin_operator
debark car46 loc12
1
65 3
2
0 0 41 0
0 43 -1 3
1
end_operator
begin_operator
debark car46 loc13
1
65 4
2
0 0 41 0
0 43 -1 4
1
end_operator
begin_operator
debark car46 loc14
1
65 5
2
0 0 41 0
0 43 -1 5
1
end_operator
begin_operator
debark car46 loc15
1
65 6
2
0 0 41 0
0 43 -1 6
1
end_operator
begin_operator
debark car46 loc16
1
65 7
2
0 0 41 0
0 43 -1 7
1
end_operator
begin_operator
debark car46 loc17
1
65 8
2
0 0 41 0
0 43 -1 8
1
end_operator
begin_operator
debark car46 loc18
1
65 9
2
0 0 41 0
0 43 -1 9
1
end_operator
begin_operator
debark car46 loc19
1
65 10
2
0 0 41 0
0 43 -1 10
1
end_operator
begin_operator
debark car46 loc2
1
65 11
2
0 0 41 0
0 43 -1 11
1
end_operator
begin_operator
debark car46 loc20
1
65 12
2
0 0 41 0
0 43 -1 12
1
end_operator
begin_operator
debark car46 loc21
1
65 13
2
0 0 41 0
0 43 -1 13
1
end_operator
begin_operator
debark car46 loc22
1
65 14
2
0 0 41 0
0 43 -1 14
1
end_operator
begin_operator
debark car46 loc23
1
65 15
2
0 0 41 0
0 43 -1 15
1
end_operator
begin_operator
debark car46 loc24
1
65 16
2
0 0 41 0
0 43 -1 16
1
end_operator
begin_operator
debark car46 loc25
1
65 17
2
0 0 41 0
0 43 -1 17
1
end_operator
begin_operator
debark car46 loc26
1
65 18
2
0 0 41 0
0 43 -1 18
1
end_operator
begin_operator
debark car46 loc27
1
65 19
2
0 0 41 0
0 43 -1 19
1
end_operator
begin_operator
debark car46 loc28
1
65 20
2
0 0 41 0
0 43 -1 20
1
end_operator
begin_operator
debark car46 loc29
1
65 21
2
0 0 41 0
0 43 -1 21
1
end_operator
begin_operator
debark car46 loc3
1
65 22
2
0 0 41 0
0 43 -1 22
1
end_operator
begin_operator
debark car46 loc30
1
65 23
2
0 0 41 0
0 43 -1 23
1
end_operator
begin_operator
debark car46 loc31
1
65 24
2
0 0 41 0
0 43 -1 24
1
end_operator
begin_operator
debark car46 loc32
1
65 25
2
0 0 41 0
0 43 -1 25
1
end_operator
begin_operator
debark car46 loc33
1
65 26
2
0 0 41 0
0 43 -1 26
1
end_operator
begin_operator
debark car46 loc34
1
65 27
2
0 0 41 0
0 43 -1 27
1
end_operator
begin_operator
debark car46 loc35
1
65 28
2
0 0 41 0
0 43 -1 28
1
end_operator
begin_operator
debark car46 loc36
1
65 29
2
0 0 41 0
0 43 -1 29
1
end_operator
begin_operator
debark car46 loc37
1
65 30
2
0 0 41 0
0 43 -1 30
1
end_operator
begin_operator
debark car46 loc38
1
65 31
2
0 0 41 0
0 43 -1 31
1
end_operator
begin_operator
debark car46 loc39
1
65 32
2
0 0 41 0
0 43 -1 32
1
end_operator
begin_operator
debark car46 loc4
1
65 33
2
0 0 41 0
0 43 -1 33
1
end_operator
begin_operator
debark car46 loc40
1
65 34
2
0 0 41 0
0 43 -1 34
1
end_operator
begin_operator
debark car46 loc41
1
65 35
2
0 0 41 0
0 43 -1 35
1
end_operator
begin_operator
debark car46 loc5
1
65 36
2
0 0 41 0
0 43 -1 36
1
end_operator
begin_operator
debark car46 loc6
1
65 37
2
0 0 41 0
0 43 -1 37
1
end_operator
begin_operator
debark car46 loc7
1
65 38
2
0 0 41 0
0 43 -1 38
1
end_operator
begin_operator
debark car46 loc8
1
65 39
2
0 0 41 0
0 43 -1 39
1
end_operator
begin_operator
debark car46 loc9
1
65 40
2
0 0 41 0
0 43 -1 40
1
end_operator
begin_operator
debark car47 loc1
1
65 0
2
0 0 42 0
0 55 -1 0
1
end_operator
begin_operator
debark car47 loc10
1
65 1
2
0 0 42 0
0 55 -1 1
1
end_operator
begin_operator
debark car47 loc11
1
65 2
2
0 0 42 0
0 55 -1 2
1
end_operator
begin_operator
debark car47 loc12
1
65 3
2
0 0 42 0
0 55 -1 3
1
end_operator
begin_operator
debark car47 loc13
1
65 4
2
0 0 42 0
0 55 -1 4
1
end_operator
begin_operator
debark car47 loc14
1
65 5
2
0 0 42 0
0 55 -1 5
1
end_operator
begin_operator
debark car47 loc15
1
65 6
2
0 0 42 0
0 55 -1 6
1
end_operator
begin_operator
debark car47 loc16
1
65 7
2
0 0 42 0
0 55 -1 7
1
end_operator
begin_operator
debark car47 loc17
1
65 8
2
0 0 42 0
0 55 -1 8
1
end_operator
begin_operator
debark car47 loc18
1
65 9
2
0 0 42 0
0 55 -1 9
1
end_operator
begin_operator
debark car47 loc19
1
65 10
2
0 0 42 0
0 55 -1 10
1
end_operator
begin_operator
debark car47 loc2
1
65 11
2
0 0 42 0
0 55 -1 11
1
end_operator
begin_operator
debark car47 loc20
1
65 12
2
0 0 42 0
0 55 -1 12
1
end_operator
begin_operator
debark car47 loc21
1
65 13
2
0 0 42 0
0 55 -1 13
1
end_operator
begin_operator
debark car47 loc22
1
65 14
2
0 0 42 0
0 55 -1 14
1
end_operator
begin_operator
debark car47 loc23
1
65 15
2
0 0 42 0
0 55 -1 15
1
end_operator
begin_operator
debark car47 loc24
1
65 16
2
0 0 42 0
0 55 -1 16
1
end_operator
begin_operator
debark car47 loc25
1
65 17
2
0 0 42 0
0 55 -1 17
1
end_operator
begin_operator
debark car47 loc26
1
65 18
2
0 0 42 0
0 55 -1 18
1
end_operator
begin_operator
debark car47 loc27
1
65 19
2
0 0 42 0
0 55 -1 19
1
end_operator
begin_operator
debark car47 loc28
1
65 20
2
0 0 42 0
0 55 -1 20
1
end_operator
begin_operator
debark car47 loc29
1
65 21
2
0 0 42 0
0 55 -1 21
1
end_operator
begin_operator
debark car47 loc3
1
65 22
2
0 0 42 0
0 55 -1 22
1
end_operator
begin_operator
debark car47 loc30
1
65 23
2
0 0 42 0
0 55 -1 23
1
end_operator
begin_operator
debark car47 loc31
1
65 24
2
0 0 42 0
0 55 -1 24
1
end_operator
begin_operator
debark car47 loc32
1
65 25
2
0 0 42 0
0 55 -1 25
1
end_operator
begin_operator
debark car47 loc33
1
65 26
2
0 0 42 0
0 55 -1 26
1
end_operator
begin_operator
debark car47 loc34
1
65 27
2
0 0 42 0
0 55 -1 27
1
end_operator
begin_operator
debark car47 loc35
1
65 28
2
0 0 42 0
0 55 -1 28
1
end_operator
begin_operator
debark car47 loc36
1
65 29
2
0 0 42 0
0 55 -1 29
1
end_operator
begin_operator
debark car47 loc37
1
65 30
2
0 0 42 0
0 55 -1 30
1
end_operator
begin_operator
debark car47 loc38
1
65 31
2
0 0 42 0
0 55 -1 31
1
end_operator
begin_operator
debark car47 loc39
1
65 32
2
0 0 42 0
0 55 -1 32
1
end_operator
begin_operator
debark car47 loc4
1
65 33
2
0 0 42 0
0 55 -1 33
1
end_operator
begin_operator
debark car47 loc40
1
65 34
2
0 0 42 0
0 55 -1 34
1
end_operator
begin_operator
debark car47 loc41
1
65 35
2
0 0 42 0
0 55 -1 35
1
end_operator
begin_operator
debark car47 loc5
1
65 36
2
0 0 42 0
0 55 -1 36
1
end_operator
begin_operator
debark car47 loc6
1
65 37
2
0 0 42 0
0 55 -1 37
1
end_operator
begin_operator
debark car47 loc7
1
65 38
2
0 0 42 0
0 55 -1 38
1
end_operator
begin_operator
debark car47 loc8
1
65 39
2
0 0 42 0
0 55 -1 39
1
end_operator
begin_operator
debark car47 loc9
1
65 40
2
0 0 42 0
0 55 -1 40
1
end_operator
begin_operator
debark car48 loc1
1
65 0
2
0 0 43 0
0 67 -1 0
1
end_operator
begin_operator
debark car48 loc10
1
65 1
2
0 0 43 0
0 67 -1 1
1
end_operator
begin_operator
debark car48 loc11
1
65 2
2
0 0 43 0
0 67 -1 2
1
end_operator
begin_operator
debark car48 loc12
1
65 3
2
0 0 43 0
0 67 -1 3
1
end_operator
begin_operator
debark car48 loc13
1
65 4
2
0 0 43 0
0 67 -1 4
1
end_operator
begin_operator
debark car48 loc14
1
65 5
2
0 0 43 0
0 67 -1 5
1
end_operator
begin_operator
debark car48 loc15
1
65 6
2
0 0 43 0
0 67 -1 6
1
end_operator
begin_operator
debark car48 loc16
1
65 7
2
0 0 43 0
0 67 -1 7
1
end_operator
begin_operator
debark car48 loc17
1
65 8
2
0 0 43 0
0 67 -1 8
1
end_operator
begin_operator
debark car48 loc18
1
65 9
2
0 0 43 0
0 67 -1 9
1
end_operator
begin_operator
debark car48 loc19
1
65 10
2
0 0 43 0
0 67 -1 10
1
end_operator
begin_operator
debark car48 loc2
1
65 11
2
0 0 43 0
0 67 -1 11
1
end_operator
begin_operator
debark car48 loc20
1
65 12
2
0 0 43 0
0 67 -1 12
1
end_operator
begin_operator
debark car48 loc21
1
65 13
2
0 0 43 0
0 67 -1 13
1
end_operator
begin_operator
debark car48 loc22
1
65 14
2
0 0 43 0
0 67 -1 14
1
end_operator
begin_operator
debark car48 loc23
1
65 15
2
0 0 43 0
0 67 -1 15
1
end_operator
begin_operator
debark car48 loc24
1
65 16
2
0 0 43 0
0 67 -1 16
1
end_operator
begin_operator
debark car48 loc25
1
65 17
2
0 0 43 0
0 67 -1 17
1
end_operator
begin_operator
debark car48 loc26
1
65 18
2
0 0 43 0
0 67 -1 18
1
end_operator
begin_operator
debark car48 loc27
1
65 19
2
0 0 43 0
0 67 -1 19
1
end_operator
begin_operator
debark car48 loc28
1
65 20
2
0 0 43 0
0 67 -1 20
1
end_operator
begin_operator
debark car48 loc29
1
65 21
2
0 0 43 0
0 67 -1 21
1
end_operator
begin_operator
debark car48 loc3
1
65 22
2
0 0 43 0
0 67 -1 22
1
end_operator
begin_operator
debark car48 loc30
1
65 23
2
0 0 43 0
0 67 -1 23
1
end_operator
begin_operator
debark car48 loc31
1
65 24
2
0 0 43 0
0 67 -1 24
1
end_operator
begin_operator
debark car48 loc32
1
65 25
2
0 0 43 0
0 67 -1 25
1
end_operator
begin_operator
debark car48 loc33
1
65 26
2
0 0 43 0
0 67 -1 26
1
end_operator
begin_operator
debark car48 loc34
1
65 27
2
0 0 43 0
0 67 -1 27
1
end_operator
begin_operator
debark car48 loc35
1
65 28
2
0 0 43 0
0 67 -1 28
1
end_operator
begin_operator
debark car48 loc36
1
65 29
2
0 0 43 0
0 67 -1 29
1
end_operator
begin_operator
debark car48 loc37
1
65 30
2
0 0 43 0
0 67 -1 30
1
end_operator
begin_operator
debark car48 loc38
1
65 31
2
0 0 43 0
0 67 -1 31
1
end_operator
begin_operator
debark car48 loc39
1
65 32
2
0 0 43 0
0 67 -1 32
1
end_operator
begin_operator
debark car48 loc4
1
65 33
2
0 0 43 0
0 67 -1 33
1
end_operator
begin_operator
debark car48 loc40
1
65 34
2
0 0 43 0
0 67 -1 34
1
end_operator
begin_operator
debark car48 loc41
1
65 35
2
0 0 43 0
0 67 -1 35
1
end_operator
begin_operator
debark car48 loc5
1
65 36
2
0 0 43 0
0 67 -1 36
1
end_operator
begin_operator
debark car48 loc6
1
65 37
2
0 0 43 0
0 67 -1 37
1
end_operator
begin_operator
debark car48 loc7
1
65 38
2
0 0 43 0
0 67 -1 38
1
end_operator
begin_operator
debark car48 loc8
1
65 39
2
0 0 43 0
0 67 -1 39
1
end_operator
begin_operator
debark car48 loc9
1
65 40
2
0 0 43 0
0 67 -1 40
1
end_operator
begin_operator
debark car49 loc1
1
65 0
2
0 0 44 0
0 4 -1 0
1
end_operator
begin_operator
debark car49 loc10
1
65 1
2
0 0 44 0
0 4 -1 1
1
end_operator
begin_operator
debark car49 loc11
1
65 2
2
0 0 44 0
0 4 -1 2
1
end_operator
begin_operator
debark car49 loc12
1
65 3
2
0 0 44 0
0 4 -1 3
1
end_operator
begin_operator
debark car49 loc13
1
65 4
2
0 0 44 0
0 4 -1 4
1
end_operator
begin_operator
debark car49 loc14
1
65 5
2
0 0 44 0
0 4 -1 5
1
end_operator
begin_operator
debark car49 loc15
1
65 6
2
0 0 44 0
0 4 -1 6
1
end_operator
begin_operator
debark car49 loc16
1
65 7
2
0 0 44 0
0 4 -1 7
1
end_operator
begin_operator
debark car49 loc17
1
65 8
2
0 0 44 0
0 4 -1 8
1
end_operator
begin_operator
debark car49 loc18
1
65 9
2
0 0 44 0
0 4 -1 9
1
end_operator
begin_operator
debark car49 loc19
1
65 10
2
0 0 44 0
0 4 -1 10
1
end_operator
begin_operator
debark car49 loc2
1
65 11
2
0 0 44 0
0 4 -1 11
1
end_operator
begin_operator
debark car49 loc20
1
65 12
2
0 0 44 0
0 4 -1 12
1
end_operator
begin_operator
debark car49 loc21
1
65 13
2
0 0 44 0
0 4 -1 13
1
end_operator
begin_operator
debark car49 loc22
1
65 14
2
0 0 44 0
0 4 -1 14
1
end_operator
begin_operator
debark car49 loc23
1
65 15
2
0 0 44 0
0 4 -1 15
1
end_operator
begin_operator
debark car49 loc24
1
65 16
2
0 0 44 0
0 4 -1 16
1
end_operator
begin_operator
debark car49 loc25
1
65 17
2
0 0 44 0
0 4 -1 17
1
end_operator
begin_operator
debark car49 loc26
1
65 18
2
0 0 44 0
0 4 -1 18
1
end_operator
begin_operator
debark car49 loc27
1
65 19
2
0 0 44 0
0 4 -1 19
1
end_operator
begin_operator
debark car49 loc28
1
65 20
2
0 0 44 0
0 4 -1 20
1
end_operator
begin_operator
debark car49 loc29
1
65 21
2
0 0 44 0
0 4 -1 21
1
end_operator
begin_operator
debark car49 loc3
1
65 22
2
0 0 44 0
0 4 -1 22
1
end_operator
begin_operator
debark car49 loc30
1
65 23
2
0 0 44 0
0 4 -1 23
1
end_operator
begin_operator
debark car49 loc31
1
65 24
2
0 0 44 0
0 4 -1 24
1
end_operator
begin_operator
debark car49 loc32
1
65 25
2
0 0 44 0
0 4 -1 25
1
end_operator
begin_operator
debark car49 loc33
1
65 26
2
0 0 44 0
0 4 -1 26
1
end_operator
begin_operator
debark car49 loc34
1
65 27
2
0 0 44 0
0 4 -1 27
1
end_operator
begin_operator
debark car49 loc35
1
65 28
2
0 0 44 0
0 4 -1 28
1
end_operator
begin_operator
debark car49 loc36
1
65 29
2
0 0 44 0
0 4 -1 29
1
end_operator
begin_operator
debark car49 loc37
1
65 30
2
0 0 44 0
0 4 -1 30
1
end_operator
begin_operator
debark car49 loc38
1
65 31
2
0 0 44 0
0 4 -1 31
1
end_operator
begin_operator
debark car49 loc39
1
65 32
2
0 0 44 0
0 4 -1 32
1
end_operator
begin_operator
debark car49 loc4
1
65 33
2
0 0 44 0
0 4 -1 33
1
end_operator
begin_operator
debark car49 loc40
1
65 34
2
0 0 44 0
0 4 -1 34
1
end_operator
begin_operator
debark car49 loc41
1
65 35
2
0 0 44 0
0 4 -1 35
1
end_operator
begin_operator
debark car49 loc5
1
65 36
2
0 0 44 0
0 4 -1 36
1
end_operator
begin_operator
debark car49 loc6
1
65 37
2
0 0 44 0
0 4 -1 37
1
end_operator
begin_operator
debark car49 loc7
1
65 38
2
0 0 44 0
0 4 -1 38
1
end_operator
begin_operator
debark car49 loc8
1
65 39
2
0 0 44 0
0 4 -1 39
1
end_operator
begin_operator
debark car49 loc9
1
65 40
2
0 0 44 0
0 4 -1 40
1
end_operator
begin_operator
debark car5 loc1
1
65 0
2
0 0 45 0
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
65 1
2
0 0 45 0
0 16 -1 1
1
end_operator
begin_operator
debark car5 loc11
1
65 2
2
0 0 45 0
0 16 -1 2
1
end_operator
begin_operator
debark car5 loc12
1
65 3
2
0 0 45 0
0 16 -1 3
1
end_operator
begin_operator
debark car5 loc13
1
65 4
2
0 0 45 0
0 16 -1 4
1
end_operator
begin_operator
debark car5 loc14
1
65 5
2
0 0 45 0
0 16 -1 5
1
end_operator
begin_operator
debark car5 loc15
1
65 6
2
0 0 45 0
0 16 -1 6
1
end_operator
begin_operator
debark car5 loc16
1
65 7
2
0 0 45 0
0 16 -1 7
1
end_operator
begin_operator
debark car5 loc17
1
65 8
2
0 0 45 0
0 16 -1 8
1
end_operator
begin_operator
debark car5 loc18
1
65 9
2
0 0 45 0
0 16 -1 9
1
end_operator
begin_operator
debark car5 loc19
1
65 10
2
0 0 45 0
0 16 -1 10
1
end_operator
begin_operator
debark car5 loc2
1
65 11
2
0 0 45 0
0 16 -1 11
1
end_operator
begin_operator
debark car5 loc20
1
65 12
2
0 0 45 0
0 16 -1 12
1
end_operator
begin_operator
debark car5 loc21
1
65 13
2
0 0 45 0
0 16 -1 13
1
end_operator
begin_operator
debark car5 loc22
1
65 14
2
0 0 45 0
0 16 -1 14
1
end_operator
begin_operator
debark car5 loc23
1
65 15
2
0 0 45 0
0 16 -1 15
1
end_operator
begin_operator
debark car5 loc24
1
65 16
2
0 0 45 0
0 16 -1 16
1
end_operator
begin_operator
debark car5 loc25
1
65 17
2
0 0 45 0
0 16 -1 17
1
end_operator
begin_operator
debark car5 loc26
1
65 18
2
0 0 45 0
0 16 -1 18
1
end_operator
begin_operator
debark car5 loc27
1
65 19
2
0 0 45 0
0 16 -1 19
1
end_operator
begin_operator
debark car5 loc28
1
65 20
2
0 0 45 0
0 16 -1 20
1
end_operator
begin_operator
debark car5 loc29
1
65 21
2
0 0 45 0
0 16 -1 21
1
end_operator
begin_operator
debark car5 loc3
1
65 22
2
0 0 45 0
0 16 -1 22
1
end_operator
begin_operator
debark car5 loc30
1
65 23
2
0 0 45 0
0 16 -1 23
1
end_operator
begin_operator
debark car5 loc31
1
65 24
2
0 0 45 0
0 16 -1 24
1
end_operator
begin_operator
debark car5 loc32
1
65 25
2
0 0 45 0
0 16 -1 25
1
end_operator
begin_operator
debark car5 loc33
1
65 26
2
0 0 45 0
0 16 -1 26
1
end_operator
begin_operator
debark car5 loc34
1
65 27
2
0 0 45 0
0 16 -1 27
1
end_operator
begin_operator
debark car5 loc35
1
65 28
2
0 0 45 0
0 16 -1 28
1
end_operator
begin_operator
debark car5 loc36
1
65 29
2
0 0 45 0
0 16 -1 29
1
end_operator
begin_operator
debark car5 loc37
1
65 30
2
0 0 45 0
0 16 -1 30
1
end_operator
begin_operator
debark car5 loc38
1
65 31
2
0 0 45 0
0 16 -1 31
1
end_operator
begin_operator
debark car5 loc39
1
65 32
2
0 0 45 0
0 16 -1 32
1
end_operator
begin_operator
debark car5 loc4
1
65 33
2
0 0 45 0
0 16 -1 33
1
end_operator
begin_operator
debark car5 loc40
1
65 34
2
0 0 45 0
0 16 -1 34
1
end_operator
begin_operator
debark car5 loc41
1
65 35
2
0 0 45 0
0 16 -1 35
1
end_operator
begin_operator
debark car5 loc5
1
65 36
2
0 0 45 0
0 16 -1 36
1
end_operator
begin_operator
debark car5 loc6
1
65 37
2
0 0 45 0
0 16 -1 37
1
end_operator
begin_operator
debark car5 loc7
1
65 38
2
0 0 45 0
0 16 -1 38
1
end_operator
begin_operator
debark car5 loc8
1
65 39
2
0 0 45 0
0 16 -1 39
1
end_operator
begin_operator
debark car5 loc9
1
65 40
2
0 0 45 0
0 16 -1 40
1
end_operator
begin_operator
debark car50 loc1
1
65 0
2
0 0 46 0
0 28 -1 0
1
end_operator
begin_operator
debark car50 loc10
1
65 1
2
0 0 46 0
0 28 -1 1
1
end_operator
begin_operator
debark car50 loc11
1
65 2
2
0 0 46 0
0 28 -1 2
1
end_operator
begin_operator
debark car50 loc12
1
65 3
2
0 0 46 0
0 28 -1 3
1
end_operator
begin_operator
debark car50 loc13
1
65 4
2
0 0 46 0
0 28 -1 4
1
end_operator
begin_operator
debark car50 loc14
1
65 5
2
0 0 46 0
0 28 -1 5
1
end_operator
begin_operator
debark car50 loc15
1
65 6
2
0 0 46 0
0 28 -1 6
1
end_operator
begin_operator
debark car50 loc16
1
65 7
2
0 0 46 0
0 28 -1 7
1
end_operator
begin_operator
debark car50 loc17
1
65 8
2
0 0 46 0
0 28 -1 8
1
end_operator
begin_operator
debark car50 loc18
1
65 9
2
0 0 46 0
0 28 -1 9
1
end_operator
begin_operator
debark car50 loc19
1
65 10
2
0 0 46 0
0 28 -1 10
1
end_operator
begin_operator
debark car50 loc2
1
65 11
2
0 0 46 0
0 28 -1 11
1
end_operator
begin_operator
debark car50 loc20
1
65 12
2
0 0 46 0
0 28 -1 12
1
end_operator
begin_operator
debark car50 loc21
1
65 13
2
0 0 46 0
0 28 -1 13
1
end_operator
begin_operator
debark car50 loc22
1
65 14
2
0 0 46 0
0 28 -1 14
1
end_operator
begin_operator
debark car50 loc23
1
65 15
2
0 0 46 0
0 28 -1 15
1
end_operator
begin_operator
debark car50 loc24
1
65 16
2
0 0 46 0
0 28 -1 16
1
end_operator
begin_operator
debark car50 loc25
1
65 17
2
0 0 46 0
0 28 -1 17
1
end_operator
begin_operator
debark car50 loc26
1
65 18
2
0 0 46 0
0 28 -1 18
1
end_operator
begin_operator
debark car50 loc27
1
65 19
2
0 0 46 0
0 28 -1 19
1
end_operator
begin_operator
debark car50 loc28
1
65 20
2
0 0 46 0
0 28 -1 20
1
end_operator
begin_operator
debark car50 loc29
1
65 21
2
0 0 46 0
0 28 -1 21
1
end_operator
begin_operator
debark car50 loc3
1
65 22
2
0 0 46 0
0 28 -1 22
1
end_operator
begin_operator
debark car50 loc30
1
65 23
2
0 0 46 0
0 28 -1 23
1
end_operator
begin_operator
debark car50 loc31
1
65 24
2
0 0 46 0
0 28 -1 24
1
end_operator
begin_operator
debark car50 loc32
1
65 25
2
0 0 46 0
0 28 -1 25
1
end_operator
begin_operator
debark car50 loc33
1
65 26
2
0 0 46 0
0 28 -1 26
1
end_operator
begin_operator
debark car50 loc34
1
65 27
2
0 0 46 0
0 28 -1 27
1
end_operator
begin_operator
debark car50 loc35
1
65 28
2
0 0 46 0
0 28 -1 28
1
end_operator
begin_operator
debark car50 loc36
1
65 29
2
0 0 46 0
0 28 -1 29
1
end_operator
begin_operator
debark car50 loc37
1
65 30
2
0 0 46 0
0 28 -1 30
1
end_operator
begin_operator
debark car50 loc38
1
65 31
2
0 0 46 0
0 28 -1 31
1
end_operator
begin_operator
debark car50 loc39
1
65 32
2
0 0 46 0
0 28 -1 32
1
end_operator
begin_operator
debark car50 loc4
1
65 33
2
0 0 46 0
0 28 -1 33
1
end_operator
begin_operator
debark car50 loc40
1
65 34
2
0 0 46 0
0 28 -1 34
1
end_operator
begin_operator
debark car50 loc41
1
65 35
2
0 0 46 0
0 28 -1 35
1
end_operator
begin_operator
debark car50 loc5
1
65 36
2
0 0 46 0
0 28 -1 36
1
end_operator
begin_operator
debark car50 loc6
1
65 37
2
0 0 46 0
0 28 -1 37
1
end_operator
begin_operator
debark car50 loc7
1
65 38
2
0 0 46 0
0 28 -1 38
1
end_operator
begin_operator
debark car50 loc8
1
65 39
2
0 0 46 0
0 28 -1 39
1
end_operator
begin_operator
debark car50 loc9
1
65 40
2
0 0 46 0
0 28 -1 40
1
end_operator
begin_operator
debark car51 loc1
1
65 0
2
0 0 47 0
0 40 -1 0
1
end_operator
begin_operator
debark car51 loc10
1
65 1
2
0 0 47 0
0 40 -1 1
1
end_operator
begin_operator
debark car51 loc11
1
65 2
2
0 0 47 0
0 40 -1 2
1
end_operator
begin_operator
debark car51 loc12
1
65 3
2
0 0 47 0
0 40 -1 3
1
end_operator
begin_operator
debark car51 loc13
1
65 4
2
0 0 47 0
0 40 -1 4
1
end_operator
begin_operator
debark car51 loc14
1
65 5
2
0 0 47 0
0 40 -1 5
1
end_operator
begin_operator
debark car51 loc15
1
65 6
2
0 0 47 0
0 40 -1 6
1
end_operator
begin_operator
debark car51 loc16
1
65 7
2
0 0 47 0
0 40 -1 7
1
end_operator
begin_operator
debark car51 loc17
1
65 8
2
0 0 47 0
0 40 -1 8
1
end_operator
begin_operator
debark car51 loc18
1
65 9
2
0 0 47 0
0 40 -1 9
1
end_operator
begin_operator
debark car51 loc19
1
65 10
2
0 0 47 0
0 40 -1 10
1
end_operator
begin_operator
debark car51 loc2
1
65 11
2
0 0 47 0
0 40 -1 11
1
end_operator
begin_operator
debark car51 loc20
1
65 12
2
0 0 47 0
0 40 -1 12
1
end_operator
begin_operator
debark car51 loc21
1
65 13
2
0 0 47 0
0 40 -1 13
1
end_operator
begin_operator
debark car51 loc22
1
65 14
2
0 0 47 0
0 40 -1 14
1
end_operator
begin_operator
debark car51 loc23
1
65 15
2
0 0 47 0
0 40 -1 15
1
end_operator
begin_operator
debark car51 loc24
1
65 16
2
0 0 47 0
0 40 -1 16
1
end_operator
begin_operator
debark car51 loc25
1
65 17
2
0 0 47 0
0 40 -1 17
1
end_operator
begin_operator
debark car51 loc26
1
65 18
2
0 0 47 0
0 40 -1 18
1
end_operator
begin_operator
debark car51 loc27
1
65 19
2
0 0 47 0
0 40 -1 19
1
end_operator
begin_operator
debark car51 loc28
1
65 20
2
0 0 47 0
0 40 -1 20
1
end_operator
begin_operator
debark car51 loc29
1
65 21
2
0 0 47 0
0 40 -1 21
1
end_operator
begin_operator
debark car51 loc3
1
65 22
2
0 0 47 0
0 40 -1 22
1
end_operator
begin_operator
debark car51 loc30
1
65 23
2
0 0 47 0
0 40 -1 23
1
end_operator
begin_operator
debark car51 loc31
1
65 24
2
0 0 47 0
0 40 -1 24
1
end_operator
begin_operator
debark car51 loc32
1
65 25
2
0 0 47 0
0 40 -1 25
1
end_operator
begin_operator
debark car51 loc33
1
65 26
2
0 0 47 0
0 40 -1 26
1
end_operator
begin_operator
debark car51 loc34
1
65 27
2
0 0 47 0
0 40 -1 27
1
end_operator
begin_operator
debark car51 loc35
1
65 28
2
0 0 47 0
0 40 -1 28
1
end_operator
begin_operator
debark car51 loc36
1
65 29
2
0 0 47 0
0 40 -1 29
1
end_operator
begin_operator
debark car51 loc37
1
65 30
2
0 0 47 0
0 40 -1 30
1
end_operator
begin_operator
debark car51 loc38
1
65 31
2
0 0 47 0
0 40 -1 31
1
end_operator
begin_operator
debark car51 loc39
1
65 32
2
0 0 47 0
0 40 -1 32
1
end_operator
begin_operator
debark car51 loc4
1
65 33
2
0 0 47 0
0 40 -1 33
1
end_operator
begin_operator
debark car51 loc40
1
65 34
2
0 0 47 0
0 40 -1 34
1
end_operator
begin_operator
debark car51 loc41
1
65 35
2
0 0 47 0
0 40 -1 35
1
end_operator
begin_operator
debark car51 loc5
1
65 36
2
0 0 47 0
0 40 -1 36
1
end_operator
begin_operator
debark car51 loc6
1
65 37
2
0 0 47 0
0 40 -1 37
1
end_operator
begin_operator
debark car51 loc7
1
65 38
2
0 0 47 0
0 40 -1 38
1
end_operator
begin_operator
debark car51 loc8
1
65 39
2
0 0 47 0
0 40 -1 39
1
end_operator
begin_operator
debark car51 loc9
1
65 40
2
0 0 47 0
0 40 -1 40
1
end_operator
begin_operator
debark car52 loc1
1
65 0
2
0 0 48 0
0 52 -1 0
1
end_operator
begin_operator
debark car52 loc10
1
65 1
2
0 0 48 0
0 52 -1 1
1
end_operator
begin_operator
debark car52 loc11
1
65 2
2
0 0 48 0
0 52 -1 2
1
end_operator
begin_operator
debark car52 loc12
1
65 3
2
0 0 48 0
0 52 -1 3
1
end_operator
begin_operator
debark car52 loc13
1
65 4
2
0 0 48 0
0 52 -1 4
1
end_operator
begin_operator
debark car52 loc14
1
65 5
2
0 0 48 0
0 52 -1 5
1
end_operator
begin_operator
debark car52 loc15
1
65 6
2
0 0 48 0
0 52 -1 6
1
end_operator
begin_operator
debark car52 loc16
1
65 7
2
0 0 48 0
0 52 -1 7
1
end_operator
begin_operator
debark car52 loc17
1
65 8
2
0 0 48 0
0 52 -1 8
1
end_operator
begin_operator
debark car52 loc18
1
65 9
2
0 0 48 0
0 52 -1 9
1
end_operator
begin_operator
debark car52 loc19
1
65 10
2
0 0 48 0
0 52 -1 10
1
end_operator
begin_operator
debark car52 loc2
1
65 11
2
0 0 48 0
0 52 -1 11
1
end_operator
begin_operator
debark car52 loc20
1
65 12
2
0 0 48 0
0 52 -1 12
1
end_operator
begin_operator
debark car52 loc21
1
65 13
2
0 0 48 0
0 52 -1 13
1
end_operator
begin_operator
debark car52 loc22
1
65 14
2
0 0 48 0
0 52 -1 14
1
end_operator
begin_operator
debark car52 loc23
1
65 15
2
0 0 48 0
0 52 -1 15
1
end_operator
begin_operator
debark car52 loc24
1
65 16
2
0 0 48 0
0 52 -1 16
1
end_operator
begin_operator
debark car52 loc25
1
65 17
2
0 0 48 0
0 52 -1 17
1
end_operator
begin_operator
debark car52 loc26
1
65 18
2
0 0 48 0
0 52 -1 18
1
end_operator
begin_operator
debark car52 loc27
1
65 19
2
0 0 48 0
0 52 -1 19
1
end_operator
begin_operator
debark car52 loc28
1
65 20
2
0 0 48 0
0 52 -1 20
1
end_operator
begin_operator
debark car52 loc29
1
65 21
2
0 0 48 0
0 52 -1 21
1
end_operator
begin_operator
debark car52 loc3
1
65 22
2
0 0 48 0
0 52 -1 22
1
end_operator
begin_operator
debark car52 loc30
1
65 23
2
0 0 48 0
0 52 -1 23
1
end_operator
begin_operator
debark car52 loc31
1
65 24
2
0 0 48 0
0 52 -1 24
1
end_operator
begin_operator
debark car52 loc32
1
65 25
2
0 0 48 0
0 52 -1 25
1
end_operator
begin_operator
debark car52 loc33
1
65 26
2
0 0 48 0
0 52 -1 26
1
end_operator
begin_operator
debark car52 loc34
1
65 27
2
0 0 48 0
0 52 -1 27
1
end_operator
begin_operator
debark car52 loc35
1
65 28
2
0 0 48 0
0 52 -1 28
1
end_operator
begin_operator
debark car52 loc36
1
65 29
2
0 0 48 0
0 52 -1 29
1
end_operator
begin_operator
debark car52 loc37
1
65 30
2
0 0 48 0
0 52 -1 30
1
end_operator
begin_operator
debark car52 loc38
1
65 31
2
0 0 48 0
0 52 -1 31
1
end_operator
begin_operator
debark car52 loc39
1
65 32
2
0 0 48 0
0 52 -1 32
1
end_operator
begin_operator
debark car52 loc4
1
65 33
2
0 0 48 0
0 52 -1 33
1
end_operator
begin_operator
debark car52 loc40
1
65 34
2
0 0 48 0
0 52 -1 34
1
end_operator
begin_operator
debark car52 loc41
1
65 35
2
0 0 48 0
0 52 -1 35
1
end_operator
begin_operator
debark car52 loc5
1
65 36
2
0 0 48 0
0 52 -1 36
1
end_operator
begin_operator
debark car52 loc6
1
65 37
2
0 0 48 0
0 52 -1 37
1
end_operator
begin_operator
debark car52 loc7
1
65 38
2
0 0 48 0
0 52 -1 38
1
end_operator
begin_operator
debark car52 loc8
1
65 39
2
0 0 48 0
0 52 -1 39
1
end_operator
begin_operator
debark car52 loc9
1
65 40
2
0 0 48 0
0 52 -1 40
1
end_operator
begin_operator
debark car53 loc1
1
65 0
2
0 0 49 0
0 64 -1 0
1
end_operator
begin_operator
debark car53 loc10
1
65 1
2
0 0 49 0
0 64 -1 1
1
end_operator
begin_operator
debark car53 loc11
1
65 2
2
0 0 49 0
0 64 -1 2
1
end_operator
begin_operator
debark car53 loc12
1
65 3
2
0 0 49 0
0 64 -1 3
1
end_operator
begin_operator
debark car53 loc13
1
65 4
2
0 0 49 0
0 64 -1 4
1
end_operator
begin_operator
debark car53 loc14
1
65 5
2
0 0 49 0
0 64 -1 5
1
end_operator
begin_operator
debark car53 loc15
1
65 6
2
0 0 49 0
0 64 -1 6
1
end_operator
begin_operator
debark car53 loc16
1
65 7
2
0 0 49 0
0 64 -1 7
1
end_operator
begin_operator
debark car53 loc17
1
65 8
2
0 0 49 0
0 64 -1 8
1
end_operator
begin_operator
debark car53 loc18
1
65 9
2
0 0 49 0
0 64 -1 9
1
end_operator
begin_operator
debark car53 loc19
1
65 10
2
0 0 49 0
0 64 -1 10
1
end_operator
begin_operator
debark car53 loc2
1
65 11
2
0 0 49 0
0 64 -1 11
1
end_operator
begin_operator
debark car53 loc20
1
65 12
2
0 0 49 0
0 64 -1 12
1
end_operator
begin_operator
debark car53 loc21
1
65 13
2
0 0 49 0
0 64 -1 13
1
end_operator
begin_operator
debark car53 loc22
1
65 14
2
0 0 49 0
0 64 -1 14
1
end_operator
begin_operator
debark car53 loc23
1
65 15
2
0 0 49 0
0 64 -1 15
1
end_operator
begin_operator
debark car53 loc24
1
65 16
2
0 0 49 0
0 64 -1 16
1
end_operator
begin_operator
debark car53 loc25
1
65 17
2
0 0 49 0
0 64 -1 17
1
end_operator
begin_operator
debark car53 loc26
1
65 18
2
0 0 49 0
0 64 -1 18
1
end_operator
begin_operator
debark car53 loc27
1
65 19
2
0 0 49 0
0 64 -1 19
1
end_operator
begin_operator
debark car53 loc28
1
65 20
2
0 0 49 0
0 64 -1 20
1
end_operator
begin_operator
debark car53 loc29
1
65 21
2
0 0 49 0
0 64 -1 21
1
end_operator
begin_operator
debark car53 loc3
1
65 22
2
0 0 49 0
0 64 -1 22
1
end_operator
begin_operator
debark car53 loc30
1
65 23
2
0 0 49 0
0 64 -1 23
1
end_operator
begin_operator
debark car53 loc31
1
65 24
2
0 0 49 0
0 64 -1 24
1
end_operator
begin_operator
debark car53 loc32
1
65 25
2
0 0 49 0
0 64 -1 25
1
end_operator
begin_operator
debark car53 loc33
1
65 26
2
0 0 49 0
0 64 -1 26
1
end_operator
begin_operator
debark car53 loc34
1
65 27
2
0 0 49 0
0 64 -1 27
1
end_operator
begin_operator
debark car53 loc35
1
65 28
2
0 0 49 0
0 64 -1 28
1
end_operator
begin_operator
debark car53 loc36
1
65 29
2
0 0 49 0
0 64 -1 29
1
end_operator
begin_operator
debark car53 loc37
1
65 30
2
0 0 49 0
0 64 -1 30
1
end_operator
begin_operator
debark car53 loc38
1
65 31
2
0 0 49 0
0 64 -1 31
1
end_operator
begin_operator
debark car53 loc39
1
65 32
2
0 0 49 0
0 64 -1 32
1
end_operator
begin_operator
debark car53 loc4
1
65 33
2
0 0 49 0
0 64 -1 33
1
end_operator
begin_operator
debark car53 loc40
1
65 34
2
0 0 49 0
0 64 -1 34
1
end_operator
begin_operator
debark car53 loc41
1
65 35
2
0 0 49 0
0 64 -1 35
1
end_operator
begin_operator
debark car53 loc5
1
65 36
2
0 0 49 0
0 64 -1 36
1
end_operator
begin_operator
debark car53 loc6
1
65 37
2
0 0 49 0
0 64 -1 37
1
end_operator
begin_operator
debark car53 loc7
1
65 38
2
0 0 49 0
0 64 -1 38
1
end_operator
begin_operator
debark car53 loc8
1
65 39
2
0 0 49 0
0 64 -1 39
1
end_operator
begin_operator
debark car53 loc9
1
65 40
2
0 0 49 0
0 64 -1 40
1
end_operator
begin_operator
debark car54 loc1
1
65 0
2
0 0 50 0
0 2 -1 0
1
end_operator
begin_operator
debark car54 loc10
1
65 1
2
0 0 50 0
0 2 -1 1
1
end_operator
begin_operator
debark car54 loc11
1
65 2
2
0 0 50 0
0 2 -1 2
1
end_operator
begin_operator
debark car54 loc12
1
65 3
2
0 0 50 0
0 2 -1 3
1
end_operator
begin_operator
debark car54 loc13
1
65 4
2
0 0 50 0
0 2 -1 4
1
end_operator
begin_operator
debark car54 loc14
1
65 5
2
0 0 50 0
0 2 -1 5
1
end_operator
begin_operator
debark car54 loc15
1
65 6
2
0 0 50 0
0 2 -1 6
1
end_operator
begin_operator
debark car54 loc16
1
65 7
2
0 0 50 0
0 2 -1 7
1
end_operator
begin_operator
debark car54 loc17
1
65 8
2
0 0 50 0
0 2 -1 8
1
end_operator
begin_operator
debark car54 loc18
1
65 9
2
0 0 50 0
0 2 -1 9
1
end_operator
begin_operator
debark car54 loc19
1
65 10
2
0 0 50 0
0 2 -1 10
1
end_operator
begin_operator
debark car54 loc2
1
65 11
2
0 0 50 0
0 2 -1 11
1
end_operator
begin_operator
debark car54 loc20
1
65 12
2
0 0 50 0
0 2 -1 12
1
end_operator
begin_operator
debark car54 loc21
1
65 13
2
0 0 50 0
0 2 -1 13
1
end_operator
begin_operator
debark car54 loc22
1
65 14
2
0 0 50 0
0 2 -1 14
1
end_operator
begin_operator
debark car54 loc23
1
65 15
2
0 0 50 0
0 2 -1 15
1
end_operator
begin_operator
debark car54 loc24
1
65 16
2
0 0 50 0
0 2 -1 16
1
end_operator
begin_operator
debark car54 loc25
1
65 17
2
0 0 50 0
0 2 -1 17
1
end_operator
begin_operator
debark car54 loc26
1
65 18
2
0 0 50 0
0 2 -1 18
1
end_operator
begin_operator
debark car54 loc27
1
65 19
2
0 0 50 0
0 2 -1 19
1
end_operator
begin_operator
debark car54 loc28
1
65 20
2
0 0 50 0
0 2 -1 20
1
end_operator
begin_operator
debark car54 loc29
1
65 21
2
0 0 50 0
0 2 -1 21
1
end_operator
begin_operator
debark car54 loc3
1
65 22
2
0 0 50 0
0 2 -1 22
1
end_operator
begin_operator
debark car54 loc30
1
65 23
2
0 0 50 0
0 2 -1 23
1
end_operator
begin_operator
debark car54 loc31
1
65 24
2
0 0 50 0
0 2 -1 24
1
end_operator
begin_operator
debark car54 loc32
1
65 25
2
0 0 50 0
0 2 -1 25
1
end_operator
begin_operator
debark car54 loc33
1
65 26
2
0 0 50 0
0 2 -1 26
1
end_operator
begin_operator
debark car54 loc34
1
65 27
2
0 0 50 0
0 2 -1 27
1
end_operator
begin_operator
debark car54 loc35
1
65 28
2
0 0 50 0
0 2 -1 28
1
end_operator
begin_operator
debark car54 loc36
1
65 29
2
0 0 50 0
0 2 -1 29
1
end_operator
begin_operator
debark car54 loc37
1
65 30
2
0 0 50 0
0 2 -1 30
1
end_operator
begin_operator
debark car54 loc38
1
65 31
2
0 0 50 0
0 2 -1 31
1
end_operator
begin_operator
debark car54 loc39
1
65 32
2
0 0 50 0
0 2 -1 32
1
end_operator
begin_operator
debark car54 loc4
1
65 33
2
0 0 50 0
0 2 -1 33
1
end_operator
begin_operator
debark car54 loc40
1
65 34
2
0 0 50 0
0 2 -1 34
1
end_operator
begin_operator
debark car54 loc41
1
65 35
2
0 0 50 0
0 2 -1 35
1
end_operator
begin_operator
debark car54 loc5
1
65 36
2
0 0 50 0
0 2 -1 36
1
end_operator
begin_operator
debark car54 loc6
1
65 37
2
0 0 50 0
0 2 -1 37
1
end_operator
begin_operator
debark car54 loc7
1
65 38
2
0 0 50 0
0 2 -1 38
1
end_operator
begin_operator
debark car54 loc8
1
65 39
2
0 0 50 0
0 2 -1 39
1
end_operator
begin_operator
debark car54 loc9
1
65 40
2
0 0 50 0
0 2 -1 40
1
end_operator
begin_operator
debark car55 loc1
1
65 0
2
0 0 51 0
0 14 -1 0
1
end_operator
begin_operator
debark car55 loc10
1
65 1
2
0 0 51 0
0 14 -1 1
1
end_operator
begin_operator
debark car55 loc11
1
65 2
2
0 0 51 0
0 14 -1 2
1
end_operator
begin_operator
debark car55 loc12
1
65 3
2
0 0 51 0
0 14 -1 3
1
end_operator
begin_operator
debark car55 loc13
1
65 4
2
0 0 51 0
0 14 -1 4
1
end_operator
begin_operator
debark car55 loc14
1
65 5
2
0 0 51 0
0 14 -1 5
1
end_operator
begin_operator
debark car55 loc15
1
65 6
2
0 0 51 0
0 14 -1 6
1
end_operator
begin_operator
debark car55 loc16
1
65 7
2
0 0 51 0
0 14 -1 7
1
end_operator
begin_operator
debark car55 loc17
1
65 8
2
0 0 51 0
0 14 -1 8
1
end_operator
begin_operator
debark car55 loc18
1
65 9
2
0 0 51 0
0 14 -1 9
1
end_operator
begin_operator
debark car55 loc19
1
65 10
2
0 0 51 0
0 14 -1 10
1
end_operator
begin_operator
debark car55 loc2
1
65 11
2
0 0 51 0
0 14 -1 11
1
end_operator
begin_operator
debark car55 loc20
1
65 12
2
0 0 51 0
0 14 -1 12
1
end_operator
begin_operator
debark car55 loc21
1
65 13
2
0 0 51 0
0 14 -1 13
1
end_operator
begin_operator
debark car55 loc22
1
65 14
2
0 0 51 0
0 14 -1 14
1
end_operator
begin_operator
debark car55 loc23
1
65 15
2
0 0 51 0
0 14 -1 15
1
end_operator
begin_operator
debark car55 loc24
1
65 16
2
0 0 51 0
0 14 -1 16
1
end_operator
begin_operator
debark car55 loc25
1
65 17
2
0 0 51 0
0 14 -1 17
1
end_operator
begin_operator
debark car55 loc26
1
65 18
2
0 0 51 0
0 14 -1 18
1
end_operator
begin_operator
debark car55 loc27
1
65 19
2
0 0 51 0
0 14 -1 19
1
end_operator
begin_operator
debark car55 loc28
1
65 20
2
0 0 51 0
0 14 -1 20
1
end_operator
begin_operator
debark car55 loc29
1
65 21
2
0 0 51 0
0 14 -1 21
1
end_operator
begin_operator
debark car55 loc3
1
65 22
2
0 0 51 0
0 14 -1 22
1
end_operator
begin_operator
debark car55 loc30
1
65 23
2
0 0 51 0
0 14 -1 23
1
end_operator
begin_operator
debark car55 loc31
1
65 24
2
0 0 51 0
0 14 -1 24
1
end_operator
begin_operator
debark car55 loc32
1
65 25
2
0 0 51 0
0 14 -1 25
1
end_operator
begin_operator
debark car55 loc33
1
65 26
2
0 0 51 0
0 14 -1 26
1
end_operator
begin_operator
debark car55 loc34
1
65 27
2
0 0 51 0
0 14 -1 27
1
end_operator
begin_operator
debark car55 loc35
1
65 28
2
0 0 51 0
0 14 -1 28
1
end_operator
begin_operator
debark car55 loc36
1
65 29
2
0 0 51 0
0 14 -1 29
1
end_operator
begin_operator
debark car55 loc37
1
65 30
2
0 0 51 0
0 14 -1 30
1
end_operator
begin_operator
debark car55 loc38
1
65 31
2
0 0 51 0
0 14 -1 31
1
end_operator
begin_operator
debark car55 loc39
1
65 32
2
0 0 51 0
0 14 -1 32
1
end_operator
begin_operator
debark car55 loc4
1
65 33
2
0 0 51 0
0 14 -1 33
1
end_operator
begin_operator
debark car55 loc40
1
65 34
2
0 0 51 0
0 14 -1 34
1
end_operator
begin_operator
debark car55 loc41
1
65 35
2
0 0 51 0
0 14 -1 35
1
end_operator
begin_operator
debark car55 loc5
1
65 36
2
0 0 51 0
0 14 -1 36
1
end_operator
begin_operator
debark car55 loc6
1
65 37
2
0 0 51 0
0 14 -1 37
1
end_operator
begin_operator
debark car55 loc7
1
65 38
2
0 0 51 0
0 14 -1 38
1
end_operator
begin_operator
debark car55 loc8
1
65 39
2
0 0 51 0
0 14 -1 39
1
end_operator
begin_operator
debark car55 loc9
1
65 40
2
0 0 51 0
0 14 -1 40
1
end_operator
begin_operator
debark car56 loc1
1
65 0
2
0 0 52 0
0 26 -1 0
1
end_operator
begin_operator
debark car56 loc10
1
65 1
2
0 0 52 0
0 26 -1 1
1
end_operator
begin_operator
debark car56 loc11
1
65 2
2
0 0 52 0
0 26 -1 2
1
end_operator
begin_operator
debark car56 loc12
1
65 3
2
0 0 52 0
0 26 -1 3
1
end_operator
begin_operator
debark car56 loc13
1
65 4
2
0 0 52 0
0 26 -1 4
1
end_operator
begin_operator
debark car56 loc14
1
65 5
2
0 0 52 0
0 26 -1 5
1
end_operator
begin_operator
debark car56 loc15
1
65 6
2
0 0 52 0
0 26 -1 6
1
end_operator
begin_operator
debark car56 loc16
1
65 7
2
0 0 52 0
0 26 -1 7
1
end_operator
begin_operator
debark car56 loc17
1
65 8
2
0 0 52 0
0 26 -1 8
1
end_operator
begin_operator
debark car56 loc18
1
65 9
2
0 0 52 0
0 26 -1 9
1
end_operator
begin_operator
debark car56 loc19
1
65 10
2
0 0 52 0
0 26 -1 10
1
end_operator
begin_operator
debark car56 loc2
1
65 11
2
0 0 52 0
0 26 -1 11
1
end_operator
begin_operator
debark car56 loc20
1
65 12
2
0 0 52 0
0 26 -1 12
1
end_operator
begin_operator
debark car56 loc21
1
65 13
2
0 0 52 0
0 26 -1 13
1
end_operator
begin_operator
debark car56 loc22
1
65 14
2
0 0 52 0
0 26 -1 14
1
end_operator
begin_operator
debark car56 loc23
1
65 15
2
0 0 52 0
0 26 -1 15
1
end_operator
begin_operator
debark car56 loc24
1
65 16
2
0 0 52 0
0 26 -1 16
1
end_operator
begin_operator
debark car56 loc25
1
65 17
2
0 0 52 0
0 26 -1 17
1
end_operator
begin_operator
debark car56 loc26
1
65 18
2
0 0 52 0
0 26 -1 18
1
end_operator
begin_operator
debark car56 loc27
1
65 19
2
0 0 52 0
0 26 -1 19
1
end_operator
begin_operator
debark car56 loc28
1
65 20
2
0 0 52 0
0 26 -1 20
1
end_operator
begin_operator
debark car56 loc29
1
65 21
2
0 0 52 0
0 26 -1 21
1
end_operator
begin_operator
debark car56 loc3
1
65 22
2
0 0 52 0
0 26 -1 22
1
end_operator
begin_operator
debark car56 loc30
1
65 23
2
0 0 52 0
0 26 -1 23
1
end_operator
begin_operator
debark car56 loc31
1
65 24
2
0 0 52 0
0 26 -1 24
1
end_operator
begin_operator
debark car56 loc32
1
65 25
2
0 0 52 0
0 26 -1 25
1
end_operator
begin_operator
debark car56 loc33
1
65 26
2
0 0 52 0
0 26 -1 26
1
end_operator
begin_operator
debark car56 loc34
1
65 27
2
0 0 52 0
0 26 -1 27
1
end_operator
begin_operator
debark car56 loc35
1
65 28
2
0 0 52 0
0 26 -1 28
1
end_operator
begin_operator
debark car56 loc36
1
65 29
2
0 0 52 0
0 26 -1 29
1
end_operator
begin_operator
debark car56 loc37
1
65 30
2
0 0 52 0
0 26 -1 30
1
end_operator
begin_operator
debark car56 loc38
1
65 31
2
0 0 52 0
0 26 -1 31
1
end_operator
begin_operator
debark car56 loc39
1
65 32
2
0 0 52 0
0 26 -1 32
1
end_operator
begin_operator
debark car56 loc4
1
65 33
2
0 0 52 0
0 26 -1 33
1
end_operator
begin_operator
debark car56 loc40
1
65 34
2
0 0 52 0
0 26 -1 34
1
end_operator
begin_operator
debark car56 loc41
1
65 35
2
0 0 52 0
0 26 -1 35
1
end_operator
begin_operator
debark car56 loc5
1
65 36
2
0 0 52 0
0 26 -1 36
1
end_operator
begin_operator
debark car56 loc6
1
65 37
2
0 0 52 0
0 26 -1 37
1
end_operator
begin_operator
debark car56 loc7
1
65 38
2
0 0 52 0
0 26 -1 38
1
end_operator
begin_operator
debark car56 loc8
1
65 39
2
0 0 52 0
0 26 -1 39
1
end_operator
begin_operator
debark car56 loc9
1
65 40
2
0 0 52 0
0 26 -1 40
1
end_operator
begin_operator
debark car57 loc1
1
65 0
2
0 0 53 0
0 38 -1 0
1
end_operator
begin_operator
debark car57 loc10
1
65 1
2
0 0 53 0
0 38 -1 1
1
end_operator
begin_operator
debark car57 loc11
1
65 2
2
0 0 53 0
0 38 -1 2
1
end_operator
begin_operator
debark car57 loc12
1
65 3
2
0 0 53 0
0 38 -1 3
1
end_operator
begin_operator
debark car57 loc13
1
65 4
2
0 0 53 0
0 38 -1 4
1
end_operator
begin_operator
debark car57 loc14
1
65 5
2
0 0 53 0
0 38 -1 5
1
end_operator
begin_operator
debark car57 loc15
1
65 6
2
0 0 53 0
0 38 -1 6
1
end_operator
begin_operator
debark car57 loc16
1
65 7
2
0 0 53 0
0 38 -1 7
1
end_operator
begin_operator
debark car57 loc17
1
65 8
2
0 0 53 0
0 38 -1 8
1
end_operator
begin_operator
debark car57 loc18
1
65 9
2
0 0 53 0
0 38 -1 9
1
end_operator
begin_operator
debark car57 loc19
1
65 10
2
0 0 53 0
0 38 -1 10
1
end_operator
begin_operator
debark car57 loc2
1
65 11
2
0 0 53 0
0 38 -1 11
1
end_operator
begin_operator
debark car57 loc20
1
65 12
2
0 0 53 0
0 38 -1 12
1
end_operator
begin_operator
debark car57 loc21
1
65 13
2
0 0 53 0
0 38 -1 13
1
end_operator
begin_operator
debark car57 loc22
1
65 14
2
0 0 53 0
0 38 -1 14
1
end_operator
begin_operator
debark car57 loc23
1
65 15
2
0 0 53 0
0 38 -1 15
1
end_operator
begin_operator
debark car57 loc24
1
65 16
2
0 0 53 0
0 38 -1 16
1
end_operator
begin_operator
debark car57 loc25
1
65 17
2
0 0 53 0
0 38 -1 17
1
end_operator
begin_operator
debark car57 loc26
1
65 18
2
0 0 53 0
0 38 -1 18
1
end_operator
begin_operator
debark car57 loc27
1
65 19
2
0 0 53 0
0 38 -1 19
1
end_operator
begin_operator
debark car57 loc28
1
65 20
2
0 0 53 0
0 38 -1 20
1
end_operator
begin_operator
debark car57 loc29
1
65 21
2
0 0 53 0
0 38 -1 21
1
end_operator
begin_operator
debark car57 loc3
1
65 22
2
0 0 53 0
0 38 -1 22
1
end_operator
begin_operator
debark car57 loc30
1
65 23
2
0 0 53 0
0 38 -1 23
1
end_operator
begin_operator
debark car57 loc31
1
65 24
2
0 0 53 0
0 38 -1 24
1
end_operator
begin_operator
debark car57 loc32
1
65 25
2
0 0 53 0
0 38 -1 25
1
end_operator
begin_operator
debark car57 loc33
1
65 26
2
0 0 53 0
0 38 -1 26
1
end_operator
begin_operator
debark car57 loc34
1
65 27
2
0 0 53 0
0 38 -1 27
1
end_operator
begin_operator
debark car57 loc35
1
65 28
2
0 0 53 0
0 38 -1 28
1
end_operator
begin_operator
debark car57 loc36
1
65 29
2
0 0 53 0
0 38 -1 29
1
end_operator
begin_operator
debark car57 loc37
1
65 30
2
0 0 53 0
0 38 -1 30
1
end_operator
begin_operator
debark car57 loc38
1
65 31
2
0 0 53 0
0 38 -1 31
1
end_operator
begin_operator
debark car57 loc39
1
65 32
2
0 0 53 0
0 38 -1 32
1
end_operator
begin_operator
debark car57 loc4
1
65 33
2
0 0 53 0
0 38 -1 33
1
end_operator
begin_operator
debark car57 loc40
1
65 34
2
0 0 53 0
0 38 -1 34
1
end_operator
begin_operator
debark car57 loc41
1
65 35
2
0 0 53 0
0 38 -1 35
1
end_operator
begin_operator
debark car57 loc5
1
65 36
2
0 0 53 0
0 38 -1 36
1
end_operator
begin_operator
debark car57 loc6
1
65 37
2
0 0 53 0
0 38 -1 37
1
end_operator
begin_operator
debark car57 loc7
1
65 38
2
0 0 53 0
0 38 -1 38
1
end_operator
begin_operator
debark car57 loc8
1
65 39
2
0 0 53 0
0 38 -1 39
1
end_operator
begin_operator
debark car57 loc9
1
65 40
2
0 0 53 0
0 38 -1 40
1
end_operator
begin_operator
debark car58 loc1
1
65 0
2
0 0 54 0
0 50 -1 0
1
end_operator
begin_operator
debark car58 loc10
1
65 1
2
0 0 54 0
0 50 -1 1
1
end_operator
begin_operator
debark car58 loc11
1
65 2
2
0 0 54 0
0 50 -1 2
1
end_operator
begin_operator
debark car58 loc12
1
65 3
2
0 0 54 0
0 50 -1 3
1
end_operator
begin_operator
debark car58 loc13
1
65 4
2
0 0 54 0
0 50 -1 4
1
end_operator
begin_operator
debark car58 loc14
1
65 5
2
0 0 54 0
0 50 -1 5
1
end_operator
begin_operator
debark car58 loc15
1
65 6
2
0 0 54 0
0 50 -1 6
1
end_operator
begin_operator
debark car58 loc16
1
65 7
2
0 0 54 0
0 50 -1 7
1
end_operator
begin_operator
debark car58 loc17
1
65 8
2
0 0 54 0
0 50 -1 8
1
end_operator
begin_operator
debark car58 loc18
1
65 9
2
0 0 54 0
0 50 -1 9
1
end_operator
begin_operator
debark car58 loc19
1
65 10
2
0 0 54 0
0 50 -1 10
1
end_operator
begin_operator
debark car58 loc2
1
65 11
2
0 0 54 0
0 50 -1 11
1
end_operator
begin_operator
debark car58 loc20
1
65 12
2
0 0 54 0
0 50 -1 12
1
end_operator
begin_operator
debark car58 loc21
1
65 13
2
0 0 54 0
0 50 -1 13
1
end_operator
begin_operator
debark car58 loc22
1
65 14
2
0 0 54 0
0 50 -1 14
1
end_operator
begin_operator
debark car58 loc23
1
65 15
2
0 0 54 0
0 50 -1 15
1
end_operator
begin_operator
debark car58 loc24
1
65 16
2
0 0 54 0
0 50 -1 16
1
end_operator
begin_operator
debark car58 loc25
1
65 17
2
0 0 54 0
0 50 -1 17
1
end_operator
begin_operator
debark car58 loc26
1
65 18
2
0 0 54 0
0 50 -1 18
1
end_operator
begin_operator
debark car58 loc27
1
65 19
2
0 0 54 0
0 50 -1 19
1
end_operator
begin_operator
debark car58 loc28
1
65 20
2
0 0 54 0
0 50 -1 20
1
end_operator
begin_operator
debark car58 loc29
1
65 21
2
0 0 54 0
0 50 -1 21
1
end_operator
begin_operator
debark car58 loc3
1
65 22
2
0 0 54 0
0 50 -1 22
1
end_operator
begin_operator
debark car58 loc30
1
65 23
2
0 0 54 0
0 50 -1 23
1
end_operator
begin_operator
debark car58 loc31
1
65 24
2
0 0 54 0
0 50 -1 24
1
end_operator
begin_operator
debark car58 loc32
1
65 25
2
0 0 54 0
0 50 -1 25
1
end_operator
begin_operator
debark car58 loc33
1
65 26
2
0 0 54 0
0 50 -1 26
1
end_operator
begin_operator
debark car58 loc34
1
65 27
2
0 0 54 0
0 50 -1 27
1
end_operator
begin_operator
debark car58 loc35
1
65 28
2
0 0 54 0
0 50 -1 28
1
end_operator
begin_operator
debark car58 loc36
1
65 29
2
0 0 54 0
0 50 -1 29
1
end_operator
begin_operator
debark car58 loc37
1
65 30
2
0 0 54 0
0 50 -1 30
1
end_operator
begin_operator
debark car58 loc38
1
65 31
2
0 0 54 0
0 50 -1 31
1
end_operator
begin_operator
debark car58 loc39
1
65 32
2
0 0 54 0
0 50 -1 32
1
end_operator
begin_operator
debark car58 loc4
1
65 33
2
0 0 54 0
0 50 -1 33
1
end_operator
begin_operator
debark car58 loc40
1
65 34
2
0 0 54 0
0 50 -1 34
1
end_operator
begin_operator
debark car58 loc41
1
65 35
2
0 0 54 0
0 50 -1 35
1
end_operator
begin_operator
debark car58 loc5
1
65 36
2
0 0 54 0
0 50 -1 36
1
end_operator
begin_operator
debark car58 loc6
1
65 37
2
0 0 54 0
0 50 -1 37
1
end_operator
begin_operator
debark car58 loc7
1
65 38
2
0 0 54 0
0 50 -1 38
1
end_operator
begin_operator
debark car58 loc8
1
65 39
2
0 0 54 0
0 50 -1 39
1
end_operator
begin_operator
debark car58 loc9
1
65 40
2
0 0 54 0
0 50 -1 40
1
end_operator
begin_operator
debark car59 loc1
1
65 0
2
0 0 55 0
0 62 -1 0
1
end_operator
begin_operator
debark car59 loc10
1
65 1
2
0 0 55 0
0 62 -1 1
1
end_operator
begin_operator
debark car59 loc11
1
65 2
2
0 0 55 0
0 62 -1 2
1
end_operator
begin_operator
debark car59 loc12
1
65 3
2
0 0 55 0
0 62 -1 3
1
end_operator
begin_operator
debark car59 loc13
1
65 4
2
0 0 55 0
0 62 -1 4
1
end_operator
begin_operator
debark car59 loc14
1
65 5
2
0 0 55 0
0 62 -1 5
1
end_operator
begin_operator
debark car59 loc15
1
65 6
2
0 0 55 0
0 62 -1 6
1
end_operator
begin_operator
debark car59 loc16
1
65 7
2
0 0 55 0
0 62 -1 7
1
end_operator
begin_operator
debark car59 loc17
1
65 8
2
0 0 55 0
0 62 -1 8
1
end_operator
begin_operator
debark car59 loc18
1
65 9
2
0 0 55 0
0 62 -1 9
1
end_operator
begin_operator
debark car59 loc19
1
65 10
2
0 0 55 0
0 62 -1 10
1
end_operator
begin_operator
debark car59 loc2
1
65 11
2
0 0 55 0
0 62 -1 11
1
end_operator
begin_operator
debark car59 loc20
1
65 12
2
0 0 55 0
0 62 -1 12
1
end_operator
begin_operator
debark car59 loc21
1
65 13
2
0 0 55 0
0 62 -1 13
1
end_operator
begin_operator
debark car59 loc22
1
65 14
2
0 0 55 0
0 62 -1 14
1
end_operator
begin_operator
debark car59 loc23
1
65 15
2
0 0 55 0
0 62 -1 15
1
end_operator
begin_operator
debark car59 loc24
1
65 16
2
0 0 55 0
0 62 -1 16
1
end_operator
begin_operator
debark car59 loc25
1
65 17
2
0 0 55 0
0 62 -1 17
1
end_operator
begin_operator
debark car59 loc26
1
65 18
2
0 0 55 0
0 62 -1 18
1
end_operator
begin_operator
debark car59 loc27
1
65 19
2
0 0 55 0
0 62 -1 19
1
end_operator
begin_operator
debark car59 loc28
1
65 20
2
0 0 55 0
0 62 -1 20
1
end_operator
begin_operator
debark car59 loc29
1
65 21
2
0 0 55 0
0 62 -1 21
1
end_operator
begin_operator
debark car59 loc3
1
65 22
2
0 0 55 0
0 62 -1 22
1
end_operator
begin_operator
debark car59 loc30
1
65 23
2
0 0 55 0
0 62 -1 23
1
end_operator
begin_operator
debark car59 loc31
1
65 24
2
0 0 55 0
0 62 -1 24
1
end_operator
begin_operator
debark car59 loc32
1
65 25
2
0 0 55 0
0 62 -1 25
1
end_operator
begin_operator
debark car59 loc33
1
65 26
2
0 0 55 0
0 62 -1 26
1
end_operator
begin_operator
debark car59 loc34
1
65 27
2
0 0 55 0
0 62 -1 27
1
end_operator
begin_operator
debark car59 loc35
1
65 28
2
0 0 55 0
0 62 -1 28
1
end_operator
begin_operator
debark car59 loc36
1
65 29
2
0 0 55 0
0 62 -1 29
1
end_operator
begin_operator
debark car59 loc37
1
65 30
2
0 0 55 0
0 62 -1 30
1
end_operator
begin_operator
debark car59 loc38
1
65 31
2
0 0 55 0
0 62 -1 31
1
end_operator
begin_operator
debark car59 loc39
1
65 32
2
0 0 55 0
0 62 -1 32
1
end_operator
begin_operator
debark car59 loc4
1
65 33
2
0 0 55 0
0 62 -1 33
1
end_operator
begin_operator
debark car59 loc40
1
65 34
2
0 0 55 0
0 62 -1 34
1
end_operator
begin_operator
debark car59 loc41
1
65 35
2
0 0 55 0
0 62 -1 35
1
end_operator
begin_operator
debark car59 loc5
1
65 36
2
0 0 55 0
0 62 -1 36
1
end_operator
begin_operator
debark car59 loc6
1
65 37
2
0 0 55 0
0 62 -1 37
1
end_operator
begin_operator
debark car59 loc7
1
65 38
2
0 0 55 0
0 62 -1 38
1
end_operator
begin_operator
debark car59 loc8
1
65 39
2
0 0 55 0
0 62 -1 39
1
end_operator
begin_operator
debark car59 loc9
1
65 40
2
0 0 55 0
0 62 -1 40
1
end_operator
begin_operator
debark car6 loc1
1
65 0
2
0 0 56 0
0 74 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
65 1
2
0 0 56 0
0 74 -1 1
1
end_operator
begin_operator
debark car6 loc11
1
65 2
2
0 0 56 0
0 74 -1 2
1
end_operator
begin_operator
debark car6 loc12
1
65 3
2
0 0 56 0
0 74 -1 3
1
end_operator
begin_operator
debark car6 loc13
1
65 4
2
0 0 56 0
0 74 -1 4
1
end_operator
begin_operator
debark car6 loc14
1
65 5
2
0 0 56 0
0 74 -1 5
1
end_operator
begin_operator
debark car6 loc15
1
65 6
2
0 0 56 0
0 74 -1 6
1
end_operator
begin_operator
debark car6 loc16
1
65 7
2
0 0 56 0
0 74 -1 7
1
end_operator
begin_operator
debark car6 loc17
1
65 8
2
0 0 56 0
0 74 -1 8
1
end_operator
begin_operator
debark car6 loc18
1
65 9
2
0 0 56 0
0 74 -1 9
1
end_operator
begin_operator
debark car6 loc19
1
65 10
2
0 0 56 0
0 74 -1 10
1
end_operator
begin_operator
debark car6 loc2
1
65 11
2
0 0 56 0
0 74 -1 11
1
end_operator
begin_operator
debark car6 loc20
1
65 12
2
0 0 56 0
0 74 -1 12
1
end_operator
begin_operator
debark car6 loc21
1
65 13
2
0 0 56 0
0 74 -1 13
1
end_operator
begin_operator
debark car6 loc22
1
65 14
2
0 0 56 0
0 74 -1 14
1
end_operator
begin_operator
debark car6 loc23
1
65 15
2
0 0 56 0
0 74 -1 15
1
end_operator
begin_operator
debark car6 loc24
1
65 16
2
0 0 56 0
0 74 -1 16
1
end_operator
begin_operator
debark car6 loc25
1
65 17
2
0 0 56 0
0 74 -1 17
1
end_operator
begin_operator
debark car6 loc26
1
65 18
2
0 0 56 0
0 74 -1 18
1
end_operator
begin_operator
debark car6 loc27
1
65 19
2
0 0 56 0
0 74 -1 19
1
end_operator
begin_operator
debark car6 loc28
1
65 20
2
0 0 56 0
0 74 -1 20
1
end_operator
begin_operator
debark car6 loc29
1
65 21
2
0 0 56 0
0 74 -1 21
1
end_operator
begin_operator
debark car6 loc3
1
65 22
2
0 0 56 0
0 74 -1 22
1
end_operator
begin_operator
debark car6 loc30
1
65 23
2
0 0 56 0
0 74 -1 23
1
end_operator
begin_operator
debark car6 loc31
1
65 24
2
0 0 56 0
0 74 -1 24
1
end_operator
begin_operator
debark car6 loc32
1
65 25
2
0 0 56 0
0 74 -1 25
1
end_operator
begin_operator
debark car6 loc33
1
65 26
2
0 0 56 0
0 74 -1 26
1
end_operator
begin_operator
debark car6 loc34
1
65 27
2
0 0 56 0
0 74 -1 27
1
end_operator
begin_operator
debark car6 loc35
1
65 28
2
0 0 56 0
0 74 -1 28
1
end_operator
begin_operator
debark car6 loc36
1
65 29
2
0 0 56 0
0 74 -1 29
1
end_operator
begin_operator
debark car6 loc37
1
65 30
2
0 0 56 0
0 74 -1 30
1
end_operator
begin_operator
debark car6 loc38
1
65 31
2
0 0 56 0
0 74 -1 31
1
end_operator
begin_operator
debark car6 loc39
1
65 32
2
0 0 56 0
0 74 -1 32
1
end_operator
begin_operator
debark car6 loc4
1
65 33
2
0 0 56 0
0 74 -1 33
1
end_operator
begin_operator
debark car6 loc40
1
65 34
2
0 0 56 0
0 74 -1 34
1
end_operator
begin_operator
debark car6 loc41
1
65 35
2
0 0 56 0
0 74 -1 35
1
end_operator
begin_operator
debark car6 loc5
1
65 36
2
0 0 56 0
0 74 -1 36
1
end_operator
begin_operator
debark car6 loc6
1
65 37
2
0 0 56 0
0 74 -1 37
1
end_operator
begin_operator
debark car6 loc7
1
65 38
2
0 0 56 0
0 74 -1 38
1
end_operator
begin_operator
debark car6 loc8
1
65 39
2
0 0 56 0
0 74 -1 39
1
end_operator
begin_operator
debark car6 loc9
1
65 40
2
0 0 56 0
0 74 -1 40
1
end_operator
begin_operator
debark car60 loc1
1
65 0
2
0 0 57 0
0 11 -1 0
1
end_operator
begin_operator
debark car60 loc10
1
65 1
2
0 0 57 0
0 11 -1 1
1
end_operator
begin_operator
debark car60 loc11
1
65 2
2
0 0 57 0
0 11 -1 2
1
end_operator
begin_operator
debark car60 loc12
1
65 3
2
0 0 57 0
0 11 -1 3
1
end_operator
begin_operator
debark car60 loc13
1
65 4
2
0 0 57 0
0 11 -1 4
1
end_operator
begin_operator
debark car60 loc14
1
65 5
2
0 0 57 0
0 11 -1 5
1
end_operator
begin_operator
debark car60 loc15
1
65 6
2
0 0 57 0
0 11 -1 6
1
end_operator
begin_operator
debark car60 loc16
1
65 7
2
0 0 57 0
0 11 -1 7
1
end_operator
begin_operator
debark car60 loc17
1
65 8
2
0 0 57 0
0 11 -1 8
1
end_operator
begin_operator
debark car60 loc18
1
65 9
2
0 0 57 0
0 11 -1 9
1
end_operator
begin_operator
debark car60 loc19
1
65 10
2
0 0 57 0
0 11 -1 10
1
end_operator
begin_operator
debark car60 loc2
1
65 11
2
0 0 57 0
0 11 -1 11
1
end_operator
begin_operator
debark car60 loc20
1
65 12
2
0 0 57 0
0 11 -1 12
1
end_operator
begin_operator
debark car60 loc21
1
65 13
2
0 0 57 0
0 11 -1 13
1
end_operator
begin_operator
debark car60 loc22
1
65 14
2
0 0 57 0
0 11 -1 14
1
end_operator
begin_operator
debark car60 loc23
1
65 15
2
0 0 57 0
0 11 -1 15
1
end_operator
begin_operator
debark car60 loc24
1
65 16
2
0 0 57 0
0 11 -1 16
1
end_operator
begin_operator
debark car60 loc25
1
65 17
2
0 0 57 0
0 11 -1 17
1
end_operator
begin_operator
debark car60 loc26
1
65 18
2
0 0 57 0
0 11 -1 18
1
end_operator
begin_operator
debark car60 loc27
1
65 19
2
0 0 57 0
0 11 -1 19
1
end_operator
begin_operator
debark car60 loc28
1
65 20
2
0 0 57 0
0 11 -1 20
1
end_operator
begin_operator
debark car60 loc29
1
65 21
2
0 0 57 0
0 11 -1 21
1
end_operator
begin_operator
debark car60 loc3
1
65 22
2
0 0 57 0
0 11 -1 22
1
end_operator
begin_operator
debark car60 loc30
1
65 23
2
0 0 57 0
0 11 -1 23
1
end_operator
begin_operator
debark car60 loc31
1
65 24
2
0 0 57 0
0 11 -1 24
1
end_operator
begin_operator
debark car60 loc32
1
65 25
2
0 0 57 0
0 11 -1 25
1
end_operator
begin_operator
debark car60 loc33
1
65 26
2
0 0 57 0
0 11 -1 26
1
end_operator
begin_operator
debark car60 loc34
1
65 27
2
0 0 57 0
0 11 -1 27
1
end_operator
begin_operator
debark car60 loc35
1
65 28
2
0 0 57 0
0 11 -1 28
1
end_operator
begin_operator
debark car60 loc36
1
65 29
2
0 0 57 0
0 11 -1 29
1
end_operator
begin_operator
debark car60 loc37
1
65 30
2
0 0 57 0
0 11 -1 30
1
end_operator
begin_operator
debark car60 loc38
1
65 31
2
0 0 57 0
0 11 -1 31
1
end_operator
begin_operator
debark car60 loc39
1
65 32
2
0 0 57 0
0 11 -1 32
1
end_operator
begin_operator
debark car60 loc4
1
65 33
2
0 0 57 0
0 11 -1 33
1
end_operator
begin_operator
debark car60 loc40
1
65 34
2
0 0 57 0
0 11 -1 34
1
end_operator
begin_operator
debark car60 loc41
1
65 35
2
0 0 57 0
0 11 -1 35
1
end_operator
begin_operator
debark car60 loc5
1
65 36
2
0 0 57 0
0 11 -1 36
1
end_operator
begin_operator
debark car60 loc6
1
65 37
2
0 0 57 0
0 11 -1 37
1
end_operator
begin_operator
debark car60 loc7
1
65 38
2
0 0 57 0
0 11 -1 38
1
end_operator
begin_operator
debark car60 loc8
1
65 39
2
0 0 57 0
0 11 -1 39
1
end_operator
begin_operator
debark car60 loc9
1
65 40
2
0 0 57 0
0 11 -1 40
1
end_operator
begin_operator
debark car61 loc1
1
65 0
2
0 0 58 0
0 23 -1 0
1
end_operator
begin_operator
debark car61 loc10
1
65 1
2
0 0 58 0
0 23 -1 1
1
end_operator
begin_operator
debark car61 loc11
1
65 2
2
0 0 58 0
0 23 -1 2
1
end_operator
begin_operator
debark car61 loc12
1
65 3
2
0 0 58 0
0 23 -1 3
1
end_operator
begin_operator
debark car61 loc13
1
65 4
2
0 0 58 0
0 23 -1 4
1
end_operator
begin_operator
debark car61 loc14
1
65 5
2
0 0 58 0
0 23 -1 5
1
end_operator
begin_operator
debark car61 loc15
1
65 6
2
0 0 58 0
0 23 -1 6
1
end_operator
begin_operator
debark car61 loc16
1
65 7
2
0 0 58 0
0 23 -1 7
1
end_operator
begin_operator
debark car61 loc17
1
65 8
2
0 0 58 0
0 23 -1 8
1
end_operator
begin_operator
debark car61 loc18
1
65 9
2
0 0 58 0
0 23 -1 9
1
end_operator
begin_operator
debark car61 loc19
1
65 10
2
0 0 58 0
0 23 -1 10
1
end_operator
begin_operator
debark car61 loc2
1
65 11
2
0 0 58 0
0 23 -1 11
1
end_operator
begin_operator
debark car61 loc20
1
65 12
2
0 0 58 0
0 23 -1 12
1
end_operator
begin_operator
debark car61 loc21
1
65 13
2
0 0 58 0
0 23 -1 13
1
end_operator
begin_operator
debark car61 loc22
1
65 14
2
0 0 58 0
0 23 -1 14
1
end_operator
begin_operator
debark car61 loc23
1
65 15
2
0 0 58 0
0 23 -1 15
1
end_operator
begin_operator
debark car61 loc24
1
65 16
2
0 0 58 0
0 23 -1 16
1
end_operator
begin_operator
debark car61 loc25
1
65 17
2
0 0 58 0
0 23 -1 17
1
end_operator
begin_operator
debark car61 loc26
1
65 18
2
0 0 58 0
0 23 -1 18
1
end_operator
begin_operator
debark car61 loc27
1
65 19
2
0 0 58 0
0 23 -1 19
1
end_operator
begin_operator
debark car61 loc28
1
65 20
2
0 0 58 0
0 23 -1 20
1
end_operator
begin_operator
debark car61 loc29
1
65 21
2
0 0 58 0
0 23 -1 21
1
end_operator
begin_operator
debark car61 loc3
1
65 22
2
0 0 58 0
0 23 -1 22
1
end_operator
begin_operator
debark car61 loc30
1
65 23
2
0 0 58 0
0 23 -1 23
1
end_operator
begin_operator
debark car61 loc31
1
65 24
2
0 0 58 0
0 23 -1 24
1
end_operator
begin_operator
debark car61 loc32
1
65 25
2
0 0 58 0
0 23 -1 25
1
end_operator
begin_operator
debark car61 loc33
1
65 26
2
0 0 58 0
0 23 -1 26
1
end_operator
begin_operator
debark car61 loc34
1
65 27
2
0 0 58 0
0 23 -1 27
1
end_operator
begin_operator
debark car61 loc35
1
65 28
2
0 0 58 0
0 23 -1 28
1
end_operator
begin_operator
debark car61 loc36
1
65 29
2
0 0 58 0
0 23 -1 29
1
end_operator
begin_operator
debark car61 loc37
1
65 30
2
0 0 58 0
0 23 -1 30
1
end_operator
begin_operator
debark car61 loc38
1
65 31
2
0 0 58 0
0 23 -1 31
1
end_operator
begin_operator
debark car61 loc39
1
65 32
2
0 0 58 0
0 23 -1 32
1
end_operator
begin_operator
debark car61 loc4
1
65 33
2
0 0 58 0
0 23 -1 33
1
end_operator
begin_operator
debark car61 loc40
1
65 34
2
0 0 58 0
0 23 -1 34
1
end_operator
begin_operator
debark car61 loc41
1
65 35
2
0 0 58 0
0 23 -1 35
1
end_operator
begin_operator
debark car61 loc5
1
65 36
2
0 0 58 0
0 23 -1 36
1
end_operator
begin_operator
debark car61 loc6
1
65 37
2
0 0 58 0
0 23 -1 37
1
end_operator
begin_operator
debark car61 loc7
1
65 38
2
0 0 58 0
0 23 -1 38
1
end_operator
begin_operator
debark car61 loc8
1
65 39
2
0 0 58 0
0 23 -1 39
1
end_operator
begin_operator
debark car61 loc9
1
65 40
2
0 0 58 0
0 23 -1 40
1
end_operator
begin_operator
debark car62 loc1
1
65 0
2
0 0 59 0
0 35 -1 0
1
end_operator
begin_operator
debark car62 loc10
1
65 1
2
0 0 59 0
0 35 -1 1
1
end_operator
begin_operator
debark car62 loc11
1
65 2
2
0 0 59 0
0 35 -1 2
1
end_operator
begin_operator
debark car62 loc12
1
65 3
2
0 0 59 0
0 35 -1 3
1
end_operator
begin_operator
debark car62 loc13
1
65 4
2
0 0 59 0
0 35 -1 4
1
end_operator
begin_operator
debark car62 loc14
1
65 5
2
0 0 59 0
0 35 -1 5
1
end_operator
begin_operator
debark car62 loc15
1
65 6
2
0 0 59 0
0 35 -1 6
1
end_operator
begin_operator
debark car62 loc16
1
65 7
2
0 0 59 0
0 35 -1 7
1
end_operator
begin_operator
debark car62 loc17
1
65 8
2
0 0 59 0
0 35 -1 8
1
end_operator
begin_operator
debark car62 loc18
1
65 9
2
0 0 59 0
0 35 -1 9
1
end_operator
begin_operator
debark car62 loc19
1
65 10
2
0 0 59 0
0 35 -1 10
1
end_operator
begin_operator
debark car62 loc2
1
65 11
2
0 0 59 0
0 35 -1 11
1
end_operator
begin_operator
debark car62 loc20
1
65 12
2
0 0 59 0
0 35 -1 12
1
end_operator
begin_operator
debark car62 loc21
1
65 13
2
0 0 59 0
0 35 -1 13
1
end_operator
begin_operator
debark car62 loc22
1
65 14
2
0 0 59 0
0 35 -1 14
1
end_operator
begin_operator
debark car62 loc23
1
65 15
2
0 0 59 0
0 35 -1 15
1
end_operator
begin_operator
debark car62 loc24
1
65 16
2
0 0 59 0
0 35 -1 16
1
end_operator
begin_operator
debark car62 loc25
1
65 17
2
0 0 59 0
0 35 -1 17
1
end_operator
begin_operator
debark car62 loc26
1
65 18
2
0 0 59 0
0 35 -1 18
1
end_operator
begin_operator
debark car62 loc27
1
65 19
2
0 0 59 0
0 35 -1 19
1
end_operator
begin_operator
debark car62 loc28
1
65 20
2
0 0 59 0
0 35 -1 20
1
end_operator
begin_operator
debark car62 loc29
1
65 21
2
0 0 59 0
0 35 -1 21
1
end_operator
begin_operator
debark car62 loc3
1
65 22
2
0 0 59 0
0 35 -1 22
1
end_operator
begin_operator
debark car62 loc30
1
65 23
2
0 0 59 0
0 35 -1 23
1
end_operator
begin_operator
debark car62 loc31
1
65 24
2
0 0 59 0
0 35 -1 24
1
end_operator
begin_operator
debark car62 loc32
1
65 25
2
0 0 59 0
0 35 -1 25
1
end_operator
begin_operator
debark car62 loc33
1
65 26
2
0 0 59 0
0 35 -1 26
1
end_operator
begin_operator
debark car62 loc34
1
65 27
2
0 0 59 0
0 35 -1 27
1
end_operator
begin_operator
debark car62 loc35
1
65 28
2
0 0 59 0
0 35 -1 28
1
end_operator
begin_operator
debark car62 loc36
1
65 29
2
0 0 59 0
0 35 -1 29
1
end_operator
begin_operator
debark car62 loc37
1
65 30
2
0 0 59 0
0 35 -1 30
1
end_operator
begin_operator
debark car62 loc38
1
65 31
2
0 0 59 0
0 35 -1 31
1
end_operator
begin_operator
debark car62 loc39
1
65 32
2
0 0 59 0
0 35 -1 32
1
end_operator
begin_operator
debark car62 loc4
1
65 33
2
0 0 59 0
0 35 -1 33
1
end_operator
begin_operator
debark car62 loc40
1
65 34
2
0 0 59 0
0 35 -1 34
1
end_operator
begin_operator
debark car62 loc41
1
65 35
2
0 0 59 0
0 35 -1 35
1
end_operator
begin_operator
debark car62 loc5
1
65 36
2
0 0 59 0
0 35 -1 36
1
end_operator
begin_operator
debark car62 loc6
1
65 37
2
0 0 59 0
0 35 -1 37
1
end_operator
begin_operator
debark car62 loc7
1
65 38
2
0 0 59 0
0 35 -1 38
1
end_operator
begin_operator
debark car62 loc8
1
65 39
2
0 0 59 0
0 35 -1 39
1
end_operator
begin_operator
debark car62 loc9
1
65 40
2
0 0 59 0
0 35 -1 40
1
end_operator
begin_operator
debark car63 loc1
1
65 0
2
0 0 60 0
0 47 -1 0
1
end_operator
begin_operator
debark car63 loc10
1
65 1
2
0 0 60 0
0 47 -1 1
1
end_operator
begin_operator
debark car63 loc11
1
65 2
2
0 0 60 0
0 47 -1 2
1
end_operator
begin_operator
debark car63 loc12
1
65 3
2
0 0 60 0
0 47 -1 3
1
end_operator
begin_operator
debark car63 loc13
1
65 4
2
0 0 60 0
0 47 -1 4
1
end_operator
begin_operator
debark car63 loc14
1
65 5
2
0 0 60 0
0 47 -1 5
1
end_operator
begin_operator
debark car63 loc15
1
65 6
2
0 0 60 0
0 47 -1 6
1
end_operator
begin_operator
debark car63 loc16
1
65 7
2
0 0 60 0
0 47 -1 7
1
end_operator
begin_operator
debark car63 loc17
1
65 8
2
0 0 60 0
0 47 -1 8
1
end_operator
begin_operator
debark car63 loc18
1
65 9
2
0 0 60 0
0 47 -1 9
1
end_operator
begin_operator
debark car63 loc19
1
65 10
2
0 0 60 0
0 47 -1 10
1
end_operator
begin_operator
debark car63 loc2
1
65 11
2
0 0 60 0
0 47 -1 11
1
end_operator
begin_operator
debark car63 loc20
1
65 12
2
0 0 60 0
0 47 -1 12
1
end_operator
begin_operator
debark car63 loc21
1
65 13
2
0 0 60 0
0 47 -1 13
1
end_operator
begin_operator
debark car63 loc22
1
65 14
2
0 0 60 0
0 47 -1 14
1
end_operator
begin_operator
debark car63 loc23
1
65 15
2
0 0 60 0
0 47 -1 15
1
end_operator
begin_operator
debark car63 loc24
1
65 16
2
0 0 60 0
0 47 -1 16
1
end_operator
begin_operator
debark car63 loc25
1
65 17
2
0 0 60 0
0 47 -1 17
1
end_operator
begin_operator
debark car63 loc26
1
65 18
2
0 0 60 0
0 47 -1 18
1
end_operator
begin_operator
debark car63 loc27
1
65 19
2
0 0 60 0
0 47 -1 19
1
end_operator
begin_operator
debark car63 loc28
1
65 20
2
0 0 60 0
0 47 -1 20
1
end_operator
begin_operator
debark car63 loc29
1
65 21
2
0 0 60 0
0 47 -1 21
1
end_operator
begin_operator
debark car63 loc3
1
65 22
2
0 0 60 0
0 47 -1 22
1
end_operator
begin_operator
debark car63 loc30
1
65 23
2
0 0 60 0
0 47 -1 23
1
end_operator
begin_operator
debark car63 loc31
1
65 24
2
0 0 60 0
0 47 -1 24
1
end_operator
begin_operator
debark car63 loc32
1
65 25
2
0 0 60 0
0 47 -1 25
1
end_operator
begin_operator
debark car63 loc33
1
65 26
2
0 0 60 0
0 47 -1 26
1
end_operator
begin_operator
debark car63 loc34
1
65 27
2
0 0 60 0
0 47 -1 27
1
end_operator
begin_operator
debark car63 loc35
1
65 28
2
0 0 60 0
0 47 -1 28
1
end_operator
begin_operator
debark car63 loc36
1
65 29
2
0 0 60 0
0 47 -1 29
1
end_operator
begin_operator
debark car63 loc37
1
65 30
2
0 0 60 0
0 47 -1 30
1
end_operator
begin_operator
debark car63 loc38
1
65 31
2
0 0 60 0
0 47 -1 31
1
end_operator
begin_operator
debark car63 loc39
1
65 32
2
0 0 60 0
0 47 -1 32
1
end_operator
begin_operator
debark car63 loc4
1
65 33
2
0 0 60 0
0 47 -1 33
1
end_operator
begin_operator
debark car63 loc40
1
65 34
2
0 0 60 0
0 47 -1 34
1
end_operator
begin_operator
debark car63 loc41
1
65 35
2
0 0 60 0
0 47 -1 35
1
end_operator
begin_operator
debark car63 loc5
1
65 36
2
0 0 60 0
0 47 -1 36
1
end_operator
begin_operator
debark car63 loc6
1
65 37
2
0 0 60 0
0 47 -1 37
1
end_operator
begin_operator
debark car63 loc7
1
65 38
2
0 0 60 0
0 47 -1 38
1
end_operator
begin_operator
debark car63 loc8
1
65 39
2
0 0 60 0
0 47 -1 39
1
end_operator
begin_operator
debark car63 loc9
1
65 40
2
0 0 60 0
0 47 -1 40
1
end_operator
begin_operator
debark car64 loc1
1
65 0
2
0 0 61 0
0 59 -1 0
1
end_operator
begin_operator
debark car64 loc10
1
65 1
2
0 0 61 0
0 59 -1 1
1
end_operator
begin_operator
debark car64 loc11
1
65 2
2
0 0 61 0
0 59 -1 2
1
end_operator
begin_operator
debark car64 loc12
1
65 3
2
0 0 61 0
0 59 -1 3
1
end_operator
begin_operator
debark car64 loc13
1
65 4
2
0 0 61 0
0 59 -1 4
1
end_operator
begin_operator
debark car64 loc14
1
65 5
2
0 0 61 0
0 59 -1 5
1
end_operator
begin_operator
debark car64 loc15
1
65 6
2
0 0 61 0
0 59 -1 6
1
end_operator
begin_operator
debark car64 loc16
1
65 7
2
0 0 61 0
0 59 -1 7
1
end_operator
begin_operator
debark car64 loc17
1
65 8
2
0 0 61 0
0 59 -1 8
1
end_operator
begin_operator
debark car64 loc18
1
65 9
2
0 0 61 0
0 59 -1 9
1
end_operator
begin_operator
debark car64 loc19
1
65 10
2
0 0 61 0
0 59 -1 10
1
end_operator
begin_operator
debark car64 loc2
1
65 11
2
0 0 61 0
0 59 -1 11
1
end_operator
begin_operator
debark car64 loc20
1
65 12
2
0 0 61 0
0 59 -1 12
1
end_operator
begin_operator
debark car64 loc21
1
65 13
2
0 0 61 0
0 59 -1 13
1
end_operator
begin_operator
debark car64 loc22
1
65 14
2
0 0 61 0
0 59 -1 14
1
end_operator
begin_operator
debark car64 loc23
1
65 15
2
0 0 61 0
0 59 -1 15
1
end_operator
begin_operator
debark car64 loc24
1
65 16
2
0 0 61 0
0 59 -1 16
1
end_operator
begin_operator
debark car64 loc25
1
65 17
2
0 0 61 0
0 59 -1 17
1
end_operator
begin_operator
debark car64 loc26
1
65 18
2
0 0 61 0
0 59 -1 18
1
end_operator
begin_operator
debark car64 loc27
1
65 19
2
0 0 61 0
0 59 -1 19
1
end_operator
begin_operator
debark car64 loc28
1
65 20
2
0 0 61 0
0 59 -1 20
1
end_operator
begin_operator
debark car64 loc29
1
65 21
2
0 0 61 0
0 59 -1 21
1
end_operator
begin_operator
debark car64 loc3
1
65 22
2
0 0 61 0
0 59 -1 22
1
end_operator
begin_operator
debark car64 loc30
1
65 23
2
0 0 61 0
0 59 -1 23
1
end_operator
begin_operator
debark car64 loc31
1
65 24
2
0 0 61 0
0 59 -1 24
1
end_operator
begin_operator
debark car64 loc32
1
65 25
2
0 0 61 0
0 59 -1 25
1
end_operator
begin_operator
debark car64 loc33
1
65 26
2
0 0 61 0
0 59 -1 26
1
end_operator
begin_operator
debark car64 loc34
1
65 27
2
0 0 61 0
0 59 -1 27
1
end_operator
begin_operator
debark car64 loc35
1
65 28
2
0 0 61 0
0 59 -1 28
1
end_operator
begin_operator
debark car64 loc36
1
65 29
2
0 0 61 0
0 59 -1 29
1
end_operator
begin_operator
debark car64 loc37
1
65 30
2
0 0 61 0
0 59 -1 30
1
end_operator
begin_operator
debark car64 loc38
1
65 31
2
0 0 61 0
0 59 -1 31
1
end_operator
begin_operator
debark car64 loc39
1
65 32
2
0 0 61 0
0 59 -1 32
1
end_operator
begin_operator
debark car64 loc4
1
65 33
2
0 0 61 0
0 59 -1 33
1
end_operator
begin_operator
debark car64 loc40
1
65 34
2
0 0 61 0
0 59 -1 34
1
end_operator
begin_operator
debark car64 loc41
1
65 35
2
0 0 61 0
0 59 -1 35
1
end_operator
begin_operator
debark car64 loc5
1
65 36
2
0 0 61 0
0 59 -1 36
1
end_operator
begin_operator
debark car64 loc6
1
65 37
2
0 0 61 0
0 59 -1 37
1
end_operator
begin_operator
debark car64 loc7
1
65 38
2
0 0 61 0
0 59 -1 38
1
end_operator
begin_operator
debark car64 loc8
1
65 39
2
0 0 61 0
0 59 -1 39
1
end_operator
begin_operator
debark car64 loc9
1
65 40
2
0 0 61 0
0 59 -1 40
1
end_operator
begin_operator
debark car65 loc1
1
65 0
2
0 0 62 0
0 71 -1 0
1
end_operator
begin_operator
debark car65 loc10
1
65 1
2
0 0 62 0
0 71 -1 1
1
end_operator
begin_operator
debark car65 loc11
1
65 2
2
0 0 62 0
0 71 -1 2
1
end_operator
begin_operator
debark car65 loc12
1
65 3
2
0 0 62 0
0 71 -1 3
1
end_operator
begin_operator
debark car65 loc13
1
65 4
2
0 0 62 0
0 71 -1 4
1
end_operator
begin_operator
debark car65 loc14
1
65 5
2
0 0 62 0
0 71 -1 5
1
end_operator
begin_operator
debark car65 loc15
1
65 6
2
0 0 62 0
0 71 -1 6
1
end_operator
begin_operator
debark car65 loc16
1
65 7
2
0 0 62 0
0 71 -1 7
1
end_operator
begin_operator
debark car65 loc17
1
65 8
2
0 0 62 0
0 71 -1 8
1
end_operator
begin_operator
debark car65 loc18
1
65 9
2
0 0 62 0
0 71 -1 9
1
end_operator
begin_operator
debark car65 loc19
1
65 10
2
0 0 62 0
0 71 -1 10
1
end_operator
begin_operator
debark car65 loc2
1
65 11
2
0 0 62 0
0 71 -1 11
1
end_operator
begin_operator
debark car65 loc20
1
65 12
2
0 0 62 0
0 71 -1 12
1
end_operator
begin_operator
debark car65 loc21
1
65 13
2
0 0 62 0
0 71 -1 13
1
end_operator
begin_operator
debark car65 loc22
1
65 14
2
0 0 62 0
0 71 -1 14
1
end_operator
begin_operator
debark car65 loc23
1
65 15
2
0 0 62 0
0 71 -1 15
1
end_operator
begin_operator
debark car65 loc24
1
65 16
2
0 0 62 0
0 71 -1 16
1
end_operator
begin_operator
debark car65 loc25
1
65 17
2
0 0 62 0
0 71 -1 17
1
end_operator
begin_operator
debark car65 loc26
1
65 18
2
0 0 62 0
0 71 -1 18
1
end_operator
begin_operator
debark car65 loc27
1
65 19
2
0 0 62 0
0 71 -1 19
1
end_operator
begin_operator
debark car65 loc28
1
65 20
2
0 0 62 0
0 71 -1 20
1
end_operator
begin_operator
debark car65 loc29
1
65 21
2
0 0 62 0
0 71 -1 21
1
end_operator
begin_operator
debark car65 loc3
1
65 22
2
0 0 62 0
0 71 -1 22
1
end_operator
begin_operator
debark car65 loc30
1
65 23
2
0 0 62 0
0 71 -1 23
1
end_operator
begin_operator
debark car65 loc31
1
65 24
2
0 0 62 0
0 71 -1 24
1
end_operator
begin_operator
debark car65 loc32
1
65 25
2
0 0 62 0
0 71 -1 25
1
end_operator
begin_operator
debark car65 loc33
1
65 26
2
0 0 62 0
0 71 -1 26
1
end_operator
begin_operator
debark car65 loc34
1
65 27
2
0 0 62 0
0 71 -1 27
1
end_operator
begin_operator
debark car65 loc35
1
65 28
2
0 0 62 0
0 71 -1 28
1
end_operator
begin_operator
debark car65 loc36
1
65 29
2
0 0 62 0
0 71 -1 29
1
end_operator
begin_operator
debark car65 loc37
1
65 30
2
0 0 62 0
0 71 -1 30
1
end_operator
begin_operator
debark car65 loc38
1
65 31
2
0 0 62 0
0 71 -1 31
1
end_operator
begin_operator
debark car65 loc39
1
65 32
2
0 0 62 0
0 71 -1 32
1
end_operator
begin_operator
debark car65 loc4
1
65 33
2
0 0 62 0
0 71 -1 33
1
end_operator
begin_operator
debark car65 loc40
1
65 34
2
0 0 62 0
0 71 -1 34
1
end_operator
begin_operator
debark car65 loc41
1
65 35
2
0 0 62 0
0 71 -1 35
1
end_operator
begin_operator
debark car65 loc5
1
65 36
2
0 0 62 0
0 71 -1 36
1
end_operator
begin_operator
debark car65 loc6
1
65 37
2
0 0 62 0
0 71 -1 37
1
end_operator
begin_operator
debark car65 loc7
1
65 38
2
0 0 62 0
0 71 -1 38
1
end_operator
begin_operator
debark car65 loc8
1
65 39
2
0 0 62 0
0 71 -1 39
1
end_operator
begin_operator
debark car65 loc9
1
65 40
2
0 0 62 0
0 71 -1 40
1
end_operator
begin_operator
debark car66 loc1
1
65 0
2
0 0 63 0
0 8 -1 0
1
end_operator
begin_operator
debark car66 loc10
1
65 1
2
0 0 63 0
0 8 -1 1
1
end_operator
begin_operator
debark car66 loc11
1
65 2
2
0 0 63 0
0 8 -1 2
1
end_operator
begin_operator
debark car66 loc12
1
65 3
2
0 0 63 0
0 8 -1 3
1
end_operator
begin_operator
debark car66 loc13
1
65 4
2
0 0 63 0
0 8 -1 4
1
end_operator
begin_operator
debark car66 loc14
1
65 5
2
0 0 63 0
0 8 -1 5
1
end_operator
begin_operator
debark car66 loc15
1
65 6
2
0 0 63 0
0 8 -1 6
1
end_operator
begin_operator
debark car66 loc16
1
65 7
2
0 0 63 0
0 8 -1 7
1
end_operator
begin_operator
debark car66 loc17
1
65 8
2
0 0 63 0
0 8 -1 8
1
end_operator
begin_operator
debark car66 loc18
1
65 9
2
0 0 63 0
0 8 -1 9
1
end_operator
begin_operator
debark car66 loc19
1
65 10
2
0 0 63 0
0 8 -1 10
1
end_operator
begin_operator
debark car66 loc2
1
65 11
2
0 0 63 0
0 8 -1 11
1
end_operator
begin_operator
debark car66 loc20
1
65 12
2
0 0 63 0
0 8 -1 12
1
end_operator
begin_operator
debark car66 loc21
1
65 13
2
0 0 63 0
0 8 -1 13
1
end_operator
begin_operator
debark car66 loc22
1
65 14
2
0 0 63 0
0 8 -1 14
1
end_operator
begin_operator
debark car66 loc23
1
65 15
2
0 0 63 0
0 8 -1 15
1
end_operator
begin_operator
debark car66 loc24
1
65 16
2
0 0 63 0
0 8 -1 16
1
end_operator
begin_operator
debark car66 loc25
1
65 17
2
0 0 63 0
0 8 -1 17
1
end_operator
begin_operator
debark car66 loc26
1
65 18
2
0 0 63 0
0 8 -1 18
1
end_operator
begin_operator
debark car66 loc27
1
65 19
2
0 0 63 0
0 8 -1 19
1
end_operator
begin_operator
debark car66 loc28
1
65 20
2
0 0 63 0
0 8 -1 20
1
end_operator
begin_operator
debark car66 loc29
1
65 21
2
0 0 63 0
0 8 -1 21
1
end_operator
begin_operator
debark car66 loc3
1
65 22
2
0 0 63 0
0 8 -1 22
1
end_operator
begin_operator
debark car66 loc30
1
65 23
2
0 0 63 0
0 8 -1 23
1
end_operator
begin_operator
debark car66 loc31
1
65 24
2
0 0 63 0
0 8 -1 24
1
end_operator
begin_operator
debark car66 loc32
1
65 25
2
0 0 63 0
0 8 -1 25
1
end_operator
begin_operator
debark car66 loc33
1
65 26
2
0 0 63 0
0 8 -1 26
1
end_operator
begin_operator
debark car66 loc34
1
65 27
2
0 0 63 0
0 8 -1 27
1
end_operator
begin_operator
debark car66 loc35
1
65 28
2
0 0 63 0
0 8 -1 28
1
end_operator
begin_operator
debark car66 loc36
1
65 29
2
0 0 63 0
0 8 -1 29
1
end_operator
begin_operator
debark car66 loc37
1
65 30
2
0 0 63 0
0 8 -1 30
1
end_operator
begin_operator
debark car66 loc38
1
65 31
2
0 0 63 0
0 8 -1 31
1
end_operator
begin_operator
debark car66 loc39
1
65 32
2
0 0 63 0
0 8 -1 32
1
end_operator
begin_operator
debark car66 loc4
1
65 33
2
0 0 63 0
0 8 -1 33
1
end_operator
begin_operator
debark car66 loc40
1
65 34
2
0 0 63 0
0 8 -1 34
1
end_operator
begin_operator
debark car66 loc41
1
65 35
2
0 0 63 0
0 8 -1 35
1
end_operator
begin_operator
debark car66 loc5
1
65 36
2
0 0 63 0
0 8 -1 36
1
end_operator
begin_operator
debark car66 loc6
1
65 37
2
0 0 63 0
0 8 -1 37
1
end_operator
begin_operator
debark car66 loc7
1
65 38
2
0 0 63 0
0 8 -1 38
1
end_operator
begin_operator
debark car66 loc8
1
65 39
2
0 0 63 0
0 8 -1 39
1
end_operator
begin_operator
debark car66 loc9
1
65 40
2
0 0 63 0
0 8 -1 40
1
end_operator
begin_operator
debark car67 loc1
1
65 0
2
0 0 64 0
0 20 -1 0
1
end_operator
begin_operator
debark car67 loc10
1
65 1
2
0 0 64 0
0 20 -1 1
1
end_operator
begin_operator
debark car67 loc11
1
65 2
2
0 0 64 0
0 20 -1 2
1
end_operator
begin_operator
debark car67 loc12
1
65 3
2
0 0 64 0
0 20 -1 3
1
end_operator
begin_operator
debark car67 loc13
1
65 4
2
0 0 64 0
0 20 -1 4
1
end_operator
begin_operator
debark car67 loc14
1
65 5
2
0 0 64 0
0 20 -1 5
1
end_operator
begin_operator
debark car67 loc15
1
65 6
2
0 0 64 0
0 20 -1 6
1
end_operator
begin_operator
debark car67 loc16
1
65 7
2
0 0 64 0
0 20 -1 7
1
end_operator
begin_operator
debark car67 loc17
1
65 8
2
0 0 64 0
0 20 -1 8
1
end_operator
begin_operator
debark car67 loc18
1
65 9
2
0 0 64 0
0 20 -1 9
1
end_operator
begin_operator
debark car67 loc19
1
65 10
2
0 0 64 0
0 20 -1 10
1
end_operator
begin_operator
debark car67 loc2
1
65 11
2
0 0 64 0
0 20 -1 11
1
end_operator
begin_operator
debark car67 loc20
1
65 12
2
0 0 64 0
0 20 -1 12
1
end_operator
begin_operator
debark car67 loc21
1
65 13
2
0 0 64 0
0 20 -1 13
1
end_operator
begin_operator
debark car67 loc22
1
65 14
2
0 0 64 0
0 20 -1 14
1
end_operator
begin_operator
debark car67 loc23
1
65 15
2
0 0 64 0
0 20 -1 15
1
end_operator
begin_operator
debark car67 loc24
1
65 16
2
0 0 64 0
0 20 -1 16
1
end_operator
begin_operator
debark car67 loc25
1
65 17
2
0 0 64 0
0 20 -1 17
1
end_operator
begin_operator
debark car67 loc26
1
65 18
2
0 0 64 0
0 20 -1 18
1
end_operator
begin_operator
debark car67 loc27
1
65 19
2
0 0 64 0
0 20 -1 19
1
end_operator
begin_operator
debark car67 loc28
1
65 20
2
0 0 64 0
0 20 -1 20
1
end_operator
begin_operator
debark car67 loc29
1
65 21
2
0 0 64 0
0 20 -1 21
1
end_operator
begin_operator
debark car67 loc3
1
65 22
2
0 0 64 0
0 20 -1 22
1
end_operator
begin_operator
debark car67 loc30
1
65 23
2
0 0 64 0
0 20 -1 23
1
end_operator
begin_operator
debark car67 loc31
1
65 24
2
0 0 64 0
0 20 -1 24
1
end_operator
begin_operator
debark car67 loc32
1
65 25
2
0 0 64 0
0 20 -1 25
1
end_operator
begin_operator
debark car67 loc33
1
65 26
2
0 0 64 0
0 20 -1 26
1
end_operator
begin_operator
debark car67 loc34
1
65 27
2
0 0 64 0
0 20 -1 27
1
end_operator
begin_operator
debark car67 loc35
1
65 28
2
0 0 64 0
0 20 -1 28
1
end_operator
begin_operator
debark car67 loc36
1
65 29
2
0 0 64 0
0 20 -1 29
1
end_operator
begin_operator
debark car67 loc37
1
65 30
2
0 0 64 0
0 20 -1 30
1
end_operator
begin_operator
debark car67 loc38
1
65 31
2
0 0 64 0
0 20 -1 31
1
end_operator
begin_operator
debark car67 loc39
1
65 32
2
0 0 64 0
0 20 -1 32
1
end_operator
begin_operator
debark car67 loc4
1
65 33
2
0 0 64 0
0 20 -1 33
1
end_operator
begin_operator
debark car67 loc40
1
65 34
2
0 0 64 0
0 20 -1 34
1
end_operator
begin_operator
debark car67 loc41
1
65 35
2
0 0 64 0
0 20 -1 35
1
end_operator
begin_operator
debark car67 loc5
1
65 36
2
0 0 64 0
0 20 -1 36
1
end_operator
begin_operator
debark car67 loc6
1
65 37
2
0 0 64 0
0 20 -1 37
1
end_operator
begin_operator
debark car67 loc7
1
65 38
2
0 0 64 0
0 20 -1 38
1
end_operator
begin_operator
debark car67 loc8
1
65 39
2
0 0 64 0
0 20 -1 39
1
end_operator
begin_operator
debark car67 loc9
1
65 40
2
0 0 64 0
0 20 -1 40
1
end_operator
begin_operator
debark car68 loc1
1
65 0
2
0 0 65 0
0 32 -1 0
1
end_operator
begin_operator
debark car68 loc10
1
65 1
2
0 0 65 0
0 32 -1 1
1
end_operator
begin_operator
debark car68 loc11
1
65 2
2
0 0 65 0
0 32 -1 2
1
end_operator
begin_operator
debark car68 loc12
1
65 3
2
0 0 65 0
0 32 -1 3
1
end_operator
begin_operator
debark car68 loc13
1
65 4
2
0 0 65 0
0 32 -1 4
1
end_operator
begin_operator
debark car68 loc14
1
65 5
2
0 0 65 0
0 32 -1 5
1
end_operator
begin_operator
debark car68 loc15
1
65 6
2
0 0 65 0
0 32 -1 6
1
end_operator
begin_operator
debark car68 loc16
1
65 7
2
0 0 65 0
0 32 -1 7
1
end_operator
begin_operator
debark car68 loc17
1
65 8
2
0 0 65 0
0 32 -1 8
1
end_operator
begin_operator
debark car68 loc18
1
65 9
2
0 0 65 0
0 32 -1 9
1
end_operator
begin_operator
debark car68 loc19
1
65 10
2
0 0 65 0
0 32 -1 10
1
end_operator
begin_operator
debark car68 loc2
1
65 11
2
0 0 65 0
0 32 -1 11
1
end_operator
begin_operator
debark car68 loc20
1
65 12
2
0 0 65 0
0 32 -1 12
1
end_operator
begin_operator
debark car68 loc21
1
65 13
2
0 0 65 0
0 32 -1 13
1
end_operator
begin_operator
debark car68 loc22
1
65 14
2
0 0 65 0
0 32 -1 14
1
end_operator
begin_operator
debark car68 loc23
1
65 15
2
0 0 65 0
0 32 -1 15
1
end_operator
begin_operator
debark car68 loc24
1
65 16
2
0 0 65 0
0 32 -1 16
1
end_operator
begin_operator
debark car68 loc25
1
65 17
2
0 0 65 0
0 32 -1 17
1
end_operator
begin_operator
debark car68 loc26
1
65 18
2
0 0 65 0
0 32 -1 18
1
end_operator
begin_operator
debark car68 loc27
1
65 19
2
0 0 65 0
0 32 -1 19
1
end_operator
begin_operator
debark car68 loc28
1
65 20
2
0 0 65 0
0 32 -1 20
1
end_operator
begin_operator
debark car68 loc29
1
65 21
2
0 0 65 0
0 32 -1 21
1
end_operator
begin_operator
debark car68 loc3
1
65 22
2
0 0 65 0
0 32 -1 22
1
end_operator
begin_operator
debark car68 loc30
1
65 23
2
0 0 65 0
0 32 -1 23
1
end_operator
begin_operator
debark car68 loc31
1
65 24
2
0 0 65 0
0 32 -1 24
1
end_operator
begin_operator
debark car68 loc32
1
65 25
2
0 0 65 0
0 32 -1 25
1
end_operator
begin_operator
debark car68 loc33
1
65 26
2
0 0 65 0
0 32 -1 26
1
end_operator
begin_operator
debark car68 loc34
1
65 27
2
0 0 65 0
0 32 -1 27
1
end_operator
begin_operator
debark car68 loc35
1
65 28
2
0 0 65 0
0 32 -1 28
1
end_operator
begin_operator
debark car68 loc36
1
65 29
2
0 0 65 0
0 32 -1 29
1
end_operator
begin_operator
debark car68 loc37
1
65 30
2
0 0 65 0
0 32 -1 30
1
end_operator
begin_operator
debark car68 loc38
1
65 31
2
0 0 65 0
0 32 -1 31
1
end_operator
begin_operator
debark car68 loc39
1
65 32
2
0 0 65 0
0 32 -1 32
1
end_operator
begin_operator
debark car68 loc4
1
65 33
2
0 0 65 0
0 32 -1 33
1
end_operator
begin_operator
debark car68 loc40
1
65 34
2
0 0 65 0
0 32 -1 34
1
end_operator
begin_operator
debark car68 loc41
1
65 35
2
0 0 65 0
0 32 -1 35
1
end_operator
begin_operator
debark car68 loc5
1
65 36
2
0 0 65 0
0 32 -1 36
1
end_operator
begin_operator
debark car68 loc6
1
65 37
2
0 0 65 0
0 32 -1 37
1
end_operator
begin_operator
debark car68 loc7
1
65 38
2
0 0 65 0
0 32 -1 38
1
end_operator
begin_operator
debark car68 loc8
1
65 39
2
0 0 65 0
0 32 -1 39
1
end_operator
begin_operator
debark car68 loc9
1
65 40
2
0 0 65 0
0 32 -1 40
1
end_operator
begin_operator
debark car69 loc1
1
65 0
2
0 0 66 0
0 44 -1 0
1
end_operator
begin_operator
debark car69 loc10
1
65 1
2
0 0 66 0
0 44 -1 1
1
end_operator
begin_operator
debark car69 loc11
1
65 2
2
0 0 66 0
0 44 -1 2
1
end_operator
begin_operator
debark car69 loc12
1
65 3
2
0 0 66 0
0 44 -1 3
1
end_operator
begin_operator
debark car69 loc13
1
65 4
2
0 0 66 0
0 44 -1 4
1
end_operator
begin_operator
debark car69 loc14
1
65 5
2
0 0 66 0
0 44 -1 5
1
end_operator
begin_operator
debark car69 loc15
1
65 6
2
0 0 66 0
0 44 -1 6
1
end_operator
begin_operator
debark car69 loc16
1
65 7
2
0 0 66 0
0 44 -1 7
1
end_operator
begin_operator
debark car69 loc17
1
65 8
2
0 0 66 0
0 44 -1 8
1
end_operator
begin_operator
debark car69 loc18
1
65 9
2
0 0 66 0
0 44 -1 9
1
end_operator
begin_operator
debark car69 loc19
1
65 10
2
0 0 66 0
0 44 -1 10
1
end_operator
begin_operator
debark car69 loc2
1
65 11
2
0 0 66 0
0 44 -1 11
1
end_operator
begin_operator
debark car69 loc20
1
65 12
2
0 0 66 0
0 44 -1 12
1
end_operator
begin_operator
debark car69 loc21
1
65 13
2
0 0 66 0
0 44 -1 13
1
end_operator
begin_operator
debark car69 loc22
1
65 14
2
0 0 66 0
0 44 -1 14
1
end_operator
begin_operator
debark car69 loc23
1
65 15
2
0 0 66 0
0 44 -1 15
1
end_operator
begin_operator
debark car69 loc24
1
65 16
2
0 0 66 0
0 44 -1 16
1
end_operator
begin_operator
debark car69 loc25
1
65 17
2
0 0 66 0
0 44 -1 17
1
end_operator
begin_operator
debark car69 loc26
1
65 18
2
0 0 66 0
0 44 -1 18
1
end_operator
begin_operator
debark car69 loc27
1
65 19
2
0 0 66 0
0 44 -1 19
1
end_operator
begin_operator
debark car69 loc28
1
65 20
2
0 0 66 0
0 44 -1 20
1
end_operator
begin_operator
debark car69 loc29
1
65 21
2
0 0 66 0
0 44 -1 21
1
end_operator
begin_operator
debark car69 loc3
1
65 22
2
0 0 66 0
0 44 -1 22
1
end_operator
begin_operator
debark car69 loc30
1
65 23
2
0 0 66 0
0 44 -1 23
1
end_operator
begin_operator
debark car69 loc31
1
65 24
2
0 0 66 0
0 44 -1 24
1
end_operator
begin_operator
debark car69 loc32
1
65 25
2
0 0 66 0
0 44 -1 25
1
end_operator
begin_operator
debark car69 loc33
1
65 26
2
0 0 66 0
0 44 -1 26
1
end_operator
begin_operator
debark car69 loc34
1
65 27
2
0 0 66 0
0 44 -1 27
1
end_operator
begin_operator
debark car69 loc35
1
65 28
2
0 0 66 0
0 44 -1 28
1
end_operator
begin_operator
debark car69 loc36
1
65 29
2
0 0 66 0
0 44 -1 29
1
end_operator
begin_operator
debark car69 loc37
1
65 30
2
0 0 66 0
0 44 -1 30
1
end_operator
begin_operator
debark car69 loc38
1
65 31
2
0 0 66 0
0 44 -1 31
1
end_operator
begin_operator
debark car69 loc39
1
65 32
2
0 0 66 0
0 44 -1 32
1
end_operator
begin_operator
debark car69 loc4
1
65 33
2
0 0 66 0
0 44 -1 33
1
end_operator
begin_operator
debark car69 loc40
1
65 34
2
0 0 66 0
0 44 -1 34
1
end_operator
begin_operator
debark car69 loc41
1
65 35
2
0 0 66 0
0 44 -1 35
1
end_operator
begin_operator
debark car69 loc5
1
65 36
2
0 0 66 0
0 44 -1 36
1
end_operator
begin_operator
debark car69 loc6
1
65 37
2
0 0 66 0
0 44 -1 37
1
end_operator
begin_operator
debark car69 loc7
1
65 38
2
0 0 66 0
0 44 -1 38
1
end_operator
begin_operator
debark car69 loc8
1
65 39
2
0 0 66 0
0 44 -1 39
1
end_operator
begin_operator
debark car69 loc9
1
65 40
2
0 0 66 0
0 44 -1 40
1
end_operator
begin_operator
debark car7 loc1
1
65 0
2
0 0 67 0
0 56 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
65 1
2
0 0 67 0
0 56 -1 1
1
end_operator
begin_operator
debark car7 loc11
1
65 2
2
0 0 67 0
0 56 -1 2
1
end_operator
begin_operator
debark car7 loc12
1
65 3
2
0 0 67 0
0 56 -1 3
1
end_operator
begin_operator
debark car7 loc13
1
65 4
2
0 0 67 0
0 56 -1 4
1
end_operator
begin_operator
debark car7 loc14
1
65 5
2
0 0 67 0
0 56 -1 5
1
end_operator
begin_operator
debark car7 loc15
1
65 6
2
0 0 67 0
0 56 -1 6
1
end_operator
begin_operator
debark car7 loc16
1
65 7
2
0 0 67 0
0 56 -1 7
1
end_operator
begin_operator
debark car7 loc17
1
65 8
2
0 0 67 0
0 56 -1 8
1
end_operator
begin_operator
debark car7 loc18
1
65 9
2
0 0 67 0
0 56 -1 9
1
end_operator
begin_operator
debark car7 loc19
1
65 10
2
0 0 67 0
0 56 -1 10
1
end_operator
begin_operator
debark car7 loc2
1
65 11
2
0 0 67 0
0 56 -1 11
1
end_operator
begin_operator
debark car7 loc20
1
65 12
2
0 0 67 0
0 56 -1 12
1
end_operator
begin_operator
debark car7 loc21
1
65 13
2
0 0 67 0
0 56 -1 13
1
end_operator
begin_operator
debark car7 loc22
1
65 14
2
0 0 67 0
0 56 -1 14
1
end_operator
begin_operator
debark car7 loc23
1
65 15
2
0 0 67 0
0 56 -1 15
1
end_operator
begin_operator
debark car7 loc24
1
65 16
2
0 0 67 0
0 56 -1 16
1
end_operator
begin_operator
debark car7 loc25
1
65 17
2
0 0 67 0
0 56 -1 17
1
end_operator
begin_operator
debark car7 loc26
1
65 18
2
0 0 67 0
0 56 -1 18
1
end_operator
begin_operator
debark car7 loc27
1
65 19
2
0 0 67 0
0 56 -1 19
1
end_operator
begin_operator
debark car7 loc28
1
65 20
2
0 0 67 0
0 56 -1 20
1
end_operator
begin_operator
debark car7 loc29
1
65 21
2
0 0 67 0
0 56 -1 21
1
end_operator
begin_operator
debark car7 loc3
1
65 22
2
0 0 67 0
0 56 -1 22
1
end_operator
begin_operator
debark car7 loc30
1
65 23
2
0 0 67 0
0 56 -1 23
1
end_operator
begin_operator
debark car7 loc31
1
65 24
2
0 0 67 0
0 56 -1 24
1
end_operator
begin_operator
debark car7 loc32
1
65 25
2
0 0 67 0
0 56 -1 25
1
end_operator
begin_operator
debark car7 loc33
1
65 26
2
0 0 67 0
0 56 -1 26
1
end_operator
begin_operator
debark car7 loc34
1
65 27
2
0 0 67 0
0 56 -1 27
1
end_operator
begin_operator
debark car7 loc35
1
65 28
2
0 0 67 0
0 56 -1 28
1
end_operator
begin_operator
debark car7 loc36
1
65 29
2
0 0 67 0
0 56 -1 29
1
end_operator
begin_operator
debark car7 loc37
1
65 30
2
0 0 67 0
0 56 -1 30
1
end_operator
begin_operator
debark car7 loc38
1
65 31
2
0 0 67 0
0 56 -1 31
1
end_operator
begin_operator
debark car7 loc39
1
65 32
2
0 0 67 0
0 56 -1 32
1
end_operator
begin_operator
debark car7 loc4
1
65 33
2
0 0 67 0
0 56 -1 33
1
end_operator
begin_operator
debark car7 loc40
1
65 34
2
0 0 67 0
0 56 -1 34
1
end_operator
begin_operator
debark car7 loc41
1
65 35
2
0 0 67 0
0 56 -1 35
1
end_operator
begin_operator
debark car7 loc5
1
65 36
2
0 0 67 0
0 56 -1 36
1
end_operator
begin_operator
debark car7 loc6
1
65 37
2
0 0 67 0
0 56 -1 37
1
end_operator
begin_operator
debark car7 loc7
1
65 38
2
0 0 67 0
0 56 -1 38
1
end_operator
begin_operator
debark car7 loc8
1
65 39
2
0 0 67 0
0 56 -1 39
1
end_operator
begin_operator
debark car7 loc9
1
65 40
2
0 0 67 0
0 56 -1 40
1
end_operator
begin_operator
debark car70 loc1
1
65 0
2
0 0 68 0
0 68 -1 0
1
end_operator
begin_operator
debark car70 loc10
1
65 1
2
0 0 68 0
0 68 -1 1
1
end_operator
begin_operator
debark car70 loc11
1
65 2
2
0 0 68 0
0 68 -1 2
1
end_operator
begin_operator
debark car70 loc12
1
65 3
2
0 0 68 0
0 68 -1 3
1
end_operator
begin_operator
debark car70 loc13
1
65 4
2
0 0 68 0
0 68 -1 4
1
end_operator
begin_operator
debark car70 loc14
1
65 5
2
0 0 68 0
0 68 -1 5
1
end_operator
begin_operator
debark car70 loc15
1
65 6
2
0 0 68 0
0 68 -1 6
1
end_operator
begin_operator
debark car70 loc16
1
65 7
2
0 0 68 0
0 68 -1 7
1
end_operator
begin_operator
debark car70 loc17
1
65 8
2
0 0 68 0
0 68 -1 8
1
end_operator
begin_operator
debark car70 loc18
1
65 9
2
0 0 68 0
0 68 -1 9
1
end_operator
begin_operator
debark car70 loc19
1
65 10
2
0 0 68 0
0 68 -1 10
1
end_operator
begin_operator
debark car70 loc2
1
65 11
2
0 0 68 0
0 68 -1 11
1
end_operator
begin_operator
debark car70 loc20
1
65 12
2
0 0 68 0
0 68 -1 12
1
end_operator
begin_operator
debark car70 loc21
1
65 13
2
0 0 68 0
0 68 -1 13
1
end_operator
begin_operator
debark car70 loc22
1
65 14
2
0 0 68 0
0 68 -1 14
1
end_operator
begin_operator
debark car70 loc23
1
65 15
2
0 0 68 0
0 68 -1 15
1
end_operator
begin_operator
debark car70 loc24
1
65 16
2
0 0 68 0
0 68 -1 16
1
end_operator
begin_operator
debark car70 loc25
1
65 17
2
0 0 68 0
0 68 -1 17
1
end_operator
begin_operator
debark car70 loc26
1
65 18
2
0 0 68 0
0 68 -1 18
1
end_operator
begin_operator
debark car70 loc27
1
65 19
2
0 0 68 0
0 68 -1 19
1
end_operator
begin_operator
debark car70 loc28
1
65 20
2
0 0 68 0
0 68 -1 20
1
end_operator
begin_operator
debark car70 loc29
1
65 21
2
0 0 68 0
0 68 -1 21
1
end_operator
begin_operator
debark car70 loc3
1
65 22
2
0 0 68 0
0 68 -1 22
1
end_operator
begin_operator
debark car70 loc30
1
65 23
2
0 0 68 0
0 68 -1 23
1
end_operator
begin_operator
debark car70 loc31
1
65 24
2
0 0 68 0
0 68 -1 24
1
end_operator
begin_operator
debark car70 loc32
1
65 25
2
0 0 68 0
0 68 -1 25
1
end_operator
begin_operator
debark car70 loc33
1
65 26
2
0 0 68 0
0 68 -1 26
1
end_operator
begin_operator
debark car70 loc34
1
65 27
2
0 0 68 0
0 68 -1 27
1
end_operator
begin_operator
debark car70 loc35
1
65 28
2
0 0 68 0
0 68 -1 28
1
end_operator
begin_operator
debark car70 loc36
1
65 29
2
0 0 68 0
0 68 -1 29
1
end_operator
begin_operator
debark car70 loc37
1
65 30
2
0 0 68 0
0 68 -1 30
1
end_operator
begin_operator
debark car70 loc38
1
65 31
2
0 0 68 0
0 68 -1 31
1
end_operator
begin_operator
debark car70 loc39
1
65 32
2
0 0 68 0
0 68 -1 32
1
end_operator
begin_operator
debark car70 loc4
1
65 33
2
0 0 68 0
0 68 -1 33
1
end_operator
begin_operator
debark car70 loc40
1
65 34
2
0 0 68 0
0 68 -1 34
1
end_operator
begin_operator
debark car70 loc41
1
65 35
2
0 0 68 0
0 68 -1 35
1
end_operator
begin_operator
debark car70 loc5
1
65 36
2
0 0 68 0
0 68 -1 36
1
end_operator
begin_operator
debark car70 loc6
1
65 37
2
0 0 68 0
0 68 -1 37
1
end_operator
begin_operator
debark car70 loc7
1
65 38
2
0 0 68 0
0 68 -1 38
1
end_operator
begin_operator
debark car70 loc8
1
65 39
2
0 0 68 0
0 68 -1 39
1
end_operator
begin_operator
debark car70 loc9
1
65 40
2
0 0 68 0
0 68 -1 40
1
end_operator
begin_operator
debark car71 loc1
1
65 0
2
0 0 69 0
0 5 -1 0
1
end_operator
begin_operator
debark car71 loc10
1
65 1
2
0 0 69 0
0 5 -1 1
1
end_operator
begin_operator
debark car71 loc11
1
65 2
2
0 0 69 0
0 5 -1 2
1
end_operator
begin_operator
debark car71 loc12
1
65 3
2
0 0 69 0
0 5 -1 3
1
end_operator
begin_operator
debark car71 loc13
1
65 4
2
0 0 69 0
0 5 -1 4
1
end_operator
begin_operator
debark car71 loc14
1
65 5
2
0 0 69 0
0 5 -1 5
1
end_operator
begin_operator
debark car71 loc15
1
65 6
2
0 0 69 0
0 5 -1 6
1
end_operator
begin_operator
debark car71 loc16
1
65 7
2
0 0 69 0
0 5 -1 7
1
end_operator
begin_operator
debark car71 loc17
1
65 8
2
0 0 69 0
0 5 -1 8
1
end_operator
begin_operator
debark car71 loc18
1
65 9
2
0 0 69 0
0 5 -1 9
1
end_operator
begin_operator
debark car71 loc19
1
65 10
2
0 0 69 0
0 5 -1 10
1
end_operator
begin_operator
debark car71 loc2
1
65 11
2
0 0 69 0
0 5 -1 11
1
end_operator
begin_operator
debark car71 loc20
1
65 12
2
0 0 69 0
0 5 -1 12
1
end_operator
begin_operator
debark car71 loc21
1
65 13
2
0 0 69 0
0 5 -1 13
1
end_operator
begin_operator
debark car71 loc22
1
65 14
2
0 0 69 0
0 5 -1 14
1
end_operator
begin_operator
debark car71 loc23
1
65 15
2
0 0 69 0
0 5 -1 15
1
end_operator
begin_operator
debark car71 loc24
1
65 16
2
0 0 69 0
0 5 -1 16
1
end_operator
begin_operator
debark car71 loc25
1
65 17
2
0 0 69 0
0 5 -1 17
1
end_operator
begin_operator
debark car71 loc26
1
65 18
2
0 0 69 0
0 5 -1 18
1
end_operator
begin_operator
debark car71 loc27
1
65 19
2
0 0 69 0
0 5 -1 19
1
end_operator
begin_operator
debark car71 loc28
1
65 20
2
0 0 69 0
0 5 -1 20
1
end_operator
begin_operator
debark car71 loc29
1
65 21
2
0 0 69 0
0 5 -1 21
1
end_operator
begin_operator
debark car71 loc3
1
65 22
2
0 0 69 0
0 5 -1 22
1
end_operator
begin_operator
debark car71 loc30
1
65 23
2
0 0 69 0
0 5 -1 23
1
end_operator
begin_operator
debark car71 loc31
1
65 24
2
0 0 69 0
0 5 -1 24
1
end_operator
begin_operator
debark car71 loc32
1
65 25
2
0 0 69 0
0 5 -1 25
1
end_operator
begin_operator
debark car71 loc33
1
65 26
2
0 0 69 0
0 5 -1 26
1
end_operator
begin_operator
debark car71 loc34
1
65 27
2
0 0 69 0
0 5 -1 27
1
end_operator
begin_operator
debark car71 loc35
1
65 28
2
0 0 69 0
0 5 -1 28
1
end_operator
begin_operator
debark car71 loc36
1
65 29
2
0 0 69 0
0 5 -1 29
1
end_operator
begin_operator
debark car71 loc37
1
65 30
2
0 0 69 0
0 5 -1 30
1
end_operator
begin_operator
debark car71 loc38
1
65 31
2
0 0 69 0
0 5 -1 31
1
end_operator
begin_operator
debark car71 loc39
1
65 32
2
0 0 69 0
0 5 -1 32
1
end_operator
begin_operator
debark car71 loc4
1
65 33
2
0 0 69 0
0 5 -1 33
1
end_operator
begin_operator
debark car71 loc40
1
65 34
2
0 0 69 0
0 5 -1 34
1
end_operator
begin_operator
debark car71 loc41
1
65 35
2
0 0 69 0
0 5 -1 35
1
end_operator
begin_operator
debark car71 loc5
1
65 36
2
0 0 69 0
0 5 -1 36
1
end_operator
begin_operator
debark car71 loc6
1
65 37
2
0 0 69 0
0 5 -1 37
1
end_operator
begin_operator
debark car71 loc7
1
65 38
2
0 0 69 0
0 5 -1 38
1
end_operator
begin_operator
debark car71 loc8
1
65 39
2
0 0 69 0
0 5 -1 39
1
end_operator
begin_operator
debark car71 loc9
1
65 40
2
0 0 69 0
0 5 -1 40
1
end_operator
begin_operator
debark car72 loc1
1
65 0
2
0 0 70 0
0 17 -1 0
1
end_operator
begin_operator
debark car72 loc10
1
65 1
2
0 0 70 0
0 17 -1 1
1
end_operator
begin_operator
debark car72 loc11
1
65 2
2
0 0 70 0
0 17 -1 2
1
end_operator
begin_operator
debark car72 loc12
1
65 3
2
0 0 70 0
0 17 -1 3
1
end_operator
begin_operator
debark car72 loc13
1
65 4
2
0 0 70 0
0 17 -1 4
1
end_operator
begin_operator
debark car72 loc14
1
65 5
2
0 0 70 0
0 17 -1 5
1
end_operator
begin_operator
debark car72 loc15
1
65 6
2
0 0 70 0
0 17 -1 6
1
end_operator
begin_operator
debark car72 loc16
1
65 7
2
0 0 70 0
0 17 -1 7
1
end_operator
begin_operator
debark car72 loc17
1
65 8
2
0 0 70 0
0 17 -1 8
1
end_operator
begin_operator
debark car72 loc18
1
65 9
2
0 0 70 0
0 17 -1 9
1
end_operator
begin_operator
debark car72 loc19
1
65 10
2
0 0 70 0
0 17 -1 10
1
end_operator
begin_operator
debark car72 loc2
1
65 11
2
0 0 70 0
0 17 -1 11
1
end_operator
begin_operator
debark car72 loc20
1
65 12
2
0 0 70 0
0 17 -1 12
1
end_operator
begin_operator
debark car72 loc21
1
65 13
2
0 0 70 0
0 17 -1 13
1
end_operator
begin_operator
debark car72 loc22
1
65 14
2
0 0 70 0
0 17 -1 14
1
end_operator
begin_operator
debark car72 loc23
1
65 15
2
0 0 70 0
0 17 -1 15
1
end_operator
begin_operator
debark car72 loc24
1
65 16
2
0 0 70 0
0 17 -1 16
1
end_operator
begin_operator
debark car72 loc25
1
65 17
2
0 0 70 0
0 17 -1 17
1
end_operator
begin_operator
debark car72 loc26
1
65 18
2
0 0 70 0
0 17 -1 18
1
end_operator
begin_operator
debark car72 loc27
1
65 19
2
0 0 70 0
0 17 -1 19
1
end_operator
begin_operator
debark car72 loc28
1
65 20
2
0 0 70 0
0 17 -1 20
1
end_operator
begin_operator
debark car72 loc29
1
65 21
2
0 0 70 0
0 17 -1 21
1
end_operator
begin_operator
debark car72 loc3
1
65 22
2
0 0 70 0
0 17 -1 22
1
end_operator
begin_operator
debark car72 loc30
1
65 23
2
0 0 70 0
0 17 -1 23
1
end_operator
begin_operator
debark car72 loc31
1
65 24
2
0 0 70 0
0 17 -1 24
1
end_operator
begin_operator
debark car72 loc32
1
65 25
2
0 0 70 0
0 17 -1 25
1
end_operator
begin_operator
debark car72 loc33
1
65 26
2
0 0 70 0
0 17 -1 26
1
end_operator
begin_operator
debark car72 loc34
1
65 27
2
0 0 70 0
0 17 -1 27
1
end_operator
begin_operator
debark car72 loc35
1
65 28
2
0 0 70 0
0 17 -1 28
1
end_operator
begin_operator
debark car72 loc36
1
65 29
2
0 0 70 0
0 17 -1 29
1
end_operator
begin_operator
debark car72 loc37
1
65 30
2
0 0 70 0
0 17 -1 30
1
end_operator
begin_operator
debark car72 loc38
1
65 31
2
0 0 70 0
0 17 -1 31
1
end_operator
begin_operator
debark car72 loc39
1
65 32
2
0 0 70 0
0 17 -1 32
1
end_operator
begin_operator
debark car72 loc4
1
65 33
2
0 0 70 0
0 17 -1 33
1
end_operator
begin_operator
debark car72 loc40
1
65 34
2
0 0 70 0
0 17 -1 34
1
end_operator
begin_operator
debark car72 loc41
1
65 35
2
0 0 70 0
0 17 -1 35
1
end_operator
begin_operator
debark car72 loc5
1
65 36
2
0 0 70 0
0 17 -1 36
1
end_operator
begin_operator
debark car72 loc6
1
65 37
2
0 0 70 0
0 17 -1 37
1
end_operator
begin_operator
debark car72 loc7
1
65 38
2
0 0 70 0
0 17 -1 38
1
end_operator
begin_operator
debark car72 loc8
1
65 39
2
0 0 70 0
0 17 -1 39
1
end_operator
begin_operator
debark car72 loc9
1
65 40
2
0 0 70 0
0 17 -1 40
1
end_operator
begin_operator
debark car73 loc1
1
65 0
2
0 0 71 0
0 29 -1 0
1
end_operator
begin_operator
debark car73 loc10
1
65 1
2
0 0 71 0
0 29 -1 1
1
end_operator
begin_operator
debark car73 loc11
1
65 2
2
0 0 71 0
0 29 -1 2
1
end_operator
begin_operator
debark car73 loc12
1
65 3
2
0 0 71 0
0 29 -1 3
1
end_operator
begin_operator
debark car73 loc13
1
65 4
2
0 0 71 0
0 29 -1 4
1
end_operator
begin_operator
debark car73 loc14
1
65 5
2
0 0 71 0
0 29 -1 5
1
end_operator
begin_operator
debark car73 loc15
1
65 6
2
0 0 71 0
0 29 -1 6
1
end_operator
begin_operator
debark car73 loc16
1
65 7
2
0 0 71 0
0 29 -1 7
1
end_operator
begin_operator
debark car73 loc17
1
65 8
2
0 0 71 0
0 29 -1 8
1
end_operator
begin_operator
debark car73 loc18
1
65 9
2
0 0 71 0
0 29 -1 9
1
end_operator
begin_operator
debark car73 loc19
1
65 10
2
0 0 71 0
0 29 -1 10
1
end_operator
begin_operator
debark car73 loc2
1
65 11
2
0 0 71 0
0 29 -1 11
1
end_operator
begin_operator
debark car73 loc20
1
65 12
2
0 0 71 0
0 29 -1 12
1
end_operator
begin_operator
debark car73 loc21
1
65 13
2
0 0 71 0
0 29 -1 13
1
end_operator
begin_operator
debark car73 loc22
1
65 14
2
0 0 71 0
0 29 -1 14
1
end_operator
begin_operator
debark car73 loc23
1
65 15
2
0 0 71 0
0 29 -1 15
1
end_operator
begin_operator
debark car73 loc24
1
65 16
2
0 0 71 0
0 29 -1 16
1
end_operator
begin_operator
debark car73 loc25
1
65 17
2
0 0 71 0
0 29 -1 17
1
end_operator
begin_operator
debark car73 loc26
1
65 18
2
0 0 71 0
0 29 -1 18
1
end_operator
begin_operator
debark car73 loc27
1
65 19
2
0 0 71 0
0 29 -1 19
1
end_operator
begin_operator
debark car73 loc28
1
65 20
2
0 0 71 0
0 29 -1 20
1
end_operator
begin_operator
debark car73 loc29
1
65 21
2
0 0 71 0
0 29 -1 21
1
end_operator
begin_operator
debark car73 loc3
1
65 22
2
0 0 71 0
0 29 -1 22
1
end_operator
begin_operator
debark car73 loc30
1
65 23
2
0 0 71 0
0 29 -1 23
1
end_operator
begin_operator
debark car73 loc31
1
65 24
2
0 0 71 0
0 29 -1 24
1
end_operator
begin_operator
debark car73 loc32
1
65 25
2
0 0 71 0
0 29 -1 25
1
end_operator
begin_operator
debark car73 loc33
1
65 26
2
0 0 71 0
0 29 -1 26
1
end_operator
begin_operator
debark car73 loc34
1
65 27
2
0 0 71 0
0 29 -1 27
1
end_operator
begin_operator
debark car73 loc35
1
65 28
2
0 0 71 0
0 29 -1 28
1
end_operator
begin_operator
debark car73 loc36
1
65 29
2
0 0 71 0
0 29 -1 29
1
end_operator
begin_operator
debark car73 loc37
1
65 30
2
0 0 71 0
0 29 -1 30
1
end_operator
begin_operator
debark car73 loc38
1
65 31
2
0 0 71 0
0 29 -1 31
1
end_operator
begin_operator
debark car73 loc39
1
65 32
2
0 0 71 0
0 29 -1 32
1
end_operator
begin_operator
debark car73 loc4
1
65 33
2
0 0 71 0
0 29 -1 33
1
end_operator
begin_operator
debark car73 loc40
1
65 34
2
0 0 71 0
0 29 -1 34
1
end_operator
begin_operator
debark car73 loc41
1
65 35
2
0 0 71 0
0 29 -1 35
1
end_operator
begin_operator
debark car73 loc5
1
65 36
2
0 0 71 0
0 29 -1 36
1
end_operator
begin_operator
debark car73 loc6
1
65 37
2
0 0 71 0
0 29 -1 37
1
end_operator
begin_operator
debark car73 loc7
1
65 38
2
0 0 71 0
0 29 -1 38
1
end_operator
begin_operator
debark car73 loc8
1
65 39
2
0 0 71 0
0 29 -1 39
1
end_operator
begin_operator
debark car73 loc9
1
65 40
2
0 0 71 0
0 29 -1 40
1
end_operator
begin_operator
debark car8 loc1
1
65 0
2
0 0 72 0
0 41 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
65 1
2
0 0 72 0
0 41 -1 1
1
end_operator
begin_operator
debark car8 loc11
1
65 2
2
0 0 72 0
0 41 -1 2
1
end_operator
begin_operator
debark car8 loc12
1
65 3
2
0 0 72 0
0 41 -1 3
1
end_operator
begin_operator
debark car8 loc13
1
65 4
2
0 0 72 0
0 41 -1 4
1
end_operator
begin_operator
debark car8 loc14
1
65 5
2
0 0 72 0
0 41 -1 5
1
end_operator
begin_operator
debark car8 loc15
1
65 6
2
0 0 72 0
0 41 -1 6
1
end_operator
begin_operator
debark car8 loc16
1
65 7
2
0 0 72 0
0 41 -1 7
1
end_operator
begin_operator
debark car8 loc17
1
65 8
2
0 0 72 0
0 41 -1 8
1
end_operator
begin_operator
debark car8 loc18
1
65 9
2
0 0 72 0
0 41 -1 9
1
end_operator
begin_operator
debark car8 loc19
1
65 10
2
0 0 72 0
0 41 -1 10
1
end_operator
begin_operator
debark car8 loc2
1
65 11
2
0 0 72 0
0 41 -1 11
1
end_operator
begin_operator
debark car8 loc20
1
65 12
2
0 0 72 0
0 41 -1 12
1
end_operator
begin_operator
debark car8 loc21
1
65 13
2
0 0 72 0
0 41 -1 13
1
end_operator
begin_operator
debark car8 loc22
1
65 14
2
0 0 72 0
0 41 -1 14
1
end_operator
begin_operator
debark car8 loc23
1
65 15
2
0 0 72 0
0 41 -1 15
1
end_operator
begin_operator
debark car8 loc24
1
65 16
2
0 0 72 0
0 41 -1 16
1
end_operator
begin_operator
debark car8 loc25
1
65 17
2
0 0 72 0
0 41 -1 17
1
end_operator
begin_operator
debark car8 loc26
1
65 18
2
0 0 72 0
0 41 -1 18
1
end_operator
begin_operator
debark car8 loc27
1
65 19
2
0 0 72 0
0 41 -1 19
1
end_operator
begin_operator
debark car8 loc28
1
65 20
2
0 0 72 0
0 41 -1 20
1
end_operator
begin_operator
debark car8 loc29
1
65 21
2
0 0 72 0
0 41 -1 21
1
end_operator
begin_operator
debark car8 loc3
1
65 22
2
0 0 72 0
0 41 -1 22
1
end_operator
begin_operator
debark car8 loc30
1
65 23
2
0 0 72 0
0 41 -1 23
1
end_operator
begin_operator
debark car8 loc31
1
65 24
2
0 0 72 0
0 41 -1 24
1
end_operator
begin_operator
debark car8 loc32
1
65 25
2
0 0 72 0
0 41 -1 25
1
end_operator
begin_operator
debark car8 loc33
1
65 26
2
0 0 72 0
0 41 -1 26
1
end_operator
begin_operator
debark car8 loc34
1
65 27
2
0 0 72 0
0 41 -1 27
1
end_operator
begin_operator
debark car8 loc35
1
65 28
2
0 0 72 0
0 41 -1 28
1
end_operator
begin_operator
debark car8 loc36
1
65 29
2
0 0 72 0
0 41 -1 29
1
end_operator
begin_operator
debark car8 loc37
1
65 30
2
0 0 72 0
0 41 -1 30
1
end_operator
begin_operator
debark car8 loc38
1
65 31
2
0 0 72 0
0 41 -1 31
1
end_operator
begin_operator
debark car8 loc39
1
65 32
2
0 0 72 0
0 41 -1 32
1
end_operator
begin_operator
debark car8 loc4
1
65 33
2
0 0 72 0
0 41 -1 33
1
end_operator
begin_operator
debark car8 loc40
1
65 34
2
0 0 72 0
0 41 -1 34
1
end_operator
begin_operator
debark car8 loc41
1
65 35
2
0 0 72 0
0 41 -1 35
1
end_operator
begin_operator
debark car8 loc5
1
65 36
2
0 0 72 0
0 41 -1 36
1
end_operator
begin_operator
debark car8 loc6
1
65 37
2
0 0 72 0
0 41 -1 37
1
end_operator
begin_operator
debark car8 loc7
1
65 38
2
0 0 72 0
0 41 -1 38
1
end_operator
begin_operator
debark car8 loc8
1
65 39
2
0 0 72 0
0 41 -1 39
1
end_operator
begin_operator
debark car8 loc9
1
65 40
2
0 0 72 0
0 41 -1 40
1
end_operator
begin_operator
debark car9 loc1
1
65 0
2
0 0 73 0
0 53 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
65 1
2
0 0 73 0
0 53 -1 1
1
end_operator
begin_operator
debark car9 loc11
1
65 2
2
0 0 73 0
0 53 -1 2
1
end_operator
begin_operator
debark car9 loc12
1
65 3
2
0 0 73 0
0 53 -1 3
1
end_operator
begin_operator
debark car9 loc13
1
65 4
2
0 0 73 0
0 53 -1 4
1
end_operator
begin_operator
debark car9 loc14
1
65 5
2
0 0 73 0
0 53 -1 5
1
end_operator
begin_operator
debark car9 loc15
1
65 6
2
0 0 73 0
0 53 -1 6
1
end_operator
begin_operator
debark car9 loc16
1
65 7
2
0 0 73 0
0 53 -1 7
1
end_operator
begin_operator
debark car9 loc17
1
65 8
2
0 0 73 0
0 53 -1 8
1
end_operator
begin_operator
debark car9 loc18
1
65 9
2
0 0 73 0
0 53 -1 9
1
end_operator
begin_operator
debark car9 loc19
1
65 10
2
0 0 73 0
0 53 -1 10
1
end_operator
begin_operator
debark car9 loc2
1
65 11
2
0 0 73 0
0 53 -1 11
1
end_operator
begin_operator
debark car9 loc20
1
65 12
2
0 0 73 0
0 53 -1 12
1
end_operator
begin_operator
debark car9 loc21
1
65 13
2
0 0 73 0
0 53 -1 13
1
end_operator
begin_operator
debark car9 loc22
1
65 14
2
0 0 73 0
0 53 -1 14
1
end_operator
begin_operator
debark car9 loc23
1
65 15
2
0 0 73 0
0 53 -1 15
1
end_operator
begin_operator
debark car9 loc24
1
65 16
2
0 0 73 0
0 53 -1 16
1
end_operator
begin_operator
debark car9 loc25
1
65 17
2
0 0 73 0
0 53 -1 17
1
end_operator
begin_operator
debark car9 loc26
1
65 18
2
0 0 73 0
0 53 -1 18
1
end_operator
begin_operator
debark car9 loc27
1
65 19
2
0 0 73 0
0 53 -1 19
1
end_operator
begin_operator
debark car9 loc28
1
65 20
2
0 0 73 0
0 53 -1 20
1
end_operator
begin_operator
debark car9 loc29
1
65 21
2
0 0 73 0
0 53 -1 21
1
end_operator
begin_operator
debark car9 loc3
1
65 22
2
0 0 73 0
0 53 -1 22
1
end_operator
begin_operator
debark car9 loc30
1
65 23
2
0 0 73 0
0 53 -1 23
1
end_operator
begin_operator
debark car9 loc31
1
65 24
2
0 0 73 0
0 53 -1 24
1
end_operator
begin_operator
debark car9 loc32
1
65 25
2
0 0 73 0
0 53 -1 25
1
end_operator
begin_operator
debark car9 loc33
1
65 26
2
0 0 73 0
0 53 -1 26
1
end_operator
begin_operator
debark car9 loc34
1
65 27
2
0 0 73 0
0 53 -1 27
1
end_operator
begin_operator
debark car9 loc35
1
65 28
2
0 0 73 0
0 53 -1 28
1
end_operator
begin_operator
debark car9 loc36
1
65 29
2
0 0 73 0
0 53 -1 29
1
end_operator
begin_operator
debark car9 loc37
1
65 30
2
0 0 73 0
0 53 -1 30
1
end_operator
begin_operator
debark car9 loc38
1
65 31
2
0 0 73 0
0 53 -1 31
1
end_operator
begin_operator
debark car9 loc39
1
65 32
2
0 0 73 0
0 53 -1 32
1
end_operator
begin_operator
debark car9 loc4
1
65 33
2
0 0 73 0
0 53 -1 33
1
end_operator
begin_operator
debark car9 loc40
1
65 34
2
0 0 73 0
0 53 -1 34
1
end_operator
begin_operator
debark car9 loc41
1
65 35
2
0 0 73 0
0 53 -1 35
1
end_operator
begin_operator
debark car9 loc5
1
65 36
2
0 0 73 0
0 53 -1 36
1
end_operator
begin_operator
debark car9 loc6
1
65 37
2
0 0 73 0
0 53 -1 37
1
end_operator
begin_operator
debark car9 loc7
1
65 38
2
0 0 73 0
0 53 -1 38
1
end_operator
begin_operator
debark car9 loc8
1
65 39
2
0 0 73 0
0 53 -1 39
1
end_operator
begin_operator
debark car9 loc9
1
65 40
2
0 0 73 0
0 53 -1 40
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 65 0 1
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 65 0 2
0 75 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 65 0 3
0 75 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 65 0 4
0 75 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 65 0 5
0 75 -1 0
0 80 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 65 0 6
0 75 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 65 0 7
0 75 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 65 0 8
0 75 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 65 0 9
0 75 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 65 0 10
0 75 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 65 0 11
0 75 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 65 0 12
0 75 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 65 0 13
0 75 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 65 0 14
0 75 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 65 0 15
0 75 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc1 loc24
0
3
0 65 0 16
0 75 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc1 loc25
0
3
0 65 0 17
0 75 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc1 loc26
0
3
0 65 0 18
0 75 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc1 loc27
0
3
0 65 0 19
0 75 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc1 loc28
0
3
0 65 0 20
0 75 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc1 loc29
0
3
0 65 0 21
0 75 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 65 0 22
0 75 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc1 loc30
0
3
0 65 0 23
0 75 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc1 loc31
0
3
0 65 0 24
0 75 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc1 loc32
0
3
0 65 0 25
0 75 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc1 loc33
0
3
0 65 0 26
0 75 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc1 loc34
0
3
0 65 0 27
0 75 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc1 loc35
0
3
0 65 0 28
0 75 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc1 loc36
0
3
0 65 0 29
0 75 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc1 loc37
0
3
0 65 0 30
0 75 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc1 loc38
0
3
0 65 0 31
0 75 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc1 loc39
0
3
0 65 0 32
0 75 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 65 0 33
0 75 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc1 loc40
0
3
0 65 0 34
0 75 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc1 loc41
0
3
0 65 0 35
0 75 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 65 0 36
0 75 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 65 0 37
0 75 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 65 0 38
0 75 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 65 0 39
0 75 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 65 0 40
0 75 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 65 1 0
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 65 1 2
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 65 1 3
0 76 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 65 1 4
0 76 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 65 1 5
0 76 -1 0
0 80 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 65 1 6
0 76 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 65 1 7
0 76 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 65 1 8
0 76 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 65 1 9
0 76 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 65 1 10
0 76 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 65 1 11
0 76 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 65 1 12
0 76 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 65 1 13
0 76 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 65 1 14
0 76 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 65 1 15
0 76 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc10 loc24
0
3
0 65 1 16
0 76 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc10 loc25
0
3
0 65 1 17
0 76 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc10 loc26
0
3
0 65 1 18
0 76 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc10 loc27
0
3
0 65 1 19
0 76 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc10 loc28
0
3
0 65 1 20
0 76 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc10 loc29
0
3
0 65 1 21
0 76 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 65 1 22
0 76 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc10 loc30
0
3
0 65 1 23
0 76 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc10 loc31
0
3
0 65 1 24
0 76 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc10 loc32
0
3
0 65 1 25
0 76 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc10 loc33
0
3
0 65 1 26
0 76 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc10 loc34
0
3
0 65 1 27
0 76 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc10 loc35
0
3
0 65 1 28
0 76 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc10 loc36
0
3
0 65 1 29
0 76 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc10 loc37
0
3
0 65 1 30
0 76 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc10 loc38
0
3
0 65 1 31
0 76 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc10 loc39
0
3
0 65 1 32
0 76 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 65 1 33
0 76 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc10 loc40
0
3
0 65 1 34
0 76 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc10 loc41
0
3
0 65 1 35
0 76 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 65 1 36
0 76 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 65 1 37
0 76 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 65 1 38
0 76 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 65 1 39
0 76 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 65 1 40
0 76 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 65 2 0
0 75 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 65 2 1
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 65 2 3
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 65 2 4
0 77 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 65 2 5
0 77 -1 0
0 80 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 65 2 6
0 77 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 65 2 7
0 77 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 65 2 8
0 77 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 65 2 9
0 77 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 65 2 10
0 77 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 65 2 11
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 65 2 12
0 77 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 65 2 13
0 77 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 65 2 14
0 77 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 65 2 15
0 77 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc11 loc24
0
3
0 65 2 16
0 77 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc11 loc25
0
3
0 65 2 17
0 77 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc11 loc26
0
3
0 65 2 18
0 77 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc11 loc27
0
3
0 65 2 19
0 77 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc11 loc28
0
3
0 65 2 20
0 77 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc11 loc29
0
3
0 65 2 21
0 77 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 65 2 22
0 77 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc11 loc30
0
3
0 65 2 23
0 77 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc11 loc31
0
3
0 65 2 24
0 77 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc11 loc32
0
3
0 65 2 25
0 77 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc11 loc33
0
3
0 65 2 26
0 77 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc11 loc34
0
3
0 65 2 27
0 77 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc11 loc35
0
3
0 65 2 28
0 77 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc11 loc36
0
3
0 65 2 29
0 77 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc11 loc37
0
3
0 65 2 30
0 77 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc11 loc38
0
3
0 65 2 31
0 77 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc11 loc39
0
3
0 65 2 32
0 77 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 65 2 33
0 77 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc11 loc40
0
3
0 65 2 34
0 77 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc11 loc41
0
3
0 65 2 35
0 77 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 65 2 36
0 77 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 65 2 37
0 77 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 65 2 38
0 77 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 65 2 39
0 77 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 65 2 40
0 77 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 65 3 0
0 75 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 65 3 1
0 76 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 65 3 2
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 65 3 4
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 65 3 5
0 78 -1 0
0 80 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 65 3 6
0 78 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 65 3 7
0 78 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 65 3 8
0 78 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 65 3 9
0 78 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 65 3 10
0 78 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 65 3 11
0 78 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 65 3 12
0 78 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 65 3 13
0 78 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 65 3 14
0 78 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 65 3 15
0 78 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc12 loc24
0
3
0 65 3 16
0 78 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc12 loc25
0
3
0 65 3 17
0 78 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc12 loc26
0
3
0 65 3 18
0 78 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc12 loc27
0
3
0 65 3 19
0 78 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc12 loc28
0
3
0 65 3 20
0 78 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc12 loc29
0
3
0 65 3 21
0 78 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 65 3 22
0 78 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc12 loc30
0
3
0 65 3 23
0 78 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc12 loc31
0
3
0 65 3 24
0 78 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc12 loc32
0
3
0 65 3 25
0 78 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc12 loc33
0
3
0 65 3 26
0 78 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc12 loc34
0
3
0 65 3 27
0 78 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc12 loc35
0
3
0 65 3 28
0 78 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc12 loc36
0
3
0 65 3 29
0 78 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc12 loc37
0
3
0 65 3 30
0 78 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc12 loc38
0
3
0 65 3 31
0 78 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc12 loc39
0
3
0 65 3 32
0 78 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 65 3 33
0 78 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc12 loc40
0
3
0 65 3 34
0 78 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc12 loc41
0
3
0 65 3 35
0 78 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 65 3 36
0 78 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 65 3 37
0 78 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 65 3 38
0 78 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 65 3 39
0 78 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 65 3 40
0 78 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 65 4 0
0 75 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 65 4 1
0 76 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 65 4 2
0 77 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 65 4 3
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 65 4 5
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 65 4 6
0 79 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 65 4 7
0 79 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 65 4 8
0 79 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 65 4 9
0 79 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 65 4 10
0 79 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 65 4 11
0 79 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 65 4 12
0 79 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 65 4 13
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 65 4 14
0 79 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 65 4 15
0 79 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc13 loc24
0
3
0 65 4 16
0 79 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc13 loc25
0
3
0 65 4 17
0 79 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc13 loc26
0
3
0 65 4 18
0 79 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc13 loc27
0
3
0 65 4 19
0 79 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc13 loc28
0
3
0 65 4 20
0 79 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc13 loc29
0
3
0 65 4 21
0 79 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 65 4 22
0 79 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc13 loc30
0
3
0 65 4 23
0 79 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc13 loc31
0
3
0 65 4 24
0 79 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc13 loc32
0
3
0 65 4 25
0 79 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc13 loc33
0
3
0 65 4 26
0 79 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc13 loc34
0
3
0 65 4 27
0 79 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc13 loc35
0
3
0 65 4 28
0 79 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc13 loc36
0
3
0 65 4 29
0 79 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc13 loc37
0
3
0 65 4 30
0 79 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc13 loc38
0
3
0 65 4 31
0 79 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc13 loc39
0
3
0 65 4 32
0 79 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 65 4 33
0 79 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc13 loc40
0
3
0 65 4 34
0 79 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc13 loc41
0
3
0 65 4 35
0 79 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 65 4 36
0 79 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 65 4 37
0 79 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 65 4 38
0 79 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 65 4 39
0 79 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 65 4 40
0 79 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 65 5 0
0 75 0 1
0 80 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 65 5 1
0 76 0 1
0 80 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 65 5 2
0 77 0 1
0 80 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 65 5 3
0 78 0 1
0 80 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 65 5 4
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 65 5 6
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 65 5 7
0 80 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 65 5 8
0 80 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 65 5 9
0 80 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 65 5 10
0 80 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 65 5 11
0 80 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 65 5 12
0 80 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 65 5 13
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 65 5 14
0 80 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 65 5 15
0 80 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc14 loc24
0
3
0 65 5 16
0 80 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc14 loc25
0
3
0 65 5 17
0 80 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc14 loc26
0
3
0 65 5 18
0 80 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc14 loc27
0
3
0 65 5 19
0 80 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc14 loc28
0
3
0 65 5 20
0 80 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc14 loc29
0
3
0 65 5 21
0 80 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 65 5 22
0 80 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc14 loc30
0
3
0 65 5 23
0 80 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc14 loc31
0
3
0 65 5 24
0 80 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc14 loc32
0
3
0 65 5 25
0 80 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc14 loc33
0
3
0 65 5 26
0 80 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc14 loc34
0
3
0 65 5 27
0 80 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc14 loc35
0
3
0 65 5 28
0 80 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc14 loc36
0
3
0 65 5 29
0 80 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc14 loc37
0
3
0 65 5 30
0 80 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc14 loc38
0
3
0 65 5 31
0 80 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc14 loc39
0
3
0 65 5 32
0 80 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 65 5 33
0 80 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc14 loc40
0
3
0 65 5 34
0 80 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc14 loc41
0
3
0 65 5 35
0 80 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 65 5 36
0 80 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 65 5 37
0 80 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 65 5 38
0 80 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 65 5 39
0 80 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 65 5 40
0 80 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 65 6 0
0 75 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 65 6 1
0 76 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 65 6 2
0 77 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 65 6 3
0 78 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 65 6 4
0 79 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 65 6 5
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 65 6 7
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 65 6 8
0 81 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 65 6 9
0 81 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 65 6 10
0 81 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 65 6 11
0 81 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 65 6 12
0 81 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 65 6 13
0 81 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 65 6 14
0 81 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 65 6 15
0 81 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc15 loc24
0
3
0 65 6 16
0 81 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc15 loc25
0
3
0 65 6 17
0 81 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc15 loc26
0
3
0 65 6 18
0 81 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc15 loc27
0
3
0 65 6 19
0 81 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc15 loc28
0
3
0 65 6 20
0 81 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc15 loc29
0
3
0 65 6 21
0 81 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 65 6 22
0 81 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc15 loc30
0
3
0 65 6 23
0 81 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc15 loc31
0
3
0 65 6 24
0 81 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc15 loc32
0
3
0 65 6 25
0 81 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc15 loc33
0
3
0 65 6 26
0 81 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc15 loc34
0
3
0 65 6 27
0 81 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc15 loc35
0
3
0 65 6 28
0 81 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc15 loc36
0
3
0 65 6 29
0 81 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc15 loc37
0
3
0 65 6 30
0 81 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc15 loc38
0
3
0 65 6 31
0 81 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc15 loc39
0
3
0 65 6 32
0 81 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 65 6 33
0 81 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc15 loc40
0
3
0 65 6 34
0 81 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc15 loc41
0
3
0 65 6 35
0 81 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 65 6 36
0 81 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 65 6 37
0 81 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 65 6 38
0 81 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 65 6 39
0 81 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 65 6 40
0 81 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 65 7 0
0 75 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 65 7 1
0 76 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 65 7 2
0 77 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 65 7 3
0 78 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 65 7 4
0 79 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 65 7 5
0 80 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 65 7 6
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 65 7 8
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 65 7 9
0 82 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 65 7 10
0 82 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 65 7 11
0 82 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 65 7 12
0 82 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 65 7 13
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 65 7 14
0 82 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 65 7 15
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc16 loc24
0
3
0 65 7 16
0 82 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc16 loc25
0
3
0 65 7 17
0 82 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc16 loc26
0
3
0 65 7 18
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc16 loc27
0
3
0 65 7 19
0 82 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc16 loc28
0
3
0 65 7 20
0 82 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc16 loc29
0
3
0 65 7 21
0 82 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 65 7 22
0 82 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc16 loc30
0
3
0 65 7 23
0 82 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc16 loc31
0
3
0 65 7 24
0 82 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc16 loc32
0
3
0 65 7 25
0 82 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc16 loc33
0
3
0 65 7 26
0 82 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc16 loc34
0
3
0 65 7 27
0 82 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc16 loc35
0
3
0 65 7 28
0 82 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc16 loc36
0
3
0 65 7 29
0 82 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc16 loc37
0
3
0 65 7 30
0 82 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc16 loc38
0
3
0 65 7 31
0 82 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc16 loc39
0
3
0 65 7 32
0 82 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 65 7 33
0 82 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc16 loc40
0
3
0 65 7 34
0 82 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc16 loc41
0
3
0 65 7 35
0 82 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 65 7 36
0 82 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 65 7 37
0 82 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 65 7 38
0 82 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 65 7 39
0 82 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 65 7 40
0 82 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 65 8 0
0 75 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 65 8 1
0 76 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 65 8 2
0 77 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 65 8 3
0 78 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 65 8 4
0 79 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 65 8 5
0 80 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 65 8 6
0 81 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 65 8 7
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 65 8 9
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 65 8 10
0 83 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 65 8 11
0 83 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 65 8 12
0 83 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 65 8 13
0 83 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 65 8 14
0 83 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 65 8 15
0 83 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc17 loc24
0
3
0 65 8 16
0 83 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc17 loc25
0
3
0 65 8 17
0 83 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc17 loc26
0
3
0 65 8 18
0 83 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc17 loc27
0
3
0 65 8 19
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc17 loc28
0
3
0 65 8 20
0 83 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc17 loc29
0
3
0 65 8 21
0 83 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 65 8 22
0 83 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc17 loc30
0
3
0 65 8 23
0 83 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc17 loc31
0
3
0 65 8 24
0 83 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc17 loc32
0
3
0 65 8 25
0 83 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc17 loc33
0
3
0 65 8 26
0 83 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc17 loc34
0
3
0 65 8 27
0 83 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc17 loc35
0
3
0 65 8 28
0 83 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc17 loc36
0
3
0 65 8 29
0 83 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc17 loc37
0
3
0 65 8 30
0 83 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc17 loc38
0
3
0 65 8 31
0 83 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc17 loc39
0
3
0 65 8 32
0 83 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 65 8 33
0 83 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc17 loc40
0
3
0 65 8 34
0 83 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc17 loc41
0
3
0 65 8 35
0 83 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 65 8 36
0 83 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 65 8 37
0 83 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 65 8 38
0 83 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 65 8 39
0 83 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 65 8 40
0 83 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 65 9 0
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 65 9 1
0 76 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 65 9 2
0 77 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 65 9 3
0 78 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 65 9 4
0 79 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 65 9 5
0 80 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 65 9 6
0 81 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 65 9 7
0 82 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 65 9 8
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 65 9 10
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 65 9 11
0 84 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 65 9 12
0 84 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 65 9 13
0 84 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 65 9 14
0 84 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 65 9 15
0 84 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc18 loc24
0
3
0 65 9 16
0 84 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc18 loc25
0
3
0 65 9 17
0 84 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc18 loc26
0
3
0 65 9 18
0 84 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc18 loc27
0
3
0 65 9 19
0 84 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc18 loc28
0
3
0 65 9 20
0 84 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc18 loc29
0
3
0 65 9 21
0 84 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 65 9 22
0 84 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc18 loc30
0
3
0 65 9 23
0 84 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc18 loc31
0
3
0 65 9 24
0 84 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc18 loc32
0
3
0 65 9 25
0 84 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc18 loc33
0
3
0 65 9 26
0 84 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc18 loc34
0
3
0 65 9 27
0 84 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc18 loc35
0
3
0 65 9 28
0 84 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc18 loc36
0
3
0 65 9 29
0 84 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc18 loc37
0
3
0 65 9 30
0 84 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc18 loc38
0
3
0 65 9 31
0 84 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc18 loc39
0
3
0 65 9 32
0 84 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 65 9 33
0 84 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc18 loc40
0
3
0 65 9 34
0 84 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc18 loc41
0
3
0 65 9 35
0 84 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 65 9 36
0 84 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 65 9 37
0 84 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 65 9 38
0 84 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 65 9 39
0 84 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 65 9 40
0 84 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 65 10 0
0 75 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 65 10 1
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 65 10 2
0 77 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 65 10 3
0 78 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 65 10 4
0 79 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 65 10 5
0 80 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 65 10 6
0 81 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 65 10 7
0 82 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 65 10 8
0 83 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 65 10 9
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 65 10 11
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 65 10 12
0 85 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 65 10 13
0 85 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 65 10 14
0 85 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 65 10 15
0 85 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc19 loc24
0
3
0 65 10 16
0 85 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc19 loc25
0
3
0 65 10 17
0 85 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc19 loc26
0
3
0 65 10 18
0 85 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc19 loc27
0
3
0 65 10 19
0 85 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc19 loc28
0
3
0 65 10 20
0 85 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc19 loc29
0
3
0 65 10 21
0 85 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 65 10 22
0 85 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc19 loc30
0
3
0 65 10 23
0 85 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc19 loc31
0
3
0 65 10 24
0 85 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc19 loc32
0
3
0 65 10 25
0 85 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc19 loc33
0
3
0 65 10 26
0 85 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc19 loc34
0
3
0 65 10 27
0 85 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc19 loc35
0
3
0 65 10 28
0 85 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc19 loc36
0
3
0 65 10 29
0 85 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc19 loc37
0
3
0 65 10 30
0 85 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc19 loc38
0
3
0 65 10 31
0 85 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc19 loc39
0
3
0 65 10 32
0 85 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 65 10 33
0 85 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc19 loc40
0
3
0 65 10 34
0 85 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc19 loc41
0
3
0 65 10 35
0 85 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 65 10 36
0 85 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 65 10 37
0 85 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 65 10 38
0 85 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 65 10 39
0 85 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 65 10 40
0 85 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 65 11 0
0 75 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 65 11 1
0 76 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 65 11 2
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 65 11 3
0 78 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 65 11 4
0 79 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 65 11 5
0 80 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 65 11 6
0 81 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 65 11 7
0 82 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 65 11 8
0 83 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 65 11 9
0 84 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 65 11 10
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 65 11 12
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 65 11 13
0 86 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 65 11 14
0 86 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 65 11 15
0 86 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc2 loc24
0
3
0 65 11 16
0 86 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc2 loc25
0
3
0 65 11 17
0 86 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc2 loc26
0
3
0 65 11 18
0 86 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc2 loc27
0
3
0 65 11 19
0 86 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc2 loc28
0
3
0 65 11 20
0 86 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc2 loc29
0
3
0 65 11 21
0 86 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 65 11 22
0 86 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc2 loc30
0
3
0 65 11 23
0 86 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc2 loc31
0
3
0 65 11 24
0 86 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc2 loc32
0
3
0 65 11 25
0 86 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc2 loc33
0
3
0 65 11 26
0 86 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc2 loc34
0
3
0 65 11 27
0 86 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc2 loc35
0
3
0 65 11 28
0 86 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc2 loc36
0
3
0 65 11 29
0 86 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc2 loc37
0
3
0 65 11 30
0 86 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc2 loc38
0
3
0 65 11 31
0 86 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc2 loc39
0
3
0 65 11 32
0 86 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 65 11 33
0 86 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc2 loc40
0
3
0 65 11 34
0 86 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc2 loc41
0
3
0 65 11 35
0 86 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 65 11 36
0 86 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 65 11 37
0 86 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 65 11 38
0 86 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 65 11 39
0 86 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 65 11 40
0 86 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 65 12 0
0 75 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 65 12 1
0 76 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 65 12 2
0 77 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 65 12 3
0 78 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 65 12 4
0 79 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 65 12 5
0 80 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 65 12 6
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 65 12 7
0 82 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 65 12 8
0 83 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 65 12 9
0 84 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 65 12 10
0 85 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 65 12 11
0 86 0 1
0 87 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 65 12 13
0 87 -1 0
0 88 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 65 12 14
0 87 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 65 12 15
0 87 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc20 loc24
0
3
0 65 12 16
0 87 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc20 loc25
0
3
0 65 12 17
0 87 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc20 loc26
0
3
0 65 12 18
0 87 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc20 loc27
0
3
0 65 12 19
0 87 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc20 loc28
0
3
0 65 12 20
0 87 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc20 loc29
0
3
0 65 12 21
0 87 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 65 12 22
0 87 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc20 loc30
0
3
0 65 12 23
0 87 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc20 loc31
0
3
0 65 12 24
0 87 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc20 loc32
0
3
0 65 12 25
0 87 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc20 loc33
0
3
0 65 12 26
0 87 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc20 loc34
0
3
0 65 12 27
0 87 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc20 loc35
0
3
0 65 12 28
0 87 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc20 loc36
0
3
0 65 12 29
0 87 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc20 loc37
0
3
0 65 12 30
0 87 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc20 loc38
0
3
0 65 12 31
0 87 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc20 loc39
0
3
0 65 12 32
0 87 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 65 12 33
0 87 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc20 loc40
0
3
0 65 12 34
0 87 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc20 loc41
0
3
0 65 12 35
0 87 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 65 12 36
0 87 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 65 12 37
0 87 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 65 12 38
0 87 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 65 12 39
0 87 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 65 12 40
0 87 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 65 13 0
0 75 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 65 13 1
0 76 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 65 13 2
0 77 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 65 13 3
0 78 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 65 13 4
0 79 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 65 13 5
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 65 13 6
0 81 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 65 13 7
0 82 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 65 13 8
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 65 13 9
0 84 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 65 13 10
0 85 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 65 13 11
0 86 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 65 13 12
0 87 0 1
0 88 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 65 13 14
0 88 -1 0
0 89 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 65 13 15
0 88 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc21 loc24
0
3
0 65 13 16
0 88 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc21 loc25
0
3
0 65 13 17
0 88 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc21 loc26
0
3
0 65 13 18
0 88 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc21 loc27
0
3
0 65 13 19
0 88 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc21 loc28
0
3
0 65 13 20
0 88 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc21 loc29
0
3
0 65 13 21
0 88 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 65 13 22
0 88 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc21 loc30
0
3
0 65 13 23
0 88 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc21 loc31
0
3
0 65 13 24
0 88 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc21 loc32
0
3
0 65 13 25
0 88 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc21 loc33
0
3
0 65 13 26
0 88 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc21 loc34
0
3
0 65 13 27
0 88 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc21 loc35
0
3
0 65 13 28
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc21 loc36
0
3
0 65 13 29
0 88 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc21 loc37
0
3
0 65 13 30
0 88 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc21 loc38
0
3
0 65 13 31
0 88 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc21 loc39
0
3
0 65 13 32
0 88 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 65 13 33
0 88 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc21 loc40
0
3
0 65 13 34
0 88 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc21 loc41
0
3
0 65 13 35
0 88 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 65 13 36
0 88 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 65 13 37
0 88 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 65 13 38
0 88 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 65 13 39
0 88 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 65 13 40
0 88 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 65 14 0
0 75 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 65 14 1
0 76 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 65 14 2
0 77 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 65 14 3
0 78 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 65 14 4
0 79 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 65 14 5
0 80 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 65 14 6
0 81 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 65 14 7
0 82 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 65 14 8
0 83 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 65 14 9
0 84 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 65 14 10
0 85 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 65 14 11
0 86 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 65 14 12
0 87 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 65 14 13
0 88 0 1
0 89 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 65 14 15
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
sail loc22 loc24
0
3
0 65 14 16
0 89 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc22 loc25
0
3
0 65 14 17
0 89 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc22 loc26
0
3
0 65 14 18
0 89 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc22 loc27
0
3
0 65 14 19
0 89 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc22 loc28
0
3
0 65 14 20
0 89 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc22 loc29
0
3
0 65 14 21
0 89 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 65 14 22
0 89 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc22 loc30
0
3
0 65 14 23
0 89 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc22 loc31
0
3
0 65 14 24
0 89 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc22 loc32
0
3
0 65 14 25
0 89 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc22 loc33
0
3
0 65 14 26
0 89 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc22 loc34
0
3
0 65 14 27
0 89 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc22 loc35
0
3
0 65 14 28
0 89 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc22 loc36
0
3
0 65 14 29
0 89 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc22 loc37
0
3
0 65 14 30
0 89 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc22 loc38
0
3
0 65 14 31
0 89 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc22 loc39
0
3
0 65 14 32
0 89 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 65 14 33
0 89 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc22 loc40
0
3
0 65 14 34
0 89 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc22 loc41
0
3
0 65 14 35
0 89 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 65 14 36
0 89 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 65 14 37
0 89 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 65 14 38
0 89 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 65 14 39
0 89 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 65 14 40
0 89 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 65 15 0
0 75 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 65 15 1
0 76 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 65 15 2
0 77 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 65 15 3
0 78 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 65 15 4
0 79 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 65 15 5
0 80 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 65 15 6
0 81 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 65 15 7
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 65 15 8
0 83 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 65 15 9
0 84 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 65 15 10
0 85 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 65 15 11
0 86 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 65 15 12
0 87 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 65 15 13
0 88 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 65 15 14
0 89 0 1
0 90 -1 0
1
end_operator
begin_operator
sail loc23 loc24
0
3
0 65 15 16
0 90 -1 0
0 91 0 1
1
end_operator
begin_operator
sail loc23 loc25
0
3
0 65 15 17
0 90 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc23 loc26
0
3
0 65 15 18
0 90 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc23 loc27
0
3
0 65 15 19
0 90 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc23 loc28
0
3
0 65 15 20
0 90 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc23 loc29
0
3
0 65 15 21
0 90 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 65 15 22
0 90 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc23 loc30
0
3
0 65 15 23
0 90 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc23 loc31
0
3
0 65 15 24
0 90 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc23 loc32
0
3
0 65 15 25
0 90 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc23 loc33
0
3
0 65 15 26
0 90 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc23 loc34
0
3
0 65 15 27
0 90 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc23 loc35
0
3
0 65 15 28
0 90 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc23 loc36
0
3
0 65 15 29
0 90 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc23 loc37
0
3
0 65 15 30
0 90 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc23 loc38
0
3
0 65 15 31
0 90 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc23 loc39
0
3
0 65 15 32
0 90 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 65 15 33
0 90 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc23 loc40
0
3
0 65 15 34
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc23 loc41
0
3
0 65 15 35
0 90 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 65 15 36
0 90 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 65 15 37
0 90 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 65 15 38
0 90 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 65 15 39
0 90 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 65 15 40
0 90 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc24 loc1
0
3
0 65 16 0
0 75 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc10
0
3
0 65 16 1
0 76 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc11
0
3
0 65 16 2
0 77 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc12
0
3
0 65 16 3
0 78 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc13
0
3
0 65 16 4
0 79 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc14
0
3
0 65 16 5
0 80 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc15
0
3
0 65 16 6
0 81 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc16
0
3
0 65 16 7
0 82 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc17
0
3
0 65 16 8
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc18
0
3
0 65 16 9
0 84 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc19
0
3
0 65 16 10
0 85 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc2
0
3
0 65 16 11
0 86 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc20
0
3
0 65 16 12
0 87 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc21
0
3
0 65 16 13
0 88 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc22
0
3
0 65 16 14
0 89 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc23
0
3
0 65 16 15
0 90 0 1
0 91 -1 0
1
end_operator
begin_operator
sail loc24 loc25
0
3
0 65 16 17
0 91 -1 0
0 92 0 1
1
end_operator
begin_operator
sail loc24 loc26
0
3
0 65 16 18
0 91 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc24 loc27
0
3
0 65 16 19
0 91 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc24 loc28
0
3
0 65 16 20
0 91 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc24 loc29
0
3
0 65 16 21
0 91 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc24 loc3
0
3
0 65 16 22
0 91 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc24 loc30
0
3
0 65 16 23
0 91 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc24 loc31
0
3
0 65 16 24
0 91 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc24 loc32
0
3
0 65 16 25
0 91 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc24 loc33
0
3
0 65 16 26
0 91 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc24 loc34
0
3
0 65 16 27
0 91 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc24 loc35
0
3
0 65 16 28
0 91 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc24 loc36
0
3
0 65 16 29
0 91 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc24 loc37
0
3
0 65 16 30
0 91 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc24 loc38
0
3
0 65 16 31
0 91 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc24 loc39
0
3
0 65 16 32
0 91 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc24 loc4
0
3
0 65 16 33
0 91 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc24 loc40
0
3
0 65 16 34
0 91 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc24 loc41
0
3
0 65 16 35
0 91 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc24 loc5
0
3
0 65 16 36
0 91 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc24 loc6
0
3
0 65 16 37
0 91 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc24 loc7
0
3
0 65 16 38
0 91 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc24 loc8
0
3
0 65 16 39
0 91 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc24 loc9
0
3
0 65 16 40
0 91 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc25 loc1
0
3
0 65 17 0
0 75 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc10
0
3
0 65 17 1
0 76 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc11
0
3
0 65 17 2
0 77 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc12
0
3
0 65 17 3
0 78 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc13
0
3
0 65 17 4
0 79 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc14
0
3
0 65 17 5
0 80 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc15
0
3
0 65 17 6
0 81 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc16
0
3
0 65 17 7
0 82 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc17
0
3
0 65 17 8
0 83 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc18
0
3
0 65 17 9
0 84 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc19
0
3
0 65 17 10
0 85 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc2
0
3
0 65 17 11
0 86 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc20
0
3
0 65 17 12
0 87 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc21
0
3
0 65 17 13
0 88 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc22
0
3
0 65 17 14
0 89 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc23
0
3
0 65 17 15
0 90 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc24
0
3
0 65 17 16
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
sail loc25 loc26
0
3
0 65 17 18
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
sail loc25 loc27
0
3
0 65 17 19
0 92 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc25 loc28
0
3
0 65 17 20
0 92 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc25 loc29
0
3
0 65 17 21
0 92 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc25 loc3
0
3
0 65 17 22
0 92 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc25 loc30
0
3
0 65 17 23
0 92 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc25 loc31
0
3
0 65 17 24
0 92 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc25 loc32
0
3
0 65 17 25
0 92 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc25 loc33
0
3
0 65 17 26
0 92 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc25 loc34
0
3
0 65 17 27
0 92 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc25 loc35
0
3
0 65 17 28
0 92 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc25 loc36
0
3
0 65 17 29
0 92 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc25 loc37
0
3
0 65 17 30
0 92 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc25 loc38
0
3
0 65 17 31
0 92 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc25 loc39
0
3
0 65 17 32
0 92 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc25 loc4
0
3
0 65 17 33
0 92 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc25 loc40
0
3
0 65 17 34
0 92 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc25 loc41
0
3
0 65 17 35
0 92 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc25 loc5
0
3
0 65 17 36
0 92 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc25 loc6
0
3
0 65 17 37
0 92 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc25 loc7
0
3
0 65 17 38
0 92 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc25 loc8
0
3
0 65 17 39
0 92 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc25 loc9
0
3
0 65 17 40
0 92 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc26 loc1
0
3
0 65 18 0
0 75 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc10
0
3
0 65 18 1
0 76 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc11
0
3
0 65 18 2
0 77 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc12
0
3
0 65 18 3
0 78 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc13
0
3
0 65 18 4
0 79 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc14
0
3
0 65 18 5
0 80 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc15
0
3
0 65 18 6
0 81 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc16
0
3
0 65 18 7
0 82 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc17
0
3
0 65 18 8
0 83 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc18
0
3
0 65 18 9
0 84 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc19
0
3
0 65 18 10
0 85 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc2
0
3
0 65 18 11
0 86 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc20
0
3
0 65 18 12
0 87 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc21
0
3
0 65 18 13
0 88 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc22
0
3
0 65 18 14
0 89 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc23
0
3
0 65 18 15
0 90 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc24
0
3
0 65 18 16
0 91 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc25
0
3
0 65 18 17
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
sail loc26 loc27
0
3
0 65 18 19
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
sail loc26 loc28
0
3
0 65 18 20
0 93 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc26 loc29
0
3
0 65 18 21
0 93 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc26 loc3
0
3
0 65 18 22
0 93 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc26 loc30
0
3
0 65 18 23
0 93 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc26 loc31
0
3
0 65 18 24
0 93 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc26 loc32
0
3
0 65 18 25
0 93 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc26 loc33
0
3
0 65 18 26
0 93 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc26 loc34
0
3
0 65 18 27
0 93 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc26 loc35
0
3
0 65 18 28
0 93 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc26 loc36
0
3
0 65 18 29
0 93 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc26 loc37
0
3
0 65 18 30
0 93 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc26 loc38
0
3
0 65 18 31
0 93 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc26 loc39
0
3
0 65 18 32
0 93 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc26 loc4
0
3
0 65 18 33
0 93 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc26 loc40
0
3
0 65 18 34
0 93 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc26 loc41
0
3
0 65 18 35
0 93 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc26 loc5
0
3
0 65 18 36
0 93 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc26 loc6
0
3
0 65 18 37
0 93 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc26 loc7
0
3
0 65 18 38
0 93 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc26 loc8
0
3
0 65 18 39
0 93 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc26 loc9
0
3
0 65 18 40
0 93 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc27 loc1
0
3
0 65 19 0
0 75 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc10
0
3
0 65 19 1
0 76 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc11
0
3
0 65 19 2
0 77 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc12
0
3
0 65 19 3
0 78 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc13
0
3
0 65 19 4
0 79 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc14
0
3
0 65 19 5
0 80 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc15
0
3
0 65 19 6
0 81 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc16
0
3
0 65 19 7
0 82 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc17
0
3
0 65 19 8
0 83 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc18
0
3
0 65 19 9
0 84 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc19
0
3
0 65 19 10
0 85 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc2
0
3
0 65 19 11
0 86 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc20
0
3
0 65 19 12
0 87 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc21
0
3
0 65 19 13
0 88 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc22
0
3
0 65 19 14
0 89 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc23
0
3
0 65 19 15
0 90 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc24
0
3
0 65 19 16
0 91 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc25
0
3
0 65 19 17
0 92 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc26
0
3
0 65 19 18
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
sail loc27 loc28
0
3
0 65 19 20
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
sail loc27 loc29
0
3
0 65 19 21
0 94 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc27 loc3
0
3
0 65 19 22
0 94 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc27 loc30
0
3
0 65 19 23
0 94 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc27 loc31
0
3
0 65 19 24
0 94 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc27 loc32
0
3
0 65 19 25
0 94 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc27 loc33
0
3
0 65 19 26
0 94 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc27 loc34
0
3
0 65 19 27
0 94 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc27 loc35
0
3
0 65 19 28
0 94 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc27 loc36
0
3
0 65 19 29
0 94 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc27 loc37
0
3
0 65 19 30
0 94 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc27 loc38
0
3
0 65 19 31
0 94 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc27 loc39
0
3
0 65 19 32
0 94 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc27 loc4
0
3
0 65 19 33
0 94 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc27 loc40
0
3
0 65 19 34
0 94 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc27 loc41
0
3
0 65 19 35
0 94 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc27 loc5
0
3
0 65 19 36
0 94 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc27 loc6
0
3
0 65 19 37
0 94 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc27 loc7
0
3
0 65 19 38
0 94 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc27 loc8
0
3
0 65 19 39
0 94 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc27 loc9
0
3
0 65 19 40
0 94 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc28 loc1
0
3
0 65 20 0
0 75 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc10
0
3
0 65 20 1
0 76 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc11
0
3
0 65 20 2
0 77 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc12
0
3
0 65 20 3
0 78 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc13
0
3
0 65 20 4
0 79 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc14
0
3
0 65 20 5
0 80 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc15
0
3
0 65 20 6
0 81 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc16
0
3
0 65 20 7
0 82 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc17
0
3
0 65 20 8
0 83 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc18
0
3
0 65 20 9
0 84 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc19
0
3
0 65 20 10
0 85 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc2
0
3
0 65 20 11
0 86 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc20
0
3
0 65 20 12
0 87 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc21
0
3
0 65 20 13
0 88 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc22
0
3
0 65 20 14
0 89 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc23
0
3
0 65 20 15
0 90 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc24
0
3
0 65 20 16
0 91 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc25
0
3
0 65 20 17
0 92 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc26
0
3
0 65 20 18
0 93 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc27
0
3
0 65 20 19
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
sail loc28 loc29
0
3
0 65 20 21
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
sail loc28 loc3
0
3
0 65 20 22
0 95 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc28 loc30
0
3
0 65 20 23
0 95 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc28 loc31
0
3
0 65 20 24
0 95 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc28 loc32
0
3
0 65 20 25
0 95 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc28 loc33
0
3
0 65 20 26
0 95 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc28 loc34
0
3
0 65 20 27
0 95 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc28 loc35
0
3
0 65 20 28
0 95 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc28 loc36
0
3
0 65 20 29
0 95 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc28 loc37
0
3
0 65 20 30
0 95 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc28 loc38
0
3
0 65 20 31
0 95 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc28 loc39
0
3
0 65 20 32
0 95 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc28 loc4
0
3
0 65 20 33
0 95 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc28 loc40
0
3
0 65 20 34
0 95 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc28 loc41
0
3
0 65 20 35
0 95 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc28 loc5
0
3
0 65 20 36
0 95 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc28 loc6
0
3
0 65 20 37
0 95 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc28 loc7
0
3
0 65 20 38
0 95 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc28 loc8
0
3
0 65 20 39
0 95 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc28 loc9
0
3
0 65 20 40
0 95 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc29 loc1
0
3
0 65 21 0
0 75 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc10
0
3
0 65 21 1
0 76 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc11
0
3
0 65 21 2
0 77 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc12
0
3
0 65 21 3
0 78 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc13
0
3
0 65 21 4
0 79 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc14
0
3
0 65 21 5
0 80 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc15
0
3
0 65 21 6
0 81 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc16
0
3
0 65 21 7
0 82 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc17
0
3
0 65 21 8
0 83 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc18
0
3
0 65 21 9
0 84 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc19
0
3
0 65 21 10
0 85 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc2
0
3
0 65 21 11
0 86 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc20
0
3
0 65 21 12
0 87 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc21
0
3
0 65 21 13
0 88 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc22
0
3
0 65 21 14
0 89 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc23
0
3
0 65 21 15
0 90 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc24
0
3
0 65 21 16
0 91 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc25
0
3
0 65 21 17
0 92 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc26
0
3
0 65 21 18
0 93 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc27
0
3
0 65 21 19
0 94 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc28
0
3
0 65 21 20
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
sail loc29 loc3
0
3
0 65 21 22
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
sail loc29 loc30
0
3
0 65 21 23
0 96 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc29 loc31
0
3
0 65 21 24
0 96 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc29 loc32
0
3
0 65 21 25
0 96 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc29 loc33
0
3
0 65 21 26
0 96 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc29 loc34
0
3
0 65 21 27
0 96 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc29 loc35
0
3
0 65 21 28
0 96 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc29 loc36
0
3
0 65 21 29
0 96 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc29 loc37
0
3
0 65 21 30
0 96 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc29 loc38
0
3
0 65 21 31
0 96 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc29 loc39
0
3
0 65 21 32
0 96 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc29 loc4
0
3
0 65 21 33
0 96 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc29 loc40
0
3
0 65 21 34
0 96 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc29 loc41
0
3
0 65 21 35
0 96 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc29 loc5
0
3
0 65 21 36
0 96 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc29 loc6
0
3
0 65 21 37
0 96 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc29 loc7
0
3
0 65 21 38
0 96 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc29 loc8
0
3
0 65 21 39
0 96 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc29 loc9
0
3
0 65 21 40
0 96 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 65 22 0
0 75 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 65 22 1
0 76 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 65 22 2
0 77 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 65 22 3
0 78 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 65 22 4
0 79 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 65 22 5
0 80 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 65 22 6
0 81 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 65 22 7
0 82 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 65 22 8
0 83 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 65 22 9
0 84 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 65 22 10
0 85 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 65 22 11
0 86 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 65 22 12
0 87 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 65 22 13
0 88 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 65 22 14
0 89 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 65 22 15
0 90 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc24
0
3
0 65 22 16
0 91 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc25
0
3
0 65 22 17
0 92 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc26
0
3
0 65 22 18
0 93 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc27
0
3
0 65 22 19
0 94 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc28
0
3
0 65 22 20
0 95 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc29
0
3
0 65 22 21
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
sail loc3 loc30
0
3
0 65 22 23
0 97 -1 0
0 98 0 1
1
end_operator
begin_operator
sail loc3 loc31
0
3
0 65 22 24
0 97 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc3 loc32
0
3
0 65 22 25
0 97 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc3 loc33
0
3
0 65 22 26
0 97 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc3 loc34
0
3
0 65 22 27
0 97 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc3 loc35
0
3
0 65 22 28
0 97 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc3 loc36
0
3
0 65 22 29
0 97 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc3 loc37
0
3
0 65 22 30
0 97 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc3 loc38
0
3
0 65 22 31
0 97 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc3 loc39
0
3
0 65 22 32
0 97 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 65 22 33
0 97 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc3 loc40
0
3
0 65 22 34
0 97 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc3 loc41
0
3
0 65 22 35
0 97 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 65 22 36
0 97 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 65 22 37
0 97 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 65 22 38
0 97 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 65 22 39
0 97 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 65 22 40
0 97 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc30 loc1
0
3
0 65 23 0
0 75 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc10
0
3
0 65 23 1
0 76 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc11
0
3
0 65 23 2
0 77 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc12
0
3
0 65 23 3
0 78 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc13
0
3
0 65 23 4
0 79 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc14
0
3
0 65 23 5
0 80 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc15
0
3
0 65 23 6
0 81 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc16
0
3
0 65 23 7
0 82 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc17
0
3
0 65 23 8
0 83 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc18
0
3
0 65 23 9
0 84 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc19
0
3
0 65 23 10
0 85 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc2
0
3
0 65 23 11
0 86 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc20
0
3
0 65 23 12
0 87 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc21
0
3
0 65 23 13
0 88 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc22
0
3
0 65 23 14
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc23
0
3
0 65 23 15
0 90 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc24
0
3
0 65 23 16
0 91 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc25
0
3
0 65 23 17
0 92 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc26
0
3
0 65 23 18
0 93 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc27
0
3
0 65 23 19
0 94 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc28
0
3
0 65 23 20
0 95 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc29
0
3
0 65 23 21
0 96 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc3
0
3
0 65 23 22
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
sail loc30 loc31
0
3
0 65 23 24
0 98 -1 0
0 99 0 1
1
end_operator
begin_operator
sail loc30 loc32
0
3
0 65 23 25
0 98 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc30 loc33
0
3
0 65 23 26
0 98 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc30 loc34
0
3
0 65 23 27
0 98 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc30 loc35
0
3
0 65 23 28
0 98 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc30 loc36
0
3
0 65 23 29
0 98 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc30 loc37
0
3
0 65 23 30
0 98 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc30 loc38
0
3
0 65 23 31
0 98 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc30 loc39
0
3
0 65 23 32
0 98 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc30 loc4
0
3
0 65 23 33
0 98 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc30 loc40
0
3
0 65 23 34
0 98 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc30 loc41
0
3
0 65 23 35
0 98 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc30 loc5
0
3
0 65 23 36
0 98 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc30 loc6
0
3
0 65 23 37
0 98 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc30 loc7
0
3
0 65 23 38
0 98 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc30 loc8
0
3
0 65 23 39
0 98 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc30 loc9
0
3
0 65 23 40
0 98 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc31 loc1
0
3
0 65 24 0
0 75 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc10
0
3
0 65 24 1
0 76 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc11
0
3
0 65 24 2
0 77 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc12
0
3
0 65 24 3
0 78 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc13
0
3
0 65 24 4
0 79 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc14
0
3
0 65 24 5
0 80 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc15
0
3
0 65 24 6
0 81 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc16
0
3
0 65 24 7
0 82 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc17
0
3
0 65 24 8
0 83 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc18
0
3
0 65 24 9
0 84 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc19
0
3
0 65 24 10
0 85 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc2
0
3
0 65 24 11
0 86 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc20
0
3
0 65 24 12
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc21
0
3
0 65 24 13
0 88 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc22
0
3
0 65 24 14
0 89 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc23
0
3
0 65 24 15
0 90 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc24
0
3
0 65 24 16
0 91 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc25
0
3
0 65 24 17
0 92 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc26
0
3
0 65 24 18
0 93 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc27
0
3
0 65 24 19
0 94 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc28
0
3
0 65 24 20
0 95 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc29
0
3
0 65 24 21
0 96 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc3
0
3
0 65 24 22
0 97 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc30
0
3
0 65 24 23
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
sail loc31 loc32
0
3
0 65 24 25
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
sail loc31 loc33
0
3
0 65 24 26
0 99 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc31 loc34
0
3
0 65 24 27
0 99 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc31 loc35
0
3
0 65 24 28
0 99 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc31 loc36
0
3
0 65 24 29
0 99 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc31 loc37
0
3
0 65 24 30
0 99 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc31 loc38
0
3
0 65 24 31
0 99 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc31 loc39
0
3
0 65 24 32
0 99 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc31 loc4
0
3
0 65 24 33
0 99 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc31 loc40
0
3
0 65 24 34
0 99 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc31 loc41
0
3
0 65 24 35
0 99 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc31 loc5
0
3
0 65 24 36
0 99 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc31 loc6
0
3
0 65 24 37
0 99 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc31 loc7
0
3
0 65 24 38
0 99 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc31 loc8
0
3
0 65 24 39
0 99 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc31 loc9
0
3
0 65 24 40
0 99 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc32 loc1
0
3
0 65 25 0
0 75 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc10
0
3
0 65 25 1
0 76 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc11
0
3
0 65 25 2
0 77 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc12
0
3
0 65 25 3
0 78 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc13
0
3
0 65 25 4
0 79 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc14
0
3
0 65 25 5
0 80 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc15
0
3
0 65 25 6
0 81 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc16
0
3
0 65 25 7
0 82 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc17
0
3
0 65 25 8
0 83 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc18
0
3
0 65 25 9
0 84 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc19
0
3
0 65 25 10
0 85 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc2
0
3
0 65 25 11
0 86 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc20
0
3
0 65 25 12
0 87 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc21
0
3
0 65 25 13
0 88 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc22
0
3
0 65 25 14
0 89 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc23
0
3
0 65 25 15
0 90 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc24
0
3
0 65 25 16
0 91 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc25
0
3
0 65 25 17
0 92 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc26
0
3
0 65 25 18
0 93 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc27
0
3
0 65 25 19
0 94 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc28
0
3
0 65 25 20
0 95 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc29
0
3
0 65 25 21
0 96 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc3
0
3
0 65 25 22
0 97 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc30
0
3
0 65 25 23
0 98 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc31
0
3
0 65 25 24
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
sail loc32 loc33
0
3
0 65 25 26
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
sail loc32 loc34
0
3
0 65 25 27
0 100 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc32 loc35
0
3
0 65 25 28
0 100 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc32 loc36
0
3
0 65 25 29
0 100 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc32 loc37
0
3
0 65 25 30
0 100 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc32 loc38
0
3
0 65 25 31
0 100 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc32 loc39
0
3
0 65 25 32
0 100 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc32 loc4
0
3
0 65 25 33
0 100 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc32 loc40
0
3
0 65 25 34
0 100 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc32 loc41
0
3
0 65 25 35
0 100 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc32 loc5
0
3
0 65 25 36
0 100 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc32 loc6
0
3
0 65 25 37
0 100 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc32 loc7
0
3
0 65 25 38
0 100 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc32 loc8
0
3
0 65 25 39
0 100 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc32 loc9
0
3
0 65 25 40
0 100 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc33 loc1
0
3
0 65 26 0
0 75 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc10
0
3
0 65 26 1
0 76 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc11
0
3
0 65 26 2
0 77 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc12
0
3
0 65 26 3
0 78 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc13
0
3
0 65 26 4
0 79 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc14
0
3
0 65 26 5
0 80 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc15
0
3
0 65 26 6
0 81 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc16
0
3
0 65 26 7
0 82 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc17
0
3
0 65 26 8
0 83 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc18
0
3
0 65 26 9
0 84 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc19
0
3
0 65 26 10
0 85 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc2
0
3
0 65 26 11
0 86 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc20
0
3
0 65 26 12
0 87 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc21
0
3
0 65 26 13
0 88 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc22
0
3
0 65 26 14
0 89 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc23
0
3
0 65 26 15
0 90 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc24
0
3
0 65 26 16
0 91 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc25
0
3
0 65 26 17
0 92 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc26
0
3
0 65 26 18
0 93 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc27
0
3
0 65 26 19
0 94 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc28
0
3
0 65 26 20
0 95 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc29
0
3
0 65 26 21
0 96 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc3
0
3
0 65 26 22
0 97 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc30
0
3
0 65 26 23
0 98 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc31
0
3
0 65 26 24
0 99 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc32
0
3
0 65 26 25
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
sail loc33 loc34
0
3
0 65 26 27
0 101 -1 0
0 102 0 1
1
end_operator
begin_operator
sail loc33 loc35
0
3
0 65 26 28
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc33 loc36
0
3
0 65 26 29
0 101 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc33 loc37
0
3
0 65 26 30
0 101 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc33 loc38
0
3
0 65 26 31
0 101 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc33 loc39
0
3
0 65 26 32
0 101 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc33 loc4
0
3
0 65 26 33
0 101 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc33 loc40
0
3
0 65 26 34
0 101 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc33 loc41
0
3
0 65 26 35
0 101 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc33 loc5
0
3
0 65 26 36
0 101 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc33 loc6
0
3
0 65 26 37
0 101 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc33 loc7
0
3
0 65 26 38
0 101 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc33 loc8
0
3
0 65 26 39
0 101 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc33 loc9
0
3
0 65 26 40
0 101 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc34 loc1
0
3
0 65 27 0
0 75 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc10
0
3
0 65 27 1
0 76 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc11
0
3
0 65 27 2
0 77 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc12
0
3
0 65 27 3
0 78 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc13
0
3
0 65 27 4
0 79 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc14
0
3
0 65 27 5
0 80 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc15
0
3
0 65 27 6
0 81 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc16
0
3
0 65 27 7
0 82 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc17
0
3
0 65 27 8
0 83 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc18
0
3
0 65 27 9
0 84 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc19
0
3
0 65 27 10
0 85 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc2
0
3
0 65 27 11
0 86 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc20
0
3
0 65 27 12
0 87 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc21
0
3
0 65 27 13
0 88 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc22
0
3
0 65 27 14
0 89 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc23
0
3
0 65 27 15
0 90 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc24
0
3
0 65 27 16
0 91 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc25
0
3
0 65 27 17
0 92 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc26
0
3
0 65 27 18
0 93 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc27
0
3
0 65 27 19
0 94 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc28
0
3
0 65 27 20
0 95 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc29
0
3
0 65 27 21
0 96 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc3
0
3
0 65 27 22
0 97 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc30
0
3
0 65 27 23
0 98 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc31
0
3
0 65 27 24
0 99 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc32
0
3
0 65 27 25
0 100 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc33
0
3
0 65 27 26
0 101 0 1
0 102 -1 0
1
end_operator
begin_operator
sail loc34 loc35
0
3
0 65 27 28
0 102 -1 0
0 103 0 1
1
end_operator
begin_operator
sail loc34 loc36
0
3
0 65 27 29
0 102 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc34 loc37
0
3
0 65 27 30
0 102 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc34 loc38
0
3
0 65 27 31
0 102 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc34 loc39
0
3
0 65 27 32
0 102 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc34 loc4
0
3
0 65 27 33
0 102 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc34 loc40
0
3
0 65 27 34
0 102 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc34 loc41
0
3
0 65 27 35
0 102 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc34 loc5
0
3
0 65 27 36
0 102 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc34 loc6
0
3
0 65 27 37
0 102 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc34 loc7
0
3
0 65 27 38
0 102 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc34 loc8
0
3
0 65 27 39
0 102 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc34 loc9
0
3
0 65 27 40
0 102 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc35 loc1
0
3
0 65 28 0
0 75 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc10
0
3
0 65 28 1
0 76 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc11
0
3
0 65 28 2
0 77 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc12
0
3
0 65 28 3
0 78 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc13
0
3
0 65 28 4
0 79 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc14
0
3
0 65 28 5
0 80 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc15
0
3
0 65 28 6
0 81 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc16
0
3
0 65 28 7
0 82 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc17
0
3
0 65 28 8
0 83 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc18
0
3
0 65 28 9
0 84 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc19
0
3
0 65 28 10
0 85 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc2
0
3
0 65 28 11
0 86 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc20
0
3
0 65 28 12
0 87 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc21
0
3
0 65 28 13
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc22
0
3
0 65 28 14
0 89 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc23
0
3
0 65 28 15
0 90 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc24
0
3
0 65 28 16
0 91 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc25
0
3
0 65 28 17
0 92 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc26
0
3
0 65 28 18
0 93 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc27
0
3
0 65 28 19
0 94 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc28
0
3
0 65 28 20
0 95 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc29
0
3
0 65 28 21
0 96 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc3
0
3
0 65 28 22
0 97 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc30
0
3
0 65 28 23
0 98 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc31
0
3
0 65 28 24
0 99 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc32
0
3
0 65 28 25
0 100 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc33
0
3
0 65 28 26
0 101 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc34
0
3
0 65 28 27
0 102 0 1
0 103 -1 0
1
end_operator
begin_operator
sail loc35 loc36
0
3
0 65 28 29
0 103 -1 0
0 104 0 1
1
end_operator
begin_operator
sail loc35 loc37
0
3
0 65 28 30
0 103 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc35 loc38
0
3
0 65 28 31
0 103 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc35 loc39
0
3
0 65 28 32
0 103 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc35 loc4
0
3
0 65 28 33
0 103 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc35 loc40
0
3
0 65 28 34
0 103 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc35 loc41
0
3
0 65 28 35
0 103 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc35 loc5
0
3
0 65 28 36
0 103 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc35 loc6
0
3
0 65 28 37
0 103 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc35 loc7
0
3
0 65 28 38
0 103 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc35 loc8
0
3
0 65 28 39
0 103 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc35 loc9
0
3
0 65 28 40
0 103 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc36 loc1
0
3
0 65 29 0
0 75 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc10
0
3
0 65 29 1
0 76 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc11
0
3
0 65 29 2
0 77 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc12
0
3
0 65 29 3
0 78 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc13
0
3
0 65 29 4
0 79 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc14
0
3
0 65 29 5
0 80 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc15
0
3
0 65 29 6
0 81 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc16
0
3
0 65 29 7
0 82 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc17
0
3
0 65 29 8
0 83 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc18
0
3
0 65 29 9
0 84 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc19
0
3
0 65 29 10
0 85 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc2
0
3
0 65 29 11
0 86 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc20
0
3
0 65 29 12
0 87 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc21
0
3
0 65 29 13
0 88 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc22
0
3
0 65 29 14
0 89 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc23
0
3
0 65 29 15
0 90 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc24
0
3
0 65 29 16
0 91 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc25
0
3
0 65 29 17
0 92 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc26
0
3
0 65 29 18
0 93 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc27
0
3
0 65 29 19
0 94 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc28
0
3
0 65 29 20
0 95 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc29
0
3
0 65 29 21
0 96 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc3
0
3
0 65 29 22
0 97 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc30
0
3
0 65 29 23
0 98 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc31
0
3
0 65 29 24
0 99 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc32
0
3
0 65 29 25
0 100 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc33
0
3
0 65 29 26
0 101 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc34
0
3
0 65 29 27
0 102 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc35
0
3
0 65 29 28
0 103 0 1
0 104 -1 0
1
end_operator
begin_operator
sail loc36 loc37
0
3
0 65 29 30
0 104 -1 0
0 105 0 1
1
end_operator
begin_operator
sail loc36 loc38
0
3
0 65 29 31
0 104 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc36 loc39
0
3
0 65 29 32
0 104 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc36 loc4
0
3
0 65 29 33
0 104 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc36 loc40
0
3
0 65 29 34
0 104 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc36 loc41
0
3
0 65 29 35
0 104 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc36 loc5
0
3
0 65 29 36
0 104 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc36 loc6
0
3
0 65 29 37
0 104 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc36 loc7
0
3
0 65 29 38
0 104 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc36 loc8
0
3
0 65 29 39
0 104 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc36 loc9
0
3
0 65 29 40
0 104 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc37 loc1
0
3
0 65 30 0
0 75 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc10
0
3
0 65 30 1
0 76 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc11
0
3
0 65 30 2
0 77 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc12
0
3
0 65 30 3
0 78 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc13
0
3
0 65 30 4
0 79 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc14
0
3
0 65 30 5
0 80 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc15
0
3
0 65 30 6
0 81 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc16
0
3
0 65 30 7
0 82 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc17
0
3
0 65 30 8
0 83 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc18
0
3
0 65 30 9
0 84 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc19
0
3
0 65 30 10
0 85 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc2
0
3
0 65 30 11
0 86 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc20
0
3
0 65 30 12
0 87 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc21
0
3
0 65 30 13
0 88 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc22
0
3
0 65 30 14
0 89 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc23
0
3
0 65 30 15
0 90 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc24
0
3
0 65 30 16
0 91 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc25
0
3
0 65 30 17
0 92 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc26
0
3
0 65 30 18
0 93 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc27
0
3
0 65 30 19
0 94 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc28
0
3
0 65 30 20
0 95 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc29
0
3
0 65 30 21
0 96 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc3
0
3
0 65 30 22
0 97 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc30
0
3
0 65 30 23
0 98 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc31
0
3
0 65 30 24
0 99 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc32
0
3
0 65 30 25
0 100 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc33
0
3
0 65 30 26
0 101 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc34
0
3
0 65 30 27
0 102 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc35
0
3
0 65 30 28
0 103 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc36
0
3
0 65 30 29
0 104 0 1
0 105 -1 0
1
end_operator
begin_operator
sail loc37 loc38
0
3
0 65 30 31
0 105 -1 0
0 106 0 1
1
end_operator
begin_operator
sail loc37 loc39
0
3
0 65 30 32
0 105 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc37 loc4
0
3
0 65 30 33
0 105 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc37 loc40
0
3
0 65 30 34
0 105 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc37 loc41
0
3
0 65 30 35
0 105 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc37 loc5
0
3
0 65 30 36
0 105 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc37 loc6
0
3
0 65 30 37
0 105 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc37 loc7
0
3
0 65 30 38
0 105 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc37 loc8
0
3
0 65 30 39
0 105 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc37 loc9
0
3
0 65 30 40
0 105 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc38 loc1
0
3
0 65 31 0
0 75 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc10
0
3
0 65 31 1
0 76 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc11
0
3
0 65 31 2
0 77 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc12
0
3
0 65 31 3
0 78 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc13
0
3
0 65 31 4
0 79 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc14
0
3
0 65 31 5
0 80 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc15
0
3
0 65 31 6
0 81 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc16
0
3
0 65 31 7
0 82 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc17
0
3
0 65 31 8
0 83 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc18
0
3
0 65 31 9
0 84 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc19
0
3
0 65 31 10
0 85 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc2
0
3
0 65 31 11
0 86 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc20
0
3
0 65 31 12
0 87 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc21
0
3
0 65 31 13
0 88 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc22
0
3
0 65 31 14
0 89 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc23
0
3
0 65 31 15
0 90 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc24
0
3
0 65 31 16
0 91 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc25
0
3
0 65 31 17
0 92 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc26
0
3
0 65 31 18
0 93 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc27
0
3
0 65 31 19
0 94 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc28
0
3
0 65 31 20
0 95 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc29
0
3
0 65 31 21
0 96 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc3
0
3
0 65 31 22
0 97 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc30
0
3
0 65 31 23
0 98 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc31
0
3
0 65 31 24
0 99 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc32
0
3
0 65 31 25
0 100 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc33
0
3
0 65 31 26
0 101 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc34
0
3
0 65 31 27
0 102 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc35
0
3
0 65 31 28
0 103 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc36
0
3
0 65 31 29
0 104 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc37
0
3
0 65 31 30
0 105 0 1
0 106 -1 0
1
end_operator
begin_operator
sail loc38 loc39
0
3
0 65 31 32
0 106 -1 0
0 107 0 1
1
end_operator
begin_operator
sail loc38 loc4
0
3
0 65 31 33
0 106 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc38 loc40
0
3
0 65 31 34
0 106 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc38 loc41
0
3
0 65 31 35
0 106 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc38 loc5
0
3
0 65 31 36
0 106 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc38 loc6
0
3
0 65 31 37
0 106 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc38 loc7
0
3
0 65 31 38
0 106 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc38 loc8
0
3
0 65 31 39
0 106 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc38 loc9
0
3
0 65 31 40
0 106 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc39 loc1
0
3
0 65 32 0
0 75 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc10
0
3
0 65 32 1
0 76 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc11
0
3
0 65 32 2
0 77 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc12
0
3
0 65 32 3
0 78 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc13
0
3
0 65 32 4
0 79 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc14
0
3
0 65 32 5
0 80 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc15
0
3
0 65 32 6
0 81 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc16
0
3
0 65 32 7
0 82 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc17
0
3
0 65 32 8
0 83 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc18
0
3
0 65 32 9
0 84 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc19
0
3
0 65 32 10
0 85 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc2
0
3
0 65 32 11
0 86 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc20
0
3
0 65 32 12
0 87 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc21
0
3
0 65 32 13
0 88 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc22
0
3
0 65 32 14
0 89 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc23
0
3
0 65 32 15
0 90 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc24
0
3
0 65 32 16
0 91 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc25
0
3
0 65 32 17
0 92 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc26
0
3
0 65 32 18
0 93 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc27
0
3
0 65 32 19
0 94 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc28
0
3
0 65 32 20
0 95 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc29
0
3
0 65 32 21
0 96 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc3
0
3
0 65 32 22
0 97 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc30
0
3
0 65 32 23
0 98 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc31
0
3
0 65 32 24
0 99 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc32
0
3
0 65 32 25
0 100 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc33
0
3
0 65 32 26
0 101 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc34
0
3
0 65 32 27
0 102 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc35
0
3
0 65 32 28
0 103 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc36
0
3
0 65 32 29
0 104 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc37
0
3
0 65 32 30
0 105 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc38
0
3
0 65 32 31
0 106 0 1
0 107 -1 0
1
end_operator
begin_operator
sail loc39 loc4
0
3
0 65 32 33
0 107 -1 0
0 108 0 1
1
end_operator
begin_operator
sail loc39 loc40
0
3
0 65 32 34
0 107 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc39 loc41
0
3
0 65 32 35
0 107 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc39 loc5
0
3
0 65 32 36
0 107 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc39 loc6
0
3
0 65 32 37
0 107 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc39 loc7
0
3
0 65 32 38
0 107 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc39 loc8
0
3
0 65 32 39
0 107 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc39 loc9
0
3
0 65 32 40
0 107 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 65 33 0
0 75 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 65 33 1
0 76 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 65 33 2
0 77 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 65 33 3
0 78 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 65 33 4
0 79 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 65 33 5
0 80 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 65 33 6
0 81 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 65 33 7
0 82 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 65 33 8
0 83 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 65 33 9
0 84 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 65 33 10
0 85 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 65 33 11
0 86 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 65 33 12
0 87 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 65 33 13
0 88 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 65 33 14
0 89 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 65 33 15
0 90 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc24
0
3
0 65 33 16
0 91 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc25
0
3
0 65 33 17
0 92 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc26
0
3
0 65 33 18
0 93 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc27
0
3
0 65 33 19
0 94 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc28
0
3
0 65 33 20
0 95 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc29
0
3
0 65 33 21
0 96 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 65 33 22
0 97 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc30
0
3
0 65 33 23
0 98 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc31
0
3
0 65 33 24
0 99 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc32
0
3
0 65 33 25
0 100 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc33
0
3
0 65 33 26
0 101 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc34
0
3
0 65 33 27
0 102 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc35
0
3
0 65 33 28
0 103 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc36
0
3
0 65 33 29
0 104 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc37
0
3
0 65 33 30
0 105 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc38
0
3
0 65 33 31
0 106 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc39
0
3
0 65 33 32
0 107 0 1
0 108 -1 0
1
end_operator
begin_operator
sail loc4 loc40
0
3
0 65 33 34
0 108 -1 0
0 109 0 1
1
end_operator
begin_operator
sail loc4 loc41
0
3
0 65 33 35
0 108 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 65 33 36
0 108 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 65 33 37
0 108 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 65 33 38
0 108 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 65 33 39
0 108 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 65 33 40
0 108 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc40 loc1
0
3
0 65 34 0
0 75 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc10
0
3
0 65 34 1
0 76 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc11
0
3
0 65 34 2
0 77 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc12
0
3
0 65 34 3
0 78 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc13
0
3
0 65 34 4
0 79 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc14
0
3
0 65 34 5
0 80 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc15
0
3
0 65 34 6
0 81 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc16
0
3
0 65 34 7
0 82 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc17
0
3
0 65 34 8
0 83 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc18
0
3
0 65 34 9
0 84 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc19
0
3
0 65 34 10
0 85 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc2
0
3
0 65 34 11
0 86 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc20
0
3
0 65 34 12
0 87 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc21
0
3
0 65 34 13
0 88 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc22
0
3
0 65 34 14
0 89 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc23
0
3
0 65 34 15
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc24
0
3
0 65 34 16
0 91 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc25
0
3
0 65 34 17
0 92 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc26
0
3
0 65 34 18
0 93 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc27
0
3
0 65 34 19
0 94 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc28
0
3
0 65 34 20
0 95 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc29
0
3
0 65 34 21
0 96 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc3
0
3
0 65 34 22
0 97 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc30
0
3
0 65 34 23
0 98 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc31
0
3
0 65 34 24
0 99 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc32
0
3
0 65 34 25
0 100 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc33
0
3
0 65 34 26
0 101 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc34
0
3
0 65 34 27
0 102 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc35
0
3
0 65 34 28
0 103 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc36
0
3
0 65 34 29
0 104 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc37
0
3
0 65 34 30
0 105 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc38
0
3
0 65 34 31
0 106 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc39
0
3
0 65 34 32
0 107 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc4
0
3
0 65 34 33
0 108 0 1
0 109 -1 0
1
end_operator
begin_operator
sail loc40 loc41
0
3
0 65 34 35
0 109 -1 0
0 110 0 1
1
end_operator
begin_operator
sail loc40 loc5
0
3
0 65 34 36
0 109 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc40 loc6
0
3
0 65 34 37
0 109 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc40 loc7
0
3
0 65 34 38
0 109 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc40 loc8
0
3
0 65 34 39
0 109 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc40 loc9
0
3
0 65 34 40
0 109 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc41 loc1
0
3
0 65 35 0
0 75 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc10
0
3
0 65 35 1
0 76 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc11
0
3
0 65 35 2
0 77 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc12
0
3
0 65 35 3
0 78 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc13
0
3
0 65 35 4
0 79 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc14
0
3
0 65 35 5
0 80 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc15
0
3
0 65 35 6
0 81 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc16
0
3
0 65 35 7
0 82 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc17
0
3
0 65 35 8
0 83 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc18
0
3
0 65 35 9
0 84 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc19
0
3
0 65 35 10
0 85 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc2
0
3
0 65 35 11
0 86 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc20
0
3
0 65 35 12
0 87 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc21
0
3
0 65 35 13
0 88 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc22
0
3
0 65 35 14
0 89 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc23
0
3
0 65 35 15
0 90 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc24
0
3
0 65 35 16
0 91 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc25
0
3
0 65 35 17
0 92 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc26
0
3
0 65 35 18
0 93 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc27
0
3
0 65 35 19
0 94 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc28
0
3
0 65 35 20
0 95 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc29
0
3
0 65 35 21
0 96 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc3
0
3
0 65 35 22
0 97 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc30
0
3
0 65 35 23
0 98 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc31
0
3
0 65 35 24
0 99 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc32
0
3
0 65 35 25
0 100 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc33
0
3
0 65 35 26
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc34
0
3
0 65 35 27
0 102 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc35
0
3
0 65 35 28
0 103 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc36
0
3
0 65 35 29
0 104 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc37
0
3
0 65 35 30
0 105 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc38
0
3
0 65 35 31
0 106 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc39
0
3
0 65 35 32
0 107 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc4
0
3
0 65 35 33
0 108 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc40
0
3
0 65 35 34
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
sail loc41 loc5
0
3
0 65 35 36
0 110 -1 0
0 111 0 1
1
end_operator
begin_operator
sail loc41 loc6
0
3
0 65 35 37
0 110 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc41 loc7
0
3
0 65 35 38
0 110 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc41 loc8
0
3
0 65 35 39
0 110 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc41 loc9
0
3
0 65 35 40
0 110 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 65 36 0
0 75 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 65 36 1
0 76 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 65 36 2
0 77 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 65 36 3
0 78 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 65 36 4
0 79 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 65 36 5
0 80 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 65 36 6
0 81 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 65 36 7
0 82 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 65 36 8
0 83 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 65 36 9
0 84 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 65 36 10
0 85 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 65 36 11
0 86 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 65 36 12
0 87 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 65 36 13
0 88 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 65 36 14
0 89 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 65 36 15
0 90 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc24
0
3
0 65 36 16
0 91 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc25
0
3
0 65 36 17
0 92 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc26
0
3
0 65 36 18
0 93 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc27
0
3
0 65 36 19
0 94 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc28
0
3
0 65 36 20
0 95 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc29
0
3
0 65 36 21
0 96 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 65 36 22
0 97 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc30
0
3
0 65 36 23
0 98 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc31
0
3
0 65 36 24
0 99 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc32
0
3
0 65 36 25
0 100 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc33
0
3
0 65 36 26
0 101 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc34
0
3
0 65 36 27
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc35
0
3
0 65 36 28
0 103 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc36
0
3
0 65 36 29
0 104 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc37
0
3
0 65 36 30
0 105 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc38
0
3
0 65 36 31
0 106 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc39
0
3
0 65 36 32
0 107 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 65 36 33
0 108 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc40
0
3
0 65 36 34
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc41
0
3
0 65 36 35
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 65 36 37
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 65 36 38
0 111 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 65 36 39
0 111 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 65 36 40
0 111 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 65 37 0
0 75 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 65 37 1
0 76 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 65 37 2
0 77 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 65 37 3
0 78 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 65 37 4
0 79 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 65 37 5
0 80 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 65 37 6
0 81 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 65 37 7
0 82 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 65 37 8
0 83 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 65 37 9
0 84 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 65 37 10
0 85 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 65 37 11
0 86 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 65 37 12
0 87 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 65 37 13
0 88 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 65 37 14
0 89 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 65 37 15
0 90 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc24
0
3
0 65 37 16
0 91 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc25
0
3
0 65 37 17
0 92 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc26
0
3
0 65 37 18
0 93 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc27
0
3
0 65 37 19
0 94 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc28
0
3
0 65 37 20
0 95 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc29
0
3
0 65 37 21
0 96 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 65 37 22
0 97 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc30
0
3
0 65 37 23
0 98 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc31
0
3
0 65 37 24
0 99 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc32
0
3
0 65 37 25
0 100 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc33
0
3
0 65 37 26
0 101 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc34
0
3
0 65 37 27
0 102 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc35
0
3
0 65 37 28
0 103 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc36
0
3
0 65 37 29
0 104 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc37
0
3
0 65 37 30
0 105 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc38
0
3
0 65 37 31
0 106 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc39
0
3
0 65 37 32
0 107 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 65 37 33
0 108 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc40
0
3
0 65 37 34
0 109 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc41
0
3
0 65 37 35
0 110 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 65 37 36
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 65 37 38
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 65 37 39
0 112 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 65 37 40
0 112 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 65 38 0
0 75 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 65 38 1
0 76 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 65 38 2
0 77 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 65 38 3
0 78 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 65 38 4
0 79 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 65 38 5
0 80 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 65 38 6
0 81 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 65 38 7
0 82 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 65 38 8
0 83 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 65 38 9
0 84 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 65 38 10
0 85 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 65 38 11
0 86 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 65 38 12
0 87 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 65 38 13
0 88 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 65 38 14
0 89 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 65 38 15
0 90 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc24
0
3
0 65 38 16
0 91 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc25
0
3
0 65 38 17
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc26
0
3
0 65 38 18
0 93 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc27
0
3
0 65 38 19
0 94 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc28
0
3
0 65 38 20
0 95 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc29
0
3
0 65 38 21
0 96 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 65 38 22
0 97 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc30
0
3
0 65 38 23
0 98 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc31
0
3
0 65 38 24
0 99 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc32
0
3
0 65 38 25
0 100 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc33
0
3
0 65 38 26
0 101 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc34
0
3
0 65 38 27
0 102 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc35
0
3
0 65 38 28
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc36
0
3
0 65 38 29
0 104 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc37
0
3
0 65 38 30
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc38
0
3
0 65 38 31
0 106 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc39
0
3
0 65 38 32
0 107 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 65 38 33
0 108 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc40
0
3
0 65 38 34
0 109 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc41
0
3
0 65 38 35
0 110 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 65 38 36
0 111 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 65 38 37
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 65 38 39
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 65 38 40
0 113 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 65 39 0
0 75 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 65 39 1
0 76 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 65 39 2
0 77 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 65 39 3
0 78 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 65 39 4
0 79 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 65 39 5
0 80 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 65 39 6
0 81 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 65 39 7
0 82 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 65 39 8
0 83 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 65 39 9
0 84 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 65 39 10
0 85 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 65 39 11
0 86 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 65 39 12
0 87 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 65 39 13
0 88 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 65 39 14
0 89 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 65 39 15
0 90 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc24
0
3
0 65 39 16
0 91 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc25
0
3
0 65 39 17
0 92 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc26
0
3
0 65 39 18
0 93 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc27
0
3
0 65 39 19
0 94 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc28
0
3
0 65 39 20
0 95 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc29
0
3
0 65 39 21
0 96 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 65 39 22
0 97 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc30
0
3
0 65 39 23
0 98 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc31
0
3
0 65 39 24
0 99 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc32
0
3
0 65 39 25
0 100 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc33
0
3
0 65 39 26
0 101 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc34
0
3
0 65 39 27
0 102 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc35
0
3
0 65 39 28
0 103 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc36
0
3
0 65 39 29
0 104 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc37
0
3
0 65 39 30
0 105 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc38
0
3
0 65 39 31
0 106 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc39
0
3
0 65 39 32
0 107 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 65 39 33
0 108 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc40
0
3
0 65 39 34
0 109 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc41
0
3
0 65 39 35
0 110 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 65 39 36
0 111 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 65 39 37
0 112 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 65 39 38
0 113 0 1
0 114 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 65 39 40
0 114 -1 0
0 115 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 65 40 0
0 75 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 65 40 1
0 76 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 65 40 2
0 77 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 65 40 3
0 78 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 65 40 4
0 79 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 65 40 5
0 80 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 65 40 6
0 81 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 65 40 7
0 82 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 65 40 8
0 83 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 65 40 9
0 84 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 65 40 10
0 85 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 65 40 11
0 86 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 65 40 12
0 87 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 65 40 13
0 88 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 65 40 14
0 89 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 65 40 15
0 90 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc24
0
3
0 65 40 16
0 91 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc25
0
3
0 65 40 17
0 92 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc26
0
3
0 65 40 18
0 93 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc27
0
3
0 65 40 19
0 94 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc28
0
3
0 65 40 20
0 95 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc29
0
3
0 65 40 21
0 96 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 65 40 22
0 97 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc30
0
3
0 65 40 23
0 98 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc31
0
3
0 65 40 24
0 99 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc32
0
3
0 65 40 25
0 100 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc33
0
3
0 65 40 26
0 101 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc34
0
3
0 65 40 27
0 102 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc35
0
3
0 65 40 28
0 103 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc36
0
3
0 65 40 29
0 104 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc37
0
3
0 65 40 30
0 105 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc38
0
3
0 65 40 31
0 106 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc39
0
3
0 65 40 32
0 107 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 65 40 33
0 108 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc40
0
3
0 65 40 34
0 109 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc41
0
3
0 65 40 35
0 110 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 65 40 36
0 111 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 65 40 37
0 112 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 65 40 38
0 113 0 1
0 115 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 65 40 39
0 114 0 1
0 115 -1 0
1
end_operator
0
