begin_version
3
end_version
begin_metric
1
end_metric
17
begin_variable
var0
-1
9
at car1 loc1
at car1 loc2
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
on car1
end_variable
begin_variable
var1
-1
9
at car2 loc1
at car2 loc2
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
on car2
end_variable
begin_variable
var2
-1
9
at car3 loc1
at car3 loc2
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
on car3
end_variable
begin_variable
var3
-1
9
at car4 loc1
at car4 loc2
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
on car4
end_variable
begin_variable
var4
-1
9
at car5 loc1
at car5 loc2
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
on car5
end_variable
begin_variable
var5
-1
9
at car6 loc1
at car6 loc2
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
on car6
end_variable
begin_variable
var6
-1
9
at car7 loc1
at car7 loc2
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
on car7
end_variable
begin_variable
var7
-1
8
at-ferry loc1
at-ferry loc2
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
end_variable
begin_variable
var8
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var9
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var10
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var11
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var16
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
6
5
2
1
5
7
0
5
0
0
0
0
0
1
0
0
0
end_state
begin_goal
7
0 3
1 4
2 7
3 4
4 4
5 4
6 4
end_goal
168
begin_operator
board car1 loc1
1
7 0
2
0 0 0 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc2
1
7 1
2
0 0 1 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc3
1
7 2
2
0 0 2 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc4
1
7 3
2
0 0 3 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc5
1
7 4
2
0 0 4 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc6
1
7 5
2
0 0 5 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc7
1
7 6
2
0 0 6 8
0 16 0 1
1
end_operator
begin_operator
board car1 loc8
1
7 7
2
0 0 7 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc1
1
7 0
2
0 1 0 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc2
1
7 1
2
0 1 1 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc3
1
7 2
2
0 1 2 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc4
1
7 3
2
0 1 3 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc5
1
7 4
2
0 1 4 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc6
1
7 5
2
0 1 5 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc7
1
7 6
2
0 1 6 8
0 16 0 1
1
end_operator
begin_operator
board car2 loc8
1
7 7
2
0 1 7 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc1
1
7 0
2
0 2 0 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc2
1
7 1
2
0 2 1 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc3
1
7 2
2
0 2 2 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc4
1
7 3
2
0 2 3 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc5
1
7 4
2
0 2 4 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc6
1
7 5
2
0 2 5 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc7
1
7 6
2
0 2 6 8
0 16 0 1
1
end_operator
begin_operator
board car3 loc8
1
7 7
2
0 2 7 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc1
1
7 0
2
0 3 0 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc2
1
7 1
2
0 3 1 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc3
1
7 2
2
0 3 2 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc4
1
7 3
2
0 3 3 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc5
1
7 4
2
0 3 4 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc6
1
7 5
2
0 3 5 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc7
1
7 6
2
0 3 6 8
0 16 0 1
1
end_operator
begin_operator
board car4 loc8
1
7 7
2
0 3 7 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc1
1
7 0
2
0 4 0 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc2
1
7 1
2
0 4 1 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc3
1
7 2
2
0 4 2 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc4
1
7 3
2
0 4 3 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc5
1
7 4
2
0 4 4 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc6
1
7 5
2
0 4 5 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc7
1
7 6
2
0 4 6 8
0 16 0 1
1
end_operator
begin_operator
board car5 loc8
1
7 7
2
0 4 7 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc1
1
7 0
2
0 5 0 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc2
1
7 1
2
0 5 1 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc3
1
7 2
2
0 5 2 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc4
1
7 3
2
0 5 3 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc5
1
7 4
2
0 5 4 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc6
1
7 5
2
0 5 5 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc7
1
7 6
2
0 5 6 8
0 16 0 1
1
end_operator
begin_operator
board car6 loc8
1
7 7
2
0 5 7 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc1
1
7 0
2
0 6 0 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc2
1
7 1
2
0 6 1 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc3
1
7 2
2
0 6 2 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc4
1
7 3
2
0 6 3 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc5
1
7 4
2
0 6 4 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc6
1
7 5
2
0 6 5 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc7
1
7 6
2
0 6 6 8
0 16 0 1
1
end_operator
begin_operator
board car7 loc8
1
7 7
2
0 6 7 8
0 16 0 1
1
end_operator
begin_operator
debark car1 loc1
1
7 0
2
0 0 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
7 1
2
0 0 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
7 2
2
0 0 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
7 3
2
0 0 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
7 4
2
0 0 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
7 5
2
0 0 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc7
1
7 6
2
0 0 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car1 loc8
1
7 7
2
0 0 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
7 0
2
0 1 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
7 1
2
0 1 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
7 2
2
0 1 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
7 3
2
0 1 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
7 4
2
0 1 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
7 5
2
0 1 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc7
1
7 6
2
0 1 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car2 loc8
1
7 7
2
0 1 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
7 0
2
0 2 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
7 1
2
0 2 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
7 2
2
0 2 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
7 3
2
0 2 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
7 4
2
0 2 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
7 5
2
0 2 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc7
1
7 6
2
0 2 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car3 loc8
1
7 7
2
0 2 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc1
1
7 0
2
0 3 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc2
1
7 1
2
0 3 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc3
1
7 2
2
0 3 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc4
1
7 3
2
0 3 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc5
1
7 4
2
0 3 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc6
1
7 5
2
0 3 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc7
1
7 6
2
0 3 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car4 loc8
1
7 7
2
0 3 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc1
1
7 0
2
0 4 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc2
1
7 1
2
0 4 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc3
1
7 2
2
0 4 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc4
1
7 3
2
0 4 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc5
1
7 4
2
0 4 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc6
1
7 5
2
0 4 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc7
1
7 6
2
0 4 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car5 loc8
1
7 7
2
0 4 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc1
1
7 0
2
0 5 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc2
1
7 1
2
0 5 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc3
1
7 2
2
0 5 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc4
1
7 3
2
0 5 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc5
1
7 4
2
0 5 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc6
1
7 5
2
0 5 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc7
1
7 6
2
0 5 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car6 loc8
1
7 7
2
0 5 8 7
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc1
1
7 0
2
0 6 8 0
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc2
1
7 1
2
0 6 8 1
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc3
1
7 2
2
0 6 8 2
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc4
1
7 3
2
0 6 8 3
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc5
1
7 4
2
0 6 8 4
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc6
1
7 5
2
0 6 8 5
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc7
1
7 6
2
0 6 8 6
0 16 -1 0
1
end_operator
begin_operator
debark car7 loc8
1
7 7
2
0 6 8 7
0 16 -1 0
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 7 0 1
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 7 0 2
0 8 -1 0
0 10 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 7 0 3
0 8 -1 0
0 11 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 7 0 4
0 8 -1 0
0 12 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 7 0 5
0 8 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 7 0 6
0 8 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 7 0 7
0 8 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 7 1 0
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 7 1 2
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 7 1 3
0 9 -1 0
0 11 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 7 1 4
0 9 -1 0
0 12 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 7 1 5
0 9 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 7 1 6
0 9 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 7 1 7
0 9 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 7 2 0
0 8 0 1
0 10 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 7 2 1
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 7 2 3
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 7 2 4
0 10 -1 0
0 12 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 7 2 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 7 2 6
0 10 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 7 2 7
0 10 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 7 3 0
0 8 0 1
0 11 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 7 3 1
0 9 0 1
0 11 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 7 3 2
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 7 3 4
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 7 3 5
0 11 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 7 3 6
0 11 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 7 3 7
0 11 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 7 4 0
0 8 0 1
0 12 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 7 4 1
0 9 0 1
0 12 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 7 4 2
0 10 0 1
0 12 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 7 4 3
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 7 4 5
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 7 4 6
0 12 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 7 4 7
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 7 5 0
0 8 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 7 5 1
0 9 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 7 5 2
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 7 5 3
0 11 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 7 5 4
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 7 5 6
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 7 5 7
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 7 6 0
0 8 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 7 6 1
0 9 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 7 6 2
0 10 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 7 6 3
0 11 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 7 6 4
0 12 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 7 6 5
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 7 6 7
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 7 7 0
0 8 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 7 7 1
0 9 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 7 7 2
0 10 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 7 7 3
0 11 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 7 7 4
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 7 7 5
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 7 7 6
0 14 0 1
0 15 -1 0
1
end_operator
0
