begin_version
3
end_version
begin_metric
1
end_metric
48
begin_variable
var0
-1
25
at car19 loc1
at car19 loc10
at car19 loc11
at car19 loc12
at car19 loc13
at car19 loc14
at car19 loc15
at car19 loc16
at car19 loc17
at car19 loc18
at car19 loc19
at car19 loc2
at car19 loc20
at car19 loc21
at car19 loc22
at car19 loc23
at car19 loc24
at car19 loc3
at car19 loc4
at car19 loc5
at car19 loc6
at car19 loc7
at car19 loc8
at car19 loc9
on car19
end_variable
begin_variable
var1
-1
25
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc22
at car9 loc23
at car9 loc24
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
on car9
end_variable
begin_variable
var2
-1
25
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc22
at car1 loc23
at car1 loc24
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
on car1
end_variable
begin_variable
var3
-1
25
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc22
at car2 loc23
at car2 loc24
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
on car2
end_variable
begin_variable
var4
-1
25
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc22
at car10 loc23
at car10 loc24
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
on car10
end_variable
begin_variable
var5
-1
25
at car20 loc1
at car20 loc10
at car20 loc11
at car20 loc12
at car20 loc13
at car20 loc14
at car20 loc15
at car20 loc16
at car20 loc17
at car20 loc18
at car20 loc19
at car20 loc2
at car20 loc20
at car20 loc21
at car20 loc22
at car20 loc23
at car20 loc24
at car20 loc3
at car20 loc4
at car20 loc5
at car20 loc6
at car20 loc7
at car20 loc8
at car20 loc9
on car20
end_variable
begin_variable
var6
-1
25
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc22
at car11 loc23
at car11 loc24
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
on car11
end_variable
begin_variable
var7
-1
25
at car21 loc1
at car21 loc10
at car21 loc11
at car21 loc12
at car21 loc13
at car21 loc14
at car21 loc15
at car21 loc16
at car21 loc17
at car21 loc18
at car21 loc19
at car21 loc2
at car21 loc20
at car21 loc21
at car21 loc22
at car21 loc23
at car21 loc24
at car21 loc3
at car21 loc4
at car21 loc5
at car21 loc6
at car21 loc7
at car21 loc8
at car21 loc9
on car21
end_variable
begin_variable
var8
-1
25
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc22
at car12 loc23
at car12 loc24
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
on car12
end_variable
begin_variable
var9
-1
25
at car22 loc1
at car22 loc10
at car22 loc11
at car22 loc12
at car22 loc13
at car22 loc14
at car22 loc15
at car22 loc16
at car22 loc17
at car22 loc18
at car22 loc19
at car22 loc2
at car22 loc20
at car22 loc21
at car22 loc22
at car22 loc23
at car22 loc24
at car22 loc3
at car22 loc4
at car22 loc5
at car22 loc6
at car22 loc7
at car22 loc8
at car22 loc9
on car22
end_variable
begin_variable
var10
-1
25
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc22
at car13 loc23
at car13 loc24
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
on car13
end_variable
begin_variable
var11
-1
25
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc22
at car3 loc23
at car3 loc24
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
on car3
end_variable
begin_variable
var12
-1
25
at car14 loc1
at car14 loc10
at car14 loc11
at car14 loc12
at car14 loc13
at car14 loc14
at car14 loc15
at car14 loc16
at car14 loc17
at car14 loc18
at car14 loc19
at car14 loc2
at car14 loc20
at car14 loc21
at car14 loc22
at car14 loc23
at car14 loc24
at car14 loc3
at car14 loc4
at car14 loc5
at car14 loc6
at car14 loc7
at car14 loc8
at car14 loc9
on car14
end_variable
begin_variable
var13
-1
25
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc22
at car4 loc23
at car4 loc24
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
on car4
end_variable
begin_variable
var14
-1
25
at car15 loc1
at car15 loc10
at car15 loc11
at car15 loc12
at car15 loc13
at car15 loc14
at car15 loc15
at car15 loc16
at car15 loc17
at car15 loc18
at car15 loc19
at car15 loc2
at car15 loc20
at car15 loc21
at car15 loc22
at car15 loc23
at car15 loc24
at car15 loc3
at car15 loc4
at car15 loc5
at car15 loc6
at car15 loc7
at car15 loc8
at car15 loc9
on car15
end_variable
begin_variable
var15
-1
25
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc22
at car5 loc23
at car5 loc24
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
on car5
end_variable
begin_variable
var16
-1
25
at car16 loc1
at car16 loc10
at car16 loc11
at car16 loc12
at car16 loc13
at car16 loc14
at car16 loc15
at car16 loc16
at car16 loc17
at car16 loc18
at car16 loc19
at car16 loc2
at car16 loc20
at car16 loc21
at car16 loc22
at car16 loc23
at car16 loc24
at car16 loc3
at car16 loc4
at car16 loc5
at car16 loc6
at car16 loc7
at car16 loc8
at car16 loc9
on car16
end_variable
begin_variable
var17
-1
25
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc22
at car6 loc23
at car6 loc24
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
on car6
end_variable
begin_variable
var18
-1
25
at car17 loc1
at car17 loc10
at car17 loc11
at car17 loc12
at car17 loc13
at car17 loc14
at car17 loc15
at car17 loc16
at car17 loc17
at car17 loc18
at car17 loc19
at car17 loc2
at car17 loc20
at car17 loc21
at car17 loc22
at car17 loc23
at car17 loc24
at car17 loc3
at car17 loc4
at car17 loc5
at car17 loc6
at car17 loc7
at car17 loc8
at car17 loc9
on car17
end_variable
begin_variable
var19
-1
25
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc22
at car7 loc23
at car7 loc24
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
on car7
end_variable
begin_variable
var20
-1
25
at car18 loc1
at car18 loc10
at car18 loc11
at car18 loc12
at car18 loc13
at car18 loc14
at car18 loc15
at car18 loc16
at car18 loc17
at car18 loc18
at car18 loc19
at car18 loc2
at car18 loc20
at car18 loc21
at car18 loc22
at car18 loc23
at car18 loc24
at car18 loc3
at car18 loc4
at car18 loc5
at car18 loc6
at car18 loc7
at car18 loc8
at car18 loc9
on car18
end_variable
begin_variable
var21
-1
25
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc22
at car8 loc23
at car8 loc24
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
on car8
end_variable
begin_variable
var22
-1
24
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc22
at-ferry loc23
at-ferry loc24
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var23
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var35
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var36
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var37
-1
2
NOT-at-ferry loc22
none-of-those
end_variable
begin_variable
var38
-1
2
NOT-at-ferry loc23
none-of-those
end_variable
begin_variable
var39
-1
2
NOT-at-ferry loc24
none-of-those
end_variable
begin_variable
var40
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var41
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var42
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var43
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var44
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var45
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var46
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
begin_variable
var47
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
12
6
23
0
8
18
23
3
20
21
18
5
6
20
14
14
1
6
16
4
4
14
3
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
22
0 6
1 10
2 17
3 6
4 0
5 23
6 15
7 23
8 1
9 8
10 9
11 12
12 10
13 4
14 20
15 7
16 16
17 0
18 18
19 8
20 23
21 20
end_goal
1608
begin_operator
board car1 loc1
1
22 0
2
0 2 0 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc10
1
22 1
2
0 2 1 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc11
1
22 2
2
0 2 2 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc12
1
22 3
2
0 2 3 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc13
1
22 4
2
0 2 4 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc14
1
22 5
2
0 2 5 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc15
1
22 6
2
0 2 6 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc16
1
22 7
2
0 2 7 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc17
1
22 8
2
0 2 8 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc18
1
22 9
2
0 2 9 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc19
1
22 10
2
0 2 10 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc2
1
22 11
2
0 2 11 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc20
1
22 12
2
0 2 12 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc21
1
22 13
2
0 2 13 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc22
1
22 14
2
0 2 14 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc23
1
22 15
2
0 2 15 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc24
1
22 16
2
0 2 16 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc3
1
22 17
2
0 2 17 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc4
1
22 18
2
0 2 18 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc5
1
22 19
2
0 2 19 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc6
1
22 20
2
0 2 20 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc7
1
22 21
2
0 2 21 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc8
1
22 22
2
0 2 22 24
0 47 0 1
1
end_operator
begin_operator
board car1 loc9
1
22 23
2
0 2 23 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc1
1
22 0
2
0 4 0 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc10
1
22 1
2
0 4 1 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc11
1
22 2
2
0 4 2 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc12
1
22 3
2
0 4 3 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc13
1
22 4
2
0 4 4 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc14
1
22 5
2
0 4 5 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc15
1
22 6
2
0 4 6 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc16
1
22 7
2
0 4 7 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc17
1
22 8
2
0 4 8 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc18
1
22 9
2
0 4 9 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc19
1
22 10
2
0 4 10 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc2
1
22 11
2
0 4 11 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc20
1
22 12
2
0 4 12 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc21
1
22 13
2
0 4 13 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc22
1
22 14
2
0 4 14 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc23
1
22 15
2
0 4 15 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc24
1
22 16
2
0 4 16 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc3
1
22 17
2
0 4 17 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc4
1
22 18
2
0 4 18 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc5
1
22 19
2
0 4 19 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc6
1
22 20
2
0 4 20 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc7
1
22 21
2
0 4 21 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc8
1
22 22
2
0 4 22 24
0 47 0 1
1
end_operator
begin_operator
board car10 loc9
1
22 23
2
0 4 23 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc1
1
22 0
2
0 6 0 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc10
1
22 1
2
0 6 1 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc11
1
22 2
2
0 6 2 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc12
1
22 3
2
0 6 3 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc13
1
22 4
2
0 6 4 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc14
1
22 5
2
0 6 5 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc15
1
22 6
2
0 6 6 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc16
1
22 7
2
0 6 7 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc17
1
22 8
2
0 6 8 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc18
1
22 9
2
0 6 9 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc19
1
22 10
2
0 6 10 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc2
1
22 11
2
0 6 11 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc20
1
22 12
2
0 6 12 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc21
1
22 13
2
0 6 13 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc22
1
22 14
2
0 6 14 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc23
1
22 15
2
0 6 15 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc24
1
22 16
2
0 6 16 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc3
1
22 17
2
0 6 17 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc4
1
22 18
2
0 6 18 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc5
1
22 19
2
0 6 19 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc6
1
22 20
2
0 6 20 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc7
1
22 21
2
0 6 21 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc8
1
22 22
2
0 6 22 24
0 47 0 1
1
end_operator
begin_operator
board car11 loc9
1
22 23
2
0 6 23 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc1
1
22 0
2
0 8 0 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc10
1
22 1
2
0 8 1 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc11
1
22 2
2
0 8 2 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc12
1
22 3
2
0 8 3 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc13
1
22 4
2
0 8 4 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc14
1
22 5
2
0 8 5 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc15
1
22 6
2
0 8 6 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc16
1
22 7
2
0 8 7 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc17
1
22 8
2
0 8 8 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc18
1
22 9
2
0 8 9 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc19
1
22 10
2
0 8 10 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc2
1
22 11
2
0 8 11 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc20
1
22 12
2
0 8 12 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc21
1
22 13
2
0 8 13 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc22
1
22 14
2
0 8 14 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc23
1
22 15
2
0 8 15 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc24
1
22 16
2
0 8 16 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc3
1
22 17
2
0 8 17 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc4
1
22 18
2
0 8 18 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc5
1
22 19
2
0 8 19 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc6
1
22 20
2
0 8 20 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc7
1
22 21
2
0 8 21 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc8
1
22 22
2
0 8 22 24
0 47 0 1
1
end_operator
begin_operator
board car12 loc9
1
22 23
2
0 8 23 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc1
1
22 0
2
0 10 0 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc10
1
22 1
2
0 10 1 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc11
1
22 2
2
0 10 2 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc12
1
22 3
2
0 10 3 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc13
1
22 4
2
0 10 4 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc14
1
22 5
2
0 10 5 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc15
1
22 6
2
0 10 6 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc16
1
22 7
2
0 10 7 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc17
1
22 8
2
0 10 8 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc18
1
22 9
2
0 10 9 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc19
1
22 10
2
0 10 10 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc2
1
22 11
2
0 10 11 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc20
1
22 12
2
0 10 12 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc21
1
22 13
2
0 10 13 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc22
1
22 14
2
0 10 14 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc23
1
22 15
2
0 10 15 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc24
1
22 16
2
0 10 16 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc3
1
22 17
2
0 10 17 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc4
1
22 18
2
0 10 18 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc5
1
22 19
2
0 10 19 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc6
1
22 20
2
0 10 20 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc7
1
22 21
2
0 10 21 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc8
1
22 22
2
0 10 22 24
0 47 0 1
1
end_operator
begin_operator
board car13 loc9
1
22 23
2
0 10 23 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc1
1
22 0
2
0 12 0 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc10
1
22 1
2
0 12 1 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc11
1
22 2
2
0 12 2 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc12
1
22 3
2
0 12 3 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc13
1
22 4
2
0 12 4 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc14
1
22 5
2
0 12 5 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc15
1
22 6
2
0 12 6 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc16
1
22 7
2
0 12 7 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc17
1
22 8
2
0 12 8 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc18
1
22 9
2
0 12 9 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc19
1
22 10
2
0 12 10 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc2
1
22 11
2
0 12 11 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc20
1
22 12
2
0 12 12 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc21
1
22 13
2
0 12 13 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc22
1
22 14
2
0 12 14 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc23
1
22 15
2
0 12 15 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc24
1
22 16
2
0 12 16 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc3
1
22 17
2
0 12 17 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc4
1
22 18
2
0 12 18 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc5
1
22 19
2
0 12 19 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc6
1
22 20
2
0 12 20 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc7
1
22 21
2
0 12 21 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc8
1
22 22
2
0 12 22 24
0 47 0 1
1
end_operator
begin_operator
board car14 loc9
1
22 23
2
0 12 23 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc1
1
22 0
2
0 14 0 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc10
1
22 1
2
0 14 1 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc11
1
22 2
2
0 14 2 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc12
1
22 3
2
0 14 3 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc13
1
22 4
2
0 14 4 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc14
1
22 5
2
0 14 5 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc15
1
22 6
2
0 14 6 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc16
1
22 7
2
0 14 7 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc17
1
22 8
2
0 14 8 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc18
1
22 9
2
0 14 9 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc19
1
22 10
2
0 14 10 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc2
1
22 11
2
0 14 11 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc20
1
22 12
2
0 14 12 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc21
1
22 13
2
0 14 13 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc22
1
22 14
2
0 14 14 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc23
1
22 15
2
0 14 15 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc24
1
22 16
2
0 14 16 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc3
1
22 17
2
0 14 17 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc4
1
22 18
2
0 14 18 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc5
1
22 19
2
0 14 19 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc6
1
22 20
2
0 14 20 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc7
1
22 21
2
0 14 21 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc8
1
22 22
2
0 14 22 24
0 47 0 1
1
end_operator
begin_operator
board car15 loc9
1
22 23
2
0 14 23 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc1
1
22 0
2
0 16 0 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc10
1
22 1
2
0 16 1 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc11
1
22 2
2
0 16 2 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc12
1
22 3
2
0 16 3 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc13
1
22 4
2
0 16 4 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc14
1
22 5
2
0 16 5 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc15
1
22 6
2
0 16 6 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc16
1
22 7
2
0 16 7 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc17
1
22 8
2
0 16 8 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc18
1
22 9
2
0 16 9 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc19
1
22 10
2
0 16 10 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc2
1
22 11
2
0 16 11 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc20
1
22 12
2
0 16 12 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc21
1
22 13
2
0 16 13 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc22
1
22 14
2
0 16 14 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc23
1
22 15
2
0 16 15 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc24
1
22 16
2
0 16 16 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc3
1
22 17
2
0 16 17 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc4
1
22 18
2
0 16 18 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc5
1
22 19
2
0 16 19 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc6
1
22 20
2
0 16 20 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc7
1
22 21
2
0 16 21 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc8
1
22 22
2
0 16 22 24
0 47 0 1
1
end_operator
begin_operator
board car16 loc9
1
22 23
2
0 16 23 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc1
1
22 0
2
0 18 0 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc10
1
22 1
2
0 18 1 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc11
1
22 2
2
0 18 2 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc12
1
22 3
2
0 18 3 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc13
1
22 4
2
0 18 4 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc14
1
22 5
2
0 18 5 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc15
1
22 6
2
0 18 6 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc16
1
22 7
2
0 18 7 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc17
1
22 8
2
0 18 8 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc18
1
22 9
2
0 18 9 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc19
1
22 10
2
0 18 10 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc2
1
22 11
2
0 18 11 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc20
1
22 12
2
0 18 12 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc21
1
22 13
2
0 18 13 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc22
1
22 14
2
0 18 14 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc23
1
22 15
2
0 18 15 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc24
1
22 16
2
0 18 16 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc3
1
22 17
2
0 18 17 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc4
1
22 18
2
0 18 18 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc5
1
22 19
2
0 18 19 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc6
1
22 20
2
0 18 20 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc7
1
22 21
2
0 18 21 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc8
1
22 22
2
0 18 22 24
0 47 0 1
1
end_operator
begin_operator
board car17 loc9
1
22 23
2
0 18 23 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc1
1
22 0
2
0 20 0 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc10
1
22 1
2
0 20 1 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc11
1
22 2
2
0 20 2 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc12
1
22 3
2
0 20 3 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc13
1
22 4
2
0 20 4 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc14
1
22 5
2
0 20 5 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc15
1
22 6
2
0 20 6 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc16
1
22 7
2
0 20 7 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc17
1
22 8
2
0 20 8 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc18
1
22 9
2
0 20 9 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc19
1
22 10
2
0 20 10 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc2
1
22 11
2
0 20 11 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc20
1
22 12
2
0 20 12 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc21
1
22 13
2
0 20 13 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc22
1
22 14
2
0 20 14 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc23
1
22 15
2
0 20 15 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc24
1
22 16
2
0 20 16 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc3
1
22 17
2
0 20 17 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc4
1
22 18
2
0 20 18 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc5
1
22 19
2
0 20 19 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc6
1
22 20
2
0 20 20 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc7
1
22 21
2
0 20 21 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc8
1
22 22
2
0 20 22 24
0 47 0 1
1
end_operator
begin_operator
board car18 loc9
1
22 23
2
0 20 23 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc1
1
22 0
2
0 0 0 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc10
1
22 1
2
0 0 1 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc11
1
22 2
2
0 0 2 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc12
1
22 3
2
0 0 3 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc13
1
22 4
2
0 0 4 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc14
1
22 5
2
0 0 5 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc15
1
22 6
2
0 0 6 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc16
1
22 7
2
0 0 7 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc17
1
22 8
2
0 0 8 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc18
1
22 9
2
0 0 9 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc19
1
22 10
2
0 0 10 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc2
1
22 11
2
0 0 11 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc20
1
22 12
2
0 0 12 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc21
1
22 13
2
0 0 13 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc22
1
22 14
2
0 0 14 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc23
1
22 15
2
0 0 15 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc24
1
22 16
2
0 0 16 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc3
1
22 17
2
0 0 17 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc4
1
22 18
2
0 0 18 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc5
1
22 19
2
0 0 19 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc6
1
22 20
2
0 0 20 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc7
1
22 21
2
0 0 21 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc8
1
22 22
2
0 0 22 24
0 47 0 1
1
end_operator
begin_operator
board car19 loc9
1
22 23
2
0 0 23 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc1
1
22 0
2
0 3 0 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc10
1
22 1
2
0 3 1 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc11
1
22 2
2
0 3 2 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc12
1
22 3
2
0 3 3 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc13
1
22 4
2
0 3 4 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc14
1
22 5
2
0 3 5 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc15
1
22 6
2
0 3 6 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc16
1
22 7
2
0 3 7 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc17
1
22 8
2
0 3 8 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc18
1
22 9
2
0 3 9 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc19
1
22 10
2
0 3 10 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc2
1
22 11
2
0 3 11 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc20
1
22 12
2
0 3 12 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc21
1
22 13
2
0 3 13 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc22
1
22 14
2
0 3 14 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc23
1
22 15
2
0 3 15 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc24
1
22 16
2
0 3 16 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc3
1
22 17
2
0 3 17 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc4
1
22 18
2
0 3 18 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc5
1
22 19
2
0 3 19 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc6
1
22 20
2
0 3 20 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc7
1
22 21
2
0 3 21 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc8
1
22 22
2
0 3 22 24
0 47 0 1
1
end_operator
begin_operator
board car2 loc9
1
22 23
2
0 3 23 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc1
1
22 0
2
0 5 0 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc10
1
22 1
2
0 5 1 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc11
1
22 2
2
0 5 2 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc12
1
22 3
2
0 5 3 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc13
1
22 4
2
0 5 4 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc14
1
22 5
2
0 5 5 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc15
1
22 6
2
0 5 6 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc16
1
22 7
2
0 5 7 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc17
1
22 8
2
0 5 8 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc18
1
22 9
2
0 5 9 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc19
1
22 10
2
0 5 10 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc2
1
22 11
2
0 5 11 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc20
1
22 12
2
0 5 12 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc21
1
22 13
2
0 5 13 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc22
1
22 14
2
0 5 14 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc23
1
22 15
2
0 5 15 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc24
1
22 16
2
0 5 16 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc3
1
22 17
2
0 5 17 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc4
1
22 18
2
0 5 18 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc5
1
22 19
2
0 5 19 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc6
1
22 20
2
0 5 20 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc7
1
22 21
2
0 5 21 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc8
1
22 22
2
0 5 22 24
0 47 0 1
1
end_operator
begin_operator
board car20 loc9
1
22 23
2
0 5 23 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc1
1
22 0
2
0 7 0 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc10
1
22 1
2
0 7 1 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc11
1
22 2
2
0 7 2 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc12
1
22 3
2
0 7 3 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc13
1
22 4
2
0 7 4 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc14
1
22 5
2
0 7 5 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc15
1
22 6
2
0 7 6 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc16
1
22 7
2
0 7 7 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc17
1
22 8
2
0 7 8 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc18
1
22 9
2
0 7 9 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc19
1
22 10
2
0 7 10 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc2
1
22 11
2
0 7 11 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc20
1
22 12
2
0 7 12 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc21
1
22 13
2
0 7 13 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc22
1
22 14
2
0 7 14 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc23
1
22 15
2
0 7 15 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc24
1
22 16
2
0 7 16 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc3
1
22 17
2
0 7 17 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc4
1
22 18
2
0 7 18 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc5
1
22 19
2
0 7 19 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc6
1
22 20
2
0 7 20 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc7
1
22 21
2
0 7 21 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc8
1
22 22
2
0 7 22 24
0 47 0 1
1
end_operator
begin_operator
board car21 loc9
1
22 23
2
0 7 23 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc1
1
22 0
2
0 9 0 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc10
1
22 1
2
0 9 1 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc11
1
22 2
2
0 9 2 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc12
1
22 3
2
0 9 3 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc13
1
22 4
2
0 9 4 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc14
1
22 5
2
0 9 5 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc15
1
22 6
2
0 9 6 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc16
1
22 7
2
0 9 7 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc17
1
22 8
2
0 9 8 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc18
1
22 9
2
0 9 9 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc19
1
22 10
2
0 9 10 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc2
1
22 11
2
0 9 11 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc20
1
22 12
2
0 9 12 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc21
1
22 13
2
0 9 13 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc22
1
22 14
2
0 9 14 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc23
1
22 15
2
0 9 15 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc24
1
22 16
2
0 9 16 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc3
1
22 17
2
0 9 17 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc4
1
22 18
2
0 9 18 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc5
1
22 19
2
0 9 19 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc6
1
22 20
2
0 9 20 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc7
1
22 21
2
0 9 21 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc8
1
22 22
2
0 9 22 24
0 47 0 1
1
end_operator
begin_operator
board car22 loc9
1
22 23
2
0 9 23 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc1
1
22 0
2
0 11 0 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc10
1
22 1
2
0 11 1 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc11
1
22 2
2
0 11 2 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc12
1
22 3
2
0 11 3 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc13
1
22 4
2
0 11 4 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc14
1
22 5
2
0 11 5 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc15
1
22 6
2
0 11 6 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc16
1
22 7
2
0 11 7 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc17
1
22 8
2
0 11 8 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc18
1
22 9
2
0 11 9 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc19
1
22 10
2
0 11 10 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc2
1
22 11
2
0 11 11 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc20
1
22 12
2
0 11 12 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc21
1
22 13
2
0 11 13 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc22
1
22 14
2
0 11 14 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc23
1
22 15
2
0 11 15 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc24
1
22 16
2
0 11 16 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc3
1
22 17
2
0 11 17 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc4
1
22 18
2
0 11 18 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc5
1
22 19
2
0 11 19 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc6
1
22 20
2
0 11 20 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc7
1
22 21
2
0 11 21 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc8
1
22 22
2
0 11 22 24
0 47 0 1
1
end_operator
begin_operator
board car3 loc9
1
22 23
2
0 11 23 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc1
1
22 0
2
0 13 0 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc10
1
22 1
2
0 13 1 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc11
1
22 2
2
0 13 2 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc12
1
22 3
2
0 13 3 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc13
1
22 4
2
0 13 4 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc14
1
22 5
2
0 13 5 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc15
1
22 6
2
0 13 6 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc16
1
22 7
2
0 13 7 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc17
1
22 8
2
0 13 8 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc18
1
22 9
2
0 13 9 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc19
1
22 10
2
0 13 10 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc2
1
22 11
2
0 13 11 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc20
1
22 12
2
0 13 12 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc21
1
22 13
2
0 13 13 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc22
1
22 14
2
0 13 14 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc23
1
22 15
2
0 13 15 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc24
1
22 16
2
0 13 16 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc3
1
22 17
2
0 13 17 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc4
1
22 18
2
0 13 18 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc5
1
22 19
2
0 13 19 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc6
1
22 20
2
0 13 20 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc7
1
22 21
2
0 13 21 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc8
1
22 22
2
0 13 22 24
0 47 0 1
1
end_operator
begin_operator
board car4 loc9
1
22 23
2
0 13 23 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc1
1
22 0
2
0 15 0 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc10
1
22 1
2
0 15 1 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc11
1
22 2
2
0 15 2 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc12
1
22 3
2
0 15 3 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc13
1
22 4
2
0 15 4 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc14
1
22 5
2
0 15 5 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc15
1
22 6
2
0 15 6 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc16
1
22 7
2
0 15 7 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc17
1
22 8
2
0 15 8 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc18
1
22 9
2
0 15 9 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc19
1
22 10
2
0 15 10 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc2
1
22 11
2
0 15 11 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc20
1
22 12
2
0 15 12 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc21
1
22 13
2
0 15 13 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc22
1
22 14
2
0 15 14 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc23
1
22 15
2
0 15 15 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc24
1
22 16
2
0 15 16 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc3
1
22 17
2
0 15 17 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc4
1
22 18
2
0 15 18 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc5
1
22 19
2
0 15 19 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc6
1
22 20
2
0 15 20 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc7
1
22 21
2
0 15 21 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc8
1
22 22
2
0 15 22 24
0 47 0 1
1
end_operator
begin_operator
board car5 loc9
1
22 23
2
0 15 23 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc1
1
22 0
2
0 17 0 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc10
1
22 1
2
0 17 1 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc11
1
22 2
2
0 17 2 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc12
1
22 3
2
0 17 3 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc13
1
22 4
2
0 17 4 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc14
1
22 5
2
0 17 5 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc15
1
22 6
2
0 17 6 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc16
1
22 7
2
0 17 7 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc17
1
22 8
2
0 17 8 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc18
1
22 9
2
0 17 9 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc19
1
22 10
2
0 17 10 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc2
1
22 11
2
0 17 11 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc20
1
22 12
2
0 17 12 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc21
1
22 13
2
0 17 13 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc22
1
22 14
2
0 17 14 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc23
1
22 15
2
0 17 15 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc24
1
22 16
2
0 17 16 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc3
1
22 17
2
0 17 17 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc4
1
22 18
2
0 17 18 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc5
1
22 19
2
0 17 19 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc6
1
22 20
2
0 17 20 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc7
1
22 21
2
0 17 21 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc8
1
22 22
2
0 17 22 24
0 47 0 1
1
end_operator
begin_operator
board car6 loc9
1
22 23
2
0 17 23 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc1
1
22 0
2
0 19 0 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc10
1
22 1
2
0 19 1 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc11
1
22 2
2
0 19 2 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc12
1
22 3
2
0 19 3 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc13
1
22 4
2
0 19 4 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc14
1
22 5
2
0 19 5 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc15
1
22 6
2
0 19 6 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc16
1
22 7
2
0 19 7 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc17
1
22 8
2
0 19 8 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc18
1
22 9
2
0 19 9 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc19
1
22 10
2
0 19 10 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc2
1
22 11
2
0 19 11 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc20
1
22 12
2
0 19 12 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc21
1
22 13
2
0 19 13 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc22
1
22 14
2
0 19 14 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc23
1
22 15
2
0 19 15 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc24
1
22 16
2
0 19 16 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc3
1
22 17
2
0 19 17 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc4
1
22 18
2
0 19 18 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc5
1
22 19
2
0 19 19 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc6
1
22 20
2
0 19 20 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc7
1
22 21
2
0 19 21 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc8
1
22 22
2
0 19 22 24
0 47 0 1
1
end_operator
begin_operator
board car7 loc9
1
22 23
2
0 19 23 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc1
1
22 0
2
0 21 0 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc10
1
22 1
2
0 21 1 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc11
1
22 2
2
0 21 2 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc12
1
22 3
2
0 21 3 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc13
1
22 4
2
0 21 4 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc14
1
22 5
2
0 21 5 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc15
1
22 6
2
0 21 6 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc16
1
22 7
2
0 21 7 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc17
1
22 8
2
0 21 8 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc18
1
22 9
2
0 21 9 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc19
1
22 10
2
0 21 10 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc2
1
22 11
2
0 21 11 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc20
1
22 12
2
0 21 12 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc21
1
22 13
2
0 21 13 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc22
1
22 14
2
0 21 14 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc23
1
22 15
2
0 21 15 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc24
1
22 16
2
0 21 16 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc3
1
22 17
2
0 21 17 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc4
1
22 18
2
0 21 18 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc5
1
22 19
2
0 21 19 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc6
1
22 20
2
0 21 20 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc7
1
22 21
2
0 21 21 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc8
1
22 22
2
0 21 22 24
0 47 0 1
1
end_operator
begin_operator
board car8 loc9
1
22 23
2
0 21 23 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc1
1
22 0
2
0 1 0 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc10
1
22 1
2
0 1 1 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc11
1
22 2
2
0 1 2 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc12
1
22 3
2
0 1 3 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc13
1
22 4
2
0 1 4 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc14
1
22 5
2
0 1 5 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc15
1
22 6
2
0 1 6 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc16
1
22 7
2
0 1 7 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc17
1
22 8
2
0 1 8 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc18
1
22 9
2
0 1 9 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc19
1
22 10
2
0 1 10 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc2
1
22 11
2
0 1 11 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc20
1
22 12
2
0 1 12 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc21
1
22 13
2
0 1 13 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc22
1
22 14
2
0 1 14 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc23
1
22 15
2
0 1 15 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc24
1
22 16
2
0 1 16 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc3
1
22 17
2
0 1 17 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc4
1
22 18
2
0 1 18 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc5
1
22 19
2
0 1 19 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc6
1
22 20
2
0 1 20 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc7
1
22 21
2
0 1 21 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc8
1
22 22
2
0 1 22 24
0 47 0 1
1
end_operator
begin_operator
board car9 loc9
1
22 23
2
0 1 23 24
0 47 0 1
1
end_operator
begin_operator
debark car1 loc1
1
22 0
2
0 2 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
22 1
2
0 2 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc11
1
22 2
2
0 2 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc12
1
22 3
2
0 2 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc13
1
22 4
2
0 2 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc14
1
22 5
2
0 2 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc15
1
22 6
2
0 2 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc16
1
22 7
2
0 2 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc17
1
22 8
2
0 2 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc18
1
22 9
2
0 2 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc19
1
22 10
2
0 2 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
22 11
2
0 2 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc20
1
22 12
2
0 2 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc21
1
22 13
2
0 2 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc22
1
22 14
2
0 2 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc23
1
22 15
2
0 2 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc24
1
22 16
2
0 2 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
22 17
2
0 2 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
22 18
2
0 2 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
22 19
2
0 2 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
22 20
2
0 2 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc7
1
22 21
2
0 2 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc8
1
22 22
2
0 2 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car1 loc9
1
22 23
2
0 2 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc1
1
22 0
2
0 4 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
22 1
2
0 4 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc11
1
22 2
2
0 4 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc12
1
22 3
2
0 4 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc13
1
22 4
2
0 4 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc14
1
22 5
2
0 4 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc15
1
22 6
2
0 4 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc16
1
22 7
2
0 4 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc17
1
22 8
2
0 4 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc18
1
22 9
2
0 4 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc19
1
22 10
2
0 4 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc2
1
22 11
2
0 4 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc20
1
22 12
2
0 4 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc21
1
22 13
2
0 4 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc22
1
22 14
2
0 4 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc23
1
22 15
2
0 4 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc24
1
22 16
2
0 4 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc3
1
22 17
2
0 4 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc4
1
22 18
2
0 4 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc5
1
22 19
2
0 4 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc6
1
22 20
2
0 4 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc7
1
22 21
2
0 4 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc8
1
22 22
2
0 4 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car10 loc9
1
22 23
2
0 4 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc1
1
22 0
2
0 6 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
22 1
2
0 6 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc11
1
22 2
2
0 6 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc12
1
22 3
2
0 6 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc13
1
22 4
2
0 6 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc14
1
22 5
2
0 6 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc15
1
22 6
2
0 6 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc16
1
22 7
2
0 6 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc17
1
22 8
2
0 6 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc18
1
22 9
2
0 6 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc19
1
22 10
2
0 6 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc2
1
22 11
2
0 6 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc20
1
22 12
2
0 6 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc21
1
22 13
2
0 6 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc22
1
22 14
2
0 6 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc23
1
22 15
2
0 6 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc24
1
22 16
2
0 6 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc3
1
22 17
2
0 6 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc4
1
22 18
2
0 6 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc5
1
22 19
2
0 6 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc6
1
22 20
2
0 6 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc7
1
22 21
2
0 6 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc8
1
22 22
2
0 6 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car11 loc9
1
22 23
2
0 6 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc1
1
22 0
2
0 8 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
22 1
2
0 8 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc11
1
22 2
2
0 8 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc12
1
22 3
2
0 8 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc13
1
22 4
2
0 8 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc14
1
22 5
2
0 8 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc15
1
22 6
2
0 8 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc16
1
22 7
2
0 8 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc17
1
22 8
2
0 8 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc18
1
22 9
2
0 8 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc19
1
22 10
2
0 8 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc2
1
22 11
2
0 8 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc20
1
22 12
2
0 8 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc21
1
22 13
2
0 8 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc22
1
22 14
2
0 8 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc23
1
22 15
2
0 8 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc24
1
22 16
2
0 8 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc3
1
22 17
2
0 8 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc4
1
22 18
2
0 8 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc5
1
22 19
2
0 8 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc6
1
22 20
2
0 8 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc7
1
22 21
2
0 8 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc8
1
22 22
2
0 8 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car12 loc9
1
22 23
2
0 8 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc1
1
22 0
2
0 10 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
22 1
2
0 10 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc11
1
22 2
2
0 10 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc12
1
22 3
2
0 10 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc13
1
22 4
2
0 10 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc14
1
22 5
2
0 10 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc15
1
22 6
2
0 10 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc16
1
22 7
2
0 10 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc17
1
22 8
2
0 10 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc18
1
22 9
2
0 10 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc19
1
22 10
2
0 10 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc2
1
22 11
2
0 10 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc20
1
22 12
2
0 10 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc21
1
22 13
2
0 10 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc22
1
22 14
2
0 10 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc23
1
22 15
2
0 10 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc24
1
22 16
2
0 10 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc3
1
22 17
2
0 10 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc4
1
22 18
2
0 10 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc5
1
22 19
2
0 10 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc6
1
22 20
2
0 10 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc7
1
22 21
2
0 10 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc8
1
22 22
2
0 10 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car13 loc9
1
22 23
2
0 10 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc1
1
22 0
2
0 12 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc10
1
22 1
2
0 12 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc11
1
22 2
2
0 12 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc12
1
22 3
2
0 12 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc13
1
22 4
2
0 12 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc14
1
22 5
2
0 12 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc15
1
22 6
2
0 12 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc16
1
22 7
2
0 12 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc17
1
22 8
2
0 12 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc18
1
22 9
2
0 12 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc19
1
22 10
2
0 12 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc2
1
22 11
2
0 12 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc20
1
22 12
2
0 12 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc21
1
22 13
2
0 12 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc22
1
22 14
2
0 12 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc23
1
22 15
2
0 12 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc24
1
22 16
2
0 12 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc3
1
22 17
2
0 12 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc4
1
22 18
2
0 12 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc5
1
22 19
2
0 12 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc6
1
22 20
2
0 12 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc7
1
22 21
2
0 12 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc8
1
22 22
2
0 12 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car14 loc9
1
22 23
2
0 12 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc1
1
22 0
2
0 14 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc10
1
22 1
2
0 14 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc11
1
22 2
2
0 14 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc12
1
22 3
2
0 14 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc13
1
22 4
2
0 14 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc14
1
22 5
2
0 14 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc15
1
22 6
2
0 14 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc16
1
22 7
2
0 14 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc17
1
22 8
2
0 14 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc18
1
22 9
2
0 14 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc19
1
22 10
2
0 14 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc2
1
22 11
2
0 14 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc20
1
22 12
2
0 14 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc21
1
22 13
2
0 14 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc22
1
22 14
2
0 14 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc23
1
22 15
2
0 14 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc24
1
22 16
2
0 14 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc3
1
22 17
2
0 14 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc4
1
22 18
2
0 14 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc5
1
22 19
2
0 14 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc6
1
22 20
2
0 14 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc7
1
22 21
2
0 14 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc8
1
22 22
2
0 14 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car15 loc9
1
22 23
2
0 14 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc1
1
22 0
2
0 16 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc10
1
22 1
2
0 16 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc11
1
22 2
2
0 16 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc12
1
22 3
2
0 16 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc13
1
22 4
2
0 16 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc14
1
22 5
2
0 16 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc15
1
22 6
2
0 16 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc16
1
22 7
2
0 16 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc17
1
22 8
2
0 16 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc18
1
22 9
2
0 16 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc19
1
22 10
2
0 16 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc2
1
22 11
2
0 16 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc20
1
22 12
2
0 16 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc21
1
22 13
2
0 16 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc22
1
22 14
2
0 16 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc23
1
22 15
2
0 16 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc24
1
22 16
2
0 16 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc3
1
22 17
2
0 16 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc4
1
22 18
2
0 16 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc5
1
22 19
2
0 16 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc6
1
22 20
2
0 16 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc7
1
22 21
2
0 16 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc8
1
22 22
2
0 16 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car16 loc9
1
22 23
2
0 16 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc1
1
22 0
2
0 18 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc10
1
22 1
2
0 18 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc11
1
22 2
2
0 18 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc12
1
22 3
2
0 18 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc13
1
22 4
2
0 18 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc14
1
22 5
2
0 18 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc15
1
22 6
2
0 18 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc16
1
22 7
2
0 18 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc17
1
22 8
2
0 18 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc18
1
22 9
2
0 18 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc19
1
22 10
2
0 18 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc2
1
22 11
2
0 18 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc20
1
22 12
2
0 18 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc21
1
22 13
2
0 18 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc22
1
22 14
2
0 18 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc23
1
22 15
2
0 18 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc24
1
22 16
2
0 18 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc3
1
22 17
2
0 18 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc4
1
22 18
2
0 18 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc5
1
22 19
2
0 18 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc6
1
22 20
2
0 18 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc7
1
22 21
2
0 18 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc8
1
22 22
2
0 18 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car17 loc9
1
22 23
2
0 18 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc1
1
22 0
2
0 20 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc10
1
22 1
2
0 20 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc11
1
22 2
2
0 20 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc12
1
22 3
2
0 20 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc13
1
22 4
2
0 20 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc14
1
22 5
2
0 20 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc15
1
22 6
2
0 20 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc16
1
22 7
2
0 20 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc17
1
22 8
2
0 20 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc18
1
22 9
2
0 20 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc19
1
22 10
2
0 20 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc2
1
22 11
2
0 20 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc20
1
22 12
2
0 20 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc21
1
22 13
2
0 20 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc22
1
22 14
2
0 20 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc23
1
22 15
2
0 20 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc24
1
22 16
2
0 20 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc3
1
22 17
2
0 20 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc4
1
22 18
2
0 20 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc5
1
22 19
2
0 20 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc6
1
22 20
2
0 20 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc7
1
22 21
2
0 20 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc8
1
22 22
2
0 20 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car18 loc9
1
22 23
2
0 20 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc1
1
22 0
2
0 0 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc10
1
22 1
2
0 0 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc11
1
22 2
2
0 0 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc12
1
22 3
2
0 0 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc13
1
22 4
2
0 0 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc14
1
22 5
2
0 0 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc15
1
22 6
2
0 0 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc16
1
22 7
2
0 0 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc17
1
22 8
2
0 0 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc18
1
22 9
2
0 0 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc19
1
22 10
2
0 0 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc2
1
22 11
2
0 0 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc20
1
22 12
2
0 0 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc21
1
22 13
2
0 0 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc22
1
22 14
2
0 0 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc23
1
22 15
2
0 0 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc24
1
22 16
2
0 0 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc3
1
22 17
2
0 0 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc4
1
22 18
2
0 0 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc5
1
22 19
2
0 0 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc6
1
22 20
2
0 0 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc7
1
22 21
2
0 0 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc8
1
22 22
2
0 0 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car19 loc9
1
22 23
2
0 0 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
22 0
2
0 3 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
22 1
2
0 3 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc11
1
22 2
2
0 3 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc12
1
22 3
2
0 3 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc13
1
22 4
2
0 3 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc14
1
22 5
2
0 3 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc15
1
22 6
2
0 3 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc16
1
22 7
2
0 3 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc17
1
22 8
2
0 3 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc18
1
22 9
2
0 3 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc19
1
22 10
2
0 3 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
22 11
2
0 3 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc20
1
22 12
2
0 3 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc21
1
22 13
2
0 3 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc22
1
22 14
2
0 3 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc23
1
22 15
2
0 3 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc24
1
22 16
2
0 3 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
22 17
2
0 3 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
22 18
2
0 3 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
22 19
2
0 3 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
22 20
2
0 3 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc7
1
22 21
2
0 3 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc8
1
22 22
2
0 3 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car2 loc9
1
22 23
2
0 3 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc1
1
22 0
2
0 5 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc10
1
22 1
2
0 5 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc11
1
22 2
2
0 5 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc12
1
22 3
2
0 5 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc13
1
22 4
2
0 5 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc14
1
22 5
2
0 5 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc15
1
22 6
2
0 5 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc16
1
22 7
2
0 5 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc17
1
22 8
2
0 5 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc18
1
22 9
2
0 5 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc19
1
22 10
2
0 5 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc2
1
22 11
2
0 5 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc20
1
22 12
2
0 5 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc21
1
22 13
2
0 5 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc22
1
22 14
2
0 5 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc23
1
22 15
2
0 5 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc24
1
22 16
2
0 5 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc3
1
22 17
2
0 5 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc4
1
22 18
2
0 5 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc5
1
22 19
2
0 5 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc6
1
22 20
2
0 5 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc7
1
22 21
2
0 5 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc8
1
22 22
2
0 5 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car20 loc9
1
22 23
2
0 5 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc1
1
22 0
2
0 7 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc10
1
22 1
2
0 7 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc11
1
22 2
2
0 7 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc12
1
22 3
2
0 7 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc13
1
22 4
2
0 7 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc14
1
22 5
2
0 7 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc15
1
22 6
2
0 7 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc16
1
22 7
2
0 7 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc17
1
22 8
2
0 7 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc18
1
22 9
2
0 7 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc19
1
22 10
2
0 7 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc2
1
22 11
2
0 7 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc20
1
22 12
2
0 7 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc21
1
22 13
2
0 7 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc22
1
22 14
2
0 7 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc23
1
22 15
2
0 7 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc24
1
22 16
2
0 7 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc3
1
22 17
2
0 7 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc4
1
22 18
2
0 7 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc5
1
22 19
2
0 7 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc6
1
22 20
2
0 7 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc7
1
22 21
2
0 7 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc8
1
22 22
2
0 7 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car21 loc9
1
22 23
2
0 7 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc1
1
22 0
2
0 9 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc10
1
22 1
2
0 9 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc11
1
22 2
2
0 9 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc12
1
22 3
2
0 9 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc13
1
22 4
2
0 9 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc14
1
22 5
2
0 9 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc15
1
22 6
2
0 9 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc16
1
22 7
2
0 9 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc17
1
22 8
2
0 9 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc18
1
22 9
2
0 9 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc19
1
22 10
2
0 9 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc2
1
22 11
2
0 9 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc20
1
22 12
2
0 9 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc21
1
22 13
2
0 9 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc22
1
22 14
2
0 9 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc23
1
22 15
2
0 9 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc24
1
22 16
2
0 9 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc3
1
22 17
2
0 9 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc4
1
22 18
2
0 9 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc5
1
22 19
2
0 9 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc6
1
22 20
2
0 9 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc7
1
22 21
2
0 9 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc8
1
22 22
2
0 9 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car22 loc9
1
22 23
2
0 9 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
22 0
2
0 11 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
22 1
2
0 11 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc11
1
22 2
2
0 11 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc12
1
22 3
2
0 11 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc13
1
22 4
2
0 11 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc14
1
22 5
2
0 11 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc15
1
22 6
2
0 11 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc16
1
22 7
2
0 11 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc17
1
22 8
2
0 11 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc18
1
22 9
2
0 11 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc19
1
22 10
2
0 11 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
22 11
2
0 11 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc20
1
22 12
2
0 11 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc21
1
22 13
2
0 11 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc22
1
22 14
2
0 11 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc23
1
22 15
2
0 11 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc24
1
22 16
2
0 11 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
22 17
2
0 11 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
22 18
2
0 11 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
22 19
2
0 11 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
22 20
2
0 11 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc7
1
22 21
2
0 11 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc8
1
22 22
2
0 11 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car3 loc9
1
22 23
2
0 11 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc1
1
22 0
2
0 13 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
22 1
2
0 13 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc11
1
22 2
2
0 13 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc12
1
22 3
2
0 13 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc13
1
22 4
2
0 13 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc14
1
22 5
2
0 13 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc15
1
22 6
2
0 13 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc16
1
22 7
2
0 13 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc17
1
22 8
2
0 13 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc18
1
22 9
2
0 13 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc19
1
22 10
2
0 13 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc2
1
22 11
2
0 13 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc20
1
22 12
2
0 13 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc21
1
22 13
2
0 13 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc22
1
22 14
2
0 13 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc23
1
22 15
2
0 13 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc24
1
22 16
2
0 13 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc3
1
22 17
2
0 13 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc4
1
22 18
2
0 13 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc5
1
22 19
2
0 13 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc6
1
22 20
2
0 13 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc7
1
22 21
2
0 13 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc8
1
22 22
2
0 13 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car4 loc9
1
22 23
2
0 13 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc1
1
22 0
2
0 15 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
22 1
2
0 15 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc11
1
22 2
2
0 15 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc12
1
22 3
2
0 15 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc13
1
22 4
2
0 15 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc14
1
22 5
2
0 15 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc15
1
22 6
2
0 15 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc16
1
22 7
2
0 15 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc17
1
22 8
2
0 15 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc18
1
22 9
2
0 15 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc19
1
22 10
2
0 15 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc2
1
22 11
2
0 15 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc20
1
22 12
2
0 15 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc21
1
22 13
2
0 15 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc22
1
22 14
2
0 15 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc23
1
22 15
2
0 15 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc24
1
22 16
2
0 15 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc3
1
22 17
2
0 15 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc4
1
22 18
2
0 15 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc5
1
22 19
2
0 15 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc6
1
22 20
2
0 15 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc7
1
22 21
2
0 15 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc8
1
22 22
2
0 15 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car5 loc9
1
22 23
2
0 15 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc1
1
22 0
2
0 17 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
22 1
2
0 17 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc11
1
22 2
2
0 17 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc12
1
22 3
2
0 17 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc13
1
22 4
2
0 17 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc14
1
22 5
2
0 17 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc15
1
22 6
2
0 17 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc16
1
22 7
2
0 17 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc17
1
22 8
2
0 17 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc18
1
22 9
2
0 17 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc19
1
22 10
2
0 17 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc2
1
22 11
2
0 17 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc20
1
22 12
2
0 17 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc21
1
22 13
2
0 17 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc22
1
22 14
2
0 17 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc23
1
22 15
2
0 17 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc24
1
22 16
2
0 17 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc3
1
22 17
2
0 17 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc4
1
22 18
2
0 17 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc5
1
22 19
2
0 17 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc6
1
22 20
2
0 17 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc7
1
22 21
2
0 17 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc8
1
22 22
2
0 17 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car6 loc9
1
22 23
2
0 17 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc1
1
22 0
2
0 19 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
22 1
2
0 19 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc11
1
22 2
2
0 19 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc12
1
22 3
2
0 19 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc13
1
22 4
2
0 19 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc14
1
22 5
2
0 19 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc15
1
22 6
2
0 19 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc16
1
22 7
2
0 19 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc17
1
22 8
2
0 19 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc18
1
22 9
2
0 19 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc19
1
22 10
2
0 19 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc2
1
22 11
2
0 19 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc20
1
22 12
2
0 19 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc21
1
22 13
2
0 19 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc22
1
22 14
2
0 19 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc23
1
22 15
2
0 19 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc24
1
22 16
2
0 19 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc3
1
22 17
2
0 19 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc4
1
22 18
2
0 19 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc5
1
22 19
2
0 19 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc6
1
22 20
2
0 19 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc7
1
22 21
2
0 19 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc8
1
22 22
2
0 19 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car7 loc9
1
22 23
2
0 19 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc1
1
22 0
2
0 21 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
22 1
2
0 21 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc11
1
22 2
2
0 21 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc12
1
22 3
2
0 21 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc13
1
22 4
2
0 21 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc14
1
22 5
2
0 21 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc15
1
22 6
2
0 21 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc16
1
22 7
2
0 21 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc17
1
22 8
2
0 21 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc18
1
22 9
2
0 21 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc19
1
22 10
2
0 21 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc2
1
22 11
2
0 21 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc20
1
22 12
2
0 21 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc21
1
22 13
2
0 21 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc22
1
22 14
2
0 21 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc23
1
22 15
2
0 21 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc24
1
22 16
2
0 21 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc3
1
22 17
2
0 21 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc4
1
22 18
2
0 21 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc5
1
22 19
2
0 21 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc6
1
22 20
2
0 21 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc7
1
22 21
2
0 21 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc8
1
22 22
2
0 21 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car8 loc9
1
22 23
2
0 21 24 23
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc1
1
22 0
2
0 1 24 0
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
22 1
2
0 1 24 1
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc11
1
22 2
2
0 1 24 2
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc12
1
22 3
2
0 1 24 3
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc13
1
22 4
2
0 1 24 4
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc14
1
22 5
2
0 1 24 5
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc15
1
22 6
2
0 1 24 6
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc16
1
22 7
2
0 1 24 7
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc17
1
22 8
2
0 1 24 8
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc18
1
22 9
2
0 1 24 9
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc19
1
22 10
2
0 1 24 10
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc2
1
22 11
2
0 1 24 11
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc20
1
22 12
2
0 1 24 12
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc21
1
22 13
2
0 1 24 13
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc22
1
22 14
2
0 1 24 14
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc23
1
22 15
2
0 1 24 15
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc24
1
22 16
2
0 1 24 16
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc3
1
22 17
2
0 1 24 17
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc4
1
22 18
2
0 1 24 18
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc5
1
22 19
2
0 1 24 19
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc6
1
22 20
2
0 1 24 20
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc7
1
22 21
2
0 1 24 21
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc8
1
22 22
2
0 1 24 22
0 47 -1 0
1
end_operator
begin_operator
debark car9 loc9
1
22 23
2
0 1 24 23
0 47 -1 0
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 22 0 1
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 22 0 2
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 22 0 3
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 22 0 4
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 22 0 5
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 22 0 6
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 22 0 7
0 23 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 22 0 8
0 23 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 22 0 9
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 22 0 10
0 23 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 22 0 11
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 22 0 12
0 23 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 22 0 13
0 23 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc1 loc22
0
3
0 22 0 14
0 23 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc1 loc23
0
3
0 22 0 15
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc1 loc24
0
3
0 22 0 16
0 23 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 22 0 17
0 23 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 22 0 18
0 23 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 22 0 19
0 23 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 22 0 20
0 23 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 22 0 21
0 23 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 22 0 22
0 23 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 22 0 23
0 23 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 22 1 0
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 22 1 2
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 22 1 3
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 22 1 4
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 22 1 5
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 22 1 6
0 24 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 22 1 7
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 22 1 8
0 24 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 22 1 9
0 24 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 22 1 10
0 24 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 22 1 11
0 24 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 22 1 12
0 24 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 22 1 13
0 24 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc10 loc22
0
3
0 22 1 14
0 24 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc10 loc23
0
3
0 22 1 15
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc10 loc24
0
3
0 22 1 16
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 22 1 17
0 24 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 22 1 18
0 24 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 22 1 19
0 24 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 22 1 20
0 24 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 22 1 21
0 24 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 22 1 22
0 24 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 22 1 23
0 24 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 22 2 0
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 22 2 1
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 22 2 3
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 22 2 4
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 22 2 5
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 22 2 6
0 25 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 22 2 7
0 25 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 22 2 8
0 25 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 22 2 9
0 25 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 22 2 10
0 25 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 22 2 11
0 25 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 22 2 12
0 25 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 22 2 13
0 25 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc11 loc22
0
3
0 22 2 14
0 25 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc11 loc23
0
3
0 22 2 15
0 25 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc11 loc24
0
3
0 22 2 16
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 22 2 17
0 25 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 22 2 18
0 25 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 22 2 19
0 25 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 22 2 20
0 25 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 22 2 21
0 25 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 22 2 22
0 25 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 22 2 23
0 25 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 22 3 0
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 22 3 1
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 22 3 2
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 22 3 4
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 22 3 5
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 22 3 6
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 22 3 7
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 22 3 8
0 26 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 22 3 9
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 22 3 10
0 26 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 22 3 11
0 26 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 22 3 12
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 22 3 13
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc12 loc22
0
3
0 22 3 14
0 26 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc12 loc23
0
3
0 22 3 15
0 26 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc12 loc24
0
3
0 22 3 16
0 26 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 22 3 17
0 26 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 22 3 18
0 26 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 22 3 19
0 26 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 22 3 20
0 26 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 22 3 21
0 26 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 22 3 22
0 26 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 22 3 23
0 26 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 22 4 0
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 22 4 1
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 22 4 2
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 22 4 3
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 22 4 5
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 22 4 6
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 22 4 7
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 22 4 8
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 22 4 9
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 22 4 10
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 22 4 11
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 22 4 12
0 27 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 22 4 13
0 27 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc13 loc22
0
3
0 22 4 14
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc13 loc23
0
3
0 22 4 15
0 27 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc13 loc24
0
3
0 22 4 16
0 27 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 22 4 17
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 22 4 18
0 27 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 22 4 19
0 27 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 22 4 20
0 27 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 22 4 21
0 27 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 22 4 22
0 27 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 22 4 23
0 27 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 22 5 0
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 22 5 1
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 22 5 2
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 22 5 3
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 22 5 4
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 22 5 6
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 22 5 7
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 22 5 8
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 22 5 9
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 22 5 10
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 22 5 11
0 28 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 22 5 12
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 22 5 13
0 28 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc14 loc22
0
3
0 22 5 14
0 28 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc14 loc23
0
3
0 22 5 15
0 28 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc14 loc24
0
3
0 22 5 16
0 28 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 22 5 17
0 28 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 22 5 18
0 28 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 22 5 19
0 28 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 22 5 20
0 28 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 22 5 21
0 28 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 22 5 22
0 28 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 22 5 23
0 28 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 22 6 0
0 23 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 22 6 1
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 22 6 2
0 25 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 22 6 3
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 22 6 4
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 22 6 5
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 22 6 7
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 22 6 8
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 22 6 9
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 22 6 10
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 22 6 11
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 22 6 12
0 29 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 22 6 13
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc15 loc22
0
3
0 22 6 14
0 29 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc15 loc23
0
3
0 22 6 15
0 29 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc15 loc24
0
3
0 22 6 16
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 22 6 17
0 29 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 22 6 18
0 29 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 22 6 19
0 29 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 22 6 20
0 29 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 22 6 21
0 29 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 22 6 22
0 29 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 22 6 23
0 29 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 22 7 0
0 23 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 22 7 1
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 22 7 2
0 25 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 22 7 3
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 22 7 4
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 22 7 5
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 22 7 6
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 22 7 8
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 22 7 9
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 22 7 10
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 22 7 11
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 22 7 12
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 22 7 13
0 30 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc16 loc22
0
3
0 22 7 14
0 30 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc16 loc23
0
3
0 22 7 15
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc16 loc24
0
3
0 22 7 16
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 22 7 17
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 22 7 18
0 30 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 22 7 19
0 30 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 22 7 20
0 30 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 22 7 21
0 30 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 22 7 22
0 30 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 22 7 23
0 30 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 22 8 0
0 23 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 22 8 1
0 24 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 22 8 2
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 22 8 3
0 26 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 22 8 4
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 22 8 5
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 22 8 6
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 22 8 7
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 22 8 9
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 22 8 10
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 22 8 11
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 22 8 12
0 31 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 22 8 13
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc17 loc22
0
3
0 22 8 14
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc17 loc23
0
3
0 22 8 15
0 31 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc17 loc24
0
3
0 22 8 16
0 31 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 22 8 17
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 22 8 18
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 22 8 19
0 31 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 22 8 20
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 22 8 21
0 31 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 22 8 22
0 31 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 22 8 23
0 31 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 22 9 0
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 22 9 1
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 22 9 2
0 25 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 22 9 3
0 26 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 22 9 4
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 22 9 5
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 22 9 6
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 22 9 7
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 22 9 8
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 22 9 10
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 22 9 11
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 22 9 12
0 32 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 22 9 13
0 32 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc18 loc22
0
3
0 22 9 14
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc18 loc23
0
3
0 22 9 15
0 32 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc18 loc24
0
3
0 22 9 16
0 32 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 22 9 17
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 22 9 18
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 22 9 19
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 22 9 20
0 32 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 22 9 21
0 32 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 22 9 22
0 32 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 22 9 23
0 32 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 22 10 0
0 23 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 22 10 1
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 22 10 2
0 25 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 22 10 3
0 26 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 22 10 4
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 22 10 5
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 22 10 6
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 22 10 7
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 22 10 8
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 22 10 9
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 22 10 11
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 22 10 12
0 33 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 22 10 13
0 33 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc19 loc22
0
3
0 22 10 14
0 33 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc19 loc23
0
3
0 22 10 15
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc19 loc24
0
3
0 22 10 16
0 33 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 22 10 17
0 33 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 22 10 18
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 22 10 19
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 22 10 20
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 22 10 21
0 33 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 22 10 22
0 33 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 22 10 23
0 33 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 22 11 0
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 22 11 1
0 24 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 22 11 2
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 22 11 3
0 26 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 22 11 4
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 22 11 5
0 28 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 22 11 6
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 22 11 7
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 22 11 8
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 22 11 9
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 22 11 10
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 22 11 12
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 22 11 13
0 34 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc2 loc22
0
3
0 22 11 14
0 34 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc2 loc23
0
3
0 22 11 15
0 34 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc2 loc24
0
3
0 22 11 16
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 22 11 17
0 34 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 22 11 18
0 34 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 22 11 19
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 22 11 20
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 22 11 21
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 22 11 22
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 22 11 23
0 34 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 22 12 0
0 23 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 22 12 1
0 24 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 22 12 2
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 22 12 3
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 22 12 4
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 22 12 5
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 22 12 6
0 29 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 22 12 7
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 22 12 8
0 31 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 22 12 9
0 32 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 22 12 10
0 33 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 22 12 11
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 22 12 13
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
sail loc20 loc22
0
3
0 22 12 14
0 35 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc20 loc23
0
3
0 22 12 15
0 35 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc20 loc24
0
3
0 22 12 16
0 35 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 22 12 17
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 22 12 18
0 35 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 22 12 19
0 35 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 22 12 20
0 35 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 22 12 21
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 22 12 22
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 22 12 23
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 22 13 0
0 23 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 22 13 1
0 24 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 22 13 2
0 25 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 22 13 3
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 22 13 4
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 22 13 5
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 22 13 6
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 22 13 7
0 30 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 22 13 8
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 22 13 9
0 32 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 22 13 10
0 33 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 22 13 11
0 34 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 22 13 12
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
sail loc21 loc22
0
3
0 22 13 14
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
sail loc21 loc23
0
3
0 22 13 15
0 36 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc21 loc24
0
3
0 22 13 16
0 36 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 22 13 17
0 36 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 22 13 18
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 22 13 19
0 36 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 22 13 20
0 36 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 22 13 21
0 36 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 22 13 22
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 22 13 23
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc22 loc1
0
3
0 22 14 0
0 23 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc10
0
3
0 22 14 1
0 24 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc11
0
3
0 22 14 2
0 25 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc12
0
3
0 22 14 3
0 26 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc13
0
3
0 22 14 4
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc14
0
3
0 22 14 5
0 28 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc15
0
3
0 22 14 6
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc16
0
3
0 22 14 7
0 30 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc17
0
3
0 22 14 8
0 31 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc18
0
3
0 22 14 9
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc19
0
3
0 22 14 10
0 33 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc2
0
3
0 22 14 11
0 34 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc20
0
3
0 22 14 12
0 35 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc21
0
3
0 22 14 13
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
sail loc22 loc23
0
3
0 22 14 15
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
sail loc22 loc24
0
3
0 22 14 16
0 37 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc22 loc3
0
3
0 22 14 17
0 37 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc22 loc4
0
3
0 22 14 18
0 37 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc22 loc5
0
3
0 22 14 19
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc22 loc6
0
3
0 22 14 20
0 37 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc22 loc7
0
3
0 22 14 21
0 37 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc22 loc8
0
3
0 22 14 22
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc22 loc9
0
3
0 22 14 23
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc23 loc1
0
3
0 22 15 0
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc10
0
3
0 22 15 1
0 24 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc11
0
3
0 22 15 2
0 25 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc12
0
3
0 22 15 3
0 26 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc13
0
3
0 22 15 4
0 27 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc14
0
3
0 22 15 5
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc15
0
3
0 22 15 6
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc16
0
3
0 22 15 7
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc17
0
3
0 22 15 8
0 31 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc18
0
3
0 22 15 9
0 32 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc19
0
3
0 22 15 10
0 33 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc2
0
3
0 22 15 11
0 34 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc20
0
3
0 22 15 12
0 35 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc21
0
3
0 22 15 13
0 36 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc22
0
3
0 22 15 14
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
sail loc23 loc24
0
3
0 22 15 16
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
sail loc23 loc3
0
3
0 22 15 17
0 38 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc23 loc4
0
3
0 22 15 18
0 38 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc23 loc5
0
3
0 22 15 19
0 38 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc23 loc6
0
3
0 22 15 20
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc23 loc7
0
3
0 22 15 21
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc23 loc8
0
3
0 22 15 22
0 38 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc23 loc9
0
3
0 22 15 23
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc24 loc1
0
3
0 22 16 0
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc10
0
3
0 22 16 1
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc11
0
3
0 22 16 2
0 25 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc12
0
3
0 22 16 3
0 26 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc13
0
3
0 22 16 4
0 27 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc14
0
3
0 22 16 5
0 28 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc15
0
3
0 22 16 6
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc16
0
3
0 22 16 7
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc17
0
3
0 22 16 8
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc18
0
3
0 22 16 9
0 32 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc19
0
3
0 22 16 10
0 33 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc2
0
3
0 22 16 11
0 34 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc20
0
3
0 22 16 12
0 35 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc21
0
3
0 22 16 13
0 36 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc22
0
3
0 22 16 14
0 37 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc23
0
3
0 22 16 15
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
sail loc24 loc3
0
3
0 22 16 17
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
sail loc24 loc4
0
3
0 22 16 18
0 39 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc24 loc5
0
3
0 22 16 19
0 39 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc24 loc6
0
3
0 22 16 20
0 39 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc24 loc7
0
3
0 22 16 21
0 39 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc24 loc8
0
3
0 22 16 22
0 39 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc24 loc9
0
3
0 22 16 23
0 39 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 22 17 0
0 23 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 22 17 1
0 24 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 22 17 2
0 25 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 22 17 3
0 26 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 22 17 4
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 22 17 5
0 28 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 22 17 6
0 29 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 22 17 7
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 22 17 8
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 22 17 9
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 22 17 10
0 33 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 22 17 11
0 34 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 22 17 12
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 22 17 13
0 36 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc22
0
3
0 22 17 14
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc23
0
3
0 22 17 15
0 38 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc24
0
3
0 22 17 16
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 22 17 18
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 22 17 19
0 40 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 22 17 20
0 40 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 22 17 21
0 40 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 22 17 22
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 22 17 23
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 22 18 0
0 23 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 22 18 1
0 24 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 22 18 2
0 25 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 22 18 3
0 26 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 22 18 4
0 27 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 22 18 5
0 28 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 22 18 6
0 29 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 22 18 7
0 30 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 22 18 8
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 22 18 9
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 22 18 10
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 22 18 11
0 34 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 22 18 12
0 35 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 22 18 13
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc22
0
3
0 22 18 14
0 37 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc23
0
3
0 22 18 15
0 38 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc24
0
3
0 22 18 16
0 39 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 22 18 17
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 22 18 19
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 22 18 20
0 41 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 22 18 21
0 41 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 22 18 22
0 41 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 22 18 23
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 22 19 0
0 23 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 22 19 1
0 24 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 22 19 2
0 25 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 22 19 3
0 26 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 22 19 4
0 27 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 22 19 5
0 28 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 22 19 6
0 29 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 22 19 7
0 30 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 22 19 8
0 31 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 22 19 9
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 22 19 10
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 22 19 11
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 22 19 12
0 35 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 22 19 13
0 36 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc22
0
3
0 22 19 14
0 37 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc23
0
3
0 22 19 15
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc24
0
3
0 22 19 16
0 39 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 22 19 17
0 40 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 22 19 18
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 22 19 20
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 22 19 21
0 42 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 22 19 22
0 42 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 22 19 23
0 42 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 22 20 0
0 23 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 22 20 1
0 24 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 22 20 2
0 25 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 22 20 3
0 26 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 22 20 4
0 27 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 22 20 5
0 28 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 22 20 6
0 29 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 22 20 7
0 30 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 22 20 8
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 22 20 9
0 32 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 22 20 10
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 22 20 11
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 22 20 12
0 35 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 22 20 13
0 36 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc22
0
3
0 22 20 14
0 37 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc23
0
3
0 22 20 15
0 38 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc24
0
3
0 22 20 16
0 39 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 22 20 17
0 40 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 22 20 18
0 41 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 22 20 19
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 22 20 21
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 22 20 22
0 43 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 22 20 23
0 43 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 22 21 0
0 23 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 22 21 1
0 24 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 22 21 2
0 25 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 22 21 3
0 26 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 22 21 4
0 27 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 22 21 5
0 28 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 22 21 6
0 29 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 22 21 7
0 30 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 22 21 8
0 31 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 22 21 9
0 32 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 22 21 10
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 22 21 11
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 22 21 12
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 22 21 13
0 36 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc22
0
3
0 22 21 14
0 37 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc23
0
3
0 22 21 15
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc24
0
3
0 22 21 16
0 39 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 22 21 17
0 40 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 22 21 18
0 41 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 22 21 19
0 42 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 22 21 20
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 22 21 22
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 22 21 23
0 44 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 22 22 0
0 23 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 22 22 1
0 24 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 22 22 2
0 25 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 22 22 3
0 26 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 22 22 4
0 27 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 22 22 5
0 28 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 22 22 6
0 29 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 22 22 7
0 30 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 22 22 8
0 31 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 22 22 9
0 32 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 22 22 10
0 33 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 22 22 11
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 22 22 12
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 22 22 13
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc22
0
3
0 22 22 14
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc23
0
3
0 22 22 15
0 38 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc24
0
3
0 22 22 16
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 22 22 17
0 40 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 22 22 18
0 41 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 22 22 19
0 42 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 22 22 20
0 43 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 22 22 21
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 22 22 23
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 22 23 0
0 23 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 22 23 1
0 24 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 22 23 2
0 25 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 22 23 3
0 26 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 22 23 4
0 27 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 22 23 5
0 28 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 22 23 6
0 29 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 22 23 7
0 30 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 22 23 8
0 31 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 22 23 9
0 32 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 22 23 10
0 33 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 22 23 11
0 34 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 22 23 12
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 22 23 13
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc22
0
3
0 22 23 14
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc23
0
3
0 22 23 15
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc24
0
3
0 22 23 16
0 39 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 22 23 17
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 22 23 18
0 41 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 22 23 19
0 42 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 22 23 20
0 43 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 22 23 21
0 44 0 1
0 46 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 22 23 22
0 45 0 1
0 46 -1 0
1
end_operator
0
