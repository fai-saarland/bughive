begin_version
3
end_version
begin_metric
1
end_metric
32
begin_variable
var0
-1
21
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
on car1
end_variable
begin_variable
var1
-1
21
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
on car10
end_variable
begin_variable
var2
-1
21
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
on car2
end_variable
begin_variable
var3
-1
21
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
on car3
end_variable
begin_variable
var4
-1
21
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
on car4
end_variable
begin_variable
var5
-1
21
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
on car5
end_variable
begin_variable
var6
-1
21
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
on car6
end_variable
begin_variable
var7
-1
21
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
on car7
end_variable
begin_variable
var8
-1
21
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
on car8
end_variable
begin_variable
var9
-1
21
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
on car9
end_variable
begin_variable
var10
-1
20
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var11
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var12
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var13
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var14
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
begin_variable
var31
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
12
11
16
1
16
18
8
11
17
9
11
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
end_state
begin_goal
10
0 6
1 15
2 12
3 2
4 11
5 11
6 5
7 18
8 19
9 13
end_goal
780
begin_operator
board car1 loc1
1
10 0
2
0 0 0 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc10
1
10 1
2
0 0 1 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc11
1
10 2
2
0 0 2 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc12
1
10 3
2
0 0 3 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc13
1
10 4
2
0 0 4 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc14
1
10 5
2
0 0 5 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc15
1
10 6
2
0 0 6 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc16
1
10 7
2
0 0 7 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc17
1
10 8
2
0 0 8 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc18
1
10 9
2
0 0 9 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc19
1
10 10
2
0 0 10 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc2
1
10 11
2
0 0 11 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc20
1
10 12
2
0 0 12 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc3
1
10 13
2
0 0 13 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc4
1
10 14
2
0 0 14 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc5
1
10 15
2
0 0 15 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc6
1
10 16
2
0 0 16 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc7
1
10 17
2
0 0 17 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc8
1
10 18
2
0 0 18 20
0 31 0 1
1
end_operator
begin_operator
board car1 loc9
1
10 19
2
0 0 19 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc1
1
10 0
2
0 1 0 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc10
1
10 1
2
0 1 1 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc11
1
10 2
2
0 1 2 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc12
1
10 3
2
0 1 3 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc13
1
10 4
2
0 1 4 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc14
1
10 5
2
0 1 5 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc15
1
10 6
2
0 1 6 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc16
1
10 7
2
0 1 7 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc17
1
10 8
2
0 1 8 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc18
1
10 9
2
0 1 9 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc19
1
10 10
2
0 1 10 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc2
1
10 11
2
0 1 11 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc20
1
10 12
2
0 1 12 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc3
1
10 13
2
0 1 13 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc4
1
10 14
2
0 1 14 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc5
1
10 15
2
0 1 15 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc6
1
10 16
2
0 1 16 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc7
1
10 17
2
0 1 17 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc8
1
10 18
2
0 1 18 20
0 31 0 1
1
end_operator
begin_operator
board car10 loc9
1
10 19
2
0 1 19 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc1
1
10 0
2
0 2 0 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc10
1
10 1
2
0 2 1 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc11
1
10 2
2
0 2 2 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc12
1
10 3
2
0 2 3 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc13
1
10 4
2
0 2 4 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc14
1
10 5
2
0 2 5 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc15
1
10 6
2
0 2 6 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc16
1
10 7
2
0 2 7 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc17
1
10 8
2
0 2 8 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc18
1
10 9
2
0 2 9 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc19
1
10 10
2
0 2 10 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc2
1
10 11
2
0 2 11 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc20
1
10 12
2
0 2 12 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc3
1
10 13
2
0 2 13 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc4
1
10 14
2
0 2 14 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc5
1
10 15
2
0 2 15 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc6
1
10 16
2
0 2 16 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc7
1
10 17
2
0 2 17 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc8
1
10 18
2
0 2 18 20
0 31 0 1
1
end_operator
begin_operator
board car2 loc9
1
10 19
2
0 2 19 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc1
1
10 0
2
0 3 0 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc10
1
10 1
2
0 3 1 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc11
1
10 2
2
0 3 2 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc12
1
10 3
2
0 3 3 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc13
1
10 4
2
0 3 4 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc14
1
10 5
2
0 3 5 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc15
1
10 6
2
0 3 6 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc16
1
10 7
2
0 3 7 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc17
1
10 8
2
0 3 8 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc18
1
10 9
2
0 3 9 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc19
1
10 10
2
0 3 10 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc2
1
10 11
2
0 3 11 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc20
1
10 12
2
0 3 12 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc3
1
10 13
2
0 3 13 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc4
1
10 14
2
0 3 14 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc5
1
10 15
2
0 3 15 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc6
1
10 16
2
0 3 16 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc7
1
10 17
2
0 3 17 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc8
1
10 18
2
0 3 18 20
0 31 0 1
1
end_operator
begin_operator
board car3 loc9
1
10 19
2
0 3 19 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc1
1
10 0
2
0 4 0 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc10
1
10 1
2
0 4 1 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc11
1
10 2
2
0 4 2 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc12
1
10 3
2
0 4 3 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc13
1
10 4
2
0 4 4 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc14
1
10 5
2
0 4 5 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc15
1
10 6
2
0 4 6 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc16
1
10 7
2
0 4 7 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc17
1
10 8
2
0 4 8 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc18
1
10 9
2
0 4 9 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc19
1
10 10
2
0 4 10 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc2
1
10 11
2
0 4 11 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc20
1
10 12
2
0 4 12 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc3
1
10 13
2
0 4 13 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc4
1
10 14
2
0 4 14 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc5
1
10 15
2
0 4 15 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc6
1
10 16
2
0 4 16 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc7
1
10 17
2
0 4 17 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc8
1
10 18
2
0 4 18 20
0 31 0 1
1
end_operator
begin_operator
board car4 loc9
1
10 19
2
0 4 19 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc1
1
10 0
2
0 5 0 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc10
1
10 1
2
0 5 1 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc11
1
10 2
2
0 5 2 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc12
1
10 3
2
0 5 3 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc13
1
10 4
2
0 5 4 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc14
1
10 5
2
0 5 5 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc15
1
10 6
2
0 5 6 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc16
1
10 7
2
0 5 7 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc17
1
10 8
2
0 5 8 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc18
1
10 9
2
0 5 9 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc19
1
10 10
2
0 5 10 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc2
1
10 11
2
0 5 11 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc20
1
10 12
2
0 5 12 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc3
1
10 13
2
0 5 13 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc4
1
10 14
2
0 5 14 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc5
1
10 15
2
0 5 15 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc6
1
10 16
2
0 5 16 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc7
1
10 17
2
0 5 17 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc8
1
10 18
2
0 5 18 20
0 31 0 1
1
end_operator
begin_operator
board car5 loc9
1
10 19
2
0 5 19 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc1
1
10 0
2
0 6 0 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc10
1
10 1
2
0 6 1 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc11
1
10 2
2
0 6 2 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc12
1
10 3
2
0 6 3 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc13
1
10 4
2
0 6 4 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc14
1
10 5
2
0 6 5 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc15
1
10 6
2
0 6 6 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc16
1
10 7
2
0 6 7 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc17
1
10 8
2
0 6 8 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc18
1
10 9
2
0 6 9 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc19
1
10 10
2
0 6 10 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc2
1
10 11
2
0 6 11 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc20
1
10 12
2
0 6 12 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc3
1
10 13
2
0 6 13 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc4
1
10 14
2
0 6 14 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc5
1
10 15
2
0 6 15 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc6
1
10 16
2
0 6 16 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc7
1
10 17
2
0 6 17 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc8
1
10 18
2
0 6 18 20
0 31 0 1
1
end_operator
begin_operator
board car6 loc9
1
10 19
2
0 6 19 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc1
1
10 0
2
0 7 0 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc10
1
10 1
2
0 7 1 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc11
1
10 2
2
0 7 2 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc12
1
10 3
2
0 7 3 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc13
1
10 4
2
0 7 4 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc14
1
10 5
2
0 7 5 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc15
1
10 6
2
0 7 6 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc16
1
10 7
2
0 7 7 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc17
1
10 8
2
0 7 8 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc18
1
10 9
2
0 7 9 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc19
1
10 10
2
0 7 10 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc2
1
10 11
2
0 7 11 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc20
1
10 12
2
0 7 12 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc3
1
10 13
2
0 7 13 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc4
1
10 14
2
0 7 14 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc5
1
10 15
2
0 7 15 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc6
1
10 16
2
0 7 16 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc7
1
10 17
2
0 7 17 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc8
1
10 18
2
0 7 18 20
0 31 0 1
1
end_operator
begin_operator
board car7 loc9
1
10 19
2
0 7 19 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc1
1
10 0
2
0 8 0 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc10
1
10 1
2
0 8 1 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc11
1
10 2
2
0 8 2 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc12
1
10 3
2
0 8 3 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc13
1
10 4
2
0 8 4 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc14
1
10 5
2
0 8 5 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc15
1
10 6
2
0 8 6 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc16
1
10 7
2
0 8 7 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc17
1
10 8
2
0 8 8 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc18
1
10 9
2
0 8 9 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc19
1
10 10
2
0 8 10 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc2
1
10 11
2
0 8 11 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc20
1
10 12
2
0 8 12 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc3
1
10 13
2
0 8 13 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc4
1
10 14
2
0 8 14 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc5
1
10 15
2
0 8 15 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc6
1
10 16
2
0 8 16 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc7
1
10 17
2
0 8 17 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc8
1
10 18
2
0 8 18 20
0 31 0 1
1
end_operator
begin_operator
board car8 loc9
1
10 19
2
0 8 19 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc1
1
10 0
2
0 9 0 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc10
1
10 1
2
0 9 1 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc11
1
10 2
2
0 9 2 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc12
1
10 3
2
0 9 3 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc13
1
10 4
2
0 9 4 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc14
1
10 5
2
0 9 5 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc15
1
10 6
2
0 9 6 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc16
1
10 7
2
0 9 7 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc17
1
10 8
2
0 9 8 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc18
1
10 9
2
0 9 9 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc19
1
10 10
2
0 9 10 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc2
1
10 11
2
0 9 11 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc20
1
10 12
2
0 9 12 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc3
1
10 13
2
0 9 13 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc4
1
10 14
2
0 9 14 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc5
1
10 15
2
0 9 15 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc6
1
10 16
2
0 9 16 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc7
1
10 17
2
0 9 17 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc8
1
10 18
2
0 9 18 20
0 31 0 1
1
end_operator
begin_operator
board car9 loc9
1
10 19
2
0 9 19 20
0 31 0 1
1
end_operator
begin_operator
debark car1 loc1
1
10 0
2
0 0 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
10 1
2
0 0 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc11
1
10 2
2
0 0 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc12
1
10 3
2
0 0 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc13
1
10 4
2
0 0 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc14
1
10 5
2
0 0 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc15
1
10 6
2
0 0 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc16
1
10 7
2
0 0 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc17
1
10 8
2
0 0 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc18
1
10 9
2
0 0 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc19
1
10 10
2
0 0 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
10 11
2
0 0 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc20
1
10 12
2
0 0 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
10 13
2
0 0 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
10 14
2
0 0 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
10 15
2
0 0 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
10 16
2
0 0 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc7
1
10 17
2
0 0 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc8
1
10 18
2
0 0 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car1 loc9
1
10 19
2
0 0 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc1
1
10 0
2
0 1 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
10 1
2
0 1 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc11
1
10 2
2
0 1 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc12
1
10 3
2
0 1 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc13
1
10 4
2
0 1 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc14
1
10 5
2
0 1 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc15
1
10 6
2
0 1 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc16
1
10 7
2
0 1 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc17
1
10 8
2
0 1 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc18
1
10 9
2
0 1 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc19
1
10 10
2
0 1 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc2
1
10 11
2
0 1 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc20
1
10 12
2
0 1 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc3
1
10 13
2
0 1 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc4
1
10 14
2
0 1 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc5
1
10 15
2
0 1 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc6
1
10 16
2
0 1 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc7
1
10 17
2
0 1 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc8
1
10 18
2
0 1 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car10 loc9
1
10 19
2
0 1 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
10 0
2
0 2 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
10 1
2
0 2 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc11
1
10 2
2
0 2 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc12
1
10 3
2
0 2 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc13
1
10 4
2
0 2 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc14
1
10 5
2
0 2 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc15
1
10 6
2
0 2 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc16
1
10 7
2
0 2 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc17
1
10 8
2
0 2 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc18
1
10 9
2
0 2 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc19
1
10 10
2
0 2 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
10 11
2
0 2 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc20
1
10 12
2
0 2 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
10 13
2
0 2 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
10 14
2
0 2 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
10 15
2
0 2 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
10 16
2
0 2 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc7
1
10 17
2
0 2 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc8
1
10 18
2
0 2 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car2 loc9
1
10 19
2
0 2 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
10 0
2
0 3 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
10 1
2
0 3 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc11
1
10 2
2
0 3 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc12
1
10 3
2
0 3 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc13
1
10 4
2
0 3 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc14
1
10 5
2
0 3 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc15
1
10 6
2
0 3 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc16
1
10 7
2
0 3 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc17
1
10 8
2
0 3 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc18
1
10 9
2
0 3 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc19
1
10 10
2
0 3 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
10 11
2
0 3 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc20
1
10 12
2
0 3 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
10 13
2
0 3 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
10 14
2
0 3 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
10 15
2
0 3 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
10 16
2
0 3 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc7
1
10 17
2
0 3 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc8
1
10 18
2
0 3 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car3 loc9
1
10 19
2
0 3 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc1
1
10 0
2
0 4 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
10 1
2
0 4 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc11
1
10 2
2
0 4 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc12
1
10 3
2
0 4 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc13
1
10 4
2
0 4 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc14
1
10 5
2
0 4 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc15
1
10 6
2
0 4 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc16
1
10 7
2
0 4 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc17
1
10 8
2
0 4 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc18
1
10 9
2
0 4 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc19
1
10 10
2
0 4 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc2
1
10 11
2
0 4 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc20
1
10 12
2
0 4 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc3
1
10 13
2
0 4 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc4
1
10 14
2
0 4 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc5
1
10 15
2
0 4 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc6
1
10 16
2
0 4 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc7
1
10 17
2
0 4 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc8
1
10 18
2
0 4 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car4 loc9
1
10 19
2
0 4 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc1
1
10 0
2
0 5 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
10 1
2
0 5 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc11
1
10 2
2
0 5 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc12
1
10 3
2
0 5 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc13
1
10 4
2
0 5 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc14
1
10 5
2
0 5 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc15
1
10 6
2
0 5 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc16
1
10 7
2
0 5 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc17
1
10 8
2
0 5 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc18
1
10 9
2
0 5 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc19
1
10 10
2
0 5 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc2
1
10 11
2
0 5 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc20
1
10 12
2
0 5 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc3
1
10 13
2
0 5 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc4
1
10 14
2
0 5 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc5
1
10 15
2
0 5 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc6
1
10 16
2
0 5 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc7
1
10 17
2
0 5 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc8
1
10 18
2
0 5 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car5 loc9
1
10 19
2
0 5 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc1
1
10 0
2
0 6 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
10 1
2
0 6 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc11
1
10 2
2
0 6 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc12
1
10 3
2
0 6 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc13
1
10 4
2
0 6 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc14
1
10 5
2
0 6 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc15
1
10 6
2
0 6 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc16
1
10 7
2
0 6 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc17
1
10 8
2
0 6 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc18
1
10 9
2
0 6 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc19
1
10 10
2
0 6 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc2
1
10 11
2
0 6 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc20
1
10 12
2
0 6 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc3
1
10 13
2
0 6 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc4
1
10 14
2
0 6 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc5
1
10 15
2
0 6 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc6
1
10 16
2
0 6 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc7
1
10 17
2
0 6 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc8
1
10 18
2
0 6 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car6 loc9
1
10 19
2
0 6 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc1
1
10 0
2
0 7 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
10 1
2
0 7 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc11
1
10 2
2
0 7 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc12
1
10 3
2
0 7 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc13
1
10 4
2
0 7 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc14
1
10 5
2
0 7 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc15
1
10 6
2
0 7 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc16
1
10 7
2
0 7 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc17
1
10 8
2
0 7 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc18
1
10 9
2
0 7 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc19
1
10 10
2
0 7 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc2
1
10 11
2
0 7 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc20
1
10 12
2
0 7 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc3
1
10 13
2
0 7 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc4
1
10 14
2
0 7 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc5
1
10 15
2
0 7 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc6
1
10 16
2
0 7 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc7
1
10 17
2
0 7 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc8
1
10 18
2
0 7 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car7 loc9
1
10 19
2
0 7 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc1
1
10 0
2
0 8 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
10 1
2
0 8 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc11
1
10 2
2
0 8 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc12
1
10 3
2
0 8 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc13
1
10 4
2
0 8 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc14
1
10 5
2
0 8 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc15
1
10 6
2
0 8 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc16
1
10 7
2
0 8 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc17
1
10 8
2
0 8 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc18
1
10 9
2
0 8 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc19
1
10 10
2
0 8 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc2
1
10 11
2
0 8 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc20
1
10 12
2
0 8 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc3
1
10 13
2
0 8 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc4
1
10 14
2
0 8 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc5
1
10 15
2
0 8 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc6
1
10 16
2
0 8 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc7
1
10 17
2
0 8 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc8
1
10 18
2
0 8 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car8 loc9
1
10 19
2
0 8 20 19
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc1
1
10 0
2
0 9 20 0
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
10 1
2
0 9 20 1
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc11
1
10 2
2
0 9 20 2
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc12
1
10 3
2
0 9 20 3
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc13
1
10 4
2
0 9 20 4
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc14
1
10 5
2
0 9 20 5
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc15
1
10 6
2
0 9 20 6
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc16
1
10 7
2
0 9 20 7
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc17
1
10 8
2
0 9 20 8
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc18
1
10 9
2
0 9 20 9
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc19
1
10 10
2
0 9 20 10
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc2
1
10 11
2
0 9 20 11
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc20
1
10 12
2
0 9 20 12
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc3
1
10 13
2
0 9 20 13
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc4
1
10 14
2
0 9 20 14
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc5
1
10 15
2
0 9 20 15
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc6
1
10 16
2
0 9 20 16
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc7
1
10 17
2
0 9 20 17
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc8
1
10 18
2
0 9 20 18
0 31 -1 0
1
end_operator
begin_operator
debark car9 loc9
1
10 19
2
0 9 20 19
0 31 -1 0
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 10 0 1
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 10 0 2
0 11 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 10 0 3
0 11 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 10 0 4
0 11 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 10 0 5
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 10 0 6
0 11 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 10 0 7
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 10 0 8
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 10 0 9
0 11 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 10 0 10
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 10 0 11
0 11 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 10 0 12
0 11 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 10 0 13
0 11 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 10 0 14
0 11 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 10 0 15
0 11 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 10 0 16
0 11 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 10 0 17
0 11 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 10 0 18
0 11 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 10 0 19
0 11 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 10 1 0
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 10 1 2
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 10 1 3
0 12 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 10 1 4
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 10 1 5
0 12 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 10 1 6
0 12 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 10 1 7
0 12 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 10 1 8
0 12 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 10 1 9
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 10 1 10
0 12 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 10 1 11
0 12 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 10 1 12
0 12 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 10 1 13
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 10 1 14
0 12 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 10 1 15
0 12 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 10 1 16
0 12 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 10 1 17
0 12 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 10 1 18
0 12 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 10 1 19
0 12 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 10 2 0
0 11 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 10 2 1
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 10 2 3
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 10 2 4
0 13 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 10 2 5
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 10 2 6
0 13 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 10 2 7
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 10 2 8
0 13 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 10 2 9
0 13 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 10 2 10
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 10 2 11
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 10 2 12
0 13 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 10 2 13
0 13 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 10 2 14
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 10 2 15
0 13 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 10 2 16
0 13 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 10 2 17
0 13 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 10 2 18
0 13 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 10 2 19
0 13 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 10 3 0
0 11 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 10 3 1
0 12 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 10 3 2
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 10 3 4
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 10 3 5
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 10 3 6
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 10 3 7
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 10 3 8
0 14 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 10 3 9
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 10 3 10
0 14 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 10 3 11
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 10 3 12
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 10 3 13
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 10 3 14
0 14 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 10 3 15
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 10 3 16
0 14 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 10 3 17
0 14 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 10 3 18
0 14 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 10 3 19
0 14 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 10 4 0
0 11 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 10 4 1
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 10 4 2
0 13 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 10 4 3
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 10 4 5
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 10 4 6
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 10 4 7
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 10 4 8
0 15 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 10 4 9
0 15 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 10 4 10
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 10 4 11
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 10 4 12
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 10 4 13
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 10 4 14
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 10 4 15
0 15 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 10 4 16
0 15 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 10 4 17
0 15 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 10 4 18
0 15 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 10 4 19
0 15 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 10 5 0
0 11 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 10 5 1
0 12 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 10 5 2
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 10 5 3
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 10 5 4
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 10 5 6
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 10 5 7
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 10 5 8
0 16 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 10 5 9
0 16 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 10 5 10
0 16 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 10 5 11
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 10 5 12
0 16 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 10 5 13
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 10 5 14
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 10 5 15
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 10 5 16
0 16 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 10 5 17
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 10 5 18
0 16 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 10 5 19
0 16 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 10 6 0
0 11 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 10 6 1
0 12 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 10 6 2
0 13 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 10 6 3
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 10 6 4
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 10 6 5
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 10 6 7
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 10 6 8
0 17 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 10 6 9
0 17 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 10 6 10
0 17 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 10 6 11
0 17 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 10 6 12
0 17 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 10 6 13
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 10 6 14
0 17 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 10 6 15
0 17 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 10 6 16
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 10 6 17
0 17 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 10 6 18
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 10 6 19
0 17 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 10 7 0
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 10 7 1
0 12 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 10 7 2
0 13 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 10 7 3
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 10 7 4
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 10 7 5
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 10 7 6
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 10 7 8
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 10 7 9
0 18 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 10 7 10
0 18 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 10 7 11
0 18 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 10 7 12
0 18 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 10 7 13
0 18 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 10 7 14
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 10 7 15
0 18 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 10 7 16
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 10 7 17
0 18 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 10 7 18
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 10 7 19
0 18 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 10 8 0
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 10 8 1
0 12 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 10 8 2
0 13 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 10 8 3
0 14 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 10 8 4
0 15 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 10 8 5
0 16 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 10 8 6
0 17 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 10 8 7
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 10 8 9
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 10 8 10
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 10 8 11
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 10 8 12
0 19 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 10 8 13
0 19 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 10 8 14
0 19 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 10 8 15
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 10 8 16
0 19 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 10 8 17
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 10 8 18
0 19 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 10 8 19
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 10 9 0
0 11 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 10 9 1
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 10 9 2
0 13 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 10 9 3
0 14 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 10 9 4
0 15 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 10 9 5
0 16 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 10 9 6
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 10 9 7
0 18 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 10 9 8
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 10 9 10
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 10 9 11
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 10 9 12
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 10 9 13
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 10 9 14
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 10 9 15
0 20 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 10 9 16
0 20 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 10 9 17
0 20 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 10 9 18
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 10 9 19
0 20 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 10 10 0
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 10 10 1
0 12 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 10 10 2
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 10 10 3
0 14 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 10 10 4
0 15 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 10 10 5
0 16 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 10 10 6
0 17 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 10 10 7
0 18 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 10 10 8
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 10 10 9
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 10 10 11
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 10 10 12
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 10 10 13
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 10 10 14
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 10 10 15
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 10 10 16
0 21 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 10 10 17
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 10 10 18
0 21 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 10 10 19
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 10 11 0
0 11 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 10 11 1
0 12 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 10 11 2
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 10 11 3
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 10 11 4
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 10 11 5
0 16 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 10 11 6
0 17 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 10 11 7
0 18 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 10 11 8
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 10 11 9
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 10 11 10
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 10 11 12
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 10 11 13
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 10 11 14
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 10 11 15
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 10 11 16
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 10 11 17
0 22 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 10 11 18
0 22 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 10 11 19
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 10 12 0
0 11 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 10 12 1
0 12 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 10 12 2
0 13 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 10 12 3
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 10 12 4
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 10 12 5
0 16 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 10 12 6
0 17 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 10 12 7
0 18 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 10 12 8
0 19 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 10 12 9
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 10 12 10
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 10 12 11
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 10 12 13
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 10 12 14
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 10 12 15
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 10 12 16
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 10 12 17
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 10 12 18
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 10 12 19
0 23 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 10 13 0
0 11 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 10 13 1
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 10 13 2
0 13 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 10 13 3
0 14 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 10 13 4
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 10 13 5
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 10 13 6
0 17 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 10 13 7
0 18 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 10 13 8
0 19 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 10 13 9
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 10 13 10
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 10 13 11
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 10 13 12
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 10 13 14
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 10 13 15
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 10 13 16
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 10 13 17
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 10 13 18
0 24 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 10 13 19
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 10 14 0
0 11 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 10 14 1
0 12 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 10 14 2
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 10 14 3
0 14 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 10 14 4
0 15 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 10 14 5
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 10 14 6
0 17 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 10 14 7
0 18 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 10 14 8
0 19 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 10 14 9
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 10 14 10
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 10 14 11
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 10 14 12
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 10 14 13
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 10 14 15
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 10 14 16
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 10 14 17
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 10 14 18
0 25 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 10 14 19
0 25 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 10 15 0
0 11 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 10 15 1
0 12 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 10 15 2
0 13 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 10 15 3
0 14 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 10 15 4
0 15 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 10 15 5
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 10 15 6
0 17 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 10 15 7
0 18 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 10 15 8
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 10 15 9
0 20 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 10 15 10
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 10 15 11
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 10 15 12
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 10 15 13
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 10 15 14
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 10 15 16
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 10 15 17
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 10 15 18
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 10 15 19
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 10 16 0
0 11 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 10 16 1
0 12 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 10 16 2
0 13 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 10 16 3
0 14 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 10 16 4
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 10 16 5
0 16 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 10 16 6
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 10 16 7
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 10 16 8
0 19 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 10 16 9
0 20 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 10 16 10
0 21 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 10 16 11
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 10 16 12
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 10 16 13
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 10 16 14
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 10 16 15
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 10 16 17
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 10 16 18
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 10 16 19
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 10 17 0
0 11 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 10 17 1
0 12 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 10 17 2
0 13 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 10 17 3
0 14 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 10 17 4
0 15 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 10 17 5
0 16 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 10 17 6
0 17 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 10 17 7
0 18 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 10 17 8
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 10 17 9
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 10 17 10
0 21 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 10 17 11
0 22 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 10 17 12
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 10 17 13
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 10 17 14
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 10 17 15
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 10 17 16
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 10 17 18
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 10 17 19
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 10 18 0
0 11 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 10 18 1
0 12 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 10 18 2
0 13 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 10 18 3
0 14 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 10 18 4
0 15 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 10 18 5
0 16 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 10 18 6
0 17 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 10 18 7
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 10 18 8
0 19 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 10 18 9
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 10 18 10
0 21 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 10 18 11
0 22 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 10 18 12
0 23 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 10 18 13
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 10 18 14
0 25 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 10 18 15
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 10 18 16
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 10 18 17
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 10 18 19
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 10 19 0
0 11 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 10 19 1
0 12 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 10 19 2
0 13 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 10 19 3
0 14 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 10 19 4
0 15 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 10 19 5
0 16 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 10 19 6
0 17 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 10 19 7
0 18 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 10 19 8
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 10 19 9
0 20 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 10 19 10
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 10 19 11
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 10 19 12
0 23 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 10 19 13
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 10 19 14
0 25 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 10 19 15
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 10 19 16
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 10 19 17
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 10 19 18
0 29 0 1
0 30 -1 0
1
end_operator
0
