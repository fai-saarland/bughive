begin_version
3
end_version
begin_metric
1
end_metric
36
begin_variable
var0
-1
22
at car9 loc1
at car9 loc10
at car9 loc11
at car9 loc12
at car9 loc13
at car9 loc14
at car9 loc15
at car9 loc16
at car9 loc17
at car9 loc18
at car9 loc19
at car9 loc2
at car9 loc20
at car9 loc21
at car9 loc3
at car9 loc4
at car9 loc5
at car9 loc6
at car9 loc7
at car9 loc8
at car9 loc9
on car9
end_variable
begin_variable
var1
-1
22
at car1 loc1
at car1 loc10
at car1 loc11
at car1 loc12
at car1 loc13
at car1 loc14
at car1 loc15
at car1 loc16
at car1 loc17
at car1 loc18
at car1 loc19
at car1 loc2
at car1 loc20
at car1 loc21
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
at car1 loc7
at car1 loc8
at car1 loc9
on car1
end_variable
begin_variable
var2
-1
22
at car10 loc1
at car10 loc10
at car10 loc11
at car10 loc12
at car10 loc13
at car10 loc14
at car10 loc15
at car10 loc16
at car10 loc17
at car10 loc18
at car10 loc19
at car10 loc2
at car10 loc20
at car10 loc21
at car10 loc3
at car10 loc4
at car10 loc5
at car10 loc6
at car10 loc7
at car10 loc8
at car10 loc9
on car10
end_variable
begin_variable
var3
-1
22
at car11 loc1
at car11 loc10
at car11 loc11
at car11 loc12
at car11 loc13
at car11 loc14
at car11 loc15
at car11 loc16
at car11 loc17
at car11 loc18
at car11 loc19
at car11 loc2
at car11 loc20
at car11 loc21
at car11 loc3
at car11 loc4
at car11 loc5
at car11 loc6
at car11 loc7
at car11 loc8
at car11 loc9
on car11
end_variable
begin_variable
var4
-1
22
at car12 loc1
at car12 loc10
at car12 loc11
at car12 loc12
at car12 loc13
at car12 loc14
at car12 loc15
at car12 loc16
at car12 loc17
at car12 loc18
at car12 loc19
at car12 loc2
at car12 loc20
at car12 loc21
at car12 loc3
at car12 loc4
at car12 loc5
at car12 loc6
at car12 loc7
at car12 loc8
at car12 loc9
on car12
end_variable
begin_variable
var5
-1
22
at car13 loc1
at car13 loc10
at car13 loc11
at car13 loc12
at car13 loc13
at car13 loc14
at car13 loc15
at car13 loc16
at car13 loc17
at car13 loc18
at car13 loc19
at car13 loc2
at car13 loc20
at car13 loc21
at car13 loc3
at car13 loc4
at car13 loc5
at car13 loc6
at car13 loc7
at car13 loc8
at car13 loc9
on car13
end_variable
begin_variable
var6
-1
22
at car2 loc1
at car2 loc10
at car2 loc11
at car2 loc12
at car2 loc13
at car2 loc14
at car2 loc15
at car2 loc16
at car2 loc17
at car2 loc18
at car2 loc19
at car2 loc2
at car2 loc20
at car2 loc21
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
at car2 loc7
at car2 loc8
at car2 loc9
on car2
end_variable
begin_variable
var7
-1
22
at car3 loc1
at car3 loc10
at car3 loc11
at car3 loc12
at car3 loc13
at car3 loc14
at car3 loc15
at car3 loc16
at car3 loc17
at car3 loc18
at car3 loc19
at car3 loc2
at car3 loc20
at car3 loc21
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
at car3 loc7
at car3 loc8
at car3 loc9
on car3
end_variable
begin_variable
var8
-1
22
at car4 loc1
at car4 loc10
at car4 loc11
at car4 loc12
at car4 loc13
at car4 loc14
at car4 loc15
at car4 loc16
at car4 loc17
at car4 loc18
at car4 loc19
at car4 loc2
at car4 loc20
at car4 loc21
at car4 loc3
at car4 loc4
at car4 loc5
at car4 loc6
at car4 loc7
at car4 loc8
at car4 loc9
on car4
end_variable
begin_variable
var9
-1
22
at car5 loc1
at car5 loc10
at car5 loc11
at car5 loc12
at car5 loc13
at car5 loc14
at car5 loc15
at car5 loc16
at car5 loc17
at car5 loc18
at car5 loc19
at car5 loc2
at car5 loc20
at car5 loc21
at car5 loc3
at car5 loc4
at car5 loc5
at car5 loc6
at car5 loc7
at car5 loc8
at car5 loc9
on car5
end_variable
begin_variable
var10
-1
22
at car6 loc1
at car6 loc10
at car6 loc11
at car6 loc12
at car6 loc13
at car6 loc14
at car6 loc15
at car6 loc16
at car6 loc17
at car6 loc18
at car6 loc19
at car6 loc2
at car6 loc20
at car6 loc21
at car6 loc3
at car6 loc4
at car6 loc5
at car6 loc6
at car6 loc7
at car6 loc8
at car6 loc9
on car6
end_variable
begin_variable
var11
-1
22
at car7 loc1
at car7 loc10
at car7 loc11
at car7 loc12
at car7 loc13
at car7 loc14
at car7 loc15
at car7 loc16
at car7 loc17
at car7 loc18
at car7 loc19
at car7 loc2
at car7 loc20
at car7 loc21
at car7 loc3
at car7 loc4
at car7 loc5
at car7 loc6
at car7 loc7
at car7 loc8
at car7 loc9
on car7
end_variable
begin_variable
var12
-1
22
at car8 loc1
at car8 loc10
at car8 loc11
at car8 loc12
at car8 loc13
at car8 loc14
at car8 loc15
at car8 loc16
at car8 loc17
at car8 loc18
at car8 loc19
at car8 loc2
at car8 loc20
at car8 loc21
at car8 loc3
at car8 loc4
at car8 loc5
at car8 loc6
at car8 loc7
at car8 loc8
at car8 loc9
on car8
end_variable
begin_variable
var13
-1
21
at-ferry loc1
at-ferry loc10
at-ferry loc11
at-ferry loc12
at-ferry loc13
at-ferry loc14
at-ferry loc15
at-ferry loc16
at-ferry loc17
at-ferry loc18
at-ferry loc19
at-ferry loc2
at-ferry loc20
at-ferry loc21
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
at-ferry loc7
at-ferry loc8
at-ferry loc9
end_variable
begin_variable
var14
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var15
-1
2
NOT-at-ferry loc10
none-of-those
end_variable
begin_variable
var16
-1
2
NOT-at-ferry loc11
none-of-those
end_variable
begin_variable
var17
-1
2
NOT-at-ferry loc12
none-of-those
end_variable
begin_variable
var18
-1
2
NOT-at-ferry loc13
none-of-those
end_variable
begin_variable
var19
-1
2
NOT-at-ferry loc14
none-of-those
end_variable
begin_variable
var20
-1
2
NOT-at-ferry loc15
none-of-those
end_variable
begin_variable
var21
-1
2
NOT-at-ferry loc16
none-of-those
end_variable
begin_variable
var22
-1
2
NOT-at-ferry loc17
none-of-those
end_variable
begin_variable
var23
-1
2
NOT-at-ferry loc18
none-of-those
end_variable
begin_variable
var24
-1
2
NOT-at-ferry loc19
none-of-those
end_variable
begin_variable
var25
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var26
-1
2
NOT-at-ferry loc20
none-of-those
end_variable
begin_variable
var27
-1
2
NOT-at-ferry loc21
none-of-those
end_variable
begin_variable
var28
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var29
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var30
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var31
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var32
-1
2
NOT-at-ferry loc7
none-of-those
end_variable
begin_variable
var33
-1
2
NOT-at-ferry loc8
none-of-those
end_variable
begin_variable
var34
-1
2
NOT-at-ferry loc9
none-of-those
end_variable
begin_variable
var35
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
10
6
3
0
9
2
2
14
15
11
16
10
15
8
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
13
0 15
1 20
2 19
3 5
4 3
5 15
6 19
7 8
8 17
9 10
10 11
11 18
12 17
end_goal
966
begin_operator
board car1 loc1
1
13 0
2
0 1 0 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc10
1
13 1
2
0 1 1 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc11
1
13 2
2
0 1 2 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc12
1
13 3
2
0 1 3 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc13
1
13 4
2
0 1 4 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc14
1
13 5
2
0 1 5 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc15
1
13 6
2
0 1 6 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc16
1
13 7
2
0 1 7 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc17
1
13 8
2
0 1 8 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc18
1
13 9
2
0 1 9 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc19
1
13 10
2
0 1 10 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc2
1
13 11
2
0 1 11 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc20
1
13 12
2
0 1 12 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc21
1
13 13
2
0 1 13 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc3
1
13 14
2
0 1 14 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc4
1
13 15
2
0 1 15 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc5
1
13 16
2
0 1 16 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc6
1
13 17
2
0 1 17 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc7
1
13 18
2
0 1 18 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc8
1
13 19
2
0 1 19 21
0 35 0 1
1
end_operator
begin_operator
board car1 loc9
1
13 20
2
0 1 20 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc1
1
13 0
2
0 2 0 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc10
1
13 1
2
0 2 1 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc11
1
13 2
2
0 2 2 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc12
1
13 3
2
0 2 3 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc13
1
13 4
2
0 2 4 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc14
1
13 5
2
0 2 5 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc15
1
13 6
2
0 2 6 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc16
1
13 7
2
0 2 7 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc17
1
13 8
2
0 2 8 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc18
1
13 9
2
0 2 9 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc19
1
13 10
2
0 2 10 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc2
1
13 11
2
0 2 11 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc20
1
13 12
2
0 2 12 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc21
1
13 13
2
0 2 13 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc3
1
13 14
2
0 2 14 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc4
1
13 15
2
0 2 15 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc5
1
13 16
2
0 2 16 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc6
1
13 17
2
0 2 17 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc7
1
13 18
2
0 2 18 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc8
1
13 19
2
0 2 19 21
0 35 0 1
1
end_operator
begin_operator
board car10 loc9
1
13 20
2
0 2 20 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc1
1
13 0
2
0 3 0 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc10
1
13 1
2
0 3 1 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc11
1
13 2
2
0 3 2 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc12
1
13 3
2
0 3 3 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc13
1
13 4
2
0 3 4 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc14
1
13 5
2
0 3 5 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc15
1
13 6
2
0 3 6 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc16
1
13 7
2
0 3 7 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc17
1
13 8
2
0 3 8 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc18
1
13 9
2
0 3 9 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc19
1
13 10
2
0 3 10 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc2
1
13 11
2
0 3 11 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc20
1
13 12
2
0 3 12 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc21
1
13 13
2
0 3 13 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc3
1
13 14
2
0 3 14 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc4
1
13 15
2
0 3 15 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc5
1
13 16
2
0 3 16 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc6
1
13 17
2
0 3 17 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc7
1
13 18
2
0 3 18 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc8
1
13 19
2
0 3 19 21
0 35 0 1
1
end_operator
begin_operator
board car11 loc9
1
13 20
2
0 3 20 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc1
1
13 0
2
0 4 0 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc10
1
13 1
2
0 4 1 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc11
1
13 2
2
0 4 2 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc12
1
13 3
2
0 4 3 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc13
1
13 4
2
0 4 4 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc14
1
13 5
2
0 4 5 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc15
1
13 6
2
0 4 6 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc16
1
13 7
2
0 4 7 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc17
1
13 8
2
0 4 8 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc18
1
13 9
2
0 4 9 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc19
1
13 10
2
0 4 10 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc2
1
13 11
2
0 4 11 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc20
1
13 12
2
0 4 12 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc21
1
13 13
2
0 4 13 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc3
1
13 14
2
0 4 14 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc4
1
13 15
2
0 4 15 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc5
1
13 16
2
0 4 16 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc6
1
13 17
2
0 4 17 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc7
1
13 18
2
0 4 18 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc8
1
13 19
2
0 4 19 21
0 35 0 1
1
end_operator
begin_operator
board car12 loc9
1
13 20
2
0 4 20 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc1
1
13 0
2
0 5 0 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc10
1
13 1
2
0 5 1 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc11
1
13 2
2
0 5 2 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc12
1
13 3
2
0 5 3 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc13
1
13 4
2
0 5 4 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc14
1
13 5
2
0 5 5 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc15
1
13 6
2
0 5 6 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc16
1
13 7
2
0 5 7 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc17
1
13 8
2
0 5 8 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc18
1
13 9
2
0 5 9 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc19
1
13 10
2
0 5 10 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc2
1
13 11
2
0 5 11 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc20
1
13 12
2
0 5 12 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc21
1
13 13
2
0 5 13 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc3
1
13 14
2
0 5 14 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc4
1
13 15
2
0 5 15 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc5
1
13 16
2
0 5 16 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc6
1
13 17
2
0 5 17 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc7
1
13 18
2
0 5 18 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc8
1
13 19
2
0 5 19 21
0 35 0 1
1
end_operator
begin_operator
board car13 loc9
1
13 20
2
0 5 20 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc1
1
13 0
2
0 6 0 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc10
1
13 1
2
0 6 1 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc11
1
13 2
2
0 6 2 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc12
1
13 3
2
0 6 3 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc13
1
13 4
2
0 6 4 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc14
1
13 5
2
0 6 5 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc15
1
13 6
2
0 6 6 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc16
1
13 7
2
0 6 7 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc17
1
13 8
2
0 6 8 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc18
1
13 9
2
0 6 9 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc19
1
13 10
2
0 6 10 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc2
1
13 11
2
0 6 11 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc20
1
13 12
2
0 6 12 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc21
1
13 13
2
0 6 13 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc3
1
13 14
2
0 6 14 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc4
1
13 15
2
0 6 15 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc5
1
13 16
2
0 6 16 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc6
1
13 17
2
0 6 17 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc7
1
13 18
2
0 6 18 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc8
1
13 19
2
0 6 19 21
0 35 0 1
1
end_operator
begin_operator
board car2 loc9
1
13 20
2
0 6 20 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc1
1
13 0
2
0 7 0 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc10
1
13 1
2
0 7 1 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc11
1
13 2
2
0 7 2 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc12
1
13 3
2
0 7 3 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc13
1
13 4
2
0 7 4 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc14
1
13 5
2
0 7 5 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc15
1
13 6
2
0 7 6 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc16
1
13 7
2
0 7 7 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc17
1
13 8
2
0 7 8 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc18
1
13 9
2
0 7 9 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc19
1
13 10
2
0 7 10 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc2
1
13 11
2
0 7 11 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc20
1
13 12
2
0 7 12 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc21
1
13 13
2
0 7 13 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc3
1
13 14
2
0 7 14 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc4
1
13 15
2
0 7 15 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc5
1
13 16
2
0 7 16 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc6
1
13 17
2
0 7 17 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc7
1
13 18
2
0 7 18 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc8
1
13 19
2
0 7 19 21
0 35 0 1
1
end_operator
begin_operator
board car3 loc9
1
13 20
2
0 7 20 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc1
1
13 0
2
0 8 0 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc10
1
13 1
2
0 8 1 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc11
1
13 2
2
0 8 2 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc12
1
13 3
2
0 8 3 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc13
1
13 4
2
0 8 4 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc14
1
13 5
2
0 8 5 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc15
1
13 6
2
0 8 6 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc16
1
13 7
2
0 8 7 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc17
1
13 8
2
0 8 8 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc18
1
13 9
2
0 8 9 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc19
1
13 10
2
0 8 10 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc2
1
13 11
2
0 8 11 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc20
1
13 12
2
0 8 12 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc21
1
13 13
2
0 8 13 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc3
1
13 14
2
0 8 14 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc4
1
13 15
2
0 8 15 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc5
1
13 16
2
0 8 16 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc6
1
13 17
2
0 8 17 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc7
1
13 18
2
0 8 18 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc8
1
13 19
2
0 8 19 21
0 35 0 1
1
end_operator
begin_operator
board car4 loc9
1
13 20
2
0 8 20 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc1
1
13 0
2
0 9 0 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc10
1
13 1
2
0 9 1 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc11
1
13 2
2
0 9 2 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc12
1
13 3
2
0 9 3 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc13
1
13 4
2
0 9 4 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc14
1
13 5
2
0 9 5 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc15
1
13 6
2
0 9 6 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc16
1
13 7
2
0 9 7 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc17
1
13 8
2
0 9 8 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc18
1
13 9
2
0 9 9 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc19
1
13 10
2
0 9 10 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc2
1
13 11
2
0 9 11 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc20
1
13 12
2
0 9 12 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc21
1
13 13
2
0 9 13 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc3
1
13 14
2
0 9 14 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc4
1
13 15
2
0 9 15 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc5
1
13 16
2
0 9 16 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc6
1
13 17
2
0 9 17 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc7
1
13 18
2
0 9 18 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc8
1
13 19
2
0 9 19 21
0 35 0 1
1
end_operator
begin_operator
board car5 loc9
1
13 20
2
0 9 20 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc1
1
13 0
2
0 10 0 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc10
1
13 1
2
0 10 1 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc11
1
13 2
2
0 10 2 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc12
1
13 3
2
0 10 3 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc13
1
13 4
2
0 10 4 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc14
1
13 5
2
0 10 5 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc15
1
13 6
2
0 10 6 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc16
1
13 7
2
0 10 7 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc17
1
13 8
2
0 10 8 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc18
1
13 9
2
0 10 9 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc19
1
13 10
2
0 10 10 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc2
1
13 11
2
0 10 11 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc20
1
13 12
2
0 10 12 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc21
1
13 13
2
0 10 13 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc3
1
13 14
2
0 10 14 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc4
1
13 15
2
0 10 15 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc5
1
13 16
2
0 10 16 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc6
1
13 17
2
0 10 17 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc7
1
13 18
2
0 10 18 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc8
1
13 19
2
0 10 19 21
0 35 0 1
1
end_operator
begin_operator
board car6 loc9
1
13 20
2
0 10 20 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc1
1
13 0
2
0 11 0 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc10
1
13 1
2
0 11 1 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc11
1
13 2
2
0 11 2 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc12
1
13 3
2
0 11 3 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc13
1
13 4
2
0 11 4 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc14
1
13 5
2
0 11 5 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc15
1
13 6
2
0 11 6 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc16
1
13 7
2
0 11 7 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc17
1
13 8
2
0 11 8 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc18
1
13 9
2
0 11 9 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc19
1
13 10
2
0 11 10 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc2
1
13 11
2
0 11 11 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc20
1
13 12
2
0 11 12 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc21
1
13 13
2
0 11 13 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc3
1
13 14
2
0 11 14 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc4
1
13 15
2
0 11 15 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc5
1
13 16
2
0 11 16 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc6
1
13 17
2
0 11 17 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc7
1
13 18
2
0 11 18 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc8
1
13 19
2
0 11 19 21
0 35 0 1
1
end_operator
begin_operator
board car7 loc9
1
13 20
2
0 11 20 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc1
1
13 0
2
0 12 0 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc10
1
13 1
2
0 12 1 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc11
1
13 2
2
0 12 2 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc12
1
13 3
2
0 12 3 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc13
1
13 4
2
0 12 4 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc14
1
13 5
2
0 12 5 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc15
1
13 6
2
0 12 6 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc16
1
13 7
2
0 12 7 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc17
1
13 8
2
0 12 8 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc18
1
13 9
2
0 12 9 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc19
1
13 10
2
0 12 10 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc2
1
13 11
2
0 12 11 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc20
1
13 12
2
0 12 12 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc21
1
13 13
2
0 12 13 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc3
1
13 14
2
0 12 14 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc4
1
13 15
2
0 12 15 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc5
1
13 16
2
0 12 16 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc6
1
13 17
2
0 12 17 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc7
1
13 18
2
0 12 18 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc8
1
13 19
2
0 12 19 21
0 35 0 1
1
end_operator
begin_operator
board car8 loc9
1
13 20
2
0 12 20 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc1
1
13 0
2
0 0 0 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc10
1
13 1
2
0 0 1 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc11
1
13 2
2
0 0 2 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc12
1
13 3
2
0 0 3 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc13
1
13 4
2
0 0 4 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc14
1
13 5
2
0 0 5 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc15
1
13 6
2
0 0 6 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc16
1
13 7
2
0 0 7 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc17
1
13 8
2
0 0 8 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc18
1
13 9
2
0 0 9 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc19
1
13 10
2
0 0 10 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc2
1
13 11
2
0 0 11 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc20
1
13 12
2
0 0 12 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc21
1
13 13
2
0 0 13 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc3
1
13 14
2
0 0 14 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc4
1
13 15
2
0 0 15 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc5
1
13 16
2
0 0 16 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc6
1
13 17
2
0 0 17 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc7
1
13 18
2
0 0 18 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc8
1
13 19
2
0 0 19 21
0 35 0 1
1
end_operator
begin_operator
board car9 loc9
1
13 20
2
0 0 20 21
0 35 0 1
1
end_operator
begin_operator
debark car1 loc1
1
13 0
2
0 1 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc10
1
13 1
2
0 1 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc11
1
13 2
2
0 1 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc12
1
13 3
2
0 1 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc13
1
13 4
2
0 1 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc14
1
13 5
2
0 1 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc15
1
13 6
2
0 1 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc16
1
13 7
2
0 1 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc17
1
13 8
2
0 1 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc18
1
13 9
2
0 1 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc19
1
13 10
2
0 1 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
13 11
2
0 1 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc20
1
13 12
2
0 1 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc21
1
13 13
2
0 1 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
13 14
2
0 1 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
13 15
2
0 1 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
13 16
2
0 1 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
13 17
2
0 1 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc7
1
13 18
2
0 1 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc8
1
13 19
2
0 1 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car1 loc9
1
13 20
2
0 1 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc1
1
13 0
2
0 2 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc10
1
13 1
2
0 2 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc11
1
13 2
2
0 2 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc12
1
13 3
2
0 2 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc13
1
13 4
2
0 2 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc14
1
13 5
2
0 2 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc15
1
13 6
2
0 2 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc16
1
13 7
2
0 2 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc17
1
13 8
2
0 2 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc18
1
13 9
2
0 2 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc19
1
13 10
2
0 2 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc2
1
13 11
2
0 2 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc20
1
13 12
2
0 2 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc21
1
13 13
2
0 2 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc3
1
13 14
2
0 2 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc4
1
13 15
2
0 2 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc5
1
13 16
2
0 2 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc6
1
13 17
2
0 2 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc7
1
13 18
2
0 2 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc8
1
13 19
2
0 2 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car10 loc9
1
13 20
2
0 2 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc1
1
13 0
2
0 3 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc10
1
13 1
2
0 3 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc11
1
13 2
2
0 3 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc12
1
13 3
2
0 3 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc13
1
13 4
2
0 3 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc14
1
13 5
2
0 3 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc15
1
13 6
2
0 3 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc16
1
13 7
2
0 3 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc17
1
13 8
2
0 3 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc18
1
13 9
2
0 3 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc19
1
13 10
2
0 3 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc2
1
13 11
2
0 3 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc20
1
13 12
2
0 3 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc21
1
13 13
2
0 3 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc3
1
13 14
2
0 3 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc4
1
13 15
2
0 3 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc5
1
13 16
2
0 3 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc6
1
13 17
2
0 3 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc7
1
13 18
2
0 3 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc8
1
13 19
2
0 3 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car11 loc9
1
13 20
2
0 3 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc1
1
13 0
2
0 4 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc10
1
13 1
2
0 4 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc11
1
13 2
2
0 4 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc12
1
13 3
2
0 4 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc13
1
13 4
2
0 4 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc14
1
13 5
2
0 4 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc15
1
13 6
2
0 4 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc16
1
13 7
2
0 4 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc17
1
13 8
2
0 4 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc18
1
13 9
2
0 4 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc19
1
13 10
2
0 4 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc2
1
13 11
2
0 4 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc20
1
13 12
2
0 4 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc21
1
13 13
2
0 4 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc3
1
13 14
2
0 4 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc4
1
13 15
2
0 4 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc5
1
13 16
2
0 4 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc6
1
13 17
2
0 4 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc7
1
13 18
2
0 4 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc8
1
13 19
2
0 4 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car12 loc9
1
13 20
2
0 4 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc1
1
13 0
2
0 5 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc10
1
13 1
2
0 5 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc11
1
13 2
2
0 5 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc12
1
13 3
2
0 5 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc13
1
13 4
2
0 5 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc14
1
13 5
2
0 5 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc15
1
13 6
2
0 5 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc16
1
13 7
2
0 5 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc17
1
13 8
2
0 5 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc18
1
13 9
2
0 5 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc19
1
13 10
2
0 5 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc2
1
13 11
2
0 5 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc20
1
13 12
2
0 5 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc21
1
13 13
2
0 5 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc3
1
13 14
2
0 5 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc4
1
13 15
2
0 5 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc5
1
13 16
2
0 5 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc6
1
13 17
2
0 5 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc7
1
13 18
2
0 5 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc8
1
13 19
2
0 5 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car13 loc9
1
13 20
2
0 5 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
13 0
2
0 6 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc10
1
13 1
2
0 6 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc11
1
13 2
2
0 6 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc12
1
13 3
2
0 6 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc13
1
13 4
2
0 6 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc14
1
13 5
2
0 6 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc15
1
13 6
2
0 6 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc16
1
13 7
2
0 6 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc17
1
13 8
2
0 6 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc18
1
13 9
2
0 6 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc19
1
13 10
2
0 6 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
13 11
2
0 6 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc20
1
13 12
2
0 6 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc21
1
13 13
2
0 6 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
13 14
2
0 6 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
13 15
2
0 6 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
13 16
2
0 6 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
13 17
2
0 6 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc7
1
13 18
2
0 6 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc8
1
13 19
2
0 6 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car2 loc9
1
13 20
2
0 6 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
13 0
2
0 7 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc10
1
13 1
2
0 7 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc11
1
13 2
2
0 7 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc12
1
13 3
2
0 7 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc13
1
13 4
2
0 7 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc14
1
13 5
2
0 7 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc15
1
13 6
2
0 7 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc16
1
13 7
2
0 7 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc17
1
13 8
2
0 7 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc18
1
13 9
2
0 7 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc19
1
13 10
2
0 7 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
13 11
2
0 7 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc20
1
13 12
2
0 7 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc21
1
13 13
2
0 7 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
13 14
2
0 7 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
13 15
2
0 7 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
13 16
2
0 7 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
13 17
2
0 7 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc7
1
13 18
2
0 7 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc8
1
13 19
2
0 7 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car3 loc9
1
13 20
2
0 7 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc1
1
13 0
2
0 8 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc10
1
13 1
2
0 8 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc11
1
13 2
2
0 8 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc12
1
13 3
2
0 8 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc13
1
13 4
2
0 8 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc14
1
13 5
2
0 8 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc15
1
13 6
2
0 8 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc16
1
13 7
2
0 8 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc17
1
13 8
2
0 8 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc18
1
13 9
2
0 8 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc19
1
13 10
2
0 8 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc2
1
13 11
2
0 8 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc20
1
13 12
2
0 8 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc21
1
13 13
2
0 8 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc3
1
13 14
2
0 8 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc4
1
13 15
2
0 8 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc5
1
13 16
2
0 8 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc6
1
13 17
2
0 8 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc7
1
13 18
2
0 8 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc8
1
13 19
2
0 8 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car4 loc9
1
13 20
2
0 8 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc1
1
13 0
2
0 9 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc10
1
13 1
2
0 9 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc11
1
13 2
2
0 9 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc12
1
13 3
2
0 9 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc13
1
13 4
2
0 9 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc14
1
13 5
2
0 9 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc15
1
13 6
2
0 9 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc16
1
13 7
2
0 9 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc17
1
13 8
2
0 9 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc18
1
13 9
2
0 9 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc19
1
13 10
2
0 9 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc2
1
13 11
2
0 9 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc20
1
13 12
2
0 9 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc21
1
13 13
2
0 9 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc3
1
13 14
2
0 9 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc4
1
13 15
2
0 9 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc5
1
13 16
2
0 9 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc6
1
13 17
2
0 9 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc7
1
13 18
2
0 9 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc8
1
13 19
2
0 9 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car5 loc9
1
13 20
2
0 9 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc1
1
13 0
2
0 10 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc10
1
13 1
2
0 10 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc11
1
13 2
2
0 10 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc12
1
13 3
2
0 10 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc13
1
13 4
2
0 10 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc14
1
13 5
2
0 10 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc15
1
13 6
2
0 10 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc16
1
13 7
2
0 10 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc17
1
13 8
2
0 10 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc18
1
13 9
2
0 10 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc19
1
13 10
2
0 10 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc2
1
13 11
2
0 10 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc20
1
13 12
2
0 10 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc21
1
13 13
2
0 10 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc3
1
13 14
2
0 10 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc4
1
13 15
2
0 10 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc5
1
13 16
2
0 10 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc6
1
13 17
2
0 10 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc7
1
13 18
2
0 10 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc8
1
13 19
2
0 10 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car6 loc9
1
13 20
2
0 10 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc1
1
13 0
2
0 11 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc10
1
13 1
2
0 11 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc11
1
13 2
2
0 11 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc12
1
13 3
2
0 11 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc13
1
13 4
2
0 11 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc14
1
13 5
2
0 11 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc15
1
13 6
2
0 11 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc16
1
13 7
2
0 11 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc17
1
13 8
2
0 11 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc18
1
13 9
2
0 11 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc19
1
13 10
2
0 11 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc2
1
13 11
2
0 11 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc20
1
13 12
2
0 11 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc21
1
13 13
2
0 11 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc3
1
13 14
2
0 11 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc4
1
13 15
2
0 11 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc5
1
13 16
2
0 11 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc6
1
13 17
2
0 11 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc7
1
13 18
2
0 11 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc8
1
13 19
2
0 11 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car7 loc9
1
13 20
2
0 11 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc1
1
13 0
2
0 12 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc10
1
13 1
2
0 12 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc11
1
13 2
2
0 12 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc12
1
13 3
2
0 12 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc13
1
13 4
2
0 12 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc14
1
13 5
2
0 12 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc15
1
13 6
2
0 12 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc16
1
13 7
2
0 12 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc17
1
13 8
2
0 12 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc18
1
13 9
2
0 12 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc19
1
13 10
2
0 12 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc2
1
13 11
2
0 12 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc20
1
13 12
2
0 12 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc21
1
13 13
2
0 12 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc3
1
13 14
2
0 12 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc4
1
13 15
2
0 12 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc5
1
13 16
2
0 12 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc6
1
13 17
2
0 12 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc7
1
13 18
2
0 12 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc8
1
13 19
2
0 12 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car8 loc9
1
13 20
2
0 12 21 20
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc1
1
13 0
2
0 0 21 0
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc10
1
13 1
2
0 0 21 1
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc11
1
13 2
2
0 0 21 2
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc12
1
13 3
2
0 0 21 3
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc13
1
13 4
2
0 0 21 4
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc14
1
13 5
2
0 0 21 5
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc15
1
13 6
2
0 0 21 6
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc16
1
13 7
2
0 0 21 7
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc17
1
13 8
2
0 0 21 8
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc18
1
13 9
2
0 0 21 9
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc19
1
13 10
2
0 0 21 10
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc2
1
13 11
2
0 0 21 11
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc20
1
13 12
2
0 0 21 12
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc21
1
13 13
2
0 0 21 13
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc3
1
13 14
2
0 0 21 14
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc4
1
13 15
2
0 0 21 15
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc5
1
13 16
2
0 0 21 16
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc6
1
13 17
2
0 0 21 17
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc7
1
13 18
2
0 0 21 18
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc8
1
13 19
2
0 0 21 19
0 35 -1 0
1
end_operator
begin_operator
debark car9 loc9
1
13 20
2
0 0 21 20
0 35 -1 0
1
end_operator
begin_operator
sail loc1 loc10
0
3
0 13 0 1
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
sail loc1 loc11
0
3
0 13 0 2
0 14 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc1 loc12
0
3
0 13 0 3
0 14 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc1 loc13
0
3
0 13 0 4
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc1 loc14
0
3
0 13 0 5
0 14 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc1 loc15
0
3
0 13 0 6
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc1 loc16
0
3
0 13 0 7
0 14 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc1 loc17
0
3
0 13 0 8
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc1 loc18
0
3
0 13 0 9
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc1 loc19
0
3
0 13 0 10
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 13 0 11
0 14 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc1 loc20
0
3
0 13 0 12
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc1 loc21
0
3
0 13 0 13
0 14 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 13 0 14
0 14 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 13 0 15
0 14 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 13 0 16
0 14 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 13 0 17
0 14 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc1 loc7
0
3
0 13 0 18
0 14 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc1 loc8
0
3
0 13 0 19
0 14 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc1 loc9
0
3
0 13 0 20
0 14 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc10 loc1
0
3
0 13 1 0
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
sail loc10 loc11
0
3
0 13 1 2
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
sail loc10 loc12
0
3
0 13 1 3
0 15 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc10 loc13
0
3
0 13 1 4
0 15 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc10 loc14
0
3
0 13 1 5
0 15 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc10 loc15
0
3
0 13 1 6
0 15 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc10 loc16
0
3
0 13 1 7
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc10 loc17
0
3
0 13 1 8
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc10 loc18
0
3
0 13 1 9
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc10 loc19
0
3
0 13 1 10
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc10 loc2
0
3
0 13 1 11
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc10 loc20
0
3
0 13 1 12
0 15 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc10 loc21
0
3
0 13 1 13
0 15 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc10 loc3
0
3
0 13 1 14
0 15 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc10 loc4
0
3
0 13 1 15
0 15 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc10 loc5
0
3
0 13 1 16
0 15 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc10 loc6
0
3
0 13 1 17
0 15 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc10 loc7
0
3
0 13 1 18
0 15 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc10 loc8
0
3
0 13 1 19
0 15 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc10 loc9
0
3
0 13 1 20
0 15 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc11 loc1
0
3
0 13 2 0
0 14 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc11 loc10
0
3
0 13 2 1
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
sail loc11 loc12
0
3
0 13 2 3
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
sail loc11 loc13
0
3
0 13 2 4
0 16 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc11 loc14
0
3
0 13 2 5
0 16 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc11 loc15
0
3
0 13 2 6
0 16 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc11 loc16
0
3
0 13 2 7
0 16 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc11 loc17
0
3
0 13 2 8
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc11 loc18
0
3
0 13 2 9
0 16 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc11 loc19
0
3
0 13 2 10
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc11 loc2
0
3
0 13 2 11
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc11 loc20
0
3
0 13 2 12
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc11 loc21
0
3
0 13 2 13
0 16 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc11 loc3
0
3
0 13 2 14
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc11 loc4
0
3
0 13 2 15
0 16 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc11 loc5
0
3
0 13 2 16
0 16 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc11 loc6
0
3
0 13 2 17
0 16 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc11 loc7
0
3
0 13 2 18
0 16 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc11 loc8
0
3
0 13 2 19
0 16 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc11 loc9
0
3
0 13 2 20
0 16 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc12 loc1
0
3
0 13 3 0
0 14 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc12 loc10
0
3
0 13 3 1
0 15 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc12 loc11
0
3
0 13 3 2
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
sail loc12 loc13
0
3
0 13 3 4
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
sail loc12 loc14
0
3
0 13 3 5
0 17 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc12 loc15
0
3
0 13 3 6
0 17 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc12 loc16
0
3
0 13 3 7
0 17 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc12 loc17
0
3
0 13 3 8
0 17 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc12 loc18
0
3
0 13 3 9
0 17 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc12 loc19
0
3
0 13 3 10
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc12 loc2
0
3
0 13 3 11
0 17 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc12 loc20
0
3
0 13 3 12
0 17 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc12 loc21
0
3
0 13 3 13
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc12 loc3
0
3
0 13 3 14
0 17 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc12 loc4
0
3
0 13 3 15
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc12 loc5
0
3
0 13 3 16
0 17 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc12 loc6
0
3
0 13 3 17
0 17 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc12 loc7
0
3
0 13 3 18
0 17 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc12 loc8
0
3
0 13 3 19
0 17 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc12 loc9
0
3
0 13 3 20
0 17 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc13 loc1
0
3
0 13 4 0
0 14 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc13 loc10
0
3
0 13 4 1
0 15 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc13 loc11
0
3
0 13 4 2
0 16 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc13 loc12
0
3
0 13 4 3
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
sail loc13 loc14
0
3
0 13 4 5
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
sail loc13 loc15
0
3
0 13 4 6
0 18 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc13 loc16
0
3
0 13 4 7
0 18 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc13 loc17
0
3
0 13 4 8
0 18 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc13 loc18
0
3
0 13 4 9
0 18 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc13 loc19
0
3
0 13 4 10
0 18 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc13 loc2
0
3
0 13 4 11
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc13 loc20
0
3
0 13 4 12
0 18 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc13 loc21
0
3
0 13 4 13
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc13 loc3
0
3
0 13 4 14
0 18 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc13 loc4
0
3
0 13 4 15
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc13 loc5
0
3
0 13 4 16
0 18 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc13 loc6
0
3
0 13 4 17
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc13 loc7
0
3
0 13 4 18
0 18 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc13 loc8
0
3
0 13 4 19
0 18 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc13 loc9
0
3
0 13 4 20
0 18 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc14 loc1
0
3
0 13 5 0
0 14 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc14 loc10
0
3
0 13 5 1
0 15 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc14 loc11
0
3
0 13 5 2
0 16 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc14 loc12
0
3
0 13 5 3
0 17 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc14 loc13
0
3
0 13 5 4
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
sail loc14 loc15
0
3
0 13 5 6
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
sail loc14 loc16
0
3
0 13 5 7
0 19 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc14 loc17
0
3
0 13 5 8
0 19 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc14 loc18
0
3
0 13 5 9
0 19 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc14 loc19
0
3
0 13 5 10
0 19 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc14 loc2
0
3
0 13 5 11
0 19 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc14 loc20
0
3
0 13 5 12
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc14 loc21
0
3
0 13 5 13
0 19 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc14 loc3
0
3
0 13 5 14
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc14 loc4
0
3
0 13 5 15
0 19 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc14 loc5
0
3
0 13 5 16
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc14 loc6
0
3
0 13 5 17
0 19 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc14 loc7
0
3
0 13 5 18
0 19 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc14 loc8
0
3
0 13 5 19
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc14 loc9
0
3
0 13 5 20
0 19 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc15 loc1
0
3
0 13 6 0
0 14 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc10
0
3
0 13 6 1
0 15 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc11
0
3
0 13 6 2
0 16 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc12
0
3
0 13 6 3
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc13
0
3
0 13 6 4
0 18 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc14
0
3
0 13 6 5
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
sail loc15 loc16
0
3
0 13 6 7
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
sail loc15 loc17
0
3
0 13 6 8
0 20 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc15 loc18
0
3
0 13 6 9
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc15 loc19
0
3
0 13 6 10
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc15 loc2
0
3
0 13 6 11
0 20 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc15 loc20
0
3
0 13 6 12
0 20 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc15 loc21
0
3
0 13 6 13
0 20 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc15 loc3
0
3
0 13 6 14
0 20 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc15 loc4
0
3
0 13 6 15
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc15 loc5
0
3
0 13 6 16
0 20 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc15 loc6
0
3
0 13 6 17
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc15 loc7
0
3
0 13 6 18
0 20 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc15 loc8
0
3
0 13 6 19
0 20 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc15 loc9
0
3
0 13 6 20
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc16 loc1
0
3
0 13 7 0
0 14 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc10
0
3
0 13 7 1
0 15 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc11
0
3
0 13 7 2
0 16 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc12
0
3
0 13 7 3
0 17 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc13
0
3
0 13 7 4
0 18 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc14
0
3
0 13 7 5
0 19 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc15
0
3
0 13 7 6
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
sail loc16 loc17
0
3
0 13 7 8
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
sail loc16 loc18
0
3
0 13 7 9
0 21 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc16 loc19
0
3
0 13 7 10
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc16 loc2
0
3
0 13 7 11
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc16 loc20
0
3
0 13 7 12
0 21 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc16 loc21
0
3
0 13 7 13
0 21 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc16 loc3
0
3
0 13 7 14
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc16 loc4
0
3
0 13 7 15
0 21 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc16 loc5
0
3
0 13 7 16
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc16 loc6
0
3
0 13 7 17
0 21 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc16 loc7
0
3
0 13 7 18
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc16 loc8
0
3
0 13 7 19
0 21 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc16 loc9
0
3
0 13 7 20
0 21 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc17 loc1
0
3
0 13 8 0
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc10
0
3
0 13 8 1
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc11
0
3
0 13 8 2
0 16 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc12
0
3
0 13 8 3
0 17 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc13
0
3
0 13 8 4
0 18 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc14
0
3
0 13 8 5
0 19 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc15
0
3
0 13 8 6
0 20 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc16
0
3
0 13 8 7
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
sail loc17 loc18
0
3
0 13 8 9
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
sail loc17 loc19
0
3
0 13 8 10
0 22 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc17 loc2
0
3
0 13 8 11
0 22 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc17 loc20
0
3
0 13 8 12
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc17 loc21
0
3
0 13 8 13
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc17 loc3
0
3
0 13 8 14
0 22 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc17 loc4
0
3
0 13 8 15
0 22 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc17 loc5
0
3
0 13 8 16
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc17 loc6
0
3
0 13 8 17
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc17 loc7
0
3
0 13 8 18
0 22 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc17 loc8
0
3
0 13 8 19
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc17 loc9
0
3
0 13 8 20
0 22 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc18 loc1
0
3
0 13 9 0
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc10
0
3
0 13 9 1
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc11
0
3
0 13 9 2
0 16 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc12
0
3
0 13 9 3
0 17 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc13
0
3
0 13 9 4
0 18 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc14
0
3
0 13 9 5
0 19 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc15
0
3
0 13 9 6
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc16
0
3
0 13 9 7
0 21 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc17
0
3
0 13 9 8
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
sail loc18 loc19
0
3
0 13 9 10
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
sail loc18 loc2
0
3
0 13 9 11
0 23 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc18 loc20
0
3
0 13 9 12
0 23 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc18 loc21
0
3
0 13 9 13
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc18 loc3
0
3
0 13 9 14
0 23 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc18 loc4
0
3
0 13 9 15
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc18 loc5
0
3
0 13 9 16
0 23 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc18 loc6
0
3
0 13 9 17
0 23 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc18 loc7
0
3
0 13 9 18
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc18 loc8
0
3
0 13 9 19
0 23 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc18 loc9
0
3
0 13 9 20
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc19 loc1
0
3
0 13 10 0
0 14 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc10
0
3
0 13 10 1
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc11
0
3
0 13 10 2
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc12
0
3
0 13 10 3
0 17 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc13
0
3
0 13 10 4
0 18 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc14
0
3
0 13 10 5
0 19 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc15
0
3
0 13 10 6
0 20 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc16
0
3
0 13 10 7
0 21 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc17
0
3
0 13 10 8
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc18
0
3
0 13 10 9
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
sail loc19 loc2
0
3
0 13 10 11
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
sail loc19 loc20
0
3
0 13 10 12
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc19 loc21
0
3
0 13 10 13
0 24 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc19 loc3
0
3
0 13 10 14
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc19 loc4
0
3
0 13 10 15
0 24 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc19 loc5
0
3
0 13 10 16
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc19 loc6
0
3
0 13 10 17
0 24 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc19 loc7
0
3
0 13 10 18
0 24 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc19 loc8
0
3
0 13 10 19
0 24 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc19 loc9
0
3
0 13 10 20
0 24 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 13 11 0
0 14 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc10
0
3
0 13 11 1
0 15 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc11
0
3
0 13 11 2
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc12
0
3
0 13 11 3
0 17 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc13
0
3
0 13 11 4
0 18 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc14
0
3
0 13 11 5
0 19 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc15
0
3
0 13 11 6
0 20 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc16
0
3
0 13 11 7
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc17
0
3
0 13 11 8
0 22 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc18
0
3
0 13 11 9
0 23 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc19
0
3
0 13 11 10
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
sail loc2 loc20
0
3
0 13 11 12
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
sail loc2 loc21
0
3
0 13 11 13
0 25 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 13 11 14
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 13 11 15
0 25 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 13 11 16
0 25 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 13 11 17
0 25 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc2 loc7
0
3
0 13 11 18
0 25 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc2 loc8
0
3
0 13 11 19
0 25 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc2 loc9
0
3
0 13 11 20
0 25 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc20 loc1
0
3
0 13 12 0
0 14 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc10
0
3
0 13 12 1
0 15 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc11
0
3
0 13 12 2
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc12
0
3
0 13 12 3
0 17 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc13
0
3
0 13 12 4
0 18 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc14
0
3
0 13 12 5
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc15
0
3
0 13 12 6
0 20 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc16
0
3
0 13 12 7
0 21 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc17
0
3
0 13 12 8
0 22 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc18
0
3
0 13 12 9
0 23 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc19
0
3
0 13 12 10
0 24 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc2
0
3
0 13 12 11
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
sail loc20 loc21
0
3
0 13 12 13
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
sail loc20 loc3
0
3
0 13 12 14
0 26 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc20 loc4
0
3
0 13 12 15
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc20 loc5
0
3
0 13 12 16
0 26 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc20 loc6
0
3
0 13 12 17
0 26 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc20 loc7
0
3
0 13 12 18
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc20 loc8
0
3
0 13 12 19
0 26 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc20 loc9
0
3
0 13 12 20
0 26 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc21 loc1
0
3
0 13 13 0
0 14 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc10
0
3
0 13 13 1
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc11
0
3
0 13 13 2
0 16 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc12
0
3
0 13 13 3
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc13
0
3
0 13 13 4
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc14
0
3
0 13 13 5
0 19 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc15
0
3
0 13 13 6
0 20 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc16
0
3
0 13 13 7
0 21 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc17
0
3
0 13 13 8
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc18
0
3
0 13 13 9
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc19
0
3
0 13 13 10
0 24 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc2
0
3
0 13 13 11
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc20
0
3
0 13 13 12
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
sail loc21 loc3
0
3
0 13 13 14
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
sail loc21 loc4
0
3
0 13 13 15
0 27 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc21 loc5
0
3
0 13 13 16
0 27 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc21 loc6
0
3
0 13 13 17
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc21 loc7
0
3
0 13 13 18
0 27 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc21 loc8
0
3
0 13 13 19
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc21 loc9
0
3
0 13 13 20
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 13 14 0
0 14 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc10
0
3
0 13 14 1
0 15 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc11
0
3
0 13 14 2
0 16 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc12
0
3
0 13 14 3
0 17 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc13
0
3
0 13 14 4
0 18 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc14
0
3
0 13 14 5
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc15
0
3
0 13 14 6
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc16
0
3
0 13 14 7
0 21 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc17
0
3
0 13 14 8
0 22 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc18
0
3
0 13 14 9
0 23 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc19
0
3
0 13 14 10
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 13 14 11
0 25 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc20
0
3
0 13 14 12
0 26 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc21
0
3
0 13 14 13
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 13 14 15
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 13 14 16
0 28 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 13 14 17
0 28 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc3 loc7
0
3
0 13 14 18
0 28 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc3 loc8
0
3
0 13 14 19
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc3 loc9
0
3
0 13 14 20
0 28 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 13 15 0
0 14 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc10
0
3
0 13 15 1
0 15 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc11
0
3
0 13 15 2
0 16 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc12
0
3
0 13 15 3
0 17 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc13
0
3
0 13 15 4
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc14
0
3
0 13 15 5
0 19 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc15
0
3
0 13 15 6
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc16
0
3
0 13 15 7
0 21 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc17
0
3
0 13 15 8
0 22 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc18
0
3
0 13 15 9
0 23 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc19
0
3
0 13 15 10
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 13 15 11
0 25 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc20
0
3
0 13 15 12
0 26 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc21
0
3
0 13 15 13
0 27 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 13 15 14
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 13 15 16
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 13 15 17
0 29 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc4 loc7
0
3
0 13 15 18
0 29 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc4 loc8
0
3
0 13 15 19
0 29 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc4 loc9
0
3
0 13 15 20
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 13 16 0
0 14 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc10
0
3
0 13 16 1
0 15 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc11
0
3
0 13 16 2
0 16 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc12
0
3
0 13 16 3
0 17 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc13
0
3
0 13 16 4
0 18 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc14
0
3
0 13 16 5
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc15
0
3
0 13 16 6
0 20 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc16
0
3
0 13 16 7
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc17
0
3
0 13 16 8
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc18
0
3
0 13 16 9
0 23 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc19
0
3
0 13 16 10
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 13 16 11
0 25 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc20
0
3
0 13 16 12
0 26 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc21
0
3
0 13 16 13
0 27 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 13 16 14
0 28 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 13 16 15
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 13 16 17
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
sail loc5 loc7
0
3
0 13 16 18
0 30 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc5 loc8
0
3
0 13 16 19
0 30 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc5 loc9
0
3
0 13 16 20
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 13 17 0
0 14 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc10
0
3
0 13 17 1
0 15 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc11
0
3
0 13 17 2
0 16 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc12
0
3
0 13 17 3
0 17 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc13
0
3
0 13 17 4
0 18 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc14
0
3
0 13 17 5
0 19 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc15
0
3
0 13 17 6
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc16
0
3
0 13 17 7
0 21 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc17
0
3
0 13 17 8
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc18
0
3
0 13 17 9
0 23 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc19
0
3
0 13 17 10
0 24 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 13 17 11
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc20
0
3
0 13 17 12
0 26 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc21
0
3
0 13 17 13
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 13 17 14
0 28 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 13 17 15
0 29 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 13 17 16
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
sail loc6 loc7
0
3
0 13 17 18
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
sail loc6 loc8
0
3
0 13 17 19
0 31 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc6 loc9
0
3
0 13 17 20
0 31 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc7 loc1
0
3
0 13 18 0
0 14 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc10
0
3
0 13 18 1
0 15 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc11
0
3
0 13 18 2
0 16 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc12
0
3
0 13 18 3
0 17 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc13
0
3
0 13 18 4
0 18 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc14
0
3
0 13 18 5
0 19 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc15
0
3
0 13 18 6
0 20 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc16
0
3
0 13 18 7
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc17
0
3
0 13 18 8
0 22 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc18
0
3
0 13 18 9
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc19
0
3
0 13 18 10
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc2
0
3
0 13 18 11
0 25 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc20
0
3
0 13 18 12
0 26 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc21
0
3
0 13 18 13
0 27 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc3
0
3
0 13 18 14
0 28 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc4
0
3
0 13 18 15
0 29 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc5
0
3
0 13 18 16
0 30 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc6
0
3
0 13 18 17
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
sail loc7 loc8
0
3
0 13 18 19
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
sail loc7 loc9
0
3
0 13 18 20
0 32 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc8 loc1
0
3
0 13 19 0
0 14 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc10
0
3
0 13 19 1
0 15 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc11
0
3
0 13 19 2
0 16 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc12
0
3
0 13 19 3
0 17 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc13
0
3
0 13 19 4
0 18 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc14
0
3
0 13 19 5
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc15
0
3
0 13 19 6
0 20 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc16
0
3
0 13 19 7
0 21 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc17
0
3
0 13 19 8
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc18
0
3
0 13 19 9
0 23 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc19
0
3
0 13 19 10
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc2
0
3
0 13 19 11
0 25 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc20
0
3
0 13 19 12
0 26 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc21
0
3
0 13 19 13
0 27 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc3
0
3
0 13 19 14
0 28 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc4
0
3
0 13 19 15
0 29 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc5
0
3
0 13 19 16
0 30 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc6
0
3
0 13 19 17
0 31 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc7
0
3
0 13 19 18
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
sail loc8 loc9
0
3
0 13 19 20
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
sail loc9 loc1
0
3
0 13 20 0
0 14 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc10
0
3
0 13 20 1
0 15 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc11
0
3
0 13 20 2
0 16 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc12
0
3
0 13 20 3
0 17 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc13
0
3
0 13 20 4
0 18 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc14
0
3
0 13 20 5
0 19 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc15
0
3
0 13 20 6
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc16
0
3
0 13 20 7
0 21 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc17
0
3
0 13 20 8
0 22 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc18
0
3
0 13 20 9
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc19
0
3
0 13 20 10
0 24 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc2
0
3
0 13 20 11
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc20
0
3
0 13 20 12
0 26 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc21
0
3
0 13 20 13
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc3
0
3
0 13 20 14
0 28 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc4
0
3
0 13 20 15
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc5
0
3
0 13 20 16
0 30 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc6
0
3
0 13 20 17
0 31 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc7
0
3
0 13 20 18
0 32 0 1
0 34 -1 0
1
end_operator
begin_operator
sail loc9 loc8
0
3
0 13 20 19
0 33 0 1
0 34 -1 0
1
end_operator
0
