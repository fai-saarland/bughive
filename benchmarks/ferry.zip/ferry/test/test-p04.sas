begin_version
3
end_version
begin_metric
1
end_metric
11
begin_variable
var0
-1
7
at car1 loc1
at car1 loc2
at car1 loc3
at car1 loc4
at car1 loc5
at car1 loc6
on car1
end_variable
begin_variable
var1
-1
7
at car2 loc1
at car2 loc2
at car2 loc3
at car2 loc4
at car2 loc5
at car2 loc6
on car2
end_variable
begin_variable
var2
-1
7
at car3 loc1
at car3 loc2
at car3 loc3
at car3 loc4
at car3 loc5
at car3 loc6
on car3
end_variable
begin_variable
var3
-1
6
at-ferry loc1
at-ferry loc2
at-ferry loc3
at-ferry loc4
at-ferry loc5
at-ferry loc6
end_variable
begin_variable
var4
-1
2
NOT-at-ferry loc1
none-of-those
end_variable
begin_variable
var5
-1
2
NOT-at-ferry loc2
none-of-those
end_variable
begin_variable
var6
-1
2
NOT-at-ferry loc3
none-of-those
end_variable
begin_variable
var7
-1
2
NOT-at-ferry loc4
none-of-those
end_variable
begin_variable
var8
-1
2
NOT-at-ferry loc5
none-of-those
end_variable
begin_variable
var9
-1
2
NOT-at-ferry loc6
none-of-those
end_variable
begin_variable
var10
-1
2
empty-ferry
none-of-those
end_variable
0
begin_state
4
1
4
5
0
0
0
0
0
1
0
end_state
begin_goal
3
0 0
1 4
2 3
end_goal
66
begin_operator
board car1 loc1
1
3 0
2
0 0 0 6
0 10 0 1
1
end_operator
begin_operator
board car1 loc2
1
3 1
2
0 0 1 6
0 10 0 1
1
end_operator
begin_operator
board car1 loc3
1
3 2
2
0 0 2 6
0 10 0 1
1
end_operator
begin_operator
board car1 loc4
1
3 3
2
0 0 3 6
0 10 0 1
1
end_operator
begin_operator
board car1 loc5
1
3 4
2
0 0 4 6
0 10 0 1
1
end_operator
begin_operator
board car1 loc6
1
3 5
2
0 0 5 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc1
1
3 0
2
0 1 0 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc2
1
3 1
2
0 1 1 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc3
1
3 2
2
0 1 2 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc4
1
3 3
2
0 1 3 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc5
1
3 4
2
0 1 4 6
0 10 0 1
1
end_operator
begin_operator
board car2 loc6
1
3 5
2
0 1 5 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc1
1
3 0
2
0 2 0 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc2
1
3 1
2
0 2 1 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc3
1
3 2
2
0 2 2 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc4
1
3 3
2
0 2 3 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc5
1
3 4
2
0 2 4 6
0 10 0 1
1
end_operator
begin_operator
board car3 loc6
1
3 5
2
0 2 5 6
0 10 0 1
1
end_operator
begin_operator
debark car1 loc1
1
3 0
2
0 0 6 0
0 10 -1 0
1
end_operator
begin_operator
debark car1 loc2
1
3 1
2
0 0 6 1
0 10 -1 0
1
end_operator
begin_operator
debark car1 loc3
1
3 2
2
0 0 6 2
0 10 -1 0
1
end_operator
begin_operator
debark car1 loc4
1
3 3
2
0 0 6 3
0 10 -1 0
1
end_operator
begin_operator
debark car1 loc5
1
3 4
2
0 0 6 4
0 10 -1 0
1
end_operator
begin_operator
debark car1 loc6
1
3 5
2
0 0 6 5
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc1
1
3 0
2
0 1 6 0
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc2
1
3 1
2
0 1 6 1
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc3
1
3 2
2
0 1 6 2
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc4
1
3 3
2
0 1 6 3
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc5
1
3 4
2
0 1 6 4
0 10 -1 0
1
end_operator
begin_operator
debark car2 loc6
1
3 5
2
0 1 6 5
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc1
1
3 0
2
0 2 6 0
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc2
1
3 1
2
0 2 6 1
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc3
1
3 2
2
0 2 6 2
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc4
1
3 3
2
0 2 6 3
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc5
1
3 4
2
0 2 6 4
0 10 -1 0
1
end_operator
begin_operator
debark car3 loc6
1
3 5
2
0 2 6 5
0 10 -1 0
1
end_operator
begin_operator
sail loc1 loc2
0
3
0 3 0 1
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
sail loc1 loc3
0
3
0 3 0 2
0 4 -1 0
0 6 0 1
1
end_operator
begin_operator
sail loc1 loc4
0
3
0 3 0 3
0 4 -1 0
0 7 0 1
1
end_operator
begin_operator
sail loc1 loc5
0
3
0 3 0 4
0 4 -1 0
0 8 0 1
1
end_operator
begin_operator
sail loc1 loc6
0
3
0 3 0 5
0 4 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc2 loc1
0
3
0 3 1 0
0 4 0 1
0 5 -1 0
1
end_operator
begin_operator
sail loc2 loc3
0
3
0 3 1 2
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
sail loc2 loc4
0
3
0 3 1 3
0 5 -1 0
0 7 0 1
1
end_operator
begin_operator
sail loc2 loc5
0
3
0 3 1 4
0 5 -1 0
0 8 0 1
1
end_operator
begin_operator
sail loc2 loc6
0
3
0 3 1 5
0 5 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc3 loc1
0
3
0 3 2 0
0 4 0 1
0 6 -1 0
1
end_operator
begin_operator
sail loc3 loc2
0
3
0 3 2 1
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
sail loc3 loc4
0
3
0 3 2 3
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
sail loc3 loc5
0
3
0 3 2 4
0 6 -1 0
0 8 0 1
1
end_operator
begin_operator
sail loc3 loc6
0
3
0 3 2 5
0 6 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc4 loc1
0
3
0 3 3 0
0 4 0 1
0 7 -1 0
1
end_operator
begin_operator
sail loc4 loc2
0
3
0 3 3 1
0 5 0 1
0 7 -1 0
1
end_operator
begin_operator
sail loc4 loc3
0
3
0 3 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
sail loc4 loc5
0
3
0 3 3 4
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
sail loc4 loc6
0
3
0 3 3 5
0 7 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc5 loc1
0
3
0 3 4 0
0 4 0 1
0 8 -1 0
1
end_operator
begin_operator
sail loc5 loc2
0
3
0 3 4 1
0 5 0 1
0 8 -1 0
1
end_operator
begin_operator
sail loc5 loc3
0
3
0 3 4 2
0 6 0 1
0 8 -1 0
1
end_operator
begin_operator
sail loc5 loc4
0
3
0 3 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
sail loc5 loc6
0
3
0 3 4 5
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
sail loc6 loc1
0
3
0 3 5 0
0 4 0 1
0 9 -1 0
1
end_operator
begin_operator
sail loc6 loc2
0
3
0 3 5 1
0 5 0 1
0 9 -1 0
1
end_operator
begin_operator
sail loc6 loc3
0
3
0 3 5 2
0 6 0 1
0 9 -1 0
1
end_operator
begin_operator
sail loc6 loc4
0
3
0 3 5 3
0 7 0 1
0 9 -1 0
1
end_operator
begin_operator
sail loc6 loc5
0
3
0 3 5 4
0 8 0 1
0 9 -1 0
1
end_operator
0
