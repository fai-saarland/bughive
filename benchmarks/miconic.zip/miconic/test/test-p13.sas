begin_version
3
end_version
begin_metric
1
end_metric
56
begin_variable
var0
-1
10
lift-at f1
lift-at f10
lift-at f2
lift-at f3
lift-at f4
lift-at f5
lift-at f6
lift-at f7
lift-at f8
lift-at f9
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f6
served p1
end_variable
begin_variable
var2
-1
3
boarded p2
origin p2 f2
served p2
end_variable
begin_variable
var3
-1
3
boarded p3
origin p3 f8
served p3
end_variable
begin_variable
var4
-1
3
boarded p4
origin p4 f4
served p4
end_variable
begin_variable
var5
-1
3
boarded p5
origin p5 f7
served p5
end_variable
begin_variable
var6
-1
2
above f1 f10
none-of-those
end_variable
begin_variable
var7
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var8
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var9
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var10
-1
2
above f1 f5
none-of-those
end_variable
begin_variable
var11
-1
2
above f1 f6
none-of-those
end_variable
begin_variable
var12
-1
2
above f1 f7
none-of-those
end_variable
begin_variable
var13
-1
2
above f1 f8
none-of-those
end_variable
begin_variable
var14
-1
2
above f1 f9
none-of-those
end_variable
begin_variable
var15
-1
2
above f2 f10
none-of-those
end_variable
begin_variable
var16
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var17
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var18
-1
2
above f2 f5
none-of-those
end_variable
begin_variable
var19
-1
2
above f2 f6
none-of-those
end_variable
begin_variable
var20
-1
2
above f2 f7
none-of-those
end_variable
begin_variable
var21
-1
2
above f2 f8
none-of-those
end_variable
begin_variable
var22
-1
2
above f2 f9
none-of-those
end_variable
begin_variable
var23
-1
2
above f3 f10
none-of-those
end_variable
begin_variable
var24
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var25
-1
2
above f3 f5
none-of-those
end_variable
begin_variable
var26
-1
2
above f3 f6
none-of-those
end_variable
begin_variable
var27
-1
2
above f3 f7
none-of-those
end_variable
begin_variable
var28
-1
2
above f3 f8
none-of-those
end_variable
begin_variable
var29
-1
2
above f3 f9
none-of-those
end_variable
begin_variable
var30
-1
2
above f4 f10
none-of-those
end_variable
begin_variable
var31
-1
2
above f4 f5
none-of-those
end_variable
begin_variable
var32
-1
2
above f4 f6
none-of-those
end_variable
begin_variable
var33
-1
2
above f4 f7
none-of-those
end_variable
begin_variable
var34
-1
2
above f4 f8
none-of-those
end_variable
begin_variable
var35
-1
2
above f4 f9
none-of-those
end_variable
begin_variable
var36
-1
2
above f5 f10
none-of-those
end_variable
begin_variable
var37
-1
2
above f5 f6
none-of-those
end_variable
begin_variable
var38
-1
2
above f5 f7
none-of-those
end_variable
begin_variable
var39
-1
2
above f5 f8
none-of-those
end_variable
begin_variable
var40
-1
2
above f5 f9
none-of-those
end_variable
begin_variable
var41
-1
2
above f6 f10
none-of-those
end_variable
begin_variable
var42
-1
2
above f6 f7
none-of-those
end_variable
begin_variable
var43
-1
2
above f6 f8
none-of-those
end_variable
begin_variable
var44
-1
2
above f6 f9
none-of-those
end_variable
begin_variable
var45
-1
2
above f7 f10
none-of-those
end_variable
begin_variable
var46
-1
2
above f7 f8
none-of-those
end_variable
begin_variable
var47
-1
2
above f7 f9
none-of-those
end_variable
begin_variable
var48
-1
2
above f8 f10
none-of-those
end_variable
begin_variable
var49
-1
2
above f8 f9
none-of-those
end_variable
begin_variable
var50
-1
2
above f9 f10
none-of-those
end_variable
begin_variable
var51
-1
2
destin p1 f4
none-of-those
end_variable
begin_variable
var52
-1
2
destin p2 f5
none-of-those
end_variable
begin_variable
var53
-1
2
destin p3 f10
none-of-those
end_variable
begin_variable
var54
-1
2
destin p4 f6
none-of-those
end_variable
begin_variable
var55
-1
2
destin p5 f8
none-of-those
end_variable
0
begin_state
0
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
5
1 2
2 2
3 2
4 2
5 2
end_goal
100
begin_operator
board f2 p2
1
0 2
1
0 2 1 0
1
end_operator
begin_operator
board f4 p4
1
0 4
1
0 4 1 0
1
end_operator
begin_operator
board f6 p1
1
0 6
1
0 1 1 0
1
end_operator
begin_operator
board f7 p5
1
0 7
1
0 5 1 0
1
end_operator
begin_operator
board f8 p3
1
0 8
1
0 3 1 0
1
end_operator
begin_operator
depart f10 p3
2
0 1
53 0
1
0 3 0 2
1
end_operator
begin_operator
depart f4 p1
2
0 4
51 0
1
0 1 0 2
1
end_operator
begin_operator
depart f5 p2
2
0 5
52 0
1
0 2 0 2
1
end_operator
begin_operator
depart f6 p4
2
0 6
54 0
1
0 4 0 2
1
end_operator
begin_operator
depart f8 p5
2
0 8
55 0
1
0 5 0 2
1
end_operator
begin_operator
down f10 f1
1
6 0
1
0 0 1 0
1
end_operator
begin_operator
down f10 f2
1
15 0
1
0 0 1 2
1
end_operator
begin_operator
down f10 f3
1
23 0
1
0 0 1 3
1
end_operator
begin_operator
down f10 f4
1
30 0
1
0 0 1 4
1
end_operator
begin_operator
down f10 f5
1
36 0
1
0 0 1 5
1
end_operator
begin_operator
down f10 f6
1
41 0
1
0 0 1 6
1
end_operator
begin_operator
down f10 f7
1
45 0
1
0 0 1 7
1
end_operator
begin_operator
down f10 f8
1
48 0
1
0 0 1 8
1
end_operator
begin_operator
down f10 f9
1
50 0
1
0 0 1 9
1
end_operator
begin_operator
down f2 f1
1
7 0
1
0 0 2 0
1
end_operator
begin_operator
down f3 f1
1
8 0
1
0 0 3 0
1
end_operator
begin_operator
down f3 f2
1
16 0
1
0 0 3 2
1
end_operator
begin_operator
down f4 f1
1
9 0
1
0 0 4 0
1
end_operator
begin_operator
down f4 f2
1
17 0
1
0 0 4 2
1
end_operator
begin_operator
down f4 f3
1
24 0
1
0 0 4 3
1
end_operator
begin_operator
down f5 f1
1
10 0
1
0 0 5 0
1
end_operator
begin_operator
down f5 f2
1
18 0
1
0 0 5 2
1
end_operator
begin_operator
down f5 f3
1
25 0
1
0 0 5 3
1
end_operator
begin_operator
down f5 f4
1
31 0
1
0 0 5 4
1
end_operator
begin_operator
down f6 f1
1
11 0
1
0 0 6 0
1
end_operator
begin_operator
down f6 f2
1
19 0
1
0 0 6 2
1
end_operator
begin_operator
down f6 f3
1
26 0
1
0 0 6 3
1
end_operator
begin_operator
down f6 f4
1
32 0
1
0 0 6 4
1
end_operator
begin_operator
down f6 f5
1
37 0
1
0 0 6 5
1
end_operator
begin_operator
down f7 f1
1
12 0
1
0 0 7 0
1
end_operator
begin_operator
down f7 f2
1
20 0
1
0 0 7 2
1
end_operator
begin_operator
down f7 f3
1
27 0
1
0 0 7 3
1
end_operator
begin_operator
down f7 f4
1
33 0
1
0 0 7 4
1
end_operator
begin_operator
down f7 f5
1
38 0
1
0 0 7 5
1
end_operator
begin_operator
down f7 f6
1
42 0
1
0 0 7 6
1
end_operator
begin_operator
down f8 f1
1
13 0
1
0 0 8 0
1
end_operator
begin_operator
down f8 f2
1
21 0
1
0 0 8 2
1
end_operator
begin_operator
down f8 f3
1
28 0
1
0 0 8 3
1
end_operator
begin_operator
down f8 f4
1
34 0
1
0 0 8 4
1
end_operator
begin_operator
down f8 f5
1
39 0
1
0 0 8 5
1
end_operator
begin_operator
down f8 f6
1
43 0
1
0 0 8 6
1
end_operator
begin_operator
down f8 f7
1
46 0
1
0 0 8 7
1
end_operator
begin_operator
down f9 f1
1
14 0
1
0 0 9 0
1
end_operator
begin_operator
down f9 f2
1
22 0
1
0 0 9 2
1
end_operator
begin_operator
down f9 f3
1
29 0
1
0 0 9 3
1
end_operator
begin_operator
down f9 f4
1
35 0
1
0 0 9 4
1
end_operator
begin_operator
down f9 f5
1
40 0
1
0 0 9 5
1
end_operator
begin_operator
down f9 f6
1
44 0
1
0 0 9 6
1
end_operator
begin_operator
down f9 f7
1
47 0
1
0 0 9 7
1
end_operator
begin_operator
down f9 f8
1
49 0
1
0 0 9 8
1
end_operator
begin_operator
up f1 f10
1
6 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f2
1
7 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f3
1
8 0
1
0 0 0 3
1
end_operator
begin_operator
up f1 f4
1
9 0
1
0 0 0 4
1
end_operator
begin_operator
up f1 f5
1
10 0
1
0 0 0 5
1
end_operator
begin_operator
up f1 f6
1
11 0
1
0 0 0 6
1
end_operator
begin_operator
up f1 f7
1
12 0
1
0 0 0 7
1
end_operator
begin_operator
up f1 f8
1
13 0
1
0 0 0 8
1
end_operator
begin_operator
up f1 f9
1
14 0
1
0 0 0 9
1
end_operator
begin_operator
up f2 f10
1
15 0
1
0 0 2 1
1
end_operator
begin_operator
up f2 f3
1
16 0
1
0 0 2 3
1
end_operator
begin_operator
up f2 f4
1
17 0
1
0 0 2 4
1
end_operator
begin_operator
up f2 f5
1
18 0
1
0 0 2 5
1
end_operator
begin_operator
up f2 f6
1
19 0
1
0 0 2 6
1
end_operator
begin_operator
up f2 f7
1
20 0
1
0 0 2 7
1
end_operator
begin_operator
up f2 f8
1
21 0
1
0 0 2 8
1
end_operator
begin_operator
up f2 f9
1
22 0
1
0 0 2 9
1
end_operator
begin_operator
up f3 f10
1
23 0
1
0 0 3 1
1
end_operator
begin_operator
up f3 f4
1
24 0
1
0 0 3 4
1
end_operator
begin_operator
up f3 f5
1
25 0
1
0 0 3 5
1
end_operator
begin_operator
up f3 f6
1
26 0
1
0 0 3 6
1
end_operator
begin_operator
up f3 f7
1
27 0
1
0 0 3 7
1
end_operator
begin_operator
up f3 f8
1
28 0
1
0 0 3 8
1
end_operator
begin_operator
up f3 f9
1
29 0
1
0 0 3 9
1
end_operator
begin_operator
up f4 f10
1
30 0
1
0 0 4 1
1
end_operator
begin_operator
up f4 f5
1
31 0
1
0 0 4 5
1
end_operator
begin_operator
up f4 f6
1
32 0
1
0 0 4 6
1
end_operator
begin_operator
up f4 f7
1
33 0
1
0 0 4 7
1
end_operator
begin_operator
up f4 f8
1
34 0
1
0 0 4 8
1
end_operator
begin_operator
up f4 f9
1
35 0
1
0 0 4 9
1
end_operator
begin_operator
up f5 f10
1
36 0
1
0 0 5 1
1
end_operator
begin_operator
up f5 f6
1
37 0
1
0 0 5 6
1
end_operator
begin_operator
up f5 f7
1
38 0
1
0 0 5 7
1
end_operator
begin_operator
up f5 f8
1
39 0
1
0 0 5 8
1
end_operator
begin_operator
up f5 f9
1
40 0
1
0 0 5 9
1
end_operator
begin_operator
up f6 f10
1
41 0
1
0 0 6 1
1
end_operator
begin_operator
up f6 f7
1
42 0
1
0 0 6 7
1
end_operator
begin_operator
up f6 f8
1
43 0
1
0 0 6 8
1
end_operator
begin_operator
up f6 f9
1
44 0
1
0 0 6 9
1
end_operator
begin_operator
up f7 f10
1
45 0
1
0 0 7 1
1
end_operator
begin_operator
up f7 f8
1
46 0
1
0 0 7 8
1
end_operator
begin_operator
up f7 f9
1
47 0
1
0 0 7 9
1
end_operator
begin_operator
up f8 f10
1
48 0
1
0 0 8 1
1
end_operator
begin_operator
up f8 f9
1
49 0
1
0 0 8 9
1
end_operator
begin_operator
up f9 f10
1
50 0
1
0 0 9 1
1
end_operator
0
