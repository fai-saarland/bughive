begin_version
3
end_version
begin_metric
1
end_metric
28
begin_variable
var0
-1
7
lift-at f1
lift-at f2
lift-at f3
lift-at f4
lift-at f5
lift-at f6
lift-at f7
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f1
served p1
end_variable
begin_variable
var2
-1
3
boarded p2
origin p2 f3
served p2
end_variable
begin_variable
var3
-1
3
boarded p3
origin p3 f4
served p3
end_variable
begin_variable
var4
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var5
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var6
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var7
-1
2
above f1 f5
none-of-those
end_variable
begin_variable
var8
-1
2
above f1 f6
none-of-those
end_variable
begin_variable
var9
-1
2
above f1 f7
none-of-those
end_variable
begin_variable
var10
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var11
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var12
-1
2
above f2 f5
none-of-those
end_variable
begin_variable
var13
-1
2
above f2 f6
none-of-those
end_variable
begin_variable
var14
-1
2
above f2 f7
none-of-those
end_variable
begin_variable
var15
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var16
-1
2
above f3 f5
none-of-those
end_variable
begin_variable
var17
-1
2
above f3 f6
none-of-those
end_variable
begin_variable
var18
-1
2
above f3 f7
none-of-those
end_variable
begin_variable
var19
-1
2
above f4 f5
none-of-those
end_variable
begin_variable
var20
-1
2
above f4 f6
none-of-those
end_variable
begin_variable
var21
-1
2
above f4 f7
none-of-those
end_variable
begin_variable
var22
-1
2
above f5 f6
none-of-those
end_variable
begin_variable
var23
-1
2
above f5 f7
none-of-those
end_variable
begin_variable
var24
-1
2
above f6 f7
none-of-those
end_variable
begin_variable
var25
-1
2
destin p1 f3
none-of-those
end_variable
begin_variable
var26
-1
2
destin p2 f1
none-of-those
end_variable
begin_variable
var27
-1
2
destin p3 f5
none-of-those
end_variable
0
begin_state
4
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
3
1 2
2 2
3 2
end_goal
48
begin_operator
board f1 p1
1
0 0
1
0 1 1 0
1
end_operator
begin_operator
board f3 p2
1
0 2
1
0 2 1 0
1
end_operator
begin_operator
board f4 p3
1
0 3
1
0 3 1 0
1
end_operator
begin_operator
depart f1 p2
2
0 0
26 0
1
0 2 0 2
1
end_operator
begin_operator
depart f3 p1
2
0 2
25 0
1
0 1 0 2
1
end_operator
begin_operator
depart f5 p3
2
0 4
27 0
1
0 3 0 2
1
end_operator
begin_operator
down f2 f1
1
4 0
1
0 0 1 0
1
end_operator
begin_operator
down f3 f1
1
5 0
1
0 0 2 0
1
end_operator
begin_operator
down f3 f2
1
10 0
1
0 0 2 1
1
end_operator
begin_operator
down f4 f1
1
6 0
1
0 0 3 0
1
end_operator
begin_operator
down f4 f2
1
11 0
1
0 0 3 1
1
end_operator
begin_operator
down f4 f3
1
15 0
1
0 0 3 2
1
end_operator
begin_operator
down f5 f1
1
7 0
1
0 0 4 0
1
end_operator
begin_operator
down f5 f2
1
12 0
1
0 0 4 1
1
end_operator
begin_operator
down f5 f3
1
16 0
1
0 0 4 2
1
end_operator
begin_operator
down f5 f4
1
19 0
1
0 0 4 3
1
end_operator
begin_operator
down f6 f1
1
8 0
1
0 0 5 0
1
end_operator
begin_operator
down f6 f2
1
13 0
1
0 0 5 1
1
end_operator
begin_operator
down f6 f3
1
17 0
1
0 0 5 2
1
end_operator
begin_operator
down f6 f4
1
20 0
1
0 0 5 3
1
end_operator
begin_operator
down f6 f5
1
22 0
1
0 0 5 4
1
end_operator
begin_operator
down f7 f1
1
9 0
1
0 0 6 0
1
end_operator
begin_operator
down f7 f2
1
14 0
1
0 0 6 1
1
end_operator
begin_operator
down f7 f3
1
18 0
1
0 0 6 2
1
end_operator
begin_operator
down f7 f4
1
21 0
1
0 0 6 3
1
end_operator
begin_operator
down f7 f5
1
23 0
1
0 0 6 4
1
end_operator
begin_operator
down f7 f6
1
24 0
1
0 0 6 5
1
end_operator
begin_operator
up f1 f2
1
4 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f3
1
5 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f4
1
6 0
1
0 0 0 3
1
end_operator
begin_operator
up f1 f5
1
7 0
1
0 0 0 4
1
end_operator
begin_operator
up f1 f6
1
8 0
1
0 0 0 5
1
end_operator
begin_operator
up f1 f7
1
9 0
1
0 0 0 6
1
end_operator
begin_operator
up f2 f3
1
10 0
1
0 0 1 2
1
end_operator
begin_operator
up f2 f4
1
11 0
1
0 0 1 3
1
end_operator
begin_operator
up f2 f5
1
12 0
1
0 0 1 4
1
end_operator
begin_operator
up f2 f6
1
13 0
1
0 0 1 5
1
end_operator
begin_operator
up f2 f7
1
14 0
1
0 0 1 6
1
end_operator
begin_operator
up f3 f4
1
15 0
1
0 0 2 3
1
end_operator
begin_operator
up f3 f5
1
16 0
1
0 0 2 4
1
end_operator
begin_operator
up f3 f6
1
17 0
1
0 0 2 5
1
end_operator
begin_operator
up f3 f7
1
18 0
1
0 0 2 6
1
end_operator
begin_operator
up f4 f5
1
19 0
1
0 0 3 4
1
end_operator
begin_operator
up f4 f6
1
20 0
1
0 0 3 5
1
end_operator
begin_operator
up f4 f7
1
21 0
1
0 0 3 6
1
end_operator
begin_operator
up f5 f6
1
22 0
1
0 0 4 5
1
end_operator
begin_operator
up f5 f7
1
23 0
1
0 0 4 6
1
end_operator
begin_operator
up f6 f7
1
24 0
1
0 0 5 6
1
end_operator
0
