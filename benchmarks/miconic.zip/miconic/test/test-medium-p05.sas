begin_version
3
end_version
begin_metric
1
end_metric
618
begin_variable
var0
-1
34
lift-at f1
lift-at f10
lift-at f11
lift-at f12
lift-at f13
lift-at f14
lift-at f15
lift-at f16
lift-at f17
lift-at f18
lift-at f19
lift-at f2
lift-at f20
lift-at f21
lift-at f22
lift-at f23
lift-at f24
lift-at f25
lift-at f26
lift-at f27
lift-at f28
lift-at f29
lift-at f3
lift-at f30
lift-at f31
lift-at f32
lift-at f33
lift-at f34
lift-at f4
lift-at f5
lift-at f6
lift-at f7
lift-at f8
lift-at f9
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f17
served p1
end_variable
begin_variable
var2
-1
3
boarded p10
origin p10 f28
served p10
end_variable
begin_variable
var3
-1
3
boarded p11
origin p11 f31
served p11
end_variable
begin_variable
var4
-1
3
boarded p12
origin p12 f31
served p12
end_variable
begin_variable
var5
-1
3
boarded p13
origin p13 f1
served p13
end_variable
begin_variable
var6
-1
3
boarded p14
origin p14 f34
served p14
end_variable
begin_variable
var7
-1
3
boarded p15
origin p15 f7
served p15
end_variable
begin_variable
var8
-1
3
boarded p16
origin p16 f29
served p16
end_variable
begin_variable
var9
-1
3
boarded p17
origin p17 f17
served p17
end_variable
begin_variable
var10
-1
3
boarded p18
origin p18 f9
served p18
end_variable
begin_variable
var11
-1
3
boarded p19
origin p19 f6
served p19
end_variable
begin_variable
var12
-1
3
boarded p2
origin p2 f27
served p2
end_variable
begin_variable
var13
-1
3
boarded p20
origin p20 f27
served p20
end_variable
begin_variable
var14
-1
3
boarded p21
origin p21 f17
served p21
end_variable
begin_variable
var15
-1
3
boarded p22
origin p22 f12
served p22
end_variable
begin_variable
var16
-1
3
boarded p23
origin p23 f33
served p23
end_variable
begin_variable
var17
-1
3
boarded p24
origin p24 f28
served p24
end_variable
begin_variable
var18
-1
3
boarded p25
origin p25 f12
served p25
end_variable
begin_variable
var19
-1
3
boarded p26
origin p26 f24
served p26
end_variable
begin_variable
var20
-1
3
boarded p27
origin p27 f9
served p27
end_variable
begin_variable
var21
-1
3
boarded p28
origin p28 f24
served p28
end_variable
begin_variable
var22
-1
3
boarded p3
origin p3 f29
served p3
end_variable
begin_variable
var23
-1
3
boarded p4
origin p4 f29
served p4
end_variable
begin_variable
var24
-1
3
boarded p5
origin p5 f17
served p5
end_variable
begin_variable
var25
-1
3
boarded p6
origin p6 f8
served p6
end_variable
begin_variable
var26
-1
3
boarded p7
origin p7 f19
served p7
end_variable
begin_variable
var27
-1
3
boarded p8
origin p8 f8
served p8
end_variable
begin_variable
var28
-1
3
boarded p9
origin p9 f14
served p9
end_variable
begin_variable
var29
-1
2
above f1 f10
none-of-those
end_variable
begin_variable
var30
-1
2
above f1 f11
none-of-those
end_variable
begin_variable
var31
-1
2
above f1 f12
none-of-those
end_variable
begin_variable
var32
-1
2
above f1 f13
none-of-those
end_variable
begin_variable
var33
-1
2
above f1 f14
none-of-those
end_variable
begin_variable
var34
-1
2
above f1 f15
none-of-those
end_variable
begin_variable
var35
-1
2
above f1 f16
none-of-those
end_variable
begin_variable
var36
-1
2
above f1 f17
none-of-those
end_variable
begin_variable
var37
-1
2
above f1 f18
none-of-those
end_variable
begin_variable
var38
-1
2
above f1 f19
none-of-those
end_variable
begin_variable
var39
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var40
-1
2
above f1 f20
none-of-those
end_variable
begin_variable
var41
-1
2
above f1 f21
none-of-those
end_variable
begin_variable
var42
-1
2
above f1 f22
none-of-those
end_variable
begin_variable
var43
-1
2
above f1 f23
none-of-those
end_variable
begin_variable
var44
-1
2
above f1 f24
none-of-those
end_variable
begin_variable
var45
-1
2
above f1 f25
none-of-those
end_variable
begin_variable
var46
-1
2
above f1 f26
none-of-those
end_variable
begin_variable
var47
-1
2
above f1 f27
none-of-those
end_variable
begin_variable
var48
-1
2
above f1 f28
none-of-those
end_variable
begin_variable
var49
-1
2
above f1 f29
none-of-those
end_variable
begin_variable
var50
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var51
-1
2
above f1 f30
none-of-those
end_variable
begin_variable
var52
-1
2
above f1 f31
none-of-those
end_variable
begin_variable
var53
-1
2
above f1 f32
none-of-those
end_variable
begin_variable
var54
-1
2
above f1 f33
none-of-those
end_variable
begin_variable
var55
-1
2
above f1 f34
none-of-those
end_variable
begin_variable
var56
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var57
-1
2
above f1 f5
none-of-those
end_variable
begin_variable
var58
-1
2
above f1 f6
none-of-those
end_variable
begin_variable
var59
-1
2
above f1 f7
none-of-those
end_variable
begin_variable
var60
-1
2
above f1 f8
none-of-those
end_variable
begin_variable
var61
-1
2
above f1 f9
none-of-those
end_variable
begin_variable
var62
-1
2
above f10 f11
none-of-those
end_variable
begin_variable
var63
-1
2
above f10 f12
none-of-those
end_variable
begin_variable
var64
-1
2
above f10 f13
none-of-those
end_variable
begin_variable
var65
-1
2
above f10 f14
none-of-those
end_variable
begin_variable
var66
-1
2
above f10 f15
none-of-those
end_variable
begin_variable
var67
-1
2
above f10 f16
none-of-those
end_variable
begin_variable
var68
-1
2
above f10 f17
none-of-those
end_variable
begin_variable
var69
-1
2
above f10 f18
none-of-those
end_variable
begin_variable
var70
-1
2
above f10 f19
none-of-those
end_variable
begin_variable
var71
-1
2
above f10 f20
none-of-those
end_variable
begin_variable
var72
-1
2
above f10 f21
none-of-those
end_variable
begin_variable
var73
-1
2
above f10 f22
none-of-those
end_variable
begin_variable
var74
-1
2
above f10 f23
none-of-those
end_variable
begin_variable
var75
-1
2
above f10 f24
none-of-those
end_variable
begin_variable
var76
-1
2
above f10 f25
none-of-those
end_variable
begin_variable
var77
-1
2
above f10 f26
none-of-those
end_variable
begin_variable
var78
-1
2
above f10 f27
none-of-those
end_variable
begin_variable
var79
-1
2
above f10 f28
none-of-those
end_variable
begin_variable
var80
-1
2
above f10 f29
none-of-those
end_variable
begin_variable
var81
-1
2
above f10 f30
none-of-those
end_variable
begin_variable
var82
-1
2
above f10 f31
none-of-those
end_variable
begin_variable
var83
-1
2
above f10 f32
none-of-those
end_variable
begin_variable
var84
-1
2
above f10 f33
none-of-those
end_variable
begin_variable
var85
-1
2
above f10 f34
none-of-those
end_variable
begin_variable
var86
-1
2
above f11 f12
none-of-those
end_variable
begin_variable
var87
-1
2
above f11 f13
none-of-those
end_variable
begin_variable
var88
-1
2
above f11 f14
none-of-those
end_variable
begin_variable
var89
-1
2
above f11 f15
none-of-those
end_variable
begin_variable
var90
-1
2
above f11 f16
none-of-those
end_variable
begin_variable
var91
-1
2
above f11 f17
none-of-those
end_variable
begin_variable
var92
-1
2
above f11 f18
none-of-those
end_variable
begin_variable
var93
-1
2
above f11 f19
none-of-those
end_variable
begin_variable
var94
-1
2
above f11 f20
none-of-those
end_variable
begin_variable
var95
-1
2
above f11 f21
none-of-those
end_variable
begin_variable
var96
-1
2
above f11 f22
none-of-those
end_variable
begin_variable
var97
-1
2
above f11 f23
none-of-those
end_variable
begin_variable
var98
-1
2
above f11 f24
none-of-those
end_variable
begin_variable
var99
-1
2
above f11 f25
none-of-those
end_variable
begin_variable
var100
-1
2
above f11 f26
none-of-those
end_variable
begin_variable
var101
-1
2
above f11 f27
none-of-those
end_variable
begin_variable
var102
-1
2
above f11 f28
none-of-those
end_variable
begin_variable
var103
-1
2
above f11 f29
none-of-those
end_variable
begin_variable
var104
-1
2
above f11 f30
none-of-those
end_variable
begin_variable
var105
-1
2
above f11 f31
none-of-those
end_variable
begin_variable
var106
-1
2
above f11 f32
none-of-those
end_variable
begin_variable
var107
-1
2
above f11 f33
none-of-those
end_variable
begin_variable
var108
-1
2
above f11 f34
none-of-those
end_variable
begin_variable
var109
-1
2
above f12 f13
none-of-those
end_variable
begin_variable
var110
-1
2
above f12 f14
none-of-those
end_variable
begin_variable
var111
-1
2
above f12 f15
none-of-those
end_variable
begin_variable
var112
-1
2
above f12 f16
none-of-those
end_variable
begin_variable
var113
-1
2
above f12 f17
none-of-those
end_variable
begin_variable
var114
-1
2
above f12 f18
none-of-those
end_variable
begin_variable
var115
-1
2
above f12 f19
none-of-those
end_variable
begin_variable
var116
-1
2
above f12 f20
none-of-those
end_variable
begin_variable
var117
-1
2
above f12 f21
none-of-those
end_variable
begin_variable
var118
-1
2
above f12 f22
none-of-those
end_variable
begin_variable
var119
-1
2
above f12 f23
none-of-those
end_variable
begin_variable
var120
-1
2
above f12 f24
none-of-those
end_variable
begin_variable
var121
-1
2
above f12 f25
none-of-those
end_variable
begin_variable
var122
-1
2
above f12 f26
none-of-those
end_variable
begin_variable
var123
-1
2
above f12 f27
none-of-those
end_variable
begin_variable
var124
-1
2
above f12 f28
none-of-those
end_variable
begin_variable
var125
-1
2
above f12 f29
none-of-those
end_variable
begin_variable
var126
-1
2
above f12 f30
none-of-those
end_variable
begin_variable
var127
-1
2
above f12 f31
none-of-those
end_variable
begin_variable
var128
-1
2
above f12 f32
none-of-those
end_variable
begin_variable
var129
-1
2
above f12 f33
none-of-those
end_variable
begin_variable
var130
-1
2
above f12 f34
none-of-those
end_variable
begin_variable
var131
-1
2
above f13 f14
none-of-those
end_variable
begin_variable
var132
-1
2
above f13 f15
none-of-those
end_variable
begin_variable
var133
-1
2
above f13 f16
none-of-those
end_variable
begin_variable
var134
-1
2
above f13 f17
none-of-those
end_variable
begin_variable
var135
-1
2
above f13 f18
none-of-those
end_variable
begin_variable
var136
-1
2
above f13 f19
none-of-those
end_variable
begin_variable
var137
-1
2
above f13 f20
none-of-those
end_variable
begin_variable
var138
-1
2
above f13 f21
none-of-those
end_variable
begin_variable
var139
-1
2
above f13 f22
none-of-those
end_variable
begin_variable
var140
-1
2
above f13 f23
none-of-those
end_variable
begin_variable
var141
-1
2
above f13 f24
none-of-those
end_variable
begin_variable
var142
-1
2
above f13 f25
none-of-those
end_variable
begin_variable
var143
-1
2
above f13 f26
none-of-those
end_variable
begin_variable
var144
-1
2
above f13 f27
none-of-those
end_variable
begin_variable
var145
-1
2
above f13 f28
none-of-those
end_variable
begin_variable
var146
-1
2
above f13 f29
none-of-those
end_variable
begin_variable
var147
-1
2
above f13 f30
none-of-those
end_variable
begin_variable
var148
-1
2
above f13 f31
none-of-those
end_variable
begin_variable
var149
-1
2
above f13 f32
none-of-those
end_variable
begin_variable
var150
-1
2
above f13 f33
none-of-those
end_variable
begin_variable
var151
-1
2
above f13 f34
none-of-those
end_variable
begin_variable
var152
-1
2
above f14 f15
none-of-those
end_variable
begin_variable
var153
-1
2
above f14 f16
none-of-those
end_variable
begin_variable
var154
-1
2
above f14 f17
none-of-those
end_variable
begin_variable
var155
-1
2
above f14 f18
none-of-those
end_variable
begin_variable
var156
-1
2
above f14 f19
none-of-those
end_variable
begin_variable
var157
-1
2
above f14 f20
none-of-those
end_variable
begin_variable
var158
-1
2
above f14 f21
none-of-those
end_variable
begin_variable
var159
-1
2
above f14 f22
none-of-those
end_variable
begin_variable
var160
-1
2
above f14 f23
none-of-those
end_variable
begin_variable
var161
-1
2
above f14 f24
none-of-those
end_variable
begin_variable
var162
-1
2
above f14 f25
none-of-those
end_variable
begin_variable
var163
-1
2
above f14 f26
none-of-those
end_variable
begin_variable
var164
-1
2
above f14 f27
none-of-those
end_variable
begin_variable
var165
-1
2
above f14 f28
none-of-those
end_variable
begin_variable
var166
-1
2
above f14 f29
none-of-those
end_variable
begin_variable
var167
-1
2
above f14 f30
none-of-those
end_variable
begin_variable
var168
-1
2
above f14 f31
none-of-those
end_variable
begin_variable
var169
-1
2
above f14 f32
none-of-those
end_variable
begin_variable
var170
-1
2
above f14 f33
none-of-those
end_variable
begin_variable
var171
-1
2
above f14 f34
none-of-those
end_variable
begin_variable
var172
-1
2
above f15 f16
none-of-those
end_variable
begin_variable
var173
-1
2
above f15 f17
none-of-those
end_variable
begin_variable
var174
-1
2
above f15 f18
none-of-those
end_variable
begin_variable
var175
-1
2
above f15 f19
none-of-those
end_variable
begin_variable
var176
-1
2
above f15 f20
none-of-those
end_variable
begin_variable
var177
-1
2
above f15 f21
none-of-those
end_variable
begin_variable
var178
-1
2
above f15 f22
none-of-those
end_variable
begin_variable
var179
-1
2
above f15 f23
none-of-those
end_variable
begin_variable
var180
-1
2
above f15 f24
none-of-those
end_variable
begin_variable
var181
-1
2
above f15 f25
none-of-those
end_variable
begin_variable
var182
-1
2
above f15 f26
none-of-those
end_variable
begin_variable
var183
-1
2
above f15 f27
none-of-those
end_variable
begin_variable
var184
-1
2
above f15 f28
none-of-those
end_variable
begin_variable
var185
-1
2
above f15 f29
none-of-those
end_variable
begin_variable
var186
-1
2
above f15 f30
none-of-those
end_variable
begin_variable
var187
-1
2
above f15 f31
none-of-those
end_variable
begin_variable
var188
-1
2
above f15 f32
none-of-those
end_variable
begin_variable
var189
-1
2
above f15 f33
none-of-those
end_variable
begin_variable
var190
-1
2
above f15 f34
none-of-those
end_variable
begin_variable
var191
-1
2
above f16 f17
none-of-those
end_variable
begin_variable
var192
-1
2
above f16 f18
none-of-those
end_variable
begin_variable
var193
-1
2
above f16 f19
none-of-those
end_variable
begin_variable
var194
-1
2
above f16 f20
none-of-those
end_variable
begin_variable
var195
-1
2
above f16 f21
none-of-those
end_variable
begin_variable
var196
-1
2
above f16 f22
none-of-those
end_variable
begin_variable
var197
-1
2
above f16 f23
none-of-those
end_variable
begin_variable
var198
-1
2
above f16 f24
none-of-those
end_variable
begin_variable
var199
-1
2
above f16 f25
none-of-those
end_variable
begin_variable
var200
-1
2
above f16 f26
none-of-those
end_variable
begin_variable
var201
-1
2
above f16 f27
none-of-those
end_variable
begin_variable
var202
-1
2
above f16 f28
none-of-those
end_variable
begin_variable
var203
-1
2
above f16 f29
none-of-those
end_variable
begin_variable
var204
-1
2
above f16 f30
none-of-those
end_variable
begin_variable
var205
-1
2
above f16 f31
none-of-those
end_variable
begin_variable
var206
-1
2
above f16 f32
none-of-those
end_variable
begin_variable
var207
-1
2
above f16 f33
none-of-those
end_variable
begin_variable
var208
-1
2
above f16 f34
none-of-those
end_variable
begin_variable
var209
-1
2
above f17 f18
none-of-those
end_variable
begin_variable
var210
-1
2
above f17 f19
none-of-those
end_variable
begin_variable
var211
-1
2
above f17 f20
none-of-those
end_variable
begin_variable
var212
-1
2
above f17 f21
none-of-those
end_variable
begin_variable
var213
-1
2
above f17 f22
none-of-those
end_variable
begin_variable
var214
-1
2
above f17 f23
none-of-those
end_variable
begin_variable
var215
-1
2
above f17 f24
none-of-those
end_variable
begin_variable
var216
-1
2
above f17 f25
none-of-those
end_variable
begin_variable
var217
-1
2
above f17 f26
none-of-those
end_variable
begin_variable
var218
-1
2
above f17 f27
none-of-those
end_variable
begin_variable
var219
-1
2
above f17 f28
none-of-those
end_variable
begin_variable
var220
-1
2
above f17 f29
none-of-those
end_variable
begin_variable
var221
-1
2
above f17 f30
none-of-those
end_variable
begin_variable
var222
-1
2
above f17 f31
none-of-those
end_variable
begin_variable
var223
-1
2
above f17 f32
none-of-those
end_variable
begin_variable
var224
-1
2
above f17 f33
none-of-those
end_variable
begin_variable
var225
-1
2
above f17 f34
none-of-those
end_variable
begin_variable
var226
-1
2
above f18 f19
none-of-those
end_variable
begin_variable
var227
-1
2
above f18 f20
none-of-those
end_variable
begin_variable
var228
-1
2
above f18 f21
none-of-those
end_variable
begin_variable
var229
-1
2
above f18 f22
none-of-those
end_variable
begin_variable
var230
-1
2
above f18 f23
none-of-those
end_variable
begin_variable
var231
-1
2
above f18 f24
none-of-those
end_variable
begin_variable
var232
-1
2
above f18 f25
none-of-those
end_variable
begin_variable
var233
-1
2
above f18 f26
none-of-those
end_variable
begin_variable
var234
-1
2
above f18 f27
none-of-those
end_variable
begin_variable
var235
-1
2
above f18 f28
none-of-those
end_variable
begin_variable
var236
-1
2
above f18 f29
none-of-those
end_variable
begin_variable
var237
-1
2
above f18 f30
none-of-those
end_variable
begin_variable
var238
-1
2
above f18 f31
none-of-those
end_variable
begin_variable
var239
-1
2
above f18 f32
none-of-those
end_variable
begin_variable
var240
-1
2
above f18 f33
none-of-those
end_variable
begin_variable
var241
-1
2
above f18 f34
none-of-those
end_variable
begin_variable
var242
-1
2
above f19 f20
none-of-those
end_variable
begin_variable
var243
-1
2
above f19 f21
none-of-those
end_variable
begin_variable
var244
-1
2
above f19 f22
none-of-those
end_variable
begin_variable
var245
-1
2
above f19 f23
none-of-those
end_variable
begin_variable
var246
-1
2
above f19 f24
none-of-those
end_variable
begin_variable
var247
-1
2
above f19 f25
none-of-those
end_variable
begin_variable
var248
-1
2
above f19 f26
none-of-those
end_variable
begin_variable
var249
-1
2
above f19 f27
none-of-those
end_variable
begin_variable
var250
-1
2
above f19 f28
none-of-those
end_variable
begin_variable
var251
-1
2
above f19 f29
none-of-those
end_variable
begin_variable
var252
-1
2
above f19 f30
none-of-those
end_variable
begin_variable
var253
-1
2
above f19 f31
none-of-those
end_variable
begin_variable
var254
-1
2
above f19 f32
none-of-those
end_variable
begin_variable
var255
-1
2
above f19 f33
none-of-those
end_variable
begin_variable
var256
-1
2
above f19 f34
none-of-those
end_variable
begin_variable
var257
-1
2
above f2 f10
none-of-those
end_variable
begin_variable
var258
-1
2
above f2 f11
none-of-those
end_variable
begin_variable
var259
-1
2
above f2 f12
none-of-those
end_variable
begin_variable
var260
-1
2
above f2 f13
none-of-those
end_variable
begin_variable
var261
-1
2
above f2 f14
none-of-those
end_variable
begin_variable
var262
-1
2
above f2 f15
none-of-those
end_variable
begin_variable
var263
-1
2
above f2 f16
none-of-those
end_variable
begin_variable
var264
-1
2
above f2 f17
none-of-those
end_variable
begin_variable
var265
-1
2
above f2 f18
none-of-those
end_variable
begin_variable
var266
-1
2
above f2 f19
none-of-those
end_variable
begin_variable
var267
-1
2
above f2 f20
none-of-those
end_variable
begin_variable
var268
-1
2
above f2 f21
none-of-those
end_variable
begin_variable
var269
-1
2
above f2 f22
none-of-those
end_variable
begin_variable
var270
-1
2
above f2 f23
none-of-those
end_variable
begin_variable
var271
-1
2
above f2 f24
none-of-those
end_variable
begin_variable
var272
-1
2
above f2 f25
none-of-those
end_variable
begin_variable
var273
-1
2
above f2 f26
none-of-those
end_variable
begin_variable
var274
-1
2
above f2 f27
none-of-those
end_variable
begin_variable
var275
-1
2
above f2 f28
none-of-those
end_variable
begin_variable
var276
-1
2
above f2 f29
none-of-those
end_variable
begin_variable
var277
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var278
-1
2
above f2 f30
none-of-those
end_variable
begin_variable
var279
-1
2
above f2 f31
none-of-those
end_variable
begin_variable
var280
-1
2
above f2 f32
none-of-those
end_variable
begin_variable
var281
-1
2
above f2 f33
none-of-those
end_variable
begin_variable
var282
-1
2
above f2 f34
none-of-those
end_variable
begin_variable
var283
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var284
-1
2
above f2 f5
none-of-those
end_variable
begin_variable
var285
-1
2
above f2 f6
none-of-those
end_variable
begin_variable
var286
-1
2
above f2 f7
none-of-those
end_variable
begin_variable
var287
-1
2
above f2 f8
none-of-those
end_variable
begin_variable
var288
-1
2
above f2 f9
none-of-those
end_variable
begin_variable
var289
-1
2
above f20 f21
none-of-those
end_variable
begin_variable
var290
-1
2
above f20 f22
none-of-those
end_variable
begin_variable
var291
-1
2
above f20 f23
none-of-those
end_variable
begin_variable
var292
-1
2
above f20 f24
none-of-those
end_variable
begin_variable
var293
-1
2
above f20 f25
none-of-those
end_variable
begin_variable
var294
-1
2
above f20 f26
none-of-those
end_variable
begin_variable
var295
-1
2
above f20 f27
none-of-those
end_variable
begin_variable
var296
-1
2
above f20 f28
none-of-those
end_variable
begin_variable
var297
-1
2
above f20 f29
none-of-those
end_variable
begin_variable
var298
-1
2
above f20 f30
none-of-those
end_variable
begin_variable
var299
-1
2
above f20 f31
none-of-those
end_variable
begin_variable
var300
-1
2
above f20 f32
none-of-those
end_variable
begin_variable
var301
-1
2
above f20 f33
none-of-those
end_variable
begin_variable
var302
-1
2
above f20 f34
none-of-those
end_variable
begin_variable
var303
-1
2
above f21 f22
none-of-those
end_variable
begin_variable
var304
-1
2
above f21 f23
none-of-those
end_variable
begin_variable
var305
-1
2
above f21 f24
none-of-those
end_variable
begin_variable
var306
-1
2
above f21 f25
none-of-those
end_variable
begin_variable
var307
-1
2
above f21 f26
none-of-those
end_variable
begin_variable
var308
-1
2
above f21 f27
none-of-those
end_variable
begin_variable
var309
-1
2
above f21 f28
none-of-those
end_variable
begin_variable
var310
-1
2
above f21 f29
none-of-those
end_variable
begin_variable
var311
-1
2
above f21 f30
none-of-those
end_variable
begin_variable
var312
-1
2
above f21 f31
none-of-those
end_variable
begin_variable
var313
-1
2
above f21 f32
none-of-those
end_variable
begin_variable
var314
-1
2
above f21 f33
none-of-those
end_variable
begin_variable
var315
-1
2
above f21 f34
none-of-those
end_variable
begin_variable
var316
-1
2
above f22 f23
none-of-those
end_variable
begin_variable
var317
-1
2
above f22 f24
none-of-those
end_variable
begin_variable
var318
-1
2
above f22 f25
none-of-those
end_variable
begin_variable
var319
-1
2
above f22 f26
none-of-those
end_variable
begin_variable
var320
-1
2
above f22 f27
none-of-those
end_variable
begin_variable
var321
-1
2
above f22 f28
none-of-those
end_variable
begin_variable
var322
-1
2
above f22 f29
none-of-those
end_variable
begin_variable
var323
-1
2
above f22 f30
none-of-those
end_variable
begin_variable
var324
-1
2
above f22 f31
none-of-those
end_variable
begin_variable
var325
-1
2
above f22 f32
none-of-those
end_variable
begin_variable
var326
-1
2
above f22 f33
none-of-those
end_variable
begin_variable
var327
-1
2
above f22 f34
none-of-those
end_variable
begin_variable
var328
-1
2
above f23 f24
none-of-those
end_variable
begin_variable
var329
-1
2
above f23 f25
none-of-those
end_variable
begin_variable
var330
-1
2
above f23 f26
none-of-those
end_variable
begin_variable
var331
-1
2
above f23 f27
none-of-those
end_variable
begin_variable
var332
-1
2
above f23 f28
none-of-those
end_variable
begin_variable
var333
-1
2
above f23 f29
none-of-those
end_variable
begin_variable
var334
-1
2
above f23 f30
none-of-those
end_variable
begin_variable
var335
-1
2
above f23 f31
none-of-those
end_variable
begin_variable
var336
-1
2
above f23 f32
none-of-those
end_variable
begin_variable
var337
-1
2
above f23 f33
none-of-those
end_variable
begin_variable
var338
-1
2
above f23 f34
none-of-those
end_variable
begin_variable
var339
-1
2
above f24 f25
none-of-those
end_variable
begin_variable
var340
-1
2
above f24 f26
none-of-those
end_variable
begin_variable
var341
-1
2
above f24 f27
none-of-those
end_variable
begin_variable
var342
-1
2
above f24 f28
none-of-those
end_variable
begin_variable
var343
-1
2
above f24 f29
none-of-those
end_variable
begin_variable
var344
-1
2
above f24 f30
none-of-those
end_variable
begin_variable
var345
-1
2
above f24 f31
none-of-those
end_variable
begin_variable
var346
-1
2
above f24 f32
none-of-those
end_variable
begin_variable
var347
-1
2
above f24 f33
none-of-those
end_variable
begin_variable
var348
-1
2
above f24 f34
none-of-those
end_variable
begin_variable
var349
-1
2
above f25 f26
none-of-those
end_variable
begin_variable
var350
-1
2
above f25 f27
none-of-those
end_variable
begin_variable
var351
-1
2
above f25 f28
none-of-those
end_variable
begin_variable
var352
-1
2
above f25 f29
none-of-those
end_variable
begin_variable
var353
-1
2
above f25 f30
none-of-those
end_variable
begin_variable
var354
-1
2
above f25 f31
none-of-those
end_variable
begin_variable
var355
-1
2
above f25 f32
none-of-those
end_variable
begin_variable
var356
-1
2
above f25 f33
none-of-those
end_variable
begin_variable
var357
-1
2
above f25 f34
none-of-those
end_variable
begin_variable
var358
-1
2
above f26 f27
none-of-those
end_variable
begin_variable
var359
-1
2
above f26 f28
none-of-those
end_variable
begin_variable
var360
-1
2
above f26 f29
none-of-those
end_variable
begin_variable
var361
-1
2
above f26 f30
none-of-those
end_variable
begin_variable
var362
-1
2
above f26 f31
none-of-those
end_variable
begin_variable
var363
-1
2
above f26 f32
none-of-those
end_variable
begin_variable
var364
-1
2
above f26 f33
none-of-those
end_variable
begin_variable
var365
-1
2
above f26 f34
none-of-those
end_variable
begin_variable
var366
-1
2
above f27 f28
none-of-those
end_variable
begin_variable
var367
-1
2
above f27 f29
none-of-those
end_variable
begin_variable
var368
-1
2
above f27 f30
none-of-those
end_variable
begin_variable
var369
-1
2
above f27 f31
none-of-those
end_variable
begin_variable
var370
-1
2
above f27 f32
none-of-those
end_variable
begin_variable
var371
-1
2
above f27 f33
none-of-those
end_variable
begin_variable
var372
-1
2
above f27 f34
none-of-those
end_variable
begin_variable
var373
-1
2
above f28 f29
none-of-those
end_variable
begin_variable
var374
-1
2
above f28 f30
none-of-those
end_variable
begin_variable
var375
-1
2
above f28 f31
none-of-those
end_variable
begin_variable
var376
-1
2
above f28 f32
none-of-those
end_variable
begin_variable
var377
-1
2
above f28 f33
none-of-those
end_variable
begin_variable
var378
-1
2
above f28 f34
none-of-those
end_variable
begin_variable
var379
-1
2
above f29 f30
none-of-those
end_variable
begin_variable
var380
-1
2
above f29 f31
none-of-those
end_variable
begin_variable
var381
-1
2
above f29 f32
none-of-those
end_variable
begin_variable
var382
-1
2
above f29 f33
none-of-those
end_variable
begin_variable
var383
-1
2
above f29 f34
none-of-those
end_variable
begin_variable
var384
-1
2
above f3 f10
none-of-those
end_variable
begin_variable
var385
-1
2
above f3 f11
none-of-those
end_variable
begin_variable
var386
-1
2
above f3 f12
none-of-those
end_variable
begin_variable
var387
-1
2
above f3 f13
none-of-those
end_variable
begin_variable
var388
-1
2
above f3 f14
none-of-those
end_variable
begin_variable
var389
-1
2
above f3 f15
none-of-those
end_variable
begin_variable
var390
-1
2
above f3 f16
none-of-those
end_variable
begin_variable
var391
-1
2
above f3 f17
none-of-those
end_variable
begin_variable
var392
-1
2
above f3 f18
none-of-those
end_variable
begin_variable
var393
-1
2
above f3 f19
none-of-those
end_variable
begin_variable
var394
-1
2
above f3 f20
none-of-those
end_variable
begin_variable
var395
-1
2
above f3 f21
none-of-those
end_variable
begin_variable
var396
-1
2
above f3 f22
none-of-those
end_variable
begin_variable
var397
-1
2
above f3 f23
none-of-those
end_variable
begin_variable
var398
-1
2
above f3 f24
none-of-those
end_variable
begin_variable
var399
-1
2
above f3 f25
none-of-those
end_variable
begin_variable
var400
-1
2
above f3 f26
none-of-those
end_variable
begin_variable
var401
-1
2
above f3 f27
none-of-those
end_variable
begin_variable
var402
-1
2
above f3 f28
none-of-those
end_variable
begin_variable
var403
-1
2
above f3 f29
none-of-those
end_variable
begin_variable
var404
-1
2
above f3 f30
none-of-those
end_variable
begin_variable
var405
-1
2
above f3 f31
none-of-those
end_variable
begin_variable
var406
-1
2
above f3 f32
none-of-those
end_variable
begin_variable
var407
-1
2
above f3 f33
none-of-those
end_variable
begin_variable
var408
-1
2
above f3 f34
none-of-those
end_variable
begin_variable
var409
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var410
-1
2
above f3 f5
none-of-those
end_variable
begin_variable
var411
-1
2
above f3 f6
none-of-those
end_variable
begin_variable
var412
-1
2
above f3 f7
none-of-those
end_variable
begin_variable
var413
-1
2
above f3 f8
none-of-those
end_variable
begin_variable
var414
-1
2
above f3 f9
none-of-those
end_variable
begin_variable
var415
-1
2
above f30 f31
none-of-those
end_variable
begin_variable
var416
-1
2
above f30 f32
none-of-those
end_variable
begin_variable
var417
-1
2
above f30 f33
none-of-those
end_variable
begin_variable
var418
-1
2
above f30 f34
none-of-those
end_variable
begin_variable
var419
-1
2
above f31 f32
none-of-those
end_variable
begin_variable
var420
-1
2
above f31 f33
none-of-those
end_variable
begin_variable
var421
-1
2
above f31 f34
none-of-those
end_variable
begin_variable
var422
-1
2
above f32 f33
none-of-those
end_variable
begin_variable
var423
-1
2
above f32 f34
none-of-those
end_variable
begin_variable
var424
-1
2
above f33 f34
none-of-those
end_variable
begin_variable
var425
-1
2
above f4 f10
none-of-those
end_variable
begin_variable
var426
-1
2
above f4 f11
none-of-those
end_variable
begin_variable
var427
-1
2
above f4 f12
none-of-those
end_variable
begin_variable
var428
-1
2
above f4 f13
none-of-those
end_variable
begin_variable
var429
-1
2
above f4 f14
none-of-those
end_variable
begin_variable
var430
-1
2
above f4 f15
none-of-those
end_variable
begin_variable
var431
-1
2
above f4 f16
none-of-those
end_variable
begin_variable
var432
-1
2
above f4 f17
none-of-those
end_variable
begin_variable
var433
-1
2
above f4 f18
none-of-those
end_variable
begin_variable
var434
-1
2
above f4 f19
none-of-those
end_variable
begin_variable
var435
-1
2
above f4 f20
none-of-those
end_variable
begin_variable
var436
-1
2
above f4 f21
none-of-those
end_variable
begin_variable
var437
-1
2
above f4 f22
none-of-those
end_variable
begin_variable
var438
-1
2
above f4 f23
none-of-those
end_variable
begin_variable
var439
-1
2
above f4 f24
none-of-those
end_variable
begin_variable
var440
-1
2
above f4 f25
none-of-those
end_variable
begin_variable
var441
-1
2
above f4 f26
none-of-those
end_variable
begin_variable
var442
-1
2
above f4 f27
none-of-those
end_variable
begin_variable
var443
-1
2
above f4 f28
none-of-those
end_variable
begin_variable
var444
-1
2
above f4 f29
none-of-those
end_variable
begin_variable
var445
-1
2
above f4 f30
none-of-those
end_variable
begin_variable
var446
-1
2
above f4 f31
none-of-those
end_variable
begin_variable
var447
-1
2
above f4 f32
none-of-those
end_variable
begin_variable
var448
-1
2
above f4 f33
none-of-those
end_variable
begin_variable
var449
-1
2
above f4 f34
none-of-those
end_variable
begin_variable
var450
-1
2
above f4 f5
none-of-those
end_variable
begin_variable
var451
-1
2
above f4 f6
none-of-those
end_variable
begin_variable
var452
-1
2
above f4 f7
none-of-those
end_variable
begin_variable
var453
-1
2
above f4 f8
none-of-those
end_variable
begin_variable
var454
-1
2
above f4 f9
none-of-those
end_variable
begin_variable
var455
-1
2
above f5 f10
none-of-those
end_variable
begin_variable
var456
-1
2
above f5 f11
none-of-those
end_variable
begin_variable
var457
-1
2
above f5 f12
none-of-those
end_variable
begin_variable
var458
-1
2
above f5 f13
none-of-those
end_variable
begin_variable
var459
-1
2
above f5 f14
none-of-those
end_variable
begin_variable
var460
-1
2
above f5 f15
none-of-those
end_variable
begin_variable
var461
-1
2
above f5 f16
none-of-those
end_variable
begin_variable
var462
-1
2
above f5 f17
none-of-those
end_variable
begin_variable
var463
-1
2
above f5 f18
none-of-those
end_variable
begin_variable
var464
-1
2
above f5 f19
none-of-those
end_variable
begin_variable
var465
-1
2
above f5 f20
none-of-those
end_variable
begin_variable
var466
-1
2
above f5 f21
none-of-those
end_variable
begin_variable
var467
-1
2
above f5 f22
none-of-those
end_variable
begin_variable
var468
-1
2
above f5 f23
none-of-those
end_variable
begin_variable
var469
-1
2
above f5 f24
none-of-those
end_variable
begin_variable
var470
-1
2
above f5 f25
none-of-those
end_variable
begin_variable
var471
-1
2
above f5 f26
none-of-those
end_variable
begin_variable
var472
-1
2
above f5 f27
none-of-those
end_variable
begin_variable
var473
-1
2
above f5 f28
none-of-those
end_variable
begin_variable
var474
-1
2
above f5 f29
none-of-those
end_variable
begin_variable
var475
-1
2
above f5 f30
none-of-those
end_variable
begin_variable
var476
-1
2
above f5 f31
none-of-those
end_variable
begin_variable
var477
-1
2
above f5 f32
none-of-those
end_variable
begin_variable
var478
-1
2
above f5 f33
none-of-those
end_variable
begin_variable
var479
-1
2
above f5 f34
none-of-those
end_variable
begin_variable
var480
-1
2
above f5 f6
none-of-those
end_variable
begin_variable
var481
-1
2
above f5 f7
none-of-those
end_variable
begin_variable
var482
-1
2
above f5 f8
none-of-those
end_variable
begin_variable
var483
-1
2
above f5 f9
none-of-those
end_variable
begin_variable
var484
-1
2
above f6 f10
none-of-those
end_variable
begin_variable
var485
-1
2
above f6 f11
none-of-those
end_variable
begin_variable
var486
-1
2
above f6 f12
none-of-those
end_variable
begin_variable
var487
-1
2
above f6 f13
none-of-those
end_variable
begin_variable
var488
-1
2
above f6 f14
none-of-those
end_variable
begin_variable
var489
-1
2
above f6 f15
none-of-those
end_variable
begin_variable
var490
-1
2
above f6 f16
none-of-those
end_variable
begin_variable
var491
-1
2
above f6 f17
none-of-those
end_variable
begin_variable
var492
-1
2
above f6 f18
none-of-those
end_variable
begin_variable
var493
-1
2
above f6 f19
none-of-those
end_variable
begin_variable
var494
-1
2
above f6 f20
none-of-those
end_variable
begin_variable
var495
-1
2
above f6 f21
none-of-those
end_variable
begin_variable
var496
-1
2
above f6 f22
none-of-those
end_variable
begin_variable
var497
-1
2
above f6 f23
none-of-those
end_variable
begin_variable
var498
-1
2
above f6 f24
none-of-those
end_variable
begin_variable
var499
-1
2
above f6 f25
none-of-those
end_variable
begin_variable
var500
-1
2
above f6 f26
none-of-those
end_variable
begin_variable
var501
-1
2
above f6 f27
none-of-those
end_variable
begin_variable
var502
-1
2
above f6 f28
none-of-those
end_variable
begin_variable
var503
-1
2
above f6 f29
none-of-those
end_variable
begin_variable
var504
-1
2
above f6 f30
none-of-those
end_variable
begin_variable
var505
-1
2
above f6 f31
none-of-those
end_variable
begin_variable
var506
-1
2
above f6 f32
none-of-those
end_variable
begin_variable
var507
-1
2
above f6 f33
none-of-those
end_variable
begin_variable
var508
-1
2
above f6 f34
none-of-those
end_variable
begin_variable
var509
-1
2
above f6 f7
none-of-those
end_variable
begin_variable
var510
-1
2
above f6 f8
none-of-those
end_variable
begin_variable
var511
-1
2
above f6 f9
none-of-those
end_variable
begin_variable
var512
-1
2
above f7 f10
none-of-those
end_variable
begin_variable
var513
-1
2
above f7 f11
none-of-those
end_variable
begin_variable
var514
-1
2
above f7 f12
none-of-those
end_variable
begin_variable
var515
-1
2
above f7 f13
none-of-those
end_variable
begin_variable
var516
-1
2
above f7 f14
none-of-those
end_variable
begin_variable
var517
-1
2
above f7 f15
none-of-those
end_variable
begin_variable
var518
-1
2
above f7 f16
none-of-those
end_variable
begin_variable
var519
-1
2
above f7 f17
none-of-those
end_variable
begin_variable
var520
-1
2
above f7 f18
none-of-those
end_variable
begin_variable
var521
-1
2
above f7 f19
none-of-those
end_variable
begin_variable
var522
-1
2
above f7 f20
none-of-those
end_variable
begin_variable
var523
-1
2
above f7 f21
none-of-those
end_variable
begin_variable
var524
-1
2
above f7 f22
none-of-those
end_variable
begin_variable
var525
-1
2
above f7 f23
none-of-those
end_variable
begin_variable
var526
-1
2
above f7 f24
none-of-those
end_variable
begin_variable
var527
-1
2
above f7 f25
none-of-those
end_variable
begin_variable
var528
-1
2
above f7 f26
none-of-those
end_variable
begin_variable
var529
-1
2
above f7 f27
none-of-those
end_variable
begin_variable
var530
-1
2
above f7 f28
none-of-those
end_variable
begin_variable
var531
-1
2
above f7 f29
none-of-those
end_variable
begin_variable
var532
-1
2
above f7 f30
none-of-those
end_variable
begin_variable
var533
-1
2
above f7 f31
none-of-those
end_variable
begin_variable
var534
-1
2
above f7 f32
none-of-those
end_variable
begin_variable
var535
-1
2
above f7 f33
none-of-those
end_variable
begin_variable
var536
-1
2
above f7 f34
none-of-those
end_variable
begin_variable
var537
-1
2
above f7 f8
none-of-those
end_variable
begin_variable
var538
-1
2
above f7 f9
none-of-those
end_variable
begin_variable
var539
-1
2
above f8 f10
none-of-those
end_variable
begin_variable
var540
-1
2
above f8 f11
none-of-those
end_variable
begin_variable
var541
-1
2
above f8 f12
none-of-those
end_variable
begin_variable
var542
-1
2
above f8 f13
none-of-those
end_variable
begin_variable
var543
-1
2
above f8 f14
none-of-those
end_variable
begin_variable
var544
-1
2
above f8 f15
none-of-those
end_variable
begin_variable
var545
-1
2
above f8 f16
none-of-those
end_variable
begin_variable
var546
-1
2
above f8 f17
none-of-those
end_variable
begin_variable
var547
-1
2
above f8 f18
none-of-those
end_variable
begin_variable
var548
-1
2
above f8 f19
none-of-those
end_variable
begin_variable
var549
-1
2
above f8 f20
none-of-those
end_variable
begin_variable
var550
-1
2
above f8 f21
none-of-those
end_variable
begin_variable
var551
-1
2
above f8 f22
none-of-those
end_variable
begin_variable
var552
-1
2
above f8 f23
none-of-those
end_variable
begin_variable
var553
-1
2
above f8 f24
none-of-those
end_variable
begin_variable
var554
-1
2
above f8 f25
none-of-those
end_variable
begin_variable
var555
-1
2
above f8 f26
none-of-those
end_variable
begin_variable
var556
-1
2
above f8 f27
none-of-those
end_variable
begin_variable
var557
-1
2
above f8 f28
none-of-those
end_variable
begin_variable
var558
-1
2
above f8 f29
none-of-those
end_variable
begin_variable
var559
-1
2
above f8 f30
none-of-those
end_variable
begin_variable
var560
-1
2
above f8 f31
none-of-those
end_variable
begin_variable
var561
-1
2
above f8 f32
none-of-those
end_variable
begin_variable
var562
-1
2
above f8 f33
none-of-those
end_variable
begin_variable
var563
-1
2
above f8 f34
none-of-those
end_variable
begin_variable
var564
-1
2
above f8 f9
none-of-those
end_variable
begin_variable
var565
-1
2
above f9 f10
none-of-those
end_variable
begin_variable
var566
-1
2
above f9 f11
none-of-those
end_variable
begin_variable
var567
-1
2
above f9 f12
none-of-those
end_variable
begin_variable
var568
-1
2
above f9 f13
none-of-those
end_variable
begin_variable
var569
-1
2
above f9 f14
none-of-those
end_variable
begin_variable
var570
-1
2
above f9 f15
none-of-those
end_variable
begin_variable
var571
-1
2
above f9 f16
none-of-those
end_variable
begin_variable
var572
-1
2
above f9 f17
none-of-those
end_variable
begin_variable
var573
-1
2
above f9 f18
none-of-those
end_variable
begin_variable
var574
-1
2
above f9 f19
none-of-those
end_variable
begin_variable
var575
-1
2
above f9 f20
none-of-those
end_variable
begin_variable
var576
-1
2
above f9 f21
none-of-those
end_variable
begin_variable
var577
-1
2
above f9 f22
none-of-those
end_variable
begin_variable
var578
-1
2
above f9 f23
none-of-those
end_variable
begin_variable
var579
-1
2
above f9 f24
none-of-those
end_variable
begin_variable
var580
-1
2
above f9 f25
none-of-those
end_variable
begin_variable
var581
-1
2
above f9 f26
none-of-those
end_variable
begin_variable
var582
-1
2
above f9 f27
none-of-those
end_variable
begin_variable
var583
-1
2
above f9 f28
none-of-those
end_variable
begin_variable
var584
-1
2
above f9 f29
none-of-those
end_variable
begin_variable
var585
-1
2
above f9 f30
none-of-those
end_variable
begin_variable
var586
-1
2
above f9 f31
none-of-those
end_variable
begin_variable
var587
-1
2
above f9 f32
none-of-those
end_variable
begin_variable
var588
-1
2
above f9 f33
none-of-those
end_variable
begin_variable
var589
-1
2
above f9 f34
none-of-those
end_variable
begin_variable
var590
-1
2
destin p1 f2
none-of-those
end_variable
begin_variable
var591
-1
2
destin p10 f23
none-of-those
end_variable
begin_variable
var592
-1
2
destin p11 f2
none-of-those
end_variable
begin_variable
var593
-1
2
destin p12 f11
none-of-those
end_variable
begin_variable
var594
-1
2
destin p13 f19
none-of-those
end_variable
begin_variable
var595
-1
2
destin p14 f11
none-of-those
end_variable
begin_variable
var596
-1
2
destin p15 f18
none-of-those
end_variable
begin_variable
var597
-1
2
destin p16 f15
none-of-those
end_variable
begin_variable
var598
-1
2
destin p17 f32
none-of-those
end_variable
begin_variable
var599
-1
2
destin p18 f33
none-of-those
end_variable
begin_variable
var600
-1
2
destin p19 f11
none-of-those
end_variable
begin_variable
var601
-1
2
destin p2 f12
none-of-those
end_variable
begin_variable
var602
-1
2
destin p20 f13
none-of-those
end_variable
begin_variable
var603
-1
2
destin p21 f21
none-of-those
end_variable
begin_variable
var604
-1
2
destin p22 f7
none-of-those
end_variable
begin_variable
var605
-1
2
destin p23 f31
none-of-those
end_variable
begin_variable
var606
-1
2
destin p24 f4
none-of-those
end_variable
begin_variable
var607
-1
2
destin p25 f11
none-of-those
end_variable
begin_variable
var608
-1
2
destin p26 f9
none-of-those
end_variable
begin_variable
var609
-1
2
destin p27 f11
none-of-those
end_variable
begin_variable
var610
-1
2
destin p28 f10
none-of-those
end_variable
begin_variable
var611
-1
2
destin p3 f26
none-of-those
end_variable
begin_variable
var612
-1
2
destin p4 f34
none-of-those
end_variable
begin_variable
var613
-1
2
destin p5 f12
none-of-those
end_variable
begin_variable
var614
-1
2
destin p6 f31
none-of-those
end_variable
begin_variable
var615
-1
2
destin p7 f26
none-of-those
end_variable
begin_variable
var616
-1
2
destin p8 f24
none-of-those
end_variable
begin_variable
var617
-1
2
destin p9 f6
none-of-those
end_variable
0
begin_state
16
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
28
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
27 2
28 2
end_goal
1178
begin_operator
board f1 p13
1
0 0
1
0 5 1 0
1
end_operator
begin_operator
board f12 p22
1
0 3
1
0 15 1 0
1
end_operator
begin_operator
board f12 p25
1
0 3
1
0 18 1 0
1
end_operator
begin_operator
board f14 p9
1
0 5
1
0 28 1 0
1
end_operator
begin_operator
board f17 p1
1
0 8
1
0 1 1 0
1
end_operator
begin_operator
board f17 p17
1
0 8
1
0 9 1 0
1
end_operator
begin_operator
board f17 p21
1
0 8
1
0 14 1 0
1
end_operator
begin_operator
board f17 p5
1
0 8
1
0 24 1 0
1
end_operator
begin_operator
board f19 p7
1
0 10
1
0 26 1 0
1
end_operator
begin_operator
board f24 p26
1
0 16
1
0 19 1 0
1
end_operator
begin_operator
board f24 p28
1
0 16
1
0 21 1 0
1
end_operator
begin_operator
board f27 p2
1
0 19
1
0 12 1 0
1
end_operator
begin_operator
board f27 p20
1
0 19
1
0 13 1 0
1
end_operator
begin_operator
board f28 p10
1
0 20
1
0 2 1 0
1
end_operator
begin_operator
board f28 p24
1
0 20
1
0 17 1 0
1
end_operator
begin_operator
board f29 p16
1
0 21
1
0 8 1 0
1
end_operator
begin_operator
board f29 p3
1
0 21
1
0 22 1 0
1
end_operator
begin_operator
board f29 p4
1
0 21
1
0 23 1 0
1
end_operator
begin_operator
board f31 p11
1
0 24
1
0 3 1 0
1
end_operator
begin_operator
board f31 p12
1
0 24
1
0 4 1 0
1
end_operator
begin_operator
board f33 p23
1
0 26
1
0 16 1 0
1
end_operator
begin_operator
board f34 p14
1
0 27
1
0 6 1 0
1
end_operator
begin_operator
board f6 p19
1
0 30
1
0 11 1 0
1
end_operator
begin_operator
board f7 p15
1
0 31
1
0 7 1 0
1
end_operator
begin_operator
board f8 p6
1
0 32
1
0 25 1 0
1
end_operator
begin_operator
board f8 p8
1
0 32
1
0 27 1 0
1
end_operator
begin_operator
board f9 p18
1
0 33
1
0 10 1 0
1
end_operator
begin_operator
board f9 p27
1
0 33
1
0 20 1 0
1
end_operator
begin_operator
depart f10 p28
2
0 1
610 0
1
0 21 0 2
1
end_operator
begin_operator
depart f11 p12
2
0 2
593 0
1
0 4 0 2
1
end_operator
begin_operator
depart f11 p14
2
0 2
595 0
1
0 6 0 2
1
end_operator
begin_operator
depart f11 p19
2
0 2
600 0
1
0 11 0 2
1
end_operator
begin_operator
depart f11 p25
2
0 2
607 0
1
0 18 0 2
1
end_operator
begin_operator
depart f11 p27
2
0 2
609 0
1
0 20 0 2
1
end_operator
begin_operator
depart f12 p2
2
0 3
601 0
1
0 12 0 2
1
end_operator
begin_operator
depart f12 p5
2
0 3
613 0
1
0 24 0 2
1
end_operator
begin_operator
depart f13 p20
2
0 4
602 0
1
0 13 0 2
1
end_operator
begin_operator
depart f15 p16
2
0 6
597 0
1
0 8 0 2
1
end_operator
begin_operator
depart f18 p15
2
0 9
596 0
1
0 7 0 2
1
end_operator
begin_operator
depart f19 p13
2
0 10
594 0
1
0 5 0 2
1
end_operator
begin_operator
depart f2 p1
2
0 11
590 0
1
0 1 0 2
1
end_operator
begin_operator
depart f2 p11
2
0 11
592 0
1
0 3 0 2
1
end_operator
begin_operator
depart f21 p21
2
0 13
603 0
1
0 14 0 2
1
end_operator
begin_operator
depart f23 p10
2
0 15
591 0
1
0 2 0 2
1
end_operator
begin_operator
depart f24 p8
2
0 16
616 0
1
0 27 0 2
1
end_operator
begin_operator
depart f26 p3
2
0 18
611 0
1
0 22 0 2
1
end_operator
begin_operator
depart f26 p7
2
0 18
615 0
1
0 26 0 2
1
end_operator
begin_operator
depart f31 p23
2
0 24
605 0
1
0 16 0 2
1
end_operator
begin_operator
depart f31 p6
2
0 24
614 0
1
0 25 0 2
1
end_operator
begin_operator
depart f32 p17
2
0 25
598 0
1
0 9 0 2
1
end_operator
begin_operator
depart f33 p18
2
0 26
599 0
1
0 10 0 2
1
end_operator
begin_operator
depart f34 p4
2
0 27
612 0
1
0 23 0 2
1
end_operator
begin_operator
depart f4 p24
2
0 28
606 0
1
0 17 0 2
1
end_operator
begin_operator
depart f6 p9
2
0 30
617 0
1
0 28 0 2
1
end_operator
begin_operator
depart f7 p22
2
0 31
604 0
1
0 15 0 2
1
end_operator
begin_operator
depart f9 p26
2
0 33
608 0
1
0 19 0 2
1
end_operator
begin_operator
down f10 f1
1
29 0
1
0 0 1 0
1
end_operator
begin_operator
down f10 f2
1
257 0
1
0 0 1 11
1
end_operator
begin_operator
down f10 f3
1
384 0
1
0 0 1 22
1
end_operator
begin_operator
down f10 f4
1
425 0
1
0 0 1 28
1
end_operator
begin_operator
down f10 f5
1
455 0
1
0 0 1 29
1
end_operator
begin_operator
down f10 f6
1
484 0
1
0 0 1 30
1
end_operator
begin_operator
down f10 f7
1
512 0
1
0 0 1 31
1
end_operator
begin_operator
down f10 f8
1
539 0
1
0 0 1 32
1
end_operator
begin_operator
down f10 f9
1
565 0
1
0 0 1 33
1
end_operator
begin_operator
down f11 f1
1
30 0
1
0 0 2 0
1
end_operator
begin_operator
down f11 f10
1
62 0
1
0 0 2 1
1
end_operator
begin_operator
down f11 f2
1
258 0
1
0 0 2 11
1
end_operator
begin_operator
down f11 f3
1
385 0
1
0 0 2 22
1
end_operator
begin_operator
down f11 f4
1
426 0
1
0 0 2 28
1
end_operator
begin_operator
down f11 f5
1
456 0
1
0 0 2 29
1
end_operator
begin_operator
down f11 f6
1
485 0
1
0 0 2 30
1
end_operator
begin_operator
down f11 f7
1
513 0
1
0 0 2 31
1
end_operator
begin_operator
down f11 f8
1
540 0
1
0 0 2 32
1
end_operator
begin_operator
down f11 f9
1
566 0
1
0 0 2 33
1
end_operator
begin_operator
down f12 f1
1
31 0
1
0 0 3 0
1
end_operator
begin_operator
down f12 f10
1
63 0
1
0 0 3 1
1
end_operator
begin_operator
down f12 f11
1
86 0
1
0 0 3 2
1
end_operator
begin_operator
down f12 f2
1
259 0
1
0 0 3 11
1
end_operator
begin_operator
down f12 f3
1
386 0
1
0 0 3 22
1
end_operator
begin_operator
down f12 f4
1
427 0
1
0 0 3 28
1
end_operator
begin_operator
down f12 f5
1
457 0
1
0 0 3 29
1
end_operator
begin_operator
down f12 f6
1
486 0
1
0 0 3 30
1
end_operator
begin_operator
down f12 f7
1
514 0
1
0 0 3 31
1
end_operator
begin_operator
down f12 f8
1
541 0
1
0 0 3 32
1
end_operator
begin_operator
down f12 f9
1
567 0
1
0 0 3 33
1
end_operator
begin_operator
down f13 f1
1
32 0
1
0 0 4 0
1
end_operator
begin_operator
down f13 f10
1
64 0
1
0 0 4 1
1
end_operator
begin_operator
down f13 f11
1
87 0
1
0 0 4 2
1
end_operator
begin_operator
down f13 f12
1
109 0
1
0 0 4 3
1
end_operator
begin_operator
down f13 f2
1
260 0
1
0 0 4 11
1
end_operator
begin_operator
down f13 f3
1
387 0
1
0 0 4 22
1
end_operator
begin_operator
down f13 f4
1
428 0
1
0 0 4 28
1
end_operator
begin_operator
down f13 f5
1
458 0
1
0 0 4 29
1
end_operator
begin_operator
down f13 f6
1
487 0
1
0 0 4 30
1
end_operator
begin_operator
down f13 f7
1
515 0
1
0 0 4 31
1
end_operator
begin_operator
down f13 f8
1
542 0
1
0 0 4 32
1
end_operator
begin_operator
down f13 f9
1
568 0
1
0 0 4 33
1
end_operator
begin_operator
down f14 f1
1
33 0
1
0 0 5 0
1
end_operator
begin_operator
down f14 f10
1
65 0
1
0 0 5 1
1
end_operator
begin_operator
down f14 f11
1
88 0
1
0 0 5 2
1
end_operator
begin_operator
down f14 f12
1
110 0
1
0 0 5 3
1
end_operator
begin_operator
down f14 f13
1
131 0
1
0 0 5 4
1
end_operator
begin_operator
down f14 f2
1
261 0
1
0 0 5 11
1
end_operator
begin_operator
down f14 f3
1
388 0
1
0 0 5 22
1
end_operator
begin_operator
down f14 f4
1
429 0
1
0 0 5 28
1
end_operator
begin_operator
down f14 f5
1
459 0
1
0 0 5 29
1
end_operator
begin_operator
down f14 f6
1
488 0
1
0 0 5 30
1
end_operator
begin_operator
down f14 f7
1
516 0
1
0 0 5 31
1
end_operator
begin_operator
down f14 f8
1
543 0
1
0 0 5 32
1
end_operator
begin_operator
down f14 f9
1
569 0
1
0 0 5 33
1
end_operator
begin_operator
down f15 f1
1
34 0
1
0 0 6 0
1
end_operator
begin_operator
down f15 f10
1
66 0
1
0 0 6 1
1
end_operator
begin_operator
down f15 f11
1
89 0
1
0 0 6 2
1
end_operator
begin_operator
down f15 f12
1
111 0
1
0 0 6 3
1
end_operator
begin_operator
down f15 f13
1
132 0
1
0 0 6 4
1
end_operator
begin_operator
down f15 f14
1
152 0
1
0 0 6 5
1
end_operator
begin_operator
down f15 f2
1
262 0
1
0 0 6 11
1
end_operator
begin_operator
down f15 f3
1
389 0
1
0 0 6 22
1
end_operator
begin_operator
down f15 f4
1
430 0
1
0 0 6 28
1
end_operator
begin_operator
down f15 f5
1
460 0
1
0 0 6 29
1
end_operator
begin_operator
down f15 f6
1
489 0
1
0 0 6 30
1
end_operator
begin_operator
down f15 f7
1
517 0
1
0 0 6 31
1
end_operator
begin_operator
down f15 f8
1
544 0
1
0 0 6 32
1
end_operator
begin_operator
down f15 f9
1
570 0
1
0 0 6 33
1
end_operator
begin_operator
down f16 f1
1
35 0
1
0 0 7 0
1
end_operator
begin_operator
down f16 f10
1
67 0
1
0 0 7 1
1
end_operator
begin_operator
down f16 f11
1
90 0
1
0 0 7 2
1
end_operator
begin_operator
down f16 f12
1
112 0
1
0 0 7 3
1
end_operator
begin_operator
down f16 f13
1
133 0
1
0 0 7 4
1
end_operator
begin_operator
down f16 f14
1
153 0
1
0 0 7 5
1
end_operator
begin_operator
down f16 f15
1
172 0
1
0 0 7 6
1
end_operator
begin_operator
down f16 f2
1
263 0
1
0 0 7 11
1
end_operator
begin_operator
down f16 f3
1
390 0
1
0 0 7 22
1
end_operator
begin_operator
down f16 f4
1
431 0
1
0 0 7 28
1
end_operator
begin_operator
down f16 f5
1
461 0
1
0 0 7 29
1
end_operator
begin_operator
down f16 f6
1
490 0
1
0 0 7 30
1
end_operator
begin_operator
down f16 f7
1
518 0
1
0 0 7 31
1
end_operator
begin_operator
down f16 f8
1
545 0
1
0 0 7 32
1
end_operator
begin_operator
down f16 f9
1
571 0
1
0 0 7 33
1
end_operator
begin_operator
down f17 f1
1
36 0
1
0 0 8 0
1
end_operator
begin_operator
down f17 f10
1
68 0
1
0 0 8 1
1
end_operator
begin_operator
down f17 f11
1
91 0
1
0 0 8 2
1
end_operator
begin_operator
down f17 f12
1
113 0
1
0 0 8 3
1
end_operator
begin_operator
down f17 f13
1
134 0
1
0 0 8 4
1
end_operator
begin_operator
down f17 f14
1
154 0
1
0 0 8 5
1
end_operator
begin_operator
down f17 f15
1
173 0
1
0 0 8 6
1
end_operator
begin_operator
down f17 f16
1
191 0
1
0 0 8 7
1
end_operator
begin_operator
down f17 f2
1
264 0
1
0 0 8 11
1
end_operator
begin_operator
down f17 f3
1
391 0
1
0 0 8 22
1
end_operator
begin_operator
down f17 f4
1
432 0
1
0 0 8 28
1
end_operator
begin_operator
down f17 f5
1
462 0
1
0 0 8 29
1
end_operator
begin_operator
down f17 f6
1
491 0
1
0 0 8 30
1
end_operator
begin_operator
down f17 f7
1
519 0
1
0 0 8 31
1
end_operator
begin_operator
down f17 f8
1
546 0
1
0 0 8 32
1
end_operator
begin_operator
down f17 f9
1
572 0
1
0 0 8 33
1
end_operator
begin_operator
down f18 f1
1
37 0
1
0 0 9 0
1
end_operator
begin_operator
down f18 f10
1
69 0
1
0 0 9 1
1
end_operator
begin_operator
down f18 f11
1
92 0
1
0 0 9 2
1
end_operator
begin_operator
down f18 f12
1
114 0
1
0 0 9 3
1
end_operator
begin_operator
down f18 f13
1
135 0
1
0 0 9 4
1
end_operator
begin_operator
down f18 f14
1
155 0
1
0 0 9 5
1
end_operator
begin_operator
down f18 f15
1
174 0
1
0 0 9 6
1
end_operator
begin_operator
down f18 f16
1
192 0
1
0 0 9 7
1
end_operator
begin_operator
down f18 f17
1
209 0
1
0 0 9 8
1
end_operator
begin_operator
down f18 f2
1
265 0
1
0 0 9 11
1
end_operator
begin_operator
down f18 f3
1
392 0
1
0 0 9 22
1
end_operator
begin_operator
down f18 f4
1
433 0
1
0 0 9 28
1
end_operator
begin_operator
down f18 f5
1
463 0
1
0 0 9 29
1
end_operator
begin_operator
down f18 f6
1
492 0
1
0 0 9 30
1
end_operator
begin_operator
down f18 f7
1
520 0
1
0 0 9 31
1
end_operator
begin_operator
down f18 f8
1
547 0
1
0 0 9 32
1
end_operator
begin_operator
down f18 f9
1
573 0
1
0 0 9 33
1
end_operator
begin_operator
down f19 f1
1
38 0
1
0 0 10 0
1
end_operator
begin_operator
down f19 f10
1
70 0
1
0 0 10 1
1
end_operator
begin_operator
down f19 f11
1
93 0
1
0 0 10 2
1
end_operator
begin_operator
down f19 f12
1
115 0
1
0 0 10 3
1
end_operator
begin_operator
down f19 f13
1
136 0
1
0 0 10 4
1
end_operator
begin_operator
down f19 f14
1
156 0
1
0 0 10 5
1
end_operator
begin_operator
down f19 f15
1
175 0
1
0 0 10 6
1
end_operator
begin_operator
down f19 f16
1
193 0
1
0 0 10 7
1
end_operator
begin_operator
down f19 f17
1
210 0
1
0 0 10 8
1
end_operator
begin_operator
down f19 f18
1
226 0
1
0 0 10 9
1
end_operator
begin_operator
down f19 f2
1
266 0
1
0 0 10 11
1
end_operator
begin_operator
down f19 f3
1
393 0
1
0 0 10 22
1
end_operator
begin_operator
down f19 f4
1
434 0
1
0 0 10 28
1
end_operator
begin_operator
down f19 f5
1
464 0
1
0 0 10 29
1
end_operator
begin_operator
down f19 f6
1
493 0
1
0 0 10 30
1
end_operator
begin_operator
down f19 f7
1
521 0
1
0 0 10 31
1
end_operator
begin_operator
down f19 f8
1
548 0
1
0 0 10 32
1
end_operator
begin_operator
down f19 f9
1
574 0
1
0 0 10 33
1
end_operator
begin_operator
down f2 f1
1
39 0
1
0 0 11 0
1
end_operator
begin_operator
down f20 f1
1
40 0
1
0 0 12 0
1
end_operator
begin_operator
down f20 f10
1
71 0
1
0 0 12 1
1
end_operator
begin_operator
down f20 f11
1
94 0
1
0 0 12 2
1
end_operator
begin_operator
down f20 f12
1
116 0
1
0 0 12 3
1
end_operator
begin_operator
down f20 f13
1
137 0
1
0 0 12 4
1
end_operator
begin_operator
down f20 f14
1
157 0
1
0 0 12 5
1
end_operator
begin_operator
down f20 f15
1
176 0
1
0 0 12 6
1
end_operator
begin_operator
down f20 f16
1
194 0
1
0 0 12 7
1
end_operator
begin_operator
down f20 f17
1
211 0
1
0 0 12 8
1
end_operator
begin_operator
down f20 f18
1
227 0
1
0 0 12 9
1
end_operator
begin_operator
down f20 f19
1
242 0
1
0 0 12 10
1
end_operator
begin_operator
down f20 f2
1
267 0
1
0 0 12 11
1
end_operator
begin_operator
down f20 f3
1
394 0
1
0 0 12 22
1
end_operator
begin_operator
down f20 f4
1
435 0
1
0 0 12 28
1
end_operator
begin_operator
down f20 f5
1
465 0
1
0 0 12 29
1
end_operator
begin_operator
down f20 f6
1
494 0
1
0 0 12 30
1
end_operator
begin_operator
down f20 f7
1
522 0
1
0 0 12 31
1
end_operator
begin_operator
down f20 f8
1
549 0
1
0 0 12 32
1
end_operator
begin_operator
down f20 f9
1
575 0
1
0 0 12 33
1
end_operator
begin_operator
down f21 f1
1
41 0
1
0 0 13 0
1
end_operator
begin_operator
down f21 f10
1
72 0
1
0 0 13 1
1
end_operator
begin_operator
down f21 f11
1
95 0
1
0 0 13 2
1
end_operator
begin_operator
down f21 f12
1
117 0
1
0 0 13 3
1
end_operator
begin_operator
down f21 f13
1
138 0
1
0 0 13 4
1
end_operator
begin_operator
down f21 f14
1
158 0
1
0 0 13 5
1
end_operator
begin_operator
down f21 f15
1
177 0
1
0 0 13 6
1
end_operator
begin_operator
down f21 f16
1
195 0
1
0 0 13 7
1
end_operator
begin_operator
down f21 f17
1
212 0
1
0 0 13 8
1
end_operator
begin_operator
down f21 f18
1
228 0
1
0 0 13 9
1
end_operator
begin_operator
down f21 f19
1
243 0
1
0 0 13 10
1
end_operator
begin_operator
down f21 f2
1
268 0
1
0 0 13 11
1
end_operator
begin_operator
down f21 f20
1
289 0
1
0 0 13 12
1
end_operator
begin_operator
down f21 f3
1
395 0
1
0 0 13 22
1
end_operator
begin_operator
down f21 f4
1
436 0
1
0 0 13 28
1
end_operator
begin_operator
down f21 f5
1
466 0
1
0 0 13 29
1
end_operator
begin_operator
down f21 f6
1
495 0
1
0 0 13 30
1
end_operator
begin_operator
down f21 f7
1
523 0
1
0 0 13 31
1
end_operator
begin_operator
down f21 f8
1
550 0
1
0 0 13 32
1
end_operator
begin_operator
down f21 f9
1
576 0
1
0 0 13 33
1
end_operator
begin_operator
down f22 f1
1
42 0
1
0 0 14 0
1
end_operator
begin_operator
down f22 f10
1
73 0
1
0 0 14 1
1
end_operator
begin_operator
down f22 f11
1
96 0
1
0 0 14 2
1
end_operator
begin_operator
down f22 f12
1
118 0
1
0 0 14 3
1
end_operator
begin_operator
down f22 f13
1
139 0
1
0 0 14 4
1
end_operator
begin_operator
down f22 f14
1
159 0
1
0 0 14 5
1
end_operator
begin_operator
down f22 f15
1
178 0
1
0 0 14 6
1
end_operator
begin_operator
down f22 f16
1
196 0
1
0 0 14 7
1
end_operator
begin_operator
down f22 f17
1
213 0
1
0 0 14 8
1
end_operator
begin_operator
down f22 f18
1
229 0
1
0 0 14 9
1
end_operator
begin_operator
down f22 f19
1
244 0
1
0 0 14 10
1
end_operator
begin_operator
down f22 f2
1
269 0
1
0 0 14 11
1
end_operator
begin_operator
down f22 f20
1
290 0
1
0 0 14 12
1
end_operator
begin_operator
down f22 f21
1
303 0
1
0 0 14 13
1
end_operator
begin_operator
down f22 f3
1
396 0
1
0 0 14 22
1
end_operator
begin_operator
down f22 f4
1
437 0
1
0 0 14 28
1
end_operator
begin_operator
down f22 f5
1
467 0
1
0 0 14 29
1
end_operator
begin_operator
down f22 f6
1
496 0
1
0 0 14 30
1
end_operator
begin_operator
down f22 f7
1
524 0
1
0 0 14 31
1
end_operator
begin_operator
down f22 f8
1
551 0
1
0 0 14 32
1
end_operator
begin_operator
down f22 f9
1
577 0
1
0 0 14 33
1
end_operator
begin_operator
down f23 f1
1
43 0
1
0 0 15 0
1
end_operator
begin_operator
down f23 f10
1
74 0
1
0 0 15 1
1
end_operator
begin_operator
down f23 f11
1
97 0
1
0 0 15 2
1
end_operator
begin_operator
down f23 f12
1
119 0
1
0 0 15 3
1
end_operator
begin_operator
down f23 f13
1
140 0
1
0 0 15 4
1
end_operator
begin_operator
down f23 f14
1
160 0
1
0 0 15 5
1
end_operator
begin_operator
down f23 f15
1
179 0
1
0 0 15 6
1
end_operator
begin_operator
down f23 f16
1
197 0
1
0 0 15 7
1
end_operator
begin_operator
down f23 f17
1
214 0
1
0 0 15 8
1
end_operator
begin_operator
down f23 f18
1
230 0
1
0 0 15 9
1
end_operator
begin_operator
down f23 f19
1
245 0
1
0 0 15 10
1
end_operator
begin_operator
down f23 f2
1
270 0
1
0 0 15 11
1
end_operator
begin_operator
down f23 f20
1
291 0
1
0 0 15 12
1
end_operator
begin_operator
down f23 f21
1
304 0
1
0 0 15 13
1
end_operator
begin_operator
down f23 f22
1
316 0
1
0 0 15 14
1
end_operator
begin_operator
down f23 f3
1
397 0
1
0 0 15 22
1
end_operator
begin_operator
down f23 f4
1
438 0
1
0 0 15 28
1
end_operator
begin_operator
down f23 f5
1
468 0
1
0 0 15 29
1
end_operator
begin_operator
down f23 f6
1
497 0
1
0 0 15 30
1
end_operator
begin_operator
down f23 f7
1
525 0
1
0 0 15 31
1
end_operator
begin_operator
down f23 f8
1
552 0
1
0 0 15 32
1
end_operator
begin_operator
down f23 f9
1
578 0
1
0 0 15 33
1
end_operator
begin_operator
down f24 f1
1
44 0
1
0 0 16 0
1
end_operator
begin_operator
down f24 f10
1
75 0
1
0 0 16 1
1
end_operator
begin_operator
down f24 f11
1
98 0
1
0 0 16 2
1
end_operator
begin_operator
down f24 f12
1
120 0
1
0 0 16 3
1
end_operator
begin_operator
down f24 f13
1
141 0
1
0 0 16 4
1
end_operator
begin_operator
down f24 f14
1
161 0
1
0 0 16 5
1
end_operator
begin_operator
down f24 f15
1
180 0
1
0 0 16 6
1
end_operator
begin_operator
down f24 f16
1
198 0
1
0 0 16 7
1
end_operator
begin_operator
down f24 f17
1
215 0
1
0 0 16 8
1
end_operator
begin_operator
down f24 f18
1
231 0
1
0 0 16 9
1
end_operator
begin_operator
down f24 f19
1
246 0
1
0 0 16 10
1
end_operator
begin_operator
down f24 f2
1
271 0
1
0 0 16 11
1
end_operator
begin_operator
down f24 f20
1
292 0
1
0 0 16 12
1
end_operator
begin_operator
down f24 f21
1
305 0
1
0 0 16 13
1
end_operator
begin_operator
down f24 f22
1
317 0
1
0 0 16 14
1
end_operator
begin_operator
down f24 f23
1
328 0
1
0 0 16 15
1
end_operator
begin_operator
down f24 f3
1
398 0
1
0 0 16 22
1
end_operator
begin_operator
down f24 f4
1
439 0
1
0 0 16 28
1
end_operator
begin_operator
down f24 f5
1
469 0
1
0 0 16 29
1
end_operator
begin_operator
down f24 f6
1
498 0
1
0 0 16 30
1
end_operator
begin_operator
down f24 f7
1
526 0
1
0 0 16 31
1
end_operator
begin_operator
down f24 f8
1
553 0
1
0 0 16 32
1
end_operator
begin_operator
down f24 f9
1
579 0
1
0 0 16 33
1
end_operator
begin_operator
down f25 f1
1
45 0
1
0 0 17 0
1
end_operator
begin_operator
down f25 f10
1
76 0
1
0 0 17 1
1
end_operator
begin_operator
down f25 f11
1
99 0
1
0 0 17 2
1
end_operator
begin_operator
down f25 f12
1
121 0
1
0 0 17 3
1
end_operator
begin_operator
down f25 f13
1
142 0
1
0 0 17 4
1
end_operator
begin_operator
down f25 f14
1
162 0
1
0 0 17 5
1
end_operator
begin_operator
down f25 f15
1
181 0
1
0 0 17 6
1
end_operator
begin_operator
down f25 f16
1
199 0
1
0 0 17 7
1
end_operator
begin_operator
down f25 f17
1
216 0
1
0 0 17 8
1
end_operator
begin_operator
down f25 f18
1
232 0
1
0 0 17 9
1
end_operator
begin_operator
down f25 f19
1
247 0
1
0 0 17 10
1
end_operator
begin_operator
down f25 f2
1
272 0
1
0 0 17 11
1
end_operator
begin_operator
down f25 f20
1
293 0
1
0 0 17 12
1
end_operator
begin_operator
down f25 f21
1
306 0
1
0 0 17 13
1
end_operator
begin_operator
down f25 f22
1
318 0
1
0 0 17 14
1
end_operator
begin_operator
down f25 f23
1
329 0
1
0 0 17 15
1
end_operator
begin_operator
down f25 f24
1
339 0
1
0 0 17 16
1
end_operator
begin_operator
down f25 f3
1
399 0
1
0 0 17 22
1
end_operator
begin_operator
down f25 f4
1
440 0
1
0 0 17 28
1
end_operator
begin_operator
down f25 f5
1
470 0
1
0 0 17 29
1
end_operator
begin_operator
down f25 f6
1
499 0
1
0 0 17 30
1
end_operator
begin_operator
down f25 f7
1
527 0
1
0 0 17 31
1
end_operator
begin_operator
down f25 f8
1
554 0
1
0 0 17 32
1
end_operator
begin_operator
down f25 f9
1
580 0
1
0 0 17 33
1
end_operator
begin_operator
down f26 f1
1
46 0
1
0 0 18 0
1
end_operator
begin_operator
down f26 f10
1
77 0
1
0 0 18 1
1
end_operator
begin_operator
down f26 f11
1
100 0
1
0 0 18 2
1
end_operator
begin_operator
down f26 f12
1
122 0
1
0 0 18 3
1
end_operator
begin_operator
down f26 f13
1
143 0
1
0 0 18 4
1
end_operator
begin_operator
down f26 f14
1
163 0
1
0 0 18 5
1
end_operator
begin_operator
down f26 f15
1
182 0
1
0 0 18 6
1
end_operator
begin_operator
down f26 f16
1
200 0
1
0 0 18 7
1
end_operator
begin_operator
down f26 f17
1
217 0
1
0 0 18 8
1
end_operator
begin_operator
down f26 f18
1
233 0
1
0 0 18 9
1
end_operator
begin_operator
down f26 f19
1
248 0
1
0 0 18 10
1
end_operator
begin_operator
down f26 f2
1
273 0
1
0 0 18 11
1
end_operator
begin_operator
down f26 f20
1
294 0
1
0 0 18 12
1
end_operator
begin_operator
down f26 f21
1
307 0
1
0 0 18 13
1
end_operator
begin_operator
down f26 f22
1
319 0
1
0 0 18 14
1
end_operator
begin_operator
down f26 f23
1
330 0
1
0 0 18 15
1
end_operator
begin_operator
down f26 f24
1
340 0
1
0 0 18 16
1
end_operator
begin_operator
down f26 f25
1
349 0
1
0 0 18 17
1
end_operator
begin_operator
down f26 f3
1
400 0
1
0 0 18 22
1
end_operator
begin_operator
down f26 f4
1
441 0
1
0 0 18 28
1
end_operator
begin_operator
down f26 f5
1
471 0
1
0 0 18 29
1
end_operator
begin_operator
down f26 f6
1
500 0
1
0 0 18 30
1
end_operator
begin_operator
down f26 f7
1
528 0
1
0 0 18 31
1
end_operator
begin_operator
down f26 f8
1
555 0
1
0 0 18 32
1
end_operator
begin_operator
down f26 f9
1
581 0
1
0 0 18 33
1
end_operator
begin_operator
down f27 f1
1
47 0
1
0 0 19 0
1
end_operator
begin_operator
down f27 f10
1
78 0
1
0 0 19 1
1
end_operator
begin_operator
down f27 f11
1
101 0
1
0 0 19 2
1
end_operator
begin_operator
down f27 f12
1
123 0
1
0 0 19 3
1
end_operator
begin_operator
down f27 f13
1
144 0
1
0 0 19 4
1
end_operator
begin_operator
down f27 f14
1
164 0
1
0 0 19 5
1
end_operator
begin_operator
down f27 f15
1
183 0
1
0 0 19 6
1
end_operator
begin_operator
down f27 f16
1
201 0
1
0 0 19 7
1
end_operator
begin_operator
down f27 f17
1
218 0
1
0 0 19 8
1
end_operator
begin_operator
down f27 f18
1
234 0
1
0 0 19 9
1
end_operator
begin_operator
down f27 f19
1
249 0
1
0 0 19 10
1
end_operator
begin_operator
down f27 f2
1
274 0
1
0 0 19 11
1
end_operator
begin_operator
down f27 f20
1
295 0
1
0 0 19 12
1
end_operator
begin_operator
down f27 f21
1
308 0
1
0 0 19 13
1
end_operator
begin_operator
down f27 f22
1
320 0
1
0 0 19 14
1
end_operator
begin_operator
down f27 f23
1
331 0
1
0 0 19 15
1
end_operator
begin_operator
down f27 f24
1
341 0
1
0 0 19 16
1
end_operator
begin_operator
down f27 f25
1
350 0
1
0 0 19 17
1
end_operator
begin_operator
down f27 f26
1
358 0
1
0 0 19 18
1
end_operator
begin_operator
down f27 f3
1
401 0
1
0 0 19 22
1
end_operator
begin_operator
down f27 f4
1
442 0
1
0 0 19 28
1
end_operator
begin_operator
down f27 f5
1
472 0
1
0 0 19 29
1
end_operator
begin_operator
down f27 f6
1
501 0
1
0 0 19 30
1
end_operator
begin_operator
down f27 f7
1
529 0
1
0 0 19 31
1
end_operator
begin_operator
down f27 f8
1
556 0
1
0 0 19 32
1
end_operator
begin_operator
down f27 f9
1
582 0
1
0 0 19 33
1
end_operator
begin_operator
down f28 f1
1
48 0
1
0 0 20 0
1
end_operator
begin_operator
down f28 f10
1
79 0
1
0 0 20 1
1
end_operator
begin_operator
down f28 f11
1
102 0
1
0 0 20 2
1
end_operator
begin_operator
down f28 f12
1
124 0
1
0 0 20 3
1
end_operator
begin_operator
down f28 f13
1
145 0
1
0 0 20 4
1
end_operator
begin_operator
down f28 f14
1
165 0
1
0 0 20 5
1
end_operator
begin_operator
down f28 f15
1
184 0
1
0 0 20 6
1
end_operator
begin_operator
down f28 f16
1
202 0
1
0 0 20 7
1
end_operator
begin_operator
down f28 f17
1
219 0
1
0 0 20 8
1
end_operator
begin_operator
down f28 f18
1
235 0
1
0 0 20 9
1
end_operator
begin_operator
down f28 f19
1
250 0
1
0 0 20 10
1
end_operator
begin_operator
down f28 f2
1
275 0
1
0 0 20 11
1
end_operator
begin_operator
down f28 f20
1
296 0
1
0 0 20 12
1
end_operator
begin_operator
down f28 f21
1
309 0
1
0 0 20 13
1
end_operator
begin_operator
down f28 f22
1
321 0
1
0 0 20 14
1
end_operator
begin_operator
down f28 f23
1
332 0
1
0 0 20 15
1
end_operator
begin_operator
down f28 f24
1
342 0
1
0 0 20 16
1
end_operator
begin_operator
down f28 f25
1
351 0
1
0 0 20 17
1
end_operator
begin_operator
down f28 f26
1
359 0
1
0 0 20 18
1
end_operator
begin_operator
down f28 f27
1
366 0
1
0 0 20 19
1
end_operator
begin_operator
down f28 f3
1
402 0
1
0 0 20 22
1
end_operator
begin_operator
down f28 f4
1
443 0
1
0 0 20 28
1
end_operator
begin_operator
down f28 f5
1
473 0
1
0 0 20 29
1
end_operator
begin_operator
down f28 f6
1
502 0
1
0 0 20 30
1
end_operator
begin_operator
down f28 f7
1
530 0
1
0 0 20 31
1
end_operator
begin_operator
down f28 f8
1
557 0
1
0 0 20 32
1
end_operator
begin_operator
down f28 f9
1
583 0
1
0 0 20 33
1
end_operator
begin_operator
down f29 f1
1
49 0
1
0 0 21 0
1
end_operator
begin_operator
down f29 f10
1
80 0
1
0 0 21 1
1
end_operator
begin_operator
down f29 f11
1
103 0
1
0 0 21 2
1
end_operator
begin_operator
down f29 f12
1
125 0
1
0 0 21 3
1
end_operator
begin_operator
down f29 f13
1
146 0
1
0 0 21 4
1
end_operator
begin_operator
down f29 f14
1
166 0
1
0 0 21 5
1
end_operator
begin_operator
down f29 f15
1
185 0
1
0 0 21 6
1
end_operator
begin_operator
down f29 f16
1
203 0
1
0 0 21 7
1
end_operator
begin_operator
down f29 f17
1
220 0
1
0 0 21 8
1
end_operator
begin_operator
down f29 f18
1
236 0
1
0 0 21 9
1
end_operator
begin_operator
down f29 f19
1
251 0
1
0 0 21 10
1
end_operator
begin_operator
down f29 f2
1
276 0
1
0 0 21 11
1
end_operator
begin_operator
down f29 f20
1
297 0
1
0 0 21 12
1
end_operator
begin_operator
down f29 f21
1
310 0
1
0 0 21 13
1
end_operator
begin_operator
down f29 f22
1
322 0
1
0 0 21 14
1
end_operator
begin_operator
down f29 f23
1
333 0
1
0 0 21 15
1
end_operator
begin_operator
down f29 f24
1
343 0
1
0 0 21 16
1
end_operator
begin_operator
down f29 f25
1
352 0
1
0 0 21 17
1
end_operator
begin_operator
down f29 f26
1
360 0
1
0 0 21 18
1
end_operator
begin_operator
down f29 f27
1
367 0
1
0 0 21 19
1
end_operator
begin_operator
down f29 f28
1
373 0
1
0 0 21 20
1
end_operator
begin_operator
down f29 f3
1
403 0
1
0 0 21 22
1
end_operator
begin_operator
down f29 f4
1
444 0
1
0 0 21 28
1
end_operator
begin_operator
down f29 f5
1
474 0
1
0 0 21 29
1
end_operator
begin_operator
down f29 f6
1
503 0
1
0 0 21 30
1
end_operator
begin_operator
down f29 f7
1
531 0
1
0 0 21 31
1
end_operator
begin_operator
down f29 f8
1
558 0
1
0 0 21 32
1
end_operator
begin_operator
down f29 f9
1
584 0
1
0 0 21 33
1
end_operator
begin_operator
down f3 f1
1
50 0
1
0 0 22 0
1
end_operator
begin_operator
down f3 f2
1
277 0
1
0 0 22 11
1
end_operator
begin_operator
down f30 f1
1
51 0
1
0 0 23 0
1
end_operator
begin_operator
down f30 f10
1
81 0
1
0 0 23 1
1
end_operator
begin_operator
down f30 f11
1
104 0
1
0 0 23 2
1
end_operator
begin_operator
down f30 f12
1
126 0
1
0 0 23 3
1
end_operator
begin_operator
down f30 f13
1
147 0
1
0 0 23 4
1
end_operator
begin_operator
down f30 f14
1
167 0
1
0 0 23 5
1
end_operator
begin_operator
down f30 f15
1
186 0
1
0 0 23 6
1
end_operator
begin_operator
down f30 f16
1
204 0
1
0 0 23 7
1
end_operator
begin_operator
down f30 f17
1
221 0
1
0 0 23 8
1
end_operator
begin_operator
down f30 f18
1
237 0
1
0 0 23 9
1
end_operator
begin_operator
down f30 f19
1
252 0
1
0 0 23 10
1
end_operator
begin_operator
down f30 f2
1
278 0
1
0 0 23 11
1
end_operator
begin_operator
down f30 f20
1
298 0
1
0 0 23 12
1
end_operator
begin_operator
down f30 f21
1
311 0
1
0 0 23 13
1
end_operator
begin_operator
down f30 f22
1
323 0
1
0 0 23 14
1
end_operator
begin_operator
down f30 f23
1
334 0
1
0 0 23 15
1
end_operator
begin_operator
down f30 f24
1
344 0
1
0 0 23 16
1
end_operator
begin_operator
down f30 f25
1
353 0
1
0 0 23 17
1
end_operator
begin_operator
down f30 f26
1
361 0
1
0 0 23 18
1
end_operator
begin_operator
down f30 f27
1
368 0
1
0 0 23 19
1
end_operator
begin_operator
down f30 f28
1
374 0
1
0 0 23 20
1
end_operator
begin_operator
down f30 f29
1
379 0
1
0 0 23 21
1
end_operator
begin_operator
down f30 f3
1
404 0
1
0 0 23 22
1
end_operator
begin_operator
down f30 f4
1
445 0
1
0 0 23 28
1
end_operator
begin_operator
down f30 f5
1
475 0
1
0 0 23 29
1
end_operator
begin_operator
down f30 f6
1
504 0
1
0 0 23 30
1
end_operator
begin_operator
down f30 f7
1
532 0
1
0 0 23 31
1
end_operator
begin_operator
down f30 f8
1
559 0
1
0 0 23 32
1
end_operator
begin_operator
down f30 f9
1
585 0
1
0 0 23 33
1
end_operator
begin_operator
down f31 f1
1
52 0
1
0 0 24 0
1
end_operator
begin_operator
down f31 f10
1
82 0
1
0 0 24 1
1
end_operator
begin_operator
down f31 f11
1
105 0
1
0 0 24 2
1
end_operator
begin_operator
down f31 f12
1
127 0
1
0 0 24 3
1
end_operator
begin_operator
down f31 f13
1
148 0
1
0 0 24 4
1
end_operator
begin_operator
down f31 f14
1
168 0
1
0 0 24 5
1
end_operator
begin_operator
down f31 f15
1
187 0
1
0 0 24 6
1
end_operator
begin_operator
down f31 f16
1
205 0
1
0 0 24 7
1
end_operator
begin_operator
down f31 f17
1
222 0
1
0 0 24 8
1
end_operator
begin_operator
down f31 f18
1
238 0
1
0 0 24 9
1
end_operator
begin_operator
down f31 f19
1
253 0
1
0 0 24 10
1
end_operator
begin_operator
down f31 f2
1
279 0
1
0 0 24 11
1
end_operator
begin_operator
down f31 f20
1
299 0
1
0 0 24 12
1
end_operator
begin_operator
down f31 f21
1
312 0
1
0 0 24 13
1
end_operator
begin_operator
down f31 f22
1
324 0
1
0 0 24 14
1
end_operator
begin_operator
down f31 f23
1
335 0
1
0 0 24 15
1
end_operator
begin_operator
down f31 f24
1
345 0
1
0 0 24 16
1
end_operator
begin_operator
down f31 f25
1
354 0
1
0 0 24 17
1
end_operator
begin_operator
down f31 f26
1
362 0
1
0 0 24 18
1
end_operator
begin_operator
down f31 f27
1
369 0
1
0 0 24 19
1
end_operator
begin_operator
down f31 f28
1
375 0
1
0 0 24 20
1
end_operator
begin_operator
down f31 f29
1
380 0
1
0 0 24 21
1
end_operator
begin_operator
down f31 f3
1
405 0
1
0 0 24 22
1
end_operator
begin_operator
down f31 f30
1
415 0
1
0 0 24 23
1
end_operator
begin_operator
down f31 f4
1
446 0
1
0 0 24 28
1
end_operator
begin_operator
down f31 f5
1
476 0
1
0 0 24 29
1
end_operator
begin_operator
down f31 f6
1
505 0
1
0 0 24 30
1
end_operator
begin_operator
down f31 f7
1
533 0
1
0 0 24 31
1
end_operator
begin_operator
down f31 f8
1
560 0
1
0 0 24 32
1
end_operator
begin_operator
down f31 f9
1
586 0
1
0 0 24 33
1
end_operator
begin_operator
down f32 f1
1
53 0
1
0 0 25 0
1
end_operator
begin_operator
down f32 f10
1
83 0
1
0 0 25 1
1
end_operator
begin_operator
down f32 f11
1
106 0
1
0 0 25 2
1
end_operator
begin_operator
down f32 f12
1
128 0
1
0 0 25 3
1
end_operator
begin_operator
down f32 f13
1
149 0
1
0 0 25 4
1
end_operator
begin_operator
down f32 f14
1
169 0
1
0 0 25 5
1
end_operator
begin_operator
down f32 f15
1
188 0
1
0 0 25 6
1
end_operator
begin_operator
down f32 f16
1
206 0
1
0 0 25 7
1
end_operator
begin_operator
down f32 f17
1
223 0
1
0 0 25 8
1
end_operator
begin_operator
down f32 f18
1
239 0
1
0 0 25 9
1
end_operator
begin_operator
down f32 f19
1
254 0
1
0 0 25 10
1
end_operator
begin_operator
down f32 f2
1
280 0
1
0 0 25 11
1
end_operator
begin_operator
down f32 f20
1
300 0
1
0 0 25 12
1
end_operator
begin_operator
down f32 f21
1
313 0
1
0 0 25 13
1
end_operator
begin_operator
down f32 f22
1
325 0
1
0 0 25 14
1
end_operator
begin_operator
down f32 f23
1
336 0
1
0 0 25 15
1
end_operator
begin_operator
down f32 f24
1
346 0
1
0 0 25 16
1
end_operator
begin_operator
down f32 f25
1
355 0
1
0 0 25 17
1
end_operator
begin_operator
down f32 f26
1
363 0
1
0 0 25 18
1
end_operator
begin_operator
down f32 f27
1
370 0
1
0 0 25 19
1
end_operator
begin_operator
down f32 f28
1
376 0
1
0 0 25 20
1
end_operator
begin_operator
down f32 f29
1
381 0
1
0 0 25 21
1
end_operator
begin_operator
down f32 f3
1
406 0
1
0 0 25 22
1
end_operator
begin_operator
down f32 f30
1
416 0
1
0 0 25 23
1
end_operator
begin_operator
down f32 f31
1
419 0
1
0 0 25 24
1
end_operator
begin_operator
down f32 f4
1
447 0
1
0 0 25 28
1
end_operator
begin_operator
down f32 f5
1
477 0
1
0 0 25 29
1
end_operator
begin_operator
down f32 f6
1
506 0
1
0 0 25 30
1
end_operator
begin_operator
down f32 f7
1
534 0
1
0 0 25 31
1
end_operator
begin_operator
down f32 f8
1
561 0
1
0 0 25 32
1
end_operator
begin_operator
down f32 f9
1
587 0
1
0 0 25 33
1
end_operator
begin_operator
down f33 f1
1
54 0
1
0 0 26 0
1
end_operator
begin_operator
down f33 f10
1
84 0
1
0 0 26 1
1
end_operator
begin_operator
down f33 f11
1
107 0
1
0 0 26 2
1
end_operator
begin_operator
down f33 f12
1
129 0
1
0 0 26 3
1
end_operator
begin_operator
down f33 f13
1
150 0
1
0 0 26 4
1
end_operator
begin_operator
down f33 f14
1
170 0
1
0 0 26 5
1
end_operator
begin_operator
down f33 f15
1
189 0
1
0 0 26 6
1
end_operator
begin_operator
down f33 f16
1
207 0
1
0 0 26 7
1
end_operator
begin_operator
down f33 f17
1
224 0
1
0 0 26 8
1
end_operator
begin_operator
down f33 f18
1
240 0
1
0 0 26 9
1
end_operator
begin_operator
down f33 f19
1
255 0
1
0 0 26 10
1
end_operator
begin_operator
down f33 f2
1
281 0
1
0 0 26 11
1
end_operator
begin_operator
down f33 f20
1
301 0
1
0 0 26 12
1
end_operator
begin_operator
down f33 f21
1
314 0
1
0 0 26 13
1
end_operator
begin_operator
down f33 f22
1
326 0
1
0 0 26 14
1
end_operator
begin_operator
down f33 f23
1
337 0
1
0 0 26 15
1
end_operator
begin_operator
down f33 f24
1
347 0
1
0 0 26 16
1
end_operator
begin_operator
down f33 f25
1
356 0
1
0 0 26 17
1
end_operator
begin_operator
down f33 f26
1
364 0
1
0 0 26 18
1
end_operator
begin_operator
down f33 f27
1
371 0
1
0 0 26 19
1
end_operator
begin_operator
down f33 f28
1
377 0
1
0 0 26 20
1
end_operator
begin_operator
down f33 f29
1
382 0
1
0 0 26 21
1
end_operator
begin_operator
down f33 f3
1
407 0
1
0 0 26 22
1
end_operator
begin_operator
down f33 f30
1
417 0
1
0 0 26 23
1
end_operator
begin_operator
down f33 f31
1
420 0
1
0 0 26 24
1
end_operator
begin_operator
down f33 f32
1
422 0
1
0 0 26 25
1
end_operator
begin_operator
down f33 f4
1
448 0
1
0 0 26 28
1
end_operator
begin_operator
down f33 f5
1
478 0
1
0 0 26 29
1
end_operator
begin_operator
down f33 f6
1
507 0
1
0 0 26 30
1
end_operator
begin_operator
down f33 f7
1
535 0
1
0 0 26 31
1
end_operator
begin_operator
down f33 f8
1
562 0
1
0 0 26 32
1
end_operator
begin_operator
down f33 f9
1
588 0
1
0 0 26 33
1
end_operator
begin_operator
down f34 f1
1
55 0
1
0 0 27 0
1
end_operator
begin_operator
down f34 f10
1
85 0
1
0 0 27 1
1
end_operator
begin_operator
down f34 f11
1
108 0
1
0 0 27 2
1
end_operator
begin_operator
down f34 f12
1
130 0
1
0 0 27 3
1
end_operator
begin_operator
down f34 f13
1
151 0
1
0 0 27 4
1
end_operator
begin_operator
down f34 f14
1
171 0
1
0 0 27 5
1
end_operator
begin_operator
down f34 f15
1
190 0
1
0 0 27 6
1
end_operator
begin_operator
down f34 f16
1
208 0
1
0 0 27 7
1
end_operator
begin_operator
down f34 f17
1
225 0
1
0 0 27 8
1
end_operator
begin_operator
down f34 f18
1
241 0
1
0 0 27 9
1
end_operator
begin_operator
down f34 f19
1
256 0
1
0 0 27 10
1
end_operator
begin_operator
down f34 f2
1
282 0
1
0 0 27 11
1
end_operator
begin_operator
down f34 f20
1
302 0
1
0 0 27 12
1
end_operator
begin_operator
down f34 f21
1
315 0
1
0 0 27 13
1
end_operator
begin_operator
down f34 f22
1
327 0
1
0 0 27 14
1
end_operator
begin_operator
down f34 f23
1
338 0
1
0 0 27 15
1
end_operator
begin_operator
down f34 f24
1
348 0
1
0 0 27 16
1
end_operator
begin_operator
down f34 f25
1
357 0
1
0 0 27 17
1
end_operator
begin_operator
down f34 f26
1
365 0
1
0 0 27 18
1
end_operator
begin_operator
down f34 f27
1
372 0
1
0 0 27 19
1
end_operator
begin_operator
down f34 f28
1
378 0
1
0 0 27 20
1
end_operator
begin_operator
down f34 f29
1
383 0
1
0 0 27 21
1
end_operator
begin_operator
down f34 f3
1
408 0
1
0 0 27 22
1
end_operator
begin_operator
down f34 f30
1
418 0
1
0 0 27 23
1
end_operator
begin_operator
down f34 f31
1
421 0
1
0 0 27 24
1
end_operator
begin_operator
down f34 f32
1
423 0
1
0 0 27 25
1
end_operator
begin_operator
down f34 f33
1
424 0
1
0 0 27 26
1
end_operator
begin_operator
down f34 f4
1
449 0
1
0 0 27 28
1
end_operator
begin_operator
down f34 f5
1
479 0
1
0 0 27 29
1
end_operator
begin_operator
down f34 f6
1
508 0
1
0 0 27 30
1
end_operator
begin_operator
down f34 f7
1
536 0
1
0 0 27 31
1
end_operator
begin_operator
down f34 f8
1
563 0
1
0 0 27 32
1
end_operator
begin_operator
down f34 f9
1
589 0
1
0 0 27 33
1
end_operator
begin_operator
down f4 f1
1
56 0
1
0 0 28 0
1
end_operator
begin_operator
down f4 f2
1
283 0
1
0 0 28 11
1
end_operator
begin_operator
down f4 f3
1
409 0
1
0 0 28 22
1
end_operator
begin_operator
down f5 f1
1
57 0
1
0 0 29 0
1
end_operator
begin_operator
down f5 f2
1
284 0
1
0 0 29 11
1
end_operator
begin_operator
down f5 f3
1
410 0
1
0 0 29 22
1
end_operator
begin_operator
down f5 f4
1
450 0
1
0 0 29 28
1
end_operator
begin_operator
down f6 f1
1
58 0
1
0 0 30 0
1
end_operator
begin_operator
down f6 f2
1
285 0
1
0 0 30 11
1
end_operator
begin_operator
down f6 f3
1
411 0
1
0 0 30 22
1
end_operator
begin_operator
down f6 f4
1
451 0
1
0 0 30 28
1
end_operator
begin_operator
down f6 f5
1
480 0
1
0 0 30 29
1
end_operator
begin_operator
down f7 f1
1
59 0
1
0 0 31 0
1
end_operator
begin_operator
down f7 f2
1
286 0
1
0 0 31 11
1
end_operator
begin_operator
down f7 f3
1
412 0
1
0 0 31 22
1
end_operator
begin_operator
down f7 f4
1
452 0
1
0 0 31 28
1
end_operator
begin_operator
down f7 f5
1
481 0
1
0 0 31 29
1
end_operator
begin_operator
down f7 f6
1
509 0
1
0 0 31 30
1
end_operator
begin_operator
down f8 f1
1
60 0
1
0 0 32 0
1
end_operator
begin_operator
down f8 f2
1
287 0
1
0 0 32 11
1
end_operator
begin_operator
down f8 f3
1
413 0
1
0 0 32 22
1
end_operator
begin_operator
down f8 f4
1
453 0
1
0 0 32 28
1
end_operator
begin_operator
down f8 f5
1
482 0
1
0 0 32 29
1
end_operator
begin_operator
down f8 f6
1
510 0
1
0 0 32 30
1
end_operator
begin_operator
down f8 f7
1
537 0
1
0 0 32 31
1
end_operator
begin_operator
down f9 f1
1
61 0
1
0 0 33 0
1
end_operator
begin_operator
down f9 f2
1
288 0
1
0 0 33 11
1
end_operator
begin_operator
down f9 f3
1
414 0
1
0 0 33 22
1
end_operator
begin_operator
down f9 f4
1
454 0
1
0 0 33 28
1
end_operator
begin_operator
down f9 f5
1
483 0
1
0 0 33 29
1
end_operator
begin_operator
down f9 f6
1
511 0
1
0 0 33 30
1
end_operator
begin_operator
down f9 f7
1
538 0
1
0 0 33 31
1
end_operator
begin_operator
down f9 f8
1
564 0
1
0 0 33 32
1
end_operator
begin_operator
up f1 f10
1
29 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f11
1
30 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f12
1
31 0
1
0 0 0 3
1
end_operator
begin_operator
up f1 f13
1
32 0
1
0 0 0 4
1
end_operator
begin_operator
up f1 f14
1
33 0
1
0 0 0 5
1
end_operator
begin_operator
up f1 f15
1
34 0
1
0 0 0 6
1
end_operator
begin_operator
up f1 f16
1
35 0
1
0 0 0 7
1
end_operator
begin_operator
up f1 f17
1
36 0
1
0 0 0 8
1
end_operator
begin_operator
up f1 f18
1
37 0
1
0 0 0 9
1
end_operator
begin_operator
up f1 f19
1
38 0
1
0 0 0 10
1
end_operator
begin_operator
up f1 f2
1
39 0
1
0 0 0 11
1
end_operator
begin_operator
up f1 f20
1
40 0
1
0 0 0 12
1
end_operator
begin_operator
up f1 f21
1
41 0
1
0 0 0 13
1
end_operator
begin_operator
up f1 f22
1
42 0
1
0 0 0 14
1
end_operator
begin_operator
up f1 f23
1
43 0
1
0 0 0 15
1
end_operator
begin_operator
up f1 f24
1
44 0
1
0 0 0 16
1
end_operator
begin_operator
up f1 f25
1
45 0
1
0 0 0 17
1
end_operator
begin_operator
up f1 f26
1
46 0
1
0 0 0 18
1
end_operator
begin_operator
up f1 f27
1
47 0
1
0 0 0 19
1
end_operator
begin_operator
up f1 f28
1
48 0
1
0 0 0 20
1
end_operator
begin_operator
up f1 f29
1
49 0
1
0 0 0 21
1
end_operator
begin_operator
up f1 f3
1
50 0
1
0 0 0 22
1
end_operator
begin_operator
up f1 f30
1
51 0
1
0 0 0 23
1
end_operator
begin_operator
up f1 f31
1
52 0
1
0 0 0 24
1
end_operator
begin_operator
up f1 f32
1
53 0
1
0 0 0 25
1
end_operator
begin_operator
up f1 f33
1
54 0
1
0 0 0 26
1
end_operator
begin_operator
up f1 f34
1
55 0
1
0 0 0 27
1
end_operator
begin_operator
up f1 f4
1
56 0
1
0 0 0 28
1
end_operator
begin_operator
up f1 f5
1
57 0
1
0 0 0 29
1
end_operator
begin_operator
up f1 f6
1
58 0
1
0 0 0 30
1
end_operator
begin_operator
up f1 f7
1
59 0
1
0 0 0 31
1
end_operator
begin_operator
up f1 f8
1
60 0
1
0 0 0 32
1
end_operator
begin_operator
up f1 f9
1
61 0
1
0 0 0 33
1
end_operator
begin_operator
up f10 f11
1
62 0
1
0 0 1 2
1
end_operator
begin_operator
up f10 f12
1
63 0
1
0 0 1 3
1
end_operator
begin_operator
up f10 f13
1
64 0
1
0 0 1 4
1
end_operator
begin_operator
up f10 f14
1
65 0
1
0 0 1 5
1
end_operator
begin_operator
up f10 f15
1
66 0
1
0 0 1 6
1
end_operator
begin_operator
up f10 f16
1
67 0
1
0 0 1 7
1
end_operator
begin_operator
up f10 f17
1
68 0
1
0 0 1 8
1
end_operator
begin_operator
up f10 f18
1
69 0
1
0 0 1 9
1
end_operator
begin_operator
up f10 f19
1
70 0
1
0 0 1 10
1
end_operator
begin_operator
up f10 f20
1
71 0
1
0 0 1 12
1
end_operator
begin_operator
up f10 f21
1
72 0
1
0 0 1 13
1
end_operator
begin_operator
up f10 f22
1
73 0
1
0 0 1 14
1
end_operator
begin_operator
up f10 f23
1
74 0
1
0 0 1 15
1
end_operator
begin_operator
up f10 f24
1
75 0
1
0 0 1 16
1
end_operator
begin_operator
up f10 f25
1
76 0
1
0 0 1 17
1
end_operator
begin_operator
up f10 f26
1
77 0
1
0 0 1 18
1
end_operator
begin_operator
up f10 f27
1
78 0
1
0 0 1 19
1
end_operator
begin_operator
up f10 f28
1
79 0
1
0 0 1 20
1
end_operator
begin_operator
up f10 f29
1
80 0
1
0 0 1 21
1
end_operator
begin_operator
up f10 f30
1
81 0
1
0 0 1 23
1
end_operator
begin_operator
up f10 f31
1
82 0
1
0 0 1 24
1
end_operator
begin_operator
up f10 f32
1
83 0
1
0 0 1 25
1
end_operator
begin_operator
up f10 f33
1
84 0
1
0 0 1 26
1
end_operator
begin_operator
up f10 f34
1
85 0
1
0 0 1 27
1
end_operator
begin_operator
up f11 f12
1
86 0
1
0 0 2 3
1
end_operator
begin_operator
up f11 f13
1
87 0
1
0 0 2 4
1
end_operator
begin_operator
up f11 f14
1
88 0
1
0 0 2 5
1
end_operator
begin_operator
up f11 f15
1
89 0
1
0 0 2 6
1
end_operator
begin_operator
up f11 f16
1
90 0
1
0 0 2 7
1
end_operator
begin_operator
up f11 f17
1
91 0
1
0 0 2 8
1
end_operator
begin_operator
up f11 f18
1
92 0
1
0 0 2 9
1
end_operator
begin_operator
up f11 f19
1
93 0
1
0 0 2 10
1
end_operator
begin_operator
up f11 f20
1
94 0
1
0 0 2 12
1
end_operator
begin_operator
up f11 f21
1
95 0
1
0 0 2 13
1
end_operator
begin_operator
up f11 f22
1
96 0
1
0 0 2 14
1
end_operator
begin_operator
up f11 f23
1
97 0
1
0 0 2 15
1
end_operator
begin_operator
up f11 f24
1
98 0
1
0 0 2 16
1
end_operator
begin_operator
up f11 f25
1
99 0
1
0 0 2 17
1
end_operator
begin_operator
up f11 f26
1
100 0
1
0 0 2 18
1
end_operator
begin_operator
up f11 f27
1
101 0
1
0 0 2 19
1
end_operator
begin_operator
up f11 f28
1
102 0
1
0 0 2 20
1
end_operator
begin_operator
up f11 f29
1
103 0
1
0 0 2 21
1
end_operator
begin_operator
up f11 f30
1
104 0
1
0 0 2 23
1
end_operator
begin_operator
up f11 f31
1
105 0
1
0 0 2 24
1
end_operator
begin_operator
up f11 f32
1
106 0
1
0 0 2 25
1
end_operator
begin_operator
up f11 f33
1
107 0
1
0 0 2 26
1
end_operator
begin_operator
up f11 f34
1
108 0
1
0 0 2 27
1
end_operator
begin_operator
up f12 f13
1
109 0
1
0 0 3 4
1
end_operator
begin_operator
up f12 f14
1
110 0
1
0 0 3 5
1
end_operator
begin_operator
up f12 f15
1
111 0
1
0 0 3 6
1
end_operator
begin_operator
up f12 f16
1
112 0
1
0 0 3 7
1
end_operator
begin_operator
up f12 f17
1
113 0
1
0 0 3 8
1
end_operator
begin_operator
up f12 f18
1
114 0
1
0 0 3 9
1
end_operator
begin_operator
up f12 f19
1
115 0
1
0 0 3 10
1
end_operator
begin_operator
up f12 f20
1
116 0
1
0 0 3 12
1
end_operator
begin_operator
up f12 f21
1
117 0
1
0 0 3 13
1
end_operator
begin_operator
up f12 f22
1
118 0
1
0 0 3 14
1
end_operator
begin_operator
up f12 f23
1
119 0
1
0 0 3 15
1
end_operator
begin_operator
up f12 f24
1
120 0
1
0 0 3 16
1
end_operator
begin_operator
up f12 f25
1
121 0
1
0 0 3 17
1
end_operator
begin_operator
up f12 f26
1
122 0
1
0 0 3 18
1
end_operator
begin_operator
up f12 f27
1
123 0
1
0 0 3 19
1
end_operator
begin_operator
up f12 f28
1
124 0
1
0 0 3 20
1
end_operator
begin_operator
up f12 f29
1
125 0
1
0 0 3 21
1
end_operator
begin_operator
up f12 f30
1
126 0
1
0 0 3 23
1
end_operator
begin_operator
up f12 f31
1
127 0
1
0 0 3 24
1
end_operator
begin_operator
up f12 f32
1
128 0
1
0 0 3 25
1
end_operator
begin_operator
up f12 f33
1
129 0
1
0 0 3 26
1
end_operator
begin_operator
up f12 f34
1
130 0
1
0 0 3 27
1
end_operator
begin_operator
up f13 f14
1
131 0
1
0 0 4 5
1
end_operator
begin_operator
up f13 f15
1
132 0
1
0 0 4 6
1
end_operator
begin_operator
up f13 f16
1
133 0
1
0 0 4 7
1
end_operator
begin_operator
up f13 f17
1
134 0
1
0 0 4 8
1
end_operator
begin_operator
up f13 f18
1
135 0
1
0 0 4 9
1
end_operator
begin_operator
up f13 f19
1
136 0
1
0 0 4 10
1
end_operator
begin_operator
up f13 f20
1
137 0
1
0 0 4 12
1
end_operator
begin_operator
up f13 f21
1
138 0
1
0 0 4 13
1
end_operator
begin_operator
up f13 f22
1
139 0
1
0 0 4 14
1
end_operator
begin_operator
up f13 f23
1
140 0
1
0 0 4 15
1
end_operator
begin_operator
up f13 f24
1
141 0
1
0 0 4 16
1
end_operator
begin_operator
up f13 f25
1
142 0
1
0 0 4 17
1
end_operator
begin_operator
up f13 f26
1
143 0
1
0 0 4 18
1
end_operator
begin_operator
up f13 f27
1
144 0
1
0 0 4 19
1
end_operator
begin_operator
up f13 f28
1
145 0
1
0 0 4 20
1
end_operator
begin_operator
up f13 f29
1
146 0
1
0 0 4 21
1
end_operator
begin_operator
up f13 f30
1
147 0
1
0 0 4 23
1
end_operator
begin_operator
up f13 f31
1
148 0
1
0 0 4 24
1
end_operator
begin_operator
up f13 f32
1
149 0
1
0 0 4 25
1
end_operator
begin_operator
up f13 f33
1
150 0
1
0 0 4 26
1
end_operator
begin_operator
up f13 f34
1
151 0
1
0 0 4 27
1
end_operator
begin_operator
up f14 f15
1
152 0
1
0 0 5 6
1
end_operator
begin_operator
up f14 f16
1
153 0
1
0 0 5 7
1
end_operator
begin_operator
up f14 f17
1
154 0
1
0 0 5 8
1
end_operator
begin_operator
up f14 f18
1
155 0
1
0 0 5 9
1
end_operator
begin_operator
up f14 f19
1
156 0
1
0 0 5 10
1
end_operator
begin_operator
up f14 f20
1
157 0
1
0 0 5 12
1
end_operator
begin_operator
up f14 f21
1
158 0
1
0 0 5 13
1
end_operator
begin_operator
up f14 f22
1
159 0
1
0 0 5 14
1
end_operator
begin_operator
up f14 f23
1
160 0
1
0 0 5 15
1
end_operator
begin_operator
up f14 f24
1
161 0
1
0 0 5 16
1
end_operator
begin_operator
up f14 f25
1
162 0
1
0 0 5 17
1
end_operator
begin_operator
up f14 f26
1
163 0
1
0 0 5 18
1
end_operator
begin_operator
up f14 f27
1
164 0
1
0 0 5 19
1
end_operator
begin_operator
up f14 f28
1
165 0
1
0 0 5 20
1
end_operator
begin_operator
up f14 f29
1
166 0
1
0 0 5 21
1
end_operator
begin_operator
up f14 f30
1
167 0
1
0 0 5 23
1
end_operator
begin_operator
up f14 f31
1
168 0
1
0 0 5 24
1
end_operator
begin_operator
up f14 f32
1
169 0
1
0 0 5 25
1
end_operator
begin_operator
up f14 f33
1
170 0
1
0 0 5 26
1
end_operator
begin_operator
up f14 f34
1
171 0
1
0 0 5 27
1
end_operator
begin_operator
up f15 f16
1
172 0
1
0 0 6 7
1
end_operator
begin_operator
up f15 f17
1
173 0
1
0 0 6 8
1
end_operator
begin_operator
up f15 f18
1
174 0
1
0 0 6 9
1
end_operator
begin_operator
up f15 f19
1
175 0
1
0 0 6 10
1
end_operator
begin_operator
up f15 f20
1
176 0
1
0 0 6 12
1
end_operator
begin_operator
up f15 f21
1
177 0
1
0 0 6 13
1
end_operator
begin_operator
up f15 f22
1
178 0
1
0 0 6 14
1
end_operator
begin_operator
up f15 f23
1
179 0
1
0 0 6 15
1
end_operator
begin_operator
up f15 f24
1
180 0
1
0 0 6 16
1
end_operator
begin_operator
up f15 f25
1
181 0
1
0 0 6 17
1
end_operator
begin_operator
up f15 f26
1
182 0
1
0 0 6 18
1
end_operator
begin_operator
up f15 f27
1
183 0
1
0 0 6 19
1
end_operator
begin_operator
up f15 f28
1
184 0
1
0 0 6 20
1
end_operator
begin_operator
up f15 f29
1
185 0
1
0 0 6 21
1
end_operator
begin_operator
up f15 f30
1
186 0
1
0 0 6 23
1
end_operator
begin_operator
up f15 f31
1
187 0
1
0 0 6 24
1
end_operator
begin_operator
up f15 f32
1
188 0
1
0 0 6 25
1
end_operator
begin_operator
up f15 f33
1
189 0
1
0 0 6 26
1
end_operator
begin_operator
up f15 f34
1
190 0
1
0 0 6 27
1
end_operator
begin_operator
up f16 f17
1
191 0
1
0 0 7 8
1
end_operator
begin_operator
up f16 f18
1
192 0
1
0 0 7 9
1
end_operator
begin_operator
up f16 f19
1
193 0
1
0 0 7 10
1
end_operator
begin_operator
up f16 f20
1
194 0
1
0 0 7 12
1
end_operator
begin_operator
up f16 f21
1
195 0
1
0 0 7 13
1
end_operator
begin_operator
up f16 f22
1
196 0
1
0 0 7 14
1
end_operator
begin_operator
up f16 f23
1
197 0
1
0 0 7 15
1
end_operator
begin_operator
up f16 f24
1
198 0
1
0 0 7 16
1
end_operator
begin_operator
up f16 f25
1
199 0
1
0 0 7 17
1
end_operator
begin_operator
up f16 f26
1
200 0
1
0 0 7 18
1
end_operator
begin_operator
up f16 f27
1
201 0
1
0 0 7 19
1
end_operator
begin_operator
up f16 f28
1
202 0
1
0 0 7 20
1
end_operator
begin_operator
up f16 f29
1
203 0
1
0 0 7 21
1
end_operator
begin_operator
up f16 f30
1
204 0
1
0 0 7 23
1
end_operator
begin_operator
up f16 f31
1
205 0
1
0 0 7 24
1
end_operator
begin_operator
up f16 f32
1
206 0
1
0 0 7 25
1
end_operator
begin_operator
up f16 f33
1
207 0
1
0 0 7 26
1
end_operator
begin_operator
up f16 f34
1
208 0
1
0 0 7 27
1
end_operator
begin_operator
up f17 f18
1
209 0
1
0 0 8 9
1
end_operator
begin_operator
up f17 f19
1
210 0
1
0 0 8 10
1
end_operator
begin_operator
up f17 f20
1
211 0
1
0 0 8 12
1
end_operator
begin_operator
up f17 f21
1
212 0
1
0 0 8 13
1
end_operator
begin_operator
up f17 f22
1
213 0
1
0 0 8 14
1
end_operator
begin_operator
up f17 f23
1
214 0
1
0 0 8 15
1
end_operator
begin_operator
up f17 f24
1
215 0
1
0 0 8 16
1
end_operator
begin_operator
up f17 f25
1
216 0
1
0 0 8 17
1
end_operator
begin_operator
up f17 f26
1
217 0
1
0 0 8 18
1
end_operator
begin_operator
up f17 f27
1
218 0
1
0 0 8 19
1
end_operator
begin_operator
up f17 f28
1
219 0
1
0 0 8 20
1
end_operator
begin_operator
up f17 f29
1
220 0
1
0 0 8 21
1
end_operator
begin_operator
up f17 f30
1
221 0
1
0 0 8 23
1
end_operator
begin_operator
up f17 f31
1
222 0
1
0 0 8 24
1
end_operator
begin_operator
up f17 f32
1
223 0
1
0 0 8 25
1
end_operator
begin_operator
up f17 f33
1
224 0
1
0 0 8 26
1
end_operator
begin_operator
up f17 f34
1
225 0
1
0 0 8 27
1
end_operator
begin_operator
up f18 f19
1
226 0
1
0 0 9 10
1
end_operator
begin_operator
up f18 f20
1
227 0
1
0 0 9 12
1
end_operator
begin_operator
up f18 f21
1
228 0
1
0 0 9 13
1
end_operator
begin_operator
up f18 f22
1
229 0
1
0 0 9 14
1
end_operator
begin_operator
up f18 f23
1
230 0
1
0 0 9 15
1
end_operator
begin_operator
up f18 f24
1
231 0
1
0 0 9 16
1
end_operator
begin_operator
up f18 f25
1
232 0
1
0 0 9 17
1
end_operator
begin_operator
up f18 f26
1
233 0
1
0 0 9 18
1
end_operator
begin_operator
up f18 f27
1
234 0
1
0 0 9 19
1
end_operator
begin_operator
up f18 f28
1
235 0
1
0 0 9 20
1
end_operator
begin_operator
up f18 f29
1
236 0
1
0 0 9 21
1
end_operator
begin_operator
up f18 f30
1
237 0
1
0 0 9 23
1
end_operator
begin_operator
up f18 f31
1
238 0
1
0 0 9 24
1
end_operator
begin_operator
up f18 f32
1
239 0
1
0 0 9 25
1
end_operator
begin_operator
up f18 f33
1
240 0
1
0 0 9 26
1
end_operator
begin_operator
up f18 f34
1
241 0
1
0 0 9 27
1
end_operator
begin_operator
up f19 f20
1
242 0
1
0 0 10 12
1
end_operator
begin_operator
up f19 f21
1
243 0
1
0 0 10 13
1
end_operator
begin_operator
up f19 f22
1
244 0
1
0 0 10 14
1
end_operator
begin_operator
up f19 f23
1
245 0
1
0 0 10 15
1
end_operator
begin_operator
up f19 f24
1
246 0
1
0 0 10 16
1
end_operator
begin_operator
up f19 f25
1
247 0
1
0 0 10 17
1
end_operator
begin_operator
up f19 f26
1
248 0
1
0 0 10 18
1
end_operator
begin_operator
up f19 f27
1
249 0
1
0 0 10 19
1
end_operator
begin_operator
up f19 f28
1
250 0
1
0 0 10 20
1
end_operator
begin_operator
up f19 f29
1
251 0
1
0 0 10 21
1
end_operator
begin_operator
up f19 f30
1
252 0
1
0 0 10 23
1
end_operator
begin_operator
up f19 f31
1
253 0
1
0 0 10 24
1
end_operator
begin_operator
up f19 f32
1
254 0
1
0 0 10 25
1
end_operator
begin_operator
up f19 f33
1
255 0
1
0 0 10 26
1
end_operator
begin_operator
up f19 f34
1
256 0
1
0 0 10 27
1
end_operator
begin_operator
up f2 f10
1
257 0
1
0 0 11 1
1
end_operator
begin_operator
up f2 f11
1
258 0
1
0 0 11 2
1
end_operator
begin_operator
up f2 f12
1
259 0
1
0 0 11 3
1
end_operator
begin_operator
up f2 f13
1
260 0
1
0 0 11 4
1
end_operator
begin_operator
up f2 f14
1
261 0
1
0 0 11 5
1
end_operator
begin_operator
up f2 f15
1
262 0
1
0 0 11 6
1
end_operator
begin_operator
up f2 f16
1
263 0
1
0 0 11 7
1
end_operator
begin_operator
up f2 f17
1
264 0
1
0 0 11 8
1
end_operator
begin_operator
up f2 f18
1
265 0
1
0 0 11 9
1
end_operator
begin_operator
up f2 f19
1
266 0
1
0 0 11 10
1
end_operator
begin_operator
up f2 f20
1
267 0
1
0 0 11 12
1
end_operator
begin_operator
up f2 f21
1
268 0
1
0 0 11 13
1
end_operator
begin_operator
up f2 f22
1
269 0
1
0 0 11 14
1
end_operator
begin_operator
up f2 f23
1
270 0
1
0 0 11 15
1
end_operator
begin_operator
up f2 f24
1
271 0
1
0 0 11 16
1
end_operator
begin_operator
up f2 f25
1
272 0
1
0 0 11 17
1
end_operator
begin_operator
up f2 f26
1
273 0
1
0 0 11 18
1
end_operator
begin_operator
up f2 f27
1
274 0
1
0 0 11 19
1
end_operator
begin_operator
up f2 f28
1
275 0
1
0 0 11 20
1
end_operator
begin_operator
up f2 f29
1
276 0
1
0 0 11 21
1
end_operator
begin_operator
up f2 f3
1
277 0
1
0 0 11 22
1
end_operator
begin_operator
up f2 f30
1
278 0
1
0 0 11 23
1
end_operator
begin_operator
up f2 f31
1
279 0
1
0 0 11 24
1
end_operator
begin_operator
up f2 f32
1
280 0
1
0 0 11 25
1
end_operator
begin_operator
up f2 f33
1
281 0
1
0 0 11 26
1
end_operator
begin_operator
up f2 f34
1
282 0
1
0 0 11 27
1
end_operator
begin_operator
up f2 f4
1
283 0
1
0 0 11 28
1
end_operator
begin_operator
up f2 f5
1
284 0
1
0 0 11 29
1
end_operator
begin_operator
up f2 f6
1
285 0
1
0 0 11 30
1
end_operator
begin_operator
up f2 f7
1
286 0
1
0 0 11 31
1
end_operator
begin_operator
up f2 f8
1
287 0
1
0 0 11 32
1
end_operator
begin_operator
up f2 f9
1
288 0
1
0 0 11 33
1
end_operator
begin_operator
up f20 f21
1
289 0
1
0 0 12 13
1
end_operator
begin_operator
up f20 f22
1
290 0
1
0 0 12 14
1
end_operator
begin_operator
up f20 f23
1
291 0
1
0 0 12 15
1
end_operator
begin_operator
up f20 f24
1
292 0
1
0 0 12 16
1
end_operator
begin_operator
up f20 f25
1
293 0
1
0 0 12 17
1
end_operator
begin_operator
up f20 f26
1
294 0
1
0 0 12 18
1
end_operator
begin_operator
up f20 f27
1
295 0
1
0 0 12 19
1
end_operator
begin_operator
up f20 f28
1
296 0
1
0 0 12 20
1
end_operator
begin_operator
up f20 f29
1
297 0
1
0 0 12 21
1
end_operator
begin_operator
up f20 f30
1
298 0
1
0 0 12 23
1
end_operator
begin_operator
up f20 f31
1
299 0
1
0 0 12 24
1
end_operator
begin_operator
up f20 f32
1
300 0
1
0 0 12 25
1
end_operator
begin_operator
up f20 f33
1
301 0
1
0 0 12 26
1
end_operator
begin_operator
up f20 f34
1
302 0
1
0 0 12 27
1
end_operator
begin_operator
up f21 f22
1
303 0
1
0 0 13 14
1
end_operator
begin_operator
up f21 f23
1
304 0
1
0 0 13 15
1
end_operator
begin_operator
up f21 f24
1
305 0
1
0 0 13 16
1
end_operator
begin_operator
up f21 f25
1
306 0
1
0 0 13 17
1
end_operator
begin_operator
up f21 f26
1
307 0
1
0 0 13 18
1
end_operator
begin_operator
up f21 f27
1
308 0
1
0 0 13 19
1
end_operator
begin_operator
up f21 f28
1
309 0
1
0 0 13 20
1
end_operator
begin_operator
up f21 f29
1
310 0
1
0 0 13 21
1
end_operator
begin_operator
up f21 f30
1
311 0
1
0 0 13 23
1
end_operator
begin_operator
up f21 f31
1
312 0
1
0 0 13 24
1
end_operator
begin_operator
up f21 f32
1
313 0
1
0 0 13 25
1
end_operator
begin_operator
up f21 f33
1
314 0
1
0 0 13 26
1
end_operator
begin_operator
up f21 f34
1
315 0
1
0 0 13 27
1
end_operator
begin_operator
up f22 f23
1
316 0
1
0 0 14 15
1
end_operator
begin_operator
up f22 f24
1
317 0
1
0 0 14 16
1
end_operator
begin_operator
up f22 f25
1
318 0
1
0 0 14 17
1
end_operator
begin_operator
up f22 f26
1
319 0
1
0 0 14 18
1
end_operator
begin_operator
up f22 f27
1
320 0
1
0 0 14 19
1
end_operator
begin_operator
up f22 f28
1
321 0
1
0 0 14 20
1
end_operator
begin_operator
up f22 f29
1
322 0
1
0 0 14 21
1
end_operator
begin_operator
up f22 f30
1
323 0
1
0 0 14 23
1
end_operator
begin_operator
up f22 f31
1
324 0
1
0 0 14 24
1
end_operator
begin_operator
up f22 f32
1
325 0
1
0 0 14 25
1
end_operator
begin_operator
up f22 f33
1
326 0
1
0 0 14 26
1
end_operator
begin_operator
up f22 f34
1
327 0
1
0 0 14 27
1
end_operator
begin_operator
up f23 f24
1
328 0
1
0 0 15 16
1
end_operator
begin_operator
up f23 f25
1
329 0
1
0 0 15 17
1
end_operator
begin_operator
up f23 f26
1
330 0
1
0 0 15 18
1
end_operator
begin_operator
up f23 f27
1
331 0
1
0 0 15 19
1
end_operator
begin_operator
up f23 f28
1
332 0
1
0 0 15 20
1
end_operator
begin_operator
up f23 f29
1
333 0
1
0 0 15 21
1
end_operator
begin_operator
up f23 f30
1
334 0
1
0 0 15 23
1
end_operator
begin_operator
up f23 f31
1
335 0
1
0 0 15 24
1
end_operator
begin_operator
up f23 f32
1
336 0
1
0 0 15 25
1
end_operator
begin_operator
up f23 f33
1
337 0
1
0 0 15 26
1
end_operator
begin_operator
up f23 f34
1
338 0
1
0 0 15 27
1
end_operator
begin_operator
up f24 f25
1
339 0
1
0 0 16 17
1
end_operator
begin_operator
up f24 f26
1
340 0
1
0 0 16 18
1
end_operator
begin_operator
up f24 f27
1
341 0
1
0 0 16 19
1
end_operator
begin_operator
up f24 f28
1
342 0
1
0 0 16 20
1
end_operator
begin_operator
up f24 f29
1
343 0
1
0 0 16 21
1
end_operator
begin_operator
up f24 f30
1
344 0
1
0 0 16 23
1
end_operator
begin_operator
up f24 f31
1
345 0
1
0 0 16 24
1
end_operator
begin_operator
up f24 f32
1
346 0
1
0 0 16 25
1
end_operator
begin_operator
up f24 f33
1
347 0
1
0 0 16 26
1
end_operator
begin_operator
up f24 f34
1
348 0
1
0 0 16 27
1
end_operator
begin_operator
up f25 f26
1
349 0
1
0 0 17 18
1
end_operator
begin_operator
up f25 f27
1
350 0
1
0 0 17 19
1
end_operator
begin_operator
up f25 f28
1
351 0
1
0 0 17 20
1
end_operator
begin_operator
up f25 f29
1
352 0
1
0 0 17 21
1
end_operator
begin_operator
up f25 f30
1
353 0
1
0 0 17 23
1
end_operator
begin_operator
up f25 f31
1
354 0
1
0 0 17 24
1
end_operator
begin_operator
up f25 f32
1
355 0
1
0 0 17 25
1
end_operator
begin_operator
up f25 f33
1
356 0
1
0 0 17 26
1
end_operator
begin_operator
up f25 f34
1
357 0
1
0 0 17 27
1
end_operator
begin_operator
up f26 f27
1
358 0
1
0 0 18 19
1
end_operator
begin_operator
up f26 f28
1
359 0
1
0 0 18 20
1
end_operator
begin_operator
up f26 f29
1
360 0
1
0 0 18 21
1
end_operator
begin_operator
up f26 f30
1
361 0
1
0 0 18 23
1
end_operator
begin_operator
up f26 f31
1
362 0
1
0 0 18 24
1
end_operator
begin_operator
up f26 f32
1
363 0
1
0 0 18 25
1
end_operator
begin_operator
up f26 f33
1
364 0
1
0 0 18 26
1
end_operator
begin_operator
up f26 f34
1
365 0
1
0 0 18 27
1
end_operator
begin_operator
up f27 f28
1
366 0
1
0 0 19 20
1
end_operator
begin_operator
up f27 f29
1
367 0
1
0 0 19 21
1
end_operator
begin_operator
up f27 f30
1
368 0
1
0 0 19 23
1
end_operator
begin_operator
up f27 f31
1
369 0
1
0 0 19 24
1
end_operator
begin_operator
up f27 f32
1
370 0
1
0 0 19 25
1
end_operator
begin_operator
up f27 f33
1
371 0
1
0 0 19 26
1
end_operator
begin_operator
up f27 f34
1
372 0
1
0 0 19 27
1
end_operator
begin_operator
up f28 f29
1
373 0
1
0 0 20 21
1
end_operator
begin_operator
up f28 f30
1
374 0
1
0 0 20 23
1
end_operator
begin_operator
up f28 f31
1
375 0
1
0 0 20 24
1
end_operator
begin_operator
up f28 f32
1
376 0
1
0 0 20 25
1
end_operator
begin_operator
up f28 f33
1
377 0
1
0 0 20 26
1
end_operator
begin_operator
up f28 f34
1
378 0
1
0 0 20 27
1
end_operator
begin_operator
up f29 f30
1
379 0
1
0 0 21 23
1
end_operator
begin_operator
up f29 f31
1
380 0
1
0 0 21 24
1
end_operator
begin_operator
up f29 f32
1
381 0
1
0 0 21 25
1
end_operator
begin_operator
up f29 f33
1
382 0
1
0 0 21 26
1
end_operator
begin_operator
up f29 f34
1
383 0
1
0 0 21 27
1
end_operator
begin_operator
up f3 f10
1
384 0
1
0 0 22 1
1
end_operator
begin_operator
up f3 f11
1
385 0
1
0 0 22 2
1
end_operator
begin_operator
up f3 f12
1
386 0
1
0 0 22 3
1
end_operator
begin_operator
up f3 f13
1
387 0
1
0 0 22 4
1
end_operator
begin_operator
up f3 f14
1
388 0
1
0 0 22 5
1
end_operator
begin_operator
up f3 f15
1
389 0
1
0 0 22 6
1
end_operator
begin_operator
up f3 f16
1
390 0
1
0 0 22 7
1
end_operator
begin_operator
up f3 f17
1
391 0
1
0 0 22 8
1
end_operator
begin_operator
up f3 f18
1
392 0
1
0 0 22 9
1
end_operator
begin_operator
up f3 f19
1
393 0
1
0 0 22 10
1
end_operator
begin_operator
up f3 f20
1
394 0
1
0 0 22 12
1
end_operator
begin_operator
up f3 f21
1
395 0
1
0 0 22 13
1
end_operator
begin_operator
up f3 f22
1
396 0
1
0 0 22 14
1
end_operator
begin_operator
up f3 f23
1
397 0
1
0 0 22 15
1
end_operator
begin_operator
up f3 f24
1
398 0
1
0 0 22 16
1
end_operator
begin_operator
up f3 f25
1
399 0
1
0 0 22 17
1
end_operator
begin_operator
up f3 f26
1
400 0
1
0 0 22 18
1
end_operator
begin_operator
up f3 f27
1
401 0
1
0 0 22 19
1
end_operator
begin_operator
up f3 f28
1
402 0
1
0 0 22 20
1
end_operator
begin_operator
up f3 f29
1
403 0
1
0 0 22 21
1
end_operator
begin_operator
up f3 f30
1
404 0
1
0 0 22 23
1
end_operator
begin_operator
up f3 f31
1
405 0
1
0 0 22 24
1
end_operator
begin_operator
up f3 f32
1
406 0
1
0 0 22 25
1
end_operator
begin_operator
up f3 f33
1
407 0
1
0 0 22 26
1
end_operator
begin_operator
up f3 f34
1
408 0
1
0 0 22 27
1
end_operator
begin_operator
up f3 f4
1
409 0
1
0 0 22 28
1
end_operator
begin_operator
up f3 f5
1
410 0
1
0 0 22 29
1
end_operator
begin_operator
up f3 f6
1
411 0
1
0 0 22 30
1
end_operator
begin_operator
up f3 f7
1
412 0
1
0 0 22 31
1
end_operator
begin_operator
up f3 f8
1
413 0
1
0 0 22 32
1
end_operator
begin_operator
up f3 f9
1
414 0
1
0 0 22 33
1
end_operator
begin_operator
up f30 f31
1
415 0
1
0 0 23 24
1
end_operator
begin_operator
up f30 f32
1
416 0
1
0 0 23 25
1
end_operator
begin_operator
up f30 f33
1
417 0
1
0 0 23 26
1
end_operator
begin_operator
up f30 f34
1
418 0
1
0 0 23 27
1
end_operator
begin_operator
up f31 f32
1
419 0
1
0 0 24 25
1
end_operator
begin_operator
up f31 f33
1
420 0
1
0 0 24 26
1
end_operator
begin_operator
up f31 f34
1
421 0
1
0 0 24 27
1
end_operator
begin_operator
up f32 f33
1
422 0
1
0 0 25 26
1
end_operator
begin_operator
up f32 f34
1
423 0
1
0 0 25 27
1
end_operator
begin_operator
up f33 f34
1
424 0
1
0 0 26 27
1
end_operator
begin_operator
up f4 f10
1
425 0
1
0 0 28 1
1
end_operator
begin_operator
up f4 f11
1
426 0
1
0 0 28 2
1
end_operator
begin_operator
up f4 f12
1
427 0
1
0 0 28 3
1
end_operator
begin_operator
up f4 f13
1
428 0
1
0 0 28 4
1
end_operator
begin_operator
up f4 f14
1
429 0
1
0 0 28 5
1
end_operator
begin_operator
up f4 f15
1
430 0
1
0 0 28 6
1
end_operator
begin_operator
up f4 f16
1
431 0
1
0 0 28 7
1
end_operator
begin_operator
up f4 f17
1
432 0
1
0 0 28 8
1
end_operator
begin_operator
up f4 f18
1
433 0
1
0 0 28 9
1
end_operator
begin_operator
up f4 f19
1
434 0
1
0 0 28 10
1
end_operator
begin_operator
up f4 f20
1
435 0
1
0 0 28 12
1
end_operator
begin_operator
up f4 f21
1
436 0
1
0 0 28 13
1
end_operator
begin_operator
up f4 f22
1
437 0
1
0 0 28 14
1
end_operator
begin_operator
up f4 f23
1
438 0
1
0 0 28 15
1
end_operator
begin_operator
up f4 f24
1
439 0
1
0 0 28 16
1
end_operator
begin_operator
up f4 f25
1
440 0
1
0 0 28 17
1
end_operator
begin_operator
up f4 f26
1
441 0
1
0 0 28 18
1
end_operator
begin_operator
up f4 f27
1
442 0
1
0 0 28 19
1
end_operator
begin_operator
up f4 f28
1
443 0
1
0 0 28 20
1
end_operator
begin_operator
up f4 f29
1
444 0
1
0 0 28 21
1
end_operator
begin_operator
up f4 f30
1
445 0
1
0 0 28 23
1
end_operator
begin_operator
up f4 f31
1
446 0
1
0 0 28 24
1
end_operator
begin_operator
up f4 f32
1
447 0
1
0 0 28 25
1
end_operator
begin_operator
up f4 f33
1
448 0
1
0 0 28 26
1
end_operator
begin_operator
up f4 f34
1
449 0
1
0 0 28 27
1
end_operator
begin_operator
up f4 f5
1
450 0
1
0 0 28 29
1
end_operator
begin_operator
up f4 f6
1
451 0
1
0 0 28 30
1
end_operator
begin_operator
up f4 f7
1
452 0
1
0 0 28 31
1
end_operator
begin_operator
up f4 f8
1
453 0
1
0 0 28 32
1
end_operator
begin_operator
up f4 f9
1
454 0
1
0 0 28 33
1
end_operator
begin_operator
up f5 f10
1
455 0
1
0 0 29 1
1
end_operator
begin_operator
up f5 f11
1
456 0
1
0 0 29 2
1
end_operator
begin_operator
up f5 f12
1
457 0
1
0 0 29 3
1
end_operator
begin_operator
up f5 f13
1
458 0
1
0 0 29 4
1
end_operator
begin_operator
up f5 f14
1
459 0
1
0 0 29 5
1
end_operator
begin_operator
up f5 f15
1
460 0
1
0 0 29 6
1
end_operator
begin_operator
up f5 f16
1
461 0
1
0 0 29 7
1
end_operator
begin_operator
up f5 f17
1
462 0
1
0 0 29 8
1
end_operator
begin_operator
up f5 f18
1
463 0
1
0 0 29 9
1
end_operator
begin_operator
up f5 f19
1
464 0
1
0 0 29 10
1
end_operator
begin_operator
up f5 f20
1
465 0
1
0 0 29 12
1
end_operator
begin_operator
up f5 f21
1
466 0
1
0 0 29 13
1
end_operator
begin_operator
up f5 f22
1
467 0
1
0 0 29 14
1
end_operator
begin_operator
up f5 f23
1
468 0
1
0 0 29 15
1
end_operator
begin_operator
up f5 f24
1
469 0
1
0 0 29 16
1
end_operator
begin_operator
up f5 f25
1
470 0
1
0 0 29 17
1
end_operator
begin_operator
up f5 f26
1
471 0
1
0 0 29 18
1
end_operator
begin_operator
up f5 f27
1
472 0
1
0 0 29 19
1
end_operator
begin_operator
up f5 f28
1
473 0
1
0 0 29 20
1
end_operator
begin_operator
up f5 f29
1
474 0
1
0 0 29 21
1
end_operator
begin_operator
up f5 f30
1
475 0
1
0 0 29 23
1
end_operator
begin_operator
up f5 f31
1
476 0
1
0 0 29 24
1
end_operator
begin_operator
up f5 f32
1
477 0
1
0 0 29 25
1
end_operator
begin_operator
up f5 f33
1
478 0
1
0 0 29 26
1
end_operator
begin_operator
up f5 f34
1
479 0
1
0 0 29 27
1
end_operator
begin_operator
up f5 f6
1
480 0
1
0 0 29 30
1
end_operator
begin_operator
up f5 f7
1
481 0
1
0 0 29 31
1
end_operator
begin_operator
up f5 f8
1
482 0
1
0 0 29 32
1
end_operator
begin_operator
up f5 f9
1
483 0
1
0 0 29 33
1
end_operator
begin_operator
up f6 f10
1
484 0
1
0 0 30 1
1
end_operator
begin_operator
up f6 f11
1
485 0
1
0 0 30 2
1
end_operator
begin_operator
up f6 f12
1
486 0
1
0 0 30 3
1
end_operator
begin_operator
up f6 f13
1
487 0
1
0 0 30 4
1
end_operator
begin_operator
up f6 f14
1
488 0
1
0 0 30 5
1
end_operator
begin_operator
up f6 f15
1
489 0
1
0 0 30 6
1
end_operator
begin_operator
up f6 f16
1
490 0
1
0 0 30 7
1
end_operator
begin_operator
up f6 f17
1
491 0
1
0 0 30 8
1
end_operator
begin_operator
up f6 f18
1
492 0
1
0 0 30 9
1
end_operator
begin_operator
up f6 f19
1
493 0
1
0 0 30 10
1
end_operator
begin_operator
up f6 f20
1
494 0
1
0 0 30 12
1
end_operator
begin_operator
up f6 f21
1
495 0
1
0 0 30 13
1
end_operator
begin_operator
up f6 f22
1
496 0
1
0 0 30 14
1
end_operator
begin_operator
up f6 f23
1
497 0
1
0 0 30 15
1
end_operator
begin_operator
up f6 f24
1
498 0
1
0 0 30 16
1
end_operator
begin_operator
up f6 f25
1
499 0
1
0 0 30 17
1
end_operator
begin_operator
up f6 f26
1
500 0
1
0 0 30 18
1
end_operator
begin_operator
up f6 f27
1
501 0
1
0 0 30 19
1
end_operator
begin_operator
up f6 f28
1
502 0
1
0 0 30 20
1
end_operator
begin_operator
up f6 f29
1
503 0
1
0 0 30 21
1
end_operator
begin_operator
up f6 f30
1
504 0
1
0 0 30 23
1
end_operator
begin_operator
up f6 f31
1
505 0
1
0 0 30 24
1
end_operator
begin_operator
up f6 f32
1
506 0
1
0 0 30 25
1
end_operator
begin_operator
up f6 f33
1
507 0
1
0 0 30 26
1
end_operator
begin_operator
up f6 f34
1
508 0
1
0 0 30 27
1
end_operator
begin_operator
up f6 f7
1
509 0
1
0 0 30 31
1
end_operator
begin_operator
up f6 f8
1
510 0
1
0 0 30 32
1
end_operator
begin_operator
up f6 f9
1
511 0
1
0 0 30 33
1
end_operator
begin_operator
up f7 f10
1
512 0
1
0 0 31 1
1
end_operator
begin_operator
up f7 f11
1
513 0
1
0 0 31 2
1
end_operator
begin_operator
up f7 f12
1
514 0
1
0 0 31 3
1
end_operator
begin_operator
up f7 f13
1
515 0
1
0 0 31 4
1
end_operator
begin_operator
up f7 f14
1
516 0
1
0 0 31 5
1
end_operator
begin_operator
up f7 f15
1
517 0
1
0 0 31 6
1
end_operator
begin_operator
up f7 f16
1
518 0
1
0 0 31 7
1
end_operator
begin_operator
up f7 f17
1
519 0
1
0 0 31 8
1
end_operator
begin_operator
up f7 f18
1
520 0
1
0 0 31 9
1
end_operator
begin_operator
up f7 f19
1
521 0
1
0 0 31 10
1
end_operator
begin_operator
up f7 f20
1
522 0
1
0 0 31 12
1
end_operator
begin_operator
up f7 f21
1
523 0
1
0 0 31 13
1
end_operator
begin_operator
up f7 f22
1
524 0
1
0 0 31 14
1
end_operator
begin_operator
up f7 f23
1
525 0
1
0 0 31 15
1
end_operator
begin_operator
up f7 f24
1
526 0
1
0 0 31 16
1
end_operator
begin_operator
up f7 f25
1
527 0
1
0 0 31 17
1
end_operator
begin_operator
up f7 f26
1
528 0
1
0 0 31 18
1
end_operator
begin_operator
up f7 f27
1
529 0
1
0 0 31 19
1
end_operator
begin_operator
up f7 f28
1
530 0
1
0 0 31 20
1
end_operator
begin_operator
up f7 f29
1
531 0
1
0 0 31 21
1
end_operator
begin_operator
up f7 f30
1
532 0
1
0 0 31 23
1
end_operator
begin_operator
up f7 f31
1
533 0
1
0 0 31 24
1
end_operator
begin_operator
up f7 f32
1
534 0
1
0 0 31 25
1
end_operator
begin_operator
up f7 f33
1
535 0
1
0 0 31 26
1
end_operator
begin_operator
up f7 f34
1
536 0
1
0 0 31 27
1
end_operator
begin_operator
up f7 f8
1
537 0
1
0 0 31 32
1
end_operator
begin_operator
up f7 f9
1
538 0
1
0 0 31 33
1
end_operator
begin_operator
up f8 f10
1
539 0
1
0 0 32 1
1
end_operator
begin_operator
up f8 f11
1
540 0
1
0 0 32 2
1
end_operator
begin_operator
up f8 f12
1
541 0
1
0 0 32 3
1
end_operator
begin_operator
up f8 f13
1
542 0
1
0 0 32 4
1
end_operator
begin_operator
up f8 f14
1
543 0
1
0 0 32 5
1
end_operator
begin_operator
up f8 f15
1
544 0
1
0 0 32 6
1
end_operator
begin_operator
up f8 f16
1
545 0
1
0 0 32 7
1
end_operator
begin_operator
up f8 f17
1
546 0
1
0 0 32 8
1
end_operator
begin_operator
up f8 f18
1
547 0
1
0 0 32 9
1
end_operator
begin_operator
up f8 f19
1
548 0
1
0 0 32 10
1
end_operator
begin_operator
up f8 f20
1
549 0
1
0 0 32 12
1
end_operator
begin_operator
up f8 f21
1
550 0
1
0 0 32 13
1
end_operator
begin_operator
up f8 f22
1
551 0
1
0 0 32 14
1
end_operator
begin_operator
up f8 f23
1
552 0
1
0 0 32 15
1
end_operator
begin_operator
up f8 f24
1
553 0
1
0 0 32 16
1
end_operator
begin_operator
up f8 f25
1
554 0
1
0 0 32 17
1
end_operator
begin_operator
up f8 f26
1
555 0
1
0 0 32 18
1
end_operator
begin_operator
up f8 f27
1
556 0
1
0 0 32 19
1
end_operator
begin_operator
up f8 f28
1
557 0
1
0 0 32 20
1
end_operator
begin_operator
up f8 f29
1
558 0
1
0 0 32 21
1
end_operator
begin_operator
up f8 f30
1
559 0
1
0 0 32 23
1
end_operator
begin_operator
up f8 f31
1
560 0
1
0 0 32 24
1
end_operator
begin_operator
up f8 f32
1
561 0
1
0 0 32 25
1
end_operator
begin_operator
up f8 f33
1
562 0
1
0 0 32 26
1
end_operator
begin_operator
up f8 f34
1
563 0
1
0 0 32 27
1
end_operator
begin_operator
up f8 f9
1
564 0
1
0 0 32 33
1
end_operator
begin_operator
up f9 f10
1
565 0
1
0 0 33 1
1
end_operator
begin_operator
up f9 f11
1
566 0
1
0 0 33 2
1
end_operator
begin_operator
up f9 f12
1
567 0
1
0 0 33 3
1
end_operator
begin_operator
up f9 f13
1
568 0
1
0 0 33 4
1
end_operator
begin_operator
up f9 f14
1
569 0
1
0 0 33 5
1
end_operator
begin_operator
up f9 f15
1
570 0
1
0 0 33 6
1
end_operator
begin_operator
up f9 f16
1
571 0
1
0 0 33 7
1
end_operator
begin_operator
up f9 f17
1
572 0
1
0 0 33 8
1
end_operator
begin_operator
up f9 f18
1
573 0
1
0 0 33 9
1
end_operator
begin_operator
up f9 f19
1
574 0
1
0 0 33 10
1
end_operator
begin_operator
up f9 f20
1
575 0
1
0 0 33 12
1
end_operator
begin_operator
up f9 f21
1
576 0
1
0 0 33 13
1
end_operator
begin_operator
up f9 f22
1
577 0
1
0 0 33 14
1
end_operator
begin_operator
up f9 f23
1
578 0
1
0 0 33 15
1
end_operator
begin_operator
up f9 f24
1
579 0
1
0 0 33 16
1
end_operator
begin_operator
up f9 f25
1
580 0
1
0 0 33 17
1
end_operator
begin_operator
up f9 f26
1
581 0
1
0 0 33 18
1
end_operator
begin_operator
up f9 f27
1
582 0
1
0 0 33 19
1
end_operator
begin_operator
up f9 f28
1
583 0
1
0 0 33 20
1
end_operator
begin_operator
up f9 f29
1
584 0
1
0 0 33 21
1
end_operator
begin_operator
up f9 f30
1
585 0
1
0 0 33 23
1
end_operator
begin_operator
up f9 f31
1
586 0
1
0 0 33 24
1
end_operator
begin_operator
up f9 f32
1
587 0
1
0 0 33 25
1
end_operator
begin_operator
up f9 f33
1
588 0
1
0 0 33 26
1
end_operator
begin_operator
up f9 f34
1
589 0
1
0 0 33 27
1
end_operator
0
