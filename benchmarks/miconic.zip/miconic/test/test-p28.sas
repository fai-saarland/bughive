begin_version
3
end_version
begin_metric
1
end_metric
192
begin_variable
var0
-1
19
lift-at f1
lift-at f10
lift-at f11
lift-at f12
lift-at f13
lift-at f14
lift-at f15
lift-at f16
lift-at f17
lift-at f18
lift-at f19
lift-at f2
lift-at f3
lift-at f4
lift-at f5
lift-at f6
lift-at f7
lift-at f8
lift-at f9
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f3
served p1
end_variable
begin_variable
var2
-1
3
boarded p10
origin p10 f15
served p10
end_variable
begin_variable
var3
-1
3
boarded p2
origin p2 f4
served p2
end_variable
begin_variable
var4
-1
3
boarded p3
origin p3 f3
served p3
end_variable
begin_variable
var5
-1
3
boarded p4
origin p4 f13
served p4
end_variable
begin_variable
var6
-1
3
boarded p5
origin p5 f6
served p5
end_variable
begin_variable
var7
-1
3
boarded p6
origin p6 f11
served p6
end_variable
begin_variable
var8
-1
3
boarded p7
origin p7 f6
served p7
end_variable
begin_variable
var9
-1
3
boarded p8
origin p8 f10
served p8
end_variable
begin_variable
var10
-1
3
boarded p9
origin p9 f8
served p9
end_variable
begin_variable
var11
-1
2
above f1 f10
none-of-those
end_variable
begin_variable
var12
-1
2
above f1 f11
none-of-those
end_variable
begin_variable
var13
-1
2
above f1 f12
none-of-those
end_variable
begin_variable
var14
-1
2
above f1 f13
none-of-those
end_variable
begin_variable
var15
-1
2
above f1 f14
none-of-those
end_variable
begin_variable
var16
-1
2
above f1 f15
none-of-those
end_variable
begin_variable
var17
-1
2
above f1 f16
none-of-those
end_variable
begin_variable
var18
-1
2
above f1 f17
none-of-those
end_variable
begin_variable
var19
-1
2
above f1 f18
none-of-those
end_variable
begin_variable
var20
-1
2
above f1 f19
none-of-those
end_variable
begin_variable
var21
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var22
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var23
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var24
-1
2
above f1 f5
none-of-those
end_variable
begin_variable
var25
-1
2
above f1 f6
none-of-those
end_variable
begin_variable
var26
-1
2
above f1 f7
none-of-those
end_variable
begin_variable
var27
-1
2
above f1 f8
none-of-those
end_variable
begin_variable
var28
-1
2
above f1 f9
none-of-those
end_variable
begin_variable
var29
-1
2
above f10 f11
none-of-those
end_variable
begin_variable
var30
-1
2
above f10 f12
none-of-those
end_variable
begin_variable
var31
-1
2
above f10 f13
none-of-those
end_variable
begin_variable
var32
-1
2
above f10 f14
none-of-those
end_variable
begin_variable
var33
-1
2
above f10 f15
none-of-those
end_variable
begin_variable
var34
-1
2
above f10 f16
none-of-those
end_variable
begin_variable
var35
-1
2
above f10 f17
none-of-those
end_variable
begin_variable
var36
-1
2
above f10 f18
none-of-those
end_variable
begin_variable
var37
-1
2
above f10 f19
none-of-those
end_variable
begin_variable
var38
-1
2
above f11 f12
none-of-those
end_variable
begin_variable
var39
-1
2
above f11 f13
none-of-those
end_variable
begin_variable
var40
-1
2
above f11 f14
none-of-those
end_variable
begin_variable
var41
-1
2
above f11 f15
none-of-those
end_variable
begin_variable
var42
-1
2
above f11 f16
none-of-those
end_variable
begin_variable
var43
-1
2
above f11 f17
none-of-those
end_variable
begin_variable
var44
-1
2
above f11 f18
none-of-those
end_variable
begin_variable
var45
-1
2
above f11 f19
none-of-those
end_variable
begin_variable
var46
-1
2
above f12 f13
none-of-those
end_variable
begin_variable
var47
-1
2
above f12 f14
none-of-those
end_variable
begin_variable
var48
-1
2
above f12 f15
none-of-those
end_variable
begin_variable
var49
-1
2
above f12 f16
none-of-those
end_variable
begin_variable
var50
-1
2
above f12 f17
none-of-those
end_variable
begin_variable
var51
-1
2
above f12 f18
none-of-those
end_variable
begin_variable
var52
-1
2
above f12 f19
none-of-those
end_variable
begin_variable
var53
-1
2
above f13 f14
none-of-those
end_variable
begin_variable
var54
-1
2
above f13 f15
none-of-those
end_variable
begin_variable
var55
-1
2
above f13 f16
none-of-those
end_variable
begin_variable
var56
-1
2
above f13 f17
none-of-those
end_variable
begin_variable
var57
-1
2
above f13 f18
none-of-those
end_variable
begin_variable
var58
-1
2
above f13 f19
none-of-those
end_variable
begin_variable
var59
-1
2
above f14 f15
none-of-those
end_variable
begin_variable
var60
-1
2
above f14 f16
none-of-those
end_variable
begin_variable
var61
-1
2
above f14 f17
none-of-those
end_variable
begin_variable
var62
-1
2
above f14 f18
none-of-those
end_variable
begin_variable
var63
-1
2
above f14 f19
none-of-those
end_variable
begin_variable
var64
-1
2
above f15 f16
none-of-those
end_variable
begin_variable
var65
-1
2
above f15 f17
none-of-those
end_variable
begin_variable
var66
-1
2
above f15 f18
none-of-those
end_variable
begin_variable
var67
-1
2
above f15 f19
none-of-those
end_variable
begin_variable
var68
-1
2
above f16 f17
none-of-those
end_variable
begin_variable
var69
-1
2
above f16 f18
none-of-those
end_variable
begin_variable
var70
-1
2
above f16 f19
none-of-those
end_variable
begin_variable
var71
-1
2
above f17 f18
none-of-those
end_variable
begin_variable
var72
-1
2
above f17 f19
none-of-those
end_variable
begin_variable
var73
-1
2
above f18 f19
none-of-those
end_variable
begin_variable
var74
-1
2
above f2 f10
none-of-those
end_variable
begin_variable
var75
-1
2
above f2 f11
none-of-those
end_variable
begin_variable
var76
-1
2
above f2 f12
none-of-those
end_variable
begin_variable
var77
-1
2
above f2 f13
none-of-those
end_variable
begin_variable
var78
-1
2
above f2 f14
none-of-those
end_variable
begin_variable
var79
-1
2
above f2 f15
none-of-those
end_variable
begin_variable
var80
-1
2
above f2 f16
none-of-those
end_variable
begin_variable
var81
-1
2
above f2 f17
none-of-those
end_variable
begin_variable
var82
-1
2
above f2 f18
none-of-those
end_variable
begin_variable
var83
-1
2
above f2 f19
none-of-those
end_variable
begin_variable
var84
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var85
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var86
-1
2
above f2 f5
none-of-those
end_variable
begin_variable
var87
-1
2
above f2 f6
none-of-those
end_variable
begin_variable
var88
-1
2
above f2 f7
none-of-those
end_variable
begin_variable
var89
-1
2
above f2 f8
none-of-those
end_variable
begin_variable
var90
-1
2
above f2 f9
none-of-those
end_variable
begin_variable
var91
-1
2
above f3 f10
none-of-those
end_variable
begin_variable
var92
-1
2
above f3 f11
none-of-those
end_variable
begin_variable
var93
-1
2
above f3 f12
none-of-those
end_variable
begin_variable
var94
-1
2
above f3 f13
none-of-those
end_variable
begin_variable
var95
-1
2
above f3 f14
none-of-those
end_variable
begin_variable
var96
-1
2
above f3 f15
none-of-those
end_variable
begin_variable
var97
-1
2
above f3 f16
none-of-those
end_variable
begin_variable
var98
-1
2
above f3 f17
none-of-those
end_variable
begin_variable
var99
-1
2
above f3 f18
none-of-those
end_variable
begin_variable
var100
-1
2
above f3 f19
none-of-those
end_variable
begin_variable
var101
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var102
-1
2
above f3 f5
none-of-those
end_variable
begin_variable
var103
-1
2
above f3 f6
none-of-those
end_variable
begin_variable
var104
-1
2
above f3 f7
none-of-those
end_variable
begin_variable
var105
-1
2
above f3 f8
none-of-those
end_variable
begin_variable
var106
-1
2
above f3 f9
none-of-those
end_variable
begin_variable
var107
-1
2
above f4 f10
none-of-those
end_variable
begin_variable
var108
-1
2
above f4 f11
none-of-those
end_variable
begin_variable
var109
-1
2
above f4 f12
none-of-those
end_variable
begin_variable
var110
-1
2
above f4 f13
none-of-those
end_variable
begin_variable
var111
-1
2
above f4 f14
none-of-those
end_variable
begin_variable
var112
-1
2
above f4 f15
none-of-those
end_variable
begin_variable
var113
-1
2
above f4 f16
none-of-those
end_variable
begin_variable
var114
-1
2
above f4 f17
none-of-those
end_variable
begin_variable
var115
-1
2
above f4 f18
none-of-those
end_variable
begin_variable
var116
-1
2
above f4 f19
none-of-those
end_variable
begin_variable
var117
-1
2
above f4 f5
none-of-those
end_variable
begin_variable
var118
-1
2
above f4 f6
none-of-those
end_variable
begin_variable
var119
-1
2
above f4 f7
none-of-those
end_variable
begin_variable
var120
-1
2
above f4 f8
none-of-those
end_variable
begin_variable
var121
-1
2
above f4 f9
none-of-those
end_variable
begin_variable
var122
-1
2
above f5 f10
none-of-those
end_variable
begin_variable
var123
-1
2
above f5 f11
none-of-those
end_variable
begin_variable
var124
-1
2
above f5 f12
none-of-those
end_variable
begin_variable
var125
-1
2
above f5 f13
none-of-those
end_variable
begin_variable
var126
-1
2
above f5 f14
none-of-those
end_variable
begin_variable
var127
-1
2
above f5 f15
none-of-those
end_variable
begin_variable
var128
-1
2
above f5 f16
none-of-those
end_variable
begin_variable
var129
-1
2
above f5 f17
none-of-those
end_variable
begin_variable
var130
-1
2
above f5 f18
none-of-those
end_variable
begin_variable
var131
-1
2
above f5 f19
none-of-those
end_variable
begin_variable
var132
-1
2
above f5 f6
none-of-those
end_variable
begin_variable
var133
-1
2
above f5 f7
none-of-those
end_variable
begin_variable
var134
-1
2
above f5 f8
none-of-those
end_variable
begin_variable
var135
-1
2
above f5 f9
none-of-those
end_variable
begin_variable
var136
-1
2
above f6 f10
none-of-those
end_variable
begin_variable
var137
-1
2
above f6 f11
none-of-those
end_variable
begin_variable
var138
-1
2
above f6 f12
none-of-those
end_variable
begin_variable
var139
-1
2
above f6 f13
none-of-those
end_variable
begin_variable
var140
-1
2
above f6 f14
none-of-those
end_variable
begin_variable
var141
-1
2
above f6 f15
none-of-those
end_variable
begin_variable
var142
-1
2
above f6 f16
none-of-those
end_variable
begin_variable
var143
-1
2
above f6 f17
none-of-those
end_variable
begin_variable
var144
-1
2
above f6 f18
none-of-those
end_variable
begin_variable
var145
-1
2
above f6 f19
none-of-those
end_variable
begin_variable
var146
-1
2
above f6 f7
none-of-those
end_variable
begin_variable
var147
-1
2
above f6 f8
none-of-those
end_variable
begin_variable
var148
-1
2
above f6 f9
none-of-those
end_variable
begin_variable
var149
-1
2
above f7 f10
none-of-those
end_variable
begin_variable
var150
-1
2
above f7 f11
none-of-those
end_variable
begin_variable
var151
-1
2
above f7 f12
none-of-those
end_variable
begin_variable
var152
-1
2
above f7 f13
none-of-those
end_variable
begin_variable
var153
-1
2
above f7 f14
none-of-those
end_variable
begin_variable
var154
-1
2
above f7 f15
none-of-those
end_variable
begin_variable
var155
-1
2
above f7 f16
none-of-those
end_variable
begin_variable
var156
-1
2
above f7 f17
none-of-those
end_variable
begin_variable
var157
-1
2
above f7 f18
none-of-those
end_variable
begin_variable
var158
-1
2
above f7 f19
none-of-those
end_variable
begin_variable
var159
-1
2
above f7 f8
none-of-those
end_variable
begin_variable
var160
-1
2
above f7 f9
none-of-those
end_variable
begin_variable
var161
-1
2
above f8 f10
none-of-those
end_variable
begin_variable
var162
-1
2
above f8 f11
none-of-those
end_variable
begin_variable
var163
-1
2
above f8 f12
none-of-those
end_variable
begin_variable
var164
-1
2
above f8 f13
none-of-those
end_variable
begin_variable
var165
-1
2
above f8 f14
none-of-those
end_variable
begin_variable
var166
-1
2
above f8 f15
none-of-those
end_variable
begin_variable
var167
-1
2
above f8 f16
none-of-those
end_variable
begin_variable
var168
-1
2
above f8 f17
none-of-those
end_variable
begin_variable
var169
-1
2
above f8 f18
none-of-those
end_variable
begin_variable
var170
-1
2
above f8 f19
none-of-those
end_variable
begin_variable
var171
-1
2
above f8 f9
none-of-those
end_variable
begin_variable
var172
-1
2
above f9 f10
none-of-those
end_variable
begin_variable
var173
-1
2
above f9 f11
none-of-those
end_variable
begin_variable
var174
-1
2
above f9 f12
none-of-those
end_variable
begin_variable
var175
-1
2
above f9 f13
none-of-those
end_variable
begin_variable
var176
-1
2
above f9 f14
none-of-those
end_variable
begin_variable
var177
-1
2
above f9 f15
none-of-those
end_variable
begin_variable
var178
-1
2
above f9 f16
none-of-those
end_variable
begin_variable
var179
-1
2
above f9 f17
none-of-those
end_variable
begin_variable
var180
-1
2
above f9 f18
none-of-those
end_variable
begin_variable
var181
-1
2
above f9 f19
none-of-those
end_variable
begin_variable
var182
-1
2
destin p1 f4
none-of-those
end_variable
begin_variable
var183
-1
2
destin p10 f5
none-of-those
end_variable
begin_variable
var184
-1
2
destin p2 f14
none-of-those
end_variable
begin_variable
var185
-1
2
destin p3 f9
none-of-those
end_variable
begin_variable
var186
-1
2
destin p4 f8
none-of-those
end_variable
begin_variable
var187
-1
2
destin p5 f13
none-of-those
end_variable
begin_variable
var188
-1
2
destin p6 f1
none-of-those
end_variable
begin_variable
var189
-1
2
destin p7 f2
none-of-those
end_variable
begin_variable
var190
-1
2
destin p8 f16
none-of-those
end_variable
begin_variable
var191
-1
2
destin p9 f17
none-of-those
end_variable
0
begin_state
11
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
10
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
end_goal
362
begin_operator
board f10 p8
1
0 1
1
0 9 1 0
1
end_operator
begin_operator
board f11 p6
1
0 2
1
0 7 1 0
1
end_operator
begin_operator
board f13 p4
1
0 4
1
0 5 1 0
1
end_operator
begin_operator
board f15 p10
1
0 6
1
0 2 1 0
1
end_operator
begin_operator
board f3 p1
1
0 12
1
0 1 1 0
1
end_operator
begin_operator
board f3 p3
1
0 12
1
0 4 1 0
1
end_operator
begin_operator
board f4 p2
1
0 13
1
0 3 1 0
1
end_operator
begin_operator
board f6 p5
1
0 15
1
0 6 1 0
1
end_operator
begin_operator
board f6 p7
1
0 15
1
0 8 1 0
1
end_operator
begin_operator
board f8 p9
1
0 17
1
0 10 1 0
1
end_operator
begin_operator
depart f1 p6
2
0 0
188 0
1
0 7 0 2
1
end_operator
begin_operator
depart f13 p5
2
0 4
187 0
1
0 6 0 2
1
end_operator
begin_operator
depart f14 p2
2
0 5
184 0
1
0 3 0 2
1
end_operator
begin_operator
depart f16 p8
2
0 7
190 0
1
0 9 0 2
1
end_operator
begin_operator
depart f17 p9
2
0 8
191 0
1
0 10 0 2
1
end_operator
begin_operator
depart f2 p7
2
0 11
189 0
1
0 8 0 2
1
end_operator
begin_operator
depart f4 p1
2
0 13
182 0
1
0 1 0 2
1
end_operator
begin_operator
depart f5 p10
2
0 14
183 0
1
0 2 0 2
1
end_operator
begin_operator
depart f8 p4
2
0 17
186 0
1
0 5 0 2
1
end_operator
begin_operator
depart f9 p3
2
0 18
185 0
1
0 4 0 2
1
end_operator
begin_operator
down f10 f1
1
11 0
1
0 0 1 0
1
end_operator
begin_operator
down f10 f2
1
74 0
1
0 0 1 11
1
end_operator
begin_operator
down f10 f3
1
91 0
1
0 0 1 12
1
end_operator
begin_operator
down f10 f4
1
107 0
1
0 0 1 13
1
end_operator
begin_operator
down f10 f5
1
122 0
1
0 0 1 14
1
end_operator
begin_operator
down f10 f6
1
136 0
1
0 0 1 15
1
end_operator
begin_operator
down f10 f7
1
149 0
1
0 0 1 16
1
end_operator
begin_operator
down f10 f8
1
161 0
1
0 0 1 17
1
end_operator
begin_operator
down f10 f9
1
172 0
1
0 0 1 18
1
end_operator
begin_operator
down f11 f1
1
12 0
1
0 0 2 0
1
end_operator
begin_operator
down f11 f10
1
29 0
1
0 0 2 1
1
end_operator
begin_operator
down f11 f2
1
75 0
1
0 0 2 11
1
end_operator
begin_operator
down f11 f3
1
92 0
1
0 0 2 12
1
end_operator
begin_operator
down f11 f4
1
108 0
1
0 0 2 13
1
end_operator
begin_operator
down f11 f5
1
123 0
1
0 0 2 14
1
end_operator
begin_operator
down f11 f6
1
137 0
1
0 0 2 15
1
end_operator
begin_operator
down f11 f7
1
150 0
1
0 0 2 16
1
end_operator
begin_operator
down f11 f8
1
162 0
1
0 0 2 17
1
end_operator
begin_operator
down f11 f9
1
173 0
1
0 0 2 18
1
end_operator
begin_operator
down f12 f1
1
13 0
1
0 0 3 0
1
end_operator
begin_operator
down f12 f10
1
30 0
1
0 0 3 1
1
end_operator
begin_operator
down f12 f11
1
38 0
1
0 0 3 2
1
end_operator
begin_operator
down f12 f2
1
76 0
1
0 0 3 11
1
end_operator
begin_operator
down f12 f3
1
93 0
1
0 0 3 12
1
end_operator
begin_operator
down f12 f4
1
109 0
1
0 0 3 13
1
end_operator
begin_operator
down f12 f5
1
124 0
1
0 0 3 14
1
end_operator
begin_operator
down f12 f6
1
138 0
1
0 0 3 15
1
end_operator
begin_operator
down f12 f7
1
151 0
1
0 0 3 16
1
end_operator
begin_operator
down f12 f8
1
163 0
1
0 0 3 17
1
end_operator
begin_operator
down f12 f9
1
174 0
1
0 0 3 18
1
end_operator
begin_operator
down f13 f1
1
14 0
1
0 0 4 0
1
end_operator
begin_operator
down f13 f10
1
31 0
1
0 0 4 1
1
end_operator
begin_operator
down f13 f11
1
39 0
1
0 0 4 2
1
end_operator
begin_operator
down f13 f12
1
46 0
1
0 0 4 3
1
end_operator
begin_operator
down f13 f2
1
77 0
1
0 0 4 11
1
end_operator
begin_operator
down f13 f3
1
94 0
1
0 0 4 12
1
end_operator
begin_operator
down f13 f4
1
110 0
1
0 0 4 13
1
end_operator
begin_operator
down f13 f5
1
125 0
1
0 0 4 14
1
end_operator
begin_operator
down f13 f6
1
139 0
1
0 0 4 15
1
end_operator
begin_operator
down f13 f7
1
152 0
1
0 0 4 16
1
end_operator
begin_operator
down f13 f8
1
164 0
1
0 0 4 17
1
end_operator
begin_operator
down f13 f9
1
175 0
1
0 0 4 18
1
end_operator
begin_operator
down f14 f1
1
15 0
1
0 0 5 0
1
end_operator
begin_operator
down f14 f10
1
32 0
1
0 0 5 1
1
end_operator
begin_operator
down f14 f11
1
40 0
1
0 0 5 2
1
end_operator
begin_operator
down f14 f12
1
47 0
1
0 0 5 3
1
end_operator
begin_operator
down f14 f13
1
53 0
1
0 0 5 4
1
end_operator
begin_operator
down f14 f2
1
78 0
1
0 0 5 11
1
end_operator
begin_operator
down f14 f3
1
95 0
1
0 0 5 12
1
end_operator
begin_operator
down f14 f4
1
111 0
1
0 0 5 13
1
end_operator
begin_operator
down f14 f5
1
126 0
1
0 0 5 14
1
end_operator
begin_operator
down f14 f6
1
140 0
1
0 0 5 15
1
end_operator
begin_operator
down f14 f7
1
153 0
1
0 0 5 16
1
end_operator
begin_operator
down f14 f8
1
165 0
1
0 0 5 17
1
end_operator
begin_operator
down f14 f9
1
176 0
1
0 0 5 18
1
end_operator
begin_operator
down f15 f1
1
16 0
1
0 0 6 0
1
end_operator
begin_operator
down f15 f10
1
33 0
1
0 0 6 1
1
end_operator
begin_operator
down f15 f11
1
41 0
1
0 0 6 2
1
end_operator
begin_operator
down f15 f12
1
48 0
1
0 0 6 3
1
end_operator
begin_operator
down f15 f13
1
54 0
1
0 0 6 4
1
end_operator
begin_operator
down f15 f14
1
59 0
1
0 0 6 5
1
end_operator
begin_operator
down f15 f2
1
79 0
1
0 0 6 11
1
end_operator
begin_operator
down f15 f3
1
96 0
1
0 0 6 12
1
end_operator
begin_operator
down f15 f4
1
112 0
1
0 0 6 13
1
end_operator
begin_operator
down f15 f5
1
127 0
1
0 0 6 14
1
end_operator
begin_operator
down f15 f6
1
141 0
1
0 0 6 15
1
end_operator
begin_operator
down f15 f7
1
154 0
1
0 0 6 16
1
end_operator
begin_operator
down f15 f8
1
166 0
1
0 0 6 17
1
end_operator
begin_operator
down f15 f9
1
177 0
1
0 0 6 18
1
end_operator
begin_operator
down f16 f1
1
17 0
1
0 0 7 0
1
end_operator
begin_operator
down f16 f10
1
34 0
1
0 0 7 1
1
end_operator
begin_operator
down f16 f11
1
42 0
1
0 0 7 2
1
end_operator
begin_operator
down f16 f12
1
49 0
1
0 0 7 3
1
end_operator
begin_operator
down f16 f13
1
55 0
1
0 0 7 4
1
end_operator
begin_operator
down f16 f14
1
60 0
1
0 0 7 5
1
end_operator
begin_operator
down f16 f15
1
64 0
1
0 0 7 6
1
end_operator
begin_operator
down f16 f2
1
80 0
1
0 0 7 11
1
end_operator
begin_operator
down f16 f3
1
97 0
1
0 0 7 12
1
end_operator
begin_operator
down f16 f4
1
113 0
1
0 0 7 13
1
end_operator
begin_operator
down f16 f5
1
128 0
1
0 0 7 14
1
end_operator
begin_operator
down f16 f6
1
142 0
1
0 0 7 15
1
end_operator
begin_operator
down f16 f7
1
155 0
1
0 0 7 16
1
end_operator
begin_operator
down f16 f8
1
167 0
1
0 0 7 17
1
end_operator
begin_operator
down f16 f9
1
178 0
1
0 0 7 18
1
end_operator
begin_operator
down f17 f1
1
18 0
1
0 0 8 0
1
end_operator
begin_operator
down f17 f10
1
35 0
1
0 0 8 1
1
end_operator
begin_operator
down f17 f11
1
43 0
1
0 0 8 2
1
end_operator
begin_operator
down f17 f12
1
50 0
1
0 0 8 3
1
end_operator
begin_operator
down f17 f13
1
56 0
1
0 0 8 4
1
end_operator
begin_operator
down f17 f14
1
61 0
1
0 0 8 5
1
end_operator
begin_operator
down f17 f15
1
65 0
1
0 0 8 6
1
end_operator
begin_operator
down f17 f16
1
68 0
1
0 0 8 7
1
end_operator
begin_operator
down f17 f2
1
81 0
1
0 0 8 11
1
end_operator
begin_operator
down f17 f3
1
98 0
1
0 0 8 12
1
end_operator
begin_operator
down f17 f4
1
114 0
1
0 0 8 13
1
end_operator
begin_operator
down f17 f5
1
129 0
1
0 0 8 14
1
end_operator
begin_operator
down f17 f6
1
143 0
1
0 0 8 15
1
end_operator
begin_operator
down f17 f7
1
156 0
1
0 0 8 16
1
end_operator
begin_operator
down f17 f8
1
168 0
1
0 0 8 17
1
end_operator
begin_operator
down f17 f9
1
179 0
1
0 0 8 18
1
end_operator
begin_operator
down f18 f1
1
19 0
1
0 0 9 0
1
end_operator
begin_operator
down f18 f10
1
36 0
1
0 0 9 1
1
end_operator
begin_operator
down f18 f11
1
44 0
1
0 0 9 2
1
end_operator
begin_operator
down f18 f12
1
51 0
1
0 0 9 3
1
end_operator
begin_operator
down f18 f13
1
57 0
1
0 0 9 4
1
end_operator
begin_operator
down f18 f14
1
62 0
1
0 0 9 5
1
end_operator
begin_operator
down f18 f15
1
66 0
1
0 0 9 6
1
end_operator
begin_operator
down f18 f16
1
69 0
1
0 0 9 7
1
end_operator
begin_operator
down f18 f17
1
71 0
1
0 0 9 8
1
end_operator
begin_operator
down f18 f2
1
82 0
1
0 0 9 11
1
end_operator
begin_operator
down f18 f3
1
99 0
1
0 0 9 12
1
end_operator
begin_operator
down f18 f4
1
115 0
1
0 0 9 13
1
end_operator
begin_operator
down f18 f5
1
130 0
1
0 0 9 14
1
end_operator
begin_operator
down f18 f6
1
144 0
1
0 0 9 15
1
end_operator
begin_operator
down f18 f7
1
157 0
1
0 0 9 16
1
end_operator
begin_operator
down f18 f8
1
169 0
1
0 0 9 17
1
end_operator
begin_operator
down f18 f9
1
180 0
1
0 0 9 18
1
end_operator
begin_operator
down f19 f1
1
20 0
1
0 0 10 0
1
end_operator
begin_operator
down f19 f10
1
37 0
1
0 0 10 1
1
end_operator
begin_operator
down f19 f11
1
45 0
1
0 0 10 2
1
end_operator
begin_operator
down f19 f12
1
52 0
1
0 0 10 3
1
end_operator
begin_operator
down f19 f13
1
58 0
1
0 0 10 4
1
end_operator
begin_operator
down f19 f14
1
63 0
1
0 0 10 5
1
end_operator
begin_operator
down f19 f15
1
67 0
1
0 0 10 6
1
end_operator
begin_operator
down f19 f16
1
70 0
1
0 0 10 7
1
end_operator
begin_operator
down f19 f17
1
72 0
1
0 0 10 8
1
end_operator
begin_operator
down f19 f18
1
73 0
1
0 0 10 9
1
end_operator
begin_operator
down f19 f2
1
83 0
1
0 0 10 11
1
end_operator
begin_operator
down f19 f3
1
100 0
1
0 0 10 12
1
end_operator
begin_operator
down f19 f4
1
116 0
1
0 0 10 13
1
end_operator
begin_operator
down f19 f5
1
131 0
1
0 0 10 14
1
end_operator
begin_operator
down f19 f6
1
145 0
1
0 0 10 15
1
end_operator
begin_operator
down f19 f7
1
158 0
1
0 0 10 16
1
end_operator
begin_operator
down f19 f8
1
170 0
1
0 0 10 17
1
end_operator
begin_operator
down f19 f9
1
181 0
1
0 0 10 18
1
end_operator
begin_operator
down f2 f1
1
21 0
1
0 0 11 0
1
end_operator
begin_operator
down f3 f1
1
22 0
1
0 0 12 0
1
end_operator
begin_operator
down f3 f2
1
84 0
1
0 0 12 11
1
end_operator
begin_operator
down f4 f1
1
23 0
1
0 0 13 0
1
end_operator
begin_operator
down f4 f2
1
85 0
1
0 0 13 11
1
end_operator
begin_operator
down f4 f3
1
101 0
1
0 0 13 12
1
end_operator
begin_operator
down f5 f1
1
24 0
1
0 0 14 0
1
end_operator
begin_operator
down f5 f2
1
86 0
1
0 0 14 11
1
end_operator
begin_operator
down f5 f3
1
102 0
1
0 0 14 12
1
end_operator
begin_operator
down f5 f4
1
117 0
1
0 0 14 13
1
end_operator
begin_operator
down f6 f1
1
25 0
1
0 0 15 0
1
end_operator
begin_operator
down f6 f2
1
87 0
1
0 0 15 11
1
end_operator
begin_operator
down f6 f3
1
103 0
1
0 0 15 12
1
end_operator
begin_operator
down f6 f4
1
118 0
1
0 0 15 13
1
end_operator
begin_operator
down f6 f5
1
132 0
1
0 0 15 14
1
end_operator
begin_operator
down f7 f1
1
26 0
1
0 0 16 0
1
end_operator
begin_operator
down f7 f2
1
88 0
1
0 0 16 11
1
end_operator
begin_operator
down f7 f3
1
104 0
1
0 0 16 12
1
end_operator
begin_operator
down f7 f4
1
119 0
1
0 0 16 13
1
end_operator
begin_operator
down f7 f5
1
133 0
1
0 0 16 14
1
end_operator
begin_operator
down f7 f6
1
146 0
1
0 0 16 15
1
end_operator
begin_operator
down f8 f1
1
27 0
1
0 0 17 0
1
end_operator
begin_operator
down f8 f2
1
89 0
1
0 0 17 11
1
end_operator
begin_operator
down f8 f3
1
105 0
1
0 0 17 12
1
end_operator
begin_operator
down f8 f4
1
120 0
1
0 0 17 13
1
end_operator
begin_operator
down f8 f5
1
134 0
1
0 0 17 14
1
end_operator
begin_operator
down f8 f6
1
147 0
1
0 0 17 15
1
end_operator
begin_operator
down f8 f7
1
159 0
1
0 0 17 16
1
end_operator
begin_operator
down f9 f1
1
28 0
1
0 0 18 0
1
end_operator
begin_operator
down f9 f2
1
90 0
1
0 0 18 11
1
end_operator
begin_operator
down f9 f3
1
106 0
1
0 0 18 12
1
end_operator
begin_operator
down f9 f4
1
121 0
1
0 0 18 13
1
end_operator
begin_operator
down f9 f5
1
135 0
1
0 0 18 14
1
end_operator
begin_operator
down f9 f6
1
148 0
1
0 0 18 15
1
end_operator
begin_operator
down f9 f7
1
160 0
1
0 0 18 16
1
end_operator
begin_operator
down f9 f8
1
171 0
1
0 0 18 17
1
end_operator
begin_operator
up f1 f10
1
11 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f11
1
12 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f12
1
13 0
1
0 0 0 3
1
end_operator
begin_operator
up f1 f13
1
14 0
1
0 0 0 4
1
end_operator
begin_operator
up f1 f14
1
15 0
1
0 0 0 5
1
end_operator
begin_operator
up f1 f15
1
16 0
1
0 0 0 6
1
end_operator
begin_operator
up f1 f16
1
17 0
1
0 0 0 7
1
end_operator
begin_operator
up f1 f17
1
18 0
1
0 0 0 8
1
end_operator
begin_operator
up f1 f18
1
19 0
1
0 0 0 9
1
end_operator
begin_operator
up f1 f19
1
20 0
1
0 0 0 10
1
end_operator
begin_operator
up f1 f2
1
21 0
1
0 0 0 11
1
end_operator
begin_operator
up f1 f3
1
22 0
1
0 0 0 12
1
end_operator
begin_operator
up f1 f4
1
23 0
1
0 0 0 13
1
end_operator
begin_operator
up f1 f5
1
24 0
1
0 0 0 14
1
end_operator
begin_operator
up f1 f6
1
25 0
1
0 0 0 15
1
end_operator
begin_operator
up f1 f7
1
26 0
1
0 0 0 16
1
end_operator
begin_operator
up f1 f8
1
27 0
1
0 0 0 17
1
end_operator
begin_operator
up f1 f9
1
28 0
1
0 0 0 18
1
end_operator
begin_operator
up f10 f11
1
29 0
1
0 0 1 2
1
end_operator
begin_operator
up f10 f12
1
30 0
1
0 0 1 3
1
end_operator
begin_operator
up f10 f13
1
31 0
1
0 0 1 4
1
end_operator
begin_operator
up f10 f14
1
32 0
1
0 0 1 5
1
end_operator
begin_operator
up f10 f15
1
33 0
1
0 0 1 6
1
end_operator
begin_operator
up f10 f16
1
34 0
1
0 0 1 7
1
end_operator
begin_operator
up f10 f17
1
35 0
1
0 0 1 8
1
end_operator
begin_operator
up f10 f18
1
36 0
1
0 0 1 9
1
end_operator
begin_operator
up f10 f19
1
37 0
1
0 0 1 10
1
end_operator
begin_operator
up f11 f12
1
38 0
1
0 0 2 3
1
end_operator
begin_operator
up f11 f13
1
39 0
1
0 0 2 4
1
end_operator
begin_operator
up f11 f14
1
40 0
1
0 0 2 5
1
end_operator
begin_operator
up f11 f15
1
41 0
1
0 0 2 6
1
end_operator
begin_operator
up f11 f16
1
42 0
1
0 0 2 7
1
end_operator
begin_operator
up f11 f17
1
43 0
1
0 0 2 8
1
end_operator
begin_operator
up f11 f18
1
44 0
1
0 0 2 9
1
end_operator
begin_operator
up f11 f19
1
45 0
1
0 0 2 10
1
end_operator
begin_operator
up f12 f13
1
46 0
1
0 0 3 4
1
end_operator
begin_operator
up f12 f14
1
47 0
1
0 0 3 5
1
end_operator
begin_operator
up f12 f15
1
48 0
1
0 0 3 6
1
end_operator
begin_operator
up f12 f16
1
49 0
1
0 0 3 7
1
end_operator
begin_operator
up f12 f17
1
50 0
1
0 0 3 8
1
end_operator
begin_operator
up f12 f18
1
51 0
1
0 0 3 9
1
end_operator
begin_operator
up f12 f19
1
52 0
1
0 0 3 10
1
end_operator
begin_operator
up f13 f14
1
53 0
1
0 0 4 5
1
end_operator
begin_operator
up f13 f15
1
54 0
1
0 0 4 6
1
end_operator
begin_operator
up f13 f16
1
55 0
1
0 0 4 7
1
end_operator
begin_operator
up f13 f17
1
56 0
1
0 0 4 8
1
end_operator
begin_operator
up f13 f18
1
57 0
1
0 0 4 9
1
end_operator
begin_operator
up f13 f19
1
58 0
1
0 0 4 10
1
end_operator
begin_operator
up f14 f15
1
59 0
1
0 0 5 6
1
end_operator
begin_operator
up f14 f16
1
60 0
1
0 0 5 7
1
end_operator
begin_operator
up f14 f17
1
61 0
1
0 0 5 8
1
end_operator
begin_operator
up f14 f18
1
62 0
1
0 0 5 9
1
end_operator
begin_operator
up f14 f19
1
63 0
1
0 0 5 10
1
end_operator
begin_operator
up f15 f16
1
64 0
1
0 0 6 7
1
end_operator
begin_operator
up f15 f17
1
65 0
1
0 0 6 8
1
end_operator
begin_operator
up f15 f18
1
66 0
1
0 0 6 9
1
end_operator
begin_operator
up f15 f19
1
67 0
1
0 0 6 10
1
end_operator
begin_operator
up f16 f17
1
68 0
1
0 0 7 8
1
end_operator
begin_operator
up f16 f18
1
69 0
1
0 0 7 9
1
end_operator
begin_operator
up f16 f19
1
70 0
1
0 0 7 10
1
end_operator
begin_operator
up f17 f18
1
71 0
1
0 0 8 9
1
end_operator
begin_operator
up f17 f19
1
72 0
1
0 0 8 10
1
end_operator
begin_operator
up f18 f19
1
73 0
1
0 0 9 10
1
end_operator
begin_operator
up f2 f10
1
74 0
1
0 0 11 1
1
end_operator
begin_operator
up f2 f11
1
75 0
1
0 0 11 2
1
end_operator
begin_operator
up f2 f12
1
76 0
1
0 0 11 3
1
end_operator
begin_operator
up f2 f13
1
77 0
1
0 0 11 4
1
end_operator
begin_operator
up f2 f14
1
78 0
1
0 0 11 5
1
end_operator
begin_operator
up f2 f15
1
79 0
1
0 0 11 6
1
end_operator
begin_operator
up f2 f16
1
80 0
1
0 0 11 7
1
end_operator
begin_operator
up f2 f17
1
81 0
1
0 0 11 8
1
end_operator
begin_operator
up f2 f18
1
82 0
1
0 0 11 9
1
end_operator
begin_operator
up f2 f19
1
83 0
1
0 0 11 10
1
end_operator
begin_operator
up f2 f3
1
84 0
1
0 0 11 12
1
end_operator
begin_operator
up f2 f4
1
85 0
1
0 0 11 13
1
end_operator
begin_operator
up f2 f5
1
86 0
1
0 0 11 14
1
end_operator
begin_operator
up f2 f6
1
87 0
1
0 0 11 15
1
end_operator
begin_operator
up f2 f7
1
88 0
1
0 0 11 16
1
end_operator
begin_operator
up f2 f8
1
89 0
1
0 0 11 17
1
end_operator
begin_operator
up f2 f9
1
90 0
1
0 0 11 18
1
end_operator
begin_operator
up f3 f10
1
91 0
1
0 0 12 1
1
end_operator
begin_operator
up f3 f11
1
92 0
1
0 0 12 2
1
end_operator
begin_operator
up f3 f12
1
93 0
1
0 0 12 3
1
end_operator
begin_operator
up f3 f13
1
94 0
1
0 0 12 4
1
end_operator
begin_operator
up f3 f14
1
95 0
1
0 0 12 5
1
end_operator
begin_operator
up f3 f15
1
96 0
1
0 0 12 6
1
end_operator
begin_operator
up f3 f16
1
97 0
1
0 0 12 7
1
end_operator
begin_operator
up f3 f17
1
98 0
1
0 0 12 8
1
end_operator
begin_operator
up f3 f18
1
99 0
1
0 0 12 9
1
end_operator
begin_operator
up f3 f19
1
100 0
1
0 0 12 10
1
end_operator
begin_operator
up f3 f4
1
101 0
1
0 0 12 13
1
end_operator
begin_operator
up f3 f5
1
102 0
1
0 0 12 14
1
end_operator
begin_operator
up f3 f6
1
103 0
1
0 0 12 15
1
end_operator
begin_operator
up f3 f7
1
104 0
1
0 0 12 16
1
end_operator
begin_operator
up f3 f8
1
105 0
1
0 0 12 17
1
end_operator
begin_operator
up f3 f9
1
106 0
1
0 0 12 18
1
end_operator
begin_operator
up f4 f10
1
107 0
1
0 0 13 1
1
end_operator
begin_operator
up f4 f11
1
108 0
1
0 0 13 2
1
end_operator
begin_operator
up f4 f12
1
109 0
1
0 0 13 3
1
end_operator
begin_operator
up f4 f13
1
110 0
1
0 0 13 4
1
end_operator
begin_operator
up f4 f14
1
111 0
1
0 0 13 5
1
end_operator
begin_operator
up f4 f15
1
112 0
1
0 0 13 6
1
end_operator
begin_operator
up f4 f16
1
113 0
1
0 0 13 7
1
end_operator
begin_operator
up f4 f17
1
114 0
1
0 0 13 8
1
end_operator
begin_operator
up f4 f18
1
115 0
1
0 0 13 9
1
end_operator
begin_operator
up f4 f19
1
116 0
1
0 0 13 10
1
end_operator
begin_operator
up f4 f5
1
117 0
1
0 0 13 14
1
end_operator
begin_operator
up f4 f6
1
118 0
1
0 0 13 15
1
end_operator
begin_operator
up f4 f7
1
119 0
1
0 0 13 16
1
end_operator
begin_operator
up f4 f8
1
120 0
1
0 0 13 17
1
end_operator
begin_operator
up f4 f9
1
121 0
1
0 0 13 18
1
end_operator
begin_operator
up f5 f10
1
122 0
1
0 0 14 1
1
end_operator
begin_operator
up f5 f11
1
123 0
1
0 0 14 2
1
end_operator
begin_operator
up f5 f12
1
124 0
1
0 0 14 3
1
end_operator
begin_operator
up f5 f13
1
125 0
1
0 0 14 4
1
end_operator
begin_operator
up f5 f14
1
126 0
1
0 0 14 5
1
end_operator
begin_operator
up f5 f15
1
127 0
1
0 0 14 6
1
end_operator
begin_operator
up f5 f16
1
128 0
1
0 0 14 7
1
end_operator
begin_operator
up f5 f17
1
129 0
1
0 0 14 8
1
end_operator
begin_operator
up f5 f18
1
130 0
1
0 0 14 9
1
end_operator
begin_operator
up f5 f19
1
131 0
1
0 0 14 10
1
end_operator
begin_operator
up f5 f6
1
132 0
1
0 0 14 15
1
end_operator
begin_operator
up f5 f7
1
133 0
1
0 0 14 16
1
end_operator
begin_operator
up f5 f8
1
134 0
1
0 0 14 17
1
end_operator
begin_operator
up f5 f9
1
135 0
1
0 0 14 18
1
end_operator
begin_operator
up f6 f10
1
136 0
1
0 0 15 1
1
end_operator
begin_operator
up f6 f11
1
137 0
1
0 0 15 2
1
end_operator
begin_operator
up f6 f12
1
138 0
1
0 0 15 3
1
end_operator
begin_operator
up f6 f13
1
139 0
1
0 0 15 4
1
end_operator
begin_operator
up f6 f14
1
140 0
1
0 0 15 5
1
end_operator
begin_operator
up f6 f15
1
141 0
1
0 0 15 6
1
end_operator
begin_operator
up f6 f16
1
142 0
1
0 0 15 7
1
end_operator
begin_operator
up f6 f17
1
143 0
1
0 0 15 8
1
end_operator
begin_operator
up f6 f18
1
144 0
1
0 0 15 9
1
end_operator
begin_operator
up f6 f19
1
145 0
1
0 0 15 10
1
end_operator
begin_operator
up f6 f7
1
146 0
1
0 0 15 16
1
end_operator
begin_operator
up f6 f8
1
147 0
1
0 0 15 17
1
end_operator
begin_operator
up f6 f9
1
148 0
1
0 0 15 18
1
end_operator
begin_operator
up f7 f10
1
149 0
1
0 0 16 1
1
end_operator
begin_operator
up f7 f11
1
150 0
1
0 0 16 2
1
end_operator
begin_operator
up f7 f12
1
151 0
1
0 0 16 3
1
end_operator
begin_operator
up f7 f13
1
152 0
1
0 0 16 4
1
end_operator
begin_operator
up f7 f14
1
153 0
1
0 0 16 5
1
end_operator
begin_operator
up f7 f15
1
154 0
1
0 0 16 6
1
end_operator
begin_operator
up f7 f16
1
155 0
1
0 0 16 7
1
end_operator
begin_operator
up f7 f17
1
156 0
1
0 0 16 8
1
end_operator
begin_operator
up f7 f18
1
157 0
1
0 0 16 9
1
end_operator
begin_operator
up f7 f19
1
158 0
1
0 0 16 10
1
end_operator
begin_operator
up f7 f8
1
159 0
1
0 0 16 17
1
end_operator
begin_operator
up f7 f9
1
160 0
1
0 0 16 18
1
end_operator
begin_operator
up f8 f10
1
161 0
1
0 0 17 1
1
end_operator
begin_operator
up f8 f11
1
162 0
1
0 0 17 2
1
end_operator
begin_operator
up f8 f12
1
163 0
1
0 0 17 3
1
end_operator
begin_operator
up f8 f13
1
164 0
1
0 0 17 4
1
end_operator
begin_operator
up f8 f14
1
165 0
1
0 0 17 5
1
end_operator
begin_operator
up f8 f15
1
166 0
1
0 0 17 6
1
end_operator
begin_operator
up f8 f16
1
167 0
1
0 0 17 7
1
end_operator
begin_operator
up f8 f17
1
168 0
1
0 0 17 8
1
end_operator
begin_operator
up f8 f18
1
169 0
1
0 0 17 9
1
end_operator
begin_operator
up f8 f19
1
170 0
1
0 0 17 10
1
end_operator
begin_operator
up f8 f9
1
171 0
1
0 0 17 18
1
end_operator
begin_operator
up f9 f10
1
172 0
1
0 0 18 1
1
end_operator
begin_operator
up f9 f11
1
173 0
1
0 0 18 2
1
end_operator
begin_operator
up f9 f12
1
174 0
1
0 0 18 3
1
end_operator
begin_operator
up f9 f13
1
175 0
1
0 0 18 4
1
end_operator
begin_operator
up f9 f14
1
176 0
1
0 0 18 5
1
end_operator
begin_operator
up f9 f15
1
177 0
1
0 0 18 6
1
end_operator
begin_operator
up f9 f16
1
178 0
1
0 0 18 7
1
end_operator
begin_operator
up f9 f17
1
179 0
1
0 0 18 8
1
end_operator
begin_operator
up f9 f18
1
180 0
1
0 0 18 9
1
end_operator
begin_operator
up f9 f19
1
181 0
1
0 0 18 10
1
end_operator
0
