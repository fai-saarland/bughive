begin_version
3
end_version
begin_metric
1
end_metric
3261
begin_variable
var0
-1
80
lift-at f1
lift-at f10
lift-at f11
lift-at f12
lift-at f13
lift-at f14
lift-at f15
lift-at f16
lift-at f17
lift-at f18
lift-at f19
lift-at f2
lift-at f20
lift-at f21
lift-at f22
lift-at f23
lift-at f24
lift-at f25
lift-at f26
lift-at f27
lift-at f28
lift-at f29
lift-at f3
lift-at f30
lift-at f31
lift-at f32
lift-at f33
lift-at f34
lift-at f35
lift-at f36
lift-at f37
lift-at f38
lift-at f39
lift-at f4
lift-at f40
lift-at f41
lift-at f42
lift-at f43
lift-at f44
lift-at f45
lift-at f46
lift-at f47
lift-at f48
lift-at f49
lift-at f5
lift-at f50
lift-at f51
lift-at f52
lift-at f53
lift-at f54
lift-at f55
lift-at f56
lift-at f57
lift-at f58
lift-at f59
lift-at f6
lift-at f60
lift-at f61
lift-at f62
lift-at f63
lift-at f64
lift-at f65
lift-at f66
lift-at f67
lift-at f68
lift-at f69
lift-at f7
lift-at f70
lift-at f71
lift-at f72
lift-at f73
lift-at f74
lift-at f75
lift-at f76
lift-at f77
lift-at f78
lift-at f79
lift-at f8
lift-at f80
lift-at f9
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f77
served p1
end_variable
begin_variable
var2
-1
3
boarded p10
origin p10 f10
served p10
end_variable
begin_variable
var3
-1
3
boarded p11
origin p11 f8
served p11
end_variable
begin_variable
var4
-1
3
boarded p12
origin p12 f55
served p12
end_variable
begin_variable
var5
-1
3
boarded p13
origin p13 f38
served p13
end_variable
begin_variable
var6
-1
3
boarded p14
origin p14 f4
served p14
end_variable
begin_variable
var7
-1
3
boarded p15
origin p15 f74
served p15
end_variable
begin_variable
var8
-1
3
boarded p16
origin p16 f12
served p16
end_variable
begin_variable
var9
-1
3
boarded p17
origin p17 f2
served p17
end_variable
begin_variable
var10
-1
3
boarded p18
origin p18 f76
served p18
end_variable
begin_variable
var11
-1
3
boarded p19
origin p19 f16
served p19
end_variable
begin_variable
var12
-1
3
boarded p2
origin p2 f40
served p2
end_variable
begin_variable
var13
-1
3
boarded p20
origin p20 f51
served p20
end_variable
begin_variable
var14
-1
3
boarded p21
origin p21 f55
served p21
end_variable
begin_variable
var15
-1
3
boarded p22
origin p22 f5
served p22
end_variable
begin_variable
var16
-1
3
boarded p23
origin p23 f35
served p23
end_variable
begin_variable
var17
-1
3
boarded p24
origin p24 f24
served p24
end_variable
begin_variable
var18
-1
3
boarded p25
origin p25 f3
served p25
end_variable
begin_variable
var19
-1
3
boarded p26
origin p26 f64
served p26
end_variable
begin_variable
var20
-1
3
boarded p27
origin p27 f78
served p27
end_variable
begin_variable
var21
-1
3
boarded p28
origin p28 f62
served p28
end_variable
begin_variable
var22
-1
3
boarded p29
origin p29 f15
served p29
end_variable
begin_variable
var23
-1
3
boarded p3
origin p3 f29
served p3
end_variable
begin_variable
var24
-1
3
boarded p30
origin p30 f9
served p30
end_variable
begin_variable
var25
-1
3
boarded p31
origin p31 f41
served p31
end_variable
begin_variable
var26
-1
3
boarded p32
origin p32 f1
served p32
end_variable
begin_variable
var27
-1
3
boarded p33
origin p33 f67
served p33
end_variable
begin_variable
var28
-1
3
boarded p34
origin p34 f33
served p34
end_variable
begin_variable
var29
-1
3
boarded p35
origin p35 f50
served p35
end_variable
begin_variable
var30
-1
3
boarded p36
origin p36 f72
served p36
end_variable
begin_variable
var31
-1
3
boarded p37
origin p37 f13
served p37
end_variable
begin_variable
var32
-1
3
boarded p38
origin p38 f7
served p38
end_variable
begin_variable
var33
-1
3
boarded p39
origin p39 f23
served p39
end_variable
begin_variable
var34
-1
3
boarded p4
origin p4 f8
served p4
end_variable
begin_variable
var35
-1
3
boarded p40
origin p40 f78
served p40
end_variable
begin_variable
var36
-1
3
boarded p41
origin p41 f48
served p41
end_variable
begin_variable
var37
-1
3
boarded p42
origin p42 f69
served p42
end_variable
begin_variable
var38
-1
3
boarded p43
origin p43 f60
served p43
end_variable
begin_variable
var39
-1
3
boarded p44
origin p44 f52
served p44
end_variable
begin_variable
var40
-1
3
boarded p45
origin p45 f60
served p45
end_variable
begin_variable
var41
-1
3
boarded p46
origin p46 f75
served p46
end_variable
begin_variable
var42
-1
3
boarded p47
origin p47 f37
served p47
end_variable
begin_variable
var43
-1
3
boarded p48
origin p48 f25
served p48
end_variable
begin_variable
var44
-1
3
boarded p49
origin p49 f70
served p49
end_variable
begin_variable
var45
-1
3
boarded p5
origin p5 f72
served p5
end_variable
begin_variable
var46
-1
3
boarded p50
origin p50 f35
served p50
end_variable
begin_variable
var47
-1
3
boarded p6
origin p6 f58
served p6
end_variable
begin_variable
var48
-1
3
boarded p7
origin p7 f37
served p7
end_variable
begin_variable
var49
-1
3
boarded p8
origin p8 f5
served p8
end_variable
begin_variable
var50
-1
3
boarded p9
origin p9 f25
served p9
end_variable
begin_variable
var51
-1
2
above f1 f10
none-of-those
end_variable
begin_variable
var52
-1
2
above f1 f11
none-of-those
end_variable
begin_variable
var53
-1
2
above f1 f12
none-of-those
end_variable
begin_variable
var54
-1
2
above f1 f13
none-of-those
end_variable
begin_variable
var55
-1
2
above f1 f14
none-of-those
end_variable
begin_variable
var56
-1
2
above f1 f15
none-of-those
end_variable
begin_variable
var57
-1
2
above f1 f16
none-of-those
end_variable
begin_variable
var58
-1
2
above f1 f17
none-of-those
end_variable
begin_variable
var59
-1
2
above f1 f18
none-of-those
end_variable
begin_variable
var60
-1
2
above f1 f19
none-of-those
end_variable
begin_variable
var61
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var62
-1
2
above f1 f20
none-of-those
end_variable
begin_variable
var63
-1
2
above f1 f21
none-of-those
end_variable
begin_variable
var64
-1
2
above f1 f22
none-of-those
end_variable
begin_variable
var65
-1
2
above f1 f23
none-of-those
end_variable
begin_variable
var66
-1
2
above f1 f24
none-of-those
end_variable
begin_variable
var67
-1
2
above f1 f25
none-of-those
end_variable
begin_variable
var68
-1
2
above f1 f26
none-of-those
end_variable
begin_variable
var69
-1
2
above f1 f27
none-of-those
end_variable
begin_variable
var70
-1
2
above f1 f28
none-of-those
end_variable
begin_variable
var71
-1
2
above f1 f29
none-of-those
end_variable
begin_variable
var72
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var73
-1
2
above f1 f30
none-of-those
end_variable
begin_variable
var74
-1
2
above f1 f31
none-of-those
end_variable
begin_variable
var75
-1
2
above f1 f32
none-of-those
end_variable
begin_variable
var76
-1
2
above f1 f33
none-of-those
end_variable
begin_variable
var77
-1
2
above f1 f34
none-of-those
end_variable
begin_variable
var78
-1
2
above f1 f35
none-of-those
end_variable
begin_variable
var79
-1
2
above f1 f36
none-of-those
end_variable
begin_variable
var80
-1
2
above f1 f37
none-of-those
end_variable
begin_variable
var81
-1
2
above f1 f38
none-of-those
end_variable
begin_variable
var82
-1
2
above f1 f39
none-of-those
end_variable
begin_variable
var83
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var84
-1
2
above f1 f40
none-of-those
end_variable
begin_variable
var85
-1
2
above f1 f41
none-of-those
end_variable
begin_variable
var86
-1
2
above f1 f42
none-of-those
end_variable
begin_variable
var87
-1
2
above f1 f43
none-of-those
end_variable
begin_variable
var88
-1
2
above f1 f44
none-of-those
end_variable
begin_variable
var89
-1
2
above f1 f45
none-of-those
end_variable
begin_variable
var90
-1
2
above f1 f46
none-of-those
end_variable
begin_variable
var91
-1
2
above f1 f47
none-of-those
end_variable
begin_variable
var92
-1
2
above f1 f48
none-of-those
end_variable
begin_variable
var93
-1
2
above f1 f49
none-of-those
end_variable
begin_variable
var94
-1
2
above f1 f5
none-of-those
end_variable
begin_variable
var95
-1
2
above f1 f50
none-of-those
end_variable
begin_variable
var96
-1
2
above f1 f51
none-of-those
end_variable
begin_variable
var97
-1
2
above f1 f52
none-of-those
end_variable
begin_variable
var98
-1
2
above f1 f53
none-of-those
end_variable
begin_variable
var99
-1
2
above f1 f54
none-of-those
end_variable
begin_variable
var100
-1
2
above f1 f55
none-of-those
end_variable
begin_variable
var101
-1
2
above f1 f56
none-of-those
end_variable
begin_variable
var102
-1
2
above f1 f57
none-of-those
end_variable
begin_variable
var103
-1
2
above f1 f58
none-of-those
end_variable
begin_variable
var104
-1
2
above f1 f59
none-of-those
end_variable
begin_variable
var105
-1
2
above f1 f6
none-of-those
end_variable
begin_variable
var106
-1
2
above f1 f60
none-of-those
end_variable
begin_variable
var107
-1
2
above f1 f61
none-of-those
end_variable
begin_variable
var108
-1
2
above f1 f62
none-of-those
end_variable
begin_variable
var109
-1
2
above f1 f63
none-of-those
end_variable
begin_variable
var110
-1
2
above f1 f64
none-of-those
end_variable
begin_variable
var111
-1
2
above f1 f65
none-of-those
end_variable
begin_variable
var112
-1
2
above f1 f66
none-of-those
end_variable
begin_variable
var113
-1
2
above f1 f67
none-of-those
end_variable
begin_variable
var114
-1
2
above f1 f68
none-of-those
end_variable
begin_variable
var115
-1
2
above f1 f69
none-of-those
end_variable
begin_variable
var116
-1
2
above f1 f7
none-of-those
end_variable
begin_variable
var117
-1
2
above f1 f70
none-of-those
end_variable
begin_variable
var118
-1
2
above f1 f71
none-of-those
end_variable
begin_variable
var119
-1
2
above f1 f72
none-of-those
end_variable
begin_variable
var120
-1
2
above f1 f73
none-of-those
end_variable
begin_variable
var121
-1
2
above f1 f74
none-of-those
end_variable
begin_variable
var122
-1
2
above f1 f75
none-of-those
end_variable
begin_variable
var123
-1
2
above f1 f76
none-of-those
end_variable
begin_variable
var124
-1
2
above f1 f77
none-of-those
end_variable
begin_variable
var125
-1
2
above f1 f78
none-of-those
end_variable
begin_variable
var126
-1
2
above f1 f79
none-of-those
end_variable
begin_variable
var127
-1
2
above f1 f8
none-of-those
end_variable
begin_variable
var128
-1
2
above f1 f80
none-of-those
end_variable
begin_variable
var129
-1
2
above f1 f9
none-of-those
end_variable
begin_variable
var130
-1
2
above f10 f11
none-of-those
end_variable
begin_variable
var131
-1
2
above f10 f12
none-of-those
end_variable
begin_variable
var132
-1
2
above f10 f13
none-of-those
end_variable
begin_variable
var133
-1
2
above f10 f14
none-of-those
end_variable
begin_variable
var134
-1
2
above f10 f15
none-of-those
end_variable
begin_variable
var135
-1
2
above f10 f16
none-of-those
end_variable
begin_variable
var136
-1
2
above f10 f17
none-of-those
end_variable
begin_variable
var137
-1
2
above f10 f18
none-of-those
end_variable
begin_variable
var138
-1
2
above f10 f19
none-of-those
end_variable
begin_variable
var139
-1
2
above f10 f20
none-of-those
end_variable
begin_variable
var140
-1
2
above f10 f21
none-of-those
end_variable
begin_variable
var141
-1
2
above f10 f22
none-of-those
end_variable
begin_variable
var142
-1
2
above f10 f23
none-of-those
end_variable
begin_variable
var143
-1
2
above f10 f24
none-of-those
end_variable
begin_variable
var144
-1
2
above f10 f25
none-of-those
end_variable
begin_variable
var145
-1
2
above f10 f26
none-of-those
end_variable
begin_variable
var146
-1
2
above f10 f27
none-of-those
end_variable
begin_variable
var147
-1
2
above f10 f28
none-of-those
end_variable
begin_variable
var148
-1
2
above f10 f29
none-of-those
end_variable
begin_variable
var149
-1
2
above f10 f30
none-of-those
end_variable
begin_variable
var150
-1
2
above f10 f31
none-of-those
end_variable
begin_variable
var151
-1
2
above f10 f32
none-of-those
end_variable
begin_variable
var152
-1
2
above f10 f33
none-of-those
end_variable
begin_variable
var153
-1
2
above f10 f34
none-of-those
end_variable
begin_variable
var154
-1
2
above f10 f35
none-of-those
end_variable
begin_variable
var155
-1
2
above f10 f36
none-of-those
end_variable
begin_variable
var156
-1
2
above f10 f37
none-of-those
end_variable
begin_variable
var157
-1
2
above f10 f38
none-of-those
end_variable
begin_variable
var158
-1
2
above f10 f39
none-of-those
end_variable
begin_variable
var159
-1
2
above f10 f40
none-of-those
end_variable
begin_variable
var160
-1
2
above f10 f41
none-of-those
end_variable
begin_variable
var161
-1
2
above f10 f42
none-of-those
end_variable
begin_variable
var162
-1
2
above f10 f43
none-of-those
end_variable
begin_variable
var163
-1
2
above f10 f44
none-of-those
end_variable
begin_variable
var164
-1
2
above f10 f45
none-of-those
end_variable
begin_variable
var165
-1
2
above f10 f46
none-of-those
end_variable
begin_variable
var166
-1
2
above f10 f47
none-of-those
end_variable
begin_variable
var167
-1
2
above f10 f48
none-of-those
end_variable
begin_variable
var168
-1
2
above f10 f49
none-of-those
end_variable
begin_variable
var169
-1
2
above f10 f50
none-of-those
end_variable
begin_variable
var170
-1
2
above f10 f51
none-of-those
end_variable
begin_variable
var171
-1
2
above f10 f52
none-of-those
end_variable
begin_variable
var172
-1
2
above f10 f53
none-of-those
end_variable
begin_variable
var173
-1
2
above f10 f54
none-of-those
end_variable
begin_variable
var174
-1
2
above f10 f55
none-of-those
end_variable
begin_variable
var175
-1
2
above f10 f56
none-of-those
end_variable
begin_variable
var176
-1
2
above f10 f57
none-of-those
end_variable
begin_variable
var177
-1
2
above f10 f58
none-of-those
end_variable
begin_variable
var178
-1
2
above f10 f59
none-of-those
end_variable
begin_variable
var179
-1
2
above f10 f60
none-of-those
end_variable
begin_variable
var180
-1
2
above f10 f61
none-of-those
end_variable
begin_variable
var181
-1
2
above f10 f62
none-of-those
end_variable
begin_variable
var182
-1
2
above f10 f63
none-of-those
end_variable
begin_variable
var183
-1
2
above f10 f64
none-of-those
end_variable
begin_variable
var184
-1
2
above f10 f65
none-of-those
end_variable
begin_variable
var185
-1
2
above f10 f66
none-of-those
end_variable
begin_variable
var186
-1
2
above f10 f67
none-of-those
end_variable
begin_variable
var187
-1
2
above f10 f68
none-of-those
end_variable
begin_variable
var188
-1
2
above f10 f69
none-of-those
end_variable
begin_variable
var189
-1
2
above f10 f70
none-of-those
end_variable
begin_variable
var190
-1
2
above f10 f71
none-of-those
end_variable
begin_variable
var191
-1
2
above f10 f72
none-of-those
end_variable
begin_variable
var192
-1
2
above f10 f73
none-of-those
end_variable
begin_variable
var193
-1
2
above f10 f74
none-of-those
end_variable
begin_variable
var194
-1
2
above f10 f75
none-of-those
end_variable
begin_variable
var195
-1
2
above f10 f76
none-of-those
end_variable
begin_variable
var196
-1
2
above f10 f77
none-of-those
end_variable
begin_variable
var197
-1
2
above f10 f78
none-of-those
end_variable
begin_variable
var198
-1
2
above f10 f79
none-of-those
end_variable
begin_variable
var199
-1
2
above f10 f80
none-of-those
end_variable
begin_variable
var200
-1
2
above f11 f12
none-of-those
end_variable
begin_variable
var201
-1
2
above f11 f13
none-of-those
end_variable
begin_variable
var202
-1
2
above f11 f14
none-of-those
end_variable
begin_variable
var203
-1
2
above f11 f15
none-of-those
end_variable
begin_variable
var204
-1
2
above f11 f16
none-of-those
end_variable
begin_variable
var205
-1
2
above f11 f17
none-of-those
end_variable
begin_variable
var206
-1
2
above f11 f18
none-of-those
end_variable
begin_variable
var207
-1
2
above f11 f19
none-of-those
end_variable
begin_variable
var208
-1
2
above f11 f20
none-of-those
end_variable
begin_variable
var209
-1
2
above f11 f21
none-of-those
end_variable
begin_variable
var210
-1
2
above f11 f22
none-of-those
end_variable
begin_variable
var211
-1
2
above f11 f23
none-of-those
end_variable
begin_variable
var212
-1
2
above f11 f24
none-of-those
end_variable
begin_variable
var213
-1
2
above f11 f25
none-of-those
end_variable
begin_variable
var214
-1
2
above f11 f26
none-of-those
end_variable
begin_variable
var215
-1
2
above f11 f27
none-of-those
end_variable
begin_variable
var216
-1
2
above f11 f28
none-of-those
end_variable
begin_variable
var217
-1
2
above f11 f29
none-of-those
end_variable
begin_variable
var218
-1
2
above f11 f30
none-of-those
end_variable
begin_variable
var219
-1
2
above f11 f31
none-of-those
end_variable
begin_variable
var220
-1
2
above f11 f32
none-of-those
end_variable
begin_variable
var221
-1
2
above f11 f33
none-of-those
end_variable
begin_variable
var222
-1
2
above f11 f34
none-of-those
end_variable
begin_variable
var223
-1
2
above f11 f35
none-of-those
end_variable
begin_variable
var224
-1
2
above f11 f36
none-of-those
end_variable
begin_variable
var225
-1
2
above f11 f37
none-of-those
end_variable
begin_variable
var226
-1
2
above f11 f38
none-of-those
end_variable
begin_variable
var227
-1
2
above f11 f39
none-of-those
end_variable
begin_variable
var228
-1
2
above f11 f40
none-of-those
end_variable
begin_variable
var229
-1
2
above f11 f41
none-of-those
end_variable
begin_variable
var230
-1
2
above f11 f42
none-of-those
end_variable
begin_variable
var231
-1
2
above f11 f43
none-of-those
end_variable
begin_variable
var232
-1
2
above f11 f44
none-of-those
end_variable
begin_variable
var233
-1
2
above f11 f45
none-of-those
end_variable
begin_variable
var234
-1
2
above f11 f46
none-of-those
end_variable
begin_variable
var235
-1
2
above f11 f47
none-of-those
end_variable
begin_variable
var236
-1
2
above f11 f48
none-of-those
end_variable
begin_variable
var237
-1
2
above f11 f49
none-of-those
end_variable
begin_variable
var238
-1
2
above f11 f50
none-of-those
end_variable
begin_variable
var239
-1
2
above f11 f51
none-of-those
end_variable
begin_variable
var240
-1
2
above f11 f52
none-of-those
end_variable
begin_variable
var241
-1
2
above f11 f53
none-of-those
end_variable
begin_variable
var242
-1
2
above f11 f54
none-of-those
end_variable
begin_variable
var243
-1
2
above f11 f55
none-of-those
end_variable
begin_variable
var244
-1
2
above f11 f56
none-of-those
end_variable
begin_variable
var245
-1
2
above f11 f57
none-of-those
end_variable
begin_variable
var246
-1
2
above f11 f58
none-of-those
end_variable
begin_variable
var247
-1
2
above f11 f59
none-of-those
end_variable
begin_variable
var248
-1
2
above f11 f60
none-of-those
end_variable
begin_variable
var249
-1
2
above f11 f61
none-of-those
end_variable
begin_variable
var250
-1
2
above f11 f62
none-of-those
end_variable
begin_variable
var251
-1
2
above f11 f63
none-of-those
end_variable
begin_variable
var252
-1
2
above f11 f64
none-of-those
end_variable
begin_variable
var253
-1
2
above f11 f65
none-of-those
end_variable
begin_variable
var254
-1
2
above f11 f66
none-of-those
end_variable
begin_variable
var255
-1
2
above f11 f67
none-of-those
end_variable
begin_variable
var256
-1
2
above f11 f68
none-of-those
end_variable
begin_variable
var257
-1
2
above f11 f69
none-of-those
end_variable
begin_variable
var258
-1
2
above f11 f70
none-of-those
end_variable
begin_variable
var259
-1
2
above f11 f71
none-of-those
end_variable
begin_variable
var260
-1
2
above f11 f72
none-of-those
end_variable
begin_variable
var261
-1
2
above f11 f73
none-of-those
end_variable
begin_variable
var262
-1
2
above f11 f74
none-of-those
end_variable
begin_variable
var263
-1
2
above f11 f75
none-of-those
end_variable
begin_variable
var264
-1
2
above f11 f76
none-of-those
end_variable
begin_variable
var265
-1
2
above f11 f77
none-of-those
end_variable
begin_variable
var266
-1
2
above f11 f78
none-of-those
end_variable
begin_variable
var267
-1
2
above f11 f79
none-of-those
end_variable
begin_variable
var268
-1
2
above f11 f80
none-of-those
end_variable
begin_variable
var269
-1
2
above f12 f13
none-of-those
end_variable
begin_variable
var270
-1
2
above f12 f14
none-of-those
end_variable
begin_variable
var271
-1
2
above f12 f15
none-of-those
end_variable
begin_variable
var272
-1
2
above f12 f16
none-of-those
end_variable
begin_variable
var273
-1
2
above f12 f17
none-of-those
end_variable
begin_variable
var274
-1
2
above f12 f18
none-of-those
end_variable
begin_variable
var275
-1
2
above f12 f19
none-of-those
end_variable
begin_variable
var276
-1
2
above f12 f20
none-of-those
end_variable
begin_variable
var277
-1
2
above f12 f21
none-of-those
end_variable
begin_variable
var278
-1
2
above f12 f22
none-of-those
end_variable
begin_variable
var279
-1
2
above f12 f23
none-of-those
end_variable
begin_variable
var280
-1
2
above f12 f24
none-of-those
end_variable
begin_variable
var281
-1
2
above f12 f25
none-of-those
end_variable
begin_variable
var282
-1
2
above f12 f26
none-of-those
end_variable
begin_variable
var283
-1
2
above f12 f27
none-of-those
end_variable
begin_variable
var284
-1
2
above f12 f28
none-of-those
end_variable
begin_variable
var285
-1
2
above f12 f29
none-of-those
end_variable
begin_variable
var286
-1
2
above f12 f30
none-of-those
end_variable
begin_variable
var287
-1
2
above f12 f31
none-of-those
end_variable
begin_variable
var288
-1
2
above f12 f32
none-of-those
end_variable
begin_variable
var289
-1
2
above f12 f33
none-of-those
end_variable
begin_variable
var290
-1
2
above f12 f34
none-of-those
end_variable
begin_variable
var291
-1
2
above f12 f35
none-of-those
end_variable
begin_variable
var292
-1
2
above f12 f36
none-of-those
end_variable
begin_variable
var293
-1
2
above f12 f37
none-of-those
end_variable
begin_variable
var294
-1
2
above f12 f38
none-of-those
end_variable
begin_variable
var295
-1
2
above f12 f39
none-of-those
end_variable
begin_variable
var296
-1
2
above f12 f40
none-of-those
end_variable
begin_variable
var297
-1
2
above f12 f41
none-of-those
end_variable
begin_variable
var298
-1
2
above f12 f42
none-of-those
end_variable
begin_variable
var299
-1
2
above f12 f43
none-of-those
end_variable
begin_variable
var300
-1
2
above f12 f44
none-of-those
end_variable
begin_variable
var301
-1
2
above f12 f45
none-of-those
end_variable
begin_variable
var302
-1
2
above f12 f46
none-of-those
end_variable
begin_variable
var303
-1
2
above f12 f47
none-of-those
end_variable
begin_variable
var304
-1
2
above f12 f48
none-of-those
end_variable
begin_variable
var305
-1
2
above f12 f49
none-of-those
end_variable
begin_variable
var306
-1
2
above f12 f50
none-of-those
end_variable
begin_variable
var307
-1
2
above f12 f51
none-of-those
end_variable
begin_variable
var308
-1
2
above f12 f52
none-of-those
end_variable
begin_variable
var309
-1
2
above f12 f53
none-of-those
end_variable
begin_variable
var310
-1
2
above f12 f54
none-of-those
end_variable
begin_variable
var311
-1
2
above f12 f55
none-of-those
end_variable
begin_variable
var312
-1
2
above f12 f56
none-of-those
end_variable
begin_variable
var313
-1
2
above f12 f57
none-of-those
end_variable
begin_variable
var314
-1
2
above f12 f58
none-of-those
end_variable
begin_variable
var315
-1
2
above f12 f59
none-of-those
end_variable
begin_variable
var316
-1
2
above f12 f60
none-of-those
end_variable
begin_variable
var317
-1
2
above f12 f61
none-of-those
end_variable
begin_variable
var318
-1
2
above f12 f62
none-of-those
end_variable
begin_variable
var319
-1
2
above f12 f63
none-of-those
end_variable
begin_variable
var320
-1
2
above f12 f64
none-of-those
end_variable
begin_variable
var321
-1
2
above f12 f65
none-of-those
end_variable
begin_variable
var322
-1
2
above f12 f66
none-of-those
end_variable
begin_variable
var323
-1
2
above f12 f67
none-of-those
end_variable
begin_variable
var324
-1
2
above f12 f68
none-of-those
end_variable
begin_variable
var325
-1
2
above f12 f69
none-of-those
end_variable
begin_variable
var326
-1
2
above f12 f70
none-of-those
end_variable
begin_variable
var327
-1
2
above f12 f71
none-of-those
end_variable
begin_variable
var328
-1
2
above f12 f72
none-of-those
end_variable
begin_variable
var329
-1
2
above f12 f73
none-of-those
end_variable
begin_variable
var330
-1
2
above f12 f74
none-of-those
end_variable
begin_variable
var331
-1
2
above f12 f75
none-of-those
end_variable
begin_variable
var332
-1
2
above f12 f76
none-of-those
end_variable
begin_variable
var333
-1
2
above f12 f77
none-of-those
end_variable
begin_variable
var334
-1
2
above f12 f78
none-of-those
end_variable
begin_variable
var335
-1
2
above f12 f79
none-of-those
end_variable
begin_variable
var336
-1
2
above f12 f80
none-of-those
end_variable
begin_variable
var337
-1
2
above f13 f14
none-of-those
end_variable
begin_variable
var338
-1
2
above f13 f15
none-of-those
end_variable
begin_variable
var339
-1
2
above f13 f16
none-of-those
end_variable
begin_variable
var340
-1
2
above f13 f17
none-of-those
end_variable
begin_variable
var341
-1
2
above f13 f18
none-of-those
end_variable
begin_variable
var342
-1
2
above f13 f19
none-of-those
end_variable
begin_variable
var343
-1
2
above f13 f20
none-of-those
end_variable
begin_variable
var344
-1
2
above f13 f21
none-of-those
end_variable
begin_variable
var345
-1
2
above f13 f22
none-of-those
end_variable
begin_variable
var346
-1
2
above f13 f23
none-of-those
end_variable
begin_variable
var347
-1
2
above f13 f24
none-of-those
end_variable
begin_variable
var348
-1
2
above f13 f25
none-of-those
end_variable
begin_variable
var349
-1
2
above f13 f26
none-of-those
end_variable
begin_variable
var350
-1
2
above f13 f27
none-of-those
end_variable
begin_variable
var351
-1
2
above f13 f28
none-of-those
end_variable
begin_variable
var352
-1
2
above f13 f29
none-of-those
end_variable
begin_variable
var353
-1
2
above f13 f30
none-of-those
end_variable
begin_variable
var354
-1
2
above f13 f31
none-of-those
end_variable
begin_variable
var355
-1
2
above f13 f32
none-of-those
end_variable
begin_variable
var356
-1
2
above f13 f33
none-of-those
end_variable
begin_variable
var357
-1
2
above f13 f34
none-of-those
end_variable
begin_variable
var358
-1
2
above f13 f35
none-of-those
end_variable
begin_variable
var359
-1
2
above f13 f36
none-of-those
end_variable
begin_variable
var360
-1
2
above f13 f37
none-of-those
end_variable
begin_variable
var361
-1
2
above f13 f38
none-of-those
end_variable
begin_variable
var362
-1
2
above f13 f39
none-of-those
end_variable
begin_variable
var363
-1
2
above f13 f40
none-of-those
end_variable
begin_variable
var364
-1
2
above f13 f41
none-of-those
end_variable
begin_variable
var365
-1
2
above f13 f42
none-of-those
end_variable
begin_variable
var366
-1
2
above f13 f43
none-of-those
end_variable
begin_variable
var367
-1
2
above f13 f44
none-of-those
end_variable
begin_variable
var368
-1
2
above f13 f45
none-of-those
end_variable
begin_variable
var369
-1
2
above f13 f46
none-of-those
end_variable
begin_variable
var370
-1
2
above f13 f47
none-of-those
end_variable
begin_variable
var371
-1
2
above f13 f48
none-of-those
end_variable
begin_variable
var372
-1
2
above f13 f49
none-of-those
end_variable
begin_variable
var373
-1
2
above f13 f50
none-of-those
end_variable
begin_variable
var374
-1
2
above f13 f51
none-of-those
end_variable
begin_variable
var375
-1
2
above f13 f52
none-of-those
end_variable
begin_variable
var376
-1
2
above f13 f53
none-of-those
end_variable
begin_variable
var377
-1
2
above f13 f54
none-of-those
end_variable
begin_variable
var378
-1
2
above f13 f55
none-of-those
end_variable
begin_variable
var379
-1
2
above f13 f56
none-of-those
end_variable
begin_variable
var380
-1
2
above f13 f57
none-of-those
end_variable
begin_variable
var381
-1
2
above f13 f58
none-of-those
end_variable
begin_variable
var382
-1
2
above f13 f59
none-of-those
end_variable
begin_variable
var383
-1
2
above f13 f60
none-of-those
end_variable
begin_variable
var384
-1
2
above f13 f61
none-of-those
end_variable
begin_variable
var385
-1
2
above f13 f62
none-of-those
end_variable
begin_variable
var386
-1
2
above f13 f63
none-of-those
end_variable
begin_variable
var387
-1
2
above f13 f64
none-of-those
end_variable
begin_variable
var388
-1
2
above f13 f65
none-of-those
end_variable
begin_variable
var389
-1
2
above f13 f66
none-of-those
end_variable
begin_variable
var390
-1
2
above f13 f67
none-of-those
end_variable
begin_variable
var391
-1
2
above f13 f68
none-of-those
end_variable
begin_variable
var392
-1
2
above f13 f69
none-of-those
end_variable
begin_variable
var393
-1
2
above f13 f70
none-of-those
end_variable
begin_variable
var394
-1
2
above f13 f71
none-of-those
end_variable
begin_variable
var395
-1
2
above f13 f72
none-of-those
end_variable
begin_variable
var396
-1
2
above f13 f73
none-of-those
end_variable
begin_variable
var397
-1
2
above f13 f74
none-of-those
end_variable
begin_variable
var398
-1
2
above f13 f75
none-of-those
end_variable
begin_variable
var399
-1
2
above f13 f76
none-of-those
end_variable
begin_variable
var400
-1
2
above f13 f77
none-of-those
end_variable
begin_variable
var401
-1
2
above f13 f78
none-of-those
end_variable
begin_variable
var402
-1
2
above f13 f79
none-of-those
end_variable
begin_variable
var403
-1
2
above f13 f80
none-of-those
end_variable
begin_variable
var404
-1
2
above f14 f15
none-of-those
end_variable
begin_variable
var405
-1
2
above f14 f16
none-of-those
end_variable
begin_variable
var406
-1
2
above f14 f17
none-of-those
end_variable
begin_variable
var407
-1
2
above f14 f18
none-of-those
end_variable
begin_variable
var408
-1
2
above f14 f19
none-of-those
end_variable
begin_variable
var409
-1
2
above f14 f20
none-of-those
end_variable
begin_variable
var410
-1
2
above f14 f21
none-of-those
end_variable
begin_variable
var411
-1
2
above f14 f22
none-of-those
end_variable
begin_variable
var412
-1
2
above f14 f23
none-of-those
end_variable
begin_variable
var413
-1
2
above f14 f24
none-of-those
end_variable
begin_variable
var414
-1
2
above f14 f25
none-of-those
end_variable
begin_variable
var415
-1
2
above f14 f26
none-of-those
end_variable
begin_variable
var416
-1
2
above f14 f27
none-of-those
end_variable
begin_variable
var417
-1
2
above f14 f28
none-of-those
end_variable
begin_variable
var418
-1
2
above f14 f29
none-of-those
end_variable
begin_variable
var419
-1
2
above f14 f30
none-of-those
end_variable
begin_variable
var420
-1
2
above f14 f31
none-of-those
end_variable
begin_variable
var421
-1
2
above f14 f32
none-of-those
end_variable
begin_variable
var422
-1
2
above f14 f33
none-of-those
end_variable
begin_variable
var423
-1
2
above f14 f34
none-of-those
end_variable
begin_variable
var424
-1
2
above f14 f35
none-of-those
end_variable
begin_variable
var425
-1
2
above f14 f36
none-of-those
end_variable
begin_variable
var426
-1
2
above f14 f37
none-of-those
end_variable
begin_variable
var427
-1
2
above f14 f38
none-of-those
end_variable
begin_variable
var428
-1
2
above f14 f39
none-of-those
end_variable
begin_variable
var429
-1
2
above f14 f40
none-of-those
end_variable
begin_variable
var430
-1
2
above f14 f41
none-of-those
end_variable
begin_variable
var431
-1
2
above f14 f42
none-of-those
end_variable
begin_variable
var432
-1
2
above f14 f43
none-of-those
end_variable
begin_variable
var433
-1
2
above f14 f44
none-of-those
end_variable
begin_variable
var434
-1
2
above f14 f45
none-of-those
end_variable
begin_variable
var435
-1
2
above f14 f46
none-of-those
end_variable
begin_variable
var436
-1
2
above f14 f47
none-of-those
end_variable
begin_variable
var437
-1
2
above f14 f48
none-of-those
end_variable
begin_variable
var438
-1
2
above f14 f49
none-of-those
end_variable
begin_variable
var439
-1
2
above f14 f50
none-of-those
end_variable
begin_variable
var440
-1
2
above f14 f51
none-of-those
end_variable
begin_variable
var441
-1
2
above f14 f52
none-of-those
end_variable
begin_variable
var442
-1
2
above f14 f53
none-of-those
end_variable
begin_variable
var443
-1
2
above f14 f54
none-of-those
end_variable
begin_variable
var444
-1
2
above f14 f55
none-of-those
end_variable
begin_variable
var445
-1
2
above f14 f56
none-of-those
end_variable
begin_variable
var446
-1
2
above f14 f57
none-of-those
end_variable
begin_variable
var447
-1
2
above f14 f58
none-of-those
end_variable
begin_variable
var448
-1
2
above f14 f59
none-of-those
end_variable
begin_variable
var449
-1
2
above f14 f60
none-of-those
end_variable
begin_variable
var450
-1
2
above f14 f61
none-of-those
end_variable
begin_variable
var451
-1
2
above f14 f62
none-of-those
end_variable
begin_variable
var452
-1
2
above f14 f63
none-of-those
end_variable
begin_variable
var453
-1
2
above f14 f64
none-of-those
end_variable
begin_variable
var454
-1
2
above f14 f65
none-of-those
end_variable
begin_variable
var455
-1
2
above f14 f66
none-of-those
end_variable
begin_variable
var456
-1
2
above f14 f67
none-of-those
end_variable
begin_variable
var457
-1
2
above f14 f68
none-of-those
end_variable
begin_variable
var458
-1
2
above f14 f69
none-of-those
end_variable
begin_variable
var459
-1
2
above f14 f70
none-of-those
end_variable
begin_variable
var460
-1
2
above f14 f71
none-of-those
end_variable
begin_variable
var461
-1
2
above f14 f72
none-of-those
end_variable
begin_variable
var462
-1
2
above f14 f73
none-of-those
end_variable
begin_variable
var463
-1
2
above f14 f74
none-of-those
end_variable
begin_variable
var464
-1
2
above f14 f75
none-of-those
end_variable
begin_variable
var465
-1
2
above f14 f76
none-of-those
end_variable
begin_variable
var466
-1
2
above f14 f77
none-of-those
end_variable
begin_variable
var467
-1
2
above f14 f78
none-of-those
end_variable
begin_variable
var468
-1
2
above f14 f79
none-of-those
end_variable
begin_variable
var469
-1
2
above f14 f80
none-of-those
end_variable
begin_variable
var470
-1
2
above f15 f16
none-of-those
end_variable
begin_variable
var471
-1
2
above f15 f17
none-of-those
end_variable
begin_variable
var472
-1
2
above f15 f18
none-of-those
end_variable
begin_variable
var473
-1
2
above f15 f19
none-of-those
end_variable
begin_variable
var474
-1
2
above f15 f20
none-of-those
end_variable
begin_variable
var475
-1
2
above f15 f21
none-of-those
end_variable
begin_variable
var476
-1
2
above f15 f22
none-of-those
end_variable
begin_variable
var477
-1
2
above f15 f23
none-of-those
end_variable
begin_variable
var478
-1
2
above f15 f24
none-of-those
end_variable
begin_variable
var479
-1
2
above f15 f25
none-of-those
end_variable
begin_variable
var480
-1
2
above f15 f26
none-of-those
end_variable
begin_variable
var481
-1
2
above f15 f27
none-of-those
end_variable
begin_variable
var482
-1
2
above f15 f28
none-of-those
end_variable
begin_variable
var483
-1
2
above f15 f29
none-of-those
end_variable
begin_variable
var484
-1
2
above f15 f30
none-of-those
end_variable
begin_variable
var485
-1
2
above f15 f31
none-of-those
end_variable
begin_variable
var486
-1
2
above f15 f32
none-of-those
end_variable
begin_variable
var487
-1
2
above f15 f33
none-of-those
end_variable
begin_variable
var488
-1
2
above f15 f34
none-of-those
end_variable
begin_variable
var489
-1
2
above f15 f35
none-of-those
end_variable
begin_variable
var490
-1
2
above f15 f36
none-of-those
end_variable
begin_variable
var491
-1
2
above f15 f37
none-of-those
end_variable
begin_variable
var492
-1
2
above f15 f38
none-of-those
end_variable
begin_variable
var493
-1
2
above f15 f39
none-of-those
end_variable
begin_variable
var494
-1
2
above f15 f40
none-of-those
end_variable
begin_variable
var495
-1
2
above f15 f41
none-of-those
end_variable
begin_variable
var496
-1
2
above f15 f42
none-of-those
end_variable
begin_variable
var497
-1
2
above f15 f43
none-of-those
end_variable
begin_variable
var498
-1
2
above f15 f44
none-of-those
end_variable
begin_variable
var499
-1
2
above f15 f45
none-of-those
end_variable
begin_variable
var500
-1
2
above f15 f46
none-of-those
end_variable
begin_variable
var501
-1
2
above f15 f47
none-of-those
end_variable
begin_variable
var502
-1
2
above f15 f48
none-of-those
end_variable
begin_variable
var503
-1
2
above f15 f49
none-of-those
end_variable
begin_variable
var504
-1
2
above f15 f50
none-of-those
end_variable
begin_variable
var505
-1
2
above f15 f51
none-of-those
end_variable
begin_variable
var506
-1
2
above f15 f52
none-of-those
end_variable
begin_variable
var507
-1
2
above f15 f53
none-of-those
end_variable
begin_variable
var508
-1
2
above f15 f54
none-of-those
end_variable
begin_variable
var509
-1
2
above f15 f55
none-of-those
end_variable
begin_variable
var510
-1
2
above f15 f56
none-of-those
end_variable
begin_variable
var511
-1
2
above f15 f57
none-of-those
end_variable
begin_variable
var512
-1
2
above f15 f58
none-of-those
end_variable
begin_variable
var513
-1
2
above f15 f59
none-of-those
end_variable
begin_variable
var514
-1
2
above f15 f60
none-of-those
end_variable
begin_variable
var515
-1
2
above f15 f61
none-of-those
end_variable
begin_variable
var516
-1
2
above f15 f62
none-of-those
end_variable
begin_variable
var517
-1
2
above f15 f63
none-of-those
end_variable
begin_variable
var518
-1
2
above f15 f64
none-of-those
end_variable
begin_variable
var519
-1
2
above f15 f65
none-of-those
end_variable
begin_variable
var520
-1
2
above f15 f66
none-of-those
end_variable
begin_variable
var521
-1
2
above f15 f67
none-of-those
end_variable
begin_variable
var522
-1
2
above f15 f68
none-of-those
end_variable
begin_variable
var523
-1
2
above f15 f69
none-of-those
end_variable
begin_variable
var524
-1
2
above f15 f70
none-of-those
end_variable
begin_variable
var525
-1
2
above f15 f71
none-of-those
end_variable
begin_variable
var526
-1
2
above f15 f72
none-of-those
end_variable
begin_variable
var527
-1
2
above f15 f73
none-of-those
end_variable
begin_variable
var528
-1
2
above f15 f74
none-of-those
end_variable
begin_variable
var529
-1
2
above f15 f75
none-of-those
end_variable
begin_variable
var530
-1
2
above f15 f76
none-of-those
end_variable
begin_variable
var531
-1
2
above f15 f77
none-of-those
end_variable
begin_variable
var532
-1
2
above f15 f78
none-of-those
end_variable
begin_variable
var533
-1
2
above f15 f79
none-of-those
end_variable
begin_variable
var534
-1
2
above f15 f80
none-of-those
end_variable
begin_variable
var535
-1
2
above f16 f17
none-of-those
end_variable
begin_variable
var536
-1
2
above f16 f18
none-of-those
end_variable
begin_variable
var537
-1
2
above f16 f19
none-of-those
end_variable
begin_variable
var538
-1
2
above f16 f20
none-of-those
end_variable
begin_variable
var539
-1
2
above f16 f21
none-of-those
end_variable
begin_variable
var540
-1
2
above f16 f22
none-of-those
end_variable
begin_variable
var541
-1
2
above f16 f23
none-of-those
end_variable
begin_variable
var542
-1
2
above f16 f24
none-of-those
end_variable
begin_variable
var543
-1
2
above f16 f25
none-of-those
end_variable
begin_variable
var544
-1
2
above f16 f26
none-of-those
end_variable
begin_variable
var545
-1
2
above f16 f27
none-of-those
end_variable
begin_variable
var546
-1
2
above f16 f28
none-of-those
end_variable
begin_variable
var547
-1
2
above f16 f29
none-of-those
end_variable
begin_variable
var548
-1
2
above f16 f30
none-of-those
end_variable
begin_variable
var549
-1
2
above f16 f31
none-of-those
end_variable
begin_variable
var550
-1
2
above f16 f32
none-of-those
end_variable
begin_variable
var551
-1
2
above f16 f33
none-of-those
end_variable
begin_variable
var552
-1
2
above f16 f34
none-of-those
end_variable
begin_variable
var553
-1
2
above f16 f35
none-of-those
end_variable
begin_variable
var554
-1
2
above f16 f36
none-of-those
end_variable
begin_variable
var555
-1
2
above f16 f37
none-of-those
end_variable
begin_variable
var556
-1
2
above f16 f38
none-of-those
end_variable
begin_variable
var557
-1
2
above f16 f39
none-of-those
end_variable
begin_variable
var558
-1
2
above f16 f40
none-of-those
end_variable
begin_variable
var559
-1
2
above f16 f41
none-of-those
end_variable
begin_variable
var560
-1
2
above f16 f42
none-of-those
end_variable
begin_variable
var561
-1
2
above f16 f43
none-of-those
end_variable
begin_variable
var562
-1
2
above f16 f44
none-of-those
end_variable
begin_variable
var563
-1
2
above f16 f45
none-of-those
end_variable
begin_variable
var564
-1
2
above f16 f46
none-of-those
end_variable
begin_variable
var565
-1
2
above f16 f47
none-of-those
end_variable
begin_variable
var566
-1
2
above f16 f48
none-of-those
end_variable
begin_variable
var567
-1
2
above f16 f49
none-of-those
end_variable
begin_variable
var568
-1
2
above f16 f50
none-of-those
end_variable
begin_variable
var569
-1
2
above f16 f51
none-of-those
end_variable
begin_variable
var570
-1
2
above f16 f52
none-of-those
end_variable
begin_variable
var571
-1
2
above f16 f53
none-of-those
end_variable
begin_variable
var572
-1
2
above f16 f54
none-of-those
end_variable
begin_variable
var573
-1
2
above f16 f55
none-of-those
end_variable
begin_variable
var574
-1
2
above f16 f56
none-of-those
end_variable
begin_variable
var575
-1
2
above f16 f57
none-of-those
end_variable
begin_variable
var576
-1
2
above f16 f58
none-of-those
end_variable
begin_variable
var577
-1
2
above f16 f59
none-of-those
end_variable
begin_variable
var578
-1
2
above f16 f60
none-of-those
end_variable
begin_variable
var579
-1
2
above f16 f61
none-of-those
end_variable
begin_variable
var580
-1
2
above f16 f62
none-of-those
end_variable
begin_variable
var581
-1
2
above f16 f63
none-of-those
end_variable
begin_variable
var582
-1
2
above f16 f64
none-of-those
end_variable
begin_variable
var583
-1
2
above f16 f65
none-of-those
end_variable
begin_variable
var584
-1
2
above f16 f66
none-of-those
end_variable
begin_variable
var585
-1
2
above f16 f67
none-of-those
end_variable
begin_variable
var586
-1
2
above f16 f68
none-of-those
end_variable
begin_variable
var587
-1
2
above f16 f69
none-of-those
end_variable
begin_variable
var588
-1
2
above f16 f70
none-of-those
end_variable
begin_variable
var589
-1
2
above f16 f71
none-of-those
end_variable
begin_variable
var590
-1
2
above f16 f72
none-of-those
end_variable
begin_variable
var591
-1
2
above f16 f73
none-of-those
end_variable
begin_variable
var592
-1
2
above f16 f74
none-of-those
end_variable
begin_variable
var593
-1
2
above f16 f75
none-of-those
end_variable
begin_variable
var594
-1
2
above f16 f76
none-of-those
end_variable
begin_variable
var595
-1
2
above f16 f77
none-of-those
end_variable
begin_variable
var596
-1
2
above f16 f78
none-of-those
end_variable
begin_variable
var597
-1
2
above f16 f79
none-of-those
end_variable
begin_variable
var598
-1
2
above f16 f80
none-of-those
end_variable
begin_variable
var599
-1
2
above f17 f18
none-of-those
end_variable
begin_variable
var600
-1
2
above f17 f19
none-of-those
end_variable
begin_variable
var601
-1
2
above f17 f20
none-of-those
end_variable
begin_variable
var602
-1
2
above f17 f21
none-of-those
end_variable
begin_variable
var603
-1
2
above f17 f22
none-of-those
end_variable
begin_variable
var604
-1
2
above f17 f23
none-of-those
end_variable
begin_variable
var605
-1
2
above f17 f24
none-of-those
end_variable
begin_variable
var606
-1
2
above f17 f25
none-of-those
end_variable
begin_variable
var607
-1
2
above f17 f26
none-of-those
end_variable
begin_variable
var608
-1
2
above f17 f27
none-of-those
end_variable
begin_variable
var609
-1
2
above f17 f28
none-of-those
end_variable
begin_variable
var610
-1
2
above f17 f29
none-of-those
end_variable
begin_variable
var611
-1
2
above f17 f30
none-of-those
end_variable
begin_variable
var612
-1
2
above f17 f31
none-of-those
end_variable
begin_variable
var613
-1
2
above f17 f32
none-of-those
end_variable
begin_variable
var614
-1
2
above f17 f33
none-of-those
end_variable
begin_variable
var615
-1
2
above f17 f34
none-of-those
end_variable
begin_variable
var616
-1
2
above f17 f35
none-of-those
end_variable
begin_variable
var617
-1
2
above f17 f36
none-of-those
end_variable
begin_variable
var618
-1
2
above f17 f37
none-of-those
end_variable
begin_variable
var619
-1
2
above f17 f38
none-of-those
end_variable
begin_variable
var620
-1
2
above f17 f39
none-of-those
end_variable
begin_variable
var621
-1
2
above f17 f40
none-of-those
end_variable
begin_variable
var622
-1
2
above f17 f41
none-of-those
end_variable
begin_variable
var623
-1
2
above f17 f42
none-of-those
end_variable
begin_variable
var624
-1
2
above f17 f43
none-of-those
end_variable
begin_variable
var625
-1
2
above f17 f44
none-of-those
end_variable
begin_variable
var626
-1
2
above f17 f45
none-of-those
end_variable
begin_variable
var627
-1
2
above f17 f46
none-of-those
end_variable
begin_variable
var628
-1
2
above f17 f47
none-of-those
end_variable
begin_variable
var629
-1
2
above f17 f48
none-of-those
end_variable
begin_variable
var630
-1
2
above f17 f49
none-of-those
end_variable
begin_variable
var631
-1
2
above f17 f50
none-of-those
end_variable
begin_variable
var632
-1
2
above f17 f51
none-of-those
end_variable
begin_variable
var633
-1
2
above f17 f52
none-of-those
end_variable
begin_variable
var634
-1
2
above f17 f53
none-of-those
end_variable
begin_variable
var635
-1
2
above f17 f54
none-of-those
end_variable
begin_variable
var636
-1
2
above f17 f55
none-of-those
end_variable
begin_variable
var637
-1
2
above f17 f56
none-of-those
end_variable
begin_variable
var638
-1
2
above f17 f57
none-of-those
end_variable
begin_variable
var639
-1
2
above f17 f58
none-of-those
end_variable
begin_variable
var640
-1
2
above f17 f59
none-of-those
end_variable
begin_variable
var641
-1
2
above f17 f60
none-of-those
end_variable
begin_variable
var642
-1
2
above f17 f61
none-of-those
end_variable
begin_variable
var643
-1
2
above f17 f62
none-of-those
end_variable
begin_variable
var644
-1
2
above f17 f63
none-of-those
end_variable
begin_variable
var645
-1
2
above f17 f64
none-of-those
end_variable
begin_variable
var646
-1
2
above f17 f65
none-of-those
end_variable
begin_variable
var647
-1
2
above f17 f66
none-of-those
end_variable
begin_variable
var648
-1
2
above f17 f67
none-of-those
end_variable
begin_variable
var649
-1
2
above f17 f68
none-of-those
end_variable
begin_variable
var650
-1
2
above f17 f69
none-of-those
end_variable
begin_variable
var651
-1
2
above f17 f70
none-of-those
end_variable
begin_variable
var652
-1
2
above f17 f71
none-of-those
end_variable
begin_variable
var653
-1
2
above f17 f72
none-of-those
end_variable
begin_variable
var654
-1
2
above f17 f73
none-of-those
end_variable
begin_variable
var655
-1
2
above f17 f74
none-of-those
end_variable
begin_variable
var656
-1
2
above f17 f75
none-of-those
end_variable
begin_variable
var657
-1
2
above f17 f76
none-of-those
end_variable
begin_variable
var658
-1
2
above f17 f77
none-of-those
end_variable
begin_variable
var659
-1
2
above f17 f78
none-of-those
end_variable
begin_variable
var660
-1
2
above f17 f79
none-of-those
end_variable
begin_variable
var661
-1
2
above f17 f80
none-of-those
end_variable
begin_variable
var662
-1
2
above f18 f19
none-of-those
end_variable
begin_variable
var663
-1
2
above f18 f20
none-of-those
end_variable
begin_variable
var664
-1
2
above f18 f21
none-of-those
end_variable
begin_variable
var665
-1
2
above f18 f22
none-of-those
end_variable
begin_variable
var666
-1
2
above f18 f23
none-of-those
end_variable
begin_variable
var667
-1
2
above f18 f24
none-of-those
end_variable
begin_variable
var668
-1
2
above f18 f25
none-of-those
end_variable
begin_variable
var669
-1
2
above f18 f26
none-of-those
end_variable
begin_variable
var670
-1
2
above f18 f27
none-of-those
end_variable
begin_variable
var671
-1
2
above f18 f28
none-of-those
end_variable
begin_variable
var672
-1
2
above f18 f29
none-of-those
end_variable
begin_variable
var673
-1
2
above f18 f30
none-of-those
end_variable
begin_variable
var674
-1
2
above f18 f31
none-of-those
end_variable
begin_variable
var675
-1
2
above f18 f32
none-of-those
end_variable
begin_variable
var676
-1
2
above f18 f33
none-of-those
end_variable
begin_variable
var677
-1
2
above f18 f34
none-of-those
end_variable
begin_variable
var678
-1
2
above f18 f35
none-of-those
end_variable
begin_variable
var679
-1
2
above f18 f36
none-of-those
end_variable
begin_variable
var680
-1
2
above f18 f37
none-of-those
end_variable
begin_variable
var681
-1
2
above f18 f38
none-of-those
end_variable
begin_variable
var682
-1
2
above f18 f39
none-of-those
end_variable
begin_variable
var683
-1
2
above f18 f40
none-of-those
end_variable
begin_variable
var684
-1
2
above f18 f41
none-of-those
end_variable
begin_variable
var685
-1
2
above f18 f42
none-of-those
end_variable
begin_variable
var686
-1
2
above f18 f43
none-of-those
end_variable
begin_variable
var687
-1
2
above f18 f44
none-of-those
end_variable
begin_variable
var688
-1
2
above f18 f45
none-of-those
end_variable
begin_variable
var689
-1
2
above f18 f46
none-of-those
end_variable
begin_variable
var690
-1
2
above f18 f47
none-of-those
end_variable
begin_variable
var691
-1
2
above f18 f48
none-of-those
end_variable
begin_variable
var692
-1
2
above f18 f49
none-of-those
end_variable
begin_variable
var693
-1
2
above f18 f50
none-of-those
end_variable
begin_variable
var694
-1
2
above f18 f51
none-of-those
end_variable
begin_variable
var695
-1
2
above f18 f52
none-of-those
end_variable
begin_variable
var696
-1
2
above f18 f53
none-of-those
end_variable
begin_variable
var697
-1
2
above f18 f54
none-of-those
end_variable
begin_variable
var698
-1
2
above f18 f55
none-of-those
end_variable
begin_variable
var699
-1
2
above f18 f56
none-of-those
end_variable
begin_variable
var700
-1
2
above f18 f57
none-of-those
end_variable
begin_variable
var701
-1
2
above f18 f58
none-of-those
end_variable
begin_variable
var702
-1
2
above f18 f59
none-of-those
end_variable
begin_variable
var703
-1
2
above f18 f60
none-of-those
end_variable
begin_variable
var704
-1
2
above f18 f61
none-of-those
end_variable
begin_variable
var705
-1
2
above f18 f62
none-of-those
end_variable
begin_variable
var706
-1
2
above f18 f63
none-of-those
end_variable
begin_variable
var707
-1
2
above f18 f64
none-of-those
end_variable
begin_variable
var708
-1
2
above f18 f65
none-of-those
end_variable
begin_variable
var709
-1
2
above f18 f66
none-of-those
end_variable
begin_variable
var710
-1
2
above f18 f67
none-of-those
end_variable
begin_variable
var711
-1
2
above f18 f68
none-of-those
end_variable
begin_variable
var712
-1
2
above f18 f69
none-of-those
end_variable
begin_variable
var713
-1
2
above f18 f70
none-of-those
end_variable
begin_variable
var714
-1
2
above f18 f71
none-of-those
end_variable
begin_variable
var715
-1
2
above f18 f72
none-of-those
end_variable
begin_variable
var716
-1
2
above f18 f73
none-of-those
end_variable
begin_variable
var717
-1
2
above f18 f74
none-of-those
end_variable
begin_variable
var718
-1
2
above f18 f75
none-of-those
end_variable
begin_variable
var719
-1
2
above f18 f76
none-of-those
end_variable
begin_variable
var720
-1
2
above f18 f77
none-of-those
end_variable
begin_variable
var721
-1
2
above f18 f78
none-of-those
end_variable
begin_variable
var722
-1
2
above f18 f79
none-of-those
end_variable
begin_variable
var723
-1
2
above f18 f80
none-of-those
end_variable
begin_variable
var724
-1
2
above f19 f20
none-of-those
end_variable
begin_variable
var725
-1
2
above f19 f21
none-of-those
end_variable
begin_variable
var726
-1
2
above f19 f22
none-of-those
end_variable
begin_variable
var727
-1
2
above f19 f23
none-of-those
end_variable
begin_variable
var728
-1
2
above f19 f24
none-of-those
end_variable
begin_variable
var729
-1
2
above f19 f25
none-of-those
end_variable
begin_variable
var730
-1
2
above f19 f26
none-of-those
end_variable
begin_variable
var731
-1
2
above f19 f27
none-of-those
end_variable
begin_variable
var732
-1
2
above f19 f28
none-of-those
end_variable
begin_variable
var733
-1
2
above f19 f29
none-of-those
end_variable
begin_variable
var734
-1
2
above f19 f30
none-of-those
end_variable
begin_variable
var735
-1
2
above f19 f31
none-of-those
end_variable
begin_variable
var736
-1
2
above f19 f32
none-of-those
end_variable
begin_variable
var737
-1
2
above f19 f33
none-of-those
end_variable
begin_variable
var738
-1
2
above f19 f34
none-of-those
end_variable
begin_variable
var739
-1
2
above f19 f35
none-of-those
end_variable
begin_variable
var740
-1
2
above f19 f36
none-of-those
end_variable
begin_variable
var741
-1
2
above f19 f37
none-of-those
end_variable
begin_variable
var742
-1
2
above f19 f38
none-of-those
end_variable
begin_variable
var743
-1
2
above f19 f39
none-of-those
end_variable
begin_variable
var744
-1
2
above f19 f40
none-of-those
end_variable
begin_variable
var745
-1
2
above f19 f41
none-of-those
end_variable
begin_variable
var746
-1
2
above f19 f42
none-of-those
end_variable
begin_variable
var747
-1
2
above f19 f43
none-of-those
end_variable
begin_variable
var748
-1
2
above f19 f44
none-of-those
end_variable
begin_variable
var749
-1
2
above f19 f45
none-of-those
end_variable
begin_variable
var750
-1
2
above f19 f46
none-of-those
end_variable
begin_variable
var751
-1
2
above f19 f47
none-of-those
end_variable
begin_variable
var752
-1
2
above f19 f48
none-of-those
end_variable
begin_variable
var753
-1
2
above f19 f49
none-of-those
end_variable
begin_variable
var754
-1
2
above f19 f50
none-of-those
end_variable
begin_variable
var755
-1
2
above f19 f51
none-of-those
end_variable
begin_variable
var756
-1
2
above f19 f52
none-of-those
end_variable
begin_variable
var757
-1
2
above f19 f53
none-of-those
end_variable
begin_variable
var758
-1
2
above f19 f54
none-of-those
end_variable
begin_variable
var759
-1
2
above f19 f55
none-of-those
end_variable
begin_variable
var760
-1
2
above f19 f56
none-of-those
end_variable
begin_variable
var761
-1
2
above f19 f57
none-of-those
end_variable
begin_variable
var762
-1
2
above f19 f58
none-of-those
end_variable
begin_variable
var763
-1
2
above f19 f59
none-of-those
end_variable
begin_variable
var764
-1
2
above f19 f60
none-of-those
end_variable
begin_variable
var765
-1
2
above f19 f61
none-of-those
end_variable
begin_variable
var766
-1
2
above f19 f62
none-of-those
end_variable
begin_variable
var767
-1
2
above f19 f63
none-of-those
end_variable
begin_variable
var768
-1
2
above f19 f64
none-of-those
end_variable
begin_variable
var769
-1
2
above f19 f65
none-of-those
end_variable
begin_variable
var770
-1
2
above f19 f66
none-of-those
end_variable
begin_variable
var771
-1
2
above f19 f67
none-of-those
end_variable
begin_variable
var772
-1
2
above f19 f68
none-of-those
end_variable
begin_variable
var773
-1
2
above f19 f69
none-of-those
end_variable
begin_variable
var774
-1
2
above f19 f70
none-of-those
end_variable
begin_variable
var775
-1
2
above f19 f71
none-of-those
end_variable
begin_variable
var776
-1
2
above f19 f72
none-of-those
end_variable
begin_variable
var777
-1
2
above f19 f73
none-of-those
end_variable
begin_variable
var778
-1
2
above f19 f74
none-of-those
end_variable
begin_variable
var779
-1
2
above f19 f75
none-of-those
end_variable
begin_variable
var780
-1
2
above f19 f76
none-of-those
end_variable
begin_variable
var781
-1
2
above f19 f77
none-of-those
end_variable
begin_variable
var782
-1
2
above f19 f78
none-of-those
end_variable
begin_variable
var783
-1
2
above f19 f79
none-of-those
end_variable
begin_variable
var784
-1
2
above f19 f80
none-of-those
end_variable
begin_variable
var785
-1
2
above f2 f10
none-of-those
end_variable
begin_variable
var786
-1
2
above f2 f11
none-of-those
end_variable
begin_variable
var787
-1
2
above f2 f12
none-of-those
end_variable
begin_variable
var788
-1
2
above f2 f13
none-of-those
end_variable
begin_variable
var789
-1
2
above f2 f14
none-of-those
end_variable
begin_variable
var790
-1
2
above f2 f15
none-of-those
end_variable
begin_variable
var791
-1
2
above f2 f16
none-of-those
end_variable
begin_variable
var792
-1
2
above f2 f17
none-of-those
end_variable
begin_variable
var793
-1
2
above f2 f18
none-of-those
end_variable
begin_variable
var794
-1
2
above f2 f19
none-of-those
end_variable
begin_variable
var795
-1
2
above f2 f20
none-of-those
end_variable
begin_variable
var796
-1
2
above f2 f21
none-of-those
end_variable
begin_variable
var797
-1
2
above f2 f22
none-of-those
end_variable
begin_variable
var798
-1
2
above f2 f23
none-of-those
end_variable
begin_variable
var799
-1
2
above f2 f24
none-of-those
end_variable
begin_variable
var800
-1
2
above f2 f25
none-of-those
end_variable
begin_variable
var801
-1
2
above f2 f26
none-of-those
end_variable
begin_variable
var802
-1
2
above f2 f27
none-of-those
end_variable
begin_variable
var803
-1
2
above f2 f28
none-of-those
end_variable
begin_variable
var804
-1
2
above f2 f29
none-of-those
end_variable
begin_variable
var805
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var806
-1
2
above f2 f30
none-of-those
end_variable
begin_variable
var807
-1
2
above f2 f31
none-of-those
end_variable
begin_variable
var808
-1
2
above f2 f32
none-of-those
end_variable
begin_variable
var809
-1
2
above f2 f33
none-of-those
end_variable
begin_variable
var810
-1
2
above f2 f34
none-of-those
end_variable
begin_variable
var811
-1
2
above f2 f35
none-of-those
end_variable
begin_variable
var812
-1
2
above f2 f36
none-of-those
end_variable
begin_variable
var813
-1
2
above f2 f37
none-of-those
end_variable
begin_variable
var814
-1
2
above f2 f38
none-of-those
end_variable
begin_variable
var815
-1
2
above f2 f39
none-of-those
end_variable
begin_variable
var816
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var817
-1
2
above f2 f40
none-of-those
end_variable
begin_variable
var818
-1
2
above f2 f41
none-of-those
end_variable
begin_variable
var819
-1
2
above f2 f42
none-of-those
end_variable
begin_variable
var820
-1
2
above f2 f43
none-of-those
end_variable
begin_variable
var821
-1
2
above f2 f44
none-of-those
end_variable
begin_variable
var822
-1
2
above f2 f45
none-of-those
end_variable
begin_variable
var823
-1
2
above f2 f46
none-of-those
end_variable
begin_variable
var824
-1
2
above f2 f47
none-of-those
end_variable
begin_variable
var825
-1
2
above f2 f48
none-of-those
end_variable
begin_variable
var826
-1
2
above f2 f49
none-of-those
end_variable
begin_variable
var827
-1
2
above f2 f5
none-of-those
end_variable
begin_variable
var828
-1
2
above f2 f50
none-of-those
end_variable
begin_variable
var829
-1
2
above f2 f51
none-of-those
end_variable
begin_variable
var830
-1
2
above f2 f52
none-of-those
end_variable
begin_variable
var831
-1
2
above f2 f53
none-of-those
end_variable
begin_variable
var832
-1
2
above f2 f54
none-of-those
end_variable
begin_variable
var833
-1
2
above f2 f55
none-of-those
end_variable
begin_variable
var834
-1
2
above f2 f56
none-of-those
end_variable
begin_variable
var835
-1
2
above f2 f57
none-of-those
end_variable
begin_variable
var836
-1
2
above f2 f58
none-of-those
end_variable
begin_variable
var837
-1
2
above f2 f59
none-of-those
end_variable
begin_variable
var838
-1
2
above f2 f6
none-of-those
end_variable
begin_variable
var839
-1
2
above f2 f60
none-of-those
end_variable
begin_variable
var840
-1
2
above f2 f61
none-of-those
end_variable
begin_variable
var841
-1
2
above f2 f62
none-of-those
end_variable
begin_variable
var842
-1
2
above f2 f63
none-of-those
end_variable
begin_variable
var843
-1
2
above f2 f64
none-of-those
end_variable
begin_variable
var844
-1
2
above f2 f65
none-of-those
end_variable
begin_variable
var845
-1
2
above f2 f66
none-of-those
end_variable
begin_variable
var846
-1
2
above f2 f67
none-of-those
end_variable
begin_variable
var847
-1
2
above f2 f68
none-of-those
end_variable
begin_variable
var848
-1
2
above f2 f69
none-of-those
end_variable
begin_variable
var849
-1
2
above f2 f7
none-of-those
end_variable
begin_variable
var850
-1
2
above f2 f70
none-of-those
end_variable
begin_variable
var851
-1
2
above f2 f71
none-of-those
end_variable
begin_variable
var852
-1
2
above f2 f72
none-of-those
end_variable
begin_variable
var853
-1
2
above f2 f73
none-of-those
end_variable
begin_variable
var854
-1
2
above f2 f74
none-of-those
end_variable
begin_variable
var855
-1
2
above f2 f75
none-of-those
end_variable
begin_variable
var856
-1
2
above f2 f76
none-of-those
end_variable
begin_variable
var857
-1
2
above f2 f77
none-of-those
end_variable
begin_variable
var858
-1
2
above f2 f78
none-of-those
end_variable
begin_variable
var859
-1
2
above f2 f79
none-of-those
end_variable
begin_variable
var860
-1
2
above f2 f8
none-of-those
end_variable
begin_variable
var861
-1
2
above f2 f80
none-of-those
end_variable
begin_variable
var862
-1
2
above f2 f9
none-of-those
end_variable
begin_variable
var863
-1
2
above f20 f21
none-of-those
end_variable
begin_variable
var864
-1
2
above f20 f22
none-of-those
end_variable
begin_variable
var865
-1
2
above f20 f23
none-of-those
end_variable
begin_variable
var866
-1
2
above f20 f24
none-of-those
end_variable
begin_variable
var867
-1
2
above f20 f25
none-of-those
end_variable
begin_variable
var868
-1
2
above f20 f26
none-of-those
end_variable
begin_variable
var869
-1
2
above f20 f27
none-of-those
end_variable
begin_variable
var870
-1
2
above f20 f28
none-of-those
end_variable
begin_variable
var871
-1
2
above f20 f29
none-of-those
end_variable
begin_variable
var872
-1
2
above f20 f30
none-of-those
end_variable
begin_variable
var873
-1
2
above f20 f31
none-of-those
end_variable
begin_variable
var874
-1
2
above f20 f32
none-of-those
end_variable
begin_variable
var875
-1
2
above f20 f33
none-of-those
end_variable
begin_variable
var876
-1
2
above f20 f34
none-of-those
end_variable
begin_variable
var877
-1
2
above f20 f35
none-of-those
end_variable
begin_variable
var878
-1
2
above f20 f36
none-of-those
end_variable
begin_variable
var879
-1
2
above f20 f37
none-of-those
end_variable
begin_variable
var880
-1
2
above f20 f38
none-of-those
end_variable
begin_variable
var881
-1
2
above f20 f39
none-of-those
end_variable
begin_variable
var882
-1
2
above f20 f40
none-of-those
end_variable
begin_variable
var883
-1
2
above f20 f41
none-of-those
end_variable
begin_variable
var884
-1
2
above f20 f42
none-of-those
end_variable
begin_variable
var885
-1
2
above f20 f43
none-of-those
end_variable
begin_variable
var886
-1
2
above f20 f44
none-of-those
end_variable
begin_variable
var887
-1
2
above f20 f45
none-of-those
end_variable
begin_variable
var888
-1
2
above f20 f46
none-of-those
end_variable
begin_variable
var889
-1
2
above f20 f47
none-of-those
end_variable
begin_variable
var890
-1
2
above f20 f48
none-of-those
end_variable
begin_variable
var891
-1
2
above f20 f49
none-of-those
end_variable
begin_variable
var892
-1
2
above f20 f50
none-of-those
end_variable
begin_variable
var893
-1
2
above f20 f51
none-of-those
end_variable
begin_variable
var894
-1
2
above f20 f52
none-of-those
end_variable
begin_variable
var895
-1
2
above f20 f53
none-of-those
end_variable
begin_variable
var896
-1
2
above f20 f54
none-of-those
end_variable
begin_variable
var897
-1
2
above f20 f55
none-of-those
end_variable
begin_variable
var898
-1
2
above f20 f56
none-of-those
end_variable
begin_variable
var899
-1
2
above f20 f57
none-of-those
end_variable
begin_variable
var900
-1
2
above f20 f58
none-of-those
end_variable
begin_variable
var901
-1
2
above f20 f59
none-of-those
end_variable
begin_variable
var902
-1
2
above f20 f60
none-of-those
end_variable
begin_variable
var903
-1
2
above f20 f61
none-of-those
end_variable
begin_variable
var904
-1
2
above f20 f62
none-of-those
end_variable
begin_variable
var905
-1
2
above f20 f63
none-of-those
end_variable
begin_variable
var906
-1
2
above f20 f64
none-of-those
end_variable
begin_variable
var907
-1
2
above f20 f65
none-of-those
end_variable
begin_variable
var908
-1
2
above f20 f66
none-of-those
end_variable
begin_variable
var909
-1
2
above f20 f67
none-of-those
end_variable
begin_variable
var910
-1
2
above f20 f68
none-of-those
end_variable
begin_variable
var911
-1
2
above f20 f69
none-of-those
end_variable
begin_variable
var912
-1
2
above f20 f70
none-of-those
end_variable
begin_variable
var913
-1
2
above f20 f71
none-of-those
end_variable
begin_variable
var914
-1
2
above f20 f72
none-of-those
end_variable
begin_variable
var915
-1
2
above f20 f73
none-of-those
end_variable
begin_variable
var916
-1
2
above f20 f74
none-of-those
end_variable
begin_variable
var917
-1
2
above f20 f75
none-of-those
end_variable
begin_variable
var918
-1
2
above f20 f76
none-of-those
end_variable
begin_variable
var919
-1
2
above f20 f77
none-of-those
end_variable
begin_variable
var920
-1
2
above f20 f78
none-of-those
end_variable
begin_variable
var921
-1
2
above f20 f79
none-of-those
end_variable
begin_variable
var922
-1
2
above f20 f80
none-of-those
end_variable
begin_variable
var923
-1
2
above f21 f22
none-of-those
end_variable
begin_variable
var924
-1
2
above f21 f23
none-of-those
end_variable
begin_variable
var925
-1
2
above f21 f24
none-of-those
end_variable
begin_variable
var926
-1
2
above f21 f25
none-of-those
end_variable
begin_variable
var927
-1
2
above f21 f26
none-of-those
end_variable
begin_variable
var928
-1
2
above f21 f27
none-of-those
end_variable
begin_variable
var929
-1
2
above f21 f28
none-of-those
end_variable
begin_variable
var930
-1
2
above f21 f29
none-of-those
end_variable
begin_variable
var931
-1
2
above f21 f30
none-of-those
end_variable
begin_variable
var932
-1
2
above f21 f31
none-of-those
end_variable
begin_variable
var933
-1
2
above f21 f32
none-of-those
end_variable
begin_variable
var934
-1
2
above f21 f33
none-of-those
end_variable
begin_variable
var935
-1
2
above f21 f34
none-of-those
end_variable
begin_variable
var936
-1
2
above f21 f35
none-of-those
end_variable
begin_variable
var937
-1
2
above f21 f36
none-of-those
end_variable
begin_variable
var938
-1
2
above f21 f37
none-of-those
end_variable
begin_variable
var939
-1
2
above f21 f38
none-of-those
end_variable
begin_variable
var940
-1
2
above f21 f39
none-of-those
end_variable
begin_variable
var941
-1
2
above f21 f40
none-of-those
end_variable
begin_variable
var942
-1
2
above f21 f41
none-of-those
end_variable
begin_variable
var943
-1
2
above f21 f42
none-of-those
end_variable
begin_variable
var944
-1
2
above f21 f43
none-of-those
end_variable
begin_variable
var945
-1
2
above f21 f44
none-of-those
end_variable
begin_variable
var946
-1
2
above f21 f45
none-of-those
end_variable
begin_variable
var947
-1
2
above f21 f46
none-of-those
end_variable
begin_variable
var948
-1
2
above f21 f47
none-of-those
end_variable
begin_variable
var949
-1
2
above f21 f48
none-of-those
end_variable
begin_variable
var950
-1
2
above f21 f49
none-of-those
end_variable
begin_variable
var951
-1
2
above f21 f50
none-of-those
end_variable
begin_variable
var952
-1
2
above f21 f51
none-of-those
end_variable
begin_variable
var953
-1
2
above f21 f52
none-of-those
end_variable
begin_variable
var954
-1
2
above f21 f53
none-of-those
end_variable
begin_variable
var955
-1
2
above f21 f54
none-of-those
end_variable
begin_variable
var956
-1
2
above f21 f55
none-of-those
end_variable
begin_variable
var957
-1
2
above f21 f56
none-of-those
end_variable
begin_variable
var958
-1
2
above f21 f57
none-of-those
end_variable
begin_variable
var959
-1
2
above f21 f58
none-of-those
end_variable
begin_variable
var960
-1
2
above f21 f59
none-of-those
end_variable
begin_variable
var961
-1
2
above f21 f60
none-of-those
end_variable
begin_variable
var962
-1
2
above f21 f61
none-of-those
end_variable
begin_variable
var963
-1
2
above f21 f62
none-of-those
end_variable
begin_variable
var964
-1
2
above f21 f63
none-of-those
end_variable
begin_variable
var965
-1
2
above f21 f64
none-of-those
end_variable
begin_variable
var966
-1
2
above f21 f65
none-of-those
end_variable
begin_variable
var967
-1
2
above f21 f66
none-of-those
end_variable
begin_variable
var968
-1
2
above f21 f67
none-of-those
end_variable
begin_variable
var969
-1
2
above f21 f68
none-of-those
end_variable
begin_variable
var970
-1
2
above f21 f69
none-of-those
end_variable
begin_variable
var971
-1
2
above f21 f70
none-of-those
end_variable
begin_variable
var972
-1
2
above f21 f71
none-of-those
end_variable
begin_variable
var973
-1
2
above f21 f72
none-of-those
end_variable
begin_variable
var974
-1
2
above f21 f73
none-of-those
end_variable
begin_variable
var975
-1
2
above f21 f74
none-of-those
end_variable
begin_variable
var976
-1
2
above f21 f75
none-of-those
end_variable
begin_variable
var977
-1
2
above f21 f76
none-of-those
end_variable
begin_variable
var978
-1
2
above f21 f77
none-of-those
end_variable
begin_variable
var979
-1
2
above f21 f78
none-of-those
end_variable
begin_variable
var980
-1
2
above f21 f79
none-of-those
end_variable
begin_variable
var981
-1
2
above f21 f80
none-of-those
end_variable
begin_variable
var982
-1
2
above f22 f23
none-of-those
end_variable
begin_variable
var983
-1
2
above f22 f24
none-of-those
end_variable
begin_variable
var984
-1
2
above f22 f25
none-of-those
end_variable
begin_variable
var985
-1
2
above f22 f26
none-of-those
end_variable
begin_variable
var986
-1
2
above f22 f27
none-of-those
end_variable
begin_variable
var987
-1
2
above f22 f28
none-of-those
end_variable
begin_variable
var988
-1
2
above f22 f29
none-of-those
end_variable
begin_variable
var989
-1
2
above f22 f30
none-of-those
end_variable
begin_variable
var990
-1
2
above f22 f31
none-of-those
end_variable
begin_variable
var991
-1
2
above f22 f32
none-of-those
end_variable
begin_variable
var992
-1
2
above f22 f33
none-of-those
end_variable
begin_variable
var993
-1
2
above f22 f34
none-of-those
end_variable
begin_variable
var994
-1
2
above f22 f35
none-of-those
end_variable
begin_variable
var995
-1
2
above f22 f36
none-of-those
end_variable
begin_variable
var996
-1
2
above f22 f37
none-of-those
end_variable
begin_variable
var997
-1
2
above f22 f38
none-of-those
end_variable
begin_variable
var998
-1
2
above f22 f39
none-of-those
end_variable
begin_variable
var999
-1
2
above f22 f40
none-of-those
end_variable
begin_variable
var1000
-1
2
above f22 f41
none-of-those
end_variable
begin_variable
var1001
-1
2
above f22 f42
none-of-those
end_variable
begin_variable
var1002
-1
2
above f22 f43
none-of-those
end_variable
begin_variable
var1003
-1
2
above f22 f44
none-of-those
end_variable
begin_variable
var1004
-1
2
above f22 f45
none-of-those
end_variable
begin_variable
var1005
-1
2
above f22 f46
none-of-those
end_variable
begin_variable
var1006
-1
2
above f22 f47
none-of-those
end_variable
begin_variable
var1007
-1
2
above f22 f48
none-of-those
end_variable
begin_variable
var1008
-1
2
above f22 f49
none-of-those
end_variable
begin_variable
var1009
-1
2
above f22 f50
none-of-those
end_variable
begin_variable
var1010
-1
2
above f22 f51
none-of-those
end_variable
begin_variable
var1011
-1
2
above f22 f52
none-of-those
end_variable
begin_variable
var1012
-1
2
above f22 f53
none-of-those
end_variable
begin_variable
var1013
-1
2
above f22 f54
none-of-those
end_variable
begin_variable
var1014
-1
2
above f22 f55
none-of-those
end_variable
begin_variable
var1015
-1
2
above f22 f56
none-of-those
end_variable
begin_variable
var1016
-1
2
above f22 f57
none-of-those
end_variable
begin_variable
var1017
-1
2
above f22 f58
none-of-those
end_variable
begin_variable
var1018
-1
2
above f22 f59
none-of-those
end_variable
begin_variable
var1019
-1
2
above f22 f60
none-of-those
end_variable
begin_variable
var1020
-1
2
above f22 f61
none-of-those
end_variable
begin_variable
var1021
-1
2
above f22 f62
none-of-those
end_variable
begin_variable
var1022
-1
2
above f22 f63
none-of-those
end_variable
begin_variable
var1023
-1
2
above f22 f64
none-of-those
end_variable
begin_variable
var1024
-1
2
above f22 f65
none-of-those
end_variable
begin_variable
var1025
-1
2
above f22 f66
none-of-those
end_variable
begin_variable
var1026
-1
2
above f22 f67
none-of-those
end_variable
begin_variable
var1027
-1
2
above f22 f68
none-of-those
end_variable
begin_variable
var1028
-1
2
above f22 f69
none-of-those
end_variable
begin_variable
var1029
-1
2
above f22 f70
none-of-those
end_variable
begin_variable
var1030
-1
2
above f22 f71
none-of-those
end_variable
begin_variable
var1031
-1
2
above f22 f72
none-of-those
end_variable
begin_variable
var1032
-1
2
above f22 f73
none-of-those
end_variable
begin_variable
var1033
-1
2
above f22 f74
none-of-those
end_variable
begin_variable
var1034
-1
2
above f22 f75
none-of-those
end_variable
begin_variable
var1035
-1
2
above f22 f76
none-of-those
end_variable
begin_variable
var1036
-1
2
above f22 f77
none-of-those
end_variable
begin_variable
var1037
-1
2
above f22 f78
none-of-those
end_variable
begin_variable
var1038
-1
2
above f22 f79
none-of-those
end_variable
begin_variable
var1039
-1
2
above f22 f80
none-of-those
end_variable
begin_variable
var1040
-1
2
above f23 f24
none-of-those
end_variable
begin_variable
var1041
-1
2
above f23 f25
none-of-those
end_variable
begin_variable
var1042
-1
2
above f23 f26
none-of-those
end_variable
begin_variable
var1043
-1
2
above f23 f27
none-of-those
end_variable
begin_variable
var1044
-1
2
above f23 f28
none-of-those
end_variable
begin_variable
var1045
-1
2
above f23 f29
none-of-those
end_variable
begin_variable
var1046
-1
2
above f23 f30
none-of-those
end_variable
begin_variable
var1047
-1
2
above f23 f31
none-of-those
end_variable
begin_variable
var1048
-1
2
above f23 f32
none-of-those
end_variable
begin_variable
var1049
-1
2
above f23 f33
none-of-those
end_variable
begin_variable
var1050
-1
2
above f23 f34
none-of-those
end_variable
begin_variable
var1051
-1
2
above f23 f35
none-of-those
end_variable
begin_variable
var1052
-1
2
above f23 f36
none-of-those
end_variable
begin_variable
var1053
-1
2
above f23 f37
none-of-those
end_variable
begin_variable
var1054
-1
2
above f23 f38
none-of-those
end_variable
begin_variable
var1055
-1
2
above f23 f39
none-of-those
end_variable
begin_variable
var1056
-1
2
above f23 f40
none-of-those
end_variable
begin_variable
var1057
-1
2
above f23 f41
none-of-those
end_variable
begin_variable
var1058
-1
2
above f23 f42
none-of-those
end_variable
begin_variable
var1059
-1
2
above f23 f43
none-of-those
end_variable
begin_variable
var1060
-1
2
above f23 f44
none-of-those
end_variable
begin_variable
var1061
-1
2
above f23 f45
none-of-those
end_variable
begin_variable
var1062
-1
2
above f23 f46
none-of-those
end_variable
begin_variable
var1063
-1
2
above f23 f47
none-of-those
end_variable
begin_variable
var1064
-1
2
above f23 f48
none-of-those
end_variable
begin_variable
var1065
-1
2
above f23 f49
none-of-those
end_variable
begin_variable
var1066
-1
2
above f23 f50
none-of-those
end_variable
begin_variable
var1067
-1
2
above f23 f51
none-of-those
end_variable
begin_variable
var1068
-1
2
above f23 f52
none-of-those
end_variable
begin_variable
var1069
-1
2
above f23 f53
none-of-those
end_variable
begin_variable
var1070
-1
2
above f23 f54
none-of-those
end_variable
begin_variable
var1071
-1
2
above f23 f55
none-of-those
end_variable
begin_variable
var1072
-1
2
above f23 f56
none-of-those
end_variable
begin_variable
var1073
-1
2
above f23 f57
none-of-those
end_variable
begin_variable
var1074
-1
2
above f23 f58
none-of-those
end_variable
begin_variable
var1075
-1
2
above f23 f59
none-of-those
end_variable
begin_variable
var1076
-1
2
above f23 f60
none-of-those
end_variable
begin_variable
var1077
-1
2
above f23 f61
none-of-those
end_variable
begin_variable
var1078
-1
2
above f23 f62
none-of-those
end_variable
begin_variable
var1079
-1
2
above f23 f63
none-of-those
end_variable
begin_variable
var1080
-1
2
above f23 f64
none-of-those
end_variable
begin_variable
var1081
-1
2
above f23 f65
none-of-those
end_variable
begin_variable
var1082
-1
2
above f23 f66
none-of-those
end_variable
begin_variable
var1083
-1
2
above f23 f67
none-of-those
end_variable
begin_variable
var1084
-1
2
above f23 f68
none-of-those
end_variable
begin_variable
var1085
-1
2
above f23 f69
none-of-those
end_variable
begin_variable
var1086
-1
2
above f23 f70
none-of-those
end_variable
begin_variable
var1087
-1
2
above f23 f71
none-of-those
end_variable
begin_variable
var1088
-1
2
above f23 f72
none-of-those
end_variable
begin_variable
var1089
-1
2
above f23 f73
none-of-those
end_variable
begin_variable
var1090
-1
2
above f23 f74
none-of-those
end_variable
begin_variable
var1091
-1
2
above f23 f75
none-of-those
end_variable
begin_variable
var1092
-1
2
above f23 f76
none-of-those
end_variable
begin_variable
var1093
-1
2
above f23 f77
none-of-those
end_variable
begin_variable
var1094
-1
2
above f23 f78
none-of-those
end_variable
begin_variable
var1095
-1
2
above f23 f79
none-of-those
end_variable
begin_variable
var1096
-1
2
above f23 f80
none-of-those
end_variable
begin_variable
var1097
-1
2
above f24 f25
none-of-those
end_variable
begin_variable
var1098
-1
2
above f24 f26
none-of-those
end_variable
begin_variable
var1099
-1
2
above f24 f27
none-of-those
end_variable
begin_variable
var1100
-1
2
above f24 f28
none-of-those
end_variable
begin_variable
var1101
-1
2
above f24 f29
none-of-those
end_variable
begin_variable
var1102
-1
2
above f24 f30
none-of-those
end_variable
begin_variable
var1103
-1
2
above f24 f31
none-of-those
end_variable
begin_variable
var1104
-1
2
above f24 f32
none-of-those
end_variable
begin_variable
var1105
-1
2
above f24 f33
none-of-those
end_variable
begin_variable
var1106
-1
2
above f24 f34
none-of-those
end_variable
begin_variable
var1107
-1
2
above f24 f35
none-of-those
end_variable
begin_variable
var1108
-1
2
above f24 f36
none-of-those
end_variable
begin_variable
var1109
-1
2
above f24 f37
none-of-those
end_variable
begin_variable
var1110
-1
2
above f24 f38
none-of-those
end_variable
begin_variable
var1111
-1
2
above f24 f39
none-of-those
end_variable
begin_variable
var1112
-1
2
above f24 f40
none-of-those
end_variable
begin_variable
var1113
-1
2
above f24 f41
none-of-those
end_variable
begin_variable
var1114
-1
2
above f24 f42
none-of-those
end_variable
begin_variable
var1115
-1
2
above f24 f43
none-of-those
end_variable
begin_variable
var1116
-1
2
above f24 f44
none-of-those
end_variable
begin_variable
var1117
-1
2
above f24 f45
none-of-those
end_variable
begin_variable
var1118
-1
2
above f24 f46
none-of-those
end_variable
begin_variable
var1119
-1
2
above f24 f47
none-of-those
end_variable
begin_variable
var1120
-1
2
above f24 f48
none-of-those
end_variable
begin_variable
var1121
-1
2
above f24 f49
none-of-those
end_variable
begin_variable
var1122
-1
2
above f24 f50
none-of-those
end_variable
begin_variable
var1123
-1
2
above f24 f51
none-of-those
end_variable
begin_variable
var1124
-1
2
above f24 f52
none-of-those
end_variable
begin_variable
var1125
-1
2
above f24 f53
none-of-those
end_variable
begin_variable
var1126
-1
2
above f24 f54
none-of-those
end_variable
begin_variable
var1127
-1
2
above f24 f55
none-of-those
end_variable
begin_variable
var1128
-1
2
above f24 f56
none-of-those
end_variable
begin_variable
var1129
-1
2
above f24 f57
none-of-those
end_variable
begin_variable
var1130
-1
2
above f24 f58
none-of-those
end_variable
begin_variable
var1131
-1
2
above f24 f59
none-of-those
end_variable
begin_variable
var1132
-1
2
above f24 f60
none-of-those
end_variable
begin_variable
var1133
-1
2
above f24 f61
none-of-those
end_variable
begin_variable
var1134
-1
2
above f24 f62
none-of-those
end_variable
begin_variable
var1135
-1
2
above f24 f63
none-of-those
end_variable
begin_variable
var1136
-1
2
above f24 f64
none-of-those
end_variable
begin_variable
var1137
-1
2
above f24 f65
none-of-those
end_variable
begin_variable
var1138
-1
2
above f24 f66
none-of-those
end_variable
begin_variable
var1139
-1
2
above f24 f67
none-of-those
end_variable
begin_variable
var1140
-1
2
above f24 f68
none-of-those
end_variable
begin_variable
var1141
-1
2
above f24 f69
none-of-those
end_variable
begin_variable
var1142
-1
2
above f24 f70
none-of-those
end_variable
begin_variable
var1143
-1
2
above f24 f71
none-of-those
end_variable
begin_variable
var1144
-1
2
above f24 f72
none-of-those
end_variable
begin_variable
var1145
-1
2
above f24 f73
none-of-those
end_variable
begin_variable
var1146
-1
2
above f24 f74
none-of-those
end_variable
begin_variable
var1147
-1
2
above f24 f75
none-of-those
end_variable
begin_variable
var1148
-1
2
above f24 f76
none-of-those
end_variable
begin_variable
var1149
-1
2
above f24 f77
none-of-those
end_variable
begin_variable
var1150
-1
2
above f24 f78
none-of-those
end_variable
begin_variable
var1151
-1
2
above f24 f79
none-of-those
end_variable
begin_variable
var1152
-1
2
above f24 f80
none-of-those
end_variable
begin_variable
var1153
-1
2
above f25 f26
none-of-those
end_variable
begin_variable
var1154
-1
2
above f25 f27
none-of-those
end_variable
begin_variable
var1155
-1
2
above f25 f28
none-of-those
end_variable
begin_variable
var1156
-1
2
above f25 f29
none-of-those
end_variable
begin_variable
var1157
-1
2
above f25 f30
none-of-those
end_variable
begin_variable
var1158
-1
2
above f25 f31
none-of-those
end_variable
begin_variable
var1159
-1
2
above f25 f32
none-of-those
end_variable
begin_variable
var1160
-1
2
above f25 f33
none-of-those
end_variable
begin_variable
var1161
-1
2
above f25 f34
none-of-those
end_variable
begin_variable
var1162
-1
2
above f25 f35
none-of-those
end_variable
begin_variable
var1163
-1
2
above f25 f36
none-of-those
end_variable
begin_variable
var1164
-1
2
above f25 f37
none-of-those
end_variable
begin_variable
var1165
-1
2
above f25 f38
none-of-those
end_variable
begin_variable
var1166
-1
2
above f25 f39
none-of-those
end_variable
begin_variable
var1167
-1
2
above f25 f40
none-of-those
end_variable
begin_variable
var1168
-1
2
above f25 f41
none-of-those
end_variable
begin_variable
var1169
-1
2
above f25 f42
none-of-those
end_variable
begin_variable
var1170
-1
2
above f25 f43
none-of-those
end_variable
begin_variable
var1171
-1
2
above f25 f44
none-of-those
end_variable
begin_variable
var1172
-1
2
above f25 f45
none-of-those
end_variable
begin_variable
var1173
-1
2
above f25 f46
none-of-those
end_variable
begin_variable
var1174
-1
2
above f25 f47
none-of-those
end_variable
begin_variable
var1175
-1
2
above f25 f48
none-of-those
end_variable
begin_variable
var1176
-1
2
above f25 f49
none-of-those
end_variable
begin_variable
var1177
-1
2
above f25 f50
none-of-those
end_variable
begin_variable
var1178
-1
2
above f25 f51
none-of-those
end_variable
begin_variable
var1179
-1
2
above f25 f52
none-of-those
end_variable
begin_variable
var1180
-1
2
above f25 f53
none-of-those
end_variable
begin_variable
var1181
-1
2
above f25 f54
none-of-those
end_variable
begin_variable
var1182
-1
2
above f25 f55
none-of-those
end_variable
begin_variable
var1183
-1
2
above f25 f56
none-of-those
end_variable
begin_variable
var1184
-1
2
above f25 f57
none-of-those
end_variable
begin_variable
var1185
-1
2
above f25 f58
none-of-those
end_variable
begin_variable
var1186
-1
2
above f25 f59
none-of-those
end_variable
begin_variable
var1187
-1
2
above f25 f60
none-of-those
end_variable
begin_variable
var1188
-1
2
above f25 f61
none-of-those
end_variable
begin_variable
var1189
-1
2
above f25 f62
none-of-those
end_variable
begin_variable
var1190
-1
2
above f25 f63
none-of-those
end_variable
begin_variable
var1191
-1
2
above f25 f64
none-of-those
end_variable
begin_variable
var1192
-1
2
above f25 f65
none-of-those
end_variable
begin_variable
var1193
-1
2
above f25 f66
none-of-those
end_variable
begin_variable
var1194
-1
2
above f25 f67
none-of-those
end_variable
begin_variable
var1195
-1
2
above f25 f68
none-of-those
end_variable
begin_variable
var1196
-1
2
above f25 f69
none-of-those
end_variable
begin_variable
var1197
-1
2
above f25 f70
none-of-those
end_variable
begin_variable
var1198
-1
2
above f25 f71
none-of-those
end_variable
begin_variable
var1199
-1
2
above f25 f72
none-of-those
end_variable
begin_variable
var1200
-1
2
above f25 f73
none-of-those
end_variable
begin_variable
var1201
-1
2
above f25 f74
none-of-those
end_variable
begin_variable
var1202
-1
2
above f25 f75
none-of-those
end_variable
begin_variable
var1203
-1
2
above f25 f76
none-of-those
end_variable
begin_variable
var1204
-1
2
above f25 f77
none-of-those
end_variable
begin_variable
var1205
-1
2
above f25 f78
none-of-those
end_variable
begin_variable
var1206
-1
2
above f25 f79
none-of-those
end_variable
begin_variable
var1207
-1
2
above f25 f80
none-of-those
end_variable
begin_variable
var1208
-1
2
above f26 f27
none-of-those
end_variable
begin_variable
var1209
-1
2
above f26 f28
none-of-those
end_variable
begin_variable
var1210
-1
2
above f26 f29
none-of-those
end_variable
begin_variable
var1211
-1
2
above f26 f30
none-of-those
end_variable
begin_variable
var1212
-1
2
above f26 f31
none-of-those
end_variable
begin_variable
var1213
-1
2
above f26 f32
none-of-those
end_variable
begin_variable
var1214
-1
2
above f26 f33
none-of-those
end_variable
begin_variable
var1215
-1
2
above f26 f34
none-of-those
end_variable
begin_variable
var1216
-1
2
above f26 f35
none-of-those
end_variable
begin_variable
var1217
-1
2
above f26 f36
none-of-those
end_variable
begin_variable
var1218
-1
2
above f26 f37
none-of-those
end_variable
begin_variable
var1219
-1
2
above f26 f38
none-of-those
end_variable
begin_variable
var1220
-1
2
above f26 f39
none-of-those
end_variable
begin_variable
var1221
-1
2
above f26 f40
none-of-those
end_variable
begin_variable
var1222
-1
2
above f26 f41
none-of-those
end_variable
begin_variable
var1223
-1
2
above f26 f42
none-of-those
end_variable
begin_variable
var1224
-1
2
above f26 f43
none-of-those
end_variable
begin_variable
var1225
-1
2
above f26 f44
none-of-those
end_variable
begin_variable
var1226
-1
2
above f26 f45
none-of-those
end_variable
begin_variable
var1227
-1
2
above f26 f46
none-of-those
end_variable
begin_variable
var1228
-1
2
above f26 f47
none-of-those
end_variable
begin_variable
var1229
-1
2
above f26 f48
none-of-those
end_variable
begin_variable
var1230
-1
2
above f26 f49
none-of-those
end_variable
begin_variable
var1231
-1
2
above f26 f50
none-of-those
end_variable
begin_variable
var1232
-1
2
above f26 f51
none-of-those
end_variable
begin_variable
var1233
-1
2
above f26 f52
none-of-those
end_variable
begin_variable
var1234
-1
2
above f26 f53
none-of-those
end_variable
begin_variable
var1235
-1
2
above f26 f54
none-of-those
end_variable
begin_variable
var1236
-1
2
above f26 f55
none-of-those
end_variable
begin_variable
var1237
-1
2
above f26 f56
none-of-those
end_variable
begin_variable
var1238
-1
2
above f26 f57
none-of-those
end_variable
begin_variable
var1239
-1
2
above f26 f58
none-of-those
end_variable
begin_variable
var1240
-1
2
above f26 f59
none-of-those
end_variable
begin_variable
var1241
-1
2
above f26 f60
none-of-those
end_variable
begin_variable
var1242
-1
2
above f26 f61
none-of-those
end_variable
begin_variable
var1243
-1
2
above f26 f62
none-of-those
end_variable
begin_variable
var1244
-1
2
above f26 f63
none-of-those
end_variable
begin_variable
var1245
-1
2
above f26 f64
none-of-those
end_variable
begin_variable
var1246
-1
2
above f26 f65
none-of-those
end_variable
begin_variable
var1247
-1
2
above f26 f66
none-of-those
end_variable
begin_variable
var1248
-1
2
above f26 f67
none-of-those
end_variable
begin_variable
var1249
-1
2
above f26 f68
none-of-those
end_variable
begin_variable
var1250
-1
2
above f26 f69
none-of-those
end_variable
begin_variable
var1251
-1
2
above f26 f70
none-of-those
end_variable
begin_variable
var1252
-1
2
above f26 f71
none-of-those
end_variable
begin_variable
var1253
-1
2
above f26 f72
none-of-those
end_variable
begin_variable
var1254
-1
2
above f26 f73
none-of-those
end_variable
begin_variable
var1255
-1
2
above f26 f74
none-of-those
end_variable
begin_variable
var1256
-1
2
above f26 f75
none-of-those
end_variable
begin_variable
var1257
-1
2
above f26 f76
none-of-those
end_variable
begin_variable
var1258
-1
2
above f26 f77
none-of-those
end_variable
begin_variable
var1259
-1
2
above f26 f78
none-of-those
end_variable
begin_variable
var1260
-1
2
above f26 f79
none-of-those
end_variable
begin_variable
var1261
-1
2
above f26 f80
none-of-those
end_variable
begin_variable
var1262
-1
2
above f27 f28
none-of-those
end_variable
begin_variable
var1263
-1
2
above f27 f29
none-of-those
end_variable
begin_variable
var1264
-1
2
above f27 f30
none-of-those
end_variable
begin_variable
var1265
-1
2
above f27 f31
none-of-those
end_variable
begin_variable
var1266
-1
2
above f27 f32
none-of-those
end_variable
begin_variable
var1267
-1
2
above f27 f33
none-of-those
end_variable
begin_variable
var1268
-1
2
above f27 f34
none-of-those
end_variable
begin_variable
var1269
-1
2
above f27 f35
none-of-those
end_variable
begin_variable
var1270
-1
2
above f27 f36
none-of-those
end_variable
begin_variable
var1271
-1
2
above f27 f37
none-of-those
end_variable
begin_variable
var1272
-1
2
above f27 f38
none-of-those
end_variable
begin_variable
var1273
-1
2
above f27 f39
none-of-those
end_variable
begin_variable
var1274
-1
2
above f27 f40
none-of-those
end_variable
begin_variable
var1275
-1
2
above f27 f41
none-of-those
end_variable
begin_variable
var1276
-1
2
above f27 f42
none-of-those
end_variable
begin_variable
var1277
-1
2
above f27 f43
none-of-those
end_variable
begin_variable
var1278
-1
2
above f27 f44
none-of-those
end_variable
begin_variable
var1279
-1
2
above f27 f45
none-of-those
end_variable
begin_variable
var1280
-1
2
above f27 f46
none-of-those
end_variable
begin_variable
var1281
-1
2
above f27 f47
none-of-those
end_variable
begin_variable
var1282
-1
2
above f27 f48
none-of-those
end_variable
begin_variable
var1283
-1
2
above f27 f49
none-of-those
end_variable
begin_variable
var1284
-1
2
above f27 f50
none-of-those
end_variable
begin_variable
var1285
-1
2
above f27 f51
none-of-those
end_variable
begin_variable
var1286
-1
2
above f27 f52
none-of-those
end_variable
begin_variable
var1287
-1
2
above f27 f53
none-of-those
end_variable
begin_variable
var1288
-1
2
above f27 f54
none-of-those
end_variable
begin_variable
var1289
-1
2
above f27 f55
none-of-those
end_variable
begin_variable
var1290
-1
2
above f27 f56
none-of-those
end_variable
begin_variable
var1291
-1
2
above f27 f57
none-of-those
end_variable
begin_variable
var1292
-1
2
above f27 f58
none-of-those
end_variable
begin_variable
var1293
-1
2
above f27 f59
none-of-those
end_variable
begin_variable
var1294
-1
2
above f27 f60
none-of-those
end_variable
begin_variable
var1295
-1
2
above f27 f61
none-of-those
end_variable
begin_variable
var1296
-1
2
above f27 f62
none-of-those
end_variable
begin_variable
var1297
-1
2
above f27 f63
none-of-those
end_variable
begin_variable
var1298
-1
2
above f27 f64
none-of-those
end_variable
begin_variable
var1299
-1
2
above f27 f65
none-of-those
end_variable
begin_variable
var1300
-1
2
above f27 f66
none-of-those
end_variable
begin_variable
var1301
-1
2
above f27 f67
none-of-those
end_variable
begin_variable
var1302
-1
2
above f27 f68
none-of-those
end_variable
begin_variable
var1303
-1
2
above f27 f69
none-of-those
end_variable
begin_variable
var1304
-1
2
above f27 f70
none-of-those
end_variable
begin_variable
var1305
-1
2
above f27 f71
none-of-those
end_variable
begin_variable
var1306
-1
2
above f27 f72
none-of-those
end_variable
begin_variable
var1307
-1
2
above f27 f73
none-of-those
end_variable
begin_variable
var1308
-1
2
above f27 f74
none-of-those
end_variable
begin_variable
var1309
-1
2
above f27 f75
none-of-those
end_variable
begin_variable
var1310
-1
2
above f27 f76
none-of-those
end_variable
begin_variable
var1311
-1
2
above f27 f77
none-of-those
end_variable
begin_variable
var1312
-1
2
above f27 f78
none-of-those
end_variable
begin_variable
var1313
-1
2
above f27 f79
none-of-those
end_variable
begin_variable
var1314
-1
2
above f27 f80
none-of-those
end_variable
begin_variable
var1315
-1
2
above f28 f29
none-of-those
end_variable
begin_variable
var1316
-1
2
above f28 f30
none-of-those
end_variable
begin_variable
var1317
-1
2
above f28 f31
none-of-those
end_variable
begin_variable
var1318
-1
2
above f28 f32
none-of-those
end_variable
begin_variable
var1319
-1
2
above f28 f33
none-of-those
end_variable
begin_variable
var1320
-1
2
above f28 f34
none-of-those
end_variable
begin_variable
var1321
-1
2
above f28 f35
none-of-those
end_variable
begin_variable
var1322
-1
2
above f28 f36
none-of-those
end_variable
begin_variable
var1323
-1
2
above f28 f37
none-of-those
end_variable
begin_variable
var1324
-1
2
above f28 f38
none-of-those
end_variable
begin_variable
var1325
-1
2
above f28 f39
none-of-those
end_variable
begin_variable
var1326
-1
2
above f28 f40
none-of-those
end_variable
begin_variable
var1327
-1
2
above f28 f41
none-of-those
end_variable
begin_variable
var1328
-1
2
above f28 f42
none-of-those
end_variable
begin_variable
var1329
-1
2
above f28 f43
none-of-those
end_variable
begin_variable
var1330
-1
2
above f28 f44
none-of-those
end_variable
begin_variable
var1331
-1
2
above f28 f45
none-of-those
end_variable
begin_variable
var1332
-1
2
above f28 f46
none-of-those
end_variable
begin_variable
var1333
-1
2
above f28 f47
none-of-those
end_variable
begin_variable
var1334
-1
2
above f28 f48
none-of-those
end_variable
begin_variable
var1335
-1
2
above f28 f49
none-of-those
end_variable
begin_variable
var1336
-1
2
above f28 f50
none-of-those
end_variable
begin_variable
var1337
-1
2
above f28 f51
none-of-those
end_variable
begin_variable
var1338
-1
2
above f28 f52
none-of-those
end_variable
begin_variable
var1339
-1
2
above f28 f53
none-of-those
end_variable
begin_variable
var1340
-1
2
above f28 f54
none-of-those
end_variable
begin_variable
var1341
-1
2
above f28 f55
none-of-those
end_variable
begin_variable
var1342
-1
2
above f28 f56
none-of-those
end_variable
begin_variable
var1343
-1
2
above f28 f57
none-of-those
end_variable
begin_variable
var1344
-1
2
above f28 f58
none-of-those
end_variable
begin_variable
var1345
-1
2
above f28 f59
none-of-those
end_variable
begin_variable
var1346
-1
2
above f28 f60
none-of-those
end_variable
begin_variable
var1347
-1
2
above f28 f61
none-of-those
end_variable
begin_variable
var1348
-1
2
above f28 f62
none-of-those
end_variable
begin_variable
var1349
-1
2
above f28 f63
none-of-those
end_variable
begin_variable
var1350
-1
2
above f28 f64
none-of-those
end_variable
begin_variable
var1351
-1
2
above f28 f65
none-of-those
end_variable
begin_variable
var1352
-1
2
above f28 f66
none-of-those
end_variable
begin_variable
var1353
-1
2
above f28 f67
none-of-those
end_variable
begin_variable
var1354
-1
2
above f28 f68
none-of-those
end_variable
begin_variable
var1355
-1
2
above f28 f69
none-of-those
end_variable
begin_variable
var1356
-1
2
above f28 f70
none-of-those
end_variable
begin_variable
var1357
-1
2
above f28 f71
none-of-those
end_variable
begin_variable
var1358
-1
2
above f28 f72
none-of-those
end_variable
begin_variable
var1359
-1
2
above f28 f73
none-of-those
end_variable
begin_variable
var1360
-1
2
above f28 f74
none-of-those
end_variable
begin_variable
var1361
-1
2
above f28 f75
none-of-those
end_variable
begin_variable
var1362
-1
2
above f28 f76
none-of-those
end_variable
begin_variable
var1363
-1
2
above f28 f77
none-of-those
end_variable
begin_variable
var1364
-1
2
above f28 f78
none-of-those
end_variable
begin_variable
var1365
-1
2
above f28 f79
none-of-those
end_variable
begin_variable
var1366
-1
2
above f28 f80
none-of-those
end_variable
begin_variable
var1367
-1
2
above f29 f30
none-of-those
end_variable
begin_variable
var1368
-1
2
above f29 f31
none-of-those
end_variable
begin_variable
var1369
-1
2
above f29 f32
none-of-those
end_variable
begin_variable
var1370
-1
2
above f29 f33
none-of-those
end_variable
begin_variable
var1371
-1
2
above f29 f34
none-of-those
end_variable
begin_variable
var1372
-1
2
above f29 f35
none-of-those
end_variable
begin_variable
var1373
-1
2
above f29 f36
none-of-those
end_variable
begin_variable
var1374
-1
2
above f29 f37
none-of-those
end_variable
begin_variable
var1375
-1
2
above f29 f38
none-of-those
end_variable
begin_variable
var1376
-1
2
above f29 f39
none-of-those
end_variable
begin_variable
var1377
-1
2
above f29 f40
none-of-those
end_variable
begin_variable
var1378
-1
2
above f29 f41
none-of-those
end_variable
begin_variable
var1379
-1
2
above f29 f42
none-of-those
end_variable
begin_variable
var1380
-1
2
above f29 f43
none-of-those
end_variable
begin_variable
var1381
-1
2
above f29 f44
none-of-those
end_variable
begin_variable
var1382
-1
2
above f29 f45
none-of-those
end_variable
begin_variable
var1383
-1
2
above f29 f46
none-of-those
end_variable
begin_variable
var1384
-1
2
above f29 f47
none-of-those
end_variable
begin_variable
var1385
-1
2
above f29 f48
none-of-those
end_variable
begin_variable
var1386
-1
2
above f29 f49
none-of-those
end_variable
begin_variable
var1387
-1
2
above f29 f50
none-of-those
end_variable
begin_variable
var1388
-1
2
above f29 f51
none-of-those
end_variable
begin_variable
var1389
-1
2
above f29 f52
none-of-those
end_variable
begin_variable
var1390
-1
2
above f29 f53
none-of-those
end_variable
begin_variable
var1391
-1
2
above f29 f54
none-of-those
end_variable
begin_variable
var1392
-1
2
above f29 f55
none-of-those
end_variable
begin_variable
var1393
-1
2
above f29 f56
none-of-those
end_variable
begin_variable
var1394
-1
2
above f29 f57
none-of-those
end_variable
begin_variable
var1395
-1
2
above f29 f58
none-of-those
end_variable
begin_variable
var1396
-1
2
above f29 f59
none-of-those
end_variable
begin_variable
var1397
-1
2
above f29 f60
none-of-those
end_variable
begin_variable
var1398
-1
2
above f29 f61
none-of-those
end_variable
begin_variable
var1399
-1
2
above f29 f62
none-of-those
end_variable
begin_variable
var1400
-1
2
above f29 f63
none-of-those
end_variable
begin_variable
var1401
-1
2
above f29 f64
none-of-those
end_variable
begin_variable
var1402
-1
2
above f29 f65
none-of-those
end_variable
begin_variable
var1403
-1
2
above f29 f66
none-of-those
end_variable
begin_variable
var1404
-1
2
above f29 f67
none-of-those
end_variable
begin_variable
var1405
-1
2
above f29 f68
none-of-those
end_variable
begin_variable
var1406
-1
2
above f29 f69
none-of-those
end_variable
begin_variable
var1407
-1
2
above f29 f70
none-of-those
end_variable
begin_variable
var1408
-1
2
above f29 f71
none-of-those
end_variable
begin_variable
var1409
-1
2
above f29 f72
none-of-those
end_variable
begin_variable
var1410
-1
2
above f29 f73
none-of-those
end_variable
begin_variable
var1411
-1
2
above f29 f74
none-of-those
end_variable
begin_variable
var1412
-1
2
above f29 f75
none-of-those
end_variable
begin_variable
var1413
-1
2
above f29 f76
none-of-those
end_variable
begin_variable
var1414
-1
2
above f29 f77
none-of-those
end_variable
begin_variable
var1415
-1
2
above f29 f78
none-of-those
end_variable
begin_variable
var1416
-1
2
above f29 f79
none-of-those
end_variable
begin_variable
var1417
-1
2
above f29 f80
none-of-those
end_variable
begin_variable
var1418
-1
2
above f3 f10
none-of-those
end_variable
begin_variable
var1419
-1
2
above f3 f11
none-of-those
end_variable
begin_variable
var1420
-1
2
above f3 f12
none-of-those
end_variable
begin_variable
var1421
-1
2
above f3 f13
none-of-those
end_variable
begin_variable
var1422
-1
2
above f3 f14
none-of-those
end_variable
begin_variable
var1423
-1
2
above f3 f15
none-of-those
end_variable
begin_variable
var1424
-1
2
above f3 f16
none-of-those
end_variable
begin_variable
var1425
-1
2
above f3 f17
none-of-those
end_variable
begin_variable
var1426
-1
2
above f3 f18
none-of-those
end_variable
begin_variable
var1427
-1
2
above f3 f19
none-of-those
end_variable
begin_variable
var1428
-1
2
above f3 f20
none-of-those
end_variable
begin_variable
var1429
-1
2
above f3 f21
none-of-those
end_variable
begin_variable
var1430
-1
2
above f3 f22
none-of-those
end_variable
begin_variable
var1431
-1
2
above f3 f23
none-of-those
end_variable
begin_variable
var1432
-1
2
above f3 f24
none-of-those
end_variable
begin_variable
var1433
-1
2
above f3 f25
none-of-those
end_variable
begin_variable
var1434
-1
2
above f3 f26
none-of-those
end_variable
begin_variable
var1435
-1
2
above f3 f27
none-of-those
end_variable
begin_variable
var1436
-1
2
above f3 f28
none-of-those
end_variable
begin_variable
var1437
-1
2
above f3 f29
none-of-those
end_variable
begin_variable
var1438
-1
2
above f3 f30
none-of-those
end_variable
begin_variable
var1439
-1
2
above f3 f31
none-of-those
end_variable
begin_variable
var1440
-1
2
above f3 f32
none-of-those
end_variable
begin_variable
var1441
-1
2
above f3 f33
none-of-those
end_variable
begin_variable
var1442
-1
2
above f3 f34
none-of-those
end_variable
begin_variable
var1443
-1
2
above f3 f35
none-of-those
end_variable
begin_variable
var1444
-1
2
above f3 f36
none-of-those
end_variable
begin_variable
var1445
-1
2
above f3 f37
none-of-those
end_variable
begin_variable
var1446
-1
2
above f3 f38
none-of-those
end_variable
begin_variable
var1447
-1
2
above f3 f39
none-of-those
end_variable
begin_variable
var1448
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var1449
-1
2
above f3 f40
none-of-those
end_variable
begin_variable
var1450
-1
2
above f3 f41
none-of-those
end_variable
begin_variable
var1451
-1
2
above f3 f42
none-of-those
end_variable
begin_variable
var1452
-1
2
above f3 f43
none-of-those
end_variable
begin_variable
var1453
-1
2
above f3 f44
none-of-those
end_variable
begin_variable
var1454
-1
2
above f3 f45
none-of-those
end_variable
begin_variable
var1455
-1
2
above f3 f46
none-of-those
end_variable
begin_variable
var1456
-1
2
above f3 f47
none-of-those
end_variable
begin_variable
var1457
-1
2
above f3 f48
none-of-those
end_variable
begin_variable
var1458
-1
2
above f3 f49
none-of-those
end_variable
begin_variable
var1459
-1
2
above f3 f5
none-of-those
end_variable
begin_variable
var1460
-1
2
above f3 f50
none-of-those
end_variable
begin_variable
var1461
-1
2
above f3 f51
none-of-those
end_variable
begin_variable
var1462
-1
2
above f3 f52
none-of-those
end_variable
begin_variable
var1463
-1
2
above f3 f53
none-of-those
end_variable
begin_variable
var1464
-1
2
above f3 f54
none-of-those
end_variable
begin_variable
var1465
-1
2
above f3 f55
none-of-those
end_variable
begin_variable
var1466
-1
2
above f3 f56
none-of-those
end_variable
begin_variable
var1467
-1
2
above f3 f57
none-of-those
end_variable
begin_variable
var1468
-1
2
above f3 f58
none-of-those
end_variable
begin_variable
var1469
-1
2
above f3 f59
none-of-those
end_variable
begin_variable
var1470
-1
2
above f3 f6
none-of-those
end_variable
begin_variable
var1471
-1
2
above f3 f60
none-of-those
end_variable
begin_variable
var1472
-1
2
above f3 f61
none-of-those
end_variable
begin_variable
var1473
-1
2
above f3 f62
none-of-those
end_variable
begin_variable
var1474
-1
2
above f3 f63
none-of-those
end_variable
begin_variable
var1475
-1
2
above f3 f64
none-of-those
end_variable
begin_variable
var1476
-1
2
above f3 f65
none-of-those
end_variable
begin_variable
var1477
-1
2
above f3 f66
none-of-those
end_variable
begin_variable
var1478
-1
2
above f3 f67
none-of-those
end_variable
begin_variable
var1479
-1
2
above f3 f68
none-of-those
end_variable
begin_variable
var1480
-1
2
above f3 f69
none-of-those
end_variable
begin_variable
var1481
-1
2
above f3 f7
none-of-those
end_variable
begin_variable
var1482
-1
2
above f3 f70
none-of-those
end_variable
begin_variable
var1483
-1
2
above f3 f71
none-of-those
end_variable
begin_variable
var1484
-1
2
above f3 f72
none-of-those
end_variable
begin_variable
var1485
-1
2
above f3 f73
none-of-those
end_variable
begin_variable
var1486
-1
2
above f3 f74
none-of-those
end_variable
begin_variable
var1487
-1
2
above f3 f75
none-of-those
end_variable
begin_variable
var1488
-1
2
above f3 f76
none-of-those
end_variable
begin_variable
var1489
-1
2
above f3 f77
none-of-those
end_variable
begin_variable
var1490
-1
2
above f3 f78
none-of-those
end_variable
begin_variable
var1491
-1
2
above f3 f79
none-of-those
end_variable
begin_variable
var1492
-1
2
above f3 f8
none-of-those
end_variable
begin_variable
var1493
-1
2
above f3 f80
none-of-those
end_variable
begin_variable
var1494
-1
2
above f3 f9
none-of-those
end_variable
begin_variable
var1495
-1
2
above f30 f31
none-of-those
end_variable
begin_variable
var1496
-1
2
above f30 f32
none-of-those
end_variable
begin_variable
var1497
-1
2
above f30 f33
none-of-those
end_variable
begin_variable
var1498
-1
2
above f30 f34
none-of-those
end_variable
begin_variable
var1499
-1
2
above f30 f35
none-of-those
end_variable
begin_variable
var1500
-1
2
above f30 f36
none-of-those
end_variable
begin_variable
var1501
-1
2
above f30 f37
none-of-those
end_variable
begin_variable
var1502
-1
2
above f30 f38
none-of-those
end_variable
begin_variable
var1503
-1
2
above f30 f39
none-of-those
end_variable
begin_variable
var1504
-1
2
above f30 f40
none-of-those
end_variable
begin_variable
var1505
-1
2
above f30 f41
none-of-those
end_variable
begin_variable
var1506
-1
2
above f30 f42
none-of-those
end_variable
begin_variable
var1507
-1
2
above f30 f43
none-of-those
end_variable
begin_variable
var1508
-1
2
above f30 f44
none-of-those
end_variable
begin_variable
var1509
-1
2
above f30 f45
none-of-those
end_variable
begin_variable
var1510
-1
2
above f30 f46
none-of-those
end_variable
begin_variable
var1511
-1
2
above f30 f47
none-of-those
end_variable
begin_variable
var1512
-1
2
above f30 f48
none-of-those
end_variable
begin_variable
var1513
-1
2
above f30 f49
none-of-those
end_variable
begin_variable
var1514
-1
2
above f30 f50
none-of-those
end_variable
begin_variable
var1515
-1
2
above f30 f51
none-of-those
end_variable
begin_variable
var1516
-1
2
above f30 f52
none-of-those
end_variable
begin_variable
var1517
-1
2
above f30 f53
none-of-those
end_variable
begin_variable
var1518
-1
2
above f30 f54
none-of-those
end_variable
begin_variable
var1519
-1
2
above f30 f55
none-of-those
end_variable
begin_variable
var1520
-1
2
above f30 f56
none-of-those
end_variable
begin_variable
var1521
-1
2
above f30 f57
none-of-those
end_variable
begin_variable
var1522
-1
2
above f30 f58
none-of-those
end_variable
begin_variable
var1523
-1
2
above f30 f59
none-of-those
end_variable
begin_variable
var1524
-1
2
above f30 f60
none-of-those
end_variable
begin_variable
var1525
-1
2
above f30 f61
none-of-those
end_variable
begin_variable
var1526
-1
2
above f30 f62
none-of-those
end_variable
begin_variable
var1527
-1
2
above f30 f63
none-of-those
end_variable
begin_variable
var1528
-1
2
above f30 f64
none-of-those
end_variable
begin_variable
var1529
-1
2
above f30 f65
none-of-those
end_variable
begin_variable
var1530
-1
2
above f30 f66
none-of-those
end_variable
begin_variable
var1531
-1
2
above f30 f67
none-of-those
end_variable
begin_variable
var1532
-1
2
above f30 f68
none-of-those
end_variable
begin_variable
var1533
-1
2
above f30 f69
none-of-those
end_variable
begin_variable
var1534
-1
2
above f30 f70
none-of-those
end_variable
begin_variable
var1535
-1
2
above f30 f71
none-of-those
end_variable
begin_variable
var1536
-1
2
above f30 f72
none-of-those
end_variable
begin_variable
var1537
-1
2
above f30 f73
none-of-those
end_variable
begin_variable
var1538
-1
2
above f30 f74
none-of-those
end_variable
begin_variable
var1539
-1
2
above f30 f75
none-of-those
end_variable
begin_variable
var1540
-1
2
above f30 f76
none-of-those
end_variable
begin_variable
var1541
-1
2
above f30 f77
none-of-those
end_variable
begin_variable
var1542
-1
2
above f30 f78
none-of-those
end_variable
begin_variable
var1543
-1
2
above f30 f79
none-of-those
end_variable
begin_variable
var1544
-1
2
above f30 f80
none-of-those
end_variable
begin_variable
var1545
-1
2
above f31 f32
none-of-those
end_variable
begin_variable
var1546
-1
2
above f31 f33
none-of-those
end_variable
begin_variable
var1547
-1
2
above f31 f34
none-of-those
end_variable
begin_variable
var1548
-1
2
above f31 f35
none-of-those
end_variable
begin_variable
var1549
-1
2
above f31 f36
none-of-those
end_variable
begin_variable
var1550
-1
2
above f31 f37
none-of-those
end_variable
begin_variable
var1551
-1
2
above f31 f38
none-of-those
end_variable
begin_variable
var1552
-1
2
above f31 f39
none-of-those
end_variable
begin_variable
var1553
-1
2
above f31 f40
none-of-those
end_variable
begin_variable
var1554
-1
2
above f31 f41
none-of-those
end_variable
begin_variable
var1555
-1
2
above f31 f42
none-of-those
end_variable
begin_variable
var1556
-1
2
above f31 f43
none-of-those
end_variable
begin_variable
var1557
-1
2
above f31 f44
none-of-those
end_variable
begin_variable
var1558
-1
2
above f31 f45
none-of-those
end_variable
begin_variable
var1559
-1
2
above f31 f46
none-of-those
end_variable
begin_variable
var1560
-1
2
above f31 f47
none-of-those
end_variable
begin_variable
var1561
-1
2
above f31 f48
none-of-those
end_variable
begin_variable
var1562
-1
2
above f31 f49
none-of-those
end_variable
begin_variable
var1563
-1
2
above f31 f50
none-of-those
end_variable
begin_variable
var1564
-1
2
above f31 f51
none-of-those
end_variable
begin_variable
var1565
-1
2
above f31 f52
none-of-those
end_variable
begin_variable
var1566
-1
2
above f31 f53
none-of-those
end_variable
begin_variable
var1567
-1
2
above f31 f54
none-of-those
end_variable
begin_variable
var1568
-1
2
above f31 f55
none-of-those
end_variable
begin_variable
var1569
-1
2
above f31 f56
none-of-those
end_variable
begin_variable
var1570
-1
2
above f31 f57
none-of-those
end_variable
begin_variable
var1571
-1
2
above f31 f58
none-of-those
end_variable
begin_variable
var1572
-1
2
above f31 f59
none-of-those
end_variable
begin_variable
var1573
-1
2
above f31 f60
none-of-those
end_variable
begin_variable
var1574
-1
2
above f31 f61
none-of-those
end_variable
begin_variable
var1575
-1
2
above f31 f62
none-of-those
end_variable
begin_variable
var1576
-1
2
above f31 f63
none-of-those
end_variable
begin_variable
var1577
-1
2
above f31 f64
none-of-those
end_variable
begin_variable
var1578
-1
2
above f31 f65
none-of-those
end_variable
begin_variable
var1579
-1
2
above f31 f66
none-of-those
end_variable
begin_variable
var1580
-1
2
above f31 f67
none-of-those
end_variable
begin_variable
var1581
-1
2
above f31 f68
none-of-those
end_variable
begin_variable
var1582
-1
2
above f31 f69
none-of-those
end_variable
begin_variable
var1583
-1
2
above f31 f70
none-of-those
end_variable
begin_variable
var1584
-1
2
above f31 f71
none-of-those
end_variable
begin_variable
var1585
-1
2
above f31 f72
none-of-those
end_variable
begin_variable
var1586
-1
2
above f31 f73
none-of-those
end_variable
begin_variable
var1587
-1
2
above f31 f74
none-of-those
end_variable
begin_variable
var1588
-1
2
above f31 f75
none-of-those
end_variable
begin_variable
var1589
-1
2
above f31 f76
none-of-those
end_variable
begin_variable
var1590
-1
2
above f31 f77
none-of-those
end_variable
begin_variable
var1591
-1
2
above f31 f78
none-of-those
end_variable
begin_variable
var1592
-1
2
above f31 f79
none-of-those
end_variable
begin_variable
var1593
-1
2
above f31 f80
none-of-those
end_variable
begin_variable
var1594
-1
2
above f32 f33
none-of-those
end_variable
begin_variable
var1595
-1
2
above f32 f34
none-of-those
end_variable
begin_variable
var1596
-1
2
above f32 f35
none-of-those
end_variable
begin_variable
var1597
-1
2
above f32 f36
none-of-those
end_variable
begin_variable
var1598
-1
2
above f32 f37
none-of-those
end_variable
begin_variable
var1599
-1
2
above f32 f38
none-of-those
end_variable
begin_variable
var1600
-1
2
above f32 f39
none-of-those
end_variable
begin_variable
var1601
-1
2
above f32 f40
none-of-those
end_variable
begin_variable
var1602
-1
2
above f32 f41
none-of-those
end_variable
begin_variable
var1603
-1
2
above f32 f42
none-of-those
end_variable
begin_variable
var1604
-1
2
above f32 f43
none-of-those
end_variable
begin_variable
var1605
-1
2
above f32 f44
none-of-those
end_variable
begin_variable
var1606
-1
2
above f32 f45
none-of-those
end_variable
begin_variable
var1607
-1
2
above f32 f46
none-of-those
end_variable
begin_variable
var1608
-1
2
above f32 f47
none-of-those
end_variable
begin_variable
var1609
-1
2
above f32 f48
none-of-those
end_variable
begin_variable
var1610
-1
2
above f32 f49
none-of-those
end_variable
begin_variable
var1611
-1
2
above f32 f50
none-of-those
end_variable
begin_variable
var1612
-1
2
above f32 f51
none-of-those
end_variable
begin_variable
var1613
-1
2
above f32 f52
none-of-those
end_variable
begin_variable
var1614
-1
2
above f32 f53
none-of-those
end_variable
begin_variable
var1615
-1
2
above f32 f54
none-of-those
end_variable
begin_variable
var1616
-1
2
above f32 f55
none-of-those
end_variable
begin_variable
var1617
-1
2
above f32 f56
none-of-those
end_variable
begin_variable
var1618
-1
2
above f32 f57
none-of-those
end_variable
begin_variable
var1619
-1
2
above f32 f58
none-of-those
end_variable
begin_variable
var1620
-1
2
above f32 f59
none-of-those
end_variable
begin_variable
var1621
-1
2
above f32 f60
none-of-those
end_variable
begin_variable
var1622
-1
2
above f32 f61
none-of-those
end_variable
begin_variable
var1623
-1
2
above f32 f62
none-of-those
end_variable
begin_variable
var1624
-1
2
above f32 f63
none-of-those
end_variable
begin_variable
var1625
-1
2
above f32 f64
none-of-those
end_variable
begin_variable
var1626
-1
2
above f32 f65
none-of-those
end_variable
begin_variable
var1627
-1
2
above f32 f66
none-of-those
end_variable
begin_variable
var1628
-1
2
above f32 f67
none-of-those
end_variable
begin_variable
var1629
-1
2
above f32 f68
none-of-those
end_variable
begin_variable
var1630
-1
2
above f32 f69
none-of-those
end_variable
begin_variable
var1631
-1
2
above f32 f70
none-of-those
end_variable
begin_variable
var1632
-1
2
above f32 f71
none-of-those
end_variable
begin_variable
var1633
-1
2
above f32 f72
none-of-those
end_variable
begin_variable
var1634
-1
2
above f32 f73
none-of-those
end_variable
begin_variable
var1635
-1
2
above f32 f74
none-of-those
end_variable
begin_variable
var1636
-1
2
above f32 f75
none-of-those
end_variable
begin_variable
var1637
-1
2
above f32 f76
none-of-those
end_variable
begin_variable
var1638
-1
2
above f32 f77
none-of-those
end_variable
begin_variable
var1639
-1
2
above f32 f78
none-of-those
end_variable
begin_variable
var1640
-1
2
above f32 f79
none-of-those
end_variable
begin_variable
var1641
-1
2
above f32 f80
none-of-those
end_variable
begin_variable
var1642
-1
2
above f33 f34
none-of-those
end_variable
begin_variable
var1643
-1
2
above f33 f35
none-of-those
end_variable
begin_variable
var1644
-1
2
above f33 f36
none-of-those
end_variable
begin_variable
var1645
-1
2
above f33 f37
none-of-those
end_variable
begin_variable
var1646
-1
2
above f33 f38
none-of-those
end_variable
begin_variable
var1647
-1
2
above f33 f39
none-of-those
end_variable
begin_variable
var1648
-1
2
above f33 f40
none-of-those
end_variable
begin_variable
var1649
-1
2
above f33 f41
none-of-those
end_variable
begin_variable
var1650
-1
2
above f33 f42
none-of-those
end_variable
begin_variable
var1651
-1
2
above f33 f43
none-of-those
end_variable
begin_variable
var1652
-1
2
above f33 f44
none-of-those
end_variable
begin_variable
var1653
-1
2
above f33 f45
none-of-those
end_variable
begin_variable
var1654
-1
2
above f33 f46
none-of-those
end_variable
begin_variable
var1655
-1
2
above f33 f47
none-of-those
end_variable
begin_variable
var1656
-1
2
above f33 f48
none-of-those
end_variable
begin_variable
var1657
-1
2
above f33 f49
none-of-those
end_variable
begin_variable
var1658
-1
2
above f33 f50
none-of-those
end_variable
begin_variable
var1659
-1
2
above f33 f51
none-of-those
end_variable
begin_variable
var1660
-1
2
above f33 f52
none-of-those
end_variable
begin_variable
var1661
-1
2
above f33 f53
none-of-those
end_variable
begin_variable
var1662
-1
2
above f33 f54
none-of-those
end_variable
begin_variable
var1663
-1
2
above f33 f55
none-of-those
end_variable
begin_variable
var1664
-1
2
above f33 f56
none-of-those
end_variable
begin_variable
var1665
-1
2
above f33 f57
none-of-those
end_variable
begin_variable
var1666
-1
2
above f33 f58
none-of-those
end_variable
begin_variable
var1667
-1
2
above f33 f59
none-of-those
end_variable
begin_variable
var1668
-1
2
above f33 f60
none-of-those
end_variable
begin_variable
var1669
-1
2
above f33 f61
none-of-those
end_variable
begin_variable
var1670
-1
2
above f33 f62
none-of-those
end_variable
begin_variable
var1671
-1
2
above f33 f63
none-of-those
end_variable
begin_variable
var1672
-1
2
above f33 f64
none-of-those
end_variable
begin_variable
var1673
-1
2
above f33 f65
none-of-those
end_variable
begin_variable
var1674
-1
2
above f33 f66
none-of-those
end_variable
begin_variable
var1675
-1
2
above f33 f67
none-of-those
end_variable
begin_variable
var1676
-1
2
above f33 f68
none-of-those
end_variable
begin_variable
var1677
-1
2
above f33 f69
none-of-those
end_variable
begin_variable
var1678
-1
2
above f33 f70
none-of-those
end_variable
begin_variable
var1679
-1
2
above f33 f71
none-of-those
end_variable
begin_variable
var1680
-1
2
above f33 f72
none-of-those
end_variable
begin_variable
var1681
-1
2
above f33 f73
none-of-those
end_variable
begin_variable
var1682
-1
2
above f33 f74
none-of-those
end_variable
begin_variable
var1683
-1
2
above f33 f75
none-of-those
end_variable
begin_variable
var1684
-1
2
above f33 f76
none-of-those
end_variable
begin_variable
var1685
-1
2
above f33 f77
none-of-those
end_variable
begin_variable
var1686
-1
2
above f33 f78
none-of-those
end_variable
begin_variable
var1687
-1
2
above f33 f79
none-of-those
end_variable
begin_variable
var1688
-1
2
above f33 f80
none-of-those
end_variable
begin_variable
var1689
-1
2
above f34 f35
none-of-those
end_variable
begin_variable
var1690
-1
2
above f34 f36
none-of-those
end_variable
begin_variable
var1691
-1
2
above f34 f37
none-of-those
end_variable
begin_variable
var1692
-1
2
above f34 f38
none-of-those
end_variable
begin_variable
var1693
-1
2
above f34 f39
none-of-those
end_variable
begin_variable
var1694
-1
2
above f34 f40
none-of-those
end_variable
begin_variable
var1695
-1
2
above f34 f41
none-of-those
end_variable
begin_variable
var1696
-1
2
above f34 f42
none-of-those
end_variable
begin_variable
var1697
-1
2
above f34 f43
none-of-those
end_variable
begin_variable
var1698
-1
2
above f34 f44
none-of-those
end_variable
begin_variable
var1699
-1
2
above f34 f45
none-of-those
end_variable
begin_variable
var1700
-1
2
above f34 f46
none-of-those
end_variable
begin_variable
var1701
-1
2
above f34 f47
none-of-those
end_variable
begin_variable
var1702
-1
2
above f34 f48
none-of-those
end_variable
begin_variable
var1703
-1
2
above f34 f49
none-of-those
end_variable
begin_variable
var1704
-1
2
above f34 f50
none-of-those
end_variable
begin_variable
var1705
-1
2
above f34 f51
none-of-those
end_variable
begin_variable
var1706
-1
2
above f34 f52
none-of-those
end_variable
begin_variable
var1707
-1
2
above f34 f53
none-of-those
end_variable
begin_variable
var1708
-1
2
above f34 f54
none-of-those
end_variable
begin_variable
var1709
-1
2
above f34 f55
none-of-those
end_variable
begin_variable
var1710
-1
2
above f34 f56
none-of-those
end_variable
begin_variable
var1711
-1
2
above f34 f57
none-of-those
end_variable
begin_variable
var1712
-1
2
above f34 f58
none-of-those
end_variable
begin_variable
var1713
-1
2
above f34 f59
none-of-those
end_variable
begin_variable
var1714
-1
2
above f34 f60
none-of-those
end_variable
begin_variable
var1715
-1
2
above f34 f61
none-of-those
end_variable
begin_variable
var1716
-1
2
above f34 f62
none-of-those
end_variable
begin_variable
var1717
-1
2
above f34 f63
none-of-those
end_variable
begin_variable
var1718
-1
2
above f34 f64
none-of-those
end_variable
begin_variable
var1719
-1
2
above f34 f65
none-of-those
end_variable
begin_variable
var1720
-1
2
above f34 f66
none-of-those
end_variable
begin_variable
var1721
-1
2
above f34 f67
none-of-those
end_variable
begin_variable
var1722
-1
2
above f34 f68
none-of-those
end_variable
begin_variable
var1723
-1
2
above f34 f69
none-of-those
end_variable
begin_variable
var1724
-1
2
above f34 f70
none-of-those
end_variable
begin_variable
var1725
-1
2
above f34 f71
none-of-those
end_variable
begin_variable
var1726
-1
2
above f34 f72
none-of-those
end_variable
begin_variable
var1727
-1
2
above f34 f73
none-of-those
end_variable
begin_variable
var1728
-1
2
above f34 f74
none-of-those
end_variable
begin_variable
var1729
-1
2
above f34 f75
none-of-those
end_variable
begin_variable
var1730
-1
2
above f34 f76
none-of-those
end_variable
begin_variable
var1731
-1
2
above f34 f77
none-of-those
end_variable
begin_variable
var1732
-1
2
above f34 f78
none-of-those
end_variable
begin_variable
var1733
-1
2
above f34 f79
none-of-those
end_variable
begin_variable
var1734
-1
2
above f34 f80
none-of-those
end_variable
begin_variable
var1735
-1
2
above f35 f36
none-of-those
end_variable
begin_variable
var1736
-1
2
above f35 f37
none-of-those
end_variable
begin_variable
var1737
-1
2
above f35 f38
none-of-those
end_variable
begin_variable
var1738
-1
2
above f35 f39
none-of-those
end_variable
begin_variable
var1739
-1
2
above f35 f40
none-of-those
end_variable
begin_variable
var1740
-1
2
above f35 f41
none-of-those
end_variable
begin_variable
var1741
-1
2
above f35 f42
none-of-those
end_variable
begin_variable
var1742
-1
2
above f35 f43
none-of-those
end_variable
begin_variable
var1743
-1
2
above f35 f44
none-of-those
end_variable
begin_variable
var1744
-1
2
above f35 f45
none-of-those
end_variable
begin_variable
var1745
-1
2
above f35 f46
none-of-those
end_variable
begin_variable
var1746
-1
2
above f35 f47
none-of-those
end_variable
begin_variable
var1747
-1
2
above f35 f48
none-of-those
end_variable
begin_variable
var1748
-1
2
above f35 f49
none-of-those
end_variable
begin_variable
var1749
-1
2
above f35 f50
none-of-those
end_variable
begin_variable
var1750
-1
2
above f35 f51
none-of-those
end_variable
begin_variable
var1751
-1
2
above f35 f52
none-of-those
end_variable
begin_variable
var1752
-1
2
above f35 f53
none-of-those
end_variable
begin_variable
var1753
-1
2
above f35 f54
none-of-those
end_variable
begin_variable
var1754
-1
2
above f35 f55
none-of-those
end_variable
begin_variable
var1755
-1
2
above f35 f56
none-of-those
end_variable
begin_variable
var1756
-1
2
above f35 f57
none-of-those
end_variable
begin_variable
var1757
-1
2
above f35 f58
none-of-those
end_variable
begin_variable
var1758
-1
2
above f35 f59
none-of-those
end_variable
begin_variable
var1759
-1
2
above f35 f60
none-of-those
end_variable
begin_variable
var1760
-1
2
above f35 f61
none-of-those
end_variable
begin_variable
var1761
-1
2
above f35 f62
none-of-those
end_variable
begin_variable
var1762
-1
2
above f35 f63
none-of-those
end_variable
begin_variable
var1763
-1
2
above f35 f64
none-of-those
end_variable
begin_variable
var1764
-1
2
above f35 f65
none-of-those
end_variable
begin_variable
var1765
-1
2
above f35 f66
none-of-those
end_variable
begin_variable
var1766
-1
2
above f35 f67
none-of-those
end_variable
begin_variable
var1767
-1
2
above f35 f68
none-of-those
end_variable
begin_variable
var1768
-1
2
above f35 f69
none-of-those
end_variable
begin_variable
var1769
-1
2
above f35 f70
none-of-those
end_variable
begin_variable
var1770
-1
2
above f35 f71
none-of-those
end_variable
begin_variable
var1771
-1
2
above f35 f72
none-of-those
end_variable
begin_variable
var1772
-1
2
above f35 f73
none-of-those
end_variable
begin_variable
var1773
-1
2
above f35 f74
none-of-those
end_variable
begin_variable
var1774
-1
2
above f35 f75
none-of-those
end_variable
begin_variable
var1775
-1
2
above f35 f76
none-of-those
end_variable
begin_variable
var1776
-1
2
above f35 f77
none-of-those
end_variable
begin_variable
var1777
-1
2
above f35 f78
none-of-those
end_variable
begin_variable
var1778
-1
2
above f35 f79
none-of-those
end_variable
begin_variable
var1779
-1
2
above f35 f80
none-of-those
end_variable
begin_variable
var1780
-1
2
above f36 f37
none-of-those
end_variable
begin_variable
var1781
-1
2
above f36 f38
none-of-those
end_variable
begin_variable
var1782
-1
2
above f36 f39
none-of-those
end_variable
begin_variable
var1783
-1
2
above f36 f40
none-of-those
end_variable
begin_variable
var1784
-1
2
above f36 f41
none-of-those
end_variable
begin_variable
var1785
-1
2
above f36 f42
none-of-those
end_variable
begin_variable
var1786
-1
2
above f36 f43
none-of-those
end_variable
begin_variable
var1787
-1
2
above f36 f44
none-of-those
end_variable
begin_variable
var1788
-1
2
above f36 f45
none-of-those
end_variable
begin_variable
var1789
-1
2
above f36 f46
none-of-those
end_variable
begin_variable
var1790
-1
2
above f36 f47
none-of-those
end_variable
begin_variable
var1791
-1
2
above f36 f48
none-of-those
end_variable
begin_variable
var1792
-1
2
above f36 f49
none-of-those
end_variable
begin_variable
var1793
-1
2
above f36 f50
none-of-those
end_variable
begin_variable
var1794
-1
2
above f36 f51
none-of-those
end_variable
begin_variable
var1795
-1
2
above f36 f52
none-of-those
end_variable
begin_variable
var1796
-1
2
above f36 f53
none-of-those
end_variable
begin_variable
var1797
-1
2
above f36 f54
none-of-those
end_variable
begin_variable
var1798
-1
2
above f36 f55
none-of-those
end_variable
begin_variable
var1799
-1
2
above f36 f56
none-of-those
end_variable
begin_variable
var1800
-1
2
above f36 f57
none-of-those
end_variable
begin_variable
var1801
-1
2
above f36 f58
none-of-those
end_variable
begin_variable
var1802
-1
2
above f36 f59
none-of-those
end_variable
begin_variable
var1803
-1
2
above f36 f60
none-of-those
end_variable
begin_variable
var1804
-1
2
above f36 f61
none-of-those
end_variable
begin_variable
var1805
-1
2
above f36 f62
none-of-those
end_variable
begin_variable
var1806
-1
2
above f36 f63
none-of-those
end_variable
begin_variable
var1807
-1
2
above f36 f64
none-of-those
end_variable
begin_variable
var1808
-1
2
above f36 f65
none-of-those
end_variable
begin_variable
var1809
-1
2
above f36 f66
none-of-those
end_variable
begin_variable
var1810
-1
2
above f36 f67
none-of-those
end_variable
begin_variable
var1811
-1
2
above f36 f68
none-of-those
end_variable
begin_variable
var1812
-1
2
above f36 f69
none-of-those
end_variable
begin_variable
var1813
-1
2
above f36 f70
none-of-those
end_variable
begin_variable
var1814
-1
2
above f36 f71
none-of-those
end_variable
begin_variable
var1815
-1
2
above f36 f72
none-of-those
end_variable
begin_variable
var1816
-1
2
above f36 f73
none-of-those
end_variable
begin_variable
var1817
-1
2
above f36 f74
none-of-those
end_variable
begin_variable
var1818
-1
2
above f36 f75
none-of-those
end_variable
begin_variable
var1819
-1
2
above f36 f76
none-of-those
end_variable
begin_variable
var1820
-1
2
above f36 f77
none-of-those
end_variable
begin_variable
var1821
-1
2
above f36 f78
none-of-those
end_variable
begin_variable
var1822
-1
2
above f36 f79
none-of-those
end_variable
begin_variable
var1823
-1
2
above f36 f80
none-of-those
end_variable
begin_variable
var1824
-1
2
above f37 f38
none-of-those
end_variable
begin_variable
var1825
-1
2
above f37 f39
none-of-those
end_variable
begin_variable
var1826
-1
2
above f37 f40
none-of-those
end_variable
begin_variable
var1827
-1
2
above f37 f41
none-of-those
end_variable
begin_variable
var1828
-1
2
above f37 f42
none-of-those
end_variable
begin_variable
var1829
-1
2
above f37 f43
none-of-those
end_variable
begin_variable
var1830
-1
2
above f37 f44
none-of-those
end_variable
begin_variable
var1831
-1
2
above f37 f45
none-of-those
end_variable
begin_variable
var1832
-1
2
above f37 f46
none-of-those
end_variable
begin_variable
var1833
-1
2
above f37 f47
none-of-those
end_variable
begin_variable
var1834
-1
2
above f37 f48
none-of-those
end_variable
begin_variable
var1835
-1
2
above f37 f49
none-of-those
end_variable
begin_variable
var1836
-1
2
above f37 f50
none-of-those
end_variable
begin_variable
var1837
-1
2
above f37 f51
none-of-those
end_variable
begin_variable
var1838
-1
2
above f37 f52
none-of-those
end_variable
begin_variable
var1839
-1
2
above f37 f53
none-of-those
end_variable
begin_variable
var1840
-1
2
above f37 f54
none-of-those
end_variable
begin_variable
var1841
-1
2
above f37 f55
none-of-those
end_variable
begin_variable
var1842
-1
2
above f37 f56
none-of-those
end_variable
begin_variable
var1843
-1
2
above f37 f57
none-of-those
end_variable
begin_variable
var1844
-1
2
above f37 f58
none-of-those
end_variable
begin_variable
var1845
-1
2
above f37 f59
none-of-those
end_variable
begin_variable
var1846
-1
2
above f37 f60
none-of-those
end_variable
begin_variable
var1847
-1
2
above f37 f61
none-of-those
end_variable
begin_variable
var1848
-1
2
above f37 f62
none-of-those
end_variable
begin_variable
var1849
-1
2
above f37 f63
none-of-those
end_variable
begin_variable
var1850
-1
2
above f37 f64
none-of-those
end_variable
begin_variable
var1851
-1
2
above f37 f65
none-of-those
end_variable
begin_variable
var1852
-1
2
above f37 f66
none-of-those
end_variable
begin_variable
var1853
-1
2
above f37 f67
none-of-those
end_variable
begin_variable
var1854
-1
2
above f37 f68
none-of-those
end_variable
begin_variable
var1855
-1
2
above f37 f69
none-of-those
end_variable
begin_variable
var1856
-1
2
above f37 f70
none-of-those
end_variable
begin_variable
var1857
-1
2
above f37 f71
none-of-those
end_variable
begin_variable
var1858
-1
2
above f37 f72
none-of-those
end_variable
begin_variable
var1859
-1
2
above f37 f73
none-of-those
end_variable
begin_variable
var1860
-1
2
above f37 f74
none-of-those
end_variable
begin_variable
var1861
-1
2
above f37 f75
none-of-those
end_variable
begin_variable
var1862
-1
2
above f37 f76
none-of-those
end_variable
begin_variable
var1863
-1
2
above f37 f77
none-of-those
end_variable
begin_variable
var1864
-1
2
above f37 f78
none-of-those
end_variable
begin_variable
var1865
-1
2
above f37 f79
none-of-those
end_variable
begin_variable
var1866
-1
2
above f37 f80
none-of-those
end_variable
begin_variable
var1867
-1
2
above f38 f39
none-of-those
end_variable
begin_variable
var1868
-1
2
above f38 f40
none-of-those
end_variable
begin_variable
var1869
-1
2
above f38 f41
none-of-those
end_variable
begin_variable
var1870
-1
2
above f38 f42
none-of-those
end_variable
begin_variable
var1871
-1
2
above f38 f43
none-of-those
end_variable
begin_variable
var1872
-1
2
above f38 f44
none-of-those
end_variable
begin_variable
var1873
-1
2
above f38 f45
none-of-those
end_variable
begin_variable
var1874
-1
2
above f38 f46
none-of-those
end_variable
begin_variable
var1875
-1
2
above f38 f47
none-of-those
end_variable
begin_variable
var1876
-1
2
above f38 f48
none-of-those
end_variable
begin_variable
var1877
-1
2
above f38 f49
none-of-those
end_variable
begin_variable
var1878
-1
2
above f38 f50
none-of-those
end_variable
begin_variable
var1879
-1
2
above f38 f51
none-of-those
end_variable
begin_variable
var1880
-1
2
above f38 f52
none-of-those
end_variable
begin_variable
var1881
-1
2
above f38 f53
none-of-those
end_variable
begin_variable
var1882
-1
2
above f38 f54
none-of-those
end_variable
begin_variable
var1883
-1
2
above f38 f55
none-of-those
end_variable
begin_variable
var1884
-1
2
above f38 f56
none-of-those
end_variable
begin_variable
var1885
-1
2
above f38 f57
none-of-those
end_variable
begin_variable
var1886
-1
2
above f38 f58
none-of-those
end_variable
begin_variable
var1887
-1
2
above f38 f59
none-of-those
end_variable
begin_variable
var1888
-1
2
above f38 f60
none-of-those
end_variable
begin_variable
var1889
-1
2
above f38 f61
none-of-those
end_variable
begin_variable
var1890
-1
2
above f38 f62
none-of-those
end_variable
begin_variable
var1891
-1
2
above f38 f63
none-of-those
end_variable
begin_variable
var1892
-1
2
above f38 f64
none-of-those
end_variable
begin_variable
var1893
-1
2
above f38 f65
none-of-those
end_variable
begin_variable
var1894
-1
2
above f38 f66
none-of-those
end_variable
begin_variable
var1895
-1
2
above f38 f67
none-of-those
end_variable
begin_variable
var1896
-1
2
above f38 f68
none-of-those
end_variable
begin_variable
var1897
-1
2
above f38 f69
none-of-those
end_variable
begin_variable
var1898
-1
2
above f38 f70
none-of-those
end_variable
begin_variable
var1899
-1
2
above f38 f71
none-of-those
end_variable
begin_variable
var1900
-1
2
above f38 f72
none-of-those
end_variable
begin_variable
var1901
-1
2
above f38 f73
none-of-those
end_variable
begin_variable
var1902
-1
2
above f38 f74
none-of-those
end_variable
begin_variable
var1903
-1
2
above f38 f75
none-of-those
end_variable
begin_variable
var1904
-1
2
above f38 f76
none-of-those
end_variable
begin_variable
var1905
-1
2
above f38 f77
none-of-those
end_variable
begin_variable
var1906
-1
2
above f38 f78
none-of-those
end_variable
begin_variable
var1907
-1
2
above f38 f79
none-of-those
end_variable
begin_variable
var1908
-1
2
above f38 f80
none-of-those
end_variable
begin_variable
var1909
-1
2
above f39 f40
none-of-those
end_variable
begin_variable
var1910
-1
2
above f39 f41
none-of-those
end_variable
begin_variable
var1911
-1
2
above f39 f42
none-of-those
end_variable
begin_variable
var1912
-1
2
above f39 f43
none-of-those
end_variable
begin_variable
var1913
-1
2
above f39 f44
none-of-those
end_variable
begin_variable
var1914
-1
2
above f39 f45
none-of-those
end_variable
begin_variable
var1915
-1
2
above f39 f46
none-of-those
end_variable
begin_variable
var1916
-1
2
above f39 f47
none-of-those
end_variable
begin_variable
var1917
-1
2
above f39 f48
none-of-those
end_variable
begin_variable
var1918
-1
2
above f39 f49
none-of-those
end_variable
begin_variable
var1919
-1
2
above f39 f50
none-of-those
end_variable
begin_variable
var1920
-1
2
above f39 f51
none-of-those
end_variable
begin_variable
var1921
-1
2
above f39 f52
none-of-those
end_variable
begin_variable
var1922
-1
2
above f39 f53
none-of-those
end_variable
begin_variable
var1923
-1
2
above f39 f54
none-of-those
end_variable
begin_variable
var1924
-1
2
above f39 f55
none-of-those
end_variable
begin_variable
var1925
-1
2
above f39 f56
none-of-those
end_variable
begin_variable
var1926
-1
2
above f39 f57
none-of-those
end_variable
begin_variable
var1927
-1
2
above f39 f58
none-of-those
end_variable
begin_variable
var1928
-1
2
above f39 f59
none-of-those
end_variable
begin_variable
var1929
-1
2
above f39 f60
none-of-those
end_variable
begin_variable
var1930
-1
2
above f39 f61
none-of-those
end_variable
begin_variable
var1931
-1
2
above f39 f62
none-of-those
end_variable
begin_variable
var1932
-1
2
above f39 f63
none-of-those
end_variable
begin_variable
var1933
-1
2
above f39 f64
none-of-those
end_variable
begin_variable
var1934
-1
2
above f39 f65
none-of-those
end_variable
begin_variable
var1935
-1
2
above f39 f66
none-of-those
end_variable
begin_variable
var1936
-1
2
above f39 f67
none-of-those
end_variable
begin_variable
var1937
-1
2
above f39 f68
none-of-those
end_variable
begin_variable
var1938
-1
2
above f39 f69
none-of-those
end_variable
begin_variable
var1939
-1
2
above f39 f70
none-of-those
end_variable
begin_variable
var1940
-1
2
above f39 f71
none-of-those
end_variable
begin_variable
var1941
-1
2
above f39 f72
none-of-those
end_variable
begin_variable
var1942
-1
2
above f39 f73
none-of-those
end_variable
begin_variable
var1943
-1
2
above f39 f74
none-of-those
end_variable
begin_variable
var1944
-1
2
above f39 f75
none-of-those
end_variable
begin_variable
var1945
-1
2
above f39 f76
none-of-those
end_variable
begin_variable
var1946
-1
2
above f39 f77
none-of-those
end_variable
begin_variable
var1947
-1
2
above f39 f78
none-of-those
end_variable
begin_variable
var1948
-1
2
above f39 f79
none-of-those
end_variable
begin_variable
var1949
-1
2
above f39 f80
none-of-those
end_variable
begin_variable
var1950
-1
2
above f4 f10
none-of-those
end_variable
begin_variable
var1951
-1
2
above f4 f11
none-of-those
end_variable
begin_variable
var1952
-1
2
above f4 f12
none-of-those
end_variable
begin_variable
var1953
-1
2
above f4 f13
none-of-those
end_variable
begin_variable
var1954
-1
2
above f4 f14
none-of-those
end_variable
begin_variable
var1955
-1
2
above f4 f15
none-of-those
end_variable
begin_variable
var1956
-1
2
above f4 f16
none-of-those
end_variable
begin_variable
var1957
-1
2
above f4 f17
none-of-those
end_variable
begin_variable
var1958
-1
2
above f4 f18
none-of-those
end_variable
begin_variable
var1959
-1
2
above f4 f19
none-of-those
end_variable
begin_variable
var1960
-1
2
above f4 f20
none-of-those
end_variable
begin_variable
var1961
-1
2
above f4 f21
none-of-those
end_variable
begin_variable
var1962
-1
2
above f4 f22
none-of-those
end_variable
begin_variable
var1963
-1
2
above f4 f23
none-of-those
end_variable
begin_variable
var1964
-1
2
above f4 f24
none-of-those
end_variable
begin_variable
var1965
-1
2
above f4 f25
none-of-those
end_variable
begin_variable
var1966
-1
2
above f4 f26
none-of-those
end_variable
begin_variable
var1967
-1
2
above f4 f27
none-of-those
end_variable
begin_variable
var1968
-1
2
above f4 f28
none-of-those
end_variable
begin_variable
var1969
-1
2
above f4 f29
none-of-those
end_variable
begin_variable
var1970
-1
2
above f4 f30
none-of-those
end_variable
begin_variable
var1971
-1
2
above f4 f31
none-of-those
end_variable
begin_variable
var1972
-1
2
above f4 f32
none-of-those
end_variable
begin_variable
var1973
-1
2
above f4 f33
none-of-those
end_variable
begin_variable
var1974
-1
2
above f4 f34
none-of-those
end_variable
begin_variable
var1975
-1
2
above f4 f35
none-of-those
end_variable
begin_variable
var1976
-1
2
above f4 f36
none-of-those
end_variable
begin_variable
var1977
-1
2
above f4 f37
none-of-those
end_variable
begin_variable
var1978
-1
2
above f4 f38
none-of-those
end_variable
begin_variable
var1979
-1
2
above f4 f39
none-of-those
end_variable
begin_variable
var1980
-1
2
above f4 f40
none-of-those
end_variable
begin_variable
var1981
-1
2
above f4 f41
none-of-those
end_variable
begin_variable
var1982
-1
2
above f4 f42
none-of-those
end_variable
begin_variable
var1983
-1
2
above f4 f43
none-of-those
end_variable
begin_variable
var1984
-1
2
above f4 f44
none-of-those
end_variable
begin_variable
var1985
-1
2
above f4 f45
none-of-those
end_variable
begin_variable
var1986
-1
2
above f4 f46
none-of-those
end_variable
begin_variable
var1987
-1
2
above f4 f47
none-of-those
end_variable
begin_variable
var1988
-1
2
above f4 f48
none-of-those
end_variable
begin_variable
var1989
-1
2
above f4 f49
none-of-those
end_variable
begin_variable
var1990
-1
2
above f4 f5
none-of-those
end_variable
begin_variable
var1991
-1
2
above f4 f50
none-of-those
end_variable
begin_variable
var1992
-1
2
above f4 f51
none-of-those
end_variable
begin_variable
var1993
-1
2
above f4 f52
none-of-those
end_variable
begin_variable
var1994
-1
2
above f4 f53
none-of-those
end_variable
begin_variable
var1995
-1
2
above f4 f54
none-of-those
end_variable
begin_variable
var1996
-1
2
above f4 f55
none-of-those
end_variable
begin_variable
var1997
-1
2
above f4 f56
none-of-those
end_variable
begin_variable
var1998
-1
2
above f4 f57
none-of-those
end_variable
begin_variable
var1999
-1
2
above f4 f58
none-of-those
end_variable
begin_variable
var2000
-1
2
above f4 f59
none-of-those
end_variable
begin_variable
var2001
-1
2
above f4 f6
none-of-those
end_variable
begin_variable
var2002
-1
2
above f4 f60
none-of-those
end_variable
begin_variable
var2003
-1
2
above f4 f61
none-of-those
end_variable
begin_variable
var2004
-1
2
above f4 f62
none-of-those
end_variable
begin_variable
var2005
-1
2
above f4 f63
none-of-those
end_variable
begin_variable
var2006
-1
2
above f4 f64
none-of-those
end_variable
begin_variable
var2007
-1
2
above f4 f65
none-of-those
end_variable
begin_variable
var2008
-1
2
above f4 f66
none-of-those
end_variable
begin_variable
var2009
-1
2
above f4 f67
none-of-those
end_variable
begin_variable
var2010
-1
2
above f4 f68
none-of-those
end_variable
begin_variable
var2011
-1
2
above f4 f69
none-of-those
end_variable
begin_variable
var2012
-1
2
above f4 f7
none-of-those
end_variable
begin_variable
var2013
-1
2
above f4 f70
none-of-those
end_variable
begin_variable
var2014
-1
2
above f4 f71
none-of-those
end_variable
begin_variable
var2015
-1
2
above f4 f72
none-of-those
end_variable
begin_variable
var2016
-1
2
above f4 f73
none-of-those
end_variable
begin_variable
var2017
-1
2
above f4 f74
none-of-those
end_variable
begin_variable
var2018
-1
2
above f4 f75
none-of-those
end_variable
begin_variable
var2019
-1
2
above f4 f76
none-of-those
end_variable
begin_variable
var2020
-1
2
above f4 f77
none-of-those
end_variable
begin_variable
var2021
-1
2
above f4 f78
none-of-those
end_variable
begin_variable
var2022
-1
2
above f4 f79
none-of-those
end_variable
begin_variable
var2023
-1
2
above f4 f8
none-of-those
end_variable
begin_variable
var2024
-1
2
above f4 f80
none-of-those
end_variable
begin_variable
var2025
-1
2
above f4 f9
none-of-those
end_variable
begin_variable
var2026
-1
2
above f40 f41
none-of-those
end_variable
begin_variable
var2027
-1
2
above f40 f42
none-of-those
end_variable
begin_variable
var2028
-1
2
above f40 f43
none-of-those
end_variable
begin_variable
var2029
-1
2
above f40 f44
none-of-those
end_variable
begin_variable
var2030
-1
2
above f40 f45
none-of-those
end_variable
begin_variable
var2031
-1
2
above f40 f46
none-of-those
end_variable
begin_variable
var2032
-1
2
above f40 f47
none-of-those
end_variable
begin_variable
var2033
-1
2
above f40 f48
none-of-those
end_variable
begin_variable
var2034
-1
2
above f40 f49
none-of-those
end_variable
begin_variable
var2035
-1
2
above f40 f50
none-of-those
end_variable
begin_variable
var2036
-1
2
above f40 f51
none-of-those
end_variable
begin_variable
var2037
-1
2
above f40 f52
none-of-those
end_variable
begin_variable
var2038
-1
2
above f40 f53
none-of-those
end_variable
begin_variable
var2039
-1
2
above f40 f54
none-of-those
end_variable
begin_variable
var2040
-1
2
above f40 f55
none-of-those
end_variable
begin_variable
var2041
-1
2
above f40 f56
none-of-those
end_variable
begin_variable
var2042
-1
2
above f40 f57
none-of-those
end_variable
begin_variable
var2043
-1
2
above f40 f58
none-of-those
end_variable
begin_variable
var2044
-1
2
above f40 f59
none-of-those
end_variable
begin_variable
var2045
-1
2
above f40 f60
none-of-those
end_variable
begin_variable
var2046
-1
2
above f40 f61
none-of-those
end_variable
begin_variable
var2047
-1
2
above f40 f62
none-of-those
end_variable
begin_variable
var2048
-1
2
above f40 f63
none-of-those
end_variable
begin_variable
var2049
-1
2
above f40 f64
none-of-those
end_variable
begin_variable
var2050
-1
2
above f40 f65
none-of-those
end_variable
begin_variable
var2051
-1
2
above f40 f66
none-of-those
end_variable
begin_variable
var2052
-1
2
above f40 f67
none-of-those
end_variable
begin_variable
var2053
-1
2
above f40 f68
none-of-those
end_variable
begin_variable
var2054
-1
2
above f40 f69
none-of-those
end_variable
begin_variable
var2055
-1
2
above f40 f70
none-of-those
end_variable
begin_variable
var2056
-1
2
above f40 f71
none-of-those
end_variable
begin_variable
var2057
-1
2
above f40 f72
none-of-those
end_variable
begin_variable
var2058
-1
2
above f40 f73
none-of-those
end_variable
begin_variable
var2059
-1
2
above f40 f74
none-of-those
end_variable
begin_variable
var2060
-1
2
above f40 f75
none-of-those
end_variable
begin_variable
var2061
-1
2
above f40 f76
none-of-those
end_variable
begin_variable
var2062
-1
2
above f40 f77
none-of-those
end_variable
begin_variable
var2063
-1
2
above f40 f78
none-of-those
end_variable
begin_variable
var2064
-1
2
above f40 f79
none-of-those
end_variable
begin_variable
var2065
-1
2
above f40 f80
none-of-those
end_variable
begin_variable
var2066
-1
2
above f41 f42
none-of-those
end_variable
begin_variable
var2067
-1
2
above f41 f43
none-of-those
end_variable
begin_variable
var2068
-1
2
above f41 f44
none-of-those
end_variable
begin_variable
var2069
-1
2
above f41 f45
none-of-those
end_variable
begin_variable
var2070
-1
2
above f41 f46
none-of-those
end_variable
begin_variable
var2071
-1
2
above f41 f47
none-of-those
end_variable
begin_variable
var2072
-1
2
above f41 f48
none-of-those
end_variable
begin_variable
var2073
-1
2
above f41 f49
none-of-those
end_variable
begin_variable
var2074
-1
2
above f41 f50
none-of-those
end_variable
begin_variable
var2075
-1
2
above f41 f51
none-of-those
end_variable
begin_variable
var2076
-1
2
above f41 f52
none-of-those
end_variable
begin_variable
var2077
-1
2
above f41 f53
none-of-those
end_variable
begin_variable
var2078
-1
2
above f41 f54
none-of-those
end_variable
begin_variable
var2079
-1
2
above f41 f55
none-of-those
end_variable
begin_variable
var2080
-1
2
above f41 f56
none-of-those
end_variable
begin_variable
var2081
-1
2
above f41 f57
none-of-those
end_variable
begin_variable
var2082
-1
2
above f41 f58
none-of-those
end_variable
begin_variable
var2083
-1
2
above f41 f59
none-of-those
end_variable
begin_variable
var2084
-1
2
above f41 f60
none-of-those
end_variable
begin_variable
var2085
-1
2
above f41 f61
none-of-those
end_variable
begin_variable
var2086
-1
2
above f41 f62
none-of-those
end_variable
begin_variable
var2087
-1
2
above f41 f63
none-of-those
end_variable
begin_variable
var2088
-1
2
above f41 f64
none-of-those
end_variable
begin_variable
var2089
-1
2
above f41 f65
none-of-those
end_variable
begin_variable
var2090
-1
2
above f41 f66
none-of-those
end_variable
begin_variable
var2091
-1
2
above f41 f67
none-of-those
end_variable
begin_variable
var2092
-1
2
above f41 f68
none-of-those
end_variable
begin_variable
var2093
-1
2
above f41 f69
none-of-those
end_variable
begin_variable
var2094
-1
2
above f41 f70
none-of-those
end_variable
begin_variable
var2095
-1
2
above f41 f71
none-of-those
end_variable
begin_variable
var2096
-1
2
above f41 f72
none-of-those
end_variable
begin_variable
var2097
-1
2
above f41 f73
none-of-those
end_variable
begin_variable
var2098
-1
2
above f41 f74
none-of-those
end_variable
begin_variable
var2099
-1
2
above f41 f75
none-of-those
end_variable
begin_variable
var2100
-1
2
above f41 f76
none-of-those
end_variable
begin_variable
var2101
-1
2
above f41 f77
none-of-those
end_variable
begin_variable
var2102
-1
2
above f41 f78
none-of-those
end_variable
begin_variable
var2103
-1
2
above f41 f79
none-of-those
end_variable
begin_variable
var2104
-1
2
above f41 f80
none-of-those
end_variable
begin_variable
var2105
-1
2
above f42 f43
none-of-those
end_variable
begin_variable
var2106
-1
2
above f42 f44
none-of-those
end_variable
begin_variable
var2107
-1
2
above f42 f45
none-of-those
end_variable
begin_variable
var2108
-1
2
above f42 f46
none-of-those
end_variable
begin_variable
var2109
-1
2
above f42 f47
none-of-those
end_variable
begin_variable
var2110
-1
2
above f42 f48
none-of-those
end_variable
begin_variable
var2111
-1
2
above f42 f49
none-of-those
end_variable
begin_variable
var2112
-1
2
above f42 f50
none-of-those
end_variable
begin_variable
var2113
-1
2
above f42 f51
none-of-those
end_variable
begin_variable
var2114
-1
2
above f42 f52
none-of-those
end_variable
begin_variable
var2115
-1
2
above f42 f53
none-of-those
end_variable
begin_variable
var2116
-1
2
above f42 f54
none-of-those
end_variable
begin_variable
var2117
-1
2
above f42 f55
none-of-those
end_variable
begin_variable
var2118
-1
2
above f42 f56
none-of-those
end_variable
begin_variable
var2119
-1
2
above f42 f57
none-of-those
end_variable
begin_variable
var2120
-1
2
above f42 f58
none-of-those
end_variable
begin_variable
var2121
-1
2
above f42 f59
none-of-those
end_variable
begin_variable
var2122
-1
2
above f42 f60
none-of-those
end_variable
begin_variable
var2123
-1
2
above f42 f61
none-of-those
end_variable
begin_variable
var2124
-1
2
above f42 f62
none-of-those
end_variable
begin_variable
var2125
-1
2
above f42 f63
none-of-those
end_variable
begin_variable
var2126
-1
2
above f42 f64
none-of-those
end_variable
begin_variable
var2127
-1
2
above f42 f65
none-of-those
end_variable
begin_variable
var2128
-1
2
above f42 f66
none-of-those
end_variable
begin_variable
var2129
-1
2
above f42 f67
none-of-those
end_variable
begin_variable
var2130
-1
2
above f42 f68
none-of-those
end_variable
begin_variable
var2131
-1
2
above f42 f69
none-of-those
end_variable
begin_variable
var2132
-1
2
above f42 f70
none-of-those
end_variable
begin_variable
var2133
-1
2
above f42 f71
none-of-those
end_variable
begin_variable
var2134
-1
2
above f42 f72
none-of-those
end_variable
begin_variable
var2135
-1
2
above f42 f73
none-of-those
end_variable
begin_variable
var2136
-1
2
above f42 f74
none-of-those
end_variable
begin_variable
var2137
-1
2
above f42 f75
none-of-those
end_variable
begin_variable
var2138
-1
2
above f42 f76
none-of-those
end_variable
begin_variable
var2139
-1
2
above f42 f77
none-of-those
end_variable
begin_variable
var2140
-1
2
above f42 f78
none-of-those
end_variable
begin_variable
var2141
-1
2
above f42 f79
none-of-those
end_variable
begin_variable
var2142
-1
2
above f42 f80
none-of-those
end_variable
begin_variable
var2143
-1
2
above f43 f44
none-of-those
end_variable
begin_variable
var2144
-1
2
above f43 f45
none-of-those
end_variable
begin_variable
var2145
-1
2
above f43 f46
none-of-those
end_variable
begin_variable
var2146
-1
2
above f43 f47
none-of-those
end_variable
begin_variable
var2147
-1
2
above f43 f48
none-of-those
end_variable
begin_variable
var2148
-1
2
above f43 f49
none-of-those
end_variable
begin_variable
var2149
-1
2
above f43 f50
none-of-those
end_variable
begin_variable
var2150
-1
2
above f43 f51
none-of-those
end_variable
begin_variable
var2151
-1
2
above f43 f52
none-of-those
end_variable
begin_variable
var2152
-1
2
above f43 f53
none-of-those
end_variable
begin_variable
var2153
-1
2
above f43 f54
none-of-those
end_variable
begin_variable
var2154
-1
2
above f43 f55
none-of-those
end_variable
begin_variable
var2155
-1
2
above f43 f56
none-of-those
end_variable
begin_variable
var2156
-1
2
above f43 f57
none-of-those
end_variable
begin_variable
var2157
-1
2
above f43 f58
none-of-those
end_variable
begin_variable
var2158
-1
2
above f43 f59
none-of-those
end_variable
begin_variable
var2159
-1
2
above f43 f60
none-of-those
end_variable
begin_variable
var2160
-1
2
above f43 f61
none-of-those
end_variable
begin_variable
var2161
-1
2
above f43 f62
none-of-those
end_variable
begin_variable
var2162
-1
2
above f43 f63
none-of-those
end_variable
begin_variable
var2163
-1
2
above f43 f64
none-of-those
end_variable
begin_variable
var2164
-1
2
above f43 f65
none-of-those
end_variable
begin_variable
var2165
-1
2
above f43 f66
none-of-those
end_variable
begin_variable
var2166
-1
2
above f43 f67
none-of-those
end_variable
begin_variable
var2167
-1
2
above f43 f68
none-of-those
end_variable
begin_variable
var2168
-1
2
above f43 f69
none-of-those
end_variable
begin_variable
var2169
-1
2
above f43 f70
none-of-those
end_variable
begin_variable
var2170
-1
2
above f43 f71
none-of-those
end_variable
begin_variable
var2171
-1
2
above f43 f72
none-of-those
end_variable
begin_variable
var2172
-1
2
above f43 f73
none-of-those
end_variable
begin_variable
var2173
-1
2
above f43 f74
none-of-those
end_variable
begin_variable
var2174
-1
2
above f43 f75
none-of-those
end_variable
begin_variable
var2175
-1
2
above f43 f76
none-of-those
end_variable
begin_variable
var2176
-1
2
above f43 f77
none-of-those
end_variable
begin_variable
var2177
-1
2
above f43 f78
none-of-those
end_variable
begin_variable
var2178
-1
2
above f43 f79
none-of-those
end_variable
begin_variable
var2179
-1
2
above f43 f80
none-of-those
end_variable
begin_variable
var2180
-1
2
above f44 f45
none-of-those
end_variable
begin_variable
var2181
-1
2
above f44 f46
none-of-those
end_variable
begin_variable
var2182
-1
2
above f44 f47
none-of-those
end_variable
begin_variable
var2183
-1
2
above f44 f48
none-of-those
end_variable
begin_variable
var2184
-1
2
above f44 f49
none-of-those
end_variable
begin_variable
var2185
-1
2
above f44 f50
none-of-those
end_variable
begin_variable
var2186
-1
2
above f44 f51
none-of-those
end_variable
begin_variable
var2187
-1
2
above f44 f52
none-of-those
end_variable
begin_variable
var2188
-1
2
above f44 f53
none-of-those
end_variable
begin_variable
var2189
-1
2
above f44 f54
none-of-those
end_variable
begin_variable
var2190
-1
2
above f44 f55
none-of-those
end_variable
begin_variable
var2191
-1
2
above f44 f56
none-of-those
end_variable
begin_variable
var2192
-1
2
above f44 f57
none-of-those
end_variable
begin_variable
var2193
-1
2
above f44 f58
none-of-those
end_variable
begin_variable
var2194
-1
2
above f44 f59
none-of-those
end_variable
begin_variable
var2195
-1
2
above f44 f60
none-of-those
end_variable
begin_variable
var2196
-1
2
above f44 f61
none-of-those
end_variable
begin_variable
var2197
-1
2
above f44 f62
none-of-those
end_variable
begin_variable
var2198
-1
2
above f44 f63
none-of-those
end_variable
begin_variable
var2199
-1
2
above f44 f64
none-of-those
end_variable
begin_variable
var2200
-1
2
above f44 f65
none-of-those
end_variable
begin_variable
var2201
-1
2
above f44 f66
none-of-those
end_variable
begin_variable
var2202
-1
2
above f44 f67
none-of-those
end_variable
begin_variable
var2203
-1
2
above f44 f68
none-of-those
end_variable
begin_variable
var2204
-1
2
above f44 f69
none-of-those
end_variable
begin_variable
var2205
-1
2
above f44 f70
none-of-those
end_variable
begin_variable
var2206
-1
2
above f44 f71
none-of-those
end_variable
begin_variable
var2207
-1
2
above f44 f72
none-of-those
end_variable
begin_variable
var2208
-1
2
above f44 f73
none-of-those
end_variable
begin_variable
var2209
-1
2
above f44 f74
none-of-those
end_variable
begin_variable
var2210
-1
2
above f44 f75
none-of-those
end_variable
begin_variable
var2211
-1
2
above f44 f76
none-of-those
end_variable
begin_variable
var2212
-1
2
above f44 f77
none-of-those
end_variable
begin_variable
var2213
-1
2
above f44 f78
none-of-those
end_variable
begin_variable
var2214
-1
2
above f44 f79
none-of-those
end_variable
begin_variable
var2215
-1
2
above f44 f80
none-of-those
end_variable
begin_variable
var2216
-1
2
above f45 f46
none-of-those
end_variable
begin_variable
var2217
-1
2
above f45 f47
none-of-those
end_variable
begin_variable
var2218
-1
2
above f45 f48
none-of-those
end_variable
begin_variable
var2219
-1
2
above f45 f49
none-of-those
end_variable
begin_variable
var2220
-1
2
above f45 f50
none-of-those
end_variable
begin_variable
var2221
-1
2
above f45 f51
none-of-those
end_variable
begin_variable
var2222
-1
2
above f45 f52
none-of-those
end_variable
begin_variable
var2223
-1
2
above f45 f53
none-of-those
end_variable
begin_variable
var2224
-1
2
above f45 f54
none-of-those
end_variable
begin_variable
var2225
-1
2
above f45 f55
none-of-those
end_variable
begin_variable
var2226
-1
2
above f45 f56
none-of-those
end_variable
begin_variable
var2227
-1
2
above f45 f57
none-of-those
end_variable
begin_variable
var2228
-1
2
above f45 f58
none-of-those
end_variable
begin_variable
var2229
-1
2
above f45 f59
none-of-those
end_variable
begin_variable
var2230
-1
2
above f45 f60
none-of-those
end_variable
begin_variable
var2231
-1
2
above f45 f61
none-of-those
end_variable
begin_variable
var2232
-1
2
above f45 f62
none-of-those
end_variable
begin_variable
var2233
-1
2
above f45 f63
none-of-those
end_variable
begin_variable
var2234
-1
2
above f45 f64
none-of-those
end_variable
begin_variable
var2235
-1
2
above f45 f65
none-of-those
end_variable
begin_variable
var2236
-1
2
above f45 f66
none-of-those
end_variable
begin_variable
var2237
-1
2
above f45 f67
none-of-those
end_variable
begin_variable
var2238
-1
2
above f45 f68
none-of-those
end_variable
begin_variable
var2239
-1
2
above f45 f69
none-of-those
end_variable
begin_variable
var2240
-1
2
above f45 f70
none-of-those
end_variable
begin_variable
var2241
-1
2
above f45 f71
none-of-those
end_variable
begin_variable
var2242
-1
2
above f45 f72
none-of-those
end_variable
begin_variable
var2243
-1
2
above f45 f73
none-of-those
end_variable
begin_variable
var2244
-1
2
above f45 f74
none-of-those
end_variable
begin_variable
var2245
-1
2
above f45 f75
none-of-those
end_variable
begin_variable
var2246
-1
2
above f45 f76
none-of-those
end_variable
begin_variable
var2247
-1
2
above f45 f77
none-of-those
end_variable
begin_variable
var2248
-1
2
above f45 f78
none-of-those
end_variable
begin_variable
var2249
-1
2
above f45 f79
none-of-those
end_variable
begin_variable
var2250
-1
2
above f45 f80
none-of-those
end_variable
begin_variable
var2251
-1
2
above f46 f47
none-of-those
end_variable
begin_variable
var2252
-1
2
above f46 f48
none-of-those
end_variable
begin_variable
var2253
-1
2
above f46 f49
none-of-those
end_variable
begin_variable
var2254
-1
2
above f46 f50
none-of-those
end_variable
begin_variable
var2255
-1
2
above f46 f51
none-of-those
end_variable
begin_variable
var2256
-1
2
above f46 f52
none-of-those
end_variable
begin_variable
var2257
-1
2
above f46 f53
none-of-those
end_variable
begin_variable
var2258
-1
2
above f46 f54
none-of-those
end_variable
begin_variable
var2259
-1
2
above f46 f55
none-of-those
end_variable
begin_variable
var2260
-1
2
above f46 f56
none-of-those
end_variable
begin_variable
var2261
-1
2
above f46 f57
none-of-those
end_variable
begin_variable
var2262
-1
2
above f46 f58
none-of-those
end_variable
begin_variable
var2263
-1
2
above f46 f59
none-of-those
end_variable
begin_variable
var2264
-1
2
above f46 f60
none-of-those
end_variable
begin_variable
var2265
-1
2
above f46 f61
none-of-those
end_variable
begin_variable
var2266
-1
2
above f46 f62
none-of-those
end_variable
begin_variable
var2267
-1
2
above f46 f63
none-of-those
end_variable
begin_variable
var2268
-1
2
above f46 f64
none-of-those
end_variable
begin_variable
var2269
-1
2
above f46 f65
none-of-those
end_variable
begin_variable
var2270
-1
2
above f46 f66
none-of-those
end_variable
begin_variable
var2271
-1
2
above f46 f67
none-of-those
end_variable
begin_variable
var2272
-1
2
above f46 f68
none-of-those
end_variable
begin_variable
var2273
-1
2
above f46 f69
none-of-those
end_variable
begin_variable
var2274
-1
2
above f46 f70
none-of-those
end_variable
begin_variable
var2275
-1
2
above f46 f71
none-of-those
end_variable
begin_variable
var2276
-1
2
above f46 f72
none-of-those
end_variable
begin_variable
var2277
-1
2
above f46 f73
none-of-those
end_variable
begin_variable
var2278
-1
2
above f46 f74
none-of-those
end_variable
begin_variable
var2279
-1
2
above f46 f75
none-of-those
end_variable
begin_variable
var2280
-1
2
above f46 f76
none-of-those
end_variable
begin_variable
var2281
-1
2
above f46 f77
none-of-those
end_variable
begin_variable
var2282
-1
2
above f46 f78
none-of-those
end_variable
begin_variable
var2283
-1
2
above f46 f79
none-of-those
end_variable
begin_variable
var2284
-1
2
above f46 f80
none-of-those
end_variable
begin_variable
var2285
-1
2
above f47 f48
none-of-those
end_variable
begin_variable
var2286
-1
2
above f47 f49
none-of-those
end_variable
begin_variable
var2287
-1
2
above f47 f50
none-of-those
end_variable
begin_variable
var2288
-1
2
above f47 f51
none-of-those
end_variable
begin_variable
var2289
-1
2
above f47 f52
none-of-those
end_variable
begin_variable
var2290
-1
2
above f47 f53
none-of-those
end_variable
begin_variable
var2291
-1
2
above f47 f54
none-of-those
end_variable
begin_variable
var2292
-1
2
above f47 f55
none-of-those
end_variable
begin_variable
var2293
-1
2
above f47 f56
none-of-those
end_variable
begin_variable
var2294
-1
2
above f47 f57
none-of-those
end_variable
begin_variable
var2295
-1
2
above f47 f58
none-of-those
end_variable
begin_variable
var2296
-1
2
above f47 f59
none-of-those
end_variable
begin_variable
var2297
-1
2
above f47 f60
none-of-those
end_variable
begin_variable
var2298
-1
2
above f47 f61
none-of-those
end_variable
begin_variable
var2299
-1
2
above f47 f62
none-of-those
end_variable
begin_variable
var2300
-1
2
above f47 f63
none-of-those
end_variable
begin_variable
var2301
-1
2
above f47 f64
none-of-those
end_variable
begin_variable
var2302
-1
2
above f47 f65
none-of-those
end_variable
begin_variable
var2303
-1
2
above f47 f66
none-of-those
end_variable
begin_variable
var2304
-1
2
above f47 f67
none-of-those
end_variable
begin_variable
var2305
-1
2
above f47 f68
none-of-those
end_variable
begin_variable
var2306
-1
2
above f47 f69
none-of-those
end_variable
begin_variable
var2307
-1
2
above f47 f70
none-of-those
end_variable
begin_variable
var2308
-1
2
above f47 f71
none-of-those
end_variable
begin_variable
var2309
-1
2
above f47 f72
none-of-those
end_variable
begin_variable
var2310
-1
2
above f47 f73
none-of-those
end_variable
begin_variable
var2311
-1
2
above f47 f74
none-of-those
end_variable
begin_variable
var2312
-1
2
above f47 f75
none-of-those
end_variable
begin_variable
var2313
-1
2
above f47 f76
none-of-those
end_variable
begin_variable
var2314
-1
2
above f47 f77
none-of-those
end_variable
begin_variable
var2315
-1
2
above f47 f78
none-of-those
end_variable
begin_variable
var2316
-1
2
above f47 f79
none-of-those
end_variable
begin_variable
var2317
-1
2
above f47 f80
none-of-those
end_variable
begin_variable
var2318
-1
2
above f48 f49
none-of-those
end_variable
begin_variable
var2319
-1
2
above f48 f50
none-of-those
end_variable
begin_variable
var2320
-1
2
above f48 f51
none-of-those
end_variable
begin_variable
var2321
-1
2
above f48 f52
none-of-those
end_variable
begin_variable
var2322
-1
2
above f48 f53
none-of-those
end_variable
begin_variable
var2323
-1
2
above f48 f54
none-of-those
end_variable
begin_variable
var2324
-1
2
above f48 f55
none-of-those
end_variable
begin_variable
var2325
-1
2
above f48 f56
none-of-those
end_variable
begin_variable
var2326
-1
2
above f48 f57
none-of-those
end_variable
begin_variable
var2327
-1
2
above f48 f58
none-of-those
end_variable
begin_variable
var2328
-1
2
above f48 f59
none-of-those
end_variable
begin_variable
var2329
-1
2
above f48 f60
none-of-those
end_variable
begin_variable
var2330
-1
2
above f48 f61
none-of-those
end_variable
begin_variable
var2331
-1
2
above f48 f62
none-of-those
end_variable
begin_variable
var2332
-1
2
above f48 f63
none-of-those
end_variable
begin_variable
var2333
-1
2
above f48 f64
none-of-those
end_variable
begin_variable
var2334
-1
2
above f48 f65
none-of-those
end_variable
begin_variable
var2335
-1
2
above f48 f66
none-of-those
end_variable
begin_variable
var2336
-1
2
above f48 f67
none-of-those
end_variable
begin_variable
var2337
-1
2
above f48 f68
none-of-those
end_variable
begin_variable
var2338
-1
2
above f48 f69
none-of-those
end_variable
begin_variable
var2339
-1
2
above f48 f70
none-of-those
end_variable
begin_variable
var2340
-1
2
above f48 f71
none-of-those
end_variable
begin_variable
var2341
-1
2
above f48 f72
none-of-those
end_variable
begin_variable
var2342
-1
2
above f48 f73
none-of-those
end_variable
begin_variable
var2343
-1
2
above f48 f74
none-of-those
end_variable
begin_variable
var2344
-1
2
above f48 f75
none-of-those
end_variable
begin_variable
var2345
-1
2
above f48 f76
none-of-those
end_variable
begin_variable
var2346
-1
2
above f48 f77
none-of-those
end_variable
begin_variable
var2347
-1
2
above f48 f78
none-of-those
end_variable
begin_variable
var2348
-1
2
above f48 f79
none-of-those
end_variable
begin_variable
var2349
-1
2
above f48 f80
none-of-those
end_variable
begin_variable
var2350
-1
2
above f49 f50
none-of-those
end_variable
begin_variable
var2351
-1
2
above f49 f51
none-of-those
end_variable
begin_variable
var2352
-1
2
above f49 f52
none-of-those
end_variable
begin_variable
var2353
-1
2
above f49 f53
none-of-those
end_variable
begin_variable
var2354
-1
2
above f49 f54
none-of-those
end_variable
begin_variable
var2355
-1
2
above f49 f55
none-of-those
end_variable
begin_variable
var2356
-1
2
above f49 f56
none-of-those
end_variable
begin_variable
var2357
-1
2
above f49 f57
none-of-those
end_variable
begin_variable
var2358
-1
2
above f49 f58
none-of-those
end_variable
begin_variable
var2359
-1
2
above f49 f59
none-of-those
end_variable
begin_variable
var2360
-1
2
above f49 f60
none-of-those
end_variable
begin_variable
var2361
-1
2
above f49 f61
none-of-those
end_variable
begin_variable
var2362
-1
2
above f49 f62
none-of-those
end_variable
begin_variable
var2363
-1
2
above f49 f63
none-of-those
end_variable
begin_variable
var2364
-1
2
above f49 f64
none-of-those
end_variable
begin_variable
var2365
-1
2
above f49 f65
none-of-those
end_variable
begin_variable
var2366
-1
2
above f49 f66
none-of-those
end_variable
begin_variable
var2367
-1
2
above f49 f67
none-of-those
end_variable
begin_variable
var2368
-1
2
above f49 f68
none-of-those
end_variable
begin_variable
var2369
-1
2
above f49 f69
none-of-those
end_variable
begin_variable
var2370
-1
2
above f49 f70
none-of-those
end_variable
begin_variable
var2371
-1
2
above f49 f71
none-of-those
end_variable
begin_variable
var2372
-1
2
above f49 f72
none-of-those
end_variable
begin_variable
var2373
-1
2
above f49 f73
none-of-those
end_variable
begin_variable
var2374
-1
2
above f49 f74
none-of-those
end_variable
begin_variable
var2375
-1
2
above f49 f75
none-of-those
end_variable
begin_variable
var2376
-1
2
above f49 f76
none-of-those
end_variable
begin_variable
var2377
-1
2
above f49 f77
none-of-those
end_variable
begin_variable
var2378
-1
2
above f49 f78
none-of-those
end_variable
begin_variable
var2379
-1
2
above f49 f79
none-of-those
end_variable
begin_variable
var2380
-1
2
above f49 f80
none-of-those
end_variable
begin_variable
var2381
-1
2
above f5 f10
none-of-those
end_variable
begin_variable
var2382
-1
2
above f5 f11
none-of-those
end_variable
begin_variable
var2383
-1
2
above f5 f12
none-of-those
end_variable
begin_variable
var2384
-1
2
above f5 f13
none-of-those
end_variable
begin_variable
var2385
-1
2
above f5 f14
none-of-those
end_variable
begin_variable
var2386
-1
2
above f5 f15
none-of-those
end_variable
begin_variable
var2387
-1
2
above f5 f16
none-of-those
end_variable
begin_variable
var2388
-1
2
above f5 f17
none-of-those
end_variable
begin_variable
var2389
-1
2
above f5 f18
none-of-those
end_variable
begin_variable
var2390
-1
2
above f5 f19
none-of-those
end_variable
begin_variable
var2391
-1
2
above f5 f20
none-of-those
end_variable
begin_variable
var2392
-1
2
above f5 f21
none-of-those
end_variable
begin_variable
var2393
-1
2
above f5 f22
none-of-those
end_variable
begin_variable
var2394
-1
2
above f5 f23
none-of-those
end_variable
begin_variable
var2395
-1
2
above f5 f24
none-of-those
end_variable
begin_variable
var2396
-1
2
above f5 f25
none-of-those
end_variable
begin_variable
var2397
-1
2
above f5 f26
none-of-those
end_variable
begin_variable
var2398
-1
2
above f5 f27
none-of-those
end_variable
begin_variable
var2399
-1
2
above f5 f28
none-of-those
end_variable
begin_variable
var2400
-1
2
above f5 f29
none-of-those
end_variable
begin_variable
var2401
-1
2
above f5 f30
none-of-those
end_variable
begin_variable
var2402
-1
2
above f5 f31
none-of-those
end_variable
begin_variable
var2403
-1
2
above f5 f32
none-of-those
end_variable
begin_variable
var2404
-1
2
above f5 f33
none-of-those
end_variable
begin_variable
var2405
-1
2
above f5 f34
none-of-those
end_variable
begin_variable
var2406
-1
2
above f5 f35
none-of-those
end_variable
begin_variable
var2407
-1
2
above f5 f36
none-of-those
end_variable
begin_variable
var2408
-1
2
above f5 f37
none-of-those
end_variable
begin_variable
var2409
-1
2
above f5 f38
none-of-those
end_variable
begin_variable
var2410
-1
2
above f5 f39
none-of-those
end_variable
begin_variable
var2411
-1
2
above f5 f40
none-of-those
end_variable
begin_variable
var2412
-1
2
above f5 f41
none-of-those
end_variable
begin_variable
var2413
-1
2
above f5 f42
none-of-those
end_variable
begin_variable
var2414
-1
2
above f5 f43
none-of-those
end_variable
begin_variable
var2415
-1
2
above f5 f44
none-of-those
end_variable
begin_variable
var2416
-1
2
above f5 f45
none-of-those
end_variable
begin_variable
var2417
-1
2
above f5 f46
none-of-those
end_variable
begin_variable
var2418
-1
2
above f5 f47
none-of-those
end_variable
begin_variable
var2419
-1
2
above f5 f48
none-of-those
end_variable
begin_variable
var2420
-1
2
above f5 f49
none-of-those
end_variable
begin_variable
var2421
-1
2
above f5 f50
none-of-those
end_variable
begin_variable
var2422
-1
2
above f5 f51
none-of-those
end_variable
begin_variable
var2423
-1
2
above f5 f52
none-of-those
end_variable
begin_variable
var2424
-1
2
above f5 f53
none-of-those
end_variable
begin_variable
var2425
-1
2
above f5 f54
none-of-those
end_variable
begin_variable
var2426
-1
2
above f5 f55
none-of-those
end_variable
begin_variable
var2427
-1
2
above f5 f56
none-of-those
end_variable
begin_variable
var2428
-1
2
above f5 f57
none-of-those
end_variable
begin_variable
var2429
-1
2
above f5 f58
none-of-those
end_variable
begin_variable
var2430
-1
2
above f5 f59
none-of-those
end_variable
begin_variable
var2431
-1
2
above f5 f6
none-of-those
end_variable
begin_variable
var2432
-1
2
above f5 f60
none-of-those
end_variable
begin_variable
var2433
-1
2
above f5 f61
none-of-those
end_variable
begin_variable
var2434
-1
2
above f5 f62
none-of-those
end_variable
begin_variable
var2435
-1
2
above f5 f63
none-of-those
end_variable
begin_variable
var2436
-1
2
above f5 f64
none-of-those
end_variable
begin_variable
var2437
-1
2
above f5 f65
none-of-those
end_variable
begin_variable
var2438
-1
2
above f5 f66
none-of-those
end_variable
begin_variable
var2439
-1
2
above f5 f67
none-of-those
end_variable
begin_variable
var2440
-1
2
above f5 f68
none-of-those
end_variable
begin_variable
var2441
-1
2
above f5 f69
none-of-those
end_variable
begin_variable
var2442
-1
2
above f5 f7
none-of-those
end_variable
begin_variable
var2443
-1
2
above f5 f70
none-of-those
end_variable
begin_variable
var2444
-1
2
above f5 f71
none-of-those
end_variable
begin_variable
var2445
-1
2
above f5 f72
none-of-those
end_variable
begin_variable
var2446
-1
2
above f5 f73
none-of-those
end_variable
begin_variable
var2447
-1
2
above f5 f74
none-of-those
end_variable
begin_variable
var2448
-1
2
above f5 f75
none-of-those
end_variable
begin_variable
var2449
-1
2
above f5 f76
none-of-those
end_variable
begin_variable
var2450
-1
2
above f5 f77
none-of-those
end_variable
begin_variable
var2451
-1
2
above f5 f78
none-of-those
end_variable
begin_variable
var2452
-1
2
above f5 f79
none-of-those
end_variable
begin_variable
var2453
-1
2
above f5 f8
none-of-those
end_variable
begin_variable
var2454
-1
2
above f5 f80
none-of-those
end_variable
begin_variable
var2455
-1
2
above f5 f9
none-of-those
end_variable
begin_variable
var2456
-1
2
above f50 f51
none-of-those
end_variable
begin_variable
var2457
-1
2
above f50 f52
none-of-those
end_variable
begin_variable
var2458
-1
2
above f50 f53
none-of-those
end_variable
begin_variable
var2459
-1
2
above f50 f54
none-of-those
end_variable
begin_variable
var2460
-1
2
above f50 f55
none-of-those
end_variable
begin_variable
var2461
-1
2
above f50 f56
none-of-those
end_variable
begin_variable
var2462
-1
2
above f50 f57
none-of-those
end_variable
begin_variable
var2463
-1
2
above f50 f58
none-of-those
end_variable
begin_variable
var2464
-1
2
above f50 f59
none-of-those
end_variable
begin_variable
var2465
-1
2
above f50 f60
none-of-those
end_variable
begin_variable
var2466
-1
2
above f50 f61
none-of-those
end_variable
begin_variable
var2467
-1
2
above f50 f62
none-of-those
end_variable
begin_variable
var2468
-1
2
above f50 f63
none-of-those
end_variable
begin_variable
var2469
-1
2
above f50 f64
none-of-those
end_variable
begin_variable
var2470
-1
2
above f50 f65
none-of-those
end_variable
begin_variable
var2471
-1
2
above f50 f66
none-of-those
end_variable
begin_variable
var2472
-1
2
above f50 f67
none-of-those
end_variable
begin_variable
var2473
-1
2
above f50 f68
none-of-those
end_variable
begin_variable
var2474
-1
2
above f50 f69
none-of-those
end_variable
begin_variable
var2475
-1
2
above f50 f70
none-of-those
end_variable
begin_variable
var2476
-1
2
above f50 f71
none-of-those
end_variable
begin_variable
var2477
-1
2
above f50 f72
none-of-those
end_variable
begin_variable
var2478
-1
2
above f50 f73
none-of-those
end_variable
begin_variable
var2479
-1
2
above f50 f74
none-of-those
end_variable
begin_variable
var2480
-1
2
above f50 f75
none-of-those
end_variable
begin_variable
var2481
-1
2
above f50 f76
none-of-those
end_variable
begin_variable
var2482
-1
2
above f50 f77
none-of-those
end_variable
begin_variable
var2483
-1
2
above f50 f78
none-of-those
end_variable
begin_variable
var2484
-1
2
above f50 f79
none-of-those
end_variable
begin_variable
var2485
-1
2
above f50 f80
none-of-those
end_variable
begin_variable
var2486
-1
2
above f51 f52
none-of-those
end_variable
begin_variable
var2487
-1
2
above f51 f53
none-of-those
end_variable
begin_variable
var2488
-1
2
above f51 f54
none-of-those
end_variable
begin_variable
var2489
-1
2
above f51 f55
none-of-those
end_variable
begin_variable
var2490
-1
2
above f51 f56
none-of-those
end_variable
begin_variable
var2491
-1
2
above f51 f57
none-of-those
end_variable
begin_variable
var2492
-1
2
above f51 f58
none-of-those
end_variable
begin_variable
var2493
-1
2
above f51 f59
none-of-those
end_variable
begin_variable
var2494
-1
2
above f51 f60
none-of-those
end_variable
begin_variable
var2495
-1
2
above f51 f61
none-of-those
end_variable
begin_variable
var2496
-1
2
above f51 f62
none-of-those
end_variable
begin_variable
var2497
-1
2
above f51 f63
none-of-those
end_variable
begin_variable
var2498
-1
2
above f51 f64
none-of-those
end_variable
begin_variable
var2499
-1
2
above f51 f65
none-of-those
end_variable
begin_variable
var2500
-1
2
above f51 f66
none-of-those
end_variable
begin_variable
var2501
-1
2
above f51 f67
none-of-those
end_variable
begin_variable
var2502
-1
2
above f51 f68
none-of-those
end_variable
begin_variable
var2503
-1
2
above f51 f69
none-of-those
end_variable
begin_variable
var2504
-1
2
above f51 f70
none-of-those
end_variable
begin_variable
var2505
-1
2
above f51 f71
none-of-those
end_variable
begin_variable
var2506
-1
2
above f51 f72
none-of-those
end_variable
begin_variable
var2507
-1
2
above f51 f73
none-of-those
end_variable
begin_variable
var2508
-1
2
above f51 f74
none-of-those
end_variable
begin_variable
var2509
-1
2
above f51 f75
none-of-those
end_variable
begin_variable
var2510
-1
2
above f51 f76
none-of-those
end_variable
begin_variable
var2511
-1
2
above f51 f77
none-of-those
end_variable
begin_variable
var2512
-1
2
above f51 f78
none-of-those
end_variable
begin_variable
var2513
-1
2
above f51 f79
none-of-those
end_variable
begin_variable
var2514
-1
2
above f51 f80
none-of-those
end_variable
begin_variable
var2515
-1
2
above f52 f53
none-of-those
end_variable
begin_variable
var2516
-1
2
above f52 f54
none-of-those
end_variable
begin_variable
var2517
-1
2
above f52 f55
none-of-those
end_variable
begin_variable
var2518
-1
2
above f52 f56
none-of-those
end_variable
begin_variable
var2519
-1
2
above f52 f57
none-of-those
end_variable
begin_variable
var2520
-1
2
above f52 f58
none-of-those
end_variable
begin_variable
var2521
-1
2
above f52 f59
none-of-those
end_variable
begin_variable
var2522
-1
2
above f52 f60
none-of-those
end_variable
begin_variable
var2523
-1
2
above f52 f61
none-of-those
end_variable
begin_variable
var2524
-1
2
above f52 f62
none-of-those
end_variable
begin_variable
var2525
-1
2
above f52 f63
none-of-those
end_variable
begin_variable
var2526
-1
2
above f52 f64
none-of-those
end_variable
begin_variable
var2527
-1
2
above f52 f65
none-of-those
end_variable
begin_variable
var2528
-1
2
above f52 f66
none-of-those
end_variable
begin_variable
var2529
-1
2
above f52 f67
none-of-those
end_variable
begin_variable
var2530
-1
2
above f52 f68
none-of-those
end_variable
begin_variable
var2531
-1
2
above f52 f69
none-of-those
end_variable
begin_variable
var2532
-1
2
above f52 f70
none-of-those
end_variable
begin_variable
var2533
-1
2
above f52 f71
none-of-those
end_variable
begin_variable
var2534
-1
2
above f52 f72
none-of-those
end_variable
begin_variable
var2535
-1
2
above f52 f73
none-of-those
end_variable
begin_variable
var2536
-1
2
above f52 f74
none-of-those
end_variable
begin_variable
var2537
-1
2
above f52 f75
none-of-those
end_variable
begin_variable
var2538
-1
2
above f52 f76
none-of-those
end_variable
begin_variable
var2539
-1
2
above f52 f77
none-of-those
end_variable
begin_variable
var2540
-1
2
above f52 f78
none-of-those
end_variable
begin_variable
var2541
-1
2
above f52 f79
none-of-those
end_variable
begin_variable
var2542
-1
2
above f52 f80
none-of-those
end_variable
begin_variable
var2543
-1
2
above f53 f54
none-of-those
end_variable
begin_variable
var2544
-1
2
above f53 f55
none-of-those
end_variable
begin_variable
var2545
-1
2
above f53 f56
none-of-those
end_variable
begin_variable
var2546
-1
2
above f53 f57
none-of-those
end_variable
begin_variable
var2547
-1
2
above f53 f58
none-of-those
end_variable
begin_variable
var2548
-1
2
above f53 f59
none-of-those
end_variable
begin_variable
var2549
-1
2
above f53 f60
none-of-those
end_variable
begin_variable
var2550
-1
2
above f53 f61
none-of-those
end_variable
begin_variable
var2551
-1
2
above f53 f62
none-of-those
end_variable
begin_variable
var2552
-1
2
above f53 f63
none-of-those
end_variable
begin_variable
var2553
-1
2
above f53 f64
none-of-those
end_variable
begin_variable
var2554
-1
2
above f53 f65
none-of-those
end_variable
begin_variable
var2555
-1
2
above f53 f66
none-of-those
end_variable
begin_variable
var2556
-1
2
above f53 f67
none-of-those
end_variable
begin_variable
var2557
-1
2
above f53 f68
none-of-those
end_variable
begin_variable
var2558
-1
2
above f53 f69
none-of-those
end_variable
begin_variable
var2559
-1
2
above f53 f70
none-of-those
end_variable
begin_variable
var2560
-1
2
above f53 f71
none-of-those
end_variable
begin_variable
var2561
-1
2
above f53 f72
none-of-those
end_variable
begin_variable
var2562
-1
2
above f53 f73
none-of-those
end_variable
begin_variable
var2563
-1
2
above f53 f74
none-of-those
end_variable
begin_variable
var2564
-1
2
above f53 f75
none-of-those
end_variable
begin_variable
var2565
-1
2
above f53 f76
none-of-those
end_variable
begin_variable
var2566
-1
2
above f53 f77
none-of-those
end_variable
begin_variable
var2567
-1
2
above f53 f78
none-of-those
end_variable
begin_variable
var2568
-1
2
above f53 f79
none-of-those
end_variable
begin_variable
var2569
-1
2
above f53 f80
none-of-those
end_variable
begin_variable
var2570
-1
2
above f54 f55
none-of-those
end_variable
begin_variable
var2571
-1
2
above f54 f56
none-of-those
end_variable
begin_variable
var2572
-1
2
above f54 f57
none-of-those
end_variable
begin_variable
var2573
-1
2
above f54 f58
none-of-those
end_variable
begin_variable
var2574
-1
2
above f54 f59
none-of-those
end_variable
begin_variable
var2575
-1
2
above f54 f60
none-of-those
end_variable
begin_variable
var2576
-1
2
above f54 f61
none-of-those
end_variable
begin_variable
var2577
-1
2
above f54 f62
none-of-those
end_variable
begin_variable
var2578
-1
2
above f54 f63
none-of-those
end_variable
begin_variable
var2579
-1
2
above f54 f64
none-of-those
end_variable
begin_variable
var2580
-1
2
above f54 f65
none-of-those
end_variable
begin_variable
var2581
-1
2
above f54 f66
none-of-those
end_variable
begin_variable
var2582
-1
2
above f54 f67
none-of-those
end_variable
begin_variable
var2583
-1
2
above f54 f68
none-of-those
end_variable
begin_variable
var2584
-1
2
above f54 f69
none-of-those
end_variable
begin_variable
var2585
-1
2
above f54 f70
none-of-those
end_variable
begin_variable
var2586
-1
2
above f54 f71
none-of-those
end_variable
begin_variable
var2587
-1
2
above f54 f72
none-of-those
end_variable
begin_variable
var2588
-1
2
above f54 f73
none-of-those
end_variable
begin_variable
var2589
-1
2
above f54 f74
none-of-those
end_variable
begin_variable
var2590
-1
2
above f54 f75
none-of-those
end_variable
begin_variable
var2591
-1
2
above f54 f76
none-of-those
end_variable
begin_variable
var2592
-1
2
above f54 f77
none-of-those
end_variable
begin_variable
var2593
-1
2
above f54 f78
none-of-those
end_variable
begin_variable
var2594
-1
2
above f54 f79
none-of-those
end_variable
begin_variable
var2595
-1
2
above f54 f80
none-of-those
end_variable
begin_variable
var2596
-1
2
above f55 f56
none-of-those
end_variable
begin_variable
var2597
-1
2
above f55 f57
none-of-those
end_variable
begin_variable
var2598
-1
2
above f55 f58
none-of-those
end_variable
begin_variable
var2599
-1
2
above f55 f59
none-of-those
end_variable
begin_variable
var2600
-1
2
above f55 f60
none-of-those
end_variable
begin_variable
var2601
-1
2
above f55 f61
none-of-those
end_variable
begin_variable
var2602
-1
2
above f55 f62
none-of-those
end_variable
begin_variable
var2603
-1
2
above f55 f63
none-of-those
end_variable
begin_variable
var2604
-1
2
above f55 f64
none-of-those
end_variable
begin_variable
var2605
-1
2
above f55 f65
none-of-those
end_variable
begin_variable
var2606
-1
2
above f55 f66
none-of-those
end_variable
begin_variable
var2607
-1
2
above f55 f67
none-of-those
end_variable
begin_variable
var2608
-1
2
above f55 f68
none-of-those
end_variable
begin_variable
var2609
-1
2
above f55 f69
none-of-those
end_variable
begin_variable
var2610
-1
2
above f55 f70
none-of-those
end_variable
begin_variable
var2611
-1
2
above f55 f71
none-of-those
end_variable
begin_variable
var2612
-1
2
above f55 f72
none-of-those
end_variable
begin_variable
var2613
-1
2
above f55 f73
none-of-those
end_variable
begin_variable
var2614
-1
2
above f55 f74
none-of-those
end_variable
begin_variable
var2615
-1
2
above f55 f75
none-of-those
end_variable
begin_variable
var2616
-1
2
above f55 f76
none-of-those
end_variable
begin_variable
var2617
-1
2
above f55 f77
none-of-those
end_variable
begin_variable
var2618
-1
2
above f55 f78
none-of-those
end_variable
begin_variable
var2619
-1
2
above f55 f79
none-of-those
end_variable
begin_variable
var2620
-1
2
above f55 f80
none-of-those
end_variable
begin_variable
var2621
-1
2
above f56 f57
none-of-those
end_variable
begin_variable
var2622
-1
2
above f56 f58
none-of-those
end_variable
begin_variable
var2623
-1
2
above f56 f59
none-of-those
end_variable
begin_variable
var2624
-1
2
above f56 f60
none-of-those
end_variable
begin_variable
var2625
-1
2
above f56 f61
none-of-those
end_variable
begin_variable
var2626
-1
2
above f56 f62
none-of-those
end_variable
begin_variable
var2627
-1
2
above f56 f63
none-of-those
end_variable
begin_variable
var2628
-1
2
above f56 f64
none-of-those
end_variable
begin_variable
var2629
-1
2
above f56 f65
none-of-those
end_variable
begin_variable
var2630
-1
2
above f56 f66
none-of-those
end_variable
begin_variable
var2631
-1
2
above f56 f67
none-of-those
end_variable
begin_variable
var2632
-1
2
above f56 f68
none-of-those
end_variable
begin_variable
var2633
-1
2
above f56 f69
none-of-those
end_variable
begin_variable
var2634
-1
2
above f56 f70
none-of-those
end_variable
begin_variable
var2635
-1
2
above f56 f71
none-of-those
end_variable
begin_variable
var2636
-1
2
above f56 f72
none-of-those
end_variable
begin_variable
var2637
-1
2
above f56 f73
none-of-those
end_variable
begin_variable
var2638
-1
2
above f56 f74
none-of-those
end_variable
begin_variable
var2639
-1
2
above f56 f75
none-of-those
end_variable
begin_variable
var2640
-1
2
above f56 f76
none-of-those
end_variable
begin_variable
var2641
-1
2
above f56 f77
none-of-those
end_variable
begin_variable
var2642
-1
2
above f56 f78
none-of-those
end_variable
begin_variable
var2643
-1
2
above f56 f79
none-of-those
end_variable
begin_variable
var2644
-1
2
above f56 f80
none-of-those
end_variable
begin_variable
var2645
-1
2
above f57 f58
none-of-those
end_variable
begin_variable
var2646
-1
2
above f57 f59
none-of-those
end_variable
begin_variable
var2647
-1
2
above f57 f60
none-of-those
end_variable
begin_variable
var2648
-1
2
above f57 f61
none-of-those
end_variable
begin_variable
var2649
-1
2
above f57 f62
none-of-those
end_variable
begin_variable
var2650
-1
2
above f57 f63
none-of-those
end_variable
begin_variable
var2651
-1
2
above f57 f64
none-of-those
end_variable
begin_variable
var2652
-1
2
above f57 f65
none-of-those
end_variable
begin_variable
var2653
-1
2
above f57 f66
none-of-those
end_variable
begin_variable
var2654
-1
2
above f57 f67
none-of-those
end_variable
begin_variable
var2655
-1
2
above f57 f68
none-of-those
end_variable
begin_variable
var2656
-1
2
above f57 f69
none-of-those
end_variable
begin_variable
var2657
-1
2
above f57 f70
none-of-those
end_variable
begin_variable
var2658
-1
2
above f57 f71
none-of-those
end_variable
begin_variable
var2659
-1
2
above f57 f72
none-of-those
end_variable
begin_variable
var2660
-1
2
above f57 f73
none-of-those
end_variable
begin_variable
var2661
-1
2
above f57 f74
none-of-those
end_variable
begin_variable
var2662
-1
2
above f57 f75
none-of-those
end_variable
begin_variable
var2663
-1
2
above f57 f76
none-of-those
end_variable
begin_variable
var2664
-1
2
above f57 f77
none-of-those
end_variable
begin_variable
var2665
-1
2
above f57 f78
none-of-those
end_variable
begin_variable
var2666
-1
2
above f57 f79
none-of-those
end_variable
begin_variable
var2667
-1
2
above f57 f80
none-of-those
end_variable
begin_variable
var2668
-1
2
above f58 f59
none-of-those
end_variable
begin_variable
var2669
-1
2
above f58 f60
none-of-those
end_variable
begin_variable
var2670
-1
2
above f58 f61
none-of-those
end_variable
begin_variable
var2671
-1
2
above f58 f62
none-of-those
end_variable
begin_variable
var2672
-1
2
above f58 f63
none-of-those
end_variable
begin_variable
var2673
-1
2
above f58 f64
none-of-those
end_variable
begin_variable
var2674
-1
2
above f58 f65
none-of-those
end_variable
begin_variable
var2675
-1
2
above f58 f66
none-of-those
end_variable
begin_variable
var2676
-1
2
above f58 f67
none-of-those
end_variable
begin_variable
var2677
-1
2
above f58 f68
none-of-those
end_variable
begin_variable
var2678
-1
2
above f58 f69
none-of-those
end_variable
begin_variable
var2679
-1
2
above f58 f70
none-of-those
end_variable
begin_variable
var2680
-1
2
above f58 f71
none-of-those
end_variable
begin_variable
var2681
-1
2
above f58 f72
none-of-those
end_variable
begin_variable
var2682
-1
2
above f58 f73
none-of-those
end_variable
begin_variable
var2683
-1
2
above f58 f74
none-of-those
end_variable
begin_variable
var2684
-1
2
above f58 f75
none-of-those
end_variable
begin_variable
var2685
-1
2
above f58 f76
none-of-those
end_variable
begin_variable
var2686
-1
2
above f58 f77
none-of-those
end_variable
begin_variable
var2687
-1
2
above f58 f78
none-of-those
end_variable
begin_variable
var2688
-1
2
above f58 f79
none-of-those
end_variable
begin_variable
var2689
-1
2
above f58 f80
none-of-those
end_variable
begin_variable
var2690
-1
2
above f59 f60
none-of-those
end_variable
begin_variable
var2691
-1
2
above f59 f61
none-of-those
end_variable
begin_variable
var2692
-1
2
above f59 f62
none-of-those
end_variable
begin_variable
var2693
-1
2
above f59 f63
none-of-those
end_variable
begin_variable
var2694
-1
2
above f59 f64
none-of-those
end_variable
begin_variable
var2695
-1
2
above f59 f65
none-of-those
end_variable
begin_variable
var2696
-1
2
above f59 f66
none-of-those
end_variable
begin_variable
var2697
-1
2
above f59 f67
none-of-those
end_variable
begin_variable
var2698
-1
2
above f59 f68
none-of-those
end_variable
begin_variable
var2699
-1
2
above f59 f69
none-of-those
end_variable
begin_variable
var2700
-1
2
above f59 f70
none-of-those
end_variable
begin_variable
var2701
-1
2
above f59 f71
none-of-those
end_variable
begin_variable
var2702
-1
2
above f59 f72
none-of-those
end_variable
begin_variable
var2703
-1
2
above f59 f73
none-of-those
end_variable
begin_variable
var2704
-1
2
above f59 f74
none-of-those
end_variable
begin_variable
var2705
-1
2
above f59 f75
none-of-those
end_variable
begin_variable
var2706
-1
2
above f59 f76
none-of-those
end_variable
begin_variable
var2707
-1
2
above f59 f77
none-of-those
end_variable
begin_variable
var2708
-1
2
above f59 f78
none-of-those
end_variable
begin_variable
var2709
-1
2
above f59 f79
none-of-those
end_variable
begin_variable
var2710
-1
2
above f59 f80
none-of-those
end_variable
begin_variable
var2711
-1
2
above f6 f10
none-of-those
end_variable
begin_variable
var2712
-1
2
above f6 f11
none-of-those
end_variable
begin_variable
var2713
-1
2
above f6 f12
none-of-those
end_variable
begin_variable
var2714
-1
2
above f6 f13
none-of-those
end_variable
begin_variable
var2715
-1
2
above f6 f14
none-of-those
end_variable
begin_variable
var2716
-1
2
above f6 f15
none-of-those
end_variable
begin_variable
var2717
-1
2
above f6 f16
none-of-those
end_variable
begin_variable
var2718
-1
2
above f6 f17
none-of-those
end_variable
begin_variable
var2719
-1
2
above f6 f18
none-of-those
end_variable
begin_variable
var2720
-1
2
above f6 f19
none-of-those
end_variable
begin_variable
var2721
-1
2
above f6 f20
none-of-those
end_variable
begin_variable
var2722
-1
2
above f6 f21
none-of-those
end_variable
begin_variable
var2723
-1
2
above f6 f22
none-of-those
end_variable
begin_variable
var2724
-1
2
above f6 f23
none-of-those
end_variable
begin_variable
var2725
-1
2
above f6 f24
none-of-those
end_variable
begin_variable
var2726
-1
2
above f6 f25
none-of-those
end_variable
begin_variable
var2727
-1
2
above f6 f26
none-of-those
end_variable
begin_variable
var2728
-1
2
above f6 f27
none-of-those
end_variable
begin_variable
var2729
-1
2
above f6 f28
none-of-those
end_variable
begin_variable
var2730
-1
2
above f6 f29
none-of-those
end_variable
begin_variable
var2731
-1
2
above f6 f30
none-of-those
end_variable
begin_variable
var2732
-1
2
above f6 f31
none-of-those
end_variable
begin_variable
var2733
-1
2
above f6 f32
none-of-those
end_variable
begin_variable
var2734
-1
2
above f6 f33
none-of-those
end_variable
begin_variable
var2735
-1
2
above f6 f34
none-of-those
end_variable
begin_variable
var2736
-1
2
above f6 f35
none-of-those
end_variable
begin_variable
var2737
-1
2
above f6 f36
none-of-those
end_variable
begin_variable
var2738
-1
2
above f6 f37
none-of-those
end_variable
begin_variable
var2739
-1
2
above f6 f38
none-of-those
end_variable
begin_variable
var2740
-1
2
above f6 f39
none-of-those
end_variable
begin_variable
var2741
-1
2
above f6 f40
none-of-those
end_variable
begin_variable
var2742
-1
2
above f6 f41
none-of-those
end_variable
begin_variable
var2743
-1
2
above f6 f42
none-of-those
end_variable
begin_variable
var2744
-1
2
above f6 f43
none-of-those
end_variable
begin_variable
var2745
-1
2
above f6 f44
none-of-those
end_variable
begin_variable
var2746
-1
2
above f6 f45
none-of-those
end_variable
begin_variable
var2747
-1
2
above f6 f46
none-of-those
end_variable
begin_variable
var2748
-1
2
above f6 f47
none-of-those
end_variable
begin_variable
var2749
-1
2
above f6 f48
none-of-those
end_variable
begin_variable
var2750
-1
2
above f6 f49
none-of-those
end_variable
begin_variable
var2751
-1
2
above f6 f50
none-of-those
end_variable
begin_variable
var2752
-1
2
above f6 f51
none-of-those
end_variable
begin_variable
var2753
-1
2
above f6 f52
none-of-those
end_variable
begin_variable
var2754
-1
2
above f6 f53
none-of-those
end_variable
begin_variable
var2755
-1
2
above f6 f54
none-of-those
end_variable
begin_variable
var2756
-1
2
above f6 f55
none-of-those
end_variable
begin_variable
var2757
-1
2
above f6 f56
none-of-those
end_variable
begin_variable
var2758
-1
2
above f6 f57
none-of-those
end_variable
begin_variable
var2759
-1
2
above f6 f58
none-of-those
end_variable
begin_variable
var2760
-1
2
above f6 f59
none-of-those
end_variable
begin_variable
var2761
-1
2
above f6 f60
none-of-those
end_variable
begin_variable
var2762
-1
2
above f6 f61
none-of-those
end_variable
begin_variable
var2763
-1
2
above f6 f62
none-of-those
end_variable
begin_variable
var2764
-1
2
above f6 f63
none-of-those
end_variable
begin_variable
var2765
-1
2
above f6 f64
none-of-those
end_variable
begin_variable
var2766
-1
2
above f6 f65
none-of-those
end_variable
begin_variable
var2767
-1
2
above f6 f66
none-of-those
end_variable
begin_variable
var2768
-1
2
above f6 f67
none-of-those
end_variable
begin_variable
var2769
-1
2
above f6 f68
none-of-those
end_variable
begin_variable
var2770
-1
2
above f6 f69
none-of-those
end_variable
begin_variable
var2771
-1
2
above f6 f7
none-of-those
end_variable
begin_variable
var2772
-1
2
above f6 f70
none-of-those
end_variable
begin_variable
var2773
-1
2
above f6 f71
none-of-those
end_variable
begin_variable
var2774
-1
2
above f6 f72
none-of-those
end_variable
begin_variable
var2775
-1
2
above f6 f73
none-of-those
end_variable
begin_variable
var2776
-1
2
above f6 f74
none-of-those
end_variable
begin_variable
var2777
-1
2
above f6 f75
none-of-those
end_variable
begin_variable
var2778
-1
2
above f6 f76
none-of-those
end_variable
begin_variable
var2779
-1
2
above f6 f77
none-of-those
end_variable
begin_variable
var2780
-1
2
above f6 f78
none-of-those
end_variable
begin_variable
var2781
-1
2
above f6 f79
none-of-those
end_variable
begin_variable
var2782
-1
2
above f6 f8
none-of-those
end_variable
begin_variable
var2783
-1
2
above f6 f80
none-of-those
end_variable
begin_variable
var2784
-1
2
above f6 f9
none-of-those
end_variable
begin_variable
var2785
-1
2
above f60 f61
none-of-those
end_variable
begin_variable
var2786
-1
2
above f60 f62
none-of-those
end_variable
begin_variable
var2787
-1
2
above f60 f63
none-of-those
end_variable
begin_variable
var2788
-1
2
above f60 f64
none-of-those
end_variable
begin_variable
var2789
-1
2
above f60 f65
none-of-those
end_variable
begin_variable
var2790
-1
2
above f60 f66
none-of-those
end_variable
begin_variable
var2791
-1
2
above f60 f67
none-of-those
end_variable
begin_variable
var2792
-1
2
above f60 f68
none-of-those
end_variable
begin_variable
var2793
-1
2
above f60 f69
none-of-those
end_variable
begin_variable
var2794
-1
2
above f60 f70
none-of-those
end_variable
begin_variable
var2795
-1
2
above f60 f71
none-of-those
end_variable
begin_variable
var2796
-1
2
above f60 f72
none-of-those
end_variable
begin_variable
var2797
-1
2
above f60 f73
none-of-those
end_variable
begin_variable
var2798
-1
2
above f60 f74
none-of-those
end_variable
begin_variable
var2799
-1
2
above f60 f75
none-of-those
end_variable
begin_variable
var2800
-1
2
above f60 f76
none-of-those
end_variable
begin_variable
var2801
-1
2
above f60 f77
none-of-those
end_variable
begin_variable
var2802
-1
2
above f60 f78
none-of-those
end_variable
begin_variable
var2803
-1
2
above f60 f79
none-of-those
end_variable
begin_variable
var2804
-1
2
above f60 f80
none-of-those
end_variable
begin_variable
var2805
-1
2
above f61 f62
none-of-those
end_variable
begin_variable
var2806
-1
2
above f61 f63
none-of-those
end_variable
begin_variable
var2807
-1
2
above f61 f64
none-of-those
end_variable
begin_variable
var2808
-1
2
above f61 f65
none-of-those
end_variable
begin_variable
var2809
-1
2
above f61 f66
none-of-those
end_variable
begin_variable
var2810
-1
2
above f61 f67
none-of-those
end_variable
begin_variable
var2811
-1
2
above f61 f68
none-of-those
end_variable
begin_variable
var2812
-1
2
above f61 f69
none-of-those
end_variable
begin_variable
var2813
-1
2
above f61 f70
none-of-those
end_variable
begin_variable
var2814
-1
2
above f61 f71
none-of-those
end_variable
begin_variable
var2815
-1
2
above f61 f72
none-of-those
end_variable
begin_variable
var2816
-1
2
above f61 f73
none-of-those
end_variable
begin_variable
var2817
-1
2
above f61 f74
none-of-those
end_variable
begin_variable
var2818
-1
2
above f61 f75
none-of-those
end_variable
begin_variable
var2819
-1
2
above f61 f76
none-of-those
end_variable
begin_variable
var2820
-1
2
above f61 f77
none-of-those
end_variable
begin_variable
var2821
-1
2
above f61 f78
none-of-those
end_variable
begin_variable
var2822
-1
2
above f61 f79
none-of-those
end_variable
begin_variable
var2823
-1
2
above f61 f80
none-of-those
end_variable
begin_variable
var2824
-1
2
above f62 f63
none-of-those
end_variable
begin_variable
var2825
-1
2
above f62 f64
none-of-those
end_variable
begin_variable
var2826
-1
2
above f62 f65
none-of-those
end_variable
begin_variable
var2827
-1
2
above f62 f66
none-of-those
end_variable
begin_variable
var2828
-1
2
above f62 f67
none-of-those
end_variable
begin_variable
var2829
-1
2
above f62 f68
none-of-those
end_variable
begin_variable
var2830
-1
2
above f62 f69
none-of-those
end_variable
begin_variable
var2831
-1
2
above f62 f70
none-of-those
end_variable
begin_variable
var2832
-1
2
above f62 f71
none-of-those
end_variable
begin_variable
var2833
-1
2
above f62 f72
none-of-those
end_variable
begin_variable
var2834
-1
2
above f62 f73
none-of-those
end_variable
begin_variable
var2835
-1
2
above f62 f74
none-of-those
end_variable
begin_variable
var2836
-1
2
above f62 f75
none-of-those
end_variable
begin_variable
var2837
-1
2
above f62 f76
none-of-those
end_variable
begin_variable
var2838
-1
2
above f62 f77
none-of-those
end_variable
begin_variable
var2839
-1
2
above f62 f78
none-of-those
end_variable
begin_variable
var2840
-1
2
above f62 f79
none-of-those
end_variable
begin_variable
var2841
-1
2
above f62 f80
none-of-those
end_variable
begin_variable
var2842
-1
2
above f63 f64
none-of-those
end_variable
begin_variable
var2843
-1
2
above f63 f65
none-of-those
end_variable
begin_variable
var2844
-1
2
above f63 f66
none-of-those
end_variable
begin_variable
var2845
-1
2
above f63 f67
none-of-those
end_variable
begin_variable
var2846
-1
2
above f63 f68
none-of-those
end_variable
begin_variable
var2847
-1
2
above f63 f69
none-of-those
end_variable
begin_variable
var2848
-1
2
above f63 f70
none-of-those
end_variable
begin_variable
var2849
-1
2
above f63 f71
none-of-those
end_variable
begin_variable
var2850
-1
2
above f63 f72
none-of-those
end_variable
begin_variable
var2851
-1
2
above f63 f73
none-of-those
end_variable
begin_variable
var2852
-1
2
above f63 f74
none-of-those
end_variable
begin_variable
var2853
-1
2
above f63 f75
none-of-those
end_variable
begin_variable
var2854
-1
2
above f63 f76
none-of-those
end_variable
begin_variable
var2855
-1
2
above f63 f77
none-of-those
end_variable
begin_variable
var2856
-1
2
above f63 f78
none-of-those
end_variable
begin_variable
var2857
-1
2
above f63 f79
none-of-those
end_variable
begin_variable
var2858
-1
2
above f63 f80
none-of-those
end_variable
begin_variable
var2859
-1
2
above f64 f65
none-of-those
end_variable
begin_variable
var2860
-1
2
above f64 f66
none-of-those
end_variable
begin_variable
var2861
-1
2
above f64 f67
none-of-those
end_variable
begin_variable
var2862
-1
2
above f64 f68
none-of-those
end_variable
begin_variable
var2863
-1
2
above f64 f69
none-of-those
end_variable
begin_variable
var2864
-1
2
above f64 f70
none-of-those
end_variable
begin_variable
var2865
-1
2
above f64 f71
none-of-those
end_variable
begin_variable
var2866
-1
2
above f64 f72
none-of-those
end_variable
begin_variable
var2867
-1
2
above f64 f73
none-of-those
end_variable
begin_variable
var2868
-1
2
above f64 f74
none-of-those
end_variable
begin_variable
var2869
-1
2
above f64 f75
none-of-those
end_variable
begin_variable
var2870
-1
2
above f64 f76
none-of-those
end_variable
begin_variable
var2871
-1
2
above f64 f77
none-of-those
end_variable
begin_variable
var2872
-1
2
above f64 f78
none-of-those
end_variable
begin_variable
var2873
-1
2
above f64 f79
none-of-those
end_variable
begin_variable
var2874
-1
2
above f64 f80
none-of-those
end_variable
begin_variable
var2875
-1
2
above f65 f66
none-of-those
end_variable
begin_variable
var2876
-1
2
above f65 f67
none-of-those
end_variable
begin_variable
var2877
-1
2
above f65 f68
none-of-those
end_variable
begin_variable
var2878
-1
2
above f65 f69
none-of-those
end_variable
begin_variable
var2879
-1
2
above f65 f70
none-of-those
end_variable
begin_variable
var2880
-1
2
above f65 f71
none-of-those
end_variable
begin_variable
var2881
-1
2
above f65 f72
none-of-those
end_variable
begin_variable
var2882
-1
2
above f65 f73
none-of-those
end_variable
begin_variable
var2883
-1
2
above f65 f74
none-of-those
end_variable
begin_variable
var2884
-1
2
above f65 f75
none-of-those
end_variable
begin_variable
var2885
-1
2
above f65 f76
none-of-those
end_variable
begin_variable
var2886
-1
2
above f65 f77
none-of-those
end_variable
begin_variable
var2887
-1
2
above f65 f78
none-of-those
end_variable
begin_variable
var2888
-1
2
above f65 f79
none-of-those
end_variable
begin_variable
var2889
-1
2
above f65 f80
none-of-those
end_variable
begin_variable
var2890
-1
2
above f66 f67
none-of-those
end_variable
begin_variable
var2891
-1
2
above f66 f68
none-of-those
end_variable
begin_variable
var2892
-1
2
above f66 f69
none-of-those
end_variable
begin_variable
var2893
-1
2
above f66 f70
none-of-those
end_variable
begin_variable
var2894
-1
2
above f66 f71
none-of-those
end_variable
begin_variable
var2895
-1
2
above f66 f72
none-of-those
end_variable
begin_variable
var2896
-1
2
above f66 f73
none-of-those
end_variable
begin_variable
var2897
-1
2
above f66 f74
none-of-those
end_variable
begin_variable
var2898
-1
2
above f66 f75
none-of-those
end_variable
begin_variable
var2899
-1
2
above f66 f76
none-of-those
end_variable
begin_variable
var2900
-1
2
above f66 f77
none-of-those
end_variable
begin_variable
var2901
-1
2
above f66 f78
none-of-those
end_variable
begin_variable
var2902
-1
2
above f66 f79
none-of-those
end_variable
begin_variable
var2903
-1
2
above f66 f80
none-of-those
end_variable
begin_variable
var2904
-1
2
above f67 f68
none-of-those
end_variable
begin_variable
var2905
-1
2
above f67 f69
none-of-those
end_variable
begin_variable
var2906
-1
2
above f67 f70
none-of-those
end_variable
begin_variable
var2907
-1
2
above f67 f71
none-of-those
end_variable
begin_variable
var2908
-1
2
above f67 f72
none-of-those
end_variable
begin_variable
var2909
-1
2
above f67 f73
none-of-those
end_variable
begin_variable
var2910
-1
2
above f67 f74
none-of-those
end_variable
begin_variable
var2911
-1
2
above f67 f75
none-of-those
end_variable
begin_variable
var2912
-1
2
above f67 f76
none-of-those
end_variable
begin_variable
var2913
-1
2
above f67 f77
none-of-those
end_variable
begin_variable
var2914
-1
2
above f67 f78
none-of-those
end_variable
begin_variable
var2915
-1
2
above f67 f79
none-of-those
end_variable
begin_variable
var2916
-1
2
above f67 f80
none-of-those
end_variable
begin_variable
var2917
-1
2
above f68 f69
none-of-those
end_variable
begin_variable
var2918
-1
2
above f68 f70
none-of-those
end_variable
begin_variable
var2919
-1
2
above f68 f71
none-of-those
end_variable
begin_variable
var2920
-1
2
above f68 f72
none-of-those
end_variable
begin_variable
var2921
-1
2
above f68 f73
none-of-those
end_variable
begin_variable
var2922
-1
2
above f68 f74
none-of-those
end_variable
begin_variable
var2923
-1
2
above f68 f75
none-of-those
end_variable
begin_variable
var2924
-1
2
above f68 f76
none-of-those
end_variable
begin_variable
var2925
-1
2
above f68 f77
none-of-those
end_variable
begin_variable
var2926
-1
2
above f68 f78
none-of-those
end_variable
begin_variable
var2927
-1
2
above f68 f79
none-of-those
end_variable
begin_variable
var2928
-1
2
above f68 f80
none-of-those
end_variable
begin_variable
var2929
-1
2
above f69 f70
none-of-those
end_variable
begin_variable
var2930
-1
2
above f69 f71
none-of-those
end_variable
begin_variable
var2931
-1
2
above f69 f72
none-of-those
end_variable
begin_variable
var2932
-1
2
above f69 f73
none-of-those
end_variable
begin_variable
var2933
-1
2
above f69 f74
none-of-those
end_variable
begin_variable
var2934
-1
2
above f69 f75
none-of-those
end_variable
begin_variable
var2935
-1
2
above f69 f76
none-of-those
end_variable
begin_variable
var2936
-1
2
above f69 f77
none-of-those
end_variable
begin_variable
var2937
-1
2
above f69 f78
none-of-those
end_variable
begin_variable
var2938
-1
2
above f69 f79
none-of-those
end_variable
begin_variable
var2939
-1
2
above f69 f80
none-of-those
end_variable
begin_variable
var2940
-1
2
above f7 f10
none-of-those
end_variable
begin_variable
var2941
-1
2
above f7 f11
none-of-those
end_variable
begin_variable
var2942
-1
2
above f7 f12
none-of-those
end_variable
begin_variable
var2943
-1
2
above f7 f13
none-of-those
end_variable
begin_variable
var2944
-1
2
above f7 f14
none-of-those
end_variable
begin_variable
var2945
-1
2
above f7 f15
none-of-those
end_variable
begin_variable
var2946
-1
2
above f7 f16
none-of-those
end_variable
begin_variable
var2947
-1
2
above f7 f17
none-of-those
end_variable
begin_variable
var2948
-1
2
above f7 f18
none-of-those
end_variable
begin_variable
var2949
-1
2
above f7 f19
none-of-those
end_variable
begin_variable
var2950
-1
2
above f7 f20
none-of-those
end_variable
begin_variable
var2951
-1
2
above f7 f21
none-of-those
end_variable
begin_variable
var2952
-1
2
above f7 f22
none-of-those
end_variable
begin_variable
var2953
-1
2
above f7 f23
none-of-those
end_variable
begin_variable
var2954
-1
2
above f7 f24
none-of-those
end_variable
begin_variable
var2955
-1
2
above f7 f25
none-of-those
end_variable
begin_variable
var2956
-1
2
above f7 f26
none-of-those
end_variable
begin_variable
var2957
-1
2
above f7 f27
none-of-those
end_variable
begin_variable
var2958
-1
2
above f7 f28
none-of-those
end_variable
begin_variable
var2959
-1
2
above f7 f29
none-of-those
end_variable
begin_variable
var2960
-1
2
above f7 f30
none-of-those
end_variable
begin_variable
var2961
-1
2
above f7 f31
none-of-those
end_variable
begin_variable
var2962
-1
2
above f7 f32
none-of-those
end_variable
begin_variable
var2963
-1
2
above f7 f33
none-of-those
end_variable
begin_variable
var2964
-1
2
above f7 f34
none-of-those
end_variable
begin_variable
var2965
-1
2
above f7 f35
none-of-those
end_variable
begin_variable
var2966
-1
2
above f7 f36
none-of-those
end_variable
begin_variable
var2967
-1
2
above f7 f37
none-of-those
end_variable
begin_variable
var2968
-1
2
above f7 f38
none-of-those
end_variable
begin_variable
var2969
-1
2
above f7 f39
none-of-those
end_variable
begin_variable
var2970
-1
2
above f7 f40
none-of-those
end_variable
begin_variable
var2971
-1
2
above f7 f41
none-of-those
end_variable
begin_variable
var2972
-1
2
above f7 f42
none-of-those
end_variable
begin_variable
var2973
-1
2
above f7 f43
none-of-those
end_variable
begin_variable
var2974
-1
2
above f7 f44
none-of-those
end_variable
begin_variable
var2975
-1
2
above f7 f45
none-of-those
end_variable
begin_variable
var2976
-1
2
above f7 f46
none-of-those
end_variable
begin_variable
var2977
-1
2
above f7 f47
none-of-those
end_variable
begin_variable
var2978
-1
2
above f7 f48
none-of-those
end_variable
begin_variable
var2979
-1
2
above f7 f49
none-of-those
end_variable
begin_variable
var2980
-1
2
above f7 f50
none-of-those
end_variable
begin_variable
var2981
-1
2
above f7 f51
none-of-those
end_variable
begin_variable
var2982
-1
2
above f7 f52
none-of-those
end_variable
begin_variable
var2983
-1
2
above f7 f53
none-of-those
end_variable
begin_variable
var2984
-1
2
above f7 f54
none-of-those
end_variable
begin_variable
var2985
-1
2
above f7 f55
none-of-those
end_variable
begin_variable
var2986
-1
2
above f7 f56
none-of-those
end_variable
begin_variable
var2987
-1
2
above f7 f57
none-of-those
end_variable
begin_variable
var2988
-1
2
above f7 f58
none-of-those
end_variable
begin_variable
var2989
-1
2
above f7 f59
none-of-those
end_variable
begin_variable
var2990
-1
2
above f7 f60
none-of-those
end_variable
begin_variable
var2991
-1
2
above f7 f61
none-of-those
end_variable
begin_variable
var2992
-1
2
above f7 f62
none-of-those
end_variable
begin_variable
var2993
-1
2
above f7 f63
none-of-those
end_variable
begin_variable
var2994
-1
2
above f7 f64
none-of-those
end_variable
begin_variable
var2995
-1
2
above f7 f65
none-of-those
end_variable
begin_variable
var2996
-1
2
above f7 f66
none-of-those
end_variable
begin_variable
var2997
-1
2
above f7 f67
none-of-those
end_variable
begin_variable
var2998
-1
2
above f7 f68
none-of-those
end_variable
begin_variable
var2999
-1
2
above f7 f69
none-of-those
end_variable
begin_variable
var3000
-1
2
above f7 f70
none-of-those
end_variable
begin_variable
var3001
-1
2
above f7 f71
none-of-those
end_variable
begin_variable
var3002
-1
2
above f7 f72
none-of-those
end_variable
begin_variable
var3003
-1
2
above f7 f73
none-of-those
end_variable
begin_variable
var3004
-1
2
above f7 f74
none-of-those
end_variable
begin_variable
var3005
-1
2
above f7 f75
none-of-those
end_variable
begin_variable
var3006
-1
2
above f7 f76
none-of-those
end_variable
begin_variable
var3007
-1
2
above f7 f77
none-of-those
end_variable
begin_variable
var3008
-1
2
above f7 f78
none-of-those
end_variable
begin_variable
var3009
-1
2
above f7 f79
none-of-those
end_variable
begin_variable
var3010
-1
2
above f7 f8
none-of-those
end_variable
begin_variable
var3011
-1
2
above f7 f80
none-of-those
end_variable
begin_variable
var3012
-1
2
above f7 f9
none-of-those
end_variable
begin_variable
var3013
-1
2
above f70 f71
none-of-those
end_variable
begin_variable
var3014
-1
2
above f70 f72
none-of-those
end_variable
begin_variable
var3015
-1
2
above f70 f73
none-of-those
end_variable
begin_variable
var3016
-1
2
above f70 f74
none-of-those
end_variable
begin_variable
var3017
-1
2
above f70 f75
none-of-those
end_variable
begin_variable
var3018
-1
2
above f70 f76
none-of-those
end_variable
begin_variable
var3019
-1
2
above f70 f77
none-of-those
end_variable
begin_variable
var3020
-1
2
above f70 f78
none-of-those
end_variable
begin_variable
var3021
-1
2
above f70 f79
none-of-those
end_variable
begin_variable
var3022
-1
2
above f70 f80
none-of-those
end_variable
begin_variable
var3023
-1
2
above f71 f72
none-of-those
end_variable
begin_variable
var3024
-1
2
above f71 f73
none-of-those
end_variable
begin_variable
var3025
-1
2
above f71 f74
none-of-those
end_variable
begin_variable
var3026
-1
2
above f71 f75
none-of-those
end_variable
begin_variable
var3027
-1
2
above f71 f76
none-of-those
end_variable
begin_variable
var3028
-1
2
above f71 f77
none-of-those
end_variable
begin_variable
var3029
-1
2
above f71 f78
none-of-those
end_variable
begin_variable
var3030
-1
2
above f71 f79
none-of-those
end_variable
begin_variable
var3031
-1
2
above f71 f80
none-of-those
end_variable
begin_variable
var3032
-1
2
above f72 f73
none-of-those
end_variable
begin_variable
var3033
-1
2
above f72 f74
none-of-those
end_variable
begin_variable
var3034
-1
2
above f72 f75
none-of-those
end_variable
begin_variable
var3035
-1
2
above f72 f76
none-of-those
end_variable
begin_variable
var3036
-1
2
above f72 f77
none-of-those
end_variable
begin_variable
var3037
-1
2
above f72 f78
none-of-those
end_variable
begin_variable
var3038
-1
2
above f72 f79
none-of-those
end_variable
begin_variable
var3039
-1
2
above f72 f80
none-of-those
end_variable
begin_variable
var3040
-1
2
above f73 f74
none-of-those
end_variable
begin_variable
var3041
-1
2
above f73 f75
none-of-those
end_variable
begin_variable
var3042
-1
2
above f73 f76
none-of-those
end_variable
begin_variable
var3043
-1
2
above f73 f77
none-of-those
end_variable
begin_variable
var3044
-1
2
above f73 f78
none-of-those
end_variable
begin_variable
var3045
-1
2
above f73 f79
none-of-those
end_variable
begin_variable
var3046
-1
2
above f73 f80
none-of-those
end_variable
begin_variable
var3047
-1
2
above f74 f75
none-of-those
end_variable
begin_variable
var3048
-1
2
above f74 f76
none-of-those
end_variable
begin_variable
var3049
-1
2
above f74 f77
none-of-those
end_variable
begin_variable
var3050
-1
2
above f74 f78
none-of-those
end_variable
begin_variable
var3051
-1
2
above f74 f79
none-of-those
end_variable
begin_variable
var3052
-1
2
above f74 f80
none-of-those
end_variable
begin_variable
var3053
-1
2
above f75 f76
none-of-those
end_variable
begin_variable
var3054
-1
2
above f75 f77
none-of-those
end_variable
begin_variable
var3055
-1
2
above f75 f78
none-of-those
end_variable
begin_variable
var3056
-1
2
above f75 f79
none-of-those
end_variable
begin_variable
var3057
-1
2
above f75 f80
none-of-those
end_variable
begin_variable
var3058
-1
2
above f76 f77
none-of-those
end_variable
begin_variable
var3059
-1
2
above f76 f78
none-of-those
end_variable
begin_variable
var3060
-1
2
above f76 f79
none-of-those
end_variable
begin_variable
var3061
-1
2
above f76 f80
none-of-those
end_variable
begin_variable
var3062
-1
2
above f77 f78
none-of-those
end_variable
begin_variable
var3063
-1
2
above f77 f79
none-of-those
end_variable
begin_variable
var3064
-1
2
above f77 f80
none-of-those
end_variable
begin_variable
var3065
-1
2
above f78 f79
none-of-those
end_variable
begin_variable
var3066
-1
2
above f78 f80
none-of-those
end_variable
begin_variable
var3067
-1
2
above f79 f80
none-of-those
end_variable
begin_variable
var3068
-1
2
above f8 f10
none-of-those
end_variable
begin_variable
var3069
-1
2
above f8 f11
none-of-those
end_variable
begin_variable
var3070
-1
2
above f8 f12
none-of-those
end_variable
begin_variable
var3071
-1
2
above f8 f13
none-of-those
end_variable
begin_variable
var3072
-1
2
above f8 f14
none-of-those
end_variable
begin_variable
var3073
-1
2
above f8 f15
none-of-those
end_variable
begin_variable
var3074
-1
2
above f8 f16
none-of-those
end_variable
begin_variable
var3075
-1
2
above f8 f17
none-of-those
end_variable
begin_variable
var3076
-1
2
above f8 f18
none-of-those
end_variable
begin_variable
var3077
-1
2
above f8 f19
none-of-those
end_variable
begin_variable
var3078
-1
2
above f8 f20
none-of-those
end_variable
begin_variable
var3079
-1
2
above f8 f21
none-of-those
end_variable
begin_variable
var3080
-1
2
above f8 f22
none-of-those
end_variable
begin_variable
var3081
-1
2
above f8 f23
none-of-those
end_variable
begin_variable
var3082
-1
2
above f8 f24
none-of-those
end_variable
begin_variable
var3083
-1
2
above f8 f25
none-of-those
end_variable
begin_variable
var3084
-1
2
above f8 f26
none-of-those
end_variable
begin_variable
var3085
-1
2
above f8 f27
none-of-those
end_variable
begin_variable
var3086
-1
2
above f8 f28
none-of-those
end_variable
begin_variable
var3087
-1
2
above f8 f29
none-of-those
end_variable
begin_variable
var3088
-1
2
above f8 f30
none-of-those
end_variable
begin_variable
var3089
-1
2
above f8 f31
none-of-those
end_variable
begin_variable
var3090
-1
2
above f8 f32
none-of-those
end_variable
begin_variable
var3091
-1
2
above f8 f33
none-of-those
end_variable
begin_variable
var3092
-1
2
above f8 f34
none-of-those
end_variable
begin_variable
var3093
-1
2
above f8 f35
none-of-those
end_variable
begin_variable
var3094
-1
2
above f8 f36
none-of-those
end_variable
begin_variable
var3095
-1
2
above f8 f37
none-of-those
end_variable
begin_variable
var3096
-1
2
above f8 f38
none-of-those
end_variable
begin_variable
var3097
-1
2
above f8 f39
none-of-those
end_variable
begin_variable
var3098
-1
2
above f8 f40
none-of-those
end_variable
begin_variable
var3099
-1
2
above f8 f41
none-of-those
end_variable
begin_variable
var3100
-1
2
above f8 f42
none-of-those
end_variable
begin_variable
var3101
-1
2
above f8 f43
none-of-those
end_variable
begin_variable
var3102
-1
2
above f8 f44
none-of-those
end_variable
begin_variable
var3103
-1
2
above f8 f45
none-of-those
end_variable
begin_variable
var3104
-1
2
above f8 f46
none-of-those
end_variable
begin_variable
var3105
-1
2
above f8 f47
none-of-those
end_variable
begin_variable
var3106
-1
2
above f8 f48
none-of-those
end_variable
begin_variable
var3107
-1
2
above f8 f49
none-of-those
end_variable
begin_variable
var3108
-1
2
above f8 f50
none-of-those
end_variable
begin_variable
var3109
-1
2
above f8 f51
none-of-those
end_variable
begin_variable
var3110
-1
2
above f8 f52
none-of-those
end_variable
begin_variable
var3111
-1
2
above f8 f53
none-of-those
end_variable
begin_variable
var3112
-1
2
above f8 f54
none-of-those
end_variable
begin_variable
var3113
-1
2
above f8 f55
none-of-those
end_variable
begin_variable
var3114
-1
2
above f8 f56
none-of-those
end_variable
begin_variable
var3115
-1
2
above f8 f57
none-of-those
end_variable
begin_variable
var3116
-1
2
above f8 f58
none-of-those
end_variable
begin_variable
var3117
-1
2
above f8 f59
none-of-those
end_variable
begin_variable
var3118
-1
2
above f8 f60
none-of-those
end_variable
begin_variable
var3119
-1
2
above f8 f61
none-of-those
end_variable
begin_variable
var3120
-1
2
above f8 f62
none-of-those
end_variable
begin_variable
var3121
-1
2
above f8 f63
none-of-those
end_variable
begin_variable
var3122
-1
2
above f8 f64
none-of-those
end_variable
begin_variable
var3123
-1
2
above f8 f65
none-of-those
end_variable
begin_variable
var3124
-1
2
above f8 f66
none-of-those
end_variable
begin_variable
var3125
-1
2
above f8 f67
none-of-those
end_variable
begin_variable
var3126
-1
2
above f8 f68
none-of-those
end_variable
begin_variable
var3127
-1
2
above f8 f69
none-of-those
end_variable
begin_variable
var3128
-1
2
above f8 f70
none-of-those
end_variable
begin_variable
var3129
-1
2
above f8 f71
none-of-those
end_variable
begin_variable
var3130
-1
2
above f8 f72
none-of-those
end_variable
begin_variable
var3131
-1
2
above f8 f73
none-of-those
end_variable
begin_variable
var3132
-1
2
above f8 f74
none-of-those
end_variable
begin_variable
var3133
-1
2
above f8 f75
none-of-those
end_variable
begin_variable
var3134
-1
2
above f8 f76
none-of-those
end_variable
begin_variable
var3135
-1
2
above f8 f77
none-of-those
end_variable
begin_variable
var3136
-1
2
above f8 f78
none-of-those
end_variable
begin_variable
var3137
-1
2
above f8 f79
none-of-those
end_variable
begin_variable
var3138
-1
2
above f8 f80
none-of-those
end_variable
begin_variable
var3139
-1
2
above f8 f9
none-of-those
end_variable
begin_variable
var3140
-1
2
above f9 f10
none-of-those
end_variable
begin_variable
var3141
-1
2
above f9 f11
none-of-those
end_variable
begin_variable
var3142
-1
2
above f9 f12
none-of-those
end_variable
begin_variable
var3143
-1
2
above f9 f13
none-of-those
end_variable
begin_variable
var3144
-1
2
above f9 f14
none-of-those
end_variable
begin_variable
var3145
-1
2
above f9 f15
none-of-those
end_variable
begin_variable
var3146
-1
2
above f9 f16
none-of-those
end_variable
begin_variable
var3147
-1
2
above f9 f17
none-of-those
end_variable
begin_variable
var3148
-1
2
above f9 f18
none-of-those
end_variable
begin_variable
var3149
-1
2
above f9 f19
none-of-those
end_variable
begin_variable
var3150
-1
2
above f9 f20
none-of-those
end_variable
begin_variable
var3151
-1
2
above f9 f21
none-of-those
end_variable
begin_variable
var3152
-1
2
above f9 f22
none-of-those
end_variable
begin_variable
var3153
-1
2
above f9 f23
none-of-those
end_variable
begin_variable
var3154
-1
2
above f9 f24
none-of-those
end_variable
begin_variable
var3155
-1
2
above f9 f25
none-of-those
end_variable
begin_variable
var3156
-1
2
above f9 f26
none-of-those
end_variable
begin_variable
var3157
-1
2
above f9 f27
none-of-those
end_variable
begin_variable
var3158
-1
2
above f9 f28
none-of-those
end_variable
begin_variable
var3159
-1
2
above f9 f29
none-of-those
end_variable
begin_variable
var3160
-1
2
above f9 f30
none-of-those
end_variable
begin_variable
var3161
-1
2
above f9 f31
none-of-those
end_variable
begin_variable
var3162
-1
2
above f9 f32
none-of-those
end_variable
begin_variable
var3163
-1
2
above f9 f33
none-of-those
end_variable
begin_variable
var3164
-1
2
above f9 f34
none-of-those
end_variable
begin_variable
var3165
-1
2
above f9 f35
none-of-those
end_variable
begin_variable
var3166
-1
2
above f9 f36
none-of-those
end_variable
begin_variable
var3167
-1
2
above f9 f37
none-of-those
end_variable
begin_variable
var3168
-1
2
above f9 f38
none-of-those
end_variable
begin_variable
var3169
-1
2
above f9 f39
none-of-those
end_variable
begin_variable
var3170
-1
2
above f9 f40
none-of-those
end_variable
begin_variable
var3171
-1
2
above f9 f41
none-of-those
end_variable
begin_variable
var3172
-1
2
above f9 f42
none-of-those
end_variable
begin_variable
var3173
-1
2
above f9 f43
none-of-those
end_variable
begin_variable
var3174
-1
2
above f9 f44
none-of-those
end_variable
begin_variable
var3175
-1
2
above f9 f45
none-of-those
end_variable
begin_variable
var3176
-1
2
above f9 f46
none-of-those
end_variable
begin_variable
var3177
-1
2
above f9 f47
none-of-those
end_variable
begin_variable
var3178
-1
2
above f9 f48
none-of-those
end_variable
begin_variable
var3179
-1
2
above f9 f49
none-of-those
end_variable
begin_variable
var3180
-1
2
above f9 f50
none-of-those
end_variable
begin_variable
var3181
-1
2
above f9 f51
none-of-those
end_variable
begin_variable
var3182
-1
2
above f9 f52
none-of-those
end_variable
begin_variable
var3183
-1
2
above f9 f53
none-of-those
end_variable
begin_variable
var3184
-1
2
above f9 f54
none-of-those
end_variable
begin_variable
var3185
-1
2
above f9 f55
none-of-those
end_variable
begin_variable
var3186
-1
2
above f9 f56
none-of-those
end_variable
begin_variable
var3187
-1
2
above f9 f57
none-of-those
end_variable
begin_variable
var3188
-1
2
above f9 f58
none-of-those
end_variable
begin_variable
var3189
-1
2
above f9 f59
none-of-those
end_variable
begin_variable
var3190
-1
2
above f9 f60
none-of-those
end_variable
begin_variable
var3191
-1
2
above f9 f61
none-of-those
end_variable
begin_variable
var3192
-1
2
above f9 f62
none-of-those
end_variable
begin_variable
var3193
-1
2
above f9 f63
none-of-those
end_variable
begin_variable
var3194
-1
2
above f9 f64
none-of-those
end_variable
begin_variable
var3195
-1
2
above f9 f65
none-of-those
end_variable
begin_variable
var3196
-1
2
above f9 f66
none-of-those
end_variable
begin_variable
var3197
-1
2
above f9 f67
none-of-those
end_variable
begin_variable
var3198
-1
2
above f9 f68
none-of-those
end_variable
begin_variable
var3199
-1
2
above f9 f69
none-of-those
end_variable
begin_variable
var3200
-1
2
above f9 f70
none-of-those
end_variable
begin_variable
var3201
-1
2
above f9 f71
none-of-those
end_variable
begin_variable
var3202
-1
2
above f9 f72
none-of-those
end_variable
begin_variable
var3203
-1
2
above f9 f73
none-of-those
end_variable
begin_variable
var3204
-1
2
above f9 f74
none-of-those
end_variable
begin_variable
var3205
-1
2
above f9 f75
none-of-those
end_variable
begin_variable
var3206
-1
2
above f9 f76
none-of-those
end_variable
begin_variable
var3207
-1
2
above f9 f77
none-of-those
end_variable
begin_variable
var3208
-1
2
above f9 f78
none-of-those
end_variable
begin_variable
var3209
-1
2
above f9 f79
none-of-those
end_variable
begin_variable
var3210
-1
2
above f9 f80
none-of-those
end_variable
begin_variable
var3211
-1
2
destin p1 f23
none-of-those
end_variable
begin_variable
var3212
-1
2
destin p10 f17
none-of-those
end_variable
begin_variable
var3213
-1
2
destin p11 f37
none-of-those
end_variable
begin_variable
var3214
-1
2
destin p12 f38
none-of-those
end_variable
begin_variable
var3215
-1
2
destin p13 f30
none-of-those
end_variable
begin_variable
var3216
-1
2
destin p14 f44
none-of-those
end_variable
begin_variable
var3217
-1
2
destin p15 f42
none-of-those
end_variable
begin_variable
var3218
-1
2
destin p16 f33
none-of-those
end_variable
begin_variable
var3219
-1
2
destin p17 f8
none-of-those
end_variable
begin_variable
var3220
-1
2
destin p18 f57
none-of-those
end_variable
begin_variable
var3221
-1
2
destin p19 f60
none-of-those
end_variable
begin_variable
var3222
-1
2
destin p2 f23
none-of-those
end_variable
begin_variable
var3223
-1
2
destin p20 f37
none-of-those
end_variable
begin_variable
var3224
-1
2
destin p21 f35
none-of-those
end_variable
begin_variable
var3225
-1
2
destin p22 f50
none-of-those
end_variable
begin_variable
var3226
-1
2
destin p23 f54
none-of-those
end_variable
begin_variable
var3227
-1
2
destin p24 f27
none-of-those
end_variable
begin_variable
var3228
-1
2
destin p25 f68
none-of-those
end_variable
begin_variable
var3229
-1
2
destin p26 f59
none-of-those
end_variable
begin_variable
var3230
-1
2
destin p27 f24
none-of-those
end_variable
begin_variable
var3231
-1
2
destin p28 f26
none-of-those
end_variable
begin_variable
var3232
-1
2
destin p29 f32
none-of-those
end_variable
begin_variable
var3233
-1
2
destin p3 f68
none-of-those
end_variable
begin_variable
var3234
-1
2
destin p30 f48
none-of-those
end_variable
begin_variable
var3235
-1
2
destin p31 f49
none-of-those
end_variable
begin_variable
var3236
-1
2
destin p32 f24
none-of-those
end_variable
begin_variable
var3237
-1
2
destin p33 f19
none-of-those
end_variable
begin_variable
var3238
-1
2
destin p34 f80
none-of-those
end_variable
begin_variable
var3239
-1
2
destin p35 f28
none-of-those
end_variable
begin_variable
var3240
-1
2
destin p36 f37
none-of-those
end_variable
begin_variable
var3241
-1
2
destin p37 f35
none-of-those
end_variable
begin_variable
var3242
-1
2
destin p38 f30
none-of-those
end_variable
begin_variable
var3243
-1
2
destin p39 f42
none-of-those
end_variable
begin_variable
var3244
-1
2
destin p4 f27
none-of-those
end_variable
begin_variable
var3245
-1
2
destin p40 f32
none-of-those
end_variable
begin_variable
var3246
-1
2
destin p41 f8
none-of-those
end_variable
begin_variable
var3247
-1
2
destin p42 f16
none-of-those
end_variable
begin_variable
var3248
-1
2
destin p43 f59
none-of-those
end_variable
begin_variable
var3249
-1
2
destin p44 f41
none-of-those
end_variable
begin_variable
var3250
-1
2
destin p45 f28
none-of-those
end_variable
begin_variable
var3251
-1
2
destin p46 f10
none-of-those
end_variable
begin_variable
var3252
-1
2
destin p47 f77
none-of-those
end_variable
begin_variable
var3253
-1
2
destin p48 f3
none-of-those
end_variable
begin_variable
var3254
-1
2
destin p49 f64
none-of-those
end_variable
begin_variable
var3255
-1
2
destin p5 f7
none-of-those
end_variable
begin_variable
var3256
-1
2
destin p50 f59
none-of-those
end_variable
begin_variable
var3257
-1
2
destin p6 f76
none-of-those
end_variable
begin_variable
var3258
-1
2
destin p7 f5
none-of-those
end_variable
begin_variable
var3259
-1
2
destin p8 f57
none-of-those
end_variable
begin_variable
var3260
-1
2
destin p9 f32
none-of-those
end_variable
0
begin_state
44
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
50
1 2
2 2
3 2
4 2
5 2
6 2
7 2
8 2
9 2
10 2
11 2
12 2
13 2
14 2
15 2
16 2
17 2
18 2
19 2
20 2
21 2
22 2
23 2
24 2
25 2
26 2
27 2
28 2
29 2
30 2
31 2
32 2
33 2
34 2
35 2
36 2
37 2
38 2
39 2
40 2
41 2
42 2
43 2
44 2
45 2
46 2
47 2
48 2
49 2
50 2
end_goal
6420
begin_operator
board f1 p32
1
0 0
1
0 26 1 0
1
end_operator
begin_operator
board f10 p10
1
0 1
1
0 2 1 0
1
end_operator
begin_operator
board f12 p16
1
0 3
1
0 8 1 0
1
end_operator
begin_operator
board f13 p37
1
0 4
1
0 31 1 0
1
end_operator
begin_operator
board f15 p29
1
0 6
1
0 22 1 0
1
end_operator
begin_operator
board f16 p19
1
0 7
1
0 11 1 0
1
end_operator
begin_operator
board f2 p17
1
0 11
1
0 9 1 0
1
end_operator
begin_operator
board f23 p39
1
0 15
1
0 33 1 0
1
end_operator
begin_operator
board f24 p24
1
0 16
1
0 17 1 0
1
end_operator
begin_operator
board f25 p48
1
0 17
1
0 43 1 0
1
end_operator
begin_operator
board f25 p9
1
0 17
1
0 50 1 0
1
end_operator
begin_operator
board f29 p3
1
0 21
1
0 23 1 0
1
end_operator
begin_operator
board f3 p25
1
0 22
1
0 18 1 0
1
end_operator
begin_operator
board f33 p34
1
0 26
1
0 28 1 0
1
end_operator
begin_operator
board f35 p23
1
0 28
1
0 16 1 0
1
end_operator
begin_operator
board f35 p50
1
0 28
1
0 46 1 0
1
end_operator
begin_operator
board f37 p47
1
0 30
1
0 42 1 0
1
end_operator
begin_operator
board f37 p7
1
0 30
1
0 48 1 0
1
end_operator
begin_operator
board f38 p13
1
0 31
1
0 5 1 0
1
end_operator
begin_operator
board f4 p14
1
0 33
1
0 6 1 0
1
end_operator
begin_operator
board f40 p2
1
0 34
1
0 12 1 0
1
end_operator
begin_operator
board f41 p31
1
0 35
1
0 25 1 0
1
end_operator
begin_operator
board f48 p41
1
0 42
1
0 36 1 0
1
end_operator
begin_operator
board f5 p22
1
0 44
1
0 15 1 0
1
end_operator
begin_operator
board f5 p8
1
0 44
1
0 49 1 0
1
end_operator
begin_operator
board f50 p35
1
0 45
1
0 29 1 0
1
end_operator
begin_operator
board f51 p20
1
0 46
1
0 13 1 0
1
end_operator
begin_operator
board f52 p44
1
0 47
1
0 39 1 0
1
end_operator
begin_operator
board f55 p12
1
0 50
1
0 4 1 0
1
end_operator
begin_operator
board f55 p21
1
0 50
1
0 14 1 0
1
end_operator
begin_operator
board f58 p6
1
0 53
1
0 47 1 0
1
end_operator
begin_operator
board f60 p43
1
0 56
1
0 38 1 0
1
end_operator
begin_operator
board f60 p45
1
0 56
1
0 40 1 0
1
end_operator
begin_operator
board f62 p28
1
0 58
1
0 21 1 0
1
end_operator
begin_operator
board f64 p26
1
0 60
1
0 19 1 0
1
end_operator
begin_operator
board f67 p33
1
0 63
1
0 27 1 0
1
end_operator
begin_operator
board f69 p42
1
0 65
1
0 37 1 0
1
end_operator
begin_operator
board f7 p38
1
0 66
1
0 32 1 0
1
end_operator
begin_operator
board f70 p49
1
0 67
1
0 44 1 0
1
end_operator
begin_operator
board f72 p36
1
0 69
1
0 30 1 0
1
end_operator
begin_operator
board f72 p5
1
0 69
1
0 45 1 0
1
end_operator
begin_operator
board f74 p15
1
0 71
1
0 7 1 0
1
end_operator
begin_operator
board f75 p46
1
0 72
1
0 41 1 0
1
end_operator
begin_operator
board f76 p18
1
0 73
1
0 10 1 0
1
end_operator
begin_operator
board f77 p1
1
0 74
1
0 1 1 0
1
end_operator
begin_operator
board f78 p27
1
0 75
1
0 20 1 0
1
end_operator
begin_operator
board f78 p40
1
0 75
1
0 35 1 0
1
end_operator
begin_operator
board f8 p11
1
0 77
1
0 3 1 0
1
end_operator
begin_operator
board f8 p4
1
0 77
1
0 34 1 0
1
end_operator
begin_operator
board f9 p30
1
0 79
1
0 24 1 0
1
end_operator
begin_operator
depart f10 p46
2
0 1
3251 0
1
0 41 0 2
1
end_operator
begin_operator
depart f16 p42
2
0 7
3247 0
1
0 37 0 2
1
end_operator
begin_operator
depart f17 p10
2
0 8
3212 0
1
0 2 0 2
1
end_operator
begin_operator
depart f19 p33
2
0 10
3237 0
1
0 27 0 2
1
end_operator
begin_operator
depart f23 p1
2
0 15
3211 0
1
0 1 0 2
1
end_operator
begin_operator
depart f23 p2
2
0 15
3222 0
1
0 12 0 2
1
end_operator
begin_operator
depart f24 p27
2
0 16
3230 0
1
0 20 0 2
1
end_operator
begin_operator
depart f24 p32
2
0 16
3236 0
1
0 26 0 2
1
end_operator
begin_operator
depart f26 p28
2
0 18
3231 0
1
0 21 0 2
1
end_operator
begin_operator
depart f27 p24
2
0 19
3227 0
1
0 17 0 2
1
end_operator
begin_operator
depart f27 p4
2
0 19
3244 0
1
0 34 0 2
1
end_operator
begin_operator
depart f28 p35
2
0 20
3239 0
1
0 29 0 2
1
end_operator
begin_operator
depart f28 p45
2
0 20
3250 0
1
0 40 0 2
1
end_operator
begin_operator
depart f3 p48
2
0 22
3253 0
1
0 43 0 2
1
end_operator
begin_operator
depart f30 p13
2
0 23
3215 0
1
0 5 0 2
1
end_operator
begin_operator
depart f30 p38
2
0 23
3242 0
1
0 32 0 2
1
end_operator
begin_operator
depart f32 p29
2
0 25
3232 0
1
0 22 0 2
1
end_operator
begin_operator
depart f32 p40
2
0 25
3245 0
1
0 35 0 2
1
end_operator
begin_operator
depart f32 p9
2
0 25
3260 0
1
0 50 0 2
1
end_operator
begin_operator
depart f33 p16
2
0 26
3218 0
1
0 8 0 2
1
end_operator
begin_operator
depart f35 p21
2
0 28
3224 0
1
0 14 0 2
1
end_operator
begin_operator
depart f35 p37
2
0 28
3241 0
1
0 31 0 2
1
end_operator
begin_operator
depart f37 p11
2
0 30
3213 0
1
0 3 0 2
1
end_operator
begin_operator
depart f37 p20
2
0 30
3223 0
1
0 13 0 2
1
end_operator
begin_operator
depart f37 p36
2
0 30
3240 0
1
0 30 0 2
1
end_operator
begin_operator
depart f38 p12
2
0 31
3214 0
1
0 4 0 2
1
end_operator
begin_operator
depart f41 p44
2
0 35
3249 0
1
0 39 0 2
1
end_operator
begin_operator
depart f42 p15
2
0 36
3217 0
1
0 7 0 2
1
end_operator
begin_operator
depart f42 p39
2
0 36
3243 0
1
0 33 0 2
1
end_operator
begin_operator
depart f44 p14
2
0 38
3216 0
1
0 6 0 2
1
end_operator
begin_operator
depart f48 p30
2
0 42
3234 0
1
0 24 0 2
1
end_operator
begin_operator
depart f49 p31
2
0 43
3235 0
1
0 25 0 2
1
end_operator
begin_operator
depart f5 p7
2
0 44
3258 0
1
0 48 0 2
1
end_operator
begin_operator
depart f50 p22
2
0 45
3225 0
1
0 15 0 2
1
end_operator
begin_operator
depart f54 p23
2
0 49
3226 0
1
0 16 0 2
1
end_operator
begin_operator
depart f57 p18
2
0 52
3220 0
1
0 10 0 2
1
end_operator
begin_operator
depart f57 p8
2
0 52
3259 0
1
0 49 0 2
1
end_operator
begin_operator
depart f59 p26
2
0 54
3229 0
1
0 19 0 2
1
end_operator
begin_operator
depart f59 p43
2
0 54
3248 0
1
0 38 0 2
1
end_operator
begin_operator
depart f59 p50
2
0 54
3256 0
1
0 46 0 2
1
end_operator
begin_operator
depart f60 p19
2
0 56
3221 0
1
0 11 0 2
1
end_operator
begin_operator
depart f64 p49
2
0 60
3254 0
1
0 44 0 2
1
end_operator
begin_operator
depart f68 p25
2
0 64
3228 0
1
0 18 0 2
1
end_operator
begin_operator
depart f68 p3
2
0 64
3233 0
1
0 23 0 2
1
end_operator
begin_operator
depart f7 p5
2
0 66
3255 0
1
0 45 0 2
1
end_operator
begin_operator
depart f76 p6
2
0 73
3257 0
1
0 47 0 2
1
end_operator
begin_operator
depart f77 p47
2
0 74
3252 0
1
0 42 0 2
1
end_operator
begin_operator
depart f8 p17
2
0 77
3219 0
1
0 9 0 2
1
end_operator
begin_operator
depart f8 p41
2
0 77
3246 0
1
0 36 0 2
1
end_operator
begin_operator
depart f80 p34
2
0 78
3238 0
1
0 28 0 2
1
end_operator
begin_operator
down f10 f1
1
51 0
1
0 0 1 0
1
end_operator
begin_operator
down f10 f2
1
785 0
1
0 0 1 11
1
end_operator
begin_operator
down f10 f3
1
1418 0
1
0 0 1 22
1
end_operator
begin_operator
down f10 f4
1
1950 0
1
0 0 1 33
1
end_operator
begin_operator
down f10 f5
1
2381 0
1
0 0 1 44
1
end_operator
begin_operator
down f10 f6
1
2711 0
1
0 0 1 55
1
end_operator
begin_operator
down f10 f7
1
2940 0
1
0 0 1 66
1
end_operator
begin_operator
down f10 f8
1
3068 0
1
0 0 1 77
1
end_operator
begin_operator
down f10 f9
1
3140 0
1
0 0 1 79
1
end_operator
begin_operator
down f11 f1
1
52 0
1
0 0 2 0
1
end_operator
begin_operator
down f11 f10
1
130 0
1
0 0 2 1
1
end_operator
begin_operator
down f11 f2
1
786 0
1
0 0 2 11
1
end_operator
begin_operator
down f11 f3
1
1419 0
1
0 0 2 22
1
end_operator
begin_operator
down f11 f4
1
1951 0
1
0 0 2 33
1
end_operator
begin_operator
down f11 f5
1
2382 0
1
0 0 2 44
1
end_operator
begin_operator
down f11 f6
1
2712 0
1
0 0 2 55
1
end_operator
begin_operator
down f11 f7
1
2941 0
1
0 0 2 66
1
end_operator
begin_operator
down f11 f8
1
3069 0
1
0 0 2 77
1
end_operator
begin_operator
down f11 f9
1
3141 0
1
0 0 2 79
1
end_operator
begin_operator
down f12 f1
1
53 0
1
0 0 3 0
1
end_operator
begin_operator
down f12 f10
1
131 0
1
0 0 3 1
1
end_operator
begin_operator
down f12 f11
1
200 0
1
0 0 3 2
1
end_operator
begin_operator
down f12 f2
1
787 0
1
0 0 3 11
1
end_operator
begin_operator
down f12 f3
1
1420 0
1
0 0 3 22
1
end_operator
begin_operator
down f12 f4
1
1952 0
1
0 0 3 33
1
end_operator
begin_operator
down f12 f5
1
2383 0
1
0 0 3 44
1
end_operator
begin_operator
down f12 f6
1
2713 0
1
0 0 3 55
1
end_operator
begin_operator
down f12 f7
1
2942 0
1
0 0 3 66
1
end_operator
begin_operator
down f12 f8
1
3070 0
1
0 0 3 77
1
end_operator
begin_operator
down f12 f9
1
3142 0
1
0 0 3 79
1
end_operator
begin_operator
down f13 f1
1
54 0
1
0 0 4 0
1
end_operator
begin_operator
down f13 f10
1
132 0
1
0 0 4 1
1
end_operator
begin_operator
down f13 f11
1
201 0
1
0 0 4 2
1
end_operator
begin_operator
down f13 f12
1
269 0
1
0 0 4 3
1
end_operator
begin_operator
down f13 f2
1
788 0
1
0 0 4 11
1
end_operator
begin_operator
down f13 f3
1
1421 0
1
0 0 4 22
1
end_operator
begin_operator
down f13 f4
1
1953 0
1
0 0 4 33
1
end_operator
begin_operator
down f13 f5
1
2384 0
1
0 0 4 44
1
end_operator
begin_operator
down f13 f6
1
2714 0
1
0 0 4 55
1
end_operator
begin_operator
down f13 f7
1
2943 0
1
0 0 4 66
1
end_operator
begin_operator
down f13 f8
1
3071 0
1
0 0 4 77
1
end_operator
begin_operator
down f13 f9
1
3143 0
1
0 0 4 79
1
end_operator
begin_operator
down f14 f1
1
55 0
1
0 0 5 0
1
end_operator
begin_operator
down f14 f10
1
133 0
1
0 0 5 1
1
end_operator
begin_operator
down f14 f11
1
202 0
1
0 0 5 2
1
end_operator
begin_operator
down f14 f12
1
270 0
1
0 0 5 3
1
end_operator
begin_operator
down f14 f13
1
337 0
1
0 0 5 4
1
end_operator
begin_operator
down f14 f2
1
789 0
1
0 0 5 11
1
end_operator
begin_operator
down f14 f3
1
1422 0
1
0 0 5 22
1
end_operator
begin_operator
down f14 f4
1
1954 0
1
0 0 5 33
1
end_operator
begin_operator
down f14 f5
1
2385 0
1
0 0 5 44
1
end_operator
begin_operator
down f14 f6
1
2715 0
1
0 0 5 55
1
end_operator
begin_operator
down f14 f7
1
2944 0
1
0 0 5 66
1
end_operator
begin_operator
down f14 f8
1
3072 0
1
0 0 5 77
1
end_operator
begin_operator
down f14 f9
1
3144 0
1
0 0 5 79
1
end_operator
begin_operator
down f15 f1
1
56 0
1
0 0 6 0
1
end_operator
begin_operator
down f15 f10
1
134 0
1
0 0 6 1
1
end_operator
begin_operator
down f15 f11
1
203 0
1
0 0 6 2
1
end_operator
begin_operator
down f15 f12
1
271 0
1
0 0 6 3
1
end_operator
begin_operator
down f15 f13
1
338 0
1
0 0 6 4
1
end_operator
begin_operator
down f15 f14
1
404 0
1
0 0 6 5
1
end_operator
begin_operator
down f15 f2
1
790 0
1
0 0 6 11
1
end_operator
begin_operator
down f15 f3
1
1423 0
1
0 0 6 22
1
end_operator
begin_operator
down f15 f4
1
1955 0
1
0 0 6 33
1
end_operator
begin_operator
down f15 f5
1
2386 0
1
0 0 6 44
1
end_operator
begin_operator
down f15 f6
1
2716 0
1
0 0 6 55
1
end_operator
begin_operator
down f15 f7
1
2945 0
1
0 0 6 66
1
end_operator
begin_operator
down f15 f8
1
3073 0
1
0 0 6 77
1
end_operator
begin_operator
down f15 f9
1
3145 0
1
0 0 6 79
1
end_operator
begin_operator
down f16 f1
1
57 0
1
0 0 7 0
1
end_operator
begin_operator
down f16 f10
1
135 0
1
0 0 7 1
1
end_operator
begin_operator
down f16 f11
1
204 0
1
0 0 7 2
1
end_operator
begin_operator
down f16 f12
1
272 0
1
0 0 7 3
1
end_operator
begin_operator
down f16 f13
1
339 0
1
0 0 7 4
1
end_operator
begin_operator
down f16 f14
1
405 0
1
0 0 7 5
1
end_operator
begin_operator
down f16 f15
1
470 0
1
0 0 7 6
1
end_operator
begin_operator
down f16 f2
1
791 0
1
0 0 7 11
1
end_operator
begin_operator
down f16 f3
1
1424 0
1
0 0 7 22
1
end_operator
begin_operator
down f16 f4
1
1956 0
1
0 0 7 33
1
end_operator
begin_operator
down f16 f5
1
2387 0
1
0 0 7 44
1
end_operator
begin_operator
down f16 f6
1
2717 0
1
0 0 7 55
1
end_operator
begin_operator
down f16 f7
1
2946 0
1
0 0 7 66
1
end_operator
begin_operator
down f16 f8
1
3074 0
1
0 0 7 77
1
end_operator
begin_operator
down f16 f9
1
3146 0
1
0 0 7 79
1
end_operator
begin_operator
down f17 f1
1
58 0
1
0 0 8 0
1
end_operator
begin_operator
down f17 f10
1
136 0
1
0 0 8 1
1
end_operator
begin_operator
down f17 f11
1
205 0
1
0 0 8 2
1
end_operator
begin_operator
down f17 f12
1
273 0
1
0 0 8 3
1
end_operator
begin_operator
down f17 f13
1
340 0
1
0 0 8 4
1
end_operator
begin_operator
down f17 f14
1
406 0
1
0 0 8 5
1
end_operator
begin_operator
down f17 f15
1
471 0
1
0 0 8 6
1
end_operator
begin_operator
down f17 f16
1
535 0
1
0 0 8 7
1
end_operator
begin_operator
down f17 f2
1
792 0
1
0 0 8 11
1
end_operator
begin_operator
down f17 f3
1
1425 0
1
0 0 8 22
1
end_operator
begin_operator
down f17 f4
1
1957 0
1
0 0 8 33
1
end_operator
begin_operator
down f17 f5
1
2388 0
1
0 0 8 44
1
end_operator
begin_operator
down f17 f6
1
2718 0
1
0 0 8 55
1
end_operator
begin_operator
down f17 f7
1
2947 0
1
0 0 8 66
1
end_operator
begin_operator
down f17 f8
1
3075 0
1
0 0 8 77
1
end_operator
begin_operator
down f17 f9
1
3147 0
1
0 0 8 79
1
end_operator
begin_operator
down f18 f1
1
59 0
1
0 0 9 0
1
end_operator
begin_operator
down f18 f10
1
137 0
1
0 0 9 1
1
end_operator
begin_operator
down f18 f11
1
206 0
1
0 0 9 2
1
end_operator
begin_operator
down f18 f12
1
274 0
1
0 0 9 3
1
end_operator
begin_operator
down f18 f13
1
341 0
1
0 0 9 4
1
end_operator
begin_operator
down f18 f14
1
407 0
1
0 0 9 5
1
end_operator
begin_operator
down f18 f15
1
472 0
1
0 0 9 6
1
end_operator
begin_operator
down f18 f16
1
536 0
1
0 0 9 7
1
end_operator
begin_operator
down f18 f17
1
599 0
1
0 0 9 8
1
end_operator
begin_operator
down f18 f2
1
793 0
1
0 0 9 11
1
end_operator
begin_operator
down f18 f3
1
1426 0
1
0 0 9 22
1
end_operator
begin_operator
down f18 f4
1
1958 0
1
0 0 9 33
1
end_operator
begin_operator
down f18 f5
1
2389 0
1
0 0 9 44
1
end_operator
begin_operator
down f18 f6
1
2719 0
1
0 0 9 55
1
end_operator
begin_operator
down f18 f7
1
2948 0
1
0 0 9 66
1
end_operator
begin_operator
down f18 f8
1
3076 0
1
0 0 9 77
1
end_operator
begin_operator
down f18 f9
1
3148 0
1
0 0 9 79
1
end_operator
begin_operator
down f19 f1
1
60 0
1
0 0 10 0
1
end_operator
begin_operator
down f19 f10
1
138 0
1
0 0 10 1
1
end_operator
begin_operator
down f19 f11
1
207 0
1
0 0 10 2
1
end_operator
begin_operator
down f19 f12
1
275 0
1
0 0 10 3
1
end_operator
begin_operator
down f19 f13
1
342 0
1
0 0 10 4
1
end_operator
begin_operator
down f19 f14
1
408 0
1
0 0 10 5
1
end_operator
begin_operator
down f19 f15
1
473 0
1
0 0 10 6
1
end_operator
begin_operator
down f19 f16
1
537 0
1
0 0 10 7
1
end_operator
begin_operator
down f19 f17
1
600 0
1
0 0 10 8
1
end_operator
begin_operator
down f19 f18
1
662 0
1
0 0 10 9
1
end_operator
begin_operator
down f19 f2
1
794 0
1
0 0 10 11
1
end_operator
begin_operator
down f19 f3
1
1427 0
1
0 0 10 22
1
end_operator
begin_operator
down f19 f4
1
1959 0
1
0 0 10 33
1
end_operator
begin_operator
down f19 f5
1
2390 0
1
0 0 10 44
1
end_operator
begin_operator
down f19 f6
1
2720 0
1
0 0 10 55
1
end_operator
begin_operator
down f19 f7
1
2949 0
1
0 0 10 66
1
end_operator
begin_operator
down f19 f8
1
3077 0
1
0 0 10 77
1
end_operator
begin_operator
down f19 f9
1
3149 0
1
0 0 10 79
1
end_operator
begin_operator
down f2 f1
1
61 0
1
0 0 11 0
1
end_operator
begin_operator
down f20 f1
1
62 0
1
0 0 12 0
1
end_operator
begin_operator
down f20 f10
1
139 0
1
0 0 12 1
1
end_operator
begin_operator
down f20 f11
1
208 0
1
0 0 12 2
1
end_operator
begin_operator
down f20 f12
1
276 0
1
0 0 12 3
1
end_operator
begin_operator
down f20 f13
1
343 0
1
0 0 12 4
1
end_operator
begin_operator
down f20 f14
1
409 0
1
0 0 12 5
1
end_operator
begin_operator
down f20 f15
1
474 0
1
0 0 12 6
1
end_operator
begin_operator
down f20 f16
1
538 0
1
0 0 12 7
1
end_operator
begin_operator
down f20 f17
1
601 0
1
0 0 12 8
1
end_operator
begin_operator
down f20 f18
1
663 0
1
0 0 12 9
1
end_operator
begin_operator
down f20 f19
1
724 0
1
0 0 12 10
1
end_operator
begin_operator
down f20 f2
1
795 0
1
0 0 12 11
1
end_operator
begin_operator
down f20 f3
1
1428 0
1
0 0 12 22
1
end_operator
begin_operator
down f20 f4
1
1960 0
1
0 0 12 33
1
end_operator
begin_operator
down f20 f5
1
2391 0
1
0 0 12 44
1
end_operator
begin_operator
down f20 f6
1
2721 0
1
0 0 12 55
1
end_operator
begin_operator
down f20 f7
1
2950 0
1
0 0 12 66
1
end_operator
begin_operator
down f20 f8
1
3078 0
1
0 0 12 77
1
end_operator
begin_operator
down f20 f9
1
3150 0
1
0 0 12 79
1
end_operator
begin_operator
down f21 f1
1
63 0
1
0 0 13 0
1
end_operator
begin_operator
down f21 f10
1
140 0
1
0 0 13 1
1
end_operator
begin_operator
down f21 f11
1
209 0
1
0 0 13 2
1
end_operator
begin_operator
down f21 f12
1
277 0
1
0 0 13 3
1
end_operator
begin_operator
down f21 f13
1
344 0
1
0 0 13 4
1
end_operator
begin_operator
down f21 f14
1
410 0
1
0 0 13 5
1
end_operator
begin_operator
down f21 f15
1
475 0
1
0 0 13 6
1
end_operator
begin_operator
down f21 f16
1
539 0
1
0 0 13 7
1
end_operator
begin_operator
down f21 f17
1
602 0
1
0 0 13 8
1
end_operator
begin_operator
down f21 f18
1
664 0
1
0 0 13 9
1
end_operator
begin_operator
down f21 f19
1
725 0
1
0 0 13 10
1
end_operator
begin_operator
down f21 f2
1
796 0
1
0 0 13 11
1
end_operator
begin_operator
down f21 f20
1
863 0
1
0 0 13 12
1
end_operator
begin_operator
down f21 f3
1
1429 0
1
0 0 13 22
1
end_operator
begin_operator
down f21 f4
1
1961 0
1
0 0 13 33
1
end_operator
begin_operator
down f21 f5
1
2392 0
1
0 0 13 44
1
end_operator
begin_operator
down f21 f6
1
2722 0
1
0 0 13 55
1
end_operator
begin_operator
down f21 f7
1
2951 0
1
0 0 13 66
1
end_operator
begin_operator
down f21 f8
1
3079 0
1
0 0 13 77
1
end_operator
begin_operator
down f21 f9
1
3151 0
1
0 0 13 79
1
end_operator
begin_operator
down f22 f1
1
64 0
1
0 0 14 0
1
end_operator
begin_operator
down f22 f10
1
141 0
1
0 0 14 1
1
end_operator
begin_operator
down f22 f11
1
210 0
1
0 0 14 2
1
end_operator
begin_operator
down f22 f12
1
278 0
1
0 0 14 3
1
end_operator
begin_operator
down f22 f13
1
345 0
1
0 0 14 4
1
end_operator
begin_operator
down f22 f14
1
411 0
1
0 0 14 5
1
end_operator
begin_operator
down f22 f15
1
476 0
1
0 0 14 6
1
end_operator
begin_operator
down f22 f16
1
540 0
1
0 0 14 7
1
end_operator
begin_operator
down f22 f17
1
603 0
1
0 0 14 8
1
end_operator
begin_operator
down f22 f18
1
665 0
1
0 0 14 9
1
end_operator
begin_operator
down f22 f19
1
726 0
1
0 0 14 10
1
end_operator
begin_operator
down f22 f2
1
797 0
1
0 0 14 11
1
end_operator
begin_operator
down f22 f20
1
864 0
1
0 0 14 12
1
end_operator
begin_operator
down f22 f21
1
923 0
1
0 0 14 13
1
end_operator
begin_operator
down f22 f3
1
1430 0
1
0 0 14 22
1
end_operator
begin_operator
down f22 f4
1
1962 0
1
0 0 14 33
1
end_operator
begin_operator
down f22 f5
1
2393 0
1
0 0 14 44
1
end_operator
begin_operator
down f22 f6
1
2723 0
1
0 0 14 55
1
end_operator
begin_operator
down f22 f7
1
2952 0
1
0 0 14 66
1
end_operator
begin_operator
down f22 f8
1
3080 0
1
0 0 14 77
1
end_operator
begin_operator
down f22 f9
1
3152 0
1
0 0 14 79
1
end_operator
begin_operator
down f23 f1
1
65 0
1
0 0 15 0
1
end_operator
begin_operator
down f23 f10
1
142 0
1
0 0 15 1
1
end_operator
begin_operator
down f23 f11
1
211 0
1
0 0 15 2
1
end_operator
begin_operator
down f23 f12
1
279 0
1
0 0 15 3
1
end_operator
begin_operator
down f23 f13
1
346 0
1
0 0 15 4
1
end_operator
begin_operator
down f23 f14
1
412 0
1
0 0 15 5
1
end_operator
begin_operator
down f23 f15
1
477 0
1
0 0 15 6
1
end_operator
begin_operator
down f23 f16
1
541 0
1
0 0 15 7
1
end_operator
begin_operator
down f23 f17
1
604 0
1
0 0 15 8
1
end_operator
begin_operator
down f23 f18
1
666 0
1
0 0 15 9
1
end_operator
begin_operator
down f23 f19
1
727 0
1
0 0 15 10
1
end_operator
begin_operator
down f23 f2
1
798 0
1
0 0 15 11
1
end_operator
begin_operator
down f23 f20
1
865 0
1
0 0 15 12
1
end_operator
begin_operator
down f23 f21
1
924 0
1
0 0 15 13
1
end_operator
begin_operator
down f23 f22
1
982 0
1
0 0 15 14
1
end_operator
begin_operator
down f23 f3
1
1431 0
1
0 0 15 22
1
end_operator
begin_operator
down f23 f4
1
1963 0
1
0 0 15 33
1
end_operator
begin_operator
down f23 f5
1
2394 0
1
0 0 15 44
1
end_operator
begin_operator
down f23 f6
1
2724 0
1
0 0 15 55
1
end_operator
begin_operator
down f23 f7
1
2953 0
1
0 0 15 66
1
end_operator
begin_operator
down f23 f8
1
3081 0
1
0 0 15 77
1
end_operator
begin_operator
down f23 f9
1
3153 0
1
0 0 15 79
1
end_operator
begin_operator
down f24 f1
1
66 0
1
0 0 16 0
1
end_operator
begin_operator
down f24 f10
1
143 0
1
0 0 16 1
1
end_operator
begin_operator
down f24 f11
1
212 0
1
0 0 16 2
1
end_operator
begin_operator
down f24 f12
1
280 0
1
0 0 16 3
1
end_operator
begin_operator
down f24 f13
1
347 0
1
0 0 16 4
1
end_operator
begin_operator
down f24 f14
1
413 0
1
0 0 16 5
1
end_operator
begin_operator
down f24 f15
1
478 0
1
0 0 16 6
1
end_operator
begin_operator
down f24 f16
1
542 0
1
0 0 16 7
1
end_operator
begin_operator
down f24 f17
1
605 0
1
0 0 16 8
1
end_operator
begin_operator
down f24 f18
1
667 0
1
0 0 16 9
1
end_operator
begin_operator
down f24 f19
1
728 0
1
0 0 16 10
1
end_operator
begin_operator
down f24 f2
1
799 0
1
0 0 16 11
1
end_operator
begin_operator
down f24 f20
1
866 0
1
0 0 16 12
1
end_operator
begin_operator
down f24 f21
1
925 0
1
0 0 16 13
1
end_operator
begin_operator
down f24 f22
1
983 0
1
0 0 16 14
1
end_operator
begin_operator
down f24 f23
1
1040 0
1
0 0 16 15
1
end_operator
begin_operator
down f24 f3
1
1432 0
1
0 0 16 22
1
end_operator
begin_operator
down f24 f4
1
1964 0
1
0 0 16 33
1
end_operator
begin_operator
down f24 f5
1
2395 0
1
0 0 16 44
1
end_operator
begin_operator
down f24 f6
1
2725 0
1
0 0 16 55
1
end_operator
begin_operator
down f24 f7
1
2954 0
1
0 0 16 66
1
end_operator
begin_operator
down f24 f8
1
3082 0
1
0 0 16 77
1
end_operator
begin_operator
down f24 f9
1
3154 0
1
0 0 16 79
1
end_operator
begin_operator
down f25 f1
1
67 0
1
0 0 17 0
1
end_operator
begin_operator
down f25 f10
1
144 0
1
0 0 17 1
1
end_operator
begin_operator
down f25 f11
1
213 0
1
0 0 17 2
1
end_operator
begin_operator
down f25 f12
1
281 0
1
0 0 17 3
1
end_operator
begin_operator
down f25 f13
1
348 0
1
0 0 17 4
1
end_operator
begin_operator
down f25 f14
1
414 0
1
0 0 17 5
1
end_operator
begin_operator
down f25 f15
1
479 0
1
0 0 17 6
1
end_operator
begin_operator
down f25 f16
1
543 0
1
0 0 17 7
1
end_operator
begin_operator
down f25 f17
1
606 0
1
0 0 17 8
1
end_operator
begin_operator
down f25 f18
1
668 0
1
0 0 17 9
1
end_operator
begin_operator
down f25 f19
1
729 0
1
0 0 17 10
1
end_operator
begin_operator
down f25 f2
1
800 0
1
0 0 17 11
1
end_operator
begin_operator
down f25 f20
1
867 0
1
0 0 17 12
1
end_operator
begin_operator
down f25 f21
1
926 0
1
0 0 17 13
1
end_operator
begin_operator
down f25 f22
1
984 0
1
0 0 17 14
1
end_operator
begin_operator
down f25 f23
1
1041 0
1
0 0 17 15
1
end_operator
begin_operator
down f25 f24
1
1097 0
1
0 0 17 16
1
end_operator
begin_operator
down f25 f3
1
1433 0
1
0 0 17 22
1
end_operator
begin_operator
down f25 f4
1
1965 0
1
0 0 17 33
1
end_operator
begin_operator
down f25 f5
1
2396 0
1
0 0 17 44
1
end_operator
begin_operator
down f25 f6
1
2726 0
1
0 0 17 55
1
end_operator
begin_operator
down f25 f7
1
2955 0
1
0 0 17 66
1
end_operator
begin_operator
down f25 f8
1
3083 0
1
0 0 17 77
1
end_operator
begin_operator
down f25 f9
1
3155 0
1
0 0 17 79
1
end_operator
begin_operator
down f26 f1
1
68 0
1
0 0 18 0
1
end_operator
begin_operator
down f26 f10
1
145 0
1
0 0 18 1
1
end_operator
begin_operator
down f26 f11
1
214 0
1
0 0 18 2
1
end_operator
begin_operator
down f26 f12
1
282 0
1
0 0 18 3
1
end_operator
begin_operator
down f26 f13
1
349 0
1
0 0 18 4
1
end_operator
begin_operator
down f26 f14
1
415 0
1
0 0 18 5
1
end_operator
begin_operator
down f26 f15
1
480 0
1
0 0 18 6
1
end_operator
begin_operator
down f26 f16
1
544 0
1
0 0 18 7
1
end_operator
begin_operator
down f26 f17
1
607 0
1
0 0 18 8
1
end_operator
begin_operator
down f26 f18
1
669 0
1
0 0 18 9
1
end_operator
begin_operator
down f26 f19
1
730 0
1
0 0 18 10
1
end_operator
begin_operator
down f26 f2
1
801 0
1
0 0 18 11
1
end_operator
begin_operator
down f26 f20
1
868 0
1
0 0 18 12
1
end_operator
begin_operator
down f26 f21
1
927 0
1
0 0 18 13
1
end_operator
begin_operator
down f26 f22
1
985 0
1
0 0 18 14
1
end_operator
begin_operator
down f26 f23
1
1042 0
1
0 0 18 15
1
end_operator
begin_operator
down f26 f24
1
1098 0
1
0 0 18 16
1
end_operator
begin_operator
down f26 f25
1
1153 0
1
0 0 18 17
1
end_operator
begin_operator
down f26 f3
1
1434 0
1
0 0 18 22
1
end_operator
begin_operator
down f26 f4
1
1966 0
1
0 0 18 33
1
end_operator
begin_operator
down f26 f5
1
2397 0
1
0 0 18 44
1
end_operator
begin_operator
down f26 f6
1
2727 0
1
0 0 18 55
1
end_operator
begin_operator
down f26 f7
1
2956 0
1
0 0 18 66
1
end_operator
begin_operator
down f26 f8
1
3084 0
1
0 0 18 77
1
end_operator
begin_operator
down f26 f9
1
3156 0
1
0 0 18 79
1
end_operator
begin_operator
down f27 f1
1
69 0
1
0 0 19 0
1
end_operator
begin_operator
down f27 f10
1
146 0
1
0 0 19 1
1
end_operator
begin_operator
down f27 f11
1
215 0
1
0 0 19 2
1
end_operator
begin_operator
down f27 f12
1
283 0
1
0 0 19 3
1
end_operator
begin_operator
down f27 f13
1
350 0
1
0 0 19 4
1
end_operator
begin_operator
down f27 f14
1
416 0
1
0 0 19 5
1
end_operator
begin_operator
down f27 f15
1
481 0
1
0 0 19 6
1
end_operator
begin_operator
down f27 f16
1
545 0
1
0 0 19 7
1
end_operator
begin_operator
down f27 f17
1
608 0
1
0 0 19 8
1
end_operator
begin_operator
down f27 f18
1
670 0
1
0 0 19 9
1
end_operator
begin_operator
down f27 f19
1
731 0
1
0 0 19 10
1
end_operator
begin_operator
down f27 f2
1
802 0
1
0 0 19 11
1
end_operator
begin_operator
down f27 f20
1
869 0
1
0 0 19 12
1
end_operator
begin_operator
down f27 f21
1
928 0
1
0 0 19 13
1
end_operator
begin_operator
down f27 f22
1
986 0
1
0 0 19 14
1
end_operator
begin_operator
down f27 f23
1
1043 0
1
0 0 19 15
1
end_operator
begin_operator
down f27 f24
1
1099 0
1
0 0 19 16
1
end_operator
begin_operator
down f27 f25
1
1154 0
1
0 0 19 17
1
end_operator
begin_operator
down f27 f26
1
1208 0
1
0 0 19 18
1
end_operator
begin_operator
down f27 f3
1
1435 0
1
0 0 19 22
1
end_operator
begin_operator
down f27 f4
1
1967 0
1
0 0 19 33
1
end_operator
begin_operator
down f27 f5
1
2398 0
1
0 0 19 44
1
end_operator
begin_operator
down f27 f6
1
2728 0
1
0 0 19 55
1
end_operator
begin_operator
down f27 f7
1
2957 0
1
0 0 19 66
1
end_operator
begin_operator
down f27 f8
1
3085 0
1
0 0 19 77
1
end_operator
begin_operator
down f27 f9
1
3157 0
1
0 0 19 79
1
end_operator
begin_operator
down f28 f1
1
70 0
1
0 0 20 0
1
end_operator
begin_operator
down f28 f10
1
147 0
1
0 0 20 1
1
end_operator
begin_operator
down f28 f11
1
216 0
1
0 0 20 2
1
end_operator
begin_operator
down f28 f12
1
284 0
1
0 0 20 3
1
end_operator
begin_operator
down f28 f13
1
351 0
1
0 0 20 4
1
end_operator
begin_operator
down f28 f14
1
417 0
1
0 0 20 5
1
end_operator
begin_operator
down f28 f15
1
482 0
1
0 0 20 6
1
end_operator
begin_operator
down f28 f16
1
546 0
1
0 0 20 7
1
end_operator
begin_operator
down f28 f17
1
609 0
1
0 0 20 8
1
end_operator
begin_operator
down f28 f18
1
671 0
1
0 0 20 9
1
end_operator
begin_operator
down f28 f19
1
732 0
1
0 0 20 10
1
end_operator
begin_operator
down f28 f2
1
803 0
1
0 0 20 11
1
end_operator
begin_operator
down f28 f20
1
870 0
1
0 0 20 12
1
end_operator
begin_operator
down f28 f21
1
929 0
1
0 0 20 13
1
end_operator
begin_operator
down f28 f22
1
987 0
1
0 0 20 14
1
end_operator
begin_operator
down f28 f23
1
1044 0
1
0 0 20 15
1
end_operator
begin_operator
down f28 f24
1
1100 0
1
0 0 20 16
1
end_operator
begin_operator
down f28 f25
1
1155 0
1
0 0 20 17
1
end_operator
begin_operator
down f28 f26
1
1209 0
1
0 0 20 18
1
end_operator
begin_operator
down f28 f27
1
1262 0
1
0 0 20 19
1
end_operator
begin_operator
down f28 f3
1
1436 0
1
0 0 20 22
1
end_operator
begin_operator
down f28 f4
1
1968 0
1
0 0 20 33
1
end_operator
begin_operator
down f28 f5
1
2399 0
1
0 0 20 44
1
end_operator
begin_operator
down f28 f6
1
2729 0
1
0 0 20 55
1
end_operator
begin_operator
down f28 f7
1
2958 0
1
0 0 20 66
1
end_operator
begin_operator
down f28 f8
1
3086 0
1
0 0 20 77
1
end_operator
begin_operator
down f28 f9
1
3158 0
1
0 0 20 79
1
end_operator
begin_operator
down f29 f1
1
71 0
1
0 0 21 0
1
end_operator
begin_operator
down f29 f10
1
148 0
1
0 0 21 1
1
end_operator
begin_operator
down f29 f11
1
217 0
1
0 0 21 2
1
end_operator
begin_operator
down f29 f12
1
285 0
1
0 0 21 3
1
end_operator
begin_operator
down f29 f13
1
352 0
1
0 0 21 4
1
end_operator
begin_operator
down f29 f14
1
418 0
1
0 0 21 5
1
end_operator
begin_operator
down f29 f15
1
483 0
1
0 0 21 6
1
end_operator
begin_operator
down f29 f16
1
547 0
1
0 0 21 7
1
end_operator
begin_operator
down f29 f17
1
610 0
1
0 0 21 8
1
end_operator
begin_operator
down f29 f18
1
672 0
1
0 0 21 9
1
end_operator
begin_operator
down f29 f19
1
733 0
1
0 0 21 10
1
end_operator
begin_operator
down f29 f2
1
804 0
1
0 0 21 11
1
end_operator
begin_operator
down f29 f20
1
871 0
1
0 0 21 12
1
end_operator
begin_operator
down f29 f21
1
930 0
1
0 0 21 13
1
end_operator
begin_operator
down f29 f22
1
988 0
1
0 0 21 14
1
end_operator
begin_operator
down f29 f23
1
1045 0
1
0 0 21 15
1
end_operator
begin_operator
down f29 f24
1
1101 0
1
0 0 21 16
1
end_operator
begin_operator
down f29 f25
1
1156 0
1
0 0 21 17
1
end_operator
begin_operator
down f29 f26
1
1210 0
1
0 0 21 18
1
end_operator
begin_operator
down f29 f27
1
1263 0
1
0 0 21 19
1
end_operator
begin_operator
down f29 f28
1
1315 0
1
0 0 21 20
1
end_operator
begin_operator
down f29 f3
1
1437 0
1
0 0 21 22
1
end_operator
begin_operator
down f29 f4
1
1969 0
1
0 0 21 33
1
end_operator
begin_operator
down f29 f5
1
2400 0
1
0 0 21 44
1
end_operator
begin_operator
down f29 f6
1
2730 0
1
0 0 21 55
1
end_operator
begin_operator
down f29 f7
1
2959 0
1
0 0 21 66
1
end_operator
begin_operator
down f29 f8
1
3087 0
1
0 0 21 77
1
end_operator
begin_operator
down f29 f9
1
3159 0
1
0 0 21 79
1
end_operator
begin_operator
down f3 f1
1
72 0
1
0 0 22 0
1
end_operator
begin_operator
down f3 f2
1
805 0
1
0 0 22 11
1
end_operator
begin_operator
down f30 f1
1
73 0
1
0 0 23 0
1
end_operator
begin_operator
down f30 f10
1
149 0
1
0 0 23 1
1
end_operator
begin_operator
down f30 f11
1
218 0
1
0 0 23 2
1
end_operator
begin_operator
down f30 f12
1
286 0
1
0 0 23 3
1
end_operator
begin_operator
down f30 f13
1
353 0
1
0 0 23 4
1
end_operator
begin_operator
down f30 f14
1
419 0
1
0 0 23 5
1
end_operator
begin_operator
down f30 f15
1
484 0
1
0 0 23 6
1
end_operator
begin_operator
down f30 f16
1
548 0
1
0 0 23 7
1
end_operator
begin_operator
down f30 f17
1
611 0
1
0 0 23 8
1
end_operator
begin_operator
down f30 f18
1
673 0
1
0 0 23 9
1
end_operator
begin_operator
down f30 f19
1
734 0
1
0 0 23 10
1
end_operator
begin_operator
down f30 f2
1
806 0
1
0 0 23 11
1
end_operator
begin_operator
down f30 f20
1
872 0
1
0 0 23 12
1
end_operator
begin_operator
down f30 f21
1
931 0
1
0 0 23 13
1
end_operator
begin_operator
down f30 f22
1
989 0
1
0 0 23 14
1
end_operator
begin_operator
down f30 f23
1
1046 0
1
0 0 23 15
1
end_operator
begin_operator
down f30 f24
1
1102 0
1
0 0 23 16
1
end_operator
begin_operator
down f30 f25
1
1157 0
1
0 0 23 17
1
end_operator
begin_operator
down f30 f26
1
1211 0
1
0 0 23 18
1
end_operator
begin_operator
down f30 f27
1
1264 0
1
0 0 23 19
1
end_operator
begin_operator
down f30 f28
1
1316 0
1
0 0 23 20
1
end_operator
begin_operator
down f30 f29
1
1367 0
1
0 0 23 21
1
end_operator
begin_operator
down f30 f3
1
1438 0
1
0 0 23 22
1
end_operator
begin_operator
down f30 f4
1
1970 0
1
0 0 23 33
1
end_operator
begin_operator
down f30 f5
1
2401 0
1
0 0 23 44
1
end_operator
begin_operator
down f30 f6
1
2731 0
1
0 0 23 55
1
end_operator
begin_operator
down f30 f7
1
2960 0
1
0 0 23 66
1
end_operator
begin_operator
down f30 f8
1
3088 0
1
0 0 23 77
1
end_operator
begin_operator
down f30 f9
1
3160 0
1
0 0 23 79
1
end_operator
begin_operator
down f31 f1
1
74 0
1
0 0 24 0
1
end_operator
begin_operator
down f31 f10
1
150 0
1
0 0 24 1
1
end_operator
begin_operator
down f31 f11
1
219 0
1
0 0 24 2
1
end_operator
begin_operator
down f31 f12
1
287 0
1
0 0 24 3
1
end_operator
begin_operator
down f31 f13
1
354 0
1
0 0 24 4
1
end_operator
begin_operator
down f31 f14
1
420 0
1
0 0 24 5
1
end_operator
begin_operator
down f31 f15
1
485 0
1
0 0 24 6
1
end_operator
begin_operator
down f31 f16
1
549 0
1
0 0 24 7
1
end_operator
begin_operator
down f31 f17
1
612 0
1
0 0 24 8
1
end_operator
begin_operator
down f31 f18
1
674 0
1
0 0 24 9
1
end_operator
begin_operator
down f31 f19
1
735 0
1
0 0 24 10
1
end_operator
begin_operator
down f31 f2
1
807 0
1
0 0 24 11
1
end_operator
begin_operator
down f31 f20
1
873 0
1
0 0 24 12
1
end_operator
begin_operator
down f31 f21
1
932 0
1
0 0 24 13
1
end_operator
begin_operator
down f31 f22
1
990 0
1
0 0 24 14
1
end_operator
begin_operator
down f31 f23
1
1047 0
1
0 0 24 15
1
end_operator
begin_operator
down f31 f24
1
1103 0
1
0 0 24 16
1
end_operator
begin_operator
down f31 f25
1
1158 0
1
0 0 24 17
1
end_operator
begin_operator
down f31 f26
1
1212 0
1
0 0 24 18
1
end_operator
begin_operator
down f31 f27
1
1265 0
1
0 0 24 19
1
end_operator
begin_operator
down f31 f28
1
1317 0
1
0 0 24 20
1
end_operator
begin_operator
down f31 f29
1
1368 0
1
0 0 24 21
1
end_operator
begin_operator
down f31 f3
1
1439 0
1
0 0 24 22
1
end_operator
begin_operator
down f31 f30
1
1495 0
1
0 0 24 23
1
end_operator
begin_operator
down f31 f4
1
1971 0
1
0 0 24 33
1
end_operator
begin_operator
down f31 f5
1
2402 0
1
0 0 24 44
1
end_operator
begin_operator
down f31 f6
1
2732 0
1
0 0 24 55
1
end_operator
begin_operator
down f31 f7
1
2961 0
1
0 0 24 66
1
end_operator
begin_operator
down f31 f8
1
3089 0
1
0 0 24 77
1
end_operator
begin_operator
down f31 f9
1
3161 0
1
0 0 24 79
1
end_operator
begin_operator
down f32 f1
1
75 0
1
0 0 25 0
1
end_operator
begin_operator
down f32 f10
1
151 0
1
0 0 25 1
1
end_operator
begin_operator
down f32 f11
1
220 0
1
0 0 25 2
1
end_operator
begin_operator
down f32 f12
1
288 0
1
0 0 25 3
1
end_operator
begin_operator
down f32 f13
1
355 0
1
0 0 25 4
1
end_operator
begin_operator
down f32 f14
1
421 0
1
0 0 25 5
1
end_operator
begin_operator
down f32 f15
1
486 0
1
0 0 25 6
1
end_operator
begin_operator
down f32 f16
1
550 0
1
0 0 25 7
1
end_operator
begin_operator
down f32 f17
1
613 0
1
0 0 25 8
1
end_operator
begin_operator
down f32 f18
1
675 0
1
0 0 25 9
1
end_operator
begin_operator
down f32 f19
1
736 0
1
0 0 25 10
1
end_operator
begin_operator
down f32 f2
1
808 0
1
0 0 25 11
1
end_operator
begin_operator
down f32 f20
1
874 0
1
0 0 25 12
1
end_operator
begin_operator
down f32 f21
1
933 0
1
0 0 25 13
1
end_operator
begin_operator
down f32 f22
1
991 0
1
0 0 25 14
1
end_operator
begin_operator
down f32 f23
1
1048 0
1
0 0 25 15
1
end_operator
begin_operator
down f32 f24
1
1104 0
1
0 0 25 16
1
end_operator
begin_operator
down f32 f25
1
1159 0
1
0 0 25 17
1
end_operator
begin_operator
down f32 f26
1
1213 0
1
0 0 25 18
1
end_operator
begin_operator
down f32 f27
1
1266 0
1
0 0 25 19
1
end_operator
begin_operator
down f32 f28
1
1318 0
1
0 0 25 20
1
end_operator
begin_operator
down f32 f29
1
1369 0
1
0 0 25 21
1
end_operator
begin_operator
down f32 f3
1
1440 0
1
0 0 25 22
1
end_operator
begin_operator
down f32 f30
1
1496 0
1
0 0 25 23
1
end_operator
begin_operator
down f32 f31
1
1545 0
1
0 0 25 24
1
end_operator
begin_operator
down f32 f4
1
1972 0
1
0 0 25 33
1
end_operator
begin_operator
down f32 f5
1
2403 0
1
0 0 25 44
1
end_operator
begin_operator
down f32 f6
1
2733 0
1
0 0 25 55
1
end_operator
begin_operator
down f32 f7
1
2962 0
1
0 0 25 66
1
end_operator
begin_operator
down f32 f8
1
3090 0
1
0 0 25 77
1
end_operator
begin_operator
down f32 f9
1
3162 0
1
0 0 25 79
1
end_operator
begin_operator
down f33 f1
1
76 0
1
0 0 26 0
1
end_operator
begin_operator
down f33 f10
1
152 0
1
0 0 26 1
1
end_operator
begin_operator
down f33 f11
1
221 0
1
0 0 26 2
1
end_operator
begin_operator
down f33 f12
1
289 0
1
0 0 26 3
1
end_operator
begin_operator
down f33 f13
1
356 0
1
0 0 26 4
1
end_operator
begin_operator
down f33 f14
1
422 0
1
0 0 26 5
1
end_operator
begin_operator
down f33 f15
1
487 0
1
0 0 26 6
1
end_operator
begin_operator
down f33 f16
1
551 0
1
0 0 26 7
1
end_operator
begin_operator
down f33 f17
1
614 0
1
0 0 26 8
1
end_operator
begin_operator
down f33 f18
1
676 0
1
0 0 26 9
1
end_operator
begin_operator
down f33 f19
1
737 0
1
0 0 26 10
1
end_operator
begin_operator
down f33 f2
1
809 0
1
0 0 26 11
1
end_operator
begin_operator
down f33 f20
1
875 0
1
0 0 26 12
1
end_operator
begin_operator
down f33 f21
1
934 0
1
0 0 26 13
1
end_operator
begin_operator
down f33 f22
1
992 0
1
0 0 26 14
1
end_operator
begin_operator
down f33 f23
1
1049 0
1
0 0 26 15
1
end_operator
begin_operator
down f33 f24
1
1105 0
1
0 0 26 16
1
end_operator
begin_operator
down f33 f25
1
1160 0
1
0 0 26 17
1
end_operator
begin_operator
down f33 f26
1
1214 0
1
0 0 26 18
1
end_operator
begin_operator
down f33 f27
1
1267 0
1
0 0 26 19
1
end_operator
begin_operator
down f33 f28
1
1319 0
1
0 0 26 20
1
end_operator
begin_operator
down f33 f29
1
1370 0
1
0 0 26 21
1
end_operator
begin_operator
down f33 f3
1
1441 0
1
0 0 26 22
1
end_operator
begin_operator
down f33 f30
1
1497 0
1
0 0 26 23
1
end_operator
begin_operator
down f33 f31
1
1546 0
1
0 0 26 24
1
end_operator
begin_operator
down f33 f32
1
1594 0
1
0 0 26 25
1
end_operator
begin_operator
down f33 f4
1
1973 0
1
0 0 26 33
1
end_operator
begin_operator
down f33 f5
1
2404 0
1
0 0 26 44
1
end_operator
begin_operator
down f33 f6
1
2734 0
1
0 0 26 55
1
end_operator
begin_operator
down f33 f7
1
2963 0
1
0 0 26 66
1
end_operator
begin_operator
down f33 f8
1
3091 0
1
0 0 26 77
1
end_operator
begin_operator
down f33 f9
1
3163 0
1
0 0 26 79
1
end_operator
begin_operator
down f34 f1
1
77 0
1
0 0 27 0
1
end_operator
begin_operator
down f34 f10
1
153 0
1
0 0 27 1
1
end_operator
begin_operator
down f34 f11
1
222 0
1
0 0 27 2
1
end_operator
begin_operator
down f34 f12
1
290 0
1
0 0 27 3
1
end_operator
begin_operator
down f34 f13
1
357 0
1
0 0 27 4
1
end_operator
begin_operator
down f34 f14
1
423 0
1
0 0 27 5
1
end_operator
begin_operator
down f34 f15
1
488 0
1
0 0 27 6
1
end_operator
begin_operator
down f34 f16
1
552 0
1
0 0 27 7
1
end_operator
begin_operator
down f34 f17
1
615 0
1
0 0 27 8
1
end_operator
begin_operator
down f34 f18
1
677 0
1
0 0 27 9
1
end_operator
begin_operator
down f34 f19
1
738 0
1
0 0 27 10
1
end_operator
begin_operator
down f34 f2
1
810 0
1
0 0 27 11
1
end_operator
begin_operator
down f34 f20
1
876 0
1
0 0 27 12
1
end_operator
begin_operator
down f34 f21
1
935 0
1
0 0 27 13
1
end_operator
begin_operator
down f34 f22
1
993 0
1
0 0 27 14
1
end_operator
begin_operator
down f34 f23
1
1050 0
1
0 0 27 15
1
end_operator
begin_operator
down f34 f24
1
1106 0
1
0 0 27 16
1
end_operator
begin_operator
down f34 f25
1
1161 0
1
0 0 27 17
1
end_operator
begin_operator
down f34 f26
1
1215 0
1
0 0 27 18
1
end_operator
begin_operator
down f34 f27
1
1268 0
1
0 0 27 19
1
end_operator
begin_operator
down f34 f28
1
1320 0
1
0 0 27 20
1
end_operator
begin_operator
down f34 f29
1
1371 0
1
0 0 27 21
1
end_operator
begin_operator
down f34 f3
1
1442 0
1
0 0 27 22
1
end_operator
begin_operator
down f34 f30
1
1498 0
1
0 0 27 23
1
end_operator
begin_operator
down f34 f31
1
1547 0
1
0 0 27 24
1
end_operator
begin_operator
down f34 f32
1
1595 0
1
0 0 27 25
1
end_operator
begin_operator
down f34 f33
1
1642 0
1
0 0 27 26
1
end_operator
begin_operator
down f34 f4
1
1974 0
1
0 0 27 33
1
end_operator
begin_operator
down f34 f5
1
2405 0
1
0 0 27 44
1
end_operator
begin_operator
down f34 f6
1
2735 0
1
0 0 27 55
1
end_operator
begin_operator
down f34 f7
1
2964 0
1
0 0 27 66
1
end_operator
begin_operator
down f34 f8
1
3092 0
1
0 0 27 77
1
end_operator
begin_operator
down f34 f9
1
3164 0
1
0 0 27 79
1
end_operator
begin_operator
down f35 f1
1
78 0
1
0 0 28 0
1
end_operator
begin_operator
down f35 f10
1
154 0
1
0 0 28 1
1
end_operator
begin_operator
down f35 f11
1
223 0
1
0 0 28 2
1
end_operator
begin_operator
down f35 f12
1
291 0
1
0 0 28 3
1
end_operator
begin_operator
down f35 f13
1
358 0
1
0 0 28 4
1
end_operator
begin_operator
down f35 f14
1
424 0
1
0 0 28 5
1
end_operator
begin_operator
down f35 f15
1
489 0
1
0 0 28 6
1
end_operator
begin_operator
down f35 f16
1
553 0
1
0 0 28 7
1
end_operator
begin_operator
down f35 f17
1
616 0
1
0 0 28 8
1
end_operator
begin_operator
down f35 f18
1
678 0
1
0 0 28 9
1
end_operator
begin_operator
down f35 f19
1
739 0
1
0 0 28 10
1
end_operator
begin_operator
down f35 f2
1
811 0
1
0 0 28 11
1
end_operator
begin_operator
down f35 f20
1
877 0
1
0 0 28 12
1
end_operator
begin_operator
down f35 f21
1
936 0
1
0 0 28 13
1
end_operator
begin_operator
down f35 f22
1
994 0
1
0 0 28 14
1
end_operator
begin_operator
down f35 f23
1
1051 0
1
0 0 28 15
1
end_operator
begin_operator
down f35 f24
1
1107 0
1
0 0 28 16
1
end_operator
begin_operator
down f35 f25
1
1162 0
1
0 0 28 17
1
end_operator
begin_operator
down f35 f26
1
1216 0
1
0 0 28 18
1
end_operator
begin_operator
down f35 f27
1
1269 0
1
0 0 28 19
1
end_operator
begin_operator
down f35 f28
1
1321 0
1
0 0 28 20
1
end_operator
begin_operator
down f35 f29
1
1372 0
1
0 0 28 21
1
end_operator
begin_operator
down f35 f3
1
1443 0
1
0 0 28 22
1
end_operator
begin_operator
down f35 f30
1
1499 0
1
0 0 28 23
1
end_operator
begin_operator
down f35 f31
1
1548 0
1
0 0 28 24
1
end_operator
begin_operator
down f35 f32
1
1596 0
1
0 0 28 25
1
end_operator
begin_operator
down f35 f33
1
1643 0
1
0 0 28 26
1
end_operator
begin_operator
down f35 f34
1
1689 0
1
0 0 28 27
1
end_operator
begin_operator
down f35 f4
1
1975 0
1
0 0 28 33
1
end_operator
begin_operator
down f35 f5
1
2406 0
1
0 0 28 44
1
end_operator
begin_operator
down f35 f6
1
2736 0
1
0 0 28 55
1
end_operator
begin_operator
down f35 f7
1
2965 0
1
0 0 28 66
1
end_operator
begin_operator
down f35 f8
1
3093 0
1
0 0 28 77
1
end_operator
begin_operator
down f35 f9
1
3165 0
1
0 0 28 79
1
end_operator
begin_operator
down f36 f1
1
79 0
1
0 0 29 0
1
end_operator
begin_operator
down f36 f10
1
155 0
1
0 0 29 1
1
end_operator
begin_operator
down f36 f11
1
224 0
1
0 0 29 2
1
end_operator
begin_operator
down f36 f12
1
292 0
1
0 0 29 3
1
end_operator
begin_operator
down f36 f13
1
359 0
1
0 0 29 4
1
end_operator
begin_operator
down f36 f14
1
425 0
1
0 0 29 5
1
end_operator
begin_operator
down f36 f15
1
490 0
1
0 0 29 6
1
end_operator
begin_operator
down f36 f16
1
554 0
1
0 0 29 7
1
end_operator
begin_operator
down f36 f17
1
617 0
1
0 0 29 8
1
end_operator
begin_operator
down f36 f18
1
679 0
1
0 0 29 9
1
end_operator
begin_operator
down f36 f19
1
740 0
1
0 0 29 10
1
end_operator
begin_operator
down f36 f2
1
812 0
1
0 0 29 11
1
end_operator
begin_operator
down f36 f20
1
878 0
1
0 0 29 12
1
end_operator
begin_operator
down f36 f21
1
937 0
1
0 0 29 13
1
end_operator
begin_operator
down f36 f22
1
995 0
1
0 0 29 14
1
end_operator
begin_operator
down f36 f23
1
1052 0
1
0 0 29 15
1
end_operator
begin_operator
down f36 f24
1
1108 0
1
0 0 29 16
1
end_operator
begin_operator
down f36 f25
1
1163 0
1
0 0 29 17
1
end_operator
begin_operator
down f36 f26
1
1217 0
1
0 0 29 18
1
end_operator
begin_operator
down f36 f27
1
1270 0
1
0 0 29 19
1
end_operator
begin_operator
down f36 f28
1
1322 0
1
0 0 29 20
1
end_operator
begin_operator
down f36 f29
1
1373 0
1
0 0 29 21
1
end_operator
begin_operator
down f36 f3
1
1444 0
1
0 0 29 22
1
end_operator
begin_operator
down f36 f30
1
1500 0
1
0 0 29 23
1
end_operator
begin_operator
down f36 f31
1
1549 0
1
0 0 29 24
1
end_operator
begin_operator
down f36 f32
1
1597 0
1
0 0 29 25
1
end_operator
begin_operator
down f36 f33
1
1644 0
1
0 0 29 26
1
end_operator
begin_operator
down f36 f34
1
1690 0
1
0 0 29 27
1
end_operator
begin_operator
down f36 f35
1
1735 0
1
0 0 29 28
1
end_operator
begin_operator
down f36 f4
1
1976 0
1
0 0 29 33
1
end_operator
begin_operator
down f36 f5
1
2407 0
1
0 0 29 44
1
end_operator
begin_operator
down f36 f6
1
2737 0
1
0 0 29 55
1
end_operator
begin_operator
down f36 f7
1
2966 0
1
0 0 29 66
1
end_operator
begin_operator
down f36 f8
1
3094 0
1
0 0 29 77
1
end_operator
begin_operator
down f36 f9
1
3166 0
1
0 0 29 79
1
end_operator
begin_operator
down f37 f1
1
80 0
1
0 0 30 0
1
end_operator
begin_operator
down f37 f10
1
156 0
1
0 0 30 1
1
end_operator
begin_operator
down f37 f11
1
225 0
1
0 0 30 2
1
end_operator
begin_operator
down f37 f12
1
293 0
1
0 0 30 3
1
end_operator
begin_operator
down f37 f13
1
360 0
1
0 0 30 4
1
end_operator
begin_operator
down f37 f14
1
426 0
1
0 0 30 5
1
end_operator
begin_operator
down f37 f15
1
491 0
1
0 0 30 6
1
end_operator
begin_operator
down f37 f16
1
555 0
1
0 0 30 7
1
end_operator
begin_operator
down f37 f17
1
618 0
1
0 0 30 8
1
end_operator
begin_operator
down f37 f18
1
680 0
1
0 0 30 9
1
end_operator
begin_operator
down f37 f19
1
741 0
1
0 0 30 10
1
end_operator
begin_operator
down f37 f2
1
813 0
1
0 0 30 11
1
end_operator
begin_operator
down f37 f20
1
879 0
1
0 0 30 12
1
end_operator
begin_operator
down f37 f21
1
938 0
1
0 0 30 13
1
end_operator
begin_operator
down f37 f22
1
996 0
1
0 0 30 14
1
end_operator
begin_operator
down f37 f23
1
1053 0
1
0 0 30 15
1
end_operator
begin_operator
down f37 f24
1
1109 0
1
0 0 30 16
1
end_operator
begin_operator
down f37 f25
1
1164 0
1
0 0 30 17
1
end_operator
begin_operator
down f37 f26
1
1218 0
1
0 0 30 18
1
end_operator
begin_operator
down f37 f27
1
1271 0
1
0 0 30 19
1
end_operator
begin_operator
down f37 f28
1
1323 0
1
0 0 30 20
1
end_operator
begin_operator
down f37 f29
1
1374 0
1
0 0 30 21
1
end_operator
begin_operator
down f37 f3
1
1445 0
1
0 0 30 22
1
end_operator
begin_operator
down f37 f30
1
1501 0
1
0 0 30 23
1
end_operator
begin_operator
down f37 f31
1
1550 0
1
0 0 30 24
1
end_operator
begin_operator
down f37 f32
1
1598 0
1
0 0 30 25
1
end_operator
begin_operator
down f37 f33
1
1645 0
1
0 0 30 26
1
end_operator
begin_operator
down f37 f34
1
1691 0
1
0 0 30 27
1
end_operator
begin_operator
down f37 f35
1
1736 0
1
0 0 30 28
1
end_operator
begin_operator
down f37 f36
1
1780 0
1
0 0 30 29
1
end_operator
begin_operator
down f37 f4
1
1977 0
1
0 0 30 33
1
end_operator
begin_operator
down f37 f5
1
2408 0
1
0 0 30 44
1
end_operator
begin_operator
down f37 f6
1
2738 0
1
0 0 30 55
1
end_operator
begin_operator
down f37 f7
1
2967 0
1
0 0 30 66
1
end_operator
begin_operator
down f37 f8
1
3095 0
1
0 0 30 77
1
end_operator
begin_operator
down f37 f9
1
3167 0
1
0 0 30 79
1
end_operator
begin_operator
down f38 f1
1
81 0
1
0 0 31 0
1
end_operator
begin_operator
down f38 f10
1
157 0
1
0 0 31 1
1
end_operator
begin_operator
down f38 f11
1
226 0
1
0 0 31 2
1
end_operator
begin_operator
down f38 f12
1
294 0
1
0 0 31 3
1
end_operator
begin_operator
down f38 f13
1
361 0
1
0 0 31 4
1
end_operator
begin_operator
down f38 f14
1
427 0
1
0 0 31 5
1
end_operator
begin_operator
down f38 f15
1
492 0
1
0 0 31 6
1
end_operator
begin_operator
down f38 f16
1
556 0
1
0 0 31 7
1
end_operator
begin_operator
down f38 f17
1
619 0
1
0 0 31 8
1
end_operator
begin_operator
down f38 f18
1
681 0
1
0 0 31 9
1
end_operator
begin_operator
down f38 f19
1
742 0
1
0 0 31 10
1
end_operator
begin_operator
down f38 f2
1
814 0
1
0 0 31 11
1
end_operator
begin_operator
down f38 f20
1
880 0
1
0 0 31 12
1
end_operator
begin_operator
down f38 f21
1
939 0
1
0 0 31 13
1
end_operator
begin_operator
down f38 f22
1
997 0
1
0 0 31 14
1
end_operator
begin_operator
down f38 f23
1
1054 0
1
0 0 31 15
1
end_operator
begin_operator
down f38 f24
1
1110 0
1
0 0 31 16
1
end_operator
begin_operator
down f38 f25
1
1165 0
1
0 0 31 17
1
end_operator
begin_operator
down f38 f26
1
1219 0
1
0 0 31 18
1
end_operator
begin_operator
down f38 f27
1
1272 0
1
0 0 31 19
1
end_operator
begin_operator
down f38 f28
1
1324 0
1
0 0 31 20
1
end_operator
begin_operator
down f38 f29
1
1375 0
1
0 0 31 21
1
end_operator
begin_operator
down f38 f3
1
1446 0
1
0 0 31 22
1
end_operator
begin_operator
down f38 f30
1
1502 0
1
0 0 31 23
1
end_operator
begin_operator
down f38 f31
1
1551 0
1
0 0 31 24
1
end_operator
begin_operator
down f38 f32
1
1599 0
1
0 0 31 25
1
end_operator
begin_operator
down f38 f33
1
1646 0
1
0 0 31 26
1
end_operator
begin_operator
down f38 f34
1
1692 0
1
0 0 31 27
1
end_operator
begin_operator
down f38 f35
1
1737 0
1
0 0 31 28
1
end_operator
begin_operator
down f38 f36
1
1781 0
1
0 0 31 29
1
end_operator
begin_operator
down f38 f37
1
1824 0
1
0 0 31 30
1
end_operator
begin_operator
down f38 f4
1
1978 0
1
0 0 31 33
1
end_operator
begin_operator
down f38 f5
1
2409 0
1
0 0 31 44
1
end_operator
begin_operator
down f38 f6
1
2739 0
1
0 0 31 55
1
end_operator
begin_operator
down f38 f7
1
2968 0
1
0 0 31 66
1
end_operator
begin_operator
down f38 f8
1
3096 0
1
0 0 31 77
1
end_operator
begin_operator
down f38 f9
1
3168 0
1
0 0 31 79
1
end_operator
begin_operator
down f39 f1
1
82 0
1
0 0 32 0
1
end_operator
begin_operator
down f39 f10
1
158 0
1
0 0 32 1
1
end_operator
begin_operator
down f39 f11
1
227 0
1
0 0 32 2
1
end_operator
begin_operator
down f39 f12
1
295 0
1
0 0 32 3
1
end_operator
begin_operator
down f39 f13
1
362 0
1
0 0 32 4
1
end_operator
begin_operator
down f39 f14
1
428 0
1
0 0 32 5
1
end_operator
begin_operator
down f39 f15
1
493 0
1
0 0 32 6
1
end_operator
begin_operator
down f39 f16
1
557 0
1
0 0 32 7
1
end_operator
begin_operator
down f39 f17
1
620 0
1
0 0 32 8
1
end_operator
begin_operator
down f39 f18
1
682 0
1
0 0 32 9
1
end_operator
begin_operator
down f39 f19
1
743 0
1
0 0 32 10
1
end_operator
begin_operator
down f39 f2
1
815 0
1
0 0 32 11
1
end_operator
begin_operator
down f39 f20
1
881 0
1
0 0 32 12
1
end_operator
begin_operator
down f39 f21
1
940 0
1
0 0 32 13
1
end_operator
begin_operator
down f39 f22
1
998 0
1
0 0 32 14
1
end_operator
begin_operator
down f39 f23
1
1055 0
1
0 0 32 15
1
end_operator
begin_operator
down f39 f24
1
1111 0
1
0 0 32 16
1
end_operator
begin_operator
down f39 f25
1
1166 0
1
0 0 32 17
1
end_operator
begin_operator
down f39 f26
1
1220 0
1
0 0 32 18
1
end_operator
begin_operator
down f39 f27
1
1273 0
1
0 0 32 19
1
end_operator
begin_operator
down f39 f28
1
1325 0
1
0 0 32 20
1
end_operator
begin_operator
down f39 f29
1
1376 0
1
0 0 32 21
1
end_operator
begin_operator
down f39 f3
1
1447 0
1
0 0 32 22
1
end_operator
begin_operator
down f39 f30
1
1503 0
1
0 0 32 23
1
end_operator
begin_operator
down f39 f31
1
1552 0
1
0 0 32 24
1
end_operator
begin_operator
down f39 f32
1
1600 0
1
0 0 32 25
1
end_operator
begin_operator
down f39 f33
1
1647 0
1
0 0 32 26
1
end_operator
begin_operator
down f39 f34
1
1693 0
1
0 0 32 27
1
end_operator
begin_operator
down f39 f35
1
1738 0
1
0 0 32 28
1
end_operator
begin_operator
down f39 f36
1
1782 0
1
0 0 32 29
1
end_operator
begin_operator
down f39 f37
1
1825 0
1
0 0 32 30
1
end_operator
begin_operator
down f39 f38
1
1867 0
1
0 0 32 31
1
end_operator
begin_operator
down f39 f4
1
1979 0
1
0 0 32 33
1
end_operator
begin_operator
down f39 f5
1
2410 0
1
0 0 32 44
1
end_operator
begin_operator
down f39 f6
1
2740 0
1
0 0 32 55
1
end_operator
begin_operator
down f39 f7
1
2969 0
1
0 0 32 66
1
end_operator
begin_operator
down f39 f8
1
3097 0
1
0 0 32 77
1
end_operator
begin_operator
down f39 f9
1
3169 0
1
0 0 32 79
1
end_operator
begin_operator
down f4 f1
1
83 0
1
0 0 33 0
1
end_operator
begin_operator
down f4 f2
1
816 0
1
0 0 33 11
1
end_operator
begin_operator
down f4 f3
1
1448 0
1
0 0 33 22
1
end_operator
begin_operator
down f40 f1
1
84 0
1
0 0 34 0
1
end_operator
begin_operator
down f40 f10
1
159 0
1
0 0 34 1
1
end_operator
begin_operator
down f40 f11
1
228 0
1
0 0 34 2
1
end_operator
begin_operator
down f40 f12
1
296 0
1
0 0 34 3
1
end_operator
begin_operator
down f40 f13
1
363 0
1
0 0 34 4
1
end_operator
begin_operator
down f40 f14
1
429 0
1
0 0 34 5
1
end_operator
begin_operator
down f40 f15
1
494 0
1
0 0 34 6
1
end_operator
begin_operator
down f40 f16
1
558 0
1
0 0 34 7
1
end_operator
begin_operator
down f40 f17
1
621 0
1
0 0 34 8
1
end_operator
begin_operator
down f40 f18
1
683 0
1
0 0 34 9
1
end_operator
begin_operator
down f40 f19
1
744 0
1
0 0 34 10
1
end_operator
begin_operator
down f40 f2
1
817 0
1
0 0 34 11
1
end_operator
begin_operator
down f40 f20
1
882 0
1
0 0 34 12
1
end_operator
begin_operator
down f40 f21
1
941 0
1
0 0 34 13
1
end_operator
begin_operator
down f40 f22
1
999 0
1
0 0 34 14
1
end_operator
begin_operator
down f40 f23
1
1056 0
1
0 0 34 15
1
end_operator
begin_operator
down f40 f24
1
1112 0
1
0 0 34 16
1
end_operator
begin_operator
down f40 f25
1
1167 0
1
0 0 34 17
1
end_operator
begin_operator
down f40 f26
1
1221 0
1
0 0 34 18
1
end_operator
begin_operator
down f40 f27
1
1274 0
1
0 0 34 19
1
end_operator
begin_operator
down f40 f28
1
1326 0
1
0 0 34 20
1
end_operator
begin_operator
down f40 f29
1
1377 0
1
0 0 34 21
1
end_operator
begin_operator
down f40 f3
1
1449 0
1
0 0 34 22
1
end_operator
begin_operator
down f40 f30
1
1504 0
1
0 0 34 23
1
end_operator
begin_operator
down f40 f31
1
1553 0
1
0 0 34 24
1
end_operator
begin_operator
down f40 f32
1
1601 0
1
0 0 34 25
1
end_operator
begin_operator
down f40 f33
1
1648 0
1
0 0 34 26
1
end_operator
begin_operator
down f40 f34
1
1694 0
1
0 0 34 27
1
end_operator
begin_operator
down f40 f35
1
1739 0
1
0 0 34 28
1
end_operator
begin_operator
down f40 f36
1
1783 0
1
0 0 34 29
1
end_operator
begin_operator
down f40 f37
1
1826 0
1
0 0 34 30
1
end_operator
begin_operator
down f40 f38
1
1868 0
1
0 0 34 31
1
end_operator
begin_operator
down f40 f39
1
1909 0
1
0 0 34 32
1
end_operator
begin_operator
down f40 f4
1
1980 0
1
0 0 34 33
1
end_operator
begin_operator
down f40 f5
1
2411 0
1
0 0 34 44
1
end_operator
begin_operator
down f40 f6
1
2741 0
1
0 0 34 55
1
end_operator
begin_operator
down f40 f7
1
2970 0
1
0 0 34 66
1
end_operator
begin_operator
down f40 f8
1
3098 0
1
0 0 34 77
1
end_operator
begin_operator
down f40 f9
1
3170 0
1
0 0 34 79
1
end_operator
begin_operator
down f41 f1
1
85 0
1
0 0 35 0
1
end_operator
begin_operator
down f41 f10
1
160 0
1
0 0 35 1
1
end_operator
begin_operator
down f41 f11
1
229 0
1
0 0 35 2
1
end_operator
begin_operator
down f41 f12
1
297 0
1
0 0 35 3
1
end_operator
begin_operator
down f41 f13
1
364 0
1
0 0 35 4
1
end_operator
begin_operator
down f41 f14
1
430 0
1
0 0 35 5
1
end_operator
begin_operator
down f41 f15
1
495 0
1
0 0 35 6
1
end_operator
begin_operator
down f41 f16
1
559 0
1
0 0 35 7
1
end_operator
begin_operator
down f41 f17
1
622 0
1
0 0 35 8
1
end_operator
begin_operator
down f41 f18
1
684 0
1
0 0 35 9
1
end_operator
begin_operator
down f41 f19
1
745 0
1
0 0 35 10
1
end_operator
begin_operator
down f41 f2
1
818 0
1
0 0 35 11
1
end_operator
begin_operator
down f41 f20
1
883 0
1
0 0 35 12
1
end_operator
begin_operator
down f41 f21
1
942 0
1
0 0 35 13
1
end_operator
begin_operator
down f41 f22
1
1000 0
1
0 0 35 14
1
end_operator
begin_operator
down f41 f23
1
1057 0
1
0 0 35 15
1
end_operator
begin_operator
down f41 f24
1
1113 0
1
0 0 35 16
1
end_operator
begin_operator
down f41 f25
1
1168 0
1
0 0 35 17
1
end_operator
begin_operator
down f41 f26
1
1222 0
1
0 0 35 18
1
end_operator
begin_operator
down f41 f27
1
1275 0
1
0 0 35 19
1
end_operator
begin_operator
down f41 f28
1
1327 0
1
0 0 35 20
1
end_operator
begin_operator
down f41 f29
1
1378 0
1
0 0 35 21
1
end_operator
begin_operator
down f41 f3
1
1450 0
1
0 0 35 22
1
end_operator
begin_operator
down f41 f30
1
1505 0
1
0 0 35 23
1
end_operator
begin_operator
down f41 f31
1
1554 0
1
0 0 35 24
1
end_operator
begin_operator
down f41 f32
1
1602 0
1
0 0 35 25
1
end_operator
begin_operator
down f41 f33
1
1649 0
1
0 0 35 26
1
end_operator
begin_operator
down f41 f34
1
1695 0
1
0 0 35 27
1
end_operator
begin_operator
down f41 f35
1
1740 0
1
0 0 35 28
1
end_operator
begin_operator
down f41 f36
1
1784 0
1
0 0 35 29
1
end_operator
begin_operator
down f41 f37
1
1827 0
1
0 0 35 30
1
end_operator
begin_operator
down f41 f38
1
1869 0
1
0 0 35 31
1
end_operator
begin_operator
down f41 f39
1
1910 0
1
0 0 35 32
1
end_operator
begin_operator
down f41 f4
1
1981 0
1
0 0 35 33
1
end_operator
begin_operator
down f41 f40
1
2026 0
1
0 0 35 34
1
end_operator
begin_operator
down f41 f5
1
2412 0
1
0 0 35 44
1
end_operator
begin_operator
down f41 f6
1
2742 0
1
0 0 35 55
1
end_operator
begin_operator
down f41 f7
1
2971 0
1
0 0 35 66
1
end_operator
begin_operator
down f41 f8
1
3099 0
1
0 0 35 77
1
end_operator
begin_operator
down f41 f9
1
3171 0
1
0 0 35 79
1
end_operator
begin_operator
down f42 f1
1
86 0
1
0 0 36 0
1
end_operator
begin_operator
down f42 f10
1
161 0
1
0 0 36 1
1
end_operator
begin_operator
down f42 f11
1
230 0
1
0 0 36 2
1
end_operator
begin_operator
down f42 f12
1
298 0
1
0 0 36 3
1
end_operator
begin_operator
down f42 f13
1
365 0
1
0 0 36 4
1
end_operator
begin_operator
down f42 f14
1
431 0
1
0 0 36 5
1
end_operator
begin_operator
down f42 f15
1
496 0
1
0 0 36 6
1
end_operator
begin_operator
down f42 f16
1
560 0
1
0 0 36 7
1
end_operator
begin_operator
down f42 f17
1
623 0
1
0 0 36 8
1
end_operator
begin_operator
down f42 f18
1
685 0
1
0 0 36 9
1
end_operator
begin_operator
down f42 f19
1
746 0
1
0 0 36 10
1
end_operator
begin_operator
down f42 f2
1
819 0
1
0 0 36 11
1
end_operator
begin_operator
down f42 f20
1
884 0
1
0 0 36 12
1
end_operator
begin_operator
down f42 f21
1
943 0
1
0 0 36 13
1
end_operator
begin_operator
down f42 f22
1
1001 0
1
0 0 36 14
1
end_operator
begin_operator
down f42 f23
1
1058 0
1
0 0 36 15
1
end_operator
begin_operator
down f42 f24
1
1114 0
1
0 0 36 16
1
end_operator
begin_operator
down f42 f25
1
1169 0
1
0 0 36 17
1
end_operator
begin_operator
down f42 f26
1
1223 0
1
0 0 36 18
1
end_operator
begin_operator
down f42 f27
1
1276 0
1
0 0 36 19
1
end_operator
begin_operator
down f42 f28
1
1328 0
1
0 0 36 20
1
end_operator
begin_operator
down f42 f29
1
1379 0
1
0 0 36 21
1
end_operator
begin_operator
down f42 f3
1
1451 0
1
0 0 36 22
1
end_operator
begin_operator
down f42 f30
1
1506 0
1
0 0 36 23
1
end_operator
begin_operator
down f42 f31
1
1555 0
1
0 0 36 24
1
end_operator
begin_operator
down f42 f32
1
1603 0
1
0 0 36 25
1
end_operator
begin_operator
down f42 f33
1
1650 0
1
0 0 36 26
1
end_operator
begin_operator
down f42 f34
1
1696 0
1
0 0 36 27
1
end_operator
begin_operator
down f42 f35
1
1741 0
1
0 0 36 28
1
end_operator
begin_operator
down f42 f36
1
1785 0
1
0 0 36 29
1
end_operator
begin_operator
down f42 f37
1
1828 0
1
0 0 36 30
1
end_operator
begin_operator
down f42 f38
1
1870 0
1
0 0 36 31
1
end_operator
begin_operator
down f42 f39
1
1911 0
1
0 0 36 32
1
end_operator
begin_operator
down f42 f4
1
1982 0
1
0 0 36 33
1
end_operator
begin_operator
down f42 f40
1
2027 0
1
0 0 36 34
1
end_operator
begin_operator
down f42 f41
1
2066 0
1
0 0 36 35
1
end_operator
begin_operator
down f42 f5
1
2413 0
1
0 0 36 44
1
end_operator
begin_operator
down f42 f6
1
2743 0
1
0 0 36 55
1
end_operator
begin_operator
down f42 f7
1
2972 0
1
0 0 36 66
1
end_operator
begin_operator
down f42 f8
1
3100 0
1
0 0 36 77
1
end_operator
begin_operator
down f42 f9
1
3172 0
1
0 0 36 79
1
end_operator
begin_operator
down f43 f1
1
87 0
1
0 0 37 0
1
end_operator
begin_operator
down f43 f10
1
162 0
1
0 0 37 1
1
end_operator
begin_operator
down f43 f11
1
231 0
1
0 0 37 2
1
end_operator
begin_operator
down f43 f12
1
299 0
1
0 0 37 3
1
end_operator
begin_operator
down f43 f13
1
366 0
1
0 0 37 4
1
end_operator
begin_operator
down f43 f14
1
432 0
1
0 0 37 5
1
end_operator
begin_operator
down f43 f15
1
497 0
1
0 0 37 6
1
end_operator
begin_operator
down f43 f16
1
561 0
1
0 0 37 7
1
end_operator
begin_operator
down f43 f17
1
624 0
1
0 0 37 8
1
end_operator
begin_operator
down f43 f18
1
686 0
1
0 0 37 9
1
end_operator
begin_operator
down f43 f19
1
747 0
1
0 0 37 10
1
end_operator
begin_operator
down f43 f2
1
820 0
1
0 0 37 11
1
end_operator
begin_operator
down f43 f20
1
885 0
1
0 0 37 12
1
end_operator
begin_operator
down f43 f21
1
944 0
1
0 0 37 13
1
end_operator
begin_operator
down f43 f22
1
1002 0
1
0 0 37 14
1
end_operator
begin_operator
down f43 f23
1
1059 0
1
0 0 37 15
1
end_operator
begin_operator
down f43 f24
1
1115 0
1
0 0 37 16
1
end_operator
begin_operator
down f43 f25
1
1170 0
1
0 0 37 17
1
end_operator
begin_operator
down f43 f26
1
1224 0
1
0 0 37 18
1
end_operator
begin_operator
down f43 f27
1
1277 0
1
0 0 37 19
1
end_operator
begin_operator
down f43 f28
1
1329 0
1
0 0 37 20
1
end_operator
begin_operator
down f43 f29
1
1380 0
1
0 0 37 21
1
end_operator
begin_operator
down f43 f3
1
1452 0
1
0 0 37 22
1
end_operator
begin_operator
down f43 f30
1
1507 0
1
0 0 37 23
1
end_operator
begin_operator
down f43 f31
1
1556 0
1
0 0 37 24
1
end_operator
begin_operator
down f43 f32
1
1604 0
1
0 0 37 25
1
end_operator
begin_operator
down f43 f33
1
1651 0
1
0 0 37 26
1
end_operator
begin_operator
down f43 f34
1
1697 0
1
0 0 37 27
1
end_operator
begin_operator
down f43 f35
1
1742 0
1
0 0 37 28
1
end_operator
begin_operator
down f43 f36
1
1786 0
1
0 0 37 29
1
end_operator
begin_operator
down f43 f37
1
1829 0
1
0 0 37 30
1
end_operator
begin_operator
down f43 f38
1
1871 0
1
0 0 37 31
1
end_operator
begin_operator
down f43 f39
1
1912 0
1
0 0 37 32
1
end_operator
begin_operator
down f43 f4
1
1983 0
1
0 0 37 33
1
end_operator
begin_operator
down f43 f40
1
2028 0
1
0 0 37 34
1
end_operator
begin_operator
down f43 f41
1
2067 0
1
0 0 37 35
1
end_operator
begin_operator
down f43 f42
1
2105 0
1
0 0 37 36
1
end_operator
begin_operator
down f43 f5
1
2414 0
1
0 0 37 44
1
end_operator
begin_operator
down f43 f6
1
2744 0
1
0 0 37 55
1
end_operator
begin_operator
down f43 f7
1
2973 0
1
0 0 37 66
1
end_operator
begin_operator
down f43 f8
1
3101 0
1
0 0 37 77
1
end_operator
begin_operator
down f43 f9
1
3173 0
1
0 0 37 79
1
end_operator
begin_operator
down f44 f1
1
88 0
1
0 0 38 0
1
end_operator
begin_operator
down f44 f10
1
163 0
1
0 0 38 1
1
end_operator
begin_operator
down f44 f11
1
232 0
1
0 0 38 2
1
end_operator
begin_operator
down f44 f12
1
300 0
1
0 0 38 3
1
end_operator
begin_operator
down f44 f13
1
367 0
1
0 0 38 4
1
end_operator
begin_operator
down f44 f14
1
433 0
1
0 0 38 5
1
end_operator
begin_operator
down f44 f15
1
498 0
1
0 0 38 6
1
end_operator
begin_operator
down f44 f16
1
562 0
1
0 0 38 7
1
end_operator
begin_operator
down f44 f17
1
625 0
1
0 0 38 8
1
end_operator
begin_operator
down f44 f18
1
687 0
1
0 0 38 9
1
end_operator
begin_operator
down f44 f19
1
748 0
1
0 0 38 10
1
end_operator
begin_operator
down f44 f2
1
821 0
1
0 0 38 11
1
end_operator
begin_operator
down f44 f20
1
886 0
1
0 0 38 12
1
end_operator
begin_operator
down f44 f21
1
945 0
1
0 0 38 13
1
end_operator
begin_operator
down f44 f22
1
1003 0
1
0 0 38 14
1
end_operator
begin_operator
down f44 f23
1
1060 0
1
0 0 38 15
1
end_operator
begin_operator
down f44 f24
1
1116 0
1
0 0 38 16
1
end_operator
begin_operator
down f44 f25
1
1171 0
1
0 0 38 17
1
end_operator
begin_operator
down f44 f26
1
1225 0
1
0 0 38 18
1
end_operator
begin_operator
down f44 f27
1
1278 0
1
0 0 38 19
1
end_operator
begin_operator
down f44 f28
1
1330 0
1
0 0 38 20
1
end_operator
begin_operator
down f44 f29
1
1381 0
1
0 0 38 21
1
end_operator
begin_operator
down f44 f3
1
1453 0
1
0 0 38 22
1
end_operator
begin_operator
down f44 f30
1
1508 0
1
0 0 38 23
1
end_operator
begin_operator
down f44 f31
1
1557 0
1
0 0 38 24
1
end_operator
begin_operator
down f44 f32
1
1605 0
1
0 0 38 25
1
end_operator
begin_operator
down f44 f33
1
1652 0
1
0 0 38 26
1
end_operator
begin_operator
down f44 f34
1
1698 0
1
0 0 38 27
1
end_operator
begin_operator
down f44 f35
1
1743 0
1
0 0 38 28
1
end_operator
begin_operator
down f44 f36
1
1787 0
1
0 0 38 29
1
end_operator
begin_operator
down f44 f37
1
1830 0
1
0 0 38 30
1
end_operator
begin_operator
down f44 f38
1
1872 0
1
0 0 38 31
1
end_operator
begin_operator
down f44 f39
1
1913 0
1
0 0 38 32
1
end_operator
begin_operator
down f44 f4
1
1984 0
1
0 0 38 33
1
end_operator
begin_operator
down f44 f40
1
2029 0
1
0 0 38 34
1
end_operator
begin_operator
down f44 f41
1
2068 0
1
0 0 38 35
1
end_operator
begin_operator
down f44 f42
1
2106 0
1
0 0 38 36
1
end_operator
begin_operator
down f44 f43
1
2143 0
1
0 0 38 37
1
end_operator
begin_operator
down f44 f5
1
2415 0
1
0 0 38 44
1
end_operator
begin_operator
down f44 f6
1
2745 0
1
0 0 38 55
1
end_operator
begin_operator
down f44 f7
1
2974 0
1
0 0 38 66
1
end_operator
begin_operator
down f44 f8
1
3102 0
1
0 0 38 77
1
end_operator
begin_operator
down f44 f9
1
3174 0
1
0 0 38 79
1
end_operator
begin_operator
down f45 f1
1
89 0
1
0 0 39 0
1
end_operator
begin_operator
down f45 f10
1
164 0
1
0 0 39 1
1
end_operator
begin_operator
down f45 f11
1
233 0
1
0 0 39 2
1
end_operator
begin_operator
down f45 f12
1
301 0
1
0 0 39 3
1
end_operator
begin_operator
down f45 f13
1
368 0
1
0 0 39 4
1
end_operator
begin_operator
down f45 f14
1
434 0
1
0 0 39 5
1
end_operator
begin_operator
down f45 f15
1
499 0
1
0 0 39 6
1
end_operator
begin_operator
down f45 f16
1
563 0
1
0 0 39 7
1
end_operator
begin_operator
down f45 f17
1
626 0
1
0 0 39 8
1
end_operator
begin_operator
down f45 f18
1
688 0
1
0 0 39 9
1
end_operator
begin_operator
down f45 f19
1
749 0
1
0 0 39 10
1
end_operator
begin_operator
down f45 f2
1
822 0
1
0 0 39 11
1
end_operator
begin_operator
down f45 f20
1
887 0
1
0 0 39 12
1
end_operator
begin_operator
down f45 f21
1
946 0
1
0 0 39 13
1
end_operator
begin_operator
down f45 f22
1
1004 0
1
0 0 39 14
1
end_operator
begin_operator
down f45 f23
1
1061 0
1
0 0 39 15
1
end_operator
begin_operator
down f45 f24
1
1117 0
1
0 0 39 16
1
end_operator
begin_operator
down f45 f25
1
1172 0
1
0 0 39 17
1
end_operator
begin_operator
down f45 f26
1
1226 0
1
0 0 39 18
1
end_operator
begin_operator
down f45 f27
1
1279 0
1
0 0 39 19
1
end_operator
begin_operator
down f45 f28
1
1331 0
1
0 0 39 20
1
end_operator
begin_operator
down f45 f29
1
1382 0
1
0 0 39 21
1
end_operator
begin_operator
down f45 f3
1
1454 0
1
0 0 39 22
1
end_operator
begin_operator
down f45 f30
1
1509 0
1
0 0 39 23
1
end_operator
begin_operator
down f45 f31
1
1558 0
1
0 0 39 24
1
end_operator
begin_operator
down f45 f32
1
1606 0
1
0 0 39 25
1
end_operator
begin_operator
down f45 f33
1
1653 0
1
0 0 39 26
1
end_operator
begin_operator
down f45 f34
1
1699 0
1
0 0 39 27
1
end_operator
begin_operator
down f45 f35
1
1744 0
1
0 0 39 28
1
end_operator
begin_operator
down f45 f36
1
1788 0
1
0 0 39 29
1
end_operator
begin_operator
down f45 f37
1
1831 0
1
0 0 39 30
1
end_operator
begin_operator
down f45 f38
1
1873 0
1
0 0 39 31
1
end_operator
begin_operator
down f45 f39
1
1914 0
1
0 0 39 32
1
end_operator
begin_operator
down f45 f4
1
1985 0
1
0 0 39 33
1
end_operator
begin_operator
down f45 f40
1
2030 0
1
0 0 39 34
1
end_operator
begin_operator
down f45 f41
1
2069 0
1
0 0 39 35
1
end_operator
begin_operator
down f45 f42
1
2107 0
1
0 0 39 36
1
end_operator
begin_operator
down f45 f43
1
2144 0
1
0 0 39 37
1
end_operator
begin_operator
down f45 f44
1
2180 0
1
0 0 39 38
1
end_operator
begin_operator
down f45 f5
1
2416 0
1
0 0 39 44
1
end_operator
begin_operator
down f45 f6
1
2746 0
1
0 0 39 55
1
end_operator
begin_operator
down f45 f7
1
2975 0
1
0 0 39 66
1
end_operator
begin_operator
down f45 f8
1
3103 0
1
0 0 39 77
1
end_operator
begin_operator
down f45 f9
1
3175 0
1
0 0 39 79
1
end_operator
begin_operator
down f46 f1
1
90 0
1
0 0 40 0
1
end_operator
begin_operator
down f46 f10
1
165 0
1
0 0 40 1
1
end_operator
begin_operator
down f46 f11
1
234 0
1
0 0 40 2
1
end_operator
begin_operator
down f46 f12
1
302 0
1
0 0 40 3
1
end_operator
begin_operator
down f46 f13
1
369 0
1
0 0 40 4
1
end_operator
begin_operator
down f46 f14
1
435 0
1
0 0 40 5
1
end_operator
begin_operator
down f46 f15
1
500 0
1
0 0 40 6
1
end_operator
begin_operator
down f46 f16
1
564 0
1
0 0 40 7
1
end_operator
begin_operator
down f46 f17
1
627 0
1
0 0 40 8
1
end_operator
begin_operator
down f46 f18
1
689 0
1
0 0 40 9
1
end_operator
begin_operator
down f46 f19
1
750 0
1
0 0 40 10
1
end_operator
begin_operator
down f46 f2
1
823 0
1
0 0 40 11
1
end_operator
begin_operator
down f46 f20
1
888 0
1
0 0 40 12
1
end_operator
begin_operator
down f46 f21
1
947 0
1
0 0 40 13
1
end_operator
begin_operator
down f46 f22
1
1005 0
1
0 0 40 14
1
end_operator
begin_operator
down f46 f23
1
1062 0
1
0 0 40 15
1
end_operator
begin_operator
down f46 f24
1
1118 0
1
0 0 40 16
1
end_operator
begin_operator
down f46 f25
1
1173 0
1
0 0 40 17
1
end_operator
begin_operator
down f46 f26
1
1227 0
1
0 0 40 18
1
end_operator
begin_operator
down f46 f27
1
1280 0
1
0 0 40 19
1
end_operator
begin_operator
down f46 f28
1
1332 0
1
0 0 40 20
1
end_operator
begin_operator
down f46 f29
1
1383 0
1
0 0 40 21
1
end_operator
begin_operator
down f46 f3
1
1455 0
1
0 0 40 22
1
end_operator
begin_operator
down f46 f30
1
1510 0
1
0 0 40 23
1
end_operator
begin_operator
down f46 f31
1
1559 0
1
0 0 40 24
1
end_operator
begin_operator
down f46 f32
1
1607 0
1
0 0 40 25
1
end_operator
begin_operator
down f46 f33
1
1654 0
1
0 0 40 26
1
end_operator
begin_operator
down f46 f34
1
1700 0
1
0 0 40 27
1
end_operator
begin_operator
down f46 f35
1
1745 0
1
0 0 40 28
1
end_operator
begin_operator
down f46 f36
1
1789 0
1
0 0 40 29
1
end_operator
begin_operator
down f46 f37
1
1832 0
1
0 0 40 30
1
end_operator
begin_operator
down f46 f38
1
1874 0
1
0 0 40 31
1
end_operator
begin_operator
down f46 f39
1
1915 0
1
0 0 40 32
1
end_operator
begin_operator
down f46 f4
1
1986 0
1
0 0 40 33
1
end_operator
begin_operator
down f46 f40
1
2031 0
1
0 0 40 34
1
end_operator
begin_operator
down f46 f41
1
2070 0
1
0 0 40 35
1
end_operator
begin_operator
down f46 f42
1
2108 0
1
0 0 40 36
1
end_operator
begin_operator
down f46 f43
1
2145 0
1
0 0 40 37
1
end_operator
begin_operator
down f46 f44
1
2181 0
1
0 0 40 38
1
end_operator
begin_operator
down f46 f45
1
2216 0
1
0 0 40 39
1
end_operator
begin_operator
down f46 f5
1
2417 0
1
0 0 40 44
1
end_operator
begin_operator
down f46 f6
1
2747 0
1
0 0 40 55
1
end_operator
begin_operator
down f46 f7
1
2976 0
1
0 0 40 66
1
end_operator
begin_operator
down f46 f8
1
3104 0
1
0 0 40 77
1
end_operator
begin_operator
down f46 f9
1
3176 0
1
0 0 40 79
1
end_operator
begin_operator
down f47 f1
1
91 0
1
0 0 41 0
1
end_operator
begin_operator
down f47 f10
1
166 0
1
0 0 41 1
1
end_operator
begin_operator
down f47 f11
1
235 0
1
0 0 41 2
1
end_operator
begin_operator
down f47 f12
1
303 0
1
0 0 41 3
1
end_operator
begin_operator
down f47 f13
1
370 0
1
0 0 41 4
1
end_operator
begin_operator
down f47 f14
1
436 0
1
0 0 41 5
1
end_operator
begin_operator
down f47 f15
1
501 0
1
0 0 41 6
1
end_operator
begin_operator
down f47 f16
1
565 0
1
0 0 41 7
1
end_operator
begin_operator
down f47 f17
1
628 0
1
0 0 41 8
1
end_operator
begin_operator
down f47 f18
1
690 0
1
0 0 41 9
1
end_operator
begin_operator
down f47 f19
1
751 0
1
0 0 41 10
1
end_operator
begin_operator
down f47 f2
1
824 0
1
0 0 41 11
1
end_operator
begin_operator
down f47 f20
1
889 0
1
0 0 41 12
1
end_operator
begin_operator
down f47 f21
1
948 0
1
0 0 41 13
1
end_operator
begin_operator
down f47 f22
1
1006 0
1
0 0 41 14
1
end_operator
begin_operator
down f47 f23
1
1063 0
1
0 0 41 15
1
end_operator
begin_operator
down f47 f24
1
1119 0
1
0 0 41 16
1
end_operator
begin_operator
down f47 f25
1
1174 0
1
0 0 41 17
1
end_operator
begin_operator
down f47 f26
1
1228 0
1
0 0 41 18
1
end_operator
begin_operator
down f47 f27
1
1281 0
1
0 0 41 19
1
end_operator
begin_operator
down f47 f28
1
1333 0
1
0 0 41 20
1
end_operator
begin_operator
down f47 f29
1
1384 0
1
0 0 41 21
1
end_operator
begin_operator
down f47 f3
1
1456 0
1
0 0 41 22
1
end_operator
begin_operator
down f47 f30
1
1511 0
1
0 0 41 23
1
end_operator
begin_operator
down f47 f31
1
1560 0
1
0 0 41 24
1
end_operator
begin_operator
down f47 f32
1
1608 0
1
0 0 41 25
1
end_operator
begin_operator
down f47 f33
1
1655 0
1
0 0 41 26
1
end_operator
begin_operator
down f47 f34
1
1701 0
1
0 0 41 27
1
end_operator
begin_operator
down f47 f35
1
1746 0
1
0 0 41 28
1
end_operator
begin_operator
down f47 f36
1
1790 0
1
0 0 41 29
1
end_operator
begin_operator
down f47 f37
1
1833 0
1
0 0 41 30
1
end_operator
begin_operator
down f47 f38
1
1875 0
1
0 0 41 31
1
end_operator
begin_operator
down f47 f39
1
1916 0
1
0 0 41 32
1
end_operator
begin_operator
down f47 f4
1
1987 0
1
0 0 41 33
1
end_operator
begin_operator
down f47 f40
1
2032 0
1
0 0 41 34
1
end_operator
begin_operator
down f47 f41
1
2071 0
1
0 0 41 35
1
end_operator
begin_operator
down f47 f42
1
2109 0
1
0 0 41 36
1
end_operator
begin_operator
down f47 f43
1
2146 0
1
0 0 41 37
1
end_operator
begin_operator
down f47 f44
1
2182 0
1
0 0 41 38
1
end_operator
begin_operator
down f47 f45
1
2217 0
1
0 0 41 39
1
end_operator
begin_operator
down f47 f46
1
2251 0
1
0 0 41 40
1
end_operator
begin_operator
down f47 f5
1
2418 0
1
0 0 41 44
1
end_operator
begin_operator
down f47 f6
1
2748 0
1
0 0 41 55
1
end_operator
begin_operator
down f47 f7
1
2977 0
1
0 0 41 66
1
end_operator
begin_operator
down f47 f8
1
3105 0
1
0 0 41 77
1
end_operator
begin_operator
down f47 f9
1
3177 0
1
0 0 41 79
1
end_operator
begin_operator
down f48 f1
1
92 0
1
0 0 42 0
1
end_operator
begin_operator
down f48 f10
1
167 0
1
0 0 42 1
1
end_operator
begin_operator
down f48 f11
1
236 0
1
0 0 42 2
1
end_operator
begin_operator
down f48 f12
1
304 0
1
0 0 42 3
1
end_operator
begin_operator
down f48 f13
1
371 0
1
0 0 42 4
1
end_operator
begin_operator
down f48 f14
1
437 0
1
0 0 42 5
1
end_operator
begin_operator
down f48 f15
1
502 0
1
0 0 42 6
1
end_operator
begin_operator
down f48 f16
1
566 0
1
0 0 42 7
1
end_operator
begin_operator
down f48 f17
1
629 0
1
0 0 42 8
1
end_operator
begin_operator
down f48 f18
1
691 0
1
0 0 42 9
1
end_operator
begin_operator
down f48 f19
1
752 0
1
0 0 42 10
1
end_operator
begin_operator
down f48 f2
1
825 0
1
0 0 42 11
1
end_operator
begin_operator
down f48 f20
1
890 0
1
0 0 42 12
1
end_operator
begin_operator
down f48 f21
1
949 0
1
0 0 42 13
1
end_operator
begin_operator
down f48 f22
1
1007 0
1
0 0 42 14
1
end_operator
begin_operator
down f48 f23
1
1064 0
1
0 0 42 15
1
end_operator
begin_operator
down f48 f24
1
1120 0
1
0 0 42 16
1
end_operator
begin_operator
down f48 f25
1
1175 0
1
0 0 42 17
1
end_operator
begin_operator
down f48 f26
1
1229 0
1
0 0 42 18
1
end_operator
begin_operator
down f48 f27
1
1282 0
1
0 0 42 19
1
end_operator
begin_operator
down f48 f28
1
1334 0
1
0 0 42 20
1
end_operator
begin_operator
down f48 f29
1
1385 0
1
0 0 42 21
1
end_operator
begin_operator
down f48 f3
1
1457 0
1
0 0 42 22
1
end_operator
begin_operator
down f48 f30
1
1512 0
1
0 0 42 23
1
end_operator
begin_operator
down f48 f31
1
1561 0
1
0 0 42 24
1
end_operator
begin_operator
down f48 f32
1
1609 0
1
0 0 42 25
1
end_operator
begin_operator
down f48 f33
1
1656 0
1
0 0 42 26
1
end_operator
begin_operator
down f48 f34
1
1702 0
1
0 0 42 27
1
end_operator
begin_operator
down f48 f35
1
1747 0
1
0 0 42 28
1
end_operator
begin_operator
down f48 f36
1
1791 0
1
0 0 42 29
1
end_operator
begin_operator
down f48 f37
1
1834 0
1
0 0 42 30
1
end_operator
begin_operator
down f48 f38
1
1876 0
1
0 0 42 31
1
end_operator
begin_operator
down f48 f39
1
1917 0
1
0 0 42 32
1
end_operator
begin_operator
down f48 f4
1
1988 0
1
0 0 42 33
1
end_operator
begin_operator
down f48 f40
1
2033 0
1
0 0 42 34
1
end_operator
begin_operator
down f48 f41
1
2072 0
1
0 0 42 35
1
end_operator
begin_operator
down f48 f42
1
2110 0
1
0 0 42 36
1
end_operator
begin_operator
down f48 f43
1
2147 0
1
0 0 42 37
1
end_operator
begin_operator
down f48 f44
1
2183 0
1
0 0 42 38
1
end_operator
begin_operator
down f48 f45
1
2218 0
1
0 0 42 39
1
end_operator
begin_operator
down f48 f46
1
2252 0
1
0 0 42 40
1
end_operator
begin_operator
down f48 f47
1
2285 0
1
0 0 42 41
1
end_operator
begin_operator
down f48 f5
1
2419 0
1
0 0 42 44
1
end_operator
begin_operator
down f48 f6
1
2749 0
1
0 0 42 55
1
end_operator
begin_operator
down f48 f7
1
2978 0
1
0 0 42 66
1
end_operator
begin_operator
down f48 f8
1
3106 0
1
0 0 42 77
1
end_operator
begin_operator
down f48 f9
1
3178 0
1
0 0 42 79
1
end_operator
begin_operator
down f49 f1
1
93 0
1
0 0 43 0
1
end_operator
begin_operator
down f49 f10
1
168 0
1
0 0 43 1
1
end_operator
begin_operator
down f49 f11
1
237 0
1
0 0 43 2
1
end_operator
begin_operator
down f49 f12
1
305 0
1
0 0 43 3
1
end_operator
begin_operator
down f49 f13
1
372 0
1
0 0 43 4
1
end_operator
begin_operator
down f49 f14
1
438 0
1
0 0 43 5
1
end_operator
begin_operator
down f49 f15
1
503 0
1
0 0 43 6
1
end_operator
begin_operator
down f49 f16
1
567 0
1
0 0 43 7
1
end_operator
begin_operator
down f49 f17
1
630 0
1
0 0 43 8
1
end_operator
begin_operator
down f49 f18
1
692 0
1
0 0 43 9
1
end_operator
begin_operator
down f49 f19
1
753 0
1
0 0 43 10
1
end_operator
begin_operator
down f49 f2
1
826 0
1
0 0 43 11
1
end_operator
begin_operator
down f49 f20
1
891 0
1
0 0 43 12
1
end_operator
begin_operator
down f49 f21
1
950 0
1
0 0 43 13
1
end_operator
begin_operator
down f49 f22
1
1008 0
1
0 0 43 14
1
end_operator
begin_operator
down f49 f23
1
1065 0
1
0 0 43 15
1
end_operator
begin_operator
down f49 f24
1
1121 0
1
0 0 43 16
1
end_operator
begin_operator
down f49 f25
1
1176 0
1
0 0 43 17
1
end_operator
begin_operator
down f49 f26
1
1230 0
1
0 0 43 18
1
end_operator
begin_operator
down f49 f27
1
1283 0
1
0 0 43 19
1
end_operator
begin_operator
down f49 f28
1
1335 0
1
0 0 43 20
1
end_operator
begin_operator
down f49 f29
1
1386 0
1
0 0 43 21
1
end_operator
begin_operator
down f49 f3
1
1458 0
1
0 0 43 22
1
end_operator
begin_operator
down f49 f30
1
1513 0
1
0 0 43 23
1
end_operator
begin_operator
down f49 f31
1
1562 0
1
0 0 43 24
1
end_operator
begin_operator
down f49 f32
1
1610 0
1
0 0 43 25
1
end_operator
begin_operator
down f49 f33
1
1657 0
1
0 0 43 26
1
end_operator
begin_operator
down f49 f34
1
1703 0
1
0 0 43 27
1
end_operator
begin_operator
down f49 f35
1
1748 0
1
0 0 43 28
1
end_operator
begin_operator
down f49 f36
1
1792 0
1
0 0 43 29
1
end_operator
begin_operator
down f49 f37
1
1835 0
1
0 0 43 30
1
end_operator
begin_operator
down f49 f38
1
1877 0
1
0 0 43 31
1
end_operator
begin_operator
down f49 f39
1
1918 0
1
0 0 43 32
1
end_operator
begin_operator
down f49 f4
1
1989 0
1
0 0 43 33
1
end_operator
begin_operator
down f49 f40
1
2034 0
1
0 0 43 34
1
end_operator
begin_operator
down f49 f41
1
2073 0
1
0 0 43 35
1
end_operator
begin_operator
down f49 f42
1
2111 0
1
0 0 43 36
1
end_operator
begin_operator
down f49 f43
1
2148 0
1
0 0 43 37
1
end_operator
begin_operator
down f49 f44
1
2184 0
1
0 0 43 38
1
end_operator
begin_operator
down f49 f45
1
2219 0
1
0 0 43 39
1
end_operator
begin_operator
down f49 f46
1
2253 0
1
0 0 43 40
1
end_operator
begin_operator
down f49 f47
1
2286 0
1
0 0 43 41
1
end_operator
begin_operator
down f49 f48
1
2318 0
1
0 0 43 42
1
end_operator
begin_operator
down f49 f5
1
2420 0
1
0 0 43 44
1
end_operator
begin_operator
down f49 f6
1
2750 0
1
0 0 43 55
1
end_operator
begin_operator
down f49 f7
1
2979 0
1
0 0 43 66
1
end_operator
begin_operator
down f49 f8
1
3107 0
1
0 0 43 77
1
end_operator
begin_operator
down f49 f9
1
3179 0
1
0 0 43 79
1
end_operator
begin_operator
down f5 f1
1
94 0
1
0 0 44 0
1
end_operator
begin_operator
down f5 f2
1
827 0
1
0 0 44 11
1
end_operator
begin_operator
down f5 f3
1
1459 0
1
0 0 44 22
1
end_operator
begin_operator
down f5 f4
1
1990 0
1
0 0 44 33
1
end_operator
begin_operator
down f50 f1
1
95 0
1
0 0 45 0
1
end_operator
begin_operator
down f50 f10
1
169 0
1
0 0 45 1
1
end_operator
begin_operator
down f50 f11
1
238 0
1
0 0 45 2
1
end_operator
begin_operator
down f50 f12
1
306 0
1
0 0 45 3
1
end_operator
begin_operator
down f50 f13
1
373 0
1
0 0 45 4
1
end_operator
begin_operator
down f50 f14
1
439 0
1
0 0 45 5
1
end_operator
begin_operator
down f50 f15
1
504 0
1
0 0 45 6
1
end_operator
begin_operator
down f50 f16
1
568 0
1
0 0 45 7
1
end_operator
begin_operator
down f50 f17
1
631 0
1
0 0 45 8
1
end_operator
begin_operator
down f50 f18
1
693 0
1
0 0 45 9
1
end_operator
begin_operator
down f50 f19
1
754 0
1
0 0 45 10
1
end_operator
begin_operator
down f50 f2
1
828 0
1
0 0 45 11
1
end_operator
begin_operator
down f50 f20
1
892 0
1
0 0 45 12
1
end_operator
begin_operator
down f50 f21
1
951 0
1
0 0 45 13
1
end_operator
begin_operator
down f50 f22
1
1009 0
1
0 0 45 14
1
end_operator
begin_operator
down f50 f23
1
1066 0
1
0 0 45 15
1
end_operator
begin_operator
down f50 f24
1
1122 0
1
0 0 45 16
1
end_operator
begin_operator
down f50 f25
1
1177 0
1
0 0 45 17
1
end_operator
begin_operator
down f50 f26
1
1231 0
1
0 0 45 18
1
end_operator
begin_operator
down f50 f27
1
1284 0
1
0 0 45 19
1
end_operator
begin_operator
down f50 f28
1
1336 0
1
0 0 45 20
1
end_operator
begin_operator
down f50 f29
1
1387 0
1
0 0 45 21
1
end_operator
begin_operator
down f50 f3
1
1460 0
1
0 0 45 22
1
end_operator
begin_operator
down f50 f30
1
1514 0
1
0 0 45 23
1
end_operator
begin_operator
down f50 f31
1
1563 0
1
0 0 45 24
1
end_operator
begin_operator
down f50 f32
1
1611 0
1
0 0 45 25
1
end_operator
begin_operator
down f50 f33
1
1658 0
1
0 0 45 26
1
end_operator
begin_operator
down f50 f34
1
1704 0
1
0 0 45 27
1
end_operator
begin_operator
down f50 f35
1
1749 0
1
0 0 45 28
1
end_operator
begin_operator
down f50 f36
1
1793 0
1
0 0 45 29
1
end_operator
begin_operator
down f50 f37
1
1836 0
1
0 0 45 30
1
end_operator
begin_operator
down f50 f38
1
1878 0
1
0 0 45 31
1
end_operator
begin_operator
down f50 f39
1
1919 0
1
0 0 45 32
1
end_operator
begin_operator
down f50 f4
1
1991 0
1
0 0 45 33
1
end_operator
begin_operator
down f50 f40
1
2035 0
1
0 0 45 34
1
end_operator
begin_operator
down f50 f41
1
2074 0
1
0 0 45 35
1
end_operator
begin_operator
down f50 f42
1
2112 0
1
0 0 45 36
1
end_operator
begin_operator
down f50 f43
1
2149 0
1
0 0 45 37
1
end_operator
begin_operator
down f50 f44
1
2185 0
1
0 0 45 38
1
end_operator
begin_operator
down f50 f45
1
2220 0
1
0 0 45 39
1
end_operator
begin_operator
down f50 f46
1
2254 0
1
0 0 45 40
1
end_operator
begin_operator
down f50 f47
1
2287 0
1
0 0 45 41
1
end_operator
begin_operator
down f50 f48
1
2319 0
1
0 0 45 42
1
end_operator
begin_operator
down f50 f49
1
2350 0
1
0 0 45 43
1
end_operator
begin_operator
down f50 f5
1
2421 0
1
0 0 45 44
1
end_operator
begin_operator
down f50 f6
1
2751 0
1
0 0 45 55
1
end_operator
begin_operator
down f50 f7
1
2980 0
1
0 0 45 66
1
end_operator
begin_operator
down f50 f8
1
3108 0
1
0 0 45 77
1
end_operator
begin_operator
down f50 f9
1
3180 0
1
0 0 45 79
1
end_operator
begin_operator
down f51 f1
1
96 0
1
0 0 46 0
1
end_operator
begin_operator
down f51 f10
1
170 0
1
0 0 46 1
1
end_operator
begin_operator
down f51 f11
1
239 0
1
0 0 46 2
1
end_operator
begin_operator
down f51 f12
1
307 0
1
0 0 46 3
1
end_operator
begin_operator
down f51 f13
1
374 0
1
0 0 46 4
1
end_operator
begin_operator
down f51 f14
1
440 0
1
0 0 46 5
1
end_operator
begin_operator
down f51 f15
1
505 0
1
0 0 46 6
1
end_operator
begin_operator
down f51 f16
1
569 0
1
0 0 46 7
1
end_operator
begin_operator
down f51 f17
1
632 0
1
0 0 46 8
1
end_operator
begin_operator
down f51 f18
1
694 0
1
0 0 46 9
1
end_operator
begin_operator
down f51 f19
1
755 0
1
0 0 46 10
1
end_operator
begin_operator
down f51 f2
1
829 0
1
0 0 46 11
1
end_operator
begin_operator
down f51 f20
1
893 0
1
0 0 46 12
1
end_operator
begin_operator
down f51 f21
1
952 0
1
0 0 46 13
1
end_operator
begin_operator
down f51 f22
1
1010 0
1
0 0 46 14
1
end_operator
begin_operator
down f51 f23
1
1067 0
1
0 0 46 15
1
end_operator
begin_operator
down f51 f24
1
1123 0
1
0 0 46 16
1
end_operator
begin_operator
down f51 f25
1
1178 0
1
0 0 46 17
1
end_operator
begin_operator
down f51 f26
1
1232 0
1
0 0 46 18
1
end_operator
begin_operator
down f51 f27
1
1285 0
1
0 0 46 19
1
end_operator
begin_operator
down f51 f28
1
1337 0
1
0 0 46 20
1
end_operator
begin_operator
down f51 f29
1
1388 0
1
0 0 46 21
1
end_operator
begin_operator
down f51 f3
1
1461 0
1
0 0 46 22
1
end_operator
begin_operator
down f51 f30
1
1515 0
1
0 0 46 23
1
end_operator
begin_operator
down f51 f31
1
1564 0
1
0 0 46 24
1
end_operator
begin_operator
down f51 f32
1
1612 0
1
0 0 46 25
1
end_operator
begin_operator
down f51 f33
1
1659 0
1
0 0 46 26
1
end_operator
begin_operator
down f51 f34
1
1705 0
1
0 0 46 27
1
end_operator
begin_operator
down f51 f35
1
1750 0
1
0 0 46 28
1
end_operator
begin_operator
down f51 f36
1
1794 0
1
0 0 46 29
1
end_operator
begin_operator
down f51 f37
1
1837 0
1
0 0 46 30
1
end_operator
begin_operator
down f51 f38
1
1879 0
1
0 0 46 31
1
end_operator
begin_operator
down f51 f39
1
1920 0
1
0 0 46 32
1
end_operator
begin_operator
down f51 f4
1
1992 0
1
0 0 46 33
1
end_operator
begin_operator
down f51 f40
1
2036 0
1
0 0 46 34
1
end_operator
begin_operator
down f51 f41
1
2075 0
1
0 0 46 35
1
end_operator
begin_operator
down f51 f42
1
2113 0
1
0 0 46 36
1
end_operator
begin_operator
down f51 f43
1
2150 0
1
0 0 46 37
1
end_operator
begin_operator
down f51 f44
1
2186 0
1
0 0 46 38
1
end_operator
begin_operator
down f51 f45
1
2221 0
1
0 0 46 39
1
end_operator
begin_operator
down f51 f46
1
2255 0
1
0 0 46 40
1
end_operator
begin_operator
down f51 f47
1
2288 0
1
0 0 46 41
1
end_operator
begin_operator
down f51 f48
1
2320 0
1
0 0 46 42
1
end_operator
begin_operator
down f51 f49
1
2351 0
1
0 0 46 43
1
end_operator
begin_operator
down f51 f5
1
2422 0
1
0 0 46 44
1
end_operator
begin_operator
down f51 f50
1
2456 0
1
0 0 46 45
1
end_operator
begin_operator
down f51 f6
1
2752 0
1
0 0 46 55
1
end_operator
begin_operator
down f51 f7
1
2981 0
1
0 0 46 66
1
end_operator
begin_operator
down f51 f8
1
3109 0
1
0 0 46 77
1
end_operator
begin_operator
down f51 f9
1
3181 0
1
0 0 46 79
1
end_operator
begin_operator
down f52 f1
1
97 0
1
0 0 47 0
1
end_operator
begin_operator
down f52 f10
1
171 0
1
0 0 47 1
1
end_operator
begin_operator
down f52 f11
1
240 0
1
0 0 47 2
1
end_operator
begin_operator
down f52 f12
1
308 0
1
0 0 47 3
1
end_operator
begin_operator
down f52 f13
1
375 0
1
0 0 47 4
1
end_operator
begin_operator
down f52 f14
1
441 0
1
0 0 47 5
1
end_operator
begin_operator
down f52 f15
1
506 0
1
0 0 47 6
1
end_operator
begin_operator
down f52 f16
1
570 0
1
0 0 47 7
1
end_operator
begin_operator
down f52 f17
1
633 0
1
0 0 47 8
1
end_operator
begin_operator
down f52 f18
1
695 0
1
0 0 47 9
1
end_operator
begin_operator
down f52 f19
1
756 0
1
0 0 47 10
1
end_operator
begin_operator
down f52 f2
1
830 0
1
0 0 47 11
1
end_operator
begin_operator
down f52 f20
1
894 0
1
0 0 47 12
1
end_operator
begin_operator
down f52 f21
1
953 0
1
0 0 47 13
1
end_operator
begin_operator
down f52 f22
1
1011 0
1
0 0 47 14
1
end_operator
begin_operator
down f52 f23
1
1068 0
1
0 0 47 15
1
end_operator
begin_operator
down f52 f24
1
1124 0
1
0 0 47 16
1
end_operator
begin_operator
down f52 f25
1
1179 0
1
0 0 47 17
1
end_operator
begin_operator
down f52 f26
1
1233 0
1
0 0 47 18
1
end_operator
begin_operator
down f52 f27
1
1286 0
1
0 0 47 19
1
end_operator
begin_operator
down f52 f28
1
1338 0
1
0 0 47 20
1
end_operator
begin_operator
down f52 f29
1
1389 0
1
0 0 47 21
1
end_operator
begin_operator
down f52 f3
1
1462 0
1
0 0 47 22
1
end_operator
begin_operator
down f52 f30
1
1516 0
1
0 0 47 23
1
end_operator
begin_operator
down f52 f31
1
1565 0
1
0 0 47 24
1
end_operator
begin_operator
down f52 f32
1
1613 0
1
0 0 47 25
1
end_operator
begin_operator
down f52 f33
1
1660 0
1
0 0 47 26
1
end_operator
begin_operator
down f52 f34
1
1706 0
1
0 0 47 27
1
end_operator
begin_operator
down f52 f35
1
1751 0
1
0 0 47 28
1
end_operator
begin_operator
down f52 f36
1
1795 0
1
0 0 47 29
1
end_operator
begin_operator
down f52 f37
1
1838 0
1
0 0 47 30
1
end_operator
begin_operator
down f52 f38
1
1880 0
1
0 0 47 31
1
end_operator
begin_operator
down f52 f39
1
1921 0
1
0 0 47 32
1
end_operator
begin_operator
down f52 f4
1
1993 0
1
0 0 47 33
1
end_operator
begin_operator
down f52 f40
1
2037 0
1
0 0 47 34
1
end_operator
begin_operator
down f52 f41
1
2076 0
1
0 0 47 35
1
end_operator
begin_operator
down f52 f42
1
2114 0
1
0 0 47 36
1
end_operator
begin_operator
down f52 f43
1
2151 0
1
0 0 47 37
1
end_operator
begin_operator
down f52 f44
1
2187 0
1
0 0 47 38
1
end_operator
begin_operator
down f52 f45
1
2222 0
1
0 0 47 39
1
end_operator
begin_operator
down f52 f46
1
2256 0
1
0 0 47 40
1
end_operator
begin_operator
down f52 f47
1
2289 0
1
0 0 47 41
1
end_operator
begin_operator
down f52 f48
1
2321 0
1
0 0 47 42
1
end_operator
begin_operator
down f52 f49
1
2352 0
1
0 0 47 43
1
end_operator
begin_operator
down f52 f5
1
2423 0
1
0 0 47 44
1
end_operator
begin_operator
down f52 f50
1
2457 0
1
0 0 47 45
1
end_operator
begin_operator
down f52 f51
1
2486 0
1
0 0 47 46
1
end_operator
begin_operator
down f52 f6
1
2753 0
1
0 0 47 55
1
end_operator
begin_operator
down f52 f7
1
2982 0
1
0 0 47 66
1
end_operator
begin_operator
down f52 f8
1
3110 0
1
0 0 47 77
1
end_operator
begin_operator
down f52 f9
1
3182 0
1
0 0 47 79
1
end_operator
begin_operator
down f53 f1
1
98 0
1
0 0 48 0
1
end_operator
begin_operator
down f53 f10
1
172 0
1
0 0 48 1
1
end_operator
begin_operator
down f53 f11
1
241 0
1
0 0 48 2
1
end_operator
begin_operator
down f53 f12
1
309 0
1
0 0 48 3
1
end_operator
begin_operator
down f53 f13
1
376 0
1
0 0 48 4
1
end_operator
begin_operator
down f53 f14
1
442 0
1
0 0 48 5
1
end_operator
begin_operator
down f53 f15
1
507 0
1
0 0 48 6
1
end_operator
begin_operator
down f53 f16
1
571 0
1
0 0 48 7
1
end_operator
begin_operator
down f53 f17
1
634 0
1
0 0 48 8
1
end_operator
begin_operator
down f53 f18
1
696 0
1
0 0 48 9
1
end_operator
begin_operator
down f53 f19
1
757 0
1
0 0 48 10
1
end_operator
begin_operator
down f53 f2
1
831 0
1
0 0 48 11
1
end_operator
begin_operator
down f53 f20
1
895 0
1
0 0 48 12
1
end_operator
begin_operator
down f53 f21
1
954 0
1
0 0 48 13
1
end_operator
begin_operator
down f53 f22
1
1012 0
1
0 0 48 14
1
end_operator
begin_operator
down f53 f23
1
1069 0
1
0 0 48 15
1
end_operator
begin_operator
down f53 f24
1
1125 0
1
0 0 48 16
1
end_operator
begin_operator
down f53 f25
1
1180 0
1
0 0 48 17
1
end_operator
begin_operator
down f53 f26
1
1234 0
1
0 0 48 18
1
end_operator
begin_operator
down f53 f27
1
1287 0
1
0 0 48 19
1
end_operator
begin_operator
down f53 f28
1
1339 0
1
0 0 48 20
1
end_operator
begin_operator
down f53 f29
1
1390 0
1
0 0 48 21
1
end_operator
begin_operator
down f53 f3
1
1463 0
1
0 0 48 22
1
end_operator
begin_operator
down f53 f30
1
1517 0
1
0 0 48 23
1
end_operator
begin_operator
down f53 f31
1
1566 0
1
0 0 48 24
1
end_operator
begin_operator
down f53 f32
1
1614 0
1
0 0 48 25
1
end_operator
begin_operator
down f53 f33
1
1661 0
1
0 0 48 26
1
end_operator
begin_operator
down f53 f34
1
1707 0
1
0 0 48 27
1
end_operator
begin_operator
down f53 f35
1
1752 0
1
0 0 48 28
1
end_operator
begin_operator
down f53 f36
1
1796 0
1
0 0 48 29
1
end_operator
begin_operator
down f53 f37
1
1839 0
1
0 0 48 30
1
end_operator
begin_operator
down f53 f38
1
1881 0
1
0 0 48 31
1
end_operator
begin_operator
down f53 f39
1
1922 0
1
0 0 48 32
1
end_operator
begin_operator
down f53 f4
1
1994 0
1
0 0 48 33
1
end_operator
begin_operator
down f53 f40
1
2038 0
1
0 0 48 34
1
end_operator
begin_operator
down f53 f41
1
2077 0
1
0 0 48 35
1
end_operator
begin_operator
down f53 f42
1
2115 0
1
0 0 48 36
1
end_operator
begin_operator
down f53 f43
1
2152 0
1
0 0 48 37
1
end_operator
begin_operator
down f53 f44
1
2188 0
1
0 0 48 38
1
end_operator
begin_operator
down f53 f45
1
2223 0
1
0 0 48 39
1
end_operator
begin_operator
down f53 f46
1
2257 0
1
0 0 48 40
1
end_operator
begin_operator
down f53 f47
1
2290 0
1
0 0 48 41
1
end_operator
begin_operator
down f53 f48
1
2322 0
1
0 0 48 42
1
end_operator
begin_operator
down f53 f49
1
2353 0
1
0 0 48 43
1
end_operator
begin_operator
down f53 f5
1
2424 0
1
0 0 48 44
1
end_operator
begin_operator
down f53 f50
1
2458 0
1
0 0 48 45
1
end_operator
begin_operator
down f53 f51
1
2487 0
1
0 0 48 46
1
end_operator
begin_operator
down f53 f52
1
2515 0
1
0 0 48 47
1
end_operator
begin_operator
down f53 f6
1
2754 0
1
0 0 48 55
1
end_operator
begin_operator
down f53 f7
1
2983 0
1
0 0 48 66
1
end_operator
begin_operator
down f53 f8
1
3111 0
1
0 0 48 77
1
end_operator
begin_operator
down f53 f9
1
3183 0
1
0 0 48 79
1
end_operator
begin_operator
down f54 f1
1
99 0
1
0 0 49 0
1
end_operator
begin_operator
down f54 f10
1
173 0
1
0 0 49 1
1
end_operator
begin_operator
down f54 f11
1
242 0
1
0 0 49 2
1
end_operator
begin_operator
down f54 f12
1
310 0
1
0 0 49 3
1
end_operator
begin_operator
down f54 f13
1
377 0
1
0 0 49 4
1
end_operator
begin_operator
down f54 f14
1
443 0
1
0 0 49 5
1
end_operator
begin_operator
down f54 f15
1
508 0
1
0 0 49 6
1
end_operator
begin_operator
down f54 f16
1
572 0
1
0 0 49 7
1
end_operator
begin_operator
down f54 f17
1
635 0
1
0 0 49 8
1
end_operator
begin_operator
down f54 f18
1
697 0
1
0 0 49 9
1
end_operator
begin_operator
down f54 f19
1
758 0
1
0 0 49 10
1
end_operator
begin_operator
down f54 f2
1
832 0
1
0 0 49 11
1
end_operator
begin_operator
down f54 f20
1
896 0
1
0 0 49 12
1
end_operator
begin_operator
down f54 f21
1
955 0
1
0 0 49 13
1
end_operator
begin_operator
down f54 f22
1
1013 0
1
0 0 49 14
1
end_operator
begin_operator
down f54 f23
1
1070 0
1
0 0 49 15
1
end_operator
begin_operator
down f54 f24
1
1126 0
1
0 0 49 16
1
end_operator
begin_operator
down f54 f25
1
1181 0
1
0 0 49 17
1
end_operator
begin_operator
down f54 f26
1
1235 0
1
0 0 49 18
1
end_operator
begin_operator
down f54 f27
1
1288 0
1
0 0 49 19
1
end_operator
begin_operator
down f54 f28
1
1340 0
1
0 0 49 20
1
end_operator
begin_operator
down f54 f29
1
1391 0
1
0 0 49 21
1
end_operator
begin_operator
down f54 f3
1
1464 0
1
0 0 49 22
1
end_operator
begin_operator
down f54 f30
1
1518 0
1
0 0 49 23
1
end_operator
begin_operator
down f54 f31
1
1567 0
1
0 0 49 24
1
end_operator
begin_operator
down f54 f32
1
1615 0
1
0 0 49 25
1
end_operator
begin_operator
down f54 f33
1
1662 0
1
0 0 49 26
1
end_operator
begin_operator
down f54 f34
1
1708 0
1
0 0 49 27
1
end_operator
begin_operator
down f54 f35
1
1753 0
1
0 0 49 28
1
end_operator
begin_operator
down f54 f36
1
1797 0
1
0 0 49 29
1
end_operator
begin_operator
down f54 f37
1
1840 0
1
0 0 49 30
1
end_operator
begin_operator
down f54 f38
1
1882 0
1
0 0 49 31
1
end_operator
begin_operator
down f54 f39
1
1923 0
1
0 0 49 32
1
end_operator
begin_operator
down f54 f4
1
1995 0
1
0 0 49 33
1
end_operator
begin_operator
down f54 f40
1
2039 0
1
0 0 49 34
1
end_operator
begin_operator
down f54 f41
1
2078 0
1
0 0 49 35
1
end_operator
begin_operator
down f54 f42
1
2116 0
1
0 0 49 36
1
end_operator
begin_operator
down f54 f43
1
2153 0
1
0 0 49 37
1
end_operator
begin_operator
down f54 f44
1
2189 0
1
0 0 49 38
1
end_operator
begin_operator
down f54 f45
1
2224 0
1
0 0 49 39
1
end_operator
begin_operator
down f54 f46
1
2258 0
1
0 0 49 40
1
end_operator
begin_operator
down f54 f47
1
2291 0
1
0 0 49 41
1
end_operator
begin_operator
down f54 f48
1
2323 0
1
0 0 49 42
1
end_operator
begin_operator
down f54 f49
1
2354 0
1
0 0 49 43
1
end_operator
begin_operator
down f54 f5
1
2425 0
1
0 0 49 44
1
end_operator
begin_operator
down f54 f50
1
2459 0
1
0 0 49 45
1
end_operator
begin_operator
down f54 f51
1
2488 0
1
0 0 49 46
1
end_operator
begin_operator
down f54 f52
1
2516 0
1
0 0 49 47
1
end_operator
begin_operator
down f54 f53
1
2543 0
1
0 0 49 48
1
end_operator
begin_operator
down f54 f6
1
2755 0
1
0 0 49 55
1
end_operator
begin_operator
down f54 f7
1
2984 0
1
0 0 49 66
1
end_operator
begin_operator
down f54 f8
1
3112 0
1
0 0 49 77
1
end_operator
begin_operator
down f54 f9
1
3184 0
1
0 0 49 79
1
end_operator
begin_operator
down f55 f1
1
100 0
1
0 0 50 0
1
end_operator
begin_operator
down f55 f10
1
174 0
1
0 0 50 1
1
end_operator
begin_operator
down f55 f11
1
243 0
1
0 0 50 2
1
end_operator
begin_operator
down f55 f12
1
311 0
1
0 0 50 3
1
end_operator
begin_operator
down f55 f13
1
378 0
1
0 0 50 4
1
end_operator
begin_operator
down f55 f14
1
444 0
1
0 0 50 5
1
end_operator
begin_operator
down f55 f15
1
509 0
1
0 0 50 6
1
end_operator
begin_operator
down f55 f16
1
573 0
1
0 0 50 7
1
end_operator
begin_operator
down f55 f17
1
636 0
1
0 0 50 8
1
end_operator
begin_operator
down f55 f18
1
698 0
1
0 0 50 9
1
end_operator
begin_operator
down f55 f19
1
759 0
1
0 0 50 10
1
end_operator
begin_operator
down f55 f2
1
833 0
1
0 0 50 11
1
end_operator
begin_operator
down f55 f20
1
897 0
1
0 0 50 12
1
end_operator
begin_operator
down f55 f21
1
956 0
1
0 0 50 13
1
end_operator
begin_operator
down f55 f22
1
1014 0
1
0 0 50 14
1
end_operator
begin_operator
down f55 f23
1
1071 0
1
0 0 50 15
1
end_operator
begin_operator
down f55 f24
1
1127 0
1
0 0 50 16
1
end_operator
begin_operator
down f55 f25
1
1182 0
1
0 0 50 17
1
end_operator
begin_operator
down f55 f26
1
1236 0
1
0 0 50 18
1
end_operator
begin_operator
down f55 f27
1
1289 0
1
0 0 50 19
1
end_operator
begin_operator
down f55 f28
1
1341 0
1
0 0 50 20
1
end_operator
begin_operator
down f55 f29
1
1392 0
1
0 0 50 21
1
end_operator
begin_operator
down f55 f3
1
1465 0
1
0 0 50 22
1
end_operator
begin_operator
down f55 f30
1
1519 0
1
0 0 50 23
1
end_operator
begin_operator
down f55 f31
1
1568 0
1
0 0 50 24
1
end_operator
begin_operator
down f55 f32
1
1616 0
1
0 0 50 25
1
end_operator
begin_operator
down f55 f33
1
1663 0
1
0 0 50 26
1
end_operator
begin_operator
down f55 f34
1
1709 0
1
0 0 50 27
1
end_operator
begin_operator
down f55 f35
1
1754 0
1
0 0 50 28
1
end_operator
begin_operator
down f55 f36
1
1798 0
1
0 0 50 29
1
end_operator
begin_operator
down f55 f37
1
1841 0
1
0 0 50 30
1
end_operator
begin_operator
down f55 f38
1
1883 0
1
0 0 50 31
1
end_operator
begin_operator
down f55 f39
1
1924 0
1
0 0 50 32
1
end_operator
begin_operator
down f55 f4
1
1996 0
1
0 0 50 33
1
end_operator
begin_operator
down f55 f40
1
2040 0
1
0 0 50 34
1
end_operator
begin_operator
down f55 f41
1
2079 0
1
0 0 50 35
1
end_operator
begin_operator
down f55 f42
1
2117 0
1
0 0 50 36
1
end_operator
begin_operator
down f55 f43
1
2154 0
1
0 0 50 37
1
end_operator
begin_operator
down f55 f44
1
2190 0
1
0 0 50 38
1
end_operator
begin_operator
down f55 f45
1
2225 0
1
0 0 50 39
1
end_operator
begin_operator
down f55 f46
1
2259 0
1
0 0 50 40
1
end_operator
begin_operator
down f55 f47
1
2292 0
1
0 0 50 41
1
end_operator
begin_operator
down f55 f48
1
2324 0
1
0 0 50 42
1
end_operator
begin_operator
down f55 f49
1
2355 0
1
0 0 50 43
1
end_operator
begin_operator
down f55 f5
1
2426 0
1
0 0 50 44
1
end_operator
begin_operator
down f55 f50
1
2460 0
1
0 0 50 45
1
end_operator
begin_operator
down f55 f51
1
2489 0
1
0 0 50 46
1
end_operator
begin_operator
down f55 f52
1
2517 0
1
0 0 50 47
1
end_operator
begin_operator
down f55 f53
1
2544 0
1
0 0 50 48
1
end_operator
begin_operator
down f55 f54
1
2570 0
1
0 0 50 49
1
end_operator
begin_operator
down f55 f6
1
2756 0
1
0 0 50 55
1
end_operator
begin_operator
down f55 f7
1
2985 0
1
0 0 50 66
1
end_operator
begin_operator
down f55 f8
1
3113 0
1
0 0 50 77
1
end_operator
begin_operator
down f55 f9
1
3185 0
1
0 0 50 79
1
end_operator
begin_operator
down f56 f1
1
101 0
1
0 0 51 0
1
end_operator
begin_operator
down f56 f10
1
175 0
1
0 0 51 1
1
end_operator
begin_operator
down f56 f11
1
244 0
1
0 0 51 2
1
end_operator
begin_operator
down f56 f12
1
312 0
1
0 0 51 3
1
end_operator
begin_operator
down f56 f13
1
379 0
1
0 0 51 4
1
end_operator
begin_operator
down f56 f14
1
445 0
1
0 0 51 5
1
end_operator
begin_operator
down f56 f15
1
510 0
1
0 0 51 6
1
end_operator
begin_operator
down f56 f16
1
574 0
1
0 0 51 7
1
end_operator
begin_operator
down f56 f17
1
637 0
1
0 0 51 8
1
end_operator
begin_operator
down f56 f18
1
699 0
1
0 0 51 9
1
end_operator
begin_operator
down f56 f19
1
760 0
1
0 0 51 10
1
end_operator
begin_operator
down f56 f2
1
834 0
1
0 0 51 11
1
end_operator
begin_operator
down f56 f20
1
898 0
1
0 0 51 12
1
end_operator
begin_operator
down f56 f21
1
957 0
1
0 0 51 13
1
end_operator
begin_operator
down f56 f22
1
1015 0
1
0 0 51 14
1
end_operator
begin_operator
down f56 f23
1
1072 0
1
0 0 51 15
1
end_operator
begin_operator
down f56 f24
1
1128 0
1
0 0 51 16
1
end_operator
begin_operator
down f56 f25
1
1183 0
1
0 0 51 17
1
end_operator
begin_operator
down f56 f26
1
1237 0
1
0 0 51 18
1
end_operator
begin_operator
down f56 f27
1
1290 0
1
0 0 51 19
1
end_operator
begin_operator
down f56 f28
1
1342 0
1
0 0 51 20
1
end_operator
begin_operator
down f56 f29
1
1393 0
1
0 0 51 21
1
end_operator
begin_operator
down f56 f3
1
1466 0
1
0 0 51 22
1
end_operator
begin_operator
down f56 f30
1
1520 0
1
0 0 51 23
1
end_operator
begin_operator
down f56 f31
1
1569 0
1
0 0 51 24
1
end_operator
begin_operator
down f56 f32
1
1617 0
1
0 0 51 25
1
end_operator
begin_operator
down f56 f33
1
1664 0
1
0 0 51 26
1
end_operator
begin_operator
down f56 f34
1
1710 0
1
0 0 51 27
1
end_operator
begin_operator
down f56 f35
1
1755 0
1
0 0 51 28
1
end_operator
begin_operator
down f56 f36
1
1799 0
1
0 0 51 29
1
end_operator
begin_operator
down f56 f37
1
1842 0
1
0 0 51 30
1
end_operator
begin_operator
down f56 f38
1
1884 0
1
0 0 51 31
1
end_operator
begin_operator
down f56 f39
1
1925 0
1
0 0 51 32
1
end_operator
begin_operator
down f56 f4
1
1997 0
1
0 0 51 33
1
end_operator
begin_operator
down f56 f40
1
2041 0
1
0 0 51 34
1
end_operator
begin_operator
down f56 f41
1
2080 0
1
0 0 51 35
1
end_operator
begin_operator
down f56 f42
1
2118 0
1
0 0 51 36
1
end_operator
begin_operator
down f56 f43
1
2155 0
1
0 0 51 37
1
end_operator
begin_operator
down f56 f44
1
2191 0
1
0 0 51 38
1
end_operator
begin_operator
down f56 f45
1
2226 0
1
0 0 51 39
1
end_operator
begin_operator
down f56 f46
1
2260 0
1
0 0 51 40
1
end_operator
begin_operator
down f56 f47
1
2293 0
1
0 0 51 41
1
end_operator
begin_operator
down f56 f48
1
2325 0
1
0 0 51 42
1
end_operator
begin_operator
down f56 f49
1
2356 0
1
0 0 51 43
1
end_operator
begin_operator
down f56 f5
1
2427 0
1
0 0 51 44
1
end_operator
begin_operator
down f56 f50
1
2461 0
1
0 0 51 45
1
end_operator
begin_operator
down f56 f51
1
2490 0
1
0 0 51 46
1
end_operator
begin_operator
down f56 f52
1
2518 0
1
0 0 51 47
1
end_operator
begin_operator
down f56 f53
1
2545 0
1
0 0 51 48
1
end_operator
begin_operator
down f56 f54
1
2571 0
1
0 0 51 49
1
end_operator
begin_operator
down f56 f55
1
2596 0
1
0 0 51 50
1
end_operator
begin_operator
down f56 f6
1
2757 0
1
0 0 51 55
1
end_operator
begin_operator
down f56 f7
1
2986 0
1
0 0 51 66
1
end_operator
begin_operator
down f56 f8
1
3114 0
1
0 0 51 77
1
end_operator
begin_operator
down f56 f9
1
3186 0
1
0 0 51 79
1
end_operator
begin_operator
down f57 f1
1
102 0
1
0 0 52 0
1
end_operator
begin_operator
down f57 f10
1
176 0
1
0 0 52 1
1
end_operator
begin_operator
down f57 f11
1
245 0
1
0 0 52 2
1
end_operator
begin_operator
down f57 f12
1
313 0
1
0 0 52 3
1
end_operator
begin_operator
down f57 f13
1
380 0
1
0 0 52 4
1
end_operator
begin_operator
down f57 f14
1
446 0
1
0 0 52 5
1
end_operator
begin_operator
down f57 f15
1
511 0
1
0 0 52 6
1
end_operator
begin_operator
down f57 f16
1
575 0
1
0 0 52 7
1
end_operator
begin_operator
down f57 f17
1
638 0
1
0 0 52 8
1
end_operator
begin_operator
down f57 f18
1
700 0
1
0 0 52 9
1
end_operator
begin_operator
down f57 f19
1
761 0
1
0 0 52 10
1
end_operator
begin_operator
down f57 f2
1
835 0
1
0 0 52 11
1
end_operator
begin_operator
down f57 f20
1
899 0
1
0 0 52 12
1
end_operator
begin_operator
down f57 f21
1
958 0
1
0 0 52 13
1
end_operator
begin_operator
down f57 f22
1
1016 0
1
0 0 52 14
1
end_operator
begin_operator
down f57 f23
1
1073 0
1
0 0 52 15
1
end_operator
begin_operator
down f57 f24
1
1129 0
1
0 0 52 16
1
end_operator
begin_operator
down f57 f25
1
1184 0
1
0 0 52 17
1
end_operator
begin_operator
down f57 f26
1
1238 0
1
0 0 52 18
1
end_operator
begin_operator
down f57 f27
1
1291 0
1
0 0 52 19
1
end_operator
begin_operator
down f57 f28
1
1343 0
1
0 0 52 20
1
end_operator
begin_operator
down f57 f29
1
1394 0
1
0 0 52 21
1
end_operator
begin_operator
down f57 f3
1
1467 0
1
0 0 52 22
1
end_operator
begin_operator
down f57 f30
1
1521 0
1
0 0 52 23
1
end_operator
begin_operator
down f57 f31
1
1570 0
1
0 0 52 24
1
end_operator
begin_operator
down f57 f32
1
1618 0
1
0 0 52 25
1
end_operator
begin_operator
down f57 f33
1
1665 0
1
0 0 52 26
1
end_operator
begin_operator
down f57 f34
1
1711 0
1
0 0 52 27
1
end_operator
begin_operator
down f57 f35
1
1756 0
1
0 0 52 28
1
end_operator
begin_operator
down f57 f36
1
1800 0
1
0 0 52 29
1
end_operator
begin_operator
down f57 f37
1
1843 0
1
0 0 52 30
1
end_operator
begin_operator
down f57 f38
1
1885 0
1
0 0 52 31
1
end_operator
begin_operator
down f57 f39
1
1926 0
1
0 0 52 32
1
end_operator
begin_operator
down f57 f4
1
1998 0
1
0 0 52 33
1
end_operator
begin_operator
down f57 f40
1
2042 0
1
0 0 52 34
1
end_operator
begin_operator
down f57 f41
1
2081 0
1
0 0 52 35
1
end_operator
begin_operator
down f57 f42
1
2119 0
1
0 0 52 36
1
end_operator
begin_operator
down f57 f43
1
2156 0
1
0 0 52 37
1
end_operator
begin_operator
down f57 f44
1
2192 0
1
0 0 52 38
1
end_operator
begin_operator
down f57 f45
1
2227 0
1
0 0 52 39
1
end_operator
begin_operator
down f57 f46
1
2261 0
1
0 0 52 40
1
end_operator
begin_operator
down f57 f47
1
2294 0
1
0 0 52 41
1
end_operator
begin_operator
down f57 f48
1
2326 0
1
0 0 52 42
1
end_operator
begin_operator
down f57 f49
1
2357 0
1
0 0 52 43
1
end_operator
begin_operator
down f57 f5
1
2428 0
1
0 0 52 44
1
end_operator
begin_operator
down f57 f50
1
2462 0
1
0 0 52 45
1
end_operator
begin_operator
down f57 f51
1
2491 0
1
0 0 52 46
1
end_operator
begin_operator
down f57 f52
1
2519 0
1
0 0 52 47
1
end_operator
begin_operator
down f57 f53
1
2546 0
1
0 0 52 48
1
end_operator
begin_operator
down f57 f54
1
2572 0
1
0 0 52 49
1
end_operator
begin_operator
down f57 f55
1
2597 0
1
0 0 52 50
1
end_operator
begin_operator
down f57 f56
1
2621 0
1
0 0 52 51
1
end_operator
begin_operator
down f57 f6
1
2758 0
1
0 0 52 55
1
end_operator
begin_operator
down f57 f7
1
2987 0
1
0 0 52 66
1
end_operator
begin_operator
down f57 f8
1
3115 0
1
0 0 52 77
1
end_operator
begin_operator
down f57 f9
1
3187 0
1
0 0 52 79
1
end_operator
begin_operator
down f58 f1
1
103 0
1
0 0 53 0
1
end_operator
begin_operator
down f58 f10
1
177 0
1
0 0 53 1
1
end_operator
begin_operator
down f58 f11
1
246 0
1
0 0 53 2
1
end_operator
begin_operator
down f58 f12
1
314 0
1
0 0 53 3
1
end_operator
begin_operator
down f58 f13
1
381 0
1
0 0 53 4
1
end_operator
begin_operator
down f58 f14
1
447 0
1
0 0 53 5
1
end_operator
begin_operator
down f58 f15
1
512 0
1
0 0 53 6
1
end_operator
begin_operator
down f58 f16
1
576 0
1
0 0 53 7
1
end_operator
begin_operator
down f58 f17
1
639 0
1
0 0 53 8
1
end_operator
begin_operator
down f58 f18
1
701 0
1
0 0 53 9
1
end_operator
begin_operator
down f58 f19
1
762 0
1
0 0 53 10
1
end_operator
begin_operator
down f58 f2
1
836 0
1
0 0 53 11
1
end_operator
begin_operator
down f58 f20
1
900 0
1
0 0 53 12
1
end_operator
begin_operator
down f58 f21
1
959 0
1
0 0 53 13
1
end_operator
begin_operator
down f58 f22
1
1017 0
1
0 0 53 14
1
end_operator
begin_operator
down f58 f23
1
1074 0
1
0 0 53 15
1
end_operator
begin_operator
down f58 f24
1
1130 0
1
0 0 53 16
1
end_operator
begin_operator
down f58 f25
1
1185 0
1
0 0 53 17
1
end_operator
begin_operator
down f58 f26
1
1239 0
1
0 0 53 18
1
end_operator
begin_operator
down f58 f27
1
1292 0
1
0 0 53 19
1
end_operator
begin_operator
down f58 f28
1
1344 0
1
0 0 53 20
1
end_operator
begin_operator
down f58 f29
1
1395 0
1
0 0 53 21
1
end_operator
begin_operator
down f58 f3
1
1468 0
1
0 0 53 22
1
end_operator
begin_operator
down f58 f30
1
1522 0
1
0 0 53 23
1
end_operator
begin_operator
down f58 f31
1
1571 0
1
0 0 53 24
1
end_operator
begin_operator
down f58 f32
1
1619 0
1
0 0 53 25
1
end_operator
begin_operator
down f58 f33
1
1666 0
1
0 0 53 26
1
end_operator
begin_operator
down f58 f34
1
1712 0
1
0 0 53 27
1
end_operator
begin_operator
down f58 f35
1
1757 0
1
0 0 53 28
1
end_operator
begin_operator
down f58 f36
1
1801 0
1
0 0 53 29
1
end_operator
begin_operator
down f58 f37
1
1844 0
1
0 0 53 30
1
end_operator
begin_operator
down f58 f38
1
1886 0
1
0 0 53 31
1
end_operator
begin_operator
down f58 f39
1
1927 0
1
0 0 53 32
1
end_operator
begin_operator
down f58 f4
1
1999 0
1
0 0 53 33
1
end_operator
begin_operator
down f58 f40
1
2043 0
1
0 0 53 34
1
end_operator
begin_operator
down f58 f41
1
2082 0
1
0 0 53 35
1
end_operator
begin_operator
down f58 f42
1
2120 0
1
0 0 53 36
1
end_operator
begin_operator
down f58 f43
1
2157 0
1
0 0 53 37
1
end_operator
begin_operator
down f58 f44
1
2193 0
1
0 0 53 38
1
end_operator
begin_operator
down f58 f45
1
2228 0
1
0 0 53 39
1
end_operator
begin_operator
down f58 f46
1
2262 0
1
0 0 53 40
1
end_operator
begin_operator
down f58 f47
1
2295 0
1
0 0 53 41
1
end_operator
begin_operator
down f58 f48
1
2327 0
1
0 0 53 42
1
end_operator
begin_operator
down f58 f49
1
2358 0
1
0 0 53 43
1
end_operator
begin_operator
down f58 f5
1
2429 0
1
0 0 53 44
1
end_operator
begin_operator
down f58 f50
1
2463 0
1
0 0 53 45
1
end_operator
begin_operator
down f58 f51
1
2492 0
1
0 0 53 46
1
end_operator
begin_operator
down f58 f52
1
2520 0
1
0 0 53 47
1
end_operator
begin_operator
down f58 f53
1
2547 0
1
0 0 53 48
1
end_operator
begin_operator
down f58 f54
1
2573 0
1
0 0 53 49
1
end_operator
begin_operator
down f58 f55
1
2598 0
1
0 0 53 50
1
end_operator
begin_operator
down f58 f56
1
2622 0
1
0 0 53 51
1
end_operator
begin_operator
down f58 f57
1
2645 0
1
0 0 53 52
1
end_operator
begin_operator
down f58 f6
1
2759 0
1
0 0 53 55
1
end_operator
begin_operator
down f58 f7
1
2988 0
1
0 0 53 66
1
end_operator
begin_operator
down f58 f8
1
3116 0
1
0 0 53 77
1
end_operator
begin_operator
down f58 f9
1
3188 0
1
0 0 53 79
1
end_operator
begin_operator
down f59 f1
1
104 0
1
0 0 54 0
1
end_operator
begin_operator
down f59 f10
1
178 0
1
0 0 54 1
1
end_operator
begin_operator
down f59 f11
1
247 0
1
0 0 54 2
1
end_operator
begin_operator
down f59 f12
1
315 0
1
0 0 54 3
1
end_operator
begin_operator
down f59 f13
1
382 0
1
0 0 54 4
1
end_operator
begin_operator
down f59 f14
1
448 0
1
0 0 54 5
1
end_operator
begin_operator
down f59 f15
1
513 0
1
0 0 54 6
1
end_operator
begin_operator
down f59 f16
1
577 0
1
0 0 54 7
1
end_operator
begin_operator
down f59 f17
1
640 0
1
0 0 54 8
1
end_operator
begin_operator
down f59 f18
1
702 0
1
0 0 54 9
1
end_operator
begin_operator
down f59 f19
1
763 0
1
0 0 54 10
1
end_operator
begin_operator
down f59 f2
1
837 0
1
0 0 54 11
1
end_operator
begin_operator
down f59 f20
1
901 0
1
0 0 54 12
1
end_operator
begin_operator
down f59 f21
1
960 0
1
0 0 54 13
1
end_operator
begin_operator
down f59 f22
1
1018 0
1
0 0 54 14
1
end_operator
begin_operator
down f59 f23
1
1075 0
1
0 0 54 15
1
end_operator
begin_operator
down f59 f24
1
1131 0
1
0 0 54 16
1
end_operator
begin_operator
down f59 f25
1
1186 0
1
0 0 54 17
1
end_operator
begin_operator
down f59 f26
1
1240 0
1
0 0 54 18
1
end_operator
begin_operator
down f59 f27
1
1293 0
1
0 0 54 19
1
end_operator
begin_operator
down f59 f28
1
1345 0
1
0 0 54 20
1
end_operator
begin_operator
down f59 f29
1
1396 0
1
0 0 54 21
1
end_operator
begin_operator
down f59 f3
1
1469 0
1
0 0 54 22
1
end_operator
begin_operator
down f59 f30
1
1523 0
1
0 0 54 23
1
end_operator
begin_operator
down f59 f31
1
1572 0
1
0 0 54 24
1
end_operator
begin_operator
down f59 f32
1
1620 0
1
0 0 54 25
1
end_operator
begin_operator
down f59 f33
1
1667 0
1
0 0 54 26
1
end_operator
begin_operator
down f59 f34
1
1713 0
1
0 0 54 27
1
end_operator
begin_operator
down f59 f35
1
1758 0
1
0 0 54 28
1
end_operator
begin_operator
down f59 f36
1
1802 0
1
0 0 54 29
1
end_operator
begin_operator
down f59 f37
1
1845 0
1
0 0 54 30
1
end_operator
begin_operator
down f59 f38
1
1887 0
1
0 0 54 31
1
end_operator
begin_operator
down f59 f39
1
1928 0
1
0 0 54 32
1
end_operator
begin_operator
down f59 f4
1
2000 0
1
0 0 54 33
1
end_operator
begin_operator
down f59 f40
1
2044 0
1
0 0 54 34
1
end_operator
begin_operator
down f59 f41
1
2083 0
1
0 0 54 35
1
end_operator
begin_operator
down f59 f42
1
2121 0
1
0 0 54 36
1
end_operator
begin_operator
down f59 f43
1
2158 0
1
0 0 54 37
1
end_operator
begin_operator
down f59 f44
1
2194 0
1
0 0 54 38
1
end_operator
begin_operator
down f59 f45
1
2229 0
1
0 0 54 39
1
end_operator
begin_operator
down f59 f46
1
2263 0
1
0 0 54 40
1
end_operator
begin_operator
down f59 f47
1
2296 0
1
0 0 54 41
1
end_operator
begin_operator
down f59 f48
1
2328 0
1
0 0 54 42
1
end_operator
begin_operator
down f59 f49
1
2359 0
1
0 0 54 43
1
end_operator
begin_operator
down f59 f5
1
2430 0
1
0 0 54 44
1
end_operator
begin_operator
down f59 f50
1
2464 0
1
0 0 54 45
1
end_operator
begin_operator
down f59 f51
1
2493 0
1
0 0 54 46
1
end_operator
begin_operator
down f59 f52
1
2521 0
1
0 0 54 47
1
end_operator
begin_operator
down f59 f53
1
2548 0
1
0 0 54 48
1
end_operator
begin_operator
down f59 f54
1
2574 0
1
0 0 54 49
1
end_operator
begin_operator
down f59 f55
1
2599 0
1
0 0 54 50
1
end_operator
begin_operator
down f59 f56
1
2623 0
1
0 0 54 51
1
end_operator
begin_operator
down f59 f57
1
2646 0
1
0 0 54 52
1
end_operator
begin_operator
down f59 f58
1
2668 0
1
0 0 54 53
1
end_operator
begin_operator
down f59 f6
1
2760 0
1
0 0 54 55
1
end_operator
begin_operator
down f59 f7
1
2989 0
1
0 0 54 66
1
end_operator
begin_operator
down f59 f8
1
3117 0
1
0 0 54 77
1
end_operator
begin_operator
down f59 f9
1
3189 0
1
0 0 54 79
1
end_operator
begin_operator
down f6 f1
1
105 0
1
0 0 55 0
1
end_operator
begin_operator
down f6 f2
1
838 0
1
0 0 55 11
1
end_operator
begin_operator
down f6 f3
1
1470 0
1
0 0 55 22
1
end_operator
begin_operator
down f6 f4
1
2001 0
1
0 0 55 33
1
end_operator
begin_operator
down f6 f5
1
2431 0
1
0 0 55 44
1
end_operator
begin_operator
down f60 f1
1
106 0
1
0 0 56 0
1
end_operator
begin_operator
down f60 f10
1
179 0
1
0 0 56 1
1
end_operator
begin_operator
down f60 f11
1
248 0
1
0 0 56 2
1
end_operator
begin_operator
down f60 f12
1
316 0
1
0 0 56 3
1
end_operator
begin_operator
down f60 f13
1
383 0
1
0 0 56 4
1
end_operator
begin_operator
down f60 f14
1
449 0
1
0 0 56 5
1
end_operator
begin_operator
down f60 f15
1
514 0
1
0 0 56 6
1
end_operator
begin_operator
down f60 f16
1
578 0
1
0 0 56 7
1
end_operator
begin_operator
down f60 f17
1
641 0
1
0 0 56 8
1
end_operator
begin_operator
down f60 f18
1
703 0
1
0 0 56 9
1
end_operator
begin_operator
down f60 f19
1
764 0
1
0 0 56 10
1
end_operator
begin_operator
down f60 f2
1
839 0
1
0 0 56 11
1
end_operator
begin_operator
down f60 f20
1
902 0
1
0 0 56 12
1
end_operator
begin_operator
down f60 f21
1
961 0
1
0 0 56 13
1
end_operator
begin_operator
down f60 f22
1
1019 0
1
0 0 56 14
1
end_operator
begin_operator
down f60 f23
1
1076 0
1
0 0 56 15
1
end_operator
begin_operator
down f60 f24
1
1132 0
1
0 0 56 16
1
end_operator
begin_operator
down f60 f25
1
1187 0
1
0 0 56 17
1
end_operator
begin_operator
down f60 f26
1
1241 0
1
0 0 56 18
1
end_operator
begin_operator
down f60 f27
1
1294 0
1
0 0 56 19
1
end_operator
begin_operator
down f60 f28
1
1346 0
1
0 0 56 20
1
end_operator
begin_operator
down f60 f29
1
1397 0
1
0 0 56 21
1
end_operator
begin_operator
down f60 f3
1
1471 0
1
0 0 56 22
1
end_operator
begin_operator
down f60 f30
1
1524 0
1
0 0 56 23
1
end_operator
begin_operator
down f60 f31
1
1573 0
1
0 0 56 24
1
end_operator
begin_operator
down f60 f32
1
1621 0
1
0 0 56 25
1
end_operator
begin_operator
down f60 f33
1
1668 0
1
0 0 56 26
1
end_operator
begin_operator
down f60 f34
1
1714 0
1
0 0 56 27
1
end_operator
begin_operator
down f60 f35
1
1759 0
1
0 0 56 28
1
end_operator
begin_operator
down f60 f36
1
1803 0
1
0 0 56 29
1
end_operator
begin_operator
down f60 f37
1
1846 0
1
0 0 56 30
1
end_operator
begin_operator
down f60 f38
1
1888 0
1
0 0 56 31
1
end_operator
begin_operator
down f60 f39
1
1929 0
1
0 0 56 32
1
end_operator
begin_operator
down f60 f4
1
2002 0
1
0 0 56 33
1
end_operator
begin_operator
down f60 f40
1
2045 0
1
0 0 56 34
1
end_operator
begin_operator
down f60 f41
1
2084 0
1
0 0 56 35
1
end_operator
begin_operator
down f60 f42
1
2122 0
1
0 0 56 36
1
end_operator
begin_operator
down f60 f43
1
2159 0
1
0 0 56 37
1
end_operator
begin_operator
down f60 f44
1
2195 0
1
0 0 56 38
1
end_operator
begin_operator
down f60 f45
1
2230 0
1
0 0 56 39
1
end_operator
begin_operator
down f60 f46
1
2264 0
1
0 0 56 40
1
end_operator
begin_operator
down f60 f47
1
2297 0
1
0 0 56 41
1
end_operator
begin_operator
down f60 f48
1
2329 0
1
0 0 56 42
1
end_operator
begin_operator
down f60 f49
1
2360 0
1
0 0 56 43
1
end_operator
begin_operator
down f60 f5
1
2432 0
1
0 0 56 44
1
end_operator
begin_operator
down f60 f50
1
2465 0
1
0 0 56 45
1
end_operator
begin_operator
down f60 f51
1
2494 0
1
0 0 56 46
1
end_operator
begin_operator
down f60 f52
1
2522 0
1
0 0 56 47
1
end_operator
begin_operator
down f60 f53
1
2549 0
1
0 0 56 48
1
end_operator
begin_operator
down f60 f54
1
2575 0
1
0 0 56 49
1
end_operator
begin_operator
down f60 f55
1
2600 0
1
0 0 56 50
1
end_operator
begin_operator
down f60 f56
1
2624 0
1
0 0 56 51
1
end_operator
begin_operator
down f60 f57
1
2647 0
1
0 0 56 52
1
end_operator
begin_operator
down f60 f58
1
2669 0
1
0 0 56 53
1
end_operator
begin_operator
down f60 f59
1
2690 0
1
0 0 56 54
1
end_operator
begin_operator
down f60 f6
1
2761 0
1
0 0 56 55
1
end_operator
begin_operator
down f60 f7
1
2990 0
1
0 0 56 66
1
end_operator
begin_operator
down f60 f8
1
3118 0
1
0 0 56 77
1
end_operator
begin_operator
down f60 f9
1
3190 0
1
0 0 56 79
1
end_operator
begin_operator
down f61 f1
1
107 0
1
0 0 57 0
1
end_operator
begin_operator
down f61 f10
1
180 0
1
0 0 57 1
1
end_operator
begin_operator
down f61 f11
1
249 0
1
0 0 57 2
1
end_operator
begin_operator
down f61 f12
1
317 0
1
0 0 57 3
1
end_operator
begin_operator
down f61 f13
1
384 0
1
0 0 57 4
1
end_operator
begin_operator
down f61 f14
1
450 0
1
0 0 57 5
1
end_operator
begin_operator
down f61 f15
1
515 0
1
0 0 57 6
1
end_operator
begin_operator
down f61 f16
1
579 0
1
0 0 57 7
1
end_operator
begin_operator
down f61 f17
1
642 0
1
0 0 57 8
1
end_operator
begin_operator
down f61 f18
1
704 0
1
0 0 57 9
1
end_operator
begin_operator
down f61 f19
1
765 0
1
0 0 57 10
1
end_operator
begin_operator
down f61 f2
1
840 0
1
0 0 57 11
1
end_operator
begin_operator
down f61 f20
1
903 0
1
0 0 57 12
1
end_operator
begin_operator
down f61 f21
1
962 0
1
0 0 57 13
1
end_operator
begin_operator
down f61 f22
1
1020 0
1
0 0 57 14
1
end_operator
begin_operator
down f61 f23
1
1077 0
1
0 0 57 15
1
end_operator
begin_operator
down f61 f24
1
1133 0
1
0 0 57 16
1
end_operator
begin_operator
down f61 f25
1
1188 0
1
0 0 57 17
1
end_operator
begin_operator
down f61 f26
1
1242 0
1
0 0 57 18
1
end_operator
begin_operator
down f61 f27
1
1295 0
1
0 0 57 19
1
end_operator
begin_operator
down f61 f28
1
1347 0
1
0 0 57 20
1
end_operator
begin_operator
down f61 f29
1
1398 0
1
0 0 57 21
1
end_operator
begin_operator
down f61 f3
1
1472 0
1
0 0 57 22
1
end_operator
begin_operator
down f61 f30
1
1525 0
1
0 0 57 23
1
end_operator
begin_operator
down f61 f31
1
1574 0
1
0 0 57 24
1
end_operator
begin_operator
down f61 f32
1
1622 0
1
0 0 57 25
1
end_operator
begin_operator
down f61 f33
1
1669 0
1
0 0 57 26
1
end_operator
begin_operator
down f61 f34
1
1715 0
1
0 0 57 27
1
end_operator
begin_operator
down f61 f35
1
1760 0
1
0 0 57 28
1
end_operator
begin_operator
down f61 f36
1
1804 0
1
0 0 57 29
1
end_operator
begin_operator
down f61 f37
1
1847 0
1
0 0 57 30
1
end_operator
begin_operator
down f61 f38
1
1889 0
1
0 0 57 31
1
end_operator
begin_operator
down f61 f39
1
1930 0
1
0 0 57 32
1
end_operator
begin_operator
down f61 f4
1
2003 0
1
0 0 57 33
1
end_operator
begin_operator
down f61 f40
1
2046 0
1
0 0 57 34
1
end_operator
begin_operator
down f61 f41
1
2085 0
1
0 0 57 35
1
end_operator
begin_operator
down f61 f42
1
2123 0
1
0 0 57 36
1
end_operator
begin_operator
down f61 f43
1
2160 0
1
0 0 57 37
1
end_operator
begin_operator
down f61 f44
1
2196 0
1
0 0 57 38
1
end_operator
begin_operator
down f61 f45
1
2231 0
1
0 0 57 39
1
end_operator
begin_operator
down f61 f46
1
2265 0
1
0 0 57 40
1
end_operator
begin_operator
down f61 f47
1
2298 0
1
0 0 57 41
1
end_operator
begin_operator
down f61 f48
1
2330 0
1
0 0 57 42
1
end_operator
begin_operator
down f61 f49
1
2361 0
1
0 0 57 43
1
end_operator
begin_operator
down f61 f5
1
2433 0
1
0 0 57 44
1
end_operator
begin_operator
down f61 f50
1
2466 0
1
0 0 57 45
1
end_operator
begin_operator
down f61 f51
1
2495 0
1
0 0 57 46
1
end_operator
begin_operator
down f61 f52
1
2523 0
1
0 0 57 47
1
end_operator
begin_operator
down f61 f53
1
2550 0
1
0 0 57 48
1
end_operator
begin_operator
down f61 f54
1
2576 0
1
0 0 57 49
1
end_operator
begin_operator
down f61 f55
1
2601 0
1
0 0 57 50
1
end_operator
begin_operator
down f61 f56
1
2625 0
1
0 0 57 51
1
end_operator
begin_operator
down f61 f57
1
2648 0
1
0 0 57 52
1
end_operator
begin_operator
down f61 f58
1
2670 0
1
0 0 57 53
1
end_operator
begin_operator
down f61 f59
1
2691 0
1
0 0 57 54
1
end_operator
begin_operator
down f61 f6
1
2762 0
1
0 0 57 55
1
end_operator
begin_operator
down f61 f60
1
2785 0
1
0 0 57 56
1
end_operator
begin_operator
down f61 f7
1
2991 0
1
0 0 57 66
1
end_operator
begin_operator
down f61 f8
1
3119 0
1
0 0 57 77
1
end_operator
begin_operator
down f61 f9
1
3191 0
1
0 0 57 79
1
end_operator
begin_operator
down f62 f1
1
108 0
1
0 0 58 0
1
end_operator
begin_operator
down f62 f10
1
181 0
1
0 0 58 1
1
end_operator
begin_operator
down f62 f11
1
250 0
1
0 0 58 2
1
end_operator
begin_operator
down f62 f12
1
318 0
1
0 0 58 3
1
end_operator
begin_operator
down f62 f13
1
385 0
1
0 0 58 4
1
end_operator
begin_operator
down f62 f14
1
451 0
1
0 0 58 5
1
end_operator
begin_operator
down f62 f15
1
516 0
1
0 0 58 6
1
end_operator
begin_operator
down f62 f16
1
580 0
1
0 0 58 7
1
end_operator
begin_operator
down f62 f17
1
643 0
1
0 0 58 8
1
end_operator
begin_operator
down f62 f18
1
705 0
1
0 0 58 9
1
end_operator
begin_operator
down f62 f19
1
766 0
1
0 0 58 10
1
end_operator
begin_operator
down f62 f2
1
841 0
1
0 0 58 11
1
end_operator
begin_operator
down f62 f20
1
904 0
1
0 0 58 12
1
end_operator
begin_operator
down f62 f21
1
963 0
1
0 0 58 13
1
end_operator
begin_operator
down f62 f22
1
1021 0
1
0 0 58 14
1
end_operator
begin_operator
down f62 f23
1
1078 0
1
0 0 58 15
1
end_operator
begin_operator
down f62 f24
1
1134 0
1
0 0 58 16
1
end_operator
begin_operator
down f62 f25
1
1189 0
1
0 0 58 17
1
end_operator
begin_operator
down f62 f26
1
1243 0
1
0 0 58 18
1
end_operator
begin_operator
down f62 f27
1
1296 0
1
0 0 58 19
1
end_operator
begin_operator
down f62 f28
1
1348 0
1
0 0 58 20
1
end_operator
begin_operator
down f62 f29
1
1399 0
1
0 0 58 21
1
end_operator
begin_operator
down f62 f3
1
1473 0
1
0 0 58 22
1
end_operator
begin_operator
down f62 f30
1
1526 0
1
0 0 58 23
1
end_operator
begin_operator
down f62 f31
1
1575 0
1
0 0 58 24
1
end_operator
begin_operator
down f62 f32
1
1623 0
1
0 0 58 25
1
end_operator
begin_operator
down f62 f33
1
1670 0
1
0 0 58 26
1
end_operator
begin_operator
down f62 f34
1
1716 0
1
0 0 58 27
1
end_operator
begin_operator
down f62 f35
1
1761 0
1
0 0 58 28
1
end_operator
begin_operator
down f62 f36
1
1805 0
1
0 0 58 29
1
end_operator
begin_operator
down f62 f37
1
1848 0
1
0 0 58 30
1
end_operator
begin_operator
down f62 f38
1
1890 0
1
0 0 58 31
1
end_operator
begin_operator
down f62 f39
1
1931 0
1
0 0 58 32
1
end_operator
begin_operator
down f62 f4
1
2004 0
1
0 0 58 33
1
end_operator
begin_operator
down f62 f40
1
2047 0
1
0 0 58 34
1
end_operator
begin_operator
down f62 f41
1
2086 0
1
0 0 58 35
1
end_operator
begin_operator
down f62 f42
1
2124 0
1
0 0 58 36
1
end_operator
begin_operator
down f62 f43
1
2161 0
1
0 0 58 37
1
end_operator
begin_operator
down f62 f44
1
2197 0
1
0 0 58 38
1
end_operator
begin_operator
down f62 f45
1
2232 0
1
0 0 58 39
1
end_operator
begin_operator
down f62 f46
1
2266 0
1
0 0 58 40
1
end_operator
begin_operator
down f62 f47
1
2299 0
1
0 0 58 41
1
end_operator
begin_operator
down f62 f48
1
2331 0
1
0 0 58 42
1
end_operator
begin_operator
down f62 f49
1
2362 0
1
0 0 58 43
1
end_operator
begin_operator
down f62 f5
1
2434 0
1
0 0 58 44
1
end_operator
begin_operator
down f62 f50
1
2467 0
1
0 0 58 45
1
end_operator
begin_operator
down f62 f51
1
2496 0
1
0 0 58 46
1
end_operator
begin_operator
down f62 f52
1
2524 0
1
0 0 58 47
1
end_operator
begin_operator
down f62 f53
1
2551 0
1
0 0 58 48
1
end_operator
begin_operator
down f62 f54
1
2577 0
1
0 0 58 49
1
end_operator
begin_operator
down f62 f55
1
2602 0
1
0 0 58 50
1
end_operator
begin_operator
down f62 f56
1
2626 0
1
0 0 58 51
1
end_operator
begin_operator
down f62 f57
1
2649 0
1
0 0 58 52
1
end_operator
begin_operator
down f62 f58
1
2671 0
1
0 0 58 53
1
end_operator
begin_operator
down f62 f59
1
2692 0
1
0 0 58 54
1
end_operator
begin_operator
down f62 f6
1
2763 0
1
0 0 58 55
1
end_operator
begin_operator
down f62 f60
1
2786 0
1
0 0 58 56
1
end_operator
begin_operator
down f62 f61
1
2805 0
1
0 0 58 57
1
end_operator
begin_operator
down f62 f7
1
2992 0
1
0 0 58 66
1
end_operator
begin_operator
down f62 f8
1
3120 0
1
0 0 58 77
1
end_operator
begin_operator
down f62 f9
1
3192 0
1
0 0 58 79
1
end_operator
begin_operator
down f63 f1
1
109 0
1
0 0 59 0
1
end_operator
begin_operator
down f63 f10
1
182 0
1
0 0 59 1
1
end_operator
begin_operator
down f63 f11
1
251 0
1
0 0 59 2
1
end_operator
begin_operator
down f63 f12
1
319 0
1
0 0 59 3
1
end_operator
begin_operator
down f63 f13
1
386 0
1
0 0 59 4
1
end_operator
begin_operator
down f63 f14
1
452 0
1
0 0 59 5
1
end_operator
begin_operator
down f63 f15
1
517 0
1
0 0 59 6
1
end_operator
begin_operator
down f63 f16
1
581 0
1
0 0 59 7
1
end_operator
begin_operator
down f63 f17
1
644 0
1
0 0 59 8
1
end_operator
begin_operator
down f63 f18
1
706 0
1
0 0 59 9
1
end_operator
begin_operator
down f63 f19
1
767 0
1
0 0 59 10
1
end_operator
begin_operator
down f63 f2
1
842 0
1
0 0 59 11
1
end_operator
begin_operator
down f63 f20
1
905 0
1
0 0 59 12
1
end_operator
begin_operator
down f63 f21
1
964 0
1
0 0 59 13
1
end_operator
begin_operator
down f63 f22
1
1022 0
1
0 0 59 14
1
end_operator
begin_operator
down f63 f23
1
1079 0
1
0 0 59 15
1
end_operator
begin_operator
down f63 f24
1
1135 0
1
0 0 59 16
1
end_operator
begin_operator
down f63 f25
1
1190 0
1
0 0 59 17
1
end_operator
begin_operator
down f63 f26
1
1244 0
1
0 0 59 18
1
end_operator
begin_operator
down f63 f27
1
1297 0
1
0 0 59 19
1
end_operator
begin_operator
down f63 f28
1
1349 0
1
0 0 59 20
1
end_operator
begin_operator
down f63 f29
1
1400 0
1
0 0 59 21
1
end_operator
begin_operator
down f63 f3
1
1474 0
1
0 0 59 22
1
end_operator
begin_operator
down f63 f30
1
1527 0
1
0 0 59 23
1
end_operator
begin_operator
down f63 f31
1
1576 0
1
0 0 59 24
1
end_operator
begin_operator
down f63 f32
1
1624 0
1
0 0 59 25
1
end_operator
begin_operator
down f63 f33
1
1671 0
1
0 0 59 26
1
end_operator
begin_operator
down f63 f34
1
1717 0
1
0 0 59 27
1
end_operator
begin_operator
down f63 f35
1
1762 0
1
0 0 59 28
1
end_operator
begin_operator
down f63 f36
1
1806 0
1
0 0 59 29
1
end_operator
begin_operator
down f63 f37
1
1849 0
1
0 0 59 30
1
end_operator
begin_operator
down f63 f38
1
1891 0
1
0 0 59 31
1
end_operator
begin_operator
down f63 f39
1
1932 0
1
0 0 59 32
1
end_operator
begin_operator
down f63 f4
1
2005 0
1
0 0 59 33
1
end_operator
begin_operator
down f63 f40
1
2048 0
1
0 0 59 34
1
end_operator
begin_operator
down f63 f41
1
2087 0
1
0 0 59 35
1
end_operator
begin_operator
down f63 f42
1
2125 0
1
0 0 59 36
1
end_operator
begin_operator
down f63 f43
1
2162 0
1
0 0 59 37
1
end_operator
begin_operator
down f63 f44
1
2198 0
1
0 0 59 38
1
end_operator
begin_operator
down f63 f45
1
2233 0
1
0 0 59 39
1
end_operator
begin_operator
down f63 f46
1
2267 0
1
0 0 59 40
1
end_operator
begin_operator
down f63 f47
1
2300 0
1
0 0 59 41
1
end_operator
begin_operator
down f63 f48
1
2332 0
1
0 0 59 42
1
end_operator
begin_operator
down f63 f49
1
2363 0
1
0 0 59 43
1
end_operator
begin_operator
down f63 f5
1
2435 0
1
0 0 59 44
1
end_operator
begin_operator
down f63 f50
1
2468 0
1
0 0 59 45
1
end_operator
begin_operator
down f63 f51
1
2497 0
1
0 0 59 46
1
end_operator
begin_operator
down f63 f52
1
2525 0
1
0 0 59 47
1
end_operator
begin_operator
down f63 f53
1
2552 0
1
0 0 59 48
1
end_operator
begin_operator
down f63 f54
1
2578 0
1
0 0 59 49
1
end_operator
begin_operator
down f63 f55
1
2603 0
1
0 0 59 50
1
end_operator
begin_operator
down f63 f56
1
2627 0
1
0 0 59 51
1
end_operator
begin_operator
down f63 f57
1
2650 0
1
0 0 59 52
1
end_operator
begin_operator
down f63 f58
1
2672 0
1
0 0 59 53
1
end_operator
begin_operator
down f63 f59
1
2693 0
1
0 0 59 54
1
end_operator
begin_operator
down f63 f6
1
2764 0
1
0 0 59 55
1
end_operator
begin_operator
down f63 f60
1
2787 0
1
0 0 59 56
1
end_operator
begin_operator
down f63 f61
1
2806 0
1
0 0 59 57
1
end_operator
begin_operator
down f63 f62
1
2824 0
1
0 0 59 58
1
end_operator
begin_operator
down f63 f7
1
2993 0
1
0 0 59 66
1
end_operator
begin_operator
down f63 f8
1
3121 0
1
0 0 59 77
1
end_operator
begin_operator
down f63 f9
1
3193 0
1
0 0 59 79
1
end_operator
begin_operator
down f64 f1
1
110 0
1
0 0 60 0
1
end_operator
begin_operator
down f64 f10
1
183 0
1
0 0 60 1
1
end_operator
begin_operator
down f64 f11
1
252 0
1
0 0 60 2
1
end_operator
begin_operator
down f64 f12
1
320 0
1
0 0 60 3
1
end_operator
begin_operator
down f64 f13
1
387 0
1
0 0 60 4
1
end_operator
begin_operator
down f64 f14
1
453 0
1
0 0 60 5
1
end_operator
begin_operator
down f64 f15
1
518 0
1
0 0 60 6
1
end_operator
begin_operator
down f64 f16
1
582 0
1
0 0 60 7
1
end_operator
begin_operator
down f64 f17
1
645 0
1
0 0 60 8
1
end_operator
begin_operator
down f64 f18
1
707 0
1
0 0 60 9
1
end_operator
begin_operator
down f64 f19
1
768 0
1
0 0 60 10
1
end_operator
begin_operator
down f64 f2
1
843 0
1
0 0 60 11
1
end_operator
begin_operator
down f64 f20
1
906 0
1
0 0 60 12
1
end_operator
begin_operator
down f64 f21
1
965 0
1
0 0 60 13
1
end_operator
begin_operator
down f64 f22
1
1023 0
1
0 0 60 14
1
end_operator
begin_operator
down f64 f23
1
1080 0
1
0 0 60 15
1
end_operator
begin_operator
down f64 f24
1
1136 0
1
0 0 60 16
1
end_operator
begin_operator
down f64 f25
1
1191 0
1
0 0 60 17
1
end_operator
begin_operator
down f64 f26
1
1245 0
1
0 0 60 18
1
end_operator
begin_operator
down f64 f27
1
1298 0
1
0 0 60 19
1
end_operator
begin_operator
down f64 f28
1
1350 0
1
0 0 60 20
1
end_operator
begin_operator
down f64 f29
1
1401 0
1
0 0 60 21
1
end_operator
begin_operator
down f64 f3
1
1475 0
1
0 0 60 22
1
end_operator
begin_operator
down f64 f30
1
1528 0
1
0 0 60 23
1
end_operator
begin_operator
down f64 f31
1
1577 0
1
0 0 60 24
1
end_operator
begin_operator
down f64 f32
1
1625 0
1
0 0 60 25
1
end_operator
begin_operator
down f64 f33
1
1672 0
1
0 0 60 26
1
end_operator
begin_operator
down f64 f34
1
1718 0
1
0 0 60 27
1
end_operator
begin_operator
down f64 f35
1
1763 0
1
0 0 60 28
1
end_operator
begin_operator
down f64 f36
1
1807 0
1
0 0 60 29
1
end_operator
begin_operator
down f64 f37
1
1850 0
1
0 0 60 30
1
end_operator
begin_operator
down f64 f38
1
1892 0
1
0 0 60 31
1
end_operator
begin_operator
down f64 f39
1
1933 0
1
0 0 60 32
1
end_operator
begin_operator
down f64 f4
1
2006 0
1
0 0 60 33
1
end_operator
begin_operator
down f64 f40
1
2049 0
1
0 0 60 34
1
end_operator
begin_operator
down f64 f41
1
2088 0
1
0 0 60 35
1
end_operator
begin_operator
down f64 f42
1
2126 0
1
0 0 60 36
1
end_operator
begin_operator
down f64 f43
1
2163 0
1
0 0 60 37
1
end_operator
begin_operator
down f64 f44
1
2199 0
1
0 0 60 38
1
end_operator
begin_operator
down f64 f45
1
2234 0
1
0 0 60 39
1
end_operator
begin_operator
down f64 f46
1
2268 0
1
0 0 60 40
1
end_operator
begin_operator
down f64 f47
1
2301 0
1
0 0 60 41
1
end_operator
begin_operator
down f64 f48
1
2333 0
1
0 0 60 42
1
end_operator
begin_operator
down f64 f49
1
2364 0
1
0 0 60 43
1
end_operator
begin_operator
down f64 f5
1
2436 0
1
0 0 60 44
1
end_operator
begin_operator
down f64 f50
1
2469 0
1
0 0 60 45
1
end_operator
begin_operator
down f64 f51
1
2498 0
1
0 0 60 46
1
end_operator
begin_operator
down f64 f52
1
2526 0
1
0 0 60 47
1
end_operator
begin_operator
down f64 f53
1
2553 0
1
0 0 60 48
1
end_operator
begin_operator
down f64 f54
1
2579 0
1
0 0 60 49
1
end_operator
begin_operator
down f64 f55
1
2604 0
1
0 0 60 50
1
end_operator
begin_operator
down f64 f56
1
2628 0
1
0 0 60 51
1
end_operator
begin_operator
down f64 f57
1
2651 0
1
0 0 60 52
1
end_operator
begin_operator
down f64 f58
1
2673 0
1
0 0 60 53
1
end_operator
begin_operator
down f64 f59
1
2694 0
1
0 0 60 54
1
end_operator
begin_operator
down f64 f6
1
2765 0
1
0 0 60 55
1
end_operator
begin_operator
down f64 f60
1
2788 0
1
0 0 60 56
1
end_operator
begin_operator
down f64 f61
1
2807 0
1
0 0 60 57
1
end_operator
begin_operator
down f64 f62
1
2825 0
1
0 0 60 58
1
end_operator
begin_operator
down f64 f63
1
2842 0
1
0 0 60 59
1
end_operator
begin_operator
down f64 f7
1
2994 0
1
0 0 60 66
1
end_operator
begin_operator
down f64 f8
1
3122 0
1
0 0 60 77
1
end_operator
begin_operator
down f64 f9
1
3194 0
1
0 0 60 79
1
end_operator
begin_operator
down f65 f1
1
111 0
1
0 0 61 0
1
end_operator
begin_operator
down f65 f10
1
184 0
1
0 0 61 1
1
end_operator
begin_operator
down f65 f11
1
253 0
1
0 0 61 2
1
end_operator
begin_operator
down f65 f12
1
321 0
1
0 0 61 3
1
end_operator
begin_operator
down f65 f13
1
388 0
1
0 0 61 4
1
end_operator
begin_operator
down f65 f14
1
454 0
1
0 0 61 5
1
end_operator
begin_operator
down f65 f15
1
519 0
1
0 0 61 6
1
end_operator
begin_operator
down f65 f16
1
583 0
1
0 0 61 7
1
end_operator
begin_operator
down f65 f17
1
646 0
1
0 0 61 8
1
end_operator
begin_operator
down f65 f18
1
708 0
1
0 0 61 9
1
end_operator
begin_operator
down f65 f19
1
769 0
1
0 0 61 10
1
end_operator
begin_operator
down f65 f2
1
844 0
1
0 0 61 11
1
end_operator
begin_operator
down f65 f20
1
907 0
1
0 0 61 12
1
end_operator
begin_operator
down f65 f21
1
966 0
1
0 0 61 13
1
end_operator
begin_operator
down f65 f22
1
1024 0
1
0 0 61 14
1
end_operator
begin_operator
down f65 f23
1
1081 0
1
0 0 61 15
1
end_operator
begin_operator
down f65 f24
1
1137 0
1
0 0 61 16
1
end_operator
begin_operator
down f65 f25
1
1192 0
1
0 0 61 17
1
end_operator
begin_operator
down f65 f26
1
1246 0
1
0 0 61 18
1
end_operator
begin_operator
down f65 f27
1
1299 0
1
0 0 61 19
1
end_operator
begin_operator
down f65 f28
1
1351 0
1
0 0 61 20
1
end_operator
begin_operator
down f65 f29
1
1402 0
1
0 0 61 21
1
end_operator
begin_operator
down f65 f3
1
1476 0
1
0 0 61 22
1
end_operator
begin_operator
down f65 f30
1
1529 0
1
0 0 61 23
1
end_operator
begin_operator
down f65 f31
1
1578 0
1
0 0 61 24
1
end_operator
begin_operator
down f65 f32
1
1626 0
1
0 0 61 25
1
end_operator
begin_operator
down f65 f33
1
1673 0
1
0 0 61 26
1
end_operator
begin_operator
down f65 f34
1
1719 0
1
0 0 61 27
1
end_operator
begin_operator
down f65 f35
1
1764 0
1
0 0 61 28
1
end_operator
begin_operator
down f65 f36
1
1808 0
1
0 0 61 29
1
end_operator
begin_operator
down f65 f37
1
1851 0
1
0 0 61 30
1
end_operator
begin_operator
down f65 f38
1
1893 0
1
0 0 61 31
1
end_operator
begin_operator
down f65 f39
1
1934 0
1
0 0 61 32
1
end_operator
begin_operator
down f65 f4
1
2007 0
1
0 0 61 33
1
end_operator
begin_operator
down f65 f40
1
2050 0
1
0 0 61 34
1
end_operator
begin_operator
down f65 f41
1
2089 0
1
0 0 61 35
1
end_operator
begin_operator
down f65 f42
1
2127 0
1
0 0 61 36
1
end_operator
begin_operator
down f65 f43
1
2164 0
1
0 0 61 37
1
end_operator
begin_operator
down f65 f44
1
2200 0
1
0 0 61 38
1
end_operator
begin_operator
down f65 f45
1
2235 0
1
0 0 61 39
1
end_operator
begin_operator
down f65 f46
1
2269 0
1
0 0 61 40
1
end_operator
begin_operator
down f65 f47
1
2302 0
1
0 0 61 41
1
end_operator
begin_operator
down f65 f48
1
2334 0
1
0 0 61 42
1
end_operator
begin_operator
down f65 f49
1
2365 0
1
0 0 61 43
1
end_operator
begin_operator
down f65 f5
1
2437 0
1
0 0 61 44
1
end_operator
begin_operator
down f65 f50
1
2470 0
1
0 0 61 45
1
end_operator
begin_operator
down f65 f51
1
2499 0
1
0 0 61 46
1
end_operator
begin_operator
down f65 f52
1
2527 0
1
0 0 61 47
1
end_operator
begin_operator
down f65 f53
1
2554 0
1
0 0 61 48
1
end_operator
begin_operator
down f65 f54
1
2580 0
1
0 0 61 49
1
end_operator
begin_operator
down f65 f55
1
2605 0
1
0 0 61 50
1
end_operator
begin_operator
down f65 f56
1
2629 0
1
0 0 61 51
1
end_operator
begin_operator
down f65 f57
1
2652 0
1
0 0 61 52
1
end_operator
begin_operator
down f65 f58
1
2674 0
1
0 0 61 53
1
end_operator
begin_operator
down f65 f59
1
2695 0
1
0 0 61 54
1
end_operator
begin_operator
down f65 f6
1
2766 0
1
0 0 61 55
1
end_operator
begin_operator
down f65 f60
1
2789 0
1
0 0 61 56
1
end_operator
begin_operator
down f65 f61
1
2808 0
1
0 0 61 57
1
end_operator
begin_operator
down f65 f62
1
2826 0
1
0 0 61 58
1
end_operator
begin_operator
down f65 f63
1
2843 0
1
0 0 61 59
1
end_operator
begin_operator
down f65 f64
1
2859 0
1
0 0 61 60
1
end_operator
begin_operator
down f65 f7
1
2995 0
1
0 0 61 66
1
end_operator
begin_operator
down f65 f8
1
3123 0
1
0 0 61 77
1
end_operator
begin_operator
down f65 f9
1
3195 0
1
0 0 61 79
1
end_operator
begin_operator
down f66 f1
1
112 0
1
0 0 62 0
1
end_operator
begin_operator
down f66 f10
1
185 0
1
0 0 62 1
1
end_operator
begin_operator
down f66 f11
1
254 0
1
0 0 62 2
1
end_operator
begin_operator
down f66 f12
1
322 0
1
0 0 62 3
1
end_operator
begin_operator
down f66 f13
1
389 0
1
0 0 62 4
1
end_operator
begin_operator
down f66 f14
1
455 0
1
0 0 62 5
1
end_operator
begin_operator
down f66 f15
1
520 0
1
0 0 62 6
1
end_operator
begin_operator
down f66 f16
1
584 0
1
0 0 62 7
1
end_operator
begin_operator
down f66 f17
1
647 0
1
0 0 62 8
1
end_operator
begin_operator
down f66 f18
1
709 0
1
0 0 62 9
1
end_operator
begin_operator
down f66 f19
1
770 0
1
0 0 62 10
1
end_operator
begin_operator
down f66 f2
1
845 0
1
0 0 62 11
1
end_operator
begin_operator
down f66 f20
1
908 0
1
0 0 62 12
1
end_operator
begin_operator
down f66 f21
1
967 0
1
0 0 62 13
1
end_operator
begin_operator
down f66 f22
1
1025 0
1
0 0 62 14
1
end_operator
begin_operator
down f66 f23
1
1082 0
1
0 0 62 15
1
end_operator
begin_operator
down f66 f24
1
1138 0
1
0 0 62 16
1
end_operator
begin_operator
down f66 f25
1
1193 0
1
0 0 62 17
1
end_operator
begin_operator
down f66 f26
1
1247 0
1
0 0 62 18
1
end_operator
begin_operator
down f66 f27
1
1300 0
1
0 0 62 19
1
end_operator
begin_operator
down f66 f28
1
1352 0
1
0 0 62 20
1
end_operator
begin_operator
down f66 f29
1
1403 0
1
0 0 62 21
1
end_operator
begin_operator
down f66 f3
1
1477 0
1
0 0 62 22
1
end_operator
begin_operator
down f66 f30
1
1530 0
1
0 0 62 23
1
end_operator
begin_operator
down f66 f31
1
1579 0
1
0 0 62 24
1
end_operator
begin_operator
down f66 f32
1
1627 0
1
0 0 62 25
1
end_operator
begin_operator
down f66 f33
1
1674 0
1
0 0 62 26
1
end_operator
begin_operator
down f66 f34
1
1720 0
1
0 0 62 27
1
end_operator
begin_operator
down f66 f35
1
1765 0
1
0 0 62 28
1
end_operator
begin_operator
down f66 f36
1
1809 0
1
0 0 62 29
1
end_operator
begin_operator
down f66 f37
1
1852 0
1
0 0 62 30
1
end_operator
begin_operator
down f66 f38
1
1894 0
1
0 0 62 31
1
end_operator
begin_operator
down f66 f39
1
1935 0
1
0 0 62 32
1
end_operator
begin_operator
down f66 f4
1
2008 0
1
0 0 62 33
1
end_operator
begin_operator
down f66 f40
1
2051 0
1
0 0 62 34
1
end_operator
begin_operator
down f66 f41
1
2090 0
1
0 0 62 35
1
end_operator
begin_operator
down f66 f42
1
2128 0
1
0 0 62 36
1
end_operator
begin_operator
down f66 f43
1
2165 0
1
0 0 62 37
1
end_operator
begin_operator
down f66 f44
1
2201 0
1
0 0 62 38
1
end_operator
begin_operator
down f66 f45
1
2236 0
1
0 0 62 39
1
end_operator
begin_operator
down f66 f46
1
2270 0
1
0 0 62 40
1
end_operator
begin_operator
down f66 f47
1
2303 0
1
0 0 62 41
1
end_operator
begin_operator
down f66 f48
1
2335 0
1
0 0 62 42
1
end_operator
begin_operator
down f66 f49
1
2366 0
1
0 0 62 43
1
end_operator
begin_operator
down f66 f5
1
2438 0
1
0 0 62 44
1
end_operator
begin_operator
down f66 f50
1
2471 0
1
0 0 62 45
1
end_operator
begin_operator
down f66 f51
1
2500 0
1
0 0 62 46
1
end_operator
begin_operator
down f66 f52
1
2528 0
1
0 0 62 47
1
end_operator
begin_operator
down f66 f53
1
2555 0
1
0 0 62 48
1
end_operator
begin_operator
down f66 f54
1
2581 0
1
0 0 62 49
1
end_operator
begin_operator
down f66 f55
1
2606 0
1
0 0 62 50
1
end_operator
begin_operator
down f66 f56
1
2630 0
1
0 0 62 51
1
end_operator
begin_operator
down f66 f57
1
2653 0
1
0 0 62 52
1
end_operator
begin_operator
down f66 f58
1
2675 0
1
0 0 62 53
1
end_operator
begin_operator
down f66 f59
1
2696 0
1
0 0 62 54
1
end_operator
begin_operator
down f66 f6
1
2767 0
1
0 0 62 55
1
end_operator
begin_operator
down f66 f60
1
2790 0
1
0 0 62 56
1
end_operator
begin_operator
down f66 f61
1
2809 0
1
0 0 62 57
1
end_operator
begin_operator
down f66 f62
1
2827 0
1
0 0 62 58
1
end_operator
begin_operator
down f66 f63
1
2844 0
1
0 0 62 59
1
end_operator
begin_operator
down f66 f64
1
2860 0
1
0 0 62 60
1
end_operator
begin_operator
down f66 f65
1
2875 0
1
0 0 62 61
1
end_operator
begin_operator
down f66 f7
1
2996 0
1
0 0 62 66
1
end_operator
begin_operator
down f66 f8
1
3124 0
1
0 0 62 77
1
end_operator
begin_operator
down f66 f9
1
3196 0
1
0 0 62 79
1
end_operator
begin_operator
down f67 f1
1
113 0
1
0 0 63 0
1
end_operator
begin_operator
down f67 f10
1
186 0
1
0 0 63 1
1
end_operator
begin_operator
down f67 f11
1
255 0
1
0 0 63 2
1
end_operator
begin_operator
down f67 f12
1
323 0
1
0 0 63 3
1
end_operator
begin_operator
down f67 f13
1
390 0
1
0 0 63 4
1
end_operator
begin_operator
down f67 f14
1
456 0
1
0 0 63 5
1
end_operator
begin_operator
down f67 f15
1
521 0
1
0 0 63 6
1
end_operator
begin_operator
down f67 f16
1
585 0
1
0 0 63 7
1
end_operator
begin_operator
down f67 f17
1
648 0
1
0 0 63 8
1
end_operator
begin_operator
down f67 f18
1
710 0
1
0 0 63 9
1
end_operator
begin_operator
down f67 f19
1
771 0
1
0 0 63 10
1
end_operator
begin_operator
down f67 f2
1
846 0
1
0 0 63 11
1
end_operator
begin_operator
down f67 f20
1
909 0
1
0 0 63 12
1
end_operator
begin_operator
down f67 f21
1
968 0
1
0 0 63 13
1
end_operator
begin_operator
down f67 f22
1
1026 0
1
0 0 63 14
1
end_operator
begin_operator
down f67 f23
1
1083 0
1
0 0 63 15
1
end_operator
begin_operator
down f67 f24
1
1139 0
1
0 0 63 16
1
end_operator
begin_operator
down f67 f25
1
1194 0
1
0 0 63 17
1
end_operator
begin_operator
down f67 f26
1
1248 0
1
0 0 63 18
1
end_operator
begin_operator
down f67 f27
1
1301 0
1
0 0 63 19
1
end_operator
begin_operator
down f67 f28
1
1353 0
1
0 0 63 20
1
end_operator
begin_operator
down f67 f29
1
1404 0
1
0 0 63 21
1
end_operator
begin_operator
down f67 f3
1
1478 0
1
0 0 63 22
1
end_operator
begin_operator
down f67 f30
1
1531 0
1
0 0 63 23
1
end_operator
begin_operator
down f67 f31
1
1580 0
1
0 0 63 24
1
end_operator
begin_operator
down f67 f32
1
1628 0
1
0 0 63 25
1
end_operator
begin_operator
down f67 f33
1
1675 0
1
0 0 63 26
1
end_operator
begin_operator
down f67 f34
1
1721 0
1
0 0 63 27
1
end_operator
begin_operator
down f67 f35
1
1766 0
1
0 0 63 28
1
end_operator
begin_operator
down f67 f36
1
1810 0
1
0 0 63 29
1
end_operator
begin_operator
down f67 f37
1
1853 0
1
0 0 63 30
1
end_operator
begin_operator
down f67 f38
1
1895 0
1
0 0 63 31
1
end_operator
begin_operator
down f67 f39
1
1936 0
1
0 0 63 32
1
end_operator
begin_operator
down f67 f4
1
2009 0
1
0 0 63 33
1
end_operator
begin_operator
down f67 f40
1
2052 0
1
0 0 63 34
1
end_operator
begin_operator
down f67 f41
1
2091 0
1
0 0 63 35
1
end_operator
begin_operator
down f67 f42
1
2129 0
1
0 0 63 36
1
end_operator
begin_operator
down f67 f43
1
2166 0
1
0 0 63 37
1
end_operator
begin_operator
down f67 f44
1
2202 0
1
0 0 63 38
1
end_operator
begin_operator
down f67 f45
1
2237 0
1
0 0 63 39
1
end_operator
begin_operator
down f67 f46
1
2271 0
1
0 0 63 40
1
end_operator
begin_operator
down f67 f47
1
2304 0
1
0 0 63 41
1
end_operator
begin_operator
down f67 f48
1
2336 0
1
0 0 63 42
1
end_operator
begin_operator
down f67 f49
1
2367 0
1
0 0 63 43
1
end_operator
begin_operator
down f67 f5
1
2439 0
1
0 0 63 44
1
end_operator
begin_operator
down f67 f50
1
2472 0
1
0 0 63 45
1
end_operator
begin_operator
down f67 f51
1
2501 0
1
0 0 63 46
1
end_operator
begin_operator
down f67 f52
1
2529 0
1
0 0 63 47
1
end_operator
begin_operator
down f67 f53
1
2556 0
1
0 0 63 48
1
end_operator
begin_operator
down f67 f54
1
2582 0
1
0 0 63 49
1
end_operator
begin_operator
down f67 f55
1
2607 0
1
0 0 63 50
1
end_operator
begin_operator
down f67 f56
1
2631 0
1
0 0 63 51
1
end_operator
begin_operator
down f67 f57
1
2654 0
1
0 0 63 52
1
end_operator
begin_operator
down f67 f58
1
2676 0
1
0 0 63 53
1
end_operator
begin_operator
down f67 f59
1
2697 0
1
0 0 63 54
1
end_operator
begin_operator
down f67 f6
1
2768 0
1
0 0 63 55
1
end_operator
begin_operator
down f67 f60
1
2791 0
1
0 0 63 56
1
end_operator
begin_operator
down f67 f61
1
2810 0
1
0 0 63 57
1
end_operator
begin_operator
down f67 f62
1
2828 0
1
0 0 63 58
1
end_operator
begin_operator
down f67 f63
1
2845 0
1
0 0 63 59
1
end_operator
begin_operator
down f67 f64
1
2861 0
1
0 0 63 60
1
end_operator
begin_operator
down f67 f65
1
2876 0
1
0 0 63 61
1
end_operator
begin_operator
down f67 f66
1
2890 0
1
0 0 63 62
1
end_operator
begin_operator
down f67 f7
1
2997 0
1
0 0 63 66
1
end_operator
begin_operator
down f67 f8
1
3125 0
1
0 0 63 77
1
end_operator
begin_operator
down f67 f9
1
3197 0
1
0 0 63 79
1
end_operator
begin_operator
down f68 f1
1
114 0
1
0 0 64 0
1
end_operator
begin_operator
down f68 f10
1
187 0
1
0 0 64 1
1
end_operator
begin_operator
down f68 f11
1
256 0
1
0 0 64 2
1
end_operator
begin_operator
down f68 f12
1
324 0
1
0 0 64 3
1
end_operator
begin_operator
down f68 f13
1
391 0
1
0 0 64 4
1
end_operator
begin_operator
down f68 f14
1
457 0
1
0 0 64 5
1
end_operator
begin_operator
down f68 f15
1
522 0
1
0 0 64 6
1
end_operator
begin_operator
down f68 f16
1
586 0
1
0 0 64 7
1
end_operator
begin_operator
down f68 f17
1
649 0
1
0 0 64 8
1
end_operator
begin_operator
down f68 f18
1
711 0
1
0 0 64 9
1
end_operator
begin_operator
down f68 f19
1
772 0
1
0 0 64 10
1
end_operator
begin_operator
down f68 f2
1
847 0
1
0 0 64 11
1
end_operator
begin_operator
down f68 f20
1
910 0
1
0 0 64 12
1
end_operator
begin_operator
down f68 f21
1
969 0
1
0 0 64 13
1
end_operator
begin_operator
down f68 f22
1
1027 0
1
0 0 64 14
1
end_operator
begin_operator
down f68 f23
1
1084 0
1
0 0 64 15
1
end_operator
begin_operator
down f68 f24
1
1140 0
1
0 0 64 16
1
end_operator
begin_operator
down f68 f25
1
1195 0
1
0 0 64 17
1
end_operator
begin_operator
down f68 f26
1
1249 0
1
0 0 64 18
1
end_operator
begin_operator
down f68 f27
1
1302 0
1
0 0 64 19
1
end_operator
begin_operator
down f68 f28
1
1354 0
1
0 0 64 20
1
end_operator
begin_operator
down f68 f29
1
1405 0
1
0 0 64 21
1
end_operator
begin_operator
down f68 f3
1
1479 0
1
0 0 64 22
1
end_operator
begin_operator
down f68 f30
1
1532 0
1
0 0 64 23
1
end_operator
begin_operator
down f68 f31
1
1581 0
1
0 0 64 24
1
end_operator
begin_operator
down f68 f32
1
1629 0
1
0 0 64 25
1
end_operator
begin_operator
down f68 f33
1
1676 0
1
0 0 64 26
1
end_operator
begin_operator
down f68 f34
1
1722 0
1
0 0 64 27
1
end_operator
begin_operator
down f68 f35
1
1767 0
1
0 0 64 28
1
end_operator
begin_operator
down f68 f36
1
1811 0
1
0 0 64 29
1
end_operator
begin_operator
down f68 f37
1
1854 0
1
0 0 64 30
1
end_operator
begin_operator
down f68 f38
1
1896 0
1
0 0 64 31
1
end_operator
begin_operator
down f68 f39
1
1937 0
1
0 0 64 32
1
end_operator
begin_operator
down f68 f4
1
2010 0
1
0 0 64 33
1
end_operator
begin_operator
down f68 f40
1
2053 0
1
0 0 64 34
1
end_operator
begin_operator
down f68 f41
1
2092 0
1
0 0 64 35
1
end_operator
begin_operator
down f68 f42
1
2130 0
1
0 0 64 36
1
end_operator
begin_operator
down f68 f43
1
2167 0
1
0 0 64 37
1
end_operator
begin_operator
down f68 f44
1
2203 0
1
0 0 64 38
1
end_operator
begin_operator
down f68 f45
1
2238 0
1
0 0 64 39
1
end_operator
begin_operator
down f68 f46
1
2272 0
1
0 0 64 40
1
end_operator
begin_operator
down f68 f47
1
2305 0
1
0 0 64 41
1
end_operator
begin_operator
down f68 f48
1
2337 0
1
0 0 64 42
1
end_operator
begin_operator
down f68 f49
1
2368 0
1
0 0 64 43
1
end_operator
begin_operator
down f68 f5
1
2440 0
1
0 0 64 44
1
end_operator
begin_operator
down f68 f50
1
2473 0
1
0 0 64 45
1
end_operator
begin_operator
down f68 f51
1
2502 0
1
0 0 64 46
1
end_operator
begin_operator
down f68 f52
1
2530 0
1
0 0 64 47
1
end_operator
begin_operator
down f68 f53
1
2557 0
1
0 0 64 48
1
end_operator
begin_operator
down f68 f54
1
2583 0
1
0 0 64 49
1
end_operator
begin_operator
down f68 f55
1
2608 0
1
0 0 64 50
1
end_operator
begin_operator
down f68 f56
1
2632 0
1
0 0 64 51
1
end_operator
begin_operator
down f68 f57
1
2655 0
1
0 0 64 52
1
end_operator
begin_operator
down f68 f58
1
2677 0
1
0 0 64 53
1
end_operator
begin_operator
down f68 f59
1
2698 0
1
0 0 64 54
1
end_operator
begin_operator
down f68 f6
1
2769 0
1
0 0 64 55
1
end_operator
begin_operator
down f68 f60
1
2792 0
1
0 0 64 56
1
end_operator
begin_operator
down f68 f61
1
2811 0
1
0 0 64 57
1
end_operator
begin_operator
down f68 f62
1
2829 0
1
0 0 64 58
1
end_operator
begin_operator
down f68 f63
1
2846 0
1
0 0 64 59
1
end_operator
begin_operator
down f68 f64
1
2862 0
1
0 0 64 60
1
end_operator
begin_operator
down f68 f65
1
2877 0
1
0 0 64 61
1
end_operator
begin_operator
down f68 f66
1
2891 0
1
0 0 64 62
1
end_operator
begin_operator
down f68 f67
1
2904 0
1
0 0 64 63
1
end_operator
begin_operator
down f68 f7
1
2998 0
1
0 0 64 66
1
end_operator
begin_operator
down f68 f8
1
3126 0
1
0 0 64 77
1
end_operator
begin_operator
down f68 f9
1
3198 0
1
0 0 64 79
1
end_operator
begin_operator
down f69 f1
1
115 0
1
0 0 65 0
1
end_operator
begin_operator
down f69 f10
1
188 0
1
0 0 65 1
1
end_operator
begin_operator
down f69 f11
1
257 0
1
0 0 65 2
1
end_operator
begin_operator
down f69 f12
1
325 0
1
0 0 65 3
1
end_operator
begin_operator
down f69 f13
1
392 0
1
0 0 65 4
1
end_operator
begin_operator
down f69 f14
1
458 0
1
0 0 65 5
1
end_operator
begin_operator
down f69 f15
1
523 0
1
0 0 65 6
1
end_operator
begin_operator
down f69 f16
1
587 0
1
0 0 65 7
1
end_operator
begin_operator
down f69 f17
1
650 0
1
0 0 65 8
1
end_operator
begin_operator
down f69 f18
1
712 0
1
0 0 65 9
1
end_operator
begin_operator
down f69 f19
1
773 0
1
0 0 65 10
1
end_operator
begin_operator
down f69 f2
1
848 0
1
0 0 65 11
1
end_operator
begin_operator
down f69 f20
1
911 0
1
0 0 65 12
1
end_operator
begin_operator
down f69 f21
1
970 0
1
0 0 65 13
1
end_operator
begin_operator
down f69 f22
1
1028 0
1
0 0 65 14
1
end_operator
begin_operator
down f69 f23
1
1085 0
1
0 0 65 15
1
end_operator
begin_operator
down f69 f24
1
1141 0
1
0 0 65 16
1
end_operator
begin_operator
down f69 f25
1
1196 0
1
0 0 65 17
1
end_operator
begin_operator
down f69 f26
1
1250 0
1
0 0 65 18
1
end_operator
begin_operator
down f69 f27
1
1303 0
1
0 0 65 19
1
end_operator
begin_operator
down f69 f28
1
1355 0
1
0 0 65 20
1
end_operator
begin_operator
down f69 f29
1
1406 0
1
0 0 65 21
1
end_operator
begin_operator
down f69 f3
1
1480 0
1
0 0 65 22
1
end_operator
begin_operator
down f69 f30
1
1533 0
1
0 0 65 23
1
end_operator
begin_operator
down f69 f31
1
1582 0
1
0 0 65 24
1
end_operator
begin_operator
down f69 f32
1
1630 0
1
0 0 65 25
1
end_operator
begin_operator
down f69 f33
1
1677 0
1
0 0 65 26
1
end_operator
begin_operator
down f69 f34
1
1723 0
1
0 0 65 27
1
end_operator
begin_operator
down f69 f35
1
1768 0
1
0 0 65 28
1
end_operator
begin_operator
down f69 f36
1
1812 0
1
0 0 65 29
1
end_operator
begin_operator
down f69 f37
1
1855 0
1
0 0 65 30
1
end_operator
begin_operator
down f69 f38
1
1897 0
1
0 0 65 31
1
end_operator
begin_operator
down f69 f39
1
1938 0
1
0 0 65 32
1
end_operator
begin_operator
down f69 f4
1
2011 0
1
0 0 65 33
1
end_operator
begin_operator
down f69 f40
1
2054 0
1
0 0 65 34
1
end_operator
begin_operator
down f69 f41
1
2093 0
1
0 0 65 35
1
end_operator
begin_operator
down f69 f42
1
2131 0
1
0 0 65 36
1
end_operator
begin_operator
down f69 f43
1
2168 0
1
0 0 65 37
1
end_operator
begin_operator
down f69 f44
1
2204 0
1
0 0 65 38
1
end_operator
begin_operator
down f69 f45
1
2239 0
1
0 0 65 39
1
end_operator
begin_operator
down f69 f46
1
2273 0
1
0 0 65 40
1
end_operator
begin_operator
down f69 f47
1
2306 0
1
0 0 65 41
1
end_operator
begin_operator
down f69 f48
1
2338 0
1
0 0 65 42
1
end_operator
begin_operator
down f69 f49
1
2369 0
1
0 0 65 43
1
end_operator
begin_operator
down f69 f5
1
2441 0
1
0 0 65 44
1
end_operator
begin_operator
down f69 f50
1
2474 0
1
0 0 65 45
1
end_operator
begin_operator
down f69 f51
1
2503 0
1
0 0 65 46
1
end_operator
begin_operator
down f69 f52
1
2531 0
1
0 0 65 47
1
end_operator
begin_operator
down f69 f53
1
2558 0
1
0 0 65 48
1
end_operator
begin_operator
down f69 f54
1
2584 0
1
0 0 65 49
1
end_operator
begin_operator
down f69 f55
1
2609 0
1
0 0 65 50
1
end_operator
begin_operator
down f69 f56
1
2633 0
1
0 0 65 51
1
end_operator
begin_operator
down f69 f57
1
2656 0
1
0 0 65 52
1
end_operator
begin_operator
down f69 f58
1
2678 0
1
0 0 65 53
1
end_operator
begin_operator
down f69 f59
1
2699 0
1
0 0 65 54
1
end_operator
begin_operator
down f69 f6
1
2770 0
1
0 0 65 55
1
end_operator
begin_operator
down f69 f60
1
2793 0
1
0 0 65 56
1
end_operator
begin_operator
down f69 f61
1
2812 0
1
0 0 65 57
1
end_operator
begin_operator
down f69 f62
1
2830 0
1
0 0 65 58
1
end_operator
begin_operator
down f69 f63
1
2847 0
1
0 0 65 59
1
end_operator
begin_operator
down f69 f64
1
2863 0
1
0 0 65 60
1
end_operator
begin_operator
down f69 f65
1
2878 0
1
0 0 65 61
1
end_operator
begin_operator
down f69 f66
1
2892 0
1
0 0 65 62
1
end_operator
begin_operator
down f69 f67
1
2905 0
1
0 0 65 63
1
end_operator
begin_operator
down f69 f68
1
2917 0
1
0 0 65 64
1
end_operator
begin_operator
down f69 f7
1
2999 0
1
0 0 65 66
1
end_operator
begin_operator
down f69 f8
1
3127 0
1
0 0 65 77
1
end_operator
begin_operator
down f69 f9
1
3199 0
1
0 0 65 79
1
end_operator
begin_operator
down f7 f1
1
116 0
1
0 0 66 0
1
end_operator
begin_operator
down f7 f2
1
849 0
1
0 0 66 11
1
end_operator
begin_operator
down f7 f3
1
1481 0
1
0 0 66 22
1
end_operator
begin_operator
down f7 f4
1
2012 0
1
0 0 66 33
1
end_operator
begin_operator
down f7 f5
1
2442 0
1
0 0 66 44
1
end_operator
begin_operator
down f7 f6
1
2771 0
1
0 0 66 55
1
end_operator
begin_operator
down f70 f1
1
117 0
1
0 0 67 0
1
end_operator
begin_operator
down f70 f10
1
189 0
1
0 0 67 1
1
end_operator
begin_operator
down f70 f11
1
258 0
1
0 0 67 2
1
end_operator
begin_operator
down f70 f12
1
326 0
1
0 0 67 3
1
end_operator
begin_operator
down f70 f13
1
393 0
1
0 0 67 4
1
end_operator
begin_operator
down f70 f14
1
459 0
1
0 0 67 5
1
end_operator
begin_operator
down f70 f15
1
524 0
1
0 0 67 6
1
end_operator
begin_operator
down f70 f16
1
588 0
1
0 0 67 7
1
end_operator
begin_operator
down f70 f17
1
651 0
1
0 0 67 8
1
end_operator
begin_operator
down f70 f18
1
713 0
1
0 0 67 9
1
end_operator
begin_operator
down f70 f19
1
774 0
1
0 0 67 10
1
end_operator
begin_operator
down f70 f2
1
850 0
1
0 0 67 11
1
end_operator
begin_operator
down f70 f20
1
912 0
1
0 0 67 12
1
end_operator
begin_operator
down f70 f21
1
971 0
1
0 0 67 13
1
end_operator
begin_operator
down f70 f22
1
1029 0
1
0 0 67 14
1
end_operator
begin_operator
down f70 f23
1
1086 0
1
0 0 67 15
1
end_operator
begin_operator
down f70 f24
1
1142 0
1
0 0 67 16
1
end_operator
begin_operator
down f70 f25
1
1197 0
1
0 0 67 17
1
end_operator
begin_operator
down f70 f26
1
1251 0
1
0 0 67 18
1
end_operator
begin_operator
down f70 f27
1
1304 0
1
0 0 67 19
1
end_operator
begin_operator
down f70 f28
1
1356 0
1
0 0 67 20
1
end_operator
begin_operator
down f70 f29
1
1407 0
1
0 0 67 21
1
end_operator
begin_operator
down f70 f3
1
1482 0
1
0 0 67 22
1
end_operator
begin_operator
down f70 f30
1
1534 0
1
0 0 67 23
1
end_operator
begin_operator
down f70 f31
1
1583 0
1
0 0 67 24
1
end_operator
begin_operator
down f70 f32
1
1631 0
1
0 0 67 25
1
end_operator
begin_operator
down f70 f33
1
1678 0
1
0 0 67 26
1
end_operator
begin_operator
down f70 f34
1
1724 0
1
0 0 67 27
1
end_operator
begin_operator
down f70 f35
1
1769 0
1
0 0 67 28
1
end_operator
begin_operator
down f70 f36
1
1813 0
1
0 0 67 29
1
end_operator
begin_operator
down f70 f37
1
1856 0
1
0 0 67 30
1
end_operator
begin_operator
down f70 f38
1
1898 0
1
0 0 67 31
1
end_operator
begin_operator
down f70 f39
1
1939 0
1
0 0 67 32
1
end_operator
begin_operator
down f70 f4
1
2013 0
1
0 0 67 33
1
end_operator
begin_operator
down f70 f40
1
2055 0
1
0 0 67 34
1
end_operator
begin_operator
down f70 f41
1
2094 0
1
0 0 67 35
1
end_operator
begin_operator
down f70 f42
1
2132 0
1
0 0 67 36
1
end_operator
begin_operator
down f70 f43
1
2169 0
1
0 0 67 37
1
end_operator
begin_operator
down f70 f44
1
2205 0
1
0 0 67 38
1
end_operator
begin_operator
down f70 f45
1
2240 0
1
0 0 67 39
1
end_operator
begin_operator
down f70 f46
1
2274 0
1
0 0 67 40
1
end_operator
begin_operator
down f70 f47
1
2307 0
1
0 0 67 41
1
end_operator
begin_operator
down f70 f48
1
2339 0
1
0 0 67 42
1
end_operator
begin_operator
down f70 f49
1
2370 0
1
0 0 67 43
1
end_operator
begin_operator
down f70 f5
1
2443 0
1
0 0 67 44
1
end_operator
begin_operator
down f70 f50
1
2475 0
1
0 0 67 45
1
end_operator
begin_operator
down f70 f51
1
2504 0
1
0 0 67 46
1
end_operator
begin_operator
down f70 f52
1
2532 0
1
0 0 67 47
1
end_operator
begin_operator
down f70 f53
1
2559 0
1
0 0 67 48
1
end_operator
begin_operator
down f70 f54
1
2585 0
1
0 0 67 49
1
end_operator
begin_operator
down f70 f55
1
2610 0
1
0 0 67 50
1
end_operator
begin_operator
down f70 f56
1
2634 0
1
0 0 67 51
1
end_operator
begin_operator
down f70 f57
1
2657 0
1
0 0 67 52
1
end_operator
begin_operator
down f70 f58
1
2679 0
1
0 0 67 53
1
end_operator
begin_operator
down f70 f59
1
2700 0
1
0 0 67 54
1
end_operator
begin_operator
down f70 f6
1
2772 0
1
0 0 67 55
1
end_operator
begin_operator
down f70 f60
1
2794 0
1
0 0 67 56
1
end_operator
begin_operator
down f70 f61
1
2813 0
1
0 0 67 57
1
end_operator
begin_operator
down f70 f62
1
2831 0
1
0 0 67 58
1
end_operator
begin_operator
down f70 f63
1
2848 0
1
0 0 67 59
1
end_operator
begin_operator
down f70 f64
1
2864 0
1
0 0 67 60
1
end_operator
begin_operator
down f70 f65
1
2879 0
1
0 0 67 61
1
end_operator
begin_operator
down f70 f66
1
2893 0
1
0 0 67 62
1
end_operator
begin_operator
down f70 f67
1
2906 0
1
0 0 67 63
1
end_operator
begin_operator
down f70 f68
1
2918 0
1
0 0 67 64
1
end_operator
begin_operator
down f70 f69
1
2929 0
1
0 0 67 65
1
end_operator
begin_operator
down f70 f7
1
3000 0
1
0 0 67 66
1
end_operator
begin_operator
down f70 f8
1
3128 0
1
0 0 67 77
1
end_operator
begin_operator
down f70 f9
1
3200 0
1
0 0 67 79
1
end_operator
begin_operator
down f71 f1
1
118 0
1
0 0 68 0
1
end_operator
begin_operator
down f71 f10
1
190 0
1
0 0 68 1
1
end_operator
begin_operator
down f71 f11
1
259 0
1
0 0 68 2
1
end_operator
begin_operator
down f71 f12
1
327 0
1
0 0 68 3
1
end_operator
begin_operator
down f71 f13
1
394 0
1
0 0 68 4
1
end_operator
begin_operator
down f71 f14
1
460 0
1
0 0 68 5
1
end_operator
begin_operator
down f71 f15
1
525 0
1
0 0 68 6
1
end_operator
begin_operator
down f71 f16
1
589 0
1
0 0 68 7
1
end_operator
begin_operator
down f71 f17
1
652 0
1
0 0 68 8
1
end_operator
begin_operator
down f71 f18
1
714 0
1
0 0 68 9
1
end_operator
begin_operator
down f71 f19
1
775 0
1
0 0 68 10
1
end_operator
begin_operator
down f71 f2
1
851 0
1
0 0 68 11
1
end_operator
begin_operator
down f71 f20
1
913 0
1
0 0 68 12
1
end_operator
begin_operator
down f71 f21
1
972 0
1
0 0 68 13
1
end_operator
begin_operator
down f71 f22
1
1030 0
1
0 0 68 14
1
end_operator
begin_operator
down f71 f23
1
1087 0
1
0 0 68 15
1
end_operator
begin_operator
down f71 f24
1
1143 0
1
0 0 68 16
1
end_operator
begin_operator
down f71 f25
1
1198 0
1
0 0 68 17
1
end_operator
begin_operator
down f71 f26
1
1252 0
1
0 0 68 18
1
end_operator
begin_operator
down f71 f27
1
1305 0
1
0 0 68 19
1
end_operator
begin_operator
down f71 f28
1
1357 0
1
0 0 68 20
1
end_operator
begin_operator
down f71 f29
1
1408 0
1
0 0 68 21
1
end_operator
begin_operator
down f71 f3
1
1483 0
1
0 0 68 22
1
end_operator
begin_operator
down f71 f30
1
1535 0
1
0 0 68 23
1
end_operator
begin_operator
down f71 f31
1
1584 0
1
0 0 68 24
1
end_operator
begin_operator
down f71 f32
1
1632 0
1
0 0 68 25
1
end_operator
begin_operator
down f71 f33
1
1679 0
1
0 0 68 26
1
end_operator
begin_operator
down f71 f34
1
1725 0
1
0 0 68 27
1
end_operator
begin_operator
down f71 f35
1
1770 0
1
0 0 68 28
1
end_operator
begin_operator
down f71 f36
1
1814 0
1
0 0 68 29
1
end_operator
begin_operator
down f71 f37
1
1857 0
1
0 0 68 30
1
end_operator
begin_operator
down f71 f38
1
1899 0
1
0 0 68 31
1
end_operator
begin_operator
down f71 f39
1
1940 0
1
0 0 68 32
1
end_operator
begin_operator
down f71 f4
1
2014 0
1
0 0 68 33
1
end_operator
begin_operator
down f71 f40
1
2056 0
1
0 0 68 34
1
end_operator
begin_operator
down f71 f41
1
2095 0
1
0 0 68 35
1
end_operator
begin_operator
down f71 f42
1
2133 0
1
0 0 68 36
1
end_operator
begin_operator
down f71 f43
1
2170 0
1
0 0 68 37
1
end_operator
begin_operator
down f71 f44
1
2206 0
1
0 0 68 38
1
end_operator
begin_operator
down f71 f45
1
2241 0
1
0 0 68 39
1
end_operator
begin_operator
down f71 f46
1
2275 0
1
0 0 68 40
1
end_operator
begin_operator
down f71 f47
1
2308 0
1
0 0 68 41
1
end_operator
begin_operator
down f71 f48
1
2340 0
1
0 0 68 42
1
end_operator
begin_operator
down f71 f49
1
2371 0
1
0 0 68 43
1
end_operator
begin_operator
down f71 f5
1
2444 0
1
0 0 68 44
1
end_operator
begin_operator
down f71 f50
1
2476 0
1
0 0 68 45
1
end_operator
begin_operator
down f71 f51
1
2505 0
1
0 0 68 46
1
end_operator
begin_operator
down f71 f52
1
2533 0
1
0 0 68 47
1
end_operator
begin_operator
down f71 f53
1
2560 0
1
0 0 68 48
1
end_operator
begin_operator
down f71 f54
1
2586 0
1
0 0 68 49
1
end_operator
begin_operator
down f71 f55
1
2611 0
1
0 0 68 50
1
end_operator
begin_operator
down f71 f56
1
2635 0
1
0 0 68 51
1
end_operator
begin_operator
down f71 f57
1
2658 0
1
0 0 68 52
1
end_operator
begin_operator
down f71 f58
1
2680 0
1
0 0 68 53
1
end_operator
begin_operator
down f71 f59
1
2701 0
1
0 0 68 54
1
end_operator
begin_operator
down f71 f6
1
2773 0
1
0 0 68 55
1
end_operator
begin_operator
down f71 f60
1
2795 0
1
0 0 68 56
1
end_operator
begin_operator
down f71 f61
1
2814 0
1
0 0 68 57
1
end_operator
begin_operator
down f71 f62
1
2832 0
1
0 0 68 58
1
end_operator
begin_operator
down f71 f63
1
2849 0
1
0 0 68 59
1
end_operator
begin_operator
down f71 f64
1
2865 0
1
0 0 68 60
1
end_operator
begin_operator
down f71 f65
1
2880 0
1
0 0 68 61
1
end_operator
begin_operator
down f71 f66
1
2894 0
1
0 0 68 62
1
end_operator
begin_operator
down f71 f67
1
2907 0
1
0 0 68 63
1
end_operator
begin_operator
down f71 f68
1
2919 0
1
0 0 68 64
1
end_operator
begin_operator
down f71 f69
1
2930 0
1
0 0 68 65
1
end_operator
begin_operator
down f71 f7
1
3001 0
1
0 0 68 66
1
end_operator
begin_operator
down f71 f70
1
3013 0
1
0 0 68 67
1
end_operator
begin_operator
down f71 f8
1
3129 0
1
0 0 68 77
1
end_operator
begin_operator
down f71 f9
1
3201 0
1
0 0 68 79
1
end_operator
begin_operator
down f72 f1
1
119 0
1
0 0 69 0
1
end_operator
begin_operator
down f72 f10
1
191 0
1
0 0 69 1
1
end_operator
begin_operator
down f72 f11
1
260 0
1
0 0 69 2
1
end_operator
begin_operator
down f72 f12
1
328 0
1
0 0 69 3
1
end_operator
begin_operator
down f72 f13
1
395 0
1
0 0 69 4
1
end_operator
begin_operator
down f72 f14
1
461 0
1
0 0 69 5
1
end_operator
begin_operator
down f72 f15
1
526 0
1
0 0 69 6
1
end_operator
begin_operator
down f72 f16
1
590 0
1
0 0 69 7
1
end_operator
begin_operator
down f72 f17
1
653 0
1
0 0 69 8
1
end_operator
begin_operator
down f72 f18
1
715 0
1
0 0 69 9
1
end_operator
begin_operator
down f72 f19
1
776 0
1
0 0 69 10
1
end_operator
begin_operator
down f72 f2
1
852 0
1
0 0 69 11
1
end_operator
begin_operator
down f72 f20
1
914 0
1
0 0 69 12
1
end_operator
begin_operator
down f72 f21
1
973 0
1
0 0 69 13
1
end_operator
begin_operator
down f72 f22
1
1031 0
1
0 0 69 14
1
end_operator
begin_operator
down f72 f23
1
1088 0
1
0 0 69 15
1
end_operator
begin_operator
down f72 f24
1
1144 0
1
0 0 69 16
1
end_operator
begin_operator
down f72 f25
1
1199 0
1
0 0 69 17
1
end_operator
begin_operator
down f72 f26
1
1253 0
1
0 0 69 18
1
end_operator
begin_operator
down f72 f27
1
1306 0
1
0 0 69 19
1
end_operator
begin_operator
down f72 f28
1
1358 0
1
0 0 69 20
1
end_operator
begin_operator
down f72 f29
1
1409 0
1
0 0 69 21
1
end_operator
begin_operator
down f72 f3
1
1484 0
1
0 0 69 22
1
end_operator
begin_operator
down f72 f30
1
1536 0
1
0 0 69 23
1
end_operator
begin_operator
down f72 f31
1
1585 0
1
0 0 69 24
1
end_operator
begin_operator
down f72 f32
1
1633 0
1
0 0 69 25
1
end_operator
begin_operator
down f72 f33
1
1680 0
1
0 0 69 26
1
end_operator
begin_operator
down f72 f34
1
1726 0
1
0 0 69 27
1
end_operator
begin_operator
down f72 f35
1
1771 0
1
0 0 69 28
1
end_operator
begin_operator
down f72 f36
1
1815 0
1
0 0 69 29
1
end_operator
begin_operator
down f72 f37
1
1858 0
1
0 0 69 30
1
end_operator
begin_operator
down f72 f38
1
1900 0
1
0 0 69 31
1
end_operator
begin_operator
down f72 f39
1
1941 0
1
0 0 69 32
1
end_operator
begin_operator
down f72 f4
1
2015 0
1
0 0 69 33
1
end_operator
begin_operator
down f72 f40
1
2057 0
1
0 0 69 34
1
end_operator
begin_operator
down f72 f41
1
2096 0
1
0 0 69 35
1
end_operator
begin_operator
down f72 f42
1
2134 0
1
0 0 69 36
1
end_operator
begin_operator
down f72 f43
1
2171 0
1
0 0 69 37
1
end_operator
begin_operator
down f72 f44
1
2207 0
1
0 0 69 38
1
end_operator
begin_operator
down f72 f45
1
2242 0
1
0 0 69 39
1
end_operator
begin_operator
down f72 f46
1
2276 0
1
0 0 69 40
1
end_operator
begin_operator
down f72 f47
1
2309 0
1
0 0 69 41
1
end_operator
begin_operator
down f72 f48
1
2341 0
1
0 0 69 42
1
end_operator
begin_operator
down f72 f49
1
2372 0
1
0 0 69 43
1
end_operator
begin_operator
down f72 f5
1
2445 0
1
0 0 69 44
1
end_operator
begin_operator
down f72 f50
1
2477 0
1
0 0 69 45
1
end_operator
begin_operator
down f72 f51
1
2506 0
1
0 0 69 46
1
end_operator
begin_operator
down f72 f52
1
2534 0
1
0 0 69 47
1
end_operator
begin_operator
down f72 f53
1
2561 0
1
0 0 69 48
1
end_operator
begin_operator
down f72 f54
1
2587 0
1
0 0 69 49
1
end_operator
begin_operator
down f72 f55
1
2612 0
1
0 0 69 50
1
end_operator
begin_operator
down f72 f56
1
2636 0
1
0 0 69 51
1
end_operator
begin_operator
down f72 f57
1
2659 0
1
0 0 69 52
1
end_operator
begin_operator
down f72 f58
1
2681 0
1
0 0 69 53
1
end_operator
begin_operator
down f72 f59
1
2702 0
1
0 0 69 54
1
end_operator
begin_operator
down f72 f6
1
2774 0
1
0 0 69 55
1
end_operator
begin_operator
down f72 f60
1
2796 0
1
0 0 69 56
1
end_operator
begin_operator
down f72 f61
1
2815 0
1
0 0 69 57
1
end_operator
begin_operator
down f72 f62
1
2833 0
1
0 0 69 58
1
end_operator
begin_operator
down f72 f63
1
2850 0
1
0 0 69 59
1
end_operator
begin_operator
down f72 f64
1
2866 0
1
0 0 69 60
1
end_operator
begin_operator
down f72 f65
1
2881 0
1
0 0 69 61
1
end_operator
begin_operator
down f72 f66
1
2895 0
1
0 0 69 62
1
end_operator
begin_operator
down f72 f67
1
2908 0
1
0 0 69 63
1
end_operator
begin_operator
down f72 f68
1
2920 0
1
0 0 69 64
1
end_operator
begin_operator
down f72 f69
1
2931 0
1
0 0 69 65
1
end_operator
begin_operator
down f72 f7
1
3002 0
1
0 0 69 66
1
end_operator
begin_operator
down f72 f70
1
3014 0
1
0 0 69 67
1
end_operator
begin_operator
down f72 f71
1
3023 0
1
0 0 69 68
1
end_operator
begin_operator
down f72 f8
1
3130 0
1
0 0 69 77
1
end_operator
begin_operator
down f72 f9
1
3202 0
1
0 0 69 79
1
end_operator
begin_operator
down f73 f1
1
120 0
1
0 0 70 0
1
end_operator
begin_operator
down f73 f10
1
192 0
1
0 0 70 1
1
end_operator
begin_operator
down f73 f11
1
261 0
1
0 0 70 2
1
end_operator
begin_operator
down f73 f12
1
329 0
1
0 0 70 3
1
end_operator
begin_operator
down f73 f13
1
396 0
1
0 0 70 4
1
end_operator
begin_operator
down f73 f14
1
462 0
1
0 0 70 5
1
end_operator
begin_operator
down f73 f15
1
527 0
1
0 0 70 6
1
end_operator
begin_operator
down f73 f16
1
591 0
1
0 0 70 7
1
end_operator
begin_operator
down f73 f17
1
654 0
1
0 0 70 8
1
end_operator
begin_operator
down f73 f18
1
716 0
1
0 0 70 9
1
end_operator
begin_operator
down f73 f19
1
777 0
1
0 0 70 10
1
end_operator
begin_operator
down f73 f2
1
853 0
1
0 0 70 11
1
end_operator
begin_operator
down f73 f20
1
915 0
1
0 0 70 12
1
end_operator
begin_operator
down f73 f21
1
974 0
1
0 0 70 13
1
end_operator
begin_operator
down f73 f22
1
1032 0
1
0 0 70 14
1
end_operator
begin_operator
down f73 f23
1
1089 0
1
0 0 70 15
1
end_operator
begin_operator
down f73 f24
1
1145 0
1
0 0 70 16
1
end_operator
begin_operator
down f73 f25
1
1200 0
1
0 0 70 17
1
end_operator
begin_operator
down f73 f26
1
1254 0
1
0 0 70 18
1
end_operator
begin_operator
down f73 f27
1
1307 0
1
0 0 70 19
1
end_operator
begin_operator
down f73 f28
1
1359 0
1
0 0 70 20
1
end_operator
begin_operator
down f73 f29
1
1410 0
1
0 0 70 21
1
end_operator
begin_operator
down f73 f3
1
1485 0
1
0 0 70 22
1
end_operator
begin_operator
down f73 f30
1
1537 0
1
0 0 70 23
1
end_operator
begin_operator
down f73 f31
1
1586 0
1
0 0 70 24
1
end_operator
begin_operator
down f73 f32
1
1634 0
1
0 0 70 25
1
end_operator
begin_operator
down f73 f33
1
1681 0
1
0 0 70 26
1
end_operator
begin_operator
down f73 f34
1
1727 0
1
0 0 70 27
1
end_operator
begin_operator
down f73 f35
1
1772 0
1
0 0 70 28
1
end_operator
begin_operator
down f73 f36
1
1816 0
1
0 0 70 29
1
end_operator
begin_operator
down f73 f37
1
1859 0
1
0 0 70 30
1
end_operator
begin_operator
down f73 f38
1
1901 0
1
0 0 70 31
1
end_operator
begin_operator
down f73 f39
1
1942 0
1
0 0 70 32
1
end_operator
begin_operator
down f73 f4
1
2016 0
1
0 0 70 33
1
end_operator
begin_operator
down f73 f40
1
2058 0
1
0 0 70 34
1
end_operator
begin_operator
down f73 f41
1
2097 0
1
0 0 70 35
1
end_operator
begin_operator
down f73 f42
1
2135 0
1
0 0 70 36
1
end_operator
begin_operator
down f73 f43
1
2172 0
1
0 0 70 37
1
end_operator
begin_operator
down f73 f44
1
2208 0
1
0 0 70 38
1
end_operator
begin_operator
down f73 f45
1
2243 0
1
0 0 70 39
1
end_operator
begin_operator
down f73 f46
1
2277 0
1
0 0 70 40
1
end_operator
begin_operator
down f73 f47
1
2310 0
1
0 0 70 41
1
end_operator
begin_operator
down f73 f48
1
2342 0
1
0 0 70 42
1
end_operator
begin_operator
down f73 f49
1
2373 0
1
0 0 70 43
1
end_operator
begin_operator
down f73 f5
1
2446 0
1
0 0 70 44
1
end_operator
begin_operator
down f73 f50
1
2478 0
1
0 0 70 45
1
end_operator
begin_operator
down f73 f51
1
2507 0
1
0 0 70 46
1
end_operator
begin_operator
down f73 f52
1
2535 0
1
0 0 70 47
1
end_operator
begin_operator
down f73 f53
1
2562 0
1
0 0 70 48
1
end_operator
begin_operator
down f73 f54
1
2588 0
1
0 0 70 49
1
end_operator
begin_operator
down f73 f55
1
2613 0
1
0 0 70 50
1
end_operator
begin_operator
down f73 f56
1
2637 0
1
0 0 70 51
1
end_operator
begin_operator
down f73 f57
1
2660 0
1
0 0 70 52
1
end_operator
begin_operator
down f73 f58
1
2682 0
1
0 0 70 53
1
end_operator
begin_operator
down f73 f59
1
2703 0
1
0 0 70 54
1
end_operator
begin_operator
down f73 f6
1
2775 0
1
0 0 70 55
1
end_operator
begin_operator
down f73 f60
1
2797 0
1
0 0 70 56
1
end_operator
begin_operator
down f73 f61
1
2816 0
1
0 0 70 57
1
end_operator
begin_operator
down f73 f62
1
2834 0
1
0 0 70 58
1
end_operator
begin_operator
down f73 f63
1
2851 0
1
0 0 70 59
1
end_operator
begin_operator
down f73 f64
1
2867 0
1
0 0 70 60
1
end_operator
begin_operator
down f73 f65
1
2882 0
1
0 0 70 61
1
end_operator
begin_operator
down f73 f66
1
2896 0
1
0 0 70 62
1
end_operator
begin_operator
down f73 f67
1
2909 0
1
0 0 70 63
1
end_operator
begin_operator
down f73 f68
1
2921 0
1
0 0 70 64
1
end_operator
begin_operator
down f73 f69
1
2932 0
1
0 0 70 65
1
end_operator
begin_operator
down f73 f7
1
3003 0
1
0 0 70 66
1
end_operator
begin_operator
down f73 f70
1
3015 0
1
0 0 70 67
1
end_operator
begin_operator
down f73 f71
1
3024 0
1
0 0 70 68
1
end_operator
begin_operator
down f73 f72
1
3032 0
1
0 0 70 69
1
end_operator
begin_operator
down f73 f8
1
3131 0
1
0 0 70 77
1
end_operator
begin_operator
down f73 f9
1
3203 0
1
0 0 70 79
1
end_operator
begin_operator
down f74 f1
1
121 0
1
0 0 71 0
1
end_operator
begin_operator
down f74 f10
1
193 0
1
0 0 71 1
1
end_operator
begin_operator
down f74 f11
1
262 0
1
0 0 71 2
1
end_operator
begin_operator
down f74 f12
1
330 0
1
0 0 71 3
1
end_operator
begin_operator
down f74 f13
1
397 0
1
0 0 71 4
1
end_operator
begin_operator
down f74 f14
1
463 0
1
0 0 71 5
1
end_operator
begin_operator
down f74 f15
1
528 0
1
0 0 71 6
1
end_operator
begin_operator
down f74 f16
1
592 0
1
0 0 71 7
1
end_operator
begin_operator
down f74 f17
1
655 0
1
0 0 71 8
1
end_operator
begin_operator
down f74 f18
1
717 0
1
0 0 71 9
1
end_operator
begin_operator
down f74 f19
1
778 0
1
0 0 71 10
1
end_operator
begin_operator
down f74 f2
1
854 0
1
0 0 71 11
1
end_operator
begin_operator
down f74 f20
1
916 0
1
0 0 71 12
1
end_operator
begin_operator
down f74 f21
1
975 0
1
0 0 71 13
1
end_operator
begin_operator
down f74 f22
1
1033 0
1
0 0 71 14
1
end_operator
begin_operator
down f74 f23
1
1090 0
1
0 0 71 15
1
end_operator
begin_operator
down f74 f24
1
1146 0
1
0 0 71 16
1
end_operator
begin_operator
down f74 f25
1
1201 0
1
0 0 71 17
1
end_operator
begin_operator
down f74 f26
1
1255 0
1
0 0 71 18
1
end_operator
begin_operator
down f74 f27
1
1308 0
1
0 0 71 19
1
end_operator
begin_operator
down f74 f28
1
1360 0
1
0 0 71 20
1
end_operator
begin_operator
down f74 f29
1
1411 0
1
0 0 71 21
1
end_operator
begin_operator
down f74 f3
1
1486 0
1
0 0 71 22
1
end_operator
begin_operator
down f74 f30
1
1538 0
1
0 0 71 23
1
end_operator
begin_operator
down f74 f31
1
1587 0
1
0 0 71 24
1
end_operator
begin_operator
down f74 f32
1
1635 0
1
0 0 71 25
1
end_operator
begin_operator
down f74 f33
1
1682 0
1
0 0 71 26
1
end_operator
begin_operator
down f74 f34
1
1728 0
1
0 0 71 27
1
end_operator
begin_operator
down f74 f35
1
1773 0
1
0 0 71 28
1
end_operator
begin_operator
down f74 f36
1
1817 0
1
0 0 71 29
1
end_operator
begin_operator
down f74 f37
1
1860 0
1
0 0 71 30
1
end_operator
begin_operator
down f74 f38
1
1902 0
1
0 0 71 31
1
end_operator
begin_operator
down f74 f39
1
1943 0
1
0 0 71 32
1
end_operator
begin_operator
down f74 f4
1
2017 0
1
0 0 71 33
1
end_operator
begin_operator
down f74 f40
1
2059 0
1
0 0 71 34
1
end_operator
begin_operator
down f74 f41
1
2098 0
1
0 0 71 35
1
end_operator
begin_operator
down f74 f42
1
2136 0
1
0 0 71 36
1
end_operator
begin_operator
down f74 f43
1
2173 0
1
0 0 71 37
1
end_operator
begin_operator
down f74 f44
1
2209 0
1
0 0 71 38
1
end_operator
begin_operator
down f74 f45
1
2244 0
1
0 0 71 39
1
end_operator
begin_operator
down f74 f46
1
2278 0
1
0 0 71 40
1
end_operator
begin_operator
down f74 f47
1
2311 0
1
0 0 71 41
1
end_operator
begin_operator
down f74 f48
1
2343 0
1
0 0 71 42
1
end_operator
begin_operator
down f74 f49
1
2374 0
1
0 0 71 43
1
end_operator
begin_operator
down f74 f5
1
2447 0
1
0 0 71 44
1
end_operator
begin_operator
down f74 f50
1
2479 0
1
0 0 71 45
1
end_operator
begin_operator
down f74 f51
1
2508 0
1
0 0 71 46
1
end_operator
begin_operator
down f74 f52
1
2536 0
1
0 0 71 47
1
end_operator
begin_operator
down f74 f53
1
2563 0
1
0 0 71 48
1
end_operator
begin_operator
down f74 f54
1
2589 0
1
0 0 71 49
1
end_operator
begin_operator
down f74 f55
1
2614 0
1
0 0 71 50
1
end_operator
begin_operator
down f74 f56
1
2638 0
1
0 0 71 51
1
end_operator
begin_operator
down f74 f57
1
2661 0
1
0 0 71 52
1
end_operator
begin_operator
down f74 f58
1
2683 0
1
0 0 71 53
1
end_operator
begin_operator
down f74 f59
1
2704 0
1
0 0 71 54
1
end_operator
begin_operator
down f74 f6
1
2776 0
1
0 0 71 55
1
end_operator
begin_operator
down f74 f60
1
2798 0
1
0 0 71 56
1
end_operator
begin_operator
down f74 f61
1
2817 0
1
0 0 71 57
1
end_operator
begin_operator
down f74 f62
1
2835 0
1
0 0 71 58
1
end_operator
begin_operator
down f74 f63
1
2852 0
1
0 0 71 59
1
end_operator
begin_operator
down f74 f64
1
2868 0
1
0 0 71 60
1
end_operator
begin_operator
down f74 f65
1
2883 0
1
0 0 71 61
1
end_operator
begin_operator
down f74 f66
1
2897 0
1
0 0 71 62
1
end_operator
begin_operator
down f74 f67
1
2910 0
1
0 0 71 63
1
end_operator
begin_operator
down f74 f68
1
2922 0
1
0 0 71 64
1
end_operator
begin_operator
down f74 f69
1
2933 0
1
0 0 71 65
1
end_operator
begin_operator
down f74 f7
1
3004 0
1
0 0 71 66
1
end_operator
begin_operator
down f74 f70
1
3016 0
1
0 0 71 67
1
end_operator
begin_operator
down f74 f71
1
3025 0
1
0 0 71 68
1
end_operator
begin_operator
down f74 f72
1
3033 0
1
0 0 71 69
1
end_operator
begin_operator
down f74 f73
1
3040 0
1
0 0 71 70
1
end_operator
begin_operator
down f74 f8
1
3132 0
1
0 0 71 77
1
end_operator
begin_operator
down f74 f9
1
3204 0
1
0 0 71 79
1
end_operator
begin_operator
down f75 f1
1
122 0
1
0 0 72 0
1
end_operator
begin_operator
down f75 f10
1
194 0
1
0 0 72 1
1
end_operator
begin_operator
down f75 f11
1
263 0
1
0 0 72 2
1
end_operator
begin_operator
down f75 f12
1
331 0
1
0 0 72 3
1
end_operator
begin_operator
down f75 f13
1
398 0
1
0 0 72 4
1
end_operator
begin_operator
down f75 f14
1
464 0
1
0 0 72 5
1
end_operator
begin_operator
down f75 f15
1
529 0
1
0 0 72 6
1
end_operator
begin_operator
down f75 f16
1
593 0
1
0 0 72 7
1
end_operator
begin_operator
down f75 f17
1
656 0
1
0 0 72 8
1
end_operator
begin_operator
down f75 f18
1
718 0
1
0 0 72 9
1
end_operator
begin_operator
down f75 f19
1
779 0
1
0 0 72 10
1
end_operator
begin_operator
down f75 f2
1
855 0
1
0 0 72 11
1
end_operator
begin_operator
down f75 f20
1
917 0
1
0 0 72 12
1
end_operator
begin_operator
down f75 f21
1
976 0
1
0 0 72 13
1
end_operator
begin_operator
down f75 f22
1
1034 0
1
0 0 72 14
1
end_operator
begin_operator
down f75 f23
1
1091 0
1
0 0 72 15
1
end_operator
begin_operator
down f75 f24
1
1147 0
1
0 0 72 16
1
end_operator
begin_operator
down f75 f25
1
1202 0
1
0 0 72 17
1
end_operator
begin_operator
down f75 f26
1
1256 0
1
0 0 72 18
1
end_operator
begin_operator
down f75 f27
1
1309 0
1
0 0 72 19
1
end_operator
begin_operator
down f75 f28
1
1361 0
1
0 0 72 20
1
end_operator
begin_operator
down f75 f29
1
1412 0
1
0 0 72 21
1
end_operator
begin_operator
down f75 f3
1
1487 0
1
0 0 72 22
1
end_operator
begin_operator
down f75 f30
1
1539 0
1
0 0 72 23
1
end_operator
begin_operator
down f75 f31
1
1588 0
1
0 0 72 24
1
end_operator
begin_operator
down f75 f32
1
1636 0
1
0 0 72 25
1
end_operator
begin_operator
down f75 f33
1
1683 0
1
0 0 72 26
1
end_operator
begin_operator
down f75 f34
1
1729 0
1
0 0 72 27
1
end_operator
begin_operator
down f75 f35
1
1774 0
1
0 0 72 28
1
end_operator
begin_operator
down f75 f36
1
1818 0
1
0 0 72 29
1
end_operator
begin_operator
down f75 f37
1
1861 0
1
0 0 72 30
1
end_operator
begin_operator
down f75 f38
1
1903 0
1
0 0 72 31
1
end_operator
begin_operator
down f75 f39
1
1944 0
1
0 0 72 32
1
end_operator
begin_operator
down f75 f4
1
2018 0
1
0 0 72 33
1
end_operator
begin_operator
down f75 f40
1
2060 0
1
0 0 72 34
1
end_operator
begin_operator
down f75 f41
1
2099 0
1
0 0 72 35
1
end_operator
begin_operator
down f75 f42
1
2137 0
1
0 0 72 36
1
end_operator
begin_operator
down f75 f43
1
2174 0
1
0 0 72 37
1
end_operator
begin_operator
down f75 f44
1
2210 0
1
0 0 72 38
1
end_operator
begin_operator
down f75 f45
1
2245 0
1
0 0 72 39
1
end_operator
begin_operator
down f75 f46
1
2279 0
1
0 0 72 40
1
end_operator
begin_operator
down f75 f47
1
2312 0
1
0 0 72 41
1
end_operator
begin_operator
down f75 f48
1
2344 0
1
0 0 72 42
1
end_operator
begin_operator
down f75 f49
1
2375 0
1
0 0 72 43
1
end_operator
begin_operator
down f75 f5
1
2448 0
1
0 0 72 44
1
end_operator
begin_operator
down f75 f50
1
2480 0
1
0 0 72 45
1
end_operator
begin_operator
down f75 f51
1
2509 0
1
0 0 72 46
1
end_operator
begin_operator
down f75 f52
1
2537 0
1
0 0 72 47
1
end_operator
begin_operator
down f75 f53
1
2564 0
1
0 0 72 48
1
end_operator
begin_operator
down f75 f54
1
2590 0
1
0 0 72 49
1
end_operator
begin_operator
down f75 f55
1
2615 0
1
0 0 72 50
1
end_operator
begin_operator
down f75 f56
1
2639 0
1
0 0 72 51
1
end_operator
begin_operator
down f75 f57
1
2662 0
1
0 0 72 52
1
end_operator
begin_operator
down f75 f58
1
2684 0
1
0 0 72 53
1
end_operator
begin_operator
down f75 f59
1
2705 0
1
0 0 72 54
1
end_operator
begin_operator
down f75 f6
1
2777 0
1
0 0 72 55
1
end_operator
begin_operator
down f75 f60
1
2799 0
1
0 0 72 56
1
end_operator
begin_operator
down f75 f61
1
2818 0
1
0 0 72 57
1
end_operator
begin_operator
down f75 f62
1
2836 0
1
0 0 72 58
1
end_operator
begin_operator
down f75 f63
1
2853 0
1
0 0 72 59
1
end_operator
begin_operator
down f75 f64
1
2869 0
1
0 0 72 60
1
end_operator
begin_operator
down f75 f65
1
2884 0
1
0 0 72 61
1
end_operator
begin_operator
down f75 f66
1
2898 0
1
0 0 72 62
1
end_operator
begin_operator
down f75 f67
1
2911 0
1
0 0 72 63
1
end_operator
begin_operator
down f75 f68
1
2923 0
1
0 0 72 64
1
end_operator
begin_operator
down f75 f69
1
2934 0
1
0 0 72 65
1
end_operator
begin_operator
down f75 f7
1
3005 0
1
0 0 72 66
1
end_operator
begin_operator
down f75 f70
1
3017 0
1
0 0 72 67
1
end_operator
begin_operator
down f75 f71
1
3026 0
1
0 0 72 68
1
end_operator
begin_operator
down f75 f72
1
3034 0
1
0 0 72 69
1
end_operator
begin_operator
down f75 f73
1
3041 0
1
0 0 72 70
1
end_operator
begin_operator
down f75 f74
1
3047 0
1
0 0 72 71
1
end_operator
begin_operator
down f75 f8
1
3133 0
1
0 0 72 77
1
end_operator
begin_operator
down f75 f9
1
3205 0
1
0 0 72 79
1
end_operator
begin_operator
down f76 f1
1
123 0
1
0 0 73 0
1
end_operator
begin_operator
down f76 f10
1
195 0
1
0 0 73 1
1
end_operator
begin_operator
down f76 f11
1
264 0
1
0 0 73 2
1
end_operator
begin_operator
down f76 f12
1
332 0
1
0 0 73 3
1
end_operator
begin_operator
down f76 f13
1
399 0
1
0 0 73 4
1
end_operator
begin_operator
down f76 f14
1
465 0
1
0 0 73 5
1
end_operator
begin_operator
down f76 f15
1
530 0
1
0 0 73 6
1
end_operator
begin_operator
down f76 f16
1
594 0
1
0 0 73 7
1
end_operator
begin_operator
down f76 f17
1
657 0
1
0 0 73 8
1
end_operator
begin_operator
down f76 f18
1
719 0
1
0 0 73 9
1
end_operator
begin_operator
down f76 f19
1
780 0
1
0 0 73 10
1
end_operator
begin_operator
down f76 f2
1
856 0
1
0 0 73 11
1
end_operator
begin_operator
down f76 f20
1
918 0
1
0 0 73 12
1
end_operator
begin_operator
down f76 f21
1
977 0
1
0 0 73 13
1
end_operator
begin_operator
down f76 f22
1
1035 0
1
0 0 73 14
1
end_operator
begin_operator
down f76 f23
1
1092 0
1
0 0 73 15
1
end_operator
begin_operator
down f76 f24
1
1148 0
1
0 0 73 16
1
end_operator
begin_operator
down f76 f25
1
1203 0
1
0 0 73 17
1
end_operator
begin_operator
down f76 f26
1
1257 0
1
0 0 73 18
1
end_operator
begin_operator
down f76 f27
1
1310 0
1
0 0 73 19
1
end_operator
begin_operator
down f76 f28
1
1362 0
1
0 0 73 20
1
end_operator
begin_operator
down f76 f29
1
1413 0
1
0 0 73 21
1
end_operator
begin_operator
down f76 f3
1
1488 0
1
0 0 73 22
1
end_operator
begin_operator
down f76 f30
1
1540 0
1
0 0 73 23
1
end_operator
begin_operator
down f76 f31
1
1589 0
1
0 0 73 24
1
end_operator
begin_operator
down f76 f32
1
1637 0
1
0 0 73 25
1
end_operator
begin_operator
down f76 f33
1
1684 0
1
0 0 73 26
1
end_operator
begin_operator
down f76 f34
1
1730 0
1
0 0 73 27
1
end_operator
begin_operator
down f76 f35
1
1775 0
1
0 0 73 28
1
end_operator
begin_operator
down f76 f36
1
1819 0
1
0 0 73 29
1
end_operator
begin_operator
down f76 f37
1
1862 0
1
0 0 73 30
1
end_operator
begin_operator
down f76 f38
1
1904 0
1
0 0 73 31
1
end_operator
begin_operator
down f76 f39
1
1945 0
1
0 0 73 32
1
end_operator
begin_operator
down f76 f4
1
2019 0
1
0 0 73 33
1
end_operator
begin_operator
down f76 f40
1
2061 0
1
0 0 73 34
1
end_operator
begin_operator
down f76 f41
1
2100 0
1
0 0 73 35
1
end_operator
begin_operator
down f76 f42
1
2138 0
1
0 0 73 36
1
end_operator
begin_operator
down f76 f43
1
2175 0
1
0 0 73 37
1
end_operator
begin_operator
down f76 f44
1
2211 0
1
0 0 73 38
1
end_operator
begin_operator
down f76 f45
1
2246 0
1
0 0 73 39
1
end_operator
begin_operator
down f76 f46
1
2280 0
1
0 0 73 40
1
end_operator
begin_operator
down f76 f47
1
2313 0
1
0 0 73 41
1
end_operator
begin_operator
down f76 f48
1
2345 0
1
0 0 73 42
1
end_operator
begin_operator
down f76 f49
1
2376 0
1
0 0 73 43
1
end_operator
begin_operator
down f76 f5
1
2449 0
1
0 0 73 44
1
end_operator
begin_operator
down f76 f50
1
2481 0
1
0 0 73 45
1
end_operator
begin_operator
down f76 f51
1
2510 0
1
0 0 73 46
1
end_operator
begin_operator
down f76 f52
1
2538 0
1
0 0 73 47
1
end_operator
begin_operator
down f76 f53
1
2565 0
1
0 0 73 48
1
end_operator
begin_operator
down f76 f54
1
2591 0
1
0 0 73 49
1
end_operator
begin_operator
down f76 f55
1
2616 0
1
0 0 73 50
1
end_operator
begin_operator
down f76 f56
1
2640 0
1
0 0 73 51
1
end_operator
begin_operator
down f76 f57
1
2663 0
1
0 0 73 52
1
end_operator
begin_operator
down f76 f58
1
2685 0
1
0 0 73 53
1
end_operator
begin_operator
down f76 f59
1
2706 0
1
0 0 73 54
1
end_operator
begin_operator
down f76 f6
1
2778 0
1
0 0 73 55
1
end_operator
begin_operator
down f76 f60
1
2800 0
1
0 0 73 56
1
end_operator
begin_operator
down f76 f61
1
2819 0
1
0 0 73 57
1
end_operator
begin_operator
down f76 f62
1
2837 0
1
0 0 73 58
1
end_operator
begin_operator
down f76 f63
1
2854 0
1
0 0 73 59
1
end_operator
begin_operator
down f76 f64
1
2870 0
1
0 0 73 60
1
end_operator
begin_operator
down f76 f65
1
2885 0
1
0 0 73 61
1
end_operator
begin_operator
down f76 f66
1
2899 0
1
0 0 73 62
1
end_operator
begin_operator
down f76 f67
1
2912 0
1
0 0 73 63
1
end_operator
begin_operator
down f76 f68
1
2924 0
1
0 0 73 64
1
end_operator
begin_operator
down f76 f69
1
2935 0
1
0 0 73 65
1
end_operator
begin_operator
down f76 f7
1
3006 0
1
0 0 73 66
1
end_operator
begin_operator
down f76 f70
1
3018 0
1
0 0 73 67
1
end_operator
begin_operator
down f76 f71
1
3027 0
1
0 0 73 68
1
end_operator
begin_operator
down f76 f72
1
3035 0
1
0 0 73 69
1
end_operator
begin_operator
down f76 f73
1
3042 0
1
0 0 73 70
1
end_operator
begin_operator
down f76 f74
1
3048 0
1
0 0 73 71
1
end_operator
begin_operator
down f76 f75
1
3053 0
1
0 0 73 72
1
end_operator
begin_operator
down f76 f8
1
3134 0
1
0 0 73 77
1
end_operator
begin_operator
down f76 f9
1
3206 0
1
0 0 73 79
1
end_operator
begin_operator
down f77 f1
1
124 0
1
0 0 74 0
1
end_operator
begin_operator
down f77 f10
1
196 0
1
0 0 74 1
1
end_operator
begin_operator
down f77 f11
1
265 0
1
0 0 74 2
1
end_operator
begin_operator
down f77 f12
1
333 0
1
0 0 74 3
1
end_operator
begin_operator
down f77 f13
1
400 0
1
0 0 74 4
1
end_operator
begin_operator
down f77 f14
1
466 0
1
0 0 74 5
1
end_operator
begin_operator
down f77 f15
1
531 0
1
0 0 74 6
1
end_operator
begin_operator
down f77 f16
1
595 0
1
0 0 74 7
1
end_operator
begin_operator
down f77 f17
1
658 0
1
0 0 74 8
1
end_operator
begin_operator
down f77 f18
1
720 0
1
0 0 74 9
1
end_operator
begin_operator
down f77 f19
1
781 0
1
0 0 74 10
1
end_operator
begin_operator
down f77 f2
1
857 0
1
0 0 74 11
1
end_operator
begin_operator
down f77 f20
1
919 0
1
0 0 74 12
1
end_operator
begin_operator
down f77 f21
1
978 0
1
0 0 74 13
1
end_operator
begin_operator
down f77 f22
1
1036 0
1
0 0 74 14
1
end_operator
begin_operator
down f77 f23
1
1093 0
1
0 0 74 15
1
end_operator
begin_operator
down f77 f24
1
1149 0
1
0 0 74 16
1
end_operator
begin_operator
down f77 f25
1
1204 0
1
0 0 74 17
1
end_operator
begin_operator
down f77 f26
1
1258 0
1
0 0 74 18
1
end_operator
begin_operator
down f77 f27
1
1311 0
1
0 0 74 19
1
end_operator
begin_operator
down f77 f28
1
1363 0
1
0 0 74 20
1
end_operator
begin_operator
down f77 f29
1
1414 0
1
0 0 74 21
1
end_operator
begin_operator
down f77 f3
1
1489 0
1
0 0 74 22
1
end_operator
begin_operator
down f77 f30
1
1541 0
1
0 0 74 23
1
end_operator
begin_operator
down f77 f31
1
1590 0
1
0 0 74 24
1
end_operator
begin_operator
down f77 f32
1
1638 0
1
0 0 74 25
1
end_operator
begin_operator
down f77 f33
1
1685 0
1
0 0 74 26
1
end_operator
begin_operator
down f77 f34
1
1731 0
1
0 0 74 27
1
end_operator
begin_operator
down f77 f35
1
1776 0
1
0 0 74 28
1
end_operator
begin_operator
down f77 f36
1
1820 0
1
0 0 74 29
1
end_operator
begin_operator
down f77 f37
1
1863 0
1
0 0 74 30
1
end_operator
begin_operator
down f77 f38
1
1905 0
1
0 0 74 31
1
end_operator
begin_operator
down f77 f39
1
1946 0
1
0 0 74 32
1
end_operator
begin_operator
down f77 f4
1
2020 0
1
0 0 74 33
1
end_operator
begin_operator
down f77 f40
1
2062 0
1
0 0 74 34
1
end_operator
begin_operator
down f77 f41
1
2101 0
1
0 0 74 35
1
end_operator
begin_operator
down f77 f42
1
2139 0
1
0 0 74 36
1
end_operator
begin_operator
down f77 f43
1
2176 0
1
0 0 74 37
1
end_operator
begin_operator
down f77 f44
1
2212 0
1
0 0 74 38
1
end_operator
begin_operator
down f77 f45
1
2247 0
1
0 0 74 39
1
end_operator
begin_operator
down f77 f46
1
2281 0
1
0 0 74 40
1
end_operator
begin_operator
down f77 f47
1
2314 0
1
0 0 74 41
1
end_operator
begin_operator
down f77 f48
1
2346 0
1
0 0 74 42
1
end_operator
begin_operator
down f77 f49
1
2377 0
1
0 0 74 43
1
end_operator
begin_operator
down f77 f5
1
2450 0
1
0 0 74 44
1
end_operator
begin_operator
down f77 f50
1
2482 0
1
0 0 74 45
1
end_operator
begin_operator
down f77 f51
1
2511 0
1
0 0 74 46
1
end_operator
begin_operator
down f77 f52
1
2539 0
1
0 0 74 47
1
end_operator
begin_operator
down f77 f53
1
2566 0
1
0 0 74 48
1
end_operator
begin_operator
down f77 f54
1
2592 0
1
0 0 74 49
1
end_operator
begin_operator
down f77 f55
1
2617 0
1
0 0 74 50
1
end_operator
begin_operator
down f77 f56
1
2641 0
1
0 0 74 51
1
end_operator
begin_operator
down f77 f57
1
2664 0
1
0 0 74 52
1
end_operator
begin_operator
down f77 f58
1
2686 0
1
0 0 74 53
1
end_operator
begin_operator
down f77 f59
1
2707 0
1
0 0 74 54
1
end_operator
begin_operator
down f77 f6
1
2779 0
1
0 0 74 55
1
end_operator
begin_operator
down f77 f60
1
2801 0
1
0 0 74 56
1
end_operator
begin_operator
down f77 f61
1
2820 0
1
0 0 74 57
1
end_operator
begin_operator
down f77 f62
1
2838 0
1
0 0 74 58
1
end_operator
begin_operator
down f77 f63
1
2855 0
1
0 0 74 59
1
end_operator
begin_operator
down f77 f64
1
2871 0
1
0 0 74 60
1
end_operator
begin_operator
down f77 f65
1
2886 0
1
0 0 74 61
1
end_operator
begin_operator
down f77 f66
1
2900 0
1
0 0 74 62
1
end_operator
begin_operator
down f77 f67
1
2913 0
1
0 0 74 63
1
end_operator
begin_operator
down f77 f68
1
2925 0
1
0 0 74 64
1
end_operator
begin_operator
down f77 f69
1
2936 0
1
0 0 74 65
1
end_operator
begin_operator
down f77 f7
1
3007 0
1
0 0 74 66
1
end_operator
begin_operator
down f77 f70
1
3019 0
1
0 0 74 67
1
end_operator
begin_operator
down f77 f71
1
3028 0
1
0 0 74 68
1
end_operator
begin_operator
down f77 f72
1
3036 0
1
0 0 74 69
1
end_operator
begin_operator
down f77 f73
1
3043 0
1
0 0 74 70
1
end_operator
begin_operator
down f77 f74
1
3049 0
1
0 0 74 71
1
end_operator
begin_operator
down f77 f75
1
3054 0
1
0 0 74 72
1
end_operator
begin_operator
down f77 f76
1
3058 0
1
0 0 74 73
1
end_operator
begin_operator
down f77 f8
1
3135 0
1
0 0 74 77
1
end_operator
begin_operator
down f77 f9
1
3207 0
1
0 0 74 79
1
end_operator
begin_operator
down f78 f1
1
125 0
1
0 0 75 0
1
end_operator
begin_operator
down f78 f10
1
197 0
1
0 0 75 1
1
end_operator
begin_operator
down f78 f11
1
266 0
1
0 0 75 2
1
end_operator
begin_operator
down f78 f12
1
334 0
1
0 0 75 3
1
end_operator
begin_operator
down f78 f13
1
401 0
1
0 0 75 4
1
end_operator
begin_operator
down f78 f14
1
467 0
1
0 0 75 5
1
end_operator
begin_operator
down f78 f15
1
532 0
1
0 0 75 6
1
end_operator
begin_operator
down f78 f16
1
596 0
1
0 0 75 7
1
end_operator
begin_operator
down f78 f17
1
659 0
1
0 0 75 8
1
end_operator
begin_operator
down f78 f18
1
721 0
1
0 0 75 9
1
end_operator
begin_operator
down f78 f19
1
782 0
1
0 0 75 10
1
end_operator
begin_operator
down f78 f2
1
858 0
1
0 0 75 11
1
end_operator
begin_operator
down f78 f20
1
920 0
1
0 0 75 12
1
end_operator
begin_operator
down f78 f21
1
979 0
1
0 0 75 13
1
end_operator
begin_operator
down f78 f22
1
1037 0
1
0 0 75 14
1
end_operator
begin_operator
down f78 f23
1
1094 0
1
0 0 75 15
1
end_operator
begin_operator
down f78 f24
1
1150 0
1
0 0 75 16
1
end_operator
begin_operator
down f78 f25
1
1205 0
1
0 0 75 17
1
end_operator
begin_operator
down f78 f26
1
1259 0
1
0 0 75 18
1
end_operator
begin_operator
down f78 f27
1
1312 0
1
0 0 75 19
1
end_operator
begin_operator
down f78 f28
1
1364 0
1
0 0 75 20
1
end_operator
begin_operator
down f78 f29
1
1415 0
1
0 0 75 21
1
end_operator
begin_operator
down f78 f3
1
1490 0
1
0 0 75 22
1
end_operator
begin_operator
down f78 f30
1
1542 0
1
0 0 75 23
1
end_operator
begin_operator
down f78 f31
1
1591 0
1
0 0 75 24
1
end_operator
begin_operator
down f78 f32
1
1639 0
1
0 0 75 25
1
end_operator
begin_operator
down f78 f33
1
1686 0
1
0 0 75 26
1
end_operator
begin_operator
down f78 f34
1
1732 0
1
0 0 75 27
1
end_operator
begin_operator
down f78 f35
1
1777 0
1
0 0 75 28
1
end_operator
begin_operator
down f78 f36
1
1821 0
1
0 0 75 29
1
end_operator
begin_operator
down f78 f37
1
1864 0
1
0 0 75 30
1
end_operator
begin_operator
down f78 f38
1
1906 0
1
0 0 75 31
1
end_operator
begin_operator
down f78 f39
1
1947 0
1
0 0 75 32
1
end_operator
begin_operator
down f78 f4
1
2021 0
1
0 0 75 33
1
end_operator
begin_operator
down f78 f40
1
2063 0
1
0 0 75 34
1
end_operator
begin_operator
down f78 f41
1
2102 0
1
0 0 75 35
1
end_operator
begin_operator
down f78 f42
1
2140 0
1
0 0 75 36
1
end_operator
begin_operator
down f78 f43
1
2177 0
1
0 0 75 37
1
end_operator
begin_operator
down f78 f44
1
2213 0
1
0 0 75 38
1
end_operator
begin_operator
down f78 f45
1
2248 0
1
0 0 75 39
1
end_operator
begin_operator
down f78 f46
1
2282 0
1
0 0 75 40
1
end_operator
begin_operator
down f78 f47
1
2315 0
1
0 0 75 41
1
end_operator
begin_operator
down f78 f48
1
2347 0
1
0 0 75 42
1
end_operator
begin_operator
down f78 f49
1
2378 0
1
0 0 75 43
1
end_operator
begin_operator
down f78 f5
1
2451 0
1
0 0 75 44
1
end_operator
begin_operator
down f78 f50
1
2483 0
1
0 0 75 45
1
end_operator
begin_operator
down f78 f51
1
2512 0
1
0 0 75 46
1
end_operator
begin_operator
down f78 f52
1
2540 0
1
0 0 75 47
1
end_operator
begin_operator
down f78 f53
1
2567 0
1
0 0 75 48
1
end_operator
begin_operator
down f78 f54
1
2593 0
1
0 0 75 49
1
end_operator
begin_operator
down f78 f55
1
2618 0
1
0 0 75 50
1
end_operator
begin_operator
down f78 f56
1
2642 0
1
0 0 75 51
1
end_operator
begin_operator
down f78 f57
1
2665 0
1
0 0 75 52
1
end_operator
begin_operator
down f78 f58
1
2687 0
1
0 0 75 53
1
end_operator
begin_operator
down f78 f59
1
2708 0
1
0 0 75 54
1
end_operator
begin_operator
down f78 f6
1
2780 0
1
0 0 75 55
1
end_operator
begin_operator
down f78 f60
1
2802 0
1
0 0 75 56
1
end_operator
begin_operator
down f78 f61
1
2821 0
1
0 0 75 57
1
end_operator
begin_operator
down f78 f62
1
2839 0
1
0 0 75 58
1
end_operator
begin_operator
down f78 f63
1
2856 0
1
0 0 75 59
1
end_operator
begin_operator
down f78 f64
1
2872 0
1
0 0 75 60
1
end_operator
begin_operator
down f78 f65
1
2887 0
1
0 0 75 61
1
end_operator
begin_operator
down f78 f66
1
2901 0
1
0 0 75 62
1
end_operator
begin_operator
down f78 f67
1
2914 0
1
0 0 75 63
1
end_operator
begin_operator
down f78 f68
1
2926 0
1
0 0 75 64
1
end_operator
begin_operator
down f78 f69
1
2937 0
1
0 0 75 65
1
end_operator
begin_operator
down f78 f7
1
3008 0
1
0 0 75 66
1
end_operator
begin_operator
down f78 f70
1
3020 0
1
0 0 75 67
1
end_operator
begin_operator
down f78 f71
1
3029 0
1
0 0 75 68
1
end_operator
begin_operator
down f78 f72
1
3037 0
1
0 0 75 69
1
end_operator
begin_operator
down f78 f73
1
3044 0
1
0 0 75 70
1
end_operator
begin_operator
down f78 f74
1
3050 0
1
0 0 75 71
1
end_operator
begin_operator
down f78 f75
1
3055 0
1
0 0 75 72
1
end_operator
begin_operator
down f78 f76
1
3059 0
1
0 0 75 73
1
end_operator
begin_operator
down f78 f77
1
3062 0
1
0 0 75 74
1
end_operator
begin_operator
down f78 f8
1
3136 0
1
0 0 75 77
1
end_operator
begin_operator
down f78 f9
1
3208 0
1
0 0 75 79
1
end_operator
begin_operator
down f79 f1
1
126 0
1
0 0 76 0
1
end_operator
begin_operator
down f79 f10
1
198 0
1
0 0 76 1
1
end_operator
begin_operator
down f79 f11
1
267 0
1
0 0 76 2
1
end_operator
begin_operator
down f79 f12
1
335 0
1
0 0 76 3
1
end_operator
begin_operator
down f79 f13
1
402 0
1
0 0 76 4
1
end_operator
begin_operator
down f79 f14
1
468 0
1
0 0 76 5
1
end_operator
begin_operator
down f79 f15
1
533 0
1
0 0 76 6
1
end_operator
begin_operator
down f79 f16
1
597 0
1
0 0 76 7
1
end_operator
begin_operator
down f79 f17
1
660 0
1
0 0 76 8
1
end_operator
begin_operator
down f79 f18
1
722 0
1
0 0 76 9
1
end_operator
begin_operator
down f79 f19
1
783 0
1
0 0 76 10
1
end_operator
begin_operator
down f79 f2
1
859 0
1
0 0 76 11
1
end_operator
begin_operator
down f79 f20
1
921 0
1
0 0 76 12
1
end_operator
begin_operator
down f79 f21
1
980 0
1
0 0 76 13
1
end_operator
begin_operator
down f79 f22
1
1038 0
1
0 0 76 14
1
end_operator
begin_operator
down f79 f23
1
1095 0
1
0 0 76 15
1
end_operator
begin_operator
down f79 f24
1
1151 0
1
0 0 76 16
1
end_operator
begin_operator
down f79 f25
1
1206 0
1
0 0 76 17
1
end_operator
begin_operator
down f79 f26
1
1260 0
1
0 0 76 18
1
end_operator
begin_operator
down f79 f27
1
1313 0
1
0 0 76 19
1
end_operator
begin_operator
down f79 f28
1
1365 0
1
0 0 76 20
1
end_operator
begin_operator
down f79 f29
1
1416 0
1
0 0 76 21
1
end_operator
begin_operator
down f79 f3
1
1491 0
1
0 0 76 22
1
end_operator
begin_operator
down f79 f30
1
1543 0
1
0 0 76 23
1
end_operator
begin_operator
down f79 f31
1
1592 0
1
0 0 76 24
1
end_operator
begin_operator
down f79 f32
1
1640 0
1
0 0 76 25
1
end_operator
begin_operator
down f79 f33
1
1687 0
1
0 0 76 26
1
end_operator
begin_operator
down f79 f34
1
1733 0
1
0 0 76 27
1
end_operator
begin_operator
down f79 f35
1
1778 0
1
0 0 76 28
1
end_operator
begin_operator
down f79 f36
1
1822 0
1
0 0 76 29
1
end_operator
begin_operator
down f79 f37
1
1865 0
1
0 0 76 30
1
end_operator
begin_operator
down f79 f38
1
1907 0
1
0 0 76 31
1
end_operator
begin_operator
down f79 f39
1
1948 0
1
0 0 76 32
1
end_operator
begin_operator
down f79 f4
1
2022 0
1
0 0 76 33
1
end_operator
begin_operator
down f79 f40
1
2064 0
1
0 0 76 34
1
end_operator
begin_operator
down f79 f41
1
2103 0
1
0 0 76 35
1
end_operator
begin_operator
down f79 f42
1
2141 0
1
0 0 76 36
1
end_operator
begin_operator
down f79 f43
1
2178 0
1
0 0 76 37
1
end_operator
begin_operator
down f79 f44
1
2214 0
1
0 0 76 38
1
end_operator
begin_operator
down f79 f45
1
2249 0
1
0 0 76 39
1
end_operator
begin_operator
down f79 f46
1
2283 0
1
0 0 76 40
1
end_operator
begin_operator
down f79 f47
1
2316 0
1
0 0 76 41
1
end_operator
begin_operator
down f79 f48
1
2348 0
1
0 0 76 42
1
end_operator
begin_operator
down f79 f49
1
2379 0
1
0 0 76 43
1
end_operator
begin_operator
down f79 f5
1
2452 0
1
0 0 76 44
1
end_operator
begin_operator
down f79 f50
1
2484 0
1
0 0 76 45
1
end_operator
begin_operator
down f79 f51
1
2513 0
1
0 0 76 46
1
end_operator
begin_operator
down f79 f52
1
2541 0
1
0 0 76 47
1
end_operator
begin_operator
down f79 f53
1
2568 0
1
0 0 76 48
1
end_operator
begin_operator
down f79 f54
1
2594 0
1
0 0 76 49
1
end_operator
begin_operator
down f79 f55
1
2619 0
1
0 0 76 50
1
end_operator
begin_operator
down f79 f56
1
2643 0
1
0 0 76 51
1
end_operator
begin_operator
down f79 f57
1
2666 0
1
0 0 76 52
1
end_operator
begin_operator
down f79 f58
1
2688 0
1
0 0 76 53
1
end_operator
begin_operator
down f79 f59
1
2709 0
1
0 0 76 54
1
end_operator
begin_operator
down f79 f6
1
2781 0
1
0 0 76 55
1
end_operator
begin_operator
down f79 f60
1
2803 0
1
0 0 76 56
1
end_operator
begin_operator
down f79 f61
1
2822 0
1
0 0 76 57
1
end_operator
begin_operator
down f79 f62
1
2840 0
1
0 0 76 58
1
end_operator
begin_operator
down f79 f63
1
2857 0
1
0 0 76 59
1
end_operator
begin_operator
down f79 f64
1
2873 0
1
0 0 76 60
1
end_operator
begin_operator
down f79 f65
1
2888 0
1
0 0 76 61
1
end_operator
begin_operator
down f79 f66
1
2902 0
1
0 0 76 62
1
end_operator
begin_operator
down f79 f67
1
2915 0
1
0 0 76 63
1
end_operator
begin_operator
down f79 f68
1
2927 0
1
0 0 76 64
1
end_operator
begin_operator
down f79 f69
1
2938 0
1
0 0 76 65
1
end_operator
begin_operator
down f79 f7
1
3009 0
1
0 0 76 66
1
end_operator
begin_operator
down f79 f70
1
3021 0
1
0 0 76 67
1
end_operator
begin_operator
down f79 f71
1
3030 0
1
0 0 76 68
1
end_operator
begin_operator
down f79 f72
1
3038 0
1
0 0 76 69
1
end_operator
begin_operator
down f79 f73
1
3045 0
1
0 0 76 70
1
end_operator
begin_operator
down f79 f74
1
3051 0
1
0 0 76 71
1
end_operator
begin_operator
down f79 f75
1
3056 0
1
0 0 76 72
1
end_operator
begin_operator
down f79 f76
1
3060 0
1
0 0 76 73
1
end_operator
begin_operator
down f79 f77
1
3063 0
1
0 0 76 74
1
end_operator
begin_operator
down f79 f78
1
3065 0
1
0 0 76 75
1
end_operator
begin_operator
down f79 f8
1
3137 0
1
0 0 76 77
1
end_operator
begin_operator
down f79 f9
1
3209 0
1
0 0 76 79
1
end_operator
begin_operator
down f8 f1
1
127 0
1
0 0 77 0
1
end_operator
begin_operator
down f8 f2
1
860 0
1
0 0 77 11
1
end_operator
begin_operator
down f8 f3
1
1492 0
1
0 0 77 22
1
end_operator
begin_operator
down f8 f4
1
2023 0
1
0 0 77 33
1
end_operator
begin_operator
down f8 f5
1
2453 0
1
0 0 77 44
1
end_operator
begin_operator
down f8 f6
1
2782 0
1
0 0 77 55
1
end_operator
begin_operator
down f8 f7
1
3010 0
1
0 0 77 66
1
end_operator
begin_operator
down f80 f1
1
128 0
1
0 0 78 0
1
end_operator
begin_operator
down f80 f10
1
199 0
1
0 0 78 1
1
end_operator
begin_operator
down f80 f11
1
268 0
1
0 0 78 2
1
end_operator
begin_operator
down f80 f12
1
336 0
1
0 0 78 3
1
end_operator
begin_operator
down f80 f13
1
403 0
1
0 0 78 4
1
end_operator
begin_operator
down f80 f14
1
469 0
1
0 0 78 5
1
end_operator
begin_operator
down f80 f15
1
534 0
1
0 0 78 6
1
end_operator
begin_operator
down f80 f16
1
598 0
1
0 0 78 7
1
end_operator
begin_operator
down f80 f17
1
661 0
1
0 0 78 8
1
end_operator
begin_operator
down f80 f18
1
723 0
1
0 0 78 9
1
end_operator
begin_operator
down f80 f19
1
784 0
1
0 0 78 10
1
end_operator
begin_operator
down f80 f2
1
861 0
1
0 0 78 11
1
end_operator
begin_operator
down f80 f20
1
922 0
1
0 0 78 12
1
end_operator
begin_operator
down f80 f21
1
981 0
1
0 0 78 13
1
end_operator
begin_operator
down f80 f22
1
1039 0
1
0 0 78 14
1
end_operator
begin_operator
down f80 f23
1
1096 0
1
0 0 78 15
1
end_operator
begin_operator
down f80 f24
1
1152 0
1
0 0 78 16
1
end_operator
begin_operator
down f80 f25
1
1207 0
1
0 0 78 17
1
end_operator
begin_operator
down f80 f26
1
1261 0
1
0 0 78 18
1
end_operator
begin_operator
down f80 f27
1
1314 0
1
0 0 78 19
1
end_operator
begin_operator
down f80 f28
1
1366 0
1
0 0 78 20
1
end_operator
begin_operator
down f80 f29
1
1417 0
1
0 0 78 21
1
end_operator
begin_operator
down f80 f3
1
1493 0
1
0 0 78 22
1
end_operator
begin_operator
down f80 f30
1
1544 0
1
0 0 78 23
1
end_operator
begin_operator
down f80 f31
1
1593 0
1
0 0 78 24
1
end_operator
begin_operator
down f80 f32
1
1641 0
1
0 0 78 25
1
end_operator
begin_operator
down f80 f33
1
1688 0
1
0 0 78 26
1
end_operator
begin_operator
down f80 f34
1
1734 0
1
0 0 78 27
1
end_operator
begin_operator
down f80 f35
1
1779 0
1
0 0 78 28
1
end_operator
begin_operator
down f80 f36
1
1823 0
1
0 0 78 29
1
end_operator
begin_operator
down f80 f37
1
1866 0
1
0 0 78 30
1
end_operator
begin_operator
down f80 f38
1
1908 0
1
0 0 78 31
1
end_operator
begin_operator
down f80 f39
1
1949 0
1
0 0 78 32
1
end_operator
begin_operator
down f80 f4
1
2024 0
1
0 0 78 33
1
end_operator
begin_operator
down f80 f40
1
2065 0
1
0 0 78 34
1
end_operator
begin_operator
down f80 f41
1
2104 0
1
0 0 78 35
1
end_operator
begin_operator
down f80 f42
1
2142 0
1
0 0 78 36
1
end_operator
begin_operator
down f80 f43
1
2179 0
1
0 0 78 37
1
end_operator
begin_operator
down f80 f44
1
2215 0
1
0 0 78 38
1
end_operator
begin_operator
down f80 f45
1
2250 0
1
0 0 78 39
1
end_operator
begin_operator
down f80 f46
1
2284 0
1
0 0 78 40
1
end_operator
begin_operator
down f80 f47
1
2317 0
1
0 0 78 41
1
end_operator
begin_operator
down f80 f48
1
2349 0
1
0 0 78 42
1
end_operator
begin_operator
down f80 f49
1
2380 0
1
0 0 78 43
1
end_operator
begin_operator
down f80 f5
1
2454 0
1
0 0 78 44
1
end_operator
begin_operator
down f80 f50
1
2485 0
1
0 0 78 45
1
end_operator
begin_operator
down f80 f51
1
2514 0
1
0 0 78 46
1
end_operator
begin_operator
down f80 f52
1
2542 0
1
0 0 78 47
1
end_operator
begin_operator
down f80 f53
1
2569 0
1
0 0 78 48
1
end_operator
begin_operator
down f80 f54
1
2595 0
1
0 0 78 49
1
end_operator
begin_operator
down f80 f55
1
2620 0
1
0 0 78 50
1
end_operator
begin_operator
down f80 f56
1
2644 0
1
0 0 78 51
1
end_operator
begin_operator
down f80 f57
1
2667 0
1
0 0 78 52
1
end_operator
begin_operator
down f80 f58
1
2689 0
1
0 0 78 53
1
end_operator
begin_operator
down f80 f59
1
2710 0
1
0 0 78 54
1
end_operator
begin_operator
down f80 f6
1
2783 0
1
0 0 78 55
1
end_operator
begin_operator
down f80 f60
1
2804 0
1
0 0 78 56
1
end_operator
begin_operator
down f80 f61
1
2823 0
1
0 0 78 57
1
end_operator
begin_operator
down f80 f62
1
2841 0
1
0 0 78 58
1
end_operator
begin_operator
down f80 f63
1
2858 0
1
0 0 78 59
1
end_operator
begin_operator
down f80 f64
1
2874 0
1
0 0 78 60
1
end_operator
begin_operator
down f80 f65
1
2889 0
1
0 0 78 61
1
end_operator
begin_operator
down f80 f66
1
2903 0
1
0 0 78 62
1
end_operator
begin_operator
down f80 f67
1
2916 0
1
0 0 78 63
1
end_operator
begin_operator
down f80 f68
1
2928 0
1
0 0 78 64
1
end_operator
begin_operator
down f80 f69
1
2939 0
1
0 0 78 65
1
end_operator
begin_operator
down f80 f7
1
3011 0
1
0 0 78 66
1
end_operator
begin_operator
down f80 f70
1
3022 0
1
0 0 78 67
1
end_operator
begin_operator
down f80 f71
1
3031 0
1
0 0 78 68
1
end_operator
begin_operator
down f80 f72
1
3039 0
1
0 0 78 69
1
end_operator
begin_operator
down f80 f73
1
3046 0
1
0 0 78 70
1
end_operator
begin_operator
down f80 f74
1
3052 0
1
0 0 78 71
1
end_operator
begin_operator
down f80 f75
1
3057 0
1
0 0 78 72
1
end_operator
begin_operator
down f80 f76
1
3061 0
1
0 0 78 73
1
end_operator
begin_operator
down f80 f77
1
3064 0
1
0 0 78 74
1
end_operator
begin_operator
down f80 f78
1
3066 0
1
0 0 78 75
1
end_operator
begin_operator
down f80 f79
1
3067 0
1
0 0 78 76
1
end_operator
begin_operator
down f80 f8
1
3138 0
1
0 0 78 77
1
end_operator
begin_operator
down f80 f9
1
3210 0
1
0 0 78 79
1
end_operator
begin_operator
down f9 f1
1
129 0
1
0 0 79 0
1
end_operator
begin_operator
down f9 f2
1
862 0
1
0 0 79 11
1
end_operator
begin_operator
down f9 f3
1
1494 0
1
0 0 79 22
1
end_operator
begin_operator
down f9 f4
1
2025 0
1
0 0 79 33
1
end_operator
begin_operator
down f9 f5
1
2455 0
1
0 0 79 44
1
end_operator
begin_operator
down f9 f6
1
2784 0
1
0 0 79 55
1
end_operator
begin_operator
down f9 f7
1
3012 0
1
0 0 79 66
1
end_operator
begin_operator
down f9 f8
1
3139 0
1
0 0 79 77
1
end_operator
begin_operator
up f1 f10
1
51 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f11
1
52 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f12
1
53 0
1
0 0 0 3
1
end_operator
begin_operator
up f1 f13
1
54 0
1
0 0 0 4
1
end_operator
begin_operator
up f1 f14
1
55 0
1
0 0 0 5
1
end_operator
begin_operator
up f1 f15
1
56 0
1
0 0 0 6
1
end_operator
begin_operator
up f1 f16
1
57 0
1
0 0 0 7
1
end_operator
begin_operator
up f1 f17
1
58 0
1
0 0 0 8
1
end_operator
begin_operator
up f1 f18
1
59 0
1
0 0 0 9
1
end_operator
begin_operator
up f1 f19
1
60 0
1
0 0 0 10
1
end_operator
begin_operator
up f1 f2
1
61 0
1
0 0 0 11
1
end_operator
begin_operator
up f1 f20
1
62 0
1
0 0 0 12
1
end_operator
begin_operator
up f1 f21
1
63 0
1
0 0 0 13
1
end_operator
begin_operator
up f1 f22
1
64 0
1
0 0 0 14
1
end_operator
begin_operator
up f1 f23
1
65 0
1
0 0 0 15
1
end_operator
begin_operator
up f1 f24
1
66 0
1
0 0 0 16
1
end_operator
begin_operator
up f1 f25
1
67 0
1
0 0 0 17
1
end_operator
begin_operator
up f1 f26
1
68 0
1
0 0 0 18
1
end_operator
begin_operator
up f1 f27
1
69 0
1
0 0 0 19
1
end_operator
begin_operator
up f1 f28
1
70 0
1
0 0 0 20
1
end_operator
begin_operator
up f1 f29
1
71 0
1
0 0 0 21
1
end_operator
begin_operator
up f1 f3
1
72 0
1
0 0 0 22
1
end_operator
begin_operator
up f1 f30
1
73 0
1
0 0 0 23
1
end_operator
begin_operator
up f1 f31
1
74 0
1
0 0 0 24
1
end_operator
begin_operator
up f1 f32
1
75 0
1
0 0 0 25
1
end_operator
begin_operator
up f1 f33
1
76 0
1
0 0 0 26
1
end_operator
begin_operator
up f1 f34
1
77 0
1
0 0 0 27
1
end_operator
begin_operator
up f1 f35
1
78 0
1
0 0 0 28
1
end_operator
begin_operator
up f1 f36
1
79 0
1
0 0 0 29
1
end_operator
begin_operator
up f1 f37
1
80 0
1
0 0 0 30
1
end_operator
begin_operator
up f1 f38
1
81 0
1
0 0 0 31
1
end_operator
begin_operator
up f1 f39
1
82 0
1
0 0 0 32
1
end_operator
begin_operator
up f1 f4
1
83 0
1
0 0 0 33
1
end_operator
begin_operator
up f1 f40
1
84 0
1
0 0 0 34
1
end_operator
begin_operator
up f1 f41
1
85 0
1
0 0 0 35
1
end_operator
begin_operator
up f1 f42
1
86 0
1
0 0 0 36
1
end_operator
begin_operator
up f1 f43
1
87 0
1
0 0 0 37
1
end_operator
begin_operator
up f1 f44
1
88 0
1
0 0 0 38
1
end_operator
begin_operator
up f1 f45
1
89 0
1
0 0 0 39
1
end_operator
begin_operator
up f1 f46
1
90 0
1
0 0 0 40
1
end_operator
begin_operator
up f1 f47
1
91 0
1
0 0 0 41
1
end_operator
begin_operator
up f1 f48
1
92 0
1
0 0 0 42
1
end_operator
begin_operator
up f1 f49
1
93 0
1
0 0 0 43
1
end_operator
begin_operator
up f1 f5
1
94 0
1
0 0 0 44
1
end_operator
begin_operator
up f1 f50
1
95 0
1
0 0 0 45
1
end_operator
begin_operator
up f1 f51
1
96 0
1
0 0 0 46
1
end_operator
begin_operator
up f1 f52
1
97 0
1
0 0 0 47
1
end_operator
begin_operator
up f1 f53
1
98 0
1
0 0 0 48
1
end_operator
begin_operator
up f1 f54
1
99 0
1
0 0 0 49
1
end_operator
begin_operator
up f1 f55
1
100 0
1
0 0 0 50
1
end_operator
begin_operator
up f1 f56
1
101 0
1
0 0 0 51
1
end_operator
begin_operator
up f1 f57
1
102 0
1
0 0 0 52
1
end_operator
begin_operator
up f1 f58
1
103 0
1
0 0 0 53
1
end_operator
begin_operator
up f1 f59
1
104 0
1
0 0 0 54
1
end_operator
begin_operator
up f1 f6
1
105 0
1
0 0 0 55
1
end_operator
begin_operator
up f1 f60
1
106 0
1
0 0 0 56
1
end_operator
begin_operator
up f1 f61
1
107 0
1
0 0 0 57
1
end_operator
begin_operator
up f1 f62
1
108 0
1
0 0 0 58
1
end_operator
begin_operator
up f1 f63
1
109 0
1
0 0 0 59
1
end_operator
begin_operator
up f1 f64
1
110 0
1
0 0 0 60
1
end_operator
begin_operator
up f1 f65
1
111 0
1
0 0 0 61
1
end_operator
begin_operator
up f1 f66
1
112 0
1
0 0 0 62
1
end_operator
begin_operator
up f1 f67
1
113 0
1
0 0 0 63
1
end_operator
begin_operator
up f1 f68
1
114 0
1
0 0 0 64
1
end_operator
begin_operator
up f1 f69
1
115 0
1
0 0 0 65
1
end_operator
begin_operator
up f1 f7
1
116 0
1
0 0 0 66
1
end_operator
begin_operator
up f1 f70
1
117 0
1
0 0 0 67
1
end_operator
begin_operator
up f1 f71
1
118 0
1
0 0 0 68
1
end_operator
begin_operator
up f1 f72
1
119 0
1
0 0 0 69
1
end_operator
begin_operator
up f1 f73
1
120 0
1
0 0 0 70
1
end_operator
begin_operator
up f1 f74
1
121 0
1
0 0 0 71
1
end_operator
begin_operator
up f1 f75
1
122 0
1
0 0 0 72
1
end_operator
begin_operator
up f1 f76
1
123 0
1
0 0 0 73
1
end_operator
begin_operator
up f1 f77
1
124 0
1
0 0 0 74
1
end_operator
begin_operator
up f1 f78
1
125 0
1
0 0 0 75
1
end_operator
begin_operator
up f1 f79
1
126 0
1
0 0 0 76
1
end_operator
begin_operator
up f1 f8
1
127 0
1
0 0 0 77
1
end_operator
begin_operator
up f1 f80
1
128 0
1
0 0 0 78
1
end_operator
begin_operator
up f1 f9
1
129 0
1
0 0 0 79
1
end_operator
begin_operator
up f10 f11
1
130 0
1
0 0 1 2
1
end_operator
begin_operator
up f10 f12
1
131 0
1
0 0 1 3
1
end_operator
begin_operator
up f10 f13
1
132 0
1
0 0 1 4
1
end_operator
begin_operator
up f10 f14
1
133 0
1
0 0 1 5
1
end_operator
begin_operator
up f10 f15
1
134 0
1
0 0 1 6
1
end_operator
begin_operator
up f10 f16
1
135 0
1
0 0 1 7
1
end_operator
begin_operator
up f10 f17
1
136 0
1
0 0 1 8
1
end_operator
begin_operator
up f10 f18
1
137 0
1
0 0 1 9
1
end_operator
begin_operator
up f10 f19
1
138 0
1
0 0 1 10
1
end_operator
begin_operator
up f10 f20
1
139 0
1
0 0 1 12
1
end_operator
begin_operator
up f10 f21
1
140 0
1
0 0 1 13
1
end_operator
begin_operator
up f10 f22
1
141 0
1
0 0 1 14
1
end_operator
begin_operator
up f10 f23
1
142 0
1
0 0 1 15
1
end_operator
begin_operator
up f10 f24
1
143 0
1
0 0 1 16
1
end_operator
begin_operator
up f10 f25
1
144 0
1
0 0 1 17
1
end_operator
begin_operator
up f10 f26
1
145 0
1
0 0 1 18
1
end_operator
begin_operator
up f10 f27
1
146 0
1
0 0 1 19
1
end_operator
begin_operator
up f10 f28
1
147 0
1
0 0 1 20
1
end_operator
begin_operator
up f10 f29
1
148 0
1
0 0 1 21
1
end_operator
begin_operator
up f10 f30
1
149 0
1
0 0 1 23
1
end_operator
begin_operator
up f10 f31
1
150 0
1
0 0 1 24
1
end_operator
begin_operator
up f10 f32
1
151 0
1
0 0 1 25
1
end_operator
begin_operator
up f10 f33
1
152 0
1
0 0 1 26
1
end_operator
begin_operator
up f10 f34
1
153 0
1
0 0 1 27
1
end_operator
begin_operator
up f10 f35
1
154 0
1
0 0 1 28
1
end_operator
begin_operator
up f10 f36
1
155 0
1
0 0 1 29
1
end_operator
begin_operator
up f10 f37
1
156 0
1
0 0 1 30
1
end_operator
begin_operator
up f10 f38
1
157 0
1
0 0 1 31
1
end_operator
begin_operator
up f10 f39
1
158 0
1
0 0 1 32
1
end_operator
begin_operator
up f10 f40
1
159 0
1
0 0 1 34
1
end_operator
begin_operator
up f10 f41
1
160 0
1
0 0 1 35
1
end_operator
begin_operator
up f10 f42
1
161 0
1
0 0 1 36
1
end_operator
begin_operator
up f10 f43
1
162 0
1
0 0 1 37
1
end_operator
begin_operator
up f10 f44
1
163 0
1
0 0 1 38
1
end_operator
begin_operator
up f10 f45
1
164 0
1
0 0 1 39
1
end_operator
begin_operator
up f10 f46
1
165 0
1
0 0 1 40
1
end_operator
begin_operator
up f10 f47
1
166 0
1
0 0 1 41
1
end_operator
begin_operator
up f10 f48
1
167 0
1
0 0 1 42
1
end_operator
begin_operator
up f10 f49
1
168 0
1
0 0 1 43
1
end_operator
begin_operator
up f10 f50
1
169 0
1
0 0 1 45
1
end_operator
begin_operator
up f10 f51
1
170 0
1
0 0 1 46
1
end_operator
begin_operator
up f10 f52
1
171 0
1
0 0 1 47
1
end_operator
begin_operator
up f10 f53
1
172 0
1
0 0 1 48
1
end_operator
begin_operator
up f10 f54
1
173 0
1
0 0 1 49
1
end_operator
begin_operator
up f10 f55
1
174 0
1
0 0 1 50
1
end_operator
begin_operator
up f10 f56
1
175 0
1
0 0 1 51
1
end_operator
begin_operator
up f10 f57
1
176 0
1
0 0 1 52
1
end_operator
begin_operator
up f10 f58
1
177 0
1
0 0 1 53
1
end_operator
begin_operator
up f10 f59
1
178 0
1
0 0 1 54
1
end_operator
begin_operator
up f10 f60
1
179 0
1
0 0 1 56
1
end_operator
begin_operator
up f10 f61
1
180 0
1
0 0 1 57
1
end_operator
begin_operator
up f10 f62
1
181 0
1
0 0 1 58
1
end_operator
begin_operator
up f10 f63
1
182 0
1
0 0 1 59
1
end_operator
begin_operator
up f10 f64
1
183 0
1
0 0 1 60
1
end_operator
begin_operator
up f10 f65
1
184 0
1
0 0 1 61
1
end_operator
begin_operator
up f10 f66
1
185 0
1
0 0 1 62
1
end_operator
begin_operator
up f10 f67
1
186 0
1
0 0 1 63
1
end_operator
begin_operator
up f10 f68
1
187 0
1
0 0 1 64
1
end_operator
begin_operator
up f10 f69
1
188 0
1
0 0 1 65
1
end_operator
begin_operator
up f10 f70
1
189 0
1
0 0 1 67
1
end_operator
begin_operator
up f10 f71
1
190 0
1
0 0 1 68
1
end_operator
begin_operator
up f10 f72
1
191 0
1
0 0 1 69
1
end_operator
begin_operator
up f10 f73
1
192 0
1
0 0 1 70
1
end_operator
begin_operator
up f10 f74
1
193 0
1
0 0 1 71
1
end_operator
begin_operator
up f10 f75
1
194 0
1
0 0 1 72
1
end_operator
begin_operator
up f10 f76
1
195 0
1
0 0 1 73
1
end_operator
begin_operator
up f10 f77
1
196 0
1
0 0 1 74
1
end_operator
begin_operator
up f10 f78
1
197 0
1
0 0 1 75
1
end_operator
begin_operator
up f10 f79
1
198 0
1
0 0 1 76
1
end_operator
begin_operator
up f10 f80
1
199 0
1
0 0 1 78
1
end_operator
begin_operator
up f11 f12
1
200 0
1
0 0 2 3
1
end_operator
begin_operator
up f11 f13
1
201 0
1
0 0 2 4
1
end_operator
begin_operator
up f11 f14
1
202 0
1
0 0 2 5
1
end_operator
begin_operator
up f11 f15
1
203 0
1
0 0 2 6
1
end_operator
begin_operator
up f11 f16
1
204 0
1
0 0 2 7
1
end_operator
begin_operator
up f11 f17
1
205 0
1
0 0 2 8
1
end_operator
begin_operator
up f11 f18
1
206 0
1
0 0 2 9
1
end_operator
begin_operator
up f11 f19
1
207 0
1
0 0 2 10
1
end_operator
begin_operator
up f11 f20
1
208 0
1
0 0 2 12
1
end_operator
begin_operator
up f11 f21
1
209 0
1
0 0 2 13
1
end_operator
begin_operator
up f11 f22
1
210 0
1
0 0 2 14
1
end_operator
begin_operator
up f11 f23
1
211 0
1
0 0 2 15
1
end_operator
begin_operator
up f11 f24
1
212 0
1
0 0 2 16
1
end_operator
begin_operator
up f11 f25
1
213 0
1
0 0 2 17
1
end_operator
begin_operator
up f11 f26
1
214 0
1
0 0 2 18
1
end_operator
begin_operator
up f11 f27
1
215 0
1
0 0 2 19
1
end_operator
begin_operator
up f11 f28
1
216 0
1
0 0 2 20
1
end_operator
begin_operator
up f11 f29
1
217 0
1
0 0 2 21
1
end_operator
begin_operator
up f11 f30
1
218 0
1
0 0 2 23
1
end_operator
begin_operator
up f11 f31
1
219 0
1
0 0 2 24
1
end_operator
begin_operator
up f11 f32
1
220 0
1
0 0 2 25
1
end_operator
begin_operator
up f11 f33
1
221 0
1
0 0 2 26
1
end_operator
begin_operator
up f11 f34
1
222 0
1
0 0 2 27
1
end_operator
begin_operator
up f11 f35
1
223 0
1
0 0 2 28
1
end_operator
begin_operator
up f11 f36
1
224 0
1
0 0 2 29
1
end_operator
begin_operator
up f11 f37
1
225 0
1
0 0 2 30
1
end_operator
begin_operator
up f11 f38
1
226 0
1
0 0 2 31
1
end_operator
begin_operator
up f11 f39
1
227 0
1
0 0 2 32
1
end_operator
begin_operator
up f11 f40
1
228 0
1
0 0 2 34
1
end_operator
begin_operator
up f11 f41
1
229 0
1
0 0 2 35
1
end_operator
begin_operator
up f11 f42
1
230 0
1
0 0 2 36
1
end_operator
begin_operator
up f11 f43
1
231 0
1
0 0 2 37
1
end_operator
begin_operator
up f11 f44
1
232 0
1
0 0 2 38
1
end_operator
begin_operator
up f11 f45
1
233 0
1
0 0 2 39
1
end_operator
begin_operator
up f11 f46
1
234 0
1
0 0 2 40
1
end_operator
begin_operator
up f11 f47
1
235 0
1
0 0 2 41
1
end_operator
begin_operator
up f11 f48
1
236 0
1
0 0 2 42
1
end_operator
begin_operator
up f11 f49
1
237 0
1
0 0 2 43
1
end_operator
begin_operator
up f11 f50
1
238 0
1
0 0 2 45
1
end_operator
begin_operator
up f11 f51
1
239 0
1
0 0 2 46
1
end_operator
begin_operator
up f11 f52
1
240 0
1
0 0 2 47
1
end_operator
begin_operator
up f11 f53
1
241 0
1
0 0 2 48
1
end_operator
begin_operator
up f11 f54
1
242 0
1
0 0 2 49
1
end_operator
begin_operator
up f11 f55
1
243 0
1
0 0 2 50
1
end_operator
begin_operator
up f11 f56
1
244 0
1
0 0 2 51
1
end_operator
begin_operator
up f11 f57
1
245 0
1
0 0 2 52
1
end_operator
begin_operator
up f11 f58
1
246 0
1
0 0 2 53
1
end_operator
begin_operator
up f11 f59
1
247 0
1
0 0 2 54
1
end_operator
begin_operator
up f11 f60
1
248 0
1
0 0 2 56
1
end_operator
begin_operator
up f11 f61
1
249 0
1
0 0 2 57
1
end_operator
begin_operator
up f11 f62
1
250 0
1
0 0 2 58
1
end_operator
begin_operator
up f11 f63
1
251 0
1
0 0 2 59
1
end_operator
begin_operator
up f11 f64
1
252 0
1
0 0 2 60
1
end_operator
begin_operator
up f11 f65
1
253 0
1
0 0 2 61
1
end_operator
begin_operator
up f11 f66
1
254 0
1
0 0 2 62
1
end_operator
begin_operator
up f11 f67
1
255 0
1
0 0 2 63
1
end_operator
begin_operator
up f11 f68
1
256 0
1
0 0 2 64
1
end_operator
begin_operator
up f11 f69
1
257 0
1
0 0 2 65
1
end_operator
begin_operator
up f11 f70
1
258 0
1
0 0 2 67
1
end_operator
begin_operator
up f11 f71
1
259 0
1
0 0 2 68
1
end_operator
begin_operator
up f11 f72
1
260 0
1
0 0 2 69
1
end_operator
begin_operator
up f11 f73
1
261 0
1
0 0 2 70
1
end_operator
begin_operator
up f11 f74
1
262 0
1
0 0 2 71
1
end_operator
begin_operator
up f11 f75
1
263 0
1
0 0 2 72
1
end_operator
begin_operator
up f11 f76
1
264 0
1
0 0 2 73
1
end_operator
begin_operator
up f11 f77
1
265 0
1
0 0 2 74
1
end_operator
begin_operator
up f11 f78
1
266 0
1
0 0 2 75
1
end_operator
begin_operator
up f11 f79
1
267 0
1
0 0 2 76
1
end_operator
begin_operator
up f11 f80
1
268 0
1
0 0 2 78
1
end_operator
begin_operator
up f12 f13
1
269 0
1
0 0 3 4
1
end_operator
begin_operator
up f12 f14
1
270 0
1
0 0 3 5
1
end_operator
begin_operator
up f12 f15
1
271 0
1
0 0 3 6
1
end_operator
begin_operator
up f12 f16
1
272 0
1
0 0 3 7
1
end_operator
begin_operator
up f12 f17
1
273 0
1
0 0 3 8
1
end_operator
begin_operator
up f12 f18
1
274 0
1
0 0 3 9
1
end_operator
begin_operator
up f12 f19
1
275 0
1
0 0 3 10
1
end_operator
begin_operator
up f12 f20
1
276 0
1
0 0 3 12
1
end_operator
begin_operator
up f12 f21
1
277 0
1
0 0 3 13
1
end_operator
begin_operator
up f12 f22
1
278 0
1
0 0 3 14
1
end_operator
begin_operator
up f12 f23
1
279 0
1
0 0 3 15
1
end_operator
begin_operator
up f12 f24
1
280 0
1
0 0 3 16
1
end_operator
begin_operator
up f12 f25
1
281 0
1
0 0 3 17
1
end_operator
begin_operator
up f12 f26
1
282 0
1
0 0 3 18
1
end_operator
begin_operator
up f12 f27
1
283 0
1
0 0 3 19
1
end_operator
begin_operator
up f12 f28
1
284 0
1
0 0 3 20
1
end_operator
begin_operator
up f12 f29
1
285 0
1
0 0 3 21
1
end_operator
begin_operator
up f12 f30
1
286 0
1
0 0 3 23
1
end_operator
begin_operator
up f12 f31
1
287 0
1
0 0 3 24
1
end_operator
begin_operator
up f12 f32
1
288 0
1
0 0 3 25
1
end_operator
begin_operator
up f12 f33
1
289 0
1
0 0 3 26
1
end_operator
begin_operator
up f12 f34
1
290 0
1
0 0 3 27
1
end_operator
begin_operator
up f12 f35
1
291 0
1
0 0 3 28
1
end_operator
begin_operator
up f12 f36
1
292 0
1
0 0 3 29
1
end_operator
begin_operator
up f12 f37
1
293 0
1
0 0 3 30
1
end_operator
begin_operator
up f12 f38
1
294 0
1
0 0 3 31
1
end_operator
begin_operator
up f12 f39
1
295 0
1
0 0 3 32
1
end_operator
begin_operator
up f12 f40
1
296 0
1
0 0 3 34
1
end_operator
begin_operator
up f12 f41
1
297 0
1
0 0 3 35
1
end_operator
begin_operator
up f12 f42
1
298 0
1
0 0 3 36
1
end_operator
begin_operator
up f12 f43
1
299 0
1
0 0 3 37
1
end_operator
begin_operator
up f12 f44
1
300 0
1
0 0 3 38
1
end_operator
begin_operator
up f12 f45
1
301 0
1
0 0 3 39
1
end_operator
begin_operator
up f12 f46
1
302 0
1
0 0 3 40
1
end_operator
begin_operator
up f12 f47
1
303 0
1
0 0 3 41
1
end_operator
begin_operator
up f12 f48
1
304 0
1
0 0 3 42
1
end_operator
begin_operator
up f12 f49
1
305 0
1
0 0 3 43
1
end_operator
begin_operator
up f12 f50
1
306 0
1
0 0 3 45
1
end_operator
begin_operator
up f12 f51
1
307 0
1
0 0 3 46
1
end_operator
begin_operator
up f12 f52
1
308 0
1
0 0 3 47
1
end_operator
begin_operator
up f12 f53
1
309 0
1
0 0 3 48
1
end_operator
begin_operator
up f12 f54
1
310 0
1
0 0 3 49
1
end_operator
begin_operator
up f12 f55
1
311 0
1
0 0 3 50
1
end_operator
begin_operator
up f12 f56
1
312 0
1
0 0 3 51
1
end_operator
begin_operator
up f12 f57
1
313 0
1
0 0 3 52
1
end_operator
begin_operator
up f12 f58
1
314 0
1
0 0 3 53
1
end_operator
begin_operator
up f12 f59
1
315 0
1
0 0 3 54
1
end_operator
begin_operator
up f12 f60
1
316 0
1
0 0 3 56
1
end_operator
begin_operator
up f12 f61
1
317 0
1
0 0 3 57
1
end_operator
begin_operator
up f12 f62
1
318 0
1
0 0 3 58
1
end_operator
begin_operator
up f12 f63
1
319 0
1
0 0 3 59
1
end_operator
begin_operator
up f12 f64
1
320 0
1
0 0 3 60
1
end_operator
begin_operator
up f12 f65
1
321 0
1
0 0 3 61
1
end_operator
begin_operator
up f12 f66
1
322 0
1
0 0 3 62
1
end_operator
begin_operator
up f12 f67
1
323 0
1
0 0 3 63
1
end_operator
begin_operator
up f12 f68
1
324 0
1
0 0 3 64
1
end_operator
begin_operator
up f12 f69
1
325 0
1
0 0 3 65
1
end_operator
begin_operator
up f12 f70
1
326 0
1
0 0 3 67
1
end_operator
begin_operator
up f12 f71
1
327 0
1
0 0 3 68
1
end_operator
begin_operator
up f12 f72
1
328 0
1
0 0 3 69
1
end_operator
begin_operator
up f12 f73
1
329 0
1
0 0 3 70
1
end_operator
begin_operator
up f12 f74
1
330 0
1
0 0 3 71
1
end_operator
begin_operator
up f12 f75
1
331 0
1
0 0 3 72
1
end_operator
begin_operator
up f12 f76
1
332 0
1
0 0 3 73
1
end_operator
begin_operator
up f12 f77
1
333 0
1
0 0 3 74
1
end_operator
begin_operator
up f12 f78
1
334 0
1
0 0 3 75
1
end_operator
begin_operator
up f12 f79
1
335 0
1
0 0 3 76
1
end_operator
begin_operator
up f12 f80
1
336 0
1
0 0 3 78
1
end_operator
begin_operator
up f13 f14
1
337 0
1
0 0 4 5
1
end_operator
begin_operator
up f13 f15
1
338 0
1
0 0 4 6
1
end_operator
begin_operator
up f13 f16
1
339 0
1
0 0 4 7
1
end_operator
begin_operator
up f13 f17
1
340 0
1
0 0 4 8
1
end_operator
begin_operator
up f13 f18
1
341 0
1
0 0 4 9
1
end_operator
begin_operator
up f13 f19
1
342 0
1
0 0 4 10
1
end_operator
begin_operator
up f13 f20
1
343 0
1
0 0 4 12
1
end_operator
begin_operator
up f13 f21
1
344 0
1
0 0 4 13
1
end_operator
begin_operator
up f13 f22
1
345 0
1
0 0 4 14
1
end_operator
begin_operator
up f13 f23
1
346 0
1
0 0 4 15
1
end_operator
begin_operator
up f13 f24
1
347 0
1
0 0 4 16
1
end_operator
begin_operator
up f13 f25
1
348 0
1
0 0 4 17
1
end_operator
begin_operator
up f13 f26
1
349 0
1
0 0 4 18
1
end_operator
begin_operator
up f13 f27
1
350 0
1
0 0 4 19
1
end_operator
begin_operator
up f13 f28
1
351 0
1
0 0 4 20
1
end_operator
begin_operator
up f13 f29
1
352 0
1
0 0 4 21
1
end_operator
begin_operator
up f13 f30
1
353 0
1
0 0 4 23
1
end_operator
begin_operator
up f13 f31
1
354 0
1
0 0 4 24
1
end_operator
begin_operator
up f13 f32
1
355 0
1
0 0 4 25
1
end_operator
begin_operator
up f13 f33
1
356 0
1
0 0 4 26
1
end_operator
begin_operator
up f13 f34
1
357 0
1
0 0 4 27
1
end_operator
begin_operator
up f13 f35
1
358 0
1
0 0 4 28
1
end_operator
begin_operator
up f13 f36
1
359 0
1
0 0 4 29
1
end_operator
begin_operator
up f13 f37
1
360 0
1
0 0 4 30
1
end_operator
begin_operator
up f13 f38
1
361 0
1
0 0 4 31
1
end_operator
begin_operator
up f13 f39
1
362 0
1
0 0 4 32
1
end_operator
begin_operator
up f13 f40
1
363 0
1
0 0 4 34
1
end_operator
begin_operator
up f13 f41
1
364 0
1
0 0 4 35
1
end_operator
begin_operator
up f13 f42
1
365 0
1
0 0 4 36
1
end_operator
begin_operator
up f13 f43
1
366 0
1
0 0 4 37
1
end_operator
begin_operator
up f13 f44
1
367 0
1
0 0 4 38
1
end_operator
begin_operator
up f13 f45
1
368 0
1
0 0 4 39
1
end_operator
begin_operator
up f13 f46
1
369 0
1
0 0 4 40
1
end_operator
begin_operator
up f13 f47
1
370 0
1
0 0 4 41
1
end_operator
begin_operator
up f13 f48
1
371 0
1
0 0 4 42
1
end_operator
begin_operator
up f13 f49
1
372 0
1
0 0 4 43
1
end_operator
begin_operator
up f13 f50
1
373 0
1
0 0 4 45
1
end_operator
begin_operator
up f13 f51
1
374 0
1
0 0 4 46
1
end_operator
begin_operator
up f13 f52
1
375 0
1
0 0 4 47
1
end_operator
begin_operator
up f13 f53
1
376 0
1
0 0 4 48
1
end_operator
begin_operator
up f13 f54
1
377 0
1
0 0 4 49
1
end_operator
begin_operator
up f13 f55
1
378 0
1
0 0 4 50
1
end_operator
begin_operator
up f13 f56
1
379 0
1
0 0 4 51
1
end_operator
begin_operator
up f13 f57
1
380 0
1
0 0 4 52
1
end_operator
begin_operator
up f13 f58
1
381 0
1
0 0 4 53
1
end_operator
begin_operator
up f13 f59
1
382 0
1
0 0 4 54
1
end_operator
begin_operator
up f13 f60
1
383 0
1
0 0 4 56
1
end_operator
begin_operator
up f13 f61
1
384 0
1
0 0 4 57
1
end_operator
begin_operator
up f13 f62
1
385 0
1
0 0 4 58
1
end_operator
begin_operator
up f13 f63
1
386 0
1
0 0 4 59
1
end_operator
begin_operator
up f13 f64
1
387 0
1
0 0 4 60
1
end_operator
begin_operator
up f13 f65
1
388 0
1
0 0 4 61
1
end_operator
begin_operator
up f13 f66
1
389 0
1
0 0 4 62
1
end_operator
begin_operator
up f13 f67
1
390 0
1
0 0 4 63
1
end_operator
begin_operator
up f13 f68
1
391 0
1
0 0 4 64
1
end_operator
begin_operator
up f13 f69
1
392 0
1
0 0 4 65
1
end_operator
begin_operator
up f13 f70
1
393 0
1
0 0 4 67
1
end_operator
begin_operator
up f13 f71
1
394 0
1
0 0 4 68
1
end_operator
begin_operator
up f13 f72
1
395 0
1
0 0 4 69
1
end_operator
begin_operator
up f13 f73
1
396 0
1
0 0 4 70
1
end_operator
begin_operator
up f13 f74
1
397 0
1
0 0 4 71
1
end_operator
begin_operator
up f13 f75
1
398 0
1
0 0 4 72
1
end_operator
begin_operator
up f13 f76
1
399 0
1
0 0 4 73
1
end_operator
begin_operator
up f13 f77
1
400 0
1
0 0 4 74
1
end_operator
begin_operator
up f13 f78
1
401 0
1
0 0 4 75
1
end_operator
begin_operator
up f13 f79
1
402 0
1
0 0 4 76
1
end_operator
begin_operator
up f13 f80
1
403 0
1
0 0 4 78
1
end_operator
begin_operator
up f14 f15
1
404 0
1
0 0 5 6
1
end_operator
begin_operator
up f14 f16
1
405 0
1
0 0 5 7
1
end_operator
begin_operator
up f14 f17
1
406 0
1
0 0 5 8
1
end_operator
begin_operator
up f14 f18
1
407 0
1
0 0 5 9
1
end_operator
begin_operator
up f14 f19
1
408 0
1
0 0 5 10
1
end_operator
begin_operator
up f14 f20
1
409 0
1
0 0 5 12
1
end_operator
begin_operator
up f14 f21
1
410 0
1
0 0 5 13
1
end_operator
begin_operator
up f14 f22
1
411 0
1
0 0 5 14
1
end_operator
begin_operator
up f14 f23
1
412 0
1
0 0 5 15
1
end_operator
begin_operator
up f14 f24
1
413 0
1
0 0 5 16
1
end_operator
begin_operator
up f14 f25
1
414 0
1
0 0 5 17
1
end_operator
begin_operator
up f14 f26
1
415 0
1
0 0 5 18
1
end_operator
begin_operator
up f14 f27
1
416 0
1
0 0 5 19
1
end_operator
begin_operator
up f14 f28
1
417 0
1
0 0 5 20
1
end_operator
begin_operator
up f14 f29
1
418 0
1
0 0 5 21
1
end_operator
begin_operator
up f14 f30
1
419 0
1
0 0 5 23
1
end_operator
begin_operator
up f14 f31
1
420 0
1
0 0 5 24
1
end_operator
begin_operator
up f14 f32
1
421 0
1
0 0 5 25
1
end_operator
begin_operator
up f14 f33
1
422 0
1
0 0 5 26
1
end_operator
begin_operator
up f14 f34
1
423 0
1
0 0 5 27
1
end_operator
begin_operator
up f14 f35
1
424 0
1
0 0 5 28
1
end_operator
begin_operator
up f14 f36
1
425 0
1
0 0 5 29
1
end_operator
begin_operator
up f14 f37
1
426 0
1
0 0 5 30
1
end_operator
begin_operator
up f14 f38
1
427 0
1
0 0 5 31
1
end_operator
begin_operator
up f14 f39
1
428 0
1
0 0 5 32
1
end_operator
begin_operator
up f14 f40
1
429 0
1
0 0 5 34
1
end_operator
begin_operator
up f14 f41
1
430 0
1
0 0 5 35
1
end_operator
begin_operator
up f14 f42
1
431 0
1
0 0 5 36
1
end_operator
begin_operator
up f14 f43
1
432 0
1
0 0 5 37
1
end_operator
begin_operator
up f14 f44
1
433 0
1
0 0 5 38
1
end_operator
begin_operator
up f14 f45
1
434 0
1
0 0 5 39
1
end_operator
begin_operator
up f14 f46
1
435 0
1
0 0 5 40
1
end_operator
begin_operator
up f14 f47
1
436 0
1
0 0 5 41
1
end_operator
begin_operator
up f14 f48
1
437 0
1
0 0 5 42
1
end_operator
begin_operator
up f14 f49
1
438 0
1
0 0 5 43
1
end_operator
begin_operator
up f14 f50
1
439 0
1
0 0 5 45
1
end_operator
begin_operator
up f14 f51
1
440 0
1
0 0 5 46
1
end_operator
begin_operator
up f14 f52
1
441 0
1
0 0 5 47
1
end_operator
begin_operator
up f14 f53
1
442 0
1
0 0 5 48
1
end_operator
begin_operator
up f14 f54
1
443 0
1
0 0 5 49
1
end_operator
begin_operator
up f14 f55
1
444 0
1
0 0 5 50
1
end_operator
begin_operator
up f14 f56
1
445 0
1
0 0 5 51
1
end_operator
begin_operator
up f14 f57
1
446 0
1
0 0 5 52
1
end_operator
begin_operator
up f14 f58
1
447 0
1
0 0 5 53
1
end_operator
begin_operator
up f14 f59
1
448 0
1
0 0 5 54
1
end_operator
begin_operator
up f14 f60
1
449 0
1
0 0 5 56
1
end_operator
begin_operator
up f14 f61
1
450 0
1
0 0 5 57
1
end_operator
begin_operator
up f14 f62
1
451 0
1
0 0 5 58
1
end_operator
begin_operator
up f14 f63
1
452 0
1
0 0 5 59
1
end_operator
begin_operator
up f14 f64
1
453 0
1
0 0 5 60
1
end_operator
begin_operator
up f14 f65
1
454 0
1
0 0 5 61
1
end_operator
begin_operator
up f14 f66
1
455 0
1
0 0 5 62
1
end_operator
begin_operator
up f14 f67
1
456 0
1
0 0 5 63
1
end_operator
begin_operator
up f14 f68
1
457 0
1
0 0 5 64
1
end_operator
begin_operator
up f14 f69
1
458 0
1
0 0 5 65
1
end_operator
begin_operator
up f14 f70
1
459 0
1
0 0 5 67
1
end_operator
begin_operator
up f14 f71
1
460 0
1
0 0 5 68
1
end_operator
begin_operator
up f14 f72
1
461 0
1
0 0 5 69
1
end_operator
begin_operator
up f14 f73
1
462 0
1
0 0 5 70
1
end_operator
begin_operator
up f14 f74
1
463 0
1
0 0 5 71
1
end_operator
begin_operator
up f14 f75
1
464 0
1
0 0 5 72
1
end_operator
begin_operator
up f14 f76
1
465 0
1
0 0 5 73
1
end_operator
begin_operator
up f14 f77
1
466 0
1
0 0 5 74
1
end_operator
begin_operator
up f14 f78
1
467 0
1
0 0 5 75
1
end_operator
begin_operator
up f14 f79
1
468 0
1
0 0 5 76
1
end_operator
begin_operator
up f14 f80
1
469 0
1
0 0 5 78
1
end_operator
begin_operator
up f15 f16
1
470 0
1
0 0 6 7
1
end_operator
begin_operator
up f15 f17
1
471 0
1
0 0 6 8
1
end_operator
begin_operator
up f15 f18
1
472 0
1
0 0 6 9
1
end_operator
begin_operator
up f15 f19
1
473 0
1
0 0 6 10
1
end_operator
begin_operator
up f15 f20
1
474 0
1
0 0 6 12
1
end_operator
begin_operator
up f15 f21
1
475 0
1
0 0 6 13
1
end_operator
begin_operator
up f15 f22
1
476 0
1
0 0 6 14
1
end_operator
begin_operator
up f15 f23
1
477 0
1
0 0 6 15
1
end_operator
begin_operator
up f15 f24
1
478 0
1
0 0 6 16
1
end_operator
begin_operator
up f15 f25
1
479 0
1
0 0 6 17
1
end_operator
begin_operator
up f15 f26
1
480 0
1
0 0 6 18
1
end_operator
begin_operator
up f15 f27
1
481 0
1
0 0 6 19
1
end_operator
begin_operator
up f15 f28
1
482 0
1
0 0 6 20
1
end_operator
begin_operator
up f15 f29
1
483 0
1
0 0 6 21
1
end_operator
begin_operator
up f15 f30
1
484 0
1
0 0 6 23
1
end_operator
begin_operator
up f15 f31
1
485 0
1
0 0 6 24
1
end_operator
begin_operator
up f15 f32
1
486 0
1
0 0 6 25
1
end_operator
begin_operator
up f15 f33
1
487 0
1
0 0 6 26
1
end_operator
begin_operator
up f15 f34
1
488 0
1
0 0 6 27
1
end_operator
begin_operator
up f15 f35
1
489 0
1
0 0 6 28
1
end_operator
begin_operator
up f15 f36
1
490 0
1
0 0 6 29
1
end_operator
begin_operator
up f15 f37
1
491 0
1
0 0 6 30
1
end_operator
begin_operator
up f15 f38
1
492 0
1
0 0 6 31
1
end_operator
begin_operator
up f15 f39
1
493 0
1
0 0 6 32
1
end_operator
begin_operator
up f15 f40
1
494 0
1
0 0 6 34
1
end_operator
begin_operator
up f15 f41
1
495 0
1
0 0 6 35
1
end_operator
begin_operator
up f15 f42
1
496 0
1
0 0 6 36
1
end_operator
begin_operator
up f15 f43
1
497 0
1
0 0 6 37
1
end_operator
begin_operator
up f15 f44
1
498 0
1
0 0 6 38
1
end_operator
begin_operator
up f15 f45
1
499 0
1
0 0 6 39
1
end_operator
begin_operator
up f15 f46
1
500 0
1
0 0 6 40
1
end_operator
begin_operator
up f15 f47
1
501 0
1
0 0 6 41
1
end_operator
begin_operator
up f15 f48
1
502 0
1
0 0 6 42
1
end_operator
begin_operator
up f15 f49
1
503 0
1
0 0 6 43
1
end_operator
begin_operator
up f15 f50
1
504 0
1
0 0 6 45
1
end_operator
begin_operator
up f15 f51
1
505 0
1
0 0 6 46
1
end_operator
begin_operator
up f15 f52
1
506 0
1
0 0 6 47
1
end_operator
begin_operator
up f15 f53
1
507 0
1
0 0 6 48
1
end_operator
begin_operator
up f15 f54
1
508 0
1
0 0 6 49
1
end_operator
begin_operator
up f15 f55
1
509 0
1
0 0 6 50
1
end_operator
begin_operator
up f15 f56
1
510 0
1
0 0 6 51
1
end_operator
begin_operator
up f15 f57
1
511 0
1
0 0 6 52
1
end_operator
begin_operator
up f15 f58
1
512 0
1
0 0 6 53
1
end_operator
begin_operator
up f15 f59
1
513 0
1
0 0 6 54
1
end_operator
begin_operator
up f15 f60
1
514 0
1
0 0 6 56
1
end_operator
begin_operator
up f15 f61
1
515 0
1
0 0 6 57
1
end_operator
begin_operator
up f15 f62
1
516 0
1
0 0 6 58
1
end_operator
begin_operator
up f15 f63
1
517 0
1
0 0 6 59
1
end_operator
begin_operator
up f15 f64
1
518 0
1
0 0 6 60
1
end_operator
begin_operator
up f15 f65
1
519 0
1
0 0 6 61
1
end_operator
begin_operator
up f15 f66
1
520 0
1
0 0 6 62
1
end_operator
begin_operator
up f15 f67
1
521 0
1
0 0 6 63
1
end_operator
begin_operator
up f15 f68
1
522 0
1
0 0 6 64
1
end_operator
begin_operator
up f15 f69
1
523 0
1
0 0 6 65
1
end_operator
begin_operator
up f15 f70
1
524 0
1
0 0 6 67
1
end_operator
begin_operator
up f15 f71
1
525 0
1
0 0 6 68
1
end_operator
begin_operator
up f15 f72
1
526 0
1
0 0 6 69
1
end_operator
begin_operator
up f15 f73
1
527 0
1
0 0 6 70
1
end_operator
begin_operator
up f15 f74
1
528 0
1
0 0 6 71
1
end_operator
begin_operator
up f15 f75
1
529 0
1
0 0 6 72
1
end_operator
begin_operator
up f15 f76
1
530 0
1
0 0 6 73
1
end_operator
begin_operator
up f15 f77
1
531 0
1
0 0 6 74
1
end_operator
begin_operator
up f15 f78
1
532 0
1
0 0 6 75
1
end_operator
begin_operator
up f15 f79
1
533 0
1
0 0 6 76
1
end_operator
begin_operator
up f15 f80
1
534 0
1
0 0 6 78
1
end_operator
begin_operator
up f16 f17
1
535 0
1
0 0 7 8
1
end_operator
begin_operator
up f16 f18
1
536 0
1
0 0 7 9
1
end_operator
begin_operator
up f16 f19
1
537 0
1
0 0 7 10
1
end_operator
begin_operator
up f16 f20
1
538 0
1
0 0 7 12
1
end_operator
begin_operator
up f16 f21
1
539 0
1
0 0 7 13
1
end_operator
begin_operator
up f16 f22
1
540 0
1
0 0 7 14
1
end_operator
begin_operator
up f16 f23
1
541 0
1
0 0 7 15
1
end_operator
begin_operator
up f16 f24
1
542 0
1
0 0 7 16
1
end_operator
begin_operator
up f16 f25
1
543 0
1
0 0 7 17
1
end_operator
begin_operator
up f16 f26
1
544 0
1
0 0 7 18
1
end_operator
begin_operator
up f16 f27
1
545 0
1
0 0 7 19
1
end_operator
begin_operator
up f16 f28
1
546 0
1
0 0 7 20
1
end_operator
begin_operator
up f16 f29
1
547 0
1
0 0 7 21
1
end_operator
begin_operator
up f16 f30
1
548 0
1
0 0 7 23
1
end_operator
begin_operator
up f16 f31
1
549 0
1
0 0 7 24
1
end_operator
begin_operator
up f16 f32
1
550 0
1
0 0 7 25
1
end_operator
begin_operator
up f16 f33
1
551 0
1
0 0 7 26
1
end_operator
begin_operator
up f16 f34
1
552 0
1
0 0 7 27
1
end_operator
begin_operator
up f16 f35
1
553 0
1
0 0 7 28
1
end_operator
begin_operator
up f16 f36
1
554 0
1
0 0 7 29
1
end_operator
begin_operator
up f16 f37
1
555 0
1
0 0 7 30
1
end_operator
begin_operator
up f16 f38
1
556 0
1
0 0 7 31
1
end_operator
begin_operator
up f16 f39
1
557 0
1
0 0 7 32
1
end_operator
begin_operator
up f16 f40
1
558 0
1
0 0 7 34
1
end_operator
begin_operator
up f16 f41
1
559 0
1
0 0 7 35
1
end_operator
begin_operator
up f16 f42
1
560 0
1
0 0 7 36
1
end_operator
begin_operator
up f16 f43
1
561 0
1
0 0 7 37
1
end_operator
begin_operator
up f16 f44
1
562 0
1
0 0 7 38
1
end_operator
begin_operator
up f16 f45
1
563 0
1
0 0 7 39
1
end_operator
begin_operator
up f16 f46
1
564 0
1
0 0 7 40
1
end_operator
begin_operator
up f16 f47
1
565 0
1
0 0 7 41
1
end_operator
begin_operator
up f16 f48
1
566 0
1
0 0 7 42
1
end_operator
begin_operator
up f16 f49
1
567 0
1
0 0 7 43
1
end_operator
begin_operator
up f16 f50
1
568 0
1
0 0 7 45
1
end_operator
begin_operator
up f16 f51
1
569 0
1
0 0 7 46
1
end_operator
begin_operator
up f16 f52
1
570 0
1
0 0 7 47
1
end_operator
begin_operator
up f16 f53
1
571 0
1
0 0 7 48
1
end_operator
begin_operator
up f16 f54
1
572 0
1
0 0 7 49
1
end_operator
begin_operator
up f16 f55
1
573 0
1
0 0 7 50
1
end_operator
begin_operator
up f16 f56
1
574 0
1
0 0 7 51
1
end_operator
begin_operator
up f16 f57
1
575 0
1
0 0 7 52
1
end_operator
begin_operator
up f16 f58
1
576 0
1
0 0 7 53
1
end_operator
begin_operator
up f16 f59
1
577 0
1
0 0 7 54
1
end_operator
begin_operator
up f16 f60
1
578 0
1
0 0 7 56
1
end_operator
begin_operator
up f16 f61
1
579 0
1
0 0 7 57
1
end_operator
begin_operator
up f16 f62
1
580 0
1
0 0 7 58
1
end_operator
begin_operator
up f16 f63
1
581 0
1
0 0 7 59
1
end_operator
begin_operator
up f16 f64
1
582 0
1
0 0 7 60
1
end_operator
begin_operator
up f16 f65
1
583 0
1
0 0 7 61
1
end_operator
begin_operator
up f16 f66
1
584 0
1
0 0 7 62
1
end_operator
begin_operator
up f16 f67
1
585 0
1
0 0 7 63
1
end_operator
begin_operator
up f16 f68
1
586 0
1
0 0 7 64
1
end_operator
begin_operator
up f16 f69
1
587 0
1
0 0 7 65
1
end_operator
begin_operator
up f16 f70
1
588 0
1
0 0 7 67
1
end_operator
begin_operator
up f16 f71
1
589 0
1
0 0 7 68
1
end_operator
begin_operator
up f16 f72
1
590 0
1
0 0 7 69
1
end_operator
begin_operator
up f16 f73
1
591 0
1
0 0 7 70
1
end_operator
begin_operator
up f16 f74
1
592 0
1
0 0 7 71
1
end_operator
begin_operator
up f16 f75
1
593 0
1
0 0 7 72
1
end_operator
begin_operator
up f16 f76
1
594 0
1
0 0 7 73
1
end_operator
begin_operator
up f16 f77
1
595 0
1
0 0 7 74
1
end_operator
begin_operator
up f16 f78
1
596 0
1
0 0 7 75
1
end_operator
begin_operator
up f16 f79
1
597 0
1
0 0 7 76
1
end_operator
begin_operator
up f16 f80
1
598 0
1
0 0 7 78
1
end_operator
begin_operator
up f17 f18
1
599 0
1
0 0 8 9
1
end_operator
begin_operator
up f17 f19
1
600 0
1
0 0 8 10
1
end_operator
begin_operator
up f17 f20
1
601 0
1
0 0 8 12
1
end_operator
begin_operator
up f17 f21
1
602 0
1
0 0 8 13
1
end_operator
begin_operator
up f17 f22
1
603 0
1
0 0 8 14
1
end_operator
begin_operator
up f17 f23
1
604 0
1
0 0 8 15
1
end_operator
begin_operator
up f17 f24
1
605 0
1
0 0 8 16
1
end_operator
begin_operator
up f17 f25
1
606 0
1
0 0 8 17
1
end_operator
begin_operator
up f17 f26
1
607 0
1
0 0 8 18
1
end_operator
begin_operator
up f17 f27
1
608 0
1
0 0 8 19
1
end_operator
begin_operator
up f17 f28
1
609 0
1
0 0 8 20
1
end_operator
begin_operator
up f17 f29
1
610 0
1
0 0 8 21
1
end_operator
begin_operator
up f17 f30
1
611 0
1
0 0 8 23
1
end_operator
begin_operator
up f17 f31
1
612 0
1
0 0 8 24
1
end_operator
begin_operator
up f17 f32
1
613 0
1
0 0 8 25
1
end_operator
begin_operator
up f17 f33
1
614 0
1
0 0 8 26
1
end_operator
begin_operator
up f17 f34
1
615 0
1
0 0 8 27
1
end_operator
begin_operator
up f17 f35
1
616 0
1
0 0 8 28
1
end_operator
begin_operator
up f17 f36
1
617 0
1
0 0 8 29
1
end_operator
begin_operator
up f17 f37
1
618 0
1
0 0 8 30
1
end_operator
begin_operator
up f17 f38
1
619 0
1
0 0 8 31
1
end_operator
begin_operator
up f17 f39
1
620 0
1
0 0 8 32
1
end_operator
begin_operator
up f17 f40
1
621 0
1
0 0 8 34
1
end_operator
begin_operator
up f17 f41
1
622 0
1
0 0 8 35
1
end_operator
begin_operator
up f17 f42
1
623 0
1
0 0 8 36
1
end_operator
begin_operator
up f17 f43
1
624 0
1
0 0 8 37
1
end_operator
begin_operator
up f17 f44
1
625 0
1
0 0 8 38
1
end_operator
begin_operator
up f17 f45
1
626 0
1
0 0 8 39
1
end_operator
begin_operator
up f17 f46
1
627 0
1
0 0 8 40
1
end_operator
begin_operator
up f17 f47
1
628 0
1
0 0 8 41
1
end_operator
begin_operator
up f17 f48
1
629 0
1
0 0 8 42
1
end_operator
begin_operator
up f17 f49
1
630 0
1
0 0 8 43
1
end_operator
begin_operator
up f17 f50
1
631 0
1
0 0 8 45
1
end_operator
begin_operator
up f17 f51
1
632 0
1
0 0 8 46
1
end_operator
begin_operator
up f17 f52
1
633 0
1
0 0 8 47
1
end_operator
begin_operator
up f17 f53
1
634 0
1
0 0 8 48
1
end_operator
begin_operator
up f17 f54
1
635 0
1
0 0 8 49
1
end_operator
begin_operator
up f17 f55
1
636 0
1
0 0 8 50
1
end_operator
begin_operator
up f17 f56
1
637 0
1
0 0 8 51
1
end_operator
begin_operator
up f17 f57
1
638 0
1
0 0 8 52
1
end_operator
begin_operator
up f17 f58
1
639 0
1
0 0 8 53
1
end_operator
begin_operator
up f17 f59
1
640 0
1
0 0 8 54
1
end_operator
begin_operator
up f17 f60
1
641 0
1
0 0 8 56
1
end_operator
begin_operator
up f17 f61
1
642 0
1
0 0 8 57
1
end_operator
begin_operator
up f17 f62
1
643 0
1
0 0 8 58
1
end_operator
begin_operator
up f17 f63
1
644 0
1
0 0 8 59
1
end_operator
begin_operator
up f17 f64
1
645 0
1
0 0 8 60
1
end_operator
begin_operator
up f17 f65
1
646 0
1
0 0 8 61
1
end_operator
begin_operator
up f17 f66
1
647 0
1
0 0 8 62
1
end_operator
begin_operator
up f17 f67
1
648 0
1
0 0 8 63
1
end_operator
begin_operator
up f17 f68
1
649 0
1
0 0 8 64
1
end_operator
begin_operator
up f17 f69
1
650 0
1
0 0 8 65
1
end_operator
begin_operator
up f17 f70
1
651 0
1
0 0 8 67
1
end_operator
begin_operator
up f17 f71
1
652 0
1
0 0 8 68
1
end_operator
begin_operator
up f17 f72
1
653 0
1
0 0 8 69
1
end_operator
begin_operator
up f17 f73
1
654 0
1
0 0 8 70
1
end_operator
begin_operator
up f17 f74
1
655 0
1
0 0 8 71
1
end_operator
begin_operator
up f17 f75
1
656 0
1
0 0 8 72
1
end_operator
begin_operator
up f17 f76
1
657 0
1
0 0 8 73
1
end_operator
begin_operator
up f17 f77
1
658 0
1
0 0 8 74
1
end_operator
begin_operator
up f17 f78
1
659 0
1
0 0 8 75
1
end_operator
begin_operator
up f17 f79
1
660 0
1
0 0 8 76
1
end_operator
begin_operator
up f17 f80
1
661 0
1
0 0 8 78
1
end_operator
begin_operator
up f18 f19
1
662 0
1
0 0 9 10
1
end_operator
begin_operator
up f18 f20
1
663 0
1
0 0 9 12
1
end_operator
begin_operator
up f18 f21
1
664 0
1
0 0 9 13
1
end_operator
begin_operator
up f18 f22
1
665 0
1
0 0 9 14
1
end_operator
begin_operator
up f18 f23
1
666 0
1
0 0 9 15
1
end_operator
begin_operator
up f18 f24
1
667 0
1
0 0 9 16
1
end_operator
begin_operator
up f18 f25
1
668 0
1
0 0 9 17
1
end_operator
begin_operator
up f18 f26
1
669 0
1
0 0 9 18
1
end_operator
begin_operator
up f18 f27
1
670 0
1
0 0 9 19
1
end_operator
begin_operator
up f18 f28
1
671 0
1
0 0 9 20
1
end_operator
begin_operator
up f18 f29
1
672 0
1
0 0 9 21
1
end_operator
begin_operator
up f18 f30
1
673 0
1
0 0 9 23
1
end_operator
begin_operator
up f18 f31
1
674 0
1
0 0 9 24
1
end_operator
begin_operator
up f18 f32
1
675 0
1
0 0 9 25
1
end_operator
begin_operator
up f18 f33
1
676 0
1
0 0 9 26
1
end_operator
begin_operator
up f18 f34
1
677 0
1
0 0 9 27
1
end_operator
begin_operator
up f18 f35
1
678 0
1
0 0 9 28
1
end_operator
begin_operator
up f18 f36
1
679 0
1
0 0 9 29
1
end_operator
begin_operator
up f18 f37
1
680 0
1
0 0 9 30
1
end_operator
begin_operator
up f18 f38
1
681 0
1
0 0 9 31
1
end_operator
begin_operator
up f18 f39
1
682 0
1
0 0 9 32
1
end_operator
begin_operator
up f18 f40
1
683 0
1
0 0 9 34
1
end_operator
begin_operator
up f18 f41
1
684 0
1
0 0 9 35
1
end_operator
begin_operator
up f18 f42
1
685 0
1
0 0 9 36
1
end_operator
begin_operator
up f18 f43
1
686 0
1
0 0 9 37
1
end_operator
begin_operator
up f18 f44
1
687 0
1
0 0 9 38
1
end_operator
begin_operator
up f18 f45
1
688 0
1
0 0 9 39
1
end_operator
begin_operator
up f18 f46
1
689 0
1
0 0 9 40
1
end_operator
begin_operator
up f18 f47
1
690 0
1
0 0 9 41
1
end_operator
begin_operator
up f18 f48
1
691 0
1
0 0 9 42
1
end_operator
begin_operator
up f18 f49
1
692 0
1
0 0 9 43
1
end_operator
begin_operator
up f18 f50
1
693 0
1
0 0 9 45
1
end_operator
begin_operator
up f18 f51
1
694 0
1
0 0 9 46
1
end_operator
begin_operator
up f18 f52
1
695 0
1
0 0 9 47
1
end_operator
begin_operator
up f18 f53
1
696 0
1
0 0 9 48
1
end_operator
begin_operator
up f18 f54
1
697 0
1
0 0 9 49
1
end_operator
begin_operator
up f18 f55
1
698 0
1
0 0 9 50
1
end_operator
begin_operator
up f18 f56
1
699 0
1
0 0 9 51
1
end_operator
begin_operator
up f18 f57
1
700 0
1
0 0 9 52
1
end_operator
begin_operator
up f18 f58
1
701 0
1
0 0 9 53
1
end_operator
begin_operator
up f18 f59
1
702 0
1
0 0 9 54
1
end_operator
begin_operator
up f18 f60
1
703 0
1
0 0 9 56
1
end_operator
begin_operator
up f18 f61
1
704 0
1
0 0 9 57
1
end_operator
begin_operator
up f18 f62
1
705 0
1
0 0 9 58
1
end_operator
begin_operator
up f18 f63
1
706 0
1
0 0 9 59
1
end_operator
begin_operator
up f18 f64
1
707 0
1
0 0 9 60
1
end_operator
begin_operator
up f18 f65
1
708 0
1
0 0 9 61
1
end_operator
begin_operator
up f18 f66
1
709 0
1
0 0 9 62
1
end_operator
begin_operator
up f18 f67
1
710 0
1
0 0 9 63
1
end_operator
begin_operator
up f18 f68
1
711 0
1
0 0 9 64
1
end_operator
begin_operator
up f18 f69
1
712 0
1
0 0 9 65
1
end_operator
begin_operator
up f18 f70
1
713 0
1
0 0 9 67
1
end_operator
begin_operator
up f18 f71
1
714 0
1
0 0 9 68
1
end_operator
begin_operator
up f18 f72
1
715 0
1
0 0 9 69
1
end_operator
begin_operator
up f18 f73
1
716 0
1
0 0 9 70
1
end_operator
begin_operator
up f18 f74
1
717 0
1
0 0 9 71
1
end_operator
begin_operator
up f18 f75
1
718 0
1
0 0 9 72
1
end_operator
begin_operator
up f18 f76
1
719 0
1
0 0 9 73
1
end_operator
begin_operator
up f18 f77
1
720 0
1
0 0 9 74
1
end_operator
begin_operator
up f18 f78
1
721 0
1
0 0 9 75
1
end_operator
begin_operator
up f18 f79
1
722 0
1
0 0 9 76
1
end_operator
begin_operator
up f18 f80
1
723 0
1
0 0 9 78
1
end_operator
begin_operator
up f19 f20
1
724 0
1
0 0 10 12
1
end_operator
begin_operator
up f19 f21
1
725 0
1
0 0 10 13
1
end_operator
begin_operator
up f19 f22
1
726 0
1
0 0 10 14
1
end_operator
begin_operator
up f19 f23
1
727 0
1
0 0 10 15
1
end_operator
begin_operator
up f19 f24
1
728 0
1
0 0 10 16
1
end_operator
begin_operator
up f19 f25
1
729 0
1
0 0 10 17
1
end_operator
begin_operator
up f19 f26
1
730 0
1
0 0 10 18
1
end_operator
begin_operator
up f19 f27
1
731 0
1
0 0 10 19
1
end_operator
begin_operator
up f19 f28
1
732 0
1
0 0 10 20
1
end_operator
begin_operator
up f19 f29
1
733 0
1
0 0 10 21
1
end_operator
begin_operator
up f19 f30
1
734 0
1
0 0 10 23
1
end_operator
begin_operator
up f19 f31
1
735 0
1
0 0 10 24
1
end_operator
begin_operator
up f19 f32
1
736 0
1
0 0 10 25
1
end_operator
begin_operator
up f19 f33
1
737 0
1
0 0 10 26
1
end_operator
begin_operator
up f19 f34
1
738 0
1
0 0 10 27
1
end_operator
begin_operator
up f19 f35
1
739 0
1
0 0 10 28
1
end_operator
begin_operator
up f19 f36
1
740 0
1
0 0 10 29
1
end_operator
begin_operator
up f19 f37
1
741 0
1
0 0 10 30
1
end_operator
begin_operator
up f19 f38
1
742 0
1
0 0 10 31
1
end_operator
begin_operator
up f19 f39
1
743 0
1
0 0 10 32
1
end_operator
begin_operator
up f19 f40
1
744 0
1
0 0 10 34
1
end_operator
begin_operator
up f19 f41
1
745 0
1
0 0 10 35
1
end_operator
begin_operator
up f19 f42
1
746 0
1
0 0 10 36
1
end_operator
begin_operator
up f19 f43
1
747 0
1
0 0 10 37
1
end_operator
begin_operator
up f19 f44
1
748 0
1
0 0 10 38
1
end_operator
begin_operator
up f19 f45
1
749 0
1
0 0 10 39
1
end_operator
begin_operator
up f19 f46
1
750 0
1
0 0 10 40
1
end_operator
begin_operator
up f19 f47
1
751 0
1
0 0 10 41
1
end_operator
begin_operator
up f19 f48
1
752 0
1
0 0 10 42
1
end_operator
begin_operator
up f19 f49
1
753 0
1
0 0 10 43
1
end_operator
begin_operator
up f19 f50
1
754 0
1
0 0 10 45
1
end_operator
begin_operator
up f19 f51
1
755 0
1
0 0 10 46
1
end_operator
begin_operator
up f19 f52
1
756 0
1
0 0 10 47
1
end_operator
begin_operator
up f19 f53
1
757 0
1
0 0 10 48
1
end_operator
begin_operator
up f19 f54
1
758 0
1
0 0 10 49
1
end_operator
begin_operator
up f19 f55
1
759 0
1
0 0 10 50
1
end_operator
begin_operator
up f19 f56
1
760 0
1
0 0 10 51
1
end_operator
begin_operator
up f19 f57
1
761 0
1
0 0 10 52
1
end_operator
begin_operator
up f19 f58
1
762 0
1
0 0 10 53
1
end_operator
begin_operator
up f19 f59
1
763 0
1
0 0 10 54
1
end_operator
begin_operator
up f19 f60
1
764 0
1
0 0 10 56
1
end_operator
begin_operator
up f19 f61
1
765 0
1
0 0 10 57
1
end_operator
begin_operator
up f19 f62
1
766 0
1
0 0 10 58
1
end_operator
begin_operator
up f19 f63
1
767 0
1
0 0 10 59
1
end_operator
begin_operator
up f19 f64
1
768 0
1
0 0 10 60
1
end_operator
begin_operator
up f19 f65
1
769 0
1
0 0 10 61
1
end_operator
begin_operator
up f19 f66
1
770 0
1
0 0 10 62
1
end_operator
begin_operator
up f19 f67
1
771 0
1
0 0 10 63
1
end_operator
begin_operator
up f19 f68
1
772 0
1
0 0 10 64
1
end_operator
begin_operator
up f19 f69
1
773 0
1
0 0 10 65
1
end_operator
begin_operator
up f19 f70
1
774 0
1
0 0 10 67
1
end_operator
begin_operator
up f19 f71
1
775 0
1
0 0 10 68
1
end_operator
begin_operator
up f19 f72
1
776 0
1
0 0 10 69
1
end_operator
begin_operator
up f19 f73
1
777 0
1
0 0 10 70
1
end_operator
begin_operator
up f19 f74
1
778 0
1
0 0 10 71
1
end_operator
begin_operator
up f19 f75
1
779 0
1
0 0 10 72
1
end_operator
begin_operator
up f19 f76
1
780 0
1
0 0 10 73
1
end_operator
begin_operator
up f19 f77
1
781 0
1
0 0 10 74
1
end_operator
begin_operator
up f19 f78
1
782 0
1
0 0 10 75
1
end_operator
begin_operator
up f19 f79
1
783 0
1
0 0 10 76
1
end_operator
begin_operator
up f19 f80
1
784 0
1
0 0 10 78
1
end_operator
begin_operator
up f2 f10
1
785 0
1
0 0 11 1
1
end_operator
begin_operator
up f2 f11
1
786 0
1
0 0 11 2
1
end_operator
begin_operator
up f2 f12
1
787 0
1
0 0 11 3
1
end_operator
begin_operator
up f2 f13
1
788 0
1
0 0 11 4
1
end_operator
begin_operator
up f2 f14
1
789 0
1
0 0 11 5
1
end_operator
begin_operator
up f2 f15
1
790 0
1
0 0 11 6
1
end_operator
begin_operator
up f2 f16
1
791 0
1
0 0 11 7
1
end_operator
begin_operator
up f2 f17
1
792 0
1
0 0 11 8
1
end_operator
begin_operator
up f2 f18
1
793 0
1
0 0 11 9
1
end_operator
begin_operator
up f2 f19
1
794 0
1
0 0 11 10
1
end_operator
begin_operator
up f2 f20
1
795 0
1
0 0 11 12
1
end_operator
begin_operator
up f2 f21
1
796 0
1
0 0 11 13
1
end_operator
begin_operator
up f2 f22
1
797 0
1
0 0 11 14
1
end_operator
begin_operator
up f2 f23
1
798 0
1
0 0 11 15
1
end_operator
begin_operator
up f2 f24
1
799 0
1
0 0 11 16
1
end_operator
begin_operator
up f2 f25
1
800 0
1
0 0 11 17
1
end_operator
begin_operator
up f2 f26
1
801 0
1
0 0 11 18
1
end_operator
begin_operator
up f2 f27
1
802 0
1
0 0 11 19
1
end_operator
begin_operator
up f2 f28
1
803 0
1
0 0 11 20
1
end_operator
begin_operator
up f2 f29
1
804 0
1
0 0 11 21
1
end_operator
begin_operator
up f2 f3
1
805 0
1
0 0 11 22
1
end_operator
begin_operator
up f2 f30
1
806 0
1
0 0 11 23
1
end_operator
begin_operator
up f2 f31
1
807 0
1
0 0 11 24
1
end_operator
begin_operator
up f2 f32
1
808 0
1
0 0 11 25
1
end_operator
begin_operator
up f2 f33
1
809 0
1
0 0 11 26
1
end_operator
begin_operator
up f2 f34
1
810 0
1
0 0 11 27
1
end_operator
begin_operator
up f2 f35
1
811 0
1
0 0 11 28
1
end_operator
begin_operator
up f2 f36
1
812 0
1
0 0 11 29
1
end_operator
begin_operator
up f2 f37
1
813 0
1
0 0 11 30
1
end_operator
begin_operator
up f2 f38
1
814 0
1
0 0 11 31
1
end_operator
begin_operator
up f2 f39
1
815 0
1
0 0 11 32
1
end_operator
begin_operator
up f2 f4
1
816 0
1
0 0 11 33
1
end_operator
begin_operator
up f2 f40
1
817 0
1
0 0 11 34
1
end_operator
begin_operator
up f2 f41
1
818 0
1
0 0 11 35
1
end_operator
begin_operator
up f2 f42
1
819 0
1
0 0 11 36
1
end_operator
begin_operator
up f2 f43
1
820 0
1
0 0 11 37
1
end_operator
begin_operator
up f2 f44
1
821 0
1
0 0 11 38
1
end_operator
begin_operator
up f2 f45
1
822 0
1
0 0 11 39
1
end_operator
begin_operator
up f2 f46
1
823 0
1
0 0 11 40
1
end_operator
begin_operator
up f2 f47
1
824 0
1
0 0 11 41
1
end_operator
begin_operator
up f2 f48
1
825 0
1
0 0 11 42
1
end_operator
begin_operator
up f2 f49
1
826 0
1
0 0 11 43
1
end_operator
begin_operator
up f2 f5
1
827 0
1
0 0 11 44
1
end_operator
begin_operator
up f2 f50
1
828 0
1
0 0 11 45
1
end_operator
begin_operator
up f2 f51
1
829 0
1
0 0 11 46
1
end_operator
begin_operator
up f2 f52
1
830 0
1
0 0 11 47
1
end_operator
begin_operator
up f2 f53
1
831 0
1
0 0 11 48
1
end_operator
begin_operator
up f2 f54
1
832 0
1
0 0 11 49
1
end_operator
begin_operator
up f2 f55
1
833 0
1
0 0 11 50
1
end_operator
begin_operator
up f2 f56
1
834 0
1
0 0 11 51
1
end_operator
begin_operator
up f2 f57
1
835 0
1
0 0 11 52
1
end_operator
begin_operator
up f2 f58
1
836 0
1
0 0 11 53
1
end_operator
begin_operator
up f2 f59
1
837 0
1
0 0 11 54
1
end_operator
begin_operator
up f2 f6
1
838 0
1
0 0 11 55
1
end_operator
begin_operator
up f2 f60
1
839 0
1
0 0 11 56
1
end_operator
begin_operator
up f2 f61
1
840 0
1
0 0 11 57
1
end_operator
begin_operator
up f2 f62
1
841 0
1
0 0 11 58
1
end_operator
begin_operator
up f2 f63
1
842 0
1
0 0 11 59
1
end_operator
begin_operator
up f2 f64
1
843 0
1
0 0 11 60
1
end_operator
begin_operator
up f2 f65
1
844 0
1
0 0 11 61
1
end_operator
begin_operator
up f2 f66
1
845 0
1
0 0 11 62
1
end_operator
begin_operator
up f2 f67
1
846 0
1
0 0 11 63
1
end_operator
begin_operator
up f2 f68
1
847 0
1
0 0 11 64
1
end_operator
begin_operator
up f2 f69
1
848 0
1
0 0 11 65
1
end_operator
begin_operator
up f2 f7
1
849 0
1
0 0 11 66
1
end_operator
begin_operator
up f2 f70
1
850 0
1
0 0 11 67
1
end_operator
begin_operator
up f2 f71
1
851 0
1
0 0 11 68
1
end_operator
begin_operator
up f2 f72
1
852 0
1
0 0 11 69
1
end_operator
begin_operator
up f2 f73
1
853 0
1
0 0 11 70
1
end_operator
begin_operator
up f2 f74
1
854 0
1
0 0 11 71
1
end_operator
begin_operator
up f2 f75
1
855 0
1
0 0 11 72
1
end_operator
begin_operator
up f2 f76
1
856 0
1
0 0 11 73
1
end_operator
begin_operator
up f2 f77
1
857 0
1
0 0 11 74
1
end_operator
begin_operator
up f2 f78
1
858 0
1
0 0 11 75
1
end_operator
begin_operator
up f2 f79
1
859 0
1
0 0 11 76
1
end_operator
begin_operator
up f2 f8
1
860 0
1
0 0 11 77
1
end_operator
begin_operator
up f2 f80
1
861 0
1
0 0 11 78
1
end_operator
begin_operator
up f2 f9
1
862 0
1
0 0 11 79
1
end_operator
begin_operator
up f20 f21
1
863 0
1
0 0 12 13
1
end_operator
begin_operator
up f20 f22
1
864 0
1
0 0 12 14
1
end_operator
begin_operator
up f20 f23
1
865 0
1
0 0 12 15
1
end_operator
begin_operator
up f20 f24
1
866 0
1
0 0 12 16
1
end_operator
begin_operator
up f20 f25
1
867 0
1
0 0 12 17
1
end_operator
begin_operator
up f20 f26
1
868 0
1
0 0 12 18
1
end_operator
begin_operator
up f20 f27
1
869 0
1
0 0 12 19
1
end_operator
begin_operator
up f20 f28
1
870 0
1
0 0 12 20
1
end_operator
begin_operator
up f20 f29
1
871 0
1
0 0 12 21
1
end_operator
begin_operator
up f20 f30
1
872 0
1
0 0 12 23
1
end_operator
begin_operator
up f20 f31
1
873 0
1
0 0 12 24
1
end_operator
begin_operator
up f20 f32
1
874 0
1
0 0 12 25
1
end_operator
begin_operator
up f20 f33
1
875 0
1
0 0 12 26
1
end_operator
begin_operator
up f20 f34
1
876 0
1
0 0 12 27
1
end_operator
begin_operator
up f20 f35
1
877 0
1
0 0 12 28
1
end_operator
begin_operator
up f20 f36
1
878 0
1
0 0 12 29
1
end_operator
begin_operator
up f20 f37
1
879 0
1
0 0 12 30
1
end_operator
begin_operator
up f20 f38
1
880 0
1
0 0 12 31
1
end_operator
begin_operator
up f20 f39
1
881 0
1
0 0 12 32
1
end_operator
begin_operator
up f20 f40
1
882 0
1
0 0 12 34
1
end_operator
begin_operator
up f20 f41
1
883 0
1
0 0 12 35
1
end_operator
begin_operator
up f20 f42
1
884 0
1
0 0 12 36
1
end_operator
begin_operator
up f20 f43
1
885 0
1
0 0 12 37
1
end_operator
begin_operator
up f20 f44
1
886 0
1
0 0 12 38
1
end_operator
begin_operator
up f20 f45
1
887 0
1
0 0 12 39
1
end_operator
begin_operator
up f20 f46
1
888 0
1
0 0 12 40
1
end_operator
begin_operator
up f20 f47
1
889 0
1
0 0 12 41
1
end_operator
begin_operator
up f20 f48
1
890 0
1
0 0 12 42
1
end_operator
begin_operator
up f20 f49
1
891 0
1
0 0 12 43
1
end_operator
begin_operator
up f20 f50
1
892 0
1
0 0 12 45
1
end_operator
begin_operator
up f20 f51
1
893 0
1
0 0 12 46
1
end_operator
begin_operator
up f20 f52
1
894 0
1
0 0 12 47
1
end_operator
begin_operator
up f20 f53
1
895 0
1
0 0 12 48
1
end_operator
begin_operator
up f20 f54
1
896 0
1
0 0 12 49
1
end_operator
begin_operator
up f20 f55
1
897 0
1
0 0 12 50
1
end_operator
begin_operator
up f20 f56
1
898 0
1
0 0 12 51
1
end_operator
begin_operator
up f20 f57
1
899 0
1
0 0 12 52
1
end_operator
begin_operator
up f20 f58
1
900 0
1
0 0 12 53
1
end_operator
begin_operator
up f20 f59
1
901 0
1
0 0 12 54
1
end_operator
begin_operator
up f20 f60
1
902 0
1
0 0 12 56
1
end_operator
begin_operator
up f20 f61
1
903 0
1
0 0 12 57
1
end_operator
begin_operator
up f20 f62
1
904 0
1
0 0 12 58
1
end_operator
begin_operator
up f20 f63
1
905 0
1
0 0 12 59
1
end_operator
begin_operator
up f20 f64
1
906 0
1
0 0 12 60
1
end_operator
begin_operator
up f20 f65
1
907 0
1
0 0 12 61
1
end_operator
begin_operator
up f20 f66
1
908 0
1
0 0 12 62
1
end_operator
begin_operator
up f20 f67
1
909 0
1
0 0 12 63
1
end_operator
begin_operator
up f20 f68
1
910 0
1
0 0 12 64
1
end_operator
begin_operator
up f20 f69
1
911 0
1
0 0 12 65
1
end_operator
begin_operator
up f20 f70
1
912 0
1
0 0 12 67
1
end_operator
begin_operator
up f20 f71
1
913 0
1
0 0 12 68
1
end_operator
begin_operator
up f20 f72
1
914 0
1
0 0 12 69
1
end_operator
begin_operator
up f20 f73
1
915 0
1
0 0 12 70
1
end_operator
begin_operator
up f20 f74
1
916 0
1
0 0 12 71
1
end_operator
begin_operator
up f20 f75
1
917 0
1
0 0 12 72
1
end_operator
begin_operator
up f20 f76
1
918 0
1
0 0 12 73
1
end_operator
begin_operator
up f20 f77
1
919 0
1
0 0 12 74
1
end_operator
begin_operator
up f20 f78
1
920 0
1
0 0 12 75
1
end_operator
begin_operator
up f20 f79
1
921 0
1
0 0 12 76
1
end_operator
begin_operator
up f20 f80
1
922 0
1
0 0 12 78
1
end_operator
begin_operator
up f21 f22
1
923 0
1
0 0 13 14
1
end_operator
begin_operator
up f21 f23
1
924 0
1
0 0 13 15
1
end_operator
begin_operator
up f21 f24
1
925 0
1
0 0 13 16
1
end_operator
begin_operator
up f21 f25
1
926 0
1
0 0 13 17
1
end_operator
begin_operator
up f21 f26
1
927 0
1
0 0 13 18
1
end_operator
begin_operator
up f21 f27
1
928 0
1
0 0 13 19
1
end_operator
begin_operator
up f21 f28
1
929 0
1
0 0 13 20
1
end_operator
begin_operator
up f21 f29
1
930 0
1
0 0 13 21
1
end_operator
begin_operator
up f21 f30
1
931 0
1
0 0 13 23
1
end_operator
begin_operator
up f21 f31
1
932 0
1
0 0 13 24
1
end_operator
begin_operator
up f21 f32
1
933 0
1
0 0 13 25
1
end_operator
begin_operator
up f21 f33
1
934 0
1
0 0 13 26
1
end_operator
begin_operator
up f21 f34
1
935 0
1
0 0 13 27
1
end_operator
begin_operator
up f21 f35
1
936 0
1
0 0 13 28
1
end_operator
begin_operator
up f21 f36
1
937 0
1
0 0 13 29
1
end_operator
begin_operator
up f21 f37
1
938 0
1
0 0 13 30
1
end_operator
begin_operator
up f21 f38
1
939 0
1
0 0 13 31
1
end_operator
begin_operator
up f21 f39
1
940 0
1
0 0 13 32
1
end_operator
begin_operator
up f21 f40
1
941 0
1
0 0 13 34
1
end_operator
begin_operator
up f21 f41
1
942 0
1
0 0 13 35
1
end_operator
begin_operator
up f21 f42
1
943 0
1
0 0 13 36
1
end_operator
begin_operator
up f21 f43
1
944 0
1
0 0 13 37
1
end_operator
begin_operator
up f21 f44
1
945 0
1
0 0 13 38
1
end_operator
begin_operator
up f21 f45
1
946 0
1
0 0 13 39
1
end_operator
begin_operator
up f21 f46
1
947 0
1
0 0 13 40
1
end_operator
begin_operator
up f21 f47
1
948 0
1
0 0 13 41
1
end_operator
begin_operator
up f21 f48
1
949 0
1
0 0 13 42
1
end_operator
begin_operator
up f21 f49
1
950 0
1
0 0 13 43
1
end_operator
begin_operator
up f21 f50
1
951 0
1
0 0 13 45
1
end_operator
begin_operator
up f21 f51
1
952 0
1
0 0 13 46
1
end_operator
begin_operator
up f21 f52
1
953 0
1
0 0 13 47
1
end_operator
begin_operator
up f21 f53
1
954 0
1
0 0 13 48
1
end_operator
begin_operator
up f21 f54
1
955 0
1
0 0 13 49
1
end_operator
begin_operator
up f21 f55
1
956 0
1
0 0 13 50
1
end_operator
begin_operator
up f21 f56
1
957 0
1
0 0 13 51
1
end_operator
begin_operator
up f21 f57
1
958 0
1
0 0 13 52
1
end_operator
begin_operator
up f21 f58
1
959 0
1
0 0 13 53
1
end_operator
begin_operator
up f21 f59
1
960 0
1
0 0 13 54
1
end_operator
begin_operator
up f21 f60
1
961 0
1
0 0 13 56
1
end_operator
begin_operator
up f21 f61
1
962 0
1
0 0 13 57
1
end_operator
begin_operator
up f21 f62
1
963 0
1
0 0 13 58
1
end_operator
begin_operator
up f21 f63
1
964 0
1
0 0 13 59
1
end_operator
begin_operator
up f21 f64
1
965 0
1
0 0 13 60
1
end_operator
begin_operator
up f21 f65
1
966 0
1
0 0 13 61
1
end_operator
begin_operator
up f21 f66
1
967 0
1
0 0 13 62
1
end_operator
begin_operator
up f21 f67
1
968 0
1
0 0 13 63
1
end_operator
begin_operator
up f21 f68
1
969 0
1
0 0 13 64
1
end_operator
begin_operator
up f21 f69
1
970 0
1
0 0 13 65
1
end_operator
begin_operator
up f21 f70
1
971 0
1
0 0 13 67
1
end_operator
begin_operator
up f21 f71
1
972 0
1
0 0 13 68
1
end_operator
begin_operator
up f21 f72
1
973 0
1
0 0 13 69
1
end_operator
begin_operator
up f21 f73
1
974 0
1
0 0 13 70
1
end_operator
begin_operator
up f21 f74
1
975 0
1
0 0 13 71
1
end_operator
begin_operator
up f21 f75
1
976 0
1
0 0 13 72
1
end_operator
begin_operator
up f21 f76
1
977 0
1
0 0 13 73
1
end_operator
begin_operator
up f21 f77
1
978 0
1
0 0 13 74
1
end_operator
begin_operator
up f21 f78
1
979 0
1
0 0 13 75
1
end_operator
begin_operator
up f21 f79
1
980 0
1
0 0 13 76
1
end_operator
begin_operator
up f21 f80
1
981 0
1
0 0 13 78
1
end_operator
begin_operator
up f22 f23
1
982 0
1
0 0 14 15
1
end_operator
begin_operator
up f22 f24
1
983 0
1
0 0 14 16
1
end_operator
begin_operator
up f22 f25
1
984 0
1
0 0 14 17
1
end_operator
begin_operator
up f22 f26
1
985 0
1
0 0 14 18
1
end_operator
begin_operator
up f22 f27
1
986 0
1
0 0 14 19
1
end_operator
begin_operator
up f22 f28
1
987 0
1
0 0 14 20
1
end_operator
begin_operator
up f22 f29
1
988 0
1
0 0 14 21
1
end_operator
begin_operator
up f22 f30
1
989 0
1
0 0 14 23
1
end_operator
begin_operator
up f22 f31
1
990 0
1
0 0 14 24
1
end_operator
begin_operator
up f22 f32
1
991 0
1
0 0 14 25
1
end_operator
begin_operator
up f22 f33
1
992 0
1
0 0 14 26
1
end_operator
begin_operator
up f22 f34
1
993 0
1
0 0 14 27
1
end_operator
begin_operator
up f22 f35
1
994 0
1
0 0 14 28
1
end_operator
begin_operator
up f22 f36
1
995 0
1
0 0 14 29
1
end_operator
begin_operator
up f22 f37
1
996 0
1
0 0 14 30
1
end_operator
begin_operator
up f22 f38
1
997 0
1
0 0 14 31
1
end_operator
begin_operator
up f22 f39
1
998 0
1
0 0 14 32
1
end_operator
begin_operator
up f22 f40
1
999 0
1
0 0 14 34
1
end_operator
begin_operator
up f22 f41
1
1000 0
1
0 0 14 35
1
end_operator
begin_operator
up f22 f42
1
1001 0
1
0 0 14 36
1
end_operator
begin_operator
up f22 f43
1
1002 0
1
0 0 14 37
1
end_operator
begin_operator
up f22 f44
1
1003 0
1
0 0 14 38
1
end_operator
begin_operator
up f22 f45
1
1004 0
1
0 0 14 39
1
end_operator
begin_operator
up f22 f46
1
1005 0
1
0 0 14 40
1
end_operator
begin_operator
up f22 f47
1
1006 0
1
0 0 14 41
1
end_operator
begin_operator
up f22 f48
1
1007 0
1
0 0 14 42
1
end_operator
begin_operator
up f22 f49
1
1008 0
1
0 0 14 43
1
end_operator
begin_operator
up f22 f50
1
1009 0
1
0 0 14 45
1
end_operator
begin_operator
up f22 f51
1
1010 0
1
0 0 14 46
1
end_operator
begin_operator
up f22 f52
1
1011 0
1
0 0 14 47
1
end_operator
begin_operator
up f22 f53
1
1012 0
1
0 0 14 48
1
end_operator
begin_operator
up f22 f54
1
1013 0
1
0 0 14 49
1
end_operator
begin_operator
up f22 f55
1
1014 0
1
0 0 14 50
1
end_operator
begin_operator
up f22 f56
1
1015 0
1
0 0 14 51
1
end_operator
begin_operator
up f22 f57
1
1016 0
1
0 0 14 52
1
end_operator
begin_operator
up f22 f58
1
1017 0
1
0 0 14 53
1
end_operator
begin_operator
up f22 f59
1
1018 0
1
0 0 14 54
1
end_operator
begin_operator
up f22 f60
1
1019 0
1
0 0 14 56
1
end_operator
begin_operator
up f22 f61
1
1020 0
1
0 0 14 57
1
end_operator
begin_operator
up f22 f62
1
1021 0
1
0 0 14 58
1
end_operator
begin_operator
up f22 f63
1
1022 0
1
0 0 14 59
1
end_operator
begin_operator
up f22 f64
1
1023 0
1
0 0 14 60
1
end_operator
begin_operator
up f22 f65
1
1024 0
1
0 0 14 61
1
end_operator
begin_operator
up f22 f66
1
1025 0
1
0 0 14 62
1
end_operator
begin_operator
up f22 f67
1
1026 0
1
0 0 14 63
1
end_operator
begin_operator
up f22 f68
1
1027 0
1
0 0 14 64
1
end_operator
begin_operator
up f22 f69
1
1028 0
1
0 0 14 65
1
end_operator
begin_operator
up f22 f70
1
1029 0
1
0 0 14 67
1
end_operator
begin_operator
up f22 f71
1
1030 0
1
0 0 14 68
1
end_operator
begin_operator
up f22 f72
1
1031 0
1
0 0 14 69
1
end_operator
begin_operator
up f22 f73
1
1032 0
1
0 0 14 70
1
end_operator
begin_operator
up f22 f74
1
1033 0
1
0 0 14 71
1
end_operator
begin_operator
up f22 f75
1
1034 0
1
0 0 14 72
1
end_operator
begin_operator
up f22 f76
1
1035 0
1
0 0 14 73
1
end_operator
begin_operator
up f22 f77
1
1036 0
1
0 0 14 74
1
end_operator
begin_operator
up f22 f78
1
1037 0
1
0 0 14 75
1
end_operator
begin_operator
up f22 f79
1
1038 0
1
0 0 14 76
1
end_operator
begin_operator
up f22 f80
1
1039 0
1
0 0 14 78
1
end_operator
begin_operator
up f23 f24
1
1040 0
1
0 0 15 16
1
end_operator
begin_operator
up f23 f25
1
1041 0
1
0 0 15 17
1
end_operator
begin_operator
up f23 f26
1
1042 0
1
0 0 15 18
1
end_operator
begin_operator
up f23 f27
1
1043 0
1
0 0 15 19
1
end_operator
begin_operator
up f23 f28
1
1044 0
1
0 0 15 20
1
end_operator
begin_operator
up f23 f29
1
1045 0
1
0 0 15 21
1
end_operator
begin_operator
up f23 f30
1
1046 0
1
0 0 15 23
1
end_operator
begin_operator
up f23 f31
1
1047 0
1
0 0 15 24
1
end_operator
begin_operator
up f23 f32
1
1048 0
1
0 0 15 25
1
end_operator
begin_operator
up f23 f33
1
1049 0
1
0 0 15 26
1
end_operator
begin_operator
up f23 f34
1
1050 0
1
0 0 15 27
1
end_operator
begin_operator
up f23 f35
1
1051 0
1
0 0 15 28
1
end_operator
begin_operator
up f23 f36
1
1052 0
1
0 0 15 29
1
end_operator
begin_operator
up f23 f37
1
1053 0
1
0 0 15 30
1
end_operator
begin_operator
up f23 f38
1
1054 0
1
0 0 15 31
1
end_operator
begin_operator
up f23 f39
1
1055 0
1
0 0 15 32
1
end_operator
begin_operator
up f23 f40
1
1056 0
1
0 0 15 34
1
end_operator
begin_operator
up f23 f41
1
1057 0
1
0 0 15 35
1
end_operator
begin_operator
up f23 f42
1
1058 0
1
0 0 15 36
1
end_operator
begin_operator
up f23 f43
1
1059 0
1
0 0 15 37
1
end_operator
begin_operator
up f23 f44
1
1060 0
1
0 0 15 38
1
end_operator
begin_operator
up f23 f45
1
1061 0
1
0 0 15 39
1
end_operator
begin_operator
up f23 f46
1
1062 0
1
0 0 15 40
1
end_operator
begin_operator
up f23 f47
1
1063 0
1
0 0 15 41
1
end_operator
begin_operator
up f23 f48
1
1064 0
1
0 0 15 42
1
end_operator
begin_operator
up f23 f49
1
1065 0
1
0 0 15 43
1
end_operator
begin_operator
up f23 f50
1
1066 0
1
0 0 15 45
1
end_operator
begin_operator
up f23 f51
1
1067 0
1
0 0 15 46
1
end_operator
begin_operator
up f23 f52
1
1068 0
1
0 0 15 47
1
end_operator
begin_operator
up f23 f53
1
1069 0
1
0 0 15 48
1
end_operator
begin_operator
up f23 f54
1
1070 0
1
0 0 15 49
1
end_operator
begin_operator
up f23 f55
1
1071 0
1
0 0 15 50
1
end_operator
begin_operator
up f23 f56
1
1072 0
1
0 0 15 51
1
end_operator
begin_operator
up f23 f57
1
1073 0
1
0 0 15 52
1
end_operator
begin_operator
up f23 f58
1
1074 0
1
0 0 15 53
1
end_operator
begin_operator
up f23 f59
1
1075 0
1
0 0 15 54
1
end_operator
begin_operator
up f23 f60
1
1076 0
1
0 0 15 56
1
end_operator
begin_operator
up f23 f61
1
1077 0
1
0 0 15 57
1
end_operator
begin_operator
up f23 f62
1
1078 0
1
0 0 15 58
1
end_operator
begin_operator
up f23 f63
1
1079 0
1
0 0 15 59
1
end_operator
begin_operator
up f23 f64
1
1080 0
1
0 0 15 60
1
end_operator
begin_operator
up f23 f65
1
1081 0
1
0 0 15 61
1
end_operator
begin_operator
up f23 f66
1
1082 0
1
0 0 15 62
1
end_operator
begin_operator
up f23 f67
1
1083 0
1
0 0 15 63
1
end_operator
begin_operator
up f23 f68
1
1084 0
1
0 0 15 64
1
end_operator
begin_operator
up f23 f69
1
1085 0
1
0 0 15 65
1
end_operator
begin_operator
up f23 f70
1
1086 0
1
0 0 15 67
1
end_operator
begin_operator
up f23 f71
1
1087 0
1
0 0 15 68
1
end_operator
begin_operator
up f23 f72
1
1088 0
1
0 0 15 69
1
end_operator
begin_operator
up f23 f73
1
1089 0
1
0 0 15 70
1
end_operator
begin_operator
up f23 f74
1
1090 0
1
0 0 15 71
1
end_operator
begin_operator
up f23 f75
1
1091 0
1
0 0 15 72
1
end_operator
begin_operator
up f23 f76
1
1092 0
1
0 0 15 73
1
end_operator
begin_operator
up f23 f77
1
1093 0
1
0 0 15 74
1
end_operator
begin_operator
up f23 f78
1
1094 0
1
0 0 15 75
1
end_operator
begin_operator
up f23 f79
1
1095 0
1
0 0 15 76
1
end_operator
begin_operator
up f23 f80
1
1096 0
1
0 0 15 78
1
end_operator
begin_operator
up f24 f25
1
1097 0
1
0 0 16 17
1
end_operator
begin_operator
up f24 f26
1
1098 0
1
0 0 16 18
1
end_operator
begin_operator
up f24 f27
1
1099 0
1
0 0 16 19
1
end_operator
begin_operator
up f24 f28
1
1100 0
1
0 0 16 20
1
end_operator
begin_operator
up f24 f29
1
1101 0
1
0 0 16 21
1
end_operator
begin_operator
up f24 f30
1
1102 0
1
0 0 16 23
1
end_operator
begin_operator
up f24 f31
1
1103 0
1
0 0 16 24
1
end_operator
begin_operator
up f24 f32
1
1104 0
1
0 0 16 25
1
end_operator
begin_operator
up f24 f33
1
1105 0
1
0 0 16 26
1
end_operator
begin_operator
up f24 f34
1
1106 0
1
0 0 16 27
1
end_operator
begin_operator
up f24 f35
1
1107 0
1
0 0 16 28
1
end_operator
begin_operator
up f24 f36
1
1108 0
1
0 0 16 29
1
end_operator
begin_operator
up f24 f37
1
1109 0
1
0 0 16 30
1
end_operator
begin_operator
up f24 f38
1
1110 0
1
0 0 16 31
1
end_operator
begin_operator
up f24 f39
1
1111 0
1
0 0 16 32
1
end_operator
begin_operator
up f24 f40
1
1112 0
1
0 0 16 34
1
end_operator
begin_operator
up f24 f41
1
1113 0
1
0 0 16 35
1
end_operator
begin_operator
up f24 f42
1
1114 0
1
0 0 16 36
1
end_operator
begin_operator
up f24 f43
1
1115 0
1
0 0 16 37
1
end_operator
begin_operator
up f24 f44
1
1116 0
1
0 0 16 38
1
end_operator
begin_operator
up f24 f45
1
1117 0
1
0 0 16 39
1
end_operator
begin_operator
up f24 f46
1
1118 0
1
0 0 16 40
1
end_operator
begin_operator
up f24 f47
1
1119 0
1
0 0 16 41
1
end_operator
begin_operator
up f24 f48
1
1120 0
1
0 0 16 42
1
end_operator
begin_operator
up f24 f49
1
1121 0
1
0 0 16 43
1
end_operator
begin_operator
up f24 f50
1
1122 0
1
0 0 16 45
1
end_operator
begin_operator
up f24 f51
1
1123 0
1
0 0 16 46
1
end_operator
begin_operator
up f24 f52
1
1124 0
1
0 0 16 47
1
end_operator
begin_operator
up f24 f53
1
1125 0
1
0 0 16 48
1
end_operator
begin_operator
up f24 f54
1
1126 0
1
0 0 16 49
1
end_operator
begin_operator
up f24 f55
1
1127 0
1
0 0 16 50
1
end_operator
begin_operator
up f24 f56
1
1128 0
1
0 0 16 51
1
end_operator
begin_operator
up f24 f57
1
1129 0
1
0 0 16 52
1
end_operator
begin_operator
up f24 f58
1
1130 0
1
0 0 16 53
1
end_operator
begin_operator
up f24 f59
1
1131 0
1
0 0 16 54
1
end_operator
begin_operator
up f24 f60
1
1132 0
1
0 0 16 56
1
end_operator
begin_operator
up f24 f61
1
1133 0
1
0 0 16 57
1
end_operator
begin_operator
up f24 f62
1
1134 0
1
0 0 16 58
1
end_operator
begin_operator
up f24 f63
1
1135 0
1
0 0 16 59
1
end_operator
begin_operator
up f24 f64
1
1136 0
1
0 0 16 60
1
end_operator
begin_operator
up f24 f65
1
1137 0
1
0 0 16 61
1
end_operator
begin_operator
up f24 f66
1
1138 0
1
0 0 16 62
1
end_operator
begin_operator
up f24 f67
1
1139 0
1
0 0 16 63
1
end_operator
begin_operator
up f24 f68
1
1140 0
1
0 0 16 64
1
end_operator
begin_operator
up f24 f69
1
1141 0
1
0 0 16 65
1
end_operator
begin_operator
up f24 f70
1
1142 0
1
0 0 16 67
1
end_operator
begin_operator
up f24 f71
1
1143 0
1
0 0 16 68
1
end_operator
begin_operator
up f24 f72
1
1144 0
1
0 0 16 69
1
end_operator
begin_operator
up f24 f73
1
1145 0
1
0 0 16 70
1
end_operator
begin_operator
up f24 f74
1
1146 0
1
0 0 16 71
1
end_operator
begin_operator
up f24 f75
1
1147 0
1
0 0 16 72
1
end_operator
begin_operator
up f24 f76
1
1148 0
1
0 0 16 73
1
end_operator
begin_operator
up f24 f77
1
1149 0
1
0 0 16 74
1
end_operator
begin_operator
up f24 f78
1
1150 0
1
0 0 16 75
1
end_operator
begin_operator
up f24 f79
1
1151 0
1
0 0 16 76
1
end_operator
begin_operator
up f24 f80
1
1152 0
1
0 0 16 78
1
end_operator
begin_operator
up f25 f26
1
1153 0
1
0 0 17 18
1
end_operator
begin_operator
up f25 f27
1
1154 0
1
0 0 17 19
1
end_operator
begin_operator
up f25 f28
1
1155 0
1
0 0 17 20
1
end_operator
begin_operator
up f25 f29
1
1156 0
1
0 0 17 21
1
end_operator
begin_operator
up f25 f30
1
1157 0
1
0 0 17 23
1
end_operator
begin_operator
up f25 f31
1
1158 0
1
0 0 17 24
1
end_operator
begin_operator
up f25 f32
1
1159 0
1
0 0 17 25
1
end_operator
begin_operator
up f25 f33
1
1160 0
1
0 0 17 26
1
end_operator
begin_operator
up f25 f34
1
1161 0
1
0 0 17 27
1
end_operator
begin_operator
up f25 f35
1
1162 0
1
0 0 17 28
1
end_operator
begin_operator
up f25 f36
1
1163 0
1
0 0 17 29
1
end_operator
begin_operator
up f25 f37
1
1164 0
1
0 0 17 30
1
end_operator
begin_operator
up f25 f38
1
1165 0
1
0 0 17 31
1
end_operator
begin_operator
up f25 f39
1
1166 0
1
0 0 17 32
1
end_operator
begin_operator
up f25 f40
1
1167 0
1
0 0 17 34
1
end_operator
begin_operator
up f25 f41
1
1168 0
1
0 0 17 35
1
end_operator
begin_operator
up f25 f42
1
1169 0
1
0 0 17 36
1
end_operator
begin_operator
up f25 f43
1
1170 0
1
0 0 17 37
1
end_operator
begin_operator
up f25 f44
1
1171 0
1
0 0 17 38
1
end_operator
begin_operator
up f25 f45
1
1172 0
1
0 0 17 39
1
end_operator
begin_operator
up f25 f46
1
1173 0
1
0 0 17 40
1
end_operator
begin_operator
up f25 f47
1
1174 0
1
0 0 17 41
1
end_operator
begin_operator
up f25 f48
1
1175 0
1
0 0 17 42
1
end_operator
begin_operator
up f25 f49
1
1176 0
1
0 0 17 43
1
end_operator
begin_operator
up f25 f50
1
1177 0
1
0 0 17 45
1
end_operator
begin_operator
up f25 f51
1
1178 0
1
0 0 17 46
1
end_operator
begin_operator
up f25 f52
1
1179 0
1
0 0 17 47
1
end_operator
begin_operator
up f25 f53
1
1180 0
1
0 0 17 48
1
end_operator
begin_operator
up f25 f54
1
1181 0
1
0 0 17 49
1
end_operator
begin_operator
up f25 f55
1
1182 0
1
0 0 17 50
1
end_operator
begin_operator
up f25 f56
1
1183 0
1
0 0 17 51
1
end_operator
begin_operator
up f25 f57
1
1184 0
1
0 0 17 52
1
end_operator
begin_operator
up f25 f58
1
1185 0
1
0 0 17 53
1
end_operator
begin_operator
up f25 f59
1
1186 0
1
0 0 17 54
1
end_operator
begin_operator
up f25 f60
1
1187 0
1
0 0 17 56
1
end_operator
begin_operator
up f25 f61
1
1188 0
1
0 0 17 57
1
end_operator
begin_operator
up f25 f62
1
1189 0
1
0 0 17 58
1
end_operator
begin_operator
up f25 f63
1
1190 0
1
0 0 17 59
1
end_operator
begin_operator
up f25 f64
1
1191 0
1
0 0 17 60
1
end_operator
begin_operator
up f25 f65
1
1192 0
1
0 0 17 61
1
end_operator
begin_operator
up f25 f66
1
1193 0
1
0 0 17 62
1
end_operator
begin_operator
up f25 f67
1
1194 0
1
0 0 17 63
1
end_operator
begin_operator
up f25 f68
1
1195 0
1
0 0 17 64
1
end_operator
begin_operator
up f25 f69
1
1196 0
1
0 0 17 65
1
end_operator
begin_operator
up f25 f70
1
1197 0
1
0 0 17 67
1
end_operator
begin_operator
up f25 f71
1
1198 0
1
0 0 17 68
1
end_operator
begin_operator
up f25 f72
1
1199 0
1
0 0 17 69
1
end_operator
begin_operator
up f25 f73
1
1200 0
1
0 0 17 70
1
end_operator
begin_operator
up f25 f74
1
1201 0
1
0 0 17 71
1
end_operator
begin_operator
up f25 f75
1
1202 0
1
0 0 17 72
1
end_operator
begin_operator
up f25 f76
1
1203 0
1
0 0 17 73
1
end_operator
begin_operator
up f25 f77
1
1204 0
1
0 0 17 74
1
end_operator
begin_operator
up f25 f78
1
1205 0
1
0 0 17 75
1
end_operator
begin_operator
up f25 f79
1
1206 0
1
0 0 17 76
1
end_operator
begin_operator
up f25 f80
1
1207 0
1
0 0 17 78
1
end_operator
begin_operator
up f26 f27
1
1208 0
1
0 0 18 19
1
end_operator
begin_operator
up f26 f28
1
1209 0
1
0 0 18 20
1
end_operator
begin_operator
up f26 f29
1
1210 0
1
0 0 18 21
1
end_operator
begin_operator
up f26 f30
1
1211 0
1
0 0 18 23
1
end_operator
begin_operator
up f26 f31
1
1212 0
1
0 0 18 24
1
end_operator
begin_operator
up f26 f32
1
1213 0
1
0 0 18 25
1
end_operator
begin_operator
up f26 f33
1
1214 0
1
0 0 18 26
1
end_operator
begin_operator
up f26 f34
1
1215 0
1
0 0 18 27
1
end_operator
begin_operator
up f26 f35
1
1216 0
1
0 0 18 28
1
end_operator
begin_operator
up f26 f36
1
1217 0
1
0 0 18 29
1
end_operator
begin_operator
up f26 f37
1
1218 0
1
0 0 18 30
1
end_operator
begin_operator
up f26 f38
1
1219 0
1
0 0 18 31
1
end_operator
begin_operator
up f26 f39
1
1220 0
1
0 0 18 32
1
end_operator
begin_operator
up f26 f40
1
1221 0
1
0 0 18 34
1
end_operator
begin_operator
up f26 f41
1
1222 0
1
0 0 18 35
1
end_operator
begin_operator
up f26 f42
1
1223 0
1
0 0 18 36
1
end_operator
begin_operator
up f26 f43
1
1224 0
1
0 0 18 37
1
end_operator
begin_operator
up f26 f44
1
1225 0
1
0 0 18 38
1
end_operator
begin_operator
up f26 f45
1
1226 0
1
0 0 18 39
1
end_operator
begin_operator
up f26 f46
1
1227 0
1
0 0 18 40
1
end_operator
begin_operator
up f26 f47
1
1228 0
1
0 0 18 41
1
end_operator
begin_operator
up f26 f48
1
1229 0
1
0 0 18 42
1
end_operator
begin_operator
up f26 f49
1
1230 0
1
0 0 18 43
1
end_operator
begin_operator
up f26 f50
1
1231 0
1
0 0 18 45
1
end_operator
begin_operator
up f26 f51
1
1232 0
1
0 0 18 46
1
end_operator
begin_operator
up f26 f52
1
1233 0
1
0 0 18 47
1
end_operator
begin_operator
up f26 f53
1
1234 0
1
0 0 18 48
1
end_operator
begin_operator
up f26 f54
1
1235 0
1
0 0 18 49
1
end_operator
begin_operator
up f26 f55
1
1236 0
1
0 0 18 50
1
end_operator
begin_operator
up f26 f56
1
1237 0
1
0 0 18 51
1
end_operator
begin_operator
up f26 f57
1
1238 0
1
0 0 18 52
1
end_operator
begin_operator
up f26 f58
1
1239 0
1
0 0 18 53
1
end_operator
begin_operator
up f26 f59
1
1240 0
1
0 0 18 54
1
end_operator
begin_operator
up f26 f60
1
1241 0
1
0 0 18 56
1
end_operator
begin_operator
up f26 f61
1
1242 0
1
0 0 18 57
1
end_operator
begin_operator
up f26 f62
1
1243 0
1
0 0 18 58
1
end_operator
begin_operator
up f26 f63
1
1244 0
1
0 0 18 59
1
end_operator
begin_operator
up f26 f64
1
1245 0
1
0 0 18 60
1
end_operator
begin_operator
up f26 f65
1
1246 0
1
0 0 18 61
1
end_operator
begin_operator
up f26 f66
1
1247 0
1
0 0 18 62
1
end_operator
begin_operator
up f26 f67
1
1248 0
1
0 0 18 63
1
end_operator
begin_operator
up f26 f68
1
1249 0
1
0 0 18 64
1
end_operator
begin_operator
up f26 f69
1
1250 0
1
0 0 18 65
1
end_operator
begin_operator
up f26 f70
1
1251 0
1
0 0 18 67
1
end_operator
begin_operator
up f26 f71
1
1252 0
1
0 0 18 68
1
end_operator
begin_operator
up f26 f72
1
1253 0
1
0 0 18 69
1
end_operator
begin_operator
up f26 f73
1
1254 0
1
0 0 18 70
1
end_operator
begin_operator
up f26 f74
1
1255 0
1
0 0 18 71
1
end_operator
begin_operator
up f26 f75
1
1256 0
1
0 0 18 72
1
end_operator
begin_operator
up f26 f76
1
1257 0
1
0 0 18 73
1
end_operator
begin_operator
up f26 f77
1
1258 0
1
0 0 18 74
1
end_operator
begin_operator
up f26 f78
1
1259 0
1
0 0 18 75
1
end_operator
begin_operator
up f26 f79
1
1260 0
1
0 0 18 76
1
end_operator
begin_operator
up f26 f80
1
1261 0
1
0 0 18 78
1
end_operator
begin_operator
up f27 f28
1
1262 0
1
0 0 19 20
1
end_operator
begin_operator
up f27 f29
1
1263 0
1
0 0 19 21
1
end_operator
begin_operator
up f27 f30
1
1264 0
1
0 0 19 23
1
end_operator
begin_operator
up f27 f31
1
1265 0
1
0 0 19 24
1
end_operator
begin_operator
up f27 f32
1
1266 0
1
0 0 19 25
1
end_operator
begin_operator
up f27 f33
1
1267 0
1
0 0 19 26
1
end_operator
begin_operator
up f27 f34
1
1268 0
1
0 0 19 27
1
end_operator
begin_operator
up f27 f35
1
1269 0
1
0 0 19 28
1
end_operator
begin_operator
up f27 f36
1
1270 0
1
0 0 19 29
1
end_operator
begin_operator
up f27 f37
1
1271 0
1
0 0 19 30
1
end_operator
begin_operator
up f27 f38
1
1272 0
1
0 0 19 31
1
end_operator
begin_operator
up f27 f39
1
1273 0
1
0 0 19 32
1
end_operator
begin_operator
up f27 f40
1
1274 0
1
0 0 19 34
1
end_operator
begin_operator
up f27 f41
1
1275 0
1
0 0 19 35
1
end_operator
begin_operator
up f27 f42
1
1276 0
1
0 0 19 36
1
end_operator
begin_operator
up f27 f43
1
1277 0
1
0 0 19 37
1
end_operator
begin_operator
up f27 f44
1
1278 0
1
0 0 19 38
1
end_operator
begin_operator
up f27 f45
1
1279 0
1
0 0 19 39
1
end_operator
begin_operator
up f27 f46
1
1280 0
1
0 0 19 40
1
end_operator
begin_operator
up f27 f47
1
1281 0
1
0 0 19 41
1
end_operator
begin_operator
up f27 f48
1
1282 0
1
0 0 19 42
1
end_operator
begin_operator
up f27 f49
1
1283 0
1
0 0 19 43
1
end_operator
begin_operator
up f27 f50
1
1284 0
1
0 0 19 45
1
end_operator
begin_operator
up f27 f51
1
1285 0
1
0 0 19 46
1
end_operator
begin_operator
up f27 f52
1
1286 0
1
0 0 19 47
1
end_operator
begin_operator
up f27 f53
1
1287 0
1
0 0 19 48
1
end_operator
begin_operator
up f27 f54
1
1288 0
1
0 0 19 49
1
end_operator
begin_operator
up f27 f55
1
1289 0
1
0 0 19 50
1
end_operator
begin_operator
up f27 f56
1
1290 0
1
0 0 19 51
1
end_operator
begin_operator
up f27 f57
1
1291 0
1
0 0 19 52
1
end_operator
begin_operator
up f27 f58
1
1292 0
1
0 0 19 53
1
end_operator
begin_operator
up f27 f59
1
1293 0
1
0 0 19 54
1
end_operator
begin_operator
up f27 f60
1
1294 0
1
0 0 19 56
1
end_operator
begin_operator
up f27 f61
1
1295 0
1
0 0 19 57
1
end_operator
begin_operator
up f27 f62
1
1296 0
1
0 0 19 58
1
end_operator
begin_operator
up f27 f63
1
1297 0
1
0 0 19 59
1
end_operator
begin_operator
up f27 f64
1
1298 0
1
0 0 19 60
1
end_operator
begin_operator
up f27 f65
1
1299 0
1
0 0 19 61
1
end_operator
begin_operator
up f27 f66
1
1300 0
1
0 0 19 62
1
end_operator
begin_operator
up f27 f67
1
1301 0
1
0 0 19 63
1
end_operator
begin_operator
up f27 f68
1
1302 0
1
0 0 19 64
1
end_operator
begin_operator
up f27 f69
1
1303 0
1
0 0 19 65
1
end_operator
begin_operator
up f27 f70
1
1304 0
1
0 0 19 67
1
end_operator
begin_operator
up f27 f71
1
1305 0
1
0 0 19 68
1
end_operator
begin_operator
up f27 f72
1
1306 0
1
0 0 19 69
1
end_operator
begin_operator
up f27 f73
1
1307 0
1
0 0 19 70
1
end_operator
begin_operator
up f27 f74
1
1308 0
1
0 0 19 71
1
end_operator
begin_operator
up f27 f75
1
1309 0
1
0 0 19 72
1
end_operator
begin_operator
up f27 f76
1
1310 0
1
0 0 19 73
1
end_operator
begin_operator
up f27 f77
1
1311 0
1
0 0 19 74
1
end_operator
begin_operator
up f27 f78
1
1312 0
1
0 0 19 75
1
end_operator
begin_operator
up f27 f79
1
1313 0
1
0 0 19 76
1
end_operator
begin_operator
up f27 f80
1
1314 0
1
0 0 19 78
1
end_operator
begin_operator
up f28 f29
1
1315 0
1
0 0 20 21
1
end_operator
begin_operator
up f28 f30
1
1316 0
1
0 0 20 23
1
end_operator
begin_operator
up f28 f31
1
1317 0
1
0 0 20 24
1
end_operator
begin_operator
up f28 f32
1
1318 0
1
0 0 20 25
1
end_operator
begin_operator
up f28 f33
1
1319 0
1
0 0 20 26
1
end_operator
begin_operator
up f28 f34
1
1320 0
1
0 0 20 27
1
end_operator
begin_operator
up f28 f35
1
1321 0
1
0 0 20 28
1
end_operator
begin_operator
up f28 f36
1
1322 0
1
0 0 20 29
1
end_operator
begin_operator
up f28 f37
1
1323 0
1
0 0 20 30
1
end_operator
begin_operator
up f28 f38
1
1324 0
1
0 0 20 31
1
end_operator
begin_operator
up f28 f39
1
1325 0
1
0 0 20 32
1
end_operator
begin_operator
up f28 f40
1
1326 0
1
0 0 20 34
1
end_operator
begin_operator
up f28 f41
1
1327 0
1
0 0 20 35
1
end_operator
begin_operator
up f28 f42
1
1328 0
1
0 0 20 36
1
end_operator
begin_operator
up f28 f43
1
1329 0
1
0 0 20 37
1
end_operator
begin_operator
up f28 f44
1
1330 0
1
0 0 20 38
1
end_operator
begin_operator
up f28 f45
1
1331 0
1
0 0 20 39
1
end_operator
begin_operator
up f28 f46
1
1332 0
1
0 0 20 40
1
end_operator
begin_operator
up f28 f47
1
1333 0
1
0 0 20 41
1
end_operator
begin_operator
up f28 f48
1
1334 0
1
0 0 20 42
1
end_operator
begin_operator
up f28 f49
1
1335 0
1
0 0 20 43
1
end_operator
begin_operator
up f28 f50
1
1336 0
1
0 0 20 45
1
end_operator
begin_operator
up f28 f51
1
1337 0
1
0 0 20 46
1
end_operator
begin_operator
up f28 f52
1
1338 0
1
0 0 20 47
1
end_operator
begin_operator
up f28 f53
1
1339 0
1
0 0 20 48
1
end_operator
begin_operator
up f28 f54
1
1340 0
1
0 0 20 49
1
end_operator
begin_operator
up f28 f55
1
1341 0
1
0 0 20 50
1
end_operator
begin_operator
up f28 f56
1
1342 0
1
0 0 20 51
1
end_operator
begin_operator
up f28 f57
1
1343 0
1
0 0 20 52
1
end_operator
begin_operator
up f28 f58
1
1344 0
1
0 0 20 53
1
end_operator
begin_operator
up f28 f59
1
1345 0
1
0 0 20 54
1
end_operator
begin_operator
up f28 f60
1
1346 0
1
0 0 20 56
1
end_operator
begin_operator
up f28 f61
1
1347 0
1
0 0 20 57
1
end_operator
begin_operator
up f28 f62
1
1348 0
1
0 0 20 58
1
end_operator
begin_operator
up f28 f63
1
1349 0
1
0 0 20 59
1
end_operator
begin_operator
up f28 f64
1
1350 0
1
0 0 20 60
1
end_operator
begin_operator
up f28 f65
1
1351 0
1
0 0 20 61
1
end_operator
begin_operator
up f28 f66
1
1352 0
1
0 0 20 62
1
end_operator
begin_operator
up f28 f67
1
1353 0
1
0 0 20 63
1
end_operator
begin_operator
up f28 f68
1
1354 0
1
0 0 20 64
1
end_operator
begin_operator
up f28 f69
1
1355 0
1
0 0 20 65
1
end_operator
begin_operator
up f28 f70
1
1356 0
1
0 0 20 67
1
end_operator
begin_operator
up f28 f71
1
1357 0
1
0 0 20 68
1
end_operator
begin_operator
up f28 f72
1
1358 0
1
0 0 20 69
1
end_operator
begin_operator
up f28 f73
1
1359 0
1
0 0 20 70
1
end_operator
begin_operator
up f28 f74
1
1360 0
1
0 0 20 71
1
end_operator
begin_operator
up f28 f75
1
1361 0
1
0 0 20 72
1
end_operator
begin_operator
up f28 f76
1
1362 0
1
0 0 20 73
1
end_operator
begin_operator
up f28 f77
1
1363 0
1
0 0 20 74
1
end_operator
begin_operator
up f28 f78
1
1364 0
1
0 0 20 75
1
end_operator
begin_operator
up f28 f79
1
1365 0
1
0 0 20 76
1
end_operator
begin_operator
up f28 f80
1
1366 0
1
0 0 20 78
1
end_operator
begin_operator
up f29 f30
1
1367 0
1
0 0 21 23
1
end_operator
begin_operator
up f29 f31
1
1368 0
1
0 0 21 24
1
end_operator
begin_operator
up f29 f32
1
1369 0
1
0 0 21 25
1
end_operator
begin_operator
up f29 f33
1
1370 0
1
0 0 21 26
1
end_operator
begin_operator
up f29 f34
1
1371 0
1
0 0 21 27
1
end_operator
begin_operator
up f29 f35
1
1372 0
1
0 0 21 28
1
end_operator
begin_operator
up f29 f36
1
1373 0
1
0 0 21 29
1
end_operator
begin_operator
up f29 f37
1
1374 0
1
0 0 21 30
1
end_operator
begin_operator
up f29 f38
1
1375 0
1
0 0 21 31
1
end_operator
begin_operator
up f29 f39
1
1376 0
1
0 0 21 32
1
end_operator
begin_operator
up f29 f40
1
1377 0
1
0 0 21 34
1
end_operator
begin_operator
up f29 f41
1
1378 0
1
0 0 21 35
1
end_operator
begin_operator
up f29 f42
1
1379 0
1
0 0 21 36
1
end_operator
begin_operator
up f29 f43
1
1380 0
1
0 0 21 37
1
end_operator
begin_operator
up f29 f44
1
1381 0
1
0 0 21 38
1
end_operator
begin_operator
up f29 f45
1
1382 0
1
0 0 21 39
1
end_operator
begin_operator
up f29 f46
1
1383 0
1
0 0 21 40
1
end_operator
begin_operator
up f29 f47
1
1384 0
1
0 0 21 41
1
end_operator
begin_operator
up f29 f48
1
1385 0
1
0 0 21 42
1
end_operator
begin_operator
up f29 f49
1
1386 0
1
0 0 21 43
1
end_operator
begin_operator
up f29 f50
1
1387 0
1
0 0 21 45
1
end_operator
begin_operator
up f29 f51
1
1388 0
1
0 0 21 46
1
end_operator
begin_operator
up f29 f52
1
1389 0
1
0 0 21 47
1
end_operator
begin_operator
up f29 f53
1
1390 0
1
0 0 21 48
1
end_operator
begin_operator
up f29 f54
1
1391 0
1
0 0 21 49
1
end_operator
begin_operator
up f29 f55
1
1392 0
1
0 0 21 50
1
end_operator
begin_operator
up f29 f56
1
1393 0
1
0 0 21 51
1
end_operator
begin_operator
up f29 f57
1
1394 0
1
0 0 21 52
1
end_operator
begin_operator
up f29 f58
1
1395 0
1
0 0 21 53
1
end_operator
begin_operator
up f29 f59
1
1396 0
1
0 0 21 54
1
end_operator
begin_operator
up f29 f60
1
1397 0
1
0 0 21 56
1
end_operator
begin_operator
up f29 f61
1
1398 0
1
0 0 21 57
1
end_operator
begin_operator
up f29 f62
1
1399 0
1
0 0 21 58
1
end_operator
begin_operator
up f29 f63
1
1400 0
1
0 0 21 59
1
end_operator
begin_operator
up f29 f64
1
1401 0
1
0 0 21 60
1
end_operator
begin_operator
up f29 f65
1
1402 0
1
0 0 21 61
1
end_operator
begin_operator
up f29 f66
1
1403 0
1
0 0 21 62
1
end_operator
begin_operator
up f29 f67
1
1404 0
1
0 0 21 63
1
end_operator
begin_operator
up f29 f68
1
1405 0
1
0 0 21 64
1
end_operator
begin_operator
up f29 f69
1
1406 0
1
0 0 21 65
1
end_operator
begin_operator
up f29 f70
1
1407 0
1
0 0 21 67
1
end_operator
begin_operator
up f29 f71
1
1408 0
1
0 0 21 68
1
end_operator
begin_operator
up f29 f72
1
1409 0
1
0 0 21 69
1
end_operator
begin_operator
up f29 f73
1
1410 0
1
0 0 21 70
1
end_operator
begin_operator
up f29 f74
1
1411 0
1
0 0 21 71
1
end_operator
begin_operator
up f29 f75
1
1412 0
1
0 0 21 72
1
end_operator
begin_operator
up f29 f76
1
1413 0
1
0 0 21 73
1
end_operator
begin_operator
up f29 f77
1
1414 0
1
0 0 21 74
1
end_operator
begin_operator
up f29 f78
1
1415 0
1
0 0 21 75
1
end_operator
begin_operator
up f29 f79
1
1416 0
1
0 0 21 76
1
end_operator
begin_operator
up f29 f80
1
1417 0
1
0 0 21 78
1
end_operator
begin_operator
up f3 f10
1
1418 0
1
0 0 22 1
1
end_operator
begin_operator
up f3 f11
1
1419 0
1
0 0 22 2
1
end_operator
begin_operator
up f3 f12
1
1420 0
1
0 0 22 3
1
end_operator
begin_operator
up f3 f13
1
1421 0
1
0 0 22 4
1
end_operator
begin_operator
up f3 f14
1
1422 0
1
0 0 22 5
1
end_operator
begin_operator
up f3 f15
1
1423 0
1
0 0 22 6
1
end_operator
begin_operator
up f3 f16
1
1424 0
1
0 0 22 7
1
end_operator
begin_operator
up f3 f17
1
1425 0
1
0 0 22 8
1
end_operator
begin_operator
up f3 f18
1
1426 0
1
0 0 22 9
1
end_operator
begin_operator
up f3 f19
1
1427 0
1
0 0 22 10
1
end_operator
begin_operator
up f3 f20
1
1428 0
1
0 0 22 12
1
end_operator
begin_operator
up f3 f21
1
1429 0
1
0 0 22 13
1
end_operator
begin_operator
up f3 f22
1
1430 0
1
0 0 22 14
1
end_operator
begin_operator
up f3 f23
1
1431 0
1
0 0 22 15
1
end_operator
begin_operator
up f3 f24
1
1432 0
1
0 0 22 16
1
end_operator
begin_operator
up f3 f25
1
1433 0
1
0 0 22 17
1
end_operator
begin_operator
up f3 f26
1
1434 0
1
0 0 22 18
1
end_operator
begin_operator
up f3 f27
1
1435 0
1
0 0 22 19
1
end_operator
begin_operator
up f3 f28
1
1436 0
1
0 0 22 20
1
end_operator
begin_operator
up f3 f29
1
1437 0
1
0 0 22 21
1
end_operator
begin_operator
up f3 f30
1
1438 0
1
0 0 22 23
1
end_operator
begin_operator
up f3 f31
1
1439 0
1
0 0 22 24
1
end_operator
begin_operator
up f3 f32
1
1440 0
1
0 0 22 25
1
end_operator
begin_operator
up f3 f33
1
1441 0
1
0 0 22 26
1
end_operator
begin_operator
up f3 f34
1
1442 0
1
0 0 22 27
1
end_operator
begin_operator
up f3 f35
1
1443 0
1
0 0 22 28
1
end_operator
begin_operator
up f3 f36
1
1444 0
1
0 0 22 29
1
end_operator
begin_operator
up f3 f37
1
1445 0
1
0 0 22 30
1
end_operator
begin_operator
up f3 f38
1
1446 0
1
0 0 22 31
1
end_operator
begin_operator
up f3 f39
1
1447 0
1
0 0 22 32
1
end_operator
begin_operator
up f3 f4
1
1448 0
1
0 0 22 33
1
end_operator
begin_operator
up f3 f40
1
1449 0
1
0 0 22 34
1
end_operator
begin_operator
up f3 f41
1
1450 0
1
0 0 22 35
1
end_operator
begin_operator
up f3 f42
1
1451 0
1
0 0 22 36
1
end_operator
begin_operator
up f3 f43
1
1452 0
1
0 0 22 37
1
end_operator
begin_operator
up f3 f44
1
1453 0
1
0 0 22 38
1
end_operator
begin_operator
up f3 f45
1
1454 0
1
0 0 22 39
1
end_operator
begin_operator
up f3 f46
1
1455 0
1
0 0 22 40
1
end_operator
begin_operator
up f3 f47
1
1456 0
1
0 0 22 41
1
end_operator
begin_operator
up f3 f48
1
1457 0
1
0 0 22 42
1
end_operator
begin_operator
up f3 f49
1
1458 0
1
0 0 22 43
1
end_operator
begin_operator
up f3 f5
1
1459 0
1
0 0 22 44
1
end_operator
begin_operator
up f3 f50
1
1460 0
1
0 0 22 45
1
end_operator
begin_operator
up f3 f51
1
1461 0
1
0 0 22 46
1
end_operator
begin_operator
up f3 f52
1
1462 0
1
0 0 22 47
1
end_operator
begin_operator
up f3 f53
1
1463 0
1
0 0 22 48
1
end_operator
begin_operator
up f3 f54
1
1464 0
1
0 0 22 49
1
end_operator
begin_operator
up f3 f55
1
1465 0
1
0 0 22 50
1
end_operator
begin_operator
up f3 f56
1
1466 0
1
0 0 22 51
1
end_operator
begin_operator
up f3 f57
1
1467 0
1
0 0 22 52
1
end_operator
begin_operator
up f3 f58
1
1468 0
1
0 0 22 53
1
end_operator
begin_operator
up f3 f59
1
1469 0
1
0 0 22 54
1
end_operator
begin_operator
up f3 f6
1
1470 0
1
0 0 22 55
1
end_operator
begin_operator
up f3 f60
1
1471 0
1
0 0 22 56
1
end_operator
begin_operator
up f3 f61
1
1472 0
1
0 0 22 57
1
end_operator
begin_operator
up f3 f62
1
1473 0
1
0 0 22 58
1
end_operator
begin_operator
up f3 f63
1
1474 0
1
0 0 22 59
1
end_operator
begin_operator
up f3 f64
1
1475 0
1
0 0 22 60
1
end_operator
begin_operator
up f3 f65
1
1476 0
1
0 0 22 61
1
end_operator
begin_operator
up f3 f66
1
1477 0
1
0 0 22 62
1
end_operator
begin_operator
up f3 f67
1
1478 0
1
0 0 22 63
1
end_operator
begin_operator
up f3 f68
1
1479 0
1
0 0 22 64
1
end_operator
begin_operator
up f3 f69
1
1480 0
1
0 0 22 65
1
end_operator
begin_operator
up f3 f7
1
1481 0
1
0 0 22 66
1
end_operator
begin_operator
up f3 f70
1
1482 0
1
0 0 22 67
1
end_operator
begin_operator
up f3 f71
1
1483 0
1
0 0 22 68
1
end_operator
begin_operator
up f3 f72
1
1484 0
1
0 0 22 69
1
end_operator
begin_operator
up f3 f73
1
1485 0
1
0 0 22 70
1
end_operator
begin_operator
up f3 f74
1
1486 0
1
0 0 22 71
1
end_operator
begin_operator
up f3 f75
1
1487 0
1
0 0 22 72
1
end_operator
begin_operator
up f3 f76
1
1488 0
1
0 0 22 73
1
end_operator
begin_operator
up f3 f77
1
1489 0
1
0 0 22 74
1
end_operator
begin_operator
up f3 f78
1
1490 0
1
0 0 22 75
1
end_operator
begin_operator
up f3 f79
1
1491 0
1
0 0 22 76
1
end_operator
begin_operator
up f3 f8
1
1492 0
1
0 0 22 77
1
end_operator
begin_operator
up f3 f80
1
1493 0
1
0 0 22 78
1
end_operator
begin_operator
up f3 f9
1
1494 0
1
0 0 22 79
1
end_operator
begin_operator
up f30 f31
1
1495 0
1
0 0 23 24
1
end_operator
begin_operator
up f30 f32
1
1496 0
1
0 0 23 25
1
end_operator
begin_operator
up f30 f33
1
1497 0
1
0 0 23 26
1
end_operator
begin_operator
up f30 f34
1
1498 0
1
0 0 23 27
1
end_operator
begin_operator
up f30 f35
1
1499 0
1
0 0 23 28
1
end_operator
begin_operator
up f30 f36
1
1500 0
1
0 0 23 29
1
end_operator
begin_operator
up f30 f37
1
1501 0
1
0 0 23 30
1
end_operator
begin_operator
up f30 f38
1
1502 0
1
0 0 23 31
1
end_operator
begin_operator
up f30 f39
1
1503 0
1
0 0 23 32
1
end_operator
begin_operator
up f30 f40
1
1504 0
1
0 0 23 34
1
end_operator
begin_operator
up f30 f41
1
1505 0
1
0 0 23 35
1
end_operator
begin_operator
up f30 f42
1
1506 0
1
0 0 23 36
1
end_operator
begin_operator
up f30 f43
1
1507 0
1
0 0 23 37
1
end_operator
begin_operator
up f30 f44
1
1508 0
1
0 0 23 38
1
end_operator
begin_operator
up f30 f45
1
1509 0
1
0 0 23 39
1
end_operator
begin_operator
up f30 f46
1
1510 0
1
0 0 23 40
1
end_operator
begin_operator
up f30 f47
1
1511 0
1
0 0 23 41
1
end_operator
begin_operator
up f30 f48
1
1512 0
1
0 0 23 42
1
end_operator
begin_operator
up f30 f49
1
1513 0
1
0 0 23 43
1
end_operator
begin_operator
up f30 f50
1
1514 0
1
0 0 23 45
1
end_operator
begin_operator
up f30 f51
1
1515 0
1
0 0 23 46
1
end_operator
begin_operator
up f30 f52
1
1516 0
1
0 0 23 47
1
end_operator
begin_operator
up f30 f53
1
1517 0
1
0 0 23 48
1
end_operator
begin_operator
up f30 f54
1
1518 0
1
0 0 23 49
1
end_operator
begin_operator
up f30 f55
1
1519 0
1
0 0 23 50
1
end_operator
begin_operator
up f30 f56
1
1520 0
1
0 0 23 51
1
end_operator
begin_operator
up f30 f57
1
1521 0
1
0 0 23 52
1
end_operator
begin_operator
up f30 f58
1
1522 0
1
0 0 23 53
1
end_operator
begin_operator
up f30 f59
1
1523 0
1
0 0 23 54
1
end_operator
begin_operator
up f30 f60
1
1524 0
1
0 0 23 56
1
end_operator
begin_operator
up f30 f61
1
1525 0
1
0 0 23 57
1
end_operator
begin_operator
up f30 f62
1
1526 0
1
0 0 23 58
1
end_operator
begin_operator
up f30 f63
1
1527 0
1
0 0 23 59
1
end_operator
begin_operator
up f30 f64
1
1528 0
1
0 0 23 60
1
end_operator
begin_operator
up f30 f65
1
1529 0
1
0 0 23 61
1
end_operator
begin_operator
up f30 f66
1
1530 0
1
0 0 23 62
1
end_operator
begin_operator
up f30 f67
1
1531 0
1
0 0 23 63
1
end_operator
begin_operator
up f30 f68
1
1532 0
1
0 0 23 64
1
end_operator
begin_operator
up f30 f69
1
1533 0
1
0 0 23 65
1
end_operator
begin_operator
up f30 f70
1
1534 0
1
0 0 23 67
1
end_operator
begin_operator
up f30 f71
1
1535 0
1
0 0 23 68
1
end_operator
begin_operator
up f30 f72
1
1536 0
1
0 0 23 69
1
end_operator
begin_operator
up f30 f73
1
1537 0
1
0 0 23 70
1
end_operator
begin_operator
up f30 f74
1
1538 0
1
0 0 23 71
1
end_operator
begin_operator
up f30 f75
1
1539 0
1
0 0 23 72
1
end_operator
begin_operator
up f30 f76
1
1540 0
1
0 0 23 73
1
end_operator
begin_operator
up f30 f77
1
1541 0
1
0 0 23 74
1
end_operator
begin_operator
up f30 f78
1
1542 0
1
0 0 23 75
1
end_operator
begin_operator
up f30 f79
1
1543 0
1
0 0 23 76
1
end_operator
begin_operator
up f30 f80
1
1544 0
1
0 0 23 78
1
end_operator
begin_operator
up f31 f32
1
1545 0
1
0 0 24 25
1
end_operator
begin_operator
up f31 f33
1
1546 0
1
0 0 24 26
1
end_operator
begin_operator
up f31 f34
1
1547 0
1
0 0 24 27
1
end_operator
begin_operator
up f31 f35
1
1548 0
1
0 0 24 28
1
end_operator
begin_operator
up f31 f36
1
1549 0
1
0 0 24 29
1
end_operator
begin_operator
up f31 f37
1
1550 0
1
0 0 24 30
1
end_operator
begin_operator
up f31 f38
1
1551 0
1
0 0 24 31
1
end_operator
begin_operator
up f31 f39
1
1552 0
1
0 0 24 32
1
end_operator
begin_operator
up f31 f40
1
1553 0
1
0 0 24 34
1
end_operator
begin_operator
up f31 f41
1
1554 0
1
0 0 24 35
1
end_operator
begin_operator
up f31 f42
1
1555 0
1
0 0 24 36
1
end_operator
begin_operator
up f31 f43
1
1556 0
1
0 0 24 37
1
end_operator
begin_operator
up f31 f44
1
1557 0
1
0 0 24 38
1
end_operator
begin_operator
up f31 f45
1
1558 0
1
0 0 24 39
1
end_operator
begin_operator
up f31 f46
1
1559 0
1
0 0 24 40
1
end_operator
begin_operator
up f31 f47
1
1560 0
1
0 0 24 41
1
end_operator
begin_operator
up f31 f48
1
1561 0
1
0 0 24 42
1
end_operator
begin_operator
up f31 f49
1
1562 0
1
0 0 24 43
1
end_operator
begin_operator
up f31 f50
1
1563 0
1
0 0 24 45
1
end_operator
begin_operator
up f31 f51
1
1564 0
1
0 0 24 46
1
end_operator
begin_operator
up f31 f52
1
1565 0
1
0 0 24 47
1
end_operator
begin_operator
up f31 f53
1
1566 0
1
0 0 24 48
1
end_operator
begin_operator
up f31 f54
1
1567 0
1
0 0 24 49
1
end_operator
begin_operator
up f31 f55
1
1568 0
1
0 0 24 50
1
end_operator
begin_operator
up f31 f56
1
1569 0
1
0 0 24 51
1
end_operator
begin_operator
up f31 f57
1
1570 0
1
0 0 24 52
1
end_operator
begin_operator
up f31 f58
1
1571 0
1
0 0 24 53
1
end_operator
begin_operator
up f31 f59
1
1572 0
1
0 0 24 54
1
end_operator
begin_operator
up f31 f60
1
1573 0
1
0 0 24 56
1
end_operator
begin_operator
up f31 f61
1
1574 0
1
0 0 24 57
1
end_operator
begin_operator
up f31 f62
1
1575 0
1
0 0 24 58
1
end_operator
begin_operator
up f31 f63
1
1576 0
1
0 0 24 59
1
end_operator
begin_operator
up f31 f64
1
1577 0
1
0 0 24 60
1
end_operator
begin_operator
up f31 f65
1
1578 0
1
0 0 24 61
1
end_operator
begin_operator
up f31 f66
1
1579 0
1
0 0 24 62
1
end_operator
begin_operator
up f31 f67
1
1580 0
1
0 0 24 63
1
end_operator
begin_operator
up f31 f68
1
1581 0
1
0 0 24 64
1
end_operator
begin_operator
up f31 f69
1
1582 0
1
0 0 24 65
1
end_operator
begin_operator
up f31 f70
1
1583 0
1
0 0 24 67
1
end_operator
begin_operator
up f31 f71
1
1584 0
1
0 0 24 68
1
end_operator
begin_operator
up f31 f72
1
1585 0
1
0 0 24 69
1
end_operator
begin_operator
up f31 f73
1
1586 0
1
0 0 24 70
1
end_operator
begin_operator
up f31 f74
1
1587 0
1
0 0 24 71
1
end_operator
begin_operator
up f31 f75
1
1588 0
1
0 0 24 72
1
end_operator
begin_operator
up f31 f76
1
1589 0
1
0 0 24 73
1
end_operator
begin_operator
up f31 f77
1
1590 0
1
0 0 24 74
1
end_operator
begin_operator
up f31 f78
1
1591 0
1
0 0 24 75
1
end_operator
begin_operator
up f31 f79
1
1592 0
1
0 0 24 76
1
end_operator
begin_operator
up f31 f80
1
1593 0
1
0 0 24 78
1
end_operator
begin_operator
up f32 f33
1
1594 0
1
0 0 25 26
1
end_operator
begin_operator
up f32 f34
1
1595 0
1
0 0 25 27
1
end_operator
begin_operator
up f32 f35
1
1596 0
1
0 0 25 28
1
end_operator
begin_operator
up f32 f36
1
1597 0
1
0 0 25 29
1
end_operator
begin_operator
up f32 f37
1
1598 0
1
0 0 25 30
1
end_operator
begin_operator
up f32 f38
1
1599 0
1
0 0 25 31
1
end_operator
begin_operator
up f32 f39
1
1600 0
1
0 0 25 32
1
end_operator
begin_operator
up f32 f40
1
1601 0
1
0 0 25 34
1
end_operator
begin_operator
up f32 f41
1
1602 0
1
0 0 25 35
1
end_operator
begin_operator
up f32 f42
1
1603 0
1
0 0 25 36
1
end_operator
begin_operator
up f32 f43
1
1604 0
1
0 0 25 37
1
end_operator
begin_operator
up f32 f44
1
1605 0
1
0 0 25 38
1
end_operator
begin_operator
up f32 f45
1
1606 0
1
0 0 25 39
1
end_operator
begin_operator
up f32 f46
1
1607 0
1
0 0 25 40
1
end_operator
begin_operator
up f32 f47
1
1608 0
1
0 0 25 41
1
end_operator
begin_operator
up f32 f48
1
1609 0
1
0 0 25 42
1
end_operator
begin_operator
up f32 f49
1
1610 0
1
0 0 25 43
1
end_operator
begin_operator
up f32 f50
1
1611 0
1
0 0 25 45
1
end_operator
begin_operator
up f32 f51
1
1612 0
1
0 0 25 46
1
end_operator
begin_operator
up f32 f52
1
1613 0
1
0 0 25 47
1
end_operator
begin_operator
up f32 f53
1
1614 0
1
0 0 25 48
1
end_operator
begin_operator
up f32 f54
1
1615 0
1
0 0 25 49
1
end_operator
begin_operator
up f32 f55
1
1616 0
1
0 0 25 50
1
end_operator
begin_operator
up f32 f56
1
1617 0
1
0 0 25 51
1
end_operator
begin_operator
up f32 f57
1
1618 0
1
0 0 25 52
1
end_operator
begin_operator
up f32 f58
1
1619 0
1
0 0 25 53
1
end_operator
begin_operator
up f32 f59
1
1620 0
1
0 0 25 54
1
end_operator
begin_operator
up f32 f60
1
1621 0
1
0 0 25 56
1
end_operator
begin_operator
up f32 f61
1
1622 0
1
0 0 25 57
1
end_operator
begin_operator
up f32 f62
1
1623 0
1
0 0 25 58
1
end_operator
begin_operator
up f32 f63
1
1624 0
1
0 0 25 59
1
end_operator
begin_operator
up f32 f64
1
1625 0
1
0 0 25 60
1
end_operator
begin_operator
up f32 f65
1
1626 0
1
0 0 25 61
1
end_operator
begin_operator
up f32 f66
1
1627 0
1
0 0 25 62
1
end_operator
begin_operator
up f32 f67
1
1628 0
1
0 0 25 63
1
end_operator
begin_operator
up f32 f68
1
1629 0
1
0 0 25 64
1
end_operator
begin_operator
up f32 f69
1
1630 0
1
0 0 25 65
1
end_operator
begin_operator
up f32 f70
1
1631 0
1
0 0 25 67
1
end_operator
begin_operator
up f32 f71
1
1632 0
1
0 0 25 68
1
end_operator
begin_operator
up f32 f72
1
1633 0
1
0 0 25 69
1
end_operator
begin_operator
up f32 f73
1
1634 0
1
0 0 25 70
1
end_operator
begin_operator
up f32 f74
1
1635 0
1
0 0 25 71
1
end_operator
begin_operator
up f32 f75
1
1636 0
1
0 0 25 72
1
end_operator
begin_operator
up f32 f76
1
1637 0
1
0 0 25 73
1
end_operator
begin_operator
up f32 f77
1
1638 0
1
0 0 25 74
1
end_operator
begin_operator
up f32 f78
1
1639 0
1
0 0 25 75
1
end_operator
begin_operator
up f32 f79
1
1640 0
1
0 0 25 76
1
end_operator
begin_operator
up f32 f80
1
1641 0
1
0 0 25 78
1
end_operator
begin_operator
up f33 f34
1
1642 0
1
0 0 26 27
1
end_operator
begin_operator
up f33 f35
1
1643 0
1
0 0 26 28
1
end_operator
begin_operator
up f33 f36
1
1644 0
1
0 0 26 29
1
end_operator
begin_operator
up f33 f37
1
1645 0
1
0 0 26 30
1
end_operator
begin_operator
up f33 f38
1
1646 0
1
0 0 26 31
1
end_operator
begin_operator
up f33 f39
1
1647 0
1
0 0 26 32
1
end_operator
begin_operator
up f33 f40
1
1648 0
1
0 0 26 34
1
end_operator
begin_operator
up f33 f41
1
1649 0
1
0 0 26 35
1
end_operator
begin_operator
up f33 f42
1
1650 0
1
0 0 26 36
1
end_operator
begin_operator
up f33 f43
1
1651 0
1
0 0 26 37
1
end_operator
begin_operator
up f33 f44
1
1652 0
1
0 0 26 38
1
end_operator
begin_operator
up f33 f45
1
1653 0
1
0 0 26 39
1
end_operator
begin_operator
up f33 f46
1
1654 0
1
0 0 26 40
1
end_operator
begin_operator
up f33 f47
1
1655 0
1
0 0 26 41
1
end_operator
begin_operator
up f33 f48
1
1656 0
1
0 0 26 42
1
end_operator
begin_operator
up f33 f49
1
1657 0
1
0 0 26 43
1
end_operator
begin_operator
up f33 f50
1
1658 0
1
0 0 26 45
1
end_operator
begin_operator
up f33 f51
1
1659 0
1
0 0 26 46
1
end_operator
begin_operator
up f33 f52
1
1660 0
1
0 0 26 47
1
end_operator
begin_operator
up f33 f53
1
1661 0
1
0 0 26 48
1
end_operator
begin_operator
up f33 f54
1
1662 0
1
0 0 26 49
1
end_operator
begin_operator
up f33 f55
1
1663 0
1
0 0 26 50
1
end_operator
begin_operator
up f33 f56
1
1664 0
1
0 0 26 51
1
end_operator
begin_operator
up f33 f57
1
1665 0
1
0 0 26 52
1
end_operator
begin_operator
up f33 f58
1
1666 0
1
0 0 26 53
1
end_operator
begin_operator
up f33 f59
1
1667 0
1
0 0 26 54
1
end_operator
begin_operator
up f33 f60
1
1668 0
1
0 0 26 56
1
end_operator
begin_operator
up f33 f61
1
1669 0
1
0 0 26 57
1
end_operator
begin_operator
up f33 f62
1
1670 0
1
0 0 26 58
1
end_operator
begin_operator
up f33 f63
1
1671 0
1
0 0 26 59
1
end_operator
begin_operator
up f33 f64
1
1672 0
1
0 0 26 60
1
end_operator
begin_operator
up f33 f65
1
1673 0
1
0 0 26 61
1
end_operator
begin_operator
up f33 f66
1
1674 0
1
0 0 26 62
1
end_operator
begin_operator
up f33 f67
1
1675 0
1
0 0 26 63
1
end_operator
begin_operator
up f33 f68
1
1676 0
1
0 0 26 64
1
end_operator
begin_operator
up f33 f69
1
1677 0
1
0 0 26 65
1
end_operator
begin_operator
up f33 f70
1
1678 0
1
0 0 26 67
1
end_operator
begin_operator
up f33 f71
1
1679 0
1
0 0 26 68
1
end_operator
begin_operator
up f33 f72
1
1680 0
1
0 0 26 69
1
end_operator
begin_operator
up f33 f73
1
1681 0
1
0 0 26 70
1
end_operator
begin_operator
up f33 f74
1
1682 0
1
0 0 26 71
1
end_operator
begin_operator
up f33 f75
1
1683 0
1
0 0 26 72
1
end_operator
begin_operator
up f33 f76
1
1684 0
1
0 0 26 73
1
end_operator
begin_operator
up f33 f77
1
1685 0
1
0 0 26 74
1
end_operator
begin_operator
up f33 f78
1
1686 0
1
0 0 26 75
1
end_operator
begin_operator
up f33 f79
1
1687 0
1
0 0 26 76
1
end_operator
begin_operator
up f33 f80
1
1688 0
1
0 0 26 78
1
end_operator
begin_operator
up f34 f35
1
1689 0
1
0 0 27 28
1
end_operator
begin_operator
up f34 f36
1
1690 0
1
0 0 27 29
1
end_operator
begin_operator
up f34 f37
1
1691 0
1
0 0 27 30
1
end_operator
begin_operator
up f34 f38
1
1692 0
1
0 0 27 31
1
end_operator
begin_operator
up f34 f39
1
1693 0
1
0 0 27 32
1
end_operator
begin_operator
up f34 f40
1
1694 0
1
0 0 27 34
1
end_operator
begin_operator
up f34 f41
1
1695 0
1
0 0 27 35
1
end_operator
begin_operator
up f34 f42
1
1696 0
1
0 0 27 36
1
end_operator
begin_operator
up f34 f43
1
1697 0
1
0 0 27 37
1
end_operator
begin_operator
up f34 f44
1
1698 0
1
0 0 27 38
1
end_operator
begin_operator
up f34 f45
1
1699 0
1
0 0 27 39
1
end_operator
begin_operator
up f34 f46
1
1700 0
1
0 0 27 40
1
end_operator
begin_operator
up f34 f47
1
1701 0
1
0 0 27 41
1
end_operator
begin_operator
up f34 f48
1
1702 0
1
0 0 27 42
1
end_operator
begin_operator
up f34 f49
1
1703 0
1
0 0 27 43
1
end_operator
begin_operator
up f34 f50
1
1704 0
1
0 0 27 45
1
end_operator
begin_operator
up f34 f51
1
1705 0
1
0 0 27 46
1
end_operator
begin_operator
up f34 f52
1
1706 0
1
0 0 27 47
1
end_operator
begin_operator
up f34 f53
1
1707 0
1
0 0 27 48
1
end_operator
begin_operator
up f34 f54
1
1708 0
1
0 0 27 49
1
end_operator
begin_operator
up f34 f55
1
1709 0
1
0 0 27 50
1
end_operator
begin_operator
up f34 f56
1
1710 0
1
0 0 27 51
1
end_operator
begin_operator
up f34 f57
1
1711 0
1
0 0 27 52
1
end_operator
begin_operator
up f34 f58
1
1712 0
1
0 0 27 53
1
end_operator
begin_operator
up f34 f59
1
1713 0
1
0 0 27 54
1
end_operator
begin_operator
up f34 f60
1
1714 0
1
0 0 27 56
1
end_operator
begin_operator
up f34 f61
1
1715 0
1
0 0 27 57
1
end_operator
begin_operator
up f34 f62
1
1716 0
1
0 0 27 58
1
end_operator
begin_operator
up f34 f63
1
1717 0
1
0 0 27 59
1
end_operator
begin_operator
up f34 f64
1
1718 0
1
0 0 27 60
1
end_operator
begin_operator
up f34 f65
1
1719 0
1
0 0 27 61
1
end_operator
begin_operator
up f34 f66
1
1720 0
1
0 0 27 62
1
end_operator
begin_operator
up f34 f67
1
1721 0
1
0 0 27 63
1
end_operator
begin_operator
up f34 f68
1
1722 0
1
0 0 27 64
1
end_operator
begin_operator
up f34 f69
1
1723 0
1
0 0 27 65
1
end_operator
begin_operator
up f34 f70
1
1724 0
1
0 0 27 67
1
end_operator
begin_operator
up f34 f71
1
1725 0
1
0 0 27 68
1
end_operator
begin_operator
up f34 f72
1
1726 0
1
0 0 27 69
1
end_operator
begin_operator
up f34 f73
1
1727 0
1
0 0 27 70
1
end_operator
begin_operator
up f34 f74
1
1728 0
1
0 0 27 71
1
end_operator
begin_operator
up f34 f75
1
1729 0
1
0 0 27 72
1
end_operator
begin_operator
up f34 f76
1
1730 0
1
0 0 27 73
1
end_operator
begin_operator
up f34 f77
1
1731 0
1
0 0 27 74
1
end_operator
begin_operator
up f34 f78
1
1732 0
1
0 0 27 75
1
end_operator
begin_operator
up f34 f79
1
1733 0
1
0 0 27 76
1
end_operator
begin_operator
up f34 f80
1
1734 0
1
0 0 27 78
1
end_operator
begin_operator
up f35 f36
1
1735 0
1
0 0 28 29
1
end_operator
begin_operator
up f35 f37
1
1736 0
1
0 0 28 30
1
end_operator
begin_operator
up f35 f38
1
1737 0
1
0 0 28 31
1
end_operator
begin_operator
up f35 f39
1
1738 0
1
0 0 28 32
1
end_operator
begin_operator
up f35 f40
1
1739 0
1
0 0 28 34
1
end_operator
begin_operator
up f35 f41
1
1740 0
1
0 0 28 35
1
end_operator
begin_operator
up f35 f42
1
1741 0
1
0 0 28 36
1
end_operator
begin_operator
up f35 f43
1
1742 0
1
0 0 28 37
1
end_operator
begin_operator
up f35 f44
1
1743 0
1
0 0 28 38
1
end_operator
begin_operator
up f35 f45
1
1744 0
1
0 0 28 39
1
end_operator
begin_operator
up f35 f46
1
1745 0
1
0 0 28 40
1
end_operator
begin_operator
up f35 f47
1
1746 0
1
0 0 28 41
1
end_operator
begin_operator
up f35 f48
1
1747 0
1
0 0 28 42
1
end_operator
begin_operator
up f35 f49
1
1748 0
1
0 0 28 43
1
end_operator
begin_operator
up f35 f50
1
1749 0
1
0 0 28 45
1
end_operator
begin_operator
up f35 f51
1
1750 0
1
0 0 28 46
1
end_operator
begin_operator
up f35 f52
1
1751 0
1
0 0 28 47
1
end_operator
begin_operator
up f35 f53
1
1752 0
1
0 0 28 48
1
end_operator
begin_operator
up f35 f54
1
1753 0
1
0 0 28 49
1
end_operator
begin_operator
up f35 f55
1
1754 0
1
0 0 28 50
1
end_operator
begin_operator
up f35 f56
1
1755 0
1
0 0 28 51
1
end_operator
begin_operator
up f35 f57
1
1756 0
1
0 0 28 52
1
end_operator
begin_operator
up f35 f58
1
1757 0
1
0 0 28 53
1
end_operator
begin_operator
up f35 f59
1
1758 0
1
0 0 28 54
1
end_operator
begin_operator
up f35 f60
1
1759 0
1
0 0 28 56
1
end_operator
begin_operator
up f35 f61
1
1760 0
1
0 0 28 57
1
end_operator
begin_operator
up f35 f62
1
1761 0
1
0 0 28 58
1
end_operator
begin_operator
up f35 f63
1
1762 0
1
0 0 28 59
1
end_operator
begin_operator
up f35 f64
1
1763 0
1
0 0 28 60
1
end_operator
begin_operator
up f35 f65
1
1764 0
1
0 0 28 61
1
end_operator
begin_operator
up f35 f66
1
1765 0
1
0 0 28 62
1
end_operator
begin_operator
up f35 f67
1
1766 0
1
0 0 28 63
1
end_operator
begin_operator
up f35 f68
1
1767 0
1
0 0 28 64
1
end_operator
begin_operator
up f35 f69
1
1768 0
1
0 0 28 65
1
end_operator
begin_operator
up f35 f70
1
1769 0
1
0 0 28 67
1
end_operator
begin_operator
up f35 f71
1
1770 0
1
0 0 28 68
1
end_operator
begin_operator
up f35 f72
1
1771 0
1
0 0 28 69
1
end_operator
begin_operator
up f35 f73
1
1772 0
1
0 0 28 70
1
end_operator
begin_operator
up f35 f74
1
1773 0
1
0 0 28 71
1
end_operator
begin_operator
up f35 f75
1
1774 0
1
0 0 28 72
1
end_operator
begin_operator
up f35 f76
1
1775 0
1
0 0 28 73
1
end_operator
begin_operator
up f35 f77
1
1776 0
1
0 0 28 74
1
end_operator
begin_operator
up f35 f78
1
1777 0
1
0 0 28 75
1
end_operator
begin_operator
up f35 f79
1
1778 0
1
0 0 28 76
1
end_operator
begin_operator
up f35 f80
1
1779 0
1
0 0 28 78
1
end_operator
begin_operator
up f36 f37
1
1780 0
1
0 0 29 30
1
end_operator
begin_operator
up f36 f38
1
1781 0
1
0 0 29 31
1
end_operator
begin_operator
up f36 f39
1
1782 0
1
0 0 29 32
1
end_operator
begin_operator
up f36 f40
1
1783 0
1
0 0 29 34
1
end_operator
begin_operator
up f36 f41
1
1784 0
1
0 0 29 35
1
end_operator
begin_operator
up f36 f42
1
1785 0
1
0 0 29 36
1
end_operator
begin_operator
up f36 f43
1
1786 0
1
0 0 29 37
1
end_operator
begin_operator
up f36 f44
1
1787 0
1
0 0 29 38
1
end_operator
begin_operator
up f36 f45
1
1788 0
1
0 0 29 39
1
end_operator
begin_operator
up f36 f46
1
1789 0
1
0 0 29 40
1
end_operator
begin_operator
up f36 f47
1
1790 0
1
0 0 29 41
1
end_operator
begin_operator
up f36 f48
1
1791 0
1
0 0 29 42
1
end_operator
begin_operator
up f36 f49
1
1792 0
1
0 0 29 43
1
end_operator
begin_operator
up f36 f50
1
1793 0
1
0 0 29 45
1
end_operator
begin_operator
up f36 f51
1
1794 0
1
0 0 29 46
1
end_operator
begin_operator
up f36 f52
1
1795 0
1
0 0 29 47
1
end_operator
begin_operator
up f36 f53
1
1796 0
1
0 0 29 48
1
end_operator
begin_operator
up f36 f54
1
1797 0
1
0 0 29 49
1
end_operator
begin_operator
up f36 f55
1
1798 0
1
0 0 29 50
1
end_operator
begin_operator
up f36 f56
1
1799 0
1
0 0 29 51
1
end_operator
begin_operator
up f36 f57
1
1800 0
1
0 0 29 52
1
end_operator
begin_operator
up f36 f58
1
1801 0
1
0 0 29 53
1
end_operator
begin_operator
up f36 f59
1
1802 0
1
0 0 29 54
1
end_operator
begin_operator
up f36 f60
1
1803 0
1
0 0 29 56
1
end_operator
begin_operator
up f36 f61
1
1804 0
1
0 0 29 57
1
end_operator
begin_operator
up f36 f62
1
1805 0
1
0 0 29 58
1
end_operator
begin_operator
up f36 f63
1
1806 0
1
0 0 29 59
1
end_operator
begin_operator
up f36 f64
1
1807 0
1
0 0 29 60
1
end_operator
begin_operator
up f36 f65
1
1808 0
1
0 0 29 61
1
end_operator
begin_operator
up f36 f66
1
1809 0
1
0 0 29 62
1
end_operator
begin_operator
up f36 f67
1
1810 0
1
0 0 29 63
1
end_operator
begin_operator
up f36 f68
1
1811 0
1
0 0 29 64
1
end_operator
begin_operator
up f36 f69
1
1812 0
1
0 0 29 65
1
end_operator
begin_operator
up f36 f70
1
1813 0
1
0 0 29 67
1
end_operator
begin_operator
up f36 f71
1
1814 0
1
0 0 29 68
1
end_operator
begin_operator
up f36 f72
1
1815 0
1
0 0 29 69
1
end_operator
begin_operator
up f36 f73
1
1816 0
1
0 0 29 70
1
end_operator
begin_operator
up f36 f74
1
1817 0
1
0 0 29 71
1
end_operator
begin_operator
up f36 f75
1
1818 0
1
0 0 29 72
1
end_operator
begin_operator
up f36 f76
1
1819 0
1
0 0 29 73
1
end_operator
begin_operator
up f36 f77
1
1820 0
1
0 0 29 74
1
end_operator
begin_operator
up f36 f78
1
1821 0
1
0 0 29 75
1
end_operator
begin_operator
up f36 f79
1
1822 0
1
0 0 29 76
1
end_operator
begin_operator
up f36 f80
1
1823 0
1
0 0 29 78
1
end_operator
begin_operator
up f37 f38
1
1824 0
1
0 0 30 31
1
end_operator
begin_operator
up f37 f39
1
1825 0
1
0 0 30 32
1
end_operator
begin_operator
up f37 f40
1
1826 0
1
0 0 30 34
1
end_operator
begin_operator
up f37 f41
1
1827 0
1
0 0 30 35
1
end_operator
begin_operator
up f37 f42
1
1828 0
1
0 0 30 36
1
end_operator
begin_operator
up f37 f43
1
1829 0
1
0 0 30 37
1
end_operator
begin_operator
up f37 f44
1
1830 0
1
0 0 30 38
1
end_operator
begin_operator
up f37 f45
1
1831 0
1
0 0 30 39
1
end_operator
begin_operator
up f37 f46
1
1832 0
1
0 0 30 40
1
end_operator
begin_operator
up f37 f47
1
1833 0
1
0 0 30 41
1
end_operator
begin_operator
up f37 f48
1
1834 0
1
0 0 30 42
1
end_operator
begin_operator
up f37 f49
1
1835 0
1
0 0 30 43
1
end_operator
begin_operator
up f37 f50
1
1836 0
1
0 0 30 45
1
end_operator
begin_operator
up f37 f51
1
1837 0
1
0 0 30 46
1
end_operator
begin_operator
up f37 f52
1
1838 0
1
0 0 30 47
1
end_operator
begin_operator
up f37 f53
1
1839 0
1
0 0 30 48
1
end_operator
begin_operator
up f37 f54
1
1840 0
1
0 0 30 49
1
end_operator
begin_operator
up f37 f55
1
1841 0
1
0 0 30 50
1
end_operator
begin_operator
up f37 f56
1
1842 0
1
0 0 30 51
1
end_operator
begin_operator
up f37 f57
1
1843 0
1
0 0 30 52
1
end_operator
begin_operator
up f37 f58
1
1844 0
1
0 0 30 53
1
end_operator
begin_operator
up f37 f59
1
1845 0
1
0 0 30 54
1
end_operator
begin_operator
up f37 f60
1
1846 0
1
0 0 30 56
1
end_operator
begin_operator
up f37 f61
1
1847 0
1
0 0 30 57
1
end_operator
begin_operator
up f37 f62
1
1848 0
1
0 0 30 58
1
end_operator
begin_operator
up f37 f63
1
1849 0
1
0 0 30 59
1
end_operator
begin_operator
up f37 f64
1
1850 0
1
0 0 30 60
1
end_operator
begin_operator
up f37 f65
1
1851 0
1
0 0 30 61
1
end_operator
begin_operator
up f37 f66
1
1852 0
1
0 0 30 62
1
end_operator
begin_operator
up f37 f67
1
1853 0
1
0 0 30 63
1
end_operator
begin_operator
up f37 f68
1
1854 0
1
0 0 30 64
1
end_operator
begin_operator
up f37 f69
1
1855 0
1
0 0 30 65
1
end_operator
begin_operator
up f37 f70
1
1856 0
1
0 0 30 67
1
end_operator
begin_operator
up f37 f71
1
1857 0
1
0 0 30 68
1
end_operator
begin_operator
up f37 f72
1
1858 0
1
0 0 30 69
1
end_operator
begin_operator
up f37 f73
1
1859 0
1
0 0 30 70
1
end_operator
begin_operator
up f37 f74
1
1860 0
1
0 0 30 71
1
end_operator
begin_operator
up f37 f75
1
1861 0
1
0 0 30 72
1
end_operator
begin_operator
up f37 f76
1
1862 0
1
0 0 30 73
1
end_operator
begin_operator
up f37 f77
1
1863 0
1
0 0 30 74
1
end_operator
begin_operator
up f37 f78
1
1864 0
1
0 0 30 75
1
end_operator
begin_operator
up f37 f79
1
1865 0
1
0 0 30 76
1
end_operator
begin_operator
up f37 f80
1
1866 0
1
0 0 30 78
1
end_operator
begin_operator
up f38 f39
1
1867 0
1
0 0 31 32
1
end_operator
begin_operator
up f38 f40
1
1868 0
1
0 0 31 34
1
end_operator
begin_operator
up f38 f41
1
1869 0
1
0 0 31 35
1
end_operator
begin_operator
up f38 f42
1
1870 0
1
0 0 31 36
1
end_operator
begin_operator
up f38 f43
1
1871 0
1
0 0 31 37
1
end_operator
begin_operator
up f38 f44
1
1872 0
1
0 0 31 38
1
end_operator
begin_operator
up f38 f45
1
1873 0
1
0 0 31 39
1
end_operator
begin_operator
up f38 f46
1
1874 0
1
0 0 31 40
1
end_operator
begin_operator
up f38 f47
1
1875 0
1
0 0 31 41
1
end_operator
begin_operator
up f38 f48
1
1876 0
1
0 0 31 42
1
end_operator
begin_operator
up f38 f49
1
1877 0
1
0 0 31 43
1
end_operator
begin_operator
up f38 f50
1
1878 0
1
0 0 31 45
1
end_operator
begin_operator
up f38 f51
1
1879 0
1
0 0 31 46
1
end_operator
begin_operator
up f38 f52
1
1880 0
1
0 0 31 47
1
end_operator
begin_operator
up f38 f53
1
1881 0
1
0 0 31 48
1
end_operator
begin_operator
up f38 f54
1
1882 0
1
0 0 31 49
1
end_operator
begin_operator
up f38 f55
1
1883 0
1
0 0 31 50
1
end_operator
begin_operator
up f38 f56
1
1884 0
1
0 0 31 51
1
end_operator
begin_operator
up f38 f57
1
1885 0
1
0 0 31 52
1
end_operator
begin_operator
up f38 f58
1
1886 0
1
0 0 31 53
1
end_operator
begin_operator
up f38 f59
1
1887 0
1
0 0 31 54
1
end_operator
begin_operator
up f38 f60
1
1888 0
1
0 0 31 56
1
end_operator
begin_operator
up f38 f61
1
1889 0
1
0 0 31 57
1
end_operator
begin_operator
up f38 f62
1
1890 0
1
0 0 31 58
1
end_operator
begin_operator
up f38 f63
1
1891 0
1
0 0 31 59
1
end_operator
begin_operator
up f38 f64
1
1892 0
1
0 0 31 60
1
end_operator
begin_operator
up f38 f65
1
1893 0
1
0 0 31 61
1
end_operator
begin_operator
up f38 f66
1
1894 0
1
0 0 31 62
1
end_operator
begin_operator
up f38 f67
1
1895 0
1
0 0 31 63
1
end_operator
begin_operator
up f38 f68
1
1896 0
1
0 0 31 64
1
end_operator
begin_operator
up f38 f69
1
1897 0
1
0 0 31 65
1
end_operator
begin_operator
up f38 f70
1
1898 0
1
0 0 31 67
1
end_operator
begin_operator
up f38 f71
1
1899 0
1
0 0 31 68
1
end_operator
begin_operator
up f38 f72
1
1900 0
1
0 0 31 69
1
end_operator
begin_operator
up f38 f73
1
1901 0
1
0 0 31 70
1
end_operator
begin_operator
up f38 f74
1
1902 0
1
0 0 31 71
1
end_operator
begin_operator
up f38 f75
1
1903 0
1
0 0 31 72
1
end_operator
begin_operator
up f38 f76
1
1904 0
1
0 0 31 73
1
end_operator
begin_operator
up f38 f77
1
1905 0
1
0 0 31 74
1
end_operator
begin_operator
up f38 f78
1
1906 0
1
0 0 31 75
1
end_operator
begin_operator
up f38 f79
1
1907 0
1
0 0 31 76
1
end_operator
begin_operator
up f38 f80
1
1908 0
1
0 0 31 78
1
end_operator
begin_operator
up f39 f40
1
1909 0
1
0 0 32 34
1
end_operator
begin_operator
up f39 f41
1
1910 0
1
0 0 32 35
1
end_operator
begin_operator
up f39 f42
1
1911 0
1
0 0 32 36
1
end_operator
begin_operator
up f39 f43
1
1912 0
1
0 0 32 37
1
end_operator
begin_operator
up f39 f44
1
1913 0
1
0 0 32 38
1
end_operator
begin_operator
up f39 f45
1
1914 0
1
0 0 32 39
1
end_operator
begin_operator
up f39 f46
1
1915 0
1
0 0 32 40
1
end_operator
begin_operator
up f39 f47
1
1916 0
1
0 0 32 41
1
end_operator
begin_operator
up f39 f48
1
1917 0
1
0 0 32 42
1
end_operator
begin_operator
up f39 f49
1
1918 0
1
0 0 32 43
1
end_operator
begin_operator
up f39 f50
1
1919 0
1
0 0 32 45
1
end_operator
begin_operator
up f39 f51
1
1920 0
1
0 0 32 46
1
end_operator
begin_operator
up f39 f52
1
1921 0
1
0 0 32 47
1
end_operator
begin_operator
up f39 f53
1
1922 0
1
0 0 32 48
1
end_operator
begin_operator
up f39 f54
1
1923 0
1
0 0 32 49
1
end_operator
begin_operator
up f39 f55
1
1924 0
1
0 0 32 50
1
end_operator
begin_operator
up f39 f56
1
1925 0
1
0 0 32 51
1
end_operator
begin_operator
up f39 f57
1
1926 0
1
0 0 32 52
1
end_operator
begin_operator
up f39 f58
1
1927 0
1
0 0 32 53
1
end_operator
begin_operator
up f39 f59
1
1928 0
1
0 0 32 54
1
end_operator
begin_operator
up f39 f60
1
1929 0
1
0 0 32 56
1
end_operator
begin_operator
up f39 f61
1
1930 0
1
0 0 32 57
1
end_operator
begin_operator
up f39 f62
1
1931 0
1
0 0 32 58
1
end_operator
begin_operator
up f39 f63
1
1932 0
1
0 0 32 59
1
end_operator
begin_operator
up f39 f64
1
1933 0
1
0 0 32 60
1
end_operator
begin_operator
up f39 f65
1
1934 0
1
0 0 32 61
1
end_operator
begin_operator
up f39 f66
1
1935 0
1
0 0 32 62
1
end_operator
begin_operator
up f39 f67
1
1936 0
1
0 0 32 63
1
end_operator
begin_operator
up f39 f68
1
1937 0
1
0 0 32 64
1
end_operator
begin_operator
up f39 f69
1
1938 0
1
0 0 32 65
1
end_operator
begin_operator
up f39 f70
1
1939 0
1
0 0 32 67
1
end_operator
begin_operator
up f39 f71
1
1940 0
1
0 0 32 68
1
end_operator
begin_operator
up f39 f72
1
1941 0
1
0 0 32 69
1
end_operator
begin_operator
up f39 f73
1
1942 0
1
0 0 32 70
1
end_operator
begin_operator
up f39 f74
1
1943 0
1
0 0 32 71
1
end_operator
begin_operator
up f39 f75
1
1944 0
1
0 0 32 72
1
end_operator
begin_operator
up f39 f76
1
1945 0
1
0 0 32 73
1
end_operator
begin_operator
up f39 f77
1
1946 0
1
0 0 32 74
1
end_operator
begin_operator
up f39 f78
1
1947 0
1
0 0 32 75
1
end_operator
begin_operator
up f39 f79
1
1948 0
1
0 0 32 76
1
end_operator
begin_operator
up f39 f80
1
1949 0
1
0 0 32 78
1
end_operator
begin_operator
up f4 f10
1
1950 0
1
0 0 33 1
1
end_operator
begin_operator
up f4 f11
1
1951 0
1
0 0 33 2
1
end_operator
begin_operator
up f4 f12
1
1952 0
1
0 0 33 3
1
end_operator
begin_operator
up f4 f13
1
1953 0
1
0 0 33 4
1
end_operator
begin_operator
up f4 f14
1
1954 0
1
0 0 33 5
1
end_operator
begin_operator
up f4 f15
1
1955 0
1
0 0 33 6
1
end_operator
begin_operator
up f4 f16
1
1956 0
1
0 0 33 7
1
end_operator
begin_operator
up f4 f17
1
1957 0
1
0 0 33 8
1
end_operator
begin_operator
up f4 f18
1
1958 0
1
0 0 33 9
1
end_operator
begin_operator
up f4 f19
1
1959 0
1
0 0 33 10
1
end_operator
begin_operator
up f4 f20
1
1960 0
1
0 0 33 12
1
end_operator
begin_operator
up f4 f21
1
1961 0
1
0 0 33 13
1
end_operator
begin_operator
up f4 f22
1
1962 0
1
0 0 33 14
1
end_operator
begin_operator
up f4 f23
1
1963 0
1
0 0 33 15
1
end_operator
begin_operator
up f4 f24
1
1964 0
1
0 0 33 16
1
end_operator
begin_operator
up f4 f25
1
1965 0
1
0 0 33 17
1
end_operator
begin_operator
up f4 f26
1
1966 0
1
0 0 33 18
1
end_operator
begin_operator
up f4 f27
1
1967 0
1
0 0 33 19
1
end_operator
begin_operator
up f4 f28
1
1968 0
1
0 0 33 20
1
end_operator
begin_operator
up f4 f29
1
1969 0
1
0 0 33 21
1
end_operator
begin_operator
up f4 f30
1
1970 0
1
0 0 33 23
1
end_operator
begin_operator
up f4 f31
1
1971 0
1
0 0 33 24
1
end_operator
begin_operator
up f4 f32
1
1972 0
1
0 0 33 25
1
end_operator
begin_operator
up f4 f33
1
1973 0
1
0 0 33 26
1
end_operator
begin_operator
up f4 f34
1
1974 0
1
0 0 33 27
1
end_operator
begin_operator
up f4 f35
1
1975 0
1
0 0 33 28
1
end_operator
begin_operator
up f4 f36
1
1976 0
1
0 0 33 29
1
end_operator
begin_operator
up f4 f37
1
1977 0
1
0 0 33 30
1
end_operator
begin_operator
up f4 f38
1
1978 0
1
0 0 33 31
1
end_operator
begin_operator
up f4 f39
1
1979 0
1
0 0 33 32
1
end_operator
begin_operator
up f4 f40
1
1980 0
1
0 0 33 34
1
end_operator
begin_operator
up f4 f41
1
1981 0
1
0 0 33 35
1
end_operator
begin_operator
up f4 f42
1
1982 0
1
0 0 33 36
1
end_operator
begin_operator
up f4 f43
1
1983 0
1
0 0 33 37
1
end_operator
begin_operator
up f4 f44
1
1984 0
1
0 0 33 38
1
end_operator
begin_operator
up f4 f45
1
1985 0
1
0 0 33 39
1
end_operator
begin_operator
up f4 f46
1
1986 0
1
0 0 33 40
1
end_operator
begin_operator
up f4 f47
1
1987 0
1
0 0 33 41
1
end_operator
begin_operator
up f4 f48
1
1988 0
1
0 0 33 42
1
end_operator
begin_operator
up f4 f49
1
1989 0
1
0 0 33 43
1
end_operator
begin_operator
up f4 f5
1
1990 0
1
0 0 33 44
1
end_operator
begin_operator
up f4 f50
1
1991 0
1
0 0 33 45
1
end_operator
begin_operator
up f4 f51
1
1992 0
1
0 0 33 46
1
end_operator
begin_operator
up f4 f52
1
1993 0
1
0 0 33 47
1
end_operator
begin_operator
up f4 f53
1
1994 0
1
0 0 33 48
1
end_operator
begin_operator
up f4 f54
1
1995 0
1
0 0 33 49
1
end_operator
begin_operator
up f4 f55
1
1996 0
1
0 0 33 50
1
end_operator
begin_operator
up f4 f56
1
1997 0
1
0 0 33 51
1
end_operator
begin_operator
up f4 f57
1
1998 0
1
0 0 33 52
1
end_operator
begin_operator
up f4 f58
1
1999 0
1
0 0 33 53
1
end_operator
begin_operator
up f4 f59
1
2000 0
1
0 0 33 54
1
end_operator
begin_operator
up f4 f6
1
2001 0
1
0 0 33 55
1
end_operator
begin_operator
up f4 f60
1
2002 0
1
0 0 33 56
1
end_operator
begin_operator
up f4 f61
1
2003 0
1
0 0 33 57
1
end_operator
begin_operator
up f4 f62
1
2004 0
1
0 0 33 58
1
end_operator
begin_operator
up f4 f63
1
2005 0
1
0 0 33 59
1
end_operator
begin_operator
up f4 f64
1
2006 0
1
0 0 33 60
1
end_operator
begin_operator
up f4 f65
1
2007 0
1
0 0 33 61
1
end_operator
begin_operator
up f4 f66
1
2008 0
1
0 0 33 62
1
end_operator
begin_operator
up f4 f67
1
2009 0
1
0 0 33 63
1
end_operator
begin_operator
up f4 f68
1
2010 0
1
0 0 33 64
1
end_operator
begin_operator
up f4 f69
1
2011 0
1
0 0 33 65
1
end_operator
begin_operator
up f4 f7
1
2012 0
1
0 0 33 66
1
end_operator
begin_operator
up f4 f70
1
2013 0
1
0 0 33 67
1
end_operator
begin_operator
up f4 f71
1
2014 0
1
0 0 33 68
1
end_operator
begin_operator
up f4 f72
1
2015 0
1
0 0 33 69
1
end_operator
begin_operator
up f4 f73
1
2016 0
1
0 0 33 70
1
end_operator
begin_operator
up f4 f74
1
2017 0
1
0 0 33 71
1
end_operator
begin_operator
up f4 f75
1
2018 0
1
0 0 33 72
1
end_operator
begin_operator
up f4 f76
1
2019 0
1
0 0 33 73
1
end_operator
begin_operator
up f4 f77
1
2020 0
1
0 0 33 74
1
end_operator
begin_operator
up f4 f78
1
2021 0
1
0 0 33 75
1
end_operator
begin_operator
up f4 f79
1
2022 0
1
0 0 33 76
1
end_operator
begin_operator
up f4 f8
1
2023 0
1
0 0 33 77
1
end_operator
begin_operator
up f4 f80
1
2024 0
1
0 0 33 78
1
end_operator
begin_operator
up f4 f9
1
2025 0
1
0 0 33 79
1
end_operator
begin_operator
up f40 f41
1
2026 0
1
0 0 34 35
1
end_operator
begin_operator
up f40 f42
1
2027 0
1
0 0 34 36
1
end_operator
begin_operator
up f40 f43
1
2028 0
1
0 0 34 37
1
end_operator
begin_operator
up f40 f44
1
2029 0
1
0 0 34 38
1
end_operator
begin_operator
up f40 f45
1
2030 0
1
0 0 34 39
1
end_operator
begin_operator
up f40 f46
1
2031 0
1
0 0 34 40
1
end_operator
begin_operator
up f40 f47
1
2032 0
1
0 0 34 41
1
end_operator
begin_operator
up f40 f48
1
2033 0
1
0 0 34 42
1
end_operator
begin_operator
up f40 f49
1
2034 0
1
0 0 34 43
1
end_operator
begin_operator
up f40 f50
1
2035 0
1
0 0 34 45
1
end_operator
begin_operator
up f40 f51
1
2036 0
1
0 0 34 46
1
end_operator
begin_operator
up f40 f52
1
2037 0
1
0 0 34 47
1
end_operator
begin_operator
up f40 f53
1
2038 0
1
0 0 34 48
1
end_operator
begin_operator
up f40 f54
1
2039 0
1
0 0 34 49
1
end_operator
begin_operator
up f40 f55
1
2040 0
1
0 0 34 50
1
end_operator
begin_operator
up f40 f56
1
2041 0
1
0 0 34 51
1
end_operator
begin_operator
up f40 f57
1
2042 0
1
0 0 34 52
1
end_operator
begin_operator
up f40 f58
1
2043 0
1
0 0 34 53
1
end_operator
begin_operator
up f40 f59
1
2044 0
1
0 0 34 54
1
end_operator
begin_operator
up f40 f60
1
2045 0
1
0 0 34 56
1
end_operator
begin_operator
up f40 f61
1
2046 0
1
0 0 34 57
1
end_operator
begin_operator
up f40 f62
1
2047 0
1
0 0 34 58
1
end_operator
begin_operator
up f40 f63
1
2048 0
1
0 0 34 59
1
end_operator
begin_operator
up f40 f64
1
2049 0
1
0 0 34 60
1
end_operator
begin_operator
up f40 f65
1
2050 0
1
0 0 34 61
1
end_operator
begin_operator
up f40 f66
1
2051 0
1
0 0 34 62
1
end_operator
begin_operator
up f40 f67
1
2052 0
1
0 0 34 63
1
end_operator
begin_operator
up f40 f68
1
2053 0
1
0 0 34 64
1
end_operator
begin_operator
up f40 f69
1
2054 0
1
0 0 34 65
1
end_operator
begin_operator
up f40 f70
1
2055 0
1
0 0 34 67
1
end_operator
begin_operator
up f40 f71
1
2056 0
1
0 0 34 68
1
end_operator
begin_operator
up f40 f72
1
2057 0
1
0 0 34 69
1
end_operator
begin_operator
up f40 f73
1
2058 0
1
0 0 34 70
1
end_operator
begin_operator
up f40 f74
1
2059 0
1
0 0 34 71
1
end_operator
begin_operator
up f40 f75
1
2060 0
1
0 0 34 72
1
end_operator
begin_operator
up f40 f76
1
2061 0
1
0 0 34 73
1
end_operator
begin_operator
up f40 f77
1
2062 0
1
0 0 34 74
1
end_operator
begin_operator
up f40 f78
1
2063 0
1
0 0 34 75
1
end_operator
begin_operator
up f40 f79
1
2064 0
1
0 0 34 76
1
end_operator
begin_operator
up f40 f80
1
2065 0
1
0 0 34 78
1
end_operator
begin_operator
up f41 f42
1
2066 0
1
0 0 35 36
1
end_operator
begin_operator
up f41 f43
1
2067 0
1
0 0 35 37
1
end_operator
begin_operator
up f41 f44
1
2068 0
1
0 0 35 38
1
end_operator
begin_operator
up f41 f45
1
2069 0
1
0 0 35 39
1
end_operator
begin_operator
up f41 f46
1
2070 0
1
0 0 35 40
1
end_operator
begin_operator
up f41 f47
1
2071 0
1
0 0 35 41
1
end_operator
begin_operator
up f41 f48
1
2072 0
1
0 0 35 42
1
end_operator
begin_operator
up f41 f49
1
2073 0
1
0 0 35 43
1
end_operator
begin_operator
up f41 f50
1
2074 0
1
0 0 35 45
1
end_operator
begin_operator
up f41 f51
1
2075 0
1
0 0 35 46
1
end_operator
begin_operator
up f41 f52
1
2076 0
1
0 0 35 47
1
end_operator
begin_operator
up f41 f53
1
2077 0
1
0 0 35 48
1
end_operator
begin_operator
up f41 f54
1
2078 0
1
0 0 35 49
1
end_operator
begin_operator
up f41 f55
1
2079 0
1
0 0 35 50
1
end_operator
begin_operator
up f41 f56
1
2080 0
1
0 0 35 51
1
end_operator
begin_operator
up f41 f57
1
2081 0
1
0 0 35 52
1
end_operator
begin_operator
up f41 f58
1
2082 0
1
0 0 35 53
1
end_operator
begin_operator
up f41 f59
1
2083 0
1
0 0 35 54
1
end_operator
begin_operator
up f41 f60
1
2084 0
1
0 0 35 56
1
end_operator
begin_operator
up f41 f61
1
2085 0
1
0 0 35 57
1
end_operator
begin_operator
up f41 f62
1
2086 0
1
0 0 35 58
1
end_operator
begin_operator
up f41 f63
1
2087 0
1
0 0 35 59
1
end_operator
begin_operator
up f41 f64
1
2088 0
1
0 0 35 60
1
end_operator
begin_operator
up f41 f65
1
2089 0
1
0 0 35 61
1
end_operator
begin_operator
up f41 f66
1
2090 0
1
0 0 35 62
1
end_operator
begin_operator
up f41 f67
1
2091 0
1
0 0 35 63
1
end_operator
begin_operator
up f41 f68
1
2092 0
1
0 0 35 64
1
end_operator
begin_operator
up f41 f69
1
2093 0
1
0 0 35 65
1
end_operator
begin_operator
up f41 f70
1
2094 0
1
0 0 35 67
1
end_operator
begin_operator
up f41 f71
1
2095 0
1
0 0 35 68
1
end_operator
begin_operator
up f41 f72
1
2096 0
1
0 0 35 69
1
end_operator
begin_operator
up f41 f73
1
2097 0
1
0 0 35 70
1
end_operator
begin_operator
up f41 f74
1
2098 0
1
0 0 35 71
1
end_operator
begin_operator
up f41 f75
1
2099 0
1
0 0 35 72
1
end_operator
begin_operator
up f41 f76
1
2100 0
1
0 0 35 73
1
end_operator
begin_operator
up f41 f77
1
2101 0
1
0 0 35 74
1
end_operator
begin_operator
up f41 f78
1
2102 0
1
0 0 35 75
1
end_operator
begin_operator
up f41 f79
1
2103 0
1
0 0 35 76
1
end_operator
begin_operator
up f41 f80
1
2104 0
1
0 0 35 78
1
end_operator
begin_operator
up f42 f43
1
2105 0
1
0 0 36 37
1
end_operator
begin_operator
up f42 f44
1
2106 0
1
0 0 36 38
1
end_operator
begin_operator
up f42 f45
1
2107 0
1
0 0 36 39
1
end_operator
begin_operator
up f42 f46
1
2108 0
1
0 0 36 40
1
end_operator
begin_operator
up f42 f47
1
2109 0
1
0 0 36 41
1
end_operator
begin_operator
up f42 f48
1
2110 0
1
0 0 36 42
1
end_operator
begin_operator
up f42 f49
1
2111 0
1
0 0 36 43
1
end_operator
begin_operator
up f42 f50
1
2112 0
1
0 0 36 45
1
end_operator
begin_operator
up f42 f51
1
2113 0
1
0 0 36 46
1
end_operator
begin_operator
up f42 f52
1
2114 0
1
0 0 36 47
1
end_operator
begin_operator
up f42 f53
1
2115 0
1
0 0 36 48
1
end_operator
begin_operator
up f42 f54
1
2116 0
1
0 0 36 49
1
end_operator
begin_operator
up f42 f55
1
2117 0
1
0 0 36 50
1
end_operator
begin_operator
up f42 f56
1
2118 0
1
0 0 36 51
1
end_operator
begin_operator
up f42 f57
1
2119 0
1
0 0 36 52
1
end_operator
begin_operator
up f42 f58
1
2120 0
1
0 0 36 53
1
end_operator
begin_operator
up f42 f59
1
2121 0
1
0 0 36 54
1
end_operator
begin_operator
up f42 f60
1
2122 0
1
0 0 36 56
1
end_operator
begin_operator
up f42 f61
1
2123 0
1
0 0 36 57
1
end_operator
begin_operator
up f42 f62
1
2124 0
1
0 0 36 58
1
end_operator
begin_operator
up f42 f63
1
2125 0
1
0 0 36 59
1
end_operator
begin_operator
up f42 f64
1
2126 0
1
0 0 36 60
1
end_operator
begin_operator
up f42 f65
1
2127 0
1
0 0 36 61
1
end_operator
begin_operator
up f42 f66
1
2128 0
1
0 0 36 62
1
end_operator
begin_operator
up f42 f67
1
2129 0
1
0 0 36 63
1
end_operator
begin_operator
up f42 f68
1
2130 0
1
0 0 36 64
1
end_operator
begin_operator
up f42 f69
1
2131 0
1
0 0 36 65
1
end_operator
begin_operator
up f42 f70
1
2132 0
1
0 0 36 67
1
end_operator
begin_operator
up f42 f71
1
2133 0
1
0 0 36 68
1
end_operator
begin_operator
up f42 f72
1
2134 0
1
0 0 36 69
1
end_operator
begin_operator
up f42 f73
1
2135 0
1
0 0 36 70
1
end_operator
begin_operator
up f42 f74
1
2136 0
1
0 0 36 71
1
end_operator
begin_operator
up f42 f75
1
2137 0
1
0 0 36 72
1
end_operator
begin_operator
up f42 f76
1
2138 0
1
0 0 36 73
1
end_operator
begin_operator
up f42 f77
1
2139 0
1
0 0 36 74
1
end_operator
begin_operator
up f42 f78
1
2140 0
1
0 0 36 75
1
end_operator
begin_operator
up f42 f79
1
2141 0
1
0 0 36 76
1
end_operator
begin_operator
up f42 f80
1
2142 0
1
0 0 36 78
1
end_operator
begin_operator
up f43 f44
1
2143 0
1
0 0 37 38
1
end_operator
begin_operator
up f43 f45
1
2144 0
1
0 0 37 39
1
end_operator
begin_operator
up f43 f46
1
2145 0
1
0 0 37 40
1
end_operator
begin_operator
up f43 f47
1
2146 0
1
0 0 37 41
1
end_operator
begin_operator
up f43 f48
1
2147 0
1
0 0 37 42
1
end_operator
begin_operator
up f43 f49
1
2148 0
1
0 0 37 43
1
end_operator
begin_operator
up f43 f50
1
2149 0
1
0 0 37 45
1
end_operator
begin_operator
up f43 f51
1
2150 0
1
0 0 37 46
1
end_operator
begin_operator
up f43 f52
1
2151 0
1
0 0 37 47
1
end_operator
begin_operator
up f43 f53
1
2152 0
1
0 0 37 48
1
end_operator
begin_operator
up f43 f54
1
2153 0
1
0 0 37 49
1
end_operator
begin_operator
up f43 f55
1
2154 0
1
0 0 37 50
1
end_operator
begin_operator
up f43 f56
1
2155 0
1
0 0 37 51
1
end_operator
begin_operator
up f43 f57
1
2156 0
1
0 0 37 52
1
end_operator
begin_operator
up f43 f58
1
2157 0
1
0 0 37 53
1
end_operator
begin_operator
up f43 f59
1
2158 0
1
0 0 37 54
1
end_operator
begin_operator
up f43 f60
1
2159 0
1
0 0 37 56
1
end_operator
begin_operator
up f43 f61
1
2160 0
1
0 0 37 57
1
end_operator
begin_operator
up f43 f62
1
2161 0
1
0 0 37 58
1
end_operator
begin_operator
up f43 f63
1
2162 0
1
0 0 37 59
1
end_operator
begin_operator
up f43 f64
1
2163 0
1
0 0 37 60
1
end_operator
begin_operator
up f43 f65
1
2164 0
1
0 0 37 61
1
end_operator
begin_operator
up f43 f66
1
2165 0
1
0 0 37 62
1
end_operator
begin_operator
up f43 f67
1
2166 0
1
0 0 37 63
1
end_operator
begin_operator
up f43 f68
1
2167 0
1
0 0 37 64
1
end_operator
begin_operator
up f43 f69
1
2168 0
1
0 0 37 65
1
end_operator
begin_operator
up f43 f70
1
2169 0
1
0 0 37 67
1
end_operator
begin_operator
up f43 f71
1
2170 0
1
0 0 37 68
1
end_operator
begin_operator
up f43 f72
1
2171 0
1
0 0 37 69
1
end_operator
begin_operator
up f43 f73
1
2172 0
1
0 0 37 70
1
end_operator
begin_operator
up f43 f74
1
2173 0
1
0 0 37 71
1
end_operator
begin_operator
up f43 f75
1
2174 0
1
0 0 37 72
1
end_operator
begin_operator
up f43 f76
1
2175 0
1
0 0 37 73
1
end_operator
begin_operator
up f43 f77
1
2176 0
1
0 0 37 74
1
end_operator
begin_operator
up f43 f78
1
2177 0
1
0 0 37 75
1
end_operator
begin_operator
up f43 f79
1
2178 0
1
0 0 37 76
1
end_operator
begin_operator
up f43 f80
1
2179 0
1
0 0 37 78
1
end_operator
begin_operator
up f44 f45
1
2180 0
1
0 0 38 39
1
end_operator
begin_operator
up f44 f46
1
2181 0
1
0 0 38 40
1
end_operator
begin_operator
up f44 f47
1
2182 0
1
0 0 38 41
1
end_operator
begin_operator
up f44 f48
1
2183 0
1
0 0 38 42
1
end_operator
begin_operator
up f44 f49
1
2184 0
1
0 0 38 43
1
end_operator
begin_operator
up f44 f50
1
2185 0
1
0 0 38 45
1
end_operator
begin_operator
up f44 f51
1
2186 0
1
0 0 38 46
1
end_operator
begin_operator
up f44 f52
1
2187 0
1
0 0 38 47
1
end_operator
begin_operator
up f44 f53
1
2188 0
1
0 0 38 48
1
end_operator
begin_operator
up f44 f54
1
2189 0
1
0 0 38 49
1
end_operator
begin_operator
up f44 f55
1
2190 0
1
0 0 38 50
1
end_operator
begin_operator
up f44 f56
1
2191 0
1
0 0 38 51
1
end_operator
begin_operator
up f44 f57
1
2192 0
1
0 0 38 52
1
end_operator
begin_operator
up f44 f58
1
2193 0
1
0 0 38 53
1
end_operator
begin_operator
up f44 f59
1
2194 0
1
0 0 38 54
1
end_operator
begin_operator
up f44 f60
1
2195 0
1
0 0 38 56
1
end_operator
begin_operator
up f44 f61
1
2196 0
1
0 0 38 57
1
end_operator
begin_operator
up f44 f62
1
2197 0
1
0 0 38 58
1
end_operator
begin_operator
up f44 f63
1
2198 0
1
0 0 38 59
1
end_operator
begin_operator
up f44 f64
1
2199 0
1
0 0 38 60
1
end_operator
begin_operator
up f44 f65
1
2200 0
1
0 0 38 61
1
end_operator
begin_operator
up f44 f66
1
2201 0
1
0 0 38 62
1
end_operator
begin_operator
up f44 f67
1
2202 0
1
0 0 38 63
1
end_operator
begin_operator
up f44 f68
1
2203 0
1
0 0 38 64
1
end_operator
begin_operator
up f44 f69
1
2204 0
1
0 0 38 65
1
end_operator
begin_operator
up f44 f70
1
2205 0
1
0 0 38 67
1
end_operator
begin_operator
up f44 f71
1
2206 0
1
0 0 38 68
1
end_operator
begin_operator
up f44 f72
1
2207 0
1
0 0 38 69
1
end_operator
begin_operator
up f44 f73
1
2208 0
1
0 0 38 70
1
end_operator
begin_operator
up f44 f74
1
2209 0
1
0 0 38 71
1
end_operator
begin_operator
up f44 f75
1
2210 0
1
0 0 38 72
1
end_operator
begin_operator
up f44 f76
1
2211 0
1
0 0 38 73
1
end_operator
begin_operator
up f44 f77
1
2212 0
1
0 0 38 74
1
end_operator
begin_operator
up f44 f78
1
2213 0
1
0 0 38 75
1
end_operator
begin_operator
up f44 f79
1
2214 0
1
0 0 38 76
1
end_operator
begin_operator
up f44 f80
1
2215 0
1
0 0 38 78
1
end_operator
begin_operator
up f45 f46
1
2216 0
1
0 0 39 40
1
end_operator
begin_operator
up f45 f47
1
2217 0
1
0 0 39 41
1
end_operator
begin_operator
up f45 f48
1
2218 0
1
0 0 39 42
1
end_operator
begin_operator
up f45 f49
1
2219 0
1
0 0 39 43
1
end_operator
begin_operator
up f45 f50
1
2220 0
1
0 0 39 45
1
end_operator
begin_operator
up f45 f51
1
2221 0
1
0 0 39 46
1
end_operator
begin_operator
up f45 f52
1
2222 0
1
0 0 39 47
1
end_operator
begin_operator
up f45 f53
1
2223 0
1
0 0 39 48
1
end_operator
begin_operator
up f45 f54
1
2224 0
1
0 0 39 49
1
end_operator
begin_operator
up f45 f55
1
2225 0
1
0 0 39 50
1
end_operator
begin_operator
up f45 f56
1
2226 0
1
0 0 39 51
1
end_operator
begin_operator
up f45 f57
1
2227 0
1
0 0 39 52
1
end_operator
begin_operator
up f45 f58
1
2228 0
1
0 0 39 53
1
end_operator
begin_operator
up f45 f59
1
2229 0
1
0 0 39 54
1
end_operator
begin_operator
up f45 f60
1
2230 0
1
0 0 39 56
1
end_operator
begin_operator
up f45 f61
1
2231 0
1
0 0 39 57
1
end_operator
begin_operator
up f45 f62
1
2232 0
1
0 0 39 58
1
end_operator
begin_operator
up f45 f63
1
2233 0
1
0 0 39 59
1
end_operator
begin_operator
up f45 f64
1
2234 0
1
0 0 39 60
1
end_operator
begin_operator
up f45 f65
1
2235 0
1
0 0 39 61
1
end_operator
begin_operator
up f45 f66
1
2236 0
1
0 0 39 62
1
end_operator
begin_operator
up f45 f67
1
2237 0
1
0 0 39 63
1
end_operator
begin_operator
up f45 f68
1
2238 0
1
0 0 39 64
1
end_operator
begin_operator
up f45 f69
1
2239 0
1
0 0 39 65
1
end_operator
begin_operator
up f45 f70
1
2240 0
1
0 0 39 67
1
end_operator
begin_operator
up f45 f71
1
2241 0
1
0 0 39 68
1
end_operator
begin_operator
up f45 f72
1
2242 0
1
0 0 39 69
1
end_operator
begin_operator
up f45 f73
1
2243 0
1
0 0 39 70
1
end_operator
begin_operator
up f45 f74
1
2244 0
1
0 0 39 71
1
end_operator
begin_operator
up f45 f75
1
2245 0
1
0 0 39 72
1
end_operator
begin_operator
up f45 f76
1
2246 0
1
0 0 39 73
1
end_operator
begin_operator
up f45 f77
1
2247 0
1
0 0 39 74
1
end_operator
begin_operator
up f45 f78
1
2248 0
1
0 0 39 75
1
end_operator
begin_operator
up f45 f79
1
2249 0
1
0 0 39 76
1
end_operator
begin_operator
up f45 f80
1
2250 0
1
0 0 39 78
1
end_operator
begin_operator
up f46 f47
1
2251 0
1
0 0 40 41
1
end_operator
begin_operator
up f46 f48
1
2252 0
1
0 0 40 42
1
end_operator
begin_operator
up f46 f49
1
2253 0
1
0 0 40 43
1
end_operator
begin_operator
up f46 f50
1
2254 0
1
0 0 40 45
1
end_operator
begin_operator
up f46 f51
1
2255 0
1
0 0 40 46
1
end_operator
begin_operator
up f46 f52
1
2256 0
1
0 0 40 47
1
end_operator
begin_operator
up f46 f53
1
2257 0
1
0 0 40 48
1
end_operator
begin_operator
up f46 f54
1
2258 0
1
0 0 40 49
1
end_operator
begin_operator
up f46 f55
1
2259 0
1
0 0 40 50
1
end_operator
begin_operator
up f46 f56
1
2260 0
1
0 0 40 51
1
end_operator
begin_operator
up f46 f57
1
2261 0
1
0 0 40 52
1
end_operator
begin_operator
up f46 f58
1
2262 0
1
0 0 40 53
1
end_operator
begin_operator
up f46 f59
1
2263 0
1
0 0 40 54
1
end_operator
begin_operator
up f46 f60
1
2264 0
1
0 0 40 56
1
end_operator
begin_operator
up f46 f61
1
2265 0
1
0 0 40 57
1
end_operator
begin_operator
up f46 f62
1
2266 0
1
0 0 40 58
1
end_operator
begin_operator
up f46 f63
1
2267 0
1
0 0 40 59
1
end_operator
begin_operator
up f46 f64
1
2268 0
1
0 0 40 60
1
end_operator
begin_operator
up f46 f65
1
2269 0
1
0 0 40 61
1
end_operator
begin_operator
up f46 f66
1
2270 0
1
0 0 40 62
1
end_operator
begin_operator
up f46 f67
1
2271 0
1
0 0 40 63
1
end_operator
begin_operator
up f46 f68
1
2272 0
1
0 0 40 64
1
end_operator
begin_operator
up f46 f69
1
2273 0
1
0 0 40 65
1
end_operator
begin_operator
up f46 f70
1
2274 0
1
0 0 40 67
1
end_operator
begin_operator
up f46 f71
1
2275 0
1
0 0 40 68
1
end_operator
begin_operator
up f46 f72
1
2276 0
1
0 0 40 69
1
end_operator
begin_operator
up f46 f73
1
2277 0
1
0 0 40 70
1
end_operator
begin_operator
up f46 f74
1
2278 0
1
0 0 40 71
1
end_operator
begin_operator
up f46 f75
1
2279 0
1
0 0 40 72
1
end_operator
begin_operator
up f46 f76
1
2280 0
1
0 0 40 73
1
end_operator
begin_operator
up f46 f77
1
2281 0
1
0 0 40 74
1
end_operator
begin_operator
up f46 f78
1
2282 0
1
0 0 40 75
1
end_operator
begin_operator
up f46 f79
1
2283 0
1
0 0 40 76
1
end_operator
begin_operator
up f46 f80
1
2284 0
1
0 0 40 78
1
end_operator
begin_operator
up f47 f48
1
2285 0
1
0 0 41 42
1
end_operator
begin_operator
up f47 f49
1
2286 0
1
0 0 41 43
1
end_operator
begin_operator
up f47 f50
1
2287 0
1
0 0 41 45
1
end_operator
begin_operator
up f47 f51
1
2288 0
1
0 0 41 46
1
end_operator
begin_operator
up f47 f52
1
2289 0
1
0 0 41 47
1
end_operator
begin_operator
up f47 f53
1
2290 0
1
0 0 41 48
1
end_operator
begin_operator
up f47 f54
1
2291 0
1
0 0 41 49
1
end_operator
begin_operator
up f47 f55
1
2292 0
1
0 0 41 50
1
end_operator
begin_operator
up f47 f56
1
2293 0
1
0 0 41 51
1
end_operator
begin_operator
up f47 f57
1
2294 0
1
0 0 41 52
1
end_operator
begin_operator
up f47 f58
1
2295 0
1
0 0 41 53
1
end_operator
begin_operator
up f47 f59
1
2296 0
1
0 0 41 54
1
end_operator
begin_operator
up f47 f60
1
2297 0
1
0 0 41 56
1
end_operator
begin_operator
up f47 f61
1
2298 0
1
0 0 41 57
1
end_operator
begin_operator
up f47 f62
1
2299 0
1
0 0 41 58
1
end_operator
begin_operator
up f47 f63
1
2300 0
1
0 0 41 59
1
end_operator
begin_operator
up f47 f64
1
2301 0
1
0 0 41 60
1
end_operator
begin_operator
up f47 f65
1
2302 0
1
0 0 41 61
1
end_operator
begin_operator
up f47 f66
1
2303 0
1
0 0 41 62
1
end_operator
begin_operator
up f47 f67
1
2304 0
1
0 0 41 63
1
end_operator
begin_operator
up f47 f68
1
2305 0
1
0 0 41 64
1
end_operator
begin_operator
up f47 f69
1
2306 0
1
0 0 41 65
1
end_operator
begin_operator
up f47 f70
1
2307 0
1
0 0 41 67
1
end_operator
begin_operator
up f47 f71
1
2308 0
1
0 0 41 68
1
end_operator
begin_operator
up f47 f72
1
2309 0
1
0 0 41 69
1
end_operator
begin_operator
up f47 f73
1
2310 0
1
0 0 41 70
1
end_operator
begin_operator
up f47 f74
1
2311 0
1
0 0 41 71
1
end_operator
begin_operator
up f47 f75
1
2312 0
1
0 0 41 72
1
end_operator
begin_operator
up f47 f76
1
2313 0
1
0 0 41 73
1
end_operator
begin_operator
up f47 f77
1
2314 0
1
0 0 41 74
1
end_operator
begin_operator
up f47 f78
1
2315 0
1
0 0 41 75
1
end_operator
begin_operator
up f47 f79
1
2316 0
1
0 0 41 76
1
end_operator
begin_operator
up f47 f80
1
2317 0
1
0 0 41 78
1
end_operator
begin_operator
up f48 f49
1
2318 0
1
0 0 42 43
1
end_operator
begin_operator
up f48 f50
1
2319 0
1
0 0 42 45
1
end_operator
begin_operator
up f48 f51
1
2320 0
1
0 0 42 46
1
end_operator
begin_operator
up f48 f52
1
2321 0
1
0 0 42 47
1
end_operator
begin_operator
up f48 f53
1
2322 0
1
0 0 42 48
1
end_operator
begin_operator
up f48 f54
1
2323 0
1
0 0 42 49
1
end_operator
begin_operator
up f48 f55
1
2324 0
1
0 0 42 50
1
end_operator
begin_operator
up f48 f56
1
2325 0
1
0 0 42 51
1
end_operator
begin_operator
up f48 f57
1
2326 0
1
0 0 42 52
1
end_operator
begin_operator
up f48 f58
1
2327 0
1
0 0 42 53
1
end_operator
begin_operator
up f48 f59
1
2328 0
1
0 0 42 54
1
end_operator
begin_operator
up f48 f60
1
2329 0
1
0 0 42 56
1
end_operator
begin_operator
up f48 f61
1
2330 0
1
0 0 42 57
1
end_operator
begin_operator
up f48 f62
1
2331 0
1
0 0 42 58
1
end_operator
begin_operator
up f48 f63
1
2332 0
1
0 0 42 59
1
end_operator
begin_operator
up f48 f64
1
2333 0
1
0 0 42 60
1
end_operator
begin_operator
up f48 f65
1
2334 0
1
0 0 42 61
1
end_operator
begin_operator
up f48 f66
1
2335 0
1
0 0 42 62
1
end_operator
begin_operator
up f48 f67
1
2336 0
1
0 0 42 63
1
end_operator
begin_operator
up f48 f68
1
2337 0
1
0 0 42 64
1
end_operator
begin_operator
up f48 f69
1
2338 0
1
0 0 42 65
1
end_operator
begin_operator
up f48 f70
1
2339 0
1
0 0 42 67
1
end_operator
begin_operator
up f48 f71
1
2340 0
1
0 0 42 68
1
end_operator
begin_operator
up f48 f72
1
2341 0
1
0 0 42 69
1
end_operator
begin_operator
up f48 f73
1
2342 0
1
0 0 42 70
1
end_operator
begin_operator
up f48 f74
1
2343 0
1
0 0 42 71
1
end_operator
begin_operator
up f48 f75
1
2344 0
1
0 0 42 72
1
end_operator
begin_operator
up f48 f76
1
2345 0
1
0 0 42 73
1
end_operator
begin_operator
up f48 f77
1
2346 0
1
0 0 42 74
1
end_operator
begin_operator
up f48 f78
1
2347 0
1
0 0 42 75
1
end_operator
begin_operator
up f48 f79
1
2348 0
1
0 0 42 76
1
end_operator
begin_operator
up f48 f80
1
2349 0
1
0 0 42 78
1
end_operator
begin_operator
up f49 f50
1
2350 0
1
0 0 43 45
1
end_operator
begin_operator
up f49 f51
1
2351 0
1
0 0 43 46
1
end_operator
begin_operator
up f49 f52
1
2352 0
1
0 0 43 47
1
end_operator
begin_operator
up f49 f53
1
2353 0
1
0 0 43 48
1
end_operator
begin_operator
up f49 f54
1
2354 0
1
0 0 43 49
1
end_operator
begin_operator
up f49 f55
1
2355 0
1
0 0 43 50
1
end_operator
begin_operator
up f49 f56
1
2356 0
1
0 0 43 51
1
end_operator
begin_operator
up f49 f57
1
2357 0
1
0 0 43 52
1
end_operator
begin_operator
up f49 f58
1
2358 0
1
0 0 43 53
1
end_operator
begin_operator
up f49 f59
1
2359 0
1
0 0 43 54
1
end_operator
begin_operator
up f49 f60
1
2360 0
1
0 0 43 56
1
end_operator
begin_operator
up f49 f61
1
2361 0
1
0 0 43 57
1
end_operator
begin_operator
up f49 f62
1
2362 0
1
0 0 43 58
1
end_operator
begin_operator
up f49 f63
1
2363 0
1
0 0 43 59
1
end_operator
begin_operator
up f49 f64
1
2364 0
1
0 0 43 60
1
end_operator
begin_operator
up f49 f65
1
2365 0
1
0 0 43 61
1
end_operator
begin_operator
up f49 f66
1
2366 0
1
0 0 43 62
1
end_operator
begin_operator
up f49 f67
1
2367 0
1
0 0 43 63
1
end_operator
begin_operator
up f49 f68
1
2368 0
1
0 0 43 64
1
end_operator
begin_operator
up f49 f69
1
2369 0
1
0 0 43 65
1
end_operator
begin_operator
up f49 f70
1
2370 0
1
0 0 43 67
1
end_operator
begin_operator
up f49 f71
1
2371 0
1
0 0 43 68
1
end_operator
begin_operator
up f49 f72
1
2372 0
1
0 0 43 69
1
end_operator
begin_operator
up f49 f73
1
2373 0
1
0 0 43 70
1
end_operator
begin_operator
up f49 f74
1
2374 0
1
0 0 43 71
1
end_operator
begin_operator
up f49 f75
1
2375 0
1
0 0 43 72
1
end_operator
begin_operator
up f49 f76
1
2376 0
1
0 0 43 73
1
end_operator
begin_operator
up f49 f77
1
2377 0
1
0 0 43 74
1
end_operator
begin_operator
up f49 f78
1
2378 0
1
0 0 43 75
1
end_operator
begin_operator
up f49 f79
1
2379 0
1
0 0 43 76
1
end_operator
begin_operator
up f49 f80
1
2380 0
1
0 0 43 78
1
end_operator
begin_operator
up f5 f10
1
2381 0
1
0 0 44 1
1
end_operator
begin_operator
up f5 f11
1
2382 0
1
0 0 44 2
1
end_operator
begin_operator
up f5 f12
1
2383 0
1
0 0 44 3
1
end_operator
begin_operator
up f5 f13
1
2384 0
1
0 0 44 4
1
end_operator
begin_operator
up f5 f14
1
2385 0
1
0 0 44 5
1
end_operator
begin_operator
up f5 f15
1
2386 0
1
0 0 44 6
1
end_operator
begin_operator
up f5 f16
1
2387 0
1
0 0 44 7
1
end_operator
begin_operator
up f5 f17
1
2388 0
1
0 0 44 8
1
end_operator
begin_operator
up f5 f18
1
2389 0
1
0 0 44 9
1
end_operator
begin_operator
up f5 f19
1
2390 0
1
0 0 44 10
1
end_operator
begin_operator
up f5 f20
1
2391 0
1
0 0 44 12
1
end_operator
begin_operator
up f5 f21
1
2392 0
1
0 0 44 13
1
end_operator
begin_operator
up f5 f22
1
2393 0
1
0 0 44 14
1
end_operator
begin_operator
up f5 f23
1
2394 0
1
0 0 44 15
1
end_operator
begin_operator
up f5 f24
1
2395 0
1
0 0 44 16
1
end_operator
begin_operator
up f5 f25
1
2396 0
1
0 0 44 17
1
end_operator
begin_operator
up f5 f26
1
2397 0
1
0 0 44 18
1
end_operator
begin_operator
up f5 f27
1
2398 0
1
0 0 44 19
1
end_operator
begin_operator
up f5 f28
1
2399 0
1
0 0 44 20
1
end_operator
begin_operator
up f5 f29
1
2400 0
1
0 0 44 21
1
end_operator
begin_operator
up f5 f30
1
2401 0
1
0 0 44 23
1
end_operator
begin_operator
up f5 f31
1
2402 0
1
0 0 44 24
1
end_operator
begin_operator
up f5 f32
1
2403 0
1
0 0 44 25
1
end_operator
begin_operator
up f5 f33
1
2404 0
1
0 0 44 26
1
end_operator
begin_operator
up f5 f34
1
2405 0
1
0 0 44 27
1
end_operator
begin_operator
up f5 f35
1
2406 0
1
0 0 44 28
1
end_operator
begin_operator
up f5 f36
1
2407 0
1
0 0 44 29
1
end_operator
begin_operator
up f5 f37
1
2408 0
1
0 0 44 30
1
end_operator
begin_operator
up f5 f38
1
2409 0
1
0 0 44 31
1
end_operator
begin_operator
up f5 f39
1
2410 0
1
0 0 44 32
1
end_operator
begin_operator
up f5 f40
1
2411 0
1
0 0 44 34
1
end_operator
begin_operator
up f5 f41
1
2412 0
1
0 0 44 35
1
end_operator
begin_operator
up f5 f42
1
2413 0
1
0 0 44 36
1
end_operator
begin_operator
up f5 f43
1
2414 0
1
0 0 44 37
1
end_operator
begin_operator
up f5 f44
1
2415 0
1
0 0 44 38
1
end_operator
begin_operator
up f5 f45
1
2416 0
1
0 0 44 39
1
end_operator
begin_operator
up f5 f46
1
2417 0
1
0 0 44 40
1
end_operator
begin_operator
up f5 f47
1
2418 0
1
0 0 44 41
1
end_operator
begin_operator
up f5 f48
1
2419 0
1
0 0 44 42
1
end_operator
begin_operator
up f5 f49
1
2420 0
1
0 0 44 43
1
end_operator
begin_operator
up f5 f50
1
2421 0
1
0 0 44 45
1
end_operator
begin_operator
up f5 f51
1
2422 0
1
0 0 44 46
1
end_operator
begin_operator
up f5 f52
1
2423 0
1
0 0 44 47
1
end_operator
begin_operator
up f5 f53
1
2424 0
1
0 0 44 48
1
end_operator
begin_operator
up f5 f54
1
2425 0
1
0 0 44 49
1
end_operator
begin_operator
up f5 f55
1
2426 0
1
0 0 44 50
1
end_operator
begin_operator
up f5 f56
1
2427 0
1
0 0 44 51
1
end_operator
begin_operator
up f5 f57
1
2428 0
1
0 0 44 52
1
end_operator
begin_operator
up f5 f58
1
2429 0
1
0 0 44 53
1
end_operator
begin_operator
up f5 f59
1
2430 0
1
0 0 44 54
1
end_operator
begin_operator
up f5 f6
1
2431 0
1
0 0 44 55
1
end_operator
begin_operator
up f5 f60
1
2432 0
1
0 0 44 56
1
end_operator
begin_operator
up f5 f61
1
2433 0
1
0 0 44 57
1
end_operator
begin_operator
up f5 f62
1
2434 0
1
0 0 44 58
1
end_operator
begin_operator
up f5 f63
1
2435 0
1
0 0 44 59
1
end_operator
begin_operator
up f5 f64
1
2436 0
1
0 0 44 60
1
end_operator
begin_operator
up f5 f65
1
2437 0
1
0 0 44 61
1
end_operator
begin_operator
up f5 f66
1
2438 0
1
0 0 44 62
1
end_operator
begin_operator
up f5 f67
1
2439 0
1
0 0 44 63
1
end_operator
begin_operator
up f5 f68
1
2440 0
1
0 0 44 64
1
end_operator
begin_operator
up f5 f69
1
2441 0
1
0 0 44 65
1
end_operator
begin_operator
up f5 f7
1
2442 0
1
0 0 44 66
1
end_operator
begin_operator
up f5 f70
1
2443 0
1
0 0 44 67
1
end_operator
begin_operator
up f5 f71
1
2444 0
1
0 0 44 68
1
end_operator
begin_operator
up f5 f72
1
2445 0
1
0 0 44 69
1
end_operator
begin_operator
up f5 f73
1
2446 0
1
0 0 44 70
1
end_operator
begin_operator
up f5 f74
1
2447 0
1
0 0 44 71
1
end_operator
begin_operator
up f5 f75
1
2448 0
1
0 0 44 72
1
end_operator
begin_operator
up f5 f76
1
2449 0
1
0 0 44 73
1
end_operator
begin_operator
up f5 f77
1
2450 0
1
0 0 44 74
1
end_operator
begin_operator
up f5 f78
1
2451 0
1
0 0 44 75
1
end_operator
begin_operator
up f5 f79
1
2452 0
1
0 0 44 76
1
end_operator
begin_operator
up f5 f8
1
2453 0
1
0 0 44 77
1
end_operator
begin_operator
up f5 f80
1
2454 0
1
0 0 44 78
1
end_operator
begin_operator
up f5 f9
1
2455 0
1
0 0 44 79
1
end_operator
begin_operator
up f50 f51
1
2456 0
1
0 0 45 46
1
end_operator
begin_operator
up f50 f52
1
2457 0
1
0 0 45 47
1
end_operator
begin_operator
up f50 f53
1
2458 0
1
0 0 45 48
1
end_operator
begin_operator
up f50 f54
1
2459 0
1
0 0 45 49
1
end_operator
begin_operator
up f50 f55
1
2460 0
1
0 0 45 50
1
end_operator
begin_operator
up f50 f56
1
2461 0
1
0 0 45 51
1
end_operator
begin_operator
up f50 f57
1
2462 0
1
0 0 45 52
1
end_operator
begin_operator
up f50 f58
1
2463 0
1
0 0 45 53
1
end_operator
begin_operator
up f50 f59
1
2464 0
1
0 0 45 54
1
end_operator
begin_operator
up f50 f60
1
2465 0
1
0 0 45 56
1
end_operator
begin_operator
up f50 f61
1
2466 0
1
0 0 45 57
1
end_operator
begin_operator
up f50 f62
1
2467 0
1
0 0 45 58
1
end_operator
begin_operator
up f50 f63
1
2468 0
1
0 0 45 59
1
end_operator
begin_operator
up f50 f64
1
2469 0
1
0 0 45 60
1
end_operator
begin_operator
up f50 f65
1
2470 0
1
0 0 45 61
1
end_operator
begin_operator
up f50 f66
1
2471 0
1
0 0 45 62
1
end_operator
begin_operator
up f50 f67
1
2472 0
1
0 0 45 63
1
end_operator
begin_operator
up f50 f68
1
2473 0
1
0 0 45 64
1
end_operator
begin_operator
up f50 f69
1
2474 0
1
0 0 45 65
1
end_operator
begin_operator
up f50 f70
1
2475 0
1
0 0 45 67
1
end_operator
begin_operator
up f50 f71
1
2476 0
1
0 0 45 68
1
end_operator
begin_operator
up f50 f72
1
2477 0
1
0 0 45 69
1
end_operator
begin_operator
up f50 f73
1
2478 0
1
0 0 45 70
1
end_operator
begin_operator
up f50 f74
1
2479 0
1
0 0 45 71
1
end_operator
begin_operator
up f50 f75
1
2480 0
1
0 0 45 72
1
end_operator
begin_operator
up f50 f76
1
2481 0
1
0 0 45 73
1
end_operator
begin_operator
up f50 f77
1
2482 0
1
0 0 45 74
1
end_operator
begin_operator
up f50 f78
1
2483 0
1
0 0 45 75
1
end_operator
begin_operator
up f50 f79
1
2484 0
1
0 0 45 76
1
end_operator
begin_operator
up f50 f80
1
2485 0
1
0 0 45 78
1
end_operator
begin_operator
up f51 f52
1
2486 0
1
0 0 46 47
1
end_operator
begin_operator
up f51 f53
1
2487 0
1
0 0 46 48
1
end_operator
begin_operator
up f51 f54
1
2488 0
1
0 0 46 49
1
end_operator
begin_operator
up f51 f55
1
2489 0
1
0 0 46 50
1
end_operator
begin_operator
up f51 f56
1
2490 0
1
0 0 46 51
1
end_operator
begin_operator
up f51 f57
1
2491 0
1
0 0 46 52
1
end_operator
begin_operator
up f51 f58
1
2492 0
1
0 0 46 53
1
end_operator
begin_operator
up f51 f59
1
2493 0
1
0 0 46 54
1
end_operator
begin_operator
up f51 f60
1
2494 0
1
0 0 46 56
1
end_operator
begin_operator
up f51 f61
1
2495 0
1
0 0 46 57
1
end_operator
begin_operator
up f51 f62
1
2496 0
1
0 0 46 58
1
end_operator
begin_operator
up f51 f63
1
2497 0
1
0 0 46 59
1
end_operator
begin_operator
up f51 f64
1
2498 0
1
0 0 46 60
1
end_operator
begin_operator
up f51 f65
1
2499 0
1
0 0 46 61
1
end_operator
begin_operator
up f51 f66
1
2500 0
1
0 0 46 62
1
end_operator
begin_operator
up f51 f67
1
2501 0
1
0 0 46 63
1
end_operator
begin_operator
up f51 f68
1
2502 0
1
0 0 46 64
1
end_operator
begin_operator
up f51 f69
1
2503 0
1
0 0 46 65
1
end_operator
begin_operator
up f51 f70
1
2504 0
1
0 0 46 67
1
end_operator
begin_operator
up f51 f71
1
2505 0
1
0 0 46 68
1
end_operator
begin_operator
up f51 f72
1
2506 0
1
0 0 46 69
1
end_operator
begin_operator
up f51 f73
1
2507 0
1
0 0 46 70
1
end_operator
begin_operator
up f51 f74
1
2508 0
1
0 0 46 71
1
end_operator
begin_operator
up f51 f75
1
2509 0
1
0 0 46 72
1
end_operator
begin_operator
up f51 f76
1
2510 0
1
0 0 46 73
1
end_operator
begin_operator
up f51 f77
1
2511 0
1
0 0 46 74
1
end_operator
begin_operator
up f51 f78
1
2512 0
1
0 0 46 75
1
end_operator
begin_operator
up f51 f79
1
2513 0
1
0 0 46 76
1
end_operator
begin_operator
up f51 f80
1
2514 0
1
0 0 46 78
1
end_operator
begin_operator
up f52 f53
1
2515 0
1
0 0 47 48
1
end_operator
begin_operator
up f52 f54
1
2516 0
1
0 0 47 49
1
end_operator
begin_operator
up f52 f55
1
2517 0
1
0 0 47 50
1
end_operator
begin_operator
up f52 f56
1
2518 0
1
0 0 47 51
1
end_operator
begin_operator
up f52 f57
1
2519 0
1
0 0 47 52
1
end_operator
begin_operator
up f52 f58
1
2520 0
1
0 0 47 53
1
end_operator
begin_operator
up f52 f59
1
2521 0
1
0 0 47 54
1
end_operator
begin_operator
up f52 f60
1
2522 0
1
0 0 47 56
1
end_operator
begin_operator
up f52 f61
1
2523 0
1
0 0 47 57
1
end_operator
begin_operator
up f52 f62
1
2524 0
1
0 0 47 58
1
end_operator
begin_operator
up f52 f63
1
2525 0
1
0 0 47 59
1
end_operator
begin_operator
up f52 f64
1
2526 0
1
0 0 47 60
1
end_operator
begin_operator
up f52 f65
1
2527 0
1
0 0 47 61
1
end_operator
begin_operator
up f52 f66
1
2528 0
1
0 0 47 62
1
end_operator
begin_operator
up f52 f67
1
2529 0
1
0 0 47 63
1
end_operator
begin_operator
up f52 f68
1
2530 0
1
0 0 47 64
1
end_operator
begin_operator
up f52 f69
1
2531 0
1
0 0 47 65
1
end_operator
begin_operator
up f52 f70
1
2532 0
1
0 0 47 67
1
end_operator
begin_operator
up f52 f71
1
2533 0
1
0 0 47 68
1
end_operator
begin_operator
up f52 f72
1
2534 0
1
0 0 47 69
1
end_operator
begin_operator
up f52 f73
1
2535 0
1
0 0 47 70
1
end_operator
begin_operator
up f52 f74
1
2536 0
1
0 0 47 71
1
end_operator
begin_operator
up f52 f75
1
2537 0
1
0 0 47 72
1
end_operator
begin_operator
up f52 f76
1
2538 0
1
0 0 47 73
1
end_operator
begin_operator
up f52 f77
1
2539 0
1
0 0 47 74
1
end_operator
begin_operator
up f52 f78
1
2540 0
1
0 0 47 75
1
end_operator
begin_operator
up f52 f79
1
2541 0
1
0 0 47 76
1
end_operator
begin_operator
up f52 f80
1
2542 0
1
0 0 47 78
1
end_operator
begin_operator
up f53 f54
1
2543 0
1
0 0 48 49
1
end_operator
begin_operator
up f53 f55
1
2544 0
1
0 0 48 50
1
end_operator
begin_operator
up f53 f56
1
2545 0
1
0 0 48 51
1
end_operator
begin_operator
up f53 f57
1
2546 0
1
0 0 48 52
1
end_operator
begin_operator
up f53 f58
1
2547 0
1
0 0 48 53
1
end_operator
begin_operator
up f53 f59
1
2548 0
1
0 0 48 54
1
end_operator
begin_operator
up f53 f60
1
2549 0
1
0 0 48 56
1
end_operator
begin_operator
up f53 f61
1
2550 0
1
0 0 48 57
1
end_operator
begin_operator
up f53 f62
1
2551 0
1
0 0 48 58
1
end_operator
begin_operator
up f53 f63
1
2552 0
1
0 0 48 59
1
end_operator
begin_operator
up f53 f64
1
2553 0
1
0 0 48 60
1
end_operator
begin_operator
up f53 f65
1
2554 0
1
0 0 48 61
1
end_operator
begin_operator
up f53 f66
1
2555 0
1
0 0 48 62
1
end_operator
begin_operator
up f53 f67
1
2556 0
1
0 0 48 63
1
end_operator
begin_operator
up f53 f68
1
2557 0
1
0 0 48 64
1
end_operator
begin_operator
up f53 f69
1
2558 0
1
0 0 48 65
1
end_operator
begin_operator
up f53 f70
1
2559 0
1
0 0 48 67
1
end_operator
begin_operator
up f53 f71
1
2560 0
1
0 0 48 68
1
end_operator
begin_operator
up f53 f72
1
2561 0
1
0 0 48 69
1
end_operator
begin_operator
up f53 f73
1
2562 0
1
0 0 48 70
1
end_operator
begin_operator
up f53 f74
1
2563 0
1
0 0 48 71
1
end_operator
begin_operator
up f53 f75
1
2564 0
1
0 0 48 72
1
end_operator
begin_operator
up f53 f76
1
2565 0
1
0 0 48 73
1
end_operator
begin_operator
up f53 f77
1
2566 0
1
0 0 48 74
1
end_operator
begin_operator
up f53 f78
1
2567 0
1
0 0 48 75
1
end_operator
begin_operator
up f53 f79
1
2568 0
1
0 0 48 76
1
end_operator
begin_operator
up f53 f80
1
2569 0
1
0 0 48 78
1
end_operator
begin_operator
up f54 f55
1
2570 0
1
0 0 49 50
1
end_operator
begin_operator
up f54 f56
1
2571 0
1
0 0 49 51
1
end_operator
begin_operator
up f54 f57
1
2572 0
1
0 0 49 52
1
end_operator
begin_operator
up f54 f58
1
2573 0
1
0 0 49 53
1
end_operator
begin_operator
up f54 f59
1
2574 0
1
0 0 49 54
1
end_operator
begin_operator
up f54 f60
1
2575 0
1
0 0 49 56
1
end_operator
begin_operator
up f54 f61
1
2576 0
1
0 0 49 57
1
end_operator
begin_operator
up f54 f62
1
2577 0
1
0 0 49 58
1
end_operator
begin_operator
up f54 f63
1
2578 0
1
0 0 49 59
1
end_operator
begin_operator
up f54 f64
1
2579 0
1
0 0 49 60
1
end_operator
begin_operator
up f54 f65
1
2580 0
1
0 0 49 61
1
end_operator
begin_operator
up f54 f66
1
2581 0
1
0 0 49 62
1
end_operator
begin_operator
up f54 f67
1
2582 0
1
0 0 49 63
1
end_operator
begin_operator
up f54 f68
1
2583 0
1
0 0 49 64
1
end_operator
begin_operator
up f54 f69
1
2584 0
1
0 0 49 65
1
end_operator
begin_operator
up f54 f70
1
2585 0
1
0 0 49 67
1
end_operator
begin_operator
up f54 f71
1
2586 0
1
0 0 49 68
1
end_operator
begin_operator
up f54 f72
1
2587 0
1
0 0 49 69
1
end_operator
begin_operator
up f54 f73
1
2588 0
1
0 0 49 70
1
end_operator
begin_operator
up f54 f74
1
2589 0
1
0 0 49 71
1
end_operator
begin_operator
up f54 f75
1
2590 0
1
0 0 49 72
1
end_operator
begin_operator
up f54 f76
1
2591 0
1
0 0 49 73
1
end_operator
begin_operator
up f54 f77
1
2592 0
1
0 0 49 74
1
end_operator
begin_operator
up f54 f78
1
2593 0
1
0 0 49 75
1
end_operator
begin_operator
up f54 f79
1
2594 0
1
0 0 49 76
1
end_operator
begin_operator
up f54 f80
1
2595 0
1
0 0 49 78
1
end_operator
begin_operator
up f55 f56
1
2596 0
1
0 0 50 51
1
end_operator
begin_operator
up f55 f57
1
2597 0
1
0 0 50 52
1
end_operator
begin_operator
up f55 f58
1
2598 0
1
0 0 50 53
1
end_operator
begin_operator
up f55 f59
1
2599 0
1
0 0 50 54
1
end_operator
begin_operator
up f55 f60
1
2600 0
1
0 0 50 56
1
end_operator
begin_operator
up f55 f61
1
2601 0
1
0 0 50 57
1
end_operator
begin_operator
up f55 f62
1
2602 0
1
0 0 50 58
1
end_operator
begin_operator
up f55 f63
1
2603 0
1
0 0 50 59
1
end_operator
begin_operator
up f55 f64
1
2604 0
1
0 0 50 60
1
end_operator
begin_operator
up f55 f65
1
2605 0
1
0 0 50 61
1
end_operator
begin_operator
up f55 f66
1
2606 0
1
0 0 50 62
1
end_operator
begin_operator
up f55 f67
1
2607 0
1
0 0 50 63
1
end_operator
begin_operator
up f55 f68
1
2608 0
1
0 0 50 64
1
end_operator
begin_operator
up f55 f69
1
2609 0
1
0 0 50 65
1
end_operator
begin_operator
up f55 f70
1
2610 0
1
0 0 50 67
1
end_operator
begin_operator
up f55 f71
1
2611 0
1
0 0 50 68
1
end_operator
begin_operator
up f55 f72
1
2612 0
1
0 0 50 69
1
end_operator
begin_operator
up f55 f73
1
2613 0
1
0 0 50 70
1
end_operator
begin_operator
up f55 f74
1
2614 0
1
0 0 50 71
1
end_operator
begin_operator
up f55 f75
1
2615 0
1
0 0 50 72
1
end_operator
begin_operator
up f55 f76
1
2616 0
1
0 0 50 73
1
end_operator
begin_operator
up f55 f77
1
2617 0
1
0 0 50 74
1
end_operator
begin_operator
up f55 f78
1
2618 0
1
0 0 50 75
1
end_operator
begin_operator
up f55 f79
1
2619 0
1
0 0 50 76
1
end_operator
begin_operator
up f55 f80
1
2620 0
1
0 0 50 78
1
end_operator
begin_operator
up f56 f57
1
2621 0
1
0 0 51 52
1
end_operator
begin_operator
up f56 f58
1
2622 0
1
0 0 51 53
1
end_operator
begin_operator
up f56 f59
1
2623 0
1
0 0 51 54
1
end_operator
begin_operator
up f56 f60
1
2624 0
1
0 0 51 56
1
end_operator
begin_operator
up f56 f61
1
2625 0
1
0 0 51 57
1
end_operator
begin_operator
up f56 f62
1
2626 0
1
0 0 51 58
1
end_operator
begin_operator
up f56 f63
1
2627 0
1
0 0 51 59
1
end_operator
begin_operator
up f56 f64
1
2628 0
1
0 0 51 60
1
end_operator
begin_operator
up f56 f65
1
2629 0
1
0 0 51 61
1
end_operator
begin_operator
up f56 f66
1
2630 0
1
0 0 51 62
1
end_operator
begin_operator
up f56 f67
1
2631 0
1
0 0 51 63
1
end_operator
begin_operator
up f56 f68
1
2632 0
1
0 0 51 64
1
end_operator
begin_operator
up f56 f69
1
2633 0
1
0 0 51 65
1
end_operator
begin_operator
up f56 f70
1
2634 0
1
0 0 51 67
1
end_operator
begin_operator
up f56 f71
1
2635 0
1
0 0 51 68
1
end_operator
begin_operator
up f56 f72
1
2636 0
1
0 0 51 69
1
end_operator
begin_operator
up f56 f73
1
2637 0
1
0 0 51 70
1
end_operator
begin_operator
up f56 f74
1
2638 0
1
0 0 51 71
1
end_operator
begin_operator
up f56 f75
1
2639 0
1
0 0 51 72
1
end_operator
begin_operator
up f56 f76
1
2640 0
1
0 0 51 73
1
end_operator
begin_operator
up f56 f77
1
2641 0
1
0 0 51 74
1
end_operator
begin_operator
up f56 f78
1
2642 0
1
0 0 51 75
1
end_operator
begin_operator
up f56 f79
1
2643 0
1
0 0 51 76
1
end_operator
begin_operator
up f56 f80
1
2644 0
1
0 0 51 78
1
end_operator
begin_operator
up f57 f58
1
2645 0
1
0 0 52 53
1
end_operator
begin_operator
up f57 f59
1
2646 0
1
0 0 52 54
1
end_operator
begin_operator
up f57 f60
1
2647 0
1
0 0 52 56
1
end_operator
begin_operator
up f57 f61
1
2648 0
1
0 0 52 57
1
end_operator
begin_operator
up f57 f62
1
2649 0
1
0 0 52 58
1
end_operator
begin_operator
up f57 f63
1
2650 0
1
0 0 52 59
1
end_operator
begin_operator
up f57 f64
1
2651 0
1
0 0 52 60
1
end_operator
begin_operator
up f57 f65
1
2652 0
1
0 0 52 61
1
end_operator
begin_operator
up f57 f66
1
2653 0
1
0 0 52 62
1
end_operator
begin_operator
up f57 f67
1
2654 0
1
0 0 52 63
1
end_operator
begin_operator
up f57 f68
1
2655 0
1
0 0 52 64
1
end_operator
begin_operator
up f57 f69
1
2656 0
1
0 0 52 65
1
end_operator
begin_operator
up f57 f70
1
2657 0
1
0 0 52 67
1
end_operator
begin_operator
up f57 f71
1
2658 0
1
0 0 52 68
1
end_operator
begin_operator
up f57 f72
1
2659 0
1
0 0 52 69
1
end_operator
begin_operator
up f57 f73
1
2660 0
1
0 0 52 70
1
end_operator
begin_operator
up f57 f74
1
2661 0
1
0 0 52 71
1
end_operator
begin_operator
up f57 f75
1
2662 0
1
0 0 52 72
1
end_operator
begin_operator
up f57 f76
1
2663 0
1
0 0 52 73
1
end_operator
begin_operator
up f57 f77
1
2664 0
1
0 0 52 74
1
end_operator
begin_operator
up f57 f78
1
2665 0
1
0 0 52 75
1
end_operator
begin_operator
up f57 f79
1
2666 0
1
0 0 52 76
1
end_operator
begin_operator
up f57 f80
1
2667 0
1
0 0 52 78
1
end_operator
begin_operator
up f58 f59
1
2668 0
1
0 0 53 54
1
end_operator
begin_operator
up f58 f60
1
2669 0
1
0 0 53 56
1
end_operator
begin_operator
up f58 f61
1
2670 0
1
0 0 53 57
1
end_operator
begin_operator
up f58 f62
1
2671 0
1
0 0 53 58
1
end_operator
begin_operator
up f58 f63
1
2672 0
1
0 0 53 59
1
end_operator
begin_operator
up f58 f64
1
2673 0
1
0 0 53 60
1
end_operator
begin_operator
up f58 f65
1
2674 0
1
0 0 53 61
1
end_operator
begin_operator
up f58 f66
1
2675 0
1
0 0 53 62
1
end_operator
begin_operator
up f58 f67
1
2676 0
1
0 0 53 63
1
end_operator
begin_operator
up f58 f68
1
2677 0
1
0 0 53 64
1
end_operator
begin_operator
up f58 f69
1
2678 0
1
0 0 53 65
1
end_operator
begin_operator
up f58 f70
1
2679 0
1
0 0 53 67
1
end_operator
begin_operator
up f58 f71
1
2680 0
1
0 0 53 68
1
end_operator
begin_operator
up f58 f72
1
2681 0
1
0 0 53 69
1
end_operator
begin_operator
up f58 f73
1
2682 0
1
0 0 53 70
1
end_operator
begin_operator
up f58 f74
1
2683 0
1
0 0 53 71
1
end_operator
begin_operator
up f58 f75
1
2684 0
1
0 0 53 72
1
end_operator
begin_operator
up f58 f76
1
2685 0
1
0 0 53 73
1
end_operator
begin_operator
up f58 f77
1
2686 0
1
0 0 53 74
1
end_operator
begin_operator
up f58 f78
1
2687 0
1
0 0 53 75
1
end_operator
begin_operator
up f58 f79
1
2688 0
1
0 0 53 76
1
end_operator
begin_operator
up f58 f80
1
2689 0
1
0 0 53 78
1
end_operator
begin_operator
up f59 f60
1
2690 0
1
0 0 54 56
1
end_operator
begin_operator
up f59 f61
1
2691 0
1
0 0 54 57
1
end_operator
begin_operator
up f59 f62
1
2692 0
1
0 0 54 58
1
end_operator
begin_operator
up f59 f63
1
2693 0
1
0 0 54 59
1
end_operator
begin_operator
up f59 f64
1
2694 0
1
0 0 54 60
1
end_operator
begin_operator
up f59 f65
1
2695 0
1
0 0 54 61
1
end_operator
begin_operator
up f59 f66
1
2696 0
1
0 0 54 62
1
end_operator
begin_operator
up f59 f67
1
2697 0
1
0 0 54 63
1
end_operator
begin_operator
up f59 f68
1
2698 0
1
0 0 54 64
1
end_operator
begin_operator
up f59 f69
1
2699 0
1
0 0 54 65
1
end_operator
begin_operator
up f59 f70
1
2700 0
1
0 0 54 67
1
end_operator
begin_operator
up f59 f71
1
2701 0
1
0 0 54 68
1
end_operator
begin_operator
up f59 f72
1
2702 0
1
0 0 54 69
1
end_operator
begin_operator
up f59 f73
1
2703 0
1
0 0 54 70
1
end_operator
begin_operator
up f59 f74
1
2704 0
1
0 0 54 71
1
end_operator
begin_operator
up f59 f75
1
2705 0
1
0 0 54 72
1
end_operator
begin_operator
up f59 f76
1
2706 0
1
0 0 54 73
1
end_operator
begin_operator
up f59 f77
1
2707 0
1
0 0 54 74
1
end_operator
begin_operator
up f59 f78
1
2708 0
1
0 0 54 75
1
end_operator
begin_operator
up f59 f79
1
2709 0
1
0 0 54 76
1
end_operator
begin_operator
up f59 f80
1
2710 0
1
0 0 54 78
1
end_operator
begin_operator
up f6 f10
1
2711 0
1
0 0 55 1
1
end_operator
begin_operator
up f6 f11
1
2712 0
1
0 0 55 2
1
end_operator
begin_operator
up f6 f12
1
2713 0
1
0 0 55 3
1
end_operator
begin_operator
up f6 f13
1
2714 0
1
0 0 55 4
1
end_operator
begin_operator
up f6 f14
1
2715 0
1
0 0 55 5
1
end_operator
begin_operator
up f6 f15
1
2716 0
1
0 0 55 6
1
end_operator
begin_operator
up f6 f16
1
2717 0
1
0 0 55 7
1
end_operator
begin_operator
up f6 f17
1
2718 0
1
0 0 55 8
1
end_operator
begin_operator
up f6 f18
1
2719 0
1
0 0 55 9
1
end_operator
begin_operator
up f6 f19
1
2720 0
1
0 0 55 10
1
end_operator
begin_operator
up f6 f20
1
2721 0
1
0 0 55 12
1
end_operator
begin_operator
up f6 f21
1
2722 0
1
0 0 55 13
1
end_operator
begin_operator
up f6 f22
1
2723 0
1
0 0 55 14
1
end_operator
begin_operator
up f6 f23
1
2724 0
1
0 0 55 15
1
end_operator
begin_operator
up f6 f24
1
2725 0
1
0 0 55 16
1
end_operator
begin_operator
up f6 f25
1
2726 0
1
0 0 55 17
1
end_operator
begin_operator
up f6 f26
1
2727 0
1
0 0 55 18
1
end_operator
begin_operator
up f6 f27
1
2728 0
1
0 0 55 19
1
end_operator
begin_operator
up f6 f28
1
2729 0
1
0 0 55 20
1
end_operator
begin_operator
up f6 f29
1
2730 0
1
0 0 55 21
1
end_operator
begin_operator
up f6 f30
1
2731 0
1
0 0 55 23
1
end_operator
begin_operator
up f6 f31
1
2732 0
1
0 0 55 24
1
end_operator
begin_operator
up f6 f32
1
2733 0
1
0 0 55 25
1
end_operator
begin_operator
up f6 f33
1
2734 0
1
0 0 55 26
1
end_operator
begin_operator
up f6 f34
1
2735 0
1
0 0 55 27
1
end_operator
begin_operator
up f6 f35
1
2736 0
1
0 0 55 28
1
end_operator
begin_operator
up f6 f36
1
2737 0
1
0 0 55 29
1
end_operator
begin_operator
up f6 f37
1
2738 0
1
0 0 55 30
1
end_operator
begin_operator
up f6 f38
1
2739 0
1
0 0 55 31
1
end_operator
begin_operator
up f6 f39
1
2740 0
1
0 0 55 32
1
end_operator
begin_operator
up f6 f40
1
2741 0
1
0 0 55 34
1
end_operator
begin_operator
up f6 f41
1
2742 0
1
0 0 55 35
1
end_operator
begin_operator
up f6 f42
1
2743 0
1
0 0 55 36
1
end_operator
begin_operator
up f6 f43
1
2744 0
1
0 0 55 37
1
end_operator
begin_operator
up f6 f44
1
2745 0
1
0 0 55 38
1
end_operator
begin_operator
up f6 f45
1
2746 0
1
0 0 55 39
1
end_operator
begin_operator
up f6 f46
1
2747 0
1
0 0 55 40
1
end_operator
begin_operator
up f6 f47
1
2748 0
1
0 0 55 41
1
end_operator
begin_operator
up f6 f48
1
2749 0
1
0 0 55 42
1
end_operator
begin_operator
up f6 f49
1
2750 0
1
0 0 55 43
1
end_operator
begin_operator
up f6 f50
1
2751 0
1
0 0 55 45
1
end_operator
begin_operator
up f6 f51
1
2752 0
1
0 0 55 46
1
end_operator
begin_operator
up f6 f52
1
2753 0
1
0 0 55 47
1
end_operator
begin_operator
up f6 f53
1
2754 0
1
0 0 55 48
1
end_operator
begin_operator
up f6 f54
1
2755 0
1
0 0 55 49
1
end_operator
begin_operator
up f6 f55
1
2756 0
1
0 0 55 50
1
end_operator
begin_operator
up f6 f56
1
2757 0
1
0 0 55 51
1
end_operator
begin_operator
up f6 f57
1
2758 0
1
0 0 55 52
1
end_operator
begin_operator
up f6 f58
1
2759 0
1
0 0 55 53
1
end_operator
begin_operator
up f6 f59
1
2760 0
1
0 0 55 54
1
end_operator
begin_operator
up f6 f60
1
2761 0
1
0 0 55 56
1
end_operator
begin_operator
up f6 f61
1
2762 0
1
0 0 55 57
1
end_operator
begin_operator
up f6 f62
1
2763 0
1
0 0 55 58
1
end_operator
begin_operator
up f6 f63
1
2764 0
1
0 0 55 59
1
end_operator
begin_operator
up f6 f64
1
2765 0
1
0 0 55 60
1
end_operator
begin_operator
up f6 f65
1
2766 0
1
0 0 55 61
1
end_operator
begin_operator
up f6 f66
1
2767 0
1
0 0 55 62
1
end_operator
begin_operator
up f6 f67
1
2768 0
1
0 0 55 63
1
end_operator
begin_operator
up f6 f68
1
2769 0
1
0 0 55 64
1
end_operator
begin_operator
up f6 f69
1
2770 0
1
0 0 55 65
1
end_operator
begin_operator
up f6 f7
1
2771 0
1
0 0 55 66
1
end_operator
begin_operator
up f6 f70
1
2772 0
1
0 0 55 67
1
end_operator
begin_operator
up f6 f71
1
2773 0
1
0 0 55 68
1
end_operator
begin_operator
up f6 f72
1
2774 0
1
0 0 55 69
1
end_operator
begin_operator
up f6 f73
1
2775 0
1
0 0 55 70
1
end_operator
begin_operator
up f6 f74
1
2776 0
1
0 0 55 71
1
end_operator
begin_operator
up f6 f75
1
2777 0
1
0 0 55 72
1
end_operator
begin_operator
up f6 f76
1
2778 0
1
0 0 55 73
1
end_operator
begin_operator
up f6 f77
1
2779 0
1
0 0 55 74
1
end_operator
begin_operator
up f6 f78
1
2780 0
1
0 0 55 75
1
end_operator
begin_operator
up f6 f79
1
2781 0
1
0 0 55 76
1
end_operator
begin_operator
up f6 f8
1
2782 0
1
0 0 55 77
1
end_operator
begin_operator
up f6 f80
1
2783 0
1
0 0 55 78
1
end_operator
begin_operator
up f6 f9
1
2784 0
1
0 0 55 79
1
end_operator
begin_operator
up f60 f61
1
2785 0
1
0 0 56 57
1
end_operator
begin_operator
up f60 f62
1
2786 0
1
0 0 56 58
1
end_operator
begin_operator
up f60 f63
1
2787 0
1
0 0 56 59
1
end_operator
begin_operator
up f60 f64
1
2788 0
1
0 0 56 60
1
end_operator
begin_operator
up f60 f65
1
2789 0
1
0 0 56 61
1
end_operator
begin_operator
up f60 f66
1
2790 0
1
0 0 56 62
1
end_operator
begin_operator
up f60 f67
1
2791 0
1
0 0 56 63
1
end_operator
begin_operator
up f60 f68
1
2792 0
1
0 0 56 64
1
end_operator
begin_operator
up f60 f69
1
2793 0
1
0 0 56 65
1
end_operator
begin_operator
up f60 f70
1
2794 0
1
0 0 56 67
1
end_operator
begin_operator
up f60 f71
1
2795 0
1
0 0 56 68
1
end_operator
begin_operator
up f60 f72
1
2796 0
1
0 0 56 69
1
end_operator
begin_operator
up f60 f73
1
2797 0
1
0 0 56 70
1
end_operator
begin_operator
up f60 f74
1
2798 0
1
0 0 56 71
1
end_operator
begin_operator
up f60 f75
1
2799 0
1
0 0 56 72
1
end_operator
begin_operator
up f60 f76
1
2800 0
1
0 0 56 73
1
end_operator
begin_operator
up f60 f77
1
2801 0
1
0 0 56 74
1
end_operator
begin_operator
up f60 f78
1
2802 0
1
0 0 56 75
1
end_operator
begin_operator
up f60 f79
1
2803 0
1
0 0 56 76
1
end_operator
begin_operator
up f60 f80
1
2804 0
1
0 0 56 78
1
end_operator
begin_operator
up f61 f62
1
2805 0
1
0 0 57 58
1
end_operator
begin_operator
up f61 f63
1
2806 0
1
0 0 57 59
1
end_operator
begin_operator
up f61 f64
1
2807 0
1
0 0 57 60
1
end_operator
begin_operator
up f61 f65
1
2808 0
1
0 0 57 61
1
end_operator
begin_operator
up f61 f66
1
2809 0
1
0 0 57 62
1
end_operator
begin_operator
up f61 f67
1
2810 0
1
0 0 57 63
1
end_operator
begin_operator
up f61 f68
1
2811 0
1
0 0 57 64
1
end_operator
begin_operator
up f61 f69
1
2812 0
1
0 0 57 65
1
end_operator
begin_operator
up f61 f70
1
2813 0
1
0 0 57 67
1
end_operator
begin_operator
up f61 f71
1
2814 0
1
0 0 57 68
1
end_operator
begin_operator
up f61 f72
1
2815 0
1
0 0 57 69
1
end_operator
begin_operator
up f61 f73
1
2816 0
1
0 0 57 70
1
end_operator
begin_operator
up f61 f74
1
2817 0
1
0 0 57 71
1
end_operator
begin_operator
up f61 f75
1
2818 0
1
0 0 57 72
1
end_operator
begin_operator
up f61 f76
1
2819 0
1
0 0 57 73
1
end_operator
begin_operator
up f61 f77
1
2820 0
1
0 0 57 74
1
end_operator
begin_operator
up f61 f78
1
2821 0
1
0 0 57 75
1
end_operator
begin_operator
up f61 f79
1
2822 0
1
0 0 57 76
1
end_operator
begin_operator
up f61 f80
1
2823 0
1
0 0 57 78
1
end_operator
begin_operator
up f62 f63
1
2824 0
1
0 0 58 59
1
end_operator
begin_operator
up f62 f64
1
2825 0
1
0 0 58 60
1
end_operator
begin_operator
up f62 f65
1
2826 0
1
0 0 58 61
1
end_operator
begin_operator
up f62 f66
1
2827 0
1
0 0 58 62
1
end_operator
begin_operator
up f62 f67
1
2828 0
1
0 0 58 63
1
end_operator
begin_operator
up f62 f68
1
2829 0
1
0 0 58 64
1
end_operator
begin_operator
up f62 f69
1
2830 0
1
0 0 58 65
1
end_operator
begin_operator
up f62 f70
1
2831 0
1
0 0 58 67
1
end_operator
begin_operator
up f62 f71
1
2832 0
1
0 0 58 68
1
end_operator
begin_operator
up f62 f72
1
2833 0
1
0 0 58 69
1
end_operator
begin_operator
up f62 f73
1
2834 0
1
0 0 58 70
1
end_operator
begin_operator
up f62 f74
1
2835 0
1
0 0 58 71
1
end_operator
begin_operator
up f62 f75
1
2836 0
1
0 0 58 72
1
end_operator
begin_operator
up f62 f76
1
2837 0
1
0 0 58 73
1
end_operator
begin_operator
up f62 f77
1
2838 0
1
0 0 58 74
1
end_operator
begin_operator
up f62 f78
1
2839 0
1
0 0 58 75
1
end_operator
begin_operator
up f62 f79
1
2840 0
1
0 0 58 76
1
end_operator
begin_operator
up f62 f80
1
2841 0
1
0 0 58 78
1
end_operator
begin_operator
up f63 f64
1
2842 0
1
0 0 59 60
1
end_operator
begin_operator
up f63 f65
1
2843 0
1
0 0 59 61
1
end_operator
begin_operator
up f63 f66
1
2844 0
1
0 0 59 62
1
end_operator
begin_operator
up f63 f67
1
2845 0
1
0 0 59 63
1
end_operator
begin_operator
up f63 f68
1
2846 0
1
0 0 59 64
1
end_operator
begin_operator
up f63 f69
1
2847 0
1
0 0 59 65
1
end_operator
begin_operator
up f63 f70
1
2848 0
1
0 0 59 67
1
end_operator
begin_operator
up f63 f71
1
2849 0
1
0 0 59 68
1
end_operator
begin_operator
up f63 f72
1
2850 0
1
0 0 59 69
1
end_operator
begin_operator
up f63 f73
1
2851 0
1
0 0 59 70
1
end_operator
begin_operator
up f63 f74
1
2852 0
1
0 0 59 71
1
end_operator
begin_operator
up f63 f75
1
2853 0
1
0 0 59 72
1
end_operator
begin_operator
up f63 f76
1
2854 0
1
0 0 59 73
1
end_operator
begin_operator
up f63 f77
1
2855 0
1
0 0 59 74
1
end_operator
begin_operator
up f63 f78
1
2856 0
1
0 0 59 75
1
end_operator
begin_operator
up f63 f79
1
2857 0
1
0 0 59 76
1
end_operator
begin_operator
up f63 f80
1
2858 0
1
0 0 59 78
1
end_operator
begin_operator
up f64 f65
1
2859 0
1
0 0 60 61
1
end_operator
begin_operator
up f64 f66
1
2860 0
1
0 0 60 62
1
end_operator
begin_operator
up f64 f67
1
2861 0
1
0 0 60 63
1
end_operator
begin_operator
up f64 f68
1
2862 0
1
0 0 60 64
1
end_operator
begin_operator
up f64 f69
1
2863 0
1
0 0 60 65
1
end_operator
begin_operator
up f64 f70
1
2864 0
1
0 0 60 67
1
end_operator
begin_operator
up f64 f71
1
2865 0
1
0 0 60 68
1
end_operator
begin_operator
up f64 f72
1
2866 0
1
0 0 60 69
1
end_operator
begin_operator
up f64 f73
1
2867 0
1
0 0 60 70
1
end_operator
begin_operator
up f64 f74
1
2868 0
1
0 0 60 71
1
end_operator
begin_operator
up f64 f75
1
2869 0
1
0 0 60 72
1
end_operator
begin_operator
up f64 f76
1
2870 0
1
0 0 60 73
1
end_operator
begin_operator
up f64 f77
1
2871 0
1
0 0 60 74
1
end_operator
begin_operator
up f64 f78
1
2872 0
1
0 0 60 75
1
end_operator
begin_operator
up f64 f79
1
2873 0
1
0 0 60 76
1
end_operator
begin_operator
up f64 f80
1
2874 0
1
0 0 60 78
1
end_operator
begin_operator
up f65 f66
1
2875 0
1
0 0 61 62
1
end_operator
begin_operator
up f65 f67
1
2876 0
1
0 0 61 63
1
end_operator
begin_operator
up f65 f68
1
2877 0
1
0 0 61 64
1
end_operator
begin_operator
up f65 f69
1
2878 0
1
0 0 61 65
1
end_operator
begin_operator
up f65 f70
1
2879 0
1
0 0 61 67
1
end_operator
begin_operator
up f65 f71
1
2880 0
1
0 0 61 68
1
end_operator
begin_operator
up f65 f72
1
2881 0
1
0 0 61 69
1
end_operator
begin_operator
up f65 f73
1
2882 0
1
0 0 61 70
1
end_operator
begin_operator
up f65 f74
1
2883 0
1
0 0 61 71
1
end_operator
begin_operator
up f65 f75
1
2884 0
1
0 0 61 72
1
end_operator
begin_operator
up f65 f76
1
2885 0
1
0 0 61 73
1
end_operator
begin_operator
up f65 f77
1
2886 0
1
0 0 61 74
1
end_operator
begin_operator
up f65 f78
1
2887 0
1
0 0 61 75
1
end_operator
begin_operator
up f65 f79
1
2888 0
1
0 0 61 76
1
end_operator
begin_operator
up f65 f80
1
2889 0
1
0 0 61 78
1
end_operator
begin_operator
up f66 f67
1
2890 0
1
0 0 62 63
1
end_operator
begin_operator
up f66 f68
1
2891 0
1
0 0 62 64
1
end_operator
begin_operator
up f66 f69
1
2892 0
1
0 0 62 65
1
end_operator
begin_operator
up f66 f70
1
2893 0
1
0 0 62 67
1
end_operator
begin_operator
up f66 f71
1
2894 0
1
0 0 62 68
1
end_operator
begin_operator
up f66 f72
1
2895 0
1
0 0 62 69
1
end_operator
begin_operator
up f66 f73
1
2896 0
1
0 0 62 70
1
end_operator
begin_operator
up f66 f74
1
2897 0
1
0 0 62 71
1
end_operator
begin_operator
up f66 f75
1
2898 0
1
0 0 62 72
1
end_operator
begin_operator
up f66 f76
1
2899 0
1
0 0 62 73
1
end_operator
begin_operator
up f66 f77
1
2900 0
1
0 0 62 74
1
end_operator
begin_operator
up f66 f78
1
2901 0
1
0 0 62 75
1
end_operator
begin_operator
up f66 f79
1
2902 0
1
0 0 62 76
1
end_operator
begin_operator
up f66 f80
1
2903 0
1
0 0 62 78
1
end_operator
begin_operator
up f67 f68
1
2904 0
1
0 0 63 64
1
end_operator
begin_operator
up f67 f69
1
2905 0
1
0 0 63 65
1
end_operator
begin_operator
up f67 f70
1
2906 0
1
0 0 63 67
1
end_operator
begin_operator
up f67 f71
1
2907 0
1
0 0 63 68
1
end_operator
begin_operator
up f67 f72
1
2908 0
1
0 0 63 69
1
end_operator
begin_operator
up f67 f73
1
2909 0
1
0 0 63 70
1
end_operator
begin_operator
up f67 f74
1
2910 0
1
0 0 63 71
1
end_operator
begin_operator
up f67 f75
1
2911 0
1
0 0 63 72
1
end_operator
begin_operator
up f67 f76
1
2912 0
1
0 0 63 73
1
end_operator
begin_operator
up f67 f77
1
2913 0
1
0 0 63 74
1
end_operator
begin_operator
up f67 f78
1
2914 0
1
0 0 63 75
1
end_operator
begin_operator
up f67 f79
1
2915 0
1
0 0 63 76
1
end_operator
begin_operator
up f67 f80
1
2916 0
1
0 0 63 78
1
end_operator
begin_operator
up f68 f69
1
2917 0
1
0 0 64 65
1
end_operator
begin_operator
up f68 f70
1
2918 0
1
0 0 64 67
1
end_operator
begin_operator
up f68 f71
1
2919 0
1
0 0 64 68
1
end_operator
begin_operator
up f68 f72
1
2920 0
1
0 0 64 69
1
end_operator
begin_operator
up f68 f73
1
2921 0
1
0 0 64 70
1
end_operator
begin_operator
up f68 f74
1
2922 0
1
0 0 64 71
1
end_operator
begin_operator
up f68 f75
1
2923 0
1
0 0 64 72
1
end_operator
begin_operator
up f68 f76
1
2924 0
1
0 0 64 73
1
end_operator
begin_operator
up f68 f77
1
2925 0
1
0 0 64 74
1
end_operator
begin_operator
up f68 f78
1
2926 0
1
0 0 64 75
1
end_operator
begin_operator
up f68 f79
1
2927 0
1
0 0 64 76
1
end_operator
begin_operator
up f68 f80
1
2928 0
1
0 0 64 78
1
end_operator
begin_operator
up f69 f70
1
2929 0
1
0 0 65 67
1
end_operator
begin_operator
up f69 f71
1
2930 0
1
0 0 65 68
1
end_operator
begin_operator
up f69 f72
1
2931 0
1
0 0 65 69
1
end_operator
begin_operator
up f69 f73
1
2932 0
1
0 0 65 70
1
end_operator
begin_operator
up f69 f74
1
2933 0
1
0 0 65 71
1
end_operator
begin_operator
up f69 f75
1
2934 0
1
0 0 65 72
1
end_operator
begin_operator
up f69 f76
1
2935 0
1
0 0 65 73
1
end_operator
begin_operator
up f69 f77
1
2936 0
1
0 0 65 74
1
end_operator
begin_operator
up f69 f78
1
2937 0
1
0 0 65 75
1
end_operator
begin_operator
up f69 f79
1
2938 0
1
0 0 65 76
1
end_operator
begin_operator
up f69 f80
1
2939 0
1
0 0 65 78
1
end_operator
begin_operator
up f7 f10
1
2940 0
1
0 0 66 1
1
end_operator
begin_operator
up f7 f11
1
2941 0
1
0 0 66 2
1
end_operator
begin_operator
up f7 f12
1
2942 0
1
0 0 66 3
1
end_operator
begin_operator
up f7 f13
1
2943 0
1
0 0 66 4
1
end_operator
begin_operator
up f7 f14
1
2944 0
1
0 0 66 5
1
end_operator
begin_operator
up f7 f15
1
2945 0
1
0 0 66 6
1
end_operator
begin_operator
up f7 f16
1
2946 0
1
0 0 66 7
1
end_operator
begin_operator
up f7 f17
1
2947 0
1
0 0 66 8
1
end_operator
begin_operator
up f7 f18
1
2948 0
1
0 0 66 9
1
end_operator
begin_operator
up f7 f19
1
2949 0
1
0 0 66 10
1
end_operator
begin_operator
up f7 f20
1
2950 0
1
0 0 66 12
1
end_operator
begin_operator
up f7 f21
1
2951 0
1
0 0 66 13
1
end_operator
begin_operator
up f7 f22
1
2952 0
1
0 0 66 14
1
end_operator
begin_operator
up f7 f23
1
2953 0
1
0 0 66 15
1
end_operator
begin_operator
up f7 f24
1
2954 0
1
0 0 66 16
1
end_operator
begin_operator
up f7 f25
1
2955 0
1
0 0 66 17
1
end_operator
begin_operator
up f7 f26
1
2956 0
1
0 0 66 18
1
end_operator
begin_operator
up f7 f27
1
2957 0
1
0 0 66 19
1
end_operator
begin_operator
up f7 f28
1
2958 0
1
0 0 66 20
1
end_operator
begin_operator
up f7 f29
1
2959 0
1
0 0 66 21
1
end_operator
begin_operator
up f7 f30
1
2960 0
1
0 0 66 23
1
end_operator
begin_operator
up f7 f31
1
2961 0
1
0 0 66 24
1
end_operator
begin_operator
up f7 f32
1
2962 0
1
0 0 66 25
1
end_operator
begin_operator
up f7 f33
1
2963 0
1
0 0 66 26
1
end_operator
begin_operator
up f7 f34
1
2964 0
1
0 0 66 27
1
end_operator
begin_operator
up f7 f35
1
2965 0
1
0 0 66 28
1
end_operator
begin_operator
up f7 f36
1
2966 0
1
0 0 66 29
1
end_operator
begin_operator
up f7 f37
1
2967 0
1
0 0 66 30
1
end_operator
begin_operator
up f7 f38
1
2968 0
1
0 0 66 31
1
end_operator
begin_operator
up f7 f39
1
2969 0
1
0 0 66 32
1
end_operator
begin_operator
up f7 f40
1
2970 0
1
0 0 66 34
1
end_operator
begin_operator
up f7 f41
1
2971 0
1
0 0 66 35
1
end_operator
begin_operator
up f7 f42
1
2972 0
1
0 0 66 36
1
end_operator
begin_operator
up f7 f43
1
2973 0
1
0 0 66 37
1
end_operator
begin_operator
up f7 f44
1
2974 0
1
0 0 66 38
1
end_operator
begin_operator
up f7 f45
1
2975 0
1
0 0 66 39
1
end_operator
begin_operator
up f7 f46
1
2976 0
1
0 0 66 40
1
end_operator
begin_operator
up f7 f47
1
2977 0
1
0 0 66 41
1
end_operator
begin_operator
up f7 f48
1
2978 0
1
0 0 66 42
1
end_operator
begin_operator
up f7 f49
1
2979 0
1
0 0 66 43
1
end_operator
begin_operator
up f7 f50
1
2980 0
1
0 0 66 45
1
end_operator
begin_operator
up f7 f51
1
2981 0
1
0 0 66 46
1
end_operator
begin_operator
up f7 f52
1
2982 0
1
0 0 66 47
1
end_operator
begin_operator
up f7 f53
1
2983 0
1
0 0 66 48
1
end_operator
begin_operator
up f7 f54
1
2984 0
1
0 0 66 49
1
end_operator
begin_operator
up f7 f55
1
2985 0
1
0 0 66 50
1
end_operator
begin_operator
up f7 f56
1
2986 0
1
0 0 66 51
1
end_operator
begin_operator
up f7 f57
1
2987 0
1
0 0 66 52
1
end_operator
begin_operator
up f7 f58
1
2988 0
1
0 0 66 53
1
end_operator
begin_operator
up f7 f59
1
2989 0
1
0 0 66 54
1
end_operator
begin_operator
up f7 f60
1
2990 0
1
0 0 66 56
1
end_operator
begin_operator
up f7 f61
1
2991 0
1
0 0 66 57
1
end_operator
begin_operator
up f7 f62
1
2992 0
1
0 0 66 58
1
end_operator
begin_operator
up f7 f63
1
2993 0
1
0 0 66 59
1
end_operator
begin_operator
up f7 f64
1
2994 0
1
0 0 66 60
1
end_operator
begin_operator
up f7 f65
1
2995 0
1
0 0 66 61
1
end_operator
begin_operator
up f7 f66
1
2996 0
1
0 0 66 62
1
end_operator
begin_operator
up f7 f67
1
2997 0
1
0 0 66 63
1
end_operator
begin_operator
up f7 f68
1
2998 0
1
0 0 66 64
1
end_operator
begin_operator
up f7 f69
1
2999 0
1
0 0 66 65
1
end_operator
begin_operator
up f7 f70
1
3000 0
1
0 0 66 67
1
end_operator
begin_operator
up f7 f71
1
3001 0
1
0 0 66 68
1
end_operator
begin_operator
up f7 f72
1
3002 0
1
0 0 66 69
1
end_operator
begin_operator
up f7 f73
1
3003 0
1
0 0 66 70
1
end_operator
begin_operator
up f7 f74
1
3004 0
1
0 0 66 71
1
end_operator
begin_operator
up f7 f75
1
3005 0
1
0 0 66 72
1
end_operator
begin_operator
up f7 f76
1
3006 0
1
0 0 66 73
1
end_operator
begin_operator
up f7 f77
1
3007 0
1
0 0 66 74
1
end_operator
begin_operator
up f7 f78
1
3008 0
1
0 0 66 75
1
end_operator
begin_operator
up f7 f79
1
3009 0
1
0 0 66 76
1
end_operator
begin_operator
up f7 f8
1
3010 0
1
0 0 66 77
1
end_operator
begin_operator
up f7 f80
1
3011 0
1
0 0 66 78
1
end_operator
begin_operator
up f7 f9
1
3012 0
1
0 0 66 79
1
end_operator
begin_operator
up f70 f71
1
3013 0
1
0 0 67 68
1
end_operator
begin_operator
up f70 f72
1
3014 0
1
0 0 67 69
1
end_operator
begin_operator
up f70 f73
1
3015 0
1
0 0 67 70
1
end_operator
begin_operator
up f70 f74
1
3016 0
1
0 0 67 71
1
end_operator
begin_operator
up f70 f75
1
3017 0
1
0 0 67 72
1
end_operator
begin_operator
up f70 f76
1
3018 0
1
0 0 67 73
1
end_operator
begin_operator
up f70 f77
1
3019 0
1
0 0 67 74
1
end_operator
begin_operator
up f70 f78
1
3020 0
1
0 0 67 75
1
end_operator
begin_operator
up f70 f79
1
3021 0
1
0 0 67 76
1
end_operator
begin_operator
up f70 f80
1
3022 0
1
0 0 67 78
1
end_operator
begin_operator
up f71 f72
1
3023 0
1
0 0 68 69
1
end_operator
begin_operator
up f71 f73
1
3024 0
1
0 0 68 70
1
end_operator
begin_operator
up f71 f74
1
3025 0
1
0 0 68 71
1
end_operator
begin_operator
up f71 f75
1
3026 0
1
0 0 68 72
1
end_operator
begin_operator
up f71 f76
1
3027 0
1
0 0 68 73
1
end_operator
begin_operator
up f71 f77
1
3028 0
1
0 0 68 74
1
end_operator
begin_operator
up f71 f78
1
3029 0
1
0 0 68 75
1
end_operator
begin_operator
up f71 f79
1
3030 0
1
0 0 68 76
1
end_operator
begin_operator
up f71 f80
1
3031 0
1
0 0 68 78
1
end_operator
begin_operator
up f72 f73
1
3032 0
1
0 0 69 70
1
end_operator
begin_operator
up f72 f74
1
3033 0
1
0 0 69 71
1
end_operator
begin_operator
up f72 f75
1
3034 0
1
0 0 69 72
1
end_operator
begin_operator
up f72 f76
1
3035 0
1
0 0 69 73
1
end_operator
begin_operator
up f72 f77
1
3036 0
1
0 0 69 74
1
end_operator
begin_operator
up f72 f78
1
3037 0
1
0 0 69 75
1
end_operator
begin_operator
up f72 f79
1
3038 0
1
0 0 69 76
1
end_operator
begin_operator
up f72 f80
1
3039 0
1
0 0 69 78
1
end_operator
begin_operator
up f73 f74
1
3040 0
1
0 0 70 71
1
end_operator
begin_operator
up f73 f75
1
3041 0
1
0 0 70 72
1
end_operator
begin_operator
up f73 f76
1
3042 0
1
0 0 70 73
1
end_operator
begin_operator
up f73 f77
1
3043 0
1
0 0 70 74
1
end_operator
begin_operator
up f73 f78
1
3044 0
1
0 0 70 75
1
end_operator
begin_operator
up f73 f79
1
3045 0
1
0 0 70 76
1
end_operator
begin_operator
up f73 f80
1
3046 0
1
0 0 70 78
1
end_operator
begin_operator
up f74 f75
1
3047 0
1
0 0 71 72
1
end_operator
begin_operator
up f74 f76
1
3048 0
1
0 0 71 73
1
end_operator
begin_operator
up f74 f77
1
3049 0
1
0 0 71 74
1
end_operator
begin_operator
up f74 f78
1
3050 0
1
0 0 71 75
1
end_operator
begin_operator
up f74 f79
1
3051 0
1
0 0 71 76
1
end_operator
begin_operator
up f74 f80
1
3052 0
1
0 0 71 78
1
end_operator
begin_operator
up f75 f76
1
3053 0
1
0 0 72 73
1
end_operator
begin_operator
up f75 f77
1
3054 0
1
0 0 72 74
1
end_operator
begin_operator
up f75 f78
1
3055 0
1
0 0 72 75
1
end_operator
begin_operator
up f75 f79
1
3056 0
1
0 0 72 76
1
end_operator
begin_operator
up f75 f80
1
3057 0
1
0 0 72 78
1
end_operator
begin_operator
up f76 f77
1
3058 0
1
0 0 73 74
1
end_operator
begin_operator
up f76 f78
1
3059 0
1
0 0 73 75
1
end_operator
begin_operator
up f76 f79
1
3060 0
1
0 0 73 76
1
end_operator
begin_operator
up f76 f80
1
3061 0
1
0 0 73 78
1
end_operator
begin_operator
up f77 f78
1
3062 0
1
0 0 74 75
1
end_operator
begin_operator
up f77 f79
1
3063 0
1
0 0 74 76
1
end_operator
begin_operator
up f77 f80
1
3064 0
1
0 0 74 78
1
end_operator
begin_operator
up f78 f79
1
3065 0
1
0 0 75 76
1
end_operator
begin_operator
up f78 f80
1
3066 0
1
0 0 75 78
1
end_operator
begin_operator
up f79 f80
1
3067 0
1
0 0 76 78
1
end_operator
begin_operator
up f8 f10
1
3068 0
1
0 0 77 1
1
end_operator
begin_operator
up f8 f11
1
3069 0
1
0 0 77 2
1
end_operator
begin_operator
up f8 f12
1
3070 0
1
0 0 77 3
1
end_operator
begin_operator
up f8 f13
1
3071 0
1
0 0 77 4
1
end_operator
begin_operator
up f8 f14
1
3072 0
1
0 0 77 5
1
end_operator
begin_operator
up f8 f15
1
3073 0
1
0 0 77 6
1
end_operator
begin_operator
up f8 f16
1
3074 0
1
0 0 77 7
1
end_operator
begin_operator
up f8 f17
1
3075 0
1
0 0 77 8
1
end_operator
begin_operator
up f8 f18
1
3076 0
1
0 0 77 9
1
end_operator
begin_operator
up f8 f19
1
3077 0
1
0 0 77 10
1
end_operator
begin_operator
up f8 f20
1
3078 0
1
0 0 77 12
1
end_operator
begin_operator
up f8 f21
1
3079 0
1
0 0 77 13
1
end_operator
begin_operator
up f8 f22
1
3080 0
1
0 0 77 14
1
end_operator
begin_operator
up f8 f23
1
3081 0
1
0 0 77 15
1
end_operator
begin_operator
up f8 f24
1
3082 0
1
0 0 77 16
1
end_operator
begin_operator
up f8 f25
1
3083 0
1
0 0 77 17
1
end_operator
begin_operator
up f8 f26
1
3084 0
1
0 0 77 18
1
end_operator
begin_operator
up f8 f27
1
3085 0
1
0 0 77 19
1
end_operator
begin_operator
up f8 f28
1
3086 0
1
0 0 77 20
1
end_operator
begin_operator
up f8 f29
1
3087 0
1
0 0 77 21
1
end_operator
begin_operator
up f8 f30
1
3088 0
1
0 0 77 23
1
end_operator
begin_operator
up f8 f31
1
3089 0
1
0 0 77 24
1
end_operator
begin_operator
up f8 f32
1
3090 0
1
0 0 77 25
1
end_operator
begin_operator
up f8 f33
1
3091 0
1
0 0 77 26
1
end_operator
begin_operator
up f8 f34
1
3092 0
1
0 0 77 27
1
end_operator
begin_operator
up f8 f35
1
3093 0
1
0 0 77 28
1
end_operator
begin_operator
up f8 f36
1
3094 0
1
0 0 77 29
1
end_operator
begin_operator
up f8 f37
1
3095 0
1
0 0 77 30
1
end_operator
begin_operator
up f8 f38
1
3096 0
1
0 0 77 31
1
end_operator
begin_operator
up f8 f39
1
3097 0
1
0 0 77 32
1
end_operator
begin_operator
up f8 f40
1
3098 0
1
0 0 77 34
1
end_operator
begin_operator
up f8 f41
1
3099 0
1
0 0 77 35
1
end_operator
begin_operator
up f8 f42
1
3100 0
1
0 0 77 36
1
end_operator
begin_operator
up f8 f43
1
3101 0
1
0 0 77 37
1
end_operator
begin_operator
up f8 f44
1
3102 0
1
0 0 77 38
1
end_operator
begin_operator
up f8 f45
1
3103 0
1
0 0 77 39
1
end_operator
begin_operator
up f8 f46
1
3104 0
1
0 0 77 40
1
end_operator
begin_operator
up f8 f47
1
3105 0
1
0 0 77 41
1
end_operator
begin_operator
up f8 f48
1
3106 0
1
0 0 77 42
1
end_operator
begin_operator
up f8 f49
1
3107 0
1
0 0 77 43
1
end_operator
begin_operator
up f8 f50
1
3108 0
1
0 0 77 45
1
end_operator
begin_operator
up f8 f51
1
3109 0
1
0 0 77 46
1
end_operator
begin_operator
up f8 f52
1
3110 0
1
0 0 77 47
1
end_operator
begin_operator
up f8 f53
1
3111 0
1
0 0 77 48
1
end_operator
begin_operator
up f8 f54
1
3112 0
1
0 0 77 49
1
end_operator
begin_operator
up f8 f55
1
3113 0
1
0 0 77 50
1
end_operator
begin_operator
up f8 f56
1
3114 0
1
0 0 77 51
1
end_operator
begin_operator
up f8 f57
1
3115 0
1
0 0 77 52
1
end_operator
begin_operator
up f8 f58
1
3116 0
1
0 0 77 53
1
end_operator
begin_operator
up f8 f59
1
3117 0
1
0 0 77 54
1
end_operator
begin_operator
up f8 f60
1
3118 0
1
0 0 77 56
1
end_operator
begin_operator
up f8 f61
1
3119 0
1
0 0 77 57
1
end_operator
begin_operator
up f8 f62
1
3120 0
1
0 0 77 58
1
end_operator
begin_operator
up f8 f63
1
3121 0
1
0 0 77 59
1
end_operator
begin_operator
up f8 f64
1
3122 0
1
0 0 77 60
1
end_operator
begin_operator
up f8 f65
1
3123 0
1
0 0 77 61
1
end_operator
begin_operator
up f8 f66
1
3124 0
1
0 0 77 62
1
end_operator
begin_operator
up f8 f67
1
3125 0
1
0 0 77 63
1
end_operator
begin_operator
up f8 f68
1
3126 0
1
0 0 77 64
1
end_operator
begin_operator
up f8 f69
1
3127 0
1
0 0 77 65
1
end_operator
begin_operator
up f8 f70
1
3128 0
1
0 0 77 67
1
end_operator
begin_operator
up f8 f71
1
3129 0
1
0 0 77 68
1
end_operator
begin_operator
up f8 f72
1
3130 0
1
0 0 77 69
1
end_operator
begin_operator
up f8 f73
1
3131 0
1
0 0 77 70
1
end_operator
begin_operator
up f8 f74
1
3132 0
1
0 0 77 71
1
end_operator
begin_operator
up f8 f75
1
3133 0
1
0 0 77 72
1
end_operator
begin_operator
up f8 f76
1
3134 0
1
0 0 77 73
1
end_operator
begin_operator
up f8 f77
1
3135 0
1
0 0 77 74
1
end_operator
begin_operator
up f8 f78
1
3136 0
1
0 0 77 75
1
end_operator
begin_operator
up f8 f79
1
3137 0
1
0 0 77 76
1
end_operator
begin_operator
up f8 f80
1
3138 0
1
0 0 77 78
1
end_operator
begin_operator
up f8 f9
1
3139 0
1
0 0 77 79
1
end_operator
begin_operator
up f9 f10
1
3140 0
1
0 0 79 1
1
end_operator
begin_operator
up f9 f11
1
3141 0
1
0 0 79 2
1
end_operator
begin_operator
up f9 f12
1
3142 0
1
0 0 79 3
1
end_operator
begin_operator
up f9 f13
1
3143 0
1
0 0 79 4
1
end_operator
begin_operator
up f9 f14
1
3144 0
1
0 0 79 5
1
end_operator
begin_operator
up f9 f15
1
3145 0
1
0 0 79 6
1
end_operator
begin_operator
up f9 f16
1
3146 0
1
0 0 79 7
1
end_operator
begin_operator
up f9 f17
1
3147 0
1
0 0 79 8
1
end_operator
begin_operator
up f9 f18
1
3148 0
1
0 0 79 9
1
end_operator
begin_operator
up f9 f19
1
3149 0
1
0 0 79 10
1
end_operator
begin_operator
up f9 f20
1
3150 0
1
0 0 79 12
1
end_operator
begin_operator
up f9 f21
1
3151 0
1
0 0 79 13
1
end_operator
begin_operator
up f9 f22
1
3152 0
1
0 0 79 14
1
end_operator
begin_operator
up f9 f23
1
3153 0
1
0 0 79 15
1
end_operator
begin_operator
up f9 f24
1
3154 0
1
0 0 79 16
1
end_operator
begin_operator
up f9 f25
1
3155 0
1
0 0 79 17
1
end_operator
begin_operator
up f9 f26
1
3156 0
1
0 0 79 18
1
end_operator
begin_operator
up f9 f27
1
3157 0
1
0 0 79 19
1
end_operator
begin_operator
up f9 f28
1
3158 0
1
0 0 79 20
1
end_operator
begin_operator
up f9 f29
1
3159 0
1
0 0 79 21
1
end_operator
begin_operator
up f9 f30
1
3160 0
1
0 0 79 23
1
end_operator
begin_operator
up f9 f31
1
3161 0
1
0 0 79 24
1
end_operator
begin_operator
up f9 f32
1
3162 0
1
0 0 79 25
1
end_operator
begin_operator
up f9 f33
1
3163 0
1
0 0 79 26
1
end_operator
begin_operator
up f9 f34
1
3164 0
1
0 0 79 27
1
end_operator
begin_operator
up f9 f35
1
3165 0
1
0 0 79 28
1
end_operator
begin_operator
up f9 f36
1
3166 0
1
0 0 79 29
1
end_operator
begin_operator
up f9 f37
1
3167 0
1
0 0 79 30
1
end_operator
begin_operator
up f9 f38
1
3168 0
1
0 0 79 31
1
end_operator
begin_operator
up f9 f39
1
3169 0
1
0 0 79 32
1
end_operator
begin_operator
up f9 f40
1
3170 0
1
0 0 79 34
1
end_operator
begin_operator
up f9 f41
1
3171 0
1
0 0 79 35
1
end_operator
begin_operator
up f9 f42
1
3172 0
1
0 0 79 36
1
end_operator
begin_operator
up f9 f43
1
3173 0
1
0 0 79 37
1
end_operator
begin_operator
up f9 f44
1
3174 0
1
0 0 79 38
1
end_operator
begin_operator
up f9 f45
1
3175 0
1
0 0 79 39
1
end_operator
begin_operator
up f9 f46
1
3176 0
1
0 0 79 40
1
end_operator
begin_operator
up f9 f47
1
3177 0
1
0 0 79 41
1
end_operator
begin_operator
up f9 f48
1
3178 0
1
0 0 79 42
1
end_operator
begin_operator
up f9 f49
1
3179 0
1
0 0 79 43
1
end_operator
begin_operator
up f9 f50
1
3180 0
1
0 0 79 45
1
end_operator
begin_operator
up f9 f51
1
3181 0
1
0 0 79 46
1
end_operator
begin_operator
up f9 f52
1
3182 0
1
0 0 79 47
1
end_operator
begin_operator
up f9 f53
1
3183 0
1
0 0 79 48
1
end_operator
begin_operator
up f9 f54
1
3184 0
1
0 0 79 49
1
end_operator
begin_operator
up f9 f55
1
3185 0
1
0 0 79 50
1
end_operator
begin_operator
up f9 f56
1
3186 0
1
0 0 79 51
1
end_operator
begin_operator
up f9 f57
1
3187 0
1
0 0 79 52
1
end_operator
begin_operator
up f9 f58
1
3188 0
1
0 0 79 53
1
end_operator
begin_operator
up f9 f59
1
3189 0
1
0 0 79 54
1
end_operator
begin_operator
up f9 f60
1
3190 0
1
0 0 79 56
1
end_operator
begin_operator
up f9 f61
1
3191 0
1
0 0 79 57
1
end_operator
begin_operator
up f9 f62
1
3192 0
1
0 0 79 58
1
end_operator
begin_operator
up f9 f63
1
3193 0
1
0 0 79 59
1
end_operator
begin_operator
up f9 f64
1
3194 0
1
0 0 79 60
1
end_operator
begin_operator
up f9 f65
1
3195 0
1
0 0 79 61
1
end_operator
begin_operator
up f9 f66
1
3196 0
1
0 0 79 62
1
end_operator
begin_operator
up f9 f67
1
3197 0
1
0 0 79 63
1
end_operator
begin_operator
up f9 f68
1
3198 0
1
0 0 79 64
1
end_operator
begin_operator
up f9 f69
1
3199 0
1
0 0 79 65
1
end_operator
begin_operator
up f9 f70
1
3200 0
1
0 0 79 67
1
end_operator
begin_operator
up f9 f71
1
3201 0
1
0 0 79 68
1
end_operator
begin_operator
up f9 f72
1
3202 0
1
0 0 79 69
1
end_operator
begin_operator
up f9 f73
1
3203 0
1
0 0 79 70
1
end_operator
begin_operator
up f9 f74
1
3204 0
1
0 0 79 71
1
end_operator
begin_operator
up f9 f75
1
3205 0
1
0 0 79 72
1
end_operator
begin_operator
up f9 f76
1
3206 0
1
0 0 79 73
1
end_operator
begin_operator
up f9 f77
1
3207 0
1
0 0 79 74
1
end_operator
begin_operator
up f9 f78
1
3208 0
1
0 0 79 75
1
end_operator
begin_operator
up f9 f79
1
3209 0
1
0 0 79 76
1
end_operator
begin_operator
up f9 f80
1
3210 0
1
0 0 79 78
1
end_operator
0
