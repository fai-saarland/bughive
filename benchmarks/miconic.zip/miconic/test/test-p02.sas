begin_version
3
end_version
begin_metric
1
end_metric
9
begin_variable
var0
-1
4
lift-at f1
lift-at f2
lift-at f3
lift-at f4
end_variable
begin_variable
var1
-1
3
boarded p1
origin p1 f3
served p1
end_variable
begin_variable
var2
-1
2
above f1 f2
none-of-those
end_variable
begin_variable
var3
-1
2
above f1 f3
none-of-those
end_variable
begin_variable
var4
-1
2
above f1 f4
none-of-those
end_variable
begin_variable
var5
-1
2
above f2 f3
none-of-those
end_variable
begin_variable
var6
-1
2
above f2 f4
none-of-those
end_variable
begin_variable
var7
-1
2
above f3 f4
none-of-those
end_variable
begin_variable
var8
-1
2
destin p1 f1
none-of-those
end_variable
0
begin_state
3
1
0
0
0
0
0
0
0
end_state
begin_goal
1
1 2
end_goal
14
begin_operator
board f3 p1
1
0 2
1
0 1 1 0
1
end_operator
begin_operator
depart f1 p1
2
0 0
8 0
1
0 1 0 2
1
end_operator
begin_operator
down f2 f1
1
2 0
1
0 0 1 0
1
end_operator
begin_operator
down f3 f1
1
3 0
1
0 0 2 0
1
end_operator
begin_operator
down f3 f2
1
5 0
1
0 0 2 1
1
end_operator
begin_operator
down f4 f1
1
4 0
1
0 0 3 0
1
end_operator
begin_operator
down f4 f2
1
6 0
1
0 0 3 1
1
end_operator
begin_operator
down f4 f3
1
7 0
1
0 0 3 2
1
end_operator
begin_operator
up f1 f2
1
2 0
1
0 0 0 1
1
end_operator
begin_operator
up f1 f3
1
3 0
1
0 0 0 2
1
end_operator
begin_operator
up f1 f4
1
4 0
1
0 0 0 3
1
end_operator
begin_operator
up f2 f3
1
5 0
1
0 0 1 2
1
end_operator
begin_operator
up f2 f4
1
6 0
1
0 0 1 3
1
end_operator
begin_operator
up f3 f4
1
7 0
1
0 0 2 3
1
end_operator
0
