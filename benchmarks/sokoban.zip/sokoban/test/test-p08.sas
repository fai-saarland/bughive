begin_version
3
end_version
begin_metric
1
end_metric
138
begin_variable
var0
-1
37
at-robot loc_2_2
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_5
at-robot loc_2_7
at-robot loc_2_8
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_5_2
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_7_2
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_8
at-robot loc_8_2
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_7
at-robot loc_8_8
end_variable
begin_variable
var1
-1
31
at box1 loc_2_7
at box1 loc_2_8
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_5_2
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_8
at box1 loc_8_2
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_8
end_variable
begin_variable
var2
-1
2
clear loc_2_2
none-of-those
end_variable
begin_variable
var3
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var4
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var40
-1
2
adjacent loc_2_2 loc_2_3 right
none-of-those
end_variable
begin_variable
var41
-1
2
adjacent loc_2_3 loc_2_2 left
none-of-those
end_variable
begin_variable
var42
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var43
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var44
-1
2
adjacent loc_2_4 loc_2_5 right
none-of-those
end_variable
begin_variable
var45
-1
2
adjacent loc_2_5 loc_2_4 left
none-of-those
end_variable
begin_variable
var46
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var47
-1
2
adjacent loc_2_7 loc_2_8 right
none-of-those
end_variable
begin_variable
var48
-1
2
adjacent loc_2_7 loc_3_7 down
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_2_8 loc_2_7 left
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_3_7 loc_2_7 up
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_5_8 loc_6_8 down
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_6_8 loc_5_8 up
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
0
begin_state
9
7
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
1
1 22
end_goal
154
begin_operator
move loc_2_2 loc_2_3 right
2
3 0
40 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_2_3 loc_2_2 left
2
2 0
41 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
4 0
42 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
3 0
43 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_2_4 loc_2_5 right
2
5 0
44 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_2_5 loc_2_4 left
2
4 0
45 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
8 0
46 0
1
0 0 3 6
1
end_operator
begin_operator
move loc_2_7 loc_2_8 right
2
7 0
47 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_2_7 loc_3_7 down
2
10 0
48 0
1
0 0 4 8
1
end_operator
begin_operator
move loc_2_8 loc_2_7 left
2
6 0
49 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
11 0
50 0
1
0 0 5 9
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
5 0
51 0
1
0 0 6 3
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
9 0
52 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
8 0
53 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
10 0
54 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
13 0
55 0
1
0 0 7 10
1
end_operator
begin_operator
move loc_3_7 loc_2_7 up
2
6 0
56 0
1
0 0 8 4
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
9 0
57 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
11 0
58 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
14 0
59 0
1
0 0 8 11
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
7 0
60 0
1
0 0 9 5
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
10 0
61 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
15 0
62 0
1
0 0 9 12
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
9 0
63 0
1
0 0 10 7
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
14 0
64 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
19 0
65 0
1
0 0 10 16
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
10 0
66 0
1
0 0 11 8
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
13 0
67 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
15 0
68 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
20 0
69 0
1
0 0 11 17
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
11 0
70 0
1
0 0 12 9
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
14 0
71 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
21 0
72 0
1
0 0 12 18
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
22 0
73 0
1
0 0 13 19
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
18 0
74 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
24 0
75 0
1
0 0 14 21
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
17 0
76 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
19 0
77 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
25 0
78 0
1
0 0 15 22
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
13 0
79 0
1
0 0 16 10
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
18 0
80 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
20 0
81 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
26 0
82 0
1
0 0 16 23
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
14 0
83 0
1
0 0 17 11
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
19 0
84 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
21 0
85 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
27 0
86 0
1
0 0 17 24
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
15 0
87 0
1
0 0 18 12
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
20 0
88 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_5_8 loc_6_8 down
2
28 0
89 0
1
0 0 18 25
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
16 0
90 0
1
0 0 19 13
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
23 0
91 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
29 0
92 0
1
0 0 19 26
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
22 0
93 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
24 0
94 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
17 0
95 0
1
0 0 21 14
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
23 0
96 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
25 0
97 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
30 0
98 0
1
0 0 21 27
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
18 0
99 0
1
0 0 22 15
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
24 0
100 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
26 0
101 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
31 0
102 0
1
0 0 22 28
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
19 0
103 0
1
0 0 23 16
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
25 0
104 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
27 0
105 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
32 0
106 0
1
0 0 23 29
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
20 0
107 0
1
0 0 24 17
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
26 0
108 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
28 0
109 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_6_8 loc_5_8 up
2
21 0
110 0
1
0 0 25 18
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
27 0
111 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
33 0
112 0
1
0 0 25 30
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
22 0
113 0
1
0 0 26 19
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
34 0
114 0
1
0 0 26 31
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
24 0
115 0
1
0 0 27 21
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
31 0
116 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
36 0
117 0
1
0 0 27 33
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
25 0
118 0
1
0 0 28 22
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
30 0
119 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
32 0
120 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
37 0
121 0
1
0 0 28 34
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
26 0
122 0
1
0 0 29 23
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
31 0
123 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
28 0
124 0
1
0 0 30 25
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
39 0
125 0
1
0 0 30 36
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
29 0
126 0
1
0 0 31 26
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
35 0
127 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
34 0
128 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
36 0
129 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
30 0
130 0
1
0 0 33 27
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
35 0
131 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
37 0
132 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
31 0
133 0
1
0 0 34 28
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
36 0
134 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
39 0
135 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
33 0
136 0
1
0 0 36 30
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
38 0
137 0
1
0 0 36 35
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box1
2
48 0
59 0
4
0 0 4 8
0 1 4 7
0 10 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box1
2
50 0
62 0
4
0 0 5 9
0 1 5 8
0 11 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
54 0
58 0
4
0 0 7 8
0 1 4 5
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
55 0
65 0
4
0 0 7 10
0 1 6 12
0 13 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
53 0
57 0
4
0 0 8 7
0 1 3 2
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
59 0
69 0
4
0 0 8 11
0 1 7 13
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
57 0
61 0
4
0 0 9 8
0 1 4 3
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box1
2
62 0
72 0
4
0 0 9 12
0 1 8 14
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
64 0
68 0
4
0 0 10 11
0 1 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
65 0
82 0
4
0 0 10 16
0 1 12 19
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box1
2
56 0
66 0
4
0 0 11 8
0 1 4 0
0 6 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
69 0
86 0
4
0 0 11 17
0 1 13 20
0 20 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box1
2
60 0
70 0
4
0 0 12 9
0 1 5 1
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
67 0
71 0
4
0 0 12 11
0 1 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box1
2
72 0
89 0
4
0 0 12 18
0 1 14 21
0 21 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
74 0
77 0
4
0 0 14 15
0 1 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
75 0
98 0
4
0 0 14 21
0 1 17 22
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
77 0
81 0
4
0 0 15 16
0 1 12 13
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
78 0
102 0
4
0 0 15 22
0 1 18 23
0 25 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
63 0
79 0
4
0 0 16 10
0 1 6 3
0 9 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
76 0
80 0
4
0 0 16 15
0 1 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
81 0
85 0
4
0 0 16 17
0 1 13 14
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
82 0
106 0
4
0 0 16 23
0 1 19 24
0 26 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
66 0
83 0
4
0 0 17 11
0 1 7 4
0 10 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
80 0
84 0
4
0 0 17 16
0 1 12 11
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box1
2
70 0
87 0
4
0 0 18 12
0 1 8 5
0 11 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
84 0
88 0
4
0 0 18 17
0 1 13 12
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box1
2
89 0
112 0
4
0 0 18 25
0 1 21 25
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box1
2
91 0
94 0
4
0 0 19 20
0 1 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box1
2
94 0
97 0
4
0 0 20 21
0 1 17 18
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box1
2
93 0
96 0
4
0 0 21 20
0 1 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
97 0
101 0
4
0 0 21 22
0 1 18 19
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
98 0
117 0
4
0 0 21 27
0 1 22 28
0 30 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box1
2
96 0
100 0
4
0 0 22 21
0 1 17 16
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
101 0
105 0
4
0 0 22 23
0 1 19 20
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box1
2
102 0
121 0
4
0 0 22 28
0 1 23 29
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
79 0
103 0
4
0 0 23 16
0 1 12 6
0 13 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
100 0
104 0
4
0 0 23 22
0 1 18 17
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
105 0
109 0
4
0 0 23 24
0 1 20 21
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
83 0
107 0
4
0 0 24 17
0 1 13 7
0 14 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
104 0
108 0
4
0 0 24 23
0 1 19 18
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box1
2
87 0
110 0
4
0 0 25 18
0 1 14 8
0 15 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
108 0
111 0
4
0 0 25 24
0 1 20 19
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box1
2
112 0
125 0
4
0 0 25 30
0 1 25 30
0 33 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box1
2
90 0
113 0
4
0 0 26 19
0 1 15 9
0 16 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
95 0
115 0
4
0 0 27 21
0 1 17 10
0 17 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
116 0
120 0
4
0 0 27 28
0 1 23 24
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
99 0
118 0
4
0 0 28 22
0 1 18 11
0 18 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
103 0
122 0
4
0 0 29 23
0 1 19 12
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box1
2
119 0
123 0
4
0 0 29 28
0 1 23 22
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box1
2
127 0
129 0
4
0 0 31 32
0 1 27 28
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box1
2
129 0
132 0
4
0 0 32 33
0 1 28 29
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
115 0
130 0
4
0 0 33 27
0 1 22 17
0 24 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box1
2
128 0
131 0
4
0 0 33 32
0 1 27 26
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box1
2
118 0
133 0
4
0 0 34 28
0 1 23 18
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box1
2
131 0
134 0
4
0 0 34 33
0 1 28 27
0 35 0 1
0 36 -1 0
1
end_operator
0
