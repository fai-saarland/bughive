begin_version
3
end_version
begin_metric
1
end_metric
121
begin_variable
var0
-1
32
at-robot loc_2_5
at-robot loc_2_7
at-robot loc_2_8
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_7
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_8
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_9_4
at-robot loc_9_6
at-robot loc_9_7
end_variable
begin_variable
var1
-1
24
at box1 loc_2_5
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_9_4
end_variable
begin_variable
var2
-1
2
at box2 loc_8_8
none-of-those
end_variable
begin_variable
var3
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var4
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var37
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var38
-1
2
adjacent loc_2_7 loc_2_8 right
none-of-those
end_variable
begin_variable
var39
-1
2
adjacent loc_2_7 loc_3_7 down
none-of-those
end_variable
begin_variable
var40
-1
2
adjacent loc_2_8 loc_2_7 left
none-of-those
end_variable
begin_variable
var41
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var42
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var43
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var44
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var45
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var46
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var47
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var48
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_3_7 loc_2_7 up
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
0
begin_state
14
8
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
2
1 21
2 0
end_goal
113
begin_operator
move loc_2_5 loc_3_5 down
2
8 0
37 0
1
0 0 0 5
1
end_operator
begin_operator
move loc_2_7 loc_2_8 right
2
5 0
38 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_2_7 loc_3_7 down
2
10 0
39 0
1
0 0 1 7
1
end_operator
begin_operator
move loc_2_8 loc_2_7 left
2
4 0
40 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
7 0
41 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
12 0
42 0
1
0 0 3 9
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
6 0
43 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
8 0
44 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
13 0
45 0
1
0 0 4 10
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
3 0
46 0
1
0 0 5 0
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
7 0
47 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
9 0
48 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
14 0
49 0
1
0 0 5 11
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
8 0
50 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
10 0
51 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_3_7 loc_2_7 up
2
4 0
52 0
1
0 0 7 1
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
9 0
53 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
15 0
54 0
1
0 0 7 12
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
12 0
55 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
6 0
56 0
1
0 0 9 3
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
11 0
57 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
13 0
58 0
1
0 0 9 10
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
16 0
59 0
1
0 0 9 13
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
7 0
60 0
1
0 0 10 4
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
12 0
61 0
1
0 0 10 9
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
14 0
62 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
17 0
63 0
1
0 0 10 14
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
8 0
64 0
1
0 0 11 5
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
13 0
65 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
18 0
66 0
1
0 0 11 15
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
10 0
67 0
1
0 0 12 7
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
12 0
68 0
1
0 0 13 9
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
17 0
69 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
20 0
70 0
1
0 0 13 16
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
13 0
71 0
1
0 0 14 10
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
16 0
72 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
18 0
73 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
21 0
74 0
1
0 0 14 17
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
14 0
75 0
1
0 0 15 11
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
17 0
76 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
16 0
77 0
1
0 0 16 13
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
21 0
78 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
23 0
79 0
1
0 0 16 19
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
17 0
80 0
1
0 0 17 14
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
20 0
81 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
24 0
82 0
1
0 0 17 20
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
28 0
83 0
1
0 0 18 24
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
20 0
84 0
1
0 0 19 16
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
24 0
85 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
29 0
86 0
1
0 0 19 25
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
21 0
87 0
1
0 0 20 17
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
23 0
88 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
25 0
89 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
30 0
90 0
1
0 0 20 26
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
24 0
91 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
26 0
92 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
25 0
93 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
27 0
94 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
31 0
95 0
1
0 0 22 27
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
26 0
96 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
28 0
97 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
32 0
98 0
1
0 0 23 28
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
22 0
99 0
1
0 0 24 18
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
27 0
100 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
23 0
102 0
1
0 0 25 19
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
30 0
103 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
24 0
104 0
1
0 0 26 20
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
29 0
105 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
34 0
106 0
1
0 0 26 29
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
26 0
107 0
1
0 0 27 22
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
32 0
108 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
35 0
109 0
1
0 0 27 30
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
27 0
110 0
1
0 0 28 23
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
31 0
111 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
36 0
113 0
1
0 0 28 31
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
30 0
116 0
1
0 0 29 26
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
31 0
117 0
1
0 0 30 27
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
36 0
118 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
32 0
119 0
1
0 0 31 28
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
35 0
120 0
1
0 0 31 30
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
41 0
44 0
4
0 0 3 4
0 1 2 3
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
42 0
59 0
4
0 0 3 9
0 1 7 10
0 12 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
44 0
48 0
4
0 0 4 5
0 1 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
45 0
63 0
4
0 0 4 10
0 1 8 11
0 13 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
43 0
47 0
4
0 0 5 4
0 1 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
48 0
51 0
4
0 0 5 6
0 1 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
49 0
66 0
4
0 0 5 11
0 1 9 12
0 14 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
58 0
62 0
4
0 0 9 10
0 1 8 9
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box1
2
59 0
70 0
4
0 0 9 13
0 1 10 13
0 16 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
57 0
61 0
4
0 0 10 9
0 1 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
63 0
74 0
4
0 0 10 14
0 1 11 14
0 17 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
46 0
64 0
4
0 0 11 5
0 1 3 0
0 3 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
61 0
65 0
4
0 0 11 10
0 1 8 7
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
56 0
68 0
4
0 0 13 9
0 1 7 1
0 6 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
69 0
73 0
4
0 0 13 14
0 1 11 12
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box1
2
70 0
79 0
4
0 0 13 16
0 1 13 15
0 20 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
60 0
71 0
4
0 0 14 10
0 1 8 2
0 7 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
74 0
82 0
4
0 0 14 17
0 1 14 16
0 21 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
64 0
75 0
4
0 0 15 11
0 1 9 3
0 8 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
72 0
76 0
4
0 0 15 14
0 1 11 10
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box1
2
68 0
77 0
4
0 0 16 13
0 1 10 7
0 12 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box1
2
79 0
86 0
4
0 0 16 19
0 1 15 21
0 23 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
71 0
80 0
4
0 0 17 14
0 1 11 8
0 13 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
82 0
90 0
4
0 0 17 20
0 1 16 22
0 24 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box1
2
77 0
84 0
4
0 0 19 16
0 1 13 10
0 16 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
85 0
89 0
4
0 0 19 20
0 1 16 17
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
80 0
87 0
4
0 0 20 17
0 1 14 11
0 17 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
89 0
92 0
4
0 0 20 21
0 1 17 18
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
90 0
106 0
4
0 0 20 26
0 1 22 23
0 30 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
92 0
94 0
4
0 0 21 22
0 1 18 19
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
94 0
97 0
4
0 0 22 23
0 1 19 20
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box1
2
84 0
102 0
4
0 0 25 19
0 1 15 13
0 20 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
87 0
104 0
4
0 0 26 20
0 1 16 14
0 21 0 1
0 24 -1 0
1
end_operator
0
