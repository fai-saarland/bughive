begin_version
3
end_version
begin_metric
1
end_metric
243
begin_variable
var0
-1
65
at-robot loc_10_10
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_10_9
at-robot loc_11_10
at-robot loc_11_11
at-robot loc_11_3
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_2_10
at-robot loc_2_5
at-robot loc_2_7
at-robot loc_3_10
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_3_9
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_2
at-robot loc_5_4
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_2
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_8_10
at-robot loc_8_2
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_2
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
45
at box1 loc_10_10
at box1 loc_11_10
at box1 loc_2_10
at box1 loc_2_5
at box1 loc_2_7
at box1 loc_3_10
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_3_9
at box1 loc_4_10
at box1 loc_4_11
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_2
at box1 loc_5_4
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_7_10
at box1 loc_7_2
at box1 loc_7_4
at box1 loc_8_10
at box1 loc_8_2
at box1 loc_9_10
at box1 loc_9_2
end_variable
begin_variable
var2
-1
12
at box2 loc_2_10
at box2 loc_2_5
at box2 loc_2_7
at box2 loc_3_10
at box2 loc_3_2
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_3_8
at box2 loc_3_9
end_variable
begin_variable
var3
-1
10
at box3 loc_10_10
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_10_9
at box3 loc_11_10
at box3 loc_11_6
end_variable
begin_variable
var4
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_11_10
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_2_10
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_10_10 loc_11_10 down
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_10_8 loc_10_9 right
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_10_9 loc_10_8 left
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_11_10 loc_10_10 up
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_11_10 loc_11_11 right
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_11_11 loc_11_10 left
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_2_10 loc_3_10 down
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_2_7 loc_3_7 down
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_3_10 loc_2_10 up
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_3_10 loc_3_9 left
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_3_7 loc_2_7 up
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_3_8 loc_3_9 right
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_3_9 loc_3_10 right
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_3_9 loc_3_8 left
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
60
28
8
6
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
3
1 5
2 7
3 5
end_goal
286
begin_operator
move loc_10_10 loc_10_9 left
2
11 0
69 0
1
0 0 0 7
1
end_operator
begin_operator
move loc_10_10 loc_11_10 down
2
12 0
70 0
1
0 0 0 8
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
63 0
71 0
1
0 0 0 59
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
6 0
72 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
14 0
73 0
1
0 0 1 10
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
5 0
74 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
7 0
75 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
6 0
76 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
8 0
77 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
15 0
78 0
1
0 0 3 11
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
7 0
79 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
9 0
80 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
16 0
81 0
1
0 0 4 12
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
65 0
82 0
1
0 0 4 61
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
8 0
83 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
10 0
84 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
66 0
85 0
1
0 0 5 62
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
9 0
86 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_8 loc_10_9 right
2
11 0
87 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
67 0
88 0
1
0 0 6 63
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
4 0
89 0
1
0 0 7 0
1
end_operator
begin_operator
move loc_10_9 loc_10_8 left
2
10 0
90 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
68 0
91 0
1
0 0 7 64
1
end_operator
begin_operator
move loc_11_10 loc_10_10 up
2
4 0
92 0
1
0 0 8 0
1
end_operator
begin_operator
move loc_11_10 loc_11_11 right
2
13 0
93 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_11_11 loc_11_10 left
2
12 0
94 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
5 0
95 0
1
0 0 10 1
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
7 0
96 0
1
0 0 11 3
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
16 0
97 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
8 0
98 0
1
0 0 12 4
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
15 0
99 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_2_10 loc_3_10 down
2
20 0
100 0
1
0 0 13 16
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
24 0
101 0
1
0 0 14 20
1
end_operator
begin_operator
move loc_2_7 loc_3_7 down
2
26 0
102 0
1
0 0 15 22
1
end_operator
begin_operator
move loc_3_10 loc_2_10 up
2
17 0
103 0
1
0 0 16 13
1
end_operator
begin_operator
move loc_3_10 loc_3_9 left
2
28 0
104 0
1
0 0 16 24
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
29 0
105 0
1
0 0 16 25
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
22 0
106 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
31 0
107 0
1
0 0 17 27
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
21 0
108 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
23 0
109 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
32 0
110 0
1
0 0 18 28
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
22 0
111 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
24 0
112 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
33 0
113 0
1
0 0 19 29
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
18 0
114 0
1
0 0 20 14
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
23 0
115 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
25 0
116 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
34 0
117 0
1
0 0 20 30
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
24 0
118 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
26 0
119 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
35 0
120 0
1
0 0 21 31
1
end_operator
begin_operator
move loc_3_7 loc_2_7 up
2
19 0
121 0
1
0 0 22 15
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
25 0
122 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
27 0
123 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
36 0
124 0
1
0 0 22 32
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
26 0
125 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_3_8 loc_3_9 right
2
28 0
126 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
37 0
127 0
1
0 0 23 33
1
end_operator
begin_operator
move loc_3_9 loc_3_10 right
2
20 0
128 0
1
0 0 24 16
1
end_operator
begin_operator
move loc_3_9 loc_3_8 left
2
27 0
129 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
38 0
130 0
1
0 0 24 34
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
20 0
131 0
1
0 0 25 16
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
30 0
132 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
38 0
133 0
1
0 0 25 34
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
39 0
134 0
1
0 0 25 35
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
29 0
135 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
21 0
136 0
1
0 0 27 17
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
32 0
137 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
40 0
138 0
1
0 0 27 36
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
22 0
139 0
1
0 0 28 18
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
31 0
140 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
33 0
141 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
23 0
142 0
1
0 0 29 19
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
32 0
143 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
34 0
144 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
41 0
145 0
1
0 0 29 37
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
24 0
146 0
1
0 0 30 20
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
33 0
147 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
35 0
148 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
25 0
149 0
1
0 0 31 21
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
34 0
150 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
36 0
151 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
42 0
152 0
1
0 0 31 38
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
26 0
153 0
1
0 0 32 22
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
35 0
154 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
37 0
155 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
43 0
156 0
1
0 0 32 39
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
27 0
157 0
1
0 0 33 23
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
36 0
158 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
38 0
159 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
44 0
160 0
1
0 0 33 40
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
28 0
161 0
1
0 0 34 24
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
29 0
162 0
1
0 0 34 25
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
37 0
163 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
45 0
164 0
1
0 0 34 41
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
29 0
165 0
1
0 0 35 25
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
45 0
166 0
1
0 0 35 41
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
46 0
167 0
1
0 0 35 42
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
31 0
168 0
1
0 0 36 27
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
47 0
169 0
1
0 0 36 43
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
33 0
170 0
1
0 0 37 29
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
49 0
171 0
1
0 0 37 45
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
35 0
172 0
1
0 0 38 31
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
43 0
173 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
51 0
174 0
1
0 0 38 47
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
36 0
175 0
1
0 0 39 32
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
42 0
176 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
44 0
177 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
52 0
178 0
1
0 0 39 48
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
37 0
179 0
1
0 0 40 33
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
43 0
180 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
45 0
181 0
1
0 0 40 41
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
38 0
182 0
1
0 0 41 34
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
39 0
183 0
1
0 0 41 35
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
44 0
184 0
1
0 0 41 40
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
39 0
185 0
1
0 0 42 35
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
53 0
186 0
1
0 0 42 49
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
40 0
187 0
1
0 0 43 36
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
48 0
188 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
55 0
189 0
1
0 0 43 51
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
47 0
190 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
49 0
191 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
41 0
192 0
1
0 0 45 37
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
48 0
193 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
50 0
194 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
56 0
195 0
1
0 0 45 52
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
49 0
196 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
51 0
197 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
57 0
198 0
1
0 0 46 53
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
42 0
199 0
1
0 0 47 38
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
50 0
200 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
52 0
201 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
43 0
202 0
1
0 0 48 39
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
51 0
203 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
46 0
204 0
1
0 0 49 42
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
54 0
205 0
1
0 0 49 50
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
58 0
206 0
1
0 0 49 54
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
53 0
207 0
1
0 0 50 49
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
47 0
208 0
1
0 0 51 43
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
59 0
209 0
1
0 0 51 55
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
49 0
210 0
1
0 0 52 45
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
57 0
211 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
50 0
212 0
1
0 0 53 46
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
56 0
213 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
53 0
214 0
1
0 0 54 49
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
62 0
215 0
1
0 0 54 58
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
63 0
216 0
1
0 0 54 59
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
55 0
217 0
1
0 0 55 51
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
64 0
218 0
1
0 0 55 60
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
61 0
219 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
65 0
220 0
1
0 0 56 61
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
60 0
221 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
66 0
222 0
1
0 0 57 62
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
58 0
223 0
1
0 0 58 54
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
68 0
224 0
1
0 0 58 64
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
4 0
225 0
1
0 0 59 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
58 0
226 0
1
0 0 59 54
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
68 0
227 0
1
0 0 59 64
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
59 0
228 0
1
0 0 60 55
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
8 0
229 0
1
0 0 61 4
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
60 0
230 0
1
0 0 61 56
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
66 0
231 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
9 0
232 0
1
0 0 62 5
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
61 0
233 0
1
0 0 62 57
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
65 0
234 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
67 0
235 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
10 0
236 0
1
0 0 63 6
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
66 0
237 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
68 0
238 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
11 0
239 0
1
0 0 64 7
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
62 0
240 0
1
0 0 64 58
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
63 0
241 0
1
0 0 64 59
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
67 0
242 0
1
0 0 64 63
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box3
2
69 0
90 0
4
0 0 0 7
0 3 7 6
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
71 0
226 0
4
0 0 0 59
0 1 43 41
0 58 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
74 0
76 0
4
0 0 3 2
0 3 2 1
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
76 0
79 0
4
0 0 4 3
0 3 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
80 0
84 0
4
0 0 4 5
0 3 5 6
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
79 0
83 0
4
0 0 5 4
0 3 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box3
2
84 0
87 0
4
0 0 5 6
0 3 6 7
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
83 0
86 0
4
0 0 6 5
0 3 5 4
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box3
2
87 0
89 0
4
0 0 6 7
0 3 7 0
0 4 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box3
2
86 0
90 0
4
0 0 7 6
0 3 6 5
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_3_9 loc_3_8 left box1
2
104 0
129 0
4
0 0 16 24
0 1 13 12
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_3_9 loc_3_8 left box2
2
104 0
129 0
4
0 0 16 24
0 2 11 10
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box1
2
105 0
134 0
4
0 0 16 25
0 1 14 24
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
106 0
109 0
4
0 0 17 18
0 1 7 8
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box2
2
106 0
109 0
4
0 0 17 18
0 2 5 6
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box1
2
107 0
138 0
4
0 0 17 27
0 1 16 25
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
109 0
112 0
4
0 0 18 19
0 1 8 9
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
109 0
112 0
4
0 0 18 19
0 2 6 7
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
108 0
111 0
4
0 0 19 18
0 1 7 6
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box2
2
108 0
111 0
4
0 0 19 18
0 2 5 4
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
112 0
116 0
4
0 0 19 20
0 1 9 10
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
112 0
116 0
4
0 0 19 20
0 2 7 8
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
113 0
145 0
4
0 0 19 29
0 1 18 26
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
111 0
115 0
4
0 0 20 19
0 1 8 7
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
111 0
115 0
4
0 0 20 19
0 2 6 5
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
116 0
119 0
4
0 0 20 21
0 1 10 11
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
116 0
119 0
4
0 0 20 21
0 2 8 9
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
115 0
118 0
4
0 0 21 20
0 1 9 8
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
115 0
118 0
4
0 0 21 20
0 2 7 6
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
119 0
123 0
4
0 0 21 22
0 1 11 12
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box2
2
119 0
123 0
4
0 0 21 22
0 2 9 10
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
120 0
152 0
4
0 0 21 31
0 1 20 27
0 35 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
118 0
122 0
4
0 0 22 21
0 1 10 9
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
118 0
122 0
4
0 0 22 21
0 2 8 7
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box1
2
123 0
126 0
4
0 0 22 23
0 1 12 13
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box2
2
123 0
126 0
4
0 0 22 23
0 2 10 11
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
124 0
156 0
4
0 0 22 32
0 1 21 28
0 36 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
122 0
125 0
4
0 0 23 22
0 1 11 10
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box2
2
122 0
125 0
4
0 0 23 22
0 2 9 8
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_9 loc_3_10 right box1
2
126 0
128 0
4
0 0 23 24
0 1 13 5
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_9 loc_3_10 right box2
2
126 0
128 0
4
0 0 23 24
0 2 11 3
0 20 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box1
2
127 0
160 0
4
0 0 23 33
0 1 22 29
0 37 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box1
2
125 0
129 0
4
0 0 24 23
0 1 12 11
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box2
2
125 0
129 0
4
0 0 24 23
0 2 10 9
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box1
2
130 0
164 0
4
0 0 24 34
0 1 23 30
0 38 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_4_10 loc_3_10 loc_2_10 up box1
2
103 0
131 0
4
0 0 25 16
0 1 5 2
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_3_10 loc_2_10 up box2
2
103 0
131 0
4
0 0 25 16
0 2 3 0
0 17 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box1
2
133 0
163 0
4
0 0 25 34
0 1 23 22
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box1
2
134 0
167 0
4
0 0 25 35
0 1 24 31
0 39 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
137 0
141 0
4
0 0 27 28
0 1 17 18
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
138 0
169 0
4
0 0 27 36
0 1 25 32
0 40 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
141 0
144 0
4
0 0 28 29
0 1 18 19
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
140 0
143 0
4
0 0 29 28
0 1 17 16
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
144 0
148 0
4
0 0 29 30
0 1 19 20
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
145 0
171 0
4
0 0 29 37
0 1 26 34
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
114 0
146 0
4
0 0 30 20
0 1 9 3
0 18 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box2
2
114 0
146 0
4
0 0 30 20
0 2 7 1
0 18 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
143 0
147 0
4
0 0 30 29
0 1 18 17
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
148 0
151 0
4
0 0 30 31
0 1 20 21
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
147 0
150 0
4
0 0 31 30
0 1 19 18
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
151 0
155 0
4
0 0 31 32
0 1 21 22
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
152 0
174 0
4
0 0 31 38
0 1 27 36
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box1
2
121 0
153 0
4
0 0 32 22
0 1 11 4
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box2
2
121 0
153 0
4
0 0 32 22
0 2 9 2
0 19 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
150 0
154 0
4
0 0 32 31
0 1 20 19
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
155 0
159 0
4
0 0 32 33
0 1 22 23
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
156 0
178 0
4
0 0 32 39
0 1 28 37
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
154 0
158 0
4
0 0 33 32
0 1 21 20
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box1
2
159 0
162 0
4
0 0 33 34
0 1 23 14
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box1
2
132 0
162 0
4
0 0 34 25
0 1 14 15
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box1
2
158 0
163 0
4
0 0 34 33
0 1 22 21
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box1
2
131 0
165 0
4
0 0 35 25
0 1 14 5
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box1
2
166 0
184 0
4
0 0 35 41
0 1 30 29
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box1
2
167 0
186 0
4
0 0 35 42
0 1 31 38
0 46 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box1
2
136 0
168 0
4
0 0 36 27
0 1 16 6
0 21 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
169 0
189 0
4
0 0 36 43
0 1 32 39
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
142 0
170 0
4
0 0 37 29
0 1 18 8
0 23 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
171 0
195 0
4
0 0 37 45
0 1 34 40
0 49 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
149 0
172 0
4
0 0 38 31
0 1 20 10
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
173 0
177 0
4
0 0 38 39
0 1 28 29
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
153 0
175 0
4
0 0 39 32
0 1 21 11
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
177 0
181 0
4
0 0 39 40
0 1 29 30
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box1
2
157 0
179 0
4
0 0 40 33
0 1 22 12
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
176 0
180 0
4
0 0 40 39
0 1 28 27
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box1
2
181 0
183 0
4
0 0 40 41
0 1 30 24
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box1
2
161 0
182 0
4
0 0 41 34
0 1 23 13
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
180 0
184 0
4
0 0 41 40
0 1 29 28
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box1
2
165 0
185 0
4
0 0 42 35
0 1 24 14
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
186 0
206 0
4
0 0 42 49
0 1 38 41
0 53 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box1
2
168 0
187 0
4
0 0 43 36
0 1 25 16
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box1
2
188 0
191 0
4
0 0 43 44
0 1 33 34
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box1
2
189 0
209 0
4
0 0 43 51
0 1 39 42
0 55 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box1
2
191 0
194 0
4
0 0 44 45
0 1 34 35
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
170 0
192 0
4
0 0 45 37
0 1 26 18
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box1
2
190 0
193 0
4
0 0 45 44
0 1 33 32
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
194 0
197 0
4
0 0 45 46
0 1 35 36
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box1
2
193 0
196 0
4
0 0 46 45
0 1 34 33
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
197 0
201 0
4
0 0 46 47
0 1 36 37
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
172 0
199 0
4
0 0 47 38
0 1 27 20
0 35 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
196 0
200 0
4
0 0 47 46
0 1 35 34
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
175 0
202 0
4
0 0 48 39
0 1 28 21
0 36 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
200 0
203 0
4
0 0 48 47
0 1 36 35
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
185 0
204 0
4
0 0 49 42
0 1 31 24
0 39 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
206 0
216 0
4
0 0 49 54
0 1 41 43
0 58 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box1
2
209 0
218 0
4
0 0 51 55
0 1 42 44
0 59 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
192 0
210 0
4
0 0 52 45
0 1 34 26
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
204 0
214 0
4
0 0 54 49
0 1 38 31
0 46 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
216 0
225 0
4
0 0 54 59
0 1 43 0
0 4 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box1
2
70 0
225 0
4
0 0 59 0
0 1 0 1
0 4 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box3
2
70 0
225 0
4
0 0 59 0
0 3 0 8
0 4 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
214 0
226 0
4
0 0 59 54
0 1 41 38
0 53 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box3
2
81 0
229 0
4
0 0 61 4
0 3 4 9
0 8 -1 0
0 16 0 1
1
end_operator
0
