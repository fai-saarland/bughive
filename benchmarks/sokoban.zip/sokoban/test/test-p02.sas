begin_version
3
end_version
begin_metric
1
end_metric
82
begin_variable
var0
-1
21
at-robot loc_2_3
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_7
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_5
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_7_3
at-robot loc_7_4
end_variable
begin_variable
var1
-1
5
at box1 loc_2_3
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
end_variable
begin_variable
var2
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var3
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var4
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var26
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var27
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var28
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var29
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var30
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var31
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var32
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var33
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var34
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var35
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var36
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var37
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var38
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var39
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var40
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var41
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var42
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var43
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var44
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var45
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var46
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var47
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var48
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
0
begin_state
10
2
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
1
1 4
end_goal
59
begin_operator
move loc_2_3 loc_3_3 down
2
5 0
26 0
1
0 0 0 2
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
5 0
27 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
9 0
28 0
1
0 0 1 6
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
2 0
29 0
1
0 0 2 0
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
4 0
30 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
6 0
31 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
10 0
32 0
1
0 0 2 7
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
5 0
33 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
7 0
34 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
11 0
35 0
1
0 0 3 8
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
6 0
36 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
12 0
37 0
1
0 0 4 9
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
14 0
38 0
1
0 0 5 11
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
4 0
39 0
1
0 0 6 1
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
10 0
40 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
15 0
41 0
1
0 0 6 12
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
5 0
42 0
1
0 0 7 2
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
9 0
43 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
11 0
44 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
16 0
45 0
1
0 0 7 13
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
6 0
46 0
1
0 0 8 3
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
10 0
47 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
12 0
48 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
7 0
49 0
1
0 0 9 4
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
11 0
50 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
13 0
51 0
1
0 0 9 10
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
17 0
52 0
1
0 0 9 14
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
12 0
53 0
1
0 0 10 9
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
14 0
54 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
8 0
55 0
1
0 0 11 5
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
13 0
56 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
9 0
57 0
1
0 0 12 6
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
16 0
58 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
18 0
59 0
1
0 0 12 15
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
10 0
60 0
1
0 0 13 7
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
15 0
61 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
19 0
62 0
1
0 0 13 16
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
12 0
63 0
1
0 0 14 9
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
21 0
64 0
1
0 0 14 18
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
15 0
65 0
1
0 0 15 12
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
19 0
66 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
16 0
67 0
1
0 0 16 13
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
18 0
68 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
20 0
69 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
22 0
70 0
1
0 0 16 19
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
19 0
71 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
21 0
72 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
23 0
73 0
1
0 0 17 20
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
17 0
74 0
1
0 0 18 14
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
20 0
75 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
19 0
76 0
1
0 0 19 16
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
23 0
77 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
20 0
78 0
1
0 0 20 17
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
22 0
79 0
1
0 0 20 19
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
27 0
31 0
4
0 0 1 2
0 1 2 3
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
31 0
34 0
4
0 0 2 3
0 1 3 4
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
30 0
33 0
4
0 0 3 2
0 1 2 1
0 4 0 1
0 5 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
33 0
36 0
4
0 0 4 3
0 1 3 2
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box1
2
29 0
42 0
4
0 0 7 2
0 1 2 0
0 2 0 1
0 5 -1 0
1
end_operator
0
