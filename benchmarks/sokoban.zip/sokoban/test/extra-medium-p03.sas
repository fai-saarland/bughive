begin_version
3
end_version
begin_metric
1
end_metric
1102
begin_variable
var0
-1
264
at-robot loc_10_10
at-robot loc_10_12
at-robot loc_10_14
at-robot loc_10_15
at-robot loc_10_17
at-robot loc_10_19
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_9
at-robot loc_11_10
at-robot loc_11_11
at-robot loc_11_12
at-robot loc_11_13
at-robot loc_11_14
at-robot loc_11_15
at-robot loc_11_16
at-robot loc_11_17
at-robot loc_11_18
at-robot loc_11_19
at-robot loc_11_20
at-robot loc_11_3
at-robot loc_11_4
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_7
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_12_10
at-robot loc_12_11
at-robot loc_12_12
at-robot loc_12_13
at-robot loc_12_14
at-robot loc_12_15
at-robot loc_12_16
at-robot loc_12_17
at-robot loc_12_18
at-robot loc_12_19
at-robot loc_12_20
at-robot loc_12_5
at-robot loc_12_6
at-robot loc_12_7
at-robot loc_12_8
at-robot loc_12_9
at-robot loc_13_10
at-robot loc_13_11
at-robot loc_13_12
at-robot loc_13_13
at-robot loc_13_14
at-robot loc_13_15
at-robot loc_13_17
at-robot loc_13_18
at-robot loc_13_19
at-robot loc_13_20
at-robot loc_13_21
at-robot loc_13_5
at-robot loc_13_6
at-robot loc_13_7
at-robot loc_13_8
at-robot loc_13_9
at-robot loc_14_10
at-robot loc_14_11
at-robot loc_14_12
at-robot loc_14_13
at-robot loc_14_14
at-robot loc_14_15
at-robot loc_14_16
at-robot loc_14_17
at-robot loc_14_18
at-robot loc_14_19
at-robot loc_14_20
at-robot loc_14_5
at-robot loc_14_6
at-robot loc_14_7
at-robot loc_14_8
at-robot loc_14_9
at-robot loc_15_10
at-robot loc_15_11
at-robot loc_15_12
at-robot loc_15_13
at-robot loc_15_14
at-robot loc_15_15
at-robot loc_15_16
at-robot loc_15_17
at-robot loc_15_18
at-robot loc_15_19
at-robot loc_15_20
at-robot loc_15_21
at-robot loc_15_5
at-robot loc_15_6
at-robot loc_15_7
at-robot loc_15_8
at-robot loc_15_9
at-robot loc_16_10
at-robot loc_16_13
at-robot loc_16_14
at-robot loc_16_19
at-robot loc_16_20
at-robot loc_16_5
at-robot loc_16_6
at-robot loc_16_7
at-robot loc_16_8
at-robot loc_16_9
at-robot loc_17_10
at-robot loc_17_13
at-robot loc_17_14
at-robot loc_17_16
at-robot loc_17_17
at-robot loc_17_19
at-robot loc_17_20
at-robot loc_17_7
at-robot loc_17_8
at-robot loc_18_10
at-robot loc_18_11
at-robot loc_18_13
at-robot loc_18_14
at-robot loc_18_15
at-robot loc_18_16
at-robot loc_18_19
at-robot loc_18_20
at-robot loc_18_6
at-robot loc_18_7
at-robot loc_18_8
at-robot loc_18_9
at-robot loc_19_11
at-robot loc_19_12
at-robot loc_19_13
at-robot loc_19_16
at-robot loc_19_17
at-robot loc_19_19
at-robot loc_19_20
at-robot loc_19_21
at-robot loc_19_6
at-robot loc_19_7
at-robot loc_19_8
at-robot loc_19_9
at-robot loc_20_10
at-robot loc_20_11
at-robot loc_20_12
at-robot loc_20_13
at-robot loc_20_14
at-robot loc_20_15
at-robot loc_20_16
at-robot loc_20_17
at-robot loc_20_18
at-robot loc_20_19
at-robot loc_20_5
at-robot loc_20_6
at-robot loc_20_7
at-robot loc_20_8
at-robot loc_20_9
at-robot loc_21_10
at-robot loc_21_11
at-robot loc_21_12
at-robot loc_21_13
at-robot loc_21_16
at-robot loc_21_17
at-robot loc_21_18
at-robot loc_21_19
at-robot loc_21_20
at-robot loc_21_8
at-robot loc_21_9
at-robot loc_2_13
at-robot loc_2_14
at-robot loc_2_2
at-robot loc_2_21
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_5
at-robot loc_2_6
at-robot loc_2_9
at-robot loc_3_10
at-robot loc_3_11
at-robot loc_3_12
at-robot loc_3_13
at-robot loc_3_14
at-robot loc_3_15
at-robot loc_3_16
at-robot loc_3_17
at-robot loc_3_2
at-robot loc_3_20
at-robot loc_3_21
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_3_9
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_12
at-robot loc_4_13
at-robot loc_4_14
at-robot loc_4_17
at-robot loc_4_2
at-robot loc_4_20
at-robot loc_4_21
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_12
at-robot loc_5_14
at-robot loc_5_16
at-robot loc_5_17
at-robot loc_5_18
at-robot loc_5_19
at-robot loc_5_2
at-robot loc_5_20
at-robot loc_5_21
at-robot loc_5_3
at-robot loc_5_9
at-robot loc_6_11
at-robot loc_6_12
at-robot loc_6_13
at-robot loc_6_14
at-robot loc_6_16
at-robot loc_6_17
at-robot loc_6_18
at-robot loc_6_20
at-robot loc_6_21
at-robot loc_6_3
at-robot loc_6_8
at-robot loc_6_9
at-robot loc_7_14
at-robot loc_7_15
at-robot loc_7_18
at-robot loc_7_19
at-robot loc_7_21
at-robot loc_7_3
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_14
at-robot loc_8_15
at-robot loc_8_16
at-robot loc_8_17
at-robot loc_8_18
at-robot loc_8_2
at-robot loc_8_20
at-robot loc_8_21
at-robot loc_8_3
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_15
at-robot loc_9_16
at-robot loc_9_17
at-robot loc_9_18
at-robot loc_9_19
at-robot loc_9_2
at-robot loc_9_20
at-robot loc_9_21
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
end_variable
begin_variable
var1
-1
198
at box1 loc_10_10
at box1 loc_10_12
at box1 loc_10_14
at box1 loc_10_15
at box1 loc_10_17
at box1 loc_10_19
at box1 loc_10_5
at box1 loc_10_9
at box1 loc_11_10
at box1 loc_11_11
at box1 loc_11_12
at box1 loc_11_13
at box1 loc_11_14
at box1 loc_11_15
at box1 loc_11_16
at box1 loc_11_17
at box1 loc_11_18
at box1 loc_11_19
at box1 loc_11_20
at box1 loc_11_3
at box1 loc_11_4
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_7
at box1 loc_11_8
at box1 loc_11_9
at box1 loc_12_10
at box1 loc_12_11
at box1 loc_12_12
at box1 loc_12_13
at box1 loc_12_14
at box1 loc_12_15
at box1 loc_12_16
at box1 loc_12_17
at box1 loc_12_18
at box1 loc_12_19
at box1 loc_12_20
at box1 loc_12_5
at box1 loc_12_6
at box1 loc_12_7
at box1 loc_12_8
at box1 loc_12_9
at box1 loc_13_10
at box1 loc_13_11
at box1 loc_13_12
at box1 loc_13_13
at box1 loc_13_14
at box1 loc_13_15
at box1 loc_13_17
at box1 loc_13_18
at box1 loc_13_19
at box1 loc_13_20
at box1 loc_13_21
at box1 loc_13_5
at box1 loc_13_6
at box1 loc_13_7
at box1 loc_13_8
at box1 loc_13_9
at box1 loc_14_10
at box1 loc_14_11
at box1 loc_14_12
at box1 loc_14_13
at box1 loc_14_14
at box1 loc_14_15
at box1 loc_14_16
at box1 loc_14_17
at box1 loc_14_18
at box1 loc_14_19
at box1 loc_14_20
at box1 loc_14_5
at box1 loc_14_6
at box1 loc_14_7
at box1 loc_14_8
at box1 loc_14_9
at box1 loc_15_10
at box1 loc_15_11
at box1 loc_15_12
at box1 loc_15_13
at box1 loc_15_14
at box1 loc_15_15
at box1 loc_15_16
at box1 loc_15_17
at box1 loc_15_18
at box1 loc_15_19
at box1 loc_15_20
at box1 loc_15_21
at box1 loc_15_5
at box1 loc_15_6
at box1 loc_15_7
at box1 loc_15_8
at box1 loc_15_9
at box1 loc_16_10
at box1 loc_16_13
at box1 loc_16_14
at box1 loc_16_19
at box1 loc_16_20
at box1 loc_16_5
at box1 loc_16_6
at box1 loc_16_7
at box1 loc_16_8
at box1 loc_16_9
at box1 loc_17_10
at box1 loc_17_13
at box1 loc_17_14
at box1 loc_17_16
at box1 loc_17_19
at box1 loc_17_20
at box1 loc_17_7
at box1 loc_17_8
at box1 loc_18_10
at box1 loc_18_11
at box1 loc_18_13
at box1 loc_18_14
at box1 loc_18_15
at box1 loc_18_16
at box1 loc_18_19
at box1 loc_18_20
at box1 loc_18_6
at box1 loc_18_7
at box1 loc_18_8
at box1 loc_18_9
at box1 loc_19_11
at box1 loc_19_12
at box1 loc_19_13
at box1 loc_19_16
at box1 loc_19_17
at box1 loc_19_19
at box1 loc_19_20
at box1 loc_19_21
at box1 loc_19_6
at box1 loc_19_7
at box1 loc_19_8
at box1 loc_19_9
at box1 loc_20_10
at box1 loc_20_11
at box1 loc_20_12
at box1 loc_20_13
at box1 loc_20_14
at box1 loc_20_15
at box1 loc_20_16
at box1 loc_20_17
at box1 loc_20_18
at box1 loc_20_19
at box1 loc_20_5
at box1 loc_20_6
at box1 loc_20_7
at box1 loc_20_8
at box1 loc_20_9
at box1 loc_21_10
at box1 loc_21_11
at box1 loc_21_12
at box1 loc_21_13
at box1 loc_21_16
at box1 loc_21_17
at box1 loc_21_18
at box1 loc_21_19
at box1 loc_21_20
at box1 loc_21_8
at box1 loc_21_9
at box1 loc_2_21
at box1 loc_3_17
at box1 loc_3_20
at box1 loc_3_21
at box1 loc_4_17
at box1 loc_4_20
at box1 loc_4_21
at box1 loc_5_16
at box1 loc_5_17
at box1 loc_5_18
at box1 loc_5_19
at box1 loc_5_20
at box1 loc_5_21
at box1 loc_6_16
at box1 loc_6_17
at box1 loc_6_18
at box1 loc_6_20
at box1 loc_6_21
at box1 loc_7_15
at box1 loc_7_18
at box1 loc_7_21
at box1 loc_7_5
at box1 loc_8_10
at box1 loc_8_14
at box1 loc_8_15
at box1 loc_8_16
at box1 loc_8_17
at box1 loc_8_18
at box1 loc_8_21
at box1 loc_8_5
at box1 loc_9_10
at box1 loc_9_15
at box1 loc_9_16
at box1 loc_9_17
at box1 loc_9_18
at box1 loc_9_19
at box1 loc_9_20
at box1 loc_9_21
at box1 loc_9_5
end_variable
begin_variable
var2
-1
198
at box6 loc_10_10
at box6 loc_10_12
at box6 loc_10_14
at box6 loc_10_15
at box6 loc_10_17
at box6 loc_10_19
at box6 loc_10_5
at box6 loc_10_9
at box6 loc_11_10
at box6 loc_11_11
at box6 loc_11_12
at box6 loc_11_13
at box6 loc_11_14
at box6 loc_11_15
at box6 loc_11_16
at box6 loc_11_17
at box6 loc_11_18
at box6 loc_11_19
at box6 loc_11_20
at box6 loc_11_3
at box6 loc_11_4
at box6 loc_11_5
at box6 loc_11_6
at box6 loc_11_7
at box6 loc_11_8
at box6 loc_11_9
at box6 loc_12_10
at box6 loc_12_11
at box6 loc_12_12
at box6 loc_12_13
at box6 loc_12_14
at box6 loc_12_15
at box6 loc_12_16
at box6 loc_12_17
at box6 loc_12_18
at box6 loc_12_19
at box6 loc_12_20
at box6 loc_12_5
at box6 loc_12_6
at box6 loc_12_7
at box6 loc_12_8
at box6 loc_12_9
at box6 loc_13_10
at box6 loc_13_11
at box6 loc_13_12
at box6 loc_13_13
at box6 loc_13_14
at box6 loc_13_15
at box6 loc_13_17
at box6 loc_13_18
at box6 loc_13_19
at box6 loc_13_20
at box6 loc_13_21
at box6 loc_13_5
at box6 loc_13_6
at box6 loc_13_7
at box6 loc_13_8
at box6 loc_13_9
at box6 loc_14_10
at box6 loc_14_11
at box6 loc_14_12
at box6 loc_14_13
at box6 loc_14_14
at box6 loc_14_15
at box6 loc_14_16
at box6 loc_14_17
at box6 loc_14_18
at box6 loc_14_19
at box6 loc_14_20
at box6 loc_14_5
at box6 loc_14_6
at box6 loc_14_7
at box6 loc_14_8
at box6 loc_14_9
at box6 loc_15_10
at box6 loc_15_11
at box6 loc_15_12
at box6 loc_15_13
at box6 loc_15_14
at box6 loc_15_15
at box6 loc_15_16
at box6 loc_15_17
at box6 loc_15_18
at box6 loc_15_19
at box6 loc_15_20
at box6 loc_15_21
at box6 loc_15_5
at box6 loc_15_6
at box6 loc_15_7
at box6 loc_15_8
at box6 loc_15_9
at box6 loc_16_10
at box6 loc_16_13
at box6 loc_16_14
at box6 loc_16_19
at box6 loc_16_20
at box6 loc_16_5
at box6 loc_16_6
at box6 loc_16_7
at box6 loc_16_8
at box6 loc_16_9
at box6 loc_17_10
at box6 loc_17_13
at box6 loc_17_14
at box6 loc_17_16
at box6 loc_17_19
at box6 loc_17_20
at box6 loc_17_7
at box6 loc_17_8
at box6 loc_18_10
at box6 loc_18_11
at box6 loc_18_13
at box6 loc_18_14
at box6 loc_18_15
at box6 loc_18_16
at box6 loc_18_19
at box6 loc_18_20
at box6 loc_18_6
at box6 loc_18_7
at box6 loc_18_8
at box6 loc_18_9
at box6 loc_19_11
at box6 loc_19_12
at box6 loc_19_13
at box6 loc_19_16
at box6 loc_19_17
at box6 loc_19_19
at box6 loc_19_20
at box6 loc_19_21
at box6 loc_19_6
at box6 loc_19_7
at box6 loc_19_8
at box6 loc_19_9
at box6 loc_20_10
at box6 loc_20_11
at box6 loc_20_12
at box6 loc_20_13
at box6 loc_20_14
at box6 loc_20_15
at box6 loc_20_16
at box6 loc_20_17
at box6 loc_20_18
at box6 loc_20_19
at box6 loc_20_5
at box6 loc_20_6
at box6 loc_20_7
at box6 loc_20_8
at box6 loc_20_9
at box6 loc_21_10
at box6 loc_21_11
at box6 loc_21_12
at box6 loc_21_13
at box6 loc_21_16
at box6 loc_21_17
at box6 loc_21_18
at box6 loc_21_19
at box6 loc_21_20
at box6 loc_21_8
at box6 loc_21_9
at box6 loc_2_21
at box6 loc_3_17
at box6 loc_3_20
at box6 loc_3_21
at box6 loc_4_17
at box6 loc_4_20
at box6 loc_4_21
at box6 loc_5_16
at box6 loc_5_17
at box6 loc_5_18
at box6 loc_5_19
at box6 loc_5_20
at box6 loc_5_21
at box6 loc_6_16
at box6 loc_6_17
at box6 loc_6_18
at box6 loc_6_20
at box6 loc_6_21
at box6 loc_7_15
at box6 loc_7_18
at box6 loc_7_21
at box6 loc_7_5
at box6 loc_8_10
at box6 loc_8_14
at box6 loc_8_15
at box6 loc_8_16
at box6 loc_8_17
at box6 loc_8_18
at box6 loc_8_21
at box6 loc_8_5
at box6 loc_9_10
at box6 loc_9_15
at box6 loc_9_16
at box6 loc_9_17
at box6 loc_9_18
at box6 loc_9_19
at box6 loc_9_20
at box6 loc_9_21
at box6 loc_9_5
end_variable
begin_variable
var3
-1
198
at box4 loc_10_10
at box4 loc_10_12
at box4 loc_10_14
at box4 loc_10_15
at box4 loc_10_17
at box4 loc_10_19
at box4 loc_10_5
at box4 loc_10_9
at box4 loc_11_10
at box4 loc_11_11
at box4 loc_11_12
at box4 loc_11_13
at box4 loc_11_14
at box4 loc_11_15
at box4 loc_11_16
at box4 loc_11_17
at box4 loc_11_18
at box4 loc_11_19
at box4 loc_11_20
at box4 loc_11_3
at box4 loc_11_4
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_7
at box4 loc_11_8
at box4 loc_11_9
at box4 loc_12_10
at box4 loc_12_11
at box4 loc_12_12
at box4 loc_12_13
at box4 loc_12_14
at box4 loc_12_15
at box4 loc_12_16
at box4 loc_12_17
at box4 loc_12_18
at box4 loc_12_19
at box4 loc_12_20
at box4 loc_12_5
at box4 loc_12_6
at box4 loc_12_7
at box4 loc_12_8
at box4 loc_12_9
at box4 loc_13_10
at box4 loc_13_11
at box4 loc_13_12
at box4 loc_13_13
at box4 loc_13_14
at box4 loc_13_15
at box4 loc_13_17
at box4 loc_13_18
at box4 loc_13_19
at box4 loc_13_20
at box4 loc_13_21
at box4 loc_13_5
at box4 loc_13_6
at box4 loc_13_7
at box4 loc_13_8
at box4 loc_13_9
at box4 loc_14_10
at box4 loc_14_11
at box4 loc_14_12
at box4 loc_14_13
at box4 loc_14_14
at box4 loc_14_15
at box4 loc_14_16
at box4 loc_14_17
at box4 loc_14_18
at box4 loc_14_19
at box4 loc_14_20
at box4 loc_14_5
at box4 loc_14_6
at box4 loc_14_7
at box4 loc_14_8
at box4 loc_14_9
at box4 loc_15_10
at box4 loc_15_11
at box4 loc_15_12
at box4 loc_15_13
at box4 loc_15_14
at box4 loc_15_15
at box4 loc_15_16
at box4 loc_15_17
at box4 loc_15_18
at box4 loc_15_19
at box4 loc_15_20
at box4 loc_15_21
at box4 loc_15_5
at box4 loc_15_6
at box4 loc_15_7
at box4 loc_15_8
at box4 loc_15_9
at box4 loc_16_10
at box4 loc_16_13
at box4 loc_16_14
at box4 loc_16_19
at box4 loc_16_20
at box4 loc_16_5
at box4 loc_16_6
at box4 loc_16_7
at box4 loc_16_8
at box4 loc_16_9
at box4 loc_17_10
at box4 loc_17_13
at box4 loc_17_14
at box4 loc_17_16
at box4 loc_17_19
at box4 loc_17_20
at box4 loc_17_7
at box4 loc_17_8
at box4 loc_18_10
at box4 loc_18_11
at box4 loc_18_13
at box4 loc_18_14
at box4 loc_18_15
at box4 loc_18_16
at box4 loc_18_19
at box4 loc_18_20
at box4 loc_18_6
at box4 loc_18_7
at box4 loc_18_8
at box4 loc_18_9
at box4 loc_19_11
at box4 loc_19_12
at box4 loc_19_13
at box4 loc_19_16
at box4 loc_19_17
at box4 loc_19_19
at box4 loc_19_20
at box4 loc_19_21
at box4 loc_19_6
at box4 loc_19_7
at box4 loc_19_8
at box4 loc_19_9
at box4 loc_20_10
at box4 loc_20_11
at box4 loc_20_12
at box4 loc_20_13
at box4 loc_20_14
at box4 loc_20_15
at box4 loc_20_16
at box4 loc_20_17
at box4 loc_20_18
at box4 loc_20_19
at box4 loc_20_5
at box4 loc_20_6
at box4 loc_20_7
at box4 loc_20_8
at box4 loc_20_9
at box4 loc_21_10
at box4 loc_21_11
at box4 loc_21_12
at box4 loc_21_13
at box4 loc_21_16
at box4 loc_21_17
at box4 loc_21_18
at box4 loc_21_19
at box4 loc_21_20
at box4 loc_21_8
at box4 loc_21_9
at box4 loc_2_21
at box4 loc_3_17
at box4 loc_3_20
at box4 loc_3_21
at box4 loc_4_17
at box4 loc_4_20
at box4 loc_4_21
at box4 loc_5_16
at box4 loc_5_17
at box4 loc_5_18
at box4 loc_5_19
at box4 loc_5_20
at box4 loc_5_21
at box4 loc_6_16
at box4 loc_6_17
at box4 loc_6_18
at box4 loc_6_20
at box4 loc_6_21
at box4 loc_7_15
at box4 loc_7_18
at box4 loc_7_21
at box4 loc_7_5
at box4 loc_8_10
at box4 loc_8_14
at box4 loc_8_15
at box4 loc_8_16
at box4 loc_8_17
at box4 loc_8_18
at box4 loc_8_21
at box4 loc_8_5
at box4 loc_9_10
at box4 loc_9_15
at box4 loc_9_16
at box4 loc_9_17
at box4 loc_9_18
at box4 loc_9_19
at box4 loc_9_20
at box4 loc_9_21
at box4 loc_9_5
end_variable
begin_variable
var4
-1
198
at box3 loc_10_10
at box3 loc_10_12
at box3 loc_10_14
at box3 loc_10_15
at box3 loc_10_17
at box3 loc_10_19
at box3 loc_10_5
at box3 loc_10_9
at box3 loc_11_10
at box3 loc_11_11
at box3 loc_11_12
at box3 loc_11_13
at box3 loc_11_14
at box3 loc_11_15
at box3 loc_11_16
at box3 loc_11_17
at box3 loc_11_18
at box3 loc_11_19
at box3 loc_11_20
at box3 loc_11_3
at box3 loc_11_4
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_7
at box3 loc_11_8
at box3 loc_11_9
at box3 loc_12_10
at box3 loc_12_11
at box3 loc_12_12
at box3 loc_12_13
at box3 loc_12_14
at box3 loc_12_15
at box3 loc_12_16
at box3 loc_12_17
at box3 loc_12_18
at box3 loc_12_19
at box3 loc_12_20
at box3 loc_12_5
at box3 loc_12_6
at box3 loc_12_7
at box3 loc_12_8
at box3 loc_12_9
at box3 loc_13_10
at box3 loc_13_11
at box3 loc_13_12
at box3 loc_13_13
at box3 loc_13_14
at box3 loc_13_15
at box3 loc_13_17
at box3 loc_13_18
at box3 loc_13_19
at box3 loc_13_20
at box3 loc_13_21
at box3 loc_13_5
at box3 loc_13_6
at box3 loc_13_7
at box3 loc_13_8
at box3 loc_13_9
at box3 loc_14_10
at box3 loc_14_11
at box3 loc_14_12
at box3 loc_14_13
at box3 loc_14_14
at box3 loc_14_15
at box3 loc_14_16
at box3 loc_14_17
at box3 loc_14_18
at box3 loc_14_19
at box3 loc_14_20
at box3 loc_14_5
at box3 loc_14_6
at box3 loc_14_7
at box3 loc_14_8
at box3 loc_14_9
at box3 loc_15_10
at box3 loc_15_11
at box3 loc_15_12
at box3 loc_15_13
at box3 loc_15_14
at box3 loc_15_15
at box3 loc_15_16
at box3 loc_15_17
at box3 loc_15_18
at box3 loc_15_19
at box3 loc_15_20
at box3 loc_15_21
at box3 loc_15_5
at box3 loc_15_6
at box3 loc_15_7
at box3 loc_15_8
at box3 loc_15_9
at box3 loc_16_10
at box3 loc_16_13
at box3 loc_16_14
at box3 loc_16_19
at box3 loc_16_20
at box3 loc_16_5
at box3 loc_16_6
at box3 loc_16_7
at box3 loc_16_8
at box3 loc_16_9
at box3 loc_17_10
at box3 loc_17_13
at box3 loc_17_14
at box3 loc_17_16
at box3 loc_17_19
at box3 loc_17_20
at box3 loc_17_7
at box3 loc_17_8
at box3 loc_18_10
at box3 loc_18_11
at box3 loc_18_13
at box3 loc_18_14
at box3 loc_18_15
at box3 loc_18_16
at box3 loc_18_19
at box3 loc_18_20
at box3 loc_18_6
at box3 loc_18_7
at box3 loc_18_8
at box3 loc_18_9
at box3 loc_19_11
at box3 loc_19_12
at box3 loc_19_13
at box3 loc_19_16
at box3 loc_19_17
at box3 loc_19_19
at box3 loc_19_20
at box3 loc_19_21
at box3 loc_19_6
at box3 loc_19_7
at box3 loc_19_8
at box3 loc_19_9
at box3 loc_20_10
at box3 loc_20_11
at box3 loc_20_12
at box3 loc_20_13
at box3 loc_20_14
at box3 loc_20_15
at box3 loc_20_16
at box3 loc_20_17
at box3 loc_20_18
at box3 loc_20_19
at box3 loc_20_5
at box3 loc_20_6
at box3 loc_20_7
at box3 loc_20_8
at box3 loc_20_9
at box3 loc_21_10
at box3 loc_21_11
at box3 loc_21_12
at box3 loc_21_13
at box3 loc_21_16
at box3 loc_21_17
at box3 loc_21_18
at box3 loc_21_19
at box3 loc_21_20
at box3 loc_21_8
at box3 loc_21_9
at box3 loc_2_21
at box3 loc_3_17
at box3 loc_3_20
at box3 loc_3_21
at box3 loc_4_17
at box3 loc_4_20
at box3 loc_4_21
at box3 loc_5_16
at box3 loc_5_17
at box3 loc_5_18
at box3 loc_5_19
at box3 loc_5_20
at box3 loc_5_21
at box3 loc_6_16
at box3 loc_6_17
at box3 loc_6_18
at box3 loc_6_20
at box3 loc_6_21
at box3 loc_7_15
at box3 loc_7_18
at box3 loc_7_21
at box3 loc_7_5
at box3 loc_8_10
at box3 loc_8_14
at box3 loc_8_15
at box3 loc_8_16
at box3 loc_8_17
at box3 loc_8_18
at box3 loc_8_21
at box3 loc_8_5
at box3 loc_9_10
at box3 loc_9_15
at box3 loc_9_16
at box3 loc_9_17
at box3 loc_9_18
at box3 loc_9_19
at box3 loc_9_20
at box3 loc_9_21
at box3 loc_9_5
end_variable
begin_variable
var5
-1
198
at box2 loc_10_10
at box2 loc_10_12
at box2 loc_10_14
at box2 loc_10_15
at box2 loc_10_17
at box2 loc_10_19
at box2 loc_10_5
at box2 loc_10_9
at box2 loc_11_10
at box2 loc_11_11
at box2 loc_11_12
at box2 loc_11_13
at box2 loc_11_14
at box2 loc_11_15
at box2 loc_11_16
at box2 loc_11_17
at box2 loc_11_18
at box2 loc_11_19
at box2 loc_11_20
at box2 loc_11_3
at box2 loc_11_4
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_7
at box2 loc_11_8
at box2 loc_11_9
at box2 loc_12_10
at box2 loc_12_11
at box2 loc_12_12
at box2 loc_12_13
at box2 loc_12_14
at box2 loc_12_15
at box2 loc_12_16
at box2 loc_12_17
at box2 loc_12_18
at box2 loc_12_19
at box2 loc_12_20
at box2 loc_12_5
at box2 loc_12_6
at box2 loc_12_7
at box2 loc_12_8
at box2 loc_12_9
at box2 loc_13_10
at box2 loc_13_11
at box2 loc_13_12
at box2 loc_13_13
at box2 loc_13_14
at box2 loc_13_15
at box2 loc_13_17
at box2 loc_13_18
at box2 loc_13_19
at box2 loc_13_20
at box2 loc_13_21
at box2 loc_13_5
at box2 loc_13_6
at box2 loc_13_7
at box2 loc_13_8
at box2 loc_13_9
at box2 loc_14_10
at box2 loc_14_11
at box2 loc_14_12
at box2 loc_14_13
at box2 loc_14_14
at box2 loc_14_15
at box2 loc_14_16
at box2 loc_14_17
at box2 loc_14_18
at box2 loc_14_19
at box2 loc_14_20
at box2 loc_14_5
at box2 loc_14_6
at box2 loc_14_7
at box2 loc_14_8
at box2 loc_14_9
at box2 loc_15_10
at box2 loc_15_11
at box2 loc_15_12
at box2 loc_15_13
at box2 loc_15_14
at box2 loc_15_15
at box2 loc_15_16
at box2 loc_15_17
at box2 loc_15_18
at box2 loc_15_19
at box2 loc_15_20
at box2 loc_15_21
at box2 loc_15_5
at box2 loc_15_6
at box2 loc_15_7
at box2 loc_15_8
at box2 loc_15_9
at box2 loc_16_10
at box2 loc_16_13
at box2 loc_16_14
at box2 loc_16_19
at box2 loc_16_20
at box2 loc_16_5
at box2 loc_16_6
at box2 loc_16_7
at box2 loc_16_8
at box2 loc_16_9
at box2 loc_17_10
at box2 loc_17_13
at box2 loc_17_14
at box2 loc_17_16
at box2 loc_17_19
at box2 loc_17_20
at box2 loc_17_7
at box2 loc_17_8
at box2 loc_18_10
at box2 loc_18_11
at box2 loc_18_13
at box2 loc_18_14
at box2 loc_18_15
at box2 loc_18_16
at box2 loc_18_19
at box2 loc_18_20
at box2 loc_18_6
at box2 loc_18_7
at box2 loc_18_8
at box2 loc_18_9
at box2 loc_19_11
at box2 loc_19_12
at box2 loc_19_13
at box2 loc_19_16
at box2 loc_19_17
at box2 loc_19_19
at box2 loc_19_20
at box2 loc_19_21
at box2 loc_19_6
at box2 loc_19_7
at box2 loc_19_8
at box2 loc_19_9
at box2 loc_20_10
at box2 loc_20_11
at box2 loc_20_12
at box2 loc_20_13
at box2 loc_20_14
at box2 loc_20_15
at box2 loc_20_16
at box2 loc_20_17
at box2 loc_20_18
at box2 loc_20_19
at box2 loc_20_5
at box2 loc_20_6
at box2 loc_20_7
at box2 loc_20_8
at box2 loc_20_9
at box2 loc_21_10
at box2 loc_21_11
at box2 loc_21_12
at box2 loc_21_13
at box2 loc_21_16
at box2 loc_21_17
at box2 loc_21_18
at box2 loc_21_19
at box2 loc_21_20
at box2 loc_21_8
at box2 loc_21_9
at box2 loc_2_21
at box2 loc_3_17
at box2 loc_3_20
at box2 loc_3_21
at box2 loc_4_17
at box2 loc_4_20
at box2 loc_4_21
at box2 loc_5_16
at box2 loc_5_17
at box2 loc_5_18
at box2 loc_5_19
at box2 loc_5_20
at box2 loc_5_21
at box2 loc_6_16
at box2 loc_6_17
at box2 loc_6_18
at box2 loc_6_20
at box2 loc_6_21
at box2 loc_7_15
at box2 loc_7_18
at box2 loc_7_21
at box2 loc_7_5
at box2 loc_8_10
at box2 loc_8_14
at box2 loc_8_15
at box2 loc_8_16
at box2 loc_8_17
at box2 loc_8_18
at box2 loc_8_21
at box2 loc_8_5
at box2 loc_9_10
at box2 loc_9_15
at box2 loc_9_16
at box2 loc_9_17
at box2 loc_9_18
at box2 loc_9_19
at box2 loc_9_20
at box2 loc_9_21
at box2 loc_9_5
end_variable
begin_variable
var6
-1
60
at box7 loc_10_3
at box7 loc_11_3
at box7 loc_2_13
at box7 loc_2_14
at box7 loc_2_2
at box7 loc_2_3
at box7 loc_2_4
at box7 loc_2_5
at box7 loc_2_6
at box7 loc_2_9
at box7 loc_3_10
at box7 loc_3_11
at box7 loc_3_12
at box7 loc_3_13
at box7 loc_3_14
at box7 loc_3_15
at box7 loc_3_16
at box7 loc_3_17
at box7 loc_3_2
at box7 loc_3_3
at box7 loc_3_4
at box7 loc_3_5
at box7 loc_3_6
at box7 loc_3_7
at box7 loc_3_8
at box7 loc_3_9
at box7 loc_4_10
at box7 loc_4_11
at box7 loc_4_12
at box7 loc_4_13
at box7 loc_4_14
at box7 loc_4_2
at box7 loc_4_3
at box7 loc_4_4
at box7 loc_4_8
at box7 loc_4_9
at box7 loc_5_10
at box7 loc_5_11
at box7 loc_5_12
at box7 loc_5_14
at box7 loc_5_2
at box7 loc_5_3
at box7 loc_5_9
at box7 loc_6_11
at box7 loc_6_12
at box7 loc_6_13
at box7 loc_6_14
at box7 loc_6_3
at box7 loc_6_9
at box7 loc_7_14
at box7 loc_7_3
at box7 loc_7_5
at box7 loc_7_9
at box7 loc_8_14
at box7 loc_8_3
at box7 loc_8_5
at box7 loc_9_2
at box7 loc_9_3
at box7 loc_9_4
at box7 loc_9_5
end_variable
begin_variable
var7
-1
12
at box5 loc_11_20
at box5 loc_12_20
at box5 loc_13_20
at box5 loc_13_21
at box5 loc_14_20
at box5 loc_15_20
at box5 loc_15_21
at box5 loc_16_20
at box5 loc_17_20
at box5 loc_18_20
at box5 loc_19_20
at box5 loc_19_21
end_variable
begin_variable
var8
-1
2
clear loc_21_12
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_21_13
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_21_16
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_21_17
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_21_18
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_21_19
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_21_20
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_21_4
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_21_8
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_21_9
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_2_13
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_2_14
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_2_18
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_2_19
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_2_2
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_2_21
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_2_9
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_3_12
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_3_13
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_3_14
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_3_15
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_3_16
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_3_17
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_3_20
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_3_21
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_4_13
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_4_14
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_4_17
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_4_20
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_4_21
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_5_12
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_5_14
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_5_16
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_5_17
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_5_18
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_5_19
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_5_20
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_5_21
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_6_12
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_6_13
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_6_14
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_6_16
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_6_17
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_6_18
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_6_20
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_6_21
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_7_14
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_7_15
none-of-those
end_variable
begin_variable
var88
-1
2
clear loc_7_18
none-of-those
end_variable
begin_variable
var89
-1
2
clear loc_7_19
none-of-those
end_variable
begin_variable
var90
-1
2
clear loc_7_21
none-of-those
end_variable
begin_variable
var91
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var92
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var93
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var94
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var95
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var96
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var97
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var98
-1
2
clear loc_8_14
none-of-those
end_variable
begin_variable
var99
-1
2
clear loc_8_15
none-of-those
end_variable
begin_variable
var100
-1
2
clear loc_8_16
none-of-those
end_variable
begin_variable
var101
-1
2
clear loc_8_17
none-of-those
end_variable
begin_variable
var102
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var103
-1
2
clear loc_8_18
none-of-those
end_variable
begin_variable
var104
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var105
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var106
-1
2
clear loc_10_14
none-of-those
end_variable
begin_variable
var107
-1
2
clear loc_8_20
none-of-those
end_variable
begin_variable
var108
-1
2
clear loc_10_15
none-of-those
end_variable
begin_variable
var109
-1
2
clear loc_8_21
none-of-those
end_variable
begin_variable
var110
-1
2
clear loc_10_17
none-of-those
end_variable
begin_variable
var111
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var112
-1
2
clear loc_10_19
none-of-those
end_variable
begin_variable
var113
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var114
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var115
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var116
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var117
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var118
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var119
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var120
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var121
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var122
-1
2
clear loc_11_10
none-of-those
end_variable
begin_variable
var123
-1
2
clear loc_9_13
none-of-those
end_variable
begin_variable
var124
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var125
-1
2
clear loc_9_15
none-of-those
end_variable
begin_variable
var126
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var127
-1
2
clear loc_9_16
none-of-those
end_variable
begin_variable
var128
-1
2
clear loc_11_13
none-of-those
end_variable
begin_variable
var129
-1
2
clear loc_9_17
none-of-those
end_variable
begin_variable
var130
-1
2
clear loc_11_14
none-of-those
end_variable
begin_variable
var131
-1
2
clear loc_9_18
none-of-those
end_variable
begin_variable
var132
-1
2
clear loc_11_15
none-of-those
end_variable
begin_variable
var133
-1
2
clear loc_9_19
none-of-those
end_variable
begin_variable
var134
-1
2
clear loc_11_16
none-of-those
end_variable
begin_variable
var135
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var136
-1
2
clear loc_11_17
none-of-those
end_variable
begin_variable
var137
-1
2
clear loc_9_20
none-of-those
end_variable
begin_variable
var138
-1
2
clear loc_11_18
none-of-those
end_variable
begin_variable
var139
-1
2
clear loc_9_21
none-of-those
end_variable
begin_variable
var140
-1
2
clear loc_11_19
none-of-those
end_variable
begin_variable
var141
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var142
-1
2
clear loc_11_20
none-of-those
end_variable
begin_variable
var143
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var144
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var145
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var146
-1
2
clear loc_11_4
none-of-those
end_variable
begin_variable
var147
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var148
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var149
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var150
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var151
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var152
-1
2
clear loc_12_10
none-of-those
end_variable
begin_variable
var153
-1
2
clear loc_12_11
none-of-those
end_variable
begin_variable
var154
-1
2
clear loc_12_12
none-of-those
end_variable
begin_variable
var155
-1
2
clear loc_12_13
none-of-those
end_variable
begin_variable
var156
-1
2
clear loc_12_14
none-of-those
end_variable
begin_variable
var157
-1
2
clear loc_12_15
none-of-those
end_variable
begin_variable
var158
-1
2
clear loc_12_16
none-of-those
end_variable
begin_variable
var159
-1
2
clear loc_12_17
none-of-those
end_variable
begin_variable
var160
-1
2
clear loc_12_18
none-of-those
end_variable
begin_variable
var161
-1
2
clear loc_12_19
none-of-those
end_variable
begin_variable
var162
-1
2
clear loc_12_2
none-of-those
end_variable
begin_variable
var163
-1
2
clear loc_12_20
none-of-those
end_variable
begin_variable
var164
-1
2
clear loc_12_5
none-of-those
end_variable
begin_variable
var165
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var166
-1
2
clear loc_12_7
none-of-those
end_variable
begin_variable
var167
-1
2
clear loc_12_8
none-of-those
end_variable
begin_variable
var168
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var169
-1
2
clear loc_13_10
none-of-those
end_variable
begin_variable
var170
-1
2
clear loc_13_11
none-of-those
end_variable
begin_variable
var171
-1
2
clear loc_13_12
none-of-those
end_variable
begin_variable
var172
-1
2
clear loc_13_13
none-of-those
end_variable
begin_variable
var173
-1
2
clear loc_13_14
none-of-those
end_variable
begin_variable
var174
-1
2
clear loc_13_15
none-of-those
end_variable
begin_variable
var175
-1
2
clear loc_13_17
none-of-those
end_variable
begin_variable
var176
-1
2
clear loc_13_18
none-of-those
end_variable
begin_variable
var177
-1
2
clear loc_13_19
none-of-those
end_variable
begin_variable
var178
-1
2
clear loc_13_20
none-of-those
end_variable
begin_variable
var179
-1
2
clear loc_13_21
none-of-those
end_variable
begin_variable
var180
-1
2
clear loc_13_5
none-of-those
end_variable
begin_variable
var181
-1
2
clear loc_13_6
none-of-those
end_variable
begin_variable
var182
-1
2
clear loc_13_7
none-of-those
end_variable
begin_variable
var183
-1
2
clear loc_13_8
none-of-those
end_variable
begin_variable
var184
-1
2
clear loc_13_9
none-of-those
end_variable
begin_variable
var185
-1
2
clear loc_14_10
none-of-those
end_variable
begin_variable
var186
-1
2
clear loc_14_11
none-of-those
end_variable
begin_variable
var187
-1
2
clear loc_14_12
none-of-those
end_variable
begin_variable
var188
-1
2
clear loc_14_13
none-of-those
end_variable
begin_variable
var189
-1
2
clear loc_14_14
none-of-those
end_variable
begin_variable
var190
-1
2
clear loc_14_15
none-of-those
end_variable
begin_variable
var191
-1
2
clear loc_14_16
none-of-those
end_variable
begin_variable
var192
-1
2
clear loc_14_17
none-of-those
end_variable
begin_variable
var193
-1
2
clear loc_14_18
none-of-those
end_variable
begin_variable
var194
-1
2
clear loc_14_19
none-of-those
end_variable
begin_variable
var195
-1
2
clear loc_14_2
none-of-those
end_variable
begin_variable
var196
-1
2
clear loc_14_20
none-of-those
end_variable
begin_variable
var197
-1
2
clear loc_14_3
none-of-those
end_variable
begin_variable
var198
-1
2
clear loc_14_5
none-of-those
end_variable
begin_variable
var199
-1
2
clear loc_14_6
none-of-those
end_variable
begin_variable
var200
-1
2
clear loc_14_7
none-of-those
end_variable
begin_variable
var201
-1
2
clear loc_14_8
none-of-those
end_variable
begin_variable
var202
-1
2
clear loc_14_9
none-of-those
end_variable
begin_variable
var203
-1
2
clear loc_15_10
none-of-those
end_variable
begin_variable
var204
-1
2
clear loc_15_11
none-of-those
end_variable
begin_variable
var205
-1
2
clear loc_15_12
none-of-those
end_variable
begin_variable
var206
-1
2
clear loc_15_13
none-of-those
end_variable
begin_variable
var207
-1
2
clear loc_15_14
none-of-those
end_variable
begin_variable
var208
-1
2
clear loc_15_15
none-of-those
end_variable
begin_variable
var209
-1
2
clear loc_15_16
none-of-those
end_variable
begin_variable
var210
-1
2
clear loc_15_17
none-of-those
end_variable
begin_variable
var211
-1
2
clear loc_15_18
none-of-those
end_variable
begin_variable
var212
-1
2
clear loc_15_19
none-of-those
end_variable
begin_variable
var213
-1
2
clear loc_15_2
none-of-those
end_variable
begin_variable
var214
-1
2
clear loc_15_20
none-of-those
end_variable
begin_variable
var215
-1
2
clear loc_15_21
none-of-those
end_variable
begin_variable
var216
-1
2
clear loc_15_3
none-of-those
end_variable
begin_variable
var217
-1
2
clear loc_15_5
none-of-those
end_variable
begin_variable
var218
-1
2
clear loc_15_6
none-of-those
end_variable
begin_variable
var219
-1
2
clear loc_15_7
none-of-those
end_variable
begin_variable
var220
-1
2
clear loc_15_8
none-of-those
end_variable
begin_variable
var221
-1
2
clear loc_15_9
none-of-those
end_variable
begin_variable
var222
-1
2
clear loc_16_10
none-of-those
end_variable
begin_variable
var223
-1
2
clear loc_16_13
none-of-those
end_variable
begin_variable
var224
-1
2
clear loc_16_14
none-of-those
end_variable
begin_variable
var225
-1
2
clear loc_16_19
none-of-those
end_variable
begin_variable
var226
-1
2
clear loc_16_2
none-of-those
end_variable
begin_variable
var227
-1
2
clear loc_16_20
none-of-those
end_variable
begin_variable
var228
-1
2
clear loc_16_3
none-of-those
end_variable
begin_variable
var229
-1
2
clear loc_16_5
none-of-those
end_variable
begin_variable
var230
-1
2
clear loc_16_6
none-of-those
end_variable
begin_variable
var231
-1
2
clear loc_16_7
none-of-those
end_variable
begin_variable
var232
-1
2
clear loc_16_8
none-of-those
end_variable
begin_variable
var233
-1
2
clear loc_16_9
none-of-those
end_variable
begin_variable
var234
-1
2
clear loc_17_10
none-of-those
end_variable
begin_variable
var235
-1
2
clear loc_17_13
none-of-those
end_variable
begin_variable
var236
-1
2
clear loc_17_14
none-of-those
end_variable
begin_variable
var237
-1
2
clear loc_17_16
none-of-those
end_variable
begin_variable
var238
-1
2
clear loc_17_17
none-of-those
end_variable
begin_variable
var239
-1
2
clear loc_17_19
none-of-those
end_variable
begin_variable
var240
-1
2
clear loc_17_20
none-of-those
end_variable
begin_variable
var241
-1
2
clear loc_17_3
none-of-those
end_variable
begin_variable
var242
-1
2
clear loc_17_7
none-of-those
end_variable
begin_variable
var243
-1
2
clear loc_17_8
none-of-those
end_variable
begin_variable
var244
-1
2
clear loc_18_10
none-of-those
end_variable
begin_variable
var245
-1
2
clear loc_18_11
none-of-those
end_variable
begin_variable
var246
-1
2
clear loc_18_13
none-of-those
end_variable
begin_variable
var247
-1
2
clear loc_18_14
none-of-those
end_variable
begin_variable
var248
-1
2
clear loc_18_15
none-of-those
end_variable
begin_variable
var249
-1
2
clear loc_18_16
none-of-those
end_variable
begin_variable
var250
-1
2
clear loc_18_19
none-of-those
end_variable
begin_variable
var251
-1
2
clear loc_18_20
none-of-those
end_variable
begin_variable
var252
-1
2
clear loc_18_6
none-of-those
end_variable
begin_variable
var253
-1
2
clear loc_18_7
none-of-those
end_variable
begin_variable
var254
-1
2
clear loc_18_8
none-of-those
end_variable
begin_variable
var255
-1
2
clear loc_18_9
none-of-those
end_variable
begin_variable
var256
-1
2
clear loc_19_11
none-of-those
end_variable
begin_variable
var257
-1
2
clear loc_19_12
none-of-those
end_variable
begin_variable
var258
-1
2
clear loc_19_13
none-of-those
end_variable
begin_variable
var259
-1
2
clear loc_19_16
none-of-those
end_variable
begin_variable
var260
-1
2
clear loc_19_17
none-of-those
end_variable
begin_variable
var261
-1
2
clear loc_19_19
none-of-those
end_variable
begin_variable
var262
-1
2
clear loc_19_2
none-of-those
end_variable
begin_variable
var263
-1
2
clear loc_19_20
none-of-those
end_variable
begin_variable
var264
-1
2
clear loc_19_21
none-of-those
end_variable
begin_variable
var265
-1
2
clear loc_19_6
none-of-those
end_variable
begin_variable
var266
-1
2
clear loc_19_7
none-of-those
end_variable
begin_variable
var267
-1
2
clear loc_19_8
none-of-those
end_variable
begin_variable
var268
-1
2
clear loc_19_9
none-of-those
end_variable
begin_variable
var269
-1
2
clear loc_20_10
none-of-those
end_variable
begin_variable
var270
-1
2
clear loc_20_11
none-of-those
end_variable
begin_variable
var271
-1
2
clear loc_20_12
none-of-those
end_variable
begin_variable
var272
-1
2
clear loc_20_13
none-of-those
end_variable
begin_variable
var273
-1
2
clear loc_20_14
none-of-those
end_variable
begin_variable
var274
-1
2
clear loc_20_15
none-of-those
end_variable
begin_variable
var275
-1
2
clear loc_20_16
none-of-those
end_variable
begin_variable
var276
-1
2
clear loc_20_17
none-of-those
end_variable
begin_variable
var277
-1
2
clear loc_20_18
none-of-those
end_variable
begin_variable
var278
-1
2
clear loc_20_19
none-of-those
end_variable
begin_variable
var279
-1
2
clear loc_20_5
none-of-those
end_variable
begin_variable
var280
-1
2
clear loc_20_6
none-of-those
end_variable
begin_variable
var281
-1
2
clear loc_20_7
none-of-those
end_variable
begin_variable
var282
-1
2
clear loc_20_8
none-of-those
end_variable
begin_variable
var283
-1
2
clear loc_20_9
none-of-those
end_variable
begin_variable
var284
-1
2
clear loc_21_10
none-of-those
end_variable
begin_variable
var285
-1
2
clear loc_21_11
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_10_10 loc_11_10 down
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_10_12 loc_11_12 down
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_10_14 loc_10_15 right
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_10_14 loc_11_14 down
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_10_15 loc_10_14 left
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_10_15 loc_11_15 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_10_15 loc_9_15 up
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_10_17 loc_11_17 down
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_10_17 loc_9_17 up
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_10_19 loc_11_19 down
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_10_19 loc_9_19 up
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_10_3 loc_9_3 up
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_10_4 loc_11_4 down
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_10_9 loc_11_9 down
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_11_10 loc_10_10 up
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_11_10 loc_11_11 right
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_11_10 loc_11_9 left
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_11_10 loc_12_10 down
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_11_11 loc_11_10 left
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_11_11 loc_11_12 right
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_11_11 loc_12_11 down
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_11_12 loc_10_12 up
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_11_12 loc_11_11 left
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_11_12 loc_11_13 right
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_11_12 loc_12_12 down
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_11_13 loc_11_12 left
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_11_13 loc_11_14 right
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_11_13 loc_12_13 down
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_11_14 loc_10_14 up
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_11_14 loc_11_13 left
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_11_14 loc_11_15 right
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_11_14 loc_12_14 down
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_11_15 loc_10_15 up
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_11_15 loc_11_14 left
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_11_15 loc_11_16 right
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_11_15 loc_12_15 down
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_11_16 loc_11_15 left
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_11_16 loc_11_17 right
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_11_16 loc_12_16 down
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_11_17 loc_10_17 up
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_11_17 loc_11_16 left
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_11_17 loc_11_18 right
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_11_17 loc_12_17 down
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_11_18 loc_11_17 left
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_11_18 loc_11_19 right
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_11_18 loc_12_18 down
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_11_19 loc_10_19 up
none-of-those
end_variable
begin_variable
var344
-1
2
adjacent loc_11_19 loc_11_18 left
none-of-those
end_variable
begin_variable
var345
-1
2
adjacent loc_11_19 loc_11_20 right
none-of-those
end_variable
begin_variable
var346
-1
2
adjacent loc_11_19 loc_12_19 down
none-of-those
end_variable
begin_variable
var347
-1
2
adjacent loc_11_20 loc_11_19 left
none-of-those
end_variable
begin_variable
var348
-1
2
adjacent loc_11_20 loc_12_20 down
none-of-those
end_variable
begin_variable
var349
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var350
-1
2
adjacent loc_11_3 loc_11_4 right
none-of-those
end_variable
begin_variable
var351
-1
2
adjacent loc_11_4 loc_10_4 up
none-of-those
end_variable
begin_variable
var352
-1
2
adjacent loc_11_4 loc_11_3 left
none-of-those
end_variable
begin_variable
var353
-1
2
adjacent loc_11_4 loc_11_5 right
none-of-those
end_variable
begin_variable
var354
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var355
-1
2
adjacent loc_11_5 loc_11_4 left
none-of-those
end_variable
begin_variable
var356
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var357
-1
2
adjacent loc_11_5 loc_12_5 down
none-of-those
end_variable
begin_variable
var358
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var359
-1
2
adjacent loc_11_6 loc_11_7 right
none-of-those
end_variable
begin_variable
var360
-1
2
adjacent loc_11_6 loc_12_6 down
none-of-those
end_variable
begin_variable
var361
-1
2
adjacent loc_11_7 loc_11_6 left
none-of-those
end_variable
begin_variable
var362
-1
2
adjacent loc_11_7 loc_11_8 right
none-of-those
end_variable
begin_variable
var363
-1
2
adjacent loc_11_7 loc_12_7 down
none-of-those
end_variable
begin_variable
var364
-1
2
adjacent loc_11_8 loc_11_7 left
none-of-those
end_variable
begin_variable
var365
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var366
-1
2
adjacent loc_11_8 loc_12_8 down
none-of-those
end_variable
begin_variable
var367
-1
2
adjacent loc_11_9 loc_10_9 up
none-of-those
end_variable
begin_variable
var368
-1
2
adjacent loc_11_9 loc_11_10 right
none-of-those
end_variable
begin_variable
var369
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var370
-1
2
adjacent loc_11_9 loc_12_9 down
none-of-those
end_variable
begin_variable
var371
-1
2
adjacent loc_12_10 loc_11_10 up
none-of-those
end_variable
begin_variable
var372
-1
2
adjacent loc_12_10 loc_12_11 right
none-of-those
end_variable
begin_variable
var373
-1
2
adjacent loc_12_10 loc_12_9 left
none-of-those
end_variable
begin_variable
var374
-1
2
adjacent loc_12_10 loc_13_10 down
none-of-those
end_variable
begin_variable
var375
-1
2
adjacent loc_12_11 loc_11_11 up
none-of-those
end_variable
begin_variable
var376
-1
2
adjacent loc_12_11 loc_12_10 left
none-of-those
end_variable
begin_variable
var377
-1
2
adjacent loc_12_11 loc_12_12 right
none-of-those
end_variable
begin_variable
var378
-1
2
adjacent loc_12_11 loc_13_11 down
none-of-those
end_variable
begin_variable
var379
-1
2
adjacent loc_12_12 loc_11_12 up
none-of-those
end_variable
begin_variable
var380
-1
2
adjacent loc_12_12 loc_12_11 left
none-of-those
end_variable
begin_variable
var381
-1
2
adjacent loc_12_12 loc_12_13 right
none-of-those
end_variable
begin_variable
var382
-1
2
adjacent loc_12_12 loc_13_12 down
none-of-those
end_variable
begin_variable
var383
-1
2
adjacent loc_12_13 loc_11_13 up
none-of-those
end_variable
begin_variable
var384
-1
2
adjacent loc_12_13 loc_12_12 left
none-of-those
end_variable
begin_variable
var385
-1
2
adjacent loc_12_13 loc_12_14 right
none-of-those
end_variable
begin_variable
var386
-1
2
adjacent loc_12_13 loc_13_13 down
none-of-those
end_variable
begin_variable
var387
-1
2
adjacent loc_12_14 loc_11_14 up
none-of-those
end_variable
begin_variable
var388
-1
2
adjacent loc_12_14 loc_12_13 left
none-of-those
end_variable
begin_variable
var389
-1
2
adjacent loc_12_14 loc_12_15 right
none-of-those
end_variable
begin_variable
var390
-1
2
adjacent loc_12_14 loc_13_14 down
none-of-those
end_variable
begin_variable
var391
-1
2
adjacent loc_12_15 loc_11_15 up
none-of-those
end_variable
begin_variable
var392
-1
2
adjacent loc_12_15 loc_12_14 left
none-of-those
end_variable
begin_variable
var393
-1
2
adjacent loc_12_15 loc_12_16 right
none-of-those
end_variable
begin_variable
var394
-1
2
adjacent loc_12_15 loc_13_15 down
none-of-those
end_variable
begin_variable
var395
-1
2
adjacent loc_12_16 loc_11_16 up
none-of-those
end_variable
begin_variable
var396
-1
2
adjacent loc_12_16 loc_12_15 left
none-of-those
end_variable
begin_variable
var397
-1
2
adjacent loc_12_16 loc_12_17 right
none-of-those
end_variable
begin_variable
var398
-1
2
adjacent loc_12_17 loc_11_17 up
none-of-those
end_variable
begin_variable
var399
-1
2
adjacent loc_12_17 loc_12_16 left
none-of-those
end_variable
begin_variable
var400
-1
2
adjacent loc_12_17 loc_12_18 right
none-of-those
end_variable
begin_variable
var401
-1
2
adjacent loc_12_17 loc_13_17 down
none-of-those
end_variable
begin_variable
var402
-1
2
adjacent loc_12_18 loc_11_18 up
none-of-those
end_variable
begin_variable
var403
-1
2
adjacent loc_12_18 loc_12_17 left
none-of-those
end_variable
begin_variable
var404
-1
2
adjacent loc_12_18 loc_12_19 right
none-of-those
end_variable
begin_variable
var405
-1
2
adjacent loc_12_18 loc_13_18 down
none-of-those
end_variable
begin_variable
var406
-1
2
adjacent loc_12_19 loc_11_19 up
none-of-those
end_variable
begin_variable
var407
-1
2
adjacent loc_12_19 loc_12_18 left
none-of-those
end_variable
begin_variable
var408
-1
2
adjacent loc_12_19 loc_12_20 right
none-of-those
end_variable
begin_variable
var409
-1
2
adjacent loc_12_19 loc_13_19 down
none-of-those
end_variable
begin_variable
var410
-1
2
adjacent loc_12_20 loc_11_20 up
none-of-those
end_variable
begin_variable
var411
-1
2
adjacent loc_12_20 loc_12_19 left
none-of-those
end_variable
begin_variable
var412
-1
2
adjacent loc_12_20 loc_13_20 down
none-of-those
end_variable
begin_variable
var413
-1
2
adjacent loc_12_5 loc_11_5 up
none-of-those
end_variable
begin_variable
var414
-1
2
adjacent loc_12_5 loc_12_6 right
none-of-those
end_variable
begin_variable
var415
-1
2
adjacent loc_12_5 loc_13_5 down
none-of-those
end_variable
begin_variable
var416
-1
2
adjacent loc_12_6 loc_11_6 up
none-of-those
end_variable
begin_variable
var417
-1
2
adjacent loc_12_6 loc_12_5 left
none-of-those
end_variable
begin_variable
var418
-1
2
adjacent loc_12_6 loc_12_7 right
none-of-those
end_variable
begin_variable
var419
-1
2
adjacent loc_12_6 loc_13_6 down
none-of-those
end_variable
begin_variable
var420
-1
2
adjacent loc_12_7 loc_11_7 up
none-of-those
end_variable
begin_variable
var421
-1
2
adjacent loc_12_7 loc_12_6 left
none-of-those
end_variable
begin_variable
var422
-1
2
adjacent loc_12_7 loc_12_8 right
none-of-those
end_variable
begin_variable
var423
-1
2
adjacent loc_12_7 loc_13_7 down
none-of-those
end_variable
begin_variable
var424
-1
2
adjacent loc_12_8 loc_11_8 up
none-of-those
end_variable
begin_variable
var425
-1
2
adjacent loc_12_8 loc_12_7 left
none-of-those
end_variable
begin_variable
var426
-1
2
adjacent loc_12_8 loc_12_9 right
none-of-those
end_variable
begin_variable
var427
-1
2
adjacent loc_12_8 loc_13_8 down
none-of-those
end_variable
begin_variable
var428
-1
2
adjacent loc_12_9 loc_11_9 up
none-of-those
end_variable
begin_variable
var429
-1
2
adjacent loc_12_9 loc_12_10 right
none-of-those
end_variable
begin_variable
var430
-1
2
adjacent loc_12_9 loc_12_8 left
none-of-those
end_variable
begin_variable
var431
-1
2
adjacent loc_12_9 loc_13_9 down
none-of-those
end_variable
begin_variable
var432
-1
2
adjacent loc_13_10 loc_12_10 up
none-of-those
end_variable
begin_variable
var433
-1
2
adjacent loc_13_10 loc_13_11 right
none-of-those
end_variable
begin_variable
var434
-1
2
adjacent loc_13_10 loc_13_9 left
none-of-those
end_variable
begin_variable
var435
-1
2
adjacent loc_13_10 loc_14_10 down
none-of-those
end_variable
begin_variable
var436
-1
2
adjacent loc_13_11 loc_12_11 up
none-of-those
end_variable
begin_variable
var437
-1
2
adjacent loc_13_11 loc_13_10 left
none-of-those
end_variable
begin_variable
var438
-1
2
adjacent loc_13_11 loc_13_12 right
none-of-those
end_variable
begin_variable
var439
-1
2
adjacent loc_13_11 loc_14_11 down
none-of-those
end_variable
begin_variable
var440
-1
2
adjacent loc_13_12 loc_12_12 up
none-of-those
end_variable
begin_variable
var441
-1
2
adjacent loc_13_12 loc_13_11 left
none-of-those
end_variable
begin_variable
var442
-1
2
adjacent loc_13_12 loc_13_13 right
none-of-those
end_variable
begin_variable
var443
-1
2
adjacent loc_13_12 loc_14_12 down
none-of-those
end_variable
begin_variable
var444
-1
2
adjacent loc_13_13 loc_12_13 up
none-of-those
end_variable
begin_variable
var445
-1
2
adjacent loc_13_13 loc_13_12 left
none-of-those
end_variable
begin_variable
var446
-1
2
adjacent loc_13_13 loc_13_14 right
none-of-those
end_variable
begin_variable
var447
-1
2
adjacent loc_13_13 loc_14_13 down
none-of-those
end_variable
begin_variable
var448
-1
2
adjacent loc_13_14 loc_12_14 up
none-of-those
end_variable
begin_variable
var449
-1
2
adjacent loc_13_14 loc_13_13 left
none-of-those
end_variable
begin_variable
var450
-1
2
adjacent loc_13_14 loc_13_15 right
none-of-those
end_variable
begin_variable
var451
-1
2
adjacent loc_13_14 loc_14_14 down
none-of-those
end_variable
begin_variable
var452
-1
2
adjacent loc_13_15 loc_12_15 up
none-of-those
end_variable
begin_variable
var453
-1
2
adjacent loc_13_15 loc_13_14 left
none-of-those
end_variable
begin_variable
var454
-1
2
adjacent loc_13_15 loc_14_15 down
none-of-those
end_variable
begin_variable
var455
-1
2
adjacent loc_13_17 loc_12_17 up
none-of-those
end_variable
begin_variable
var456
-1
2
adjacent loc_13_17 loc_13_18 right
none-of-those
end_variable
begin_variable
var457
-1
2
adjacent loc_13_17 loc_14_17 down
none-of-those
end_variable
begin_variable
var458
-1
2
adjacent loc_13_18 loc_12_18 up
none-of-those
end_variable
begin_variable
var459
-1
2
adjacent loc_13_18 loc_13_17 left
none-of-those
end_variable
begin_variable
var460
-1
2
adjacent loc_13_18 loc_13_19 right
none-of-those
end_variable
begin_variable
var461
-1
2
adjacent loc_13_18 loc_14_18 down
none-of-those
end_variable
begin_variable
var462
-1
2
adjacent loc_13_19 loc_12_19 up
none-of-those
end_variable
begin_variable
var463
-1
2
adjacent loc_13_19 loc_13_18 left
none-of-those
end_variable
begin_variable
var464
-1
2
adjacent loc_13_19 loc_13_20 right
none-of-those
end_variable
begin_variable
var465
-1
2
adjacent loc_13_19 loc_14_19 down
none-of-those
end_variable
begin_variable
var466
-1
2
adjacent loc_13_20 loc_12_20 up
none-of-those
end_variable
begin_variable
var467
-1
2
adjacent loc_13_20 loc_13_19 left
none-of-those
end_variable
begin_variable
var468
-1
2
adjacent loc_13_20 loc_13_21 right
none-of-those
end_variable
begin_variable
var469
-1
2
adjacent loc_13_20 loc_14_20 down
none-of-those
end_variable
begin_variable
var470
-1
2
adjacent loc_13_21 loc_13_20 left
none-of-those
end_variable
begin_variable
var471
-1
2
adjacent loc_13_5 loc_12_5 up
none-of-those
end_variable
begin_variable
var472
-1
2
adjacent loc_13_5 loc_13_6 right
none-of-those
end_variable
begin_variable
var473
-1
2
adjacent loc_13_5 loc_14_5 down
none-of-those
end_variable
begin_variable
var474
-1
2
adjacent loc_13_6 loc_12_6 up
none-of-those
end_variable
begin_variable
var475
-1
2
adjacent loc_13_6 loc_13_5 left
none-of-those
end_variable
begin_variable
var476
-1
2
adjacent loc_13_6 loc_13_7 right
none-of-those
end_variable
begin_variable
var477
-1
2
adjacent loc_13_6 loc_14_6 down
none-of-those
end_variable
begin_variable
var478
-1
2
adjacent loc_13_7 loc_12_7 up
none-of-those
end_variable
begin_variable
var479
-1
2
adjacent loc_13_7 loc_13_6 left
none-of-those
end_variable
begin_variable
var480
-1
2
adjacent loc_13_7 loc_13_8 right
none-of-those
end_variable
begin_variable
var481
-1
2
adjacent loc_13_7 loc_14_7 down
none-of-those
end_variable
begin_variable
var482
-1
2
adjacent loc_13_8 loc_12_8 up
none-of-those
end_variable
begin_variable
var483
-1
2
adjacent loc_13_8 loc_13_7 left
none-of-those
end_variable
begin_variable
var484
-1
2
adjacent loc_13_8 loc_13_9 right
none-of-those
end_variable
begin_variable
var485
-1
2
adjacent loc_13_8 loc_14_8 down
none-of-those
end_variable
begin_variable
var486
-1
2
adjacent loc_13_9 loc_12_9 up
none-of-those
end_variable
begin_variable
var487
-1
2
adjacent loc_13_9 loc_13_10 right
none-of-those
end_variable
begin_variable
var488
-1
2
adjacent loc_13_9 loc_13_8 left
none-of-those
end_variable
begin_variable
var489
-1
2
adjacent loc_13_9 loc_14_9 down
none-of-those
end_variable
begin_variable
var490
-1
2
adjacent loc_14_10 loc_13_10 up
none-of-those
end_variable
begin_variable
var491
-1
2
adjacent loc_14_10 loc_14_11 right
none-of-those
end_variable
begin_variable
var492
-1
2
adjacent loc_14_10 loc_14_9 left
none-of-those
end_variable
begin_variable
var493
-1
2
adjacent loc_14_10 loc_15_10 down
none-of-those
end_variable
begin_variable
var494
-1
2
adjacent loc_14_11 loc_13_11 up
none-of-those
end_variable
begin_variable
var495
-1
2
adjacent loc_14_11 loc_14_10 left
none-of-those
end_variable
begin_variable
var496
-1
2
adjacent loc_14_11 loc_14_12 right
none-of-those
end_variable
begin_variable
var497
-1
2
adjacent loc_14_11 loc_15_11 down
none-of-those
end_variable
begin_variable
var498
-1
2
adjacent loc_14_12 loc_13_12 up
none-of-those
end_variable
begin_variable
var499
-1
2
adjacent loc_14_12 loc_14_11 left
none-of-those
end_variable
begin_variable
var500
-1
2
adjacent loc_14_12 loc_14_13 right
none-of-those
end_variable
begin_variable
var501
-1
2
adjacent loc_14_12 loc_15_12 down
none-of-those
end_variable
begin_variable
var502
-1
2
adjacent loc_14_13 loc_13_13 up
none-of-those
end_variable
begin_variable
var503
-1
2
adjacent loc_14_13 loc_14_12 left
none-of-those
end_variable
begin_variable
var504
-1
2
adjacent loc_14_13 loc_14_14 right
none-of-those
end_variable
begin_variable
var505
-1
2
adjacent loc_14_13 loc_15_13 down
none-of-those
end_variable
begin_variable
var506
-1
2
adjacent loc_14_14 loc_13_14 up
none-of-those
end_variable
begin_variable
var507
-1
2
adjacent loc_14_14 loc_14_13 left
none-of-those
end_variable
begin_variable
var508
-1
2
adjacent loc_14_14 loc_14_15 right
none-of-those
end_variable
begin_variable
var509
-1
2
adjacent loc_14_14 loc_15_14 down
none-of-those
end_variable
begin_variable
var510
-1
2
adjacent loc_14_15 loc_13_15 up
none-of-those
end_variable
begin_variable
var511
-1
2
adjacent loc_14_15 loc_14_14 left
none-of-those
end_variable
begin_variable
var512
-1
2
adjacent loc_14_15 loc_14_16 right
none-of-those
end_variable
begin_variable
var513
-1
2
adjacent loc_14_15 loc_15_15 down
none-of-those
end_variable
begin_variable
var514
-1
2
adjacent loc_14_16 loc_14_15 left
none-of-those
end_variable
begin_variable
var515
-1
2
adjacent loc_14_16 loc_14_17 right
none-of-those
end_variable
begin_variable
var516
-1
2
adjacent loc_14_16 loc_15_16 down
none-of-those
end_variable
begin_variable
var517
-1
2
adjacent loc_14_17 loc_13_17 up
none-of-those
end_variable
begin_variable
var518
-1
2
adjacent loc_14_17 loc_14_16 left
none-of-those
end_variable
begin_variable
var519
-1
2
adjacent loc_14_17 loc_14_18 right
none-of-those
end_variable
begin_variable
var520
-1
2
adjacent loc_14_17 loc_15_17 down
none-of-those
end_variable
begin_variable
var521
-1
2
adjacent loc_14_18 loc_13_18 up
none-of-those
end_variable
begin_variable
var522
-1
2
adjacent loc_14_18 loc_14_17 left
none-of-those
end_variable
begin_variable
var523
-1
2
adjacent loc_14_18 loc_14_19 right
none-of-those
end_variable
begin_variable
var524
-1
2
adjacent loc_14_18 loc_15_18 down
none-of-those
end_variable
begin_variable
var525
-1
2
adjacent loc_14_19 loc_13_19 up
none-of-those
end_variable
begin_variable
var526
-1
2
adjacent loc_14_19 loc_14_18 left
none-of-those
end_variable
begin_variable
var527
-1
2
adjacent loc_14_19 loc_14_20 right
none-of-those
end_variable
begin_variable
var528
-1
2
adjacent loc_14_19 loc_15_19 down
none-of-those
end_variable
begin_variable
var529
-1
2
adjacent loc_14_2 loc_14_3 right
none-of-those
end_variable
begin_variable
var530
-1
2
adjacent loc_14_2 loc_15_2 down
none-of-those
end_variable
begin_variable
var531
-1
2
adjacent loc_14_20 loc_13_20 up
none-of-those
end_variable
begin_variable
var532
-1
2
adjacent loc_14_20 loc_14_19 left
none-of-those
end_variable
begin_variable
var533
-1
2
adjacent loc_14_20 loc_15_20 down
none-of-those
end_variable
begin_variable
var534
-1
2
adjacent loc_14_3 loc_14_2 left
none-of-those
end_variable
begin_variable
var535
-1
2
adjacent loc_14_3 loc_15_3 down
none-of-those
end_variable
begin_variable
var536
-1
2
adjacent loc_14_5 loc_13_5 up
none-of-those
end_variable
begin_variable
var537
-1
2
adjacent loc_14_5 loc_14_6 right
none-of-those
end_variable
begin_variable
var538
-1
2
adjacent loc_14_5 loc_15_5 down
none-of-those
end_variable
begin_variable
var539
-1
2
adjacent loc_14_6 loc_13_6 up
none-of-those
end_variable
begin_variable
var540
-1
2
adjacent loc_14_6 loc_14_5 left
none-of-those
end_variable
begin_variable
var541
-1
2
adjacent loc_14_6 loc_14_7 right
none-of-those
end_variable
begin_variable
var542
-1
2
adjacent loc_14_6 loc_15_6 down
none-of-those
end_variable
begin_variable
var543
-1
2
adjacent loc_14_7 loc_13_7 up
none-of-those
end_variable
begin_variable
var544
-1
2
adjacent loc_14_7 loc_14_6 left
none-of-those
end_variable
begin_variable
var545
-1
2
adjacent loc_14_7 loc_14_8 right
none-of-those
end_variable
begin_variable
var546
-1
2
adjacent loc_14_7 loc_15_7 down
none-of-those
end_variable
begin_variable
var547
-1
2
adjacent loc_14_8 loc_13_8 up
none-of-those
end_variable
begin_variable
var548
-1
2
adjacent loc_14_8 loc_14_7 left
none-of-those
end_variable
begin_variable
var549
-1
2
adjacent loc_14_8 loc_14_9 right
none-of-those
end_variable
begin_variable
var550
-1
2
adjacent loc_14_8 loc_15_8 down
none-of-those
end_variable
begin_variable
var551
-1
2
adjacent loc_14_9 loc_13_9 up
none-of-those
end_variable
begin_variable
var552
-1
2
adjacent loc_14_9 loc_14_10 right
none-of-those
end_variable
begin_variable
var553
-1
2
adjacent loc_14_9 loc_14_8 left
none-of-those
end_variable
begin_variable
var554
-1
2
adjacent loc_14_9 loc_15_9 down
none-of-those
end_variable
begin_variable
var555
-1
2
adjacent loc_15_10 loc_14_10 up
none-of-those
end_variable
begin_variable
var556
-1
2
adjacent loc_15_10 loc_15_11 right
none-of-those
end_variable
begin_variable
var557
-1
2
adjacent loc_15_10 loc_15_9 left
none-of-those
end_variable
begin_variable
var558
-1
2
adjacent loc_15_10 loc_16_10 down
none-of-those
end_variable
begin_variable
var559
-1
2
adjacent loc_15_11 loc_14_11 up
none-of-those
end_variable
begin_variable
var560
-1
2
adjacent loc_15_11 loc_15_10 left
none-of-those
end_variable
begin_variable
var561
-1
2
adjacent loc_15_11 loc_15_12 right
none-of-those
end_variable
begin_variable
var562
-1
2
adjacent loc_15_12 loc_14_12 up
none-of-those
end_variable
begin_variable
var563
-1
2
adjacent loc_15_12 loc_15_11 left
none-of-those
end_variable
begin_variable
var564
-1
2
adjacent loc_15_12 loc_15_13 right
none-of-those
end_variable
begin_variable
var565
-1
2
adjacent loc_15_13 loc_14_13 up
none-of-those
end_variable
begin_variable
var566
-1
2
adjacent loc_15_13 loc_15_12 left
none-of-those
end_variable
begin_variable
var567
-1
2
adjacent loc_15_13 loc_15_14 right
none-of-those
end_variable
begin_variable
var568
-1
2
adjacent loc_15_13 loc_16_13 down
none-of-those
end_variable
begin_variable
var569
-1
2
adjacent loc_15_14 loc_14_14 up
none-of-those
end_variable
begin_variable
var570
-1
2
adjacent loc_15_14 loc_15_13 left
none-of-those
end_variable
begin_variable
var571
-1
2
adjacent loc_15_14 loc_15_15 right
none-of-those
end_variable
begin_variable
var572
-1
2
adjacent loc_15_14 loc_16_14 down
none-of-those
end_variable
begin_variable
var573
-1
2
adjacent loc_15_15 loc_14_15 up
none-of-those
end_variable
begin_variable
var574
-1
2
adjacent loc_15_15 loc_15_14 left
none-of-those
end_variable
begin_variable
var575
-1
2
adjacent loc_15_15 loc_15_16 right
none-of-those
end_variable
begin_variable
var576
-1
2
adjacent loc_15_16 loc_14_16 up
none-of-those
end_variable
begin_variable
var577
-1
2
adjacent loc_15_16 loc_15_15 left
none-of-those
end_variable
begin_variable
var578
-1
2
adjacent loc_15_16 loc_15_17 right
none-of-those
end_variable
begin_variable
var579
-1
2
adjacent loc_15_17 loc_14_17 up
none-of-those
end_variable
begin_variable
var580
-1
2
adjacent loc_15_17 loc_15_16 left
none-of-those
end_variable
begin_variable
var581
-1
2
adjacent loc_15_17 loc_15_18 right
none-of-those
end_variable
begin_variable
var582
-1
2
adjacent loc_15_18 loc_14_18 up
none-of-those
end_variable
begin_variable
var583
-1
2
adjacent loc_15_18 loc_15_17 left
none-of-those
end_variable
begin_variable
var584
-1
2
adjacent loc_15_18 loc_15_19 right
none-of-those
end_variable
begin_variable
var585
-1
2
adjacent loc_15_19 loc_14_19 up
none-of-those
end_variable
begin_variable
var586
-1
2
adjacent loc_15_19 loc_15_18 left
none-of-those
end_variable
begin_variable
var587
-1
2
adjacent loc_15_19 loc_15_20 right
none-of-those
end_variable
begin_variable
var588
-1
2
adjacent loc_15_19 loc_16_19 down
none-of-those
end_variable
begin_variable
var589
-1
2
adjacent loc_15_2 loc_14_2 up
none-of-those
end_variable
begin_variable
var590
-1
2
adjacent loc_15_2 loc_15_3 right
none-of-those
end_variable
begin_variable
var591
-1
2
adjacent loc_15_2 loc_16_2 down
none-of-those
end_variable
begin_variable
var592
-1
2
adjacent loc_15_20 loc_14_20 up
none-of-those
end_variable
begin_variable
var593
-1
2
adjacent loc_15_20 loc_15_19 left
none-of-those
end_variable
begin_variable
var594
-1
2
adjacent loc_15_20 loc_15_21 right
none-of-those
end_variable
begin_variable
var595
-1
2
adjacent loc_15_20 loc_16_20 down
none-of-those
end_variable
begin_variable
var596
-1
2
adjacent loc_15_21 loc_15_20 left
none-of-those
end_variable
begin_variable
var597
-1
2
adjacent loc_15_3 loc_14_3 up
none-of-those
end_variable
begin_variable
var598
-1
2
adjacent loc_15_3 loc_15_2 left
none-of-those
end_variable
begin_variable
var599
-1
2
adjacent loc_15_3 loc_16_3 down
none-of-those
end_variable
begin_variable
var600
-1
2
adjacent loc_15_5 loc_14_5 up
none-of-those
end_variable
begin_variable
var601
-1
2
adjacent loc_15_5 loc_15_6 right
none-of-those
end_variable
begin_variable
var602
-1
2
adjacent loc_15_5 loc_16_5 down
none-of-those
end_variable
begin_variable
var603
-1
2
adjacent loc_15_6 loc_14_6 up
none-of-those
end_variable
begin_variable
var604
-1
2
adjacent loc_15_6 loc_15_5 left
none-of-those
end_variable
begin_variable
var605
-1
2
adjacent loc_15_6 loc_15_7 right
none-of-those
end_variable
begin_variable
var606
-1
2
adjacent loc_15_6 loc_16_6 down
none-of-those
end_variable
begin_variable
var607
-1
2
adjacent loc_15_7 loc_14_7 up
none-of-those
end_variable
begin_variable
var608
-1
2
adjacent loc_15_7 loc_15_6 left
none-of-those
end_variable
begin_variable
var609
-1
2
adjacent loc_15_7 loc_15_8 right
none-of-those
end_variable
begin_variable
var610
-1
2
adjacent loc_15_7 loc_16_7 down
none-of-those
end_variable
begin_variable
var611
-1
2
adjacent loc_15_8 loc_14_8 up
none-of-those
end_variable
begin_variable
var612
-1
2
adjacent loc_15_8 loc_15_7 left
none-of-those
end_variable
begin_variable
var613
-1
2
adjacent loc_15_8 loc_15_9 right
none-of-those
end_variable
begin_variable
var614
-1
2
adjacent loc_15_8 loc_16_8 down
none-of-those
end_variable
begin_variable
var615
-1
2
adjacent loc_15_9 loc_14_9 up
none-of-those
end_variable
begin_variable
var616
-1
2
adjacent loc_15_9 loc_15_10 right
none-of-those
end_variable
begin_variable
var617
-1
2
adjacent loc_15_9 loc_15_8 left
none-of-those
end_variable
begin_variable
var618
-1
2
adjacent loc_15_9 loc_16_9 down
none-of-those
end_variable
begin_variable
var619
-1
2
adjacent loc_16_10 loc_15_10 up
none-of-those
end_variable
begin_variable
var620
-1
2
adjacent loc_16_10 loc_16_9 left
none-of-those
end_variable
begin_variable
var621
-1
2
adjacent loc_16_10 loc_17_10 down
none-of-those
end_variable
begin_variable
var622
-1
2
adjacent loc_16_13 loc_15_13 up
none-of-those
end_variable
begin_variable
var623
-1
2
adjacent loc_16_13 loc_16_14 right
none-of-those
end_variable
begin_variable
var624
-1
2
adjacent loc_16_13 loc_17_13 down
none-of-those
end_variable
begin_variable
var625
-1
2
adjacent loc_16_14 loc_15_14 up
none-of-those
end_variable
begin_variable
var626
-1
2
adjacent loc_16_14 loc_16_13 left
none-of-those
end_variable
begin_variable
var627
-1
2
adjacent loc_16_14 loc_17_14 down
none-of-those
end_variable
begin_variable
var628
-1
2
adjacent loc_16_19 loc_15_19 up
none-of-those
end_variable
begin_variable
var629
-1
2
adjacent loc_16_19 loc_16_20 right
none-of-those
end_variable
begin_variable
var630
-1
2
adjacent loc_16_19 loc_17_19 down
none-of-those
end_variable
begin_variable
var631
-1
2
adjacent loc_16_2 loc_15_2 up
none-of-those
end_variable
begin_variable
var632
-1
2
adjacent loc_16_2 loc_16_3 right
none-of-those
end_variable
begin_variable
var633
-1
2
adjacent loc_16_20 loc_15_20 up
none-of-those
end_variable
begin_variable
var634
-1
2
adjacent loc_16_20 loc_16_19 left
none-of-those
end_variable
begin_variable
var635
-1
2
adjacent loc_16_20 loc_17_20 down
none-of-those
end_variable
begin_variable
var636
-1
2
adjacent loc_16_3 loc_15_3 up
none-of-those
end_variable
begin_variable
var637
-1
2
adjacent loc_16_3 loc_16_2 left
none-of-those
end_variable
begin_variable
var638
-1
2
adjacent loc_16_3 loc_17_3 down
none-of-those
end_variable
begin_variable
var639
-1
2
adjacent loc_16_5 loc_15_5 up
none-of-those
end_variable
begin_variable
var640
-1
2
adjacent loc_16_5 loc_16_6 right
none-of-those
end_variable
begin_variable
var641
-1
2
adjacent loc_16_6 loc_15_6 up
none-of-those
end_variable
begin_variable
var642
-1
2
adjacent loc_16_6 loc_16_5 left
none-of-those
end_variable
begin_variable
var643
-1
2
adjacent loc_16_6 loc_16_7 right
none-of-those
end_variable
begin_variable
var644
-1
2
adjacent loc_16_7 loc_15_7 up
none-of-those
end_variable
begin_variable
var645
-1
2
adjacent loc_16_7 loc_16_6 left
none-of-those
end_variable
begin_variable
var646
-1
2
adjacent loc_16_7 loc_16_8 right
none-of-those
end_variable
begin_variable
var647
-1
2
adjacent loc_16_7 loc_17_7 down
none-of-those
end_variable
begin_variable
var648
-1
2
adjacent loc_16_8 loc_15_8 up
none-of-those
end_variable
begin_variable
var649
-1
2
adjacent loc_16_8 loc_16_7 left
none-of-those
end_variable
begin_variable
var650
-1
2
adjacent loc_16_8 loc_16_9 right
none-of-those
end_variable
begin_variable
var651
-1
2
adjacent loc_16_8 loc_17_8 down
none-of-those
end_variable
begin_variable
var652
-1
2
adjacent loc_16_9 loc_15_9 up
none-of-those
end_variable
begin_variable
var653
-1
2
adjacent loc_16_9 loc_16_10 right
none-of-those
end_variable
begin_variable
var654
-1
2
adjacent loc_16_9 loc_16_8 left
none-of-those
end_variable
begin_variable
var655
-1
2
adjacent loc_17_10 loc_16_10 up
none-of-those
end_variable
begin_variable
var656
-1
2
adjacent loc_17_10 loc_18_10 down
none-of-those
end_variable
begin_variable
var657
-1
2
adjacent loc_17_13 loc_16_13 up
none-of-those
end_variable
begin_variable
var658
-1
2
adjacent loc_17_13 loc_17_14 right
none-of-those
end_variable
begin_variable
var659
-1
2
adjacent loc_17_13 loc_18_13 down
none-of-those
end_variable
begin_variable
var660
-1
2
adjacent loc_17_14 loc_16_14 up
none-of-those
end_variable
begin_variable
var661
-1
2
adjacent loc_17_14 loc_17_13 left
none-of-those
end_variable
begin_variable
var662
-1
2
adjacent loc_17_14 loc_18_14 down
none-of-those
end_variable
begin_variable
var663
-1
2
adjacent loc_17_16 loc_17_17 right
none-of-those
end_variable
begin_variable
var664
-1
2
adjacent loc_17_16 loc_18_16 down
none-of-those
end_variable
begin_variable
var665
-1
2
adjacent loc_17_17 loc_17_16 left
none-of-those
end_variable
begin_variable
var666
-1
2
adjacent loc_17_19 loc_16_19 up
none-of-those
end_variable
begin_variable
var667
-1
2
adjacent loc_17_19 loc_17_20 right
none-of-those
end_variable
begin_variable
var668
-1
2
adjacent loc_17_19 loc_18_19 down
none-of-those
end_variable
begin_variable
var669
-1
2
adjacent loc_17_20 loc_16_20 up
none-of-those
end_variable
begin_variable
var670
-1
2
adjacent loc_17_20 loc_17_19 left
none-of-those
end_variable
begin_variable
var671
-1
2
adjacent loc_17_20 loc_18_20 down
none-of-those
end_variable
begin_variable
var672
-1
2
adjacent loc_17_3 loc_16_3 up
none-of-those
end_variable
begin_variable
var673
-1
2
adjacent loc_17_7 loc_16_7 up
none-of-those
end_variable
begin_variable
var674
-1
2
adjacent loc_17_7 loc_17_8 right
none-of-those
end_variable
begin_variable
var675
-1
2
adjacent loc_17_7 loc_18_7 down
none-of-those
end_variable
begin_variable
var676
-1
2
adjacent loc_17_8 loc_16_8 up
none-of-those
end_variable
begin_variable
var677
-1
2
adjacent loc_17_8 loc_17_7 left
none-of-those
end_variable
begin_variable
var678
-1
2
adjacent loc_17_8 loc_18_8 down
none-of-those
end_variable
begin_variable
var679
-1
2
adjacent loc_18_10 loc_17_10 up
none-of-those
end_variable
begin_variable
var680
-1
2
adjacent loc_18_10 loc_18_11 right
none-of-those
end_variable
begin_variable
var681
-1
2
adjacent loc_18_10 loc_18_9 left
none-of-those
end_variable
begin_variable
var682
-1
2
adjacent loc_18_11 loc_18_10 left
none-of-those
end_variable
begin_variable
var683
-1
2
adjacent loc_18_11 loc_19_11 down
none-of-those
end_variable
begin_variable
var684
-1
2
adjacent loc_18_13 loc_17_13 up
none-of-those
end_variable
begin_variable
var685
-1
2
adjacent loc_18_13 loc_18_14 right
none-of-those
end_variable
begin_variable
var686
-1
2
adjacent loc_18_13 loc_19_13 down
none-of-those
end_variable
begin_variable
var687
-1
2
adjacent loc_18_14 loc_17_14 up
none-of-those
end_variable
begin_variable
var688
-1
2
adjacent loc_18_14 loc_18_13 left
none-of-those
end_variable
begin_variable
var689
-1
2
adjacent loc_18_14 loc_18_15 right
none-of-those
end_variable
begin_variable
var690
-1
2
adjacent loc_18_15 loc_18_14 left
none-of-those
end_variable
begin_variable
var691
-1
2
adjacent loc_18_15 loc_18_16 right
none-of-those
end_variable
begin_variable
var692
-1
2
adjacent loc_18_16 loc_17_16 up
none-of-those
end_variable
begin_variable
var693
-1
2
adjacent loc_18_16 loc_18_15 left
none-of-those
end_variable
begin_variable
var694
-1
2
adjacent loc_18_16 loc_19_16 down
none-of-those
end_variable
begin_variable
var695
-1
2
adjacent loc_18_19 loc_17_19 up
none-of-those
end_variable
begin_variable
var696
-1
2
adjacent loc_18_19 loc_18_20 right
none-of-those
end_variable
begin_variable
var697
-1
2
adjacent loc_18_19 loc_19_19 down
none-of-those
end_variable
begin_variable
var698
-1
2
adjacent loc_18_20 loc_17_20 up
none-of-those
end_variable
begin_variable
var699
-1
2
adjacent loc_18_20 loc_18_19 left
none-of-those
end_variable
begin_variable
var700
-1
2
adjacent loc_18_20 loc_19_20 down
none-of-those
end_variable
begin_variable
var701
-1
2
adjacent loc_18_6 loc_18_7 right
none-of-those
end_variable
begin_variable
var702
-1
2
adjacent loc_18_6 loc_19_6 down
none-of-those
end_variable
begin_variable
var703
-1
2
adjacent loc_18_7 loc_17_7 up
none-of-those
end_variable
begin_variable
var704
-1
2
adjacent loc_18_7 loc_18_6 left
none-of-those
end_variable
begin_variable
var705
-1
2
adjacent loc_18_7 loc_18_8 right
none-of-those
end_variable
begin_variable
var706
-1
2
adjacent loc_18_7 loc_19_7 down
none-of-those
end_variable
begin_variable
var707
-1
2
adjacent loc_18_8 loc_17_8 up
none-of-those
end_variable
begin_variable
var708
-1
2
adjacent loc_18_8 loc_18_7 left
none-of-those
end_variable
begin_variable
var709
-1
2
adjacent loc_18_8 loc_18_9 right
none-of-those
end_variable
begin_variable
var710
-1
2
adjacent loc_18_8 loc_19_8 down
none-of-those
end_variable
begin_variable
var711
-1
2
adjacent loc_18_9 loc_18_10 right
none-of-those
end_variable
begin_variable
var712
-1
2
adjacent loc_18_9 loc_18_8 left
none-of-those
end_variable
begin_variable
var713
-1
2
adjacent loc_18_9 loc_19_9 down
none-of-those
end_variable
begin_variable
var714
-1
2
adjacent loc_19_11 loc_18_11 up
none-of-those
end_variable
begin_variable
var715
-1
2
adjacent loc_19_11 loc_19_12 right
none-of-those
end_variable
begin_variable
var716
-1
2
adjacent loc_19_11 loc_20_11 down
none-of-those
end_variable
begin_variable
var717
-1
2
adjacent loc_19_12 loc_19_11 left
none-of-those
end_variable
begin_variable
var718
-1
2
adjacent loc_19_12 loc_19_13 right
none-of-those
end_variable
begin_variable
var719
-1
2
adjacent loc_19_12 loc_20_12 down
none-of-those
end_variable
begin_variable
var720
-1
2
adjacent loc_19_13 loc_18_13 up
none-of-those
end_variable
begin_variable
var721
-1
2
adjacent loc_19_13 loc_19_12 left
none-of-those
end_variable
begin_variable
var722
-1
2
adjacent loc_19_13 loc_20_13 down
none-of-those
end_variable
begin_variable
var723
-1
2
adjacent loc_19_16 loc_18_16 up
none-of-those
end_variable
begin_variable
var724
-1
2
adjacent loc_19_16 loc_19_17 right
none-of-those
end_variable
begin_variable
var725
-1
2
adjacent loc_19_16 loc_20_16 down
none-of-those
end_variable
begin_variable
var726
-1
2
adjacent loc_19_17 loc_19_16 left
none-of-those
end_variable
begin_variable
var727
-1
2
adjacent loc_19_17 loc_20_17 down
none-of-those
end_variable
begin_variable
var728
-1
2
adjacent loc_19_19 loc_18_19 up
none-of-those
end_variable
begin_variable
var729
-1
2
adjacent loc_19_19 loc_19_20 right
none-of-those
end_variable
begin_variable
var730
-1
2
adjacent loc_19_19 loc_20_19 down
none-of-those
end_variable
begin_variable
var731
-1
2
adjacent loc_19_20 loc_18_20 up
none-of-those
end_variable
begin_variable
var732
-1
2
adjacent loc_19_20 loc_19_19 left
none-of-those
end_variable
begin_variable
var733
-1
2
adjacent loc_19_20 loc_19_21 right
none-of-those
end_variable
begin_variable
var734
-1
2
adjacent loc_19_21 loc_19_20 left
none-of-those
end_variable
begin_variable
var735
-1
2
adjacent loc_19_6 loc_18_6 up
none-of-those
end_variable
begin_variable
var736
-1
2
adjacent loc_19_6 loc_19_7 right
none-of-those
end_variable
begin_variable
var737
-1
2
adjacent loc_19_6 loc_20_6 down
none-of-those
end_variable
begin_variable
var738
-1
2
adjacent loc_19_7 loc_18_7 up
none-of-those
end_variable
begin_variable
var739
-1
2
adjacent loc_19_7 loc_19_6 left
none-of-those
end_variable
begin_variable
var740
-1
2
adjacent loc_19_7 loc_19_8 right
none-of-those
end_variable
begin_variable
var741
-1
2
adjacent loc_19_7 loc_20_7 down
none-of-those
end_variable
begin_variable
var742
-1
2
adjacent loc_19_8 loc_18_8 up
none-of-those
end_variable
begin_variable
var743
-1
2
adjacent loc_19_8 loc_19_7 left
none-of-those
end_variable
begin_variable
var744
-1
2
adjacent loc_19_8 loc_19_9 right
none-of-those
end_variable
begin_variable
var745
-1
2
adjacent loc_19_8 loc_20_8 down
none-of-those
end_variable
begin_variable
var746
-1
2
adjacent loc_19_9 loc_18_9 up
none-of-those
end_variable
begin_variable
var747
-1
2
adjacent loc_19_9 loc_19_8 left
none-of-those
end_variable
begin_variable
var748
-1
2
adjacent loc_19_9 loc_20_9 down
none-of-those
end_variable
begin_variable
var749
-1
2
adjacent loc_20_10 loc_20_11 right
none-of-those
end_variable
begin_variable
var750
-1
2
adjacent loc_20_10 loc_20_9 left
none-of-those
end_variable
begin_variable
var751
-1
2
adjacent loc_20_10 loc_21_10 down
none-of-those
end_variable
begin_variable
var752
-1
2
adjacent loc_20_11 loc_19_11 up
none-of-those
end_variable
begin_variable
var753
-1
2
adjacent loc_20_11 loc_20_10 left
none-of-those
end_variable
begin_variable
var754
-1
2
adjacent loc_20_11 loc_20_12 right
none-of-those
end_variable
begin_variable
var755
-1
2
adjacent loc_20_11 loc_21_11 down
none-of-those
end_variable
begin_variable
var756
-1
2
adjacent loc_20_12 loc_19_12 up
none-of-those
end_variable
begin_variable
var757
-1
2
adjacent loc_20_12 loc_20_11 left
none-of-those
end_variable
begin_variable
var758
-1
2
adjacent loc_20_12 loc_20_13 right
none-of-those
end_variable
begin_variable
var759
-1
2
adjacent loc_20_12 loc_21_12 down
none-of-those
end_variable
begin_variable
var760
-1
2
adjacent loc_20_13 loc_19_13 up
none-of-those
end_variable
begin_variable
var761
-1
2
adjacent loc_20_13 loc_20_12 left
none-of-those
end_variable
begin_variable
var762
-1
2
adjacent loc_20_13 loc_20_14 right
none-of-those
end_variable
begin_variable
var763
-1
2
adjacent loc_20_13 loc_21_13 down
none-of-those
end_variable
begin_variable
var764
-1
2
adjacent loc_20_14 loc_20_13 left
none-of-those
end_variable
begin_variable
var765
-1
2
adjacent loc_20_14 loc_20_15 right
none-of-those
end_variable
begin_variable
var766
-1
2
adjacent loc_20_15 loc_20_14 left
none-of-those
end_variable
begin_variable
var767
-1
2
adjacent loc_20_15 loc_20_16 right
none-of-those
end_variable
begin_variable
var768
-1
2
adjacent loc_20_16 loc_19_16 up
none-of-those
end_variable
begin_variable
var769
-1
2
adjacent loc_20_16 loc_20_15 left
none-of-those
end_variable
begin_variable
var770
-1
2
adjacent loc_20_16 loc_20_17 right
none-of-those
end_variable
begin_variable
var771
-1
2
adjacent loc_20_16 loc_21_16 down
none-of-those
end_variable
begin_variable
var772
-1
2
adjacent loc_20_17 loc_19_17 up
none-of-those
end_variable
begin_variable
var773
-1
2
adjacent loc_20_17 loc_20_16 left
none-of-those
end_variable
begin_variable
var774
-1
2
adjacent loc_20_17 loc_20_18 right
none-of-those
end_variable
begin_variable
var775
-1
2
adjacent loc_20_17 loc_21_17 down
none-of-those
end_variable
begin_variable
var776
-1
2
adjacent loc_20_18 loc_20_17 left
none-of-those
end_variable
begin_variable
var777
-1
2
adjacent loc_20_18 loc_20_19 right
none-of-those
end_variable
begin_variable
var778
-1
2
adjacent loc_20_18 loc_21_18 down
none-of-those
end_variable
begin_variable
var779
-1
2
adjacent loc_20_19 loc_19_19 up
none-of-those
end_variable
begin_variable
var780
-1
2
adjacent loc_20_19 loc_20_18 left
none-of-those
end_variable
begin_variable
var781
-1
2
adjacent loc_20_19 loc_21_19 down
none-of-those
end_variable
begin_variable
var782
-1
2
adjacent loc_20_5 loc_20_6 right
none-of-those
end_variable
begin_variable
var783
-1
2
adjacent loc_20_6 loc_19_6 up
none-of-those
end_variable
begin_variable
var784
-1
2
adjacent loc_20_6 loc_20_5 left
none-of-those
end_variable
begin_variable
var785
-1
2
adjacent loc_20_6 loc_20_7 right
none-of-those
end_variable
begin_variable
var786
-1
2
adjacent loc_20_7 loc_19_7 up
none-of-those
end_variable
begin_variable
var787
-1
2
adjacent loc_20_7 loc_20_6 left
none-of-those
end_variable
begin_variable
var788
-1
2
adjacent loc_20_7 loc_20_8 right
none-of-those
end_variable
begin_variable
var789
-1
2
adjacent loc_20_8 loc_19_8 up
none-of-those
end_variable
begin_variable
var790
-1
2
adjacent loc_20_8 loc_20_7 left
none-of-those
end_variable
begin_variable
var791
-1
2
adjacent loc_20_8 loc_20_9 right
none-of-those
end_variable
begin_variable
var792
-1
2
adjacent loc_20_8 loc_21_8 down
none-of-those
end_variable
begin_variable
var793
-1
2
adjacent loc_20_9 loc_19_9 up
none-of-those
end_variable
begin_variable
var794
-1
2
adjacent loc_20_9 loc_20_10 right
none-of-those
end_variable
begin_variable
var795
-1
2
adjacent loc_20_9 loc_20_8 left
none-of-those
end_variable
begin_variable
var796
-1
2
adjacent loc_20_9 loc_21_9 down
none-of-those
end_variable
begin_variable
var797
-1
2
adjacent loc_21_10 loc_20_10 up
none-of-those
end_variable
begin_variable
var798
-1
2
adjacent loc_21_10 loc_21_11 right
none-of-those
end_variable
begin_variable
var799
-1
2
adjacent loc_21_10 loc_21_9 left
none-of-those
end_variable
begin_variable
var800
-1
2
adjacent loc_21_11 loc_20_11 up
none-of-those
end_variable
begin_variable
var801
-1
2
adjacent loc_21_11 loc_21_10 left
none-of-those
end_variable
begin_variable
var802
-1
2
adjacent loc_21_11 loc_21_12 right
none-of-those
end_variable
begin_variable
var803
-1
2
adjacent loc_21_12 loc_20_12 up
none-of-those
end_variable
begin_variable
var804
-1
2
adjacent loc_21_12 loc_21_11 left
none-of-those
end_variable
begin_variable
var805
-1
2
adjacent loc_21_12 loc_21_13 right
none-of-those
end_variable
begin_variable
var806
-1
2
adjacent loc_21_13 loc_20_13 up
none-of-those
end_variable
begin_variable
var807
-1
2
adjacent loc_21_13 loc_21_12 left
none-of-those
end_variable
begin_variable
var808
-1
2
adjacent loc_21_16 loc_20_16 up
none-of-those
end_variable
begin_variable
var809
-1
2
adjacent loc_21_16 loc_21_17 right
none-of-those
end_variable
begin_variable
var810
-1
2
adjacent loc_21_17 loc_20_17 up
none-of-those
end_variable
begin_variable
var811
-1
2
adjacent loc_21_17 loc_21_16 left
none-of-those
end_variable
begin_variable
var812
-1
2
adjacent loc_21_17 loc_21_18 right
none-of-those
end_variable
begin_variable
var813
-1
2
adjacent loc_21_18 loc_20_18 up
none-of-those
end_variable
begin_variable
var814
-1
2
adjacent loc_21_18 loc_21_17 left
none-of-those
end_variable
begin_variable
var815
-1
2
adjacent loc_21_18 loc_21_19 right
none-of-those
end_variable
begin_variable
var816
-1
2
adjacent loc_21_19 loc_20_19 up
none-of-those
end_variable
begin_variable
var817
-1
2
adjacent loc_21_19 loc_21_18 left
none-of-those
end_variable
begin_variable
var818
-1
2
adjacent loc_21_19 loc_21_20 right
none-of-those
end_variable
begin_variable
var819
-1
2
adjacent loc_21_20 loc_21_19 left
none-of-those
end_variable
begin_variable
var820
-1
2
adjacent loc_21_8 loc_20_8 up
none-of-those
end_variable
begin_variable
var821
-1
2
adjacent loc_21_8 loc_21_9 right
none-of-those
end_variable
begin_variable
var822
-1
2
adjacent loc_21_9 loc_20_9 up
none-of-those
end_variable
begin_variable
var823
-1
2
adjacent loc_21_9 loc_21_10 right
none-of-those
end_variable
begin_variable
var824
-1
2
adjacent loc_21_9 loc_21_8 left
none-of-those
end_variable
begin_variable
var825
-1
2
adjacent loc_2_13 loc_2_14 right
none-of-those
end_variable
begin_variable
var826
-1
2
adjacent loc_2_13 loc_3_13 down
none-of-those
end_variable
begin_variable
var827
-1
2
adjacent loc_2_14 loc_2_13 left
none-of-those
end_variable
begin_variable
var828
-1
2
adjacent loc_2_14 loc_3_14 down
none-of-those
end_variable
begin_variable
var829
-1
2
adjacent loc_2_18 loc_2_19 right
none-of-those
end_variable
begin_variable
var830
-1
2
adjacent loc_2_19 loc_2_18 left
none-of-those
end_variable
begin_variable
var831
-1
2
adjacent loc_2_2 loc_2_3 right
none-of-those
end_variable
begin_variable
var832
-1
2
adjacent loc_2_2 loc_3_2 down
none-of-those
end_variable
begin_variable
var833
-1
2
adjacent loc_2_21 loc_3_21 down
none-of-those
end_variable
begin_variable
var834
-1
2
adjacent loc_2_3 loc_2_2 left
none-of-those
end_variable
begin_variable
var835
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var836
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var837
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var838
-1
2
adjacent loc_2_4 loc_2_5 right
none-of-those
end_variable
begin_variable
var839
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var840
-1
2
adjacent loc_2_5 loc_2_4 left
none-of-those
end_variable
begin_variable
var841
-1
2
adjacent loc_2_5 loc_2_6 right
none-of-those
end_variable
begin_variable
var842
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var843
-1
2
adjacent loc_2_6 loc_2_5 left
none-of-those
end_variable
begin_variable
var844
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var845
-1
2
adjacent loc_2_9 loc_3_9 down
none-of-those
end_variable
begin_variable
var846
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var847
-1
2
adjacent loc_3_10 loc_3_9 left
none-of-those
end_variable
begin_variable
var848
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var849
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var850
-1
2
adjacent loc_3_11 loc_3_12 right
none-of-those
end_variable
begin_variable
var851
-1
2
adjacent loc_3_11 loc_4_11 down
none-of-those
end_variable
begin_variable
var852
-1
2
adjacent loc_3_12 loc_3_11 left
none-of-those
end_variable
begin_variable
var853
-1
2
adjacent loc_3_12 loc_3_13 right
none-of-those
end_variable
begin_variable
var854
-1
2
adjacent loc_3_12 loc_4_12 down
none-of-those
end_variable
begin_variable
var855
-1
2
adjacent loc_3_13 loc_2_13 up
none-of-those
end_variable
begin_variable
var856
-1
2
adjacent loc_3_13 loc_3_12 left
none-of-those
end_variable
begin_variable
var857
-1
2
adjacent loc_3_13 loc_3_14 right
none-of-those
end_variable
begin_variable
var858
-1
2
adjacent loc_3_13 loc_4_13 down
none-of-those
end_variable
begin_variable
var859
-1
2
adjacent loc_3_14 loc_2_14 up
none-of-those
end_variable
begin_variable
var860
-1
2
adjacent loc_3_14 loc_3_13 left
none-of-those
end_variable
begin_variable
var861
-1
2
adjacent loc_3_14 loc_3_15 right
none-of-those
end_variable
begin_variable
var862
-1
2
adjacent loc_3_14 loc_4_14 down
none-of-those
end_variable
begin_variable
var863
-1
2
adjacent loc_3_15 loc_3_14 left
none-of-those
end_variable
begin_variable
var864
-1
2
adjacent loc_3_15 loc_3_16 right
none-of-those
end_variable
begin_variable
var865
-1
2
adjacent loc_3_16 loc_3_15 left
none-of-those
end_variable
begin_variable
var866
-1
2
adjacent loc_3_16 loc_3_17 right
none-of-those
end_variable
begin_variable
var867
-1
2
adjacent loc_3_17 loc_3_16 left
none-of-those
end_variable
begin_variable
var868
-1
2
adjacent loc_3_17 loc_4_17 down
none-of-those
end_variable
begin_variable
var869
-1
2
adjacent loc_3_2 loc_2_2 up
none-of-those
end_variable
begin_variable
var870
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var871
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var872
-1
2
adjacent loc_3_20 loc_3_21 right
none-of-those
end_variable
begin_variable
var873
-1
2
adjacent loc_3_20 loc_4_20 down
none-of-those
end_variable
begin_variable
var874
-1
2
adjacent loc_3_21 loc_2_21 up
none-of-those
end_variable
begin_variable
var875
-1
2
adjacent loc_3_21 loc_3_20 left
none-of-those
end_variable
begin_variable
var876
-1
2
adjacent loc_3_21 loc_4_21 down
none-of-those
end_variable
begin_variable
var877
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var878
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var879
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var880
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var881
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var882
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var883
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var884
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var885
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var886
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var887
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var888
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var889
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var890
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var891
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var892
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var893
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var894
-1
2
adjacent loc_3_8 loc_3_9 right
none-of-those
end_variable
begin_variable
var895
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var896
-1
2
adjacent loc_3_9 loc_2_9 up
none-of-those
end_variable
begin_variable
var897
-1
2
adjacent loc_3_9 loc_3_10 right
none-of-those
end_variable
begin_variable
var898
-1
2
adjacent loc_3_9 loc_3_8 left
none-of-those
end_variable
begin_variable
var899
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var900
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var901
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var902
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var903
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var904
-1
2
adjacent loc_4_11 loc_3_11 up
none-of-those
end_variable
begin_variable
var905
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var906
-1
2
adjacent loc_4_11 loc_4_12 right
none-of-those
end_variable
begin_variable
var907
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var908
-1
2
adjacent loc_4_12 loc_3_12 up
none-of-those
end_variable
begin_variable
var909
-1
2
adjacent loc_4_12 loc_4_11 left
none-of-those
end_variable
begin_variable
var910
-1
2
adjacent loc_4_12 loc_4_13 right
none-of-those
end_variable
begin_variable
var911
-1
2
adjacent loc_4_12 loc_5_12 down
none-of-those
end_variable
begin_variable
var912
-1
2
adjacent loc_4_13 loc_3_13 up
none-of-those
end_variable
begin_variable
var913
-1
2
adjacent loc_4_13 loc_4_12 left
none-of-those
end_variable
begin_variable
var914
-1
2
adjacent loc_4_13 loc_4_14 right
none-of-those
end_variable
begin_variable
var915
-1
2
adjacent loc_4_14 loc_3_14 up
none-of-those
end_variable
begin_variable
var916
-1
2
adjacent loc_4_14 loc_4_13 left
none-of-those
end_variable
begin_variable
var917
-1
2
adjacent loc_4_14 loc_5_14 down
none-of-those
end_variable
begin_variable
var918
-1
2
adjacent loc_4_17 loc_3_17 up
none-of-those
end_variable
begin_variable
var919
-1
2
adjacent loc_4_17 loc_5_17 down
none-of-those
end_variable
begin_variable
var920
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var921
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var922
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var923
-1
2
adjacent loc_4_20 loc_3_20 up
none-of-those
end_variable
begin_variable
var924
-1
2
adjacent loc_4_20 loc_4_21 right
none-of-those
end_variable
begin_variable
var925
-1
2
adjacent loc_4_20 loc_5_20 down
none-of-those
end_variable
begin_variable
var926
-1
2
adjacent loc_4_21 loc_3_21 up
none-of-those
end_variable
begin_variable
var927
-1
2
adjacent loc_4_21 loc_4_20 left
none-of-those
end_variable
begin_variable
var928
-1
2
adjacent loc_4_21 loc_5_21 down
none-of-those
end_variable
begin_variable
var929
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var930
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var931
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var932
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var933
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var934
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var935
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var936
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var937
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var938
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var939
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var940
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var941
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var942
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var943
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var944
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var945
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var946
-1
2
adjacent loc_5_11 loc_5_12 right
none-of-those
end_variable
begin_variable
var947
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var948
-1
2
adjacent loc_5_12 loc_4_12 up
none-of-those
end_variable
begin_variable
var949
-1
2
adjacent loc_5_12 loc_5_11 left
none-of-those
end_variable
begin_variable
var950
-1
2
adjacent loc_5_12 loc_6_12 down
none-of-those
end_variable
begin_variable
var951
-1
2
adjacent loc_5_14 loc_4_14 up
none-of-those
end_variable
begin_variable
var952
-1
2
adjacent loc_5_14 loc_6_14 down
none-of-those
end_variable
begin_variable
var953
-1
2
adjacent loc_5_16 loc_5_17 right
none-of-those
end_variable
begin_variable
var954
-1
2
adjacent loc_5_16 loc_6_16 down
none-of-those
end_variable
begin_variable
var955
-1
2
adjacent loc_5_17 loc_4_17 up
none-of-those
end_variable
begin_variable
var956
-1
2
adjacent loc_5_17 loc_5_16 left
none-of-those
end_variable
begin_variable
var957
-1
2
adjacent loc_5_17 loc_5_18 right
none-of-those
end_variable
begin_variable
var958
-1
2
adjacent loc_5_17 loc_6_17 down
none-of-those
end_variable
begin_variable
var959
-1
2
adjacent loc_5_18 loc_5_17 left
none-of-those
end_variable
begin_variable
var960
-1
2
adjacent loc_5_18 loc_5_19 right
none-of-those
end_variable
begin_variable
var961
-1
2
adjacent loc_5_18 loc_6_18 down
none-of-those
end_variable
begin_variable
var962
-1
2
adjacent loc_5_19 loc_5_18 left
none-of-those
end_variable
begin_variable
var963
-1
2
adjacent loc_5_19 loc_5_20 right
none-of-those
end_variable
begin_variable
var964
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var965
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var966
-1
2
adjacent loc_5_20 loc_4_20 up
none-of-those
end_variable
begin_variable
var967
-1
2
adjacent loc_5_20 loc_5_19 left
none-of-those
end_variable
begin_variable
var968
-1
2
adjacent loc_5_20 loc_5_21 right
none-of-those
end_variable
begin_variable
var969
-1
2
adjacent loc_5_20 loc_6_20 down
none-of-those
end_variable
begin_variable
var970
-1
2
adjacent loc_5_21 loc_4_21 up
none-of-those
end_variable
begin_variable
var971
-1
2
adjacent loc_5_21 loc_5_20 left
none-of-those
end_variable
begin_variable
var972
-1
2
adjacent loc_5_21 loc_6_21 down
none-of-those
end_variable
begin_variable
var973
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var974
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var975
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var976
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var977
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var978
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var979
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var980
-1
2
adjacent loc_6_11 loc_6_12 right
none-of-those
end_variable
begin_variable
var981
-1
2
adjacent loc_6_12 loc_5_12 up
none-of-those
end_variable
begin_variable
var982
-1
2
adjacent loc_6_12 loc_6_11 left
none-of-those
end_variable
begin_variable
var983
-1
2
adjacent loc_6_12 loc_6_13 right
none-of-those
end_variable
begin_variable
var984
-1
2
adjacent loc_6_13 loc_6_12 left
none-of-those
end_variable
begin_variable
var985
-1
2
adjacent loc_6_13 loc_6_14 right
none-of-those
end_variable
begin_variable
var986
-1
2
adjacent loc_6_14 loc_5_14 up
none-of-those
end_variable
begin_variable
var987
-1
2
adjacent loc_6_14 loc_6_13 left
none-of-those
end_variable
begin_variable
var988
-1
2
adjacent loc_6_14 loc_7_14 down
none-of-those
end_variable
begin_variable
var989
-1
2
adjacent loc_6_16 loc_5_16 up
none-of-those
end_variable
begin_variable
var990
-1
2
adjacent loc_6_16 loc_6_17 right
none-of-those
end_variable
begin_variable
var991
-1
2
adjacent loc_6_17 loc_5_17 up
none-of-those
end_variable
begin_variable
var992
-1
2
adjacent loc_6_17 loc_6_16 left
none-of-those
end_variable
begin_variable
var993
-1
2
adjacent loc_6_17 loc_6_18 right
none-of-those
end_variable
begin_variable
var994
-1
2
adjacent loc_6_18 loc_5_18 up
none-of-those
end_variable
begin_variable
var995
-1
2
adjacent loc_6_18 loc_6_17 left
none-of-those
end_variable
begin_variable
var996
-1
2
adjacent loc_6_18 loc_7_18 down
none-of-those
end_variable
begin_variable
var997
-1
2
adjacent loc_6_20 loc_5_20 up
none-of-those
end_variable
begin_variable
var998
-1
2
adjacent loc_6_20 loc_6_21 right
none-of-those
end_variable
begin_variable
var999
-1
2
adjacent loc_6_21 loc_5_21 up
none-of-those
end_variable
begin_variable
var1000
-1
2
adjacent loc_6_21 loc_6_20 left
none-of-those
end_variable
begin_variable
var1001
-1
2
adjacent loc_6_21 loc_7_21 down
none-of-those
end_variable
begin_variable
var1002
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var1003
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var1004
-1
2
adjacent loc_6_8 loc_6_9 right
none-of-those
end_variable
begin_variable
var1005
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var1006
-1
2
adjacent loc_6_9 loc_6_8 left
none-of-those
end_variable
begin_variable
var1007
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var1008
-1
2
adjacent loc_7_14 loc_6_14 up
none-of-those
end_variable
begin_variable
var1009
-1
2
adjacent loc_7_14 loc_7_15 right
none-of-those
end_variable
begin_variable
var1010
-1
2
adjacent loc_7_14 loc_8_14 down
none-of-those
end_variable
begin_variable
var1011
-1
2
adjacent loc_7_15 loc_7_14 left
none-of-those
end_variable
begin_variable
var1012
-1
2
adjacent loc_7_15 loc_8_15 down
none-of-those
end_variable
begin_variable
var1013
-1
2
adjacent loc_7_18 loc_6_18 up
none-of-those
end_variable
begin_variable
var1014
-1
2
adjacent loc_7_18 loc_7_19 right
none-of-those
end_variable
begin_variable
var1015
-1
2
adjacent loc_7_18 loc_8_18 down
none-of-those
end_variable
begin_variable
var1016
-1
2
adjacent loc_7_19 loc_7_18 left
none-of-those
end_variable
begin_variable
var1017
-1
2
adjacent loc_7_21 loc_6_21 up
none-of-those
end_variable
begin_variable
var1018
-1
2
adjacent loc_7_21 loc_8_21 down
none-of-those
end_variable
begin_variable
var1019
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var1020
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var1021
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var1022
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var1023
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var1024
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var1025
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var1026
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var1027
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var1028
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var1029
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var1030
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var1031
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var1032
-1
2
adjacent loc_8_14 loc_7_14 up
none-of-those
end_variable
begin_variable
var1033
-1
2
adjacent loc_8_14 loc_8_15 right
none-of-those
end_variable
begin_variable
var1034
-1
2
adjacent loc_8_15 loc_7_15 up
none-of-those
end_variable
begin_variable
var1035
-1
2
adjacent loc_8_15 loc_8_14 left
none-of-those
end_variable
begin_variable
var1036
-1
2
adjacent loc_8_15 loc_8_16 right
none-of-those
end_variable
begin_variable
var1037
-1
2
adjacent loc_8_15 loc_9_15 down
none-of-those
end_variable
begin_variable
var1038
-1
2
adjacent loc_8_16 loc_8_15 left
none-of-those
end_variable
begin_variable
var1039
-1
2
adjacent loc_8_16 loc_8_17 right
none-of-those
end_variable
begin_variable
var1040
-1
2
adjacent loc_8_16 loc_9_16 down
none-of-those
end_variable
begin_variable
var1041
-1
2
adjacent loc_8_17 loc_8_16 left
none-of-those
end_variable
begin_variable
var1042
-1
2
adjacent loc_8_17 loc_8_18 right
none-of-those
end_variable
begin_variable
var1043
-1
2
adjacent loc_8_17 loc_9_17 down
none-of-those
end_variable
begin_variable
var1044
-1
2
adjacent loc_8_18 loc_7_18 up
none-of-those
end_variable
begin_variable
var1045
-1
2
adjacent loc_8_18 loc_8_17 left
none-of-those
end_variable
begin_variable
var1046
-1
2
adjacent loc_8_18 loc_9_18 down
none-of-those
end_variable
begin_variable
var1047
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var1048
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var1049
-1
2
adjacent loc_8_20 loc_8_21 right
none-of-those
end_variable
begin_variable
var1050
-1
2
adjacent loc_8_20 loc_9_20 down
none-of-those
end_variable
begin_variable
var1051
-1
2
adjacent loc_8_21 loc_7_21 up
none-of-those
end_variable
begin_variable
var1052
-1
2
adjacent loc_8_21 loc_8_20 left
none-of-those
end_variable
begin_variable
var1053
-1
2
adjacent loc_8_21 loc_9_21 down
none-of-those
end_variable
begin_variable
var1054
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var1055
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var1056
-1
2
adjacent loc_8_3 loc_9_3 down
none-of-those
end_variable
begin_variable
var1057
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var1058
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var1059
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var1060
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var1061
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var1062
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var1063
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var1064
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var1065
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var1066
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var1067
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var1068
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var1069
-1
2
adjacent loc_9_15 loc_10_15 down
none-of-those
end_variable
begin_variable
var1070
-1
2
adjacent loc_9_15 loc_8_15 up
none-of-those
end_variable
begin_variable
var1071
-1
2
adjacent loc_9_15 loc_9_16 right
none-of-those
end_variable
begin_variable
var1072
-1
2
adjacent loc_9_16 loc_8_16 up
none-of-those
end_variable
begin_variable
var1073
-1
2
adjacent loc_9_16 loc_9_15 left
none-of-those
end_variable
begin_variable
var1074
-1
2
adjacent loc_9_16 loc_9_17 right
none-of-those
end_variable
begin_variable
var1075
-1
2
adjacent loc_9_17 loc_10_17 down
none-of-those
end_variable
begin_variable
var1076
-1
2
adjacent loc_9_17 loc_8_17 up
none-of-those
end_variable
begin_variable
var1077
-1
2
adjacent loc_9_17 loc_9_16 left
none-of-those
end_variable
begin_variable
var1078
-1
2
adjacent loc_9_17 loc_9_18 right
none-of-those
end_variable
begin_variable
var1079
-1
2
adjacent loc_9_18 loc_8_18 up
none-of-those
end_variable
begin_variable
var1080
-1
2
adjacent loc_9_18 loc_9_17 left
none-of-those
end_variable
begin_variable
var1081
-1
2
adjacent loc_9_18 loc_9_19 right
none-of-those
end_variable
begin_variable
var1082
-1
2
adjacent loc_9_19 loc_10_19 down
none-of-those
end_variable
begin_variable
var1083
-1
2
adjacent loc_9_19 loc_9_18 left
none-of-those
end_variable
begin_variable
var1084
-1
2
adjacent loc_9_19 loc_9_20 right
none-of-those
end_variable
begin_variable
var1085
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var1086
-1
2
adjacent loc_9_2 loc_9_3 right
none-of-those
end_variable
begin_variable
var1087
-1
2
adjacent loc_9_20 loc_8_20 up
none-of-those
end_variable
begin_variable
var1088
-1
2
adjacent loc_9_20 loc_9_19 left
none-of-those
end_variable
begin_variable
var1089
-1
2
adjacent loc_9_20 loc_9_21 right
none-of-those
end_variable
begin_variable
var1090
-1
2
adjacent loc_9_21 loc_8_21 up
none-of-those
end_variable
begin_variable
var1091
-1
2
adjacent loc_9_21 loc_9_20 left
none-of-those
end_variable
begin_variable
var1092
-1
2
adjacent loc_9_3 loc_10_3 down
none-of-those
end_variable
begin_variable
var1093
-1
2
adjacent loc_9_3 loc_8_3 up
none-of-those
end_variable
begin_variable
var1094
-1
2
adjacent loc_9_3 loc_9_2 left
none-of-those
end_variable
begin_variable
var1095
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var1096
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var1097
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var1098
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var1099
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var1100
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var1101
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
0
begin_state
233
63
139
61
73
192
57
9
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
7
1 68
2 147
3 5
4 181
5 38
6 53
7 8
end_goal
3274
begin_operator
move loc_10_10 loc_10_9 left
2
120 0
286 0
1
0 0 0 9
1
end_operator
begin_operator
move loc_10_10 loc_11_10 down
2
122 0
287 0
1
0 0 0 10
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
119 0
288 0
1
0 0 0 251
1
end_operator
begin_operator
move loc_10_12 loc_11_12 down
2
126 0
289 0
1
0 0 1 12
1
end_operator
begin_operator
move loc_10_14 loc_10_15 right
2
108 0
290 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_14 loc_11_14 down
2
130 0
291 0
1
0 0 2 14
1
end_operator
begin_operator
move loc_10_15 loc_10_14 left
2
106 0
292 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_15 loc_11_15 down
2
132 0
293 0
1
0 0 3 15
1
end_operator
begin_operator
move loc_10_15 loc_9_15 up
2
125 0
294 0
1
0 0 3 253
1
end_operator
begin_operator
move loc_10_17 loc_11_17 down
2
136 0
295 0
1
0 0 4 17
1
end_operator
begin_operator
move loc_10_17 loc_9_17 up
2
129 0
296 0
1
0 0 4 255
1
end_operator
begin_operator
move loc_10_19 loc_11_19 down
2
140 0
297 0
1
0 0 5 19
1
end_operator
begin_operator
move loc_10_19 loc_9_19 up
2
133 0
298 0
1
0 0 5 257
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
116 0
299 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
144 0
300 0
1
0 0 6 21
1
end_operator
begin_operator
move loc_10_3 loc_9_3 up
2
141 0
301 0
1
0 0 6 261
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
114 0
302 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
118 0
303 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_4 loc_11_4 down
2
146 0
304 0
1
0 0 7 22
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
143 0
305 0
1
0 0 7 262
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
116 0
306 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
147 0
307 0
1
0 0 8 23
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
145 0
308 0
1
0 0 8 263
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
102 0
309 0
1
0 0 9 0
1
end_operator
begin_operator
move loc_10_9 loc_11_9 down
2
151 0
310 0
1
0 0 9 27
1
end_operator
begin_operator
move loc_11_10 loc_10_10 up
2
102 0
311 0
1
0 0 10 0
1
end_operator
begin_operator
move loc_11_10 loc_11_11 right
2
124 0
312 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_11_10 loc_11_9 left
2
151 0
313 0
1
0 0 10 27
1
end_operator
begin_operator
move loc_11_10 loc_12_10 down
2
152 0
314 0
1
0 0 10 28
1
end_operator
begin_operator
move loc_11_11 loc_11_10 left
2
122 0
315 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_11_11 loc_11_12 right
2
126 0
316 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_11 loc_12_11 down
2
153 0
317 0
1
0 0 11 29
1
end_operator
begin_operator
move loc_11_12 loc_10_12 up
2
104 0
318 0
1
0 0 12 1
1
end_operator
begin_operator
move loc_11_12 loc_11_11 left
2
124 0
319 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_12 loc_11_13 right
2
128 0
320 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_12 loc_12_12 down
2
154 0
321 0
1
0 0 12 30
1
end_operator
begin_operator
move loc_11_13 loc_11_12 left
2
126 0
322 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_13 loc_11_14 right
2
130 0
323 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_11_13 loc_12_13 down
2
155 0
324 0
1
0 0 13 31
1
end_operator
begin_operator
move loc_11_14 loc_10_14 up
2
106 0
325 0
1
0 0 14 2
1
end_operator
begin_operator
move loc_11_14 loc_11_13 left
2
128 0
326 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_11_14 loc_11_15 right
2
132 0
327 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_11_14 loc_12_14 down
2
156 0
328 0
1
0 0 14 32
1
end_operator
begin_operator
move loc_11_15 loc_10_15 up
2
108 0
329 0
1
0 0 15 3
1
end_operator
begin_operator
move loc_11_15 loc_11_14 left
2
130 0
330 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_11_15 loc_11_16 right
2
134 0
331 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_11_15 loc_12_15 down
2
157 0
332 0
1
0 0 15 33
1
end_operator
begin_operator
move loc_11_16 loc_11_15 left
2
132 0
333 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_11_16 loc_11_17 right
2
136 0
334 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_11_16 loc_12_16 down
2
158 0
335 0
1
0 0 16 34
1
end_operator
begin_operator
move loc_11_17 loc_10_17 up
2
110 0
336 0
1
0 0 17 4
1
end_operator
begin_operator
move loc_11_17 loc_11_16 left
2
134 0
337 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_11_17 loc_11_18 right
2
138 0
338 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_11_17 loc_12_17 down
2
159 0
339 0
1
0 0 17 35
1
end_operator
begin_operator
move loc_11_18 loc_11_17 left
2
136 0
340 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_11_18 loc_11_19 right
2
140 0
341 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_11_18 loc_12_18 down
2
160 0
342 0
1
0 0 18 36
1
end_operator
begin_operator
move loc_11_19 loc_10_19 up
2
112 0
343 0
1
0 0 19 5
1
end_operator
begin_operator
move loc_11_19 loc_11_18 left
2
138 0
344 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_11_19 loc_11_20 right
2
142 0
345 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_11_19 loc_12_19 down
2
161 0
346 0
1
0 0 19 37
1
end_operator
begin_operator
move loc_11_20 loc_11_19 left
2
140 0
347 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_11_20 loc_12_20 down
2
163 0
348 0
1
0 0 20 38
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
114 0
349 0
1
0 0 21 6
1
end_operator
begin_operator
move loc_11_3 loc_11_4 right
2
146 0
350 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_11_4 loc_10_4 up
2
116 0
351 0
1
0 0 22 7
1
end_operator
begin_operator
move loc_11_4 loc_11_3 left
2
144 0
352 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_11_4 loc_11_5 right
2
147 0
353 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
118 0
354 0
1
0 0 23 8
1
end_operator
begin_operator
move loc_11_5 loc_11_4 left
2
146 0
355 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
148 0
356 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_11_5 loc_12_5 down
2
164 0
357 0
1
0 0 23 39
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
147 0
358 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_11_6 loc_11_7 right
2
149 0
359 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_11_6 loc_12_6 down
2
165 0
360 0
1
0 0 24 40
1
end_operator
begin_operator
move loc_11_7 loc_11_6 left
2
148 0
361 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_11_7 loc_11_8 right
2
150 0
362 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_11_7 loc_12_7 down
2
166 0
363 0
1
0 0 25 41
1
end_operator
begin_operator
move loc_11_8 loc_11_7 left
2
149 0
364 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
151 0
365 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_11_8 loc_12_8 down
2
167 0
366 0
1
0 0 26 42
1
end_operator
begin_operator
move loc_11_9 loc_10_9 up
2
120 0
367 0
1
0 0 27 9
1
end_operator
begin_operator
move loc_11_9 loc_11_10 right
2
122 0
368 0
1
0 0 27 10
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
150 0
369 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_11_9 loc_12_9 down
2
168 0
370 0
1
0 0 27 43
1
end_operator
begin_operator
move loc_12_10 loc_11_10 up
2
122 0
371 0
1
0 0 28 10
1
end_operator
begin_operator
move loc_12_10 loc_12_11 right
2
153 0
372 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_12_10 loc_12_9 left
2
168 0
373 0
1
0 0 28 43
1
end_operator
begin_operator
move loc_12_10 loc_13_10 down
2
169 0
374 0
1
0 0 28 44
1
end_operator
begin_operator
move loc_12_11 loc_11_11 up
2
124 0
375 0
1
0 0 29 11
1
end_operator
begin_operator
move loc_12_11 loc_12_10 left
2
152 0
376 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_12_11 loc_12_12 right
2
154 0
377 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_12_11 loc_13_11 down
2
170 0
378 0
1
0 0 29 45
1
end_operator
begin_operator
move loc_12_12 loc_11_12 up
2
126 0
379 0
1
0 0 30 12
1
end_operator
begin_operator
move loc_12_12 loc_12_11 left
2
153 0
380 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_12_12 loc_12_13 right
2
155 0
381 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_12_12 loc_13_12 down
2
171 0
382 0
1
0 0 30 46
1
end_operator
begin_operator
move loc_12_13 loc_11_13 up
2
128 0
383 0
1
0 0 31 13
1
end_operator
begin_operator
move loc_12_13 loc_12_12 left
2
154 0
384 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_12_13 loc_12_14 right
2
156 0
385 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_12_13 loc_13_13 down
2
172 0
386 0
1
0 0 31 47
1
end_operator
begin_operator
move loc_12_14 loc_11_14 up
2
130 0
387 0
1
0 0 32 14
1
end_operator
begin_operator
move loc_12_14 loc_12_13 left
2
155 0
388 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_12_14 loc_12_15 right
2
157 0
389 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_12_14 loc_13_14 down
2
173 0
390 0
1
0 0 32 48
1
end_operator
begin_operator
move loc_12_15 loc_11_15 up
2
132 0
391 0
1
0 0 33 15
1
end_operator
begin_operator
move loc_12_15 loc_12_14 left
2
156 0
392 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_12_15 loc_12_16 right
2
158 0
393 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_12_15 loc_13_15 down
2
174 0
394 0
1
0 0 33 49
1
end_operator
begin_operator
move loc_12_16 loc_11_16 up
2
134 0
395 0
1
0 0 34 16
1
end_operator
begin_operator
move loc_12_16 loc_12_15 left
2
157 0
396 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_12_16 loc_12_17 right
2
159 0
397 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_12_17 loc_11_17 up
2
136 0
398 0
1
0 0 35 17
1
end_operator
begin_operator
move loc_12_17 loc_12_16 left
2
158 0
399 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_12_17 loc_12_18 right
2
160 0
400 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_12_17 loc_13_17 down
2
175 0
401 0
1
0 0 35 50
1
end_operator
begin_operator
move loc_12_18 loc_11_18 up
2
138 0
402 0
1
0 0 36 18
1
end_operator
begin_operator
move loc_12_18 loc_12_17 left
2
159 0
403 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_12_18 loc_12_19 right
2
161 0
404 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_12_18 loc_13_18 down
2
176 0
405 0
1
0 0 36 51
1
end_operator
begin_operator
move loc_12_19 loc_11_19 up
2
140 0
406 0
1
0 0 37 19
1
end_operator
begin_operator
move loc_12_19 loc_12_18 left
2
160 0
407 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_12_19 loc_12_20 right
2
163 0
408 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_12_19 loc_13_19 down
2
177 0
409 0
1
0 0 37 52
1
end_operator
begin_operator
move loc_12_20 loc_11_20 up
2
142 0
410 0
1
0 0 38 20
1
end_operator
begin_operator
move loc_12_20 loc_12_19 left
2
161 0
411 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_12_20 loc_13_20 down
2
178 0
412 0
1
0 0 38 53
1
end_operator
begin_operator
move loc_12_5 loc_11_5 up
2
147 0
413 0
1
0 0 39 23
1
end_operator
begin_operator
move loc_12_5 loc_12_6 right
2
165 0
414 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_12_5 loc_13_5 down
2
180 0
415 0
1
0 0 39 55
1
end_operator
begin_operator
move loc_12_6 loc_11_6 up
2
148 0
416 0
1
0 0 40 24
1
end_operator
begin_operator
move loc_12_6 loc_12_5 left
2
164 0
417 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_12_6 loc_12_7 right
2
166 0
418 0
1
0 0 40 41
1
end_operator
begin_operator
move loc_12_6 loc_13_6 down
2
181 0
419 0
1
0 0 40 56
1
end_operator
begin_operator
move loc_12_7 loc_11_7 up
2
149 0
420 0
1
0 0 41 25
1
end_operator
begin_operator
move loc_12_7 loc_12_6 left
2
165 0
421 0
1
0 0 41 40
1
end_operator
begin_operator
move loc_12_7 loc_12_8 right
2
167 0
422 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_12_7 loc_13_7 down
2
182 0
423 0
1
0 0 41 57
1
end_operator
begin_operator
move loc_12_8 loc_11_8 up
2
150 0
424 0
1
0 0 42 26
1
end_operator
begin_operator
move loc_12_8 loc_12_7 left
2
166 0
425 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_12_8 loc_12_9 right
2
168 0
426 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_12_8 loc_13_8 down
2
183 0
427 0
1
0 0 42 58
1
end_operator
begin_operator
move loc_12_9 loc_11_9 up
2
151 0
428 0
1
0 0 43 27
1
end_operator
begin_operator
move loc_12_9 loc_12_10 right
2
152 0
429 0
1
0 0 43 28
1
end_operator
begin_operator
move loc_12_9 loc_12_8 left
2
167 0
430 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_12_9 loc_13_9 down
2
184 0
431 0
1
0 0 43 59
1
end_operator
begin_operator
move loc_13_10 loc_12_10 up
2
152 0
432 0
1
0 0 44 28
1
end_operator
begin_operator
move loc_13_10 loc_13_11 right
2
170 0
433 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_13_10 loc_13_9 left
2
184 0
434 0
1
0 0 44 59
1
end_operator
begin_operator
move loc_13_10 loc_14_10 down
2
185 0
435 0
1
0 0 44 60
1
end_operator
begin_operator
move loc_13_11 loc_12_11 up
2
153 0
436 0
1
0 0 45 29
1
end_operator
begin_operator
move loc_13_11 loc_13_10 left
2
169 0
437 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_13_11 loc_13_12 right
2
171 0
438 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_13_11 loc_14_11 down
2
186 0
439 0
1
0 0 45 61
1
end_operator
begin_operator
move loc_13_12 loc_12_12 up
2
154 0
440 0
1
0 0 46 30
1
end_operator
begin_operator
move loc_13_12 loc_13_11 left
2
170 0
441 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_13_12 loc_13_13 right
2
172 0
442 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_13_12 loc_14_12 down
2
187 0
443 0
1
0 0 46 62
1
end_operator
begin_operator
move loc_13_13 loc_12_13 up
2
155 0
444 0
1
0 0 47 31
1
end_operator
begin_operator
move loc_13_13 loc_13_12 left
2
171 0
445 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_13_13 loc_13_14 right
2
173 0
446 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_13_13 loc_14_13 down
2
188 0
447 0
1
0 0 47 63
1
end_operator
begin_operator
move loc_13_14 loc_12_14 up
2
156 0
448 0
1
0 0 48 32
1
end_operator
begin_operator
move loc_13_14 loc_13_13 left
2
172 0
449 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_13_14 loc_13_15 right
2
174 0
450 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_13_14 loc_14_14 down
2
189 0
451 0
1
0 0 48 64
1
end_operator
begin_operator
move loc_13_15 loc_12_15 up
2
157 0
452 0
1
0 0 49 33
1
end_operator
begin_operator
move loc_13_15 loc_13_14 left
2
173 0
453 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_13_15 loc_14_15 down
2
190 0
454 0
1
0 0 49 65
1
end_operator
begin_operator
move loc_13_17 loc_12_17 up
2
159 0
455 0
1
0 0 50 35
1
end_operator
begin_operator
move loc_13_17 loc_13_18 right
2
176 0
456 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_13_17 loc_14_17 down
2
192 0
457 0
1
0 0 50 67
1
end_operator
begin_operator
move loc_13_18 loc_12_18 up
2
160 0
458 0
1
0 0 51 36
1
end_operator
begin_operator
move loc_13_18 loc_13_17 left
2
175 0
459 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_13_18 loc_13_19 right
2
177 0
460 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_13_18 loc_14_18 down
2
193 0
461 0
1
0 0 51 68
1
end_operator
begin_operator
move loc_13_19 loc_12_19 up
2
161 0
462 0
1
0 0 52 37
1
end_operator
begin_operator
move loc_13_19 loc_13_18 left
2
176 0
463 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_13_19 loc_13_20 right
2
178 0
464 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_13_19 loc_14_19 down
2
194 0
465 0
1
0 0 52 69
1
end_operator
begin_operator
move loc_13_20 loc_12_20 up
2
163 0
466 0
1
0 0 53 38
1
end_operator
begin_operator
move loc_13_20 loc_13_19 left
2
177 0
467 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_13_20 loc_13_21 right
2
179 0
468 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_13_20 loc_14_20 down
2
196 0
469 0
1
0 0 53 70
1
end_operator
begin_operator
move loc_13_21 loc_13_20 left
2
178 0
470 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_13_5 loc_12_5 up
2
164 0
471 0
1
0 0 55 39
1
end_operator
begin_operator
move loc_13_5 loc_13_6 right
2
181 0
472 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_13_5 loc_14_5 down
2
198 0
473 0
1
0 0 55 71
1
end_operator
begin_operator
move loc_13_6 loc_12_6 up
2
165 0
474 0
1
0 0 56 40
1
end_operator
begin_operator
move loc_13_6 loc_13_5 left
2
180 0
475 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_13_6 loc_13_7 right
2
182 0
476 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_13_6 loc_14_6 down
2
199 0
477 0
1
0 0 56 72
1
end_operator
begin_operator
move loc_13_7 loc_12_7 up
2
166 0
478 0
1
0 0 57 41
1
end_operator
begin_operator
move loc_13_7 loc_13_6 left
2
181 0
479 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_13_7 loc_13_8 right
2
183 0
480 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_13_7 loc_14_7 down
2
200 0
481 0
1
0 0 57 73
1
end_operator
begin_operator
move loc_13_8 loc_12_8 up
2
167 0
482 0
1
0 0 58 42
1
end_operator
begin_operator
move loc_13_8 loc_13_7 left
2
182 0
483 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_13_8 loc_13_9 right
2
184 0
484 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_13_8 loc_14_8 down
2
201 0
485 0
1
0 0 58 74
1
end_operator
begin_operator
move loc_13_9 loc_12_9 up
2
168 0
486 0
1
0 0 59 43
1
end_operator
begin_operator
move loc_13_9 loc_13_10 right
2
169 0
487 0
1
0 0 59 44
1
end_operator
begin_operator
move loc_13_9 loc_13_8 left
2
183 0
488 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_13_9 loc_14_9 down
2
202 0
489 0
1
0 0 59 75
1
end_operator
begin_operator
move loc_14_10 loc_13_10 up
2
169 0
490 0
1
0 0 60 44
1
end_operator
begin_operator
move loc_14_10 loc_14_11 right
2
186 0
491 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_14_10 loc_14_9 left
2
202 0
492 0
1
0 0 60 75
1
end_operator
begin_operator
move loc_14_10 loc_15_10 down
2
203 0
493 0
1
0 0 60 76
1
end_operator
begin_operator
move loc_14_11 loc_13_11 up
2
170 0
494 0
1
0 0 61 45
1
end_operator
begin_operator
move loc_14_11 loc_14_10 left
2
185 0
495 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_14_11 loc_14_12 right
2
187 0
496 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_14_11 loc_15_11 down
2
204 0
497 0
1
0 0 61 77
1
end_operator
begin_operator
move loc_14_12 loc_13_12 up
2
171 0
498 0
1
0 0 62 46
1
end_operator
begin_operator
move loc_14_12 loc_14_11 left
2
186 0
499 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_14_12 loc_14_13 right
2
188 0
500 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_14_12 loc_15_12 down
2
205 0
501 0
1
0 0 62 78
1
end_operator
begin_operator
move loc_14_13 loc_13_13 up
2
172 0
502 0
1
0 0 63 47
1
end_operator
begin_operator
move loc_14_13 loc_14_12 left
2
187 0
503 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_14_13 loc_14_14 right
2
189 0
504 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_14_13 loc_15_13 down
2
206 0
505 0
1
0 0 63 79
1
end_operator
begin_operator
move loc_14_14 loc_13_14 up
2
173 0
506 0
1
0 0 64 48
1
end_operator
begin_operator
move loc_14_14 loc_14_13 left
2
188 0
507 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_14_14 loc_14_15 right
2
190 0
508 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_14_14 loc_15_14 down
2
207 0
509 0
1
0 0 64 80
1
end_operator
begin_operator
move loc_14_15 loc_13_15 up
2
174 0
510 0
1
0 0 65 49
1
end_operator
begin_operator
move loc_14_15 loc_14_14 left
2
189 0
511 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_14_15 loc_14_16 right
2
191 0
512 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_14_15 loc_15_15 down
2
208 0
513 0
1
0 0 65 81
1
end_operator
begin_operator
move loc_14_16 loc_14_15 left
2
190 0
514 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_14_16 loc_14_17 right
2
192 0
515 0
1
0 0 66 67
1
end_operator
begin_operator
move loc_14_16 loc_15_16 down
2
209 0
516 0
1
0 0 66 82
1
end_operator
begin_operator
move loc_14_17 loc_13_17 up
2
175 0
517 0
1
0 0 67 50
1
end_operator
begin_operator
move loc_14_17 loc_14_16 left
2
191 0
518 0
1
0 0 67 66
1
end_operator
begin_operator
move loc_14_17 loc_14_18 right
2
193 0
519 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_14_17 loc_15_17 down
2
210 0
520 0
1
0 0 67 83
1
end_operator
begin_operator
move loc_14_18 loc_13_18 up
2
176 0
521 0
1
0 0 68 51
1
end_operator
begin_operator
move loc_14_18 loc_14_17 left
2
192 0
522 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_14_18 loc_14_19 right
2
194 0
523 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_14_18 loc_15_18 down
2
211 0
524 0
1
0 0 68 84
1
end_operator
begin_operator
move loc_14_19 loc_13_19 up
2
177 0
525 0
1
0 0 69 52
1
end_operator
begin_operator
move loc_14_19 loc_14_18 left
2
193 0
526 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_14_19 loc_14_20 right
2
196 0
527 0
1
0 0 69 70
1
end_operator
begin_operator
move loc_14_19 loc_15_19 down
2
212 0
528 0
1
0 0 69 85
1
end_operator
begin_operator
move loc_14_20 loc_13_20 up
2
178 0
531 0
1
0 0 70 53
1
end_operator
begin_operator
move loc_14_20 loc_14_19 left
2
194 0
532 0
1
0 0 70 69
1
end_operator
begin_operator
move loc_14_20 loc_15_20 down
2
214 0
533 0
1
0 0 70 86
1
end_operator
begin_operator
move loc_14_5 loc_13_5 up
2
180 0
536 0
1
0 0 71 55
1
end_operator
begin_operator
move loc_14_5 loc_14_6 right
2
199 0
537 0
1
0 0 71 72
1
end_operator
begin_operator
move loc_14_5 loc_15_5 down
2
217 0
538 0
1
0 0 71 88
1
end_operator
begin_operator
move loc_14_6 loc_13_6 up
2
181 0
539 0
1
0 0 72 56
1
end_operator
begin_operator
move loc_14_6 loc_14_5 left
2
198 0
540 0
1
0 0 72 71
1
end_operator
begin_operator
move loc_14_6 loc_14_7 right
2
200 0
541 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_14_6 loc_15_6 down
2
218 0
542 0
1
0 0 72 89
1
end_operator
begin_operator
move loc_14_7 loc_13_7 up
2
182 0
543 0
1
0 0 73 57
1
end_operator
begin_operator
move loc_14_7 loc_14_6 left
2
199 0
544 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_14_7 loc_14_8 right
2
201 0
545 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_14_7 loc_15_7 down
2
219 0
546 0
1
0 0 73 90
1
end_operator
begin_operator
move loc_14_8 loc_13_8 up
2
183 0
547 0
1
0 0 74 58
1
end_operator
begin_operator
move loc_14_8 loc_14_7 left
2
200 0
548 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_14_8 loc_14_9 right
2
202 0
549 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_14_8 loc_15_8 down
2
220 0
550 0
1
0 0 74 91
1
end_operator
begin_operator
move loc_14_9 loc_13_9 up
2
184 0
551 0
1
0 0 75 59
1
end_operator
begin_operator
move loc_14_9 loc_14_10 right
2
185 0
552 0
1
0 0 75 60
1
end_operator
begin_operator
move loc_14_9 loc_14_8 left
2
201 0
553 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_14_9 loc_15_9 down
2
221 0
554 0
1
0 0 75 92
1
end_operator
begin_operator
move loc_15_10 loc_14_10 up
2
185 0
555 0
1
0 0 76 60
1
end_operator
begin_operator
move loc_15_10 loc_15_11 right
2
204 0
556 0
1
0 0 76 77
1
end_operator
begin_operator
move loc_15_10 loc_15_9 left
2
221 0
557 0
1
0 0 76 92
1
end_operator
begin_operator
move loc_15_10 loc_16_10 down
2
222 0
558 0
1
0 0 76 93
1
end_operator
begin_operator
move loc_15_11 loc_14_11 up
2
186 0
559 0
1
0 0 77 61
1
end_operator
begin_operator
move loc_15_11 loc_15_10 left
2
203 0
560 0
1
0 0 77 76
1
end_operator
begin_operator
move loc_15_11 loc_15_12 right
2
205 0
561 0
1
0 0 77 78
1
end_operator
begin_operator
move loc_15_12 loc_14_12 up
2
187 0
562 0
1
0 0 78 62
1
end_operator
begin_operator
move loc_15_12 loc_15_11 left
2
204 0
563 0
1
0 0 78 77
1
end_operator
begin_operator
move loc_15_12 loc_15_13 right
2
206 0
564 0
1
0 0 78 79
1
end_operator
begin_operator
move loc_15_13 loc_14_13 up
2
188 0
565 0
1
0 0 79 63
1
end_operator
begin_operator
move loc_15_13 loc_15_12 left
2
205 0
566 0
1
0 0 79 78
1
end_operator
begin_operator
move loc_15_13 loc_15_14 right
2
207 0
567 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_15_13 loc_16_13 down
2
223 0
568 0
1
0 0 79 94
1
end_operator
begin_operator
move loc_15_14 loc_14_14 up
2
189 0
569 0
1
0 0 80 64
1
end_operator
begin_operator
move loc_15_14 loc_15_13 left
2
206 0
570 0
1
0 0 80 79
1
end_operator
begin_operator
move loc_15_14 loc_15_15 right
2
208 0
571 0
1
0 0 80 81
1
end_operator
begin_operator
move loc_15_14 loc_16_14 down
2
224 0
572 0
1
0 0 80 95
1
end_operator
begin_operator
move loc_15_15 loc_14_15 up
2
190 0
573 0
1
0 0 81 65
1
end_operator
begin_operator
move loc_15_15 loc_15_14 left
2
207 0
574 0
1
0 0 81 80
1
end_operator
begin_operator
move loc_15_15 loc_15_16 right
2
209 0
575 0
1
0 0 81 82
1
end_operator
begin_operator
move loc_15_16 loc_14_16 up
2
191 0
576 0
1
0 0 82 66
1
end_operator
begin_operator
move loc_15_16 loc_15_15 left
2
208 0
577 0
1
0 0 82 81
1
end_operator
begin_operator
move loc_15_16 loc_15_17 right
2
210 0
578 0
1
0 0 82 83
1
end_operator
begin_operator
move loc_15_17 loc_14_17 up
2
192 0
579 0
1
0 0 83 67
1
end_operator
begin_operator
move loc_15_17 loc_15_16 left
2
209 0
580 0
1
0 0 83 82
1
end_operator
begin_operator
move loc_15_17 loc_15_18 right
2
211 0
581 0
1
0 0 83 84
1
end_operator
begin_operator
move loc_15_18 loc_14_18 up
2
193 0
582 0
1
0 0 84 68
1
end_operator
begin_operator
move loc_15_18 loc_15_17 left
2
210 0
583 0
1
0 0 84 83
1
end_operator
begin_operator
move loc_15_18 loc_15_19 right
2
212 0
584 0
1
0 0 84 85
1
end_operator
begin_operator
move loc_15_19 loc_14_19 up
2
194 0
585 0
1
0 0 85 69
1
end_operator
begin_operator
move loc_15_19 loc_15_18 left
2
211 0
586 0
1
0 0 85 84
1
end_operator
begin_operator
move loc_15_19 loc_15_20 right
2
214 0
587 0
1
0 0 85 86
1
end_operator
begin_operator
move loc_15_19 loc_16_19 down
2
225 0
588 0
1
0 0 85 96
1
end_operator
begin_operator
move loc_15_20 loc_14_20 up
2
196 0
592 0
1
0 0 86 70
1
end_operator
begin_operator
move loc_15_20 loc_15_19 left
2
212 0
593 0
1
0 0 86 85
1
end_operator
begin_operator
move loc_15_20 loc_15_21 right
2
215 0
594 0
1
0 0 86 87
1
end_operator
begin_operator
move loc_15_20 loc_16_20 down
2
227 0
595 0
1
0 0 86 97
1
end_operator
begin_operator
move loc_15_21 loc_15_20 left
2
214 0
596 0
1
0 0 87 86
1
end_operator
begin_operator
move loc_15_5 loc_14_5 up
2
198 0
600 0
1
0 0 88 71
1
end_operator
begin_operator
move loc_15_5 loc_15_6 right
2
218 0
601 0
1
0 0 88 89
1
end_operator
begin_operator
move loc_15_5 loc_16_5 down
2
229 0
602 0
1
0 0 88 98
1
end_operator
begin_operator
move loc_15_6 loc_14_6 up
2
199 0
603 0
1
0 0 89 72
1
end_operator
begin_operator
move loc_15_6 loc_15_5 left
2
217 0
604 0
1
0 0 89 88
1
end_operator
begin_operator
move loc_15_6 loc_15_7 right
2
219 0
605 0
1
0 0 89 90
1
end_operator
begin_operator
move loc_15_6 loc_16_6 down
2
230 0
606 0
1
0 0 89 99
1
end_operator
begin_operator
move loc_15_7 loc_14_7 up
2
200 0
607 0
1
0 0 90 73
1
end_operator
begin_operator
move loc_15_7 loc_15_6 left
2
218 0
608 0
1
0 0 90 89
1
end_operator
begin_operator
move loc_15_7 loc_15_8 right
2
220 0
609 0
1
0 0 90 91
1
end_operator
begin_operator
move loc_15_7 loc_16_7 down
2
231 0
610 0
1
0 0 90 100
1
end_operator
begin_operator
move loc_15_8 loc_14_8 up
2
201 0
611 0
1
0 0 91 74
1
end_operator
begin_operator
move loc_15_8 loc_15_7 left
2
219 0
612 0
1
0 0 91 90
1
end_operator
begin_operator
move loc_15_8 loc_15_9 right
2
221 0
613 0
1
0 0 91 92
1
end_operator
begin_operator
move loc_15_8 loc_16_8 down
2
232 0
614 0
1
0 0 91 101
1
end_operator
begin_operator
move loc_15_9 loc_14_9 up
2
202 0
615 0
1
0 0 92 75
1
end_operator
begin_operator
move loc_15_9 loc_15_10 right
2
203 0
616 0
1
0 0 92 76
1
end_operator
begin_operator
move loc_15_9 loc_15_8 left
2
220 0
617 0
1
0 0 92 91
1
end_operator
begin_operator
move loc_15_9 loc_16_9 down
2
233 0
618 0
1
0 0 92 102
1
end_operator
begin_operator
move loc_16_10 loc_15_10 up
2
203 0
619 0
1
0 0 93 76
1
end_operator
begin_operator
move loc_16_10 loc_16_9 left
2
233 0
620 0
1
0 0 93 102
1
end_operator
begin_operator
move loc_16_10 loc_17_10 down
2
234 0
621 0
1
0 0 93 103
1
end_operator
begin_operator
move loc_16_13 loc_15_13 up
2
206 0
622 0
1
0 0 94 79
1
end_operator
begin_operator
move loc_16_13 loc_16_14 right
2
224 0
623 0
1
0 0 94 95
1
end_operator
begin_operator
move loc_16_13 loc_17_13 down
2
235 0
624 0
1
0 0 94 104
1
end_operator
begin_operator
move loc_16_14 loc_15_14 up
2
207 0
625 0
1
0 0 95 80
1
end_operator
begin_operator
move loc_16_14 loc_16_13 left
2
223 0
626 0
1
0 0 95 94
1
end_operator
begin_operator
move loc_16_14 loc_17_14 down
2
236 0
627 0
1
0 0 95 105
1
end_operator
begin_operator
move loc_16_19 loc_15_19 up
2
212 0
628 0
1
0 0 96 85
1
end_operator
begin_operator
move loc_16_19 loc_16_20 right
2
227 0
629 0
1
0 0 96 97
1
end_operator
begin_operator
move loc_16_19 loc_17_19 down
2
239 0
630 0
1
0 0 96 108
1
end_operator
begin_operator
move loc_16_20 loc_15_20 up
2
214 0
633 0
1
0 0 97 86
1
end_operator
begin_operator
move loc_16_20 loc_16_19 left
2
225 0
634 0
1
0 0 97 96
1
end_operator
begin_operator
move loc_16_20 loc_17_20 down
2
240 0
635 0
1
0 0 97 109
1
end_operator
begin_operator
move loc_16_5 loc_15_5 up
2
217 0
639 0
1
0 0 98 88
1
end_operator
begin_operator
move loc_16_5 loc_16_6 right
2
230 0
640 0
1
0 0 98 99
1
end_operator
begin_operator
move loc_16_6 loc_15_6 up
2
218 0
641 0
1
0 0 99 89
1
end_operator
begin_operator
move loc_16_6 loc_16_5 left
2
229 0
642 0
1
0 0 99 98
1
end_operator
begin_operator
move loc_16_6 loc_16_7 right
2
231 0
643 0
1
0 0 99 100
1
end_operator
begin_operator
move loc_16_7 loc_15_7 up
2
219 0
644 0
1
0 0 100 90
1
end_operator
begin_operator
move loc_16_7 loc_16_6 left
2
230 0
645 0
1
0 0 100 99
1
end_operator
begin_operator
move loc_16_7 loc_16_8 right
2
232 0
646 0
1
0 0 100 101
1
end_operator
begin_operator
move loc_16_7 loc_17_7 down
2
242 0
647 0
1
0 0 100 110
1
end_operator
begin_operator
move loc_16_8 loc_15_8 up
2
220 0
648 0
1
0 0 101 91
1
end_operator
begin_operator
move loc_16_8 loc_16_7 left
2
231 0
649 0
1
0 0 101 100
1
end_operator
begin_operator
move loc_16_8 loc_16_9 right
2
233 0
650 0
1
0 0 101 102
1
end_operator
begin_operator
move loc_16_8 loc_17_8 down
2
243 0
651 0
1
0 0 101 111
1
end_operator
begin_operator
move loc_16_9 loc_15_9 up
2
221 0
652 0
1
0 0 102 92
1
end_operator
begin_operator
move loc_16_9 loc_16_10 right
2
222 0
653 0
1
0 0 102 93
1
end_operator
begin_operator
move loc_16_9 loc_16_8 left
2
232 0
654 0
1
0 0 102 101
1
end_operator
begin_operator
move loc_17_10 loc_16_10 up
2
222 0
655 0
1
0 0 103 93
1
end_operator
begin_operator
move loc_17_10 loc_18_10 down
2
244 0
656 0
1
0 0 103 112
1
end_operator
begin_operator
move loc_17_13 loc_16_13 up
2
223 0
657 0
1
0 0 104 94
1
end_operator
begin_operator
move loc_17_13 loc_17_14 right
2
236 0
658 0
1
0 0 104 105
1
end_operator
begin_operator
move loc_17_13 loc_18_13 down
2
246 0
659 0
1
0 0 104 114
1
end_operator
begin_operator
move loc_17_14 loc_16_14 up
2
224 0
660 0
1
0 0 105 95
1
end_operator
begin_operator
move loc_17_14 loc_17_13 left
2
235 0
661 0
1
0 0 105 104
1
end_operator
begin_operator
move loc_17_14 loc_18_14 down
2
247 0
662 0
1
0 0 105 115
1
end_operator
begin_operator
move loc_17_16 loc_17_17 right
2
238 0
663 0
1
0 0 106 107
1
end_operator
begin_operator
move loc_17_16 loc_18_16 down
2
249 0
664 0
1
0 0 106 117
1
end_operator
begin_operator
move loc_17_17 loc_17_16 left
2
237 0
665 0
1
0 0 107 106
1
end_operator
begin_operator
move loc_17_19 loc_16_19 up
2
225 0
666 0
1
0 0 108 96
1
end_operator
begin_operator
move loc_17_19 loc_17_20 right
2
240 0
667 0
1
0 0 108 109
1
end_operator
begin_operator
move loc_17_19 loc_18_19 down
2
250 0
668 0
1
0 0 108 118
1
end_operator
begin_operator
move loc_17_20 loc_16_20 up
2
227 0
669 0
1
0 0 109 97
1
end_operator
begin_operator
move loc_17_20 loc_17_19 left
2
239 0
670 0
1
0 0 109 108
1
end_operator
begin_operator
move loc_17_20 loc_18_20 down
2
251 0
671 0
1
0 0 109 119
1
end_operator
begin_operator
move loc_17_7 loc_16_7 up
2
231 0
673 0
1
0 0 110 100
1
end_operator
begin_operator
move loc_17_7 loc_17_8 right
2
243 0
674 0
1
0 0 110 111
1
end_operator
begin_operator
move loc_17_7 loc_18_7 down
2
253 0
675 0
1
0 0 110 121
1
end_operator
begin_operator
move loc_17_8 loc_16_8 up
2
232 0
676 0
1
0 0 111 101
1
end_operator
begin_operator
move loc_17_8 loc_17_7 left
2
242 0
677 0
1
0 0 111 110
1
end_operator
begin_operator
move loc_17_8 loc_18_8 down
2
254 0
678 0
1
0 0 111 122
1
end_operator
begin_operator
move loc_18_10 loc_17_10 up
2
234 0
679 0
1
0 0 112 103
1
end_operator
begin_operator
move loc_18_10 loc_18_11 right
2
245 0
680 0
1
0 0 112 113
1
end_operator
begin_operator
move loc_18_10 loc_18_9 left
2
255 0
681 0
1
0 0 112 123
1
end_operator
begin_operator
move loc_18_11 loc_18_10 left
2
244 0
682 0
1
0 0 113 112
1
end_operator
begin_operator
move loc_18_11 loc_19_11 down
2
256 0
683 0
1
0 0 113 124
1
end_operator
begin_operator
move loc_18_13 loc_17_13 up
2
235 0
684 0
1
0 0 114 104
1
end_operator
begin_operator
move loc_18_13 loc_18_14 right
2
247 0
685 0
1
0 0 114 115
1
end_operator
begin_operator
move loc_18_13 loc_19_13 down
2
258 0
686 0
1
0 0 114 126
1
end_operator
begin_operator
move loc_18_14 loc_17_14 up
2
236 0
687 0
1
0 0 115 105
1
end_operator
begin_operator
move loc_18_14 loc_18_13 left
2
246 0
688 0
1
0 0 115 114
1
end_operator
begin_operator
move loc_18_14 loc_18_15 right
2
248 0
689 0
1
0 0 115 116
1
end_operator
begin_operator
move loc_18_15 loc_18_14 left
2
247 0
690 0
1
0 0 116 115
1
end_operator
begin_operator
move loc_18_15 loc_18_16 right
2
249 0
691 0
1
0 0 116 117
1
end_operator
begin_operator
move loc_18_16 loc_17_16 up
2
237 0
692 0
1
0 0 117 106
1
end_operator
begin_operator
move loc_18_16 loc_18_15 left
2
248 0
693 0
1
0 0 117 116
1
end_operator
begin_operator
move loc_18_16 loc_19_16 down
2
259 0
694 0
1
0 0 117 127
1
end_operator
begin_operator
move loc_18_19 loc_17_19 up
2
239 0
695 0
1
0 0 118 108
1
end_operator
begin_operator
move loc_18_19 loc_18_20 right
2
251 0
696 0
1
0 0 118 119
1
end_operator
begin_operator
move loc_18_19 loc_19_19 down
2
261 0
697 0
1
0 0 118 129
1
end_operator
begin_operator
move loc_18_20 loc_17_20 up
2
240 0
698 0
1
0 0 119 109
1
end_operator
begin_operator
move loc_18_20 loc_18_19 left
2
250 0
699 0
1
0 0 119 118
1
end_operator
begin_operator
move loc_18_20 loc_19_20 down
2
263 0
700 0
1
0 0 119 130
1
end_operator
begin_operator
move loc_18_6 loc_18_7 right
2
253 0
701 0
1
0 0 120 121
1
end_operator
begin_operator
move loc_18_6 loc_19_6 down
2
265 0
702 0
1
0 0 120 132
1
end_operator
begin_operator
move loc_18_7 loc_17_7 up
2
242 0
703 0
1
0 0 121 110
1
end_operator
begin_operator
move loc_18_7 loc_18_6 left
2
252 0
704 0
1
0 0 121 120
1
end_operator
begin_operator
move loc_18_7 loc_18_8 right
2
254 0
705 0
1
0 0 121 122
1
end_operator
begin_operator
move loc_18_7 loc_19_7 down
2
266 0
706 0
1
0 0 121 133
1
end_operator
begin_operator
move loc_18_8 loc_17_8 up
2
243 0
707 0
1
0 0 122 111
1
end_operator
begin_operator
move loc_18_8 loc_18_7 left
2
253 0
708 0
1
0 0 122 121
1
end_operator
begin_operator
move loc_18_8 loc_18_9 right
2
255 0
709 0
1
0 0 122 123
1
end_operator
begin_operator
move loc_18_8 loc_19_8 down
2
267 0
710 0
1
0 0 122 134
1
end_operator
begin_operator
move loc_18_9 loc_18_10 right
2
244 0
711 0
1
0 0 123 112
1
end_operator
begin_operator
move loc_18_9 loc_18_8 left
2
254 0
712 0
1
0 0 123 122
1
end_operator
begin_operator
move loc_18_9 loc_19_9 down
2
268 0
713 0
1
0 0 123 135
1
end_operator
begin_operator
move loc_19_11 loc_18_11 up
2
245 0
714 0
1
0 0 124 113
1
end_operator
begin_operator
move loc_19_11 loc_19_12 right
2
257 0
715 0
1
0 0 124 125
1
end_operator
begin_operator
move loc_19_11 loc_20_11 down
2
270 0
716 0
1
0 0 124 137
1
end_operator
begin_operator
move loc_19_12 loc_19_11 left
2
256 0
717 0
1
0 0 125 124
1
end_operator
begin_operator
move loc_19_12 loc_19_13 right
2
258 0
718 0
1
0 0 125 126
1
end_operator
begin_operator
move loc_19_12 loc_20_12 down
2
271 0
719 0
1
0 0 125 138
1
end_operator
begin_operator
move loc_19_13 loc_18_13 up
2
246 0
720 0
1
0 0 126 114
1
end_operator
begin_operator
move loc_19_13 loc_19_12 left
2
257 0
721 0
1
0 0 126 125
1
end_operator
begin_operator
move loc_19_13 loc_20_13 down
2
272 0
722 0
1
0 0 126 139
1
end_operator
begin_operator
move loc_19_16 loc_18_16 up
2
249 0
723 0
1
0 0 127 117
1
end_operator
begin_operator
move loc_19_16 loc_19_17 right
2
260 0
724 0
1
0 0 127 128
1
end_operator
begin_operator
move loc_19_16 loc_20_16 down
2
275 0
725 0
1
0 0 127 142
1
end_operator
begin_operator
move loc_19_17 loc_19_16 left
2
259 0
726 0
1
0 0 128 127
1
end_operator
begin_operator
move loc_19_17 loc_20_17 down
2
276 0
727 0
1
0 0 128 143
1
end_operator
begin_operator
move loc_19_19 loc_18_19 up
2
250 0
728 0
1
0 0 129 118
1
end_operator
begin_operator
move loc_19_19 loc_19_20 right
2
263 0
729 0
1
0 0 129 130
1
end_operator
begin_operator
move loc_19_19 loc_20_19 down
2
278 0
730 0
1
0 0 129 145
1
end_operator
begin_operator
move loc_19_20 loc_18_20 up
2
251 0
731 0
1
0 0 130 119
1
end_operator
begin_operator
move loc_19_20 loc_19_19 left
2
261 0
732 0
1
0 0 130 129
1
end_operator
begin_operator
move loc_19_20 loc_19_21 right
2
264 0
733 0
1
0 0 130 131
1
end_operator
begin_operator
move loc_19_21 loc_19_20 left
2
263 0
734 0
1
0 0 131 130
1
end_operator
begin_operator
move loc_19_6 loc_18_6 up
2
252 0
735 0
1
0 0 132 120
1
end_operator
begin_operator
move loc_19_6 loc_19_7 right
2
266 0
736 0
1
0 0 132 133
1
end_operator
begin_operator
move loc_19_6 loc_20_6 down
2
280 0
737 0
1
0 0 132 147
1
end_operator
begin_operator
move loc_19_7 loc_18_7 up
2
253 0
738 0
1
0 0 133 121
1
end_operator
begin_operator
move loc_19_7 loc_19_6 left
2
265 0
739 0
1
0 0 133 132
1
end_operator
begin_operator
move loc_19_7 loc_19_8 right
2
267 0
740 0
1
0 0 133 134
1
end_operator
begin_operator
move loc_19_7 loc_20_7 down
2
281 0
741 0
1
0 0 133 148
1
end_operator
begin_operator
move loc_19_8 loc_18_8 up
2
254 0
742 0
1
0 0 134 122
1
end_operator
begin_operator
move loc_19_8 loc_19_7 left
2
266 0
743 0
1
0 0 134 133
1
end_operator
begin_operator
move loc_19_8 loc_19_9 right
2
268 0
744 0
1
0 0 134 135
1
end_operator
begin_operator
move loc_19_8 loc_20_8 down
2
282 0
745 0
1
0 0 134 149
1
end_operator
begin_operator
move loc_19_9 loc_18_9 up
2
255 0
746 0
1
0 0 135 123
1
end_operator
begin_operator
move loc_19_9 loc_19_8 left
2
267 0
747 0
1
0 0 135 134
1
end_operator
begin_operator
move loc_19_9 loc_20_9 down
2
283 0
748 0
1
0 0 135 150
1
end_operator
begin_operator
move loc_20_10 loc_20_11 right
2
270 0
749 0
1
0 0 136 137
1
end_operator
begin_operator
move loc_20_10 loc_20_9 left
2
283 0
750 0
1
0 0 136 150
1
end_operator
begin_operator
move loc_20_10 loc_21_10 down
2
284 0
751 0
1
0 0 136 151
1
end_operator
begin_operator
move loc_20_11 loc_19_11 up
2
256 0
752 0
1
0 0 137 124
1
end_operator
begin_operator
move loc_20_11 loc_20_10 left
2
269 0
753 0
1
0 0 137 136
1
end_operator
begin_operator
move loc_20_11 loc_20_12 right
2
271 0
754 0
1
0 0 137 138
1
end_operator
begin_operator
move loc_20_11 loc_21_11 down
2
285 0
755 0
1
0 0 137 152
1
end_operator
begin_operator
move loc_20_12 loc_19_12 up
2
257 0
756 0
1
0 0 138 125
1
end_operator
begin_operator
move loc_20_12 loc_20_11 left
2
270 0
757 0
1
0 0 138 137
1
end_operator
begin_operator
move loc_20_12 loc_20_13 right
2
272 0
758 0
1
0 0 138 139
1
end_operator
begin_operator
move loc_20_12 loc_21_12 down
2
8 0
759 0
1
0 0 138 153
1
end_operator
begin_operator
move loc_20_13 loc_19_13 up
2
258 0
760 0
1
0 0 139 126
1
end_operator
begin_operator
move loc_20_13 loc_20_12 left
2
271 0
761 0
1
0 0 139 138
1
end_operator
begin_operator
move loc_20_13 loc_20_14 right
2
273 0
762 0
1
0 0 139 140
1
end_operator
begin_operator
move loc_20_13 loc_21_13 down
2
9 0
763 0
1
0 0 139 154
1
end_operator
begin_operator
move loc_20_14 loc_20_13 left
2
272 0
764 0
1
0 0 140 139
1
end_operator
begin_operator
move loc_20_14 loc_20_15 right
2
274 0
765 0
1
0 0 140 141
1
end_operator
begin_operator
move loc_20_15 loc_20_14 left
2
273 0
766 0
1
0 0 141 140
1
end_operator
begin_operator
move loc_20_15 loc_20_16 right
2
275 0
767 0
1
0 0 141 142
1
end_operator
begin_operator
move loc_20_16 loc_19_16 up
2
259 0
768 0
1
0 0 142 127
1
end_operator
begin_operator
move loc_20_16 loc_20_15 left
2
274 0
769 0
1
0 0 142 141
1
end_operator
begin_operator
move loc_20_16 loc_20_17 right
2
276 0
770 0
1
0 0 142 143
1
end_operator
begin_operator
move loc_20_16 loc_21_16 down
2
10 0
771 0
1
0 0 142 155
1
end_operator
begin_operator
move loc_20_17 loc_19_17 up
2
260 0
772 0
1
0 0 143 128
1
end_operator
begin_operator
move loc_20_17 loc_20_16 left
2
275 0
773 0
1
0 0 143 142
1
end_operator
begin_operator
move loc_20_17 loc_20_18 right
2
277 0
774 0
1
0 0 143 144
1
end_operator
begin_operator
move loc_20_17 loc_21_17 down
2
11 0
775 0
1
0 0 143 156
1
end_operator
begin_operator
move loc_20_18 loc_20_17 left
2
276 0
776 0
1
0 0 144 143
1
end_operator
begin_operator
move loc_20_18 loc_20_19 right
2
278 0
777 0
1
0 0 144 145
1
end_operator
begin_operator
move loc_20_18 loc_21_18 down
2
12 0
778 0
1
0 0 144 157
1
end_operator
begin_operator
move loc_20_19 loc_19_19 up
2
261 0
779 0
1
0 0 145 129
1
end_operator
begin_operator
move loc_20_19 loc_20_18 left
2
277 0
780 0
1
0 0 145 144
1
end_operator
begin_operator
move loc_20_19 loc_21_19 down
2
13 0
781 0
1
0 0 145 158
1
end_operator
begin_operator
move loc_20_5 loc_20_6 right
2
280 0
782 0
1
0 0 146 147
1
end_operator
begin_operator
move loc_20_6 loc_19_6 up
2
265 0
783 0
1
0 0 147 132
1
end_operator
begin_operator
move loc_20_6 loc_20_5 left
2
279 0
784 0
1
0 0 147 146
1
end_operator
begin_operator
move loc_20_6 loc_20_7 right
2
281 0
785 0
1
0 0 147 148
1
end_operator
begin_operator
move loc_20_7 loc_19_7 up
2
266 0
786 0
1
0 0 148 133
1
end_operator
begin_operator
move loc_20_7 loc_20_6 left
2
280 0
787 0
1
0 0 148 147
1
end_operator
begin_operator
move loc_20_7 loc_20_8 right
2
282 0
788 0
1
0 0 148 149
1
end_operator
begin_operator
move loc_20_8 loc_19_8 up
2
267 0
789 0
1
0 0 149 134
1
end_operator
begin_operator
move loc_20_8 loc_20_7 left
2
281 0
790 0
1
0 0 149 148
1
end_operator
begin_operator
move loc_20_8 loc_20_9 right
2
283 0
791 0
1
0 0 149 150
1
end_operator
begin_operator
move loc_20_8 loc_21_8 down
2
16 0
792 0
1
0 0 149 160
1
end_operator
begin_operator
move loc_20_9 loc_19_9 up
2
268 0
793 0
1
0 0 150 135
1
end_operator
begin_operator
move loc_20_9 loc_20_10 right
2
269 0
794 0
1
0 0 150 136
1
end_operator
begin_operator
move loc_20_9 loc_20_8 left
2
282 0
795 0
1
0 0 150 149
1
end_operator
begin_operator
move loc_20_9 loc_21_9 down
2
17 0
796 0
1
0 0 150 161
1
end_operator
begin_operator
move loc_21_10 loc_20_10 up
2
269 0
797 0
1
0 0 151 136
1
end_operator
begin_operator
move loc_21_10 loc_21_11 right
2
285 0
798 0
1
0 0 151 152
1
end_operator
begin_operator
move loc_21_10 loc_21_9 left
2
17 0
799 0
1
0 0 151 161
1
end_operator
begin_operator
move loc_21_11 loc_20_11 up
2
270 0
800 0
1
0 0 152 137
1
end_operator
begin_operator
move loc_21_11 loc_21_10 left
2
284 0
801 0
1
0 0 152 151
1
end_operator
begin_operator
move loc_21_11 loc_21_12 right
2
8 0
802 0
1
0 0 152 153
1
end_operator
begin_operator
move loc_21_12 loc_20_12 up
2
271 0
803 0
1
0 0 153 138
1
end_operator
begin_operator
move loc_21_12 loc_21_11 left
2
285 0
804 0
1
0 0 153 152
1
end_operator
begin_operator
move loc_21_12 loc_21_13 right
2
9 0
805 0
1
0 0 153 154
1
end_operator
begin_operator
move loc_21_13 loc_20_13 up
2
272 0
806 0
1
0 0 154 139
1
end_operator
begin_operator
move loc_21_13 loc_21_12 left
2
8 0
807 0
1
0 0 154 153
1
end_operator
begin_operator
move loc_21_16 loc_20_16 up
2
275 0
808 0
1
0 0 155 142
1
end_operator
begin_operator
move loc_21_16 loc_21_17 right
2
11 0
809 0
1
0 0 155 156
1
end_operator
begin_operator
move loc_21_17 loc_20_17 up
2
276 0
810 0
1
0 0 156 143
1
end_operator
begin_operator
move loc_21_17 loc_21_16 left
2
10 0
811 0
1
0 0 156 155
1
end_operator
begin_operator
move loc_21_17 loc_21_18 right
2
12 0
812 0
1
0 0 156 157
1
end_operator
begin_operator
move loc_21_18 loc_20_18 up
2
277 0
813 0
1
0 0 157 144
1
end_operator
begin_operator
move loc_21_18 loc_21_17 left
2
11 0
814 0
1
0 0 157 156
1
end_operator
begin_operator
move loc_21_18 loc_21_19 right
2
13 0
815 0
1
0 0 157 158
1
end_operator
begin_operator
move loc_21_19 loc_20_19 up
2
278 0
816 0
1
0 0 158 145
1
end_operator
begin_operator
move loc_21_19 loc_21_18 left
2
12 0
817 0
1
0 0 158 157
1
end_operator
begin_operator
move loc_21_19 loc_21_20 right
2
14 0
818 0
1
0 0 158 159
1
end_operator
begin_operator
move loc_21_20 loc_21_19 left
2
13 0
819 0
1
0 0 159 158
1
end_operator
begin_operator
move loc_21_8 loc_20_8 up
2
282 0
820 0
1
0 0 160 149
1
end_operator
begin_operator
move loc_21_8 loc_21_9 right
2
17 0
821 0
1
0 0 160 161
1
end_operator
begin_operator
move loc_21_9 loc_20_9 up
2
283 0
822 0
1
0 0 161 150
1
end_operator
begin_operator
move loc_21_9 loc_21_10 right
2
284 0
823 0
1
0 0 161 151
1
end_operator
begin_operator
move loc_21_9 loc_21_8 left
2
16 0
824 0
1
0 0 161 160
1
end_operator
begin_operator
move loc_2_13 loc_2_14 right
2
19 0
825 0
1
0 0 162 163
1
end_operator
begin_operator
move loc_2_13 loc_3_13 down
2
32 0
826 0
1
0 0 162 174
1
end_operator
begin_operator
move loc_2_14 loc_2_13 left
2
18 0
827 0
1
0 0 163 162
1
end_operator
begin_operator
move loc_2_14 loc_3_14 down
2
33 0
828 0
1
0 0 163 175
1
end_operator
begin_operator
move loc_2_2 loc_2_3 right
2
24 0
831 0
1
0 0 164 166
1
end_operator
begin_operator
move loc_2_2 loc_3_2 down
2
37 0
832 0
1
0 0 164 179
1
end_operator
begin_operator
move loc_2_21 loc_3_21 down
2
39 0
833 0
1
0 0 165 181
1
end_operator
begin_operator
move loc_2_3 loc_2_2 left
2
22 0
834 0
1
0 0 166 164
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
25 0
835 0
1
0 0 166 167
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
40 0
836 0
1
0 0 166 182
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
24 0
837 0
1
0 0 167 166
1
end_operator
begin_operator
move loc_2_4 loc_2_5 right
2
26 0
838 0
1
0 0 167 168
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
41 0
839 0
1
0 0 167 183
1
end_operator
begin_operator
move loc_2_5 loc_2_4 left
2
25 0
840 0
1
0 0 168 167
1
end_operator
begin_operator
move loc_2_5 loc_2_6 right
2
27 0
841 0
1
0 0 168 169
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
42 0
842 0
1
0 0 168 184
1
end_operator
begin_operator
move loc_2_6 loc_2_5 left
2
26 0
843 0
1
0 0 169 168
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
43 0
844 0
1
0 0 169 185
1
end_operator
begin_operator
move loc_2_9 loc_3_9 down
2
46 0
845 0
1
0 0 170 188
1
end_operator
begin_operator
move loc_3_10 loc_3_11 right
2
30 0
846 0
1
0 0 171 172
1
end_operator
begin_operator
move loc_3_10 loc_3_9 left
2
46 0
847 0
1
0 0 171 188
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
47 0
848 0
1
0 0 171 189
1
end_operator
begin_operator
move loc_3_11 loc_3_10 left
2
29 0
849 0
1
0 0 172 171
1
end_operator
begin_operator
move loc_3_11 loc_3_12 right
2
31 0
850 0
1
0 0 172 173
1
end_operator
begin_operator
move loc_3_11 loc_4_11 down
2
48 0
851 0
1
0 0 172 190
1
end_operator
begin_operator
move loc_3_12 loc_3_11 left
2
30 0
852 0
1
0 0 173 172
1
end_operator
begin_operator
move loc_3_12 loc_3_13 right
2
32 0
853 0
1
0 0 173 174
1
end_operator
begin_operator
move loc_3_12 loc_4_12 down
2
49 0
854 0
1
0 0 173 191
1
end_operator
begin_operator
move loc_3_13 loc_2_13 up
2
18 0
855 0
1
0 0 174 162
1
end_operator
begin_operator
move loc_3_13 loc_3_12 left
2
31 0
856 0
1
0 0 174 173
1
end_operator
begin_operator
move loc_3_13 loc_3_14 right
2
33 0
857 0
1
0 0 174 175
1
end_operator
begin_operator
move loc_3_13 loc_4_13 down
2
50 0
858 0
1
0 0 174 192
1
end_operator
begin_operator
move loc_3_14 loc_2_14 up
2
19 0
859 0
1
0 0 175 163
1
end_operator
begin_operator
move loc_3_14 loc_3_13 left
2
32 0
860 0
1
0 0 175 174
1
end_operator
begin_operator
move loc_3_14 loc_3_15 right
2
34 0
861 0
1
0 0 175 176
1
end_operator
begin_operator
move loc_3_14 loc_4_14 down
2
51 0
862 0
1
0 0 175 193
1
end_operator
begin_operator
move loc_3_15 loc_3_14 left
2
33 0
863 0
1
0 0 176 175
1
end_operator
begin_operator
move loc_3_15 loc_3_16 right
2
35 0
864 0
1
0 0 176 177
1
end_operator
begin_operator
move loc_3_16 loc_3_15 left
2
34 0
865 0
1
0 0 177 176
1
end_operator
begin_operator
move loc_3_16 loc_3_17 right
2
36 0
866 0
1
0 0 177 178
1
end_operator
begin_operator
move loc_3_17 loc_3_16 left
2
35 0
867 0
1
0 0 178 177
1
end_operator
begin_operator
move loc_3_17 loc_4_17 down
2
52 0
868 0
1
0 0 178 194
1
end_operator
begin_operator
move loc_3_2 loc_2_2 up
2
22 0
869 0
1
0 0 179 164
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
40 0
870 0
1
0 0 179 182
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
53 0
871 0
1
0 0 179 195
1
end_operator
begin_operator
move loc_3_20 loc_3_21 right
2
39 0
872 0
1
0 0 180 181
1
end_operator
begin_operator
move loc_3_20 loc_4_20 down
2
54 0
873 0
1
0 0 180 196
1
end_operator
begin_operator
move loc_3_21 loc_2_21 up
2
23 0
874 0
1
0 0 181 165
1
end_operator
begin_operator
move loc_3_21 loc_3_20 left
2
38 0
875 0
1
0 0 181 180
1
end_operator
begin_operator
move loc_3_21 loc_4_21 down
2
55 0
876 0
1
0 0 181 197
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
24 0
877 0
1
0 0 182 166
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
37 0
878 0
1
0 0 182 179
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
41 0
879 0
1
0 0 182 183
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
56 0
880 0
1
0 0 182 198
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
25 0
881 0
1
0 0 183 167
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
40 0
882 0
1
0 0 183 182
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
42 0
883 0
1
0 0 183 184
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
57 0
884 0
1
0 0 183 199
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
26 0
885 0
1
0 0 184 168
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
41 0
886 0
1
0 0 184 183
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
43 0
887 0
1
0 0 184 185
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
27 0
888 0
1
0 0 185 169
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
42 0
889 0
1
0 0 185 184
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
44 0
890 0
1
0 0 185 186
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
43 0
891 0
1
0 0 186 185
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
45 0
892 0
1
0 0 186 187
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
44 0
893 0
1
0 0 187 186
1
end_operator
begin_operator
move loc_3_8 loc_3_9 right
2
46 0
894 0
1
0 0 187 188
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
58 0
895 0
1
0 0 187 200
1
end_operator
begin_operator
move loc_3_9 loc_2_9 up
2
28 0
896 0
1
0 0 188 170
1
end_operator
begin_operator
move loc_3_9 loc_3_10 right
2
29 0
897 0
1
0 0 188 171
1
end_operator
begin_operator
move loc_3_9 loc_3_8 left
2
45 0
898 0
1
0 0 188 187
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
59 0
899 0
1
0 0 188 201
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
29 0
900 0
1
0 0 189 171
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
48 0
901 0
1
0 0 189 190
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
59 0
902 0
1
0 0 189 201
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
60 0
903 0
1
0 0 189 202
1
end_operator
begin_operator
move loc_4_11 loc_3_11 up
2
30 0
904 0
1
0 0 190 172
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
47 0
905 0
1
0 0 190 189
1
end_operator
begin_operator
move loc_4_11 loc_4_12 right
2
49 0
906 0
1
0 0 190 191
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
61 0
907 0
1
0 0 190 203
1
end_operator
begin_operator
move loc_4_12 loc_3_12 up
2
31 0
908 0
1
0 0 191 173
1
end_operator
begin_operator
move loc_4_12 loc_4_11 left
2
48 0
909 0
1
0 0 191 190
1
end_operator
begin_operator
move loc_4_12 loc_4_13 right
2
50 0
910 0
1
0 0 191 192
1
end_operator
begin_operator
move loc_4_12 loc_5_12 down
2
62 0
911 0
1
0 0 191 204
1
end_operator
begin_operator
move loc_4_13 loc_3_13 up
2
32 0
912 0
1
0 0 192 174
1
end_operator
begin_operator
move loc_4_13 loc_4_12 left
2
49 0
913 0
1
0 0 192 191
1
end_operator
begin_operator
move loc_4_13 loc_4_14 right
2
51 0
914 0
1
0 0 192 193
1
end_operator
begin_operator
move loc_4_14 loc_3_14 up
2
33 0
915 0
1
0 0 193 175
1
end_operator
begin_operator
move loc_4_14 loc_4_13 left
2
50 0
916 0
1
0 0 193 192
1
end_operator
begin_operator
move loc_4_14 loc_5_14 down
2
63 0
917 0
1
0 0 193 205
1
end_operator
begin_operator
move loc_4_17 loc_3_17 up
2
36 0
918 0
1
0 0 194 178
1
end_operator
begin_operator
move loc_4_17 loc_5_17 down
2
65 0
919 0
1
0 0 194 207
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
37 0
920 0
1
0 0 195 179
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
56 0
921 0
1
0 0 195 198
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
68 0
922 0
1
0 0 195 210
1
end_operator
begin_operator
move loc_4_20 loc_3_20 up
2
38 0
923 0
1
0 0 196 180
1
end_operator
begin_operator
move loc_4_20 loc_4_21 right
2
55 0
924 0
1
0 0 196 197
1
end_operator
begin_operator
move loc_4_20 loc_5_20 down
2
69 0
925 0
1
0 0 196 211
1
end_operator
begin_operator
move loc_4_21 loc_3_21 up
2
39 0
926 0
1
0 0 197 181
1
end_operator
begin_operator
move loc_4_21 loc_4_20 left
2
54 0
927 0
1
0 0 197 196
1
end_operator
begin_operator
move loc_4_21 loc_5_21 down
2
70 0
928 0
1
0 0 197 212
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
40 0
929 0
1
0 0 198 182
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
53 0
930 0
1
0 0 198 195
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
57 0
931 0
1
0 0 198 199
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
71 0
932 0
1
0 0 198 213
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
41 0
933 0
1
0 0 199 183
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
56 0
934 0
1
0 0 199 198
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
45 0
935 0
1
0 0 200 187
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
59 0
936 0
1
0 0 200 201
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
46 0
937 0
1
0 0 201 188
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
47 0
938 0
1
0 0 201 189
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
58 0
939 0
1
0 0 201 200
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
73 0
940 0
1
0 0 201 214
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
47 0
941 0
1
0 0 202 189
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
61 0
942 0
1
0 0 202 203
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
73 0
943 0
1
0 0 202 214
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
48 0
944 0
1
0 0 203 190
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
60 0
945 0
1
0 0 203 202
1
end_operator
begin_operator
move loc_5_11 loc_5_12 right
2
62 0
946 0
1
0 0 203 204
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
74 0
947 0
1
0 0 203 215
1
end_operator
begin_operator
move loc_5_12 loc_4_12 up
2
49 0
948 0
1
0 0 204 191
1
end_operator
begin_operator
move loc_5_12 loc_5_11 left
2
61 0
949 0
1
0 0 204 203
1
end_operator
begin_operator
move loc_5_12 loc_6_12 down
2
75 0
950 0
1
0 0 204 216
1
end_operator
begin_operator
move loc_5_14 loc_4_14 up
2
51 0
951 0
1
0 0 205 193
1
end_operator
begin_operator
move loc_5_14 loc_6_14 down
2
77 0
952 0
1
0 0 205 218
1
end_operator
begin_operator
move loc_5_16 loc_5_17 right
2
65 0
953 0
1
0 0 206 207
1
end_operator
begin_operator
move loc_5_16 loc_6_16 down
2
78 0
954 0
1
0 0 206 219
1
end_operator
begin_operator
move loc_5_17 loc_4_17 up
2
52 0
955 0
1
0 0 207 194
1
end_operator
begin_operator
move loc_5_17 loc_5_16 left
2
64 0
956 0
1
0 0 207 206
1
end_operator
begin_operator
move loc_5_17 loc_5_18 right
2
66 0
957 0
1
0 0 207 208
1
end_operator
begin_operator
move loc_5_17 loc_6_17 down
2
79 0
958 0
1
0 0 207 220
1
end_operator
begin_operator
move loc_5_18 loc_5_17 left
2
65 0
959 0
1
0 0 208 207
1
end_operator
begin_operator
move loc_5_18 loc_5_19 right
2
67 0
960 0
1
0 0 208 209
1
end_operator
begin_operator
move loc_5_18 loc_6_18 down
2
80 0
961 0
1
0 0 208 221
1
end_operator
begin_operator
move loc_5_19 loc_5_18 left
2
66 0
962 0
1
0 0 209 208
1
end_operator
begin_operator
move loc_5_19 loc_5_20 right
2
69 0
963 0
1
0 0 209 211
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
53 0
964 0
1
0 0 210 195
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
71 0
965 0
1
0 0 210 213
1
end_operator
begin_operator
move loc_5_20 loc_4_20 up
2
54 0
966 0
1
0 0 211 196
1
end_operator
begin_operator
move loc_5_20 loc_5_19 left
2
67 0
967 0
1
0 0 211 209
1
end_operator
begin_operator
move loc_5_20 loc_5_21 right
2
70 0
968 0
1
0 0 211 212
1
end_operator
begin_operator
move loc_5_20 loc_6_20 down
2
81 0
969 0
1
0 0 211 222
1
end_operator
begin_operator
move loc_5_21 loc_4_21 up
2
55 0
970 0
1
0 0 212 197
1
end_operator
begin_operator
move loc_5_21 loc_5_20 left
2
69 0
971 0
1
0 0 212 211
1
end_operator
begin_operator
move loc_5_21 loc_6_21 down
2
82 0
972 0
1
0 0 212 223
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
56 0
973 0
1
0 0 213 198
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
68 0
974 0
1
0 0 213 210
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
83 0
975 0
1
0 0 213 224
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
59 0
976 0
1
0 0 214 201
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
60 0
977 0
1
0 0 214 202
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
85 0
978 0
1
0 0 214 226
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
61 0
979 0
1
0 0 215 203
1
end_operator
begin_operator
move loc_6_11 loc_6_12 right
2
75 0
980 0
1
0 0 215 216
1
end_operator
begin_operator
move loc_6_12 loc_5_12 up
2
62 0
981 0
1
0 0 216 204
1
end_operator
begin_operator
move loc_6_12 loc_6_11 left
2
74 0
982 0
1
0 0 216 215
1
end_operator
begin_operator
move loc_6_12 loc_6_13 right
2
76 0
983 0
1
0 0 216 217
1
end_operator
begin_operator
move loc_6_13 loc_6_12 left
2
75 0
984 0
1
0 0 217 216
1
end_operator
begin_operator
move loc_6_13 loc_6_14 right
2
77 0
985 0
1
0 0 217 218
1
end_operator
begin_operator
move loc_6_14 loc_5_14 up
2
63 0
986 0
1
0 0 218 205
1
end_operator
begin_operator
move loc_6_14 loc_6_13 left
2
76 0
987 0
1
0 0 218 217
1
end_operator
begin_operator
move loc_6_14 loc_7_14 down
2
86 0
988 0
1
0 0 218 227
1
end_operator
begin_operator
move loc_6_16 loc_5_16 up
2
64 0
989 0
1
0 0 219 206
1
end_operator
begin_operator
move loc_6_16 loc_6_17 right
2
79 0
990 0
1
0 0 219 220
1
end_operator
begin_operator
move loc_6_17 loc_5_17 up
2
65 0
991 0
1
0 0 220 207
1
end_operator
begin_operator
move loc_6_17 loc_6_16 left
2
78 0
992 0
1
0 0 220 219
1
end_operator
begin_operator
move loc_6_17 loc_6_18 right
2
80 0
993 0
1
0 0 220 221
1
end_operator
begin_operator
move loc_6_18 loc_5_18 up
2
66 0
994 0
1
0 0 221 208
1
end_operator
begin_operator
move loc_6_18 loc_6_17 left
2
79 0
995 0
1
0 0 221 220
1
end_operator
begin_operator
move loc_6_18 loc_7_18 down
2
88 0
996 0
1
0 0 221 229
1
end_operator
begin_operator
move loc_6_20 loc_5_20 up
2
69 0
997 0
1
0 0 222 211
1
end_operator
begin_operator
move loc_6_20 loc_6_21 right
2
82 0
998 0
1
0 0 222 223
1
end_operator
begin_operator
move loc_6_21 loc_5_21 up
2
70 0
999 0
1
0 0 223 212
1
end_operator
begin_operator
move loc_6_21 loc_6_20 left
2
81 0
1000 0
1
0 0 223 222
1
end_operator
begin_operator
move loc_6_21 loc_7_21 down
2
90 0
1001 0
1
0 0 223 231
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
71 0
1002 0
1
0 0 224 213
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
91 0
1003 0
1
0 0 224 232
1
end_operator
begin_operator
move loc_6_8 loc_6_9 right
2
85 0
1004 0
1
0 0 225 226
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
73 0
1005 0
1
0 0 226 214
1
end_operator
begin_operator
move loc_6_9 loc_6_8 left
2
84 0
1006 0
1
0 0 226 225
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
94 0
1007 0
1
0 0 226 235
1
end_operator
begin_operator
move loc_7_14 loc_6_14 up
2
77 0
1008 0
1
0 0 227 218
1
end_operator
begin_operator
move loc_7_14 loc_7_15 right
2
87 0
1009 0
1
0 0 227 228
1
end_operator
begin_operator
move loc_7_14 loc_8_14 down
2
98 0
1010 0
1
0 0 227 239
1
end_operator
begin_operator
move loc_7_15 loc_7_14 left
2
86 0
1011 0
1
0 0 228 227
1
end_operator
begin_operator
move loc_7_15 loc_8_15 down
2
99 0
1012 0
1
0 0 228 240
1
end_operator
begin_operator
move loc_7_18 loc_6_18 up
2
80 0
1013 0
1
0 0 229 221
1
end_operator
begin_operator
move loc_7_18 loc_7_19 right
2
89 0
1014 0
1
0 0 229 230
1
end_operator
begin_operator
move loc_7_18 loc_8_18 down
2
103 0
1015 0
1
0 0 229 243
1
end_operator
begin_operator
move loc_7_19 loc_7_18 left
2
88 0
1016 0
1
0 0 230 229
1
end_operator
begin_operator
move loc_7_21 loc_6_21 up
2
82 0
1017 0
1
0 0 231 223
1
end_operator
begin_operator
move loc_7_21 loc_8_21 down
2
109 0
1018 0
1
0 0 231 246
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
83 0
1019 0
1
0 0 232 224
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
111 0
1020 0
1
0 0 232 247
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
93 0
1021 0
1
0 0 233 234
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
113 0
1022 0
1
0 0 233 248
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
92 0
1023 0
1
0 0 234 233
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
115 0
1024 0
1
0 0 234 249
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
85 0
1025 0
1
0 0 235 226
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
96 0
1026 0
1
0 0 236 237
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
119 0
1027 0
1
0 0 236 251
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
95 0
1028 0
1
0 0 237 236
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
97 0
1029 0
1
0 0 237 238
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
121 0
1030 0
1
0 0 237 252
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
96 0
1031 0
1
0 0 238 237
1
end_operator
begin_operator
move loc_8_14 loc_7_14 up
2
86 0
1032 0
1
0 0 239 227
1
end_operator
begin_operator
move loc_8_14 loc_8_15 right
2
99 0
1033 0
1
0 0 239 240
1
end_operator
begin_operator
move loc_8_15 loc_7_15 up
2
87 0
1034 0
1
0 0 240 228
1
end_operator
begin_operator
move loc_8_15 loc_8_14 left
2
98 0
1035 0
1
0 0 240 239
1
end_operator
begin_operator
move loc_8_15 loc_8_16 right
2
100 0
1036 0
1
0 0 240 241
1
end_operator
begin_operator
move loc_8_15 loc_9_15 down
2
125 0
1037 0
1
0 0 240 253
1
end_operator
begin_operator
move loc_8_16 loc_8_15 left
2
99 0
1038 0
1
0 0 241 240
1
end_operator
begin_operator
move loc_8_16 loc_8_17 right
2
101 0
1039 0
1
0 0 241 242
1
end_operator
begin_operator
move loc_8_16 loc_9_16 down
2
127 0
1040 0
1
0 0 241 254
1
end_operator
begin_operator
move loc_8_17 loc_8_16 left
2
100 0
1041 0
1
0 0 242 241
1
end_operator
begin_operator
move loc_8_17 loc_8_18 right
2
103 0
1042 0
1
0 0 242 243
1
end_operator
begin_operator
move loc_8_17 loc_9_17 down
2
129 0
1043 0
1
0 0 242 255
1
end_operator
begin_operator
move loc_8_18 loc_7_18 up
2
88 0
1044 0
1
0 0 243 229
1
end_operator
begin_operator
move loc_8_18 loc_8_17 left
2
101 0
1045 0
1
0 0 243 242
1
end_operator
begin_operator
move loc_8_18 loc_9_18 down
2
131 0
1046 0
1
0 0 243 256
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
111 0
1047 0
1
0 0 244 247
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
135 0
1048 0
1
0 0 244 258
1
end_operator
begin_operator
move loc_8_20 loc_8_21 right
2
109 0
1049 0
1
0 0 245 246
1
end_operator
begin_operator
move loc_8_20 loc_9_20 down
2
137 0
1050 0
1
0 0 245 259
1
end_operator
begin_operator
move loc_8_21 loc_7_21 up
2
90 0
1051 0
1
0 0 246 231
1
end_operator
begin_operator
move loc_8_21 loc_8_20 left
2
107 0
1052 0
1
0 0 246 245
1
end_operator
begin_operator
move loc_8_21 loc_9_21 down
2
139 0
1053 0
1
0 0 246 260
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
91 0
1054 0
1
0 0 247 232
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
105 0
1055 0
1
0 0 247 244
1
end_operator
begin_operator
move loc_8_3 loc_9_3 down
2
141 0
1056 0
1
0 0 247 261
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
92 0
1057 0
1
0 0 248 233
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
115 0
1058 0
1
0 0 248 249
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
145 0
1059 0
1
0 0 248 263
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
93 0
1060 0
1
0 0 249 234
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
113 0
1061 0
1
0 0 249 248
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
117 0
1062 0
1
0 0 249 250
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
115 0
1063 0
1
0 0 250 249
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
102 0
1064 0
1
0 0 251 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
95 0
1065 0
1
0 0 251 236
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
121 0
1066 0
1
0 0 251 252
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
96 0
1067 0
1
0 0 252 237
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
119 0
1068 0
1
0 0 252 251
1
end_operator
begin_operator
move loc_9_15 loc_10_15 down
2
108 0
1069 0
1
0 0 253 3
1
end_operator
begin_operator
move loc_9_15 loc_8_15 up
2
99 0
1070 0
1
0 0 253 240
1
end_operator
begin_operator
move loc_9_15 loc_9_16 right
2
127 0
1071 0
1
0 0 253 254
1
end_operator
begin_operator
move loc_9_16 loc_8_16 up
2
100 0
1072 0
1
0 0 254 241
1
end_operator
begin_operator
move loc_9_16 loc_9_15 left
2
125 0
1073 0
1
0 0 254 253
1
end_operator
begin_operator
move loc_9_16 loc_9_17 right
2
129 0
1074 0
1
0 0 254 255
1
end_operator
begin_operator
move loc_9_17 loc_10_17 down
2
110 0
1075 0
1
0 0 255 4
1
end_operator
begin_operator
move loc_9_17 loc_8_17 up
2
101 0
1076 0
1
0 0 255 242
1
end_operator
begin_operator
move loc_9_17 loc_9_16 left
2
127 0
1077 0
1
0 0 255 254
1
end_operator
begin_operator
move loc_9_17 loc_9_18 right
2
131 0
1078 0
1
0 0 255 256
1
end_operator
begin_operator
move loc_9_18 loc_8_18 up
2
103 0
1079 0
1
0 0 256 243
1
end_operator
begin_operator
move loc_9_18 loc_9_17 left
2
129 0
1080 0
1
0 0 256 255
1
end_operator
begin_operator
move loc_9_18 loc_9_19 right
2
133 0
1081 0
1
0 0 256 257
1
end_operator
begin_operator
move loc_9_19 loc_10_19 down
2
112 0
1082 0
1
0 0 257 5
1
end_operator
begin_operator
move loc_9_19 loc_9_18 left
2
131 0
1083 0
1
0 0 257 256
1
end_operator
begin_operator
move loc_9_19 loc_9_20 right
2
137 0
1084 0
1
0 0 257 259
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
105 0
1085 0
1
0 0 258 244
1
end_operator
begin_operator
move loc_9_2 loc_9_3 right
2
141 0
1086 0
1
0 0 258 261
1
end_operator
begin_operator
move loc_9_20 loc_8_20 up
2
107 0
1087 0
1
0 0 259 245
1
end_operator
begin_operator
move loc_9_20 loc_9_19 left
2
133 0
1088 0
1
0 0 259 257
1
end_operator
begin_operator
move loc_9_20 loc_9_21 right
2
139 0
1089 0
1
0 0 259 260
1
end_operator
begin_operator
move loc_9_21 loc_8_21 up
2
109 0
1090 0
1
0 0 260 246
1
end_operator
begin_operator
move loc_9_21 loc_9_20 left
2
137 0
1091 0
1
0 0 260 259
1
end_operator
begin_operator
move loc_9_3 loc_10_3 down
2
114 0
1092 0
1
0 0 261 6
1
end_operator
begin_operator
move loc_9_3 loc_8_3 up
2
111 0
1093 0
1
0 0 261 247
1
end_operator
begin_operator
move loc_9_3 loc_9_2 left
2
135 0
1094 0
1
0 0 261 258
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
143 0
1095 0
1
0 0 261 262
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
116 0
1096 0
1
0 0 262 7
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
141 0
1097 0
1
0 0 262 261
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
145 0
1098 0
1
0 0 262 263
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
118 0
1099 0
1
0 0 263 8
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
113 0
1100 0
1
0 0 263 248
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
143 0
1101 0
1
0 0 263 262
1
end_operator
begin_operator
push loc_10_10 loc_11_10 loc_12_10 down box1
2
287 0
314 0
4
0 0 0 10
0 1 8 26
0 122 -1 0
0 152 0 1
1
end_operator
begin_operator
push loc_10_10 loc_11_10 loc_12_10 down box2
2
287 0
314 0
4
0 0 0 10
0 5 8 26
0 122 -1 0
0 152 0 1
1
end_operator
begin_operator
push loc_10_10 loc_11_10 loc_12_10 down box3
2
287 0
314 0
4
0 0 0 10
0 4 8 26
0 122 -1 0
0 152 0 1
1
end_operator
begin_operator
push loc_10_10 loc_11_10 loc_12_10 down box4
2
287 0
314 0
4
0 0 0 10
0 3 8 26
0 122 -1 0
0 152 0 1
1
end_operator
begin_operator
push loc_10_10 loc_11_10 loc_12_10 down box6
2
287 0
314 0
4
0 0 0 10
0 2 8 26
0 122 -1 0
0 152 0 1
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
288 0
1065 0
4
0 0 0 251
0 1 189 181
0 95 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
288 0
1065 0
4
0 0 0 251
0 5 189 181
0 95 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
288 0
1065 0
4
0 0 0 251
0 4 189 181
0 95 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
288 0
1065 0
4
0 0 0 251
0 3 189 181
0 95 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box6
2
288 0
1065 0
4
0 0 0 251
0 2 189 181
0 95 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box1
2
291 0
328 0
4
0 0 2 14
0 1 12 30
0 130 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box2
2
291 0
328 0
4
0 0 2 14
0 5 12 30
0 130 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box3
2
291 0
328 0
4
0 0 2 14
0 4 12 30
0 130 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box4
2
291 0
328 0
4
0 0 2 14
0 3 12 30
0 130 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box6
2
291 0
328 0
4
0 0 2 14
0 2 12 30
0 130 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box1
2
293 0
332 0
4
0 0 3 15
0 1 13 31
0 132 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box2
2
293 0
332 0
4
0 0 3 15
0 5 13 31
0 132 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box3
2
293 0
332 0
4
0 0 3 15
0 4 13 31
0 132 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box4
2
293 0
332 0
4
0 0 3 15
0 3 13 31
0 132 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box6
2
293 0
332 0
4
0 0 3 15
0 2 13 31
0 132 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box1
2
294 0
1070 0
4
0 0 3 253
0 1 190 183
0 99 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box2
2
294 0
1070 0
4
0 0 3 253
0 5 190 183
0 99 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box3
2
294 0
1070 0
4
0 0 3 253
0 4 190 183
0 99 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box4
2
294 0
1070 0
4
0 0 3 253
0 3 190 183
0 99 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box6
2
294 0
1070 0
4
0 0 3 253
0 2 190 183
0 99 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box1
2
295 0
339 0
4
0 0 4 17
0 1 15 33
0 136 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box2
2
295 0
339 0
4
0 0 4 17
0 5 15 33
0 136 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box3
2
295 0
339 0
4
0 0 4 17
0 4 15 33
0 136 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box4
2
295 0
339 0
4
0 0 4 17
0 3 15 33
0 136 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box6
2
295 0
339 0
4
0 0 4 17
0 2 15 33
0 136 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box1
2
296 0
1076 0
4
0 0 4 255
0 1 192 185
0 101 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box2
2
296 0
1076 0
4
0 0 4 255
0 5 192 185
0 101 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box3
2
296 0
1076 0
4
0 0 4 255
0 4 192 185
0 101 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box4
2
296 0
1076 0
4
0 0 4 255
0 3 192 185
0 101 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box6
2
296 0
1076 0
4
0 0 4 255
0 2 192 185
0 101 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box1
2
297 0
346 0
4
0 0 5 19
0 1 17 35
0 140 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box2
2
297 0
346 0
4
0 0 5 19
0 5 17 35
0 140 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box3
2
297 0
346 0
4
0 0 5 19
0 4 17 35
0 140 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box4
2
297 0
346 0
4
0 0 5 19
0 3 17 35
0 140 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box6
2
297 0
346 0
4
0 0 5 19
0 2 17 35
0 140 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box7
2
301 0
1093 0
4
0 0 6 261
0 6 57 54
0 111 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box1
2
307 0
357 0
4
0 0 8 23
0 1 21 37
0 147 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box2
2
307 0
357 0
4
0 0 8 23
0 5 21 37
0 147 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box3
2
307 0
357 0
4
0 0 8 23
0 4 21 37
0 147 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box4
2
307 0
357 0
4
0 0 8 23
0 3 21 37
0 147 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box6
2
307 0
357 0
4
0 0 8 23
0 2 21 37
0 147 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
308 0
1100 0
4
0 0 8 263
0 1 197 188
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
308 0
1100 0
4
0 0 8 263
0 5 197 188
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
308 0
1100 0
4
0 0 8 263
0 4 197 188
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box4
2
308 0
1100 0
4
0 0 8 263
0 3 197 188
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box6
2
308 0
1100 0
4
0 0 8 263
0 2 197 188
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box7
2
308 0
1100 0
4
0 0 8 263
0 6 59 55
0 113 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box1
2
310 0
370 0
4
0 0 9 27
0 1 25 41
0 151 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box2
2
310 0
370 0
4
0 0 9 27
0 5 25 41
0 151 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box3
2
310 0
370 0
4
0 0 9 27
0 4 25 41
0 151 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box4
2
310 0
370 0
4
0 0 9 27
0 3 25 41
0 151 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box6
2
310 0
370 0
4
0 0 9 27
0 2 25 41
0 151 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box1
2
288 0
311 0
4
0 0 10 0
0 1 0 189
0 102 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box2
2
288 0
311 0
4
0 0 10 0
0 5 0 189
0 102 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box3
2
288 0
311 0
4
0 0 10 0
0 4 0 189
0 102 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box4
2
288 0
311 0
4
0 0 10 0
0 3 0 189
0 102 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box6
2
288 0
311 0
4
0 0 10 0
0 2 0 189
0 102 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box1
2
312 0
316 0
4
0 0 10 11
0 1 9 10
0 124 -1 0
0 126 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box2
2
312 0
316 0
4
0 0 10 11
0 5 9 10
0 124 -1 0
0 126 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box3
2
312 0
316 0
4
0 0 10 11
0 4 9 10
0 124 -1 0
0 126 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box4
2
312 0
316 0
4
0 0 10 11
0 3 9 10
0 124 -1 0
0 126 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box6
2
312 0
316 0
4
0 0 10 11
0 2 9 10
0 124 -1 0
0 126 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box1
2
313 0
369 0
4
0 0 10 27
0 1 25 24
0 150 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box2
2
313 0
369 0
4
0 0 10 27
0 5 25 24
0 150 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box3
2
313 0
369 0
4
0 0 10 27
0 4 25 24
0 150 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box4
2
313 0
369 0
4
0 0 10 27
0 3 25 24
0 150 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box6
2
313 0
369 0
4
0 0 10 27
0 2 25 24
0 150 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_12_10 loc_13_10 down box1
2
314 0
374 0
4
0 0 10 28
0 1 26 42
0 152 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_10 loc_12_10 loc_13_10 down box2
2
314 0
374 0
4
0 0 10 28
0 5 26 42
0 152 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_10 loc_12_10 loc_13_10 down box3
2
314 0
374 0
4
0 0 10 28
0 4 26 42
0 152 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_10 loc_12_10 loc_13_10 down box4
2
314 0
374 0
4
0 0 10 28
0 3 26 42
0 152 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_10 loc_12_10 loc_13_10 down box6
2
314 0
374 0
4
0 0 10 28
0 2 26 42
0 152 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box1
2
313 0
315 0
4
0 0 11 10
0 1 8 25
0 122 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box2
2
313 0
315 0
4
0 0 11 10
0 5 8 25
0 122 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box3
2
313 0
315 0
4
0 0 11 10
0 4 8 25
0 122 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box4
2
313 0
315 0
4
0 0 11 10
0 3 8 25
0 122 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box6
2
313 0
315 0
4
0 0 11 10
0 2 8 25
0 122 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_12 loc_11_13 right box1
2
316 0
320 0
4
0 0 11 12
0 1 10 11
0 126 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_12 loc_11_13 right box2
2
316 0
320 0
4
0 0 11 12
0 5 10 11
0 126 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_12 loc_11_13 right box3
2
316 0
320 0
4
0 0 11 12
0 4 10 11
0 126 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_12 loc_11_13 right box4
2
316 0
320 0
4
0 0 11 12
0 3 10 11
0 126 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_12 loc_11_13 right box6
2
316 0
320 0
4
0 0 11 12
0 2 10 11
0 126 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box1
2
317 0
378 0
4
0 0 11 29
0 1 27 43
0 153 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box2
2
317 0
378 0
4
0 0 11 29
0 5 27 43
0 153 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box3
2
317 0
378 0
4
0 0 11 29
0 4 27 43
0 153 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box4
2
317 0
378 0
4
0 0 11 29
0 3 27 43
0 153 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box6
2
317 0
378 0
4
0 0 11 29
0 2 27 43
0 153 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box1
2
315 0
319 0
4
0 0 12 11
0 1 9 8
0 122 0 1
0 124 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box2
2
315 0
319 0
4
0 0 12 11
0 5 9 8
0 122 0 1
0 124 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box3
2
315 0
319 0
4
0 0 12 11
0 4 9 8
0 122 0 1
0 124 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box4
2
315 0
319 0
4
0 0 12 11
0 3 9 8
0 122 0 1
0 124 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box6
2
315 0
319 0
4
0 0 12 11
0 2 9 8
0 122 0 1
0 124 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_13 loc_11_14 right box1
2
320 0
323 0
4
0 0 12 13
0 1 11 12
0 128 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_11_12 loc_11_13 loc_11_14 right box2
2
320 0
323 0
4
0 0 12 13
0 5 11 12
0 128 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_11_12 loc_11_13 loc_11_14 right box3
2
320 0
323 0
4
0 0 12 13
0 4 11 12
0 128 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_11_12 loc_11_13 loc_11_14 right box4
2
320 0
323 0
4
0 0 12 13
0 3 11 12
0 128 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_11_12 loc_11_13 loc_11_14 right box6
2
320 0
323 0
4
0 0 12 13
0 2 11 12
0 128 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_11_12 loc_12_12 loc_13_12 down box1
2
321 0
382 0
4
0 0 12 30
0 1 28 44
0 154 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_11_12 loc_12_12 loc_13_12 down box2
2
321 0
382 0
4
0 0 12 30
0 5 28 44
0 154 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_11_12 loc_12_12 loc_13_12 down box3
2
321 0
382 0
4
0 0 12 30
0 4 28 44
0 154 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_11_12 loc_12_12 loc_13_12 down box4
2
321 0
382 0
4
0 0 12 30
0 3 28 44
0 154 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_11_12 loc_12_12 loc_13_12 down box6
2
321 0
382 0
4
0 0 12 30
0 2 28 44
0 154 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_12 loc_11_11 left box1
2
319 0
322 0
4
0 0 13 12
0 1 10 9
0 124 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_12 loc_11_11 left box2
2
319 0
322 0
4
0 0 13 12
0 5 10 9
0 124 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_12 loc_11_11 left box3
2
319 0
322 0
4
0 0 13 12
0 4 10 9
0 124 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_12 loc_11_11 left box4
2
319 0
322 0
4
0 0 13 12
0 3 10 9
0 124 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_12 loc_11_11 left box6
2
319 0
322 0
4
0 0 13 12
0 2 10 9
0 124 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box1
2
323 0
327 0
4
0 0 13 14
0 1 12 13
0 130 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box2
2
323 0
327 0
4
0 0 13 14
0 5 12 13
0 130 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box3
2
323 0
327 0
4
0 0 13 14
0 4 12 13
0 130 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box4
2
323 0
327 0
4
0 0 13 14
0 3 12 13
0 130 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box6
2
323 0
327 0
4
0 0 13 14
0 2 12 13
0 130 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box1
2
324 0
386 0
4
0 0 13 31
0 1 29 45
0 155 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box2
2
324 0
386 0
4
0 0 13 31
0 5 29 45
0 155 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box3
2
324 0
386 0
4
0 0 13 31
0 4 29 45
0 155 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box4
2
324 0
386 0
4
0 0 13 31
0 3 29 45
0 155 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box6
2
324 0
386 0
4
0 0 13 31
0 2 29 45
0 155 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_11_14 loc_11_13 loc_11_12 left box1
2
322 0
326 0
4
0 0 14 13
0 1 11 10
0 126 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_11_14 loc_11_13 loc_11_12 left box2
2
322 0
326 0
4
0 0 14 13
0 5 11 10
0 126 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_11_14 loc_11_13 loc_11_12 left box3
2
322 0
326 0
4
0 0 14 13
0 4 11 10
0 126 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_11_14 loc_11_13 loc_11_12 left box4
2
322 0
326 0
4
0 0 14 13
0 3 11 10
0 126 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_11_14 loc_11_13 loc_11_12 left box6
2
322 0
326 0
4
0 0 14 13
0 2 11 10
0 126 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_11_14 loc_11_15 loc_11_16 right box1
2
327 0
331 0
4
0 0 14 15
0 1 13 14
0 132 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_11_14 loc_11_15 loc_11_16 right box2
2
327 0
331 0
4
0 0 14 15
0 5 13 14
0 132 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_11_14 loc_11_15 loc_11_16 right box3
2
327 0
331 0
4
0 0 14 15
0 4 13 14
0 132 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_11_14 loc_11_15 loc_11_16 right box4
2
327 0
331 0
4
0 0 14 15
0 3 13 14
0 132 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_11_14 loc_11_15 loc_11_16 right box6
2
327 0
331 0
4
0 0 14 15
0 2 13 14
0 132 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box1
2
328 0
390 0
4
0 0 14 32
0 1 30 46
0 156 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box2
2
328 0
390 0
4
0 0 14 32
0 5 30 46
0 156 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box3
2
328 0
390 0
4
0 0 14 32
0 4 30 46
0 156 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box4
2
328 0
390 0
4
0 0 14 32
0 3 30 46
0 156 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box6
2
328 0
390 0
4
0 0 14 32
0 2 30 46
0 156 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box1
2
294 0
329 0
4
0 0 15 3
0 1 3 190
0 108 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box2
2
294 0
329 0
4
0 0 15 3
0 5 3 190
0 108 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box3
2
294 0
329 0
4
0 0 15 3
0 4 3 190
0 108 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box4
2
294 0
329 0
4
0 0 15 3
0 3 3 190
0 108 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box6
2
294 0
329 0
4
0 0 15 3
0 2 3 190
0 108 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box1
2
326 0
330 0
4
0 0 15 14
0 1 12 11
0 128 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box2
2
326 0
330 0
4
0 0 15 14
0 5 12 11
0 128 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box3
2
326 0
330 0
4
0 0 15 14
0 4 12 11
0 128 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box4
2
326 0
330 0
4
0 0 15 14
0 3 12 11
0 128 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box6
2
326 0
330 0
4
0 0 15 14
0 2 12 11
0 128 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_16 loc_11_17 right box1
2
331 0
334 0
4
0 0 15 16
0 1 14 15
0 134 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_11_15 loc_11_16 loc_11_17 right box2
2
331 0
334 0
4
0 0 15 16
0 5 14 15
0 134 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_11_15 loc_11_16 loc_11_17 right box3
2
331 0
334 0
4
0 0 15 16
0 4 14 15
0 134 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_11_15 loc_11_16 loc_11_17 right box4
2
331 0
334 0
4
0 0 15 16
0 3 14 15
0 134 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_11_15 loc_11_16 loc_11_17 right box6
2
331 0
334 0
4
0 0 15 16
0 2 14 15
0 134 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box1
2
332 0
394 0
4
0 0 15 33
0 1 31 47
0 157 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box2
2
332 0
394 0
4
0 0 15 33
0 5 31 47
0 157 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box3
2
332 0
394 0
4
0 0 15 33
0 4 31 47
0 157 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box4
2
332 0
394 0
4
0 0 15 33
0 3 31 47
0 157 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box6
2
332 0
394 0
4
0 0 15 33
0 2 31 47
0 157 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_11_16 loc_11_15 loc_11_14 left box1
2
330 0
333 0
4
0 0 16 15
0 1 13 12
0 130 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_11_16 loc_11_15 loc_11_14 left box2
2
330 0
333 0
4
0 0 16 15
0 5 13 12
0 130 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_11_16 loc_11_15 loc_11_14 left box3
2
330 0
333 0
4
0 0 16 15
0 4 13 12
0 130 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_11_16 loc_11_15 loc_11_14 left box4
2
330 0
333 0
4
0 0 16 15
0 3 13 12
0 130 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_11_16 loc_11_15 loc_11_14 left box6
2
330 0
333 0
4
0 0 16 15
0 2 13 12
0 130 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_11_16 loc_11_17 loc_11_18 right box1
2
334 0
338 0
4
0 0 16 17
0 1 15 16
0 136 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_11_16 loc_11_17 loc_11_18 right box2
2
334 0
338 0
4
0 0 16 17
0 5 15 16
0 136 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_11_16 loc_11_17 loc_11_18 right box3
2
334 0
338 0
4
0 0 16 17
0 4 15 16
0 136 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_11_16 loc_11_17 loc_11_18 right box4
2
334 0
338 0
4
0 0 16 17
0 3 15 16
0 136 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_11_16 loc_11_17 loc_11_18 right box6
2
334 0
338 0
4
0 0 16 17
0 2 15 16
0 136 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box1
2
296 0
336 0
4
0 0 17 4
0 1 4 192
0 110 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box2
2
296 0
336 0
4
0 0 17 4
0 5 4 192
0 110 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box3
2
296 0
336 0
4
0 0 17 4
0 4 4 192
0 110 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box4
2
296 0
336 0
4
0 0 17 4
0 3 4 192
0 110 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box6
2
296 0
336 0
4
0 0 17 4
0 2 4 192
0 110 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_16 loc_11_15 left box1
2
333 0
337 0
4
0 0 17 16
0 1 14 13
0 132 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_16 loc_11_15 left box2
2
333 0
337 0
4
0 0 17 16
0 5 14 13
0 132 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_16 loc_11_15 left box3
2
333 0
337 0
4
0 0 17 16
0 4 14 13
0 132 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_16 loc_11_15 left box4
2
333 0
337 0
4
0 0 17 16
0 3 14 13
0 132 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_16 loc_11_15 left box6
2
333 0
337 0
4
0 0 17 16
0 2 14 13
0 132 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box1
2
338 0
341 0
4
0 0 17 18
0 1 16 17
0 138 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box2
2
338 0
341 0
4
0 0 17 18
0 5 16 17
0 138 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box3
2
338 0
341 0
4
0 0 17 18
0 4 16 17
0 138 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box4
2
338 0
341 0
4
0 0 17 18
0 3 16 17
0 138 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box6
2
338 0
341 0
4
0 0 17 18
0 2 16 17
0 138 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box1
2
339 0
401 0
4
0 0 17 35
0 1 33 48
0 159 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box2
2
339 0
401 0
4
0 0 17 35
0 5 33 48
0 159 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box3
2
339 0
401 0
4
0 0 17 35
0 4 33 48
0 159 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box4
2
339 0
401 0
4
0 0 17 35
0 3 33 48
0 159 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box6
2
339 0
401 0
4
0 0 17 35
0 2 33 48
0 159 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_17 loc_11_16 left box1
2
337 0
340 0
4
0 0 18 17
0 1 15 14
0 134 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_11_18 loc_11_17 loc_11_16 left box2
2
337 0
340 0
4
0 0 18 17
0 5 15 14
0 134 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_11_18 loc_11_17 loc_11_16 left box3
2
337 0
340 0
4
0 0 18 17
0 4 15 14
0 134 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_11_18 loc_11_17 loc_11_16 left box4
2
337 0
340 0
4
0 0 18 17
0 3 15 14
0 134 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_11_18 loc_11_17 loc_11_16 left box6
2
337 0
340 0
4
0 0 18 17
0 2 15 14
0 134 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box1
2
341 0
345 0
4
0 0 18 19
0 1 17 18
0 140 -1 0
0 142 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box2
2
341 0
345 0
4
0 0 18 19
0 5 17 18
0 140 -1 0
0 142 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box3
2
341 0
345 0
4
0 0 18 19
0 4 17 18
0 140 -1 0
0 142 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box4
2
341 0
345 0
4
0 0 18 19
0 3 17 18
0 140 -1 0
0 142 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box6
2
341 0
345 0
4
0 0 18 19
0 2 17 18
0 140 -1 0
0 142 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box1
2
342 0
405 0
4
0 0 18 36
0 1 34 49
0 160 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box2
2
342 0
405 0
4
0 0 18 36
0 5 34 49
0 160 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box3
2
342 0
405 0
4
0 0 18 36
0 4 34 49
0 160 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box4
2
342 0
405 0
4
0 0 18 36
0 3 34 49
0 160 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box6
2
342 0
405 0
4
0 0 18 36
0 2 34 49
0 160 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box1
2
298 0
343 0
4
0 0 19 5
0 1 5 194
0 112 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box2
2
298 0
343 0
4
0 0 19 5
0 5 5 194
0 112 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box3
2
298 0
343 0
4
0 0 19 5
0 4 5 194
0 112 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box4
2
298 0
343 0
4
0 0 19 5
0 3 5 194
0 112 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box6
2
298 0
343 0
4
0 0 19 5
0 2 5 194
0 112 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box1
2
340 0
344 0
4
0 0 19 18
0 1 16 15
0 136 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box2
2
340 0
344 0
4
0 0 19 18
0 5 16 15
0 136 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box3
2
340 0
344 0
4
0 0 19 18
0 4 16 15
0 136 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box4
2
340 0
344 0
4
0 0 19 18
0 3 16 15
0 136 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box6
2
340 0
344 0
4
0 0 19 18
0 2 16 15
0 136 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box1
2
346 0
409 0
4
0 0 19 37
0 1 35 50
0 161 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box2
2
346 0
409 0
4
0 0 19 37
0 5 35 50
0 161 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box3
2
346 0
409 0
4
0 0 19 37
0 4 35 50
0 161 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box4
2
346 0
409 0
4
0 0 19 37
0 3 35 50
0 161 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box6
2
346 0
409 0
4
0 0 19 37
0 2 35 50
0 161 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_20 loc_11_19 loc_11_18 left box1
2
344 0
347 0
4
0 0 20 19
0 1 17 16
0 138 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_11_20 loc_11_19 loc_11_18 left box2
2
344 0
347 0
4
0 0 20 19
0 5 17 16
0 138 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_11_20 loc_11_19 loc_11_18 left box3
2
344 0
347 0
4
0 0 20 19
0 4 17 16
0 138 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_11_20 loc_11_19 loc_11_18 left box4
2
344 0
347 0
4
0 0 20 19
0 3 17 16
0 138 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_11_20 loc_11_19 loc_11_18 left box6
2
344 0
347 0
4
0 0 20 19
0 2 17 16
0 138 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box1
2
348 0
412 0
4
0 0 20 38
0 1 36 51
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box2
2
348 0
412 0
4
0 0 20 38
0 5 36 51
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box3
2
348 0
412 0
4
0 0 20 38
0 4 36 51
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box4
2
348 0
412 0
4
0 0 20 38
0 3 36 51
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box5
2
348 0
412 0
4
0 0 20 38
0 7 1 2
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_20 loc_12_20 loc_13_20 down box6
2
348 0
412 0
4
0 0 20 38
0 2 36 51
0 163 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box7
2
301 0
349 0
4
0 0 21 6
0 6 0 57
0 114 -1 0
0 141 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box1
2
350 0
353 0
4
0 0 21 22
0 1 20 21
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box2
2
350 0
353 0
4
0 0 21 22
0 5 20 21
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box3
2
350 0
353 0
4
0 0 21 22
0 4 20 21
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box4
2
350 0
353 0
4
0 0 21 22
0 3 20 21
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box6
2
350 0
353 0
4
0 0 21 22
0 2 20 21
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box1
2
353 0
356 0
4
0 0 22 23
0 1 21 22
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box2
2
353 0
356 0
4
0 0 22 23
0 5 21 22
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box3
2
353 0
356 0
4
0 0 22 23
0 4 21 22
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box4
2
353 0
356 0
4
0 0 22 23
0 3 21 22
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box6
2
353 0
356 0
4
0 0 22 23
0 2 21 22
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
308 0
354 0
4
0 0 23 8
0 1 6 197
0 118 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
308 0
354 0
4
0 0 23 8
0 5 6 197
0 118 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
308 0
354 0
4
0 0 23 8
0 4 6 197
0 118 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box4
2
308 0
354 0
4
0 0 23 8
0 3 6 197
0 118 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box6
2
308 0
354 0
4
0 0 23 8
0 2 6 197
0 118 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box1
2
352 0
355 0
4
0 0 23 22
0 1 20 19
0 144 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box2
2
352 0
355 0
4
0 0 23 22
0 5 20 19
0 144 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box3
2
352 0
355 0
4
0 0 23 22
0 4 20 19
0 144 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box4
2
352 0
355 0
4
0 0 23 22
0 3 20 19
0 144 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box6
2
352 0
355 0
4
0 0 23 22
0 2 20 19
0 144 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box1
2
356 0
359 0
4
0 0 23 24
0 1 22 23
0 148 -1 0
0 149 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box2
2
356 0
359 0
4
0 0 23 24
0 5 22 23
0 148 -1 0
0 149 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box3
2
356 0
359 0
4
0 0 23 24
0 4 22 23
0 148 -1 0
0 149 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box4
2
356 0
359 0
4
0 0 23 24
0 3 22 23
0 148 -1 0
0 149 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box6
2
356 0
359 0
4
0 0 23 24
0 2 22 23
0 148 -1 0
0 149 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box1
2
357 0
415 0
4
0 0 23 39
0 1 37 53
0 164 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box2
2
357 0
415 0
4
0 0 23 39
0 5 37 53
0 164 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box3
2
357 0
415 0
4
0 0 23 39
0 4 37 53
0 164 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box4
2
357 0
415 0
4
0 0 23 39
0 3 37 53
0 164 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box6
2
357 0
415 0
4
0 0 23 39
0 2 37 53
0 164 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box1
2
355 0
358 0
4
0 0 24 23
0 1 21 20
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box2
2
355 0
358 0
4
0 0 24 23
0 5 21 20
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box3
2
355 0
358 0
4
0 0 24 23
0 4 21 20
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box4
2
355 0
358 0
4
0 0 24 23
0 3 21 20
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box6
2
355 0
358 0
4
0 0 24 23
0 2 21 20
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box1
2
359 0
362 0
4
0 0 24 25
0 1 23 24
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box2
2
359 0
362 0
4
0 0 24 25
0 5 23 24
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box3
2
359 0
362 0
4
0 0 24 25
0 4 23 24
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box4
2
359 0
362 0
4
0 0 24 25
0 3 23 24
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box6
2
359 0
362 0
4
0 0 24 25
0 2 23 24
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box1
2
360 0
419 0
4
0 0 24 40
0 1 38 54
0 165 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box2
2
360 0
419 0
4
0 0 24 40
0 5 38 54
0 165 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box3
2
360 0
419 0
4
0 0 24 40
0 4 38 54
0 165 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box4
2
360 0
419 0
4
0 0 24 40
0 3 38 54
0 165 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box6
2
360 0
419 0
4
0 0 24 40
0 2 38 54
0 165 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box1
2
358 0
361 0
4
0 0 25 24
0 1 22 21
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box2
2
358 0
361 0
4
0 0 25 24
0 5 22 21
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box3
2
358 0
361 0
4
0 0 25 24
0 4 22 21
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box4
2
358 0
361 0
4
0 0 25 24
0 3 22 21
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box6
2
358 0
361 0
4
0 0 25 24
0 2 22 21
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box1
2
362 0
365 0
4
0 0 25 26
0 1 24 25
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box2
2
362 0
365 0
4
0 0 25 26
0 5 24 25
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box3
2
362 0
365 0
4
0 0 25 26
0 4 24 25
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box4
2
362 0
365 0
4
0 0 25 26
0 3 24 25
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box6
2
362 0
365 0
4
0 0 25 26
0 2 24 25
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box1
2
363 0
423 0
4
0 0 25 41
0 1 39 55
0 166 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box2
2
363 0
423 0
4
0 0 25 41
0 5 39 55
0 166 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box3
2
363 0
423 0
4
0 0 25 41
0 4 39 55
0 166 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box4
2
363 0
423 0
4
0 0 25 41
0 3 39 55
0 166 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box6
2
363 0
423 0
4
0 0 25 41
0 2 39 55
0 166 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box1
2
361 0
364 0
4
0 0 26 25
0 1 23 22
0 148 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box2
2
361 0
364 0
4
0 0 26 25
0 5 23 22
0 148 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box3
2
361 0
364 0
4
0 0 26 25
0 4 23 22
0 148 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box4
2
361 0
364 0
4
0 0 26 25
0 3 23 22
0 148 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box6
2
361 0
364 0
4
0 0 26 25
0 2 23 22
0 148 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box1
2
365 0
368 0
4
0 0 26 27
0 1 25 8
0 122 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box2
2
365 0
368 0
4
0 0 26 27
0 5 25 8
0 122 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box3
2
365 0
368 0
4
0 0 26 27
0 4 25 8
0 122 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box4
2
365 0
368 0
4
0 0 26 27
0 3 25 8
0 122 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box6
2
365 0
368 0
4
0 0 26 27
0 2 25 8
0 122 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box1
2
366 0
427 0
4
0 0 26 42
0 1 40 56
0 167 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box2
2
366 0
427 0
4
0 0 26 42
0 5 40 56
0 167 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box3
2
366 0
427 0
4
0 0 26 42
0 4 40 56
0 167 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box4
2
366 0
427 0
4
0 0 26 42
0 3 40 56
0 167 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box6
2
366 0
427 0
4
0 0 26 42
0 2 40 56
0 167 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box1
2
312 0
368 0
4
0 0 27 10
0 1 8 9
0 122 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box2
2
312 0
368 0
4
0 0 27 10
0 5 8 9
0 122 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box3
2
312 0
368 0
4
0 0 27 10
0 4 8 9
0 122 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box4
2
312 0
368 0
4
0 0 27 10
0 3 8 9
0 122 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box6
2
312 0
368 0
4
0 0 27 10
0 2 8 9
0 122 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box1
2
364 0
369 0
4
0 0 27 26
0 1 24 23
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box2
2
364 0
369 0
4
0 0 27 26
0 5 24 23
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box3
2
364 0
369 0
4
0 0 27 26
0 4 24 23
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box4
2
364 0
369 0
4
0 0 27 26
0 3 24 23
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box6
2
364 0
369 0
4
0 0 27 26
0 2 24 23
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_12_9 loc_13_9 down box1
2
370 0
431 0
4
0 0 27 43
0 1 41 57
0 168 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_9 loc_12_9 loc_13_9 down box2
2
370 0
431 0
4
0 0 27 43
0 5 41 57
0 168 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_9 loc_12_9 loc_13_9 down box3
2
370 0
431 0
4
0 0 27 43
0 4 41 57
0 168 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_9 loc_12_9 loc_13_9 down box4
2
370 0
431 0
4
0 0 27 43
0 3 41 57
0 168 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_9 loc_12_9 loc_13_9 down box6
2
370 0
431 0
4
0 0 27 43
0 2 41 57
0 168 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_12_10 loc_11_10 loc_10_10 up box1
2
311 0
371 0
4
0 0 28 10
0 1 8 0
0 102 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_11_10 loc_10_10 up box2
2
311 0
371 0
4
0 0 28 10
0 5 8 0
0 102 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_11_10 loc_10_10 up box3
2
311 0
371 0
4
0 0 28 10
0 4 8 0
0 102 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_11_10 loc_10_10 up box4
2
311 0
371 0
4
0 0 28 10
0 3 8 0
0 102 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_11_10 loc_10_10 up box6
2
311 0
371 0
4
0 0 28 10
0 2 8 0
0 102 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_12_11 loc_12_12 right box1
2
372 0
377 0
4
0 0 28 29
0 1 27 28
0 153 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_12_10 loc_12_11 loc_12_12 right box2
2
372 0
377 0
4
0 0 28 29
0 5 27 28
0 153 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_12_10 loc_12_11 loc_12_12 right box3
2
372 0
377 0
4
0 0 28 29
0 4 27 28
0 153 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_12_10 loc_12_11 loc_12_12 right box4
2
372 0
377 0
4
0 0 28 29
0 3 27 28
0 153 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_12_10 loc_12_11 loc_12_12 right box6
2
372 0
377 0
4
0 0 28 29
0 2 27 28
0 153 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_12_10 loc_12_9 loc_12_8 left box1
2
373 0
430 0
4
0 0 28 43
0 1 41 40
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_12_9 loc_12_8 left box2
2
373 0
430 0
4
0 0 28 43
0 5 41 40
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_12_9 loc_12_8 left box3
2
373 0
430 0
4
0 0 28 43
0 4 41 40
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_12_9 loc_12_8 left box4
2
373 0
430 0
4
0 0 28 43
0 3 41 40
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_12_9 loc_12_8 left box6
2
373 0
430 0
4
0 0 28 43
0 2 41 40
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_10 loc_13_10 loc_14_10 down box1
2
374 0
435 0
4
0 0 28 44
0 1 42 58
0 169 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_12_10 loc_13_10 loc_14_10 down box2
2
374 0
435 0
4
0 0 28 44
0 5 42 58
0 169 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_12_10 loc_13_10 loc_14_10 down box3
2
374 0
435 0
4
0 0 28 44
0 4 42 58
0 169 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_12_10 loc_13_10 loc_14_10 down box4
2
374 0
435 0
4
0 0 28 44
0 3 42 58
0 169 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_12_10 loc_13_10 loc_14_10 down box6
2
374 0
435 0
4
0 0 28 44
0 2 42 58
0 169 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_10 loc_12_9 left box1
2
373 0
376 0
4
0 0 29 28
0 1 26 41
0 152 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_10 loc_12_9 left box2
2
373 0
376 0
4
0 0 29 28
0 5 26 41
0 152 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_10 loc_12_9 left box3
2
373 0
376 0
4
0 0 29 28
0 4 26 41
0 152 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_10 loc_12_9 left box4
2
373 0
376 0
4
0 0 29 28
0 3 26 41
0 152 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_10 loc_12_9 left box6
2
373 0
376 0
4
0 0 29 28
0 2 26 41
0 152 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box1
2
377 0
381 0
4
0 0 29 30
0 1 28 29
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box2
2
377 0
381 0
4
0 0 29 30
0 5 28 29
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box3
2
377 0
381 0
4
0 0 29 30
0 4 28 29
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box4
2
377 0
381 0
4
0 0 29 30
0 3 28 29
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box6
2
377 0
381 0
4
0 0 29 30
0 2 28 29
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box1
2
378 0
439 0
4
0 0 29 45
0 1 43 59
0 170 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box2
2
378 0
439 0
4
0 0 29 45
0 5 43 59
0 170 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box3
2
378 0
439 0
4
0 0 29 45
0 4 43 59
0 170 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box4
2
378 0
439 0
4
0 0 29 45
0 3 43 59
0 170 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box6
2
378 0
439 0
4
0 0 29 45
0 2 43 59
0 170 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box1
2
318 0
379 0
4
0 0 30 12
0 1 10 1
0 104 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box2
2
318 0
379 0
4
0 0 30 12
0 5 10 1
0 104 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box3
2
318 0
379 0
4
0 0 30 12
0 4 10 1
0 104 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box4
2
318 0
379 0
4
0 0 30 12
0 3 10 1
0 104 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box6
2
318 0
379 0
4
0 0 30 12
0 2 10 1
0 104 0 1
0 126 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_11 loc_12_10 left box1
2
376 0
380 0
4
0 0 30 29
0 1 27 26
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_11 loc_12_10 left box2
2
376 0
380 0
4
0 0 30 29
0 5 27 26
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_11 loc_12_10 left box3
2
376 0
380 0
4
0 0 30 29
0 4 27 26
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_11 loc_12_10 left box4
2
376 0
380 0
4
0 0 30 29
0 3 27 26
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_11 loc_12_10 left box6
2
376 0
380 0
4
0 0 30 29
0 2 27 26
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box1
2
381 0
385 0
4
0 0 30 31
0 1 29 30
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box2
2
381 0
385 0
4
0 0 30 31
0 5 29 30
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box3
2
381 0
385 0
4
0 0 30 31
0 4 29 30
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box4
2
381 0
385 0
4
0 0 30 31
0 3 29 30
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box6
2
381 0
385 0
4
0 0 30 31
0 2 29 30
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_12_12 loc_13_12 loc_14_12 down box1
2
382 0
443 0
4
0 0 30 46
0 1 44 60
0 171 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_12_12 loc_13_12 loc_14_12 down box2
2
382 0
443 0
4
0 0 30 46
0 5 44 60
0 171 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_12_12 loc_13_12 loc_14_12 down box3
2
382 0
443 0
4
0 0 30 46
0 4 44 60
0 171 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_12_12 loc_13_12 loc_14_12 down box4
2
382 0
443 0
4
0 0 30 46
0 3 44 60
0 171 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_12_12 loc_13_12 loc_14_12 down box6
2
382 0
443 0
4
0 0 30 46
0 2 44 60
0 171 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box1
2
380 0
384 0
4
0 0 31 30
0 1 28 27
0 153 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box2
2
380 0
384 0
4
0 0 31 30
0 5 28 27
0 153 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box3
2
380 0
384 0
4
0 0 31 30
0 4 28 27
0 153 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box4
2
380 0
384 0
4
0 0 31 30
0 3 28 27
0 153 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box6
2
380 0
384 0
4
0 0 31 30
0 2 28 27
0 153 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box1
2
385 0
389 0
4
0 0 31 32
0 1 30 31
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box2
2
385 0
389 0
4
0 0 31 32
0 5 30 31
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box3
2
385 0
389 0
4
0 0 31 32
0 4 30 31
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box4
2
385 0
389 0
4
0 0 31 32
0 3 30 31
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box6
2
385 0
389 0
4
0 0 31 32
0 2 30 31
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box1
2
386 0
447 0
4
0 0 31 47
0 1 45 61
0 172 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box2
2
386 0
447 0
4
0 0 31 47
0 5 45 61
0 172 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box3
2
386 0
447 0
4
0 0 31 47
0 4 45 61
0 172 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box4
2
386 0
447 0
4
0 0 31 47
0 3 45 61
0 172 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box6
2
386 0
447 0
4
0 0 31 47
0 2 45 61
0 172 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box1
2
325 0
387 0
4
0 0 32 14
0 1 12 2
0 106 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box2
2
325 0
387 0
4
0 0 32 14
0 5 12 2
0 106 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box3
2
325 0
387 0
4
0 0 32 14
0 4 12 2
0 106 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box4
2
325 0
387 0
4
0 0 32 14
0 3 12 2
0 106 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box6
2
325 0
387 0
4
0 0 32 14
0 2 12 2
0 106 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box1
2
384 0
388 0
4
0 0 32 31
0 1 29 28
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box2
2
384 0
388 0
4
0 0 32 31
0 5 29 28
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box3
2
384 0
388 0
4
0 0 32 31
0 4 29 28
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box4
2
384 0
388 0
4
0 0 32 31
0 3 29 28
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box6
2
384 0
388 0
4
0 0 32 31
0 2 29 28
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box1
2
389 0
393 0
4
0 0 32 33
0 1 31 32
0 157 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box2
2
389 0
393 0
4
0 0 32 33
0 5 31 32
0 157 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box3
2
389 0
393 0
4
0 0 32 33
0 4 31 32
0 157 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box4
2
389 0
393 0
4
0 0 32 33
0 3 31 32
0 157 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box6
2
389 0
393 0
4
0 0 32 33
0 2 31 32
0 157 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box1
2
390 0
451 0
4
0 0 32 48
0 1 46 62
0 173 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box2
2
390 0
451 0
4
0 0 32 48
0 5 46 62
0 173 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box3
2
390 0
451 0
4
0 0 32 48
0 4 46 62
0 173 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box4
2
390 0
451 0
4
0 0 32 48
0 3 46 62
0 173 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box6
2
390 0
451 0
4
0 0 32 48
0 2 46 62
0 173 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box1
2
329 0
391 0
4
0 0 33 15
0 1 13 3
0 108 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box2
2
329 0
391 0
4
0 0 33 15
0 5 13 3
0 108 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box3
2
329 0
391 0
4
0 0 33 15
0 4 13 3
0 108 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box4
2
329 0
391 0
4
0 0 33 15
0 3 13 3
0 108 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box6
2
329 0
391 0
4
0 0 33 15
0 2 13 3
0 108 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box1
2
388 0
392 0
4
0 0 33 32
0 1 30 29
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box2
2
388 0
392 0
4
0 0 33 32
0 5 30 29
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box3
2
388 0
392 0
4
0 0 33 32
0 4 30 29
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box4
2
388 0
392 0
4
0 0 33 32
0 3 30 29
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box6
2
388 0
392 0
4
0 0 33 32
0 2 30 29
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box1
2
393 0
397 0
4
0 0 33 34
0 1 32 33
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box2
2
393 0
397 0
4
0 0 33 34
0 5 32 33
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box3
2
393 0
397 0
4
0 0 33 34
0 4 32 33
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box4
2
393 0
397 0
4
0 0 33 34
0 3 32 33
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box6
2
393 0
397 0
4
0 0 33 34
0 2 32 33
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_12_15 loc_13_15 loc_14_15 down box1
2
394 0
454 0
4
0 0 33 49
0 1 47 63
0 174 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_12_15 loc_13_15 loc_14_15 down box2
2
394 0
454 0
4
0 0 33 49
0 5 47 63
0 174 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_12_15 loc_13_15 loc_14_15 down box3
2
394 0
454 0
4
0 0 33 49
0 4 47 63
0 174 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_12_15 loc_13_15 loc_14_15 down box4
2
394 0
454 0
4
0 0 33 49
0 3 47 63
0 174 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_12_15 loc_13_15 loc_14_15 down box6
2
394 0
454 0
4
0 0 33 49
0 2 47 63
0 174 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box1
2
392 0
396 0
4
0 0 34 33
0 1 31 30
0 156 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box2
2
392 0
396 0
4
0 0 34 33
0 5 31 30
0 156 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box3
2
392 0
396 0
4
0 0 34 33
0 4 31 30
0 156 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box4
2
392 0
396 0
4
0 0 34 33
0 3 31 30
0 156 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box6
2
392 0
396 0
4
0 0 34 33
0 2 31 30
0 156 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box1
2
397 0
400 0
4
0 0 34 35
0 1 33 34
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box2
2
397 0
400 0
4
0 0 34 35
0 5 33 34
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box3
2
397 0
400 0
4
0 0 34 35
0 4 33 34
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box4
2
397 0
400 0
4
0 0 34 35
0 3 33 34
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box6
2
397 0
400 0
4
0 0 34 35
0 2 33 34
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box1
2
336 0
398 0
4
0 0 35 17
0 1 15 4
0 110 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box2
2
336 0
398 0
4
0 0 35 17
0 5 15 4
0 110 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box3
2
336 0
398 0
4
0 0 35 17
0 4 15 4
0 110 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box4
2
336 0
398 0
4
0 0 35 17
0 3 15 4
0 110 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box6
2
336 0
398 0
4
0 0 35 17
0 2 15 4
0 110 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box1
2
396 0
399 0
4
0 0 35 34
0 1 32 31
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box2
2
396 0
399 0
4
0 0 35 34
0 5 32 31
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box3
2
396 0
399 0
4
0 0 35 34
0 4 32 31
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box4
2
396 0
399 0
4
0 0 35 34
0 3 32 31
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box6
2
396 0
399 0
4
0 0 35 34
0 2 32 31
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box1
2
400 0
404 0
4
0 0 35 36
0 1 34 35
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box2
2
400 0
404 0
4
0 0 35 36
0 5 34 35
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box3
2
400 0
404 0
4
0 0 35 36
0 4 34 35
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box4
2
400 0
404 0
4
0 0 35 36
0 3 34 35
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box6
2
400 0
404 0
4
0 0 35 36
0 2 34 35
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box1
2
401 0
457 0
4
0 0 35 50
0 1 48 65
0 175 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box2
2
401 0
457 0
4
0 0 35 50
0 5 48 65
0 175 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box3
2
401 0
457 0
4
0 0 35 50
0 4 48 65
0 175 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box4
2
401 0
457 0
4
0 0 35 50
0 3 48 65
0 175 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box6
2
401 0
457 0
4
0 0 35 50
0 2 48 65
0 175 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box1
2
399 0
403 0
4
0 0 36 35
0 1 33 32
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box2
2
399 0
403 0
4
0 0 36 35
0 5 33 32
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box3
2
399 0
403 0
4
0 0 36 35
0 4 33 32
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box4
2
399 0
403 0
4
0 0 36 35
0 3 33 32
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box6
2
399 0
403 0
4
0 0 36 35
0 2 33 32
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_19 loc_12_20 right box1
2
404 0
408 0
4
0 0 36 37
0 1 35 36
0 161 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_12_18 loc_12_19 loc_12_20 right box2
2
404 0
408 0
4
0 0 36 37
0 5 35 36
0 161 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_12_18 loc_12_19 loc_12_20 right box3
2
404 0
408 0
4
0 0 36 37
0 4 35 36
0 161 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_12_18 loc_12_19 loc_12_20 right box4
2
404 0
408 0
4
0 0 36 37
0 3 35 36
0 161 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_12_18 loc_12_19 loc_12_20 right box6
2
404 0
408 0
4
0 0 36 37
0 2 35 36
0 161 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box1
2
405 0
461 0
4
0 0 36 51
0 1 49 66
0 176 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box2
2
405 0
461 0
4
0 0 36 51
0 5 49 66
0 176 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box3
2
405 0
461 0
4
0 0 36 51
0 4 49 66
0 176 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box4
2
405 0
461 0
4
0 0 36 51
0 3 49 66
0 176 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box6
2
405 0
461 0
4
0 0 36 51
0 2 49 66
0 176 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box1
2
343 0
406 0
4
0 0 37 19
0 1 17 5
0 112 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box2
2
343 0
406 0
4
0 0 37 19
0 5 17 5
0 112 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box3
2
343 0
406 0
4
0 0 37 19
0 4 17 5
0 112 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box4
2
343 0
406 0
4
0 0 37 19
0 3 17 5
0 112 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box6
2
343 0
406 0
4
0 0 37 19
0 2 17 5
0 112 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box1
2
403 0
407 0
4
0 0 37 36
0 1 34 33
0 159 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box2
2
403 0
407 0
4
0 0 37 36
0 5 34 33
0 159 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box3
2
403 0
407 0
4
0 0 37 36
0 4 34 33
0 159 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box4
2
403 0
407 0
4
0 0 37 36
0 3 34 33
0 159 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box6
2
403 0
407 0
4
0 0 37 36
0 2 34 33
0 159 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box1
2
409 0
465 0
4
0 0 37 52
0 1 50 67
0 177 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box2
2
409 0
465 0
4
0 0 37 52
0 5 50 67
0 177 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box3
2
409 0
465 0
4
0 0 37 52
0 4 50 67
0 177 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box4
2
409 0
465 0
4
0 0 37 52
0 3 50 67
0 177 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box6
2
409 0
465 0
4
0 0 37 52
0 2 50 67
0 177 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_12_20 loc_12_19 loc_12_18 left box1
2
407 0
411 0
4
0 0 38 37
0 1 35 34
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_12_20 loc_12_19 loc_12_18 left box2
2
407 0
411 0
4
0 0 38 37
0 5 35 34
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_12_20 loc_12_19 loc_12_18 left box3
2
407 0
411 0
4
0 0 38 37
0 4 35 34
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_12_20 loc_12_19 loc_12_18 left box4
2
407 0
411 0
4
0 0 38 37
0 3 35 34
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_12_20 loc_12_19 loc_12_18 left box6
2
407 0
411 0
4
0 0 38 37
0 2 35 34
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box1
2
412 0
469 0
4
0 0 38 53
0 1 51 68
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box2
2
412 0
469 0
4
0 0 38 53
0 5 51 68
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box3
2
412 0
469 0
4
0 0 38 53
0 4 51 68
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box4
2
412 0
469 0
4
0 0 38 53
0 3 51 68
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box5
2
412 0
469 0
4
0 0 38 53
0 7 2 4
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_20 loc_13_20 loc_14_20 down box6
2
412 0
469 0
4
0 0 38 53
0 2 51 68
0 178 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box1
2
354 0
413 0
4
0 0 39 23
0 1 21 6
0 118 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box2
2
354 0
413 0
4
0 0 39 23
0 5 21 6
0 118 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box3
2
354 0
413 0
4
0 0 39 23
0 4 21 6
0 118 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box4
2
354 0
413 0
4
0 0 39 23
0 3 21 6
0 118 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box6
2
354 0
413 0
4
0 0 39 23
0 2 21 6
0 118 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box1
2
414 0
418 0
4
0 0 39 40
0 1 38 39
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box2
2
414 0
418 0
4
0 0 39 40
0 5 38 39
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box3
2
414 0
418 0
4
0 0 39 40
0 4 38 39
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box4
2
414 0
418 0
4
0 0 39 40
0 3 38 39
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box6
2
414 0
418 0
4
0 0 39 40
0 2 38 39
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box1
2
415 0
473 0
4
0 0 39 55
0 1 53 69
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box2
2
415 0
473 0
4
0 0 39 55
0 5 53 69
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box3
2
415 0
473 0
4
0 0 39 55
0 4 53 69
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box4
2
415 0
473 0
4
0 0 39 55
0 3 53 69
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box6
2
415 0
473 0
4
0 0 39 55
0 2 53 69
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_6 loc_12_7 loc_12_8 right box1
2
418 0
422 0
4
0 0 40 41
0 1 39 40
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_12_6 loc_12_7 loc_12_8 right box2
2
418 0
422 0
4
0 0 40 41
0 5 39 40
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_12_6 loc_12_7 loc_12_8 right box3
2
418 0
422 0
4
0 0 40 41
0 4 39 40
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_12_6 loc_12_7 loc_12_8 right box4
2
418 0
422 0
4
0 0 40 41
0 3 39 40
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_12_6 loc_12_7 loc_12_8 right box6
2
418 0
422 0
4
0 0 40 41
0 2 39 40
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box1
2
419 0
477 0
4
0 0 40 56
0 1 54 70
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box2
2
419 0
477 0
4
0 0 40 56
0 5 54 70
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box3
2
419 0
477 0
4
0 0 40 56
0 4 54 70
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box4
2
419 0
477 0
4
0 0 40 56
0 3 54 70
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box6
2
419 0
477 0
4
0 0 40 56
0 2 54 70
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box1
2
417 0
421 0
4
0 0 41 40
0 1 38 37
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box2
2
417 0
421 0
4
0 0 41 40
0 5 38 37
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box3
2
417 0
421 0
4
0 0 41 40
0 4 38 37
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box4
2
417 0
421 0
4
0 0 41 40
0 3 38 37
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box6
2
417 0
421 0
4
0 0 41 40
0 2 38 37
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_8 loc_12_9 right box1
2
422 0
426 0
4
0 0 41 42
0 1 40 41
0 167 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_7 loc_12_8 loc_12_9 right box2
2
422 0
426 0
4
0 0 41 42
0 5 40 41
0 167 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_7 loc_12_8 loc_12_9 right box3
2
422 0
426 0
4
0 0 41 42
0 4 40 41
0 167 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_7 loc_12_8 loc_12_9 right box4
2
422 0
426 0
4
0 0 41 42
0 3 40 41
0 167 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_7 loc_12_8 loc_12_9 right box6
2
422 0
426 0
4
0 0 41 42
0 2 40 41
0 167 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box1
2
423 0
481 0
4
0 0 41 57
0 1 55 71
0 182 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box2
2
423 0
481 0
4
0 0 41 57
0 5 55 71
0 182 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box3
2
423 0
481 0
4
0 0 41 57
0 4 55 71
0 182 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box4
2
423 0
481 0
4
0 0 41 57
0 3 55 71
0 182 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box6
2
423 0
481 0
4
0 0 41 57
0 2 55 71
0 182 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_8 loc_12_7 loc_12_6 left box1
2
421 0
425 0
4
0 0 42 41
0 1 39 38
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_7 loc_12_6 left box2
2
421 0
425 0
4
0 0 42 41
0 5 39 38
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_7 loc_12_6 left box3
2
421 0
425 0
4
0 0 42 41
0 4 39 38
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_7 loc_12_6 left box4
2
421 0
425 0
4
0 0 42 41
0 3 39 38
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_7 loc_12_6 left box6
2
421 0
425 0
4
0 0 42 41
0 2 39 38
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_9 loc_12_10 right box1
2
426 0
429 0
4
0 0 42 43
0 1 41 26
0 152 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_9 loc_12_10 right box2
2
426 0
429 0
4
0 0 42 43
0 5 41 26
0 152 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_9 loc_12_10 right box3
2
426 0
429 0
4
0 0 42 43
0 4 41 26
0 152 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_9 loc_12_10 right box4
2
426 0
429 0
4
0 0 42 43
0 3 41 26
0 152 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_12_9 loc_12_10 right box6
2
426 0
429 0
4
0 0 42 43
0 2 41 26
0 152 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_12_8 loc_13_8 loc_14_8 down box1
2
427 0
485 0
4
0 0 42 58
0 1 56 72
0 183 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_8 loc_13_8 loc_14_8 down box2
2
427 0
485 0
4
0 0 42 58
0 5 56 72
0 183 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_8 loc_13_8 loc_14_8 down box3
2
427 0
485 0
4
0 0 42 58
0 4 56 72
0 183 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_8 loc_13_8 loc_14_8 down box4
2
427 0
485 0
4
0 0 42 58
0 3 56 72
0 183 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_8 loc_13_8 loc_14_8 down box6
2
427 0
485 0
4
0 0 42 58
0 2 56 72
0 183 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box1
2
367 0
428 0
4
0 0 43 27
0 1 25 7
0 120 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box2
2
367 0
428 0
4
0 0 43 27
0 5 25 7
0 120 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box3
2
367 0
428 0
4
0 0 43 27
0 4 25 7
0 120 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box4
2
367 0
428 0
4
0 0 43 27
0 3 25 7
0 120 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box6
2
367 0
428 0
4
0 0 43 27
0 2 25 7
0 120 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_12_10 loc_12_11 right box1
2
372 0
429 0
4
0 0 43 28
0 1 26 27
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_12_9 loc_12_10 loc_12_11 right box2
2
372 0
429 0
4
0 0 43 28
0 5 26 27
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_12_9 loc_12_10 loc_12_11 right box3
2
372 0
429 0
4
0 0 43 28
0 4 26 27
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_12_9 loc_12_10 loc_12_11 right box4
2
372 0
429 0
4
0 0 43 28
0 3 26 27
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_12_9 loc_12_10 loc_12_11 right box6
2
372 0
429 0
4
0 0 43 28
0 2 26 27
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_12_9 loc_12_8 loc_12_7 left box1
2
425 0
430 0
4
0 0 43 42
0 1 40 39
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_12_8 loc_12_7 left box2
2
425 0
430 0
4
0 0 43 42
0 5 40 39
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_12_8 loc_12_7 left box3
2
425 0
430 0
4
0 0 43 42
0 4 40 39
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_12_8 loc_12_7 left box4
2
425 0
430 0
4
0 0 43 42
0 3 40 39
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_12_8 loc_12_7 left box6
2
425 0
430 0
4
0 0 43 42
0 2 40 39
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_13_9 loc_14_9 down box1
2
431 0
489 0
4
0 0 43 59
0 1 57 73
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_12_9 loc_13_9 loc_14_9 down box2
2
431 0
489 0
4
0 0 43 59
0 5 57 73
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_12_9 loc_13_9 loc_14_9 down box3
2
431 0
489 0
4
0 0 43 59
0 4 57 73
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_12_9 loc_13_9 loc_14_9 down box4
2
431 0
489 0
4
0 0 43 59
0 3 57 73
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_12_9 loc_13_9 loc_14_9 down box6
2
431 0
489 0
4
0 0 43 59
0 2 57 73
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_13_10 loc_12_10 loc_11_10 up box1
2
371 0
432 0
4
0 0 44 28
0 1 26 8
0 122 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_12_10 loc_11_10 up box2
2
371 0
432 0
4
0 0 44 28
0 5 26 8
0 122 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_12_10 loc_11_10 up box3
2
371 0
432 0
4
0 0 44 28
0 4 26 8
0 122 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_12_10 loc_11_10 up box4
2
371 0
432 0
4
0 0 44 28
0 3 26 8
0 122 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_12_10 loc_11_10 up box6
2
371 0
432 0
4
0 0 44 28
0 2 26 8
0 122 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_13_11 loc_13_12 right box1
2
433 0
438 0
4
0 0 44 45
0 1 43 44
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_13_10 loc_13_11 loc_13_12 right box2
2
433 0
438 0
4
0 0 44 45
0 5 43 44
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_13_10 loc_13_11 loc_13_12 right box3
2
433 0
438 0
4
0 0 44 45
0 4 43 44
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_13_10 loc_13_11 loc_13_12 right box4
2
433 0
438 0
4
0 0 44 45
0 3 43 44
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_13_10 loc_13_11 loc_13_12 right box6
2
433 0
438 0
4
0 0 44 45
0 2 43 44
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_13_10 loc_13_9 loc_13_8 left box1
2
434 0
488 0
4
0 0 44 59
0 1 57 56
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_13_9 loc_13_8 left box2
2
434 0
488 0
4
0 0 44 59
0 5 57 56
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_13_9 loc_13_8 left box3
2
434 0
488 0
4
0 0 44 59
0 4 57 56
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_13_9 loc_13_8 left box4
2
434 0
488 0
4
0 0 44 59
0 3 57 56
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_13_9 loc_13_8 left box6
2
434 0
488 0
4
0 0 44 59
0 2 57 56
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box1
2
435 0
493 0
4
0 0 44 60
0 1 58 74
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box2
2
435 0
493 0
4
0 0 44 60
0 5 58 74
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box3
2
435 0
493 0
4
0 0 44 60
0 4 58 74
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box4
2
435 0
493 0
4
0 0 44 60
0 3 58 74
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box6
2
435 0
493 0
4
0 0 44 60
0 2 58 74
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box1
2
375 0
436 0
4
0 0 45 29
0 1 27 9
0 124 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box2
2
375 0
436 0
4
0 0 45 29
0 5 27 9
0 124 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box3
2
375 0
436 0
4
0 0 45 29
0 4 27 9
0 124 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box4
2
375 0
436 0
4
0 0 45 29
0 3 27 9
0 124 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box6
2
375 0
436 0
4
0 0 45 29
0 2 27 9
0 124 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_13_10 loc_13_9 left box1
2
434 0
437 0
4
0 0 45 44
0 1 42 57
0 169 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_10 loc_13_9 left box2
2
434 0
437 0
4
0 0 45 44
0 5 42 57
0 169 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_10 loc_13_9 left box3
2
434 0
437 0
4
0 0 45 44
0 4 42 57
0 169 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_10 loc_13_9 left box4
2
434 0
437 0
4
0 0 45 44
0 3 42 57
0 169 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_10 loc_13_9 left box6
2
434 0
437 0
4
0 0 45 44
0 2 42 57
0 169 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_12 loc_13_13 right box1
2
438 0
442 0
4
0 0 45 46
0 1 44 45
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_12 loc_13_13 right box2
2
438 0
442 0
4
0 0 45 46
0 5 44 45
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_12 loc_13_13 right box3
2
438 0
442 0
4
0 0 45 46
0 4 44 45
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_12 loc_13_13 right box4
2
438 0
442 0
4
0 0 45 46
0 3 44 45
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_13_11 loc_13_12 loc_13_13 right box6
2
438 0
442 0
4
0 0 45 46
0 2 44 45
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box1
2
439 0
497 0
4
0 0 45 61
0 1 59 75
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box2
2
439 0
497 0
4
0 0 45 61
0 5 59 75
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box3
2
439 0
497 0
4
0 0 45 61
0 4 59 75
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box4
2
439 0
497 0
4
0 0 45 61
0 3 59 75
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box6
2
439 0
497 0
4
0 0 45 61
0 2 59 75
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_13_12 loc_12_12 loc_11_12 up box1
2
379 0
440 0
4
0 0 46 30
0 1 28 10
0 126 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_12_12 loc_11_12 up box2
2
379 0
440 0
4
0 0 46 30
0 5 28 10
0 126 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_12_12 loc_11_12 up box3
2
379 0
440 0
4
0 0 46 30
0 4 28 10
0 126 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_12_12 loc_11_12 up box4
2
379 0
440 0
4
0 0 46 30
0 3 28 10
0 126 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_12_12 loc_11_12 up box6
2
379 0
440 0
4
0 0 46 30
0 2 28 10
0 126 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_11 loc_13_10 left box1
2
437 0
441 0
4
0 0 46 45
0 1 43 42
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_11 loc_13_10 left box2
2
437 0
441 0
4
0 0 46 45
0 5 43 42
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_11 loc_13_10 left box3
2
437 0
441 0
4
0 0 46 45
0 4 43 42
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_11 loc_13_10 left box4
2
437 0
441 0
4
0 0 46 45
0 3 43 42
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_11 loc_13_10 left box6
2
437 0
441 0
4
0 0 46 45
0 2 43 42
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_13_12 loc_13_13 loc_13_14 right box1
2
442 0
446 0
4
0 0 46 47
0 1 45 46
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_13_12 loc_13_13 loc_13_14 right box2
2
442 0
446 0
4
0 0 46 47
0 5 45 46
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_13_12 loc_13_13 loc_13_14 right box3
2
442 0
446 0
4
0 0 46 47
0 4 45 46
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_13_12 loc_13_13 loc_13_14 right box4
2
442 0
446 0
4
0 0 46 47
0 3 45 46
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_13_12 loc_13_13 loc_13_14 right box6
2
442 0
446 0
4
0 0 46 47
0 2 45 46
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_13_12 loc_14_12 loc_15_12 down box1
2
443 0
501 0
4
0 0 46 62
0 1 60 76
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_13_12 loc_14_12 loc_15_12 down box2
2
443 0
501 0
4
0 0 46 62
0 5 60 76
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_13_12 loc_14_12 loc_15_12 down box3
2
443 0
501 0
4
0 0 46 62
0 4 60 76
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_13_12 loc_14_12 loc_15_12 down box4
2
443 0
501 0
4
0 0 46 62
0 3 60 76
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_13_12 loc_14_12 loc_15_12 down box6
2
443 0
501 0
4
0 0 46 62
0 2 60 76
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box1
2
383 0
444 0
4
0 0 47 31
0 1 29 11
0 128 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box2
2
383 0
444 0
4
0 0 47 31
0 5 29 11
0 128 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box3
2
383 0
444 0
4
0 0 47 31
0 4 29 11
0 128 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box4
2
383 0
444 0
4
0 0 47 31
0 3 29 11
0 128 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box6
2
383 0
444 0
4
0 0 47 31
0 2 29 11
0 128 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_12 loc_13_11 left box1
2
441 0
445 0
4
0 0 47 46
0 1 44 43
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_12 loc_13_11 left box2
2
441 0
445 0
4
0 0 47 46
0 5 44 43
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_12 loc_13_11 left box3
2
441 0
445 0
4
0 0 47 46
0 4 44 43
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_12 loc_13_11 left box4
2
441 0
445 0
4
0 0 47 46
0 3 44 43
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_12 loc_13_11 left box6
2
441 0
445 0
4
0 0 47 46
0 2 44 43
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box1
2
446 0
450 0
4
0 0 47 48
0 1 46 47
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box2
2
446 0
450 0
4
0 0 47 48
0 5 46 47
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box3
2
446 0
450 0
4
0 0 47 48
0 4 46 47
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box4
2
446 0
450 0
4
0 0 47 48
0 3 46 47
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box6
2
446 0
450 0
4
0 0 47 48
0 2 46 47
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_13_13 loc_14_13 loc_15_13 down box1
2
447 0
505 0
4
0 0 47 63
0 1 61 77
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_13_13 loc_14_13 loc_15_13 down box2
2
447 0
505 0
4
0 0 47 63
0 5 61 77
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_13_13 loc_14_13 loc_15_13 down box3
2
447 0
505 0
4
0 0 47 63
0 4 61 77
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_13_13 loc_14_13 loc_15_13 down box4
2
447 0
505 0
4
0 0 47 63
0 3 61 77
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_13_13 loc_14_13 loc_15_13 down box6
2
447 0
505 0
4
0 0 47 63
0 2 61 77
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box1
2
387 0
448 0
4
0 0 48 32
0 1 30 12
0 130 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box2
2
387 0
448 0
4
0 0 48 32
0 5 30 12
0 130 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box3
2
387 0
448 0
4
0 0 48 32
0 4 30 12
0 130 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box4
2
387 0
448 0
4
0 0 48 32
0 3 30 12
0 130 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box6
2
387 0
448 0
4
0 0 48 32
0 2 30 12
0 130 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_13_13 loc_13_12 left box1
2
445 0
449 0
4
0 0 48 47
0 1 45 44
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_13_13 loc_13_12 left box2
2
445 0
449 0
4
0 0 48 47
0 5 45 44
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_13_13 loc_13_12 left box3
2
445 0
449 0
4
0 0 48 47
0 4 45 44
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_13_13 loc_13_12 left box4
2
445 0
449 0
4
0 0 48 47
0 3 45 44
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_13_13 loc_13_12 left box6
2
445 0
449 0
4
0 0 48 47
0 2 45 44
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_13_14 loc_14_14 loc_15_14 down box1
2
451 0
509 0
4
0 0 48 64
0 1 62 78
0 189 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_14 loc_14_14 loc_15_14 down box2
2
451 0
509 0
4
0 0 48 64
0 5 62 78
0 189 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_14 loc_14_14 loc_15_14 down box3
2
451 0
509 0
4
0 0 48 64
0 4 62 78
0 189 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_14 loc_14_14 loc_15_14 down box4
2
451 0
509 0
4
0 0 48 64
0 3 62 78
0 189 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_14 loc_14_14 loc_15_14 down box6
2
451 0
509 0
4
0 0 48 64
0 2 62 78
0 189 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box1
2
391 0
452 0
4
0 0 49 33
0 1 31 13
0 132 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box2
2
391 0
452 0
4
0 0 49 33
0 5 31 13
0 132 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box3
2
391 0
452 0
4
0 0 49 33
0 4 31 13
0 132 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box4
2
391 0
452 0
4
0 0 49 33
0 3 31 13
0 132 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box6
2
391 0
452 0
4
0 0 49 33
0 2 31 13
0 132 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box1
2
449 0
453 0
4
0 0 49 48
0 1 46 45
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box2
2
449 0
453 0
4
0 0 49 48
0 5 46 45
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box3
2
449 0
453 0
4
0 0 49 48
0 4 46 45
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box4
2
449 0
453 0
4
0 0 49 48
0 3 46 45
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box6
2
449 0
453 0
4
0 0 49 48
0 2 46 45
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_14_15 loc_15_15 down box1
2
454 0
513 0
4
0 0 49 65
0 1 63 79
0 190 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_15 loc_14_15 loc_15_15 down box2
2
454 0
513 0
4
0 0 49 65
0 5 63 79
0 190 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_15 loc_14_15 loc_15_15 down box3
2
454 0
513 0
4
0 0 49 65
0 4 63 79
0 190 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_15 loc_14_15 loc_15_15 down box4
2
454 0
513 0
4
0 0 49 65
0 3 63 79
0 190 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_15 loc_14_15 loc_15_15 down box6
2
454 0
513 0
4
0 0 49 65
0 2 63 79
0 190 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box1
2
398 0
455 0
4
0 0 50 35
0 1 33 15
0 136 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box2
2
398 0
455 0
4
0 0 50 35
0 5 33 15
0 136 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box3
2
398 0
455 0
4
0 0 50 35
0 4 33 15
0 136 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box4
2
398 0
455 0
4
0 0 50 35
0 3 33 15
0 136 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box6
2
398 0
455 0
4
0 0 50 35
0 2 33 15
0 136 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box1
2
456 0
460 0
4
0 0 50 51
0 1 49 50
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box2
2
456 0
460 0
4
0 0 50 51
0 5 49 50
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box3
2
456 0
460 0
4
0 0 50 51
0 4 49 50
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box4
2
456 0
460 0
4
0 0 50 51
0 3 49 50
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box6
2
456 0
460 0
4
0 0 50 51
0 2 49 50
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box1
2
457 0
520 0
4
0 0 50 67
0 1 65 81
0 192 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box2
2
457 0
520 0
4
0 0 50 67
0 5 65 81
0 192 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box3
2
457 0
520 0
4
0 0 50 67
0 4 65 81
0 192 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box4
2
457 0
520 0
4
0 0 50 67
0 3 65 81
0 192 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box6
2
457 0
520 0
4
0 0 50 67
0 2 65 81
0 192 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box1
2
402 0
458 0
4
0 0 51 36
0 1 34 16
0 138 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box2
2
402 0
458 0
4
0 0 51 36
0 5 34 16
0 138 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box3
2
402 0
458 0
4
0 0 51 36
0 4 34 16
0 138 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box4
2
402 0
458 0
4
0 0 51 36
0 3 34 16
0 138 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box6
2
402 0
458 0
4
0 0 51 36
0 2 34 16
0 138 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_13_19 loc_13_20 right box1
2
460 0
464 0
4
0 0 51 52
0 1 50 51
0 177 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_13_18 loc_13_19 loc_13_20 right box2
2
460 0
464 0
4
0 0 51 52
0 5 50 51
0 177 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_13_18 loc_13_19 loc_13_20 right box3
2
460 0
464 0
4
0 0 51 52
0 4 50 51
0 177 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_13_18 loc_13_19 loc_13_20 right box4
2
460 0
464 0
4
0 0 51 52
0 3 50 51
0 177 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_13_18 loc_13_19 loc_13_20 right box6
2
460 0
464 0
4
0 0 51 52
0 2 50 51
0 177 -1 0
0 178 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box1
2
461 0
524 0
4
0 0 51 68
0 1 66 82
0 193 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box2
2
461 0
524 0
4
0 0 51 68
0 5 66 82
0 193 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box3
2
461 0
524 0
4
0 0 51 68
0 4 66 82
0 193 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box4
2
461 0
524 0
4
0 0 51 68
0 3 66 82
0 193 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box6
2
461 0
524 0
4
0 0 51 68
0 2 66 82
0 193 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box1
2
406 0
462 0
4
0 0 52 37
0 1 35 17
0 140 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box2
2
406 0
462 0
4
0 0 52 37
0 5 35 17
0 140 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box3
2
406 0
462 0
4
0 0 52 37
0 4 35 17
0 140 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box4
2
406 0
462 0
4
0 0 52 37
0 3 35 17
0 140 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box6
2
406 0
462 0
4
0 0 52 37
0 2 35 17
0 140 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box1
2
459 0
463 0
4
0 0 52 51
0 1 49 48
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box2
2
459 0
463 0
4
0 0 52 51
0 5 49 48
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box3
2
459 0
463 0
4
0 0 52 51
0 4 49 48
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box4
2
459 0
463 0
4
0 0 52 51
0 3 49 48
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box6
2
459 0
463 0
4
0 0 52 51
0 2 49 48
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box1
2
464 0
468 0
4
0 0 52 53
0 1 51 52
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box2
2
464 0
468 0
4
0 0 52 53
0 5 51 52
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box3
2
464 0
468 0
4
0 0 52 53
0 4 51 52
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box4
2
464 0
468 0
4
0 0 52 53
0 3 51 52
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box5
2
464 0
468 0
4
0 0 52 53
0 7 2 3
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_13_20 loc_13_21 right box6
2
464 0
468 0
4
0 0 52 53
0 2 51 52
0 178 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box1
2
465 0
528 0
4
0 0 52 69
0 1 67 83
0 194 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box2
2
465 0
528 0
4
0 0 52 69
0 5 67 83
0 194 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box3
2
465 0
528 0
4
0 0 52 69
0 4 67 83
0 194 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box4
2
465 0
528 0
4
0 0 52 69
0 3 67 83
0 194 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box6
2
465 0
528 0
4
0 0 52 69
0 2 67 83
0 194 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box1
2
410 0
466 0
4
0 0 53 38
0 1 36 18
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box2
2
410 0
466 0
4
0 0 53 38
0 5 36 18
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box3
2
410 0
466 0
4
0 0 53 38
0 4 36 18
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box4
2
410 0
466 0
4
0 0 53 38
0 3 36 18
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box5
2
410 0
466 0
4
0 0 53 38
0 7 1 0
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_12_20 loc_11_20 up box6
2
410 0
466 0
4
0 0 53 38
0 2 36 18
0 142 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_13_19 loc_13_18 left box1
2
463 0
467 0
4
0 0 53 52
0 1 50 49
0 176 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_13_19 loc_13_18 left box2
2
463 0
467 0
4
0 0 53 52
0 5 50 49
0 176 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_13_19 loc_13_18 left box3
2
463 0
467 0
4
0 0 53 52
0 4 50 49
0 176 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_13_19 loc_13_18 left box4
2
463 0
467 0
4
0 0 53 52
0 3 50 49
0 176 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_13_19 loc_13_18 left box6
2
463 0
467 0
4
0 0 53 52
0 2 50 49
0 176 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box1
2
469 0
533 0
4
0 0 53 70
0 1 68 84
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box2
2
469 0
533 0
4
0 0 53 70
0 5 68 84
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box3
2
469 0
533 0
4
0 0 53 70
0 4 68 84
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box4
2
469 0
533 0
4
0 0 53 70
0 3 68 84
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box5
2
469 0
533 0
4
0 0 53 70
0 7 4 5
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_20 loc_14_20 loc_15_20 down box6
2
469 0
533 0
4
0 0 53 70
0 2 68 84
0 196 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box1
2
413 0
471 0
4
0 0 55 39
0 1 37 21
0 147 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box2
2
413 0
471 0
4
0 0 55 39
0 5 37 21
0 147 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box3
2
413 0
471 0
4
0 0 55 39
0 4 37 21
0 147 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box4
2
413 0
471 0
4
0 0 55 39
0 3 37 21
0 147 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box6
2
413 0
471 0
4
0 0 55 39
0 2 37 21
0 147 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box1
2
472 0
476 0
4
0 0 55 56
0 1 54 55
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box2
2
472 0
476 0
4
0 0 55 56
0 5 54 55
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box3
2
472 0
476 0
4
0 0 55 56
0 4 54 55
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box4
2
472 0
476 0
4
0 0 55 56
0 3 54 55
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box6
2
472 0
476 0
4
0 0 55 56
0 2 54 55
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box1
2
473 0
538 0
4
0 0 55 71
0 1 69 86
0 198 -1 0
0 217 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box2
2
473 0
538 0
4
0 0 55 71
0 5 69 86
0 198 -1 0
0 217 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box3
2
473 0
538 0
4
0 0 55 71
0 4 69 86
0 198 -1 0
0 217 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box4
2
473 0
538 0
4
0 0 55 71
0 3 69 86
0 198 -1 0
0 217 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box6
2
473 0
538 0
4
0 0 55 71
0 2 69 86
0 198 -1 0
0 217 0 1
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box1
2
416 0
474 0
4
0 0 56 40
0 1 38 22
0 148 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box2
2
416 0
474 0
4
0 0 56 40
0 5 38 22
0 148 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box3
2
416 0
474 0
4
0 0 56 40
0 4 38 22
0 148 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box4
2
416 0
474 0
4
0 0 56 40
0 3 38 22
0 148 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box6
2
416 0
474 0
4
0 0 56 40
0 2 38 22
0 148 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box1
2
476 0
480 0
4
0 0 56 57
0 1 55 56
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box2
2
476 0
480 0
4
0 0 56 57
0 5 55 56
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box3
2
476 0
480 0
4
0 0 56 57
0 4 55 56
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box4
2
476 0
480 0
4
0 0 56 57
0 3 55 56
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box6
2
476 0
480 0
4
0 0 56 57
0 2 55 56
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box1
2
477 0
542 0
4
0 0 56 72
0 1 70 87
0 199 -1 0
0 218 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box2
2
477 0
542 0
4
0 0 56 72
0 5 70 87
0 199 -1 0
0 218 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box3
2
477 0
542 0
4
0 0 56 72
0 4 70 87
0 199 -1 0
0 218 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box4
2
477 0
542 0
4
0 0 56 72
0 3 70 87
0 199 -1 0
0 218 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box6
2
477 0
542 0
4
0 0 56 72
0 2 70 87
0 199 -1 0
0 218 0 1
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box1
2
420 0
478 0
4
0 0 57 41
0 1 39 23
0 149 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box2
2
420 0
478 0
4
0 0 57 41
0 5 39 23
0 149 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box3
2
420 0
478 0
4
0 0 57 41
0 4 39 23
0 149 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box4
2
420 0
478 0
4
0 0 57 41
0 3 39 23
0 149 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box6
2
420 0
478 0
4
0 0 57 41
0 2 39 23
0 149 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box1
2
475 0
479 0
4
0 0 57 56
0 1 54 53
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box2
2
475 0
479 0
4
0 0 57 56
0 5 54 53
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box3
2
475 0
479 0
4
0 0 57 56
0 4 54 53
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box4
2
475 0
479 0
4
0 0 57 56
0 3 54 53
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box6
2
475 0
479 0
4
0 0 57 56
0 2 54 53
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_8 loc_13_9 right box1
2
480 0
484 0
4
0 0 57 58
0 1 56 57
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_7 loc_13_8 loc_13_9 right box2
2
480 0
484 0
4
0 0 57 58
0 5 56 57
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_7 loc_13_8 loc_13_9 right box3
2
480 0
484 0
4
0 0 57 58
0 4 56 57
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_7 loc_13_8 loc_13_9 right box4
2
480 0
484 0
4
0 0 57 58
0 3 56 57
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_7 loc_13_8 loc_13_9 right box6
2
480 0
484 0
4
0 0 57 58
0 2 56 57
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box1
2
481 0
546 0
4
0 0 57 73
0 1 71 88
0 200 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box2
2
481 0
546 0
4
0 0 57 73
0 5 71 88
0 200 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box3
2
481 0
546 0
4
0 0 57 73
0 4 71 88
0 200 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box4
2
481 0
546 0
4
0 0 57 73
0 3 71 88
0 200 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box6
2
481 0
546 0
4
0 0 57 73
0 2 71 88
0 200 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box1
2
424 0
482 0
4
0 0 58 42
0 1 40 24
0 150 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box2
2
424 0
482 0
4
0 0 58 42
0 5 40 24
0 150 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box3
2
424 0
482 0
4
0 0 58 42
0 4 40 24
0 150 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box4
2
424 0
482 0
4
0 0 58 42
0 3 40 24
0 150 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box6
2
424 0
482 0
4
0 0 58 42
0 2 40 24
0 150 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box1
2
479 0
483 0
4
0 0 58 57
0 1 55 54
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box2
2
479 0
483 0
4
0 0 58 57
0 5 55 54
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box3
2
479 0
483 0
4
0 0 58 57
0 4 55 54
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box4
2
479 0
483 0
4
0 0 58 57
0 3 55 54
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box6
2
479 0
483 0
4
0 0 58 57
0 2 55 54
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_9 loc_13_10 right box1
2
484 0
487 0
4
0 0 58 59
0 1 57 42
0 169 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_9 loc_13_10 right box2
2
484 0
487 0
4
0 0 58 59
0 5 57 42
0 169 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_9 loc_13_10 right box3
2
484 0
487 0
4
0 0 58 59
0 4 57 42
0 169 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_9 loc_13_10 right box4
2
484 0
487 0
4
0 0 58 59
0 3 57 42
0 169 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_9 loc_13_10 right box6
2
484 0
487 0
4
0 0 58 59
0 2 57 42
0 169 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_14_8 loc_15_8 down box1
2
485 0
550 0
4
0 0 58 74
0 1 72 89
0 201 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_13_8 loc_14_8 loc_15_8 down box2
2
485 0
550 0
4
0 0 58 74
0 5 72 89
0 201 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_13_8 loc_14_8 loc_15_8 down box3
2
485 0
550 0
4
0 0 58 74
0 4 72 89
0 201 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_13_8 loc_14_8 loc_15_8 down box4
2
485 0
550 0
4
0 0 58 74
0 3 72 89
0 201 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_13_8 loc_14_8 loc_15_8 down box6
2
485 0
550 0
4
0 0 58 74
0 2 72 89
0 201 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_13_9 loc_12_9 loc_11_9 up box1
2
428 0
486 0
4
0 0 59 43
0 1 41 25
0 151 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_12_9 loc_11_9 up box2
2
428 0
486 0
4
0 0 59 43
0 5 41 25
0 151 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_12_9 loc_11_9 up box3
2
428 0
486 0
4
0 0 59 43
0 4 41 25
0 151 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_12_9 loc_11_9 up box4
2
428 0
486 0
4
0 0 59 43
0 3 41 25
0 151 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_12_9 loc_11_9 up box6
2
428 0
486 0
4
0 0 59 43
0 2 41 25
0 151 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_13_10 loc_13_11 right box1
2
433 0
487 0
4
0 0 59 44
0 1 42 43
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_13_9 loc_13_10 loc_13_11 right box2
2
433 0
487 0
4
0 0 59 44
0 5 42 43
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_13_9 loc_13_10 loc_13_11 right box3
2
433 0
487 0
4
0 0 59 44
0 4 42 43
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_13_9 loc_13_10 loc_13_11 right box4
2
433 0
487 0
4
0 0 59 44
0 3 42 43
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_13_9 loc_13_10 loc_13_11 right box6
2
433 0
487 0
4
0 0 59 44
0 2 42 43
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_13_9 loc_13_8 loc_13_7 left box1
2
483 0
488 0
4
0 0 59 58
0 1 56 55
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_13_8 loc_13_7 left box2
2
483 0
488 0
4
0 0 59 58
0 5 56 55
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_13_8 loc_13_7 left box3
2
483 0
488 0
4
0 0 59 58
0 4 56 55
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_13_8 loc_13_7 left box4
2
483 0
488 0
4
0 0 59 58
0 3 56 55
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_13_8 loc_13_7 left box6
2
483 0
488 0
4
0 0 59 58
0 2 56 55
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_13_9 loc_14_9 loc_15_9 down box1
2
489 0
554 0
4
0 0 59 75
0 1 73 90
0 202 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_13_9 loc_14_9 loc_15_9 down box2
2
489 0
554 0
4
0 0 59 75
0 5 73 90
0 202 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_13_9 loc_14_9 loc_15_9 down box3
2
489 0
554 0
4
0 0 59 75
0 4 73 90
0 202 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_13_9 loc_14_9 loc_15_9 down box4
2
489 0
554 0
4
0 0 59 75
0 3 73 90
0 202 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_13_9 loc_14_9 loc_15_9 down box6
2
489 0
554 0
4
0 0 59 75
0 2 73 90
0 202 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_14_10 loc_13_10 loc_12_10 up box1
2
432 0
490 0
4
0 0 60 44
0 1 42 26
0 152 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_13_10 loc_12_10 up box2
2
432 0
490 0
4
0 0 60 44
0 5 42 26
0 152 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_13_10 loc_12_10 up box3
2
432 0
490 0
4
0 0 60 44
0 4 42 26
0 152 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_13_10 loc_12_10 up box4
2
432 0
490 0
4
0 0 60 44
0 3 42 26
0 152 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_13_10 loc_12_10 up box6
2
432 0
490 0
4
0 0 60 44
0 2 42 26
0 152 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box1
2
491 0
496 0
4
0 0 60 61
0 1 59 60
0 186 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box2
2
491 0
496 0
4
0 0 60 61
0 5 59 60
0 186 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box3
2
491 0
496 0
4
0 0 60 61
0 4 59 60
0 186 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box4
2
491 0
496 0
4
0 0 60 61
0 3 59 60
0 186 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box6
2
491 0
496 0
4
0 0 60 61
0 2 59 60
0 186 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box1
2
492 0
553 0
4
0 0 60 75
0 1 73 72
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box2
2
492 0
553 0
4
0 0 60 75
0 5 73 72
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box3
2
492 0
553 0
4
0 0 60 75
0 4 73 72
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box4
2
492 0
553 0
4
0 0 60 75
0 3 73 72
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box6
2
492 0
553 0
4
0 0 60 75
0 2 73 72
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box1
2
493 0
558 0
4
0 0 60 76
0 1 74 91
0 203 -1 0
0 222 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box2
2
493 0
558 0
4
0 0 60 76
0 5 74 91
0 203 -1 0
0 222 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box3
2
493 0
558 0
4
0 0 60 76
0 4 74 91
0 203 -1 0
0 222 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box4
2
493 0
558 0
4
0 0 60 76
0 3 74 91
0 203 -1 0
0 222 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box6
2
493 0
558 0
4
0 0 60 76
0 2 74 91
0 203 -1 0
0 222 0 1
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box1
2
436 0
494 0
4
0 0 61 45
0 1 43 27
0 153 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box2
2
436 0
494 0
4
0 0 61 45
0 5 43 27
0 153 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box3
2
436 0
494 0
4
0 0 61 45
0 4 43 27
0 153 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box4
2
436 0
494 0
4
0 0 61 45
0 3 43 27
0 153 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box6
2
436 0
494 0
4
0 0 61 45
0 2 43 27
0 153 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box1
2
492 0
495 0
4
0 0 61 60
0 1 58 73
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box2
2
492 0
495 0
4
0 0 61 60
0 5 58 73
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box3
2
492 0
495 0
4
0 0 61 60
0 4 58 73
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box4
2
492 0
495 0
4
0 0 61 60
0 3 58 73
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box6
2
492 0
495 0
4
0 0 61 60
0 2 58 73
0 185 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_12 loc_14_13 right box1
2
496 0
500 0
4
0 0 61 62
0 1 60 61
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_12 loc_14_13 right box2
2
496 0
500 0
4
0 0 61 62
0 5 60 61
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_12 loc_14_13 right box3
2
496 0
500 0
4
0 0 61 62
0 4 60 61
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_12 loc_14_13 right box4
2
496 0
500 0
4
0 0 61 62
0 3 60 61
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_12 loc_14_13 right box6
2
496 0
500 0
4
0 0 61 62
0 2 60 61
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_14_12 loc_13_12 loc_12_12 up box1
2
440 0
498 0
4
0 0 62 46
0 1 44 28
0 154 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_13_12 loc_12_12 up box2
2
440 0
498 0
4
0 0 62 46
0 5 44 28
0 154 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_13_12 loc_12_12 up box3
2
440 0
498 0
4
0 0 62 46
0 4 44 28
0 154 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_13_12 loc_12_12 up box4
2
440 0
498 0
4
0 0 62 46
0 3 44 28
0 154 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_13_12 loc_12_12 up box6
2
440 0
498 0
4
0 0 62 46
0 2 44 28
0 154 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box1
2
495 0
499 0
4
0 0 62 61
0 1 59 58
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box2
2
495 0
499 0
4
0 0 62 61
0 5 59 58
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box3
2
495 0
499 0
4
0 0 62 61
0 4 59 58
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box4
2
495 0
499 0
4
0 0 62 61
0 3 59 58
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box6
2
495 0
499 0
4
0 0 62 61
0 2 59 58
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_13 loc_14_14 right box1
2
500 0
504 0
4
0 0 62 63
0 1 61 62
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_14_12 loc_14_13 loc_14_14 right box2
2
500 0
504 0
4
0 0 62 63
0 5 61 62
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_14_12 loc_14_13 loc_14_14 right box3
2
500 0
504 0
4
0 0 62 63
0 4 61 62
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_14_12 loc_14_13 loc_14_14 right box4
2
500 0
504 0
4
0 0 62 63
0 3 61 62
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_14_12 loc_14_13 loc_14_14 right box6
2
500 0
504 0
4
0 0 62 63
0 2 61 62
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box1
2
444 0
502 0
4
0 0 63 47
0 1 45 29
0 155 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box2
2
444 0
502 0
4
0 0 63 47
0 5 45 29
0 155 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box3
2
444 0
502 0
4
0 0 63 47
0 4 45 29
0 155 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box4
2
444 0
502 0
4
0 0 63 47
0 3 45 29
0 155 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box6
2
444 0
502 0
4
0 0 63 47
0 2 45 29
0 155 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_12 loc_14_11 left box1
2
499 0
503 0
4
0 0 63 62
0 1 60 59
0 186 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_12 loc_14_11 left box2
2
499 0
503 0
4
0 0 63 62
0 5 60 59
0 186 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_12 loc_14_11 left box3
2
499 0
503 0
4
0 0 63 62
0 4 60 59
0 186 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_12 loc_14_11 left box4
2
499 0
503 0
4
0 0 63 62
0 3 60 59
0 186 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_12 loc_14_11 left box6
2
499 0
503 0
4
0 0 63 62
0 2 60 59
0 186 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_14_14 loc_14_15 right box1
2
504 0
508 0
4
0 0 63 64
0 1 62 63
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_14_13 loc_14_14 loc_14_15 right box2
2
504 0
508 0
4
0 0 63 64
0 5 62 63
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_14_13 loc_14_14 loc_14_15 right box3
2
504 0
508 0
4
0 0 63 64
0 4 62 63
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_14_13 loc_14_14 loc_14_15 right box4
2
504 0
508 0
4
0 0 63 64
0 3 62 63
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_14_13 loc_14_14 loc_14_15 right box6
2
504 0
508 0
4
0 0 63 64
0 2 62 63
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_14_13 loc_15_13 loc_16_13 down box1
2
505 0
568 0
4
0 0 63 79
0 1 77 92
0 206 -1 0
0 223 0 1
1
end_operator
begin_operator
push loc_14_13 loc_15_13 loc_16_13 down box2
2
505 0
568 0
4
0 0 63 79
0 5 77 92
0 206 -1 0
0 223 0 1
1
end_operator
begin_operator
push loc_14_13 loc_15_13 loc_16_13 down box3
2
505 0
568 0
4
0 0 63 79
0 4 77 92
0 206 -1 0
0 223 0 1
1
end_operator
begin_operator
push loc_14_13 loc_15_13 loc_16_13 down box4
2
505 0
568 0
4
0 0 63 79
0 3 77 92
0 206 -1 0
0 223 0 1
1
end_operator
begin_operator
push loc_14_13 loc_15_13 loc_16_13 down box6
2
505 0
568 0
4
0 0 63 79
0 2 77 92
0 206 -1 0
0 223 0 1
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box1
2
448 0
506 0
4
0 0 64 48
0 1 46 30
0 156 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box2
2
448 0
506 0
4
0 0 64 48
0 5 46 30
0 156 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box3
2
448 0
506 0
4
0 0 64 48
0 4 46 30
0 156 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box4
2
448 0
506 0
4
0 0 64 48
0 3 46 30
0 156 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box6
2
448 0
506 0
4
0 0 64 48
0 2 46 30
0 156 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_13 loc_14_12 left box1
2
503 0
507 0
4
0 0 64 63
0 1 61 60
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_13 loc_14_12 left box2
2
503 0
507 0
4
0 0 64 63
0 5 61 60
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_13 loc_14_12 left box3
2
503 0
507 0
4
0 0 64 63
0 4 61 60
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_13 loc_14_12 left box4
2
503 0
507 0
4
0 0 64 63
0 3 61 60
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_13 loc_14_12 left box6
2
503 0
507 0
4
0 0 64 63
0 2 61 60
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_14_15 loc_14_16 right box1
2
508 0
512 0
4
0 0 64 65
0 1 63 64
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_14_14 loc_14_15 loc_14_16 right box2
2
508 0
512 0
4
0 0 64 65
0 5 63 64
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_14_14 loc_14_15 loc_14_16 right box3
2
508 0
512 0
4
0 0 64 65
0 4 63 64
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_14_14 loc_14_15 loc_14_16 right box4
2
508 0
512 0
4
0 0 64 65
0 3 63 64
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_14_14 loc_14_15 loc_14_16 right box6
2
508 0
512 0
4
0 0 64 65
0 2 63 64
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_14_14 loc_15_14 loc_16_14 down box1
2
509 0
572 0
4
0 0 64 80
0 1 78 93
0 207 -1 0
0 224 0 1
1
end_operator
begin_operator
push loc_14_14 loc_15_14 loc_16_14 down box2
2
509 0
572 0
4
0 0 64 80
0 5 78 93
0 207 -1 0
0 224 0 1
1
end_operator
begin_operator
push loc_14_14 loc_15_14 loc_16_14 down box3
2
509 0
572 0
4
0 0 64 80
0 4 78 93
0 207 -1 0
0 224 0 1
1
end_operator
begin_operator
push loc_14_14 loc_15_14 loc_16_14 down box4
2
509 0
572 0
4
0 0 64 80
0 3 78 93
0 207 -1 0
0 224 0 1
1
end_operator
begin_operator
push loc_14_14 loc_15_14 loc_16_14 down box6
2
509 0
572 0
4
0 0 64 80
0 2 78 93
0 207 -1 0
0 224 0 1
1
end_operator
begin_operator
push loc_14_15 loc_13_15 loc_12_15 up box1
2
452 0
510 0
4
0 0 65 49
0 1 47 31
0 157 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_13_15 loc_12_15 up box2
2
452 0
510 0
4
0 0 65 49
0 5 47 31
0 157 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_13_15 loc_12_15 up box3
2
452 0
510 0
4
0 0 65 49
0 4 47 31
0 157 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_13_15 loc_12_15 up box4
2
452 0
510 0
4
0 0 65 49
0 3 47 31
0 157 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_13_15 loc_12_15 up box6
2
452 0
510 0
4
0 0 65 49
0 2 47 31
0 157 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_14 loc_14_13 left box1
2
507 0
511 0
4
0 0 65 64
0 1 62 61
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_14 loc_14_13 left box2
2
507 0
511 0
4
0 0 65 64
0 5 62 61
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_14 loc_14_13 left box3
2
507 0
511 0
4
0 0 65 64
0 4 62 61
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_14 loc_14_13 left box4
2
507 0
511 0
4
0 0 65 64
0 3 62 61
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_14 loc_14_13 left box6
2
507 0
511 0
4
0 0 65 64
0 2 62 61
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_14_15 loc_14_16 loc_14_17 right box1
2
512 0
515 0
4
0 0 65 66
0 1 64 65
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_14_15 loc_14_16 loc_14_17 right box2
2
512 0
515 0
4
0 0 65 66
0 5 64 65
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_14_15 loc_14_16 loc_14_17 right box3
2
512 0
515 0
4
0 0 65 66
0 4 64 65
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_14_15 loc_14_16 loc_14_17 right box4
2
512 0
515 0
4
0 0 65 66
0 3 64 65
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_14_15 loc_14_16 loc_14_17 right box6
2
512 0
515 0
4
0 0 65 66
0 2 64 65
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_14_16 loc_14_15 loc_14_14 left box1
2
511 0
514 0
4
0 0 66 65
0 1 63 62
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_14_15 loc_14_14 left box2
2
511 0
514 0
4
0 0 66 65
0 5 63 62
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_14_15 loc_14_14 left box3
2
511 0
514 0
4
0 0 66 65
0 4 63 62
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_14_15 loc_14_14 left box4
2
511 0
514 0
4
0 0 66 65
0 3 63 62
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_14_15 loc_14_14 left box6
2
511 0
514 0
4
0 0 66 65
0 2 63 62
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_14_17 loc_14_18 right box1
2
515 0
519 0
4
0 0 66 67
0 1 65 66
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_14_16 loc_14_17 loc_14_18 right box2
2
515 0
519 0
4
0 0 66 67
0 5 65 66
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_14_16 loc_14_17 loc_14_18 right box3
2
515 0
519 0
4
0 0 66 67
0 4 65 66
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_14_16 loc_14_17 loc_14_18 right box4
2
515 0
519 0
4
0 0 66 67
0 3 65 66
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_14_16 loc_14_17 loc_14_18 right box6
2
515 0
519 0
4
0 0 66 67
0 2 65 66
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box1
2
455 0
517 0
4
0 0 67 50
0 1 48 33
0 159 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box2
2
455 0
517 0
4
0 0 67 50
0 5 48 33
0 159 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box3
2
455 0
517 0
4
0 0 67 50
0 4 48 33
0 159 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box4
2
455 0
517 0
4
0 0 67 50
0 3 48 33
0 159 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box6
2
455 0
517 0
4
0 0 67 50
0 2 48 33
0 159 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_16 loc_14_15 left box1
2
514 0
518 0
4
0 0 67 66
0 1 64 63
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_16 loc_14_15 left box2
2
514 0
518 0
4
0 0 67 66
0 5 64 63
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_16 loc_14_15 left box3
2
514 0
518 0
4
0 0 67 66
0 4 64 63
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_16 loc_14_15 left box4
2
514 0
518 0
4
0 0 67 66
0 3 64 63
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_16 loc_14_15 left box6
2
514 0
518 0
4
0 0 67 66
0 2 64 63
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box1
2
519 0
523 0
4
0 0 67 68
0 1 66 67
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box2
2
519 0
523 0
4
0 0 67 68
0 5 66 67
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box3
2
519 0
523 0
4
0 0 67 68
0 4 66 67
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box4
2
519 0
523 0
4
0 0 67 68
0 3 66 67
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box6
2
519 0
523 0
4
0 0 67 68
0 2 66 67
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box1
2
458 0
521 0
4
0 0 68 51
0 1 49 34
0 160 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box2
2
458 0
521 0
4
0 0 68 51
0 5 49 34
0 160 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box3
2
458 0
521 0
4
0 0 68 51
0 4 49 34
0 160 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box4
2
458 0
521 0
4
0 0 68 51
0 3 49 34
0 160 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box6
2
458 0
521 0
4
0 0 68 51
0 2 49 34
0 160 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_17 loc_14_16 left box1
2
518 0
522 0
4
0 0 68 67
0 1 65 64
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_17 loc_14_16 left box2
2
518 0
522 0
4
0 0 68 67
0 5 65 64
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_17 loc_14_16 left box3
2
518 0
522 0
4
0 0 68 67
0 4 65 64
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_17 loc_14_16 left box4
2
518 0
522 0
4
0 0 68 67
0 3 65 64
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_17 loc_14_16 left box6
2
518 0
522 0
4
0 0 68 67
0 2 65 64
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_14_19 loc_14_20 right box1
2
523 0
527 0
4
0 0 68 69
0 1 67 68
0 194 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_14_18 loc_14_19 loc_14_20 right box2
2
523 0
527 0
4
0 0 68 69
0 5 67 68
0 194 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_14_18 loc_14_19 loc_14_20 right box3
2
523 0
527 0
4
0 0 68 69
0 4 67 68
0 194 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_14_18 loc_14_19 loc_14_20 right box4
2
523 0
527 0
4
0 0 68 69
0 3 67 68
0 194 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_14_18 loc_14_19 loc_14_20 right box6
2
523 0
527 0
4
0 0 68 69
0 2 67 68
0 194 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box1
2
462 0
525 0
4
0 0 69 52
0 1 50 35
0 161 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box2
2
462 0
525 0
4
0 0 69 52
0 5 50 35
0 161 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box3
2
462 0
525 0
4
0 0 69 52
0 4 50 35
0 161 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box4
2
462 0
525 0
4
0 0 69 52
0 3 50 35
0 161 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box6
2
462 0
525 0
4
0 0 69 52
0 2 50 35
0 161 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box1
2
522 0
526 0
4
0 0 69 68
0 1 66 65
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box2
2
522 0
526 0
4
0 0 69 68
0 5 66 65
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box3
2
522 0
526 0
4
0 0 69 68
0 4 66 65
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box4
2
522 0
526 0
4
0 0 69 68
0 3 66 65
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box6
2
522 0
526 0
4
0 0 69 68
0 2 66 65
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box1
2
528 0
588 0
4
0 0 69 85
0 1 83 94
0 212 -1 0
0 225 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box2
2
528 0
588 0
4
0 0 69 85
0 5 83 94
0 212 -1 0
0 225 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box3
2
528 0
588 0
4
0 0 69 85
0 4 83 94
0 212 -1 0
0 225 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box4
2
528 0
588 0
4
0 0 69 85
0 3 83 94
0 212 -1 0
0 225 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box6
2
528 0
588 0
4
0 0 69 85
0 2 83 94
0 212 -1 0
0 225 0 1
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box1
2
466 0
531 0
4
0 0 70 53
0 1 51 36
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box2
2
466 0
531 0
4
0 0 70 53
0 5 51 36
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box3
2
466 0
531 0
4
0 0 70 53
0 4 51 36
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box4
2
466 0
531 0
4
0 0 70 53
0 3 51 36
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box5
2
466 0
531 0
4
0 0 70 53
0 7 2 1
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_13_20 loc_12_20 up box6
2
466 0
531 0
4
0 0 70 53
0 2 51 36
0 163 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_14_19 loc_14_18 left box1
2
526 0
532 0
4
0 0 70 69
0 1 67 66
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_14_19 loc_14_18 left box2
2
526 0
532 0
4
0 0 70 69
0 5 67 66
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_14_19 loc_14_18 left box3
2
526 0
532 0
4
0 0 70 69
0 4 67 66
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_14_19 loc_14_18 left box4
2
526 0
532 0
4
0 0 70 69
0 3 67 66
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_14_19 loc_14_18 left box6
2
526 0
532 0
4
0 0 70 69
0 2 67 66
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box1
2
533 0
595 0
4
0 0 70 86
0 1 84 95
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box2
2
533 0
595 0
4
0 0 70 86
0 5 84 95
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box3
2
533 0
595 0
4
0 0 70 86
0 4 84 95
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box4
2
533 0
595 0
4
0 0 70 86
0 3 84 95
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box5
2
533 0
595 0
4
0 0 70 86
0 7 5 7
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_20 loc_15_20 loc_16_20 down box6
2
533 0
595 0
4
0 0 70 86
0 2 84 95
0 214 -1 0
0 227 0 1
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box1
2
471 0
536 0
4
0 0 71 55
0 1 53 37
0 164 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box2
2
471 0
536 0
4
0 0 71 55
0 5 53 37
0 164 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box3
2
471 0
536 0
4
0 0 71 55
0 4 53 37
0 164 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box4
2
471 0
536 0
4
0 0 71 55
0 3 53 37
0 164 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box6
2
471 0
536 0
4
0 0 71 55
0 2 53 37
0 164 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box1
2
537 0
541 0
4
0 0 71 72
0 1 70 71
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box2
2
537 0
541 0
4
0 0 71 72
0 5 70 71
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box3
2
537 0
541 0
4
0 0 71 72
0 4 70 71
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box4
2
537 0
541 0
4
0 0 71 72
0 3 70 71
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box6
2
537 0
541 0
4
0 0 71 72
0 2 70 71
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box1
2
538 0
602 0
4
0 0 71 88
0 1 86 96
0 217 -1 0
0 229 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box2
2
538 0
602 0
4
0 0 71 88
0 5 86 96
0 217 -1 0
0 229 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box3
2
538 0
602 0
4
0 0 71 88
0 4 86 96
0 217 -1 0
0 229 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box4
2
538 0
602 0
4
0 0 71 88
0 3 86 96
0 217 -1 0
0 229 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box6
2
538 0
602 0
4
0 0 71 88
0 2 86 96
0 217 -1 0
0 229 0 1
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box1
2
474 0
539 0
4
0 0 72 56
0 1 54 38
0 165 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box2
2
474 0
539 0
4
0 0 72 56
0 5 54 38
0 165 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box3
2
474 0
539 0
4
0 0 72 56
0 4 54 38
0 165 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box4
2
474 0
539 0
4
0 0 72 56
0 3 54 38
0 165 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box6
2
474 0
539 0
4
0 0 72 56
0 2 54 38
0 165 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box1
2
541 0
545 0
4
0 0 72 73
0 1 71 72
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box2
2
541 0
545 0
4
0 0 72 73
0 5 71 72
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box3
2
541 0
545 0
4
0 0 72 73
0 4 71 72
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box4
2
541 0
545 0
4
0 0 72 73
0 3 71 72
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box6
2
541 0
545 0
4
0 0 72 73
0 2 71 72
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box1
2
542 0
606 0
4
0 0 72 89
0 1 87 97
0 218 -1 0
0 230 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box2
2
542 0
606 0
4
0 0 72 89
0 5 87 97
0 218 -1 0
0 230 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box3
2
542 0
606 0
4
0 0 72 89
0 4 87 97
0 218 -1 0
0 230 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box4
2
542 0
606 0
4
0 0 72 89
0 3 87 97
0 218 -1 0
0 230 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box6
2
542 0
606 0
4
0 0 72 89
0 2 87 97
0 218 -1 0
0 230 0 1
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box1
2
478 0
543 0
4
0 0 73 57
0 1 55 39
0 166 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box2
2
478 0
543 0
4
0 0 73 57
0 5 55 39
0 166 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box3
2
478 0
543 0
4
0 0 73 57
0 4 55 39
0 166 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box4
2
478 0
543 0
4
0 0 73 57
0 3 55 39
0 166 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box6
2
478 0
543 0
4
0 0 73 57
0 2 55 39
0 166 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box1
2
540 0
544 0
4
0 0 73 72
0 1 70 69
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box2
2
540 0
544 0
4
0 0 73 72
0 5 70 69
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box3
2
540 0
544 0
4
0 0 73 72
0 4 70 69
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box4
2
540 0
544 0
4
0 0 73 72
0 3 70 69
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box6
2
540 0
544 0
4
0 0 73 72
0 2 70 69
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box1
2
545 0
549 0
4
0 0 73 74
0 1 72 73
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box2
2
545 0
549 0
4
0 0 73 74
0 5 72 73
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box3
2
545 0
549 0
4
0 0 73 74
0 4 72 73
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box4
2
545 0
549 0
4
0 0 73 74
0 3 72 73
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box6
2
545 0
549 0
4
0 0 73 74
0 2 72 73
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_14_7 loc_15_7 loc_16_7 down box1
2
546 0
610 0
4
0 0 73 90
0 1 88 98
0 219 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_14_7 loc_15_7 loc_16_7 down box2
2
546 0
610 0
4
0 0 73 90
0 5 88 98
0 219 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_14_7 loc_15_7 loc_16_7 down box3
2
546 0
610 0
4
0 0 73 90
0 4 88 98
0 219 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_14_7 loc_15_7 loc_16_7 down box4
2
546 0
610 0
4
0 0 73 90
0 3 88 98
0 219 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_14_7 loc_15_7 loc_16_7 down box6
2
546 0
610 0
4
0 0 73 90
0 2 88 98
0 219 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_14_8 loc_13_8 loc_12_8 up box1
2
482 0
547 0
4
0 0 74 58
0 1 56 40
0 167 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_13_8 loc_12_8 up box2
2
482 0
547 0
4
0 0 74 58
0 5 56 40
0 167 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_13_8 loc_12_8 up box3
2
482 0
547 0
4
0 0 74 58
0 4 56 40
0 167 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_13_8 loc_12_8 up box4
2
482 0
547 0
4
0 0 74 58
0 3 56 40
0 167 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_13_8 loc_12_8 up box6
2
482 0
547 0
4
0 0 74 58
0 2 56 40
0 167 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box1
2
544 0
548 0
4
0 0 74 73
0 1 71 70
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box2
2
544 0
548 0
4
0 0 74 73
0 5 71 70
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box3
2
544 0
548 0
4
0 0 74 73
0 4 71 70
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box4
2
544 0
548 0
4
0 0 74 73
0 3 71 70
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box6
2
544 0
548 0
4
0 0 74 73
0 2 71 70
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box1
2
549 0
552 0
4
0 0 74 75
0 1 73 58
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box2
2
549 0
552 0
4
0 0 74 75
0 5 73 58
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box3
2
549 0
552 0
4
0 0 74 75
0 4 73 58
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box4
2
549 0
552 0
4
0 0 74 75
0 3 73 58
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box6
2
549 0
552 0
4
0 0 74 75
0 2 73 58
0 185 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_15_8 loc_16_8 down box1
2
550 0
614 0
4
0 0 74 91
0 1 89 99
0 220 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_14_8 loc_15_8 loc_16_8 down box2
2
550 0
614 0
4
0 0 74 91
0 5 89 99
0 220 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_14_8 loc_15_8 loc_16_8 down box3
2
550 0
614 0
4
0 0 74 91
0 4 89 99
0 220 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_14_8 loc_15_8 loc_16_8 down box4
2
550 0
614 0
4
0 0 74 91
0 3 89 99
0 220 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_14_8 loc_15_8 loc_16_8 down box6
2
550 0
614 0
4
0 0 74 91
0 2 89 99
0 220 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_14_9 loc_13_9 loc_12_9 up box1
2
486 0
551 0
4
0 0 75 59
0 1 57 41
0 168 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_13_9 loc_12_9 up box2
2
486 0
551 0
4
0 0 75 59
0 5 57 41
0 168 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_13_9 loc_12_9 up box3
2
486 0
551 0
4
0 0 75 59
0 4 57 41
0 168 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_13_9 loc_12_9 up box4
2
486 0
551 0
4
0 0 75 59
0 3 57 41
0 168 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_13_9 loc_12_9 up box6
2
486 0
551 0
4
0 0 75 59
0 2 57 41
0 168 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box1
2
491 0
552 0
4
0 0 75 60
0 1 58 59
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box2
2
491 0
552 0
4
0 0 75 60
0 5 58 59
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box3
2
491 0
552 0
4
0 0 75 60
0 4 58 59
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box4
2
491 0
552 0
4
0 0 75 60
0 3 58 59
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box6
2
491 0
552 0
4
0 0 75 60
0 2 58 59
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box1
2
548 0
553 0
4
0 0 75 74
0 1 72 71
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box2
2
548 0
553 0
4
0 0 75 74
0 5 72 71
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box3
2
548 0
553 0
4
0 0 75 74
0 4 72 71
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box4
2
548 0
553 0
4
0 0 75 74
0 3 72 71
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box6
2
548 0
553 0
4
0 0 75 74
0 2 72 71
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_15_9 loc_16_9 down box1
2
554 0
618 0
4
0 0 75 92
0 1 90 100
0 221 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_14_9 loc_15_9 loc_16_9 down box2
2
554 0
618 0
4
0 0 75 92
0 5 90 100
0 221 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_14_9 loc_15_9 loc_16_9 down box3
2
554 0
618 0
4
0 0 75 92
0 4 90 100
0 221 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_14_9 loc_15_9 loc_16_9 down box4
2
554 0
618 0
4
0 0 75 92
0 3 90 100
0 221 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_14_9 loc_15_9 loc_16_9 down box6
2
554 0
618 0
4
0 0 75 92
0 2 90 100
0 221 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box1
2
490 0
555 0
4
0 0 76 60
0 1 58 42
0 169 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box2
2
490 0
555 0
4
0 0 76 60
0 5 58 42
0 169 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box3
2
490 0
555 0
4
0 0 76 60
0 4 58 42
0 169 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box4
2
490 0
555 0
4
0 0 76 60
0 3 58 42
0 169 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box6
2
490 0
555 0
4
0 0 76 60
0 2 58 42
0 169 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box1
2
556 0
561 0
4
0 0 76 77
0 1 75 76
0 204 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box2
2
556 0
561 0
4
0 0 76 77
0 5 75 76
0 204 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box3
2
556 0
561 0
4
0 0 76 77
0 4 75 76
0 204 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box4
2
556 0
561 0
4
0 0 76 77
0 3 75 76
0 204 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box6
2
556 0
561 0
4
0 0 76 77
0 2 75 76
0 204 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box1
2
557 0
617 0
4
0 0 76 92
0 1 90 89
0 220 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box2
2
557 0
617 0
4
0 0 76 92
0 5 90 89
0 220 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box3
2
557 0
617 0
4
0 0 76 92
0 4 90 89
0 220 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box4
2
557 0
617 0
4
0 0 76 92
0 3 90 89
0 220 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box6
2
557 0
617 0
4
0 0 76 92
0 2 90 89
0 220 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_16_10 loc_17_10 down box1
2
558 0
621 0
4
0 0 76 93
0 1 91 101
0 222 -1 0
0 234 0 1
1
end_operator
begin_operator
push loc_15_10 loc_16_10 loc_17_10 down box2
2
558 0
621 0
4
0 0 76 93
0 5 91 101
0 222 -1 0
0 234 0 1
1
end_operator
begin_operator
push loc_15_10 loc_16_10 loc_17_10 down box3
2
558 0
621 0
4
0 0 76 93
0 4 91 101
0 222 -1 0
0 234 0 1
1
end_operator
begin_operator
push loc_15_10 loc_16_10 loc_17_10 down box4
2
558 0
621 0
4
0 0 76 93
0 3 91 101
0 222 -1 0
0 234 0 1
1
end_operator
begin_operator
push loc_15_10 loc_16_10 loc_17_10 down box6
2
558 0
621 0
4
0 0 76 93
0 2 91 101
0 222 -1 0
0 234 0 1
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box1
2
494 0
559 0
4
0 0 77 61
0 1 59 43
0 170 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box2
2
494 0
559 0
4
0 0 77 61
0 5 59 43
0 170 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box3
2
494 0
559 0
4
0 0 77 61
0 4 59 43
0 170 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box4
2
494 0
559 0
4
0 0 77 61
0 3 59 43
0 170 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box6
2
494 0
559 0
4
0 0 77 61
0 2 59 43
0 170 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box1
2
557 0
560 0
4
0 0 77 76
0 1 74 90
0 203 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box2
2
557 0
560 0
4
0 0 77 76
0 5 74 90
0 203 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box3
2
557 0
560 0
4
0 0 77 76
0 4 74 90
0 203 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box4
2
557 0
560 0
4
0 0 77 76
0 3 74 90
0 203 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box6
2
557 0
560 0
4
0 0 77 76
0 2 74 90
0 203 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box1
2
561 0
564 0
4
0 0 77 78
0 1 76 77
0 205 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box2
2
561 0
564 0
4
0 0 77 78
0 5 76 77
0 205 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box3
2
561 0
564 0
4
0 0 77 78
0 4 76 77
0 205 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box4
2
561 0
564 0
4
0 0 77 78
0 3 76 77
0 205 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box6
2
561 0
564 0
4
0 0 77 78
0 2 76 77
0 205 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_15_12 loc_14_12 loc_13_12 up box1
2
498 0
562 0
4
0 0 78 62
0 1 60 44
0 171 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_14_12 loc_13_12 up box2
2
498 0
562 0
4
0 0 78 62
0 5 60 44
0 171 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_14_12 loc_13_12 up box3
2
498 0
562 0
4
0 0 78 62
0 4 60 44
0 171 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_14_12 loc_13_12 up box4
2
498 0
562 0
4
0 0 78 62
0 3 60 44
0 171 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_14_12 loc_13_12 up box6
2
498 0
562 0
4
0 0 78 62
0 2 60 44
0 171 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box1
2
560 0
563 0
4
0 0 78 77
0 1 75 74
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box2
2
560 0
563 0
4
0 0 78 77
0 5 75 74
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box3
2
560 0
563 0
4
0 0 78 77
0 4 75 74
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box4
2
560 0
563 0
4
0 0 78 77
0 3 75 74
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box6
2
560 0
563 0
4
0 0 78 77
0 2 75 74
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box1
2
564 0
567 0
4
0 0 78 79
0 1 77 78
0 206 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box2
2
564 0
567 0
4
0 0 78 79
0 5 77 78
0 206 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box3
2
564 0
567 0
4
0 0 78 79
0 4 77 78
0 206 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box4
2
564 0
567 0
4
0 0 78 79
0 3 77 78
0 206 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box6
2
564 0
567 0
4
0 0 78 79
0 2 77 78
0 206 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_15_13 loc_14_13 loc_13_13 up box1
2
502 0
565 0
4
0 0 79 63
0 1 61 45
0 172 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_14_13 loc_13_13 up box2
2
502 0
565 0
4
0 0 79 63
0 5 61 45
0 172 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_14_13 loc_13_13 up box3
2
502 0
565 0
4
0 0 79 63
0 4 61 45
0 172 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_14_13 loc_13_13 up box4
2
502 0
565 0
4
0 0 79 63
0 3 61 45
0 172 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_14_13 loc_13_13 up box6
2
502 0
565 0
4
0 0 79 63
0 2 61 45
0 172 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box1
2
563 0
566 0
4
0 0 79 78
0 1 76 75
0 204 0 1
0 205 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box2
2
563 0
566 0
4
0 0 79 78
0 5 76 75
0 204 0 1
0 205 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box3
2
563 0
566 0
4
0 0 79 78
0 4 76 75
0 204 0 1
0 205 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box4
2
563 0
566 0
4
0 0 79 78
0 3 76 75
0 204 0 1
0 205 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box6
2
563 0
566 0
4
0 0 79 78
0 2 76 75
0 204 0 1
0 205 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box1
2
567 0
571 0
4
0 0 79 80
0 1 78 79
0 207 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box2
2
567 0
571 0
4
0 0 79 80
0 5 78 79
0 207 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box3
2
567 0
571 0
4
0 0 79 80
0 4 78 79
0 207 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box4
2
567 0
571 0
4
0 0 79 80
0 3 78 79
0 207 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box6
2
567 0
571 0
4
0 0 79 80
0 2 78 79
0 207 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_15_13 loc_16_13 loc_17_13 down box1
2
568 0
624 0
4
0 0 79 94
0 1 92 102
0 223 -1 0
0 235 0 1
1
end_operator
begin_operator
push loc_15_13 loc_16_13 loc_17_13 down box2
2
568 0
624 0
4
0 0 79 94
0 5 92 102
0 223 -1 0
0 235 0 1
1
end_operator
begin_operator
push loc_15_13 loc_16_13 loc_17_13 down box3
2
568 0
624 0
4
0 0 79 94
0 4 92 102
0 223 -1 0
0 235 0 1
1
end_operator
begin_operator
push loc_15_13 loc_16_13 loc_17_13 down box4
2
568 0
624 0
4
0 0 79 94
0 3 92 102
0 223 -1 0
0 235 0 1
1
end_operator
begin_operator
push loc_15_13 loc_16_13 loc_17_13 down box6
2
568 0
624 0
4
0 0 79 94
0 2 92 102
0 223 -1 0
0 235 0 1
1
end_operator
begin_operator
push loc_15_14 loc_14_14 loc_13_14 up box1
2
506 0
569 0
4
0 0 80 64
0 1 62 46
0 173 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_14_14 loc_13_14 up box2
2
506 0
569 0
4
0 0 80 64
0 5 62 46
0 173 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_14_14 loc_13_14 up box3
2
506 0
569 0
4
0 0 80 64
0 4 62 46
0 173 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_14_14 loc_13_14 up box4
2
506 0
569 0
4
0 0 80 64
0 3 62 46
0 173 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_14_14 loc_13_14 up box6
2
506 0
569 0
4
0 0 80 64
0 2 62 46
0 173 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box1
2
566 0
570 0
4
0 0 80 79
0 1 77 76
0 205 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box2
2
566 0
570 0
4
0 0 80 79
0 5 77 76
0 205 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box3
2
566 0
570 0
4
0 0 80 79
0 4 77 76
0 205 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box4
2
566 0
570 0
4
0 0 80 79
0 3 77 76
0 205 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box6
2
566 0
570 0
4
0 0 80 79
0 2 77 76
0 205 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box1
2
571 0
575 0
4
0 0 80 81
0 1 79 80
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box2
2
571 0
575 0
4
0 0 80 81
0 5 79 80
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box3
2
571 0
575 0
4
0 0 80 81
0 4 79 80
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box4
2
571 0
575 0
4
0 0 80 81
0 3 79 80
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box6
2
571 0
575 0
4
0 0 80 81
0 2 79 80
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_15_14 loc_16_14 loc_17_14 down box1
2
572 0
627 0
4
0 0 80 95
0 1 93 103
0 224 -1 0
0 236 0 1
1
end_operator
begin_operator
push loc_15_14 loc_16_14 loc_17_14 down box2
2
572 0
627 0
4
0 0 80 95
0 5 93 103
0 224 -1 0
0 236 0 1
1
end_operator
begin_operator
push loc_15_14 loc_16_14 loc_17_14 down box3
2
572 0
627 0
4
0 0 80 95
0 4 93 103
0 224 -1 0
0 236 0 1
1
end_operator
begin_operator
push loc_15_14 loc_16_14 loc_17_14 down box4
2
572 0
627 0
4
0 0 80 95
0 3 93 103
0 224 -1 0
0 236 0 1
1
end_operator
begin_operator
push loc_15_14 loc_16_14 loc_17_14 down box6
2
572 0
627 0
4
0 0 80 95
0 2 93 103
0 224 -1 0
0 236 0 1
1
end_operator
begin_operator
push loc_15_15 loc_14_15 loc_13_15 up box1
2
510 0
573 0
4
0 0 81 65
0 1 63 47
0 174 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_14_15 loc_13_15 up box2
2
510 0
573 0
4
0 0 81 65
0 5 63 47
0 174 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_14_15 loc_13_15 up box3
2
510 0
573 0
4
0 0 81 65
0 4 63 47
0 174 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_14_15 loc_13_15 up box4
2
510 0
573 0
4
0 0 81 65
0 3 63 47
0 174 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_14_15 loc_13_15 up box6
2
510 0
573 0
4
0 0 81 65
0 2 63 47
0 174 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box1
2
570 0
574 0
4
0 0 81 80
0 1 78 77
0 206 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box2
2
570 0
574 0
4
0 0 81 80
0 5 78 77
0 206 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box3
2
570 0
574 0
4
0 0 81 80
0 4 78 77
0 206 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box4
2
570 0
574 0
4
0 0 81 80
0 3 78 77
0 206 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box6
2
570 0
574 0
4
0 0 81 80
0 2 78 77
0 206 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box1
2
575 0
578 0
4
0 0 81 82
0 1 80 81
0 209 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box2
2
575 0
578 0
4
0 0 81 82
0 5 80 81
0 209 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box3
2
575 0
578 0
4
0 0 81 82
0 4 80 81
0 209 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box4
2
575 0
578 0
4
0 0 81 82
0 3 80 81
0 209 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box6
2
575 0
578 0
4
0 0 81 82
0 2 80 81
0 209 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box1
2
574 0
577 0
4
0 0 82 81
0 1 79 78
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box2
2
574 0
577 0
4
0 0 82 81
0 5 79 78
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box3
2
574 0
577 0
4
0 0 82 81
0 4 79 78
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box4
2
574 0
577 0
4
0 0 82 81
0 3 79 78
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box6
2
574 0
577 0
4
0 0 82 81
0 2 79 78
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box1
2
578 0
581 0
4
0 0 82 83
0 1 81 82
0 210 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box2
2
578 0
581 0
4
0 0 82 83
0 5 81 82
0 210 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box3
2
578 0
581 0
4
0 0 82 83
0 4 81 82
0 210 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box4
2
578 0
581 0
4
0 0 82 83
0 3 81 82
0 210 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box6
2
578 0
581 0
4
0 0 82 83
0 2 81 82
0 210 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box1
2
517 0
579 0
4
0 0 83 67
0 1 65 48
0 175 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box2
2
517 0
579 0
4
0 0 83 67
0 5 65 48
0 175 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box3
2
517 0
579 0
4
0 0 83 67
0 4 65 48
0 175 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box4
2
517 0
579 0
4
0 0 83 67
0 3 65 48
0 175 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box6
2
517 0
579 0
4
0 0 83 67
0 2 65 48
0 175 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box1
2
577 0
580 0
4
0 0 83 82
0 1 80 79
0 208 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box2
2
577 0
580 0
4
0 0 83 82
0 5 80 79
0 208 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box3
2
577 0
580 0
4
0 0 83 82
0 4 80 79
0 208 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box4
2
577 0
580 0
4
0 0 83 82
0 3 80 79
0 208 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box6
2
577 0
580 0
4
0 0 83 82
0 2 80 79
0 208 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box1
2
581 0
584 0
4
0 0 83 84
0 1 82 83
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box2
2
581 0
584 0
4
0 0 83 84
0 5 82 83
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box3
2
581 0
584 0
4
0 0 83 84
0 4 82 83
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box4
2
581 0
584 0
4
0 0 83 84
0 3 82 83
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box6
2
581 0
584 0
4
0 0 83 84
0 2 82 83
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box1
2
521 0
582 0
4
0 0 84 68
0 1 66 49
0 176 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box2
2
521 0
582 0
4
0 0 84 68
0 5 66 49
0 176 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box3
2
521 0
582 0
4
0 0 84 68
0 4 66 49
0 176 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box4
2
521 0
582 0
4
0 0 84 68
0 3 66 49
0 176 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box6
2
521 0
582 0
4
0 0 84 68
0 2 66 49
0 176 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box1
2
580 0
583 0
4
0 0 84 83
0 1 81 80
0 209 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box2
2
580 0
583 0
4
0 0 84 83
0 5 81 80
0 209 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box3
2
580 0
583 0
4
0 0 84 83
0 4 81 80
0 209 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box4
2
580 0
583 0
4
0 0 84 83
0 3 81 80
0 209 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box6
2
580 0
583 0
4
0 0 84 83
0 2 81 80
0 209 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_19 loc_15_20 right box1
2
584 0
587 0
4
0 0 84 85
0 1 83 84
0 212 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_15_18 loc_15_19 loc_15_20 right box2
2
584 0
587 0
4
0 0 84 85
0 5 83 84
0 212 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_15_18 loc_15_19 loc_15_20 right box3
2
584 0
587 0
4
0 0 84 85
0 4 83 84
0 212 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_15_18 loc_15_19 loc_15_20 right box4
2
584 0
587 0
4
0 0 84 85
0 3 83 84
0 212 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_15_18 loc_15_19 loc_15_20 right box6
2
584 0
587 0
4
0 0 84 85
0 2 83 84
0 212 -1 0
0 214 0 1
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box1
2
525 0
585 0
4
0 0 85 69
0 1 67 50
0 177 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box2
2
525 0
585 0
4
0 0 85 69
0 5 67 50
0 177 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box3
2
525 0
585 0
4
0 0 85 69
0 4 67 50
0 177 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box4
2
525 0
585 0
4
0 0 85 69
0 3 67 50
0 177 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box6
2
525 0
585 0
4
0 0 85 69
0 2 67 50
0 177 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box1
2
583 0
586 0
4
0 0 85 84
0 1 82 81
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box2
2
583 0
586 0
4
0 0 85 84
0 5 82 81
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box3
2
583 0
586 0
4
0 0 85 84
0 4 82 81
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box4
2
583 0
586 0
4
0 0 85 84
0 3 82 81
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box6
2
583 0
586 0
4
0 0 85 84
0 2 82 81
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box1
2
587 0
594 0
4
0 0 85 86
0 1 84 85
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box2
2
587 0
594 0
4
0 0 85 86
0 5 84 85
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box3
2
587 0
594 0
4
0 0 85 86
0 4 84 85
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box4
2
587 0
594 0
4
0 0 85 86
0 3 84 85
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box5
2
587 0
594 0
4
0 0 85 86
0 7 5 6
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_15_20 loc_15_21 right box6
2
587 0
594 0
4
0 0 85 86
0 2 84 85
0 214 -1 0
0 215 0 1
1
end_operator
begin_operator
push loc_15_19 loc_16_19 loc_17_19 down box1
2
588 0
630 0
4
0 0 85 96
0 1 94 105
0 225 -1 0
0 239 0 1
1
end_operator
begin_operator
push loc_15_19 loc_16_19 loc_17_19 down box2
2
588 0
630 0
4
0 0 85 96
0 5 94 105
0 225 -1 0
0 239 0 1
1
end_operator
begin_operator
push loc_15_19 loc_16_19 loc_17_19 down box3
2
588 0
630 0
4
0 0 85 96
0 4 94 105
0 225 -1 0
0 239 0 1
1
end_operator
begin_operator
push loc_15_19 loc_16_19 loc_17_19 down box4
2
588 0
630 0
4
0 0 85 96
0 3 94 105
0 225 -1 0
0 239 0 1
1
end_operator
begin_operator
push loc_15_19 loc_16_19 loc_17_19 down box6
2
588 0
630 0
4
0 0 85 96
0 2 94 105
0 225 -1 0
0 239 0 1
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box1
2
531 0
592 0
4
0 0 86 70
0 1 68 51
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box2
2
531 0
592 0
4
0 0 86 70
0 5 68 51
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box3
2
531 0
592 0
4
0 0 86 70
0 4 68 51
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box4
2
531 0
592 0
4
0 0 86 70
0 3 68 51
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box5
2
531 0
592 0
4
0 0 86 70
0 7 4 2
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_14_20 loc_13_20 up box6
2
531 0
592 0
4
0 0 86 70
0 2 68 51
0 178 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_15_19 loc_15_18 left box1
2
586 0
593 0
4
0 0 86 85
0 1 83 82
0 211 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_15_19 loc_15_18 left box2
2
586 0
593 0
4
0 0 86 85
0 5 83 82
0 211 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_15_19 loc_15_18 left box3
2
586 0
593 0
4
0 0 86 85
0 4 83 82
0 211 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_15_19 loc_15_18 left box4
2
586 0
593 0
4
0 0 86 85
0 3 83 82
0 211 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_15_19 loc_15_18 left box6
2
586 0
593 0
4
0 0 86 85
0 2 83 82
0 211 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box1
2
595 0
635 0
4
0 0 86 97
0 1 95 106
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box2
2
595 0
635 0
4
0 0 86 97
0 5 95 106
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box3
2
595 0
635 0
4
0 0 86 97
0 4 95 106
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box4
2
595 0
635 0
4
0 0 86 97
0 3 95 106
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box5
2
595 0
635 0
4
0 0 86 97
0 7 7 8
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_20 loc_16_20 loc_17_20 down box6
2
595 0
635 0
4
0 0 86 97
0 2 95 106
0 227 -1 0
0 240 0 1
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box1
2
536 0
600 0
4
0 0 88 71
0 1 69 53
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box2
2
536 0
600 0
4
0 0 88 71
0 5 69 53
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box3
2
536 0
600 0
4
0 0 88 71
0 4 69 53
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box4
2
536 0
600 0
4
0 0 88 71
0 3 69 53
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box6
2
536 0
600 0
4
0 0 88 71
0 2 69 53
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box1
2
601 0
605 0
4
0 0 88 89
0 1 87 88
0 218 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box2
2
601 0
605 0
4
0 0 88 89
0 5 87 88
0 218 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box3
2
601 0
605 0
4
0 0 88 89
0 4 87 88
0 218 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box4
2
601 0
605 0
4
0 0 88 89
0 3 87 88
0 218 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box6
2
601 0
605 0
4
0 0 88 89
0 2 87 88
0 218 -1 0
0 219 0 1
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box1
2
539 0
603 0
4
0 0 89 72
0 1 70 54
0 181 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box2
2
539 0
603 0
4
0 0 89 72
0 5 70 54
0 181 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box3
2
539 0
603 0
4
0 0 89 72
0 4 70 54
0 181 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box4
2
539 0
603 0
4
0 0 89 72
0 3 70 54
0 181 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box6
2
539 0
603 0
4
0 0 89 72
0 2 70 54
0 181 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box1
2
605 0
609 0
4
0 0 89 90
0 1 88 89
0 219 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box2
2
605 0
609 0
4
0 0 89 90
0 5 88 89
0 219 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box3
2
605 0
609 0
4
0 0 89 90
0 4 88 89
0 219 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box4
2
605 0
609 0
4
0 0 89 90
0 3 88 89
0 219 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box6
2
605 0
609 0
4
0 0 89 90
0 2 88 89
0 219 -1 0
0 220 0 1
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box1
2
543 0
607 0
4
0 0 90 73
0 1 71 55
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box2
2
543 0
607 0
4
0 0 90 73
0 5 71 55
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box3
2
543 0
607 0
4
0 0 90 73
0 4 71 55
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box4
2
543 0
607 0
4
0 0 90 73
0 3 71 55
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box6
2
543 0
607 0
4
0 0 90 73
0 2 71 55
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box1
2
604 0
608 0
4
0 0 90 89
0 1 87 86
0 217 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box2
2
604 0
608 0
4
0 0 90 89
0 5 87 86
0 217 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box3
2
604 0
608 0
4
0 0 90 89
0 4 87 86
0 217 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box4
2
604 0
608 0
4
0 0 90 89
0 3 87 86
0 217 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box6
2
604 0
608 0
4
0 0 90 89
0 2 87 86
0 217 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box1
2
609 0
613 0
4
0 0 90 91
0 1 89 90
0 220 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box2
2
609 0
613 0
4
0 0 90 91
0 5 89 90
0 220 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box3
2
609 0
613 0
4
0 0 90 91
0 4 89 90
0 220 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box4
2
609 0
613 0
4
0 0 90 91
0 3 89 90
0 220 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box6
2
609 0
613 0
4
0 0 90 91
0 2 89 90
0 220 -1 0
0 221 0 1
1
end_operator
begin_operator
push loc_15_7 loc_16_7 loc_17_7 down box1
2
610 0
647 0
4
0 0 90 100
0 1 98 107
0 231 -1 0
0 242 0 1
1
end_operator
begin_operator
push loc_15_7 loc_16_7 loc_17_7 down box2
2
610 0
647 0
4
0 0 90 100
0 5 98 107
0 231 -1 0
0 242 0 1
1
end_operator
begin_operator
push loc_15_7 loc_16_7 loc_17_7 down box3
2
610 0
647 0
4
0 0 90 100
0 4 98 107
0 231 -1 0
0 242 0 1
1
end_operator
begin_operator
push loc_15_7 loc_16_7 loc_17_7 down box4
2
610 0
647 0
4
0 0 90 100
0 3 98 107
0 231 -1 0
0 242 0 1
1
end_operator
begin_operator
push loc_15_7 loc_16_7 loc_17_7 down box6
2
610 0
647 0
4
0 0 90 100
0 2 98 107
0 231 -1 0
0 242 0 1
1
end_operator
begin_operator
push loc_15_8 loc_14_8 loc_13_8 up box1
2
547 0
611 0
4
0 0 91 74
0 1 72 56
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_14_8 loc_13_8 up box2
2
547 0
611 0
4
0 0 91 74
0 5 72 56
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_14_8 loc_13_8 up box3
2
547 0
611 0
4
0 0 91 74
0 4 72 56
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_14_8 loc_13_8 up box4
2
547 0
611 0
4
0 0 91 74
0 3 72 56
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_14_8 loc_13_8 up box6
2
547 0
611 0
4
0 0 91 74
0 2 72 56
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box1
2
608 0
612 0
4
0 0 91 90
0 1 88 87
0 218 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box2
2
608 0
612 0
4
0 0 91 90
0 5 88 87
0 218 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box3
2
608 0
612 0
4
0 0 91 90
0 4 88 87
0 218 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box4
2
608 0
612 0
4
0 0 91 90
0 3 88 87
0 218 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box6
2
608 0
612 0
4
0 0 91 90
0 2 88 87
0 218 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box1
2
613 0
616 0
4
0 0 91 92
0 1 90 74
0 203 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box2
2
613 0
616 0
4
0 0 91 92
0 5 90 74
0 203 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box3
2
613 0
616 0
4
0 0 91 92
0 4 90 74
0 203 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box4
2
613 0
616 0
4
0 0 91 92
0 3 90 74
0 203 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box6
2
613 0
616 0
4
0 0 91 92
0 2 90 74
0 203 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_16_8 loc_17_8 down box1
2
614 0
651 0
4
0 0 91 101
0 1 99 108
0 232 -1 0
0 243 0 1
1
end_operator
begin_operator
push loc_15_8 loc_16_8 loc_17_8 down box2
2
614 0
651 0
4
0 0 91 101
0 5 99 108
0 232 -1 0
0 243 0 1
1
end_operator
begin_operator
push loc_15_8 loc_16_8 loc_17_8 down box3
2
614 0
651 0
4
0 0 91 101
0 4 99 108
0 232 -1 0
0 243 0 1
1
end_operator
begin_operator
push loc_15_8 loc_16_8 loc_17_8 down box4
2
614 0
651 0
4
0 0 91 101
0 3 99 108
0 232 -1 0
0 243 0 1
1
end_operator
begin_operator
push loc_15_8 loc_16_8 loc_17_8 down box6
2
614 0
651 0
4
0 0 91 101
0 2 99 108
0 232 -1 0
0 243 0 1
1
end_operator
begin_operator
push loc_15_9 loc_14_9 loc_13_9 up box1
2
551 0
615 0
4
0 0 92 75
0 1 73 57
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_14_9 loc_13_9 up box2
2
551 0
615 0
4
0 0 92 75
0 5 73 57
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_14_9 loc_13_9 up box3
2
551 0
615 0
4
0 0 92 75
0 4 73 57
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_14_9 loc_13_9 up box4
2
551 0
615 0
4
0 0 92 75
0 3 73 57
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_14_9 loc_13_9 up box6
2
551 0
615 0
4
0 0 92 75
0 2 73 57
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box1
2
556 0
616 0
4
0 0 92 76
0 1 74 75
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box2
2
556 0
616 0
4
0 0 92 76
0 5 74 75
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box3
2
556 0
616 0
4
0 0 92 76
0 4 74 75
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box4
2
556 0
616 0
4
0 0 92 76
0 3 74 75
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box6
2
556 0
616 0
4
0 0 92 76
0 2 74 75
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box1
2
612 0
617 0
4
0 0 92 91
0 1 89 88
0 219 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box2
2
612 0
617 0
4
0 0 92 91
0 5 89 88
0 219 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box3
2
612 0
617 0
4
0 0 92 91
0 4 89 88
0 219 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box4
2
612 0
617 0
4
0 0 92 91
0 3 89 88
0 219 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box6
2
612 0
617 0
4
0 0 92 91
0 2 89 88
0 219 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_15_10 loc_14_10 up box1
2
555 0
619 0
4
0 0 93 76
0 1 74 58
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_15_10 loc_14_10 up box2
2
555 0
619 0
4
0 0 93 76
0 5 74 58
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_15_10 loc_14_10 up box3
2
555 0
619 0
4
0 0 93 76
0 4 74 58
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_15_10 loc_14_10 up box4
2
555 0
619 0
4
0 0 93 76
0 3 74 58
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_15_10 loc_14_10 up box6
2
555 0
619 0
4
0 0 93 76
0 2 74 58
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box1
2
620 0
654 0
4
0 0 93 102
0 1 100 99
0 232 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box2
2
620 0
654 0
4
0 0 93 102
0 5 100 99
0 232 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box3
2
620 0
654 0
4
0 0 93 102
0 4 100 99
0 232 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box4
2
620 0
654 0
4
0 0 93 102
0 3 100 99
0 232 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box6
2
620 0
654 0
4
0 0 93 102
0 2 100 99
0 232 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_17_10 loc_18_10 down box1
2
621 0
656 0
4
0 0 93 103
0 1 101 109
0 234 -1 0
0 244 0 1
1
end_operator
begin_operator
push loc_16_10 loc_17_10 loc_18_10 down box2
2
621 0
656 0
4
0 0 93 103
0 5 101 109
0 234 -1 0
0 244 0 1
1
end_operator
begin_operator
push loc_16_10 loc_17_10 loc_18_10 down box3
2
621 0
656 0
4
0 0 93 103
0 4 101 109
0 234 -1 0
0 244 0 1
1
end_operator
begin_operator
push loc_16_10 loc_17_10 loc_18_10 down box4
2
621 0
656 0
4
0 0 93 103
0 3 101 109
0 234 -1 0
0 244 0 1
1
end_operator
begin_operator
push loc_16_10 loc_17_10 loc_18_10 down box6
2
621 0
656 0
4
0 0 93 103
0 2 101 109
0 234 -1 0
0 244 0 1
1
end_operator
begin_operator
push loc_16_13 loc_15_13 loc_14_13 up box1
2
565 0
622 0
4
0 0 94 79
0 1 77 61
0 188 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_15_13 loc_14_13 up box2
2
565 0
622 0
4
0 0 94 79
0 5 77 61
0 188 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_15_13 loc_14_13 up box3
2
565 0
622 0
4
0 0 94 79
0 4 77 61
0 188 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_15_13 loc_14_13 up box4
2
565 0
622 0
4
0 0 94 79
0 3 77 61
0 188 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_15_13 loc_14_13 up box6
2
565 0
622 0
4
0 0 94 79
0 2 77 61
0 188 0 1
0 206 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_17_13 loc_18_13 down box1
2
624 0
659 0
4
0 0 94 104
0 1 102 111
0 235 -1 0
0 246 0 1
1
end_operator
begin_operator
push loc_16_13 loc_17_13 loc_18_13 down box2
2
624 0
659 0
4
0 0 94 104
0 5 102 111
0 235 -1 0
0 246 0 1
1
end_operator
begin_operator
push loc_16_13 loc_17_13 loc_18_13 down box3
2
624 0
659 0
4
0 0 94 104
0 4 102 111
0 235 -1 0
0 246 0 1
1
end_operator
begin_operator
push loc_16_13 loc_17_13 loc_18_13 down box4
2
624 0
659 0
4
0 0 94 104
0 3 102 111
0 235 -1 0
0 246 0 1
1
end_operator
begin_operator
push loc_16_13 loc_17_13 loc_18_13 down box6
2
624 0
659 0
4
0 0 94 104
0 2 102 111
0 235 -1 0
0 246 0 1
1
end_operator
begin_operator
push loc_16_14 loc_15_14 loc_14_14 up box1
2
569 0
625 0
4
0 0 95 80
0 1 78 62
0 189 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_15_14 loc_14_14 up box2
2
569 0
625 0
4
0 0 95 80
0 5 78 62
0 189 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_15_14 loc_14_14 up box3
2
569 0
625 0
4
0 0 95 80
0 4 78 62
0 189 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_15_14 loc_14_14 up box4
2
569 0
625 0
4
0 0 95 80
0 3 78 62
0 189 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_15_14 loc_14_14 up box6
2
569 0
625 0
4
0 0 95 80
0 2 78 62
0 189 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_17_14 loc_18_14 down box1
2
627 0
662 0
4
0 0 95 105
0 1 103 112
0 236 -1 0
0 247 0 1
1
end_operator
begin_operator
push loc_16_14 loc_17_14 loc_18_14 down box2
2
627 0
662 0
4
0 0 95 105
0 5 103 112
0 236 -1 0
0 247 0 1
1
end_operator
begin_operator
push loc_16_14 loc_17_14 loc_18_14 down box3
2
627 0
662 0
4
0 0 95 105
0 4 103 112
0 236 -1 0
0 247 0 1
1
end_operator
begin_operator
push loc_16_14 loc_17_14 loc_18_14 down box4
2
627 0
662 0
4
0 0 95 105
0 3 103 112
0 236 -1 0
0 247 0 1
1
end_operator
begin_operator
push loc_16_14 loc_17_14 loc_18_14 down box6
2
627 0
662 0
4
0 0 95 105
0 2 103 112
0 236 -1 0
0 247 0 1
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box1
2
585 0
628 0
4
0 0 96 85
0 1 83 67
0 194 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box2
2
585 0
628 0
4
0 0 96 85
0 5 83 67
0 194 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box3
2
585 0
628 0
4
0 0 96 85
0 4 83 67
0 194 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box4
2
585 0
628 0
4
0 0 96 85
0 3 83 67
0 194 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box6
2
585 0
628 0
4
0 0 96 85
0 2 83 67
0 194 0 1
0 212 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_17_19 loc_18_19 down box1
2
630 0
668 0
4
0 0 96 108
0 1 105 115
0 239 -1 0
0 250 0 1
1
end_operator
begin_operator
push loc_16_19 loc_17_19 loc_18_19 down box2
2
630 0
668 0
4
0 0 96 108
0 5 105 115
0 239 -1 0
0 250 0 1
1
end_operator
begin_operator
push loc_16_19 loc_17_19 loc_18_19 down box3
2
630 0
668 0
4
0 0 96 108
0 4 105 115
0 239 -1 0
0 250 0 1
1
end_operator
begin_operator
push loc_16_19 loc_17_19 loc_18_19 down box4
2
630 0
668 0
4
0 0 96 108
0 3 105 115
0 239 -1 0
0 250 0 1
1
end_operator
begin_operator
push loc_16_19 loc_17_19 loc_18_19 down box6
2
630 0
668 0
4
0 0 96 108
0 2 105 115
0 239 -1 0
0 250 0 1
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box1
2
592 0
633 0
4
0 0 97 86
0 1 84 68
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box2
2
592 0
633 0
4
0 0 97 86
0 5 84 68
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box3
2
592 0
633 0
4
0 0 97 86
0 4 84 68
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box4
2
592 0
633 0
4
0 0 97 86
0 3 84 68
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box5
2
592 0
633 0
4
0 0 97 86
0 7 5 4
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_15_20 loc_14_20 up box6
2
592 0
633 0
4
0 0 97 86
0 2 84 68
0 196 0 1
0 214 -1 0
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box1
2
635 0
671 0
4
0 0 97 109
0 1 106 116
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box2
2
635 0
671 0
4
0 0 97 109
0 5 106 116
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box3
2
635 0
671 0
4
0 0 97 109
0 4 106 116
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box4
2
635 0
671 0
4
0 0 97 109
0 3 106 116
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box5
2
635 0
671 0
4
0 0 97 109
0 7 8 9
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_20 loc_17_20 loc_18_20 down box6
2
635 0
671 0
4
0 0 97 109
0 2 106 116
0 240 -1 0
0 251 0 1
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box1
2
600 0
639 0
4
0 0 98 88
0 1 86 69
0 198 0 1
0 217 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box2
2
600 0
639 0
4
0 0 98 88
0 5 86 69
0 198 0 1
0 217 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box3
2
600 0
639 0
4
0 0 98 88
0 4 86 69
0 198 0 1
0 217 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box4
2
600 0
639 0
4
0 0 98 88
0 3 86 69
0 198 0 1
0 217 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box6
2
600 0
639 0
4
0 0 98 88
0 2 86 69
0 198 0 1
0 217 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box1
2
640 0
643 0
4
0 0 98 99
0 1 97 98
0 230 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box2
2
640 0
643 0
4
0 0 98 99
0 5 97 98
0 230 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box3
2
640 0
643 0
4
0 0 98 99
0 4 97 98
0 230 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box4
2
640 0
643 0
4
0 0 98 99
0 3 97 98
0 230 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box6
2
640 0
643 0
4
0 0 98 99
0 2 97 98
0 230 -1 0
0 231 0 1
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box1
2
603 0
641 0
4
0 0 99 89
0 1 87 70
0 199 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box2
2
603 0
641 0
4
0 0 99 89
0 5 87 70
0 199 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box3
2
603 0
641 0
4
0 0 99 89
0 4 87 70
0 199 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box4
2
603 0
641 0
4
0 0 99 89
0 3 87 70
0 199 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box6
2
603 0
641 0
4
0 0 99 89
0 2 87 70
0 199 0 1
0 218 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box1
2
643 0
646 0
4
0 0 99 100
0 1 98 99
0 231 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box2
2
643 0
646 0
4
0 0 99 100
0 5 98 99
0 231 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box3
2
643 0
646 0
4
0 0 99 100
0 4 98 99
0 231 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box4
2
643 0
646 0
4
0 0 99 100
0 3 98 99
0 231 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box6
2
643 0
646 0
4
0 0 99 100
0 2 98 99
0 231 -1 0
0 232 0 1
1
end_operator
begin_operator
push loc_16_7 loc_15_7 loc_14_7 up box1
2
607 0
644 0
4
0 0 100 90
0 1 88 71
0 200 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_15_7 loc_14_7 up box2
2
607 0
644 0
4
0 0 100 90
0 5 88 71
0 200 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_15_7 loc_14_7 up box3
2
607 0
644 0
4
0 0 100 90
0 4 88 71
0 200 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_15_7 loc_14_7 up box4
2
607 0
644 0
4
0 0 100 90
0 3 88 71
0 200 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_15_7 loc_14_7 up box6
2
607 0
644 0
4
0 0 100 90
0 2 88 71
0 200 0 1
0 219 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box1
2
642 0
645 0
4
0 0 100 99
0 1 97 96
0 229 0 1
0 230 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box2
2
642 0
645 0
4
0 0 100 99
0 5 97 96
0 229 0 1
0 230 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box3
2
642 0
645 0
4
0 0 100 99
0 4 97 96
0 229 0 1
0 230 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box4
2
642 0
645 0
4
0 0 100 99
0 3 97 96
0 229 0 1
0 230 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box6
2
642 0
645 0
4
0 0 100 99
0 2 97 96
0 229 0 1
0 230 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box1
2
646 0
650 0
4
0 0 100 101
0 1 99 100
0 232 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box2
2
646 0
650 0
4
0 0 100 101
0 5 99 100
0 232 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box3
2
646 0
650 0
4
0 0 100 101
0 4 99 100
0 232 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box4
2
646 0
650 0
4
0 0 100 101
0 3 99 100
0 232 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box6
2
646 0
650 0
4
0 0 100 101
0 2 99 100
0 232 -1 0
0 233 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box1
2
647 0
675 0
4
0 0 100 110
0 1 107 118
0 242 -1 0
0 253 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box2
2
647 0
675 0
4
0 0 100 110
0 5 107 118
0 242 -1 0
0 253 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box3
2
647 0
675 0
4
0 0 100 110
0 4 107 118
0 242 -1 0
0 253 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box4
2
647 0
675 0
4
0 0 100 110
0 3 107 118
0 242 -1 0
0 253 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box6
2
647 0
675 0
4
0 0 100 110
0 2 107 118
0 242 -1 0
0 253 0 1
1
end_operator
begin_operator
push loc_16_8 loc_15_8 loc_14_8 up box1
2
611 0
648 0
4
0 0 101 91
0 1 89 72
0 201 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_15_8 loc_14_8 up box2
2
611 0
648 0
4
0 0 101 91
0 5 89 72
0 201 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_15_8 loc_14_8 up box3
2
611 0
648 0
4
0 0 101 91
0 4 89 72
0 201 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_15_8 loc_14_8 up box4
2
611 0
648 0
4
0 0 101 91
0 3 89 72
0 201 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_15_8 loc_14_8 up box6
2
611 0
648 0
4
0 0 101 91
0 2 89 72
0 201 0 1
0 220 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box1
2
645 0
649 0
4
0 0 101 100
0 1 98 97
0 230 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box2
2
645 0
649 0
4
0 0 101 100
0 5 98 97
0 230 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box3
2
645 0
649 0
4
0 0 101 100
0 4 98 97
0 230 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box4
2
645 0
649 0
4
0 0 101 100
0 3 98 97
0 230 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box6
2
645 0
649 0
4
0 0 101 100
0 2 98 97
0 230 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box1
2
650 0
653 0
4
0 0 101 102
0 1 100 91
0 222 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box2
2
650 0
653 0
4
0 0 101 102
0 5 100 91
0 222 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box3
2
650 0
653 0
4
0 0 101 102
0 4 100 91
0 222 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box4
2
650 0
653 0
4
0 0 101 102
0 3 100 91
0 222 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box6
2
650 0
653 0
4
0 0 101 102
0 2 100 91
0 222 0 1
0 233 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_17_8 loc_18_8 down box1
2
651 0
678 0
4
0 0 101 111
0 1 108 119
0 243 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_16_8 loc_17_8 loc_18_8 down box2
2
651 0
678 0
4
0 0 101 111
0 5 108 119
0 243 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_16_8 loc_17_8 loc_18_8 down box3
2
651 0
678 0
4
0 0 101 111
0 4 108 119
0 243 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_16_8 loc_17_8 loc_18_8 down box4
2
651 0
678 0
4
0 0 101 111
0 3 108 119
0 243 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_16_8 loc_17_8 loc_18_8 down box6
2
651 0
678 0
4
0 0 101 111
0 2 108 119
0 243 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_16_9 loc_15_9 loc_14_9 up box1
2
615 0
652 0
4
0 0 102 92
0 1 90 73
0 202 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_15_9 loc_14_9 up box2
2
615 0
652 0
4
0 0 102 92
0 5 90 73
0 202 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_15_9 loc_14_9 up box3
2
615 0
652 0
4
0 0 102 92
0 4 90 73
0 202 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_15_9 loc_14_9 up box4
2
615 0
652 0
4
0 0 102 92
0 3 90 73
0 202 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_15_9 loc_14_9 up box6
2
615 0
652 0
4
0 0 102 92
0 2 90 73
0 202 0 1
0 221 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box1
2
649 0
654 0
4
0 0 102 101
0 1 99 98
0 231 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box2
2
649 0
654 0
4
0 0 102 101
0 5 99 98
0 231 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box3
2
649 0
654 0
4
0 0 102 101
0 4 99 98
0 231 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box4
2
649 0
654 0
4
0 0 102 101
0 3 99 98
0 231 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box6
2
649 0
654 0
4
0 0 102 101
0 2 99 98
0 231 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_10 loc_16_10 loc_15_10 up box1
2
619 0
655 0
4
0 0 103 93
0 1 91 74
0 203 0 1
0 222 -1 0
1
end_operator
begin_operator
push loc_17_10 loc_16_10 loc_15_10 up box2
2
619 0
655 0
4
0 0 103 93
0 5 91 74
0 203 0 1
0 222 -1 0
1
end_operator
begin_operator
push loc_17_10 loc_16_10 loc_15_10 up box3
2
619 0
655 0
4
0 0 103 93
0 4 91 74
0 203 0 1
0 222 -1 0
1
end_operator
begin_operator
push loc_17_10 loc_16_10 loc_15_10 up box4
2
619 0
655 0
4
0 0 103 93
0 3 91 74
0 203 0 1
0 222 -1 0
1
end_operator
begin_operator
push loc_17_10 loc_16_10 loc_15_10 up box6
2
619 0
655 0
4
0 0 103 93
0 2 91 74
0 203 0 1
0 222 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_16_13 loc_15_13 up box1
2
622 0
657 0
4
0 0 104 94
0 1 92 77
0 206 0 1
0 223 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_16_13 loc_15_13 up box2
2
622 0
657 0
4
0 0 104 94
0 5 92 77
0 206 0 1
0 223 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_16_13 loc_15_13 up box3
2
622 0
657 0
4
0 0 104 94
0 4 92 77
0 206 0 1
0 223 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_16_13 loc_15_13 up box4
2
622 0
657 0
4
0 0 104 94
0 3 92 77
0 206 0 1
0 223 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_16_13 loc_15_13 up box6
2
622 0
657 0
4
0 0 104 94
0 2 92 77
0 206 0 1
0 223 -1 0
1
end_operator
begin_operator
push loc_17_13 loc_18_13 loc_19_13 down box1
2
659 0
686 0
4
0 0 104 114
0 1 111 123
0 246 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_17_13 loc_18_13 loc_19_13 down box2
2
659 0
686 0
4
0 0 104 114
0 5 111 123
0 246 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_17_13 loc_18_13 loc_19_13 down box3
2
659 0
686 0
4
0 0 104 114
0 4 111 123
0 246 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_17_13 loc_18_13 loc_19_13 down box4
2
659 0
686 0
4
0 0 104 114
0 3 111 123
0 246 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_17_13 loc_18_13 loc_19_13 down box6
2
659 0
686 0
4
0 0 104 114
0 2 111 123
0 246 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_17_14 loc_16_14 loc_15_14 up box1
2
625 0
660 0
4
0 0 105 95
0 1 93 78
0 207 0 1
0 224 -1 0
1
end_operator
begin_operator
push loc_17_14 loc_16_14 loc_15_14 up box2
2
625 0
660 0
4
0 0 105 95
0 5 93 78
0 207 0 1
0 224 -1 0
1
end_operator
begin_operator
push loc_17_14 loc_16_14 loc_15_14 up box3
2
625 0
660 0
4
0 0 105 95
0 4 93 78
0 207 0 1
0 224 -1 0
1
end_operator
begin_operator
push loc_17_14 loc_16_14 loc_15_14 up box4
2
625 0
660 0
4
0 0 105 95
0 3 93 78
0 207 0 1
0 224 -1 0
1
end_operator
begin_operator
push loc_17_14 loc_16_14 loc_15_14 up box6
2
625 0
660 0
4
0 0 105 95
0 2 93 78
0 207 0 1
0 224 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_16_19 loc_15_19 up box1
2
628 0
666 0
4
0 0 108 96
0 1 94 83
0 212 0 1
0 225 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_16_19 loc_15_19 up box2
2
628 0
666 0
4
0 0 108 96
0 5 94 83
0 212 0 1
0 225 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_16_19 loc_15_19 up box3
2
628 0
666 0
4
0 0 108 96
0 4 94 83
0 212 0 1
0 225 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_16_19 loc_15_19 up box4
2
628 0
666 0
4
0 0 108 96
0 3 94 83
0 212 0 1
0 225 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_16_19 loc_15_19 up box6
2
628 0
666 0
4
0 0 108 96
0 2 94 83
0 212 0 1
0 225 -1 0
1
end_operator
begin_operator
push loc_17_19 loc_18_19 loc_19_19 down box1
2
668 0
697 0
4
0 0 108 118
0 1 115 126
0 250 -1 0
0 261 0 1
1
end_operator
begin_operator
push loc_17_19 loc_18_19 loc_19_19 down box2
2
668 0
697 0
4
0 0 108 118
0 5 115 126
0 250 -1 0
0 261 0 1
1
end_operator
begin_operator
push loc_17_19 loc_18_19 loc_19_19 down box3
2
668 0
697 0
4
0 0 108 118
0 4 115 126
0 250 -1 0
0 261 0 1
1
end_operator
begin_operator
push loc_17_19 loc_18_19 loc_19_19 down box4
2
668 0
697 0
4
0 0 108 118
0 3 115 126
0 250 -1 0
0 261 0 1
1
end_operator
begin_operator
push loc_17_19 loc_18_19 loc_19_19 down box6
2
668 0
697 0
4
0 0 108 118
0 2 115 126
0 250 -1 0
0 261 0 1
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box1
2
633 0
669 0
4
0 0 109 97
0 1 95 84
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box2
2
633 0
669 0
4
0 0 109 97
0 5 95 84
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box3
2
633 0
669 0
4
0 0 109 97
0 4 95 84
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box4
2
633 0
669 0
4
0 0 109 97
0 3 95 84
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box5
2
633 0
669 0
4
0 0 109 97
0 7 7 5
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_16_20 loc_15_20 up box6
2
633 0
669 0
4
0 0 109 97
0 2 95 84
0 214 0 1
0 227 -1 0
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box1
2
671 0
700 0
4
0 0 109 119
0 1 116 127
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box2
2
671 0
700 0
4
0 0 109 119
0 5 116 127
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box3
2
671 0
700 0
4
0 0 109 119
0 4 116 127
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box4
2
671 0
700 0
4
0 0 109 119
0 3 116 127
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box5
2
671 0
700 0
4
0 0 109 119
0 7 9 10
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_20 loc_18_20 loc_19_20 down box6
2
671 0
700 0
4
0 0 109 119
0 2 116 127
0 251 -1 0
0 263 0 1
1
end_operator
begin_operator
push loc_17_7 loc_16_7 loc_15_7 up box1
2
644 0
673 0
4
0 0 110 100
0 1 98 88
0 219 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_16_7 loc_15_7 up box2
2
644 0
673 0
4
0 0 110 100
0 5 98 88
0 219 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_16_7 loc_15_7 up box3
2
644 0
673 0
4
0 0 110 100
0 4 98 88
0 219 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_16_7 loc_15_7 up box4
2
644 0
673 0
4
0 0 110 100
0 3 98 88
0 219 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_16_7 loc_15_7 up box6
2
644 0
673 0
4
0 0 110 100
0 2 98 88
0 219 0 1
0 231 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_18_7 loc_19_7 down box1
2
675 0
706 0
4
0 0 110 121
0 1 118 130
0 253 -1 0
0 266 0 1
1
end_operator
begin_operator
push loc_17_7 loc_18_7 loc_19_7 down box2
2
675 0
706 0
4
0 0 110 121
0 5 118 130
0 253 -1 0
0 266 0 1
1
end_operator
begin_operator
push loc_17_7 loc_18_7 loc_19_7 down box3
2
675 0
706 0
4
0 0 110 121
0 4 118 130
0 253 -1 0
0 266 0 1
1
end_operator
begin_operator
push loc_17_7 loc_18_7 loc_19_7 down box4
2
675 0
706 0
4
0 0 110 121
0 3 118 130
0 253 -1 0
0 266 0 1
1
end_operator
begin_operator
push loc_17_7 loc_18_7 loc_19_7 down box6
2
675 0
706 0
4
0 0 110 121
0 2 118 130
0 253 -1 0
0 266 0 1
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box1
2
648 0
676 0
4
0 0 111 101
0 1 99 89
0 220 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box2
2
648 0
676 0
4
0 0 111 101
0 5 99 89
0 220 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box3
2
648 0
676 0
4
0 0 111 101
0 4 99 89
0 220 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box4
2
648 0
676 0
4
0 0 111 101
0 3 99 89
0 220 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box6
2
648 0
676 0
4
0 0 111 101
0 2 99 89
0 220 0 1
0 232 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_18_8 loc_19_8 down box1
2
678 0
710 0
4
0 0 111 122
0 1 119 131
0 254 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_17_8 loc_18_8 loc_19_8 down box2
2
678 0
710 0
4
0 0 111 122
0 5 119 131
0 254 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_17_8 loc_18_8 loc_19_8 down box3
2
678 0
710 0
4
0 0 111 122
0 4 119 131
0 254 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_17_8 loc_18_8 loc_19_8 down box4
2
678 0
710 0
4
0 0 111 122
0 3 119 131
0 254 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_17_8 loc_18_8 loc_19_8 down box6
2
678 0
710 0
4
0 0 111 122
0 2 119 131
0 254 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_18_10 loc_17_10 loc_16_10 up box1
2
655 0
679 0
4
0 0 112 103
0 1 101 91
0 222 0 1
0 234 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_17_10 loc_16_10 up box2
2
655 0
679 0
4
0 0 112 103
0 5 101 91
0 222 0 1
0 234 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_17_10 loc_16_10 up box3
2
655 0
679 0
4
0 0 112 103
0 4 101 91
0 222 0 1
0 234 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_17_10 loc_16_10 up box4
2
655 0
679 0
4
0 0 112 103
0 3 101 91
0 222 0 1
0 234 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_17_10 loc_16_10 up box6
2
655 0
679 0
4
0 0 112 103
0 2 101 91
0 222 0 1
0 234 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_18_9 loc_18_8 left box1
2
681 0
712 0
4
0 0 112 123
0 1 120 119
0 254 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_18_9 loc_18_8 left box2
2
681 0
712 0
4
0 0 112 123
0 5 120 119
0 254 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_18_9 loc_18_8 left box3
2
681 0
712 0
4
0 0 112 123
0 4 120 119
0 254 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_18_9 loc_18_8 left box4
2
681 0
712 0
4
0 0 112 123
0 3 120 119
0 254 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_10 loc_18_9 loc_18_8 left box6
2
681 0
712 0
4
0 0 112 123
0 2 120 119
0 254 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_11 loc_18_10 loc_18_9 left box1
2
681 0
682 0
4
0 0 113 112
0 1 109 120
0 244 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_11 loc_18_10 loc_18_9 left box2
2
681 0
682 0
4
0 0 113 112
0 5 109 120
0 244 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_11 loc_18_10 loc_18_9 left box3
2
681 0
682 0
4
0 0 113 112
0 4 109 120
0 244 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_11 loc_18_10 loc_18_9 left box4
2
681 0
682 0
4
0 0 113 112
0 3 109 120
0 244 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_11 loc_18_10 loc_18_9 left box6
2
681 0
682 0
4
0 0 113 112
0 2 109 120
0 244 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_11 loc_19_11 loc_20_11 down box1
2
683 0
716 0
4
0 0 113 124
0 1 121 134
0 256 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_18_11 loc_19_11 loc_20_11 down box2
2
683 0
716 0
4
0 0 113 124
0 5 121 134
0 256 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_18_11 loc_19_11 loc_20_11 down box3
2
683 0
716 0
4
0 0 113 124
0 4 121 134
0 256 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_18_11 loc_19_11 loc_20_11 down box4
2
683 0
716 0
4
0 0 113 124
0 3 121 134
0 256 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_18_11 loc_19_11 loc_20_11 down box6
2
683 0
716 0
4
0 0 113 124
0 2 121 134
0 256 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_18_13 loc_17_13 loc_16_13 up box1
2
657 0
684 0
4
0 0 114 104
0 1 102 92
0 223 0 1
0 235 -1 0
1
end_operator
begin_operator
push loc_18_13 loc_17_13 loc_16_13 up box2
2
657 0
684 0
4
0 0 114 104
0 5 102 92
0 223 0 1
0 235 -1 0
1
end_operator
begin_operator
push loc_18_13 loc_17_13 loc_16_13 up box3
2
657 0
684 0
4
0 0 114 104
0 4 102 92
0 223 0 1
0 235 -1 0
1
end_operator
begin_operator
push loc_18_13 loc_17_13 loc_16_13 up box4
2
657 0
684 0
4
0 0 114 104
0 3 102 92
0 223 0 1
0 235 -1 0
1
end_operator
begin_operator
push loc_18_13 loc_17_13 loc_16_13 up box6
2
657 0
684 0
4
0 0 114 104
0 2 102 92
0 223 0 1
0 235 -1 0
1
end_operator
begin_operator
push loc_18_13 loc_18_14 loc_18_15 right box1
2
685 0
689 0
4
0 0 114 115
0 1 112 113
0 247 -1 0
0 248 0 1
1
end_operator
begin_operator
push loc_18_13 loc_18_14 loc_18_15 right box2
2
685 0
689 0
4
0 0 114 115
0 5 112 113
0 247 -1 0
0 248 0 1
1
end_operator
begin_operator
push loc_18_13 loc_18_14 loc_18_15 right box3
2
685 0
689 0
4
0 0 114 115
0 4 112 113
0 247 -1 0
0 248 0 1
1
end_operator
begin_operator
push loc_18_13 loc_18_14 loc_18_15 right box4
2
685 0
689 0
4
0 0 114 115
0 3 112 113
0 247 -1 0
0 248 0 1
1
end_operator
begin_operator
push loc_18_13 loc_18_14 loc_18_15 right box6
2
685 0
689 0
4
0 0 114 115
0 2 112 113
0 247 -1 0
0 248 0 1
1
end_operator
begin_operator
push loc_18_13 loc_19_13 loc_20_13 down box1
2
686 0
722 0
4
0 0 114 126
0 1 123 136
0 258 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_18_13 loc_19_13 loc_20_13 down box2
2
686 0
722 0
4
0 0 114 126
0 5 123 136
0 258 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_18_13 loc_19_13 loc_20_13 down box3
2
686 0
722 0
4
0 0 114 126
0 4 123 136
0 258 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_18_13 loc_19_13 loc_20_13 down box4
2
686 0
722 0
4
0 0 114 126
0 3 123 136
0 258 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_18_13 loc_19_13 loc_20_13 down box6
2
686 0
722 0
4
0 0 114 126
0 2 123 136
0 258 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_18_14 loc_17_14 loc_16_14 up box1
2
660 0
687 0
4
0 0 115 105
0 1 103 93
0 224 0 1
0 236 -1 0
1
end_operator
begin_operator
push loc_18_14 loc_17_14 loc_16_14 up box2
2
660 0
687 0
4
0 0 115 105
0 5 103 93
0 224 0 1
0 236 -1 0
1
end_operator
begin_operator
push loc_18_14 loc_17_14 loc_16_14 up box3
2
660 0
687 0
4
0 0 115 105
0 4 103 93
0 224 0 1
0 236 -1 0
1
end_operator
begin_operator
push loc_18_14 loc_17_14 loc_16_14 up box4
2
660 0
687 0
4
0 0 115 105
0 3 103 93
0 224 0 1
0 236 -1 0
1
end_operator
begin_operator
push loc_18_14 loc_17_14 loc_16_14 up box6
2
660 0
687 0
4
0 0 115 105
0 2 103 93
0 224 0 1
0 236 -1 0
1
end_operator
begin_operator
push loc_18_14 loc_18_15 loc_18_16 right box1
2
689 0
691 0
4
0 0 115 116
0 1 113 114
0 248 -1 0
0 249 0 1
1
end_operator
begin_operator
push loc_18_14 loc_18_15 loc_18_16 right box2
2
689 0
691 0
4
0 0 115 116
0 5 113 114
0 248 -1 0
0 249 0 1
1
end_operator
begin_operator
push loc_18_14 loc_18_15 loc_18_16 right box3
2
689 0
691 0
4
0 0 115 116
0 4 113 114
0 248 -1 0
0 249 0 1
1
end_operator
begin_operator
push loc_18_14 loc_18_15 loc_18_16 right box4
2
689 0
691 0
4
0 0 115 116
0 3 113 114
0 248 -1 0
0 249 0 1
1
end_operator
begin_operator
push loc_18_14 loc_18_15 loc_18_16 right box6
2
689 0
691 0
4
0 0 115 116
0 2 113 114
0 248 -1 0
0 249 0 1
1
end_operator
begin_operator
push loc_18_15 loc_18_14 loc_18_13 left box1
2
688 0
690 0
4
0 0 116 115
0 1 112 111
0 246 0 1
0 247 -1 0
1
end_operator
begin_operator
push loc_18_15 loc_18_14 loc_18_13 left box2
2
688 0
690 0
4
0 0 116 115
0 5 112 111
0 246 0 1
0 247 -1 0
1
end_operator
begin_operator
push loc_18_15 loc_18_14 loc_18_13 left box3
2
688 0
690 0
4
0 0 116 115
0 4 112 111
0 246 0 1
0 247 -1 0
1
end_operator
begin_operator
push loc_18_15 loc_18_14 loc_18_13 left box4
2
688 0
690 0
4
0 0 116 115
0 3 112 111
0 246 0 1
0 247 -1 0
1
end_operator
begin_operator
push loc_18_15 loc_18_14 loc_18_13 left box6
2
688 0
690 0
4
0 0 116 115
0 2 112 111
0 246 0 1
0 247 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_18_15 loc_18_14 left box1
2
690 0
693 0
4
0 0 117 116
0 1 113 112
0 247 0 1
0 248 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_18_15 loc_18_14 left box2
2
690 0
693 0
4
0 0 117 116
0 5 113 112
0 247 0 1
0 248 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_18_15 loc_18_14 left box3
2
690 0
693 0
4
0 0 117 116
0 4 113 112
0 247 0 1
0 248 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_18_15 loc_18_14 left box4
2
690 0
693 0
4
0 0 117 116
0 3 113 112
0 247 0 1
0 248 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_18_15 loc_18_14 left box6
2
690 0
693 0
4
0 0 117 116
0 2 113 112
0 247 0 1
0 248 -1 0
1
end_operator
begin_operator
push loc_18_16 loc_19_16 loc_20_16 down box1
2
694 0
725 0
4
0 0 117 127
0 1 124 139
0 259 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_18_16 loc_19_16 loc_20_16 down box2
2
694 0
725 0
4
0 0 117 127
0 5 124 139
0 259 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_18_16 loc_19_16 loc_20_16 down box3
2
694 0
725 0
4
0 0 117 127
0 4 124 139
0 259 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_18_16 loc_19_16 loc_20_16 down box4
2
694 0
725 0
4
0 0 117 127
0 3 124 139
0 259 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_18_16 loc_19_16 loc_20_16 down box6
2
694 0
725 0
4
0 0 117 127
0 2 124 139
0 259 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_18_19 loc_17_19 loc_16_19 up box1
2
666 0
695 0
4
0 0 118 108
0 1 105 94
0 225 0 1
0 239 -1 0
1
end_operator
begin_operator
push loc_18_19 loc_17_19 loc_16_19 up box2
2
666 0
695 0
4
0 0 118 108
0 5 105 94
0 225 0 1
0 239 -1 0
1
end_operator
begin_operator
push loc_18_19 loc_17_19 loc_16_19 up box3
2
666 0
695 0
4
0 0 118 108
0 4 105 94
0 225 0 1
0 239 -1 0
1
end_operator
begin_operator
push loc_18_19 loc_17_19 loc_16_19 up box4
2
666 0
695 0
4
0 0 118 108
0 3 105 94
0 225 0 1
0 239 -1 0
1
end_operator
begin_operator
push loc_18_19 loc_17_19 loc_16_19 up box6
2
666 0
695 0
4
0 0 118 108
0 2 105 94
0 225 0 1
0 239 -1 0
1
end_operator
begin_operator
push loc_18_19 loc_19_19 loc_20_19 down box1
2
697 0
730 0
4
0 0 118 129
0 1 126 142
0 261 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_18_19 loc_19_19 loc_20_19 down box2
2
697 0
730 0
4
0 0 118 129
0 5 126 142
0 261 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_18_19 loc_19_19 loc_20_19 down box3
2
697 0
730 0
4
0 0 118 129
0 4 126 142
0 261 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_18_19 loc_19_19 loc_20_19 down box4
2
697 0
730 0
4
0 0 118 129
0 3 126 142
0 261 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_18_19 loc_19_19 loc_20_19 down box6
2
697 0
730 0
4
0 0 118 129
0 2 126 142
0 261 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box1
2
669 0
698 0
4
0 0 119 109
0 1 106 95
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box2
2
669 0
698 0
4
0 0 119 109
0 5 106 95
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box3
2
669 0
698 0
4
0 0 119 109
0 4 106 95
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box4
2
669 0
698 0
4
0 0 119 109
0 3 106 95
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box5
2
669 0
698 0
4
0 0 119 109
0 7 8 7
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_20 loc_17_20 loc_16_20 up box6
2
669 0
698 0
4
0 0 119 109
0 2 106 95
0 227 0 1
0 240 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_18_7 loc_18_8 right box1
2
701 0
705 0
4
0 0 120 121
0 1 118 119
0 253 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_18_6 loc_18_7 loc_18_8 right box2
2
701 0
705 0
4
0 0 120 121
0 5 118 119
0 253 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_18_6 loc_18_7 loc_18_8 right box3
2
701 0
705 0
4
0 0 120 121
0 4 118 119
0 253 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_18_6 loc_18_7 loc_18_8 right box4
2
701 0
705 0
4
0 0 120 121
0 3 118 119
0 253 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_18_6 loc_18_7 loc_18_8 right box6
2
701 0
705 0
4
0 0 120 121
0 2 118 119
0 253 -1 0
0 254 0 1
1
end_operator
begin_operator
push loc_18_6 loc_19_6 loc_20_6 down box1
2
702 0
737 0
4
0 0 120 132
0 1 129 144
0 265 -1 0
0 280 0 1
1
end_operator
begin_operator
push loc_18_6 loc_19_6 loc_20_6 down box2
2
702 0
737 0
4
0 0 120 132
0 5 129 144
0 265 -1 0
0 280 0 1
1
end_operator
begin_operator
push loc_18_6 loc_19_6 loc_20_6 down box3
2
702 0
737 0
4
0 0 120 132
0 4 129 144
0 265 -1 0
0 280 0 1
1
end_operator
begin_operator
push loc_18_6 loc_19_6 loc_20_6 down box4
2
702 0
737 0
4
0 0 120 132
0 3 129 144
0 265 -1 0
0 280 0 1
1
end_operator
begin_operator
push loc_18_6 loc_19_6 loc_20_6 down box6
2
702 0
737 0
4
0 0 120 132
0 2 129 144
0 265 -1 0
0 280 0 1
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box1
2
673 0
703 0
4
0 0 121 110
0 1 107 98
0 231 0 1
0 242 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box2
2
673 0
703 0
4
0 0 121 110
0 5 107 98
0 231 0 1
0 242 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box3
2
673 0
703 0
4
0 0 121 110
0 4 107 98
0 231 0 1
0 242 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box4
2
673 0
703 0
4
0 0 121 110
0 3 107 98
0 231 0 1
0 242 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box6
2
673 0
703 0
4
0 0 121 110
0 2 107 98
0 231 0 1
0 242 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_18_8 loc_18_9 right box1
2
705 0
709 0
4
0 0 121 122
0 1 119 120
0 254 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_7 loc_18_8 loc_18_9 right box2
2
705 0
709 0
4
0 0 121 122
0 5 119 120
0 254 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_7 loc_18_8 loc_18_9 right box3
2
705 0
709 0
4
0 0 121 122
0 4 119 120
0 254 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_7 loc_18_8 loc_18_9 right box4
2
705 0
709 0
4
0 0 121 122
0 3 119 120
0 254 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_7 loc_18_8 loc_18_9 right box6
2
705 0
709 0
4
0 0 121 122
0 2 119 120
0 254 -1 0
0 255 0 1
1
end_operator
begin_operator
push loc_18_7 loc_19_7 loc_20_7 down box1
2
706 0
741 0
4
0 0 121 133
0 1 130 145
0 266 -1 0
0 281 0 1
1
end_operator
begin_operator
push loc_18_7 loc_19_7 loc_20_7 down box2
2
706 0
741 0
4
0 0 121 133
0 5 130 145
0 266 -1 0
0 281 0 1
1
end_operator
begin_operator
push loc_18_7 loc_19_7 loc_20_7 down box3
2
706 0
741 0
4
0 0 121 133
0 4 130 145
0 266 -1 0
0 281 0 1
1
end_operator
begin_operator
push loc_18_7 loc_19_7 loc_20_7 down box4
2
706 0
741 0
4
0 0 121 133
0 3 130 145
0 266 -1 0
0 281 0 1
1
end_operator
begin_operator
push loc_18_7 loc_19_7 loc_20_7 down box6
2
706 0
741 0
4
0 0 121 133
0 2 130 145
0 266 -1 0
0 281 0 1
1
end_operator
begin_operator
push loc_18_8 loc_17_8 loc_16_8 up box1
2
676 0
707 0
4
0 0 122 111
0 1 108 99
0 232 0 1
0 243 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_17_8 loc_16_8 up box2
2
676 0
707 0
4
0 0 122 111
0 5 108 99
0 232 0 1
0 243 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_17_8 loc_16_8 up box3
2
676 0
707 0
4
0 0 122 111
0 4 108 99
0 232 0 1
0 243 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_17_8 loc_16_8 up box4
2
676 0
707 0
4
0 0 122 111
0 3 108 99
0 232 0 1
0 243 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_17_8 loc_16_8 up box6
2
676 0
707 0
4
0 0 122 111
0 2 108 99
0 232 0 1
0 243 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_7 loc_18_6 left box1
2
704 0
708 0
4
0 0 122 121
0 1 118 117
0 252 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_7 loc_18_6 left box2
2
704 0
708 0
4
0 0 122 121
0 5 118 117
0 252 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_7 loc_18_6 left box3
2
704 0
708 0
4
0 0 122 121
0 4 118 117
0 252 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_7 loc_18_6 left box4
2
704 0
708 0
4
0 0 122 121
0 3 118 117
0 252 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_7 loc_18_6 left box6
2
704 0
708 0
4
0 0 122 121
0 2 118 117
0 252 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_9 loc_18_10 right box1
2
709 0
711 0
4
0 0 122 123
0 1 120 109
0 244 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_9 loc_18_10 right box2
2
709 0
711 0
4
0 0 122 123
0 5 120 109
0 244 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_9 loc_18_10 right box3
2
709 0
711 0
4
0 0 122 123
0 4 120 109
0 244 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_9 loc_18_10 right box4
2
709 0
711 0
4
0 0 122 123
0 3 120 109
0 244 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_18_9 loc_18_10 right box6
2
709 0
711 0
4
0 0 122 123
0 2 120 109
0 244 0 1
0 255 -1 0
1
end_operator
begin_operator
push loc_18_8 loc_19_8 loc_20_8 down box1
2
710 0
745 0
4
0 0 122 134
0 1 131 146
0 267 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_18_8 loc_19_8 loc_20_8 down box2
2
710 0
745 0
4
0 0 122 134
0 5 131 146
0 267 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_18_8 loc_19_8 loc_20_8 down box3
2
710 0
745 0
4
0 0 122 134
0 4 131 146
0 267 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_18_8 loc_19_8 loc_20_8 down box4
2
710 0
745 0
4
0 0 122 134
0 3 131 146
0 267 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_18_8 loc_19_8 loc_20_8 down box6
2
710 0
745 0
4
0 0 122 134
0 2 131 146
0 267 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_10 loc_18_11 right box1
2
680 0
711 0
4
0 0 123 112
0 1 109 110
0 244 -1 0
0 245 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_10 loc_18_11 right box2
2
680 0
711 0
4
0 0 123 112
0 5 109 110
0 244 -1 0
0 245 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_10 loc_18_11 right box3
2
680 0
711 0
4
0 0 123 112
0 4 109 110
0 244 -1 0
0 245 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_10 loc_18_11 right box4
2
680 0
711 0
4
0 0 123 112
0 3 109 110
0 244 -1 0
0 245 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_10 loc_18_11 right box6
2
680 0
711 0
4
0 0 123 112
0 2 109 110
0 244 -1 0
0 245 0 1
1
end_operator
begin_operator
push loc_18_9 loc_18_8 loc_18_7 left box1
2
708 0
712 0
4
0 0 123 122
0 1 119 118
0 253 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_18_9 loc_18_8 loc_18_7 left box2
2
708 0
712 0
4
0 0 123 122
0 5 119 118
0 253 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_18_9 loc_18_8 loc_18_7 left box3
2
708 0
712 0
4
0 0 123 122
0 4 119 118
0 253 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_18_9 loc_18_8 loc_18_7 left box4
2
708 0
712 0
4
0 0 123 122
0 3 119 118
0 253 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_18_9 loc_18_8 loc_18_7 left box6
2
708 0
712 0
4
0 0 123 122
0 2 119 118
0 253 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_18_9 loc_19_9 loc_20_9 down box1
2
713 0
748 0
4
0 0 123 135
0 1 132 147
0 268 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_18_9 loc_19_9 loc_20_9 down box2
2
713 0
748 0
4
0 0 123 135
0 5 132 147
0 268 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_18_9 loc_19_9 loc_20_9 down box3
2
713 0
748 0
4
0 0 123 135
0 4 132 147
0 268 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_18_9 loc_19_9 loc_20_9 down box4
2
713 0
748 0
4
0 0 123 135
0 3 132 147
0 268 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_18_9 loc_19_9 loc_20_9 down box6
2
713 0
748 0
4
0 0 123 135
0 2 132 147
0 268 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_19_11 loc_19_12 loc_19_13 right box1
2
715 0
718 0
4
0 0 124 125
0 1 122 123
0 257 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_19_11 loc_19_12 loc_19_13 right box2
2
715 0
718 0
4
0 0 124 125
0 5 122 123
0 257 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_19_11 loc_19_12 loc_19_13 right box3
2
715 0
718 0
4
0 0 124 125
0 4 122 123
0 257 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_19_11 loc_19_12 loc_19_13 right box4
2
715 0
718 0
4
0 0 124 125
0 3 122 123
0 257 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_19_11 loc_19_12 loc_19_13 right box6
2
715 0
718 0
4
0 0 124 125
0 2 122 123
0 257 -1 0
0 258 0 1
1
end_operator
begin_operator
push loc_19_11 loc_20_11 loc_21_11 down box1
2
716 0
755 0
4
0 0 124 137
0 1 134 149
0 270 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_19_11 loc_20_11 loc_21_11 down box2
2
716 0
755 0
4
0 0 124 137
0 5 134 149
0 270 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_19_11 loc_20_11 loc_21_11 down box3
2
716 0
755 0
4
0 0 124 137
0 4 134 149
0 270 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_19_11 loc_20_11 loc_21_11 down box4
2
716 0
755 0
4
0 0 124 137
0 3 134 149
0 270 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_19_11 loc_20_11 loc_21_11 down box6
2
716 0
755 0
4
0 0 124 137
0 2 134 149
0 270 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_19_12 loc_20_12 loc_21_12 down box1
2
719 0
759 0
4
0 0 125 138
0 1 135 150
0 8 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_19_12 loc_20_12 loc_21_12 down box2
2
719 0
759 0
4
0 0 125 138
0 5 135 150
0 8 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_19_12 loc_20_12 loc_21_12 down box3
2
719 0
759 0
4
0 0 125 138
0 4 135 150
0 8 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_19_12 loc_20_12 loc_21_12 down box4
2
719 0
759 0
4
0 0 125 138
0 3 135 150
0 8 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_19_12 loc_20_12 loc_21_12 down box6
2
719 0
759 0
4
0 0 125 138
0 2 135 150
0 8 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_18_13 loc_17_13 up box1
2
684 0
720 0
4
0 0 126 114
0 1 111 102
0 235 0 1
0 246 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_18_13 loc_17_13 up box2
2
684 0
720 0
4
0 0 126 114
0 5 111 102
0 235 0 1
0 246 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_18_13 loc_17_13 up box3
2
684 0
720 0
4
0 0 126 114
0 4 111 102
0 235 0 1
0 246 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_18_13 loc_17_13 up box4
2
684 0
720 0
4
0 0 126 114
0 3 111 102
0 235 0 1
0 246 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_18_13 loc_17_13 up box6
2
684 0
720 0
4
0 0 126 114
0 2 111 102
0 235 0 1
0 246 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_19_12 loc_19_11 left box1
2
717 0
721 0
4
0 0 126 125
0 1 122 121
0 256 0 1
0 257 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_19_12 loc_19_11 left box2
2
717 0
721 0
4
0 0 126 125
0 5 122 121
0 256 0 1
0 257 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_19_12 loc_19_11 left box3
2
717 0
721 0
4
0 0 126 125
0 4 122 121
0 256 0 1
0 257 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_19_12 loc_19_11 left box4
2
717 0
721 0
4
0 0 126 125
0 3 122 121
0 256 0 1
0 257 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_19_12 loc_19_11 left box6
2
717 0
721 0
4
0 0 126 125
0 2 122 121
0 256 0 1
0 257 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_20_13 loc_21_13 down box1
2
722 0
763 0
4
0 0 126 139
0 1 136 151
0 9 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_20_13 loc_21_13 down box2
2
722 0
763 0
4
0 0 126 139
0 5 136 151
0 9 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_20_13 loc_21_13 down box3
2
722 0
763 0
4
0 0 126 139
0 4 136 151
0 9 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_20_13 loc_21_13 down box4
2
722 0
763 0
4
0 0 126 139
0 3 136 151
0 9 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_19_13 loc_20_13 loc_21_13 down box6
2
722 0
763 0
4
0 0 126 139
0 2 136 151
0 9 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_18_16 loc_17_16 up box1
2
692 0
723 0
4
0 0 127 117
0 1 114 104
0 237 0 1
0 249 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_18_16 loc_17_16 up box2
2
692 0
723 0
4
0 0 127 117
0 5 114 104
0 237 0 1
0 249 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_18_16 loc_17_16 up box3
2
692 0
723 0
4
0 0 127 117
0 4 114 104
0 237 0 1
0 249 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_18_16 loc_17_16 up box4
2
692 0
723 0
4
0 0 127 117
0 3 114 104
0 237 0 1
0 249 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_18_16 loc_17_16 up box6
2
692 0
723 0
4
0 0 127 117
0 2 114 104
0 237 0 1
0 249 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_20_16 loc_21_16 down box1
2
725 0
771 0
4
0 0 127 142
0 1 139 152
0 10 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_20_16 loc_21_16 down box2
2
725 0
771 0
4
0 0 127 142
0 5 139 152
0 10 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_20_16 loc_21_16 down box3
2
725 0
771 0
4
0 0 127 142
0 4 139 152
0 10 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_20_16 loc_21_16 down box4
2
725 0
771 0
4
0 0 127 142
0 3 139 152
0 10 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_19_16 loc_20_16 loc_21_16 down box6
2
725 0
771 0
4
0 0 127 142
0 2 139 152
0 10 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_19_17 loc_20_17 loc_21_17 down box1
2
727 0
775 0
4
0 0 128 143
0 1 140 153
0 11 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_19_17 loc_20_17 loc_21_17 down box2
2
727 0
775 0
4
0 0 128 143
0 5 140 153
0 11 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_19_17 loc_20_17 loc_21_17 down box3
2
727 0
775 0
4
0 0 128 143
0 4 140 153
0 11 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_19_17 loc_20_17 loc_21_17 down box4
2
727 0
775 0
4
0 0 128 143
0 3 140 153
0 11 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_19_17 loc_20_17 loc_21_17 down box6
2
727 0
775 0
4
0 0 128 143
0 2 140 153
0 11 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_18_19 loc_17_19 up box1
2
695 0
728 0
4
0 0 129 118
0 1 115 105
0 239 0 1
0 250 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_18_19 loc_17_19 up box2
2
695 0
728 0
4
0 0 129 118
0 5 115 105
0 239 0 1
0 250 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_18_19 loc_17_19 up box3
2
695 0
728 0
4
0 0 129 118
0 4 115 105
0 239 0 1
0 250 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_18_19 loc_17_19 up box4
2
695 0
728 0
4
0 0 129 118
0 3 115 105
0 239 0 1
0 250 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_18_19 loc_17_19 up box6
2
695 0
728 0
4
0 0 129 118
0 2 115 105
0 239 0 1
0 250 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box1
2
729 0
733 0
4
0 0 129 130
0 1 127 128
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box2
2
729 0
733 0
4
0 0 129 130
0 5 127 128
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box3
2
729 0
733 0
4
0 0 129 130
0 4 127 128
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box4
2
729 0
733 0
4
0 0 129 130
0 3 127 128
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box5
2
729 0
733 0
4
0 0 129 130
0 7 10 11
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_19_20 loc_19_21 right box6
2
729 0
733 0
4
0 0 129 130
0 2 127 128
0 263 -1 0
0 264 0 1
1
end_operator
begin_operator
push loc_19_19 loc_20_19 loc_21_19 down box1
2
730 0
781 0
4
0 0 129 145
0 1 142 155
0 13 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_20_19 loc_21_19 down box2
2
730 0
781 0
4
0 0 129 145
0 5 142 155
0 13 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_20_19 loc_21_19 down box3
2
730 0
781 0
4
0 0 129 145
0 4 142 155
0 13 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_20_19 loc_21_19 down box4
2
730 0
781 0
4
0 0 129 145
0 3 142 155
0 13 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_19_19 loc_20_19 loc_21_19 down box6
2
730 0
781 0
4
0 0 129 145
0 2 142 155
0 13 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box1
2
698 0
731 0
4
0 0 130 119
0 1 116 106
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box2
2
698 0
731 0
4
0 0 130 119
0 5 116 106
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box3
2
698 0
731 0
4
0 0 130 119
0 4 116 106
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box4
2
698 0
731 0
4
0 0 130 119
0 3 116 106
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box5
2
698 0
731 0
4
0 0 130 119
0 7 9 8
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_20 loc_18_20 loc_17_20 up box6
2
698 0
731 0
4
0 0 130 119
0 2 116 106
0 240 0 1
0 251 -1 0
1
end_operator
begin_operator
push loc_19_6 loc_19_7 loc_19_8 right box1
2
736 0
740 0
4
0 0 132 133
0 1 130 131
0 266 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_19_6 loc_19_7 loc_19_8 right box2
2
736 0
740 0
4
0 0 132 133
0 5 130 131
0 266 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_19_6 loc_19_7 loc_19_8 right box3
2
736 0
740 0
4
0 0 132 133
0 4 130 131
0 266 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_19_6 loc_19_7 loc_19_8 right box4
2
736 0
740 0
4
0 0 132 133
0 3 130 131
0 266 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_19_6 loc_19_7 loc_19_8 right box6
2
736 0
740 0
4
0 0 132 133
0 2 130 131
0 266 -1 0
0 267 0 1
1
end_operator
begin_operator
push loc_19_7 loc_18_7 loc_17_7 up box1
2
703 0
738 0
4
0 0 133 121
0 1 118 107
0 242 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_19_7 loc_18_7 loc_17_7 up box2
2
703 0
738 0
4
0 0 133 121
0 5 118 107
0 242 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_19_7 loc_18_7 loc_17_7 up box3
2
703 0
738 0
4
0 0 133 121
0 4 118 107
0 242 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_19_7 loc_18_7 loc_17_7 up box4
2
703 0
738 0
4
0 0 133 121
0 3 118 107
0 242 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_19_7 loc_18_7 loc_17_7 up box6
2
703 0
738 0
4
0 0 133 121
0 2 118 107
0 242 0 1
0 253 -1 0
1
end_operator
begin_operator
push loc_19_7 loc_19_8 loc_19_9 right box1
2
740 0
744 0
4
0 0 133 134
0 1 131 132
0 267 -1 0
0 268 0 1
1
end_operator
begin_operator
push loc_19_7 loc_19_8 loc_19_9 right box2
2
740 0
744 0
4
0 0 133 134
0 5 131 132
0 267 -1 0
0 268 0 1
1
end_operator
begin_operator
push loc_19_7 loc_19_8 loc_19_9 right box3
2
740 0
744 0
4
0 0 133 134
0 4 131 132
0 267 -1 0
0 268 0 1
1
end_operator
begin_operator
push loc_19_7 loc_19_8 loc_19_9 right box4
2
740 0
744 0
4
0 0 133 134
0 3 131 132
0 267 -1 0
0 268 0 1
1
end_operator
begin_operator
push loc_19_7 loc_19_8 loc_19_9 right box6
2
740 0
744 0
4
0 0 133 134
0 2 131 132
0 267 -1 0
0 268 0 1
1
end_operator
begin_operator
push loc_19_8 loc_18_8 loc_17_8 up box1
2
707 0
742 0
4
0 0 134 122
0 1 119 108
0 243 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_18_8 loc_17_8 up box2
2
707 0
742 0
4
0 0 134 122
0 5 119 108
0 243 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_18_8 loc_17_8 up box3
2
707 0
742 0
4
0 0 134 122
0 4 119 108
0 243 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_18_8 loc_17_8 up box4
2
707 0
742 0
4
0 0 134 122
0 3 119 108
0 243 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_18_8 loc_17_8 up box6
2
707 0
742 0
4
0 0 134 122
0 2 119 108
0 243 0 1
0 254 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_19_7 loc_19_6 left box1
2
739 0
743 0
4
0 0 134 133
0 1 130 129
0 265 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_19_7 loc_19_6 left box2
2
739 0
743 0
4
0 0 134 133
0 5 130 129
0 265 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_19_7 loc_19_6 left box3
2
739 0
743 0
4
0 0 134 133
0 4 130 129
0 265 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_19_7 loc_19_6 left box4
2
739 0
743 0
4
0 0 134 133
0 3 130 129
0 265 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_19_7 loc_19_6 left box6
2
739 0
743 0
4
0 0 134 133
0 2 130 129
0 265 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_20_8 loc_21_8 down box1
2
745 0
792 0
4
0 0 134 149
0 1 146 157
0 16 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_20_8 loc_21_8 down box2
2
745 0
792 0
4
0 0 134 149
0 5 146 157
0 16 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_20_8 loc_21_8 down box3
2
745 0
792 0
4
0 0 134 149
0 4 146 157
0 16 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_20_8 loc_21_8 down box4
2
745 0
792 0
4
0 0 134 149
0 3 146 157
0 16 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_19_8 loc_20_8 loc_21_8 down box6
2
745 0
792 0
4
0 0 134 149
0 2 146 157
0 16 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_19_8 loc_19_7 left box1
2
743 0
747 0
4
0 0 135 134
0 1 131 130
0 266 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_19_8 loc_19_7 left box2
2
743 0
747 0
4
0 0 135 134
0 5 131 130
0 266 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_19_8 loc_19_7 left box3
2
743 0
747 0
4
0 0 135 134
0 4 131 130
0 266 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_19_8 loc_19_7 left box4
2
743 0
747 0
4
0 0 135 134
0 3 131 130
0 266 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_19_8 loc_19_7 left box6
2
743 0
747 0
4
0 0 135 134
0 2 131 130
0 266 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_20_9 loc_21_9 down box1
2
748 0
796 0
4
0 0 135 150
0 1 147 158
0 17 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_20_9 loc_21_9 down box2
2
748 0
796 0
4
0 0 135 150
0 5 147 158
0 17 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_20_9 loc_21_9 down box3
2
748 0
796 0
4
0 0 135 150
0 4 147 158
0 17 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_20_9 loc_21_9 down box4
2
748 0
796 0
4
0 0 135 150
0 3 147 158
0 17 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_19_9 loc_20_9 loc_21_9 down box6
2
748 0
796 0
4
0 0 135 150
0 2 147 158
0 17 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_10 loc_20_11 loc_20_12 right box1
2
749 0
754 0
4
0 0 136 137
0 1 134 135
0 270 -1 0
0 271 0 1
1
end_operator
begin_operator
push loc_20_10 loc_20_11 loc_20_12 right box2
2
749 0
754 0
4
0 0 136 137
0 5 134 135
0 270 -1 0
0 271 0 1
1
end_operator
begin_operator
push loc_20_10 loc_20_11 loc_20_12 right box3
2
749 0
754 0
4
0 0 136 137
0 4 134 135
0 270 -1 0
0 271 0 1
1
end_operator
begin_operator
push loc_20_10 loc_20_11 loc_20_12 right box4
2
749 0
754 0
4
0 0 136 137
0 3 134 135
0 270 -1 0
0 271 0 1
1
end_operator
begin_operator
push loc_20_10 loc_20_11 loc_20_12 right box6
2
749 0
754 0
4
0 0 136 137
0 2 134 135
0 270 -1 0
0 271 0 1
1
end_operator
begin_operator
push loc_20_10 loc_20_9 loc_20_8 left box1
2
750 0
795 0
4
0 0 136 150
0 1 147 146
0 282 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_10 loc_20_9 loc_20_8 left box2
2
750 0
795 0
4
0 0 136 150
0 5 147 146
0 282 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_10 loc_20_9 loc_20_8 left box3
2
750 0
795 0
4
0 0 136 150
0 4 147 146
0 282 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_10 loc_20_9 loc_20_8 left box4
2
750 0
795 0
4
0 0 136 150
0 3 147 146
0 282 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_10 loc_20_9 loc_20_8 left box6
2
750 0
795 0
4
0 0 136 150
0 2 147 146
0 282 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_19_11 loc_18_11 up box1
2
714 0
752 0
4
0 0 137 124
0 1 121 110
0 245 0 1
0 256 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_19_11 loc_18_11 up box2
2
714 0
752 0
4
0 0 137 124
0 5 121 110
0 245 0 1
0 256 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_19_11 loc_18_11 up box3
2
714 0
752 0
4
0 0 137 124
0 4 121 110
0 245 0 1
0 256 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_19_11 loc_18_11 up box4
2
714 0
752 0
4
0 0 137 124
0 3 121 110
0 245 0 1
0 256 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_19_11 loc_18_11 up box6
2
714 0
752 0
4
0 0 137 124
0 2 121 110
0 245 0 1
0 256 -1 0
1
end_operator
begin_operator
push loc_20_11 loc_20_10 loc_20_9 left box1
2
750 0
753 0
4
0 0 137 136
0 1 133 147
0 269 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_10 loc_20_9 left box2
2
750 0
753 0
4
0 0 137 136
0 5 133 147
0 269 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_10 loc_20_9 left box3
2
750 0
753 0
4
0 0 137 136
0 4 133 147
0 269 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_10 loc_20_9 left box4
2
750 0
753 0
4
0 0 137 136
0 3 133 147
0 269 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_10 loc_20_9 left box6
2
750 0
753 0
4
0 0 137 136
0 2 133 147
0 269 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_12 loc_20_13 right box1
2
754 0
758 0
4
0 0 137 138
0 1 135 136
0 271 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_12 loc_20_13 right box2
2
754 0
758 0
4
0 0 137 138
0 5 135 136
0 271 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_12 loc_20_13 right box3
2
754 0
758 0
4
0 0 137 138
0 4 135 136
0 271 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_12 loc_20_13 right box4
2
754 0
758 0
4
0 0 137 138
0 3 135 136
0 271 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_20_11 loc_20_12 loc_20_13 right box6
2
754 0
758 0
4
0 0 137 138
0 2 135 136
0 271 -1 0
0 272 0 1
1
end_operator
begin_operator
push loc_20_12 loc_20_11 loc_20_10 left box1
2
753 0
757 0
4
0 0 138 137
0 1 134 133
0 269 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_20_12 loc_20_11 loc_20_10 left box2
2
753 0
757 0
4
0 0 138 137
0 5 134 133
0 269 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_20_12 loc_20_11 loc_20_10 left box3
2
753 0
757 0
4
0 0 138 137
0 4 134 133
0 269 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_20_12 loc_20_11 loc_20_10 left box4
2
753 0
757 0
4
0 0 138 137
0 3 134 133
0 269 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_20_12 loc_20_11 loc_20_10 left box6
2
753 0
757 0
4
0 0 138 137
0 2 134 133
0 269 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_20_12 loc_20_13 loc_20_14 right box1
2
758 0
762 0
4
0 0 138 139
0 1 136 137
0 272 -1 0
0 273 0 1
1
end_operator
begin_operator
push loc_20_12 loc_20_13 loc_20_14 right box2
2
758 0
762 0
4
0 0 138 139
0 5 136 137
0 272 -1 0
0 273 0 1
1
end_operator
begin_operator
push loc_20_12 loc_20_13 loc_20_14 right box3
2
758 0
762 0
4
0 0 138 139
0 4 136 137
0 272 -1 0
0 273 0 1
1
end_operator
begin_operator
push loc_20_12 loc_20_13 loc_20_14 right box4
2
758 0
762 0
4
0 0 138 139
0 3 136 137
0 272 -1 0
0 273 0 1
1
end_operator
begin_operator
push loc_20_12 loc_20_13 loc_20_14 right box6
2
758 0
762 0
4
0 0 138 139
0 2 136 137
0 272 -1 0
0 273 0 1
1
end_operator
begin_operator
push loc_20_13 loc_19_13 loc_18_13 up box1
2
720 0
760 0
4
0 0 139 126
0 1 123 111
0 246 0 1
0 258 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_19_13 loc_18_13 up box2
2
720 0
760 0
4
0 0 139 126
0 5 123 111
0 246 0 1
0 258 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_19_13 loc_18_13 up box3
2
720 0
760 0
4
0 0 139 126
0 4 123 111
0 246 0 1
0 258 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_19_13 loc_18_13 up box4
2
720 0
760 0
4
0 0 139 126
0 3 123 111
0 246 0 1
0 258 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_19_13 loc_18_13 up box6
2
720 0
760 0
4
0 0 139 126
0 2 123 111
0 246 0 1
0 258 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_12 loc_20_11 left box1
2
757 0
761 0
4
0 0 139 138
0 1 135 134
0 270 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_12 loc_20_11 left box2
2
757 0
761 0
4
0 0 139 138
0 5 135 134
0 270 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_12 loc_20_11 left box3
2
757 0
761 0
4
0 0 139 138
0 4 135 134
0 270 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_12 loc_20_11 left box4
2
757 0
761 0
4
0 0 139 138
0 3 135 134
0 270 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_12 loc_20_11 left box6
2
757 0
761 0
4
0 0 139 138
0 2 135 134
0 270 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_20_13 loc_20_14 loc_20_15 right box1
2
762 0
765 0
4
0 0 139 140
0 1 137 138
0 273 -1 0
0 274 0 1
1
end_operator
begin_operator
push loc_20_13 loc_20_14 loc_20_15 right box2
2
762 0
765 0
4
0 0 139 140
0 5 137 138
0 273 -1 0
0 274 0 1
1
end_operator
begin_operator
push loc_20_13 loc_20_14 loc_20_15 right box3
2
762 0
765 0
4
0 0 139 140
0 4 137 138
0 273 -1 0
0 274 0 1
1
end_operator
begin_operator
push loc_20_13 loc_20_14 loc_20_15 right box4
2
762 0
765 0
4
0 0 139 140
0 3 137 138
0 273 -1 0
0 274 0 1
1
end_operator
begin_operator
push loc_20_13 loc_20_14 loc_20_15 right box6
2
762 0
765 0
4
0 0 139 140
0 2 137 138
0 273 -1 0
0 274 0 1
1
end_operator
begin_operator
push loc_20_14 loc_20_13 loc_20_12 left box1
2
761 0
764 0
4
0 0 140 139
0 1 136 135
0 271 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_20_14 loc_20_13 loc_20_12 left box2
2
761 0
764 0
4
0 0 140 139
0 5 136 135
0 271 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_20_14 loc_20_13 loc_20_12 left box3
2
761 0
764 0
4
0 0 140 139
0 4 136 135
0 271 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_20_14 loc_20_13 loc_20_12 left box4
2
761 0
764 0
4
0 0 140 139
0 3 136 135
0 271 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_20_14 loc_20_13 loc_20_12 left box6
2
761 0
764 0
4
0 0 140 139
0 2 136 135
0 271 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_20_14 loc_20_15 loc_20_16 right box1
2
765 0
767 0
4
0 0 140 141
0 1 138 139
0 274 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_20_14 loc_20_15 loc_20_16 right box2
2
765 0
767 0
4
0 0 140 141
0 5 138 139
0 274 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_20_14 loc_20_15 loc_20_16 right box3
2
765 0
767 0
4
0 0 140 141
0 4 138 139
0 274 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_20_14 loc_20_15 loc_20_16 right box4
2
765 0
767 0
4
0 0 140 141
0 3 138 139
0 274 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_20_14 loc_20_15 loc_20_16 right box6
2
765 0
767 0
4
0 0 140 141
0 2 138 139
0 274 -1 0
0 275 0 1
1
end_operator
begin_operator
push loc_20_15 loc_20_14 loc_20_13 left box1
2
764 0
766 0
4
0 0 141 140
0 1 137 136
0 272 0 1
0 273 -1 0
1
end_operator
begin_operator
push loc_20_15 loc_20_14 loc_20_13 left box2
2
764 0
766 0
4
0 0 141 140
0 5 137 136
0 272 0 1
0 273 -1 0
1
end_operator
begin_operator
push loc_20_15 loc_20_14 loc_20_13 left box3
2
764 0
766 0
4
0 0 141 140
0 4 137 136
0 272 0 1
0 273 -1 0
1
end_operator
begin_operator
push loc_20_15 loc_20_14 loc_20_13 left box4
2
764 0
766 0
4
0 0 141 140
0 3 137 136
0 272 0 1
0 273 -1 0
1
end_operator
begin_operator
push loc_20_15 loc_20_14 loc_20_13 left box6
2
764 0
766 0
4
0 0 141 140
0 2 137 136
0 272 0 1
0 273 -1 0
1
end_operator
begin_operator
push loc_20_15 loc_20_16 loc_20_17 right box1
2
767 0
770 0
4
0 0 141 142
0 1 139 140
0 275 -1 0
0 276 0 1
1
end_operator
begin_operator
push loc_20_15 loc_20_16 loc_20_17 right box2
2
767 0
770 0
4
0 0 141 142
0 5 139 140
0 275 -1 0
0 276 0 1
1
end_operator
begin_operator
push loc_20_15 loc_20_16 loc_20_17 right box3
2
767 0
770 0
4
0 0 141 142
0 4 139 140
0 275 -1 0
0 276 0 1
1
end_operator
begin_operator
push loc_20_15 loc_20_16 loc_20_17 right box4
2
767 0
770 0
4
0 0 141 142
0 3 139 140
0 275 -1 0
0 276 0 1
1
end_operator
begin_operator
push loc_20_15 loc_20_16 loc_20_17 right box6
2
767 0
770 0
4
0 0 141 142
0 2 139 140
0 275 -1 0
0 276 0 1
1
end_operator
begin_operator
push loc_20_16 loc_19_16 loc_18_16 up box1
2
723 0
768 0
4
0 0 142 127
0 1 124 114
0 249 0 1
0 259 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_19_16 loc_18_16 up box2
2
723 0
768 0
4
0 0 142 127
0 5 124 114
0 249 0 1
0 259 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_19_16 loc_18_16 up box3
2
723 0
768 0
4
0 0 142 127
0 4 124 114
0 249 0 1
0 259 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_19_16 loc_18_16 up box4
2
723 0
768 0
4
0 0 142 127
0 3 124 114
0 249 0 1
0 259 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_19_16 loc_18_16 up box6
2
723 0
768 0
4
0 0 142 127
0 2 124 114
0 249 0 1
0 259 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_15 loc_20_14 left box1
2
766 0
769 0
4
0 0 142 141
0 1 138 137
0 273 0 1
0 274 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_15 loc_20_14 left box2
2
766 0
769 0
4
0 0 142 141
0 5 138 137
0 273 0 1
0 274 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_15 loc_20_14 left box3
2
766 0
769 0
4
0 0 142 141
0 4 138 137
0 273 0 1
0 274 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_15 loc_20_14 left box4
2
766 0
769 0
4
0 0 142 141
0 3 138 137
0 273 0 1
0 274 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_15 loc_20_14 left box6
2
766 0
769 0
4
0 0 142 141
0 2 138 137
0 273 0 1
0 274 -1 0
1
end_operator
begin_operator
push loc_20_16 loc_20_17 loc_20_18 right box1
2
770 0
774 0
4
0 0 142 143
0 1 140 141
0 276 -1 0
0 277 0 1
1
end_operator
begin_operator
push loc_20_16 loc_20_17 loc_20_18 right box2
2
770 0
774 0
4
0 0 142 143
0 5 140 141
0 276 -1 0
0 277 0 1
1
end_operator
begin_operator
push loc_20_16 loc_20_17 loc_20_18 right box3
2
770 0
774 0
4
0 0 142 143
0 4 140 141
0 276 -1 0
0 277 0 1
1
end_operator
begin_operator
push loc_20_16 loc_20_17 loc_20_18 right box4
2
770 0
774 0
4
0 0 142 143
0 3 140 141
0 276 -1 0
0 277 0 1
1
end_operator
begin_operator
push loc_20_16 loc_20_17 loc_20_18 right box6
2
770 0
774 0
4
0 0 142 143
0 2 140 141
0 276 -1 0
0 277 0 1
1
end_operator
begin_operator
push loc_20_17 loc_20_16 loc_20_15 left box1
2
769 0
773 0
4
0 0 143 142
0 1 139 138
0 274 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_20_17 loc_20_16 loc_20_15 left box2
2
769 0
773 0
4
0 0 143 142
0 5 139 138
0 274 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_20_17 loc_20_16 loc_20_15 left box3
2
769 0
773 0
4
0 0 143 142
0 4 139 138
0 274 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_20_17 loc_20_16 loc_20_15 left box4
2
769 0
773 0
4
0 0 143 142
0 3 139 138
0 274 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_20_17 loc_20_16 loc_20_15 left box6
2
769 0
773 0
4
0 0 143 142
0 2 139 138
0 274 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_20_17 loc_20_18 loc_20_19 right box1
2
774 0
777 0
4
0 0 143 144
0 1 141 142
0 277 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_20_17 loc_20_18 loc_20_19 right box2
2
774 0
777 0
4
0 0 143 144
0 5 141 142
0 277 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_20_17 loc_20_18 loc_20_19 right box3
2
774 0
777 0
4
0 0 143 144
0 4 141 142
0 277 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_20_17 loc_20_18 loc_20_19 right box4
2
774 0
777 0
4
0 0 143 144
0 3 141 142
0 277 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_20_17 loc_20_18 loc_20_19 right box6
2
774 0
777 0
4
0 0 143 144
0 2 141 142
0 277 -1 0
0 278 0 1
1
end_operator
begin_operator
push loc_20_18 loc_20_17 loc_20_16 left box1
2
773 0
776 0
4
0 0 144 143
0 1 140 139
0 275 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_20_18 loc_20_17 loc_20_16 left box2
2
773 0
776 0
4
0 0 144 143
0 5 140 139
0 275 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_20_18 loc_20_17 loc_20_16 left box3
2
773 0
776 0
4
0 0 144 143
0 4 140 139
0 275 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_20_18 loc_20_17 loc_20_16 left box4
2
773 0
776 0
4
0 0 144 143
0 3 140 139
0 275 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_20_18 loc_20_17 loc_20_16 left box6
2
773 0
776 0
4
0 0 144 143
0 2 140 139
0 275 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_19_19 loc_18_19 up box1
2
728 0
779 0
4
0 0 145 129
0 1 126 115
0 250 0 1
0 261 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_19_19 loc_18_19 up box2
2
728 0
779 0
4
0 0 145 129
0 5 126 115
0 250 0 1
0 261 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_19_19 loc_18_19 up box3
2
728 0
779 0
4
0 0 145 129
0 4 126 115
0 250 0 1
0 261 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_19_19 loc_18_19 up box4
2
728 0
779 0
4
0 0 145 129
0 3 126 115
0 250 0 1
0 261 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_19_19 loc_18_19 up box6
2
728 0
779 0
4
0 0 145 129
0 2 126 115
0 250 0 1
0 261 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_20_18 loc_20_17 left box1
2
776 0
780 0
4
0 0 145 144
0 1 141 140
0 276 0 1
0 277 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_20_18 loc_20_17 left box2
2
776 0
780 0
4
0 0 145 144
0 5 141 140
0 276 0 1
0 277 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_20_18 loc_20_17 left box3
2
776 0
780 0
4
0 0 145 144
0 4 141 140
0 276 0 1
0 277 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_20_18 loc_20_17 left box4
2
776 0
780 0
4
0 0 145 144
0 3 141 140
0 276 0 1
0 277 -1 0
1
end_operator
begin_operator
push loc_20_19 loc_20_18 loc_20_17 left box6
2
776 0
780 0
4
0 0 145 144
0 2 141 140
0 276 0 1
0 277 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_19_6 loc_18_6 up box1
2
735 0
783 0
4
0 0 147 132
0 1 129 117
0 252 0 1
0 265 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_19_6 loc_18_6 up box2
2
735 0
783 0
4
0 0 147 132
0 5 129 117
0 252 0 1
0 265 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_19_6 loc_18_6 up box3
2
735 0
783 0
4
0 0 147 132
0 4 129 117
0 252 0 1
0 265 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_19_6 loc_18_6 up box4
2
735 0
783 0
4
0 0 147 132
0 3 129 117
0 252 0 1
0 265 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_19_6 loc_18_6 up box6
2
735 0
783 0
4
0 0 147 132
0 2 129 117
0 252 0 1
0 265 -1 0
1
end_operator
begin_operator
push loc_20_6 loc_20_7 loc_20_8 right box1
2
785 0
788 0
4
0 0 147 148
0 1 145 146
0 281 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_20_6 loc_20_7 loc_20_8 right box2
2
785 0
788 0
4
0 0 147 148
0 5 145 146
0 281 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_20_6 loc_20_7 loc_20_8 right box3
2
785 0
788 0
4
0 0 147 148
0 4 145 146
0 281 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_20_6 loc_20_7 loc_20_8 right box4
2
785 0
788 0
4
0 0 147 148
0 3 145 146
0 281 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_20_6 loc_20_7 loc_20_8 right box6
2
785 0
788 0
4
0 0 147 148
0 2 145 146
0 281 -1 0
0 282 0 1
1
end_operator
begin_operator
push loc_20_7 loc_19_7 loc_18_7 up box1
2
738 0
786 0
4
0 0 148 133
0 1 130 118
0 253 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_19_7 loc_18_7 up box2
2
738 0
786 0
4
0 0 148 133
0 5 130 118
0 253 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_19_7 loc_18_7 up box3
2
738 0
786 0
4
0 0 148 133
0 4 130 118
0 253 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_19_7 loc_18_7 up box4
2
738 0
786 0
4
0 0 148 133
0 3 130 118
0 253 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_19_7 loc_18_7 up box6
2
738 0
786 0
4
0 0 148 133
0 2 130 118
0 253 0 1
0 266 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_6 loc_20_5 left box1
2
784 0
787 0
4
0 0 148 147
0 1 144 143
0 279 0 1
0 280 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_6 loc_20_5 left box2
2
784 0
787 0
4
0 0 148 147
0 5 144 143
0 279 0 1
0 280 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_6 loc_20_5 left box3
2
784 0
787 0
4
0 0 148 147
0 4 144 143
0 279 0 1
0 280 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_6 loc_20_5 left box4
2
784 0
787 0
4
0 0 148 147
0 3 144 143
0 279 0 1
0 280 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_6 loc_20_5 left box6
2
784 0
787 0
4
0 0 148 147
0 2 144 143
0 279 0 1
0 280 -1 0
1
end_operator
begin_operator
push loc_20_7 loc_20_8 loc_20_9 right box1
2
788 0
791 0
4
0 0 148 149
0 1 146 147
0 282 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_7 loc_20_8 loc_20_9 right box2
2
788 0
791 0
4
0 0 148 149
0 5 146 147
0 282 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_7 loc_20_8 loc_20_9 right box3
2
788 0
791 0
4
0 0 148 149
0 4 146 147
0 282 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_7 loc_20_8 loc_20_9 right box4
2
788 0
791 0
4
0 0 148 149
0 3 146 147
0 282 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_7 loc_20_8 loc_20_9 right box6
2
788 0
791 0
4
0 0 148 149
0 2 146 147
0 282 -1 0
0 283 0 1
1
end_operator
begin_operator
push loc_20_8 loc_19_8 loc_18_8 up box1
2
742 0
789 0
4
0 0 149 134
0 1 131 119
0 254 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_19_8 loc_18_8 up box2
2
742 0
789 0
4
0 0 149 134
0 5 131 119
0 254 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_19_8 loc_18_8 up box3
2
742 0
789 0
4
0 0 149 134
0 4 131 119
0 254 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_19_8 loc_18_8 up box4
2
742 0
789 0
4
0 0 149 134
0 3 131 119
0 254 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_19_8 loc_18_8 up box6
2
742 0
789 0
4
0 0 149 134
0 2 131 119
0 254 0 1
0 267 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_7 loc_20_6 left box1
2
787 0
790 0
4
0 0 149 148
0 1 145 144
0 280 0 1
0 281 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_7 loc_20_6 left box2
2
787 0
790 0
4
0 0 149 148
0 5 145 144
0 280 0 1
0 281 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_7 loc_20_6 left box3
2
787 0
790 0
4
0 0 149 148
0 4 145 144
0 280 0 1
0 281 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_7 loc_20_6 left box4
2
787 0
790 0
4
0 0 149 148
0 3 145 144
0 280 0 1
0 281 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_7 loc_20_6 left box6
2
787 0
790 0
4
0 0 149 148
0 2 145 144
0 280 0 1
0 281 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_9 loc_20_10 right box1
2
791 0
794 0
4
0 0 149 150
0 1 147 133
0 269 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_9 loc_20_10 right box2
2
791 0
794 0
4
0 0 149 150
0 5 147 133
0 269 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_9 loc_20_10 right box3
2
791 0
794 0
4
0 0 149 150
0 4 147 133
0 269 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_9 loc_20_10 right box4
2
791 0
794 0
4
0 0 149 150
0 3 147 133
0 269 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_8 loc_20_9 loc_20_10 right box6
2
791 0
794 0
4
0 0 149 150
0 2 147 133
0 269 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_19_9 loc_18_9 up box1
2
746 0
793 0
4
0 0 150 135
0 1 132 120
0 255 0 1
0 268 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_19_9 loc_18_9 up box2
2
746 0
793 0
4
0 0 150 135
0 5 132 120
0 255 0 1
0 268 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_19_9 loc_18_9 up box3
2
746 0
793 0
4
0 0 150 135
0 4 132 120
0 255 0 1
0 268 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_19_9 loc_18_9 up box4
2
746 0
793 0
4
0 0 150 135
0 3 132 120
0 255 0 1
0 268 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_19_9 loc_18_9 up box6
2
746 0
793 0
4
0 0 150 135
0 2 132 120
0 255 0 1
0 268 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_20_10 loc_20_11 right box1
2
749 0
794 0
4
0 0 150 136
0 1 133 134
0 269 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_20_9 loc_20_10 loc_20_11 right box2
2
749 0
794 0
4
0 0 150 136
0 5 133 134
0 269 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_20_9 loc_20_10 loc_20_11 right box3
2
749 0
794 0
4
0 0 150 136
0 4 133 134
0 269 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_20_9 loc_20_10 loc_20_11 right box4
2
749 0
794 0
4
0 0 150 136
0 3 133 134
0 269 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_20_9 loc_20_10 loc_20_11 right box6
2
749 0
794 0
4
0 0 150 136
0 2 133 134
0 269 -1 0
0 270 0 1
1
end_operator
begin_operator
push loc_20_9 loc_20_8 loc_20_7 left box1
2
790 0
795 0
4
0 0 150 149
0 1 146 145
0 281 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_20_8 loc_20_7 left box2
2
790 0
795 0
4
0 0 150 149
0 5 146 145
0 281 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_20_8 loc_20_7 left box3
2
790 0
795 0
4
0 0 150 149
0 4 146 145
0 281 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_20_8 loc_20_7 left box4
2
790 0
795 0
4
0 0 150 149
0 3 146 145
0 281 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_20_9 loc_20_8 loc_20_7 left box6
2
790 0
795 0
4
0 0 150 149
0 2 146 145
0 281 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_11 loc_21_12 right box1
2
798 0
802 0
4
0 0 151 152
0 1 149 150
0 8 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_11 loc_21_12 right box2
2
798 0
802 0
4
0 0 151 152
0 5 149 150
0 8 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_11 loc_21_12 right box3
2
798 0
802 0
4
0 0 151 152
0 4 149 150
0 8 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_11 loc_21_12 right box4
2
798 0
802 0
4
0 0 151 152
0 3 149 150
0 8 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_11 loc_21_12 right box6
2
798 0
802 0
4
0 0 151 152
0 2 149 150
0 8 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_9 loc_21_8 left box1
2
799 0
824 0
4
0 0 151 161
0 1 158 157
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_9 loc_21_8 left box2
2
799 0
824 0
4
0 0 151 161
0 5 158 157
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_9 loc_21_8 left box3
2
799 0
824 0
4
0 0 151 161
0 4 158 157
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_9 loc_21_8 left box4
2
799 0
824 0
4
0 0 151 161
0 3 158 157
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_21_10 loc_21_9 loc_21_8 left box6
2
799 0
824 0
4
0 0 151 161
0 2 158 157
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_20_11 loc_19_11 up box1
2
752 0
800 0
4
0 0 152 137
0 1 134 121
0 256 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_20_11 loc_19_11 up box2
2
752 0
800 0
4
0 0 152 137
0 5 134 121
0 256 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_20_11 loc_19_11 up box3
2
752 0
800 0
4
0 0 152 137
0 4 134 121
0 256 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_20_11 loc_19_11 up box4
2
752 0
800 0
4
0 0 152 137
0 3 134 121
0 256 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_20_11 loc_19_11 up box6
2
752 0
800 0
4
0 0 152 137
0 2 134 121
0 256 0 1
0 270 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_10 loc_21_9 left box1
2
799 0
801 0
4
0 0 152 151
0 1 148 158
0 17 0 1
0 284 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_10 loc_21_9 left box2
2
799 0
801 0
4
0 0 152 151
0 5 148 158
0 17 0 1
0 284 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_10 loc_21_9 left box3
2
799 0
801 0
4
0 0 152 151
0 4 148 158
0 17 0 1
0 284 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_10 loc_21_9 left box4
2
799 0
801 0
4
0 0 152 151
0 3 148 158
0 17 0 1
0 284 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_10 loc_21_9 left box6
2
799 0
801 0
4
0 0 152 151
0 2 148 158
0 17 0 1
0 284 -1 0
1
end_operator
begin_operator
push loc_21_11 loc_21_12 loc_21_13 right box1
2
802 0
805 0
4
0 0 152 153
0 1 150 151
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_21_11 loc_21_12 loc_21_13 right box2
2
802 0
805 0
4
0 0 152 153
0 5 150 151
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_21_11 loc_21_12 loc_21_13 right box3
2
802 0
805 0
4
0 0 152 153
0 4 150 151
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_21_11 loc_21_12 loc_21_13 right box4
2
802 0
805 0
4
0 0 152 153
0 3 150 151
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_21_11 loc_21_12 loc_21_13 right box6
2
802 0
805 0
4
0 0 152 153
0 2 150 151
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_21_12 loc_20_12 loc_19_12 up box1
2
756 0
803 0
4
0 0 153 138
0 1 135 122
0 257 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_20_12 loc_19_12 up box2
2
756 0
803 0
4
0 0 153 138
0 5 135 122
0 257 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_20_12 loc_19_12 up box3
2
756 0
803 0
4
0 0 153 138
0 4 135 122
0 257 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_20_12 loc_19_12 up box4
2
756 0
803 0
4
0 0 153 138
0 3 135 122
0 257 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_20_12 loc_19_12 up box6
2
756 0
803 0
4
0 0 153 138
0 2 135 122
0 257 0 1
0 271 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_21_11 loc_21_10 left box1
2
801 0
804 0
4
0 0 153 152
0 1 149 148
0 284 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_21_11 loc_21_10 left box2
2
801 0
804 0
4
0 0 153 152
0 5 149 148
0 284 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_21_11 loc_21_10 left box3
2
801 0
804 0
4
0 0 153 152
0 4 149 148
0 284 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_21_11 loc_21_10 left box4
2
801 0
804 0
4
0 0 153 152
0 3 149 148
0 284 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_12 loc_21_11 loc_21_10 left box6
2
801 0
804 0
4
0 0 153 152
0 2 149 148
0 284 0 1
0 285 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_20_13 loc_19_13 up box1
2
760 0
806 0
4
0 0 154 139
0 1 136 123
0 258 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_20_13 loc_19_13 up box2
2
760 0
806 0
4
0 0 154 139
0 5 136 123
0 258 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_20_13 loc_19_13 up box3
2
760 0
806 0
4
0 0 154 139
0 4 136 123
0 258 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_20_13 loc_19_13 up box4
2
760 0
806 0
4
0 0 154 139
0 3 136 123
0 258 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_20_13 loc_19_13 up box6
2
760 0
806 0
4
0 0 154 139
0 2 136 123
0 258 0 1
0 272 -1 0
1
end_operator
begin_operator
push loc_21_13 loc_21_12 loc_21_11 left box1
2
804 0
807 0
4
0 0 154 153
0 1 150 149
0 8 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_13 loc_21_12 loc_21_11 left box2
2
804 0
807 0
4
0 0 154 153
0 5 150 149
0 8 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_13 loc_21_12 loc_21_11 left box3
2
804 0
807 0
4
0 0 154 153
0 4 150 149
0 8 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_13 loc_21_12 loc_21_11 left box4
2
804 0
807 0
4
0 0 154 153
0 3 150 149
0 8 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_13 loc_21_12 loc_21_11 left box6
2
804 0
807 0
4
0 0 154 153
0 2 150 149
0 8 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_16 loc_20_16 loc_19_16 up box1
2
768 0
808 0
4
0 0 155 142
0 1 139 124
0 259 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_21_16 loc_20_16 loc_19_16 up box2
2
768 0
808 0
4
0 0 155 142
0 5 139 124
0 259 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_21_16 loc_20_16 loc_19_16 up box3
2
768 0
808 0
4
0 0 155 142
0 4 139 124
0 259 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_21_16 loc_20_16 loc_19_16 up box4
2
768 0
808 0
4
0 0 155 142
0 3 139 124
0 259 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_21_16 loc_20_16 loc_19_16 up box6
2
768 0
808 0
4
0 0 155 142
0 2 139 124
0 259 0 1
0 275 -1 0
1
end_operator
begin_operator
push loc_21_16 loc_21_17 loc_21_18 right box1
2
809 0
812 0
4
0 0 155 156
0 1 153 154
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_21_16 loc_21_17 loc_21_18 right box2
2
809 0
812 0
4
0 0 155 156
0 5 153 154
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_21_16 loc_21_17 loc_21_18 right box3
2
809 0
812 0
4
0 0 155 156
0 4 153 154
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_21_16 loc_21_17 loc_21_18 right box4
2
809 0
812 0
4
0 0 155 156
0 3 153 154
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_21_16 loc_21_17 loc_21_18 right box6
2
809 0
812 0
4
0 0 155 156
0 2 153 154
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_21_17 loc_20_17 loc_19_17 up box1
2
772 0
810 0
4
0 0 156 143
0 1 140 125
0 260 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_21_17 loc_20_17 loc_19_17 up box2
2
772 0
810 0
4
0 0 156 143
0 5 140 125
0 260 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_21_17 loc_20_17 loc_19_17 up box3
2
772 0
810 0
4
0 0 156 143
0 4 140 125
0 260 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_21_17 loc_20_17 loc_19_17 up box4
2
772 0
810 0
4
0 0 156 143
0 3 140 125
0 260 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_21_17 loc_20_17 loc_19_17 up box6
2
772 0
810 0
4
0 0 156 143
0 2 140 125
0 260 0 1
0 276 -1 0
1
end_operator
begin_operator
push loc_21_17 loc_21_18 loc_21_19 right box1
2
812 0
815 0
4
0 0 156 157
0 1 154 155
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_21_17 loc_21_18 loc_21_19 right box2
2
812 0
815 0
4
0 0 156 157
0 5 154 155
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_21_17 loc_21_18 loc_21_19 right box3
2
812 0
815 0
4
0 0 156 157
0 4 154 155
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_21_17 loc_21_18 loc_21_19 right box4
2
812 0
815 0
4
0 0 156 157
0 3 154 155
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_21_17 loc_21_18 loc_21_19 right box6
2
812 0
815 0
4
0 0 156 157
0 2 154 155
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_21_18 loc_21_17 loc_21_16 left box1
2
811 0
814 0
4
0 0 157 156
0 1 153 152
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_21_18 loc_21_17 loc_21_16 left box2
2
811 0
814 0
4
0 0 157 156
0 5 153 152
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_21_18 loc_21_17 loc_21_16 left box3
2
811 0
814 0
4
0 0 157 156
0 4 153 152
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_21_18 loc_21_17 loc_21_16 left box4
2
811 0
814 0
4
0 0 157 156
0 3 153 152
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_21_18 loc_21_17 loc_21_16 left box6
2
811 0
814 0
4
0 0 157 156
0 2 153 152
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_21_18 loc_21_19 loc_21_20 right box1
2
815 0
818 0
4
0 0 157 158
0 1 155 156
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_21_18 loc_21_19 loc_21_20 right box2
2
815 0
818 0
4
0 0 157 158
0 5 155 156
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_21_18 loc_21_19 loc_21_20 right box3
2
815 0
818 0
4
0 0 157 158
0 4 155 156
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_21_18 loc_21_19 loc_21_20 right box4
2
815 0
818 0
4
0 0 157 158
0 3 155 156
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_21_18 loc_21_19 loc_21_20 right box6
2
815 0
818 0
4
0 0 157 158
0 2 155 156
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_21_19 loc_20_19 loc_19_19 up box1
2
779 0
816 0
4
0 0 158 145
0 1 142 126
0 261 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_20_19 loc_19_19 up box2
2
779 0
816 0
4
0 0 158 145
0 5 142 126
0 261 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_20_19 loc_19_19 up box3
2
779 0
816 0
4
0 0 158 145
0 4 142 126
0 261 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_20_19 loc_19_19 up box4
2
779 0
816 0
4
0 0 158 145
0 3 142 126
0 261 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_20_19 loc_19_19 up box6
2
779 0
816 0
4
0 0 158 145
0 2 142 126
0 261 0 1
0 278 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_21_18 loc_21_17 left box1
2
814 0
817 0
4
0 0 158 157
0 1 154 153
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_21_18 loc_21_17 left box2
2
814 0
817 0
4
0 0 158 157
0 5 154 153
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_21_18 loc_21_17 left box3
2
814 0
817 0
4
0 0 158 157
0 4 154 153
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_21_18 loc_21_17 left box4
2
814 0
817 0
4
0 0 158 157
0 3 154 153
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_21_19 loc_21_18 loc_21_17 left box6
2
814 0
817 0
4
0 0 158 157
0 2 154 153
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_20_8 loc_19_8 up box1
2
789 0
820 0
4
0 0 160 149
0 1 146 131
0 267 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_20_8 loc_19_8 up box2
2
789 0
820 0
4
0 0 160 149
0 5 146 131
0 267 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_20_8 loc_19_8 up box3
2
789 0
820 0
4
0 0 160 149
0 4 146 131
0 267 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_20_8 loc_19_8 up box4
2
789 0
820 0
4
0 0 160 149
0 3 146 131
0 267 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_20_8 loc_19_8 up box6
2
789 0
820 0
4
0 0 160 149
0 2 146 131
0 267 0 1
0 282 -1 0
1
end_operator
begin_operator
push loc_21_8 loc_21_9 loc_21_10 right box1
2
821 0
823 0
4
0 0 160 161
0 1 158 148
0 17 -1 0
0 284 0 1
1
end_operator
begin_operator
push loc_21_8 loc_21_9 loc_21_10 right box2
2
821 0
823 0
4
0 0 160 161
0 5 158 148
0 17 -1 0
0 284 0 1
1
end_operator
begin_operator
push loc_21_8 loc_21_9 loc_21_10 right box3
2
821 0
823 0
4
0 0 160 161
0 4 158 148
0 17 -1 0
0 284 0 1
1
end_operator
begin_operator
push loc_21_8 loc_21_9 loc_21_10 right box4
2
821 0
823 0
4
0 0 160 161
0 3 158 148
0 17 -1 0
0 284 0 1
1
end_operator
begin_operator
push loc_21_8 loc_21_9 loc_21_10 right box6
2
821 0
823 0
4
0 0 160 161
0 2 158 148
0 17 -1 0
0 284 0 1
1
end_operator
begin_operator
push loc_21_9 loc_20_9 loc_19_9 up box1
2
793 0
822 0
4
0 0 161 150
0 1 147 132
0 268 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_21_9 loc_20_9 loc_19_9 up box2
2
793 0
822 0
4
0 0 161 150
0 5 147 132
0 268 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_21_9 loc_20_9 loc_19_9 up box3
2
793 0
822 0
4
0 0 161 150
0 4 147 132
0 268 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_21_9 loc_20_9 loc_19_9 up box4
2
793 0
822 0
4
0 0 161 150
0 3 147 132
0 268 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_21_9 loc_20_9 loc_19_9 up box6
2
793 0
822 0
4
0 0 161 150
0 2 147 132
0 268 0 1
0 283 -1 0
1
end_operator
begin_operator
push loc_21_9 loc_21_10 loc_21_11 right box1
2
798 0
823 0
4
0 0 161 151
0 1 148 149
0 284 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_9 loc_21_10 loc_21_11 right box2
2
798 0
823 0
4
0 0 161 151
0 5 148 149
0 284 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_9 loc_21_10 loc_21_11 right box3
2
798 0
823 0
4
0 0 161 151
0 4 148 149
0 284 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_9 loc_21_10 loc_21_11 right box4
2
798 0
823 0
4
0 0 161 151
0 3 148 149
0 284 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_21_9 loc_21_10 loc_21_11 right box6
2
798 0
823 0
4
0 0 161 151
0 2 148 149
0 284 -1 0
0 285 0 1
1
end_operator
begin_operator
push loc_2_13 loc_3_13 loc_4_13 down box7
2
826 0
858 0
4
0 0 162 174
0 6 13 29
0 32 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_2_14 loc_3_14 loc_4_14 down box7
2
828 0
862 0
4
0 0 163 175
0 6 14 30
0 33 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_2_2 loc_2_3 loc_2_4 right box7
2
831 0
835 0
4
0 0 164 166
0 6 5 6
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_2_2 loc_3_2 loc_4_2 down box7
2
832 0
871 0
4
0 0 164 179
0 6 18 31
0 37 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_2_3 loc_2_4 loc_2_5 right box7
2
835 0
838 0
4
0 0 166 167
0 6 6 7
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box7
2
836 0
880 0
4
0 0 166 182
0 6 19 32
0 40 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_3 loc_2_2 left box7
2
834 0
837 0
4
0 0 167 166
0 6 5 4
0 22 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box7
2
838 0
841 0
4
0 0 167 168
0 6 7 8
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box7
2
839 0
884 0
4
0 0 167 183
0 6 20 33
0 41 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_4 loc_2_3 left box7
2
837 0
840 0
4
0 0 168 167
0 6 6 5
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box7
2
840 0
843 0
4
0 0 169 168
0 6 7 6
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_3_11 loc_3_12 right box7
2
846 0
850 0
4
0 0 171 172
0 6 11 12
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_10 loc_3_9 loc_3_8 left box7
2
847 0
898 0
4
0 0 171 188
0 6 25 24
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box7
2
848 0
903 0
4
0 0 171 189
0 6 26 36
0 47 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box7
2
847 0
849 0
4
0 0 172 171
0 6 10 25
0 29 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_12 loc_3_13 right box7
2
850 0
853 0
4
0 0 172 173
0 6 12 13
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box7
2
851 0
907 0
4
0 0 172 190
0 6 27 37
0 48 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_3_12 loc_3_11 loc_3_10 left box7
2
849 0
852 0
4
0 0 173 172
0 6 11 10
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_3_13 loc_3_14 right box7
2
853 0
857 0
4
0 0 173 174
0 6 13 14
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_12 loc_4_12 loc_5_12 down box7
2
854 0
911 0
4
0 0 173 191
0 6 28 38
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_3_13 loc_3_12 loc_3_11 left box7
2
852 0
856 0
4
0 0 174 173
0 6 12 11
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_13 loc_3_14 loc_3_15 right box7
2
857 0
861 0
4
0 0 174 175
0 6 14 15
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_14 loc_3_13 loc_3_12 left box7
2
856 0
860 0
4
0 0 175 174
0 6 13 12
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_14 loc_3_15 loc_3_16 right box7
2
861 0
864 0
4
0 0 175 176
0 6 15 16
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_14 loc_4_14 loc_5_14 down box7
2
862 0
917 0
4
0 0 175 193
0 6 30 39
0 51 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_3_15 loc_3_14 loc_3_13 left box7
2
860 0
863 0
4
0 0 176 175
0 6 14 13
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_15 loc_3_16 loc_3_17 right box7
2
864 0
866 0
4
0 0 176 177
0 6 16 17
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_3_16 loc_3_15 loc_3_14 left box7
2
863 0
865 0
4
0 0 177 176
0 6 15 14
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_3_17 loc_3_16 loc_3_15 left box7
2
865 0
867 0
4
0 0 178 177
0 6 16 15
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_3_17 loc_4_17 loc_5_17 down box1
2
868 0
919 0
4
0 0 178 194
0 1 163 167
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_3_17 loc_4_17 loc_5_17 down box2
2
868 0
919 0
4
0 0 178 194
0 5 163 167
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_3_17 loc_4_17 loc_5_17 down box3
2
868 0
919 0
4
0 0 178 194
0 4 163 167
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_3_17 loc_4_17 loc_5_17 down box4
2
868 0
919 0
4
0 0 178 194
0 3 163 167
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_3_17 loc_4_17 loc_5_17 down box6
2
868 0
919 0
4
0 0 178 194
0 2 163 167
0 52 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box7
2
870 0
879 0
4
0 0 179 182
0 6 19 20
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box7
2
871 0
922 0
4
0 0 179 195
0 6 31 40
0 53 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_3_20 loc_4_20 loc_5_20 down box1
2
873 0
925 0
4
0 0 180 196
0 1 164 170
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_3_20 loc_4_20 loc_5_20 down box2
2
873 0
925 0
4
0 0 180 196
0 5 164 170
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_3_20 loc_4_20 loc_5_20 down box3
2
873 0
925 0
4
0 0 180 196
0 4 164 170
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_3_20 loc_4_20 loc_5_20 down box4
2
873 0
925 0
4
0 0 180 196
0 3 164 170
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_3_20 loc_4_20 loc_5_20 down box6
2
873 0
925 0
4
0 0 180 196
0 2 164 170
0 54 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_3_21 loc_4_21 loc_5_21 down box1
2
876 0
928 0
4
0 0 181 197
0 1 165 171
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_3_21 loc_4_21 loc_5_21 down box2
2
876 0
928 0
4
0 0 181 197
0 5 165 171
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_3_21 loc_4_21 loc_5_21 down box3
2
876 0
928 0
4
0 0 181 197
0 4 165 171
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_3_21 loc_4_21 loc_5_21 down box4
2
876 0
928 0
4
0 0 181 197
0 3 165 171
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_3_21 loc_4_21 loc_5_21 down box6
2
876 0
928 0
4
0 0 181 197
0 2 165 171
0 55 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box7
2
879 0
883 0
4
0 0 182 183
0 6 20 21
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box7
2
880 0
932 0
4
0 0 182 198
0 6 32 41
0 56 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box7
2
878 0
882 0
4
0 0 183 182
0 6 19 18
0 37 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box7
2
883 0
887 0
4
0 0 183 184
0 6 21 22
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box7
2
882 0
886 0
4
0 0 184 183
0 6 20 19
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box7
2
887 0
890 0
4
0 0 184 185
0 6 22 23
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box7
2
886 0
889 0
4
0 0 185 184
0 6 21 20
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box7
2
890 0
892 0
4
0 0 185 186
0 6 23 24
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box7
2
889 0
891 0
4
0 0 186 185
0 6 22 21
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box7
2
892 0
894 0
4
0 0 186 187
0 6 24 25
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box7
2
891 0
893 0
4
0 0 187 186
0 6 23 22
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_9 loc_3_10 right box7
2
894 0
897 0
4
0 0 187 188
0 6 25 10
0 29 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box7
2
846 0
897 0
4
0 0 188 171
0 6 10 11
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box7
2
893 0
898 0
4
0 0 188 187
0 6 24 23
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box7
2
899 0
940 0
4
0 0 188 201
0 6 35 42
0 59 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_11 loc_4_12 right box7
2
901 0
906 0
4
0 0 189 190
0 6 27 28
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box7
2
902 0
939 0
4
0 0 189 201
0 6 35 34
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box7
2
902 0
905 0
4
0 0 190 189
0 6 26 35
0 47 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_12 loc_4_13 right box7
2
906 0
910 0
4
0 0 190 191
0 6 28 29
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box7
2
907 0
947 0
4
0 0 190 203
0 6 37 43
0 61 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_4_12 loc_4_11 loc_4_10 left box7
2
905 0
909 0
4
0 0 191 190
0 6 27 26
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_4_12 loc_4_13 loc_4_14 right box7
2
910 0
914 0
4
0 0 191 192
0 6 29 30
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_4_12 loc_5_12 loc_6_12 down box7
2
911 0
950 0
4
0 0 191 204
0 6 38 44
0 62 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_4_13 loc_3_13 loc_2_13 up box7
2
855 0
912 0
4
0 0 192 174
0 6 13 2
0 18 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_13 loc_4_12 loc_4_11 left box7
2
909 0
913 0
4
0 0 192 191
0 6 28 27
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_4_14 loc_3_14 loc_2_14 up box7
2
859 0
915 0
4
0 0 193 175
0 6 14 3
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_14 loc_4_13 loc_4_12 left box7
2
913 0
916 0
4
0 0 193 192
0 6 29 28
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_4_14 loc_5_14 loc_6_14 down box7
2
917 0
952 0
4
0 0 193 205
0 6 39 46
0 63 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_4_17 loc_5_17 loc_6_17 down box1
2
919 0
958 0
4
0 0 194 207
0 1 167 173
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_4_17 loc_5_17 loc_6_17 down box2
2
919 0
958 0
4
0 0 194 207
0 5 167 173
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_4_17 loc_5_17 loc_6_17 down box3
2
919 0
958 0
4
0 0 194 207
0 4 167 173
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_4_17 loc_5_17 loc_6_17 down box4
2
919 0
958 0
4
0 0 194 207
0 3 167 173
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_4_17 loc_5_17 loc_6_17 down box6
2
919 0
958 0
4
0 0 194 207
0 2 167 173
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box7
2
869 0
920 0
4
0 0 195 179
0 6 18 4
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box7
2
921 0
931 0
4
0 0 195 198
0 6 32 33
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_20 loc_5_20 loc_6_20 down box1
2
925 0
969 0
4
0 0 196 211
0 1 170 175
0 69 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_4_20 loc_5_20 loc_6_20 down box2
2
925 0
969 0
4
0 0 196 211
0 5 170 175
0 69 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_4_20 loc_5_20 loc_6_20 down box3
2
925 0
969 0
4
0 0 196 211
0 4 170 175
0 69 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_4_20 loc_5_20 loc_6_20 down box4
2
925 0
969 0
4
0 0 196 211
0 3 170 175
0 69 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_4_20 loc_5_20 loc_6_20 down box6
2
925 0
969 0
4
0 0 196 211
0 2 170 175
0 69 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_4_21 loc_3_21 loc_2_21 up box1
2
874 0
926 0
4
0 0 197 181
0 1 162 159
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_21 loc_3_21 loc_2_21 up box2
2
874 0
926 0
4
0 0 197 181
0 5 162 159
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_21 loc_3_21 loc_2_21 up box3
2
874 0
926 0
4
0 0 197 181
0 4 162 159
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_21 loc_3_21 loc_2_21 up box4
2
874 0
926 0
4
0 0 197 181
0 3 162 159
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_21 loc_3_21 loc_2_21 up box6
2
874 0
926 0
4
0 0 197 181
0 2 162 159
0 23 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_21 loc_5_21 loc_6_21 down box1
2
928 0
972 0
4
0 0 197 212
0 1 171 176
0 70 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_21 loc_5_21 loc_6_21 down box2
2
928 0
972 0
4
0 0 197 212
0 5 171 176
0 70 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_21 loc_5_21 loc_6_21 down box3
2
928 0
972 0
4
0 0 197 212
0 4 171 176
0 70 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_21 loc_5_21 loc_6_21 down box4
2
928 0
972 0
4
0 0 197 212
0 3 171 176
0 70 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_21 loc_5_21 loc_6_21 down box6
2
928 0
972 0
4
0 0 197 212
0 2 171 176
0 70 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box7
2
877 0
929 0
4
0 0 198 182
0 6 19 5
0 24 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box7
2
932 0
975 0
4
0 0 198 213
0 6 41 47
0 71 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box7
2
881 0
933 0
4
0 0 199 183
0 6 20 6
0 25 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box7
2
930 0
934 0
4
0 0 199 198
0 6 32 31
0 53 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box7
2
936 0
938 0
4
0 0 200 201
0 6 35 26
0 47 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box7
2
896 0
937 0
4
0 0 201 188
0 6 25 9
0 28 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box7
2
901 0
938 0
4
0 0 201 189
0 6 26 27
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box7
2
940 0
978 0
4
0 0 201 214
0 6 42 48
0 73 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box7
2
900 0
941 0
4
0 0 202 189
0 6 26 10
0 29 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_11 loc_5_12 right box7
2
942 0
946 0
4
0 0 202 203
0 6 37 38
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box7
2
904 0
944 0
4
0 0 203 190
0 6 27 11
0 30 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box7
2
943 0
945 0
4
0 0 203 202
0 6 36 42
0 60 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_12 loc_4_12 loc_3_12 up box7
2
908 0
948 0
4
0 0 204 191
0 6 28 12
0 31 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_5_11 loc_5_10 left box7
2
945 0
949 0
4
0 0 204 203
0 6 37 36
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_5_14 loc_4_14 loc_3_14 up box7
2
915 0
951 0
4
0 0 205 193
0 6 30 14
0 33 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_14 loc_6_14 loc_7_14 down box7
2
952 0
988 0
4
0 0 205 218
0 6 46 49
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_5_16 loc_5_17 loc_5_18 right box1
2
953 0
957 0
4
0 0 206 207
0 1 167 168
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_16 loc_5_17 loc_5_18 right box2
2
953 0
957 0
4
0 0 206 207
0 5 167 168
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_16 loc_5_17 loc_5_18 right box3
2
953 0
957 0
4
0 0 206 207
0 4 167 168
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_16 loc_5_17 loc_5_18 right box4
2
953 0
957 0
4
0 0 206 207
0 3 167 168
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_16 loc_5_17 loc_5_18 right box6
2
953 0
957 0
4
0 0 206 207
0 2 167 168
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_17 loc_4_17 loc_3_17 up box1
2
918 0
955 0
4
0 0 207 194
0 1 163 160
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_17 loc_4_17 loc_3_17 up box2
2
918 0
955 0
4
0 0 207 194
0 5 163 160
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_17 loc_4_17 loc_3_17 up box3
2
918 0
955 0
4
0 0 207 194
0 4 163 160
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_17 loc_4_17 loc_3_17 up box4
2
918 0
955 0
4
0 0 207 194
0 3 163 160
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_17 loc_4_17 loc_3_17 up box6
2
918 0
955 0
4
0 0 207 194
0 2 163 160
0 36 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_17 loc_5_18 loc_5_19 right box1
2
957 0
960 0
4
0 0 207 208
0 1 168 169
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_17 loc_5_18 loc_5_19 right box2
2
957 0
960 0
4
0 0 207 208
0 5 168 169
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_17 loc_5_18 loc_5_19 right box3
2
957 0
960 0
4
0 0 207 208
0 4 168 169
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_17 loc_5_18 loc_5_19 right box4
2
957 0
960 0
4
0 0 207 208
0 3 168 169
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_17 loc_5_18 loc_5_19 right box6
2
957 0
960 0
4
0 0 207 208
0 2 168 169
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_17 loc_5_16 left box1
2
956 0
959 0
4
0 0 208 207
0 1 167 166
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_5_18 loc_5_17 loc_5_16 left box2
2
956 0
959 0
4
0 0 208 207
0 5 167 166
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_5_18 loc_5_17 loc_5_16 left box3
2
956 0
959 0
4
0 0 208 207
0 4 167 166
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_5_18 loc_5_17 loc_5_16 left box4
2
956 0
959 0
4
0 0 208 207
0 3 167 166
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_5_18 loc_5_17 loc_5_16 left box6
2
956 0
959 0
4
0 0 208 207
0 2 167 166
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box1
2
960 0
963 0
4
0 0 208 209
0 1 169 170
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box2
2
960 0
963 0
4
0 0 208 209
0 5 169 170
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box3
2
960 0
963 0
4
0 0 208 209
0 4 169 170
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box4
2
960 0
963 0
4
0 0 208 209
0 3 169 170
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box6
2
960 0
963 0
4
0 0 208 209
0 2 169 170
0 67 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box1
2
961 0
996 0
4
0 0 208 221
0 1 174 178
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box2
2
961 0
996 0
4
0 0 208 221
0 5 174 178
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box3
2
961 0
996 0
4
0 0 208 221
0 4 174 178
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box4
2
961 0
996 0
4
0 0 208 221
0 3 174 178
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box6
2
961 0
996 0
4
0 0 208 221
0 2 174 178
0 80 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_5_19 loc_5_18 loc_5_17 left box1
2
959 0
962 0
4
0 0 209 208
0 1 168 167
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_5_19 loc_5_18 loc_5_17 left box2
2
959 0
962 0
4
0 0 209 208
0 5 168 167
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_5_19 loc_5_18 loc_5_17 left box3
2
959 0
962 0
4
0 0 209 208
0 4 168 167
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_5_19 loc_5_18 loc_5_17 left box4
2
959 0
962 0
4
0 0 209 208
0 3 168 167
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_5_19 loc_5_18 loc_5_17 left box6
2
959 0
962 0
4
0 0 209 208
0 2 168 167
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_5_19 loc_5_20 loc_5_21 right box1
2
963 0
968 0
4
0 0 209 211
0 1 170 171
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_19 loc_5_20 loc_5_21 right box2
2
963 0
968 0
4
0 0 209 211
0 5 170 171
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_19 loc_5_20 loc_5_21 right box3
2
963 0
968 0
4
0 0 209 211
0 4 170 171
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_19 loc_5_20 loc_5_21 right box4
2
963 0
968 0
4
0 0 209 211
0 3 170 171
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_19 loc_5_20 loc_5_21 right box6
2
963 0
968 0
4
0 0 209 211
0 2 170 171
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box7
2
920 0
964 0
4
0 0 210 195
0 6 31 18
0 37 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_4_20 loc_3_20 up box1
2
923 0
966 0
4
0 0 211 196
0 1 164 161
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_4_20 loc_3_20 up box2
2
923 0
966 0
4
0 0 211 196
0 5 164 161
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_4_20 loc_3_20 up box3
2
923 0
966 0
4
0 0 211 196
0 4 164 161
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_4_20 loc_3_20 up box4
2
923 0
966 0
4
0 0 211 196
0 3 164 161
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_4_20 loc_3_20 up box6
2
923 0
966 0
4
0 0 211 196
0 2 164 161
0 38 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_5_19 loc_5_18 left box1
2
962 0
967 0
4
0 0 211 209
0 1 169 168
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_5_19 loc_5_18 left box2
2
962 0
967 0
4
0 0 211 209
0 5 169 168
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_5_19 loc_5_18 left box3
2
962 0
967 0
4
0 0 211 209
0 4 169 168
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_5_19 loc_5_18 left box4
2
962 0
967 0
4
0 0 211 209
0 3 169 168
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_5_20 loc_5_19 loc_5_18 left box6
2
962 0
967 0
4
0 0 211 209
0 2 169 168
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_4_21 loc_3_21 up box1
2
926 0
970 0
4
0 0 212 197
0 1 165 162
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_4_21 loc_3_21 up box2
2
926 0
970 0
4
0 0 212 197
0 5 165 162
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_4_21 loc_3_21 up box3
2
926 0
970 0
4
0 0 212 197
0 4 165 162
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_4_21 loc_3_21 up box4
2
926 0
970 0
4
0 0 212 197
0 3 165 162
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_4_21 loc_3_21 up box6
2
926 0
970 0
4
0 0 212 197
0 2 165 162
0 39 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_5_20 loc_5_19 left box1
2
967 0
971 0
4
0 0 212 211
0 1 170 169
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_5_20 loc_5_19 left box2
2
967 0
971 0
4
0 0 212 211
0 5 170 169
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_5_20 loc_5_19 left box3
2
967 0
971 0
4
0 0 212 211
0 4 170 169
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_5_20 loc_5_19 left box4
2
967 0
971 0
4
0 0 212 211
0 3 170 169
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_5_20 loc_5_19 left box6
2
967 0
971 0
4
0 0 212 211
0 2 170 169
0 67 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_5_21 loc_6_21 loc_7_21 down box1
2
972 0
1001 0
4
0 0 212 223
0 1 176 179
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_21 loc_6_21 loc_7_21 down box2
2
972 0
1001 0
4
0 0 212 223
0 5 176 179
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_21 loc_6_21 loc_7_21 down box3
2
972 0
1001 0
4
0 0 212 223
0 4 176 179
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_21 loc_6_21 loc_7_21 down box4
2
972 0
1001 0
4
0 0 212 223
0 3 176 179
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_21 loc_6_21 loc_7_21 down box6
2
972 0
1001 0
4
0 0 212 223
0 2 176 179
0 82 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box7
2
929 0
973 0
4
0 0 213 198
0 6 32 19
0 40 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box7
2
975 0
1003 0
4
0 0 213 224
0 6 47 50
0 83 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box7
2
937 0
976 0
4
0 0 214 201
0 6 35 25
0 46 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box7
2
942 0
977 0
4
0 0 214 202
0 6 36 37
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box7
2
978 0
1007 0
4
0 0 214 226
0 6 48 52
0 85 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box7
2
944 0
979 0
4
0 0 215 203
0 6 37 27
0 48 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_6_12 loc_6_13 right box7
2
980 0
983 0
4
0 0 215 216
0 6 44 45
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_6_12 loc_5_12 loc_4_12 up box7
2
948 0
981 0
4
0 0 216 204
0 6 38 28
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_6_12 loc_6_13 loc_6_14 right box7
2
983 0
985 0
4
0 0 216 217
0 6 45 46
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_6_13 loc_6_12 loc_6_11 left box7
2
982 0
984 0
4
0 0 217 216
0 6 44 43
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_6_14 loc_5_14 loc_4_14 up box7
2
951 0
986 0
4
0 0 218 205
0 6 39 30
0 51 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_14 loc_6_13 loc_6_12 left box7
2
984 0
987 0
4
0 0 218 217
0 6 45 44
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_6_14 loc_7_14 loc_8_14 down box7
2
988 0
1010 0
4
0 0 218 227
0 6 49 53
0 86 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_6_16 loc_6_17 loc_6_18 right box1
2
990 0
993 0
4
0 0 219 220
0 1 173 174
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_16 loc_6_17 loc_6_18 right box2
2
990 0
993 0
4
0 0 219 220
0 5 173 174
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_16 loc_6_17 loc_6_18 right box3
2
990 0
993 0
4
0 0 219 220
0 4 173 174
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_16 loc_6_17 loc_6_18 right box4
2
990 0
993 0
4
0 0 219 220
0 3 173 174
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_16 loc_6_17 loc_6_18 right box6
2
990 0
993 0
4
0 0 219 220
0 2 173 174
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_17 loc_5_17 loc_4_17 up box1
2
955 0
991 0
4
0 0 220 207
0 1 167 163
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_17 loc_5_17 loc_4_17 up box2
2
955 0
991 0
4
0 0 220 207
0 5 167 163
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_17 loc_5_17 loc_4_17 up box3
2
955 0
991 0
4
0 0 220 207
0 4 167 163
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_17 loc_5_17 loc_4_17 up box4
2
955 0
991 0
4
0 0 220 207
0 3 167 163
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_17 loc_5_17 loc_4_17 up box6
2
955 0
991 0
4
0 0 220 207
0 2 167 163
0 52 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_6_17 loc_6_16 left box1
2
992 0
995 0
4
0 0 221 220
0 1 173 172
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_6_17 loc_6_16 left box2
2
992 0
995 0
4
0 0 221 220
0 5 173 172
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_6_17 loc_6_16 left box3
2
992 0
995 0
4
0 0 221 220
0 4 173 172
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_6_17 loc_6_16 left box4
2
992 0
995 0
4
0 0 221 220
0 3 173 172
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_6_17 loc_6_16 left box6
2
992 0
995 0
4
0 0 221 220
0 2 173 172
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box1
2
996 0
1015 0
4
0 0 221 229
0 1 178 186
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box2
2
996 0
1015 0
4
0 0 221 229
0 5 178 186
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box3
2
996 0
1015 0
4
0 0 221 229
0 4 178 186
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box4
2
996 0
1015 0
4
0 0 221 229
0 3 178 186
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box6
2
996 0
1015 0
4
0 0 221 229
0 2 178 186
0 88 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_6_20 loc_5_20 loc_4_20 up box1
2
966 0
997 0
4
0 0 222 211
0 1 170 164
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_6_20 loc_5_20 loc_4_20 up box2
2
966 0
997 0
4
0 0 222 211
0 5 170 164
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_6_20 loc_5_20 loc_4_20 up box3
2
966 0
997 0
4
0 0 222 211
0 4 170 164
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_6_20 loc_5_20 loc_4_20 up box4
2
966 0
997 0
4
0 0 222 211
0 3 170 164
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_6_20 loc_5_20 loc_4_20 up box6
2
966 0
997 0
4
0 0 222 211
0 2 170 164
0 54 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_5_21 loc_4_21 up box1
2
970 0
999 0
4
0 0 223 212
0 1 171 165
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_5_21 loc_4_21 up box2
2
970 0
999 0
4
0 0 223 212
0 5 171 165
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_5_21 loc_4_21 up box3
2
970 0
999 0
4
0 0 223 212
0 4 171 165
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_5_21 loc_4_21 up box4
2
970 0
999 0
4
0 0 223 212
0 3 171 165
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_5_21 loc_4_21 up box6
2
970 0
999 0
4
0 0 223 212
0 2 171 165
0 55 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_21 loc_7_21 loc_8_21 down box1
2
1001 0
1018 0
4
0 0 223 231
0 1 179 187
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
push loc_6_21 loc_7_21 loc_8_21 down box2
2
1001 0
1018 0
4
0 0 223 231
0 5 179 187
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
push loc_6_21 loc_7_21 loc_8_21 down box3
2
1001 0
1018 0
4
0 0 223 231
0 4 179 187
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
push loc_6_21 loc_7_21 loc_8_21 down box4
2
1001 0
1018 0
4
0 0 223 231
0 3 179 187
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
push loc_6_21 loc_7_21 loc_8_21 down box6
2
1001 0
1018 0
4
0 0 223 231
0 2 179 187
0 90 -1 0
0 109 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box7
2
973 0
1002 0
4
0 0 224 213
0 6 41 32
0 56 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box7
2
1003 0
1020 0
4
0 0 224 232
0 6 50 54
0 91 -1 0
0 111 0 1
1
end_operator
begin_operator
push loc_7_14 loc_6_14 loc_5_14 up box7
2
986 0
1008 0
4
0 0 227 218
0 6 46 39
0 63 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_7_15 loc_8_15 loc_9_15 down box1
2
1012 0
1037 0
4
0 0 228 240
0 1 183 190
0 99 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_7_15 loc_8_15 loc_9_15 down box2
2
1012 0
1037 0
4
0 0 228 240
0 5 183 190
0 99 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_7_15 loc_8_15 loc_9_15 down box3
2
1012 0
1037 0
4
0 0 228 240
0 4 183 190
0 99 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_7_15 loc_8_15 loc_9_15 down box4
2
1012 0
1037 0
4
0 0 228 240
0 3 183 190
0 99 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_7_15 loc_8_15 loc_9_15 down box6
2
1012 0
1037 0
4
0 0 228 240
0 2 183 190
0 99 -1 0
0 125 0 1
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box1
2
994 0
1013 0
4
0 0 229 221
0 1 174 168
0 66 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box2
2
994 0
1013 0
4
0 0 229 221
0 5 174 168
0 66 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box3
2
994 0
1013 0
4
0 0 229 221
0 4 174 168
0 66 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box4
2
994 0
1013 0
4
0 0 229 221
0 3 174 168
0 66 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box6
2
994 0
1013 0
4
0 0 229 221
0 2 174 168
0 66 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box1
2
1015 0
1046 0
4
0 0 229 243
0 1 186 193
0 103 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box2
2
1015 0
1046 0
4
0 0 229 243
0 5 186 193
0 103 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box3
2
1015 0
1046 0
4
0 0 229 243
0 4 186 193
0 103 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box4
2
1015 0
1046 0
4
0 0 229 243
0 3 186 193
0 103 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box6
2
1015 0
1046 0
4
0 0 229 243
0 2 186 193
0 103 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_7_21 loc_6_21 loc_5_21 up box1
2
999 0
1017 0
4
0 0 231 223
0 1 176 171
0 70 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_7_21 loc_6_21 loc_5_21 up box2
2
999 0
1017 0
4
0 0 231 223
0 5 176 171
0 70 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_7_21 loc_6_21 loc_5_21 up box3
2
999 0
1017 0
4
0 0 231 223
0 4 176 171
0 70 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_7_21 loc_6_21 loc_5_21 up box4
2
999 0
1017 0
4
0 0 231 223
0 3 176 171
0 70 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_7_21 loc_6_21 loc_5_21 up box6
2
999 0
1017 0
4
0 0 231 223
0 2 176 171
0 70 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_7_21 loc_8_21 loc_9_21 down box1
2
1018 0
1053 0
4
0 0 231 246
0 1 187 196
0 109 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_7_21 loc_8_21 loc_9_21 down box2
2
1018 0
1053 0
4
0 0 231 246
0 5 187 196
0 109 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_7_21 loc_8_21 loc_9_21 down box3
2
1018 0
1053 0
4
0 0 231 246
0 4 187 196
0 109 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_7_21 loc_8_21 loc_9_21 down box4
2
1018 0
1053 0
4
0 0 231 246
0 3 187 196
0 109 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_7_21 loc_8_21 loc_9_21 down box6
2
1018 0
1053 0
4
0 0 231 246
0 2 187 196
0 109 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box7
2
1002 0
1019 0
4
0 0 232 224
0 6 47 41
0 71 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box7
2
1020 0
1056 0
4
0 0 232 247
0 6 54 57
0 111 -1 0
0 141 0 1
1
end_operator
begin_operator
push loc_8_14 loc_7_14 loc_6_14 up box7
2
1008 0
1032 0
4
0 0 239 227
0 6 49 46
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_8_14 loc_8_15 loc_8_16 right box1
2
1033 0
1036 0
4
0 0 239 240
0 1 183 184
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
push loc_8_14 loc_8_15 loc_8_16 right box2
2
1033 0
1036 0
4
0 0 239 240
0 5 183 184
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
push loc_8_14 loc_8_15 loc_8_16 right box3
2
1033 0
1036 0
4
0 0 239 240
0 4 183 184
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
push loc_8_14 loc_8_15 loc_8_16 right box4
2
1033 0
1036 0
4
0 0 239 240
0 3 183 184
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
push loc_8_14 loc_8_15 loc_8_16 right box6
2
1033 0
1036 0
4
0 0 239 240
0 2 183 184
0 99 -1 0
0 100 0 1
1
end_operator
begin_operator
push loc_8_15 loc_8_16 loc_8_17 right box1
2
1036 0
1039 0
4
0 0 240 241
0 1 184 185
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
push loc_8_15 loc_8_16 loc_8_17 right box2
2
1036 0
1039 0
4
0 0 240 241
0 5 184 185
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
push loc_8_15 loc_8_16 loc_8_17 right box3
2
1036 0
1039 0
4
0 0 240 241
0 4 184 185
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
push loc_8_15 loc_8_16 loc_8_17 right box4
2
1036 0
1039 0
4
0 0 240 241
0 3 184 185
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
push loc_8_15 loc_8_16 loc_8_17 right box6
2
1036 0
1039 0
4
0 0 240 241
0 2 184 185
0 100 -1 0
0 101 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box1
2
1037 0
1069 0
4
0 0 240 253
0 1 190 3
0 108 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box2
2
1037 0
1069 0
4
0 0 240 253
0 5 190 3
0 108 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box3
2
1037 0
1069 0
4
0 0 240 253
0 4 190 3
0 108 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box4
2
1037 0
1069 0
4
0 0 240 253
0 3 190 3
0 108 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box6
2
1037 0
1069 0
4
0 0 240 253
0 2 190 3
0 108 0 1
0 125 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_15 loc_8_14 left box1
2
1035 0
1038 0
4
0 0 241 240
0 1 183 182
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_15 loc_8_14 left box2
2
1035 0
1038 0
4
0 0 241 240
0 5 183 182
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_15 loc_8_14 left box3
2
1035 0
1038 0
4
0 0 241 240
0 4 183 182
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_15 loc_8_14 left box4
2
1035 0
1038 0
4
0 0 241 240
0 3 183 182
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_15 loc_8_14 left box6
2
1035 0
1038 0
4
0 0 241 240
0 2 183 182
0 98 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_8_16 loc_8_17 loc_8_18 right box1
2
1039 0
1042 0
4
0 0 241 242
0 1 185 186
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_8_16 loc_8_17 loc_8_18 right box2
2
1039 0
1042 0
4
0 0 241 242
0 5 185 186
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_8_16 loc_8_17 loc_8_18 right box3
2
1039 0
1042 0
4
0 0 241 242
0 4 185 186
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_8_16 loc_8_17 loc_8_18 right box4
2
1039 0
1042 0
4
0 0 241 242
0 3 185 186
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_8_16 loc_8_17 loc_8_18 right box6
2
1039 0
1042 0
4
0 0 241 242
0 2 185 186
0 101 -1 0
0 103 0 1
1
end_operator
begin_operator
push loc_8_17 loc_8_16 loc_8_15 left box1
2
1038 0
1041 0
4
0 0 242 241
0 1 184 183
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_8_16 loc_8_15 left box2
2
1038 0
1041 0
4
0 0 242 241
0 5 184 183
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_8_16 loc_8_15 left box3
2
1038 0
1041 0
4
0 0 242 241
0 4 184 183
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_8_16 loc_8_15 left box4
2
1038 0
1041 0
4
0 0 242 241
0 3 184 183
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_8_16 loc_8_15 left box6
2
1038 0
1041 0
4
0 0 242 241
0 2 184 183
0 99 0 1
0 100 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box1
2
1043 0
1075 0
4
0 0 242 255
0 1 192 4
0 110 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box2
2
1043 0
1075 0
4
0 0 242 255
0 5 192 4
0 110 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box3
2
1043 0
1075 0
4
0 0 242 255
0 4 192 4
0 110 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box4
2
1043 0
1075 0
4
0 0 242 255
0 3 192 4
0 110 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box6
2
1043 0
1075 0
4
0 0 242 255
0 2 192 4
0 110 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box1
2
1013 0
1044 0
4
0 0 243 229
0 1 178 174
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box2
2
1013 0
1044 0
4
0 0 243 229
0 5 178 174
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box3
2
1013 0
1044 0
4
0 0 243 229
0 4 178 174
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box4
2
1013 0
1044 0
4
0 0 243 229
0 3 178 174
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box6
2
1013 0
1044 0
4
0 0 243 229
0 2 178 174
0 80 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_8_17 loc_8_16 left box1
2
1041 0
1045 0
4
0 0 243 242
0 1 185 184
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_8_17 loc_8_16 left box2
2
1041 0
1045 0
4
0 0 243 242
0 5 185 184
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_8_17 loc_8_16 left box3
2
1041 0
1045 0
4
0 0 243 242
0 4 185 184
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_8_17 loc_8_16 left box4
2
1041 0
1045 0
4
0 0 243 242
0 3 185 184
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_8_17 loc_8_16 left box6
2
1041 0
1045 0
4
0 0 243 242
0 2 185 184
0 100 0 1
0 101 -1 0
1
end_operator
begin_operator
push loc_8_21 loc_7_21 loc_6_21 up box1
2
1017 0
1051 0
4
0 0 246 231
0 1 179 176
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_8_21 loc_7_21 loc_6_21 up box2
2
1017 0
1051 0
4
0 0 246 231
0 5 179 176
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_8_21 loc_7_21 loc_6_21 up box3
2
1017 0
1051 0
4
0 0 246 231
0 4 179 176
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_8_21 loc_7_21 loc_6_21 up box4
2
1017 0
1051 0
4
0 0 246 231
0 3 179 176
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_8_21 loc_7_21 loc_6_21 up box6
2
1017 0
1051 0
4
0 0 246 231
0 2 179 176
0 82 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box7
2
1019 0
1054 0
4
0 0 247 232
0 6 50 47
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box7
2
1056 0
1092 0
4
0 0 247 261
0 6 57 0
0 114 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box1
2
293 0
1069 0
4
0 0 253 3
0 1 3 13
0 108 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box2
2
293 0
1069 0
4
0 0 253 3
0 5 3 13
0 108 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box3
2
293 0
1069 0
4
0 0 253 3
0 4 3 13
0 108 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box4
2
293 0
1069 0
4
0 0 253 3
0 3 3 13
0 108 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box6
2
293 0
1069 0
4
0 0 253 3
0 2 3 13
0 108 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box1
2
1034 0
1070 0
4
0 0 253 240
0 1 183 177
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box2
2
1034 0
1070 0
4
0 0 253 240
0 5 183 177
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box3
2
1034 0
1070 0
4
0 0 253 240
0 4 183 177
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box4
2
1034 0
1070 0
4
0 0 253 240
0 3 183 177
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box6
2
1034 0
1070 0
4
0 0 253 240
0 2 183 177
0 87 0 1
0 99 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box1
2
1071 0
1074 0
4
0 0 253 254
0 1 191 192
0 127 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box2
2
1071 0
1074 0
4
0 0 253 254
0 5 191 192
0 127 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box3
2
1071 0
1074 0
4
0 0 253 254
0 4 191 192
0 127 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box4
2
1071 0
1074 0
4
0 0 253 254
0 3 191 192
0 127 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box6
2
1071 0
1074 0
4
0 0 253 254
0 2 191 192
0 127 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box1
2
1074 0
1078 0
4
0 0 254 255
0 1 192 193
0 129 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box2
2
1074 0
1078 0
4
0 0 254 255
0 5 192 193
0 129 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box3
2
1074 0
1078 0
4
0 0 254 255
0 4 192 193
0 129 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box4
2
1074 0
1078 0
4
0 0 254 255
0 3 192 193
0 129 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box6
2
1074 0
1078 0
4
0 0 254 255
0 2 192 193
0 129 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box1
2
295 0
1075 0
4
0 0 255 4
0 1 4 15
0 110 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box2
2
295 0
1075 0
4
0 0 255 4
0 5 4 15
0 110 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box3
2
295 0
1075 0
4
0 0 255 4
0 4 4 15
0 110 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box4
2
295 0
1075 0
4
0 0 255 4
0 3 4 15
0 110 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box6
2
295 0
1075 0
4
0 0 255 4
0 2 4 15
0 110 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box1
2
1073 0
1077 0
4
0 0 255 254
0 1 191 190
0 125 0 1
0 127 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box2
2
1073 0
1077 0
4
0 0 255 254
0 5 191 190
0 125 0 1
0 127 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box3
2
1073 0
1077 0
4
0 0 255 254
0 4 191 190
0 125 0 1
0 127 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box4
2
1073 0
1077 0
4
0 0 255 254
0 3 191 190
0 125 0 1
0 127 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box6
2
1073 0
1077 0
4
0 0 255 254
0 2 191 190
0 125 0 1
0 127 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box1
2
1078 0
1081 0
4
0 0 255 256
0 1 193 194
0 131 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box2
2
1078 0
1081 0
4
0 0 255 256
0 5 193 194
0 131 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box3
2
1078 0
1081 0
4
0 0 255 256
0 4 193 194
0 131 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box4
2
1078 0
1081 0
4
0 0 255 256
0 3 193 194
0 131 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box6
2
1078 0
1081 0
4
0 0 255 256
0 2 193 194
0 131 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box1
2
1044 0
1079 0
4
0 0 256 243
0 1 186 178
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box2
2
1044 0
1079 0
4
0 0 256 243
0 5 186 178
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box3
2
1044 0
1079 0
4
0 0 256 243
0 4 186 178
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box4
2
1044 0
1079 0
4
0 0 256 243
0 3 186 178
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box6
2
1044 0
1079 0
4
0 0 256 243
0 2 186 178
0 88 0 1
0 103 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box1
2
1077 0
1080 0
4
0 0 256 255
0 1 192 191
0 127 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box2
2
1077 0
1080 0
4
0 0 256 255
0 5 192 191
0 127 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box3
2
1077 0
1080 0
4
0 0 256 255
0 4 192 191
0 127 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box4
2
1077 0
1080 0
4
0 0 256 255
0 3 192 191
0 127 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box6
2
1077 0
1080 0
4
0 0 256 255
0 2 192 191
0 127 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box1
2
1081 0
1084 0
4
0 0 256 257
0 1 194 195
0 133 -1 0
0 137 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box2
2
1081 0
1084 0
4
0 0 256 257
0 5 194 195
0 133 -1 0
0 137 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box3
2
1081 0
1084 0
4
0 0 256 257
0 4 194 195
0 133 -1 0
0 137 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box4
2
1081 0
1084 0
4
0 0 256 257
0 3 194 195
0 133 -1 0
0 137 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box6
2
1081 0
1084 0
4
0 0 256 257
0 2 194 195
0 133 -1 0
0 137 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box1
2
297 0
1082 0
4
0 0 257 5
0 1 5 17
0 112 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box2
2
297 0
1082 0
4
0 0 257 5
0 5 5 17
0 112 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box3
2
297 0
1082 0
4
0 0 257 5
0 4 5 17
0 112 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box4
2
297 0
1082 0
4
0 0 257 5
0 3 5 17
0 112 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box6
2
297 0
1082 0
4
0 0 257 5
0 2 5 17
0 112 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box1
2
1080 0
1083 0
4
0 0 257 256
0 1 193 192
0 129 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box2
2
1080 0
1083 0
4
0 0 257 256
0 5 193 192
0 129 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box3
2
1080 0
1083 0
4
0 0 257 256
0 4 193 192
0 129 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box4
2
1080 0
1083 0
4
0 0 257 256
0 3 193 192
0 129 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box6
2
1080 0
1083 0
4
0 0 257 256
0 2 193 192
0 129 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_20 loc_9_21 right box1
2
1084 0
1089 0
4
0 0 257 259
0 1 195 196
0 137 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_9_19 loc_9_20 loc_9_21 right box2
2
1084 0
1089 0
4
0 0 257 259
0 5 195 196
0 137 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_9_19 loc_9_20 loc_9_21 right box3
2
1084 0
1089 0
4
0 0 257 259
0 4 195 196
0 137 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_9_19 loc_9_20 loc_9_21 right box4
2
1084 0
1089 0
4
0 0 257 259
0 3 195 196
0 137 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_9_19 loc_9_20 loc_9_21 right box6
2
1084 0
1089 0
4
0 0 257 259
0 2 195 196
0 137 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box7
2
1086 0
1095 0
4
0 0 258 261
0 6 57 58
0 141 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_9_20 loc_9_19 loc_9_18 left box1
2
1083 0
1088 0
4
0 0 259 257
0 1 194 193
0 131 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_9_20 loc_9_19 loc_9_18 left box2
2
1083 0
1088 0
4
0 0 259 257
0 5 194 193
0 131 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_9_20 loc_9_19 loc_9_18 left box3
2
1083 0
1088 0
4
0 0 259 257
0 4 194 193
0 131 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_9_20 loc_9_19 loc_9_18 left box4
2
1083 0
1088 0
4
0 0 259 257
0 3 194 193
0 131 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_9_20 loc_9_19 loc_9_18 left box6
2
1083 0
1088 0
4
0 0 259 257
0 2 194 193
0 131 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_8_21 loc_7_21 up box1
2
1051 0
1090 0
4
0 0 260 246
0 1 187 179
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_8_21 loc_7_21 up box2
2
1051 0
1090 0
4
0 0 260 246
0 5 187 179
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_8_21 loc_7_21 up box3
2
1051 0
1090 0
4
0 0 260 246
0 4 187 179
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_8_21 loc_7_21 up box4
2
1051 0
1090 0
4
0 0 260 246
0 3 187 179
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_8_21 loc_7_21 up box6
2
1051 0
1090 0
4
0 0 260 246
0 2 187 179
0 90 0 1
0 109 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_9_20 loc_9_19 left box1
2
1088 0
1091 0
4
0 0 260 259
0 1 195 194
0 133 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_9_20 loc_9_19 left box2
2
1088 0
1091 0
4
0 0 260 259
0 5 195 194
0 133 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_9_20 loc_9_19 left box3
2
1088 0
1091 0
4
0 0 260 259
0 4 195 194
0 133 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_9_20 loc_9_19 left box4
2
1088 0
1091 0
4
0 0 260 259
0 3 195 194
0 133 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_9_21 loc_9_20 loc_9_19 left box6
2
1088 0
1091 0
4
0 0 260 259
0 2 195 194
0 133 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box7
2
300 0
1092 0
4
0 0 261 6
0 6 0 1
0 114 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box7
2
1054 0
1093 0
4
0 0 261 247
0 6 54 50
0 91 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box7
2
1095 0
1098 0
4
0 0 261 262
0 6 58 59
0 143 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box7
2
1094 0
1097 0
4
0 0 262 261
0 6 57 56
0 135 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
307 0
1099 0
4
0 0 263 8
0 1 6 21
0 118 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
307 0
1099 0
4
0 0 263 8
0 5 6 21
0 118 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
307 0
1099 0
4
0 0 263 8
0 4 6 21
0 118 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box4
2
307 0
1099 0
4
0 0 263 8
0 3 6 21
0 118 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box6
2
307 0
1099 0
4
0 0 263 8
0 2 6 21
0 118 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
1057 0
1100 0
4
0 0 263 248
0 1 188 180
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
1057 0
1100 0
4
0 0 263 248
0 5 188 180
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box3
2
1057 0
1100 0
4
0 0 263 248
0 4 188 180
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box4
2
1057 0
1100 0
4
0 0 263 248
0 3 188 180
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box6
2
1057 0
1100 0
4
0 0 263 248
0 2 188 180
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box7
2
1057 0
1100 0
4
0 0 263 248
0 6 55 51
0 92 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box7
2
1097 0
1101 0
4
0 0 263 262
0 6 58 57
0 141 0 1
0 143 -1 0
1
end_operator
0
