begin_version
3
end_version
begin_metric
1
end_metric
283
begin_variable
var0
-1
66
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_12
at-robot loc_10_9
at-robot loc_11_11
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_12_10
at-robot loc_12_11
at-robot loc_12_9
at-robot loc_2_10
at-robot loc_2_11
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_9
at-robot loc_3_10
at-robot loc_3_11
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_9
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_6
at-robot loc_6_9
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
64
at box4 loc_10_10
at box4 loc_10_11
at box4 loc_10_12
at box4 loc_10_9
at box4 loc_11_11
at box4 loc_11_9
at box4 loc_12_11
at box4 loc_12_9
at box4 loc_2_10
at box4 loc_2_11
at box4 loc_2_3
at box4 loc_2_4
at box4 loc_2_9
at box4 loc_3_10
at box4 loc_3_11
at box4 loc_3_2
at box4 loc_3_3
at box4 loc_3_4
at box4 loc_3_5
at box4 loc_3_9
at box4 loc_4_10
at box4 loc_4_11
at box4 loc_4_2
at box4 loc_4_3
at box4 loc_4_4
at box4 loc_4_9
at box4 loc_5_10
at box4 loc_5_11
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_2
at box4 loc_6_3
at box4 loc_6_4
at box4 loc_6_6
at box4 loc_6_9
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_5
at box4 loc_7_6
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_4
at box4 loc_8_5
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_8
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_4
at box4 loc_9_5
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var2
-1
55
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_12
at box2 loc_10_9
at box2 loc_11_11
at box2 loc_11_9
at box2 loc_12_11
at box2 loc_12_9
at box2 loc_2_10
at box2 loc_2_11
at box2 loc_2_4
at box2 loc_2_9
at box2 loc_3_10
at box2 loc_3_11
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_9
at box2 loc_4_10
at box2 loc_4_11
at box2 loc_4_4
at box2 loc_4_9
at box2 loc_5_10
at box2 loc_5_11
at box2 loc_5_4
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_4
at box2 loc_6_6
at box2 loc_6_9
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var3
-1
55
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_12
at box1 loc_10_9
at box1 loc_11_11
at box1 loc_11_9
at box1 loc_12_11
at box1 loc_12_9
at box1 loc_2_10
at box1 loc_2_11
at box1 loc_2_4
at box1 loc_2_9
at box1 loc_3_10
at box1 loc_3_11
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_9
at box1 loc_4_10
at box1 loc_4_11
at box1 loc_4_4
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_11
at box1 loc_5_4
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_4
at box1 loc_6_6
at box1 loc_6_9
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var4
-1
12
at box3 loc_10_11
at box3 loc_10_12
at box3 loc_11_11
at box3 loc_12_11
at box3 loc_2_11
at box3 loc_3_11
at box3 loc_4_11
at box3 loc_5_11
at box3 loc_6_11
at box3 loc_7_11
at box3 loc_8_11
at box3 loc_9_11
end_variable
begin_variable
var5
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_12_10
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_12_11
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_12_2
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_12_3
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_2_10
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_2_11
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_2_9
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_10_11 loc_10_12 right
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_10_11 loc_11_11 down
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_10_12 loc_10_11 left
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_9 loc_11_9 down
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_11_11 loc_10_11 up
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_11_11 loc_12_11 down
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_11_3 loc_12_3 down
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_11_9 loc_10_9 up
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_11_9 loc_12_9 down
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_12_10 loc_12_11 right
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_12_10 loc_12_9 left
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_12_11 loc_11_11 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_12_11 loc_12_10 left
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_12_2 loc_12_3 right
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_12_3 loc_11_3 up
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_12_3 loc_12_2 left
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_12_9 loc_11_9 up
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_12_9 loc_12_10 right
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_2_10 loc_2_11 right
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_2_10 loc_2_9 left
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_2_10 loc_3_10 down
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_2_11 loc_2_10 left
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_2_11 loc_3_11 down
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_2_9 loc_2_10 right
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_2_9 loc_3_9 down
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_3_10 loc_2_10 up
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_3_10 loc_3_9 left
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_3_11 loc_2_11 up
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_3_11 loc_4_11 down
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_3_9 loc_2_9 up
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_3_9 loc_3_10 right
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_4_11 loc_3_11 up
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_6_10 loc_6_9 left
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_6_9 loc_6_10 right
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_8_8 loc_9_8 down
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_9_8 loc_8_8 up
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
9
23
21
50
7
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
1
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 50
2 24
3 31
4 5
end_goal
608
begin_operator
move loc_10_10 loc_10_11 right
2
24 0
79 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_10_9 left
2
27 0
80 0
1
0 0 0 3
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
15 0
81 0
1
0 0 0 58
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
23 0
82 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_10_12 right
2
25 0
83 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_11 loc_11_11 down
2
28 0
84 0
1
0 0 1 4
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
16 0
85 0
1
0 0 1 59
1
end_operator
begin_operator
move loc_10_12 loc_10_11 left
2
24 0
86 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
23 0
87 0
1
0 0 3 0
1
end_operator
begin_operator
move loc_10_9 loc_11_9 down
2
31 0
88 0
1
0 0 3 6
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
22 0
89 0
1
0 0 3 65
1
end_operator
begin_operator
move loc_11_11 loc_10_11 up
2
24 0
90 0
1
0 0 4 1
1
end_operator
begin_operator
move loc_11_11 loc_12_11 down
2
33 0
91 0
1
0 0 4 8
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
31 0
93 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_11_9 loc_10_9 up
2
27 0
94 0
1
0 0 6 3
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
30 0
95 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_11_9 loc_12_9 down
2
37 0
96 0
1
0 0 6 9
1
end_operator
begin_operator
move loc_12_10 loc_12_11 right
2
33 0
97 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_12_10 loc_12_9 left
2
37 0
98 0
1
0 0 7 9
1
end_operator
begin_operator
move loc_12_11 loc_11_11 up
2
28 0
99 0
1
0 0 8 4
1
end_operator
begin_operator
move loc_12_11 loc_12_10 left
2
32 0
100 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_12_9 loc_11_9 up
2
31 0
104 0
1
0 0 9 6
1
end_operator
begin_operator
move loc_12_9 loc_12_10 right
2
32 0
105 0
1
0 0 9 7
1
end_operator
begin_operator
move loc_2_10 loc_2_11 right
2
39 0
106 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_2_10 loc_2_9 left
2
43 0
107 0
1
0 0 10 14
1
end_operator
begin_operator
move loc_2_10 loc_3_10 down
2
44 0
108 0
1
0 0 10 15
1
end_operator
begin_operator
move loc_2_11 loc_2_10 left
2
38 0
109 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_2_11 loc_3_11 down
2
45 0
110 0
1
0 0 11 16
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
41 0
111 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
47 0
112 0
1
0 0 12 18
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
40 0
113 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
48 0
114 0
1
0 0 13 19
1
end_operator
begin_operator
move loc_2_9 loc_2_10 right
2
38 0
115 0
1
0 0 14 10
1
end_operator
begin_operator
move loc_2_9 loc_3_9 down
2
50 0
116 0
1
0 0 14 21
1
end_operator
begin_operator
move loc_3_10 loc_2_10 up
2
38 0
117 0
1
0 0 15 10
1
end_operator
begin_operator
move loc_3_10 loc_3_11 right
2
45 0
118 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_3_10 loc_3_9 left
2
50 0
119 0
1
0 0 15 21
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
51 0
120 0
1
0 0 15 22
1
end_operator
begin_operator
move loc_3_11 loc_2_11 up
2
39 0
121 0
1
0 0 16 11
1
end_operator
begin_operator
move loc_3_11 loc_3_10 left
2
44 0
122 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_3_11 loc_4_11 down
2
52 0
123 0
1
0 0 16 23
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
47 0
124 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
53 0
125 0
1
0 0 17 24
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
40 0
126 0
1
0 0 18 12
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
46 0
127 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
48 0
128 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
54 0
129 0
1
0 0 18 25
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
41 0
130 0
1
0 0 19 13
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
47 0
131 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
49 0
132 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
55 0
133 0
1
0 0 19 26
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
48 0
134 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_3_9 loc_2_9 up
2
43 0
135 0
1
0 0 21 14
1
end_operator
begin_operator
move loc_3_9 loc_3_10 right
2
44 0
136 0
1
0 0 21 15
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
56 0
137 0
1
0 0 21 27
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
44 0
138 0
1
0 0 22 15
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
52 0
139 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
56 0
140 0
1
0 0 22 27
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
57 0
141 0
1
0 0 22 28
1
end_operator
begin_operator
move loc_4_11 loc_3_11 up
2
45 0
142 0
1
0 0 23 16
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
51 0
143 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
58 0
144 0
1
0 0 23 29
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
46 0
145 0
1
0 0 24 17
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
54 0
146 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
59 0
147 0
1
0 0 24 30
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
47 0
148 0
1
0 0 25 18
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
53 0
149 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
55 0
150 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
60 0
151 0
1
0 0 25 31
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
48 0
152 0
1
0 0 26 19
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
54 0
153 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
61 0
154 0
1
0 0 26 32
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
50 0
155 0
1
0 0 27 21
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
51 0
156 0
1
0 0 27 22
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
63 0
157 0
1
0 0 27 33
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
51 0
158 0
1
0 0 28 22
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
58 0
159 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
63 0
160 0
1
0 0 28 33
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
64 0
161 0
1
0 0 28 34
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
52 0
162 0
1
0 0 29 23
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
57 0
163 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
65 0
164 0
1
0 0 29 35
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
53 0
165 0
1
0 0 30 24
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
60 0
166 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
66 0
167 0
1
0 0 30 36
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
54 0
168 0
1
0 0 31 25
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
59 0
169 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
61 0
170 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
67 0
171 0
1
0 0 31 37
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
55 0
172 0
1
0 0 32 26
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
60 0
173 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
68 0
174 0
1
0 0 32 38
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
56 0
175 0
1
0 0 33 27
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
57 0
176 0
1
0 0 33 28
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
70 0
177 0
1
0 0 33 40
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
57 0
178 0
1
0 0 34 28
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
65 0
179 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_6_10 loc_6_9 left
2
70 0
180 0
1
0 0 34 40
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
71 0
181 0
1
0 0 34 41
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
58 0
182 0
1
0 0 35 29
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
64 0
183 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
72 0
184 0
1
0 0 35 42
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
59 0
185 0
1
0 0 36 30
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
67 0
186 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
60 0
187 0
1
0 0 37 31
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
66 0
188 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
68 0
189 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
73 0
190 0
1
0 0 37 43
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
61 0
191 0
1
0 0 38 32
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
67 0
192 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
74 0
193 0
1
0 0 38 44
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
76 0
194 0
1
0 0 39 46
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
63 0
195 0
1
0 0 40 33
1
end_operator
begin_operator
move loc_6_9 loc_6_10 right
2
64 0
196 0
1
0 0 40 34
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
5 0
197 0
1
0 0 40 49
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
64 0
198 0
1
0 0 41 34
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
72 0
199 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
5 0
200 0
1
0 0 41 49
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
6 0
201 0
1
0 0 41 50
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
65 0
202 0
1
0 0 42 35
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
71 0
203 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
7 0
204 0
1
0 0 42 51
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
67 0
205 0
1
0 0 43 37
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
74 0
206 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
68 0
207 0
1
0 0 44 38
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
73 0
208 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
75 0
209 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
9 0
210 0
1
0 0 44 52
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
74 0
211 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
76 0
212 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
10 0
213 0
1
0 0 45 53
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
69 0
214 0
1
0 0 46 39
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
75 0
215 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
77 0
216 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
11 0
217 0
1
0 0 46 54
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
76 0
218 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
78 0
219 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
12 0
220 0
1
0 0 47 55
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
77 0
221 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
5 0
222 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
13 0
223 0
1
0 0 48 56
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
70 0
224 0
1
0 0 49 40
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
71 0
225 0
1
0 0 49 41
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
78 0
226 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
14 0
227 0
1
0 0 49 57
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
71 0
228 0
1
0 0 50 41
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
7 0
229 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
14 0
230 0
1
0 0 50 57
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
15 0
231 0
1
0 0 50 58
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
72 0
232 0
1
0 0 51 42
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
6 0
233 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
16 0
234 0
1
0 0 51 59
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
74 0
235 0
1
0 0 52 44
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
10 0
236 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
17 0
237 0
1
0 0 52 60
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
75 0
238 0
1
0 0 53 45
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
9 0
239 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
11 0
240 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
18 0
241 0
1
0 0 53 61
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
76 0
242 0
1
0 0 54 46
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
10 0
243 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
12 0
244 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
19 0
245 0
1
0 0 54 62
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
77 0
246 0
1
0 0 55 47
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
11 0
247 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
13 0
248 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
20 0
249 0
1
0 0 55 63
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
78 0
250 0
1
0 0 56 48
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
12 0
251 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
14 0
252 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_8_8 loc_9_8 down
2
21 0
253 0
1
0 0 56 64
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
5 0
254 0
1
0 0 57 49
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
6 0
255 0
1
0 0 57 50
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
13 0
256 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
22 0
257 0
1
0 0 57 65
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
23 0
258 0
1
0 0 58 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
6 0
259 0
1
0 0 58 50
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
16 0
260 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
22 0
261 0
1
0 0 58 65
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
24 0
262 0
1
0 0 59 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
7 0
263 0
1
0 0 59 51
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
15 0
264 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
9 0
265 0
1
0 0 60 52
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
18 0
266 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
10 0
267 0
1
0 0 61 53
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
17 0
268 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
19 0
269 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
11 0
270 0
1
0 0 62 54
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
18 0
271 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
20 0
272 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
12 0
273 0
1
0 0 63 55
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
19 0
274 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
21 0
275 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_9_8 loc_8_8 up
2
13 0
276 0
1
0 0 64 56
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
20 0
277 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
22 0
278 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
27 0
279 0
1
0 0 65 3
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
14 0
280 0
1
0 0 65 57
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
15 0
281 0
1
0 0 65 58
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
21 0
282 0
1
0 0 65 64
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box1
2
79 0
83 0
4
0 0 0 1
0 3 1 2
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box2
2
79 0
83 0
4
0 0 0 1
0 2 1 2
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box3
2
79 0
83 0
4
0 0 0 1
0 4 0 1
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box4
2
79 0
83 0
4
0 0 0 1
0 1 1 2
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
81 0
259 0
4
0 0 0 58
0 3 47 39
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
81 0
259 0
4
0 0 0 58
0 2 47 39
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
81 0
259 0
4
0 0 0 58
0 1 56 48
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box1
2
80 0
82 0
4
0 0 1 0
0 3 0 3
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box2
2
80 0
82 0
4
0 0 1 0
0 2 0 3
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box4
2
80 0
82 0
4
0 0 1 0
0 1 0 3
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box1
2
84 0
91 0
4
0 0 1 4
0 3 4 6
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box2
2
84 0
91 0
4
0 0 1 4
0 2 4 6
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box3
2
84 0
91 0
4
0 0 1 4
0 4 2 3
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box4
2
84 0
91 0
4
0 0 1 4
0 1 4 6
0 28 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
85 0
263 0
4
0 0 1 59
0 3 48 40
0 7 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
85 0
263 0
4
0 0 1 59
0 2 48 40
0 7 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
85 0
263 0
4
0 0 1 59
0 4 11 10
0 7 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box4
2
85 0
263 0
4
0 0 1 59
0 1 57 49
0 7 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box1
2
79 0
87 0
4
0 0 3 0
0 3 0 1
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box2
2
79 0
87 0
4
0 0 3 0
0 2 0 1
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box4
2
79 0
87 0
4
0 0 3 0
0 1 0 1
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box1
2
88 0
96 0
4
0 0 3 6
0 3 5 7
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box2
2
88 0
96 0
4
0 0 3 6
0 2 5 7
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_9 loc_11_9 loc_12_9 down box4
2
88 0
96 0
4
0 0 3 6
0 1 5 7
0 31 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box1
2
89 0
280 0
4
0 0 3 65
0 3 54 46
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box2
2
89 0
280 0
4
0 0 3 65
0 2 54 46
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box4
2
89 0
280 0
4
0 0 3 65
0 1 63 55
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box1
2
85 0
90 0
4
0 0 4 1
0 3 1 48
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box2
2
85 0
90 0
4
0 0 4 1
0 2 1 48
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box3
2
85 0
90 0
4
0 0 4 1
0 4 0 11
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box4
2
85 0
90 0
4
0 0 4 1
0 1 1 57
0 16 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box1
2
89 0
94 0
4
0 0 6 3
0 3 3 54
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box2
2
89 0
94 0
4
0 0 6 3
0 2 3 54
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box4
2
89 0
94 0
4
0 0 6 3
0 1 3 63
0 22 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box1
2
90 0
99 0
4
0 0 8 4
0 3 4 1
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box2
2
90 0
99 0
4
0 0 8 4
0 2 4 1
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box3
2
90 0
99 0
4
0 0 8 4
0 4 2 0
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box4
2
90 0
99 0
4
0 0 8 4
0 1 4 1
0 24 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box1
2
94 0
104 0
4
0 0 9 6
0 3 5 3
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box2
2
94 0
104 0
4
0 0 9 6
0 2 5 3
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_12_9 loc_11_9 loc_10_9 up box4
2
94 0
104 0
4
0 0 9 6
0 1 5 3
0 27 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_2_10 loc_3_10 loc_4_10 down box1
2
108 0
120 0
4
0 0 10 15
0 3 12 17
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_2_10 loc_3_10 loc_4_10 down box2
2
108 0
120 0
4
0 0 10 15
0 2 12 17
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_2_10 loc_3_10 loc_4_10 down box4
2
108 0
120 0
4
0 0 10 15
0 1 13 20
0 44 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_2_11 loc_2_10 loc_2_9 left box1
2
107 0
109 0
4
0 0 11 10
0 3 8 11
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_11 loc_2_10 loc_2_9 left box2
2
107 0
109 0
4
0 0 11 10
0 2 8 11
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_11 loc_2_10 loc_2_9 left box4
2
107 0
109 0
4
0 0 11 10
0 1 8 12
0 38 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_11 loc_3_11 loc_4_11 down box1
2
110 0
123 0
4
0 0 11 16
0 3 13 18
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_2_11 loc_3_11 loc_4_11 down box2
2
110 0
123 0
4
0 0 11 16
0 2 13 18
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_2_11 loc_3_11 loc_4_11 down box3
2
110 0
123 0
4
0 0 11 16
0 4 5 6
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_2_11 loc_3_11 loc_4_11 down box4
2
110 0
123 0
4
0 0 11 16
0 1 14 21
0 45 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box4
2
112 0
129 0
4
0 0 12 18
0 1 16 23
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
2
114 0
133 0
4
0 0 13 19
0 3 14 19
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box2
2
114 0
133 0
4
0 0 13 19
0 2 14 19
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box4
2
114 0
133 0
4
0 0 13 19
0 1 17 24
0 48 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_2_9 loc_2_10 loc_2_11 right box1
2
106 0
115 0
4
0 0 14 10
0 3 8 9
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_9 loc_2_10 loc_2_11 right box2
2
106 0
115 0
4
0 0 14 10
0 2 8 9
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_9 loc_2_10 loc_2_11 right box4
2
106 0
115 0
4
0 0 14 10
0 1 8 9
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box1
2
116 0
137 0
4
0 0 14 21
0 3 16 20
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box2
2
116 0
137 0
4
0 0 14 21
0 2 16 20
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box4
2
116 0
137 0
4
0 0 14 21
0 1 19 25
0 50 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box1
2
120 0
141 0
4
0 0 15 22
0 3 17 21
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box2
2
120 0
141 0
4
0 0 15 22
0 2 17 21
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box4
2
120 0
141 0
4
0 0 15 22
0 1 20 26
0 51 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box1
2
119 0
122 0
4
0 0 16 15
0 3 12 16
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box2
2
119 0
122 0
4
0 0 16 15
0 2 12 16
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box4
2
119 0
122 0
4
0 0 16 15
0 1 13 19
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box1
2
123 0
144 0
4
0 0 16 23
0 3 18 22
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box2
2
123 0
144 0
4
0 0 16 23
0 2 18 22
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box3
2
123 0
144 0
4
0 0 16 23
0 4 6 7
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box4
2
123 0
144 0
4
0 0 16 23
0 1 21 27
0 52 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box4
2
124 0
128 0
4
0 0 17 18
0 1 16 17
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box4
2
125 0
147 0
4
0 0 17 24
0 1 22 28
0 53 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
128 0
132 0
4
0 0 18 19
0 3 14 15
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
128 0
132 0
4
0 0 18 19
0 2 14 15
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box4
2
128 0
132 0
4
0 0 18 19
0 1 17 18
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box4
2
129 0
151 0
4
0 0 18 25
0 1 23 29
0 54 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box4
2
127 0
131 0
4
0 0 19 18
0 1 16 15
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
133 0
154 0
4
0 0 19 26
0 3 19 23
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
133 0
154 0
4
0 0 19 26
0 2 19 23
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box4
2
133 0
154 0
4
0 0 19 26
0 1 24 30
0 55 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box1
2
118 0
136 0
4
0 0 21 15
0 3 12 13
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box2
2
118 0
136 0
4
0 0 21 15
0 2 12 13
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box4
2
118 0
136 0
4
0 0 21 15
0 1 13 14
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box1
2
137 0
157 0
4
0 0 21 27
0 3 20 24
0 56 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box2
2
137 0
157 0
4
0 0 21 27
0 2 20 24
0 56 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box4
2
137 0
157 0
4
0 0 21 27
0 1 25 31
0 56 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_4_10 loc_3_10 loc_2_10 up box1
2
117 0
138 0
4
0 0 22 15
0 3 12 8
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_3_10 loc_2_10 up box2
2
117 0
138 0
4
0 0 22 15
0 2 12 8
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_3_10 loc_2_10 up box4
2
117 0
138 0
4
0 0 22 15
0 1 13 8
0 38 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box1
2
141 0
161 0
4
0 0 22 28
0 3 21 25
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box2
2
141 0
161 0
4
0 0 22 28
0 2 21 25
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box4
2
141 0
161 0
4
0 0 22 28
0 1 26 32
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_11 loc_3_11 loc_2_11 up box1
2
121 0
142 0
4
0 0 23 16
0 3 13 9
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_3_11 loc_2_11 up box2
2
121 0
142 0
4
0 0 23 16
0 2 13 9
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_3_11 loc_2_11 up box3
2
121 0
142 0
4
0 0 23 16
0 4 5 4
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_3_11 loc_2_11 up box4
2
121 0
142 0
4
0 0 23 16
0 1 14 9
0 39 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box1
2
140 0
143 0
4
0 0 23 22
0 3 17 20
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box2
2
140 0
143 0
4
0 0 23 22
0 2 17 20
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box4
2
140 0
143 0
4
0 0 23 22
0 1 20 25
0 51 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box1
2
144 0
164 0
4
0 0 23 29
0 3 22 26
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box2
2
144 0
164 0
4
0 0 23 29
0 2 22 26
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box3
2
144 0
164 0
4
0 0 23 29
0 4 7 8
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box4
2
144 0
164 0
4
0 0 23 29
0 1 27 33
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box4
2
146 0
150 0
4
0 0 24 25
0 1 23 24
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box4
2
147 0
167 0
4
0 0 24 30
0 1 28 34
0 59 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box4
2
126 0
148 0
4
0 0 25 18
0 1 16 10
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box4
2
151 0
171 0
4
0 0 25 31
0 1 29 35
0 60 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
130 0
152 0
4
0 0 26 19
0 3 14 10
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box2
2
130 0
152 0
4
0 0 26 19
0 2 14 10
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box4
2
130 0
152 0
4
0 0 26 19
0 1 17 11
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box4
2
149 0
153 0
4
0 0 26 25
0 1 23 22
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
154 0
174 0
4
0 0 26 32
0 3 23 27
0 61 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
154 0
174 0
4
0 0 26 32
0 2 23 27
0 61 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box4
2
154 0
174 0
4
0 0 26 32
0 1 30 36
0 61 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box1
2
135 0
155 0
4
0 0 27 21
0 3 16 11
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box2
2
135 0
155 0
4
0 0 27 21
0 2 16 11
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box4
2
135 0
155 0
4
0 0 27 21
0 1 19 12
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box1
2
139 0
156 0
4
0 0 27 22
0 3 17 18
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box2
2
139 0
156 0
4
0 0 27 22
0 2 17 18
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box4
2
139 0
156 0
4
0 0 27 22
0 1 20 21
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box1
2
157 0
177 0
4
0 0 27 33
0 3 24 29
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box2
2
157 0
177 0
4
0 0 27 33
0 2 24 29
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box4
2
157 0
177 0
4
0 0 27 33
0 1 31 38
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box1
2
138 0
158 0
4
0 0 28 22
0 3 17 12
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box2
2
138 0
158 0
4
0 0 28 22
0 2 17 12
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box4
2
138 0
158 0
4
0 0 28 22
0 1 20 13
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box1
2
161 0
181 0
4
0 0 28 34
0 3 25 30
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box2
2
161 0
181 0
4
0 0 28 34
0 2 25 30
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box4
2
161 0
181 0
4
0 0 28 34
0 1 32 39
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box1
2
142 0
162 0
4
0 0 29 23
0 3 18 13
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box2
2
142 0
162 0
4
0 0 29 23
0 2 18 13
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box3
2
142 0
162 0
4
0 0 29 23
0 4 6 5
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box4
2
142 0
162 0
4
0 0 29 23
0 1 21 14
0 45 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box1
2
160 0
163 0
4
0 0 29 28
0 3 21 24
0 57 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box2
2
160 0
163 0
4
0 0 29 28
0 2 21 24
0 57 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box4
2
160 0
163 0
4
0 0 29 28
0 1 26 31
0 57 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box1
2
164 0
184 0
4
0 0 29 35
0 3 26 31
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box2
2
164 0
184 0
4
0 0 29 35
0 2 26 31
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box3
2
164 0
184 0
4
0 0 29 35
0 4 8 9
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box4
2
164 0
184 0
4
0 0 29 35
0 1 33 40
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box4
2
145 0
165 0
4
0 0 30 24
0 1 22 15
0 46 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box4
2
166 0
170 0
4
0 0 30 31
0 1 29 30
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box4
2
148 0
168 0
4
0 0 31 25
0 1 23 16
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box4
2
171 0
190 0
4
0 0 31 37
0 1 35 41
0 67 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
152 0
172 0
4
0 0 32 26
0 3 19 14
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
152 0
172 0
4
0 0 32 26
0 2 19 14
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box4
2
152 0
172 0
4
0 0 32 26
0 1 24 17
0 48 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
169 0
173 0
4
0 0 32 31
0 1 29 28
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
174 0
193 0
4
0 0 32 38
0 3 27 33
0 68 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
174 0
193 0
4
0 0 32 38
0 2 27 33
0 68 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box4
2
174 0
193 0
4
0 0 32 38
0 1 36 42
0 68 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box1
2
155 0
175 0
4
0 0 33 27
0 3 20 16
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box2
2
155 0
175 0
4
0 0 33 27
0 2 20 16
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box4
2
155 0
175 0
4
0 0 33 27
0 1 25 19
0 50 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box1
2
159 0
176 0
4
0 0 33 28
0 3 21 22
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box2
2
159 0
176 0
4
0 0 33 28
0 2 21 22
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box4
2
159 0
176 0
4
0 0 33 28
0 1 26 27
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box1
2
177 0
197 0
4
0 0 33 40
0 3 29 38
0 5 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box2
2
177 0
197 0
4
0 0 33 40
0 2 29 38
0 5 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box4
2
177 0
197 0
4
0 0 33 40
0 1 38 47
0 5 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box1
2
158 0
178 0
4
0 0 34 28
0 3 21 17
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box2
2
158 0
178 0
4
0 0 34 28
0 2 21 17
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box4
2
158 0
178 0
4
0 0 34 28
0 1 26 20
0 51 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
181 0
201 0
4
0 0 34 41
0 3 30 39
0 6 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
181 0
201 0
4
0 0 34 41
0 2 30 39
0 6 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
181 0
201 0
4
0 0 34 41
0 1 39 48
0 6 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box1
2
162 0
182 0
4
0 0 35 29
0 3 22 18
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box2
2
162 0
182 0
4
0 0 35 29
0 2 22 18
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box3
2
162 0
182 0
4
0 0 35 29
0 4 7 6
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box4
2
162 0
182 0
4
0 0 35 29
0 1 27 21
0 52 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box1
2
180 0
183 0
4
0 0 35 34
0 3 25 29
0 64 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box2
2
180 0
183 0
4
0 0 35 34
0 2 25 29
0 64 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box4
2
180 0
183 0
4
0 0 35 34
0 1 32 38
0 64 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box1
2
184 0
204 0
4
0 0 35 42
0 3 31 40
0 7 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box2
2
184 0
204 0
4
0 0 35 42
0 2 31 40
0 7 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box3
2
184 0
204 0
4
0 0 35 42
0 4 9 10
0 7 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box4
2
184 0
204 0
4
0 0 35 42
0 1 40 49
0 7 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box4
2
165 0
185 0
4
0 0 36 30
0 1 28 22
0 53 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box4
2
186 0
189 0
4
0 0 36 37
0 1 35 36
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box4
2
168 0
187 0
4
0 0 37 31
0 1 29 23
0 54 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
172 0
191 0
4
0 0 38 32
0 3 23 19
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
172 0
191 0
4
0 0 38 32
0 2 23 19
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box4
2
172 0
191 0
4
0 0 38 32
0 1 30 24
0 55 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box4
2
188 0
192 0
4
0 0 38 37
0 1 35 34
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
193 0
210 0
4
0 0 38 44
0 3 33 41
0 9 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box2
2
193 0
210 0
4
0 0 38 44
0 2 33 41
0 9 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box4
2
193 0
210 0
4
0 0 38 44
0 1 42 50
0 9 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box1
2
175 0
195 0
4
0 0 40 33
0 3 24 20
0 56 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box2
2
175 0
195 0
4
0 0 40 33
0 2 24 20
0 56 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box4
2
175 0
195 0
4
0 0 40 33
0 1 31 25
0 56 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box1
2
179 0
196 0
4
0 0 40 34
0 3 25 26
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box2
2
179 0
196 0
4
0 0 40 34
0 2 25 26
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box4
2
179 0
196 0
4
0 0 40 34
0 1 32 33
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box1
2
197 0
227 0
4
0 0 40 49
0 3 38 46
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box2
2
197 0
227 0
4
0 0 40 49
0 2 38 46
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box4
2
197 0
227 0
4
0 0 40 49
0 1 47 55
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
178 0
198 0
4
0 0 41 34
0 3 25 21
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box2
2
178 0
198 0
4
0 0 41 34
0 2 25 21
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box4
2
178 0
198 0
4
0 0 41 34
0 1 32 26
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
200 0
226 0
4
0 0 41 49
0 3 38 37
0 5 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
200 0
226 0
4
0 0 41 49
0 2 38 37
0 5 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box4
2
200 0
226 0
4
0 0 41 49
0 1 47 46
0 5 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
201 0
231 0
4
0 0 41 50
0 3 39 47
0 6 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
201 0
231 0
4
0 0 41 50
0 2 39 47
0 6 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
201 0
231 0
4
0 0 41 50
0 1 48 56
0 6 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box1
2
182 0
202 0
4
0 0 42 35
0 3 26 22
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box2
2
182 0
202 0
4
0 0 42 35
0 2 26 22
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box3
2
182 0
202 0
4
0 0 42 35
0 4 8 7
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box4
2
182 0
202 0
4
0 0 42 35
0 1 33 27
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
200 0
203 0
4
0 0 42 41
0 3 30 38
0 5 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
200 0
203 0
4
0 0 42 41
0 2 30 38
0 5 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
200 0
203 0
4
0 0 42 41
0 1 39 47
0 5 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
204 0
234 0
4
0 0 42 51
0 3 40 48
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
204 0
234 0
4
0 0 42 51
0 2 40 48
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
204 0
234 0
4
0 0 42 51
0 4 10 11
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
204 0
234 0
4
0 0 42 51
0 1 49 57
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box4
2
187 0
205 0
4
0 0 43 37
0 1 35 29
0 60 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
206 0
209 0
4
0 0 43 44
0 3 33 34
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box2
2
206 0
209 0
4
0 0 43 44
0 2 33 34
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box4
2
206 0
209 0
4
0 0 43 44
0 1 42 43
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
191 0
207 0
4
0 0 44 38
0 3 27 23
0 61 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
191 0
207 0
4
0 0 44 38
0 2 27 23
0 61 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box4
2
191 0
207 0
4
0 0 44 38
0 1 36 30
0 61 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
209 0
212 0
4
0 0 44 45
0 3 34 35
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box2
2
209 0
212 0
4
0 0 44 45
0 2 34 35
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box4
2
209 0
212 0
4
0 0 44 45
0 1 43 44
0 75 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
210 0
237 0
4
0 0 44 52
0 3 41 49
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
210 0
237 0
4
0 0 44 52
0 2 41 49
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box4
2
210 0
237 0
4
0 0 44 52
0 1 50 58
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box1
2
208 0
211 0
4
0 0 45 44
0 3 33 32
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box2
2
208 0
211 0
4
0 0 45 44
0 2 33 32
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box4
2
208 0
211 0
4
0 0 45 44
0 1 42 41
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
212 0
216 0
4
0 0 45 46
0 3 35 36
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box2
2
212 0
216 0
4
0 0 45 46
0 2 35 36
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box4
2
212 0
216 0
4
0 0 45 46
0 1 44 45
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box1
2
213 0
241 0
4
0 0 45 53
0 3 42 50
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box2
2
213 0
241 0
4
0 0 45 53
0 2 42 50
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box4
2
213 0
241 0
4
0 0 45 53
0 1 51 59
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box1
2
211 0
215 0
4
0 0 46 45
0 3 34 33
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box2
2
211 0
215 0
4
0 0 46 45
0 2 34 33
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box4
2
211 0
215 0
4
0 0 46 45
0 1 43 42
0 74 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
216 0
219 0
4
0 0 46 47
0 3 36 37
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
216 0
219 0
4
0 0 46 47
0 2 36 37
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box4
2
216 0
219 0
4
0 0 46 47
0 1 45 46
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box1
2
217 0
245 0
4
0 0 46 54
0 3 43 51
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box2
2
217 0
245 0
4
0 0 46 54
0 2 43 51
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box4
2
217 0
245 0
4
0 0 46 54
0 1 52 60
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box1
2
215 0
218 0
4
0 0 47 46
0 3 35 34
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box2
2
215 0
218 0
4
0 0 47 46
0 2 35 34
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box4
2
215 0
218 0
4
0 0 47 46
0 1 44 43
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
219 0
222 0
4
0 0 47 48
0 3 37 38
0 5 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
219 0
222 0
4
0 0 47 48
0 2 37 38
0 5 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box4
2
219 0
222 0
4
0 0 47 48
0 1 46 47
0 5 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
220 0
249 0
4
0 0 47 55
0 3 44 52
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
220 0
249 0
4
0 0 47 55
0 2 44 52
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box4
2
220 0
249 0
4
0 0 47 55
0 1 53 61
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
218 0
221 0
4
0 0 48 47
0 3 36 35
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
218 0
221 0
4
0 0 48 47
0 2 36 35
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box4
2
218 0
221 0
4
0 0 48 47
0 1 45 44
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
222 0
225 0
4
0 0 48 49
0 3 38 30
0 5 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
222 0
225 0
4
0 0 48 49
0 2 38 30
0 5 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box4
2
222 0
225 0
4
0 0 48 49
0 1 47 39
0 5 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box1
2
223 0
253 0
4
0 0 48 56
0 3 45 53
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box2
2
223 0
253 0
4
0 0 48 56
0 2 45 53
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box4
2
223 0
253 0
4
0 0 48 56
0 1 54 62
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box1
2
195 0
224 0
4
0 0 49 40
0 3 29 24
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box2
2
195 0
224 0
4
0 0 49 40
0 2 29 24
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box4
2
195 0
224 0
4
0 0 49 40
0 1 38 31
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
199 0
225 0
4
0 0 49 41
0 3 30 31
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
199 0
225 0
4
0 0 49 41
0 2 30 31
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
199 0
225 0
4
0 0 49 41
0 1 39 40
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
221 0
226 0
4
0 0 49 48
0 3 37 36
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
221 0
226 0
4
0 0 49 48
0 2 37 36
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box4
2
221 0
226 0
4
0 0 49 48
0 1 46 45
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
227 0
257 0
4
0 0 49 57
0 3 46 54
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
227 0
257 0
4
0 0 49 57
0 2 46 54
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
227 0
257 0
4
0 0 49 57
0 1 55 63
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
198 0
228 0
4
0 0 50 41
0 3 30 25
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
198 0
228 0
4
0 0 50 41
0 2 30 25
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
198 0
228 0
4
0 0 50 41
0 1 39 32
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
230 0
256 0
4
0 0 50 57
0 3 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
230 0
256 0
4
0 0 50 57
0 2 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box4
2
230 0
256 0
4
0 0 50 57
0 1 55 54
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
231 0
258 0
4
0 0 50 58
0 3 47 0
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
231 0
258 0
4
0 0 50 58
0 2 47 0
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
231 0
258 0
4
0 0 50 58
0 1 56 0
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
202 0
232 0
4
0 0 51 42
0 3 31 26
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
202 0
232 0
4
0 0 51 42
0 2 31 26
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
202 0
232 0
4
0 0 51 42
0 4 9 8
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box4
2
202 0
232 0
4
0 0 51 42
0 1 40 33
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
230 0
233 0
4
0 0 51 50
0 3 39 46
0 6 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
230 0
233 0
4
0 0 51 50
0 2 39 46
0 6 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
230 0
233 0
4
0 0 51 50
0 1 48 55
0 6 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
234 0
262 0
4
0 0 51 59
0 3 48 1
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
234 0
262 0
4
0 0 51 59
0 2 48 1
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
234 0
262 0
4
0 0 51 59
0 4 11 0
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box4
2
234 0
262 0
4
0 0 51 59
0 1 57 1
0 16 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
207 0
235 0
4
0 0 52 44
0 3 33 27
0 68 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box2
2
207 0
235 0
4
0 0 52 44
0 2 33 27
0 68 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box4
2
207 0
235 0
4
0 0 52 44
0 1 42 36
0 68 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box1
2
236 0
240 0
4
0 0 52 53
0 3 42 43
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box2
2
236 0
240 0
4
0 0 52 53
0 2 42 43
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box4
2
236 0
240 0
4
0 0 52 53
0 1 51 52
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
240 0
244 0
4
0 0 53 54
0 3 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
240 0
244 0
4
0 0 53 54
0 2 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box4
2
240 0
244 0
4
0 0 53 54
0 1 52 53
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
214 0
242 0
4
0 0 54 46
0 3 35 28
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
214 0
242 0
4
0 0 54 46
0 2 35 28
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box4
2
214 0
242 0
4
0 0 54 46
0 1 44 37
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
239 0
243 0
4
0 0 54 53
0 3 42 41
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
239 0
243 0
4
0 0 54 53
0 2 42 41
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box4
2
239 0
243 0
4
0 0 54 53
0 1 51 50
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box1
2
244 0
248 0
4
0 0 54 55
0 3 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box2
2
244 0
248 0
4
0 0 54 55
0 2 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box4
2
244 0
248 0
4
0 0 54 55
0 1 53 54
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
243 0
247 0
4
0 0 55 54
0 3 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
243 0
247 0
4
0 0 55 54
0 2 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box4
2
243 0
247 0
4
0 0 55 54
0 1 52 51
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
248 0
252 0
4
0 0 55 56
0 3 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
248 0
252 0
4
0 0 55 56
0 2 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box4
2
248 0
252 0
4
0 0 55 56
0 1 54 55
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box1
2
247 0
251 0
4
0 0 56 55
0 3 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box2
2
247 0
251 0
4
0 0 56 55
0 2 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box4
2
247 0
251 0
4
0 0 56 55
0 1 53 52
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
252 0
255 0
4
0 0 56 57
0 3 46 39
0 6 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
252 0
255 0
4
0 0 56 57
0 2 46 39
0 6 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box4
2
252 0
255 0
4
0 0 56 57
0 1 55 48
0 6 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box1
2
224 0
254 0
4
0 0 57 49
0 3 38 29
0 5 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box2
2
224 0
254 0
4
0 0 57 49
0 2 38 29
0 5 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box4
2
224 0
254 0
4
0 0 57 49
0 1 47 38
0 5 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
229 0
255 0
4
0 0 57 50
0 3 39 40
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
229 0
255 0
4
0 0 57 50
0 2 39 40
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
229 0
255 0
4
0 0 57 50
0 1 48 49
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
251 0
256 0
4
0 0 57 56
0 3 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
251 0
256 0
4
0 0 57 56
0 2 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box4
2
251 0
256 0
4
0 0 57 56
0 1 54 53
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box1
2
257 0
279 0
4
0 0 57 65
0 3 54 3
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box2
2
257 0
279 0
4
0 0 57 65
0 2 54 3
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box4
2
257 0
279 0
4
0 0 57 65
0 1 63 3
0 22 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
228 0
259 0
4
0 0 58 50
0 3 39 30
0 6 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
228 0
259 0
4
0 0 58 50
0 2 39 30
0 6 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
228 0
259 0
4
0 0 58 50
0 1 48 39
0 6 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
261 0
282 0
4
0 0 58 65
0 3 54 53
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
261 0
282 0
4
0 0 58 65
0 2 54 53
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
261 0
282 0
4
0 0 58 65
0 1 63 62
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box1
2
84 0
262 0
4
0 0 59 1
0 3 1 4
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box2
2
84 0
262 0
4
0 0 59 1
0 2 1 4
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box3
2
84 0
262 0
4
0 0 59 1
0 4 0 2
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box4
2
84 0
262 0
4
0 0 59 1
0 1 1 4
0 24 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
232 0
263 0
4
0 0 59 51
0 3 40 31
0 7 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
232 0
263 0
4
0 0 59 51
0 2 40 31
0 7 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
232 0
263 0
4
0 0 59 51
0 4 10 9
0 7 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
232 0
263 0
4
0 0 59 51
0 1 49 40
0 7 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
261 0
264 0
4
0 0 59 58
0 3 47 54
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
261 0
264 0
4
0 0 59 58
0 2 47 54
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box4
2
261 0
264 0
4
0 0 59 58
0 1 56 63
0 15 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
235 0
265 0
4
0 0 60 52
0 3 41 33
0 9 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
235 0
265 0
4
0 0 60 52
0 2 41 33
0 9 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box4
2
235 0
265 0
4
0 0 60 52
0 1 50 42
0 9 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
266 0
269 0
4
0 0 60 61
0 3 50 51
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
266 0
269 0
4
0 0 60 61
0 2 50 51
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box4
2
266 0
269 0
4
0 0 60 61
0 1 59 60
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
238 0
267 0
4
0 0 61 53
0 3 42 34
0 10 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
238 0
267 0
4
0 0 61 53
0 2 42 34
0 10 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box4
2
238 0
267 0
4
0 0 61 53
0 1 51 43
0 10 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
269 0
272 0
4
0 0 61 62
0 3 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
269 0
272 0
4
0 0 61 62
0 2 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box4
2
269 0
272 0
4
0 0 61 62
0 1 60 61
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box1
2
242 0
270 0
4
0 0 62 54
0 3 43 35
0 11 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box2
2
242 0
270 0
4
0 0 62 54
0 2 43 35
0 11 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box4
2
242 0
270 0
4
0 0 62 54
0 1 52 44
0 11 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
268 0
271 0
4
0 0 62 61
0 3 50 49
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
268 0
271 0
4
0 0 62 61
0 2 50 49
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box4
2
268 0
271 0
4
0 0 62 61
0 1 59 58
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
272 0
275 0
4
0 0 62 63
0 3 52 53
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
272 0
275 0
4
0 0 62 63
0 2 52 53
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
272 0
275 0
4
0 0 62 63
0 1 61 62
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
246 0
273 0
4
0 0 63 55
0 3 44 36
0 12 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
246 0
273 0
4
0 0 63 55
0 2 44 36
0 12 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box4
2
246 0
273 0
4
0 0 63 55
0 1 53 45
0 12 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
271 0
274 0
4
0 0 63 62
0 3 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
271 0
274 0
4
0 0 63 62
0 2 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box4
2
271 0
274 0
4
0 0 63 62
0 1 60 59
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
275 0
278 0
4
0 0 63 64
0 3 53 54
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
275 0
278 0
4
0 0 63 64
0 2 53 54
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
275 0
278 0
4
0 0 63 64
0 1 62 63
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box1
2
250 0
276 0
4
0 0 64 56
0 3 45 37
0 13 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box2
2
250 0
276 0
4
0 0 64 56
0 2 45 37
0 13 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box4
2
250 0
276 0
4
0 0 64 56
0 1 54 46
0 13 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
274 0
277 0
4
0 0 64 63
0 3 52 51
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
274 0
277 0
4
0 0 64 63
0 2 52 51
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
274 0
277 0
4
0 0 64 63
0 1 61 60
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
278 0
281 0
4
0 0 64 65
0 3 54 47
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
278 0
281 0
4
0 0 64 65
0 2 54 47
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
278 0
281 0
4
0 0 64 65
0 1 63 56
0 15 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box1
2
88 0
279 0
4
0 0 65 3
0 3 3 5
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box2
2
88 0
279 0
4
0 0 65 3
0 2 3 5
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box4
2
88 0
279 0
4
0 0 65 3
0 1 3 5
0 27 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
254 0
280 0
4
0 0 65 57
0 3 46 38
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
254 0
280 0
4
0 0 65 57
0 2 46 38
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
254 0
280 0
4
0 0 65 57
0 1 55 47
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
260 0
281 0
4
0 0 65 58
0 3 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
260 0
281 0
4
0 0 65 58
0 2 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
260 0
281 0
4
0 0 65 58
0 1 56 57
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
277 0
282 0
4
0 0 65 64
0 3 53 52
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
277 0
282 0
4
0 0 65 64
0 2 53 52
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
277 0
282 0
4
0 0 65 64
0 1 62 61
0 20 0 1
0 21 -1 0
1
end_operator
0
