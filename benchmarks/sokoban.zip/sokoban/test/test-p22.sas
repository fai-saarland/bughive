begin_version
3
end_version
begin_metric
1
end_metric
323
begin_variable
var0
-1
81
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_10_9
at-robot loc_11_10
at-robot loc_11_2
at-robot loc_11_3
at-robot loc_11_4
at-robot loc_11_5
at-robot loc_11_7
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_2_10
at-robot loc_2_4
at-robot loc_2_5
at-robot loc_2_6
at-robot loc_2_8
at-robot loc_2_9
at-robot loc_3_10
at-robot loc_3_11
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_2
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_7_11
at-robot loc_7_2
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_2
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_2
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
68
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_10_9
at box2 loc_11_10
at box2 loc_11_2
at box2 loc_11_3
at box2 loc_11_4
at box2 loc_11_5
at box2 loc_11_7
at box2 loc_11_8
at box2 loc_11_9
at box2 loc_2_4
at box2 loc_2_5
at box2 loc_2_6
at box2 loc_3_2
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_3_8
at box2 loc_4_2
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_6_2
at box2 loc_6_4
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_7_11
at box2 loc_7_2
at box2 loc_7_4
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_2
at box2 loc_8_3
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_2
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var2
-1
68
at box3 loc_10_10
at box3 loc_10_11
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_10_9
at box3 loc_11_10
at box3 loc_11_2
at box3 loc_11_3
at box3 loc_11_4
at box3 loc_11_5
at box3 loc_11_7
at box3 loc_11_8
at box3 loc_11_9
at box3 loc_2_4
at box3 loc_2_5
at box3 loc_2_6
at box3 loc_3_2
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_3_7
at box3 loc_3_8
at box3 loc_4_2
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_6_2
at box3 loc_6_4
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_7_11
at box3 loc_7_2
at box3 loc_7_4
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_2
at box3 loc_8_3
at box3 loc_8_4
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_2
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var3
-1
68
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_10_9
at box1 loc_11_10
at box1 loc_11_2
at box1 loc_11_3
at box1 loc_11_4
at box1 loc_11_5
at box1 loc_11_7
at box1 loc_11_8
at box1 loc_11_9
at box1 loc_2_4
at box1 loc_2_5
at box1 loc_2_6
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_6_2
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_7_11
at box1 loc_7_2
at box1 loc_7_4
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_2
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_2
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var4
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_11_10
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_11_4
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_2_10
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_2_9
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_10_10 loc_11_10 down
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_10_4 loc_11_4 down
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_10_8 loc_10_9 right
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_10_8 loc_11_8 down
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_10_9 loc_10_8 left
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_10_9 loc_11_9 down
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_11_10 loc_10_10 up
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_11_10 loc_11_9 left
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_11_3 loc_11_4 right
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_11_4 loc_10_4 up
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_11_4 loc_11_3 left
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_11_4 loc_11_5 right
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_11_5 loc_11_4 left
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_11_7 loc_11_8 right
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_11_8 loc_10_8 up
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_11_8 loc_11_7 left
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_11_9 loc_10_9 up
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_11_9 loc_11_10 right
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_2_10 loc_2_9 left
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_2_10 loc_3_10 down
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_2_4 loc_2_5 right
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_2_5 loc_2_4 left
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_2_5 loc_2_6 right
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_2_6 loc_2_5 left
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_2_8 loc_2_9 right
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_2_9 loc_2_10 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_2_9 loc_2_8 left
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_3_10 loc_2_10 up
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_3_11 loc_4_11 down
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_4_11 loc_3_11 up
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_7_2 loc_7_3 right
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_7_3 loc_7_2 left
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
47
66
0
64
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
3
1 67
2 0
3 22
end_goal
676
begin_operator
move loc_10_10 loc_10_11 right
2
5 0
85 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_10_9 left
2
12 0
86 0
1
0 0 0 8
1
end_operator
begin_operator
move loc_10_10 loc_11_10 down
2
13 0
87 0
1
0 0 0 9
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
76 0
88 0
1
0 0 0 72
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
4 0
89 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
77 0
90 0
1
0 0 1 73
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
7 0
91 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
15 0
92 0
1
0 0 2 11
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
6 0
93 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
8 0
94 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_4 loc_11_4 down
2
16 0
95 0
1
0 0 3 12
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
79 0
96 0
1
0 0 3 75
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
7 0
97 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
9 0
98 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
17 0
99 0
1
0 0 4 13
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
80 0
100 0
1
0 0 4 76
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
8 0
101 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
10 0
102 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
81 0
103 0
1
0 0 5 77
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
9 0
104 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
11 0
105 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
18 0
106 0
1
0 0 6 14
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
82 0
107 0
1
0 0 6 78
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
10 0
108 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_8 loc_10_9 right
2
12 0
109 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_8 loc_11_8 down
2
19 0
110 0
1
0 0 7 15
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
83 0
111 0
1
0 0 7 79
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
4 0
112 0
1
0 0 8 0
1
end_operator
begin_operator
move loc_10_9 loc_10_8 left
2
11 0
113 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_9 loc_11_9 down
2
20 0
114 0
1
0 0 8 16
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
84 0
115 0
1
0 0 8 80
1
end_operator
begin_operator
move loc_11_10 loc_10_10 up
2
4 0
116 0
1
0 0 9 0
1
end_operator
begin_operator
move loc_11_10 loc_11_9 left
2
20 0
117 0
1
0 0 9 16
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
15 0
118 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
6 0
119 0
1
0 0 11 2
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
14 0
120 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_11_3 loc_11_4 right
2
16 0
121 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_4 loc_10_4 up
2
7 0
122 0
1
0 0 12 3
1
end_operator
begin_operator
move loc_11_4 loc_11_3 left
2
15 0
123 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_4 loc_11_5 right
2
17 0
124 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
8 0
125 0
1
0 0 13 4
1
end_operator
begin_operator
move loc_11_5 loc_11_4 left
2
16 0
126 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
10 0
127 0
1
0 0 14 6
1
end_operator
begin_operator
move loc_11_7 loc_11_8 right
2
19 0
128 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_11_8 loc_10_8 up
2
11 0
129 0
1
0 0 15 7
1
end_operator
begin_operator
move loc_11_8 loc_11_7 left
2
18 0
130 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
20 0
131 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_11_9 loc_10_9 up
2
12 0
132 0
1
0 0 16 8
1
end_operator
begin_operator
move loc_11_9 loc_11_10 right
2
13 0
133 0
1
0 0 16 9
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
19 0
134 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_2_10 loc_2_9 left
2
26 0
135 0
1
0 0 17 22
1
end_operator
begin_operator
move loc_2_10 loc_3_10 down
2
27 0
136 0
1
0 0 17 23
1
end_operator
begin_operator
move loc_2_4 loc_2_5 right
2
23 0
137 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
31 0
138 0
1
0 0 18 27
1
end_operator
begin_operator
move loc_2_5 loc_2_4 left
2
22 0
139 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_2_5 loc_2_6 right
2
24 0
140 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
32 0
141 0
1
0 0 19 28
1
end_operator
begin_operator
move loc_2_6 loc_2_5 left
2
23 0
142 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
33 0
143 0
1
0 0 20 29
1
end_operator
begin_operator
move loc_2_8 loc_2_9 right
2
26 0
144 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
35 0
145 0
1
0 0 21 31
1
end_operator
begin_operator
move loc_2_9 loc_2_10 right
2
21 0
146 0
1
0 0 22 17
1
end_operator
begin_operator
move loc_2_9 loc_2_8 left
2
25 0
147 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_3_10 loc_2_10 up
2
21 0
148 0
1
0 0 23 17
1
end_operator
begin_operator
move loc_3_10 loc_3_11 right
2
28 0
149 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
36 0
150 0
1
0 0 23 32
1
end_operator
begin_operator
move loc_3_11 loc_3_10 left
2
27 0
151 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_3_11 loc_4_11 down
2
37 0
152 0
1
0 0 24 33
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
30 0
153 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
38 0
154 0
1
0 0 25 34
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
29 0
155 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
31 0
156 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
39 0
157 0
1
0 0 26 35
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
22 0
158 0
1
0 0 27 18
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
30 0
159 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
32 0
160 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
40 0
161 0
1
0 0 27 36
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
23 0
162 0
1
0 0 28 19
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
31 0
163 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
33 0
164 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
41 0
165 0
1
0 0 28 37
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
24 0
166 0
1
0 0 29 20
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
32 0
167 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
34 0
168 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
42 0
169 0
1
0 0 29 38
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
33 0
170 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
35 0
171 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
43 0
172 0
1
0 0 30 39
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
25 0
173 0
1
0 0 31 21
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
34 0
174 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
27 0
175 0
1
0 0 32 23
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
37 0
176 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
44 0
177 0
1
0 0 32 40
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
45 0
178 0
1
0 0 32 41
1
end_operator
begin_operator
move loc_4_11 loc_3_11 up
2
28 0
179 0
1
0 0 33 24
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
36 0
180 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
46 0
181 0
1
0 0 33 42
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
29 0
182 0
1
0 0 34 25
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
39 0
183 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
47 0
184 0
1
0 0 34 43
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
30 0
185 0
1
0 0 35 26
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
38 0
186 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
40 0
187 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
48 0
188 0
1
0 0 35 44
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
31 0
189 0
1
0 0 36 27
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
39 0
190 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
41 0
191 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
49 0
192 0
1
0 0 36 45
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
32 0
193 0
1
0 0 37 28
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
40 0
194 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
42 0
195 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
33 0
196 0
1
0 0 38 29
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
41 0
197 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
43 0
198 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
50 0
199 0
1
0 0 38 46
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
34 0
200 0
1
0 0 39 30
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
42 0
201 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
51 0
202 0
1
0 0 39 47
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
36 0
203 0
1
0 0 40 32
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
52 0
204 0
1
0 0 40 48
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
36 0
205 0
1
0 0 41 32
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
46 0
206 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
52 0
207 0
1
0 0 41 48
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
53 0
208 0
1
0 0 41 49
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
37 0
209 0
1
0 0 42 33
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
45 0
210 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
38 0
211 0
1
0 0 43 34
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
48 0
212 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
54 0
213 0
1
0 0 43 50
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
39 0
214 0
1
0 0 44 35
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
47 0
215 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
49 0
216 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
40 0
217 0
1
0 0 45 36
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
48 0
218 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
55 0
219 0
1
0 0 45 51
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
42 0
220 0
1
0 0 46 38
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
51 0
221 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
57 0
222 0
1
0 0 46 53
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
43 0
223 0
1
0 0 47 39
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
50 0
224 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
58 0
225 0
1
0 0 47 54
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
44 0
226 0
1
0 0 48 40
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
45 0
227 0
1
0 0 48 41
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
45 0
228 0
1
0 0 49 41
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
47 0
229 0
1
0 0 50 43
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
61 0
230 0
1
0 0 50 57
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
49 0
231 0
1
0 0 51 45
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
56 0
232 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
63 0
233 0
1
0 0 51 59
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
55 0
234 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
57 0
235 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
50 0
236 0
1
0 0 53 46
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
56 0
237 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
58 0
238 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
64 0
239 0
1
0 0 53 60
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
51 0
240 0
1
0 0 54 47
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
57 0
241 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
59 0
242 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
65 0
243 0
1
0 0 54 61
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
58 0
244 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
66 0
245 0
1
0 0 55 62
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
68 0
246 0
1
0 0 56 64
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
54 0
247 0
1
0 0 57 50
1
end_operator
begin_operator
move loc_7_2 loc_7_3 right
2
62 0
248 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
69 0
249 0
1
0 0 57 65
1
end_operator
begin_operator
move loc_7_3 loc_7_2 left
2
61 0
250 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
63 0
251 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
70 0
252 0
1
0 0 58 66
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
55 0
253 0
1
0 0 59 51
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
62 0
254 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
71 0
255 0
1
0 0 59 67
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
57 0
256 0
1
0 0 60 53
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
65 0
257 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
73 0
258 0
1
0 0 60 69
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
58 0
259 0
1
0 0 61 54
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
64 0
260 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
66 0
261 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
74 0
262 0
1
0 0 61 70
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
59 0
263 0
1
0 0 62 55
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
65 0
264 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
68 0
265 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
75 0
266 0
1
0 0 63 71
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
76 0
267 0
1
0 0 63 72
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
60 0
268 0
1
0 0 64 56
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
67 0
269 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
77 0
270 0
1
0 0 64 73
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
61 0
271 0
1
0 0 65 57
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
70 0
272 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
78 0
273 0
1
0 0 65 74
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
62 0
274 0
1
0 0 66 58
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
69 0
275 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
71 0
276 0
1
0 0 66 67
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
63 0
277 0
1
0 0 67 59
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
70 0
278 0
1
0 0 67 66
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
72 0
279 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
79 0
280 0
1
0 0 67 75
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
71 0
281 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
73 0
282 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
80 0
283 0
1
0 0 68 76
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
64 0
284 0
1
0 0 69 60
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
72 0
285 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
74 0
286 0
1
0 0 69 70
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
81 0
287 0
1
0 0 69 77
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
65 0
288 0
1
0 0 70 61
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
73 0
289 0
1
0 0 70 69
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
82 0
290 0
1
0 0 70 78
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
67 0
291 0
1
0 0 71 63
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
84 0
292 0
1
0 0 71 80
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
4 0
293 0
1
0 0 72 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
67 0
294 0
1
0 0 72 63
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
77 0
295 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
84 0
296 0
1
0 0 72 80
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
5 0
297 0
1
0 0 73 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
68 0
298 0
1
0 0 73 64
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
76 0
299 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
69 0
300 0
1
0 0 74 65
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
7 0
301 0
1
0 0 75 3
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
71 0
302 0
1
0 0 75 67
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
80 0
303 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
8 0
304 0
1
0 0 76 4
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
72 0
305 0
1
0 0 76 68
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
79 0
306 0
1
0 0 76 75
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
81 0
307 0
1
0 0 76 77
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
9 0
308 0
1
0 0 77 5
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
73 0
309 0
1
0 0 77 69
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
80 0
310 0
1
0 0 77 76
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
82 0
311 0
1
0 0 77 78
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
10 0
312 0
1
0 0 78 6
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
74 0
313 0
1
0 0 78 70
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
81 0
314 0
1
0 0 78 77
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
83 0
315 0
1
0 0 78 79
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
11 0
316 0
1
0 0 79 7
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
82 0
317 0
1
0 0 79 78
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
84 0
318 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
12 0
319 0
1
0 0 80 8
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
75 0
320 0
1
0 0 80 71
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
76 0
321 0
1
0 0 80 72
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
83 0
322 0
1
0 0 80 79
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box1
2
86 0
113 0
4
0 0 0 8
0 3 8 7
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box2
2
86 0
113 0
4
0 0 0 8
0 1 8 7
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box3
2
86 0
113 0
4
0 0 0 8
0 2 8 7
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
88 0
294 0
4
0 0 0 72
0 3 59 50
0 67 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
88 0
294 0
4
0 0 0 72
0 1 59 50
0 67 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
88 0
294 0
4
0 0 0 72
0 2 59 50
0 67 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box1
2
86 0
89 0
4
0 0 1 0
0 3 0 8
0 4 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box2
2
86 0
89 0
4
0 0 1 0
0 1 0 8
0 4 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box3
2
86 0
89 0
4
0 0 1 0
0 2 0 8
0 4 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
90 0
298 0
4
0 0 1 73
0 3 60 51
0 68 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
90 0
298 0
4
0 0 1 73
0 1 60 51
0 68 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
90 0
298 0
4
0 0 1 73
0 2 60 51
0 68 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
91 0
94 0
4
0 0 2 3
0 3 3 4
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
91 0
94 0
4
0 0 2 3
0 1 3 4
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
91 0
94 0
4
0 0 2 3
0 2 3 4
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
94 0
98 0
4
0 0 3 4
0 3 4 5
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
94 0
98 0
4
0 0 3 4
0 1 4 5
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
94 0
98 0
4
0 0 3 4
0 2 4 5
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box1
2
96 0
302 0
4
0 0 3 75
0 3 62 54
0 71 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box2
2
96 0
302 0
4
0 0 3 75
0 1 62 54
0 71 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box3
2
96 0
302 0
4
0 0 3 75
0 2 62 54
0 71 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
93 0
97 0
4
0 0 4 3
0 3 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
93 0
97 0
4
0 0 4 3
0 1 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
93 0
97 0
4
0 0 4 3
0 2 3 2
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
98 0
102 0
4
0 0 4 5
0 3 5 6
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
98 0
102 0
4
0 0 4 5
0 1 5 6
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
98 0
102 0
4
0 0 4 5
0 2 5 6
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
100 0
305 0
4
0 0 4 76
0 3 63 55
0 72 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
100 0
305 0
4
0 0 4 76
0 1 63 55
0 72 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
100 0
305 0
4
0 0 4 76
0 2 63 55
0 72 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
97 0
101 0
4
0 0 5 4
0 3 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
97 0
101 0
4
0 0 5 4
0 1 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
97 0
101 0
4
0 0 5 4
0 2 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
102 0
105 0
4
0 0 5 6
0 3 6 7
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
102 0
105 0
4
0 0 5 6
0 1 6 7
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
102 0
105 0
4
0 0 5 6
0 2 6 7
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box1
2
103 0
309 0
4
0 0 5 77
0 3 64 56
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box2
2
103 0
309 0
4
0 0 5 77
0 1 64 56
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box3
2
103 0
309 0
4
0 0 5 77
0 2 64 56
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
101 0
104 0
4
0 0 6 5
0 3 5 4
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
101 0
104 0
4
0 0 6 5
0 1 5 4
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
101 0
104 0
4
0 0 6 5
0 2 5 4
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box1
2
105 0
109 0
4
0 0 6 7
0 3 7 8
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box2
2
105 0
109 0
4
0 0 6 7
0 1 7 8
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box3
2
105 0
109 0
4
0 0 6 7
0 2 7 8
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
107 0
313 0
4
0 0 6 78
0 3 65 57
0 74 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
107 0
313 0
4
0 0 6 78
0 1 65 57
0 74 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
107 0
313 0
4
0 0 6 78
0 2 65 57
0 74 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
104 0
108 0
4
0 0 7 6
0 3 6 5
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
104 0
108 0
4
0 0 7 6
0 1 6 5
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
104 0
108 0
4
0 0 7 6
0 2 6 5
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box1
2
109 0
112 0
4
0 0 7 8
0 3 8 0
0 4 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box2
2
109 0
112 0
4
0 0 7 8
0 1 8 0
0 4 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box3
2
109 0
112 0
4
0 0 7 8
0 2 8 0
0 4 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box1
2
85 0
112 0
4
0 0 8 0
0 3 0 1
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box2
2
85 0
112 0
4
0 0 8 0
0 1 0 1
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box3
2
85 0
112 0
4
0 0 8 0
0 2 0 1
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box1
2
108 0
113 0
4
0 0 8 7
0 3 7 6
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box2
2
108 0
113 0
4
0 0 8 7
0 1 7 6
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box3
2
108 0
113 0
4
0 0 8 7
0 2 7 6
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box1
2
115 0
320 0
4
0 0 8 80
0 3 67 58
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box2
2
115 0
320 0
4
0 0 8 80
0 1 67 58
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box3
2
115 0
320 0
4
0 0 8 80
0 2 67 58
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box1
2
88 0
116 0
4
0 0 9 0
0 3 0 59
0 4 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box2
2
88 0
116 0
4
0 0 9 0
0 1 0 59
0 4 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box3
2
88 0
116 0
4
0 0 9 0
0 2 0 59
0 4 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box1
2
117 0
134 0
4
0 0 9 16
0 3 16 15
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box2
2
117 0
134 0
4
0 0 9 16
0 1 16 15
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box3
2
117 0
134 0
4
0 0 9 16
0 2 16 15
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box1
2
121 0
124 0
4
0 0 11 12
0 3 12 13
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box2
2
121 0
124 0
4
0 0 11 12
0 1 12 13
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box3
2
121 0
124 0
4
0 0 11 12
0 2 12 13
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box1
2
96 0
122 0
4
0 0 12 3
0 3 3 62
0 7 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box2
2
96 0
122 0
4
0 0 12 3
0 1 3 62
0 7 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box3
2
96 0
122 0
4
0 0 12 3
0 2 3 62
0 7 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box1
2
120 0
123 0
4
0 0 12 11
0 3 11 10
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box2
2
120 0
123 0
4
0 0 12 11
0 1 11 10
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box3
2
120 0
123 0
4
0 0 12 11
0 2 11 10
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
100 0
125 0
4
0 0 13 4
0 3 4 63
0 8 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
100 0
125 0
4
0 0 13 4
0 1 4 63
0 8 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
100 0
125 0
4
0 0 13 4
0 2 4 63
0 8 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box1
2
123 0
126 0
4
0 0 13 12
0 3 12 11
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box2
2
123 0
126 0
4
0 0 13 12
0 1 12 11
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box3
2
123 0
126 0
4
0 0 13 12
0 2 12 11
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
107 0
127 0
4
0 0 14 6
0 3 6 65
0 10 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
107 0
127 0
4
0 0 14 6
0 1 6 65
0 10 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
107 0
127 0
4
0 0 14 6
0 2 6 65
0 10 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box1
2
128 0
131 0
4
0 0 14 15
0 3 15 16
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box2
2
128 0
131 0
4
0 0 14 15
0 1 15 16
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box3
2
128 0
131 0
4
0 0 14 15
0 2 15 16
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box1
2
111 0
129 0
4
0 0 15 7
0 3 7 66
0 11 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box2
2
111 0
129 0
4
0 0 15 7
0 1 7 66
0 11 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box3
2
111 0
129 0
4
0 0 15 7
0 2 7 66
0 11 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box1
2
131 0
133 0
4
0 0 15 16
0 3 16 9
0 13 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box2
2
131 0
133 0
4
0 0 15 16
0 1 16 9
0 13 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box3
2
131 0
133 0
4
0 0 15 16
0 2 16 9
0 13 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box1
2
115 0
132 0
4
0 0 16 8
0 3 8 67
0 12 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box2
2
115 0
132 0
4
0 0 16 8
0 1 8 67
0 12 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box3
2
115 0
132 0
4
0 0 16 8
0 2 8 67
0 12 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box1
2
130 0
134 0
4
0 0 16 15
0 3 15 14
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box2
2
130 0
134 0
4
0 0 16 15
0 1 15 14
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box3
2
130 0
134 0
4
0 0 16 15
0 2 15 14
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box1
2
137 0
140 0
4
0 0 18 19
0 3 18 19
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box2
2
137 0
140 0
4
0 0 18 19
0 1 18 19
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box3
2
137 0
140 0
4
0 0 18 19
0 2 18 19
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
2
138 0
161 0
4
0 0 18 27
0 3 22 29
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box2
2
138 0
161 0
4
0 0 18 27
0 1 22 29
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box3
2
138 0
161 0
4
0 0 18 27
0 2 22 29
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box1
2
141 0
165 0
4
0 0 19 28
0 3 23 30
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box2
2
141 0
165 0
4
0 0 19 28
0 1 23 30
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box3
2
141 0
165 0
4
0 0 19 28
0 2 23 30
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box1
2
139 0
142 0
4
0 0 20 19
0 3 18 17
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box2
2
139 0
142 0
4
0 0 20 19
0 1 18 17
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box3
2
139 0
142 0
4
0 0 20 19
0 2 18 17
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box1
2
143 0
169 0
4
0 0 20 29
0 3 24 31
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box2
2
143 0
169 0
4
0 0 20 29
0 1 24 31
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box3
2
143 0
169 0
4
0 0 20 29
0 2 24 31
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
153 0
156 0
4
0 0 25 26
0 3 21 22
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box2
2
153 0
156 0
4
0 0 25 26
0 1 21 22
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box3
2
153 0
156 0
4
0 0 25 26
0 2 21 22
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box1
2
154 0
184 0
4
0 0 25 34
0 3 27 33
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box2
2
154 0
184 0
4
0 0 25 34
0 1 27 33
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box3
2
154 0
184 0
4
0 0 25 34
0 2 27 33
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
156 0
160 0
4
0 0 26 27
0 3 22 23
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
156 0
160 0
4
0 0 26 27
0 1 22 23
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
156 0
160 0
4
0 0 26 27
0 2 22 23
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
157 0
188 0
4
0 0 26 35
0 3 28 34
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box2
2
157 0
188 0
4
0 0 26 35
0 1 28 34
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box3
2
157 0
188 0
4
0 0 26 35
0 2 28 34
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
155 0
159 0
4
0 0 27 26
0 3 21 20
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box2
2
155 0
159 0
4
0 0 27 26
0 1 21 20
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box3
2
155 0
159 0
4
0 0 27 26
0 2 21 20
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
160 0
164 0
4
0 0 27 28
0 3 23 24
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
160 0
164 0
4
0 0 27 28
0 1 23 24
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
160 0
164 0
4
0 0 27 28
0 2 23 24
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
161 0
192 0
4
0 0 27 36
0 3 29 35
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
161 0
192 0
4
0 0 27 36
0 1 29 35
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
161 0
192 0
4
0 0 27 36
0 2 29 35
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
159 0
163 0
4
0 0 28 27
0 3 22 21
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
159 0
163 0
4
0 0 28 27
0 1 22 21
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
159 0
163 0
4
0 0 28 27
0 2 22 21
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
164 0
168 0
4
0 0 28 29
0 3 24 25
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
164 0
168 0
4
0 0 28 29
0 1 24 25
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box3
2
164 0
168 0
4
0 0 28 29
0 2 24 25
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
163 0
167 0
4
0 0 29 28
0 3 23 22
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
163 0
167 0
4
0 0 29 28
0 1 23 22
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
163 0
167 0
4
0 0 29 28
0 2 23 22
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
168 0
171 0
4
0 0 29 30
0 3 25 26
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box2
2
168 0
171 0
4
0 0 29 30
0 1 25 26
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box3
2
168 0
171 0
4
0 0 29 30
0 2 25 26
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
169 0
199 0
4
0 0 29 38
0 3 31 36
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
169 0
199 0
4
0 0 29 38
0 1 31 36
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
169 0
199 0
4
0 0 29 38
0 2 31 36
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
167 0
170 0
4
0 0 30 29
0 3 24 23
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
167 0
170 0
4
0 0 30 29
0 1 24 23
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box3
2
167 0
170 0
4
0 0 30 29
0 2 24 23
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
172 0
202 0
4
0 0 30 39
0 3 32 37
0 43 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box2
2
172 0
202 0
4
0 0 30 39
0 1 32 37
0 43 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box3
2
172 0
202 0
4
0 0 30 39
0 2 32 37
0 43 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
183 0
187 0
4
0 0 34 35
0 3 28 29
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box2
2
183 0
187 0
4
0 0 34 35
0 1 28 29
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box3
2
183 0
187 0
4
0 0 34 35
0 2 28 29
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
184 0
213 0
4
0 0 34 43
0 3 33 38
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box2
2
184 0
213 0
4
0 0 34 43
0 1 33 38
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box3
2
184 0
213 0
4
0 0 34 43
0 2 33 38
0 47 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
187 0
191 0
4
0 0 35 36
0 3 29 30
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
187 0
191 0
4
0 0 35 36
0 1 29 30
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
187 0
191 0
4
0 0 35 36
0 2 29 30
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
158 0
189 0
4
0 0 36 27
0 3 22 17
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box2
2
158 0
189 0
4
0 0 36 27
0 1 22 17
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box3
2
158 0
189 0
4
0 0 36 27
0 2 22 17
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
186 0
190 0
4
0 0 36 35
0 3 28 27
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box2
2
186 0
190 0
4
0 0 36 35
0 1 28 27
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box3
2
186 0
190 0
4
0 0 36 35
0 2 28 27
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
191 0
195 0
4
0 0 36 37
0 3 30 31
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
191 0
195 0
4
0 0 36 37
0 1 30 31
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
191 0
195 0
4
0 0 36 37
0 2 30 31
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
192 0
219 0
4
0 0 36 45
0 3 35 39
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
192 0
219 0
4
0 0 36 45
0 1 35 39
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
192 0
219 0
4
0 0 36 45
0 2 35 39
0 49 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
162 0
193 0
4
0 0 37 28
0 3 23 18
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box2
2
162 0
193 0
4
0 0 37 28
0 1 23 18
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box3
2
162 0
193 0
4
0 0 37 28
0 2 23 18
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
190 0
194 0
4
0 0 37 36
0 3 29 28
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
190 0
194 0
4
0 0 37 36
0 1 29 28
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
190 0
194 0
4
0 0 37 36
0 2 29 28
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
195 0
198 0
4
0 0 37 38
0 3 31 32
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
195 0
198 0
4
0 0 37 38
0 1 31 32
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
195 0
198 0
4
0 0 37 38
0 2 31 32
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
166 0
196 0
4
0 0 38 29
0 3 24 19
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box2
2
166 0
196 0
4
0 0 38 29
0 1 24 19
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box3
2
166 0
196 0
4
0 0 38 29
0 2 24 19
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
194 0
197 0
4
0 0 38 37
0 3 30 29
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
194 0
197 0
4
0 0 38 37
0 1 30 29
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
194 0
197 0
4
0 0 38 37
0 2 30 29
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
199 0
222 0
4
0 0 38 46
0 3 36 41
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
199 0
222 0
4
0 0 38 46
0 1 36 41
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
199 0
222 0
4
0 0 38 46
0 2 36 41
0 50 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
197 0
201 0
4
0 0 39 38
0 3 31 30
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
197 0
201 0
4
0 0 39 38
0 1 31 30
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
197 0
201 0
4
0 0 39 38
0 2 31 30
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
202 0
225 0
4
0 0 39 47
0 3 37 42
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
202 0
225 0
4
0 0 39 47
0 1 37 42
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
202 0
225 0
4
0 0 39 47
0 2 37 42
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box1
2
182 0
211 0
4
0 0 43 34
0 3 27 20
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box2
2
182 0
211 0
4
0 0 43 34
0 1 27 20
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box3
2
182 0
211 0
4
0 0 43 34
0 2 27 20
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
212 0
216 0
4
0 0 43 44
0 3 34 35
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box2
2
212 0
216 0
4
0 0 43 44
0 1 34 35
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box3
2
212 0
216 0
4
0 0 43 44
0 2 34 35
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
213 0
230 0
4
0 0 43 50
0 3 38 45
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box2
2
213 0
230 0
4
0 0 43 50
0 1 38 45
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box3
2
213 0
230 0
4
0 0 43 50
0 2 38 45
0 54 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
185 0
214 0
4
0 0 44 35
0 3 28 21
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box2
2
185 0
214 0
4
0 0 44 35
0 1 28 21
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box3
2
185 0
214 0
4
0 0 44 35
0 2 28 21
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
189 0
217 0
4
0 0 45 36
0 3 29 22
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
189 0
217 0
4
0 0 45 36
0 1 29 22
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
189 0
217 0
4
0 0 45 36
0 2 29 22
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
215 0
218 0
4
0 0 45 44
0 3 34 33
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
215 0
218 0
4
0 0 45 44
0 1 34 33
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
215 0
218 0
4
0 0 45 44
0 2 34 33
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
219 0
233 0
4
0 0 45 51
0 3 39 46
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
219 0
233 0
4
0 0 45 51
0 1 39 46
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
219 0
233 0
4
0 0 45 51
0 2 39 46
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
196 0
220 0
4
0 0 46 38
0 3 31 24
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
196 0
220 0
4
0 0 46 38
0 1 31 24
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
196 0
220 0
4
0 0 46 38
0 2 31 24
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
222 0
239 0
4
0 0 46 53
0 3 41 47
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
222 0
239 0
4
0 0 46 53
0 1 41 47
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
222 0
239 0
4
0 0 46 53
0 2 41 47
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
200 0
223 0
4
0 0 47 39
0 3 32 25
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
200 0
223 0
4
0 0 47 39
0 1 32 25
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
200 0
223 0
4
0 0 47 39
0 2 32 25
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
225 0
243 0
4
0 0 47 54
0 3 42 48
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
225 0
243 0
4
0 0 47 54
0 1 42 48
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
225 0
243 0
4
0 0 47 54
0 2 42 48
0 58 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box1
2
211 0
229 0
4
0 0 50 43
0 3 33 27
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box2
2
211 0
229 0
4
0 0 50 43
0 1 33 27
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box3
2
211 0
229 0
4
0 0 50 43
0 2 33 27
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box1
2
230 0
249 0
4
0 0 50 57
0 3 45 52
0 61 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box2
2
230 0
249 0
4
0 0 50 57
0 1 45 52
0 61 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box3
2
230 0
249 0
4
0 0 50 57
0 2 45 52
0 61 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
217 0
231 0
4
0 0 51 45
0 3 35 29
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
217 0
231 0
4
0 0 51 45
0 1 35 29
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box3
2
217 0
231 0
4
0 0 51 45
0 2 35 29
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
232 0
235 0
4
0 0 51 52
0 3 40 41
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box2
2
232 0
235 0
4
0 0 51 52
0 1 40 41
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box3
2
232 0
235 0
4
0 0 51 52
0 2 40 41
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
233 0
255 0
4
0 0 51 59
0 3 46 54
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box2
2
233 0
255 0
4
0 0 51 59
0 1 46 54
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box3
2
233 0
255 0
4
0 0 51 59
0 2 46 54
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
235 0
238 0
4
0 0 52 53
0 3 41 42
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
235 0
238 0
4
0 0 52 53
0 1 41 42
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
235 0
238 0
4
0 0 52 53
0 2 41 42
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
220 0
236 0
4
0 0 53 46
0 3 36 31
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
220 0
236 0
4
0 0 53 46
0 1 36 31
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
220 0
236 0
4
0 0 53 46
0 2 36 31
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
234 0
237 0
4
0 0 53 52
0 3 40 39
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box2
2
234 0
237 0
4
0 0 53 52
0 1 40 39
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box3
2
234 0
237 0
4
0 0 53 52
0 2 40 39
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
238 0
242 0
4
0 0 53 54
0 3 42 43
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
238 0
242 0
4
0 0 53 54
0 1 42 43
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
238 0
242 0
4
0 0 53 54
0 2 42 43
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box1
2
239 0
258 0
4
0 0 53 60
0 3 47 56
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box2
2
239 0
258 0
4
0 0 53 60
0 1 47 56
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box3
2
239 0
258 0
4
0 0 53 60
0 2 47 56
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
223 0
240 0
4
0 0 54 47
0 3 37 32
0 43 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
223 0
240 0
4
0 0 54 47
0 1 37 32
0 43 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
223 0
240 0
4
0 0 54 47
0 2 37 32
0 43 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
237 0
241 0
4
0 0 54 53
0 3 41 40
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
237 0
241 0
4
0 0 54 53
0 1 41 40
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
237 0
241 0
4
0 0 54 53
0 2 41 40
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
243 0
262 0
4
0 0 54 61
0 3 48 57
0 65 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
243 0
262 0
4
0 0 54 61
0 1 48 57
0 65 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
243 0
262 0
4
0 0 54 61
0 2 48 57
0 65 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
241 0
244 0
4
0 0 55 54
0 3 42 41
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
241 0
244 0
4
0 0 55 54
0 1 42 41
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
241 0
244 0
4
0 0 55 54
0 2 42 41
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box1
2
229 0
247 0
4
0 0 57 50
0 3 38 33
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box2
2
229 0
247 0
4
0 0 57 50
0 1 38 33
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box3
2
229 0
247 0
4
0 0 57 50
0 2 38 33
0 47 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box1
2
249 0
273 0
4
0 0 57 65
0 3 52 61
0 69 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box2
2
249 0
273 0
4
0 0 57 65
0 1 52 61
0 69 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box3
2
249 0
273 0
4
0 0 57 65
0 2 52 61
0 69 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
231 0
253 0
4
0 0 59 51
0 3 39 35
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
231 0
253 0
4
0 0 59 51
0 1 39 35
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box3
2
231 0
253 0
4
0 0 59 51
0 2 39 35
0 49 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
255 0
280 0
4
0 0 59 67
0 3 54 62
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
255 0
280 0
4
0 0 59 67
0 1 54 62
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box3
2
255 0
280 0
4
0 0 59 67
0 2 54 62
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
236 0
256 0
4
0 0 60 53
0 3 41 36
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
236 0
256 0
4
0 0 60 53
0 1 41 36
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
236 0
256 0
4
0 0 60 53
0 2 41 36
0 50 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
257 0
261 0
4
0 0 60 61
0 3 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
257 0
261 0
4
0 0 60 61
0 1 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
257 0
261 0
4
0 0 60 61
0 2 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box1
2
258 0
287 0
4
0 0 60 69
0 3 56 64
0 73 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box2
2
258 0
287 0
4
0 0 60 69
0 1 56 64
0 73 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box3
2
258 0
287 0
4
0 0 60 69
0 2 56 64
0 73 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
240 0
259 0
4
0 0 61 54
0 3 42 37
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
240 0
259 0
4
0 0 61 54
0 1 42 37
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
240 0
259 0
4
0 0 61 54
0 2 42 37
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
262 0
290 0
4
0 0 61 70
0 3 57 65
0 74 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
262 0
290 0
4
0 0 61 70
0 1 57 65
0 74 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
262 0
290 0
4
0 0 61 70
0 2 57 65
0 74 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
260 0
264 0
4
0 0 62 61
0 3 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
260 0
264 0
4
0 0 62 61
0 1 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
260 0
264 0
4
0 0 62 61
0 2 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
267 0
293 0
4
0 0 63 72
0 3 59 0
0 4 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
267 0
293 0
4
0 0 63 72
0 1 59 0
0 4 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
267 0
293 0
4
0 0 63 72
0 2 59 0
0 4 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
266 0
269 0
4
0 0 64 63
0 3 50 58
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
266 0
269 0
4
0 0 64 63
0 1 50 58
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
266 0
269 0
4
0 0 64 63
0 2 50 58
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
270 0
297 0
4
0 0 64 73
0 3 60 1
0 5 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
270 0
297 0
4
0 0 64 73
0 1 60 1
0 5 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
270 0
297 0
4
0 0 64 73
0 2 60 1
0 5 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box1
2
247 0
271 0
4
0 0 65 57
0 3 45 38
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box2
2
247 0
271 0
4
0 0 65 57
0 1 45 38
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box3
2
247 0
271 0
4
0 0 65 57
0 2 45 38
0 54 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box1
2
272 0
276 0
4
0 0 65 66
0 3 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box2
2
272 0
276 0
4
0 0 65 66
0 1 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box3
2
272 0
276 0
4
0 0 65 66
0 2 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box1
2
276 0
279 0
4
0 0 66 67
0 3 54 55
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box2
2
276 0
279 0
4
0 0 66 67
0 1 54 55
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box3
2
276 0
279 0
4
0 0 66 67
0 2 54 55
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
253 0
277 0
4
0 0 67 59
0 3 46 39
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box2
2
253 0
277 0
4
0 0 67 59
0 1 46 39
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box3
2
253 0
277 0
4
0 0 67 59
0 2 46 39
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box1
2
275 0
278 0
4
0 0 67 66
0 3 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box2
2
275 0
278 0
4
0 0 67 66
0 1 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box3
2
275 0
278 0
4
0 0 67 66
0 2 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box1
2
279 0
282 0
4
0 0 67 68
0 3 55 56
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box2
2
279 0
282 0
4
0 0 67 68
0 1 55 56
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box3
2
279 0
282 0
4
0 0 67 68
0 2 55 56
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box1
2
280 0
301 0
4
0 0 67 75
0 3 62 3
0 7 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box2
2
280 0
301 0
4
0 0 67 75
0 1 62 3
0 7 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box3
2
280 0
301 0
4
0 0 67 75
0 2 62 3
0 7 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box1
2
278 0
281 0
4
0 0 68 67
0 3 54 53
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box2
2
278 0
281 0
4
0 0 68 67
0 1 54 53
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box3
2
278 0
281 0
4
0 0 68 67
0 2 54 53
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
282 0
286 0
4
0 0 68 69
0 3 56 57
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
282 0
286 0
4
0 0 68 69
0 1 56 57
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
282 0
286 0
4
0 0 68 69
0 2 56 57
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box1
2
283 0
304 0
4
0 0 68 76
0 3 63 4
0 8 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box2
2
283 0
304 0
4
0 0 68 76
0 1 63 4
0 8 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box3
2
283 0
304 0
4
0 0 68 76
0 2 63 4
0 8 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
256 0
284 0
4
0 0 69 60
0 3 47 41
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
256 0
284 0
4
0 0 69 60
0 1 47 41
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box3
2
256 0
284 0
4
0 0 69 60
0 2 47 41
0 57 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
281 0
285 0
4
0 0 69 68
0 3 55 54
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
281 0
285 0
4
0 0 69 68
0 1 55 54
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box3
2
281 0
285 0
4
0 0 69 68
0 2 55 54
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box1
2
287 0
308 0
4
0 0 69 77
0 3 64 5
0 9 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box2
2
287 0
308 0
4
0 0 69 77
0 1 64 5
0 9 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box3
2
287 0
308 0
4
0 0 69 77
0 2 64 5
0 9 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
259 0
288 0
4
0 0 70 61
0 3 48 42
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
259 0
288 0
4
0 0 70 61
0 1 48 42
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
259 0
288 0
4
0 0 70 61
0 2 48 42
0 58 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
285 0
289 0
4
0 0 70 69
0 3 56 55
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
285 0
289 0
4
0 0 70 69
0 1 56 55
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
285 0
289 0
4
0 0 70 69
0 2 56 55
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
290 0
312 0
4
0 0 70 78
0 3 65 6
0 10 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
290 0
312 0
4
0 0 70 78
0 1 65 6
0 10 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
290 0
312 0
4
0 0 70 78
0 2 65 6
0 10 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
265 0
291 0
4
0 0 71 63
0 3 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
265 0
291 0
4
0 0 71 63
0 1 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
265 0
291 0
4
0 0 71 63
0 2 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box1
2
292 0
319 0
4
0 0 71 80
0 3 67 8
0 12 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box2
2
292 0
319 0
4
0 0 71 80
0 1 67 8
0 12 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box3
2
292 0
319 0
4
0 0 71 80
0 2 67 8
0 12 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box1
2
87 0
293 0
4
0 0 72 0
0 3 0 9
0 4 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box2
2
87 0
293 0
4
0 0 72 0
0 1 0 9
0 4 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box3
2
87 0
293 0
4
0 0 72 0
0 2 0 9
0 4 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
296 0
322 0
4
0 0 72 80
0 3 67 66
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
296 0
322 0
4
0 0 72 80
0 1 67 66
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
296 0
322 0
4
0 0 72 80
0 2 67 66
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
268 0
298 0
4
0 0 73 64
0 3 51 44
0 60 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
268 0
298 0
4
0 0 73 64
0 1 51 44
0 60 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
268 0
298 0
4
0 0 73 64
0 2 51 44
0 60 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
296 0
299 0
4
0 0 73 72
0 3 59 67
0 76 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
296 0
299 0
4
0 0 73 72
0 1 59 67
0 76 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
296 0
299 0
4
0 0 73 72
0 2 59 67
0 76 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box1
2
95 0
301 0
4
0 0 75 3
0 3 3 12
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box2
2
95 0
301 0
4
0 0 75 3
0 1 3 12
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box3
2
95 0
301 0
4
0 0 75 3
0 2 3 12
0 7 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
277 0
302 0
4
0 0 75 67
0 3 54 46
0 63 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
277 0
302 0
4
0 0 75 67
0 1 54 46
0 63 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box3
2
277 0
302 0
4
0 0 75 67
0 2 54 46
0 63 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
303 0
307 0
4
0 0 75 76
0 3 63 64
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
303 0
307 0
4
0 0 75 76
0 1 63 64
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
303 0
307 0
4
0 0 75 76
0 2 63 64
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
99 0
304 0
4
0 0 76 4
0 3 4 13
0 8 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
99 0
304 0
4
0 0 76 4
0 1 4 13
0 8 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
99 0
304 0
4
0 0 76 4
0 2 4 13
0 8 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
307 0
311 0
4
0 0 76 77
0 3 64 65
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
307 0
311 0
4
0 0 76 77
0 1 64 65
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
307 0
311 0
4
0 0 76 77
0 2 64 65
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box1
2
284 0
309 0
4
0 0 77 69
0 3 56 47
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box2
2
284 0
309 0
4
0 0 77 69
0 1 56 47
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box3
2
284 0
309 0
4
0 0 77 69
0 2 56 47
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
306 0
310 0
4
0 0 77 76
0 3 63 62
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
306 0
310 0
4
0 0 77 76
0 1 63 62
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
306 0
310 0
4
0 0 77 76
0 2 63 62
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
311 0
315 0
4
0 0 77 78
0 3 65 66
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
311 0
315 0
4
0 0 77 78
0 1 65 66
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
311 0
315 0
4
0 0 77 78
0 2 65 66
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
106 0
312 0
4
0 0 78 6
0 3 6 14
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
106 0
312 0
4
0 0 78 6
0 1 6 14
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
106 0
312 0
4
0 0 78 6
0 2 6 14
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
288 0
313 0
4
0 0 78 70
0 3 57 48
0 65 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
288 0
313 0
4
0 0 78 70
0 1 57 48
0 65 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
288 0
313 0
4
0 0 78 70
0 2 57 48
0 65 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
310 0
314 0
4
0 0 78 77
0 3 64 63
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
310 0
314 0
4
0 0 78 77
0 1 64 63
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
310 0
314 0
4
0 0 78 77
0 2 64 63
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
315 0
318 0
4
0 0 78 79
0 3 66 67
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
315 0
318 0
4
0 0 78 79
0 1 66 67
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
315 0
318 0
4
0 0 78 79
0 2 66 67
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box1
2
110 0
316 0
4
0 0 79 7
0 3 7 15
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box2
2
110 0
316 0
4
0 0 79 7
0 1 7 15
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box3
2
110 0
316 0
4
0 0 79 7
0 2 7 15
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
314 0
317 0
4
0 0 79 78
0 3 65 64
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
314 0
317 0
4
0 0 79 78
0 1 65 64
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
314 0
317 0
4
0 0 79 78
0 2 65 64
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
318 0
321 0
4
0 0 79 80
0 3 67 59
0 76 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
318 0
321 0
4
0 0 79 80
0 1 67 59
0 76 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
318 0
321 0
4
0 0 79 80
0 2 67 59
0 76 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box1
2
114 0
319 0
4
0 0 80 8
0 3 8 16
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box2
2
114 0
319 0
4
0 0 80 8
0 1 8 16
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box3
2
114 0
319 0
4
0 0 80 8
0 2 8 16
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
295 0
321 0
4
0 0 80 72
0 3 59 60
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
295 0
321 0
4
0 0 80 72
0 1 59 60
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
295 0
321 0
4
0 0 80 72
0 2 59 60
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
317 0
322 0
4
0 0 80 79
0 3 66 65
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
317 0
322 0
4
0 0 80 79
0 1 66 65
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
317 0
322 0
4
0 0 80 79
0 2 66 65
0 82 0 1
0 83 -1 0
1
end_operator
0
