begin_version
3
end_version
begin_metric
1
end_metric
113
begin_variable
var0
-1
29
at box1 loc_2_2
at box1 loc_2_4
at box1 loc_2_5
at box1 loc_2_6
at box1 loc_2_7
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_6_2
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_7_2
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
end_variable
begin_variable
var1
-1
29
at-robot loc_2_2
at-robot loc_2_4
at-robot loc_2_5
at-robot loc_2_6
at-robot loc_2_7
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_6_2
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_7_2
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
end_variable
begin_variable
var2
-1
2
clear loc_2_2
none-of-those
end_variable
begin_variable
var3
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var4
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var31
-1
2
adjacent loc_2_2 loc_3_2 down
none-of-those
end_variable
begin_variable
var32
-1
2
adjacent loc_2_4 loc_2_5 right
none-of-those
end_variable
begin_variable
var33
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var34
-1
2
adjacent loc_2_5 loc_2_4 left
none-of-those
end_variable
begin_variable
var35
-1
2
adjacent loc_2_5 loc_2_6 right
none-of-those
end_variable
begin_variable
var36
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var37
-1
2
adjacent loc_2_6 loc_2_5 left
none-of-those
end_variable
begin_variable
var38
-1
2
adjacent loc_2_6 loc_2_7 right
none-of-those
end_variable
begin_variable
var39
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var40
-1
2
adjacent loc_2_7 loc_2_6 left
none-of-those
end_variable
begin_variable
var41
-1
2
adjacent loc_3_2 loc_2_2 up
none-of-those
end_variable
begin_variable
var42
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var43
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var44
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var45
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var46
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var47
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var48
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
0
begin_state
12
25
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
1
0 17
end_goal
136
begin_operator
move loc_2_2 loc_3_2 down
2
7 0
31 0
1
0 1 0 5
1
end_operator
begin_operator
move loc_2_4 loc_2_5 right
2
4 0
32 0
1
0 1 1 2
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
9 0
33 0
1
0 1 1 7
1
end_operator
begin_operator
move loc_2_5 loc_2_4 left
2
3 0
34 0
1
0 1 2 1
1
end_operator
begin_operator
move loc_2_5 loc_2_6 right
2
5 0
35 0
1
0 1 2 3
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
10 0
36 0
1
0 1 2 8
1
end_operator
begin_operator
move loc_2_6 loc_2_5 left
2
4 0
37 0
1
0 1 3 2
1
end_operator
begin_operator
move loc_2_6 loc_2_7 right
2
6 0
38 0
1
0 1 3 4
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
11 0
39 0
1
0 1 3 9
1
end_operator
begin_operator
move loc_2_7 loc_2_6 left
2
5 0
40 0
1
0 1 4 3
1
end_operator
begin_operator
move loc_3_2 loc_2_2 up
2
2 0
41 0
1
0 1 5 0
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
8 0
42 0
1
0 1 5 6
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
12 0
43 0
1
0 1 5 10
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
7 0
44 0
1
0 1 6 5
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
9 0
45 0
1
0 1 6 7
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
13 0
46 0
1
0 1 6 11
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
3 0
47 0
1
0 1 7 1
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
8 0
48 0
1
0 1 7 6
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
10 0
49 0
1
0 1 7 8
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
14 0
50 0
1
0 1 7 12
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
4 0
51 0
1
0 1 8 2
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
9 0
52 0
1
0 1 8 7
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
11 0
53 0
1
0 1 8 9
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
15 0
54 0
1
0 1 8 13
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
5 0
55 0
1
0 1 9 3
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
10 0
56 0
1
0 1 9 8
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
16 0
57 0
1
0 1 9 14
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
7 0
58 0
1
0 1 10 5
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
13 0
59 0
1
0 1 10 11
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
18 0
60 0
1
0 1 10 16
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
8 0
61 0
1
0 1 11 6
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
12 0
62 0
1
0 1 11 10
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
14 0
63 0
1
0 1 11 12
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
19 0
64 0
1
0 1 11 17
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
9 0
65 0
1
0 1 12 7
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
13 0
66 0
1
0 1 12 11
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
15 0
67 0
1
0 1 12 13
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
20 0
68 0
1
0 1 12 18
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
10 0
69 0
1
0 1 13 8
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
14 0
70 0
1
0 1 13 12
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
16 0
71 0
1
0 1 13 14
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
21 0
72 0
1
0 1 13 19
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
11 0
73 0
1
0 1 14 9
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
15 0
74 0
1
0 1 14 13
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
17 0
75 0
1
0 1 14 15
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
22 0
76 0
1
0 1 14 20
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
16 0
77 0
1
0 1 15 14
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
12 0
78 0
1
0 1 16 10
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
19 0
79 0
1
0 1 16 17
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
23 0
80 0
1
0 1 16 21
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
13 0
81 0
1
0 1 17 11
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
18 0
82 0
1
0 1 17 16
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
20 0
83 0
1
0 1 17 18
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
14 0
84 0
1
0 1 18 12
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
19 0
85 0
1
0 1 18 17
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
21 0
86 0
1
0 1 18 19
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
24 0
87 0
1
0 1 18 22
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
15 0
88 0
1
0 1 19 13
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
20 0
89 0
1
0 1 19 18
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
22 0
90 0
1
0 1 19 20
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
25 0
91 0
1
0 1 19 23
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
16 0
92 0
1
0 1 20 14
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
21 0
93 0
1
0 1 20 19
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
26 0
94 0
1
0 1 20 24
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
18 0
95 0
1
0 1 21 16
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
27 0
96 0
1
0 1 21 25
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
20 0
97 0
1
0 1 22 18
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
25 0
98 0
1
0 1 22 23
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
21 0
99 0
1
0 1 23 19
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
24 0
100 0
1
0 1 23 22
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
26 0
101 0
1
0 1 23 24
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
28 0
102 0
1
0 1 23 26
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
22 0
103 0
1
0 1 24 20
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
25 0
104 0
1
0 1 24 23
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
29 0
105 0
1
0 1 24 27
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
23 0
106 0
1
0 1 25 21
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
25 0
107 0
1
0 1 26 23
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
29 0
108 0
1
0 1 26 27
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
26 0
109 0
1
0 1 27 24
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
28 0
110 0
1
0 1 27 26
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
30 0
111 0
1
0 1 27 28
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
29 0
112 0
1
0 1 28 27
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box1
2
32 0
35 0
4
0 0 2 3
0 1 1 2
0 4 -1 0
0 5 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
2
33 0
50 0
4
0 0 7 12
0 1 1 7
0 9 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_6 loc_2_7 right box1
2
35 0
38 0
4
0 0 3 4
0 1 2 3
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box1
2
36 0
54 0
4
0 0 8 13
0 1 2 8
0 10 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box1
2
34 0
37 0
4
0 0 2 1
0 1 3 2
0 3 0 1
0 4 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box1
2
39 0
57 0
4
0 0 9 14
0 1 3 9
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
42 0
45 0
4
0 0 6 7
0 1 5 6
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box1
2
43 0
60 0
4
0 0 10 16
0 1 5 10
0 12 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
45 0
49 0
4
0 0 7 8
0 1 6 7
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
46 0
64 0
4
0 0 11 17
0 1 6 11
0 13 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
44 0
48 0
4
0 0 6 5
0 1 7 6
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
49 0
53 0
4
0 0 8 9
0 1 7 8
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
50 0
68 0
4
0 0 12 18
0 1 7 12
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
48 0
52 0
4
0 0 7 6
0 1 8 7
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
54 0
72 0
4
0 0 13 19
0 1 8 13
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
52 0
56 0
4
0 0 8 7
0 1 9 8
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
57 0
76 0
4
0 0 14 20
0 1 9 14
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box1
2
41 0
58 0
4
0 0 5 0
0 1 10 5
0 2 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
59 0
63 0
4
0 0 11 12
0 1 10 11
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
60 0
80 0
4
0 0 16 21
0 1 10 16
0 18 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
63 0
67 0
4
0 0 12 13
0 1 11 12
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
47 0
65 0
4
0 0 7 1
0 1 12 7
0 3 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
62 0
66 0
4
0 0 11 10
0 1 12 11
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
67 0
71 0
4
0 0 13 14
0 1 12 13
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
68 0
87 0
4
0 0 18 22
0 1 12 18
0 20 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
51 0
69 0
4
0 0 8 2
0 1 13 8
0 4 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
66 0
70 0
4
0 0 12 11
0 1 13 12
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
71 0
75 0
4
0 0 14 15
0 1 13 14
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
72 0
91 0
4
0 0 19 23
0 1 13 19
0 21 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
55 0
73 0
4
0 0 9 3
0 1 14 9
0 5 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
70 0
74 0
4
0 0 13 12
0 1 14 13
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
76 0
94 0
4
0 0 20 24
0 1 14 20
0 22 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box1
2
58 0
78 0
4
0 0 10 5
0 1 16 10
0 7 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
79 0
83 0
4
0 0 17 18
0 1 16 17
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
80 0
96 0
4
0 0 21 25
0 1 16 21
0 23 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
61 0
81 0
4
0 0 11 6
0 1 17 11
0 8 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
83 0
86 0
4
0 0 18 19
0 1 17 18
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
65 0
84 0
4
0 0 12 7
0 1 18 12
0 9 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
82 0
85 0
4
0 0 17 16
0 1 18 17
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
86 0
90 0
4
0 0 19 20
0 1 18 19
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
69 0
88 0
4
0 0 13 8
0 1 19 13
0 10 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
85 0
89 0
4
0 0 18 17
0 1 19 18
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
91 0
102 0
4
0 0 23 26
0 1 19 23
0 25 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
73 0
92 0
4
0 0 14 9
0 1 20 14
0 11 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
89 0
93 0
4
0 0 19 18
0 1 20 19
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
94 0
105 0
4
0 0 24 27
0 1 20 24
0 26 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
84 0
97 0
4
0 0 18 12
0 1 22 18
0 14 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
98 0
101 0
4
0 0 23 24
0 1 22 23
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
88 0
99 0
4
0 0 19 13
0 1 23 19
0 15 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
92 0
103 0
4
0 0 20 14
0 1 24 20
0 16 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
100 0
104 0
4
0 0 23 22
0 1 24 23
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
99 0
107 0
4
0 0 23 19
0 1 26 23
0 21 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
108 0
111 0
4
0 0 27 28
0 1 26 27
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
103 0
109 0
4
0 0 24 20
0 1 27 24
0 22 0 1
0 26 -1 0
1
end_operator
0
