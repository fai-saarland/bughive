begin_version
3
end_version
begin_metric
1
end_metric
753
begin_variable
var0
-1
175
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_12
at-robot loc_10_13
at-robot loc_10_14
at-robot loc_10_15
at-robot loc_10_16
at-robot loc_10_17
at-robot loc_10_18
at-robot loc_10_19
at-robot loc_10_2
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_10_9
at-robot loc_11_10
at-robot loc_11_11
at-robot loc_11_13
at-robot loc_11_14
at-robot loc_11_15
at-robot loc_11_17
at-robot loc_11_18
at-robot loc_11_19
at-robot loc_11_2
at-robot loc_11_3
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_7
at-robot loc_11_8
at-robot loc_12_13
at-robot loc_12_14
at-robot loc_12_15
at-robot loc_12_16
at-robot loc_12_17
at-robot loc_12_18
at-robot loc_12_3
at-robot loc_12_5
at-robot loc_12_6
at-robot loc_12_8
at-robot loc_12_9
at-robot loc_13_13
at-robot loc_13_14
at-robot loc_13_15
at-robot loc_13_16
at-robot loc_13_17
at-robot loc_13_18
at-robot loc_13_2
at-robot loc_13_3
at-robot loc_13_4
at-robot loc_13_5
at-robot loc_13_6
at-robot loc_13_7
at-robot loc_13_8
at-robot loc_14_13
at-robot loc_14_14
at-robot loc_14_16
at-robot loc_14_5
at-robot loc_14_6
at-robot loc_15_11
at-robot loc_15_15
at-robot loc_15_16
at-robot loc_15_18
at-robot loc_15_5
at-robot loc_15_6
at-robot loc_15_8
at-robot loc_16_10
at-robot loc_16_11
at-robot loc_16_12
at-robot loc_16_13
at-robot loc_16_14
at-robot loc_16_15
at-robot loc_16_16
at-robot loc_16_17
at-robot loc_16_18
at-robot loc_16_4
at-robot loc_16_5
at-robot loc_16_6
at-robot loc_16_7
at-robot loc_16_8
at-robot loc_16_9
at-robot loc_17_12
at-robot loc_17_15
at-robot loc_17_3
at-robot loc_17_4
at-robot loc_17_5
at-robot loc_17_6
at-robot loc_17_7
at-robot loc_17_8
at-robot loc_18_12
at-robot loc_18_14
at-robot loc_18_15
at-robot loc_18_4
at-robot loc_18_6
at-robot loc_18_7
at-robot loc_19_11
at-robot loc_19_12
at-robot loc_19_15
at-robot loc_19_16
at-robot loc_19_2
at-robot loc_19_3
at-robot loc_19_4
at-robot loc_19_6
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_6
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_6_10
at-robot loc_6_12
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_6_9
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_12
at-robot loc_7_15
at-robot loc_7_2
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_13
at-robot loc_8_15
at-robot loc_8_16
at-robot loc_8_17
at-robot loc_8_2
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_13
at-robot loc_9_15
at-robot loc_9_16
at-robot loc_9_17
at-robot loc_9_19
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
159
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_12
at box1 loc_10_13
at box1 loc_10_14
at box1 loc_10_15
at box1 loc_10_16
at box1 loc_10_17
at box1 loc_10_18
at box1 loc_10_19
at box1 loc_10_2
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_10_9
at box1 loc_11_10
at box1 loc_11_11
at box1 loc_11_13
at box1 loc_11_14
at box1 loc_11_15
at box1 loc_11_17
at box1 loc_11_18
at box1 loc_11_19
at box1 loc_11_3
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_7
at box1 loc_11_8
at box1 loc_12_13
at box1 loc_12_14
at box1 loc_12_15
at box1 loc_12_16
at box1 loc_12_17
at box1 loc_12_18
at box1 loc_12_3
at box1 loc_12_5
at box1 loc_12_6
at box1 loc_12_8
at box1 loc_13_13
at box1 loc_13_14
at box1 loc_13_15
at box1 loc_13_16
at box1 loc_13_17
at box1 loc_13_18
at box1 loc_13_2
at box1 loc_13_3
at box1 loc_13_4
at box1 loc_13_5
at box1 loc_13_6
at box1 loc_13_7
at box1 loc_13_8
at box1 loc_14_13
at box1 loc_14_14
at box1 loc_14_16
at box1 loc_14_5
at box1 loc_14_6
at box1 loc_15_16
at box1 loc_15_5
at box1 loc_15_6
at box1 loc_15_8
at box1 loc_16_10
at box1 loc_16_11
at box1 loc_16_12
at box1 loc_16_13
at box1 loc_16_14
at box1 loc_16_15
at box1 loc_16_16
at box1 loc_16_17
at box1 loc_16_18
at box1 loc_16_4
at box1 loc_16_5
at box1 loc_16_6
at box1 loc_16_7
at box1 loc_16_8
at box1 loc_16_9
at box1 loc_17_15
at box1 loc_17_3
at box1 loc_17_4
at box1 loc_17_5
at box1 loc_17_6
at box1 loc_17_7
at box1 loc_17_8
at box1 loc_18_15
at box1 loc_18_4
at box1 loc_18_6
at box1 loc_18_7
at box1 loc_19_15
at box1 loc_19_4
at box1 loc_19_6
at box1 loc_2_3
at box1 loc_2_4
at box1 loc_2_6
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_6_10
at box1 loc_6_12
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_6_9
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_12
at box1 loc_7_15
at box1 loc_7_2
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_12
at box1 loc_8_13
at box1 loc_8_15
at box1 loc_8_17
at box1 loc_8_2
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_13
at box1 loc_9_15
at box1 loc_9_17
at box1 loc_9_19
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var2
-1
159
at box3 loc_10_10
at box3 loc_10_11
at box3 loc_10_12
at box3 loc_10_13
at box3 loc_10_14
at box3 loc_10_15
at box3 loc_10_16
at box3 loc_10_17
at box3 loc_10_18
at box3 loc_10_19
at box3 loc_10_2
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_10_9
at box3 loc_11_10
at box3 loc_11_11
at box3 loc_11_13
at box3 loc_11_14
at box3 loc_11_15
at box3 loc_11_17
at box3 loc_11_18
at box3 loc_11_19
at box3 loc_11_3
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_7
at box3 loc_11_8
at box3 loc_12_13
at box3 loc_12_14
at box3 loc_12_15
at box3 loc_12_16
at box3 loc_12_17
at box3 loc_12_18
at box3 loc_12_3
at box3 loc_12_5
at box3 loc_12_6
at box3 loc_12_8
at box3 loc_13_13
at box3 loc_13_14
at box3 loc_13_15
at box3 loc_13_16
at box3 loc_13_17
at box3 loc_13_18
at box3 loc_13_2
at box3 loc_13_3
at box3 loc_13_4
at box3 loc_13_5
at box3 loc_13_6
at box3 loc_13_7
at box3 loc_13_8
at box3 loc_14_13
at box3 loc_14_14
at box3 loc_14_16
at box3 loc_14_5
at box3 loc_14_6
at box3 loc_15_16
at box3 loc_15_5
at box3 loc_15_6
at box3 loc_15_8
at box3 loc_16_10
at box3 loc_16_11
at box3 loc_16_12
at box3 loc_16_13
at box3 loc_16_14
at box3 loc_16_15
at box3 loc_16_16
at box3 loc_16_17
at box3 loc_16_18
at box3 loc_16_4
at box3 loc_16_5
at box3 loc_16_6
at box3 loc_16_7
at box3 loc_16_8
at box3 loc_16_9
at box3 loc_17_15
at box3 loc_17_3
at box3 loc_17_4
at box3 loc_17_5
at box3 loc_17_6
at box3 loc_17_7
at box3 loc_17_8
at box3 loc_18_15
at box3 loc_18_4
at box3 loc_18_6
at box3 loc_18_7
at box3 loc_19_15
at box3 loc_19_4
at box3 loc_19_6
at box3 loc_2_3
at box3 loc_2_4
at box3 loc_2_6
at box3 loc_3_2
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_3_7
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_4_8
at box3 loc_4_9
at box3 loc_5_10
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_6_10
at box3 loc_6_12
at box3 loc_6_2
at box3 loc_6_3
at box3 loc_6_4
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_6_9
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_12
at box3 loc_7_15
at box3 loc_7_2
at box3 loc_7_3
at box3 loc_7_4
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_12
at box3 loc_8_13
at box3 loc_8_15
at box3 loc_8_17
at box3 loc_8_2
at box3 loc_8_3
at box3 loc_8_4
at box3 loc_8_7
at box3 loc_8_8
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_13
at box3 loc_9_15
at box3 loc_9_17
at box3 loc_9_19
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var3
-1
159
at box5 loc_10_10
at box5 loc_10_11
at box5 loc_10_12
at box5 loc_10_13
at box5 loc_10_14
at box5 loc_10_15
at box5 loc_10_16
at box5 loc_10_17
at box5 loc_10_18
at box5 loc_10_19
at box5 loc_10_2
at box5 loc_10_3
at box5 loc_10_4
at box5 loc_10_5
at box5 loc_10_6
at box5 loc_10_7
at box5 loc_10_8
at box5 loc_10_9
at box5 loc_11_10
at box5 loc_11_11
at box5 loc_11_13
at box5 loc_11_14
at box5 loc_11_15
at box5 loc_11_17
at box5 loc_11_18
at box5 loc_11_19
at box5 loc_11_3
at box5 loc_11_5
at box5 loc_11_6
at box5 loc_11_7
at box5 loc_11_8
at box5 loc_12_13
at box5 loc_12_14
at box5 loc_12_15
at box5 loc_12_16
at box5 loc_12_17
at box5 loc_12_18
at box5 loc_12_3
at box5 loc_12_5
at box5 loc_12_6
at box5 loc_12_8
at box5 loc_13_13
at box5 loc_13_14
at box5 loc_13_15
at box5 loc_13_16
at box5 loc_13_17
at box5 loc_13_18
at box5 loc_13_2
at box5 loc_13_3
at box5 loc_13_4
at box5 loc_13_5
at box5 loc_13_6
at box5 loc_13_7
at box5 loc_13_8
at box5 loc_14_13
at box5 loc_14_14
at box5 loc_14_16
at box5 loc_14_5
at box5 loc_14_6
at box5 loc_15_16
at box5 loc_15_5
at box5 loc_15_6
at box5 loc_15_8
at box5 loc_16_10
at box5 loc_16_11
at box5 loc_16_12
at box5 loc_16_13
at box5 loc_16_14
at box5 loc_16_15
at box5 loc_16_16
at box5 loc_16_17
at box5 loc_16_18
at box5 loc_16_4
at box5 loc_16_5
at box5 loc_16_6
at box5 loc_16_7
at box5 loc_16_8
at box5 loc_16_9
at box5 loc_17_15
at box5 loc_17_3
at box5 loc_17_4
at box5 loc_17_5
at box5 loc_17_6
at box5 loc_17_7
at box5 loc_17_8
at box5 loc_18_15
at box5 loc_18_4
at box5 loc_18_6
at box5 loc_18_7
at box5 loc_19_15
at box5 loc_19_4
at box5 loc_19_6
at box5 loc_2_3
at box5 loc_2_4
at box5 loc_2_6
at box5 loc_3_2
at box5 loc_3_3
at box5 loc_3_4
at box5 loc_3_5
at box5 loc_3_6
at box5 loc_3_7
at box5 loc_4_3
at box5 loc_4_4
at box5 loc_4_5
at box5 loc_4_6
at box5 loc_4_7
at box5 loc_4_8
at box5 loc_4_9
at box5 loc_5_10
at box5 loc_5_2
at box5 loc_5_3
at box5 loc_5_4
at box5 loc_5_5
at box5 loc_5_6
at box5 loc_5_7
at box5 loc_6_10
at box5 loc_6_12
at box5 loc_6_2
at box5 loc_6_3
at box5 loc_6_4
at box5 loc_6_6
at box5 loc_6_7
at box5 loc_6_8
at box5 loc_6_9
at box5 loc_7_10
at box5 loc_7_11
at box5 loc_7_12
at box5 loc_7_15
at box5 loc_7_2
at box5 loc_7_3
at box5 loc_7_4
at box5 loc_7_7
at box5 loc_7_8
at box5 loc_7_9
at box5 loc_8_10
at box5 loc_8_11
at box5 loc_8_12
at box5 loc_8_13
at box5 loc_8_15
at box5 loc_8_17
at box5 loc_8_2
at box5 loc_8_3
at box5 loc_8_4
at box5 loc_8_7
at box5 loc_8_8
at box5 loc_8_9
at box5 loc_9_10
at box5 loc_9_11
at box5 loc_9_13
at box5 loc_9_15
at box5 loc_9_17
at box5 loc_9_19
at box5 loc_9_3
at box5 loc_9_4
at box5 loc_9_5
at box5 loc_9_6
at box5 loc_9_7
at box5 loc_9_8
at box5 loc_9_9
end_variable
begin_variable
var4
-1
159
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_12
at box2 loc_10_13
at box2 loc_10_14
at box2 loc_10_15
at box2 loc_10_16
at box2 loc_10_17
at box2 loc_10_18
at box2 loc_10_19
at box2 loc_10_2
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_10_9
at box2 loc_11_10
at box2 loc_11_11
at box2 loc_11_13
at box2 loc_11_14
at box2 loc_11_15
at box2 loc_11_17
at box2 loc_11_18
at box2 loc_11_19
at box2 loc_11_3
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_7
at box2 loc_11_8
at box2 loc_12_13
at box2 loc_12_14
at box2 loc_12_15
at box2 loc_12_16
at box2 loc_12_17
at box2 loc_12_18
at box2 loc_12_3
at box2 loc_12_5
at box2 loc_12_6
at box2 loc_12_8
at box2 loc_13_13
at box2 loc_13_14
at box2 loc_13_15
at box2 loc_13_16
at box2 loc_13_17
at box2 loc_13_18
at box2 loc_13_2
at box2 loc_13_3
at box2 loc_13_4
at box2 loc_13_5
at box2 loc_13_6
at box2 loc_13_7
at box2 loc_13_8
at box2 loc_14_13
at box2 loc_14_14
at box2 loc_14_16
at box2 loc_14_5
at box2 loc_14_6
at box2 loc_15_16
at box2 loc_15_5
at box2 loc_15_6
at box2 loc_15_8
at box2 loc_16_10
at box2 loc_16_11
at box2 loc_16_12
at box2 loc_16_13
at box2 loc_16_14
at box2 loc_16_15
at box2 loc_16_16
at box2 loc_16_17
at box2 loc_16_18
at box2 loc_16_4
at box2 loc_16_5
at box2 loc_16_6
at box2 loc_16_7
at box2 loc_16_8
at box2 loc_16_9
at box2 loc_17_15
at box2 loc_17_3
at box2 loc_17_4
at box2 loc_17_5
at box2 loc_17_6
at box2 loc_17_7
at box2 loc_17_8
at box2 loc_18_15
at box2 loc_18_4
at box2 loc_18_6
at box2 loc_18_7
at box2 loc_19_15
at box2 loc_19_4
at box2 loc_19_6
at box2 loc_2_3
at box2 loc_2_4
at box2 loc_2_6
at box2 loc_3_2
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_4_8
at box2 loc_4_9
at box2 loc_5_10
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_6_10
at box2 loc_6_12
at box2 loc_6_2
at box2 loc_6_3
at box2 loc_6_4
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_6_9
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_12
at box2 loc_7_15
at box2 loc_7_2
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_12
at box2 loc_8_13
at box2 loc_8_15
at box2 loc_8_17
at box2 loc_8_2
at box2 loc_8_3
at box2 loc_8_4
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_13
at box2 loc_9_15
at box2 loc_9_17
at box2 loc_9_19
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var5
-1
159
at box4 loc_10_10
at box4 loc_10_11
at box4 loc_10_12
at box4 loc_10_13
at box4 loc_10_14
at box4 loc_10_15
at box4 loc_10_16
at box4 loc_10_17
at box4 loc_10_18
at box4 loc_10_19
at box4 loc_10_2
at box4 loc_10_3
at box4 loc_10_4
at box4 loc_10_5
at box4 loc_10_6
at box4 loc_10_7
at box4 loc_10_8
at box4 loc_10_9
at box4 loc_11_10
at box4 loc_11_11
at box4 loc_11_13
at box4 loc_11_14
at box4 loc_11_15
at box4 loc_11_17
at box4 loc_11_18
at box4 loc_11_19
at box4 loc_11_3
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_7
at box4 loc_11_8
at box4 loc_12_13
at box4 loc_12_14
at box4 loc_12_15
at box4 loc_12_16
at box4 loc_12_17
at box4 loc_12_18
at box4 loc_12_3
at box4 loc_12_5
at box4 loc_12_6
at box4 loc_12_8
at box4 loc_13_13
at box4 loc_13_14
at box4 loc_13_15
at box4 loc_13_16
at box4 loc_13_17
at box4 loc_13_18
at box4 loc_13_2
at box4 loc_13_3
at box4 loc_13_4
at box4 loc_13_5
at box4 loc_13_6
at box4 loc_13_7
at box4 loc_13_8
at box4 loc_14_13
at box4 loc_14_14
at box4 loc_14_16
at box4 loc_14_5
at box4 loc_14_6
at box4 loc_15_16
at box4 loc_15_5
at box4 loc_15_6
at box4 loc_15_8
at box4 loc_16_10
at box4 loc_16_11
at box4 loc_16_12
at box4 loc_16_13
at box4 loc_16_14
at box4 loc_16_15
at box4 loc_16_16
at box4 loc_16_17
at box4 loc_16_18
at box4 loc_16_4
at box4 loc_16_5
at box4 loc_16_6
at box4 loc_16_7
at box4 loc_16_8
at box4 loc_16_9
at box4 loc_17_15
at box4 loc_17_3
at box4 loc_17_4
at box4 loc_17_5
at box4 loc_17_6
at box4 loc_17_7
at box4 loc_17_8
at box4 loc_18_15
at box4 loc_18_4
at box4 loc_18_6
at box4 loc_18_7
at box4 loc_19_15
at box4 loc_19_4
at box4 loc_19_6
at box4 loc_2_3
at box4 loc_2_4
at box4 loc_2_6
at box4 loc_3_2
at box4 loc_3_3
at box4 loc_3_4
at box4 loc_3_5
at box4 loc_3_6
at box4 loc_3_7
at box4 loc_4_3
at box4 loc_4_4
at box4 loc_4_5
at box4 loc_4_6
at box4 loc_4_7
at box4 loc_4_8
at box4 loc_4_9
at box4 loc_5_10
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_5
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_6_10
at box4 loc_6_12
at box4 loc_6_2
at box4 loc_6_3
at box4 loc_6_4
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_6_8
at box4 loc_6_9
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_12
at box4 loc_7_15
at box4 loc_7_2
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_12
at box4 loc_8_13
at box4 loc_8_15
at box4 loc_8_17
at box4 loc_8_2
at box4 loc_8_3
at box4 loc_8_4
at box4 loc_8_7
at box4 loc_8_8
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_13
at box4 loc_9_15
at box4 loc_9_17
at box4 loc_9_19
at box4 loc_9_3
at box4 loc_9_4
at box4 loc_9_5
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var6
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_12_13
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_12_14
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_12_15
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_12_16
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_12_17
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_12_18
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_12_3
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_12_5
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_12_8
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_13_10
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_13_13
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_13_14
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_13_15
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_13_16
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_13_17
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_13_18
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_13_2
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_13_3
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_13_4
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_13_5
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_13_6
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_13_7
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_13_8
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_14_10
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_14_13
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_14_14
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_14_16
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_14_5
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_14_6
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_14_9
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_15_11
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_15_15
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_15_16
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_15_18
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_15_2
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_15_5
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_15_6
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_15_8
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_16_10
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_16_11
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_16_12
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_16_13
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_16_14
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_16_15
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_16_16
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_16_17
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_16_18
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_16_4
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_16_5
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_16_6
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_16_7
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_16_8
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_16_9
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_17_12
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_17_15
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_17_19
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_17_3
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_17_4
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_17_5
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_17_6
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_17_7
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_17_8
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_18_10
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_18_12
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_18_14
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_18_15
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_18_18
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_18_19
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_18_4
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_18_6
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_18_7
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_18_9
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_19_11
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_19_12
none-of-those
end_variable
begin_variable
var88
-1
2
clear loc_19_15
none-of-those
end_variable
begin_variable
var89
-1
2
clear loc_19_16
none-of-those
end_variable
begin_variable
var90
-1
2
clear loc_19_19
none-of-those
end_variable
begin_variable
var91
-1
2
clear loc_19_2
none-of-those
end_variable
begin_variable
var92
-1
2
clear loc_19_3
none-of-those
end_variable
begin_variable
var93
-1
2
clear loc_19_4
none-of-those
end_variable
begin_variable
var94
-1
2
clear loc_19_6
none-of-those
end_variable
begin_variable
var95
-1
2
clear loc_19_8
none-of-those
end_variable
begin_variable
var96
-1
2
clear loc_2_10
none-of-those
end_variable
begin_variable
var97
-1
2
clear loc_2_13
none-of-those
end_variable
begin_variable
var98
-1
2
clear loc_2_14
none-of-those
end_variable
begin_variable
var99
-1
2
clear loc_2_17
none-of-those
end_variable
begin_variable
var100
-1
2
clear loc_2_19
none-of-those
end_variable
begin_variable
var101
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var102
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var103
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var104
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var105
-1
2
clear loc_3_12
none-of-those
end_variable
begin_variable
var106
-1
2
clear loc_3_15
none-of-those
end_variable
begin_variable
var107
-1
2
clear loc_3_16
none-of-those
end_variable
begin_variable
var108
-1
2
clear loc_3_17
none-of-those
end_variable
begin_variable
var109
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var110
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var111
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var112
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var113
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var114
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var115
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var116
-1
2
clear loc_4_18
none-of-those
end_variable
begin_variable
var117
-1
2
clear loc_4_19
none-of-those
end_variable
begin_variable
var118
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var119
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var120
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var121
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var122
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var123
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var124
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var125
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var126
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var127
-1
2
clear loc_5_13
none-of-those
end_variable
begin_variable
var128
-1
2
clear loc_5_14
none-of-those
end_variable
begin_variable
var129
-1
2
clear loc_5_16
none-of-those
end_variable
begin_variable
var130
-1
2
clear loc_5_17
none-of-those
end_variable
begin_variable
var131
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var132
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var133
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var134
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var135
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var136
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var137
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var138
-1
2
clear loc_6_12
none-of-those
end_variable
begin_variable
var139
-1
2
clear loc_6_16
none-of-those
end_variable
begin_variable
var140
-1
2
clear loc_6_17
none-of-those
end_variable
begin_variable
var141
-1
2
clear loc_6_18
none-of-those
end_variable
begin_variable
var142
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var143
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var144
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var145
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var146
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var147
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var148
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var149
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var150
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var151
-1
2
clear loc_7_12
none-of-those
end_variable
begin_variable
var152
-1
2
clear loc_7_15
none-of-those
end_variable
begin_variable
var153
-1
2
clear loc_7_18
none-of-those
end_variable
begin_variable
var154
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var155
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var156
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var157
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var158
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var159
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var160
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var161
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var162
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var163
-1
2
clear loc_8_13
none-of-those
end_variable
begin_variable
var164
-1
2
clear loc_8_15
none-of-those
end_variable
begin_variable
var165
-1
2
clear loc_8_16
none-of-those
end_variable
begin_variable
var166
-1
2
clear loc_8_17
none-of-those
end_variable
begin_variable
var167
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var168
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var169
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var170
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var171
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var172
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var173
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var174
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var175
-1
2
clear loc_9_13
none-of-those
end_variable
begin_variable
var176
-1
2
clear loc_9_15
none-of-those
end_variable
begin_variable
var177
-1
2
clear loc_9_16
none-of-those
end_variable
begin_variable
var178
-1
2
clear loc_9_17
none-of-those
end_variable
begin_variable
var179
-1
2
clear loc_9_19
none-of-those
end_variable
begin_variable
var180
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var181
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var182
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var183
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var184
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var185
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var186
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var187
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var188
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var189
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var190
-1
2
clear loc_10_13
none-of-those
end_variable
begin_variable
var191
-1
2
clear loc_10_14
none-of-those
end_variable
begin_variable
var192
-1
2
clear loc_10_15
none-of-those
end_variable
begin_variable
var193
-1
2
clear loc_10_16
none-of-those
end_variable
begin_variable
var194
-1
2
clear loc_10_17
none-of-those
end_variable
begin_variable
var195
-1
2
clear loc_10_18
none-of-those
end_variable
begin_variable
var196
-1
2
clear loc_10_19
none-of-those
end_variable
begin_variable
var197
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var198
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var199
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var200
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var201
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var202
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var203
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var204
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var205
-1
2
clear loc_11_10
none-of-those
end_variable
begin_variable
var206
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var207
-1
2
clear loc_11_13
none-of-those
end_variable
begin_variable
var208
-1
2
clear loc_11_14
none-of-those
end_variable
begin_variable
var209
-1
2
clear loc_11_15
none-of-those
end_variable
begin_variable
var210
-1
2
clear loc_11_17
none-of-those
end_variable
begin_variable
var211
-1
2
clear loc_11_18
none-of-those
end_variable
begin_variable
var212
-1
2
clear loc_11_19
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_10_10 loc_11_10 down
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_10_11 loc_10_12 right
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_10_11 loc_11_11 down
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_10_12 loc_10_11 left
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_10_12 loc_10_13 right
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_10_13 loc_10_12 left
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_10_13 loc_10_14 right
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_10_13 loc_11_13 down
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_10_13 loc_9_13 up
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_10_14 loc_10_13 left
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_10_14 loc_10_15 right
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_10_14 loc_11_14 down
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_10_15 loc_10_14 left
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_10_15 loc_10_16 right
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_10_15 loc_11_15 down
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_10_15 loc_9_15 up
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_10_16 loc_10_15 left
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_10_16 loc_10_17 right
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_10_16 loc_9_16 up
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_10_17 loc_10_16 left
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_10_17 loc_10_18 right
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_10_17 loc_11_17 down
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_10_17 loc_9_17 up
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_10_18 loc_10_17 left
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_10_18 loc_10_19 right
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_10_18 loc_11_18 down
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_10_19 loc_10_18 left
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_10_19 loc_11_19 down
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_10_19 loc_9_19 up
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_10_2 loc_10_3 right
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_10_2 loc_11_2 down
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_10_3 loc_10_2 left
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_10_3 loc_9_3 up
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_10_8 loc_10_9 right
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_10_8 loc_11_8 down
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_10_9 loc_10_8 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_11_10 loc_10_10 up
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_11_10 loc_11_11 right
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_11_11 loc_10_11 up
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_11_11 loc_11_10 left
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_11_13 loc_10_13 up
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_11_13 loc_11_14 right
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_11_13 loc_12_13 down
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_11_14 loc_10_14 up
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_11_14 loc_11_13 left
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_11_14 loc_11_15 right
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_11_14 loc_12_14 down
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_11_15 loc_10_15 up
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_11_15 loc_11_14 left
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_11_15 loc_12_15 down
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_11_17 loc_10_17 up
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_11_17 loc_11_18 right
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_11_17 loc_12_17 down
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_11_18 loc_10_18 up
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_11_18 loc_11_17 left
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_11_18 loc_11_19 right
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_11_18 loc_12_18 down
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_11_19 loc_10_19 up
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_11_19 loc_11_18 left
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_11_2 loc_10_2 up
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_11_3 loc_12_3 down
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_11_5 loc_12_5 down
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_11_6 loc_11_7 right
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_11_6 loc_12_6 down
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_11_7 loc_11_6 left
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_11_7 loc_11_8 right
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_11_8 loc_10_8 up
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_11_8 loc_11_7 left
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_11_8 loc_12_8 down
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_12_13 loc_11_13 up
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_12_13 loc_12_14 right
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_12_13 loc_13_13 down
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_12_14 loc_11_14 up
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_12_14 loc_12_13 left
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_12_14 loc_12_15 right
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_12_14 loc_13_14 down
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_12_15 loc_11_15 up
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_12_15 loc_12_14 left
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_12_15 loc_12_16 right
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_12_15 loc_13_15 down
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_12_16 loc_12_15 left
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_12_16 loc_12_17 right
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_12_16 loc_13_16 down
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_12_17 loc_11_17 up
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_12_17 loc_12_16 left
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_12_17 loc_12_18 right
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_12_17 loc_13_17 down
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_12_18 loc_11_18 up
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_12_18 loc_12_17 left
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_12_18 loc_13_18 down
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_12_3 loc_11_3 up
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_12_3 loc_13_3 down
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_12_5 loc_11_5 up
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_12_5 loc_12_6 right
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_12_5 loc_13_5 down
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_12_6 loc_11_6 up
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_12_6 loc_12_5 left
none-of-those
end_variable
begin_variable
var344
-1
2
adjacent loc_12_6 loc_13_6 down
none-of-those
end_variable
begin_variable
var345
-1
2
adjacent loc_12_8 loc_11_8 up
none-of-those
end_variable
begin_variable
var346
-1
2
adjacent loc_12_8 loc_12_9 right
none-of-those
end_variable
begin_variable
var347
-1
2
adjacent loc_12_8 loc_13_8 down
none-of-those
end_variable
begin_variable
var348
-1
2
adjacent loc_12_9 loc_12_8 left
none-of-those
end_variable
begin_variable
var349
-1
2
adjacent loc_13_10 loc_14_10 down
none-of-those
end_variable
begin_variable
var350
-1
2
adjacent loc_13_13 loc_12_13 up
none-of-those
end_variable
begin_variable
var351
-1
2
adjacent loc_13_13 loc_13_14 right
none-of-those
end_variable
begin_variable
var352
-1
2
adjacent loc_13_13 loc_14_13 down
none-of-those
end_variable
begin_variable
var353
-1
2
adjacent loc_13_14 loc_12_14 up
none-of-those
end_variable
begin_variable
var354
-1
2
adjacent loc_13_14 loc_13_13 left
none-of-those
end_variable
begin_variable
var355
-1
2
adjacent loc_13_14 loc_13_15 right
none-of-those
end_variable
begin_variable
var356
-1
2
adjacent loc_13_14 loc_14_14 down
none-of-those
end_variable
begin_variable
var357
-1
2
adjacent loc_13_15 loc_12_15 up
none-of-those
end_variable
begin_variable
var358
-1
2
adjacent loc_13_15 loc_13_14 left
none-of-those
end_variable
begin_variable
var359
-1
2
adjacent loc_13_15 loc_13_16 right
none-of-those
end_variable
begin_variable
var360
-1
2
adjacent loc_13_16 loc_12_16 up
none-of-those
end_variable
begin_variable
var361
-1
2
adjacent loc_13_16 loc_13_15 left
none-of-those
end_variable
begin_variable
var362
-1
2
adjacent loc_13_16 loc_13_17 right
none-of-those
end_variable
begin_variable
var363
-1
2
adjacent loc_13_16 loc_14_16 down
none-of-those
end_variable
begin_variable
var364
-1
2
adjacent loc_13_17 loc_12_17 up
none-of-those
end_variable
begin_variable
var365
-1
2
adjacent loc_13_17 loc_13_16 left
none-of-those
end_variable
begin_variable
var366
-1
2
adjacent loc_13_17 loc_13_18 right
none-of-those
end_variable
begin_variable
var367
-1
2
adjacent loc_13_18 loc_12_18 up
none-of-those
end_variable
begin_variable
var368
-1
2
adjacent loc_13_18 loc_13_17 left
none-of-those
end_variable
begin_variable
var369
-1
2
adjacent loc_13_2 loc_13_3 right
none-of-those
end_variable
begin_variable
var370
-1
2
adjacent loc_13_3 loc_12_3 up
none-of-those
end_variable
begin_variable
var371
-1
2
adjacent loc_13_3 loc_13_2 left
none-of-those
end_variable
begin_variable
var372
-1
2
adjacent loc_13_3 loc_13_4 right
none-of-those
end_variable
begin_variable
var373
-1
2
adjacent loc_13_4 loc_13_3 left
none-of-those
end_variable
begin_variable
var374
-1
2
adjacent loc_13_4 loc_13_5 right
none-of-those
end_variable
begin_variable
var375
-1
2
adjacent loc_13_5 loc_12_5 up
none-of-those
end_variable
begin_variable
var376
-1
2
adjacent loc_13_5 loc_13_4 left
none-of-those
end_variable
begin_variable
var377
-1
2
adjacent loc_13_5 loc_13_6 right
none-of-those
end_variable
begin_variable
var378
-1
2
adjacent loc_13_5 loc_14_5 down
none-of-those
end_variable
begin_variable
var379
-1
2
adjacent loc_13_6 loc_12_6 up
none-of-those
end_variable
begin_variable
var380
-1
2
adjacent loc_13_6 loc_13_5 left
none-of-those
end_variable
begin_variable
var381
-1
2
adjacent loc_13_6 loc_13_7 right
none-of-those
end_variable
begin_variable
var382
-1
2
adjacent loc_13_6 loc_14_6 down
none-of-those
end_variable
begin_variable
var383
-1
2
adjacent loc_13_7 loc_13_6 left
none-of-those
end_variable
begin_variable
var384
-1
2
adjacent loc_13_7 loc_13_8 right
none-of-those
end_variable
begin_variable
var385
-1
2
adjacent loc_13_8 loc_12_8 up
none-of-those
end_variable
begin_variable
var386
-1
2
adjacent loc_13_8 loc_13_7 left
none-of-those
end_variable
begin_variable
var387
-1
2
adjacent loc_14_10 loc_13_10 up
none-of-those
end_variable
begin_variable
var388
-1
2
adjacent loc_14_10 loc_14_9 left
none-of-those
end_variable
begin_variable
var389
-1
2
adjacent loc_14_13 loc_13_13 up
none-of-those
end_variable
begin_variable
var390
-1
2
adjacent loc_14_13 loc_14_14 right
none-of-those
end_variable
begin_variable
var391
-1
2
adjacent loc_14_14 loc_13_14 up
none-of-those
end_variable
begin_variable
var392
-1
2
adjacent loc_14_14 loc_14_13 left
none-of-those
end_variable
begin_variable
var393
-1
2
adjacent loc_14_16 loc_13_16 up
none-of-those
end_variable
begin_variable
var394
-1
2
adjacent loc_14_16 loc_15_16 down
none-of-those
end_variable
begin_variable
var395
-1
2
adjacent loc_14_5 loc_13_5 up
none-of-those
end_variable
begin_variable
var396
-1
2
adjacent loc_14_5 loc_14_6 right
none-of-those
end_variable
begin_variable
var397
-1
2
adjacent loc_14_5 loc_15_5 down
none-of-those
end_variable
begin_variable
var398
-1
2
adjacent loc_14_6 loc_13_6 up
none-of-those
end_variable
begin_variable
var399
-1
2
adjacent loc_14_6 loc_14_5 left
none-of-those
end_variable
begin_variable
var400
-1
2
adjacent loc_14_6 loc_15_6 down
none-of-those
end_variable
begin_variable
var401
-1
2
adjacent loc_14_9 loc_14_10 right
none-of-those
end_variable
begin_variable
var402
-1
2
adjacent loc_15_11 loc_16_11 down
none-of-those
end_variable
begin_variable
var403
-1
2
adjacent loc_15_15 loc_15_16 right
none-of-those
end_variable
begin_variable
var404
-1
2
adjacent loc_15_15 loc_16_15 down
none-of-those
end_variable
begin_variable
var405
-1
2
adjacent loc_15_16 loc_14_16 up
none-of-those
end_variable
begin_variable
var406
-1
2
adjacent loc_15_16 loc_15_15 left
none-of-those
end_variable
begin_variable
var407
-1
2
adjacent loc_15_16 loc_16_16 down
none-of-those
end_variable
begin_variable
var408
-1
2
adjacent loc_15_18 loc_16_18 down
none-of-those
end_variable
begin_variable
var409
-1
2
adjacent loc_15_5 loc_14_5 up
none-of-those
end_variable
begin_variable
var410
-1
2
adjacent loc_15_5 loc_15_6 right
none-of-those
end_variable
begin_variable
var411
-1
2
adjacent loc_15_5 loc_16_5 down
none-of-those
end_variable
begin_variable
var412
-1
2
adjacent loc_15_6 loc_14_6 up
none-of-those
end_variable
begin_variable
var413
-1
2
adjacent loc_15_6 loc_15_5 left
none-of-those
end_variable
begin_variable
var414
-1
2
adjacent loc_15_6 loc_16_6 down
none-of-those
end_variable
begin_variable
var415
-1
2
adjacent loc_15_8 loc_16_8 down
none-of-those
end_variable
begin_variable
var416
-1
2
adjacent loc_16_10 loc_16_11 right
none-of-those
end_variable
begin_variable
var417
-1
2
adjacent loc_16_10 loc_16_9 left
none-of-those
end_variable
begin_variable
var418
-1
2
adjacent loc_16_11 loc_15_11 up
none-of-those
end_variable
begin_variable
var419
-1
2
adjacent loc_16_11 loc_16_10 left
none-of-those
end_variable
begin_variable
var420
-1
2
adjacent loc_16_11 loc_16_12 right
none-of-those
end_variable
begin_variable
var421
-1
2
adjacent loc_16_12 loc_16_11 left
none-of-those
end_variable
begin_variable
var422
-1
2
adjacent loc_16_12 loc_16_13 right
none-of-those
end_variable
begin_variable
var423
-1
2
adjacent loc_16_12 loc_17_12 down
none-of-those
end_variable
begin_variable
var424
-1
2
adjacent loc_16_13 loc_16_12 left
none-of-those
end_variable
begin_variable
var425
-1
2
adjacent loc_16_13 loc_16_14 right
none-of-those
end_variable
begin_variable
var426
-1
2
adjacent loc_16_14 loc_16_13 left
none-of-those
end_variable
begin_variable
var427
-1
2
adjacent loc_16_14 loc_16_15 right
none-of-those
end_variable
begin_variable
var428
-1
2
adjacent loc_16_15 loc_15_15 up
none-of-those
end_variable
begin_variable
var429
-1
2
adjacent loc_16_15 loc_16_14 left
none-of-those
end_variable
begin_variable
var430
-1
2
adjacent loc_16_15 loc_16_16 right
none-of-those
end_variable
begin_variable
var431
-1
2
adjacent loc_16_15 loc_17_15 down
none-of-those
end_variable
begin_variable
var432
-1
2
adjacent loc_16_16 loc_15_16 up
none-of-those
end_variable
begin_variable
var433
-1
2
adjacent loc_16_16 loc_16_15 left
none-of-those
end_variable
begin_variable
var434
-1
2
adjacent loc_16_16 loc_16_17 right
none-of-those
end_variable
begin_variable
var435
-1
2
adjacent loc_16_17 loc_16_16 left
none-of-those
end_variable
begin_variable
var436
-1
2
adjacent loc_16_17 loc_16_18 right
none-of-those
end_variable
begin_variable
var437
-1
2
adjacent loc_16_18 loc_15_18 up
none-of-those
end_variable
begin_variable
var438
-1
2
adjacent loc_16_18 loc_16_17 left
none-of-those
end_variable
begin_variable
var439
-1
2
adjacent loc_16_4 loc_16_5 right
none-of-those
end_variable
begin_variable
var440
-1
2
adjacent loc_16_4 loc_17_4 down
none-of-those
end_variable
begin_variable
var441
-1
2
adjacent loc_16_5 loc_15_5 up
none-of-those
end_variable
begin_variable
var442
-1
2
adjacent loc_16_5 loc_16_4 left
none-of-those
end_variable
begin_variable
var443
-1
2
adjacent loc_16_5 loc_16_6 right
none-of-those
end_variable
begin_variable
var444
-1
2
adjacent loc_16_5 loc_17_5 down
none-of-those
end_variable
begin_variable
var445
-1
2
adjacent loc_16_6 loc_15_6 up
none-of-those
end_variable
begin_variable
var446
-1
2
adjacent loc_16_6 loc_16_5 left
none-of-those
end_variable
begin_variable
var447
-1
2
adjacent loc_16_6 loc_16_7 right
none-of-those
end_variable
begin_variable
var448
-1
2
adjacent loc_16_6 loc_17_6 down
none-of-those
end_variable
begin_variable
var449
-1
2
adjacent loc_16_7 loc_16_6 left
none-of-those
end_variable
begin_variable
var450
-1
2
adjacent loc_16_7 loc_16_8 right
none-of-those
end_variable
begin_variable
var451
-1
2
adjacent loc_16_7 loc_17_7 down
none-of-those
end_variable
begin_variable
var452
-1
2
adjacent loc_16_8 loc_15_8 up
none-of-those
end_variable
begin_variable
var453
-1
2
adjacent loc_16_8 loc_16_7 left
none-of-those
end_variable
begin_variable
var454
-1
2
adjacent loc_16_8 loc_16_9 right
none-of-those
end_variable
begin_variable
var455
-1
2
adjacent loc_16_8 loc_17_8 down
none-of-those
end_variable
begin_variable
var456
-1
2
adjacent loc_16_9 loc_16_10 right
none-of-those
end_variable
begin_variable
var457
-1
2
adjacent loc_16_9 loc_16_8 left
none-of-those
end_variable
begin_variable
var458
-1
2
adjacent loc_17_12 loc_16_12 up
none-of-those
end_variable
begin_variable
var459
-1
2
adjacent loc_17_12 loc_18_12 down
none-of-those
end_variable
begin_variable
var460
-1
2
adjacent loc_17_15 loc_16_15 up
none-of-those
end_variable
begin_variable
var461
-1
2
adjacent loc_17_15 loc_18_15 down
none-of-those
end_variable
begin_variable
var462
-1
2
adjacent loc_17_19 loc_18_19 down
none-of-those
end_variable
begin_variable
var463
-1
2
adjacent loc_17_3 loc_17_4 right
none-of-those
end_variable
begin_variable
var464
-1
2
adjacent loc_17_4 loc_16_4 up
none-of-those
end_variable
begin_variable
var465
-1
2
adjacent loc_17_4 loc_17_3 left
none-of-those
end_variable
begin_variable
var466
-1
2
adjacent loc_17_4 loc_17_5 right
none-of-those
end_variable
begin_variable
var467
-1
2
adjacent loc_17_4 loc_18_4 down
none-of-those
end_variable
begin_variable
var468
-1
2
adjacent loc_17_5 loc_16_5 up
none-of-those
end_variable
begin_variable
var469
-1
2
adjacent loc_17_5 loc_17_4 left
none-of-those
end_variable
begin_variable
var470
-1
2
adjacent loc_17_5 loc_17_6 right
none-of-those
end_variable
begin_variable
var471
-1
2
adjacent loc_17_6 loc_16_6 up
none-of-those
end_variable
begin_variable
var472
-1
2
adjacent loc_17_6 loc_17_5 left
none-of-those
end_variable
begin_variable
var473
-1
2
adjacent loc_17_6 loc_17_7 right
none-of-those
end_variable
begin_variable
var474
-1
2
adjacent loc_17_6 loc_18_6 down
none-of-those
end_variable
begin_variable
var475
-1
2
adjacent loc_17_7 loc_16_7 up
none-of-those
end_variable
begin_variable
var476
-1
2
adjacent loc_17_7 loc_17_6 left
none-of-those
end_variable
begin_variable
var477
-1
2
adjacent loc_17_7 loc_17_8 right
none-of-those
end_variable
begin_variable
var478
-1
2
adjacent loc_17_7 loc_18_7 down
none-of-those
end_variable
begin_variable
var479
-1
2
adjacent loc_17_8 loc_16_8 up
none-of-those
end_variable
begin_variable
var480
-1
2
adjacent loc_17_8 loc_17_7 left
none-of-those
end_variable
begin_variable
var481
-1
2
adjacent loc_18_10 loc_18_9 left
none-of-those
end_variable
begin_variable
var482
-1
2
adjacent loc_18_12 loc_17_12 up
none-of-those
end_variable
begin_variable
var483
-1
2
adjacent loc_18_12 loc_19_12 down
none-of-those
end_variable
begin_variable
var484
-1
2
adjacent loc_18_14 loc_18_15 right
none-of-those
end_variable
begin_variable
var485
-1
2
adjacent loc_18_15 loc_17_15 up
none-of-those
end_variable
begin_variable
var486
-1
2
adjacent loc_18_15 loc_18_14 left
none-of-those
end_variable
begin_variable
var487
-1
2
adjacent loc_18_15 loc_19_15 down
none-of-those
end_variable
begin_variable
var488
-1
2
adjacent loc_18_18 loc_18_19 right
none-of-those
end_variable
begin_variable
var489
-1
2
adjacent loc_18_19 loc_17_19 up
none-of-those
end_variable
begin_variable
var490
-1
2
adjacent loc_18_19 loc_18_18 left
none-of-those
end_variable
begin_variable
var491
-1
2
adjacent loc_18_19 loc_19_19 down
none-of-those
end_variable
begin_variable
var492
-1
2
adjacent loc_18_4 loc_17_4 up
none-of-those
end_variable
begin_variable
var493
-1
2
adjacent loc_18_4 loc_19_4 down
none-of-those
end_variable
begin_variable
var494
-1
2
adjacent loc_18_6 loc_17_6 up
none-of-those
end_variable
begin_variable
var495
-1
2
adjacent loc_18_6 loc_18_7 right
none-of-those
end_variable
begin_variable
var496
-1
2
adjacent loc_18_6 loc_19_6 down
none-of-those
end_variable
begin_variable
var497
-1
2
adjacent loc_18_7 loc_17_7 up
none-of-those
end_variable
begin_variable
var498
-1
2
adjacent loc_18_7 loc_18_6 left
none-of-those
end_variable
begin_variable
var499
-1
2
adjacent loc_18_9 loc_18_10 right
none-of-those
end_variable
begin_variable
var500
-1
2
adjacent loc_19_11 loc_19_12 right
none-of-those
end_variable
begin_variable
var501
-1
2
adjacent loc_19_12 loc_18_12 up
none-of-those
end_variable
begin_variable
var502
-1
2
adjacent loc_19_12 loc_19_11 left
none-of-those
end_variable
begin_variable
var503
-1
2
adjacent loc_19_15 loc_18_15 up
none-of-those
end_variable
begin_variable
var504
-1
2
adjacent loc_19_15 loc_19_16 right
none-of-those
end_variable
begin_variable
var505
-1
2
adjacent loc_19_16 loc_19_15 left
none-of-those
end_variable
begin_variable
var506
-1
2
adjacent loc_19_19 loc_18_19 up
none-of-those
end_variable
begin_variable
var507
-1
2
adjacent loc_19_2 loc_19_3 right
none-of-those
end_variable
begin_variable
var508
-1
2
adjacent loc_19_3 loc_19_2 left
none-of-those
end_variable
begin_variable
var509
-1
2
adjacent loc_19_3 loc_19_4 right
none-of-those
end_variable
begin_variable
var510
-1
2
adjacent loc_19_4 loc_18_4 up
none-of-those
end_variable
begin_variable
var511
-1
2
adjacent loc_19_4 loc_19_3 left
none-of-those
end_variable
begin_variable
var512
-1
2
adjacent loc_19_6 loc_18_6 up
none-of-those
end_variable
begin_variable
var513
-1
2
adjacent loc_2_13 loc_2_14 right
none-of-those
end_variable
begin_variable
var514
-1
2
adjacent loc_2_14 loc_2_13 left
none-of-those
end_variable
begin_variable
var515
-1
2
adjacent loc_2_17 loc_3_17 down
none-of-those
end_variable
begin_variable
var516
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var517
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var518
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var519
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var520
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var521
-1
2
adjacent loc_3_11 loc_3_12 right
none-of-those
end_variable
begin_variable
var522
-1
2
adjacent loc_3_12 loc_3_11 left
none-of-those
end_variable
begin_variable
var523
-1
2
adjacent loc_3_12 loc_4_12 down
none-of-those
end_variable
begin_variable
var524
-1
2
adjacent loc_3_15 loc_3_16 right
none-of-those
end_variable
begin_variable
var525
-1
2
adjacent loc_3_16 loc_3_15 left
none-of-those
end_variable
begin_variable
var526
-1
2
adjacent loc_3_16 loc_3_17 right
none-of-those
end_variable
begin_variable
var527
-1
2
adjacent loc_3_17 loc_2_17 up
none-of-those
end_variable
begin_variable
var528
-1
2
adjacent loc_3_17 loc_3_16 left
none-of-those
end_variable
begin_variable
var529
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var530
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var531
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var532
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var533
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var534
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var535
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var536
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var537
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var538
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var539
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var540
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var541
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var542
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var543
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var544
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var545
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var546
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var547
-1
2
adjacent loc_4_12 loc_3_12 up
none-of-those
end_variable
begin_variable
var548
-1
2
adjacent loc_4_18 loc_4_19 right
none-of-those
end_variable
begin_variable
var549
-1
2
adjacent loc_4_19 loc_4_18 left
none-of-those
end_variable
begin_variable
var550
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var551
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var552
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var553
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var554
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var555
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var556
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var557
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var558
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var559
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var560
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var561
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var562
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var563
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var564
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var565
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var566
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var567
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var568
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var569
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var570
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var571
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var572
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var573
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var574
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var575
-1
2
adjacent loc_5_13 loc_5_14 right
none-of-those
end_variable
begin_variable
var576
-1
2
adjacent loc_5_14 loc_5_13 left
none-of-those
end_variable
begin_variable
var577
-1
2
adjacent loc_5_16 loc_5_17 right
none-of-those
end_variable
begin_variable
var578
-1
2
adjacent loc_5_16 loc_6_16 down
none-of-those
end_variable
begin_variable
var579
-1
2
adjacent loc_5_17 loc_5_16 left
none-of-those
end_variable
begin_variable
var580
-1
2
adjacent loc_5_17 loc_6_17 down
none-of-those
end_variable
begin_variable
var581
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var582
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var583
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var584
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var585
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var586
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var587
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var588
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var589
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var590
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var591
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var592
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var593
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var594
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var595
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var596
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var597
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var598
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var599
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var600
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var601
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var602
-1
2
adjacent loc_6_10 loc_6_9 left
none-of-those
end_variable
begin_variable
var603
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var604
-1
2
adjacent loc_6_12 loc_7_12 down
none-of-those
end_variable
begin_variable
var605
-1
2
adjacent loc_6_16 loc_5_16 up
none-of-those
end_variable
begin_variable
var606
-1
2
adjacent loc_6_16 loc_6_17 right
none-of-those
end_variable
begin_variable
var607
-1
2
adjacent loc_6_17 loc_5_17 up
none-of-those
end_variable
begin_variable
var608
-1
2
adjacent loc_6_17 loc_6_16 left
none-of-those
end_variable
begin_variable
var609
-1
2
adjacent loc_6_17 loc_6_18 right
none-of-those
end_variable
begin_variable
var610
-1
2
adjacent loc_6_18 loc_6_17 left
none-of-those
end_variable
begin_variable
var611
-1
2
adjacent loc_6_18 loc_7_18 down
none-of-those
end_variable
begin_variable
var612
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var613
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var614
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var615
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var616
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var617
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var618
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var619
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var620
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var621
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var622
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var623
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var624
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var625
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var626
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var627
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var628
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var629
-1
2
adjacent loc_6_8 loc_6_9 right
none-of-those
end_variable
begin_variable
var630
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var631
-1
2
adjacent loc_6_9 loc_6_10 right
none-of-those
end_variable
begin_variable
var632
-1
2
adjacent loc_6_9 loc_6_8 left
none-of-those
end_variable
begin_variable
var633
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var634
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var635
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var636
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var637
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var638
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var639
-1
2
adjacent loc_7_11 loc_7_12 right
none-of-those
end_variable
begin_variable
var640
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var641
-1
2
adjacent loc_7_12 loc_6_12 up
none-of-those
end_variable
begin_variable
var642
-1
2
adjacent loc_7_12 loc_7_11 left
none-of-those
end_variable
begin_variable
var643
-1
2
adjacent loc_7_12 loc_8_12 down
none-of-those
end_variable
begin_variable
var644
-1
2
adjacent loc_7_15 loc_8_15 down
none-of-those
end_variable
begin_variable
var645
-1
2
adjacent loc_7_18 loc_6_18 up
none-of-those
end_variable
begin_variable
var646
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var647
-1
2
adjacent loc_7_2 loc_7_3 right
none-of-those
end_variable
begin_variable
var648
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var649
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var650
-1
2
adjacent loc_7_3 loc_7_2 left
none-of-those
end_variable
begin_variable
var651
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var652
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var653
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var654
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var655
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var656
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var657
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var658
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var659
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var660
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var661
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var662
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var663
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var664
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var665
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var666
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var667
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var668
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var669
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var670
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var671
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var672
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var673
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var674
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var675
-1
2
adjacent loc_8_12 loc_7_12 up
none-of-those
end_variable
begin_variable
var676
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var677
-1
2
adjacent loc_8_12 loc_8_13 right
none-of-those
end_variable
begin_variable
var678
-1
2
adjacent loc_8_13 loc_8_12 left
none-of-those
end_variable
begin_variable
var679
-1
2
adjacent loc_8_13 loc_9_13 down
none-of-those
end_variable
begin_variable
var680
-1
2
adjacent loc_8_15 loc_7_15 up
none-of-those
end_variable
begin_variable
var681
-1
2
adjacent loc_8_15 loc_8_16 right
none-of-those
end_variable
begin_variable
var682
-1
2
adjacent loc_8_15 loc_9_15 down
none-of-those
end_variable
begin_variable
var683
-1
2
adjacent loc_8_16 loc_8_15 left
none-of-those
end_variable
begin_variable
var684
-1
2
adjacent loc_8_16 loc_8_17 right
none-of-those
end_variable
begin_variable
var685
-1
2
adjacent loc_8_16 loc_9_16 down
none-of-those
end_variable
begin_variable
var686
-1
2
adjacent loc_8_17 loc_8_16 left
none-of-those
end_variable
begin_variable
var687
-1
2
adjacent loc_8_17 loc_9_17 down
none-of-those
end_variable
begin_variable
var688
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var689
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var690
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var691
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var692
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var693
-1
2
adjacent loc_8_3 loc_9_3 down
none-of-those
end_variable
begin_variable
var694
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var695
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var696
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var697
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var698
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var699
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var700
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var701
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var702
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var703
-1
2
adjacent loc_8_8 loc_9_8 down
none-of-those
end_variable
begin_variable
var704
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var705
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var706
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var707
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var708
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var709
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var710
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var711
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var712
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var713
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var714
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var715
-1
2
adjacent loc_9_13 loc_10_13 down
none-of-those
end_variable
begin_variable
var716
-1
2
adjacent loc_9_13 loc_8_13 up
none-of-those
end_variable
begin_variable
var717
-1
2
adjacent loc_9_15 loc_10_15 down
none-of-those
end_variable
begin_variable
var718
-1
2
adjacent loc_9_15 loc_8_15 up
none-of-those
end_variable
begin_variable
var719
-1
2
adjacent loc_9_15 loc_9_16 right
none-of-those
end_variable
begin_variable
var720
-1
2
adjacent loc_9_16 loc_10_16 down
none-of-those
end_variable
begin_variable
var721
-1
2
adjacent loc_9_16 loc_8_16 up
none-of-those
end_variable
begin_variable
var722
-1
2
adjacent loc_9_16 loc_9_15 left
none-of-those
end_variable
begin_variable
var723
-1
2
adjacent loc_9_16 loc_9_17 right
none-of-those
end_variable
begin_variable
var724
-1
2
adjacent loc_9_17 loc_10_17 down
none-of-those
end_variable
begin_variable
var725
-1
2
adjacent loc_9_17 loc_8_17 up
none-of-those
end_variable
begin_variable
var726
-1
2
adjacent loc_9_17 loc_9_16 left
none-of-those
end_variable
begin_variable
var727
-1
2
adjacent loc_9_19 loc_10_19 down
none-of-those
end_variable
begin_variable
var728
-1
2
adjacent loc_9_3 loc_10_3 down
none-of-those
end_variable
begin_variable
var729
-1
2
adjacent loc_9_3 loc_8_3 up
none-of-those
end_variable
begin_variable
var730
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var731
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var732
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var733
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var734
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var735
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var736
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var737
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var738
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var739
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var740
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var741
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var742
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var743
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var744
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var745
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var746
-1
2
adjacent loc_9_8 loc_8_8 up
none-of-those
end_variable
begin_variable
var747
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var748
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var749
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var750
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var751
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var752
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
109
142
37
135
65
6
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
5
1 101
2 105
3 145
4 80
5 33
end_goal
2195
begin_operator
move loc_10_10 loc_10_11 right
2
188 0
213 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_10_9 left
2
204 0
214 0
1
0 0 0 17
1
end_operator
begin_operator
move loc_10_10 loc_11_10 down
2
205 0
215 0
1
0 0 0 18
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
173 0
216 0
1
0 0 0 161
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
187 0
217 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_10_12 right
2
189 0
218 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_11 loc_11_11 down
2
206 0
219 0
1
0 0 1 19
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
174 0
220 0
1
0 0 1 162
1
end_operator
begin_operator
move loc_10_12 loc_10_11 left
2
188 0
221 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_12 loc_10_13 right
2
190 0
222 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_13 loc_10_12 left
2
189 0
223 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_13 loc_10_14 right
2
191 0
224 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_13 loc_11_13 down
2
207 0
225 0
1
0 0 3 20
1
end_operator
begin_operator
move loc_10_13 loc_9_13 up
2
175 0
226 0
1
0 0 3 163
1
end_operator
begin_operator
move loc_10_14 loc_10_13 left
2
190 0
227 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_14 loc_10_15 right
2
192 0
228 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_14 loc_11_14 down
2
208 0
229 0
1
0 0 4 21
1
end_operator
begin_operator
move loc_10_15 loc_10_14 left
2
191 0
230 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_15 loc_10_16 right
2
193 0
231 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_15 loc_11_15 down
2
209 0
232 0
1
0 0 5 22
1
end_operator
begin_operator
move loc_10_15 loc_9_15 up
2
176 0
233 0
1
0 0 5 164
1
end_operator
begin_operator
move loc_10_16 loc_10_15 left
2
192 0
234 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_16 loc_10_17 right
2
194 0
235 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_16 loc_9_16 up
2
177 0
236 0
1
0 0 6 165
1
end_operator
begin_operator
move loc_10_17 loc_10_16 left
2
193 0
237 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_17 loc_10_18 right
2
195 0
238 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_17 loc_11_17 down
2
210 0
239 0
1
0 0 7 23
1
end_operator
begin_operator
move loc_10_17 loc_9_17 up
2
178 0
240 0
1
0 0 7 166
1
end_operator
begin_operator
move loc_10_18 loc_10_17 left
2
194 0
241 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_18 loc_10_19 right
2
196 0
242 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_10_18 loc_11_18 down
2
211 0
243 0
1
0 0 8 24
1
end_operator
begin_operator
move loc_10_19 loc_10_18 left
2
195 0
244 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_10_19 loc_11_19 down
2
212 0
245 0
1
0 0 9 25
1
end_operator
begin_operator
move loc_10_19 loc_9_19 up
2
179 0
246 0
1
0 0 9 167
1
end_operator
begin_operator
move loc_10_2 loc_10_3 right
2
198 0
247 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_10_2 loc_11_2 down
2
6 0
248 0
1
0 0 10 26
1
end_operator
begin_operator
move loc_10_3 loc_10_2 left
2
197 0
249 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
199 0
250 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
7 0
251 0
1
0 0 11 27
1
end_operator
begin_operator
move loc_10_3 loc_9_3 up
2
180 0
252 0
1
0 0 11 168
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
198 0
253 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
200 0
254 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
181 0
255 0
1
0 0 12 169
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
199 0
256 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
201 0
257 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
8 0
258 0
1
0 0 13 28
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
182 0
259 0
1
0 0 13 170
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
200 0
260 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
202 0
261 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
9 0
262 0
1
0 0 14 29
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
183 0
263 0
1
0 0 14 171
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
201 0
264 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
203 0
265 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
10 0
266 0
1
0 0 15 30
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
184 0
267 0
1
0 0 15 172
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
202 0
268 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_10_8 loc_10_9 right
2
204 0
269 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_10_8 loc_11_8 down
2
11 0
270 0
1
0 0 16 31
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
185 0
271 0
1
0 0 16 173
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
187 0
272 0
1
0 0 17 0
1
end_operator
begin_operator
move loc_10_9 loc_10_8 left
2
203 0
273 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
186 0
274 0
1
0 0 17 174
1
end_operator
begin_operator
move loc_11_10 loc_10_10 up
2
187 0
275 0
1
0 0 18 0
1
end_operator
begin_operator
move loc_11_10 loc_11_11 right
2
206 0
276 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_11_11 loc_10_11 up
2
188 0
277 0
1
0 0 19 1
1
end_operator
begin_operator
move loc_11_11 loc_11_10 left
2
205 0
278 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_11_13 loc_10_13 up
2
190 0
279 0
1
0 0 20 3
1
end_operator
begin_operator
move loc_11_13 loc_11_14 right
2
208 0
280 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_11_13 loc_12_13 down
2
12 0
281 0
1
0 0 20 32
1
end_operator
begin_operator
move loc_11_14 loc_10_14 up
2
191 0
282 0
1
0 0 21 4
1
end_operator
begin_operator
move loc_11_14 loc_11_13 left
2
207 0
283 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_11_14 loc_11_15 right
2
209 0
284 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_11_14 loc_12_14 down
2
13 0
285 0
1
0 0 21 33
1
end_operator
begin_operator
move loc_11_15 loc_10_15 up
2
192 0
286 0
1
0 0 22 5
1
end_operator
begin_operator
move loc_11_15 loc_11_14 left
2
208 0
287 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_11_15 loc_12_15 down
2
14 0
288 0
1
0 0 22 34
1
end_operator
begin_operator
move loc_11_17 loc_10_17 up
2
194 0
289 0
1
0 0 23 7
1
end_operator
begin_operator
move loc_11_17 loc_11_18 right
2
211 0
290 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_11_17 loc_12_17 down
2
16 0
291 0
1
0 0 23 36
1
end_operator
begin_operator
move loc_11_18 loc_10_18 up
2
195 0
292 0
1
0 0 24 8
1
end_operator
begin_operator
move loc_11_18 loc_11_17 left
2
210 0
293 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_11_18 loc_11_19 right
2
212 0
294 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_11_18 loc_12_18 down
2
17 0
295 0
1
0 0 24 37
1
end_operator
begin_operator
move loc_11_19 loc_10_19 up
2
196 0
296 0
1
0 0 25 9
1
end_operator
begin_operator
move loc_11_19 loc_11_18 left
2
211 0
297 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_11_2 loc_10_2 up
2
197 0
298 0
1
0 0 26 10
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
7 0
299 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
198 0
300 0
1
0 0 27 11
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
6 0
301 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_11_3 loc_12_3 down
2
18 0
302 0
1
0 0 27 38
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
200 0
303 0
1
0 0 28 13
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
9 0
304 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_11_5 loc_12_5 down
2
19 0
305 0
1
0 0 28 39
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
201 0
306 0
1
0 0 29 14
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
8 0
307 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_11_6 loc_11_7 right
2
10 0
308 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_11_6 loc_12_6 down
2
20 0
309 0
1
0 0 29 40
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
202 0
310 0
1
0 0 30 15
1
end_operator
begin_operator
move loc_11_7 loc_11_6 left
2
9 0
311 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_11_7 loc_11_8 right
2
11 0
312 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_11_8 loc_10_8 up
2
203 0
313 0
1
0 0 31 16
1
end_operator
begin_operator
move loc_11_8 loc_11_7 left
2
10 0
314 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_11_8 loc_12_8 down
2
21 0
315 0
1
0 0 31 41
1
end_operator
begin_operator
move loc_12_13 loc_11_13 up
2
207 0
316 0
1
0 0 32 20
1
end_operator
begin_operator
move loc_12_13 loc_12_14 right
2
13 0
317 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_12_13 loc_13_13 down
2
24 0
318 0
1
0 0 32 43
1
end_operator
begin_operator
move loc_12_14 loc_11_14 up
2
208 0
319 0
1
0 0 33 21
1
end_operator
begin_operator
move loc_12_14 loc_12_13 left
2
12 0
320 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_12_14 loc_12_15 right
2
14 0
321 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_12_14 loc_13_14 down
2
25 0
322 0
1
0 0 33 44
1
end_operator
begin_operator
move loc_12_15 loc_11_15 up
2
209 0
323 0
1
0 0 34 22
1
end_operator
begin_operator
move loc_12_15 loc_12_14 left
2
13 0
324 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_12_15 loc_12_16 right
2
15 0
325 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_12_15 loc_13_15 down
2
26 0
326 0
1
0 0 34 45
1
end_operator
begin_operator
move loc_12_16 loc_12_15 left
2
14 0
327 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_12_16 loc_12_17 right
2
16 0
328 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_12_16 loc_13_16 down
2
27 0
329 0
1
0 0 35 46
1
end_operator
begin_operator
move loc_12_17 loc_11_17 up
2
210 0
330 0
1
0 0 36 23
1
end_operator
begin_operator
move loc_12_17 loc_12_16 left
2
15 0
331 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_12_17 loc_12_18 right
2
17 0
332 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_12_17 loc_13_17 down
2
28 0
333 0
1
0 0 36 47
1
end_operator
begin_operator
move loc_12_18 loc_11_18 up
2
211 0
334 0
1
0 0 37 24
1
end_operator
begin_operator
move loc_12_18 loc_12_17 left
2
16 0
335 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_12_18 loc_13_18 down
2
29 0
336 0
1
0 0 37 48
1
end_operator
begin_operator
move loc_12_3 loc_11_3 up
2
7 0
337 0
1
0 0 38 27
1
end_operator
begin_operator
move loc_12_3 loc_13_3 down
2
31 0
338 0
1
0 0 38 50
1
end_operator
begin_operator
move loc_12_5 loc_11_5 up
2
8 0
339 0
1
0 0 39 28
1
end_operator
begin_operator
move loc_12_5 loc_12_6 right
2
20 0
340 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_12_5 loc_13_5 down
2
33 0
341 0
1
0 0 39 52
1
end_operator
begin_operator
move loc_12_6 loc_11_6 up
2
9 0
342 0
1
0 0 40 29
1
end_operator
begin_operator
move loc_12_6 loc_12_5 left
2
19 0
343 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_12_6 loc_13_6 down
2
34 0
344 0
1
0 0 40 53
1
end_operator
begin_operator
move loc_12_8 loc_11_8 up
2
11 0
345 0
1
0 0 41 31
1
end_operator
begin_operator
move loc_12_8 loc_12_9 right
2
22 0
346 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_12_8 loc_13_8 down
2
36 0
347 0
1
0 0 41 55
1
end_operator
begin_operator
move loc_12_9 loc_12_8 left
2
21 0
348 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_13_13 loc_12_13 up
2
12 0
350 0
1
0 0 43 32
1
end_operator
begin_operator
move loc_13_13 loc_13_14 right
2
25 0
351 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_13_13 loc_14_13 down
2
38 0
352 0
1
0 0 43 56
1
end_operator
begin_operator
move loc_13_14 loc_12_14 up
2
13 0
353 0
1
0 0 44 33
1
end_operator
begin_operator
move loc_13_14 loc_13_13 left
2
24 0
354 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_13_14 loc_13_15 right
2
26 0
355 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_13_14 loc_14_14 down
2
39 0
356 0
1
0 0 44 57
1
end_operator
begin_operator
move loc_13_15 loc_12_15 up
2
14 0
357 0
1
0 0 45 34
1
end_operator
begin_operator
move loc_13_15 loc_13_14 left
2
25 0
358 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_13_15 loc_13_16 right
2
27 0
359 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_13_16 loc_12_16 up
2
15 0
360 0
1
0 0 46 35
1
end_operator
begin_operator
move loc_13_16 loc_13_15 left
2
26 0
361 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_13_16 loc_13_17 right
2
28 0
362 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_13_16 loc_14_16 down
2
40 0
363 0
1
0 0 46 58
1
end_operator
begin_operator
move loc_13_17 loc_12_17 up
2
16 0
364 0
1
0 0 47 36
1
end_operator
begin_operator
move loc_13_17 loc_13_16 left
2
27 0
365 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_13_17 loc_13_18 right
2
29 0
366 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_13_18 loc_12_18 up
2
17 0
367 0
1
0 0 48 37
1
end_operator
begin_operator
move loc_13_18 loc_13_17 left
2
28 0
368 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_13_2 loc_13_3 right
2
31 0
369 0
1
0 0 49 50
1
end_operator
begin_operator
move loc_13_3 loc_12_3 up
2
18 0
370 0
1
0 0 50 38
1
end_operator
begin_operator
move loc_13_3 loc_13_2 left
2
30 0
371 0
1
0 0 50 49
1
end_operator
begin_operator
move loc_13_3 loc_13_4 right
2
32 0
372 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_13_4 loc_13_3 left
2
31 0
373 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_13_4 loc_13_5 right
2
33 0
374 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_13_5 loc_12_5 up
2
19 0
375 0
1
0 0 52 39
1
end_operator
begin_operator
move loc_13_5 loc_13_4 left
2
32 0
376 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_13_5 loc_13_6 right
2
34 0
377 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_13_5 loc_14_5 down
2
41 0
378 0
1
0 0 52 59
1
end_operator
begin_operator
move loc_13_6 loc_12_6 up
2
20 0
379 0
1
0 0 53 40
1
end_operator
begin_operator
move loc_13_6 loc_13_5 left
2
33 0
380 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_13_6 loc_13_7 right
2
35 0
381 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_13_6 loc_14_6 down
2
42 0
382 0
1
0 0 53 60
1
end_operator
begin_operator
move loc_13_7 loc_13_6 left
2
34 0
383 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_13_7 loc_13_8 right
2
36 0
384 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_13_8 loc_12_8 up
2
21 0
385 0
1
0 0 55 41
1
end_operator
begin_operator
move loc_13_8 loc_13_7 left
2
35 0
386 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_14_13 loc_13_13 up
2
24 0
389 0
1
0 0 56 43
1
end_operator
begin_operator
move loc_14_13 loc_14_14 right
2
39 0
390 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_14_14 loc_13_14 up
2
25 0
391 0
1
0 0 57 44
1
end_operator
begin_operator
move loc_14_14 loc_14_13 left
2
38 0
392 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_14_16 loc_13_16 up
2
27 0
393 0
1
0 0 58 46
1
end_operator
begin_operator
move loc_14_16 loc_15_16 down
2
46 0
394 0
1
0 0 58 63
1
end_operator
begin_operator
move loc_14_5 loc_13_5 up
2
33 0
395 0
1
0 0 59 52
1
end_operator
begin_operator
move loc_14_5 loc_14_6 right
2
42 0
396 0
1
0 0 59 60
1
end_operator
begin_operator
move loc_14_5 loc_15_5 down
2
49 0
397 0
1
0 0 59 65
1
end_operator
begin_operator
move loc_14_6 loc_13_6 up
2
34 0
398 0
1
0 0 60 53
1
end_operator
begin_operator
move loc_14_6 loc_14_5 left
2
41 0
399 0
1
0 0 60 59
1
end_operator
begin_operator
move loc_14_6 loc_15_6 down
2
50 0
400 0
1
0 0 60 66
1
end_operator
begin_operator
move loc_15_11 loc_16_11 down
2
53 0
402 0
1
0 0 61 69
1
end_operator
begin_operator
move loc_15_15 loc_15_16 right
2
46 0
403 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_15_15 loc_16_15 down
2
57 0
404 0
1
0 0 62 73
1
end_operator
begin_operator
move loc_15_16 loc_14_16 up
2
40 0
405 0
1
0 0 63 58
1
end_operator
begin_operator
move loc_15_16 loc_15_15 left
2
45 0
406 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_15_16 loc_16_16 down
2
58 0
407 0
1
0 0 63 74
1
end_operator
begin_operator
move loc_15_18 loc_16_18 down
2
60 0
408 0
1
0 0 64 76
1
end_operator
begin_operator
move loc_15_5 loc_14_5 up
2
41 0
409 0
1
0 0 65 59
1
end_operator
begin_operator
move loc_15_5 loc_15_6 right
2
50 0
410 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_15_5 loc_16_5 down
2
62 0
411 0
1
0 0 65 78
1
end_operator
begin_operator
move loc_15_6 loc_14_6 up
2
42 0
412 0
1
0 0 66 60
1
end_operator
begin_operator
move loc_15_6 loc_15_5 left
2
49 0
413 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_15_6 loc_16_6 down
2
63 0
414 0
1
0 0 66 79
1
end_operator
begin_operator
move loc_15_8 loc_16_8 down
2
65 0
415 0
1
0 0 67 81
1
end_operator
begin_operator
move loc_16_10 loc_16_11 right
2
53 0
416 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_16_10 loc_16_9 left
2
66 0
417 0
1
0 0 68 82
1
end_operator
begin_operator
move loc_16_11 loc_15_11 up
2
44 0
418 0
1
0 0 69 61
1
end_operator
begin_operator
move loc_16_11 loc_16_10 left
2
52 0
419 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_16_11 loc_16_12 right
2
54 0
420 0
1
0 0 69 70
1
end_operator
begin_operator
move loc_16_12 loc_16_11 left
2
53 0
421 0
1
0 0 70 69
1
end_operator
begin_operator
move loc_16_12 loc_16_13 right
2
55 0
422 0
1
0 0 70 71
1
end_operator
begin_operator
move loc_16_12 loc_17_12 down
2
67 0
423 0
1
0 0 70 83
1
end_operator
begin_operator
move loc_16_13 loc_16_12 left
2
54 0
424 0
1
0 0 71 70
1
end_operator
begin_operator
move loc_16_13 loc_16_14 right
2
56 0
425 0
1
0 0 71 72
1
end_operator
begin_operator
move loc_16_14 loc_16_13 left
2
55 0
426 0
1
0 0 72 71
1
end_operator
begin_operator
move loc_16_14 loc_16_15 right
2
57 0
427 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_16_15 loc_15_15 up
2
45 0
428 0
1
0 0 73 62
1
end_operator
begin_operator
move loc_16_15 loc_16_14 left
2
56 0
429 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_16_15 loc_16_16 right
2
58 0
430 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_16_15 loc_17_15 down
2
68 0
431 0
1
0 0 73 84
1
end_operator
begin_operator
move loc_16_16 loc_15_16 up
2
46 0
432 0
1
0 0 74 63
1
end_operator
begin_operator
move loc_16_16 loc_16_15 left
2
57 0
433 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_16_16 loc_16_17 right
2
59 0
434 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_16_17 loc_16_16 left
2
58 0
435 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_16_17 loc_16_18 right
2
60 0
436 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_16_18 loc_15_18 up
2
47 0
437 0
1
0 0 76 64
1
end_operator
begin_operator
move loc_16_18 loc_16_17 left
2
59 0
438 0
1
0 0 76 75
1
end_operator
begin_operator
move loc_16_4 loc_16_5 right
2
62 0
439 0
1
0 0 77 78
1
end_operator
begin_operator
move loc_16_4 loc_17_4 down
2
71 0
440 0
1
0 0 77 86
1
end_operator
begin_operator
move loc_16_5 loc_15_5 up
2
49 0
441 0
1
0 0 78 65
1
end_operator
begin_operator
move loc_16_5 loc_16_4 left
2
61 0
442 0
1
0 0 78 77
1
end_operator
begin_operator
move loc_16_5 loc_16_6 right
2
63 0
443 0
1
0 0 78 79
1
end_operator
begin_operator
move loc_16_5 loc_17_5 down
2
72 0
444 0
1
0 0 78 87
1
end_operator
begin_operator
move loc_16_6 loc_15_6 up
2
50 0
445 0
1
0 0 79 66
1
end_operator
begin_operator
move loc_16_6 loc_16_5 left
2
62 0
446 0
1
0 0 79 78
1
end_operator
begin_operator
move loc_16_6 loc_16_7 right
2
64 0
447 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_16_6 loc_17_6 down
2
73 0
448 0
1
0 0 79 88
1
end_operator
begin_operator
move loc_16_7 loc_16_6 left
2
63 0
449 0
1
0 0 80 79
1
end_operator
begin_operator
move loc_16_7 loc_16_8 right
2
65 0
450 0
1
0 0 80 81
1
end_operator
begin_operator
move loc_16_7 loc_17_7 down
2
74 0
451 0
1
0 0 80 89
1
end_operator
begin_operator
move loc_16_8 loc_15_8 up
2
51 0
452 0
1
0 0 81 67
1
end_operator
begin_operator
move loc_16_8 loc_16_7 left
2
64 0
453 0
1
0 0 81 80
1
end_operator
begin_operator
move loc_16_8 loc_16_9 right
2
66 0
454 0
1
0 0 81 82
1
end_operator
begin_operator
move loc_16_8 loc_17_8 down
2
75 0
455 0
1
0 0 81 90
1
end_operator
begin_operator
move loc_16_9 loc_16_10 right
2
52 0
456 0
1
0 0 82 68
1
end_operator
begin_operator
move loc_16_9 loc_16_8 left
2
65 0
457 0
1
0 0 82 81
1
end_operator
begin_operator
move loc_17_12 loc_16_12 up
2
54 0
458 0
1
0 0 83 70
1
end_operator
begin_operator
move loc_17_12 loc_18_12 down
2
77 0
459 0
1
0 0 83 91
1
end_operator
begin_operator
move loc_17_15 loc_16_15 up
2
57 0
460 0
1
0 0 84 73
1
end_operator
begin_operator
move loc_17_15 loc_18_15 down
2
79 0
461 0
1
0 0 84 93
1
end_operator
begin_operator
move loc_17_3 loc_17_4 right
2
71 0
463 0
1
0 0 85 86
1
end_operator
begin_operator
move loc_17_4 loc_16_4 up
2
61 0
464 0
1
0 0 86 77
1
end_operator
begin_operator
move loc_17_4 loc_17_3 left
2
70 0
465 0
1
0 0 86 85
1
end_operator
begin_operator
move loc_17_4 loc_17_5 right
2
72 0
466 0
1
0 0 86 87
1
end_operator
begin_operator
move loc_17_4 loc_18_4 down
2
82 0
467 0
1
0 0 86 94
1
end_operator
begin_operator
move loc_17_5 loc_16_5 up
2
62 0
468 0
1
0 0 87 78
1
end_operator
begin_operator
move loc_17_5 loc_17_4 left
2
71 0
469 0
1
0 0 87 86
1
end_operator
begin_operator
move loc_17_5 loc_17_6 right
2
73 0
470 0
1
0 0 87 88
1
end_operator
begin_operator
move loc_17_6 loc_16_6 up
2
63 0
471 0
1
0 0 88 79
1
end_operator
begin_operator
move loc_17_6 loc_17_5 left
2
72 0
472 0
1
0 0 88 87
1
end_operator
begin_operator
move loc_17_6 loc_17_7 right
2
74 0
473 0
1
0 0 88 89
1
end_operator
begin_operator
move loc_17_6 loc_18_6 down
2
83 0
474 0
1
0 0 88 95
1
end_operator
begin_operator
move loc_17_7 loc_16_7 up
2
64 0
475 0
1
0 0 89 80
1
end_operator
begin_operator
move loc_17_7 loc_17_6 left
2
73 0
476 0
1
0 0 89 88
1
end_operator
begin_operator
move loc_17_7 loc_17_8 right
2
75 0
477 0
1
0 0 89 90
1
end_operator
begin_operator
move loc_17_7 loc_18_7 down
2
84 0
478 0
1
0 0 89 96
1
end_operator
begin_operator
move loc_17_8 loc_16_8 up
2
65 0
479 0
1
0 0 90 81
1
end_operator
begin_operator
move loc_17_8 loc_17_7 left
2
74 0
480 0
1
0 0 90 89
1
end_operator
begin_operator
move loc_18_12 loc_17_12 up
2
67 0
482 0
1
0 0 91 83
1
end_operator
begin_operator
move loc_18_12 loc_19_12 down
2
87 0
483 0
1
0 0 91 98
1
end_operator
begin_operator
move loc_18_14 loc_18_15 right
2
79 0
484 0
1
0 0 92 93
1
end_operator
begin_operator
move loc_18_15 loc_17_15 up
2
68 0
485 0
1
0 0 93 84
1
end_operator
begin_operator
move loc_18_15 loc_18_14 left
2
78 0
486 0
1
0 0 93 92
1
end_operator
begin_operator
move loc_18_15 loc_19_15 down
2
88 0
487 0
1
0 0 93 99
1
end_operator
begin_operator
move loc_18_4 loc_17_4 up
2
71 0
492 0
1
0 0 94 86
1
end_operator
begin_operator
move loc_18_4 loc_19_4 down
2
93 0
493 0
1
0 0 94 103
1
end_operator
begin_operator
move loc_18_6 loc_17_6 up
2
73 0
494 0
1
0 0 95 88
1
end_operator
begin_operator
move loc_18_6 loc_18_7 right
2
84 0
495 0
1
0 0 95 96
1
end_operator
begin_operator
move loc_18_6 loc_19_6 down
2
94 0
496 0
1
0 0 95 104
1
end_operator
begin_operator
move loc_18_7 loc_17_7 up
2
74 0
497 0
1
0 0 96 89
1
end_operator
begin_operator
move loc_18_7 loc_18_6 left
2
83 0
498 0
1
0 0 96 95
1
end_operator
begin_operator
move loc_19_11 loc_19_12 right
2
87 0
500 0
1
0 0 97 98
1
end_operator
begin_operator
move loc_19_12 loc_18_12 up
2
77 0
501 0
1
0 0 98 91
1
end_operator
begin_operator
move loc_19_12 loc_19_11 left
2
86 0
502 0
1
0 0 98 97
1
end_operator
begin_operator
move loc_19_15 loc_18_15 up
2
79 0
503 0
1
0 0 99 93
1
end_operator
begin_operator
move loc_19_15 loc_19_16 right
2
89 0
504 0
1
0 0 99 100
1
end_operator
begin_operator
move loc_19_16 loc_19_15 left
2
88 0
505 0
1
0 0 100 99
1
end_operator
begin_operator
move loc_19_2 loc_19_3 right
2
92 0
507 0
1
0 0 101 102
1
end_operator
begin_operator
move loc_19_3 loc_19_2 left
2
91 0
508 0
1
0 0 102 101
1
end_operator
begin_operator
move loc_19_3 loc_19_4 right
2
93 0
509 0
1
0 0 102 103
1
end_operator
begin_operator
move loc_19_4 loc_18_4 up
2
82 0
510 0
1
0 0 103 94
1
end_operator
begin_operator
move loc_19_4 loc_19_3 left
2
92 0
511 0
1
0 0 103 102
1
end_operator
begin_operator
move loc_19_6 loc_18_6 up
2
83 0
512 0
1
0 0 104 95
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
102 0
516 0
1
0 0 105 106
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
110 0
517 0
1
0 0 105 109
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
101 0
518 0
1
0 0 106 105
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
111 0
519 0
1
0 0 106 110
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
113 0
520 0
1
0 0 107 112
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
110 0
529 0
1
0 0 108 109
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
101 0
530 0
1
0 0 109 105
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
109 0
531 0
1
0 0 109 108
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
111 0
532 0
1
0 0 109 110
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
118 0
533 0
1
0 0 109 114
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
102 0
534 0
1
0 0 110 106
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
110 0
535 0
1
0 0 110 109
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
112 0
536 0
1
0 0 110 111
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
119 0
537 0
1
0 0 110 115
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
111 0
538 0
1
0 0 111 110
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
113 0
539 0
1
0 0 111 112
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
120 0
540 0
1
0 0 111 116
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
103 0
541 0
1
0 0 112 107
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
112 0
542 0
1
0 0 112 111
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
114 0
543 0
1
0 0 112 113
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
121 0
544 0
1
0 0 112 117
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
113 0
545 0
1
0 0 113 112
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
122 0
546 0
1
0 0 113 118
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
110 0
550 0
1
0 0 114 109
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
119 0
551 0
1
0 0 114 115
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
132 0
552 0
1
0 0 114 124
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
111 0
553 0
1
0 0 115 110
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
118 0
554 0
1
0 0 115 114
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
120 0
555 0
1
0 0 115 116
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
133 0
556 0
1
0 0 115 125
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
112 0
557 0
1
0 0 116 111
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
119 0
558 0
1
0 0 116 115
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
121 0
559 0
1
0 0 116 117
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
134 0
560 0
1
0 0 116 126
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
113 0
561 0
1
0 0 117 112
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
120 0
562 0
1
0 0 117 116
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
122 0
563 0
1
0 0 117 118
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
135 0
564 0
1
0 0 117 127
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
114 0
565 0
1
0 0 118 113
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
121 0
566 0
1
0 0 118 117
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
123 0
567 0
1
0 0 118 119
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
136 0
568 0
1
0 0 118 128
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
122 0
569 0
1
0 0 119 118
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
124 0
570 0
1
0 0 119 120
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
123 0
571 0
1
0 0 120 119
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
126 0
572 0
1
0 0 121 122
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
137 0
573 0
1
0 0 121 129
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
125 0
574 0
1
0 0 122 121
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
132 0
581 0
1
0 0 123 124
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
142 0
582 0
1
0 0 123 131
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
118 0
583 0
1
0 0 124 114
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
131 0
584 0
1
0 0 124 123
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
133 0
585 0
1
0 0 124 125
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
143 0
586 0
1
0 0 124 132
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
119 0
587 0
1
0 0 125 115
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
132 0
588 0
1
0 0 125 124
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
134 0
589 0
1
0 0 125 126
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
144 0
590 0
1
0 0 125 133
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
120 0
591 0
1
0 0 126 116
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
133 0
592 0
1
0 0 126 125
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
135 0
593 0
1
0 0 126 127
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
121 0
594 0
1
0 0 127 117
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
134 0
595 0
1
0 0 127 126
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
136 0
596 0
1
0 0 127 128
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
145 0
597 0
1
0 0 127 134
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
122 0
598 0
1
0 0 128 118
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
135 0
599 0
1
0 0 128 127
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
146 0
600 0
1
0 0 128 135
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
125 0
601 0
1
0 0 129 121
1
end_operator
begin_operator
move loc_6_10 loc_6_9 left
2
148 0
602 0
1
0 0 129 137
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
149 0
603 0
1
0 0 129 138
1
end_operator
begin_operator
move loc_6_12 loc_7_12 down
2
151 0
604 0
1
0 0 130 140
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
131 0
612 0
1
0 0 131 123
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
143 0
613 0
1
0 0 131 132
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
154 0
614 0
1
0 0 131 142
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
132 0
615 0
1
0 0 132 124
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
142 0
616 0
1
0 0 132 131
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
144 0
617 0
1
0 0 132 133
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
155 0
618 0
1
0 0 132 143
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
133 0
619 0
1
0 0 133 125
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
143 0
620 0
1
0 0 133 132
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
156 0
621 0
1
0 0 133 144
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
135 0
622 0
1
0 0 134 127
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
146 0
623 0
1
0 0 134 135
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
136 0
624 0
1
0 0 135 128
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
145 0
625 0
1
0 0 135 134
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
147 0
626 0
1
0 0 135 136
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
157 0
627 0
1
0 0 135 145
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
146 0
628 0
1
0 0 136 135
1
end_operator
begin_operator
move loc_6_8 loc_6_9 right
2
148 0
629 0
1
0 0 136 137
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
158 0
630 0
1
0 0 136 146
1
end_operator
begin_operator
move loc_6_9 loc_6_10 right
2
137 0
631 0
1
0 0 137 129
1
end_operator
begin_operator
move loc_6_9 loc_6_8 left
2
147 0
632 0
1
0 0 137 136
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
159 0
633 0
1
0 0 137 147
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
137 0
634 0
1
0 0 138 129
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
150 0
635 0
1
0 0 138 139
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
159 0
636 0
1
0 0 138 147
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
160 0
637 0
1
0 0 138 148
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
149 0
638 0
1
0 0 139 138
1
end_operator
begin_operator
move loc_7_11 loc_7_12 right
2
151 0
639 0
1
0 0 139 140
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
161 0
640 0
1
0 0 139 149
1
end_operator
begin_operator
move loc_7_12 loc_6_12 up
2
138 0
641 0
1
0 0 140 130
1
end_operator
begin_operator
move loc_7_12 loc_7_11 left
2
150 0
642 0
1
0 0 140 139
1
end_operator
begin_operator
move loc_7_12 loc_8_12 down
2
162 0
643 0
1
0 0 140 150
1
end_operator
begin_operator
move loc_7_15 loc_8_15 down
2
164 0
644 0
1
0 0 141 152
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
142 0
646 0
1
0 0 142 131
1
end_operator
begin_operator
move loc_7_2 loc_7_3 right
2
155 0
647 0
1
0 0 142 143
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
167 0
648 0
1
0 0 142 155
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
143 0
649 0
1
0 0 143 132
1
end_operator
begin_operator
move loc_7_3 loc_7_2 left
2
154 0
650 0
1
0 0 143 142
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
156 0
651 0
1
0 0 143 144
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
168 0
652 0
1
0 0 143 156
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
144 0
653 0
1
0 0 144 133
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
155 0
654 0
1
0 0 144 143
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
169 0
655 0
1
0 0 144 157
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
146 0
656 0
1
0 0 145 135
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
158 0
657 0
1
0 0 145 146
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
170 0
658 0
1
0 0 145 158
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
147 0
659 0
1
0 0 146 136
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
157 0
660 0
1
0 0 146 145
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
159 0
661 0
1
0 0 146 147
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
171 0
662 0
1
0 0 146 159
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
148 0
663 0
1
0 0 147 137
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
149 0
664 0
1
0 0 147 138
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
158 0
665 0
1
0 0 147 146
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
172 0
666 0
1
0 0 147 160
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
149 0
667 0
1
0 0 148 138
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
161 0
668 0
1
0 0 148 149
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
172 0
669 0
1
0 0 148 160
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
173 0
670 0
1
0 0 148 161
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
150 0
671 0
1
0 0 149 139
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
160 0
672 0
1
0 0 149 148
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
162 0
673 0
1
0 0 149 150
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
174 0
674 0
1
0 0 149 162
1
end_operator
begin_operator
move loc_8_12 loc_7_12 up
2
151 0
675 0
1
0 0 150 140
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
161 0
676 0
1
0 0 150 149
1
end_operator
begin_operator
move loc_8_12 loc_8_13 right
2
163 0
677 0
1
0 0 150 151
1
end_operator
begin_operator
move loc_8_13 loc_8_12 left
2
162 0
678 0
1
0 0 151 150
1
end_operator
begin_operator
move loc_8_13 loc_9_13 down
2
175 0
679 0
1
0 0 151 163
1
end_operator
begin_operator
move loc_8_15 loc_7_15 up
2
152 0
680 0
1
0 0 152 141
1
end_operator
begin_operator
move loc_8_15 loc_8_16 right
2
165 0
681 0
1
0 0 152 153
1
end_operator
begin_operator
move loc_8_15 loc_9_15 down
2
176 0
682 0
1
0 0 152 164
1
end_operator
begin_operator
move loc_8_16 loc_8_15 left
2
164 0
683 0
1
0 0 153 152
1
end_operator
begin_operator
move loc_8_16 loc_8_17 right
2
166 0
684 0
1
0 0 153 154
1
end_operator
begin_operator
move loc_8_16 loc_9_16 down
2
177 0
685 0
1
0 0 153 165
1
end_operator
begin_operator
move loc_8_17 loc_8_16 left
2
165 0
686 0
1
0 0 154 153
1
end_operator
begin_operator
move loc_8_17 loc_9_17 down
2
178 0
687 0
1
0 0 154 166
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
154 0
688 0
1
0 0 155 142
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
168 0
689 0
1
0 0 155 156
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
155 0
690 0
1
0 0 156 143
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
167 0
691 0
1
0 0 156 155
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
169 0
692 0
1
0 0 156 157
1
end_operator
begin_operator
move loc_8_3 loc_9_3 down
2
180 0
693 0
1
0 0 156 168
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
156 0
694 0
1
0 0 157 144
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
168 0
695 0
1
0 0 157 156
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
181 0
696 0
1
0 0 157 169
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
157 0
697 0
1
0 0 158 145
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
171 0
698 0
1
0 0 158 159
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
184 0
699 0
1
0 0 158 172
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
158 0
700 0
1
0 0 159 146
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
170 0
701 0
1
0 0 159 158
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
172 0
702 0
1
0 0 159 160
1
end_operator
begin_operator
move loc_8_8 loc_9_8 down
2
185 0
703 0
1
0 0 159 173
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
159 0
704 0
1
0 0 160 147
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
160 0
705 0
1
0 0 160 148
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
171 0
706 0
1
0 0 160 159
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
186 0
707 0
1
0 0 160 174
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
187 0
708 0
1
0 0 161 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
160 0
709 0
1
0 0 161 148
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
174 0
710 0
1
0 0 161 162
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
186 0
711 0
1
0 0 161 174
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
188 0
712 0
1
0 0 162 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
161 0
713 0
1
0 0 162 149
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
173 0
714 0
1
0 0 162 161
1
end_operator
begin_operator
move loc_9_13 loc_10_13 down
2
190 0
715 0
1
0 0 163 3
1
end_operator
begin_operator
move loc_9_13 loc_8_13 up
2
163 0
716 0
1
0 0 163 151
1
end_operator
begin_operator
move loc_9_15 loc_10_15 down
2
192 0
717 0
1
0 0 164 5
1
end_operator
begin_operator
move loc_9_15 loc_8_15 up
2
164 0
718 0
1
0 0 164 152
1
end_operator
begin_operator
move loc_9_15 loc_9_16 right
2
177 0
719 0
1
0 0 164 165
1
end_operator
begin_operator
move loc_9_16 loc_10_16 down
2
193 0
720 0
1
0 0 165 6
1
end_operator
begin_operator
move loc_9_16 loc_8_16 up
2
165 0
721 0
1
0 0 165 153
1
end_operator
begin_operator
move loc_9_16 loc_9_15 left
2
176 0
722 0
1
0 0 165 164
1
end_operator
begin_operator
move loc_9_16 loc_9_17 right
2
178 0
723 0
1
0 0 165 166
1
end_operator
begin_operator
move loc_9_17 loc_10_17 down
2
194 0
724 0
1
0 0 166 7
1
end_operator
begin_operator
move loc_9_17 loc_8_17 up
2
166 0
725 0
1
0 0 166 154
1
end_operator
begin_operator
move loc_9_17 loc_9_16 left
2
177 0
726 0
1
0 0 166 165
1
end_operator
begin_operator
move loc_9_19 loc_10_19 down
2
196 0
727 0
1
0 0 167 9
1
end_operator
begin_operator
move loc_9_3 loc_10_3 down
2
198 0
728 0
1
0 0 168 11
1
end_operator
begin_operator
move loc_9_3 loc_8_3 up
2
168 0
729 0
1
0 0 168 156
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
181 0
730 0
1
0 0 168 169
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
199 0
731 0
1
0 0 169 12
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
169 0
732 0
1
0 0 169 157
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
180 0
733 0
1
0 0 169 168
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
182 0
734 0
1
0 0 169 170
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
200 0
735 0
1
0 0 170 13
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
181 0
736 0
1
0 0 170 169
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
183 0
737 0
1
0 0 170 171
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
201 0
738 0
1
0 0 171 14
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
182 0
739 0
1
0 0 171 170
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
184 0
740 0
1
0 0 171 172
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
202 0
741 0
1
0 0 172 15
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
170 0
742 0
1
0 0 172 158
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
183 0
743 0
1
0 0 172 171
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
185 0
744 0
1
0 0 172 173
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
203 0
745 0
1
0 0 173 16
1
end_operator
begin_operator
move loc_9_8 loc_8_8 up
2
171 0
746 0
1
0 0 173 159
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
184 0
747 0
1
0 0 173 172
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
186 0
748 0
1
0 0 173 174
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
204 0
749 0
1
0 0 174 17
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
172 0
750 0
1
0 0 174 160
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
173 0
751 0
1
0 0 174 161
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
185 0
752 0
1
0 0 174 173
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box1
2
213 0
218 0
4
0 0 0 1
0 1 1 2
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box2
2
213 0
218 0
4
0 0 0 1
0 4 1 2
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box3
2
213 0
218 0
4
0 0 0 1
0 2 1 2
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box4
2
213 0
218 0
4
0 0 0 1
0 5 1 2
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box5
2
213 0
218 0
4
0 0 0 1
0 3 1 2
0 188 -1 0
0 189 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box1
2
214 0
273 0
4
0 0 0 17
0 1 17 16
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box2
2
214 0
273 0
4
0 0 0 17
0 4 17 16
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box3
2
214 0
273 0
4
0 0 0 17
0 2 17 16
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box4
2
214 0
273 0
4
0 0 0 17
0 5 17 16
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box5
2
214 0
273 0
4
0 0 0 17
0 3 17 16
0 203 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
216 0
709 0
4
0 0 0 161
0 1 146 134
0 160 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
216 0
709 0
4
0 0 0 161
0 4 146 134
0 160 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
216 0
709 0
4
0 0 0 161
0 2 146 134
0 160 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
216 0
709 0
4
0 0 0 161
0 5 146 134
0 160 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box5
2
216 0
709 0
4
0 0 0 161
0 3 146 134
0 160 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box1
2
214 0
217 0
4
0 0 1 0
0 1 0 17
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box2
2
214 0
217 0
4
0 0 1 0
0 4 0 17
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box3
2
214 0
217 0
4
0 0 1 0
0 2 0 17
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box4
2
214 0
217 0
4
0 0 1 0
0 5 0 17
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box5
2
214 0
217 0
4
0 0 1 0
0 3 0 17
0 187 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box1
2
218 0
222 0
4
0 0 1 2
0 1 2 3
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box2
2
218 0
222 0
4
0 0 1 2
0 4 2 3
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box3
2
218 0
222 0
4
0 0 1 2
0 2 2 3
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box4
2
218 0
222 0
4
0 0 1 2
0 5 2 3
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box5
2
218 0
222 0
4
0 0 1 2
0 3 2 3
0 189 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
220 0
713 0
4
0 0 1 162
0 1 147 135
0 161 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
220 0
713 0
4
0 0 1 162
0 4 147 135
0 161 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
220 0
713 0
4
0 0 1 162
0 2 147 135
0 161 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box4
2
220 0
713 0
4
0 0 1 162
0 5 147 135
0 161 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box5
2
220 0
713 0
4
0 0 1 162
0 3 147 135
0 161 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box1
2
217 0
221 0
4
0 0 2 1
0 1 1 0
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box2
2
217 0
221 0
4
0 0 2 1
0 4 1 0
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box3
2
217 0
221 0
4
0 0 2 1
0 2 1 0
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box4
2
217 0
221 0
4
0 0 2 1
0 5 1 0
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box5
2
217 0
221 0
4
0 0 2 1
0 3 1 0
0 187 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box1
2
222 0
224 0
4
0 0 2 3
0 1 3 4
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box2
2
222 0
224 0
4
0 0 2 3
0 4 3 4
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box3
2
222 0
224 0
4
0 0 2 3
0 2 3 4
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box4
2
222 0
224 0
4
0 0 2 3
0 5 3 4
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box5
2
222 0
224 0
4
0 0 2 3
0 3 3 4
0 190 -1 0
0 191 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box1
2
221 0
223 0
4
0 0 3 2
0 1 2 1
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box2
2
221 0
223 0
4
0 0 3 2
0 4 2 1
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box3
2
221 0
223 0
4
0 0 3 2
0 2 2 1
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box4
2
221 0
223 0
4
0 0 3 2
0 5 2 1
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box5
2
221 0
223 0
4
0 0 3 2
0 3 2 1
0 188 0 1
0 189 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box1
2
224 0
228 0
4
0 0 3 4
0 1 4 5
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box2
2
224 0
228 0
4
0 0 3 4
0 4 4 5
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box3
2
224 0
228 0
4
0 0 3 4
0 2 4 5
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box4
2
224 0
228 0
4
0 0 3 4
0 5 4 5
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box5
2
224 0
228 0
4
0 0 3 4
0 3 4 5
0 191 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_10_13 loc_11_13 loc_12_13 down box1
2
225 0
281 0
4
0 0 3 20
0 1 20 31
0 12 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_11_13 loc_12_13 down box2
2
225 0
281 0
4
0 0 3 20
0 4 20 31
0 12 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_11_13 loc_12_13 down box3
2
225 0
281 0
4
0 0 3 20
0 2 20 31
0 12 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_11_13 loc_12_13 down box4
2
225 0
281 0
4
0 0 3 20
0 5 20 31
0 12 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_11_13 loc_12_13 down box5
2
225 0
281 0
4
0 0 3 20
0 3 20 31
0 12 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box1
2
226 0
716 0
4
0 0 3 163
0 1 148 137
0 163 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box2
2
226 0
716 0
4
0 0 3 163
0 4 148 137
0 163 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box3
2
226 0
716 0
4
0 0 3 163
0 2 148 137
0 163 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box4
2
226 0
716 0
4
0 0 3 163
0 5 148 137
0 163 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box5
2
226 0
716 0
4
0 0 3 163
0 3 148 137
0 163 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box1
2
223 0
227 0
4
0 0 4 3
0 1 3 2
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box2
2
223 0
227 0
4
0 0 4 3
0 4 3 2
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box3
2
223 0
227 0
4
0 0 4 3
0 2 3 2
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box4
2
223 0
227 0
4
0 0 4 3
0 5 3 2
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box5
2
223 0
227 0
4
0 0 4 3
0 3 3 2
0 189 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box1
2
228 0
231 0
4
0 0 4 5
0 1 5 6
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box2
2
228 0
231 0
4
0 0 4 5
0 4 5 6
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box3
2
228 0
231 0
4
0 0 4 5
0 2 5 6
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box4
2
228 0
231 0
4
0 0 4 5
0 5 5 6
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box5
2
228 0
231 0
4
0 0 4 5
0 3 5 6
0 192 -1 0
0 193 0 1
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box1
2
229 0
285 0
4
0 0 4 21
0 1 21 32
0 13 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box2
2
229 0
285 0
4
0 0 4 21
0 4 21 32
0 13 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box3
2
229 0
285 0
4
0 0 4 21
0 2 21 32
0 13 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box4
2
229 0
285 0
4
0 0 4 21
0 5 21 32
0 13 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_11_14 loc_12_14 down box5
2
229 0
285 0
4
0 0 4 21
0 3 21 32
0 13 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box1
2
227 0
230 0
4
0 0 5 4
0 1 4 3
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box2
2
227 0
230 0
4
0 0 5 4
0 4 4 3
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box3
2
227 0
230 0
4
0 0 5 4
0 2 4 3
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box4
2
227 0
230 0
4
0 0 5 4
0 5 4 3
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box5
2
227 0
230 0
4
0 0 5 4
0 3 4 3
0 190 0 1
0 191 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box1
2
231 0
235 0
4
0 0 5 6
0 1 6 7
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box2
2
231 0
235 0
4
0 0 5 6
0 4 6 7
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box3
2
231 0
235 0
4
0 0 5 6
0 2 6 7
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box4
2
231 0
235 0
4
0 0 5 6
0 5 6 7
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box5
2
231 0
235 0
4
0 0 5 6
0 3 6 7
0 193 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box1
2
232 0
288 0
4
0 0 5 22
0 1 22 33
0 14 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box2
2
232 0
288 0
4
0 0 5 22
0 4 22 33
0 14 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box3
2
232 0
288 0
4
0 0 5 22
0 2 22 33
0 14 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box4
2
232 0
288 0
4
0 0 5 22
0 5 22 33
0 14 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_11_15 loc_12_15 down box5
2
232 0
288 0
4
0 0 5 22
0 3 22 33
0 14 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box1
2
233 0
718 0
4
0 0 5 164
0 1 149 138
0 164 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box2
2
233 0
718 0
4
0 0 5 164
0 4 149 138
0 164 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box3
2
233 0
718 0
4
0 0 5 164
0 2 149 138
0 164 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box4
2
233 0
718 0
4
0 0 5 164
0 5 149 138
0 164 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_9_15 loc_8_15 up box5
2
233 0
718 0
4
0 0 5 164
0 3 149 138
0 164 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box1
2
230 0
234 0
4
0 0 6 5
0 1 5 4
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box2
2
230 0
234 0
4
0 0 6 5
0 4 5 4
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box3
2
230 0
234 0
4
0 0 6 5
0 2 5 4
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box4
2
230 0
234 0
4
0 0 6 5
0 5 5 4
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box5
2
230 0
234 0
4
0 0 6 5
0 3 5 4
0 191 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box1
2
235 0
238 0
4
0 0 6 7
0 1 7 8
0 194 -1 0
0 195 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box2
2
235 0
238 0
4
0 0 6 7
0 4 7 8
0 194 -1 0
0 195 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box3
2
235 0
238 0
4
0 0 6 7
0 2 7 8
0 194 -1 0
0 195 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box4
2
235 0
238 0
4
0 0 6 7
0 5 7 8
0 194 -1 0
0 195 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box5
2
235 0
238 0
4
0 0 6 7
0 3 7 8
0 194 -1 0
0 195 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box1
2
234 0
237 0
4
0 0 7 6
0 1 6 5
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box2
2
234 0
237 0
4
0 0 7 6
0 4 6 5
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box3
2
234 0
237 0
4
0 0 7 6
0 2 6 5
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box4
2
234 0
237 0
4
0 0 7 6
0 5 6 5
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box5
2
234 0
237 0
4
0 0 7 6
0 3 6 5
0 192 0 1
0 193 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box1
2
238 0
242 0
4
0 0 7 8
0 1 8 9
0 195 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box2
2
238 0
242 0
4
0 0 7 8
0 4 8 9
0 195 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box3
2
238 0
242 0
4
0 0 7 8
0 2 8 9
0 195 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box4
2
238 0
242 0
4
0 0 7 8
0 5 8 9
0 195 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box5
2
238 0
242 0
4
0 0 7 8
0 3 8 9
0 195 -1 0
0 196 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box1
2
239 0
291 0
4
0 0 7 23
0 1 23 35
0 16 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box2
2
239 0
291 0
4
0 0 7 23
0 4 23 35
0 16 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box3
2
239 0
291 0
4
0 0 7 23
0 2 23 35
0 16 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box4
2
239 0
291 0
4
0 0 7 23
0 5 23 35
0 16 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box5
2
239 0
291 0
4
0 0 7 23
0 3 23 35
0 16 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box1
2
240 0
725 0
4
0 0 7 166
0 1 150 139
0 166 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box2
2
240 0
725 0
4
0 0 7 166
0 4 150 139
0 166 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box3
2
240 0
725 0
4
0 0 7 166
0 2 150 139
0 166 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box4
2
240 0
725 0
4
0 0 7 166
0 5 150 139
0 166 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box5
2
240 0
725 0
4
0 0 7 166
0 3 150 139
0 166 0 1
0 178 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box1
2
237 0
241 0
4
0 0 8 7
0 1 7 6
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box2
2
237 0
241 0
4
0 0 8 7
0 4 7 6
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box3
2
237 0
241 0
4
0 0 8 7
0 2 7 6
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box4
2
237 0
241 0
4
0 0 8 7
0 5 7 6
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box5
2
237 0
241 0
4
0 0 8 7
0 3 7 6
0 193 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box1
2
243 0
295 0
4
0 0 8 24
0 1 24 36
0 17 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box2
2
243 0
295 0
4
0 0 8 24
0 4 24 36
0 17 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box3
2
243 0
295 0
4
0 0 8 24
0 2 24 36
0 17 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box4
2
243 0
295 0
4
0 0 8 24
0 5 24 36
0 17 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box5
2
243 0
295 0
4
0 0 8 24
0 3 24 36
0 17 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box1
2
241 0
244 0
4
0 0 9 8
0 1 8 7
0 194 0 1
0 195 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box2
2
241 0
244 0
4
0 0 9 8
0 4 8 7
0 194 0 1
0 195 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box3
2
241 0
244 0
4
0 0 9 8
0 2 8 7
0 194 0 1
0 195 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box4
2
241 0
244 0
4
0 0 9 8
0 5 8 7
0 194 0 1
0 195 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box5
2
241 0
244 0
4
0 0 9 8
0 3 8 7
0 194 0 1
0 195 -1 0
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box1
2
247 0
250 0
4
0 0 10 11
0 1 11 12
0 198 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box2
2
247 0
250 0
4
0 0 10 11
0 4 11 12
0 198 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box3
2
247 0
250 0
4
0 0 10 11
0 2 11 12
0 198 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box4
2
247 0
250 0
4
0 0 10 11
0 5 11 12
0 198 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box5
2
247 0
250 0
4
0 0 10 11
0 3 11 12
0 198 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
250 0
254 0
4
0 0 11 12
0 1 12 13
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
250 0
254 0
4
0 0 11 12
0 4 12 13
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
250 0
254 0
4
0 0 11 12
0 2 12 13
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box4
2
250 0
254 0
4
0 0 11 12
0 5 12 13
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box5
2
250 0
254 0
4
0 0 11 12
0 3 12 13
0 199 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box1
2
251 0
302 0
4
0 0 11 27
0 1 26 37
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box2
2
251 0
302 0
4
0 0 11 27
0 4 26 37
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box3
2
251 0
302 0
4
0 0 11 27
0 2 26 37
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box4
2
251 0
302 0
4
0 0 11 27
0 5 26 37
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box5
2
251 0
302 0
4
0 0 11 27
0 3 26 37
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box1
2
252 0
729 0
4
0 0 11 168
0 1 152 141
0 168 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box2
2
252 0
729 0
4
0 0 11 168
0 4 152 141
0 168 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box3
2
252 0
729 0
4
0 0 11 168
0 2 152 141
0 168 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box4
2
252 0
729 0
4
0 0 11 168
0 5 152 141
0 168 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box5
2
252 0
729 0
4
0 0 11 168
0 3 152 141
0 168 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box1
2
249 0
253 0
4
0 0 12 11
0 1 11 10
0 197 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box2
2
249 0
253 0
4
0 0 12 11
0 4 11 10
0 197 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box3
2
249 0
253 0
4
0 0 12 11
0 2 11 10
0 197 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box4
2
249 0
253 0
4
0 0 12 11
0 5 11 10
0 197 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box5
2
249 0
253 0
4
0 0 12 11
0 3 11 10
0 197 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
254 0
257 0
4
0 0 12 13
0 1 13 14
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
254 0
257 0
4
0 0 12 13
0 4 13 14
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
254 0
257 0
4
0 0 12 13
0 2 13 14
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box4
2
254 0
257 0
4
0 0 12 13
0 5 13 14
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box5
2
254 0
257 0
4
0 0 12 13
0 3 13 14
0 200 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box1
2
255 0
732 0
4
0 0 12 169
0 1 153 142
0 169 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box2
2
255 0
732 0
4
0 0 12 169
0 4 153 142
0 169 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box3
2
255 0
732 0
4
0 0 12 169
0 2 153 142
0 169 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box4
2
255 0
732 0
4
0 0 12 169
0 5 153 142
0 169 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box5
2
255 0
732 0
4
0 0 12 169
0 3 153 142
0 169 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
253 0
256 0
4
0 0 13 12
0 1 12 11
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
253 0
256 0
4
0 0 13 12
0 4 12 11
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
253 0
256 0
4
0 0 13 12
0 2 12 11
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box4
2
253 0
256 0
4
0 0 13 12
0 5 12 11
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box5
2
253 0
256 0
4
0 0 13 12
0 3 12 11
0 198 0 1
0 199 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
257 0
261 0
4
0 0 13 14
0 1 14 15
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
257 0
261 0
4
0 0 13 14
0 4 14 15
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
257 0
261 0
4
0 0 13 14
0 2 14 15
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box4
2
257 0
261 0
4
0 0 13 14
0 5 14 15
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box5
2
257 0
261 0
4
0 0 13 14
0 3 14 15
0 201 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box1
2
258 0
305 0
4
0 0 13 28
0 1 27 38
0 8 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box2
2
258 0
305 0
4
0 0 13 28
0 4 27 38
0 8 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box3
2
258 0
305 0
4
0 0 13 28
0 2 27 38
0 8 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box4
2
258 0
305 0
4
0 0 13 28
0 5 27 38
0 8 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box5
2
258 0
305 0
4
0 0 13 28
0 3 27 38
0 8 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
256 0
260 0
4
0 0 14 13
0 1 13 12
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
256 0
260 0
4
0 0 14 13
0 4 13 12
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
256 0
260 0
4
0 0 14 13
0 2 13 12
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box4
2
256 0
260 0
4
0 0 14 13
0 5 13 12
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box5
2
256 0
260 0
4
0 0 14 13
0 3 13 12
0 199 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
261 0
265 0
4
0 0 14 15
0 1 15 16
0 202 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
261 0
265 0
4
0 0 14 15
0 4 15 16
0 202 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
261 0
265 0
4
0 0 14 15
0 2 15 16
0 202 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box4
2
261 0
265 0
4
0 0 14 15
0 5 15 16
0 202 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box5
2
261 0
265 0
4
0 0 14 15
0 3 15 16
0 202 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box1
2
262 0
309 0
4
0 0 14 29
0 1 28 39
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box2
2
262 0
309 0
4
0 0 14 29
0 4 28 39
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box3
2
262 0
309 0
4
0 0 14 29
0 2 28 39
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box4
2
262 0
309 0
4
0 0 14 29
0 5 28 39
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box5
2
262 0
309 0
4
0 0 14 29
0 3 28 39
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
260 0
264 0
4
0 0 15 14
0 1 14 13
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
260 0
264 0
4
0 0 15 14
0 4 14 13
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
260 0
264 0
4
0 0 15 14
0 2 14 13
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box4
2
260 0
264 0
4
0 0 15 14
0 5 14 13
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box5
2
260 0
264 0
4
0 0 15 14
0 3 14 13
0 200 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box1
2
265 0
269 0
4
0 0 15 16
0 1 16 17
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box2
2
265 0
269 0
4
0 0 15 16
0 4 16 17
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box3
2
265 0
269 0
4
0 0 15 16
0 2 16 17
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box4
2
265 0
269 0
4
0 0 15 16
0 5 16 17
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box5
2
265 0
269 0
4
0 0 15 16
0 3 16 17
0 203 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
267 0
742 0
4
0 0 15 172
0 1 156 143
0 170 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
267 0
742 0
4
0 0 15 172
0 4 156 143
0 170 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
267 0
742 0
4
0 0 15 172
0 2 156 143
0 170 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box4
2
267 0
742 0
4
0 0 15 172
0 5 156 143
0 170 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box5
2
267 0
742 0
4
0 0 15 172
0 3 156 143
0 170 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
264 0
268 0
4
0 0 16 15
0 1 15 14
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
264 0
268 0
4
0 0 16 15
0 4 15 14
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
264 0
268 0
4
0 0 16 15
0 2 15 14
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box4
2
264 0
268 0
4
0 0 16 15
0 5 15 14
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box5
2
264 0
268 0
4
0 0 16 15
0 3 15 14
0 201 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box1
2
269 0
272 0
4
0 0 16 17
0 1 17 0
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box2
2
269 0
272 0
4
0 0 16 17
0 4 17 0
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box3
2
269 0
272 0
4
0 0 16 17
0 2 17 0
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box4
2
269 0
272 0
4
0 0 16 17
0 5 17 0
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box5
2
269 0
272 0
4
0 0 16 17
0 3 17 0
0 187 0 1
0 204 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box1
2
270 0
315 0
4
0 0 16 31
0 1 30 40
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box2
2
270 0
315 0
4
0 0 16 31
0 4 30 40
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box3
2
270 0
315 0
4
0 0 16 31
0 2 30 40
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box4
2
270 0
315 0
4
0 0 16 31
0 5 30 40
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box5
2
270 0
315 0
4
0 0 16 31
0 3 30 40
0 11 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box1
2
271 0
746 0
4
0 0 16 173
0 1 157 144
0 171 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box2
2
271 0
746 0
4
0 0 16 173
0 4 157 144
0 171 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box3
2
271 0
746 0
4
0 0 16 173
0 2 157 144
0 171 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box4
2
271 0
746 0
4
0 0 16 173
0 5 157 144
0 171 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box5
2
271 0
746 0
4
0 0 16 173
0 3 157 144
0 171 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box1
2
213 0
272 0
4
0 0 17 0
0 1 0 1
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box2
2
213 0
272 0
4
0 0 17 0
0 4 0 1
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box3
2
213 0
272 0
4
0 0 17 0
0 2 0 1
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box4
2
213 0
272 0
4
0 0 17 0
0 5 0 1
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box5
2
213 0
272 0
4
0 0 17 0
0 3 0 1
0 187 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box1
2
268 0
273 0
4
0 0 17 16
0 1 16 15
0 202 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box2
2
268 0
273 0
4
0 0 17 16
0 4 16 15
0 202 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box3
2
268 0
273 0
4
0 0 17 16
0 2 16 15
0 202 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box4
2
268 0
273 0
4
0 0 17 16
0 5 16 15
0 202 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box5
2
268 0
273 0
4
0 0 17 16
0 3 16 15
0 202 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box1
2
274 0
750 0
4
0 0 17 174
0 1 158 145
0 172 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box2
2
274 0
750 0
4
0 0 17 174
0 4 158 145
0 172 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box3
2
274 0
750 0
4
0 0 17 174
0 2 158 145
0 172 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box4
2
274 0
750 0
4
0 0 17 174
0 5 158 145
0 172 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box5
2
274 0
750 0
4
0 0 17 174
0 3 158 145
0 172 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box1
2
216 0
275 0
4
0 0 18 0
0 1 0 146
0 173 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box2
2
216 0
275 0
4
0 0 18 0
0 4 0 146
0 173 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box3
2
216 0
275 0
4
0 0 18 0
0 2 0 146
0 173 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box4
2
216 0
275 0
4
0 0 18 0
0 5 0 146
0 173 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box5
2
216 0
275 0
4
0 0 18 0
0 3 0 146
0 173 0 1
0 187 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box1
2
220 0
277 0
4
0 0 19 1
0 1 1 147
0 174 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box2
2
220 0
277 0
4
0 0 19 1
0 4 1 147
0 174 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box3
2
220 0
277 0
4
0 0 19 1
0 2 1 147
0 174 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box4
2
220 0
277 0
4
0 0 19 1
0 5 1 147
0 174 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box5
2
220 0
277 0
4
0 0 19 1
0 3 1 147
0 174 0 1
0 188 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_10_13 loc_9_13 up box1
2
226 0
279 0
4
0 0 20 3
0 1 3 148
0 175 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_10_13 loc_9_13 up box2
2
226 0
279 0
4
0 0 20 3
0 4 3 148
0 175 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_10_13 loc_9_13 up box3
2
226 0
279 0
4
0 0 20 3
0 2 3 148
0 175 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_10_13 loc_9_13 up box4
2
226 0
279 0
4
0 0 20 3
0 5 3 148
0 175 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_10_13 loc_9_13 up box5
2
226 0
279 0
4
0 0 20 3
0 3 3 148
0 175 0 1
0 190 -1 0
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box1
2
280 0
284 0
4
0 0 20 21
0 1 21 22
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box2
2
280 0
284 0
4
0 0 20 21
0 4 21 22
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box3
2
280 0
284 0
4
0 0 20 21
0 2 21 22
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box4
2
280 0
284 0
4
0 0 20 21
0 5 21 22
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_11_13 loc_11_14 loc_11_15 right box5
2
280 0
284 0
4
0 0 20 21
0 3 21 22
0 208 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box1
2
281 0
318 0
4
0 0 20 32
0 1 31 41
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box2
2
281 0
318 0
4
0 0 20 32
0 4 31 41
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box3
2
281 0
318 0
4
0 0 20 32
0 2 31 41
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box4
2
281 0
318 0
4
0 0 20 32
0 5 31 41
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_13 loc_12_13 loc_13_13 down box5
2
281 0
318 0
4
0 0 20 32
0 3 31 41
0 12 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box1
2
285 0
322 0
4
0 0 21 33
0 1 32 42
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box2
2
285 0
322 0
4
0 0 21 33
0 4 32 42
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box3
2
285 0
322 0
4
0 0 21 33
0 2 32 42
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box4
2
285 0
322 0
4
0 0 21 33
0 5 32 42
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_11_14 loc_12_14 loc_13_14 down box5
2
285 0
322 0
4
0 0 21 33
0 3 32 42
0 13 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box1
2
233 0
286 0
4
0 0 22 5
0 1 5 149
0 176 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box2
2
233 0
286 0
4
0 0 22 5
0 4 5 149
0 176 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box3
2
233 0
286 0
4
0 0 22 5
0 2 5 149
0 176 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box4
2
233 0
286 0
4
0 0 22 5
0 5 5 149
0 176 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_10_15 loc_9_15 up box5
2
233 0
286 0
4
0 0 22 5
0 3 5 149
0 176 0 1
0 192 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box1
2
283 0
287 0
4
0 0 22 21
0 1 21 20
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box2
2
283 0
287 0
4
0 0 22 21
0 4 21 20
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box3
2
283 0
287 0
4
0 0 22 21
0 2 21 20
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box4
2
283 0
287 0
4
0 0 22 21
0 5 21 20
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_11_14 loc_11_13 left box5
2
283 0
287 0
4
0 0 22 21
0 3 21 20
0 207 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box1
2
288 0
326 0
4
0 0 22 34
0 1 33 43
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box2
2
288 0
326 0
4
0 0 22 34
0 4 33 43
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box3
2
288 0
326 0
4
0 0 22 34
0 2 33 43
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box4
2
288 0
326 0
4
0 0 22 34
0 5 33 43
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_15 loc_12_15 loc_13_15 down box5
2
288 0
326 0
4
0 0 22 34
0 3 33 43
0 14 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box1
2
240 0
289 0
4
0 0 23 7
0 1 7 150
0 178 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box2
2
240 0
289 0
4
0 0 23 7
0 4 7 150
0 178 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box3
2
240 0
289 0
4
0 0 23 7
0 2 7 150
0 178 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box4
2
240 0
289 0
4
0 0 23 7
0 5 7 150
0 178 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box5
2
240 0
289 0
4
0 0 23 7
0 3 7 150
0 178 0 1
0 194 -1 0
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box1
2
290 0
294 0
4
0 0 23 24
0 1 24 25
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box2
2
290 0
294 0
4
0 0 23 24
0 4 24 25
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box3
2
290 0
294 0
4
0 0 23 24
0 2 24 25
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box4
2
290 0
294 0
4
0 0 23 24
0 5 24 25
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box5
2
290 0
294 0
4
0 0 23 24
0 3 24 25
0 211 -1 0
0 212 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box1
2
291 0
333 0
4
0 0 23 36
0 1 35 45
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box2
2
291 0
333 0
4
0 0 23 36
0 4 35 45
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box3
2
291 0
333 0
4
0 0 23 36
0 2 35 45
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box4
2
291 0
333 0
4
0 0 23 36
0 5 35 45
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box5
2
291 0
333 0
4
0 0 23 36
0 3 35 45
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box1
2
295 0
336 0
4
0 0 24 37
0 1 36 46
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box2
2
295 0
336 0
4
0 0 24 37
0 4 36 46
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box3
2
295 0
336 0
4
0 0 24 37
0 2 36 46
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box4
2
295 0
336 0
4
0 0 24 37
0 5 36 46
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box5
2
295 0
336 0
4
0 0 24 37
0 3 36 46
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box1
2
246 0
296 0
4
0 0 25 9
0 1 9 151
0 179 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box2
2
246 0
296 0
4
0 0 25 9
0 4 9 151
0 179 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box3
2
246 0
296 0
4
0 0 25 9
0 2 9 151
0 179 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box4
2
246 0
296 0
4
0 0 25 9
0 5 9 151
0 179 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box5
2
246 0
296 0
4
0 0 25 9
0 3 9 151
0 179 0 1
0 196 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box1
2
293 0
297 0
4
0 0 25 24
0 1 24 23
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box2
2
293 0
297 0
4
0 0 25 24
0 4 24 23
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box3
2
293 0
297 0
4
0 0 25 24
0 2 24 23
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box4
2
293 0
297 0
4
0 0 25 24
0 5 24 23
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box5
2
293 0
297 0
4
0 0 25 24
0 3 24 23
0 210 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box1
2
252 0
300 0
4
0 0 27 11
0 1 11 152
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box2
2
252 0
300 0
4
0 0 27 11
0 4 11 152
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box3
2
252 0
300 0
4
0 0 27 11
0 2 11 152
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box4
2
252 0
300 0
4
0 0 27 11
0 5 11 152
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box5
2
252 0
300 0
4
0 0 27 11
0 3 11 152
0 180 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_12_3 loc_13_3 down box1
2
302 0
338 0
4
0 0 27 38
0 1 37 48
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_11_3 loc_12_3 loc_13_3 down box2
2
302 0
338 0
4
0 0 27 38
0 4 37 48
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_11_3 loc_12_3 loc_13_3 down box3
2
302 0
338 0
4
0 0 27 38
0 2 37 48
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_11_3 loc_12_3 loc_13_3 down box4
2
302 0
338 0
4
0 0 27 38
0 5 37 48
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_11_3 loc_12_3 loc_13_3 down box5
2
302 0
338 0
4
0 0 27 38
0 3 37 48
0 18 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
259 0
303 0
4
0 0 28 13
0 1 13 154
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
259 0
303 0
4
0 0 28 13
0 4 13 154
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
259 0
303 0
4
0 0 28 13
0 2 13 154
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box4
2
259 0
303 0
4
0 0 28 13
0 5 13 154
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box5
2
259 0
303 0
4
0 0 28 13
0 3 13 154
0 182 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box1
2
304 0
308 0
4
0 0 28 29
0 1 28 29
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box2
2
304 0
308 0
4
0 0 28 29
0 4 28 29
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box3
2
304 0
308 0
4
0 0 28 29
0 2 28 29
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box4
2
304 0
308 0
4
0 0 28 29
0 5 28 29
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box5
2
304 0
308 0
4
0 0 28 29
0 3 28 29
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box1
2
305 0
341 0
4
0 0 28 39
0 1 38 50
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box2
2
305 0
341 0
4
0 0 28 39
0 4 38 50
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box3
2
305 0
341 0
4
0 0 28 39
0 2 38 50
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box4
2
305 0
341 0
4
0 0 28 39
0 5 38 50
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_11_5 loc_12_5 loc_13_5 down box5
2
305 0
341 0
4
0 0 28 39
0 3 38 50
0 19 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box1
2
263 0
306 0
4
0 0 29 14
0 1 14 155
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box2
2
263 0
306 0
4
0 0 29 14
0 4 14 155
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box3
2
263 0
306 0
4
0 0 29 14
0 2 14 155
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box4
2
263 0
306 0
4
0 0 29 14
0 5 14 155
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box5
2
263 0
306 0
4
0 0 29 14
0 3 14 155
0 183 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box1
2
308 0
312 0
4
0 0 29 30
0 1 29 30
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box2
2
308 0
312 0
4
0 0 29 30
0 4 29 30
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box3
2
308 0
312 0
4
0 0 29 30
0 2 29 30
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box4
2
308 0
312 0
4
0 0 29 30
0 5 29 30
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box5
2
308 0
312 0
4
0 0 29 30
0 3 29 30
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box1
2
309 0
344 0
4
0 0 29 40
0 1 39 51
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box2
2
309 0
344 0
4
0 0 29 40
0 4 39 51
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box3
2
309 0
344 0
4
0 0 29 40
0 2 39 51
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box4
2
309 0
344 0
4
0 0 29 40
0 5 39 51
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_11_6 loc_12_6 loc_13_6 down box5
2
309 0
344 0
4
0 0 29 40
0 3 39 51
0 20 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
267 0
310 0
4
0 0 30 15
0 1 15 156
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
267 0
310 0
4
0 0 30 15
0 4 15 156
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
267 0
310 0
4
0 0 30 15
0 2 15 156
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box4
2
267 0
310 0
4
0 0 30 15
0 5 15 156
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box5
2
267 0
310 0
4
0 0 30 15
0 3 15 156
0 184 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box1
2
307 0
311 0
4
0 0 30 29
0 1 28 27
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box2
2
307 0
311 0
4
0 0 30 29
0 4 28 27
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box3
2
307 0
311 0
4
0 0 30 29
0 2 28 27
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box4
2
307 0
311 0
4
0 0 30 29
0 5 28 27
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box5
2
307 0
311 0
4
0 0 30 29
0 3 28 27
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box1
2
271 0
313 0
4
0 0 31 16
0 1 16 157
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box2
2
271 0
313 0
4
0 0 31 16
0 4 16 157
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box3
2
271 0
313 0
4
0 0 31 16
0 2 16 157
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box4
2
271 0
313 0
4
0 0 31 16
0 5 16 157
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box5
2
271 0
313 0
4
0 0 31 16
0 3 16 157
0 185 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box1
2
311 0
314 0
4
0 0 31 30
0 1 29 28
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box2
2
311 0
314 0
4
0 0 31 30
0 4 29 28
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box3
2
311 0
314 0
4
0 0 31 30
0 2 29 28
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box4
2
311 0
314 0
4
0 0 31 30
0 5 29 28
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box5
2
311 0
314 0
4
0 0 31 30
0 3 29 28
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box1
2
315 0
347 0
4
0 0 31 41
0 1 40 53
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box2
2
315 0
347 0
4
0 0 31 41
0 4 40 53
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box3
2
315 0
347 0
4
0 0 31 41
0 2 40 53
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box4
2
315 0
347 0
4
0 0 31 41
0 5 40 53
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_11_8 loc_12_8 loc_13_8 down box5
2
315 0
347 0
4
0 0 31 41
0 3 40 53
0 21 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_13 loc_11_13 loc_10_13 up box1
2
279 0
316 0
4
0 0 32 20
0 1 20 3
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_11_13 loc_10_13 up box2
2
279 0
316 0
4
0 0 32 20
0 4 20 3
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_11_13 loc_10_13 up box3
2
279 0
316 0
4
0 0 32 20
0 2 20 3
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_11_13 loc_10_13 up box4
2
279 0
316 0
4
0 0 32 20
0 5 20 3
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_11_13 loc_10_13 up box5
2
279 0
316 0
4
0 0 32 20
0 3 20 3
0 190 0 1
0 207 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box1
2
317 0
321 0
4
0 0 32 33
0 1 32 33
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box2
2
317 0
321 0
4
0 0 32 33
0 4 32 33
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box3
2
317 0
321 0
4
0 0 32 33
0 2 32 33
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box4
2
317 0
321 0
4
0 0 32 33
0 5 32 33
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box5
2
317 0
321 0
4
0 0 32 33
0 3 32 33
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box1
2
318 0
352 0
4
0 0 32 43
0 1 41 54
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box2
2
318 0
352 0
4
0 0 32 43
0 4 41 54
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box3
2
318 0
352 0
4
0 0 32 43
0 2 41 54
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box4
2
318 0
352 0
4
0 0 32 43
0 5 41 54
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_13 loc_13_13 loc_14_13 down box5
2
318 0
352 0
4
0 0 32 43
0 3 41 54
0 24 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box1
2
282 0
319 0
4
0 0 33 21
0 1 21 4
0 191 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box2
2
282 0
319 0
4
0 0 33 21
0 4 21 4
0 191 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box3
2
282 0
319 0
4
0 0 33 21
0 2 21 4
0 191 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box4
2
282 0
319 0
4
0 0 33 21
0 5 21 4
0 191 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_11_14 loc_10_14 up box5
2
282 0
319 0
4
0 0 33 21
0 3 21 4
0 191 0 1
0 208 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box1
2
321 0
325 0
4
0 0 33 34
0 1 33 34
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box2
2
321 0
325 0
4
0 0 33 34
0 4 33 34
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box3
2
321 0
325 0
4
0 0 33 34
0 2 33 34
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box4
2
321 0
325 0
4
0 0 33 34
0 5 33 34
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box5
2
321 0
325 0
4
0 0 33 34
0 3 33 34
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box1
2
322 0
356 0
4
0 0 33 44
0 1 42 55
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box2
2
322 0
356 0
4
0 0 33 44
0 4 42 55
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box3
2
322 0
356 0
4
0 0 33 44
0 2 42 55
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box4
2
322 0
356 0
4
0 0 33 44
0 5 42 55
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_14 loc_13_14 loc_14_14 down box5
2
322 0
356 0
4
0 0 33 44
0 3 42 55
0 25 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box1
2
286 0
323 0
4
0 0 34 22
0 1 22 5
0 192 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box2
2
286 0
323 0
4
0 0 34 22
0 4 22 5
0 192 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box3
2
286 0
323 0
4
0 0 34 22
0 2 22 5
0 192 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box4
2
286 0
323 0
4
0 0 34 22
0 5 22 5
0 192 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_11_15 loc_10_15 up box5
2
286 0
323 0
4
0 0 34 22
0 3 22 5
0 192 0 1
0 209 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box1
2
320 0
324 0
4
0 0 34 33
0 1 32 31
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box2
2
320 0
324 0
4
0 0 34 33
0 4 32 31
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box3
2
320 0
324 0
4
0 0 34 33
0 2 32 31
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box4
2
320 0
324 0
4
0 0 34 33
0 5 32 31
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box5
2
320 0
324 0
4
0 0 34 33
0 3 32 31
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box1
2
325 0
328 0
4
0 0 34 35
0 1 34 35
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box2
2
325 0
328 0
4
0 0 34 35
0 4 34 35
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box3
2
325 0
328 0
4
0 0 34 35
0 2 34 35
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box4
2
325 0
328 0
4
0 0 34 35
0 5 34 35
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box5
2
325 0
328 0
4
0 0 34 35
0 3 34 35
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box1
2
324 0
327 0
4
0 0 35 34
0 1 33 32
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box2
2
324 0
327 0
4
0 0 35 34
0 4 33 32
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box3
2
324 0
327 0
4
0 0 35 34
0 2 33 32
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box4
2
324 0
327 0
4
0 0 35 34
0 5 33 32
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box5
2
324 0
327 0
4
0 0 35 34
0 3 33 32
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box1
2
328 0
332 0
4
0 0 35 36
0 1 35 36
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box2
2
328 0
332 0
4
0 0 35 36
0 4 35 36
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box3
2
328 0
332 0
4
0 0 35 36
0 2 35 36
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box4
2
328 0
332 0
4
0 0 35 36
0 5 35 36
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box5
2
328 0
332 0
4
0 0 35 36
0 3 35 36
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_12_16 loc_13_16 loc_14_16 down box1
2
329 0
363 0
4
0 0 35 46
0 1 44 56
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_12_16 loc_13_16 loc_14_16 down box2
2
329 0
363 0
4
0 0 35 46
0 4 44 56
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_12_16 loc_13_16 loc_14_16 down box3
2
329 0
363 0
4
0 0 35 46
0 2 44 56
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_12_16 loc_13_16 loc_14_16 down box4
2
329 0
363 0
4
0 0 35 46
0 5 44 56
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_12_16 loc_13_16 loc_14_16 down box5
2
329 0
363 0
4
0 0 35 46
0 3 44 56
0 27 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box1
2
289 0
330 0
4
0 0 36 23
0 1 23 7
0 194 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box2
2
289 0
330 0
4
0 0 36 23
0 4 23 7
0 194 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box3
2
289 0
330 0
4
0 0 36 23
0 2 23 7
0 194 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box4
2
289 0
330 0
4
0 0 36 23
0 5 23 7
0 194 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box5
2
289 0
330 0
4
0 0 36 23
0 3 23 7
0 194 0 1
0 210 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box1
2
327 0
331 0
4
0 0 36 35
0 1 34 33
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box2
2
327 0
331 0
4
0 0 36 35
0 4 34 33
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box3
2
327 0
331 0
4
0 0 36 35
0 2 34 33
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box4
2
327 0
331 0
4
0 0 36 35
0 5 34 33
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box5
2
327 0
331 0
4
0 0 36 35
0 3 34 33
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box1
2
292 0
334 0
4
0 0 37 24
0 1 24 8
0 195 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box2
2
292 0
334 0
4
0 0 37 24
0 4 24 8
0 195 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box3
2
292 0
334 0
4
0 0 37 24
0 2 24 8
0 195 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box4
2
292 0
334 0
4
0 0 37 24
0 5 24 8
0 195 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box5
2
292 0
334 0
4
0 0 37 24
0 3 24 8
0 195 0 1
0 211 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box1
2
331 0
335 0
4
0 0 37 36
0 1 35 34
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box2
2
331 0
335 0
4
0 0 37 36
0 4 35 34
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box3
2
331 0
335 0
4
0 0 37 36
0 2 35 34
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box4
2
331 0
335 0
4
0 0 37 36
0 5 35 34
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box5
2
331 0
335 0
4
0 0 37 36
0 3 35 34
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box1
2
300 0
337 0
4
0 0 38 27
0 1 26 11
0 7 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box2
2
300 0
337 0
4
0 0 38 27
0 4 26 11
0 7 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box3
2
300 0
337 0
4
0 0 38 27
0 2 26 11
0 7 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box4
2
300 0
337 0
4
0 0 38 27
0 5 26 11
0 7 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box5
2
300 0
337 0
4
0 0 38 27
0 3 26 11
0 7 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box1
2
303 0
339 0
4
0 0 39 28
0 1 27 13
0 8 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box2
2
303 0
339 0
4
0 0 39 28
0 4 27 13
0 8 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box3
2
303 0
339 0
4
0 0 39 28
0 2 27 13
0 8 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box4
2
303 0
339 0
4
0 0 39 28
0 5 27 13
0 8 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box5
2
303 0
339 0
4
0 0 39 28
0 3 27 13
0 8 -1 0
0 200 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box1
2
341 0
378 0
4
0 0 39 52
0 1 50 57
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box2
2
341 0
378 0
4
0 0 39 52
0 4 50 57
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box3
2
341 0
378 0
4
0 0 39 52
0 2 50 57
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box4
2
341 0
378 0
4
0 0 39 52
0 5 50 57
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_12_5 loc_13_5 loc_14_5 down box5
2
341 0
378 0
4
0 0 39 52
0 3 50 57
0 33 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box1
2
306 0
342 0
4
0 0 40 29
0 1 28 14
0 9 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box2
2
306 0
342 0
4
0 0 40 29
0 4 28 14
0 9 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box3
2
306 0
342 0
4
0 0 40 29
0 2 28 14
0 9 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box4
2
306 0
342 0
4
0 0 40 29
0 5 28 14
0 9 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box5
2
306 0
342 0
4
0 0 40 29
0 3 28 14
0 9 -1 0
0 201 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box1
2
344 0
382 0
4
0 0 40 53
0 1 51 58
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box2
2
344 0
382 0
4
0 0 40 53
0 4 51 58
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box3
2
344 0
382 0
4
0 0 40 53
0 2 51 58
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box4
2
344 0
382 0
4
0 0 40 53
0 5 51 58
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_12_6 loc_13_6 loc_14_6 down box5
2
344 0
382 0
4
0 0 40 53
0 3 51 58
0 34 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_12_8 loc_11_8 loc_10_8 up box1
2
313 0
345 0
4
0 0 41 31
0 1 30 16
0 11 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_12_8 loc_11_8 loc_10_8 up box2
2
313 0
345 0
4
0 0 41 31
0 4 30 16
0 11 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_12_8 loc_11_8 loc_10_8 up box3
2
313 0
345 0
4
0 0 41 31
0 2 30 16
0 11 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_12_8 loc_11_8 loc_10_8 up box4
2
313 0
345 0
4
0 0 41 31
0 5 30 16
0 11 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_12_8 loc_11_8 loc_10_8 up box5
2
313 0
345 0
4
0 0 41 31
0 3 30 16
0 11 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box1
2
316 0
350 0
4
0 0 43 32
0 1 31 20
0 12 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box2
2
316 0
350 0
4
0 0 43 32
0 4 31 20
0 12 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box3
2
316 0
350 0
4
0 0 43 32
0 2 31 20
0 12 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box4
2
316 0
350 0
4
0 0 43 32
0 5 31 20
0 12 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_13 loc_12_13 loc_11_13 up box5
2
316 0
350 0
4
0 0 43 32
0 3 31 20
0 12 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box1
2
351 0
355 0
4
0 0 43 44
0 1 42 43
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box2
2
351 0
355 0
4
0 0 43 44
0 4 42 43
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box3
2
351 0
355 0
4
0 0 43 44
0 2 42 43
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box4
2
351 0
355 0
4
0 0 43 44
0 5 42 43
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_13_13 loc_13_14 loc_13_15 right box5
2
351 0
355 0
4
0 0 43 44
0 3 42 43
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box1
2
319 0
353 0
4
0 0 44 33
0 1 32 21
0 13 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box2
2
319 0
353 0
4
0 0 44 33
0 4 32 21
0 13 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box3
2
319 0
353 0
4
0 0 44 33
0 2 32 21
0 13 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box4
2
319 0
353 0
4
0 0 44 33
0 5 32 21
0 13 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_14 loc_12_14 loc_11_14 up box5
2
319 0
353 0
4
0 0 44 33
0 3 32 21
0 13 -1 0
0 208 0 1
1
end_operator
begin_operator
push loc_13_14 loc_13_15 loc_13_16 right box1
2
355 0
359 0
4
0 0 44 45
0 1 43 44
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_13_14 loc_13_15 loc_13_16 right box2
2
355 0
359 0
4
0 0 44 45
0 4 43 44
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_13_14 loc_13_15 loc_13_16 right box3
2
355 0
359 0
4
0 0 44 45
0 2 43 44
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_13_14 loc_13_15 loc_13_16 right box4
2
355 0
359 0
4
0 0 44 45
0 5 43 44
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_13_14 loc_13_15 loc_13_16 right box5
2
355 0
359 0
4
0 0 44 45
0 3 43 44
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box1
2
323 0
357 0
4
0 0 45 34
0 1 33 22
0 14 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box2
2
323 0
357 0
4
0 0 45 34
0 4 33 22
0 14 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box3
2
323 0
357 0
4
0 0 45 34
0 2 33 22
0 14 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box4
2
323 0
357 0
4
0 0 45 34
0 5 33 22
0 14 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_13_15 loc_12_15 loc_11_15 up box5
2
323 0
357 0
4
0 0 45 34
0 3 33 22
0 14 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box1
2
354 0
358 0
4
0 0 45 44
0 1 42 41
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box2
2
354 0
358 0
4
0 0 45 44
0 4 42 41
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box3
2
354 0
358 0
4
0 0 45 44
0 2 42 41
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box4
2
354 0
358 0
4
0 0 45 44
0 5 42 41
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_14 loc_13_13 left box5
2
354 0
358 0
4
0 0 45 44
0 3 42 41
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_13_15 loc_13_16 loc_13_17 right box1
2
359 0
362 0
4
0 0 45 46
0 1 44 45
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_13_15 loc_13_16 loc_13_17 right box2
2
359 0
362 0
4
0 0 45 46
0 4 44 45
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_13_15 loc_13_16 loc_13_17 right box3
2
359 0
362 0
4
0 0 45 46
0 2 44 45
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_13_15 loc_13_16 loc_13_17 right box4
2
359 0
362 0
4
0 0 45 46
0 5 44 45
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_13_15 loc_13_16 loc_13_17 right box5
2
359 0
362 0
4
0 0 45 46
0 3 44 45
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_13_16 loc_13_15 loc_13_14 left box1
2
358 0
361 0
4
0 0 46 45
0 1 43 42
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_13_16 loc_13_15 loc_13_14 left box2
2
358 0
361 0
4
0 0 46 45
0 4 43 42
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_13_16 loc_13_15 loc_13_14 left box3
2
358 0
361 0
4
0 0 46 45
0 2 43 42
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_13_16 loc_13_15 loc_13_14 left box4
2
358 0
361 0
4
0 0 46 45
0 5 43 42
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_13_16 loc_13_15 loc_13_14 left box5
2
358 0
361 0
4
0 0 46 45
0 3 43 42
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_13_16 loc_13_17 loc_13_18 right box1
2
362 0
366 0
4
0 0 46 47
0 1 45 46
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_13_16 loc_13_17 loc_13_18 right box2
2
362 0
366 0
4
0 0 46 47
0 4 45 46
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_13_16 loc_13_17 loc_13_18 right box3
2
362 0
366 0
4
0 0 46 47
0 2 45 46
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_13_16 loc_13_17 loc_13_18 right box4
2
362 0
366 0
4
0 0 46 47
0 5 45 46
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_13_16 loc_13_17 loc_13_18 right box5
2
362 0
366 0
4
0 0 46 47
0 3 45 46
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_13_16 loc_14_16 loc_15_16 down box1
2
363 0
394 0
4
0 0 46 58
0 1 56 59
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_13_16 loc_14_16 loc_15_16 down box2
2
363 0
394 0
4
0 0 46 58
0 4 56 59
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_13_16 loc_14_16 loc_15_16 down box3
2
363 0
394 0
4
0 0 46 58
0 2 56 59
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_13_16 loc_14_16 loc_15_16 down box4
2
363 0
394 0
4
0 0 46 58
0 5 56 59
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_13_16 loc_14_16 loc_15_16 down box5
2
363 0
394 0
4
0 0 46 58
0 3 56 59
0 40 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box1
2
330 0
364 0
4
0 0 47 36
0 1 35 23
0 16 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box2
2
330 0
364 0
4
0 0 47 36
0 4 35 23
0 16 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box3
2
330 0
364 0
4
0 0 47 36
0 2 35 23
0 16 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box4
2
330 0
364 0
4
0 0 47 36
0 5 35 23
0 16 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box5
2
330 0
364 0
4
0 0 47 36
0 3 35 23
0 16 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_16 loc_13_15 left box1
2
361 0
365 0
4
0 0 47 46
0 1 44 43
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_16 loc_13_15 left box2
2
361 0
365 0
4
0 0 47 46
0 4 44 43
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_16 loc_13_15 left box3
2
361 0
365 0
4
0 0 47 46
0 2 44 43
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_16 loc_13_15 left box4
2
361 0
365 0
4
0 0 47 46
0 5 44 43
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_16 loc_13_15 left box5
2
361 0
365 0
4
0 0 47 46
0 3 44 43
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box1
2
334 0
367 0
4
0 0 48 37
0 1 36 24
0 17 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box2
2
334 0
367 0
4
0 0 48 37
0 4 36 24
0 17 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box3
2
334 0
367 0
4
0 0 48 37
0 2 36 24
0 17 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box4
2
334 0
367 0
4
0 0 48 37
0 5 36 24
0 17 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box5
2
334 0
367 0
4
0 0 48 37
0 3 36 24
0 17 -1 0
0 211 0 1
1
end_operator
begin_operator
push loc_13_18 loc_13_17 loc_13_16 left box1
2
365 0
368 0
4
0 0 48 47
0 1 45 44
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_13_17 loc_13_16 left box2
2
365 0
368 0
4
0 0 48 47
0 4 45 44
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_13_17 loc_13_16 left box3
2
365 0
368 0
4
0 0 48 47
0 2 45 44
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_13_17 loc_13_16 left box4
2
365 0
368 0
4
0 0 48 47
0 5 45 44
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_13_17 loc_13_16 left box5
2
365 0
368 0
4
0 0 48 47
0 3 45 44
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_12_3 loc_11_3 up box1
2
337 0
370 0
4
0 0 50 38
0 1 37 26
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_12_3 loc_11_3 up box2
2
337 0
370 0
4
0 0 50 38
0 4 37 26
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_12_3 loc_11_3 up box3
2
337 0
370 0
4
0 0 50 38
0 2 37 26
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_12_3 loc_11_3 up box4
2
337 0
370 0
4
0 0 50 38
0 5 37 26
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_12_3 loc_11_3 up box5
2
337 0
370 0
4
0 0 50 38
0 3 37 26
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_13_3 loc_13_4 loc_13_5 right box1
2
372 0
374 0
4
0 0 50 51
0 1 49 50
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_13_3 loc_13_4 loc_13_5 right box2
2
372 0
374 0
4
0 0 50 51
0 4 49 50
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_13_3 loc_13_4 loc_13_5 right box3
2
372 0
374 0
4
0 0 50 51
0 2 49 50
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_13_3 loc_13_4 loc_13_5 right box4
2
372 0
374 0
4
0 0 50 51
0 5 49 50
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_13_3 loc_13_4 loc_13_5 right box5
2
372 0
374 0
4
0 0 50 51
0 3 49 50
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_3 loc_13_2 left box1
2
371 0
373 0
4
0 0 51 50
0 1 48 47
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_4 loc_13_3 loc_13_2 left box2
2
371 0
373 0
4
0 0 51 50
0 4 48 47
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_4 loc_13_3 loc_13_2 left box3
2
371 0
373 0
4
0 0 51 50
0 2 48 47
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_4 loc_13_3 loc_13_2 left box4
2
371 0
373 0
4
0 0 51 50
0 5 48 47
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_4 loc_13_3 loc_13_2 left box5
2
371 0
373 0
4
0 0 51 50
0 3 48 47
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box1
2
374 0
377 0
4
0 0 51 52
0 1 50 51
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box2
2
374 0
377 0
4
0 0 51 52
0 4 50 51
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box3
2
374 0
377 0
4
0 0 51 52
0 2 50 51
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box4
2
374 0
377 0
4
0 0 51 52
0 5 50 51
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box5
2
374 0
377 0
4
0 0 51 52
0 3 50 51
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box1
2
339 0
375 0
4
0 0 52 39
0 1 38 27
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box2
2
339 0
375 0
4
0 0 52 39
0 4 38 27
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box3
2
339 0
375 0
4
0 0 52 39
0 2 38 27
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box4
2
339 0
375 0
4
0 0 52 39
0 5 38 27
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_12_5 loc_11_5 up box5
2
339 0
375 0
4
0 0 52 39
0 3 38 27
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_4 loc_13_3 left box1
2
373 0
376 0
4
0 0 52 51
0 1 49 48
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_4 loc_13_3 left box2
2
373 0
376 0
4
0 0 52 51
0 4 49 48
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_4 loc_13_3 left box3
2
373 0
376 0
4
0 0 52 51
0 2 49 48
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_4 loc_13_3 left box4
2
373 0
376 0
4
0 0 52 51
0 5 49 48
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_4 loc_13_3 left box5
2
373 0
376 0
4
0 0 52 51
0 3 49 48
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box1
2
377 0
381 0
4
0 0 52 53
0 1 51 52
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box2
2
377 0
381 0
4
0 0 52 53
0 4 51 52
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box3
2
377 0
381 0
4
0 0 52 53
0 2 51 52
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box4
2
377 0
381 0
4
0 0 52 53
0 5 51 52
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box5
2
377 0
381 0
4
0 0 52 53
0 3 51 52
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box1
2
378 0
397 0
4
0 0 52 59
0 1 57 60
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box2
2
378 0
397 0
4
0 0 52 59
0 4 57 60
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box3
2
378 0
397 0
4
0 0 52 59
0 2 57 60
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box4
2
378 0
397 0
4
0 0 52 59
0 5 57 60
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box5
2
378 0
397 0
4
0 0 52 59
0 3 57 60
0 41 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box1
2
342 0
379 0
4
0 0 53 40
0 1 39 28
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box2
2
342 0
379 0
4
0 0 53 40
0 4 39 28
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box3
2
342 0
379 0
4
0 0 53 40
0 2 39 28
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box4
2
342 0
379 0
4
0 0 53 40
0 5 39 28
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_12_6 loc_11_6 up box5
2
342 0
379 0
4
0 0 53 40
0 3 39 28
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box1
2
376 0
380 0
4
0 0 53 52
0 1 50 49
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box2
2
376 0
380 0
4
0 0 53 52
0 4 50 49
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box3
2
376 0
380 0
4
0 0 53 52
0 2 50 49
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box4
2
376 0
380 0
4
0 0 53 52
0 5 50 49
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box5
2
376 0
380 0
4
0 0 53 52
0 3 50 49
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box1
2
381 0
384 0
4
0 0 53 54
0 1 52 53
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box2
2
381 0
384 0
4
0 0 53 54
0 4 52 53
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box3
2
381 0
384 0
4
0 0 53 54
0 2 52 53
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box4
2
381 0
384 0
4
0 0 53 54
0 5 52 53
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_7 loc_13_8 right box5
2
381 0
384 0
4
0 0 53 54
0 3 52 53
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box1
2
382 0
400 0
4
0 0 53 60
0 1 58 61
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box2
2
382 0
400 0
4
0 0 53 60
0 4 58 61
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box3
2
382 0
400 0
4
0 0 53 60
0 2 58 61
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box4
2
382 0
400 0
4
0 0 53 60
0 5 58 61
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box5
2
382 0
400 0
4
0 0 53 60
0 3 58 61
0 42 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box1
2
380 0
383 0
4
0 0 54 53
0 1 51 50
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box2
2
380 0
383 0
4
0 0 54 53
0 4 51 50
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box3
2
380 0
383 0
4
0 0 54 53
0 2 51 50
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box4
2
380 0
383 0
4
0 0 54 53
0 5 51 50
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box5
2
380 0
383 0
4
0 0 54 53
0 3 51 50
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box1
2
345 0
385 0
4
0 0 55 41
0 1 40 30
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box2
2
345 0
385 0
4
0 0 55 41
0 4 40 30
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box3
2
345 0
385 0
4
0 0 55 41
0 2 40 30
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box4
2
345 0
385 0
4
0 0 55 41
0 5 40 30
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_12_8 loc_11_8 up box5
2
345 0
385 0
4
0 0 55 41
0 3 40 30
0 11 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box1
2
383 0
386 0
4
0 0 55 54
0 1 52 51
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box2
2
383 0
386 0
4
0 0 55 54
0 4 52 51
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box3
2
383 0
386 0
4
0 0 55 54
0 2 52 51
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box4
2
383 0
386 0
4
0 0 55 54
0 5 52 51
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_13_8 loc_13_7 loc_13_6 left box5
2
383 0
386 0
4
0 0 55 54
0 3 52 51
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box1
2
350 0
389 0
4
0 0 56 43
0 1 41 31
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box2
2
350 0
389 0
4
0 0 56 43
0 4 41 31
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box3
2
350 0
389 0
4
0 0 56 43
0 2 41 31
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box4
2
350 0
389 0
4
0 0 56 43
0 5 41 31
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_14_13 loc_13_13 loc_12_13 up box5
2
350 0
389 0
4
0 0 56 43
0 3 41 31
0 12 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box1
2
353 0
391 0
4
0 0 57 44
0 1 42 32
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box2
2
353 0
391 0
4
0 0 57 44
0 4 42 32
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box3
2
353 0
391 0
4
0 0 57 44
0 2 42 32
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box4
2
353 0
391 0
4
0 0 57 44
0 5 42 32
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_14_14 loc_13_14 loc_12_14 up box5
2
353 0
391 0
4
0 0 57 44
0 3 42 32
0 13 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_13_16 loc_12_16 up box1
2
360 0
393 0
4
0 0 58 46
0 1 44 34
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_13_16 loc_12_16 up box2
2
360 0
393 0
4
0 0 58 46
0 4 44 34
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_13_16 loc_12_16 up box3
2
360 0
393 0
4
0 0 58 46
0 2 44 34
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_13_16 loc_12_16 up box4
2
360 0
393 0
4
0 0 58 46
0 5 44 34
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_13_16 loc_12_16 up box5
2
360 0
393 0
4
0 0 58 46
0 3 44 34
0 15 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_14_16 loc_15_16 loc_16_16 down box1
2
394 0
407 0
4
0 0 58 63
0 1 59 69
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_16 loc_15_16 loc_16_16 down box2
2
394 0
407 0
4
0 0 58 63
0 4 59 69
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_16 loc_15_16 loc_16_16 down box3
2
394 0
407 0
4
0 0 58 63
0 2 59 69
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_16 loc_15_16 loc_16_16 down box4
2
394 0
407 0
4
0 0 58 63
0 5 59 69
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_16 loc_15_16 loc_16_16 down box5
2
394 0
407 0
4
0 0 58 63
0 3 59 69
0 46 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box1
2
375 0
395 0
4
0 0 59 52
0 1 50 38
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box2
2
375 0
395 0
4
0 0 59 52
0 4 50 38
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box3
2
375 0
395 0
4
0 0 59 52
0 2 50 38
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box4
2
375 0
395 0
4
0 0 59 52
0 5 50 38
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_13_5 loc_12_5 up box5
2
375 0
395 0
4
0 0 59 52
0 3 50 38
0 19 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box1
2
397 0
411 0
4
0 0 59 65
0 1 60 73
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box2
2
397 0
411 0
4
0 0 59 65
0 4 60 73
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box3
2
397 0
411 0
4
0 0 59 65
0 2 60 73
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box4
2
397 0
411 0
4
0 0 59 65
0 5 60 73
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_15_5 loc_16_5 down box5
2
397 0
411 0
4
0 0 59 65
0 3 60 73
0 49 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box1
2
379 0
398 0
4
0 0 60 53
0 1 51 39
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box2
2
379 0
398 0
4
0 0 60 53
0 4 51 39
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box3
2
379 0
398 0
4
0 0 60 53
0 2 51 39
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box4
2
379 0
398 0
4
0 0 60 53
0 5 51 39
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_13_6 loc_12_6 up box5
2
379 0
398 0
4
0 0 60 53
0 3 51 39
0 20 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box1
2
400 0
414 0
4
0 0 60 66
0 1 61 74
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box2
2
400 0
414 0
4
0 0 60 66
0 4 61 74
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box3
2
400 0
414 0
4
0 0 60 66
0 2 61 74
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box4
2
400 0
414 0
4
0 0 60 66
0 5 61 74
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_15_6 loc_16_6 down box5
2
400 0
414 0
4
0 0 60 66
0 3 61 74
0 50 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_15_15 loc_16_15 loc_17_15 down box1
2
404 0
431 0
4
0 0 62 73
0 1 68 78
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_15 loc_16_15 loc_17_15 down box2
2
404 0
431 0
4
0 0 62 73
0 4 68 78
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_15 loc_16_15 loc_17_15 down box3
2
404 0
431 0
4
0 0 62 73
0 2 68 78
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_15 loc_16_15 loc_17_15 down box4
2
404 0
431 0
4
0 0 62 73
0 5 68 78
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_15 loc_16_15 loc_17_15 down box5
2
404 0
431 0
4
0 0 62 73
0 3 68 78
0 57 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_16 loc_14_16 loc_13_16 up box1
2
393 0
405 0
4
0 0 63 58
0 1 56 44
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_14_16 loc_13_16 up box2
2
393 0
405 0
4
0 0 63 58
0 4 56 44
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_14_16 loc_13_16 up box3
2
393 0
405 0
4
0 0 63 58
0 2 56 44
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_14_16 loc_13_16 up box4
2
393 0
405 0
4
0 0 63 58
0 5 56 44
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_14_16 loc_13_16 up box5
2
393 0
405 0
4
0 0 63 58
0 3 56 44
0 27 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box1
2
395 0
409 0
4
0 0 65 59
0 1 57 50
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box2
2
395 0
409 0
4
0 0 65 59
0 4 57 50
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box3
2
395 0
409 0
4
0 0 65 59
0 2 57 50
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box4
2
395 0
409 0
4
0 0 65 59
0 5 57 50
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box5
2
395 0
409 0
4
0 0 65 59
0 3 57 50
0 33 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_16_5 loc_17_5 down box1
2
411 0
444 0
4
0 0 65 78
0 1 73 81
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_5 loc_16_5 loc_17_5 down box2
2
411 0
444 0
4
0 0 65 78
0 4 73 81
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_5 loc_16_5 loc_17_5 down box3
2
411 0
444 0
4
0 0 65 78
0 2 73 81
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_5 loc_16_5 loc_17_5 down box4
2
411 0
444 0
4
0 0 65 78
0 5 73 81
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_5 loc_16_5 loc_17_5 down box5
2
411 0
444 0
4
0 0 65 78
0 3 73 81
0 62 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box1
2
398 0
412 0
4
0 0 66 60
0 1 58 51
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box2
2
398 0
412 0
4
0 0 66 60
0 4 58 51
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box3
2
398 0
412 0
4
0 0 66 60
0 2 58 51
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box4
2
398 0
412 0
4
0 0 66 60
0 5 58 51
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box5
2
398 0
412 0
4
0 0 66 60
0 3 58 51
0 34 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_16_6 loc_17_6 down box1
2
414 0
448 0
4
0 0 66 79
0 1 74 82
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_6 loc_16_6 loc_17_6 down box2
2
414 0
448 0
4
0 0 66 79
0 4 74 82
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_6 loc_16_6 loc_17_6 down box3
2
414 0
448 0
4
0 0 66 79
0 2 74 82
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_6 loc_16_6 loc_17_6 down box4
2
414 0
448 0
4
0 0 66 79
0 5 74 82
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_6 loc_16_6 loc_17_6 down box5
2
414 0
448 0
4
0 0 66 79
0 3 74 82
0 63 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_11 loc_16_12 right box1
2
416 0
420 0
4
0 0 68 69
0 1 64 65
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_11 loc_16_12 right box2
2
416 0
420 0
4
0 0 68 69
0 4 64 65
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_11 loc_16_12 right box3
2
416 0
420 0
4
0 0 68 69
0 2 64 65
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_11 loc_16_12 right box4
2
416 0
420 0
4
0 0 68 69
0 5 64 65
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_11 loc_16_12 right box5
2
416 0
420 0
4
0 0 68 69
0 3 64 65
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box1
2
417 0
457 0
4
0 0 68 82
0 1 77 76
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box2
2
417 0
457 0
4
0 0 68 82
0 4 77 76
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box3
2
417 0
457 0
4
0 0 68 82
0 2 77 76
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box4
2
417 0
457 0
4
0 0 68 82
0 5 77 76
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_10 loc_16_9 loc_16_8 left box5
2
417 0
457 0
4
0 0 68 82
0 3 77 76
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_11 loc_16_10 loc_16_9 left box1
2
417 0
419 0
4
0 0 69 68
0 1 63 77
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_10 loc_16_9 left box2
2
417 0
419 0
4
0 0 69 68
0 4 63 77
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_10 loc_16_9 left box3
2
417 0
419 0
4
0 0 69 68
0 2 63 77
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_10 loc_16_9 left box4
2
417 0
419 0
4
0 0 69 68
0 5 63 77
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_10 loc_16_9 left box5
2
417 0
419 0
4
0 0 69 68
0 3 63 77
0 52 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_12 loc_16_13 right box1
2
420 0
422 0
4
0 0 69 70
0 1 65 66
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_12 loc_16_13 right box2
2
420 0
422 0
4
0 0 69 70
0 4 65 66
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_12 loc_16_13 right box3
2
420 0
422 0
4
0 0 69 70
0 2 65 66
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_12 loc_16_13 right box4
2
420 0
422 0
4
0 0 69 70
0 5 65 66
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_16_11 loc_16_12 loc_16_13 right box5
2
420 0
422 0
4
0 0 69 70
0 3 65 66
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_16_12 loc_16_11 loc_16_10 left box1
2
419 0
421 0
4
0 0 70 69
0 1 64 63
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_16_12 loc_16_11 loc_16_10 left box2
2
419 0
421 0
4
0 0 70 69
0 4 64 63
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_16_12 loc_16_11 loc_16_10 left box3
2
419 0
421 0
4
0 0 70 69
0 2 64 63
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_16_12 loc_16_11 loc_16_10 left box4
2
419 0
421 0
4
0 0 70 69
0 5 64 63
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_16_12 loc_16_11 loc_16_10 left box5
2
419 0
421 0
4
0 0 70 69
0 3 64 63
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_16_12 loc_16_13 loc_16_14 right box1
2
422 0
425 0
4
0 0 70 71
0 1 66 67
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_16_12 loc_16_13 loc_16_14 right box2
2
422 0
425 0
4
0 0 70 71
0 4 66 67
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_16_12 loc_16_13 loc_16_14 right box3
2
422 0
425 0
4
0 0 70 71
0 2 66 67
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_16_12 loc_16_13 loc_16_14 right box4
2
422 0
425 0
4
0 0 70 71
0 5 66 67
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_16_12 loc_16_13 loc_16_14 right box5
2
422 0
425 0
4
0 0 70 71
0 3 66 67
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_16_13 loc_16_12 loc_16_11 left box1
2
421 0
424 0
4
0 0 71 70
0 1 65 64
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_16_12 loc_16_11 left box2
2
421 0
424 0
4
0 0 71 70
0 4 65 64
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_16_12 loc_16_11 left box3
2
421 0
424 0
4
0 0 71 70
0 2 65 64
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_16_12 loc_16_11 left box4
2
421 0
424 0
4
0 0 71 70
0 5 65 64
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_16_12 loc_16_11 left box5
2
421 0
424 0
4
0 0 71 70
0 3 65 64
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_16_13 loc_16_14 loc_16_15 right box1
2
425 0
427 0
4
0 0 71 72
0 1 67 68
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_16_13 loc_16_14 loc_16_15 right box2
2
425 0
427 0
4
0 0 71 72
0 4 67 68
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_16_13 loc_16_14 loc_16_15 right box3
2
425 0
427 0
4
0 0 71 72
0 2 67 68
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_16_13 loc_16_14 loc_16_15 right box4
2
425 0
427 0
4
0 0 71 72
0 5 67 68
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_16_13 loc_16_14 loc_16_15 right box5
2
425 0
427 0
4
0 0 71 72
0 3 67 68
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_16_14 loc_16_13 loc_16_12 left box1
2
424 0
426 0
4
0 0 72 71
0 1 66 65
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_16_13 loc_16_12 left box2
2
424 0
426 0
4
0 0 72 71
0 4 66 65
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_16_13 loc_16_12 left box3
2
424 0
426 0
4
0 0 72 71
0 2 66 65
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_16_13 loc_16_12 left box4
2
424 0
426 0
4
0 0 72 71
0 5 66 65
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_16_13 loc_16_12 left box5
2
424 0
426 0
4
0 0 72 71
0 3 66 65
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_16_14 loc_16_15 loc_16_16 right box1
2
427 0
430 0
4
0 0 72 73
0 1 68 69
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_16_14 loc_16_15 loc_16_16 right box2
2
427 0
430 0
4
0 0 72 73
0 4 68 69
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_16_14 loc_16_15 loc_16_16 right box3
2
427 0
430 0
4
0 0 72 73
0 2 68 69
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_16_14 loc_16_15 loc_16_16 right box4
2
427 0
430 0
4
0 0 72 73
0 5 68 69
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_16_14 loc_16_15 loc_16_16 right box5
2
427 0
430 0
4
0 0 72 73
0 3 68 69
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_16_15 loc_16_14 loc_16_13 left box1
2
426 0
429 0
4
0 0 73 72
0 1 67 66
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_16_15 loc_16_14 loc_16_13 left box2
2
426 0
429 0
4
0 0 73 72
0 4 67 66
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_16_15 loc_16_14 loc_16_13 left box3
2
426 0
429 0
4
0 0 73 72
0 2 67 66
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_16_15 loc_16_14 loc_16_13 left box4
2
426 0
429 0
4
0 0 73 72
0 5 67 66
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_16_15 loc_16_14 loc_16_13 left box5
2
426 0
429 0
4
0 0 73 72
0 3 67 66
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_16_15 loc_16_16 loc_16_17 right box1
2
430 0
434 0
4
0 0 73 74
0 1 69 70
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_16_15 loc_16_16 loc_16_17 right box2
2
430 0
434 0
4
0 0 73 74
0 4 69 70
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_16_15 loc_16_16 loc_16_17 right box3
2
430 0
434 0
4
0 0 73 74
0 2 69 70
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_16_15 loc_16_16 loc_16_17 right box4
2
430 0
434 0
4
0 0 73 74
0 5 69 70
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_16_15 loc_16_16 loc_16_17 right box5
2
430 0
434 0
4
0 0 73 74
0 3 69 70
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_16_15 loc_17_15 loc_18_15 down box1
2
431 0
461 0
4
0 0 73 84
0 1 78 85
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_16_15 loc_17_15 loc_18_15 down box2
2
431 0
461 0
4
0 0 73 84
0 4 78 85
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_16_15 loc_17_15 loc_18_15 down box3
2
431 0
461 0
4
0 0 73 84
0 2 78 85
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_16_15 loc_17_15 loc_18_15 down box4
2
431 0
461 0
4
0 0 73 84
0 5 78 85
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_16_15 loc_17_15 loc_18_15 down box5
2
431 0
461 0
4
0 0 73 84
0 3 78 85
0 68 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_16_16 loc_15_16 loc_14_16 up box1
2
405 0
432 0
4
0 0 74 63
0 1 59 56
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_15_16 loc_14_16 up box2
2
405 0
432 0
4
0 0 74 63
0 4 59 56
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_15_16 loc_14_16 up box3
2
405 0
432 0
4
0 0 74 63
0 2 59 56
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_15_16 loc_14_16 up box4
2
405 0
432 0
4
0 0 74 63
0 5 59 56
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_15_16 loc_14_16 up box5
2
405 0
432 0
4
0 0 74 63
0 3 59 56
0 40 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_15 loc_16_14 left box1
2
429 0
433 0
4
0 0 74 73
0 1 68 67
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_15 loc_16_14 left box2
2
429 0
433 0
4
0 0 74 73
0 4 68 67
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_15 loc_16_14 left box3
2
429 0
433 0
4
0 0 74 73
0 2 68 67
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_15 loc_16_14 left box4
2
429 0
433 0
4
0 0 74 73
0 5 68 67
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_15 loc_16_14 left box5
2
429 0
433 0
4
0 0 74 73
0 3 68 67
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_16_16 loc_16_17 loc_16_18 right box1
2
434 0
436 0
4
0 0 74 75
0 1 70 71
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_16_16 loc_16_17 loc_16_18 right box2
2
434 0
436 0
4
0 0 74 75
0 4 70 71
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_16_16 loc_16_17 loc_16_18 right box3
2
434 0
436 0
4
0 0 74 75
0 2 70 71
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_16_16 loc_16_17 loc_16_18 right box4
2
434 0
436 0
4
0 0 74 75
0 5 70 71
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_16_16 loc_16_17 loc_16_18 right box5
2
434 0
436 0
4
0 0 74 75
0 3 70 71
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_16_4 loc_16_5 loc_16_6 right box1
2
439 0
443 0
4
0 0 77 78
0 1 73 74
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_16_4 loc_16_5 loc_16_6 right box2
2
439 0
443 0
4
0 0 77 78
0 4 73 74
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_16_4 loc_16_5 loc_16_6 right box3
2
439 0
443 0
4
0 0 77 78
0 2 73 74
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_16_4 loc_16_5 loc_16_6 right box4
2
439 0
443 0
4
0 0 77 78
0 5 73 74
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_16_4 loc_16_5 loc_16_6 right box5
2
439 0
443 0
4
0 0 77 78
0 3 73 74
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_16_4 loc_17_4 loc_18_4 down box1
2
440 0
467 0
4
0 0 77 86
0 1 80 86
0 71 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_16_4 loc_17_4 loc_18_4 down box2
2
440 0
467 0
4
0 0 77 86
0 4 80 86
0 71 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_16_4 loc_17_4 loc_18_4 down box3
2
440 0
467 0
4
0 0 77 86
0 2 80 86
0 71 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_16_4 loc_17_4 loc_18_4 down box4
2
440 0
467 0
4
0 0 77 86
0 5 80 86
0 71 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_16_4 loc_17_4 loc_18_4 down box5
2
440 0
467 0
4
0 0 77 86
0 3 80 86
0 71 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box1
2
409 0
441 0
4
0 0 78 65
0 1 60 57
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box2
2
409 0
441 0
4
0 0 78 65
0 4 60 57
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box3
2
409 0
441 0
4
0 0 78 65
0 2 60 57
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box4
2
409 0
441 0
4
0 0 78 65
0 5 60 57
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_15_5 loc_14_5 up box5
2
409 0
441 0
4
0 0 78 65
0 3 60 57
0 41 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box1
2
443 0
447 0
4
0 0 78 79
0 1 74 75
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box2
2
443 0
447 0
4
0 0 78 79
0 4 74 75
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box3
2
443 0
447 0
4
0 0 78 79
0 2 74 75
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box4
2
443 0
447 0
4
0 0 78 79
0 5 74 75
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_16_5 loc_16_6 loc_16_7 right box5
2
443 0
447 0
4
0 0 78 79
0 3 74 75
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box1
2
412 0
445 0
4
0 0 79 66
0 1 61 58
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box2
2
412 0
445 0
4
0 0 79 66
0 4 61 58
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box3
2
412 0
445 0
4
0 0 79 66
0 2 61 58
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box4
2
412 0
445 0
4
0 0 79 66
0 5 61 58
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_15_6 loc_14_6 up box5
2
412 0
445 0
4
0 0 79 66
0 3 61 58
0 42 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_5 loc_16_4 left box1
2
442 0
446 0
4
0 0 79 78
0 1 73 72
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_5 loc_16_4 left box2
2
442 0
446 0
4
0 0 79 78
0 4 73 72
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_5 loc_16_4 left box3
2
442 0
446 0
4
0 0 79 78
0 2 73 72
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_5 loc_16_4 left box4
2
442 0
446 0
4
0 0 79 78
0 5 73 72
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_5 loc_16_4 left box5
2
442 0
446 0
4
0 0 79 78
0 3 73 72
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box1
2
447 0
450 0
4
0 0 79 80
0 1 75 76
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box2
2
447 0
450 0
4
0 0 79 80
0 4 75 76
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box3
2
447 0
450 0
4
0 0 79 80
0 2 75 76
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box4
2
447 0
450 0
4
0 0 79 80
0 5 75 76
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_16_6 loc_16_7 loc_16_8 right box5
2
447 0
450 0
4
0 0 79 80
0 3 75 76
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_16_6 loc_17_6 loc_18_6 down box1
2
448 0
474 0
4
0 0 79 88
0 1 82 87
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_16_6 loc_17_6 loc_18_6 down box2
2
448 0
474 0
4
0 0 79 88
0 4 82 87
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_16_6 loc_17_6 loc_18_6 down box3
2
448 0
474 0
4
0 0 79 88
0 2 82 87
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_16_6 loc_17_6 loc_18_6 down box4
2
448 0
474 0
4
0 0 79 88
0 5 82 87
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_16_6 loc_17_6 loc_18_6 down box5
2
448 0
474 0
4
0 0 79 88
0 3 82 87
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box1
2
446 0
449 0
4
0 0 80 79
0 1 74 73
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box2
2
446 0
449 0
4
0 0 80 79
0 4 74 73
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box3
2
446 0
449 0
4
0 0 80 79
0 2 74 73
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box4
2
446 0
449 0
4
0 0 80 79
0 5 74 73
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_6 loc_16_5 left box5
2
446 0
449 0
4
0 0 80 79
0 3 74 73
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box1
2
450 0
454 0
4
0 0 80 81
0 1 76 77
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box2
2
450 0
454 0
4
0 0 80 81
0 4 76 77
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box3
2
450 0
454 0
4
0 0 80 81
0 2 76 77
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box4
2
450 0
454 0
4
0 0 80 81
0 5 76 77
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_7 loc_16_8 loc_16_9 right box5
2
450 0
454 0
4
0 0 80 81
0 3 76 77
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box1
2
451 0
478 0
4
0 0 80 89
0 1 83 88
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box2
2
451 0
478 0
4
0 0 80 89
0 4 83 88
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box3
2
451 0
478 0
4
0 0 80 89
0 2 83 88
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box4
2
451 0
478 0
4
0 0 80 89
0 5 83 88
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_7 loc_17_7 loc_18_7 down box5
2
451 0
478 0
4
0 0 80 89
0 3 83 88
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box1
2
449 0
453 0
4
0 0 81 80
0 1 75 74
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box2
2
449 0
453 0
4
0 0 81 80
0 4 75 74
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box3
2
449 0
453 0
4
0 0 81 80
0 2 75 74
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box4
2
449 0
453 0
4
0 0 81 80
0 5 75 74
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_7 loc_16_6 left box5
2
449 0
453 0
4
0 0 81 80
0 3 75 74
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box1
2
454 0
456 0
4
0 0 81 82
0 1 77 63
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box2
2
454 0
456 0
4
0 0 81 82
0 4 77 63
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box3
2
454 0
456 0
4
0 0 81 82
0 2 77 63
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box4
2
454 0
456 0
4
0 0 81 82
0 5 77 63
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_8 loc_16_9 loc_16_10 right box5
2
454 0
456 0
4
0 0 81 82
0 3 77 63
0 52 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_10 loc_16_11 right box1
2
416 0
456 0
4
0 0 82 68
0 1 63 64
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_16_9 loc_16_10 loc_16_11 right box2
2
416 0
456 0
4
0 0 82 68
0 4 63 64
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_16_9 loc_16_10 loc_16_11 right box3
2
416 0
456 0
4
0 0 82 68
0 2 63 64
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_16_9 loc_16_10 loc_16_11 right box4
2
416 0
456 0
4
0 0 82 68
0 5 63 64
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_16_9 loc_16_10 loc_16_11 right box5
2
416 0
456 0
4
0 0 82 68
0 3 63 64
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box1
2
453 0
457 0
4
0 0 82 81
0 1 76 75
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box2
2
453 0
457 0
4
0 0 82 81
0 4 76 75
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box3
2
453 0
457 0
4
0 0 82 81
0 2 76 75
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box4
2
453 0
457 0
4
0 0 82 81
0 5 76 75
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_16_9 loc_16_8 loc_16_7 left box5
2
453 0
457 0
4
0 0 82 81
0 3 76 75
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_15 loc_18_15 loc_19_15 down box1
2
461 0
487 0
4
0 0 84 93
0 1 85 89
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_17_15 loc_18_15 loc_19_15 down box2
2
461 0
487 0
4
0 0 84 93
0 4 85 89
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_17_15 loc_18_15 loc_19_15 down box3
2
461 0
487 0
4
0 0 84 93
0 2 85 89
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_17_15 loc_18_15 loc_19_15 down box4
2
461 0
487 0
4
0 0 84 93
0 5 85 89
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_17_15 loc_18_15 loc_19_15 down box5
2
461 0
487 0
4
0 0 84 93
0 3 85 89
0 79 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_17_4 loc_17_5 loc_17_6 right box1
2
466 0
470 0
4
0 0 86 87
0 1 81 82
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_17_4 loc_17_5 loc_17_6 right box2
2
466 0
470 0
4
0 0 86 87
0 4 81 82
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_17_4 loc_17_5 loc_17_6 right box3
2
466 0
470 0
4
0 0 86 87
0 2 81 82
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_17_4 loc_17_5 loc_17_6 right box4
2
466 0
470 0
4
0 0 86 87
0 5 81 82
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_17_4 loc_17_5 loc_17_6 right box5
2
466 0
470 0
4
0 0 86 87
0 3 81 82
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_17_4 loc_18_4 loc_19_4 down box1
2
467 0
493 0
4
0 0 86 94
0 1 86 90
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_17_4 loc_18_4 loc_19_4 down box2
2
467 0
493 0
4
0 0 86 94
0 4 86 90
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_17_4 loc_18_4 loc_19_4 down box3
2
467 0
493 0
4
0 0 86 94
0 2 86 90
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_17_4 loc_18_4 loc_19_4 down box4
2
467 0
493 0
4
0 0 86 94
0 5 86 90
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_17_4 loc_18_4 loc_19_4 down box5
2
467 0
493 0
4
0 0 86 94
0 3 86 90
0 82 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_17_5 loc_16_5 loc_15_5 up box1
2
441 0
468 0
4
0 0 87 78
0 1 73 60
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_16_5 loc_15_5 up box2
2
441 0
468 0
4
0 0 87 78
0 4 73 60
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_16_5 loc_15_5 up box3
2
441 0
468 0
4
0 0 87 78
0 2 73 60
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_16_5 loc_15_5 up box4
2
441 0
468 0
4
0 0 87 78
0 5 73 60
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_16_5 loc_15_5 up box5
2
441 0
468 0
4
0 0 87 78
0 3 73 60
0 49 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_4 loc_17_3 left box1
2
465 0
469 0
4
0 0 87 86
0 1 80 79
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_4 loc_17_3 left box2
2
465 0
469 0
4
0 0 87 86
0 4 80 79
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_4 loc_17_3 left box3
2
465 0
469 0
4
0 0 87 86
0 2 80 79
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_4 loc_17_3 left box4
2
465 0
469 0
4
0 0 87 86
0 5 80 79
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_4 loc_17_3 left box5
2
465 0
469 0
4
0 0 87 86
0 3 80 79
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_17_5 loc_17_6 loc_17_7 right box1
2
470 0
473 0
4
0 0 87 88
0 1 82 83
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_17_5 loc_17_6 loc_17_7 right box2
2
470 0
473 0
4
0 0 87 88
0 4 82 83
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_17_5 loc_17_6 loc_17_7 right box3
2
470 0
473 0
4
0 0 87 88
0 2 82 83
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_17_5 loc_17_6 loc_17_7 right box4
2
470 0
473 0
4
0 0 87 88
0 5 82 83
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_17_5 loc_17_6 loc_17_7 right box5
2
470 0
473 0
4
0 0 87 88
0 3 82 83
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_17_6 loc_16_6 loc_15_6 up box1
2
445 0
471 0
4
0 0 88 79
0 1 74 61
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_16_6 loc_15_6 up box2
2
445 0
471 0
4
0 0 88 79
0 4 74 61
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_16_6 loc_15_6 up box3
2
445 0
471 0
4
0 0 88 79
0 2 74 61
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_16_6 loc_15_6 up box4
2
445 0
471 0
4
0 0 88 79
0 5 74 61
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_16_6 loc_15_6 up box5
2
445 0
471 0
4
0 0 88 79
0 3 74 61
0 50 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_5 loc_17_4 left box1
2
469 0
472 0
4
0 0 88 87
0 1 81 80
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_5 loc_17_4 left box2
2
469 0
472 0
4
0 0 88 87
0 4 81 80
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_5 loc_17_4 left box3
2
469 0
472 0
4
0 0 88 87
0 2 81 80
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_5 loc_17_4 left box4
2
469 0
472 0
4
0 0 88 87
0 5 81 80
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_5 loc_17_4 left box5
2
469 0
472 0
4
0 0 88 87
0 3 81 80
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_17_6 loc_17_7 loc_17_8 right box1
2
473 0
477 0
4
0 0 88 89
0 1 83 84
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_17_6 loc_17_7 loc_17_8 right box2
2
473 0
477 0
4
0 0 88 89
0 4 83 84
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_17_6 loc_17_7 loc_17_8 right box3
2
473 0
477 0
4
0 0 88 89
0 2 83 84
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_17_6 loc_17_7 loc_17_8 right box4
2
473 0
477 0
4
0 0 88 89
0 5 83 84
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_17_6 loc_17_7 loc_17_8 right box5
2
473 0
477 0
4
0 0 88 89
0 3 83 84
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_17_6 loc_18_6 loc_19_6 down box1
2
474 0
496 0
4
0 0 88 95
0 1 87 91
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_17_6 loc_18_6 loc_19_6 down box2
2
474 0
496 0
4
0 0 88 95
0 4 87 91
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_17_6 loc_18_6 loc_19_6 down box3
2
474 0
496 0
4
0 0 88 95
0 2 87 91
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_17_6 loc_18_6 loc_19_6 down box4
2
474 0
496 0
4
0 0 88 95
0 5 87 91
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_17_6 loc_18_6 loc_19_6 down box5
2
474 0
496 0
4
0 0 88 95
0 3 87 91
0 83 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_17_7 loc_17_6 loc_17_5 left box1
2
472 0
476 0
4
0 0 89 88
0 1 82 81
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_17_6 loc_17_5 left box2
2
472 0
476 0
4
0 0 89 88
0 4 82 81
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_17_6 loc_17_5 left box3
2
472 0
476 0
4
0 0 89 88
0 2 82 81
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_17_6 loc_17_5 left box4
2
472 0
476 0
4
0 0 89 88
0 5 82 81
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_17_7 loc_17_6 loc_17_5 left box5
2
472 0
476 0
4
0 0 89 88
0 3 82 81
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box1
2
452 0
479 0
4
0 0 90 81
0 1 76 62
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box2
2
452 0
479 0
4
0 0 90 81
0 4 76 62
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box3
2
452 0
479 0
4
0 0 90 81
0 2 76 62
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box4
2
452 0
479 0
4
0 0 90 81
0 5 76 62
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_16_8 loc_15_8 up box5
2
452 0
479 0
4
0 0 90 81
0 3 76 62
0 51 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_17_7 loc_17_6 left box1
2
476 0
480 0
4
0 0 90 89
0 1 83 82
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_17_7 loc_17_6 left box2
2
476 0
480 0
4
0 0 90 89
0 4 83 82
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_17_7 loc_17_6 left box3
2
476 0
480 0
4
0 0 90 89
0 2 83 82
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_17_7 loc_17_6 left box4
2
476 0
480 0
4
0 0 90 89
0 5 83 82
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_17_8 loc_17_7 loc_17_6 left box5
2
476 0
480 0
4
0 0 90 89
0 3 83 82
0 73 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_17_6 loc_16_6 up box1
2
471 0
494 0
4
0 0 95 88
0 1 82 74
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_17_6 loc_16_6 up box2
2
471 0
494 0
4
0 0 95 88
0 4 82 74
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_17_6 loc_16_6 up box3
2
471 0
494 0
4
0 0 95 88
0 2 82 74
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_17_6 loc_16_6 up box4
2
471 0
494 0
4
0 0 95 88
0 5 82 74
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_18_6 loc_17_6 loc_16_6 up box5
2
471 0
494 0
4
0 0 95 88
0 3 82 74
0 63 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box1
2
475 0
497 0
4
0 0 96 89
0 1 83 75
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box2
2
475 0
497 0
4
0 0 96 89
0 4 83 75
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box3
2
475 0
497 0
4
0 0 96 89
0 2 83 75
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box4
2
475 0
497 0
4
0 0 96 89
0 5 83 75
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_18_7 loc_17_7 loc_16_7 up box5
2
475 0
497 0
4
0 0 96 89
0 3 83 75
0 64 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box1
2
517 0
533 0
4
0 0 105 109
0 1 96 101
0 110 -1 0
0 118 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box2
2
517 0
533 0
4
0 0 105 109
0 4 96 101
0 110 -1 0
0 118 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box3
2
517 0
533 0
4
0 0 105 109
0 2 96 101
0 110 -1 0
0 118 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box4
2
517 0
533 0
4
0 0 105 109
0 5 96 101
0 110 -1 0
0 118 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box5
2
517 0
533 0
4
0 0 105 109
0 3 96 101
0 110 -1 0
0 118 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
2
519 0
537 0
4
0 0 106 110
0 1 97 102
0 111 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box2
2
519 0
537 0
4
0 0 106 110
0 4 97 102
0 111 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box3
2
519 0
537 0
4
0 0 106 110
0 2 97 102
0 111 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box4
2
519 0
537 0
4
0 0 106 110
0 5 97 102
0 111 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box5
2
519 0
537 0
4
0 0 106 110
0 3 97 102
0 111 -1 0
0 119 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
532 0
536 0
4
0 0 109 110
0 1 97 98
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
532 0
536 0
4
0 0 109 110
0 4 97 98
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
532 0
536 0
4
0 0 109 110
0 2 97 98
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box4
2
532 0
536 0
4
0 0 109 110
0 5 97 98
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box5
2
532 0
536 0
4
0 0 109 110
0 3 97 98
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
533 0
552 0
4
0 0 109 114
0 1 101 110
0 118 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box2
2
533 0
552 0
4
0 0 109 114
0 4 101 110
0 118 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box3
2
533 0
552 0
4
0 0 109 114
0 2 101 110
0 118 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box4
2
533 0
552 0
4
0 0 109 114
0 5 101 110
0 118 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box5
2
533 0
552 0
4
0 0 109 114
0 3 101 110
0 118 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
531 0
535 0
4
0 0 110 109
0 1 96 95
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box2
2
531 0
535 0
4
0 0 110 109
0 4 96 95
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box3
2
531 0
535 0
4
0 0 110 109
0 2 96 95
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box4
2
531 0
535 0
4
0 0 110 109
0 5 96 95
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box5
2
531 0
535 0
4
0 0 110 109
0 3 96 95
0 109 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
536 0
539 0
4
0 0 110 111
0 1 98 99
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
536 0
539 0
4
0 0 110 111
0 4 98 99
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
536 0
539 0
4
0 0 110 111
0 2 98 99
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box4
2
536 0
539 0
4
0 0 110 111
0 5 98 99
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box5
2
536 0
539 0
4
0 0 110 111
0 3 98 99
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
537 0
556 0
4
0 0 110 115
0 1 102 111
0 119 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
537 0
556 0
4
0 0 110 115
0 4 102 111
0 119 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
537 0
556 0
4
0 0 110 115
0 2 102 111
0 119 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box4
2
537 0
556 0
4
0 0 110 115
0 5 102 111
0 119 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box5
2
537 0
556 0
4
0 0 110 115
0 3 102 111
0 119 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
535 0
538 0
4
0 0 111 110
0 1 97 96
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
535 0
538 0
4
0 0 111 110
0 4 97 96
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
535 0
538 0
4
0 0 111 110
0 2 97 96
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box4
2
535 0
538 0
4
0 0 111 110
0 5 97 96
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box5
2
535 0
538 0
4
0 0 111 110
0 3 97 96
0 110 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
539 0
543 0
4
0 0 111 112
0 1 99 100
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
539 0
543 0
4
0 0 111 112
0 4 99 100
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box3
2
539 0
543 0
4
0 0 111 112
0 2 99 100
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box4
2
539 0
543 0
4
0 0 111 112
0 5 99 100
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box5
2
539 0
543 0
4
0 0 111 112
0 3 99 100
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
540 0
560 0
4
0 0 111 116
0 1 103 112
0 120 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
540 0
560 0
4
0 0 111 116
0 4 103 112
0 120 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
540 0
560 0
4
0 0 111 116
0 2 103 112
0 120 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box4
2
540 0
560 0
4
0 0 111 116
0 5 103 112
0 120 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box5
2
540 0
560 0
4
0 0 111 116
0 3 103 112
0 120 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
538 0
542 0
4
0 0 112 111
0 1 98 97
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
538 0
542 0
4
0 0 112 111
0 4 98 97
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
538 0
542 0
4
0 0 112 111
0 2 98 97
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box4
2
538 0
542 0
4
0 0 112 111
0 5 98 97
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box5
2
538 0
542 0
4
0 0 112 111
0 3 98 97
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
544 0
564 0
4
0 0 112 117
0 1 104 113
0 121 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
544 0
564 0
4
0 0 112 117
0 4 104 113
0 121 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
544 0
564 0
4
0 0 112 117
0 2 104 113
0 121 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box4
2
544 0
564 0
4
0 0 112 117
0 5 104 113
0 121 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box5
2
544 0
564 0
4
0 0 112 117
0 3 104 113
0 121 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
542 0
545 0
4
0 0 113 112
0 1 99 98
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
542 0
545 0
4
0 0 113 112
0 4 99 98
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box3
2
542 0
545 0
4
0 0 113 112
0 2 99 98
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box4
2
542 0
545 0
4
0 0 113 112
0 5 99 98
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box5
2
542 0
545 0
4
0 0 113 112
0 3 99 98
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
546 0
568 0
4
0 0 113 118
0 1 105 114
0 122 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box2
2
546 0
568 0
4
0 0 113 118
0 4 105 114
0 122 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box3
2
546 0
568 0
4
0 0 113 118
0 2 105 114
0 122 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box4
2
546 0
568 0
4
0 0 113 118
0 5 105 114
0 122 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box5
2
546 0
568 0
4
0 0 113 118
0 3 105 114
0 122 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box1
2
530 0
550 0
4
0 0 114 109
0 1 96 92
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box2
2
530 0
550 0
4
0 0 114 109
0 4 96 92
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box3
2
530 0
550 0
4
0 0 114 109
0 2 96 92
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box4
2
530 0
550 0
4
0 0 114 109
0 5 96 92
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box5
2
530 0
550 0
4
0 0 114 109
0 3 96 92
0 101 0 1
0 110 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
551 0
555 0
4
0 0 114 115
0 1 102 103
0 119 -1 0
0 120 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
551 0
555 0
4
0 0 114 115
0 4 102 103
0 119 -1 0
0 120 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
551 0
555 0
4
0 0 114 115
0 2 102 103
0 119 -1 0
0 120 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box4
2
551 0
555 0
4
0 0 114 115
0 5 102 103
0 119 -1 0
0 120 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box5
2
551 0
555 0
4
0 0 114 115
0 3 102 103
0 119 -1 0
0 120 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box1
2
552 0
586 0
4
0 0 114 124
0 1 110 118
0 132 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box2
2
552 0
586 0
4
0 0 114 124
0 4 110 118
0 132 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box3
2
552 0
586 0
4
0 0 114 124
0 2 110 118
0 132 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box4
2
552 0
586 0
4
0 0 114 124
0 5 110 118
0 132 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box5
2
552 0
586 0
4
0 0 114 124
0 3 110 118
0 132 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
534 0
553 0
4
0 0 115 110
0 1 97 93
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box2
2
534 0
553 0
4
0 0 115 110
0 4 97 93
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box3
2
534 0
553 0
4
0 0 115 110
0 2 97 93
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box4
2
534 0
553 0
4
0 0 115 110
0 5 97 93
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box5
2
534 0
553 0
4
0 0 115 110
0 3 97 93
0 102 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
555 0
559 0
4
0 0 115 116
0 1 103 104
0 120 -1 0
0 121 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
555 0
559 0
4
0 0 115 116
0 4 103 104
0 120 -1 0
0 121 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
555 0
559 0
4
0 0 115 116
0 2 103 104
0 120 -1 0
0 121 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box4
2
555 0
559 0
4
0 0 115 116
0 5 103 104
0 120 -1 0
0 121 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box5
2
555 0
559 0
4
0 0 115 116
0 3 103 104
0 120 -1 0
0 121 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
556 0
590 0
4
0 0 115 125
0 1 111 119
0 133 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
556 0
590 0
4
0 0 115 125
0 4 111 119
0 133 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
556 0
590 0
4
0 0 115 125
0 2 111 119
0 133 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box4
2
556 0
590 0
4
0 0 115 125
0 5 111 119
0 133 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box5
2
556 0
590 0
4
0 0 115 125
0 3 111 119
0 133 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
554 0
558 0
4
0 0 116 115
0 1 102 101
0 118 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
554 0
558 0
4
0 0 116 115
0 4 102 101
0 118 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
554 0
558 0
4
0 0 116 115
0 2 102 101
0 118 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box4
2
554 0
558 0
4
0 0 116 115
0 5 102 101
0 118 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box5
2
554 0
558 0
4
0 0 116 115
0 3 102 101
0 118 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
559 0
563 0
4
0 0 116 117
0 1 104 105
0 121 -1 0
0 122 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
559 0
563 0
4
0 0 116 117
0 4 104 105
0 121 -1 0
0 122 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
559 0
563 0
4
0 0 116 117
0 2 104 105
0 121 -1 0
0 122 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box4
2
559 0
563 0
4
0 0 116 117
0 5 104 105
0 121 -1 0
0 122 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box5
2
559 0
563 0
4
0 0 116 117
0 3 104 105
0 121 -1 0
0 122 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
541 0
561 0
4
0 0 117 112
0 1 99 94
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box2
2
541 0
561 0
4
0 0 117 112
0 4 99 94
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box3
2
541 0
561 0
4
0 0 117 112
0 2 99 94
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box4
2
541 0
561 0
4
0 0 117 112
0 5 99 94
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box5
2
541 0
561 0
4
0 0 117 112
0 3 99 94
0 103 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
558 0
562 0
4
0 0 117 116
0 1 103 102
0 119 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
558 0
562 0
4
0 0 117 116
0 4 103 102
0 119 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
558 0
562 0
4
0 0 117 116
0 2 103 102
0 119 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box4
2
558 0
562 0
4
0 0 117 116
0 5 103 102
0 119 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box5
2
558 0
562 0
4
0 0 117 116
0 3 103 102
0 119 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
563 0
567 0
4
0 0 117 118
0 1 105 106
0 122 -1 0
0 123 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box2
2
563 0
567 0
4
0 0 117 118
0 4 105 106
0 122 -1 0
0 123 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box3
2
563 0
567 0
4
0 0 117 118
0 2 105 106
0 122 -1 0
0 123 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box4
2
563 0
567 0
4
0 0 117 118
0 5 105 106
0 122 -1 0
0 123 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box5
2
563 0
567 0
4
0 0 117 118
0 3 105 106
0 122 -1 0
0 123 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
564 0
597 0
4
0 0 117 127
0 1 113 120
0 135 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
564 0
597 0
4
0 0 117 127
0 4 113 120
0 135 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
564 0
597 0
4
0 0 117 127
0 2 113 120
0 135 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box4
2
564 0
597 0
4
0 0 117 127
0 5 113 120
0 135 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box5
2
564 0
597 0
4
0 0 117 127
0 3 113 120
0 135 -1 0
0 145 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
562 0
566 0
4
0 0 118 117
0 1 104 103
0 120 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
562 0
566 0
4
0 0 118 117
0 4 104 103
0 120 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
562 0
566 0
4
0 0 118 117
0 2 104 103
0 120 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box4
2
562 0
566 0
4
0 0 118 117
0 5 104 103
0 120 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box5
2
562 0
566 0
4
0 0 118 117
0 3 104 103
0 120 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
567 0
570 0
4
0 0 118 119
0 1 106 107
0 123 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box2
2
567 0
570 0
4
0 0 118 119
0 4 106 107
0 123 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box3
2
567 0
570 0
4
0 0 118 119
0 2 106 107
0 123 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box4
2
567 0
570 0
4
0 0 118 119
0 5 106 107
0 123 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box5
2
567 0
570 0
4
0 0 118 119
0 3 106 107
0 123 -1 0
0 124 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
568 0
600 0
4
0 0 118 128
0 1 114 121
0 136 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
568 0
600 0
4
0 0 118 128
0 4 114 121
0 136 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
568 0
600 0
4
0 0 118 128
0 2 114 121
0 136 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box4
2
568 0
600 0
4
0 0 118 128
0 5 114 121
0 136 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box5
2
568 0
600 0
4
0 0 118 128
0 3 114 121
0 136 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
581 0
585 0
4
0 0 123 124
0 1 110 111
0 132 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box2
2
581 0
585 0
4
0 0 123 124
0 4 110 111
0 132 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box3
2
581 0
585 0
4
0 0 123 124
0 2 110 111
0 132 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box4
2
581 0
585 0
4
0 0 123 124
0 5 110 111
0 132 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box5
2
581 0
585 0
4
0 0 123 124
0 3 110 111
0 132 -1 0
0 133 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
582 0
614 0
4
0 0 123 131
0 1 117 128
0 142 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box2
2
582 0
614 0
4
0 0 123 131
0 4 117 128
0 142 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box3
2
582 0
614 0
4
0 0 123 131
0 2 117 128
0 142 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box4
2
582 0
614 0
4
0 0 123 131
0 5 117 128
0 142 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box5
2
582 0
614 0
4
0 0 123 131
0 3 117 128
0 142 -1 0
0 154 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
550 0
583 0
4
0 0 124 114
0 1 101 96
0 110 0 1
0 118 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box2
2
550 0
583 0
4
0 0 124 114
0 4 101 96
0 110 0 1
0 118 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box3
2
550 0
583 0
4
0 0 124 114
0 2 101 96
0 110 0 1
0 118 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box4
2
550 0
583 0
4
0 0 124 114
0 5 101 96
0 110 0 1
0 118 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box5
2
550 0
583 0
4
0 0 124 114
0 3 101 96
0 110 0 1
0 118 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
585 0
589 0
4
0 0 124 125
0 1 111 112
0 133 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box2
2
585 0
589 0
4
0 0 124 125
0 4 111 112
0 133 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box3
2
585 0
589 0
4
0 0 124 125
0 2 111 112
0 133 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box4
2
585 0
589 0
4
0 0 124 125
0 5 111 112
0 133 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box5
2
585 0
589 0
4
0 0 124 125
0 3 111 112
0 133 -1 0
0 134 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box1
2
586 0
618 0
4
0 0 124 132
0 1 118 129
0 143 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box2
2
586 0
618 0
4
0 0 124 132
0 4 118 129
0 143 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box3
2
586 0
618 0
4
0 0 124 132
0 2 118 129
0 143 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box4
2
586 0
618 0
4
0 0 124 132
0 5 118 129
0 143 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box5
2
586 0
618 0
4
0 0 124 132
0 3 118 129
0 143 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
553 0
587 0
4
0 0 125 115
0 1 102 97
0 111 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
553 0
587 0
4
0 0 125 115
0 4 102 97
0 111 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
553 0
587 0
4
0 0 125 115
0 2 102 97
0 111 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box4
2
553 0
587 0
4
0 0 125 115
0 5 102 97
0 111 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box5
2
553 0
587 0
4
0 0 125 115
0 3 102 97
0 111 0 1
0 119 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
584 0
588 0
4
0 0 125 124
0 1 110 109
0 131 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
584 0
588 0
4
0 0 125 124
0 4 110 109
0 131 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
584 0
588 0
4
0 0 125 124
0 2 110 109
0 131 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
584 0
588 0
4
0 0 125 124
0 5 110 109
0 131 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box5
2
584 0
588 0
4
0 0 125 124
0 3 110 109
0 131 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
589 0
593 0
4
0 0 125 126
0 1 112 113
0 134 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
589 0
593 0
4
0 0 125 126
0 4 112 113
0 134 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
589 0
593 0
4
0 0 125 126
0 2 112 113
0 134 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box4
2
589 0
593 0
4
0 0 125 126
0 5 112 113
0 134 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box5
2
589 0
593 0
4
0 0 125 126
0 3 112 113
0 134 -1 0
0 135 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
590 0
621 0
4
0 0 125 133
0 1 119 130
0 144 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
590 0
621 0
4
0 0 125 133
0 4 119 130
0 144 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
590 0
621 0
4
0 0 125 133
0 2 119 130
0 144 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box4
2
590 0
621 0
4
0 0 125 133
0 5 119 130
0 144 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box5
2
590 0
621 0
4
0 0 125 133
0 3 119 130
0 144 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
557 0
591 0
4
0 0 126 116
0 1 103 98
0 112 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
557 0
591 0
4
0 0 126 116
0 4 103 98
0 112 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
557 0
591 0
4
0 0 126 116
0 2 103 98
0 112 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box4
2
557 0
591 0
4
0 0 126 116
0 5 103 98
0 112 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box5
2
557 0
591 0
4
0 0 126 116
0 3 103 98
0 112 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
588 0
592 0
4
0 0 126 125
0 1 111 110
0 132 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
588 0
592 0
4
0 0 126 125
0 4 111 110
0 132 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
588 0
592 0
4
0 0 126 125
0 2 111 110
0 132 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box4
2
588 0
592 0
4
0 0 126 125
0 5 111 110
0 132 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box5
2
588 0
592 0
4
0 0 126 125
0 3 111 110
0 132 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
593 0
596 0
4
0 0 126 127
0 1 113 114
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
593 0
596 0
4
0 0 126 127
0 4 113 114
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
593 0
596 0
4
0 0 126 127
0 2 113 114
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box4
2
593 0
596 0
4
0 0 126 127
0 5 113 114
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box5
2
593 0
596 0
4
0 0 126 127
0 3 113 114
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
561 0
594 0
4
0 0 127 117
0 1 104 99
0 113 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
561 0
594 0
4
0 0 127 117
0 4 104 99
0 113 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
561 0
594 0
4
0 0 127 117
0 2 104 99
0 113 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box4
2
561 0
594 0
4
0 0 127 117
0 5 104 99
0 113 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box5
2
561 0
594 0
4
0 0 127 117
0 3 104 99
0 113 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
592 0
595 0
4
0 0 127 126
0 1 112 111
0 133 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
592 0
595 0
4
0 0 127 126
0 4 112 111
0 133 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
592 0
595 0
4
0 0 127 126
0 2 112 111
0 133 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box4
2
592 0
595 0
4
0 0 127 126
0 5 112 111
0 133 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box5
2
592 0
595 0
4
0 0 127 126
0 3 112 111
0 133 0 1
0 134 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
565 0
598 0
4
0 0 128 118
0 1 105 100
0 114 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
565 0
598 0
4
0 0 128 118
0 4 105 100
0 114 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
565 0
598 0
4
0 0 128 118
0 2 105 100
0 114 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box4
2
565 0
598 0
4
0 0 128 118
0 5 105 100
0 114 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box5
2
565 0
598 0
4
0 0 128 118
0 3 105 100
0 114 0 1
0 122 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
595 0
599 0
4
0 0 128 127
0 1 113 112
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
595 0
599 0
4
0 0 128 127
0 4 113 112
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
595 0
599 0
4
0 0 128 127
0 2 113 112
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box4
2
595 0
599 0
4
0 0 128 127
0 5 113 112
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box5
2
595 0
599 0
4
0 0 128 127
0 3 113 112
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
600 0
627 0
4
0 0 128 135
0 1 121 131
0 146 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
600 0
627 0
4
0 0 128 135
0 4 121 131
0 146 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
600 0
627 0
4
0 0 128 135
0 2 121 131
0 146 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box4
2
600 0
627 0
4
0 0 128 135
0 5 121 131
0 146 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box5
2
600 0
627 0
4
0 0 128 135
0 3 121 131
0 146 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box1
2
602 0
632 0
4
0 0 129 137
0 1 123 122
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box2
2
602 0
632 0
4
0 0 129 137
0 4 123 122
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box3
2
602 0
632 0
4
0 0 129 137
0 2 123 122
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box4
2
602 0
632 0
4
0 0 129 137
0 5 123 122
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box5
2
602 0
632 0
4
0 0 129 137
0 3 123 122
0 147 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
603 0
637 0
4
0 0 129 138
0 1 124 134
0 149 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
603 0
637 0
4
0 0 129 138
0 4 124 134
0 149 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box3
2
603 0
637 0
4
0 0 129 138
0 2 124 134
0 149 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
603 0
637 0
4
0 0 129 138
0 5 124 134
0 149 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box5
2
603 0
637 0
4
0 0 129 138
0 3 124 134
0 149 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box1
2
613 0
617 0
4
0 0 131 132
0 1 118 119
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box2
2
613 0
617 0
4
0 0 131 132
0 4 118 119
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box3
2
613 0
617 0
4
0 0 131 132
0 2 118 119
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box4
2
613 0
617 0
4
0 0 131 132
0 5 118 119
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box5
2
613 0
617 0
4
0 0 131 132
0 3 118 119
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box1
2
614 0
648 0
4
0 0 131 142
0 1 128 140
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box2
2
614 0
648 0
4
0 0 131 142
0 4 128 140
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box3
2
614 0
648 0
4
0 0 131 142
0 2 128 140
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box4
2
614 0
648 0
4
0 0 131 142
0 5 128 140
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box5
2
614 0
648 0
4
0 0 131 142
0 3 128 140
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box1
2
583 0
615 0
4
0 0 132 124
0 1 110 101
0 118 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box2
2
583 0
615 0
4
0 0 132 124
0 4 110 101
0 118 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box3
2
583 0
615 0
4
0 0 132 124
0 2 110 101
0 118 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box4
2
583 0
615 0
4
0 0 132 124
0 5 110 101
0 118 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box5
2
583 0
615 0
4
0 0 132 124
0 3 110 101
0 118 0 1
0 132 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box1
2
618 0
652 0
4
0 0 132 143
0 1 129 141
0 155 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box2
2
618 0
652 0
4
0 0 132 143
0 4 129 141
0 155 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box3
2
618 0
652 0
4
0 0 132 143
0 2 129 141
0 155 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box4
2
618 0
652 0
4
0 0 132 143
0 5 129 141
0 155 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box5
2
618 0
652 0
4
0 0 132 143
0 3 129 141
0 155 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
587 0
619 0
4
0 0 133 125
0 1 111 102
0 119 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
587 0
619 0
4
0 0 133 125
0 4 111 102
0 119 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box3
2
587 0
619 0
4
0 0 133 125
0 2 111 102
0 119 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box4
2
587 0
619 0
4
0 0 133 125
0 5 111 102
0 119 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box5
2
587 0
619 0
4
0 0 133 125
0 3 111 102
0 119 0 1
0 133 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box1
2
616 0
620 0
4
0 0 133 132
0 1 118 117
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box2
2
616 0
620 0
4
0 0 133 132
0 4 118 117
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box3
2
616 0
620 0
4
0 0 133 132
0 2 118 117
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box4
2
616 0
620 0
4
0 0 133 132
0 5 118 117
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box5
2
616 0
620 0
4
0 0 133 132
0 3 118 117
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
621 0
655 0
4
0 0 133 144
0 1 130 142
0 156 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box2
2
621 0
655 0
4
0 0 133 144
0 4 130 142
0 156 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box3
2
621 0
655 0
4
0 0 133 144
0 2 130 142
0 156 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box4
2
621 0
655 0
4
0 0 133 144
0 5 130 142
0 156 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box5
2
621 0
655 0
4
0 0 133 144
0 3 130 142
0 156 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
594 0
622 0
4
0 0 134 127
0 1 113 104
0 121 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
594 0
622 0
4
0 0 134 127
0 4 113 104
0 121 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
594 0
622 0
4
0 0 134 127
0 2 113 104
0 121 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box4
2
594 0
622 0
4
0 0 134 127
0 5 113 104
0 121 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box5
2
594 0
622 0
4
0 0 134 127
0 3 113 104
0 121 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
623 0
626 0
4
0 0 134 135
0 1 121 122
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
623 0
626 0
4
0 0 134 135
0 4 121 122
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
623 0
626 0
4
0 0 134 135
0 2 121 122
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box4
2
623 0
626 0
4
0 0 134 135
0 5 121 122
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box5
2
623 0
626 0
4
0 0 134 135
0 3 121 122
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
598 0
624 0
4
0 0 135 128
0 1 114 105
0 122 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
598 0
624 0
4
0 0 135 128
0 4 114 105
0 122 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
598 0
624 0
4
0 0 135 128
0 2 114 105
0 122 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box4
2
598 0
624 0
4
0 0 135 128
0 5 114 105
0 122 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box5
2
598 0
624 0
4
0 0 135 128
0 3 114 105
0 122 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box1
2
626 0
629 0
4
0 0 135 136
0 1 122 123
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box2
2
626 0
629 0
4
0 0 135 136
0 4 122 123
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box3
2
626 0
629 0
4
0 0 135 136
0 2 122 123
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box4
2
626 0
629 0
4
0 0 135 136
0 5 122 123
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box5
2
626 0
629 0
4
0 0 135 136
0 3 122 123
0 147 -1 0
0 148 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
627 0
658 0
4
0 0 135 145
0 1 131 143
0 157 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
627 0
658 0
4
0 0 135 145
0 4 131 143
0 157 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
627 0
658 0
4
0 0 135 145
0 2 131 143
0 157 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box4
2
627 0
658 0
4
0 0 135 145
0 5 131 143
0 157 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box5
2
627 0
658 0
4
0 0 135 145
0 3 131 143
0 157 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
625 0
628 0
4
0 0 136 135
0 1 121 120
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
625 0
628 0
4
0 0 136 135
0 4 121 120
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
625 0
628 0
4
0 0 136 135
0 2 121 120
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box4
2
625 0
628 0
4
0 0 136 135
0 5 121 120
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box5
2
625 0
628 0
4
0 0 136 135
0 3 121 120
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box1
2
629 0
631 0
4
0 0 136 137
0 1 123 115
0 137 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box2
2
629 0
631 0
4
0 0 136 137
0 4 123 115
0 137 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box3
2
629 0
631 0
4
0 0 136 137
0 2 123 115
0 137 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box4
2
629 0
631 0
4
0 0 136 137
0 5 123 115
0 137 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box5
2
629 0
631 0
4
0 0 136 137
0 3 123 115
0 137 0 1
0 148 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box1
2
630 0
662 0
4
0 0 136 146
0 1 132 144
0 158 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box2
2
630 0
662 0
4
0 0 136 146
0 4 132 144
0 158 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box3
2
630 0
662 0
4
0 0 136 146
0 2 132 144
0 158 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box4
2
630 0
662 0
4
0 0 136 146
0 5 132 144
0 158 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box5
2
630 0
662 0
4
0 0 136 146
0 3 132 144
0 158 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box1
2
628 0
632 0
4
0 0 137 136
0 1 122 121
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box2
2
628 0
632 0
4
0 0 137 136
0 4 122 121
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box3
2
628 0
632 0
4
0 0 137 136
0 2 122 121
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box4
2
628 0
632 0
4
0 0 137 136
0 5 122 121
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box5
2
628 0
632 0
4
0 0 137 136
0 3 122 121
0 146 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box1
2
633 0
666 0
4
0 0 137 147
0 1 133 145
0 159 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box2
2
633 0
666 0
4
0 0 137 147
0 4 133 145
0 159 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box3
2
633 0
666 0
4
0 0 137 147
0 2 133 145
0 159 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box4
2
633 0
666 0
4
0 0 137 147
0 5 133 145
0 159 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box5
2
633 0
666 0
4
0 0 137 147
0 3 133 145
0 159 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
601 0
634 0
4
0 0 138 129
0 1 115 108
0 125 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box2
2
601 0
634 0
4
0 0 138 129
0 4 115 108
0 125 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box3
2
601 0
634 0
4
0 0 138 129
0 2 115 108
0 125 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box4
2
601 0
634 0
4
0 0 138 129
0 5 115 108
0 125 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box5
2
601 0
634 0
4
0 0 138 129
0 3 115 108
0 125 0 1
0 137 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box1
2
635 0
639 0
4
0 0 138 139
0 1 125 126
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box2
2
635 0
639 0
4
0 0 138 139
0 4 125 126
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box3
2
635 0
639 0
4
0 0 138 139
0 2 125 126
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box4
2
635 0
639 0
4
0 0 138 139
0 5 125 126
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box5
2
635 0
639 0
4
0 0 138 139
0 3 125 126
0 150 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
636 0
665 0
4
0 0 138 147
0 1 133 132
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
636 0
665 0
4
0 0 138 147
0 4 133 132
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box3
2
636 0
665 0
4
0 0 138 147
0 2 133 132
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box4
2
636 0
665 0
4
0 0 138 147
0 5 133 132
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box5
2
636 0
665 0
4
0 0 138 147
0 3 133 132
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
637 0
670 0
4
0 0 138 148
0 1 134 146
0 160 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
637 0
670 0
4
0 0 138 148
0 4 134 146
0 160 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
637 0
670 0
4
0 0 138 148
0 2 134 146
0 160 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
637 0
670 0
4
0 0 138 148
0 5 134 146
0 160 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box5
2
637 0
670 0
4
0 0 138 148
0 3 134 146
0 160 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
636 0
638 0
4
0 0 139 138
0 1 124 133
0 149 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
636 0
638 0
4
0 0 139 138
0 4 124 133
0 149 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
636 0
638 0
4
0 0 139 138
0 2 124 133
0 149 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
636 0
638 0
4
0 0 139 138
0 5 124 133
0 149 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box5
2
636 0
638 0
4
0 0 139 138
0 3 124 133
0 149 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
640 0
674 0
4
0 0 139 149
0 1 135 147
0 161 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
640 0
674 0
4
0 0 139 149
0 4 135 147
0 161 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
640 0
674 0
4
0 0 139 149
0 2 135 147
0 161 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
640 0
674 0
4
0 0 139 149
0 5 135 147
0 161 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box5
2
640 0
674 0
4
0 0 139 149
0 3 135 147
0 161 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box1
2
638 0
642 0
4
0 0 140 139
0 1 125 124
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box2
2
638 0
642 0
4
0 0 140 139
0 4 125 124
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box3
2
638 0
642 0
4
0 0 140 139
0 2 125 124
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box4
2
638 0
642 0
4
0 0 140 139
0 5 125 124
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box5
2
638 0
642 0
4
0 0 140 139
0 3 125 124
0 149 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box1
2
612 0
646 0
4
0 0 142 131
0 1 117 109
0 131 0 1
0 142 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box2
2
612 0
646 0
4
0 0 142 131
0 4 117 109
0 131 0 1
0 142 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box3
2
612 0
646 0
4
0 0 142 131
0 2 117 109
0 131 0 1
0 142 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box4
2
612 0
646 0
4
0 0 142 131
0 5 117 109
0 131 0 1
0 142 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box5
2
612 0
646 0
4
0 0 142 131
0 3 117 109
0 131 0 1
0 142 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box1
2
647 0
651 0
4
0 0 142 143
0 1 129 130
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box2
2
647 0
651 0
4
0 0 142 143
0 4 129 130
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box3
2
647 0
651 0
4
0 0 142 143
0 2 129 130
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box4
2
647 0
651 0
4
0 0 142 143
0 5 129 130
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box5
2
647 0
651 0
4
0 0 142 143
0 3 129 130
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box1
2
615 0
649 0
4
0 0 143 132
0 1 118 110
0 132 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box2
2
615 0
649 0
4
0 0 143 132
0 4 118 110
0 132 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box3
2
615 0
649 0
4
0 0 143 132
0 2 118 110
0 132 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box4
2
615 0
649 0
4
0 0 143 132
0 5 118 110
0 132 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box5
2
615 0
649 0
4
0 0 143 132
0 3 118 110
0 132 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box1
2
652 0
693 0
4
0 0 143 156
0 1 141 152
0 168 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box2
2
652 0
693 0
4
0 0 143 156
0 4 141 152
0 168 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box3
2
652 0
693 0
4
0 0 143 156
0 2 141 152
0 168 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box4
2
652 0
693 0
4
0 0 143 156
0 5 141 152
0 168 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box5
2
652 0
693 0
4
0 0 143 156
0 3 141 152
0 168 -1 0
0 180 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
619 0
653 0
4
0 0 144 133
0 1 119 111
0 133 0 1
0 144 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
619 0
653 0
4
0 0 144 133
0 4 119 111
0 133 0 1
0 144 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box3
2
619 0
653 0
4
0 0 144 133
0 2 119 111
0 133 0 1
0 144 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box4
2
619 0
653 0
4
0 0 144 133
0 5 119 111
0 133 0 1
0 144 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box5
2
619 0
653 0
4
0 0 144 133
0 3 119 111
0 133 0 1
0 144 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box1
2
650 0
654 0
4
0 0 144 143
0 1 129 128
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box2
2
650 0
654 0
4
0 0 144 143
0 4 129 128
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box3
2
650 0
654 0
4
0 0 144 143
0 2 129 128
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box4
2
650 0
654 0
4
0 0 144 143
0 5 129 128
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box5
2
650 0
654 0
4
0 0 144 143
0 3 129 128
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
655 0
696 0
4
0 0 144 157
0 1 142 153
0 169 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
655 0
696 0
4
0 0 144 157
0 4 142 153
0 169 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box3
2
655 0
696 0
4
0 0 144 157
0 2 142 153
0 169 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box4
2
655 0
696 0
4
0 0 144 157
0 5 142 153
0 169 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box5
2
655 0
696 0
4
0 0 144 157
0 3 142 153
0 169 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
624 0
656 0
4
0 0 145 135
0 1 121 114
0 136 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
624 0
656 0
4
0 0 145 135
0 4 121 114
0 136 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
624 0
656 0
4
0 0 145 135
0 2 121 114
0 136 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box4
2
624 0
656 0
4
0 0 145 135
0 5 121 114
0 136 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box5
2
624 0
656 0
4
0 0 145 135
0 3 121 114
0 136 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
657 0
661 0
4
0 0 145 146
0 1 132 133
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
657 0
661 0
4
0 0 145 146
0 4 132 133
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
657 0
661 0
4
0 0 145 146
0 2 132 133
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box4
2
657 0
661 0
4
0 0 145 146
0 5 132 133
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box5
2
657 0
661 0
4
0 0 145 146
0 3 132 133
0 158 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
658 0
699 0
4
0 0 145 158
0 1 143 156
0 170 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
658 0
699 0
4
0 0 145 158
0 4 143 156
0 170 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
658 0
699 0
4
0 0 145 158
0 2 143 156
0 170 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box4
2
658 0
699 0
4
0 0 145 158
0 5 143 156
0 170 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box5
2
658 0
699 0
4
0 0 145 158
0 3 143 156
0 170 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
661 0
664 0
4
0 0 146 147
0 1 133 124
0 149 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
661 0
664 0
4
0 0 146 147
0 4 133 124
0 149 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box3
2
661 0
664 0
4
0 0 146 147
0 2 133 124
0 149 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box4
2
661 0
664 0
4
0 0 146 147
0 5 133 124
0 149 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box5
2
661 0
664 0
4
0 0 146 147
0 3 133 124
0 149 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box1
2
662 0
703 0
4
0 0 146 159
0 1 144 157
0 171 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box2
2
662 0
703 0
4
0 0 146 159
0 4 144 157
0 171 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box3
2
662 0
703 0
4
0 0 146 159
0 2 144 157
0 171 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box4
2
662 0
703 0
4
0 0 146 159
0 5 144 157
0 171 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box5
2
662 0
703 0
4
0 0 146 159
0 3 144 157
0 171 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
635 0
664 0
4
0 0 147 138
0 1 124 125
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
635 0
664 0
4
0 0 147 138
0 4 124 125
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
635 0
664 0
4
0 0 147 138
0 2 124 125
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
635 0
664 0
4
0 0 147 138
0 5 124 125
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box5
2
635 0
664 0
4
0 0 147 138
0 3 124 125
0 149 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
660 0
665 0
4
0 0 147 146
0 1 132 131
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
660 0
665 0
4
0 0 147 146
0 4 132 131
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
660 0
665 0
4
0 0 147 146
0 2 132 131
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box4
2
660 0
665 0
4
0 0 147 146
0 5 132 131
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box5
2
660 0
665 0
4
0 0 147 146
0 3 132 131
0 157 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
666 0
707 0
4
0 0 147 160
0 1 145 158
0 172 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
666 0
707 0
4
0 0 147 160
0 4 145 158
0 172 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
666 0
707 0
4
0 0 147 160
0 2 145 158
0 172 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
666 0
707 0
4
0 0 147 160
0 5 145 158
0 172 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box5
2
666 0
707 0
4
0 0 147 160
0 3 145 158
0 172 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
634 0
667 0
4
0 0 148 138
0 1 124 115
0 137 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
634 0
667 0
4
0 0 148 138
0 4 124 115
0 137 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box3
2
634 0
667 0
4
0 0 148 138
0 2 124 115
0 137 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
634 0
667 0
4
0 0 148 138
0 5 124 115
0 137 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box5
2
634 0
667 0
4
0 0 148 138
0 3 124 115
0 137 0 1
0 149 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box1
2
668 0
673 0
4
0 0 148 149
0 1 135 136
0 161 -1 0
0 162 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box2
2
668 0
673 0
4
0 0 148 149
0 4 135 136
0 161 -1 0
0 162 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box3
2
668 0
673 0
4
0 0 148 149
0 2 135 136
0 161 -1 0
0 162 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box4
2
668 0
673 0
4
0 0 148 149
0 5 135 136
0 161 -1 0
0 162 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box5
2
668 0
673 0
4
0 0 148 149
0 3 135 136
0 161 -1 0
0 162 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
669 0
706 0
4
0 0 148 160
0 1 145 144
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
669 0
706 0
4
0 0 148 160
0 4 145 144
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box3
2
669 0
706 0
4
0 0 148 160
0 2 145 144
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box4
2
669 0
706 0
4
0 0 148 160
0 5 145 144
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box5
2
669 0
706 0
4
0 0 148 160
0 3 145 144
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
670 0
708 0
4
0 0 148 161
0 1 146 0
0 173 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
670 0
708 0
4
0 0 148 161
0 4 146 0
0 173 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
670 0
708 0
4
0 0 148 161
0 2 146 0
0 173 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
670 0
708 0
4
0 0 148 161
0 5 146 0
0 173 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box5
2
670 0
708 0
4
0 0 148 161
0 3 146 0
0 173 -1 0
0 187 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
669 0
672 0
4
0 0 149 148
0 1 134 145
0 160 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
669 0
672 0
4
0 0 149 148
0 4 134 145
0 160 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
669 0
672 0
4
0 0 149 148
0 2 134 145
0 160 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
669 0
672 0
4
0 0 149 148
0 5 134 145
0 160 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box5
2
669 0
672 0
4
0 0 149 148
0 3 134 145
0 160 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box1
2
673 0
677 0
4
0 0 149 150
0 1 136 137
0 162 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box2
2
673 0
677 0
4
0 0 149 150
0 4 136 137
0 162 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box3
2
673 0
677 0
4
0 0 149 150
0 2 136 137
0 162 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box4
2
673 0
677 0
4
0 0 149 150
0 5 136 137
0 162 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box5
2
673 0
677 0
4
0 0 149 150
0 3 136 137
0 162 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
674 0
712 0
4
0 0 149 162
0 1 147 1
0 174 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
674 0
712 0
4
0 0 149 162
0 4 147 1
0 174 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
674 0
712 0
4
0 0 149 162
0 2 147 1
0 174 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box4
2
674 0
712 0
4
0 0 149 162
0 5 147 1
0 174 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box5
2
674 0
712 0
4
0 0 149 162
0 3 147 1
0 174 -1 0
0 188 0 1
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box1
2
641 0
675 0
4
0 0 150 140
0 1 126 116
0 138 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box2
2
641 0
675 0
4
0 0 150 140
0 4 126 116
0 138 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box3
2
641 0
675 0
4
0 0 150 140
0 2 126 116
0 138 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box4
2
641 0
675 0
4
0 0 150 140
0 5 126 116
0 138 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box5
2
641 0
675 0
4
0 0 150 140
0 3 126 116
0 138 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box1
2
672 0
676 0
4
0 0 150 149
0 1 135 134
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box2
2
672 0
676 0
4
0 0 150 149
0 4 135 134
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box3
2
672 0
676 0
4
0 0 150 149
0 2 135 134
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box4
2
672 0
676 0
4
0 0 150 149
0 5 135 134
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box5
2
672 0
676 0
4
0 0 150 149
0 3 135 134
0 160 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box1
2
676 0
678 0
4
0 0 151 150
0 1 136 135
0 161 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box2
2
676 0
678 0
4
0 0 151 150
0 4 136 135
0 161 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box3
2
676 0
678 0
4
0 0 151 150
0 2 136 135
0 161 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box4
2
676 0
678 0
4
0 0 151 150
0 5 136 135
0 161 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box5
2
676 0
678 0
4
0 0 151 150
0 3 136 135
0 161 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box1
2
679 0
715 0
4
0 0 151 163
0 1 148 3
0 175 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box2
2
679 0
715 0
4
0 0 151 163
0 4 148 3
0 175 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box3
2
679 0
715 0
4
0 0 151 163
0 2 148 3
0 175 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box4
2
679 0
715 0
4
0 0 151 163
0 5 148 3
0 175 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box5
2
679 0
715 0
4
0 0 151 163
0 3 148 3
0 175 -1 0
0 190 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box1
2
682 0
717 0
4
0 0 152 164
0 1 149 5
0 176 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box2
2
682 0
717 0
4
0 0 152 164
0 4 149 5
0 176 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box3
2
682 0
717 0
4
0 0 152 164
0 2 149 5
0 176 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box4
2
682 0
717 0
4
0 0 152 164
0 5 149 5
0 176 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_8_15 loc_9_15 loc_10_15 down box5
2
682 0
717 0
4
0 0 152 164
0 3 149 5
0 176 -1 0
0 192 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box1
2
687 0
724 0
4
0 0 154 166
0 1 150 7
0 178 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box2
2
687 0
724 0
4
0 0 154 166
0 4 150 7
0 178 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box3
2
687 0
724 0
4
0 0 154 166
0 2 150 7
0 178 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box4
2
687 0
724 0
4
0 0 154 166
0 5 150 7
0 178 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box5
2
687 0
724 0
4
0 0 154 166
0 3 150 7
0 178 -1 0
0 194 0 1
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box1
2
646 0
688 0
4
0 0 155 142
0 1 128 117
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box2
2
646 0
688 0
4
0 0 155 142
0 4 128 117
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box3
2
646 0
688 0
4
0 0 155 142
0 2 128 117
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box4
2
646 0
688 0
4
0 0 155 142
0 5 128 117
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box5
2
646 0
688 0
4
0 0 155 142
0 3 128 117
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box1
2
689 0
692 0
4
0 0 155 156
0 1 141 142
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box2
2
689 0
692 0
4
0 0 155 156
0 4 141 142
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box3
2
689 0
692 0
4
0 0 155 156
0 2 141 142
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box4
2
689 0
692 0
4
0 0 155 156
0 5 141 142
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box5
2
689 0
692 0
4
0 0 155 156
0 3 141 142
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box1
2
649 0
690 0
4
0 0 156 143
0 1 129 118
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box2
2
649 0
690 0
4
0 0 156 143
0 4 129 118
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box3
2
649 0
690 0
4
0 0 156 143
0 2 129 118
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box4
2
649 0
690 0
4
0 0 156 143
0 5 129 118
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box5
2
649 0
690 0
4
0 0 156 143
0 3 129 118
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box1
2
693 0
728 0
4
0 0 156 168
0 1 152 11
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box2
2
693 0
728 0
4
0 0 156 168
0 4 152 11
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box3
2
693 0
728 0
4
0 0 156 168
0 2 152 11
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box4
2
693 0
728 0
4
0 0 156 168
0 5 152 11
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box5
2
693 0
728 0
4
0 0 156 168
0 3 152 11
0 180 -1 0
0 198 0 1
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
653 0
694 0
4
0 0 157 144
0 1 130 119
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box2
2
653 0
694 0
4
0 0 157 144
0 4 130 119
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box3
2
653 0
694 0
4
0 0 157 144
0 2 130 119
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box4
2
653 0
694 0
4
0 0 157 144
0 5 130 119
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box5
2
653 0
694 0
4
0 0 157 144
0 3 130 119
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box1
2
691 0
695 0
4
0 0 157 156
0 1 141 140
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box2
2
691 0
695 0
4
0 0 157 156
0 4 141 140
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box3
2
691 0
695 0
4
0 0 157 156
0 2 141 140
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box4
2
691 0
695 0
4
0 0 157 156
0 5 141 140
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box5
2
691 0
695 0
4
0 0 157 156
0 3 141 140
0 167 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box1
2
696 0
731 0
4
0 0 157 169
0 1 153 12
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box2
2
696 0
731 0
4
0 0 157 169
0 4 153 12
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box3
2
696 0
731 0
4
0 0 157 169
0 2 153 12
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box4
2
696 0
731 0
4
0 0 157 169
0 5 153 12
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box5
2
696 0
731 0
4
0 0 157 169
0 3 153 12
0 181 -1 0
0 199 0 1
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
656 0
697 0
4
0 0 158 145
0 1 131 121
0 146 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
656 0
697 0
4
0 0 158 145
0 4 131 121
0 146 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
656 0
697 0
4
0 0 158 145
0 2 131 121
0 146 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box4
2
656 0
697 0
4
0 0 158 145
0 5 131 121
0 146 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box5
2
656 0
697 0
4
0 0 158 145
0 3 131 121
0 146 0 1
0 157 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
698 0
702 0
4
0 0 158 159
0 1 144 145
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
698 0
702 0
4
0 0 158 159
0 4 144 145
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box3
2
698 0
702 0
4
0 0 158 159
0 2 144 145
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box4
2
698 0
702 0
4
0 0 158 159
0 5 144 145
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box5
2
698 0
702 0
4
0 0 158 159
0 3 144 145
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
699 0
741 0
4
0 0 158 172
0 1 156 15
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
699 0
741 0
4
0 0 158 172
0 4 156 15
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
699 0
741 0
4
0 0 158 172
0 2 156 15
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box4
2
699 0
741 0
4
0 0 158 172
0 5 156 15
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box5
2
699 0
741 0
4
0 0 158 172
0 3 156 15
0 184 -1 0
0 202 0 1
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box1
2
659 0
700 0
4
0 0 159 146
0 1 132 122
0 147 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box2
2
659 0
700 0
4
0 0 159 146
0 4 132 122
0 147 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box3
2
659 0
700 0
4
0 0 159 146
0 2 132 122
0 147 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box4
2
659 0
700 0
4
0 0 159 146
0 5 132 122
0 147 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box5
2
659 0
700 0
4
0 0 159 146
0 3 132 122
0 147 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
702 0
705 0
4
0 0 159 160
0 1 145 134
0 160 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
702 0
705 0
4
0 0 159 160
0 4 145 134
0 160 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box3
2
702 0
705 0
4
0 0 159 160
0 2 145 134
0 160 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box4
2
702 0
705 0
4
0 0 159 160
0 5 145 134
0 160 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box5
2
702 0
705 0
4
0 0 159 160
0 3 145 134
0 160 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box1
2
703 0
745 0
4
0 0 159 173
0 1 157 16
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box2
2
703 0
745 0
4
0 0 159 173
0 4 157 16
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box3
2
703 0
745 0
4
0 0 159 173
0 2 157 16
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box4
2
703 0
745 0
4
0 0 159 173
0 5 157 16
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box5
2
703 0
745 0
4
0 0 159 173
0 3 157 16
0 185 -1 0
0 203 0 1
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box1
2
663 0
704 0
4
0 0 160 147
0 1 133 123
0 148 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box2
2
663 0
704 0
4
0 0 160 147
0 4 133 123
0 148 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box3
2
663 0
704 0
4
0 0 160 147
0 2 133 123
0 148 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box4
2
663 0
704 0
4
0 0 160 147
0 5 133 123
0 148 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box5
2
663 0
704 0
4
0 0 160 147
0 3 133 123
0 148 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
668 0
705 0
4
0 0 160 148
0 1 134 135
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
668 0
705 0
4
0 0 160 148
0 4 134 135
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
668 0
705 0
4
0 0 160 148
0 2 134 135
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
668 0
705 0
4
0 0 160 148
0 5 134 135
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box5
2
668 0
705 0
4
0 0 160 148
0 3 134 135
0 160 -1 0
0 161 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
701 0
706 0
4
0 0 160 159
0 1 144 143
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
701 0
706 0
4
0 0 160 159
0 4 144 143
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box3
2
701 0
706 0
4
0 0 160 159
0 2 144 143
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box4
2
701 0
706 0
4
0 0 160 159
0 5 144 143
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box5
2
701 0
706 0
4
0 0 160 159
0 3 144 143
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box1
2
707 0
749 0
4
0 0 160 174
0 1 158 17
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box2
2
707 0
749 0
4
0 0 160 174
0 4 158 17
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box3
2
707 0
749 0
4
0 0 160 174
0 2 158 17
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box4
2
707 0
749 0
4
0 0 160 174
0 5 158 17
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box5
2
707 0
749 0
4
0 0 160 174
0 3 158 17
0 186 -1 0
0 204 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box1
2
215 0
708 0
4
0 0 161 0
0 1 0 18
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box2
2
215 0
708 0
4
0 0 161 0
0 4 0 18
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box3
2
215 0
708 0
4
0 0 161 0
0 2 0 18
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box4
2
215 0
708 0
4
0 0 161 0
0 5 0 18
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box5
2
215 0
708 0
4
0 0 161 0
0 3 0 18
0 187 -1 0
0 205 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
667 0
709 0
4
0 0 161 148
0 1 134 124
0 149 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
667 0
709 0
4
0 0 161 148
0 4 134 124
0 149 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
667 0
709 0
4
0 0 161 148
0 2 134 124
0 149 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
667 0
709 0
4
0 0 161 148
0 5 134 124
0 149 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box5
2
667 0
709 0
4
0 0 161 148
0 3 134 124
0 149 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
711 0
752 0
4
0 0 161 174
0 1 158 157
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
711 0
752 0
4
0 0 161 174
0 4 158 157
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
711 0
752 0
4
0 0 161 174
0 2 158 157
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
711 0
752 0
4
0 0 161 174
0 5 158 157
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box5
2
711 0
752 0
4
0 0 161 174
0 3 158 157
0 185 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box1
2
219 0
712 0
4
0 0 162 1
0 1 1 19
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box2
2
219 0
712 0
4
0 0 162 1
0 4 1 19
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box3
2
219 0
712 0
4
0 0 162 1
0 2 1 19
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box4
2
219 0
712 0
4
0 0 162 1
0 5 1 19
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box5
2
219 0
712 0
4
0 0 162 1
0 3 1 19
0 188 -1 0
0 206 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
671 0
713 0
4
0 0 162 149
0 1 135 125
0 150 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
671 0
713 0
4
0 0 162 149
0 4 135 125
0 150 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
671 0
713 0
4
0 0 162 149
0 2 135 125
0 150 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
671 0
713 0
4
0 0 162 149
0 5 135 125
0 150 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box5
2
671 0
713 0
4
0 0 162 149
0 3 135 125
0 150 0 1
0 161 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
711 0
714 0
4
0 0 162 161
0 1 146 158
0 173 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
711 0
714 0
4
0 0 162 161
0 4 146 158
0 173 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
711 0
714 0
4
0 0 162 161
0 2 146 158
0 173 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box4
2
711 0
714 0
4
0 0 162 161
0 5 146 158
0 173 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box5
2
711 0
714 0
4
0 0 162 161
0 3 146 158
0 173 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_13 loc_10_13 loc_11_13 down box1
2
225 0
715 0
4
0 0 163 3
0 1 3 20
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_9_13 loc_10_13 loc_11_13 down box2
2
225 0
715 0
4
0 0 163 3
0 4 3 20
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_9_13 loc_10_13 loc_11_13 down box3
2
225 0
715 0
4
0 0 163 3
0 2 3 20
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_9_13 loc_10_13 loc_11_13 down box4
2
225 0
715 0
4
0 0 163 3
0 5 3 20
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_9_13 loc_10_13 loc_11_13 down box5
2
225 0
715 0
4
0 0 163 3
0 3 3 20
0 190 -1 0
0 207 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box1
2
232 0
717 0
4
0 0 164 5
0 1 5 22
0 192 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box2
2
232 0
717 0
4
0 0 164 5
0 4 5 22
0 192 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box3
2
232 0
717 0
4
0 0 164 5
0 2 5 22
0 192 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box4
2
232 0
717 0
4
0 0 164 5
0 5 5 22
0 192 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_9_15 loc_10_15 loc_11_15 down box5
2
232 0
717 0
4
0 0 164 5
0 3 5 22
0 192 -1 0
0 209 0 1
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box1
2
680 0
718 0
4
0 0 164 152
0 1 138 127
0 152 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box2
2
680 0
718 0
4
0 0 164 152
0 4 138 127
0 152 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box3
2
680 0
718 0
4
0 0 164 152
0 2 138 127
0 152 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box4
2
680 0
718 0
4
0 0 164 152
0 5 138 127
0 152 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_8_15 loc_7_15 up box5
2
680 0
718 0
4
0 0 164 152
0 3 138 127
0 152 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box1
2
239 0
724 0
4
0 0 166 7
0 1 7 23
0 194 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box2
2
239 0
724 0
4
0 0 166 7
0 4 7 23
0 194 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box3
2
239 0
724 0
4
0 0 166 7
0 2 7 23
0 194 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box4
2
239 0
724 0
4
0 0 166 7
0 5 7 23
0 194 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box5
2
239 0
724 0
4
0 0 166 7
0 3 7 23
0 194 -1 0
0 210 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box1
2
251 0
728 0
4
0 0 168 11
0 1 11 26
0 7 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box2
2
251 0
728 0
4
0 0 168 11
0 4 11 26
0 7 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box3
2
251 0
728 0
4
0 0 168 11
0 2 11 26
0 7 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box4
2
251 0
728 0
4
0 0 168 11
0 5 11 26
0 7 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box5
2
251 0
728 0
4
0 0 168 11
0 3 11 26
0 7 0 1
0 198 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box1
2
690 0
729 0
4
0 0 168 156
0 1 141 129
0 155 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box2
2
690 0
729 0
4
0 0 168 156
0 4 141 129
0 155 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box3
2
690 0
729 0
4
0 0 168 156
0 2 141 129
0 155 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box4
2
690 0
729 0
4
0 0 168 156
0 5 141 129
0 155 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box5
2
690 0
729 0
4
0 0 168 156
0 3 141 129
0 155 0 1
0 168 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
730 0
734 0
4
0 0 168 169
0 1 153 154
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
730 0
734 0
4
0 0 168 169
0 4 153 154
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
730 0
734 0
4
0 0 168 169
0 2 153 154
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box4
2
730 0
734 0
4
0 0 168 169
0 5 153 154
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box5
2
730 0
734 0
4
0 0 168 169
0 3 153 154
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
694 0
732 0
4
0 0 169 157
0 1 142 130
0 156 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
694 0
732 0
4
0 0 169 157
0 4 142 130
0 156 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box3
2
694 0
732 0
4
0 0 169 157
0 2 142 130
0 156 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box4
2
694 0
732 0
4
0 0 169 157
0 5 142 130
0 156 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box5
2
694 0
732 0
4
0 0 169 157
0 3 142 130
0 156 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
734 0
737 0
4
0 0 169 170
0 1 154 155
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
734 0
737 0
4
0 0 169 170
0 4 154 155
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
734 0
737 0
4
0 0 169 170
0 2 154 155
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box4
2
734 0
737 0
4
0 0 169 170
0 5 154 155
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box5
2
734 0
737 0
4
0 0 169 170
0 3 154 155
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
258 0
735 0
4
0 0 170 13
0 1 13 27
0 8 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
258 0
735 0
4
0 0 170 13
0 4 13 27
0 8 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
258 0
735 0
4
0 0 170 13
0 2 13 27
0 8 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box4
2
258 0
735 0
4
0 0 170 13
0 5 13 27
0 8 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box5
2
258 0
735 0
4
0 0 170 13
0 3 13 27
0 8 0 1
0 200 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
733 0
736 0
4
0 0 170 169
0 1 153 152
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
733 0
736 0
4
0 0 170 169
0 4 153 152
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
733 0
736 0
4
0 0 170 169
0 2 153 152
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box4
2
733 0
736 0
4
0 0 170 169
0 5 153 152
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box5
2
733 0
736 0
4
0 0 170 169
0 3 153 152
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
737 0
740 0
4
0 0 170 171
0 1 155 156
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
737 0
740 0
4
0 0 170 171
0 4 155 156
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
737 0
740 0
4
0 0 170 171
0 2 155 156
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box4
2
737 0
740 0
4
0 0 170 171
0 5 155 156
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box5
2
737 0
740 0
4
0 0 170 171
0 3 155 156
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box1
2
262 0
738 0
4
0 0 171 14
0 1 14 28
0 9 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box2
2
262 0
738 0
4
0 0 171 14
0 4 14 28
0 9 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box3
2
262 0
738 0
4
0 0 171 14
0 2 14 28
0 9 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box4
2
262 0
738 0
4
0 0 171 14
0 5 14 28
0 9 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box5
2
262 0
738 0
4
0 0 171 14
0 3 14 28
0 9 0 1
0 201 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
736 0
739 0
4
0 0 171 170
0 1 154 153
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
736 0
739 0
4
0 0 171 170
0 4 154 153
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
736 0
739 0
4
0 0 171 170
0 2 154 153
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box4
2
736 0
739 0
4
0 0 171 170
0 5 154 153
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box5
2
736 0
739 0
4
0 0 171 170
0 3 154 153
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
740 0
744 0
4
0 0 171 172
0 1 156 157
0 184 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
740 0
744 0
4
0 0 171 172
0 4 156 157
0 184 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
740 0
744 0
4
0 0 171 172
0 2 156 157
0 184 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
740 0
744 0
4
0 0 171 172
0 5 156 157
0 184 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box5
2
740 0
744 0
4
0 0 171 172
0 3 156 157
0 184 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
266 0
741 0
4
0 0 172 15
0 1 15 29
0 10 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
266 0
741 0
4
0 0 172 15
0 4 15 29
0 10 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
266 0
741 0
4
0 0 172 15
0 2 15 29
0 10 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box4
2
266 0
741 0
4
0 0 172 15
0 5 15 29
0 10 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box5
2
266 0
741 0
4
0 0 172 15
0 3 15 29
0 10 0 1
0 202 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
697 0
742 0
4
0 0 172 158
0 1 143 131
0 157 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
697 0
742 0
4
0 0 172 158
0 4 143 131
0 157 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
697 0
742 0
4
0 0 172 158
0 2 143 131
0 157 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box4
2
697 0
742 0
4
0 0 172 158
0 5 143 131
0 157 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box5
2
697 0
742 0
4
0 0 172 158
0 3 143 131
0 157 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
739 0
743 0
4
0 0 172 171
0 1 155 154
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
739 0
743 0
4
0 0 172 171
0 4 155 154
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
739 0
743 0
4
0 0 172 171
0 2 155 154
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box4
2
739 0
743 0
4
0 0 172 171
0 5 155 154
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box5
2
739 0
743 0
4
0 0 172 171
0 3 155 154
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
744 0
748 0
4
0 0 172 173
0 1 157 158
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
744 0
748 0
4
0 0 172 173
0 4 157 158
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
744 0
748 0
4
0 0 172 173
0 2 157 158
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
744 0
748 0
4
0 0 172 173
0 5 157 158
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box5
2
744 0
748 0
4
0 0 172 173
0 3 157 158
0 185 -1 0
0 186 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box1
2
270 0
745 0
4
0 0 173 16
0 1 16 30
0 11 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box2
2
270 0
745 0
4
0 0 173 16
0 4 16 30
0 11 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box3
2
270 0
745 0
4
0 0 173 16
0 2 16 30
0 11 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box4
2
270 0
745 0
4
0 0 173 16
0 5 16 30
0 11 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box5
2
270 0
745 0
4
0 0 173 16
0 3 16 30
0 11 0 1
0 203 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box1
2
700 0
746 0
4
0 0 173 159
0 1 144 132
0 158 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box2
2
700 0
746 0
4
0 0 173 159
0 4 144 132
0 158 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box3
2
700 0
746 0
4
0 0 173 159
0 2 144 132
0 158 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box4
2
700 0
746 0
4
0 0 173 159
0 5 144 132
0 158 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box5
2
700 0
746 0
4
0 0 173 159
0 3 144 132
0 158 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
743 0
747 0
4
0 0 173 172
0 1 156 155
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
743 0
747 0
4
0 0 173 172
0 4 156 155
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
743 0
747 0
4
0 0 173 172
0 2 156 155
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
743 0
747 0
4
0 0 173 172
0 5 156 155
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box5
2
743 0
747 0
4
0 0 173 172
0 3 156 155
0 183 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
748 0
751 0
4
0 0 173 174
0 1 158 146
0 173 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
748 0
751 0
4
0 0 173 174
0 4 158 146
0 173 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
748 0
751 0
4
0 0 173 174
0 2 158 146
0 173 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
748 0
751 0
4
0 0 173 174
0 5 158 146
0 173 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box5
2
748 0
751 0
4
0 0 173 174
0 3 158 146
0 173 0 1
0 186 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
704 0
750 0
4
0 0 174 160
0 1 145 133
0 159 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
704 0
750 0
4
0 0 174 160
0 4 145 133
0 159 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
704 0
750 0
4
0 0 174 160
0 2 145 133
0 159 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
704 0
750 0
4
0 0 174 160
0 5 145 133
0 159 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box5
2
704 0
750 0
4
0 0 174 160
0 3 145 133
0 159 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
710 0
751 0
4
0 0 174 161
0 1 146 147
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
710 0
751 0
4
0 0 174 161
0 4 146 147
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
710 0
751 0
4
0 0 174 161
0 2 146 147
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
710 0
751 0
4
0 0 174 161
0 5 146 147
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box5
2
710 0
751 0
4
0 0 174 161
0 3 146 147
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
747 0
752 0
4
0 0 174 173
0 1 157 156
0 184 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
747 0
752 0
4
0 0 174 173
0 4 157 156
0 184 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
747 0
752 0
4
0 0 174 173
0 2 157 156
0 184 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
747 0
752 0
4
0 0 174 173
0 5 157 156
0 184 0 1
0 185 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box5
2
747 0
752 0
4
0 0 174 173
0 3 157 156
0 184 0 1
0 185 -1 0
1
end_operator
0
