begin_version
3
end_version
begin_metric
1
end_metric
88
begin_variable
var0
-1
20
at-robot loc_2_6
at-robot loc_2_7
at-robot loc_2_8
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_7_3
end_variable
begin_variable
var1
-1
19
at box1 loc_2_6
at box1 loc_2_7
at box1 loc_2_8
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
end_variable
begin_variable
var2
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var3
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var4
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var28
-1
2
adjacent loc_2_6 loc_2_7 right
none-of-those
end_variable
begin_variable
var29
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var30
-1
2
adjacent loc_2_7 loc_2_6 left
none-of-those
end_variable
begin_variable
var31
-1
2
adjacent loc_2_7 loc_2_8 right
none-of-those
end_variable
begin_variable
var32
-1
2
adjacent loc_2_7 loc_3_7 down
none-of-those
end_variable
begin_variable
var33
-1
2
adjacent loc_2_8 loc_2_7 left
none-of-those
end_variable
begin_variable
var34
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var35
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var36
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var37
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var38
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var39
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var40
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var41
-1
2
adjacent loc_3_7 loc_2_7 up
none-of-those
end_variable
begin_variable
var42
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var43
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var44
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var45
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var46
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var47
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var48
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
0
begin_state
11
3
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
1
1 8
end_goal
80
begin_operator
move loc_2_6 loc_2_7 right
2
3 0
28 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
7 0
29 0
1
0 0 0 3
1
end_operator
begin_operator
move loc_2_7 loc_2_6 left
2
2 0
30 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_2_7 loc_2_8 right
2
4 0
31 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_2_7 loc_3_7 down
2
8 0
32 0
1
0 0 1 4
1
end_operator
begin_operator
move loc_2_8 loc_2_7 left
2
3 0
33 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
9 0
34 0
1
0 0 2 5
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
2 0
38 0
1
0 0 3 0
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
8 0
39 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
12 0
40 0
1
0 0 3 7
1
end_operator
begin_operator
move loc_3_7 loc_2_7 up
2
3 0
41 0
1
0 0 4 1
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
7 0
42 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
9 0
43 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
13 0
44 0
1
0 0 4 8
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
4 0
45 0
1
0 0 5 2
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
8 0
46 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
12 0
48 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
14 0
49 0
1
0 0 6 9
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
7 0
50 0
1
0 0 7 3
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
11 0
51 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
13 0
52 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
15 0
53 0
1
0 0 7 10
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
8 0
54 0
1
0 0 8 4
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
12 0
55 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
16 0
56 0
1
0 0 8 11
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
11 0
57 0
1
0 0 9 6
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
15 0
58 0
1
0 0 9 10
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
20 0
59 0
1
0 0 9 15
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
12 0
60 0
1
0 0 10 7
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
14 0
61 0
1
0 0 10 9
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
16 0
62 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
21 0
63 0
1
0 0 10 16
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
13 0
64 0
1
0 0 11 8
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
15 0
65 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
22 0
66 0
1
0 0 11 17
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
18 0
67 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
17 0
68 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
19 0
69 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
24 0
70 0
1
0 0 13 19
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
18 0
71 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
20 0
72 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
14 0
73 0
1
0 0 15 9
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
19 0
74 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
21 0
75 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
15 0
76 0
1
0 0 16 10
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
20 0
77 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
22 0
78 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
16 0
79 0
1
0 0 17 11
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
21 0
80 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
23 0
81 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
22 0
82 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
18 0
83 0
1
0 0 19 13
1
end_operator
begin_operator
push loc_2_6 loc_2_7 loc_2_8 right box1
2
28 0
31 0
4
0 0 0 1
0 1 1 2
0 3 -1 0
0 4 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box1
2
29 0
40 0
4
0 0 0 3
0 1 3 7
0 7 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box1
2
32 0
44 0
4
0 0 1 4
0 1 4 8
0 8 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_2_8 loc_2_7 loc_2_6 left box1
2
30 0
33 0
4
0 0 2 1
0 1 1 0
0 2 0 1
0 3 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
39 0
43 0
4
0 0 3 4
0 1 4 5
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
40 0
53 0
4
0 0 3 7
0 1 7 10
0 12 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
44 0
56 0
4
0 0 4 8
0 1 8 11
0 13 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
42 0
46 0
4
0 0 5 4
0 1 4 3
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
48 0
52 0
4
0 0 6 7
0 1 7 8
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
49 0
59 0
4
0 0 6 9
0 1 9 15
0 14 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
38 0
50 0
4
0 0 7 3
0 1 3 0
0 2 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
53 0
63 0
4
0 0 7 10
0 1 10 16
0 15 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box1
2
41 0
54 0
4
0 0 8 4
0 1 4 1
0 3 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
51 0
55 0
4
0 0 8 7
0 1 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
56 0
66 0
4
0 0 8 11
0 1 11 17
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
58 0
62 0
4
0 0 9 10
0 1 10 11
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
50 0
60 0
4
0 0 10 7
0 1 7 3
0 7 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
54 0
64 0
4
0 0 11 8
0 1 8 4
0 8 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
61 0
65 0
4
0 0 11 10
0 1 10 9
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box1
2
68 0
71 0
4
0 0 14 13
0 1 13 12
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
57 0
73 0
4
0 0 15 9
0 1 9 6
0 11 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box1
2
71 0
74 0
4
0 0 15 14
0 1 14 13
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
75 0
78 0
4
0 0 15 16
0 1 16 17
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
60 0
76 0
4
0 0 16 10
0 1 10 7
0 12 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
74 0
77 0
4
0 0 16 15
0 1 15 14
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
78 0
81 0
4
0 0 16 17
0 1 17 18
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
64 0
79 0
4
0 0 17 11
0 1 11 8
0 13 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
77 0
80 0
4
0 0 17 16
0 1 16 15
0 20 0 1
0 21 -1 0
1
end_operator
0
