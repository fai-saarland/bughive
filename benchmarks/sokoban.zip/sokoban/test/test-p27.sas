begin_version
3
end_version
begin_metric
1
end_metric
308
begin_variable
var0
-1
77
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_12
at-robot loc_10_5
at-robot loc_10_7
at-robot loc_11_12
at-robot loc_11_7
at-robot loc_12_10
at-robot loc_12_11
at-robot loc_12_12
at-robot loc_12_7
at-robot loc_12_8
at-robot loc_12_9
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_6
at-robot loc_2_8
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_3_9
at-robot loc_4_11
at-robot loc_4_12
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_2
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_9
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_12
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_3
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_12
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
68
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_12
at box2 loc_10_7
at box2 loc_11_12
at box2 loc_11_7
at box2 loc_12_12
at box2 loc_12_7
at box2 loc_2_4
at box2 loc_2_6
at box2 loc_2_8
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_3_8
at box2 loc_3_9
at box2 loc_4_11
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_4_8
at box2 loc_4_9
at box2 loc_5_10
at box2 loc_5_11
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_4
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_9
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_12
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_12
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_12
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var2
-1
68
at box3 loc_10_10
at box3 loc_10_11
at box3 loc_10_12
at box3 loc_10_7
at box3 loc_11_12
at box3 loc_11_7
at box3 loc_12_12
at box3 loc_12_7
at box3 loc_2_4
at box3 loc_2_6
at box3 loc_2_8
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_3_7
at box3 loc_3_8
at box3 loc_3_9
at box3 loc_4_11
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_4_8
at box3 loc_4_9
at box3 loc_5_10
at box3 loc_5_11
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_10
at box3 loc_6_11
at box3 loc_6_4
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_9
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_12
at box3 loc_7_3
at box3 loc_7_4
at box3 loc_7_5
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_12
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_12
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var3
-1
68
at box4 loc_10_10
at box4 loc_10_11
at box4 loc_10_12
at box4 loc_10_7
at box4 loc_11_12
at box4 loc_11_7
at box4 loc_12_12
at box4 loc_12_7
at box4 loc_2_4
at box4 loc_2_6
at box4 loc_2_8
at box4 loc_3_3
at box4 loc_3_4
at box4 loc_3_5
at box4 loc_3_6
at box4 loc_3_7
at box4 loc_3_8
at box4 loc_3_9
at box4 loc_4_11
at box4 loc_4_4
at box4 loc_4_5
at box4 loc_4_6
at box4 loc_4_7
at box4 loc_4_8
at box4 loc_4_9
at box4 loc_5_10
at box4 loc_5_11
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_5
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_5_8
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_4
at box4 loc_6_5
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_6_9
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_12
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_5
at box4 loc_7_6
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_12
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_12
at box4 loc_9_3
at box4 loc_9_4
at box4 loc_9_5
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var4
-1
68
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_12
at box1 loc_10_7
at box1 loc_11_12
at box1 loc_11_7
at box1 loc_12_12
at box1 loc_12_7
at box1 loc_2_4
at box1 loc_2_6
at box1 loc_2_8
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_3_9
at box1 loc_4_11
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_11
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_9
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_12
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_12
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_12
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var5
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_12_10
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_12_11
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_12_12
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_12_2
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_12_7
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_12_8
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_2_12
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_7_12
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_9_12
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_11 loc_10_12 right
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_10_12 loc_10_11 left
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_10_12 loc_11_12 down
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_10_12 loc_9_12 up
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_11_12 loc_10_12 up
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_11_12 loc_12_12 down
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_11_7 loc_12_7 down
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_12_10 loc_12_11 right
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_12_10 loc_12_9 left
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_12_11 loc_12_10 left
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_12_11 loc_12_12 right
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_12_12 loc_11_12 up
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_12_12 loc_12_11 left
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_12_7 loc_11_7 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_12_7 loc_12_8 right
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_12_8 loc_12_7 left
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_12_8 loc_12_9 right
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_12_9 loc_12_10 right
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_12_9 loc_12_8 left
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_3_8 loc_3_9 right
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_3_9 loc_3_8 left
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_4_11 loc_4_12 right
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_4_12 loc_4_11 left
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_6_10 loc_6_9 left
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_6_9 loc_6_10 right
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_7_11 loc_7_12 right
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_7_12 loc_7_11 left
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_7_12 loc_8_12 down
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_8_12 loc_7_12 up
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_8_12 loc_9_12 down
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_8_3 loc_9_3 down
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_9_11 loc_9_12 right
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_9_12 loc_10_12 down
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_9_12 loc_8_12 up
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_9_12 loc_9_11 left
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_9_3 loc_8_3 up
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
70
25
58
38
23
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 63
2 50
3 55
4 11
end_goal
834
begin_operator
move loc_10_10 loc_10_11 right
2
6 0
86 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
76 0
87 0
1
0 0 0 67
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
5 0
88 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_10_12 right
2
7 0
89 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
77 0
90 0
1
0 0 1 68
1
end_operator
begin_operator
move loc_10_12 loc_10_11 left
2
6 0
91 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_12 loc_11_12 down
2
11 0
92 0
1
0 0 2 5
1
end_operator
begin_operator
move loc_10_12 loc_9_12 up
2
78 0
93 0
1
0 0 2 69
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
81 0
94 0
1
0 0 3 72
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
13 0
95 0
1
0 0 4 6
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
83 0
96 0
1
0 0 4 74
1
end_operator
begin_operator
move loc_11_12 loc_10_12 up
2
7 0
97 0
1
0 0 5 2
1
end_operator
begin_operator
move loc_11_12 loc_12_12 down
2
16 0
98 0
1
0 0 5 9
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
10 0
99 0
1
0 0 6 4
1
end_operator
begin_operator
move loc_11_7 loc_12_7 down
2
18 0
100 0
1
0 0 6 10
1
end_operator
begin_operator
move loc_12_10 loc_12_11 right
2
15 0
101 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_12_10 loc_12_9 left
2
20 0
102 0
1
0 0 7 12
1
end_operator
begin_operator
move loc_12_11 loc_12_10 left
2
14 0
103 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_12_11 loc_12_12 right
2
16 0
104 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_12_12 loc_11_12 up
2
11 0
105 0
1
0 0 9 5
1
end_operator
begin_operator
move loc_12_12 loc_12_11 left
2
15 0
106 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_12_7 loc_11_7 up
2
13 0
107 0
1
0 0 10 6
1
end_operator
begin_operator
move loc_12_7 loc_12_8 right
2
19 0
108 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_12_8 loc_12_7 left
2
18 0
109 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_12_8 loc_12_9 right
2
20 0
110 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_12_9 loc_12_10 right
2
14 0
111 0
1
0 0 12 7
1
end_operator
begin_operator
move loc_12_9 loc_12_8 left
2
19 0
112 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
23 0
113 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
26 0
114 0
1
0 0 13 17
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
22 0
115 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
27 0
116 0
1
0 0 14 18
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
29 0
117 0
1
0 0 15 20
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
31 0
118 0
1
0 0 16 22
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
22 0
119 0
1
0 0 17 13
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
27 0
120 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
23 0
121 0
1
0 0 18 14
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
26 0
122 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
28 0
123 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
35 0
124 0
1
0 0 18 26
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
27 0
125 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
29 0
126 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
36 0
127 0
1
0 0 19 27
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
24 0
128 0
1
0 0 20 15
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
28 0
129 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
30 0
130 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
37 0
131 0
1
0 0 20 28
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
29 0
132 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
31 0
133 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
38 0
134 0
1
0 0 21 29
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
25 0
135 0
1
0 0 22 16
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
30 0
136 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_3_8 loc_3_9 right
2
32 0
137 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
39 0
138 0
1
0 0 22 30
1
end_operator
begin_operator
move loc_3_9 loc_3_8 left
2
31 0
139 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
40 0
140 0
1
0 0 23 31
1
end_operator
begin_operator
move loc_4_11 loc_4_12 right
2
34 0
141 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
42 0
142 0
1
0 0 24 33
1
end_operator
begin_operator
move loc_4_12 loc_4_11 left
2
33 0
143 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
27 0
144 0
1
0 0 26 18
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
36 0
145 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
45 0
146 0
1
0 0 26 36
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
28 0
147 0
1
0 0 27 19
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
35 0
148 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
37 0
149 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
46 0
150 0
1
0 0 27 37
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
29 0
151 0
1
0 0 28 20
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
36 0
152 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
38 0
153 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
47 0
154 0
1
0 0 28 38
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
30 0
155 0
1
0 0 29 21
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
37 0
156 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
39 0
157 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
48 0
158 0
1
0 0 29 39
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
31 0
159 0
1
0 0 30 22
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
38 0
160 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
40 0
161 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
49 0
162 0
1
0 0 30 40
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
32 0
163 0
1
0 0 31 23
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
39 0
164 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
50 0
165 0
1
0 0 31 41
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
42 0
166 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
50 0
167 0
1
0 0 32 41
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
51 0
168 0
1
0 0 32 42
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
33 0
169 0
1
0 0 33 24
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
41 0
170 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
52 0
171 0
1
0 0 33 43
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
44 0
172 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
53 0
173 0
1
0 0 34 44
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
43 0
174 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
45 0
175 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
35 0
176 0
1
0 0 36 26
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
44 0
177 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
46 0
178 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
54 0
179 0
1
0 0 36 45
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
36 0
180 0
1
0 0 37 27
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
45 0
181 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
47 0
182 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
55 0
183 0
1
0 0 37 46
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
37 0
184 0
1
0 0 38 28
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
46 0
185 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
48 0
186 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
56 0
187 0
1
0 0 38 47
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
38 0
188 0
1
0 0 39 29
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
47 0
189 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
49 0
190 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
57 0
191 0
1
0 0 39 48
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
39 0
192 0
1
0 0 40 30
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
48 0
193 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
50 0
194 0
1
0 0 40 41
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
40 0
195 0
1
0 0 41 31
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
41 0
196 0
1
0 0 41 32
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
49 0
197 0
1
0 0 41 40
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
58 0
198 0
1
0 0 41 49
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
41 0
199 0
1
0 0 42 32
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
52 0
200 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_6_10 loc_6_9 left
2
58 0
201 0
1
0 0 42 49
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
59 0
202 0
1
0 0 42 50
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
42 0
203 0
1
0 0 43 33
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
51 0
204 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
60 0
205 0
1
0 0 43 51
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
43 0
206 0
1
0 0 44 34
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
45 0
207 0
1
0 0 45 36
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
55 0
208 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
63 0
209 0
1
0 0 45 54
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
46 0
210 0
1
0 0 46 37
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
54 0
211 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
56 0
212 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
64 0
213 0
1
0 0 46 55
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
47 0
214 0
1
0 0 47 38
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
55 0
215 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
57 0
216 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
65 0
217 0
1
0 0 47 56
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
48 0
218 0
1
0 0 48 39
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
56 0
219 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
66 0
220 0
1
0 0 48 57
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
50 0
221 0
1
0 0 49 41
1
end_operator
begin_operator
move loc_6_9 loc_6_10 right
2
51 0
222 0
1
0 0 49 42
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
68 0
223 0
1
0 0 49 59
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
51 0
224 0
1
0 0 50 42
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
60 0
225 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
68 0
226 0
1
0 0 50 59
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
69 0
227 0
1
0 0 50 60
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
52 0
228 0
1
0 0 51 43
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
59 0
229 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_7_11 loc_7_12 right
2
61 0
230 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
70 0
231 0
1
0 0 51 61
1
end_operator
begin_operator
move loc_7_12 loc_7_11 left
2
60 0
232 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_7_12 loc_8_12 down
2
71 0
233 0
1
0 0 52 62
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
63 0
234 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
72 0
235 0
1
0 0 53 63
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
54 0
236 0
1
0 0 54 45
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
62 0
237 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
64 0
238 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
55 0
239 0
1
0 0 55 46
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
63 0
240 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
65 0
241 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
56 0
242 0
1
0 0 56 47
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
64 0
243 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
66 0
244 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
73 0
245 0
1
0 0 56 64
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
57 0
246 0
1
0 0 57 48
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
65 0
247 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
67 0
248 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
74 0
249 0
1
0 0 57 65
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
66 0
250 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
68 0
251 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
58 0
252 0
1
0 0 59 49
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
59 0
253 0
1
0 0 59 50
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
67 0
254 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
75 0
255 0
1
0 0 59 66
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
59 0
256 0
1
0 0 60 50
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
70 0
257 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
75 0
258 0
1
0 0 60 66
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
76 0
259 0
1
0 0 60 67
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
60 0
260 0
1
0 0 61 51
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
69 0
261 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
71 0
262 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
77 0
263 0
1
0 0 61 68
1
end_operator
begin_operator
move loc_8_12 loc_7_12 up
2
61 0
264 0
1
0 0 62 52
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
70 0
265 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_8_12 loc_9_12 down
2
78 0
266 0
1
0 0 62 69
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
62 0
267 0
1
0 0 63 53
1
end_operator
begin_operator
move loc_8_3 loc_9_3 down
2
79 0
268 0
1
0 0 63 70
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
65 0
269 0
1
0 0 64 56
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
74 0
270 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
82 0
271 0
1
0 0 64 73
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
66 0
272 0
1
0 0 65 57
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
73 0
273 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
83 0
274 0
1
0 0 65 74
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
68 0
275 0
1
0 0 66 59
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
69 0
276 0
1
0 0 66 60
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
85 0
277 0
1
0 0 66 76
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
5 0
278 0
1
0 0 67 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
69 0
279 0
1
0 0 67 60
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
77 0
280 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
85 0
281 0
1
0 0 67 76
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
6 0
282 0
1
0 0 68 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
70 0
283 0
1
0 0 68 61
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
76 0
284 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_9_11 loc_9_12 right
2
78 0
285 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_9_12 loc_10_12 down
2
7 0
286 0
1
0 0 69 2
1
end_operator
begin_operator
move loc_9_12 loc_8_12 up
2
71 0
287 0
1
0 0 69 62
1
end_operator
begin_operator
move loc_9_12 loc_9_11 left
2
77 0
288 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_9_3 loc_8_3 up
2
72 0
289 0
1
0 0 70 63
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
80 0
290 0
1
0 0 70 71
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
79 0
291 0
1
0 0 71 70
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
81 0
292 0
1
0 0 71 72
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
9 0
293 0
1
0 0 72 3
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
80 0
294 0
1
0 0 72 71
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
82 0
295 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
73 0
296 0
1
0 0 73 64
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
81 0
297 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
83 0
298 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
10 0
299 0
1
0 0 74 4
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
74 0
300 0
1
0 0 74 65
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
82 0
301 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
84 0
302 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
83 0
303 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
85 0
304 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
75 0
305 0
1
0 0 76 66
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
76 0
306 0
1
0 0 76 67
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
84 0
307 0
1
0 0 76 75
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box1
2
86 0
89 0
4
0 0 0 1
0 4 1 2
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box2
2
86 0
89 0
4
0 0 0 1
0 1 1 2
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box3
2
86 0
89 0
4
0 0 0 1
0 2 1 2
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box4
2
86 0
89 0
4
0 0 0 1
0 3 1 2
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
87 0
279 0
4
0 0 0 67
0 4 58 52
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
87 0
279 0
4
0 0 0 67
0 1 58 52
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
87 0
279 0
4
0 0 0 67
0 2 58 52
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
87 0
279 0
4
0 0 0 67
0 3 58 52
0 69 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
90 0
283 0
4
0 0 1 68
0 4 59 53
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
90 0
283 0
4
0 0 1 68
0 1 59 53
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
90 0
283 0
4
0 0 1 68
0 2 59 53
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box4
2
90 0
283 0
4
0 0 1 68
0 3 59 53
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box1
2
88 0
91 0
4
0 0 2 1
0 4 1 0
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box2
2
88 0
91 0
4
0 0 2 1
0 1 1 0
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box3
2
88 0
91 0
4
0 0 2 1
0 2 1 0
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box4
2
88 0
91 0
4
0 0 2 1
0 3 1 0
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box1
2
92 0
98 0
4
0 0 2 5
0 4 4 6
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box2
2
92 0
98 0
4
0 0 2 5
0 1 4 6
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box3
2
92 0
98 0
4
0 0 2 5
0 2 4 6
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box4
2
92 0
98 0
4
0 0 2 5
0 3 4 6
0 11 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box1
2
93 0
287 0
4
0 0 2 69
0 4 60 54
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box2
2
93 0
287 0
4
0 0 2 69
0 1 60 54
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box3
2
93 0
287 0
4
0 0 2 69
0 2 60 54
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box4
2
93 0
287 0
4
0 0 2 69
0 3 60 54
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box1
2
95 0
100 0
4
0 0 4 6
0 4 5 7
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box2
2
95 0
100 0
4
0 0 4 6
0 1 5 7
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box3
2
95 0
100 0
4
0 0 4 6
0 2 5 7
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box4
2
95 0
100 0
4
0 0 4 6
0 3 5 7
0 13 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
96 0
300 0
4
0 0 4 74
0 4 65 56
0 74 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
96 0
300 0
4
0 0 4 74
0 1 65 56
0 74 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
96 0
300 0
4
0 0 4 74
0 2 65 56
0 74 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box4
2
96 0
300 0
4
0 0 4 74
0 3 65 56
0 74 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box1
2
93 0
97 0
4
0 0 5 2
0 4 2 60
0 7 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box2
2
93 0
97 0
4
0 0 5 2
0 1 2 60
0 7 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box3
2
93 0
97 0
4
0 0 5 2
0 2 2 60
0 7 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box4
2
93 0
97 0
4
0 0 5 2
0 3 2 60
0 7 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
96 0
99 0
4
0 0 6 4
0 4 3 65
0 10 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
96 0
99 0
4
0 0 6 4
0 1 3 65
0 10 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
96 0
99 0
4
0 0 6 4
0 2 3 65
0 10 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box4
2
96 0
99 0
4
0 0 6 4
0 3 3 65
0 10 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box1
2
97 0
105 0
4
0 0 9 5
0 4 4 2
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box2
2
97 0
105 0
4
0 0 9 5
0 1 4 2
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box3
2
97 0
105 0
4
0 0 9 5
0 2 4 2
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box4
2
97 0
105 0
4
0 0 9 5
0 3 4 2
0 7 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box1
2
99 0
107 0
4
0 0 10 6
0 4 5 3
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box2
2
99 0
107 0
4
0 0 10 6
0 1 5 3
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box3
2
99 0
107 0
4
0 0 10 6
0 2 5 3
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box4
2
99 0
107 0
4
0 0 10 6
0 3 5 3
0 10 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
123 0
126 0
4
0 0 18 19
0 4 13 14
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
123 0
126 0
4
0 0 18 19
0 1 13 14
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
123 0
126 0
4
0 0 18 19
0 2 13 14
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box4
2
123 0
126 0
4
0 0 18 19
0 3 13 14
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
124 0
146 0
4
0 0 18 26
0 4 19 29
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
124 0
146 0
4
0 0 18 26
0 1 19 29
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
124 0
146 0
4
0 0 18 26
0 2 19 29
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box4
2
124 0
146 0
4
0 0 18 26
0 3 19 29
0 35 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
122 0
125 0
4
0 0 19 18
0 4 12 11
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
122 0
125 0
4
0 0 19 18
0 1 12 11
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
122 0
125 0
4
0 0 19 18
0 2 12 11
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box4
2
122 0
125 0
4
0 0 19 18
0 3 12 11
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
126 0
130 0
4
0 0 19 20
0 4 14 15
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
126 0
130 0
4
0 0 19 20
0 1 14 15
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box3
2
126 0
130 0
4
0 0 19 20
0 2 14 15
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box4
2
126 0
130 0
4
0 0 19 20
0 3 14 15
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
127 0
150 0
4
0 0 19 27
0 4 20 30
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
127 0
150 0
4
0 0 19 27
0 1 20 30
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
127 0
150 0
4
0 0 19 27
0 2 20 30
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box4
2
127 0
150 0
4
0 0 19 27
0 3 20 30
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
125 0
129 0
4
0 0 20 19
0 4 13 12
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
125 0
129 0
4
0 0 20 19
0 1 13 12
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
125 0
129 0
4
0 0 20 19
0 2 13 12
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box4
2
125 0
129 0
4
0 0 20 19
0 3 13 12
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
130 0
133 0
4
0 0 20 21
0 4 15 16
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box2
2
130 0
133 0
4
0 0 20 21
0 1 15 16
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box3
2
130 0
133 0
4
0 0 20 21
0 2 15 16
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box4
2
130 0
133 0
4
0 0 20 21
0 3 15 16
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
131 0
154 0
4
0 0 20 28
0 4 21 31
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
131 0
154 0
4
0 0 20 28
0 1 21 31
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
131 0
154 0
4
0 0 20 28
0 2 21 31
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box4
2
131 0
154 0
4
0 0 20 28
0 3 21 31
0 37 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
129 0
132 0
4
0 0 21 20
0 4 14 13
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
129 0
132 0
4
0 0 21 20
0 1 14 13
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box3
2
129 0
132 0
4
0 0 21 20
0 2 14 13
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box4
2
129 0
132 0
4
0 0 21 20
0 3 14 13
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box1
2
133 0
137 0
4
0 0 21 22
0 4 16 17
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box2
2
133 0
137 0
4
0 0 21 22
0 1 16 17
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box3
2
133 0
137 0
4
0 0 21 22
0 2 16 17
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box4
2
133 0
137 0
4
0 0 21 22
0 3 16 17
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
134 0
158 0
4
0 0 21 29
0 4 22 32
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box2
2
134 0
158 0
4
0 0 21 29
0 1 22 32
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box3
2
134 0
158 0
4
0 0 21 29
0 2 22 32
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box4
2
134 0
158 0
4
0 0 21 29
0 3 22 32
0 38 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
132 0
136 0
4
0 0 22 21
0 4 15 14
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box2
2
132 0
136 0
4
0 0 22 21
0 1 15 14
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box3
2
132 0
136 0
4
0 0 22 21
0 2 15 14
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box4
2
132 0
136 0
4
0 0 22 21
0 3 15 14
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box1
2
138 0
162 0
4
0 0 22 30
0 4 23 33
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box2
2
138 0
162 0
4
0 0 22 30
0 1 23 33
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box3
2
138 0
162 0
4
0 0 22 30
0 2 23 33
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box4
2
138 0
162 0
4
0 0 22 30
0 3 23 33
0 39 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box1
2
136 0
139 0
4
0 0 23 22
0 4 16 15
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box2
2
136 0
139 0
4
0 0 23 22
0 1 16 15
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box3
2
136 0
139 0
4
0 0 23 22
0 2 16 15
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box4
2
136 0
139 0
4
0 0 23 22
0 3 16 15
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box1
2
140 0
165 0
4
0 0 23 31
0 4 24 34
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box2
2
140 0
165 0
4
0 0 23 31
0 1 24 34
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box3
2
140 0
165 0
4
0 0 23 31
0 2 24 34
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box4
2
140 0
165 0
4
0 0 23 31
0 3 24 34
0 40 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
121 0
144 0
4
0 0 26 18
0 4 12 8
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box2
2
121 0
144 0
4
0 0 26 18
0 1 12 8
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box3
2
121 0
144 0
4
0 0 26 18
0 2 12 8
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box4
2
121 0
144 0
4
0 0 26 18
0 3 12 8
0 23 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
145 0
149 0
4
0 0 26 27
0 4 20 21
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
145 0
149 0
4
0 0 26 27
0 1 20 21
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
145 0
149 0
4
0 0 26 27
0 2 20 21
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box4
2
145 0
149 0
4
0 0 26 27
0 3 20 21
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
146 0
179 0
4
0 0 26 36
0 4 29 37
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
146 0
179 0
4
0 0 26 36
0 1 29 37
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
146 0
179 0
4
0 0 26 36
0 2 29 37
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box4
2
146 0
179 0
4
0 0 26 36
0 3 29 37
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
149 0
153 0
4
0 0 27 28
0 4 21 22
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
149 0
153 0
4
0 0 27 28
0 1 21 22
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
149 0
153 0
4
0 0 27 28
0 2 21 22
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box4
2
149 0
153 0
4
0 0 27 28
0 3 21 22
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
150 0
183 0
4
0 0 27 37
0 4 30 38
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box2
2
150 0
183 0
4
0 0 27 37
0 1 30 38
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box3
2
150 0
183 0
4
0 0 27 37
0 2 30 38
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box4
2
150 0
183 0
4
0 0 27 37
0 3 30 38
0 46 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
128 0
151 0
4
0 0 28 20
0 4 14 9
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box2
2
128 0
151 0
4
0 0 28 20
0 1 14 9
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box3
2
128 0
151 0
4
0 0 28 20
0 2 14 9
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box4
2
128 0
151 0
4
0 0 28 20
0 3 14 9
0 24 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
148 0
152 0
4
0 0 28 27
0 4 20 19
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
148 0
152 0
4
0 0 28 27
0 1 20 19
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
148 0
152 0
4
0 0 28 27
0 2 20 19
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box4
2
148 0
152 0
4
0 0 28 27
0 3 20 19
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
153 0
157 0
4
0 0 28 29
0 4 22 23
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box2
2
153 0
157 0
4
0 0 28 29
0 1 22 23
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box3
2
153 0
157 0
4
0 0 28 29
0 2 22 23
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box4
2
153 0
157 0
4
0 0 28 29
0 3 22 23
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
154 0
187 0
4
0 0 28 38
0 4 31 39
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
154 0
187 0
4
0 0 28 38
0 1 31 39
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
154 0
187 0
4
0 0 28 38
0 2 31 39
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box4
2
154 0
187 0
4
0 0 28 38
0 3 31 39
0 47 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
152 0
156 0
4
0 0 29 28
0 4 21 20
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
152 0
156 0
4
0 0 29 28
0 1 21 20
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
152 0
156 0
4
0 0 29 28
0 2 21 20
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box4
2
152 0
156 0
4
0 0 29 28
0 3 21 20
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
157 0
161 0
4
0 0 29 30
0 4 23 24
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box2
2
157 0
161 0
4
0 0 29 30
0 1 23 24
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box3
2
157 0
161 0
4
0 0 29 30
0 2 23 24
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box4
2
157 0
161 0
4
0 0 29 30
0 3 23 24
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
158 0
191 0
4
0 0 29 39
0 4 32 40
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
158 0
191 0
4
0 0 29 39
0 1 32 40
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
158 0
191 0
4
0 0 29 39
0 2 32 40
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box4
2
158 0
191 0
4
0 0 29 39
0 3 32 40
0 48 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box1
2
135 0
159 0
4
0 0 30 22
0 4 16 10
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box2
2
135 0
159 0
4
0 0 30 22
0 1 16 10
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box3
2
135 0
159 0
4
0 0 30 22
0 2 16 10
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box4
2
135 0
159 0
4
0 0 30 22
0 3 16 10
0 25 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
156 0
160 0
4
0 0 30 29
0 4 22 21
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box2
2
156 0
160 0
4
0 0 30 29
0 1 22 21
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box3
2
156 0
160 0
4
0 0 30 29
0 2 22 21
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box4
2
156 0
160 0
4
0 0 30 29
0 3 22 21
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box1
2
160 0
164 0
4
0 0 31 30
0 4 23 22
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box2
2
160 0
164 0
4
0 0 31 30
0 1 23 22
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box3
2
160 0
164 0
4
0 0 31 30
0 2 23 22
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box4
2
160 0
164 0
4
0 0 31 30
0 3 23 22
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box1
2
165 0
198 0
4
0 0 31 41
0 4 34 41
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box2
2
165 0
198 0
4
0 0 31 41
0 1 34 41
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box3
2
165 0
198 0
4
0 0 31 41
0 2 34 41
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box4
2
165 0
198 0
4
0 0 31 41
0 3 34 41
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box1
2
167 0
197 0
4
0 0 32 41
0 4 34 33
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box2
2
167 0
197 0
4
0 0 32 41
0 1 34 33
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box3
2
167 0
197 0
4
0 0 32 41
0 2 34 33
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box4
2
167 0
197 0
4
0 0 32 41
0 3 34 33
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box1
2
168 0
202 0
4
0 0 32 42
0 4 35 42
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box2
2
168 0
202 0
4
0 0 32 42
0 1 35 42
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box3
2
168 0
202 0
4
0 0 32 42
0 2 35 42
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box4
2
168 0
202 0
4
0 0 32 42
0 3 35 42
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box1
2
167 0
170 0
4
0 0 33 32
0 4 25 34
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box2
2
167 0
170 0
4
0 0 33 32
0 1 25 34
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box3
2
167 0
170 0
4
0 0 33 32
0 2 25 34
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box4
2
167 0
170 0
4
0 0 33 32
0 3 25 34
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box1
2
171 0
205 0
4
0 0 33 43
0 4 36 43
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box2
2
171 0
205 0
4
0 0 33 43
0 1 36 43
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box3
2
171 0
205 0
4
0 0 33 43
0 2 36 43
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box4
2
171 0
205 0
4
0 0 33 43
0 3 36 43
0 52 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
144 0
176 0
4
0 0 36 26
0 4 19 12
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
144 0
176 0
4
0 0 36 26
0 1 19 12
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
144 0
176 0
4
0 0 36 26
0 2 19 12
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box4
2
144 0
176 0
4
0 0 36 26
0 3 19 12
0 27 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
174 0
177 0
4
0 0 36 35
0 4 28 27
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
174 0
177 0
4
0 0 36 35
0 1 28 27
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
174 0
177 0
4
0 0 36 35
0 2 28 27
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
174 0
177 0
4
0 0 36 35
0 3 28 27
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
178 0
182 0
4
0 0 36 37
0 4 30 31
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
178 0
182 0
4
0 0 36 37
0 1 30 31
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
178 0
182 0
4
0 0 36 37
0 2 30 31
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box4
2
178 0
182 0
4
0 0 36 37
0 3 30 31
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
179 0
209 0
4
0 0 36 45
0 4 37 46
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
179 0
209 0
4
0 0 36 45
0 1 37 46
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
179 0
209 0
4
0 0 36 45
0 2 37 46
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box4
2
179 0
209 0
4
0 0 36 45
0 3 37 46
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
147 0
180 0
4
0 0 37 27
0 4 20 13
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
147 0
180 0
4
0 0 37 27
0 1 20 13
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
147 0
180 0
4
0 0 37 27
0 2 20 13
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box4
2
147 0
180 0
4
0 0 37 27
0 3 20 13
0 28 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
177 0
181 0
4
0 0 37 36
0 4 29 28
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
177 0
181 0
4
0 0 37 36
0 1 29 28
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
177 0
181 0
4
0 0 37 36
0 2 29 28
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box4
2
177 0
181 0
4
0 0 37 36
0 3 29 28
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
182 0
186 0
4
0 0 37 38
0 4 31 32
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
182 0
186 0
4
0 0 37 38
0 1 31 32
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
182 0
186 0
4
0 0 37 38
0 2 31 32
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box4
2
182 0
186 0
4
0 0 37 38
0 3 31 32
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
183 0
213 0
4
0 0 37 46
0 4 38 47
0 55 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box2
2
183 0
213 0
4
0 0 37 46
0 1 38 47
0 55 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box3
2
183 0
213 0
4
0 0 37 46
0 2 38 47
0 55 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box4
2
183 0
213 0
4
0 0 37 46
0 3 38 47
0 55 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
151 0
184 0
4
0 0 38 28
0 4 21 14
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
151 0
184 0
4
0 0 38 28
0 1 21 14
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
151 0
184 0
4
0 0 38 28
0 2 21 14
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box4
2
151 0
184 0
4
0 0 38 28
0 3 21 14
0 29 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
181 0
185 0
4
0 0 38 37
0 4 30 29
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
181 0
185 0
4
0 0 38 37
0 1 30 29
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
181 0
185 0
4
0 0 38 37
0 2 30 29
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box4
2
181 0
185 0
4
0 0 38 37
0 3 30 29
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
186 0
190 0
4
0 0 38 39
0 4 32 33
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
186 0
190 0
4
0 0 38 39
0 1 32 33
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
186 0
190 0
4
0 0 38 39
0 2 32 33
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box4
2
186 0
190 0
4
0 0 38 39
0 3 32 33
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
187 0
217 0
4
0 0 38 47
0 4 39 48
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
187 0
217 0
4
0 0 38 47
0 1 39 48
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
187 0
217 0
4
0 0 38 47
0 2 39 48
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box4
2
187 0
217 0
4
0 0 38 47
0 3 39 48
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
155 0
188 0
4
0 0 39 29
0 4 22 15
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
155 0
188 0
4
0 0 39 29
0 1 22 15
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
155 0
188 0
4
0 0 39 29
0 2 22 15
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box4
2
155 0
188 0
4
0 0 39 29
0 3 22 15
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
185 0
189 0
4
0 0 39 38
0 4 31 30
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
185 0
189 0
4
0 0 39 38
0 1 31 30
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
185 0
189 0
4
0 0 39 38
0 2 31 30
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box4
2
185 0
189 0
4
0 0 39 38
0 3 31 30
0 46 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
190 0
194 0
4
0 0 39 40
0 4 33 34
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
190 0
194 0
4
0 0 39 40
0 1 33 34
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
190 0
194 0
4
0 0 39 40
0 2 33 34
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box4
2
190 0
194 0
4
0 0 39 40
0 3 33 34
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
191 0
220 0
4
0 0 39 48
0 4 40 49
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
191 0
220 0
4
0 0 39 48
0 1 40 49
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
191 0
220 0
4
0 0 39 48
0 2 40 49
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box4
2
191 0
220 0
4
0 0 39 48
0 3 40 49
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box1
2
159 0
192 0
4
0 0 40 30
0 4 23 16
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box2
2
159 0
192 0
4
0 0 40 30
0 1 23 16
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box3
2
159 0
192 0
4
0 0 40 30
0 2 23 16
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box4
2
159 0
192 0
4
0 0 40 30
0 3 23 16
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
189 0
193 0
4
0 0 40 39
0 4 32 31
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
189 0
193 0
4
0 0 40 39
0 1 32 31
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
189 0
193 0
4
0 0 40 39
0 2 32 31
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box4
2
189 0
193 0
4
0 0 40 39
0 3 32 31
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box1
2
194 0
196 0
4
0 0 40 41
0 4 34 25
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box2
2
194 0
196 0
4
0 0 40 41
0 1 34 25
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box3
2
194 0
196 0
4
0 0 40 41
0 2 34 25
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box4
2
194 0
196 0
4
0 0 40 41
0 3 34 25
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box1
2
163 0
195 0
4
0 0 41 31
0 4 24 17
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box2
2
163 0
195 0
4
0 0 41 31
0 1 24 17
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box3
2
163 0
195 0
4
0 0 41 31
0 2 24 17
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box4
2
163 0
195 0
4
0 0 41 31
0 3 24 17
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box1
2
166 0
196 0
4
0 0 41 32
0 4 25 26
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box2
2
166 0
196 0
4
0 0 41 32
0 1 25 26
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box3
2
166 0
196 0
4
0 0 41 32
0 2 25 26
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box4
2
166 0
196 0
4
0 0 41 32
0 3 25 26
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
193 0
197 0
4
0 0 41 40
0 4 33 32
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
193 0
197 0
4
0 0 41 40
0 1 33 32
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
193 0
197 0
4
0 0 41 40
0 2 33 32
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box4
2
193 0
197 0
4
0 0 41 40
0 3 33 32
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box1
2
198 0
223 0
4
0 0 41 49
0 4 41 51
0 58 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box2
2
198 0
223 0
4
0 0 41 49
0 1 41 51
0 58 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box3
2
198 0
223 0
4
0 0 41 49
0 2 41 51
0 58 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box4
2
198 0
223 0
4
0 0 41 49
0 3 41 51
0 58 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
202 0
227 0
4
0 0 42 50
0 4 42 52
0 59 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
202 0
227 0
4
0 0 42 50
0 1 42 52
0 59 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box3
2
202 0
227 0
4
0 0 42 50
0 2 42 52
0 59 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
202 0
227 0
4
0 0 42 50
0 3 42 52
0 59 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box1
2
169 0
203 0
4
0 0 43 33
0 4 26 18
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box2
2
169 0
203 0
4
0 0 43 33
0 1 26 18
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box3
2
169 0
203 0
4
0 0 43 33
0 2 26 18
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box4
2
169 0
203 0
4
0 0 43 33
0 3 26 18
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box1
2
201 0
204 0
4
0 0 43 42
0 4 35 41
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box2
2
201 0
204 0
4
0 0 43 42
0 1 35 41
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box3
2
201 0
204 0
4
0 0 43 42
0 2 35 41
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box4
2
201 0
204 0
4
0 0 43 42
0 3 35 41
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box1
2
205 0
231 0
4
0 0 43 51
0 4 43 53
0 60 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box2
2
205 0
231 0
4
0 0 43 51
0 1 43 53
0 60 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box3
2
205 0
231 0
4
0 0 43 51
0 2 43 53
0 60 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box4
2
205 0
231 0
4
0 0 43 51
0 3 43 53
0 60 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
176 0
207 0
4
0 0 45 36
0 4 29 19
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
176 0
207 0
4
0 0 45 36
0 1 29 19
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box3
2
176 0
207 0
4
0 0 45 36
0 2 29 19
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box4
2
176 0
207 0
4
0 0 45 36
0 3 29 19
0 35 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
208 0
212 0
4
0 0 45 46
0 4 38 39
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box2
2
208 0
212 0
4
0 0 45 46
0 1 38 39
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box3
2
208 0
212 0
4
0 0 45 46
0 2 38 39
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box4
2
208 0
212 0
4
0 0 45 46
0 3 38 39
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
180 0
210 0
4
0 0 46 37
0 4 30 20
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box2
2
180 0
210 0
4
0 0 46 37
0 1 30 20
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box3
2
180 0
210 0
4
0 0 46 37
0 2 30 20
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box4
2
180 0
210 0
4
0 0 46 37
0 3 30 20
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
212 0
216 0
4
0 0 46 47
0 4 39 40
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
212 0
216 0
4
0 0 46 47
0 1 39 40
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
212 0
216 0
4
0 0 46 47
0 2 39 40
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box4
2
212 0
216 0
4
0 0 46 47
0 3 39 40
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
184 0
214 0
4
0 0 47 38
0 4 31 21
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
184 0
214 0
4
0 0 47 38
0 1 31 21
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
184 0
214 0
4
0 0 47 38
0 2 31 21
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box4
2
184 0
214 0
4
0 0 47 38
0 3 31 21
0 37 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
211 0
215 0
4
0 0 47 46
0 4 38 37
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box2
2
211 0
215 0
4
0 0 47 46
0 1 38 37
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box3
2
211 0
215 0
4
0 0 47 46
0 2 38 37
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box4
2
211 0
215 0
4
0 0 47 46
0 3 38 37
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box1
2
217 0
245 0
4
0 0 47 56
0 4 48 55
0 65 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box2
2
217 0
245 0
4
0 0 47 56
0 1 48 55
0 65 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box3
2
217 0
245 0
4
0 0 47 56
0 2 48 55
0 65 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box4
2
217 0
245 0
4
0 0 47 56
0 3 48 55
0 65 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
188 0
218 0
4
0 0 48 39
0 4 32 22
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
188 0
218 0
4
0 0 48 39
0 1 32 22
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
188 0
218 0
4
0 0 48 39
0 2 32 22
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box4
2
188 0
218 0
4
0 0 48 39
0 3 32 22
0 38 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
215 0
219 0
4
0 0 48 47
0 4 39 38
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
215 0
219 0
4
0 0 48 47
0 1 39 38
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
215 0
219 0
4
0 0 48 47
0 2 39 38
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box4
2
215 0
219 0
4
0 0 48 47
0 3 39 38
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
220 0
249 0
4
0 0 48 57
0 4 49 56
0 66 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
220 0
249 0
4
0 0 48 57
0 1 49 56
0 66 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
220 0
249 0
4
0 0 48 57
0 2 49 56
0 66 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box4
2
220 0
249 0
4
0 0 48 57
0 3 49 56
0 66 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box1
2
195 0
221 0
4
0 0 49 41
0 4 34 24
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box2
2
195 0
221 0
4
0 0 49 41
0 1 34 24
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box3
2
195 0
221 0
4
0 0 49 41
0 2 34 24
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box4
2
195 0
221 0
4
0 0 49 41
0 3 34 24
0 40 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box1
2
200 0
222 0
4
0 0 49 42
0 4 35 36
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box2
2
200 0
222 0
4
0 0 49 42
0 1 35 36
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box3
2
200 0
222 0
4
0 0 49 42
0 2 35 36
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box4
2
200 0
222 0
4
0 0 49 42
0 3 35 36
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box1
2
223 0
255 0
4
0 0 49 59
0 4 51 57
0 68 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box2
2
223 0
255 0
4
0 0 49 59
0 1 51 57
0 68 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box3
2
223 0
255 0
4
0 0 49 59
0 2 51 57
0 68 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box4
2
223 0
255 0
4
0 0 49 59
0 3 51 57
0 68 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
199 0
224 0
4
0 0 50 42
0 4 35 25
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box2
2
199 0
224 0
4
0 0 50 42
0 1 35 25
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box3
2
199 0
224 0
4
0 0 50 42
0 2 35 25
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box4
2
199 0
224 0
4
0 0 50 42
0 3 35 25
0 41 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box1
2
225 0
230 0
4
0 0 50 51
0 4 43 44
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box2
2
225 0
230 0
4
0 0 50 51
0 1 43 44
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box3
2
225 0
230 0
4
0 0 50 51
0 2 43 44
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box4
2
225 0
230 0
4
0 0 50 51
0 3 43 44
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
226 0
254 0
4
0 0 50 59
0 4 51 50
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
226 0
254 0
4
0 0 50 59
0 1 51 50
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box3
2
226 0
254 0
4
0 0 50 59
0 2 51 50
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box4
2
226 0
254 0
4
0 0 50 59
0 3 51 50
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
227 0
259 0
4
0 0 50 60
0 4 52 58
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
227 0
259 0
4
0 0 50 60
0 1 52 58
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
227 0
259 0
4
0 0 50 60
0 2 52 58
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
227 0
259 0
4
0 0 50 60
0 3 52 58
0 69 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box1
2
203 0
228 0
4
0 0 51 43
0 4 36 26
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box2
2
203 0
228 0
4
0 0 51 43
0 1 36 26
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box3
2
203 0
228 0
4
0 0 51 43
0 2 36 26
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box4
2
203 0
228 0
4
0 0 51 43
0 3 36 26
0 42 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
226 0
229 0
4
0 0 51 50
0 4 42 51
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
226 0
229 0
4
0 0 51 50
0 1 42 51
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
226 0
229 0
4
0 0 51 50
0 2 42 51
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
226 0
229 0
4
0 0 51 50
0 3 42 51
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
231 0
263 0
4
0 0 51 61
0 4 53 59
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
231 0
263 0
4
0 0 51 61
0 1 53 59
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
231 0
263 0
4
0 0 51 61
0 2 53 59
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
231 0
263 0
4
0 0 51 61
0 3 53 59
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box1
2
229 0
232 0
4
0 0 52 51
0 4 43 42
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box2
2
229 0
232 0
4
0 0 52 51
0 1 43 42
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box3
2
229 0
232 0
4
0 0 52 51
0 2 43 42
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box4
2
229 0
232 0
4
0 0 52 51
0 3 43 42
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box1
2
233 0
266 0
4
0 0 52 62
0 4 54 60
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box2
2
233 0
266 0
4
0 0 52 62
0 1 54 60
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box3
2
233 0
266 0
4
0 0 52 62
0 2 54 60
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box4
2
233 0
266 0
4
0 0 52 62
0 3 54 60
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
234 0
238 0
4
0 0 53 54
0 4 46 47
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box2
2
234 0
238 0
4
0 0 53 54
0 1 46 47
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box3
2
234 0
238 0
4
0 0 53 54
0 2 46 47
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box4
2
234 0
238 0
4
0 0 53 54
0 3 46 47
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
207 0
236 0
4
0 0 54 45
0 4 37 29
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
207 0
236 0
4
0 0 54 45
0 1 37 29
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box3
2
207 0
236 0
4
0 0 54 45
0 2 37 29
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box4
2
207 0
236 0
4
0 0 54 45
0 3 37 29
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
238 0
241 0
4
0 0 54 55
0 4 47 48
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box2
2
238 0
241 0
4
0 0 54 55
0 1 47 48
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box3
2
238 0
241 0
4
0 0 54 55
0 2 47 48
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box4
2
238 0
241 0
4
0 0 54 55
0 3 47 48
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
210 0
239 0
4
0 0 55 46
0 4 38 30
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box2
2
210 0
239 0
4
0 0 55 46
0 1 38 30
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box3
2
210 0
239 0
4
0 0 55 46
0 2 38 30
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box4
2
210 0
239 0
4
0 0 55 46
0 3 38 30
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box1
2
237 0
240 0
4
0 0 55 54
0 4 46 45
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box2
2
237 0
240 0
4
0 0 55 54
0 1 46 45
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box3
2
237 0
240 0
4
0 0 55 54
0 2 46 45
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box4
2
237 0
240 0
4
0 0 55 54
0 3 46 45
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
241 0
244 0
4
0 0 55 56
0 4 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box2
2
241 0
244 0
4
0 0 55 56
0 1 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box3
2
241 0
244 0
4
0 0 55 56
0 2 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box4
2
241 0
244 0
4
0 0 55 56
0 3 48 49
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
214 0
242 0
4
0 0 56 47
0 4 39 31
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
214 0
242 0
4
0 0 56 47
0 1 39 31
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
214 0
242 0
4
0 0 56 47
0 2 39 31
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box4
2
214 0
242 0
4
0 0 56 47
0 3 39 31
0 47 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box1
2
240 0
243 0
4
0 0 56 55
0 4 47 46
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box2
2
240 0
243 0
4
0 0 56 55
0 1 47 46
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box3
2
240 0
243 0
4
0 0 56 55
0 2 47 46
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box4
2
240 0
243 0
4
0 0 56 55
0 3 47 46
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
244 0
248 0
4
0 0 56 57
0 4 49 50
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
244 0
248 0
4
0 0 56 57
0 1 49 50
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
244 0
248 0
4
0 0 56 57
0 2 49 50
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box4
2
244 0
248 0
4
0 0 56 57
0 3 49 50
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box1
2
245 0
271 0
4
0 0 56 64
0 4 55 64
0 73 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box2
2
245 0
271 0
4
0 0 56 64
0 1 55 64
0 73 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box3
2
245 0
271 0
4
0 0 56 64
0 2 55 64
0 73 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box4
2
245 0
271 0
4
0 0 56 64
0 3 55 64
0 73 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
218 0
246 0
4
0 0 57 48
0 4 40 32
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
218 0
246 0
4
0 0 57 48
0 1 40 32
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
218 0
246 0
4
0 0 57 48
0 2 40 32
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box4
2
218 0
246 0
4
0 0 57 48
0 3 40 32
0 48 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box1
2
243 0
247 0
4
0 0 57 56
0 4 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box2
2
243 0
247 0
4
0 0 57 56
0 1 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box3
2
243 0
247 0
4
0 0 57 56
0 2 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box4
2
243 0
247 0
4
0 0 57 56
0 3 48 47
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
248 0
251 0
4
0 0 57 58
0 4 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
248 0
251 0
4
0 0 57 58
0 1 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
248 0
251 0
4
0 0 57 58
0 2 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box4
2
248 0
251 0
4
0 0 57 58
0 3 50 51
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
249 0
274 0
4
0 0 57 65
0 4 56 65
0 74 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
249 0
274 0
4
0 0 57 65
0 1 56 65
0 74 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
249 0
274 0
4
0 0 57 65
0 2 56 65
0 74 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box4
2
249 0
274 0
4
0 0 57 65
0 3 56 65
0 74 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
247 0
250 0
4
0 0 58 57
0 4 49 48
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
247 0
250 0
4
0 0 58 57
0 1 49 48
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
247 0
250 0
4
0 0 58 57
0 2 49 48
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box4
2
247 0
250 0
4
0 0 58 57
0 3 49 48
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
251 0
253 0
4
0 0 58 59
0 4 51 42
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
251 0
253 0
4
0 0 58 59
0 1 51 42
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box3
2
251 0
253 0
4
0 0 58 59
0 2 51 42
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box4
2
251 0
253 0
4
0 0 58 59
0 3 51 42
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box1
2
221 0
252 0
4
0 0 59 49
0 4 41 34
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box2
2
221 0
252 0
4
0 0 59 49
0 1 41 34
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box3
2
221 0
252 0
4
0 0 59 49
0 2 41 34
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box4
2
221 0
252 0
4
0 0 59 49
0 3 41 34
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
225 0
253 0
4
0 0 59 50
0 4 42 43
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
225 0
253 0
4
0 0 59 50
0 1 42 43
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
225 0
253 0
4
0 0 59 50
0 2 42 43
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
225 0
253 0
4
0 0 59 50
0 3 42 43
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
250 0
254 0
4
0 0 59 58
0 4 50 49
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
250 0
254 0
4
0 0 59 58
0 1 50 49
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
250 0
254 0
4
0 0 59 58
0 2 50 49
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box4
2
250 0
254 0
4
0 0 59 58
0 3 50 49
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
255 0
277 0
4
0 0 59 66
0 4 57 67
0 75 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
255 0
277 0
4
0 0 59 66
0 1 57 67
0 75 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
255 0
277 0
4
0 0 59 66
0 2 57 67
0 75 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
255 0
277 0
4
0 0 59 66
0 3 57 67
0 75 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
224 0
256 0
4
0 0 60 50
0 4 42 35
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
224 0
256 0
4
0 0 60 50
0 1 42 35
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box3
2
224 0
256 0
4
0 0 60 50
0 2 42 35
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
224 0
256 0
4
0 0 60 50
0 3 42 35
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box1
2
257 0
262 0
4
0 0 60 61
0 4 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box2
2
257 0
262 0
4
0 0 60 61
0 1 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box3
2
257 0
262 0
4
0 0 60 61
0 2 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box4
2
257 0
262 0
4
0 0 60 61
0 3 53 54
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
259 0
278 0
4
0 0 60 67
0 4 58 0
0 5 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
259 0
278 0
4
0 0 60 67
0 1 58 0
0 5 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
259 0
278 0
4
0 0 60 67
0 2 58 0
0 5 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
259 0
278 0
4
0 0 60 67
0 3 58 0
0 5 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
228 0
260 0
4
0 0 61 51
0 4 43 36
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
228 0
260 0
4
0 0 61 51
0 1 43 36
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
228 0
260 0
4
0 0 61 51
0 2 43 36
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box4
2
228 0
260 0
4
0 0 61 51
0 3 43 36
0 52 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
258 0
261 0
4
0 0 61 60
0 4 52 57
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
258 0
261 0
4
0 0 61 60
0 1 52 57
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
258 0
261 0
4
0 0 61 60
0 2 52 57
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
258 0
261 0
4
0 0 61 60
0 3 52 57
0 69 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
263 0
282 0
4
0 0 61 68
0 4 59 1
0 6 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
263 0
282 0
4
0 0 61 68
0 1 59 1
0 6 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
263 0
282 0
4
0 0 61 68
0 2 59 1
0 6 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box4
2
263 0
282 0
4
0 0 61 68
0 3 59 1
0 6 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box1
2
261 0
265 0
4
0 0 62 61
0 4 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box2
2
261 0
265 0
4
0 0 62 61
0 1 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box3
2
261 0
265 0
4
0 0 62 61
0 2 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box4
2
261 0
265 0
4
0 0 62 61
0 3 53 52
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box1
2
266 0
286 0
4
0 0 62 69
0 4 60 2
0 7 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box2
2
266 0
286 0
4
0 0 62 69
0 1 60 2
0 7 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box3
2
266 0
286 0
4
0 0 62 69
0 2 60 2
0 7 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box4
2
266 0
286 0
4
0 0 62 69
0 3 60 2
0 7 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
242 0
269 0
4
0 0 64 56
0 4 48 39
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
242 0
269 0
4
0 0 64 56
0 1 48 39
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box3
2
242 0
269 0
4
0 0 64 56
0 2 48 39
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box4
2
242 0
269 0
4
0 0 64 56
0 3 48 39
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
246 0
272 0
4
0 0 65 57
0 4 49 40
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
246 0
272 0
4
0 0 65 57
0 1 49 40
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
246 0
272 0
4
0 0 65 57
0 2 49 40
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box4
2
246 0
272 0
4
0 0 65 57
0 3 49 40
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
274 0
299 0
4
0 0 65 74
0 4 65 3
0 10 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
274 0
299 0
4
0 0 65 74
0 1 65 3
0 10 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
274 0
299 0
4
0 0 65 74
0 2 65 3
0 10 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box4
2
274 0
299 0
4
0 0 65 74
0 3 65 3
0 10 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box1
2
252 0
275 0
4
0 0 66 59
0 4 51 41
0 58 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box2
2
252 0
275 0
4
0 0 66 59
0 1 51 41
0 58 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box3
2
252 0
275 0
4
0 0 66 59
0 2 51 41
0 58 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box4
2
252 0
275 0
4
0 0 66 59
0 3 51 41
0 58 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
257 0
276 0
4
0 0 66 60
0 4 52 53
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
257 0
276 0
4
0 0 66 60
0 1 52 53
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
257 0
276 0
4
0 0 66 60
0 2 52 53
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
257 0
276 0
4
0 0 66 60
0 3 52 53
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
256 0
279 0
4
0 0 67 60
0 4 52 42
0 59 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
256 0
279 0
4
0 0 67 60
0 1 52 42
0 59 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
256 0
279 0
4
0 0 67 60
0 2 52 42
0 59 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
256 0
279 0
4
0 0 67 60
0 3 52 42
0 59 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box1
2
280 0
285 0
4
0 0 67 68
0 4 59 60
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box2
2
280 0
285 0
4
0 0 67 68
0 1 59 60
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box3
2
280 0
285 0
4
0 0 67 68
0 2 59 60
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box4
2
280 0
285 0
4
0 0 67 68
0 3 59 60
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
281 0
307 0
4
0 0 67 76
0 4 67 66
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
281 0
307 0
4
0 0 67 76
0 1 67 66
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
281 0
307 0
4
0 0 67 76
0 2 67 66
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
281 0
307 0
4
0 0 67 76
0 3 67 66
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
260 0
283 0
4
0 0 68 61
0 4 53 43
0 60 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
260 0
283 0
4
0 0 68 61
0 1 53 43
0 60 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
260 0
283 0
4
0 0 68 61
0 2 53 43
0 60 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
260 0
283 0
4
0 0 68 61
0 3 53 43
0 60 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
281 0
284 0
4
0 0 68 67
0 4 58 67
0 76 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
281 0
284 0
4
0 0 68 67
0 1 58 67
0 76 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
281 0
284 0
4
0 0 68 67
0 2 58 67
0 76 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box4
2
281 0
284 0
4
0 0 68 67
0 3 58 67
0 76 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box1
2
92 0
286 0
4
0 0 69 2
0 4 2 4
0 7 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box2
2
92 0
286 0
4
0 0 69 2
0 1 2 4
0 7 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box3
2
92 0
286 0
4
0 0 69 2
0 2 2 4
0 7 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box4
2
92 0
286 0
4
0 0 69 2
0 3 2 4
0 7 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box1
2
264 0
287 0
4
0 0 69 62
0 4 54 44
0 61 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box2
2
264 0
287 0
4
0 0 69 62
0 1 54 44
0 61 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box3
2
264 0
287 0
4
0 0 69 62
0 2 54 44
0 61 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box4
2
264 0
287 0
4
0 0 69 62
0 3 54 44
0 61 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box1
2
284 0
288 0
4
0 0 69 68
0 4 59 58
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box2
2
284 0
288 0
4
0 0 69 68
0 1 59 58
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box3
2
284 0
288 0
4
0 0 69 68
0 2 59 58
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box4
2
284 0
288 0
4
0 0 69 68
0 3 59 58
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
290 0
292 0
4
0 0 70 71
0 4 62 63
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
290 0
292 0
4
0 0 70 71
0 1 62 63
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
290 0
292 0
4
0 0 70 71
0 2 62 63
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box4
2
290 0
292 0
4
0 0 70 71
0 3 62 63
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
292 0
295 0
4
0 0 71 72
0 4 63 64
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
292 0
295 0
4
0 0 71 72
0 1 63 64
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
292 0
295 0
4
0 0 71 72
0 2 63 64
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box4
2
292 0
295 0
4
0 0 71 72
0 3 63 64
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
291 0
294 0
4
0 0 72 71
0 4 62 61
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
291 0
294 0
4
0 0 72 71
0 1 62 61
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
291 0
294 0
4
0 0 72 71
0 2 62 61
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box4
2
291 0
294 0
4
0 0 72 71
0 3 62 61
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
295 0
298 0
4
0 0 72 73
0 4 64 65
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
295 0
298 0
4
0 0 72 73
0 1 64 65
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
295 0
298 0
4
0 0 72 73
0 2 64 65
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box4
2
295 0
298 0
4
0 0 72 73
0 3 64 65
0 82 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box1
2
269 0
296 0
4
0 0 73 64
0 4 55 48
0 65 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box2
2
269 0
296 0
4
0 0 73 64
0 1 55 48
0 65 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box3
2
269 0
296 0
4
0 0 73 64
0 2 55 48
0 65 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box4
2
269 0
296 0
4
0 0 73 64
0 3 55 48
0 65 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
294 0
297 0
4
0 0 73 72
0 4 63 62
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
294 0
297 0
4
0 0 73 72
0 1 63 62
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
294 0
297 0
4
0 0 73 72
0 2 63 62
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box4
2
294 0
297 0
4
0 0 73 72
0 3 63 62
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
298 0
302 0
4
0 0 73 74
0 4 65 66
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
298 0
302 0
4
0 0 73 74
0 1 65 66
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
298 0
302 0
4
0 0 73 74
0 2 65 66
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
298 0
302 0
4
0 0 73 74
0 3 65 66
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
95 0
299 0
4
0 0 74 4
0 4 3 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
95 0
299 0
4
0 0 74 4
0 1 3 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
95 0
299 0
4
0 0 74 4
0 2 3 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box4
2
95 0
299 0
4
0 0 74 4
0 3 3 5
0 10 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
272 0
300 0
4
0 0 74 65
0 4 56 49
0 66 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
272 0
300 0
4
0 0 74 65
0 1 56 49
0 66 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
272 0
300 0
4
0 0 74 65
0 2 56 49
0 66 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box4
2
272 0
300 0
4
0 0 74 65
0 3 56 49
0 66 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
297 0
301 0
4
0 0 74 73
0 4 64 63
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
297 0
301 0
4
0 0 74 73
0 1 64 63
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
297 0
301 0
4
0 0 74 73
0 2 64 63
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box4
2
297 0
301 0
4
0 0 74 73
0 3 64 63
0 81 0 1
0 82 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
302 0
304 0
4
0 0 74 75
0 4 66 67
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
302 0
304 0
4
0 0 74 75
0 1 66 67
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
302 0
304 0
4
0 0 74 75
0 2 66 67
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
302 0
304 0
4
0 0 74 75
0 3 66 67
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
301 0
303 0
4
0 0 75 74
0 4 65 64
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
301 0
303 0
4
0 0 75 74
0 1 65 64
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
301 0
303 0
4
0 0 75 74
0 2 65 64
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
301 0
303 0
4
0 0 75 74
0 3 65 64
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
304 0
306 0
4
0 0 75 76
0 4 67 58
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
304 0
306 0
4
0 0 75 76
0 1 67 58
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
304 0
306 0
4
0 0 75 76
0 2 67 58
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
304 0
306 0
4
0 0 75 76
0 3 67 58
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
275 0
305 0
4
0 0 76 66
0 4 57 51
0 68 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
275 0
305 0
4
0 0 76 66
0 1 57 51
0 68 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
275 0
305 0
4
0 0 76 66
0 2 57 51
0 68 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
275 0
305 0
4
0 0 76 66
0 3 57 51
0 68 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
280 0
306 0
4
0 0 76 67
0 4 58 59
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
280 0
306 0
4
0 0 76 67
0 1 58 59
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
280 0
306 0
4
0 0 76 67
0 2 58 59
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
280 0
306 0
4
0 0 76 67
0 3 58 59
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
303 0
307 0
4
0 0 76 75
0 4 66 65
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
303 0
307 0
4
0 0 76 75
0 1 66 65
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
303 0
307 0
4
0 0 76 75
0 2 66 65
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
303 0
307 0
4
0 0 76 75
0 3 66 65
0 83 0 1
0 84 -1 0
1
end_operator
0
