begin_version
3
end_version
begin_metric
1
end_metric
244
begin_variable
var0
-1
55
at-robot loc_10_10
at-robot loc_10_2
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_11_2
at-robot loc_11_3
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_7
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_12_3
at-robot loc_12_4
at-robot loc_12_5
at-robot loc_12_6
at-robot loc_12_7
at-robot loc_12_9
at-robot loc_4_8
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_6_9
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_12
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_12
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_2
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
52
at box2 loc_10_10
at box2 loc_10_2
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_11_3
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_7
at box2 loc_11_8
at box2 loc_11_9
at box2 loc_12_3
at box2 loc_12_4
at box2 loc_12_5
at box2 loc_12_6
at box2 loc_12_7
at box2 loc_4_8
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_6_9
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_12
at box2 loc_7_5
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_2
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var2
-1
51
at box3 loc_10_10
at box3 loc_10_2
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_7
at box3 loc_11_8
at box3 loc_11_9
at box3 loc_12_3
at box3 loc_12_4
at box3 loc_12_5
at box3 loc_12_6
at box3 loc_12_7
at box3 loc_4_8
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_10
at box3 loc_6_11
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_6_9
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_12
at box3 loc_7_5
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_4
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_8
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_2
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var3
-1
51
at box4 loc_10_10
at box4 loc_10_2
at box4 loc_10_3
at box4 loc_10_4
at box4 loc_10_5
at box4 loc_10_6
at box4 loc_10_7
at box4 loc_10_8
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_7
at box4 loc_11_8
at box4 loc_11_9
at box4 loc_12_3
at box4 loc_12_4
at box4 loc_12_5
at box4 loc_12_6
at box4 loc_12_7
at box4 loc_4_8
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_5_8
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_6_8
at box4 loc_6_9
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_12
at box4 loc_7_5
at box4 loc_7_6
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_4
at box4 loc_8_5
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_8
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_2
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var4
-1
51
at box1 loc_10_10
at box1 loc_10_2
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_7
at box1 loc_11_8
at box1 loc_11_9
at box1 loc_12_3
at box1 loc_12_4
at box1 loc_12_5
at box1 loc_12_6
at box1 loc_12_7
at box1 loc_4_8
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_6_9
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_12
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_2
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var5
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_12_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_12_4
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_12_5
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_12_7
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_2_10
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_7_12
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_10_2 loc_10_3 right
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_10_2 loc_11_2 down
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_10_2 loc_9_2 up
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_10_3 loc_10_2 left
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_10_8 loc_11_8 down
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_11_11 loc_11_12 right
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_11_12 loc_11_11 left
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_11_2 loc_10_2 up
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_11_3 loc_12_3 down
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_11_5 loc_12_5 down
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_11_6 loc_11_7 right
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_11_6 loc_12_6 down
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_11_7 loc_11_6 left
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_11_7 loc_11_8 right
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_11_7 loc_12_7 down
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_11_8 loc_10_8 up
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_11_8 loc_11_7 left
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_11_9 loc_12_9 down
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_12_3 loc_11_3 up
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_12_3 loc_12_4 right
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_12_4 loc_12_3 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_12_4 loc_12_5 right
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_12_5 loc_11_5 up
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_12_5 loc_12_4 left
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_12_5 loc_12_6 right
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_12_6 loc_11_6 up
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_12_6 loc_12_5 left
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_12_6 loc_12_7 right
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_12_7 loc_11_7 up
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_12_7 loc_12_6 left
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_12_9 loc_11_9 up
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_2_10 loc_3_10 down
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_2_7 loc_2_8 right
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_2_8 loc_2_7 left
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_3_10 loc_2_10 up
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_5_8 loc_6_8 down
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_6_10 loc_6_9 left
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_6_8 loc_5_8 up
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_6_8 loc_6_9 right
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_6_9 loc_6_10 right
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_6_9 loc_6_8 left
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_7_11 loc_7_12 right
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_7_12 loc_7_11 left
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_7_12 loc_8_12 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_8_12 loc_7_12 up
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_8_8 loc_9_8 down
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_9_2 loc_10_2 down
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_9_8 loc_8_8 up
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
42
8
34
50
29
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 11
2 35
3 8
4 7
end_goal
598
begin_operator
move loc_10_10 loc_9_10 up
2
67 0
74 0
1
0 0 0 48
1
end_operator
begin_operator
move loc_10_2 loc_10_3 right
2
7 0
75 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_2 loc_11_2 down
2
15 0
76 0
1
0 0 1 8
1
end_operator
begin_operator
move loc_10_2 loc_9_2 up
2
69 0
77 0
1
0 0 1 50
1
end_operator
begin_operator
move loc_10_3 loc_10_2 left
2
6 0
78 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
8 0
79 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
16 0
80 0
1
0 0 2 9
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
7 0
81 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
9 0
82 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
8 0
83 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
10 0
84 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
17 0
85 0
1
0 0 4 10
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
9 0
86 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
11 0
87 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
18 0
88 0
1
0 0 5 11
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
70 0
89 0
1
0 0 5 51
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
10 0
90 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
12 0
91 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
19 0
92 0
1
0 0 6 12
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
71 0
93 0
1
0 0 6 52
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
11 0
94 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_8 loc_11_8 down
2
20 0
95 0
1
0 0 7 13
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
72 0
96 0
1
0 0 7 53
1
end_operator
begin_operator
move loc_11_2 loc_10_2 up
2
6 0
99 0
1
0 0 8 1
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
16 0
100 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
7 0
101 0
1
0 0 9 2
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
15 0
102 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_11_3 loc_12_3 down
2
22 0
103 0
1
0 0 9 15
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
9 0
104 0
1
0 0 10 4
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
18 0
105 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_11_5 loc_12_5 down
2
24 0
106 0
1
0 0 10 17
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
10 0
107 0
1
0 0 11 5
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
17 0
108 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_11_6 loc_11_7 right
2
19 0
109 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_6 loc_12_6 down
2
25 0
110 0
1
0 0 11 18
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
11 0
111 0
1
0 0 12 6
1
end_operator
begin_operator
move loc_11_7 loc_11_6 left
2
18 0
112 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_7 loc_11_8 right
2
20 0
113 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_7 loc_12_7 down
2
26 0
114 0
1
0 0 12 19
1
end_operator
begin_operator
move loc_11_8 loc_10_8 up
2
12 0
115 0
1
0 0 13 7
1
end_operator
begin_operator
move loc_11_8 loc_11_7 left
2
19 0
116 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
21 0
117 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
20 0
118 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_11_9 loc_12_9 down
2
27 0
119 0
1
0 0 14 20
1
end_operator
begin_operator
move loc_12_3 loc_11_3 up
2
16 0
120 0
1
0 0 15 9
1
end_operator
begin_operator
move loc_12_3 loc_12_4 right
2
23 0
121 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_12_4 loc_12_3 left
2
22 0
122 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_12_4 loc_12_5 right
2
24 0
123 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_12_5 loc_11_5 up
2
17 0
124 0
1
0 0 17 10
1
end_operator
begin_operator
move loc_12_5 loc_12_4 left
2
23 0
125 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_12_5 loc_12_6 right
2
25 0
126 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_12_6 loc_11_6 up
2
18 0
127 0
1
0 0 18 11
1
end_operator
begin_operator
move loc_12_6 loc_12_5 left
2
24 0
128 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_12_6 loc_12_7 right
2
26 0
129 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_12_7 loc_11_7 up
2
19 0
130 0
1
0 0 19 12
1
end_operator
begin_operator
move loc_12_7 loc_12_6 left
2
25 0
131 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_12_9 loc_11_9 up
2
21 0
132 0
1
0 0 20 14
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
42 0
141 0
1
0 0 21 24
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
41 0
142 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
47 0
143 0
1
0 0 22 28
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
40 0
144 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
42 0
145 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
48 0
146 0
1
0 0 23 29
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
38 0
147 0
1
0 0 24 21
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
41 0
148 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
43 0
149 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_5_8 loc_6_8 down
2
49 0
150 0
1
0 0 24 30
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
42 0
151 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
50 0
152 0
1
0 0 25 31
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
45 0
153 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_6_10 loc_6_9 left
2
50 0
154 0
1
0 0 26 31
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
51 0
155 0
1
0 0 26 32
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
44 0
156 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
52 0
157 0
1
0 0 27 33
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
40 0
158 0
1
0 0 28 22
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
48 0
159 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
55 0
160 0
1
0 0 28 36
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
41 0
161 0
1
0 0 29 23
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
47 0
162 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
49 0
163 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
56 0
164 0
1
0 0 29 37
1
end_operator
begin_operator
move loc_6_8 loc_5_8 up
2
42 0
165 0
1
0 0 30 24
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
48 0
166 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_6_8 loc_6_9 right
2
50 0
167 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
57 0
168 0
1
0 0 30 38
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
43 0
169 0
1
0 0 31 25
1
end_operator
begin_operator
move loc_6_9 loc_6_10 right
2
44 0
170 0
1
0 0 31 26
1
end_operator
begin_operator
move loc_6_9 loc_6_8 left
2
49 0
171 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
58 0
172 0
1
0 0 31 39
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
44 0
173 0
1
0 0 32 26
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
52 0
174 0
1
0 0 32 33
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
58 0
175 0
1
0 0 32 39
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
59 0
176 0
1
0 0 32 40
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
45 0
177 0
1
0 0 33 27
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
51 0
178 0
1
0 0 33 32
1
end_operator
begin_operator
move loc_7_11 loc_7_12 right
2
53 0
179 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_7_12 loc_7_11 left
2
52 0
180 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_7_12 loc_8_12 down
2
60 0
181 0
1
0 0 34 41
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
55 0
182 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
62 0
183 0
1
0 0 35 43
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
47 0
184 0
1
0 0 36 28
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
54 0
185 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
56 0
186 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
63 0
187 0
1
0 0 36 44
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
48 0
188 0
1
0 0 37 29
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
55 0
189 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
57 0
190 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
64 0
191 0
1
0 0 37 45
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
49 0
192 0
1
0 0 38 30
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
56 0
193 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
58 0
194 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
65 0
195 0
1
0 0 38 46
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
50 0
196 0
1
0 0 39 31
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
51 0
197 0
1
0 0 39 32
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
57 0
198 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
66 0
199 0
1
0 0 39 47
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
51 0
200 0
1
0 0 40 32
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
66 0
201 0
1
0 0 40 47
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
67 0
202 0
1
0 0 40 48
1
end_operator
begin_operator
move loc_8_12 loc_7_12 up
2
53 0
203 0
1
0 0 41 34
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
62 0
204 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
54 0
205 0
1
0 0 43 35
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
61 0
206 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
63 0
207 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
55 0
208 0
1
0 0 44 36
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
62 0
209 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
64 0
210 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
70 0
211 0
1
0 0 44 51
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
56 0
212 0
1
0 0 45 37
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
63 0
213 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
65 0
214 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
71 0
215 0
1
0 0 45 52
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
57 0
216 0
1
0 0 46 38
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
64 0
217 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
66 0
218 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_8_8 loc_9_8 down
2
72 0
219 0
1
0 0 46 53
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
58 0
220 0
1
0 0 47 39
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
59 0
221 0
1
0 0 47 40
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
65 0
222 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
73 0
223 0
1
0 0 47 54
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
5 0
224 0
1
0 0 48 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
59 0
225 0
1
0 0 48 40
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
68 0
226 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
73 0
227 0
1
0 0 48 54
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
67 0
228 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_9_2 loc_10_2 down
2
6 0
229 0
1
0 0 50 1
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
10 0
230 0
1
0 0 51 5
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
63 0
231 0
1
0 0 51 44
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
71 0
232 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
11 0
233 0
1
0 0 52 6
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
64 0
234 0
1
0 0 52 45
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
70 0
235 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
72 0
236 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
12 0
237 0
1
0 0 53 7
1
end_operator
begin_operator
move loc_9_8 loc_8_8 up
2
65 0
238 0
1
0 0 53 46
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
71 0
239 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
73 0
240 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
66 0
241 0
1
0 0 54 47
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
67 0
242 0
1
0 0 54 48
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
72 0
243 0
1
0 0 54 53
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box1
2
75 0
79 0
4
0 0 1 2
0 4 2 3
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box2
2
75 0
79 0
4
0 0 1 2
0 1 2 3
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box3
2
75 0
79 0
4
0 0 1 2
0 2 2 3
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box4
2
75 0
79 0
4
0 0 1 2
0 3 2 3
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
79 0
82 0
4
0 0 2 3
0 4 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
79 0
82 0
4
0 0 2 3
0 1 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
79 0
82 0
4
0 0 2 3
0 2 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box4
2
79 0
82 0
4
0 0 2 3
0 3 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box2
2
80 0
103 0
4
0 0 2 9
0 1 8 14
0 16 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box1
2
78 0
81 0
4
0 0 3 2
0 4 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box2
2
78 0
81 0
4
0 0 3 2
0 1 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box3
2
78 0
81 0
4
0 0 3 2
0 2 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box4
2
78 0
81 0
4
0 0 3 2
0 3 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
82 0
84 0
4
0 0 3 4
0 4 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
82 0
84 0
4
0 0 3 4
0 1 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
82 0
84 0
4
0 0 3 4
0 2 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box4
2
82 0
84 0
4
0 0 3 4
0 3 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
81 0
83 0
4
0 0 4 3
0 4 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
81 0
83 0
4
0 0 4 3
0 1 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
81 0
83 0
4
0 0 4 3
0 2 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box4
2
81 0
83 0
4
0 0 4 3
0 3 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
84 0
87 0
4
0 0 4 5
0 4 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
84 0
87 0
4
0 0 4 5
0 1 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
84 0
87 0
4
0 0 4 5
0 2 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box4
2
84 0
87 0
4
0 0 4 5
0 3 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box1
2
85 0
106 0
4
0 0 4 10
0 4 8 15
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box2
2
85 0
106 0
4
0 0 4 10
0 1 9 16
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box3
2
85 0
106 0
4
0 0 4 10
0 2 8 15
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box4
2
85 0
106 0
4
0 0 4 10
0 3 8 15
0 17 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
83 0
86 0
4
0 0 5 4
0 4 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
83 0
86 0
4
0 0 5 4
0 1 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
83 0
86 0
4
0 0 5 4
0 2 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box4
2
83 0
86 0
4
0 0 5 4
0 3 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
87 0
91 0
4
0 0 5 6
0 4 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
87 0
91 0
4
0 0 5 6
0 1 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
87 0
91 0
4
0 0 5 6
0 2 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box4
2
87 0
91 0
4
0 0 5 6
0 3 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box1
2
88 0
110 0
4
0 0 5 11
0 4 9 16
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box2
2
88 0
110 0
4
0 0 5 11
0 1 10 17
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box3
2
88 0
110 0
4
0 0 5 11
0 2 9 16
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box4
2
88 0
110 0
4
0 0 5 11
0 3 9 16
0 18 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box1
2
89 0
231 0
4
0 0 5 51
0 4 47 40
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box2
2
89 0
231 0
4
0 0 5 51
0 1 48 41
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box3
2
89 0
231 0
4
0 0 5 51
0 2 47 40
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box4
2
89 0
231 0
4
0 0 5 51
0 3 47 40
0 63 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
86 0
90 0
4
0 0 6 5
0 4 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
86 0
90 0
4
0 0 6 5
0 1 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
86 0
90 0
4
0 0 6 5
0 2 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box4
2
86 0
90 0
4
0 0 6 5
0 3 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box1
2
92 0
114 0
4
0 0 6 12
0 4 10 17
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box2
2
92 0
114 0
4
0 0 6 12
0 1 11 18
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box3
2
92 0
114 0
4
0 0 6 12
0 2 10 17
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box4
2
92 0
114 0
4
0 0 6 12
0 3 10 17
0 19 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
93 0
234 0
4
0 0 6 52
0 4 48 41
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
93 0
234 0
4
0 0 6 52
0 1 49 42
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
93 0
234 0
4
0 0 6 52
0 2 48 41
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box4
2
93 0
234 0
4
0 0 6 52
0 3 48 41
0 64 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
90 0
94 0
4
0 0 7 6
0 4 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
90 0
94 0
4
0 0 7 6
0 1 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
90 0
94 0
4
0 0 7 6
0 2 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box4
2
90 0
94 0
4
0 0 7 6
0 3 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box1
2
96 0
238 0
4
0 0 7 53
0 4 49 42
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box2
2
96 0
238 0
4
0 0 7 53
0 1 50 43
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box3
2
96 0
238 0
4
0 0 7 53
0 2 49 42
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box4
2
96 0
238 0
4
0 0 7 53
0 3 49 42
0 65 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box1
2
77 0
99 0
4
0 0 8 1
0 4 1 46
0 6 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box2
2
77 0
99 0
4
0 0 8 1
0 1 1 47
0 6 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box3
2
77 0
99 0
4
0 0 8 1
0 2 1 46
0 6 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box4
2
77 0
99 0
4
0 0 8 1
0 3 1 46
0 6 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box1
2
105 0
109 0
4
0 0 10 11
0 4 9 10
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box2
2
105 0
109 0
4
0 0 10 11
0 1 10 11
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box3
2
105 0
109 0
4
0 0 10 11
0 2 9 10
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box4
2
105 0
109 0
4
0 0 10 11
0 3 9 10
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box1
2
89 0
107 0
4
0 0 11 5
0 4 5 47
0 10 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box2
2
89 0
107 0
4
0 0 11 5
0 1 5 48
0 10 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box3
2
89 0
107 0
4
0 0 11 5
0 2 5 47
0 10 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box4
2
89 0
107 0
4
0 0 11 5
0 3 5 47
0 10 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box1
2
109 0
113 0
4
0 0 11 12
0 4 10 11
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box2
2
109 0
113 0
4
0 0 11 12
0 1 11 12
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box3
2
109 0
113 0
4
0 0 11 12
0 2 10 11
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box4
2
109 0
113 0
4
0 0 11 12
0 3 10 11
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
93 0
111 0
4
0 0 12 6
0 4 6 48
0 11 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
93 0
111 0
4
0 0 12 6
0 1 6 49
0 11 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
93 0
111 0
4
0 0 12 6
0 2 6 48
0 11 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box4
2
93 0
111 0
4
0 0 12 6
0 3 6 48
0 11 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box1
2
108 0
112 0
4
0 0 12 11
0 4 9 8
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box2
2
108 0
112 0
4
0 0 12 11
0 1 10 9
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box3
2
108 0
112 0
4
0 0 12 11
0 2 9 8
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box4
2
108 0
112 0
4
0 0 12 11
0 3 9 8
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box1
2
113 0
117 0
4
0 0 12 13
0 4 11 12
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box2
2
113 0
117 0
4
0 0 12 13
0 1 12 13
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box3
2
113 0
117 0
4
0 0 12 13
0 2 11 12
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box4
2
113 0
117 0
4
0 0 12 13
0 3 11 12
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box1
2
96 0
115 0
4
0 0 13 7
0 4 7 49
0 12 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box2
2
96 0
115 0
4
0 0 13 7
0 1 7 50
0 12 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box3
2
96 0
115 0
4
0 0 13 7
0 2 7 49
0 12 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box4
2
96 0
115 0
4
0 0 13 7
0 3 7 49
0 12 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box1
2
112 0
116 0
4
0 0 13 12
0 4 10 9
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box2
2
112 0
116 0
4
0 0 13 12
0 1 11 10
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box3
2
112 0
116 0
4
0 0 13 12
0 2 10 9
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box4
2
112 0
116 0
4
0 0 13 12
0 3 10 9
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box2
2
101 0
120 0
4
0 0 15 9
0 1 8 2
0 7 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box1
2
121 0
123 0
4
0 0 15 16
0 4 14 15
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box2
2
121 0
123 0
4
0 0 15 16
0 1 15 16
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box3
2
121 0
123 0
4
0 0 15 16
0 2 14 15
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box4
2
121 0
123 0
4
0 0 15 16
0 3 14 15
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box1
2
123 0
126 0
4
0 0 16 17
0 4 15 16
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box2
2
123 0
126 0
4
0 0 16 17
0 1 16 17
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box3
2
123 0
126 0
4
0 0 16 17
0 2 15 16
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box4
2
123 0
126 0
4
0 0 16 17
0 3 15 16
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box1
2
104 0
124 0
4
0 0 17 10
0 4 8 4
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box2
2
104 0
124 0
4
0 0 17 10
0 1 9 4
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box3
2
104 0
124 0
4
0 0 17 10
0 2 8 4
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box4
2
104 0
124 0
4
0 0 17 10
0 3 8 4
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box1
2
122 0
125 0
4
0 0 17 16
0 4 14 13
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box2
2
122 0
125 0
4
0 0 17 16
0 1 15 14
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box3
2
122 0
125 0
4
0 0 17 16
0 2 14 13
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box4
2
122 0
125 0
4
0 0 17 16
0 3 14 13
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box1
2
126 0
129 0
4
0 0 17 18
0 4 16 17
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box2
2
126 0
129 0
4
0 0 17 18
0 1 17 18
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box3
2
126 0
129 0
4
0 0 17 18
0 2 16 17
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_12_5 loc_12_6 loc_12_7 right box4
2
126 0
129 0
4
0 0 17 18
0 3 16 17
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box1
2
107 0
127 0
4
0 0 18 11
0 4 9 5
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box2
2
107 0
127 0
4
0 0 18 11
0 1 10 5
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box3
2
107 0
127 0
4
0 0 18 11
0 2 9 5
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box4
2
107 0
127 0
4
0 0 18 11
0 3 9 5
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box1
2
125 0
128 0
4
0 0 18 17
0 4 15 14
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box2
2
125 0
128 0
4
0 0 18 17
0 1 16 15
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box3
2
125 0
128 0
4
0 0 18 17
0 2 15 14
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box4
2
125 0
128 0
4
0 0 18 17
0 3 15 14
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box1
2
111 0
130 0
4
0 0 19 12
0 4 10 6
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box2
2
111 0
130 0
4
0 0 19 12
0 1 11 6
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box3
2
111 0
130 0
4
0 0 19 12
0 2 10 6
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box4
2
111 0
130 0
4
0 0 19 12
0 3 10 6
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box1
2
128 0
131 0
4
0 0 19 18
0 4 16 15
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box2
2
128 0
131 0
4
0 0 19 18
0 1 17 16
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box3
2
128 0
131 0
4
0 0 19 18
0 2 16 15
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_12_6 loc_12_5 left box4
2
128 0
131 0
4
0 0 19 18
0 3 16 15
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
142 0
145 0
4
0 0 22 23
0 4 20 21
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
142 0
145 0
4
0 0 22 23
0 1 21 22
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
142 0
145 0
4
0 0 22 23
0 2 20 21
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box4
2
142 0
145 0
4
0 0 22 23
0 3 20 21
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
143 0
160 0
4
0 0 22 28
0 4 25 33
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
143 0
160 0
4
0 0 22 28
0 1 26 34
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
143 0
160 0
4
0 0 22 28
0 2 25 33
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box4
2
143 0
160 0
4
0 0 22 28
0 3 25 33
0 47 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
145 0
149 0
4
0 0 23 24
0 4 21 22
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
145 0
149 0
4
0 0 23 24
0 1 22 23
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
145 0
149 0
4
0 0 23 24
0 2 21 22
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box4
2
145 0
149 0
4
0 0 23 24
0 3 21 22
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
146 0
164 0
4
0 0 23 29
0 4 26 34
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
146 0
164 0
4
0 0 23 29
0 1 27 35
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
146 0
164 0
4
0 0 23 29
0 2 26 34
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box4
2
146 0
164 0
4
0 0 23 29
0 3 26 34
0 48 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
144 0
148 0
4
0 0 24 23
0 4 20 19
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
144 0
148 0
4
0 0 24 23
0 1 21 20
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
144 0
148 0
4
0 0 24 23
0 2 20 19
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box4
2
144 0
148 0
4
0 0 24 23
0 3 20 19
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box1
2
150 0
168 0
4
0 0 24 30
0 4 27 35
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box2
2
150 0
168 0
4
0 0 24 30
0 1 28 36
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box3
2
150 0
168 0
4
0 0 24 30
0 2 27 35
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box4
2
150 0
168 0
4
0 0 24 30
0 3 27 35
0 49 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
148 0
151 0
4
0 0 25 24
0 4 21 20
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
148 0
151 0
4
0 0 25 24
0 1 22 21
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
148 0
151 0
4
0 0 25 24
0 2 21 20
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box4
2
148 0
151 0
4
0 0 25 24
0 3 21 20
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box1
2
152 0
172 0
4
0 0 25 31
0 4 28 36
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box2
2
152 0
172 0
4
0 0 25 31
0 1 29 37
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box3
2
152 0
172 0
4
0 0 25 31
0 2 28 36
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box4
2
152 0
172 0
4
0 0 25 31
0 3 28 36
0 50 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box1
2
154 0
171 0
4
0 0 26 31
0 4 28 27
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box2
2
154 0
171 0
4
0 0 26 31
0 1 29 28
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box3
2
154 0
171 0
4
0 0 26 31
0 2 28 27
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box4
2
154 0
171 0
4
0 0 26 31
0 3 28 27
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
155 0
176 0
4
0 0 26 32
0 4 29 37
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
155 0
176 0
4
0 0 26 32
0 1 30 38
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box3
2
155 0
176 0
4
0 0 26 32
0 2 29 37
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
155 0
176 0
4
0 0 26 32
0 3 29 37
0 51 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box1
2
154 0
156 0
4
0 0 27 26
0 4 23 28
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box2
2
154 0
156 0
4
0 0 27 26
0 1 24 29
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box3
2
154 0
156 0
4
0 0 27 26
0 2 23 28
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box4
2
154 0
156 0
4
0 0 27 26
0 3 23 28
0 44 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
159 0
163 0
4
0 0 28 29
0 4 26 27
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
159 0
163 0
4
0 0 28 29
0 1 27 28
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
159 0
163 0
4
0 0 28 29
0 2 26 27
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box4
2
159 0
163 0
4
0 0 28 29
0 3 26 27
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box1
2
160 0
187 0
4
0 0 28 36
0 4 33 40
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box2
2
160 0
187 0
4
0 0 28 36
0 1 34 41
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box3
2
160 0
187 0
4
0 0 28 36
0 2 33 40
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box4
2
160 0
187 0
4
0 0 28 36
0 3 33 40
0 55 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box1
2
163 0
167 0
4
0 0 29 30
0 4 27 28
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box2
2
163 0
167 0
4
0 0 29 30
0 1 28 29
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box3
2
163 0
167 0
4
0 0 29 30
0 2 27 28
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box4
2
163 0
167 0
4
0 0 29 30
0 3 27 28
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
164 0
191 0
4
0 0 29 37
0 4 34 41
0 56 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
164 0
191 0
4
0 0 29 37
0 1 35 42
0 56 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
164 0
191 0
4
0 0 29 37
0 2 34 41
0 56 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box4
2
164 0
191 0
4
0 0 29 37
0 3 34 41
0 56 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box1
2
147 0
165 0
4
0 0 30 24
0 4 21 18
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box2
2
147 0
165 0
4
0 0 30 24
0 1 22 19
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box3
2
147 0
165 0
4
0 0 30 24
0 2 21 18
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box4
2
147 0
165 0
4
0 0 30 24
0 3 21 18
0 38 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
162 0
166 0
4
0 0 30 29
0 4 26 25
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
162 0
166 0
4
0 0 30 29
0 1 27 26
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
162 0
166 0
4
0 0 30 29
0 2 26 25
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box4
2
162 0
166 0
4
0 0 30 29
0 3 26 25
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box1
2
167 0
170 0
4
0 0 30 31
0 4 28 23
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box2
2
167 0
170 0
4
0 0 30 31
0 1 29 24
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box3
2
167 0
170 0
4
0 0 30 31
0 2 28 23
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box4
2
167 0
170 0
4
0 0 30 31
0 3 28 23
0 44 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box1
2
168 0
195 0
4
0 0 30 38
0 4 35 42
0 57 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box2
2
168 0
195 0
4
0 0 30 38
0 1 36 43
0 57 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box3
2
168 0
195 0
4
0 0 30 38
0 2 35 42
0 57 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box4
2
168 0
195 0
4
0 0 30 38
0 3 35 42
0 57 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box1
2
153 0
170 0
4
0 0 31 26
0 4 23 24
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box2
2
153 0
170 0
4
0 0 31 26
0 1 24 25
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box3
2
153 0
170 0
4
0 0 31 26
0 2 23 24
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box4
2
153 0
170 0
4
0 0 31 26
0 3 23 24
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box1
2
166 0
171 0
4
0 0 31 30
0 4 27 26
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box2
2
166 0
171 0
4
0 0 31 30
0 1 28 27
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box3
2
166 0
171 0
4
0 0 31 30
0 2 27 26
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box4
2
166 0
171 0
4
0 0 31 30
0 3 27 26
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box1
2
172 0
199 0
4
0 0 31 39
0 4 36 43
0 58 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box2
2
172 0
199 0
4
0 0 31 39
0 1 37 44
0 58 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box3
2
172 0
199 0
4
0 0 31 39
0 2 36 43
0 58 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box4
2
172 0
199 0
4
0 0 31 39
0 3 36 43
0 58 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box1
2
174 0
179 0
4
0 0 32 33
0 4 30 31
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box2
2
174 0
179 0
4
0 0 32 33
0 1 31 32
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box3
2
174 0
179 0
4
0 0 32 33
0 2 30 31
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box4
2
174 0
179 0
4
0 0 32 33
0 3 30 31
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
175 0
198 0
4
0 0 32 39
0 4 36 35
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
175 0
198 0
4
0 0 32 39
0 1 37 36
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box3
2
175 0
198 0
4
0 0 32 39
0 2 36 35
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box4
2
175 0
198 0
4
0 0 32 39
0 3 36 35
0 57 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
176 0
202 0
4
0 0 32 40
0 4 37 44
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
176 0
202 0
4
0 0 32 40
0 1 38 45
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
176 0
202 0
4
0 0 32 40
0 2 37 44
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
176 0
202 0
4
0 0 32 40
0 3 37 44
0 59 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
175 0
178 0
4
0 0 33 32
0 4 29 36
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
175 0
178 0
4
0 0 33 32
0 1 30 37
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
175 0
178 0
4
0 0 33 32
0 2 29 36
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
175 0
178 0
4
0 0 33 32
0 3 29 36
0 51 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
182 0
186 0
4
0 0 35 36
0 4 33 34
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box2
2
182 0
186 0
4
0 0 35 36
0 1 34 35
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box3
2
182 0
186 0
4
0 0 35 36
0 2 33 34
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box4
2
182 0
186 0
4
0 0 35 36
0 3 33 34
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
158 0
184 0
4
0 0 36 28
0 4 25 19
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
158 0
184 0
4
0 0 36 28
0 1 26 20
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
158 0
184 0
4
0 0 36 28
0 2 25 19
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box4
2
158 0
184 0
4
0 0 36 28
0 3 25 19
0 40 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
186 0
190 0
4
0 0 36 37
0 4 34 35
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
186 0
190 0
4
0 0 36 37
0 1 35 36
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
186 0
190 0
4
0 0 36 37
0 2 34 35
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box4
2
186 0
190 0
4
0 0 36 37
0 3 34 35
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box1
2
187 0
211 0
4
0 0 36 44
0 4 40 47
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box2
2
187 0
211 0
4
0 0 36 44
0 1 41 48
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box3
2
187 0
211 0
4
0 0 36 44
0 2 40 47
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box4
2
187 0
211 0
4
0 0 36 44
0 3 40 47
0 63 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
161 0
188 0
4
0 0 37 29
0 4 26 20
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
161 0
188 0
4
0 0 37 29
0 1 27 21
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
161 0
188 0
4
0 0 37 29
0 2 26 20
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box4
2
161 0
188 0
4
0 0 37 29
0 3 26 20
0 41 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box1
2
185 0
189 0
4
0 0 37 36
0 4 33 32
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box2
2
185 0
189 0
4
0 0 37 36
0 1 34 33
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box3
2
185 0
189 0
4
0 0 37 36
0 2 33 32
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box4
2
185 0
189 0
4
0 0 37 36
0 3 33 32
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
190 0
194 0
4
0 0 37 38
0 4 35 36
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
190 0
194 0
4
0 0 37 38
0 1 36 37
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
190 0
194 0
4
0 0 37 38
0 2 35 36
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box4
2
190 0
194 0
4
0 0 37 38
0 3 35 36
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
191 0
215 0
4
0 0 37 45
0 4 41 48
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
191 0
215 0
4
0 0 37 45
0 1 42 49
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
191 0
215 0
4
0 0 37 45
0 2 41 48
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box4
2
191 0
215 0
4
0 0 37 45
0 3 41 48
0 64 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box1
2
165 0
192 0
4
0 0 38 30
0 4 27 21
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box2
2
165 0
192 0
4
0 0 38 30
0 1 28 22
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box3
2
165 0
192 0
4
0 0 38 30
0 2 27 21
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box4
2
165 0
192 0
4
0 0 38 30
0 3 27 21
0 42 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
189 0
193 0
4
0 0 38 37
0 4 34 33
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
189 0
193 0
4
0 0 38 37
0 1 35 34
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
189 0
193 0
4
0 0 38 37
0 2 34 33
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box4
2
189 0
193 0
4
0 0 38 37
0 3 34 33
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
194 0
197 0
4
0 0 38 39
0 4 36 29
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
194 0
197 0
4
0 0 38 39
0 1 37 30
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box3
2
194 0
197 0
4
0 0 38 39
0 2 36 29
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box4
2
194 0
197 0
4
0 0 38 39
0 3 36 29
0 51 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box1
2
195 0
219 0
4
0 0 38 46
0 4 42 49
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box2
2
195 0
219 0
4
0 0 38 46
0 1 43 50
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box3
2
195 0
219 0
4
0 0 38 46
0 2 42 49
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_8 loc_8_8 loc_9_8 down box4
2
195 0
219 0
4
0 0 38 46
0 3 42 49
0 65 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box1
2
169 0
196 0
4
0 0 39 31
0 4 28 22
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box2
2
169 0
196 0
4
0 0 39 31
0 1 29 23
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box3
2
169 0
196 0
4
0 0 39 31
0 2 28 22
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box4
2
169 0
196 0
4
0 0 39 31
0 3 28 22
0 43 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
174 0
197 0
4
0 0 39 32
0 4 29 30
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
174 0
197 0
4
0 0 39 32
0 1 30 31
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
174 0
197 0
4
0 0 39 32
0 2 29 30
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
174 0
197 0
4
0 0 39 32
0 3 29 30
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
193 0
198 0
4
0 0 39 38
0 4 35 34
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
193 0
198 0
4
0 0 39 38
0 1 36 35
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
193 0
198 0
4
0 0 39 38
0 2 35 34
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box4
2
193 0
198 0
4
0 0 39 38
0 3 35 34
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
199 0
223 0
4
0 0 39 47
0 4 43 50
0 66 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
199 0
223 0
4
0 0 39 47
0 1 44 51
0 66 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
199 0
223 0
4
0 0 39 47
0 2 43 50
0 66 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
199 0
223 0
4
0 0 39 47
0 3 43 50
0 66 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
173 0
200 0
4
0 0 40 32
0 4 29 23
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
173 0
200 0
4
0 0 40 32
0 1 30 24
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box3
2
173 0
200 0
4
0 0 40 32
0 2 29 23
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
173 0
200 0
4
0 0 40 32
0 3 29 23
0 44 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
201 0
222 0
4
0 0 40 47
0 4 43 42
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
201 0
222 0
4
0 0 40 47
0 1 44 43
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box3
2
201 0
222 0
4
0 0 40 47
0 2 43 42
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box4
2
201 0
222 0
4
0 0 40 47
0 3 43 42
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
202 0
224 0
4
0 0 40 48
0 4 44 0
0 5 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
202 0
224 0
4
0 0 40 48
0 1 45 0
0 5 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
202 0
224 0
4
0 0 40 48
0 2 44 0
0 5 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
202 0
224 0
4
0 0 40 48
0 3 44 0
0 5 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
207 0
210 0
4
0 0 43 44
0 4 40 41
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
207 0
210 0
4
0 0 43 44
0 1 41 42
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
207 0
210 0
4
0 0 43 44
0 2 40 41
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box4
2
207 0
210 0
4
0 0 43 44
0 3 40 41
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
184 0
208 0
4
0 0 44 36
0 4 33 25
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
184 0
208 0
4
0 0 44 36
0 1 34 26
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box3
2
184 0
208 0
4
0 0 44 36
0 2 33 25
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box4
2
184 0
208 0
4
0 0 44 36
0 3 33 25
0 47 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
206 0
209 0
4
0 0 44 43
0 4 39 38
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
206 0
209 0
4
0 0 44 43
0 1 40 39
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box3
2
206 0
209 0
4
0 0 44 43
0 2 39 38
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box4
2
206 0
209 0
4
0 0 44 43
0 3 39 38
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box1
2
210 0
214 0
4
0 0 44 45
0 4 41 42
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box2
2
210 0
214 0
4
0 0 44 45
0 1 42 43
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box3
2
210 0
214 0
4
0 0 44 45
0 2 41 42
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box4
2
210 0
214 0
4
0 0 44 45
0 3 41 42
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box1
2
211 0
230 0
4
0 0 44 51
0 4 47 5
0 10 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box2
2
211 0
230 0
4
0 0 44 51
0 1 48 5
0 10 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box3
2
211 0
230 0
4
0 0 44 51
0 2 47 5
0 10 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box4
2
211 0
230 0
4
0 0 44 51
0 3 47 5
0 10 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
188 0
212 0
4
0 0 45 37
0 4 34 26
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
188 0
212 0
4
0 0 45 37
0 1 35 27
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
188 0
212 0
4
0 0 45 37
0 2 34 26
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box4
2
188 0
212 0
4
0 0 45 37
0 3 34 26
0 48 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
209 0
213 0
4
0 0 45 44
0 4 40 39
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
209 0
213 0
4
0 0 45 44
0 1 41 40
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
209 0
213 0
4
0 0 45 44
0 2 40 39
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box4
2
209 0
213 0
4
0 0 45 44
0 3 40 39
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
214 0
218 0
4
0 0 45 46
0 4 42 43
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
214 0
218 0
4
0 0 45 46
0 1 43 44
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box3
2
214 0
218 0
4
0 0 45 46
0 2 42 43
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box4
2
214 0
218 0
4
0 0 45 46
0 3 42 43
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
215 0
233 0
4
0 0 45 52
0 4 48 6
0 11 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
215 0
233 0
4
0 0 45 52
0 1 49 6
0 11 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
215 0
233 0
4
0 0 45 52
0 2 48 6
0 11 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box4
2
215 0
233 0
4
0 0 45 52
0 3 48 6
0 11 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box1
2
192 0
216 0
4
0 0 46 38
0 4 35 27
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box2
2
192 0
216 0
4
0 0 46 38
0 1 36 28
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box3
2
192 0
216 0
4
0 0 46 38
0 2 35 27
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box4
2
192 0
216 0
4
0 0 46 38
0 3 35 27
0 49 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box1
2
213 0
217 0
4
0 0 46 45
0 4 41 40
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box2
2
213 0
217 0
4
0 0 46 45
0 1 42 41
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box3
2
213 0
217 0
4
0 0 46 45
0 2 41 40
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box4
2
213 0
217 0
4
0 0 46 45
0 3 41 40
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
218 0
221 0
4
0 0 46 47
0 4 43 37
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
218 0
221 0
4
0 0 46 47
0 1 44 38
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box3
2
218 0
221 0
4
0 0 46 47
0 2 43 37
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box4
2
218 0
221 0
4
0 0 46 47
0 3 43 37
0 59 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box1
2
219 0
237 0
4
0 0 46 53
0 4 49 7
0 12 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box2
2
219 0
237 0
4
0 0 46 53
0 1 50 7
0 12 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box3
2
219 0
237 0
4
0 0 46 53
0 2 49 7
0 12 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box4
2
219 0
237 0
4
0 0 46 53
0 3 49 7
0 12 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box1
2
196 0
220 0
4
0 0 47 39
0 4 36 28
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box2
2
196 0
220 0
4
0 0 47 39
0 1 37 29
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box3
2
196 0
220 0
4
0 0 47 39
0 2 36 28
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box4
2
196 0
220 0
4
0 0 47 39
0 3 36 28
0 50 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
217 0
222 0
4
0 0 47 46
0 4 42 41
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
217 0
222 0
4
0 0 47 46
0 1 43 42
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box3
2
217 0
222 0
4
0 0 47 46
0 2 42 41
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box4
2
217 0
222 0
4
0 0 47 46
0 3 42 41
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
200 0
225 0
4
0 0 48 40
0 4 37 29
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
200 0
225 0
4
0 0 48 40
0 1 38 30
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
200 0
225 0
4
0 0 48 40
0 2 37 29
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
200 0
225 0
4
0 0 48 40
0 3 37 29
0 51 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
227 0
243 0
4
0 0 48 54
0 4 50 49
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
227 0
243 0
4
0 0 48 54
0 1 51 50
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
227 0
243 0
4
0 0 48 54
0 2 50 49
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
227 0
243 0
4
0 0 48 54
0 3 50 49
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box1
2
88 0
230 0
4
0 0 51 5
0 4 5 9
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box2
2
88 0
230 0
4
0 0 51 5
0 1 5 10
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box3
2
88 0
230 0
4
0 0 51 5
0 2 5 9
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box4
2
88 0
230 0
4
0 0 51 5
0 3 5 9
0 10 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box1
2
208 0
231 0
4
0 0 51 44
0 4 40 33
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box2
2
208 0
231 0
4
0 0 51 44
0 1 41 34
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box3
2
208 0
231 0
4
0 0 51 44
0 2 40 33
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box4
2
208 0
231 0
4
0 0 51 44
0 3 40 33
0 55 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
232 0
236 0
4
0 0 51 52
0 4 48 49
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
232 0
236 0
4
0 0 51 52
0 1 49 50
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
232 0
236 0
4
0 0 51 52
0 2 48 49
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
232 0
236 0
4
0 0 51 52
0 3 48 49
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
92 0
233 0
4
0 0 52 6
0 4 6 10
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
92 0
233 0
4
0 0 52 6
0 1 6 11
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
92 0
233 0
4
0 0 52 6
0 2 6 10
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box4
2
92 0
233 0
4
0 0 52 6
0 3 6 10
0 11 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
212 0
234 0
4
0 0 52 45
0 4 41 34
0 56 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
212 0
234 0
4
0 0 52 45
0 1 42 35
0 56 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
212 0
234 0
4
0 0 52 45
0 2 41 34
0 56 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box4
2
212 0
234 0
4
0 0 52 45
0 3 41 34
0 56 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
236 0
240 0
4
0 0 52 53
0 4 49 50
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
236 0
240 0
4
0 0 52 53
0 1 50 51
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
236 0
240 0
4
0 0 52 53
0 2 49 50
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
236 0
240 0
4
0 0 52 53
0 3 49 50
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box1
2
95 0
237 0
4
0 0 53 7
0 4 7 11
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box2
2
95 0
237 0
4
0 0 53 7
0 1 7 12
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box3
2
95 0
237 0
4
0 0 53 7
0 2 7 11
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box4
2
95 0
237 0
4
0 0 53 7
0 3 7 11
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box1
2
216 0
238 0
4
0 0 53 46
0 4 42 35
0 57 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box2
2
216 0
238 0
4
0 0 53 46
0 1 43 36
0 57 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box3
2
216 0
238 0
4
0 0 53 46
0 2 42 35
0 57 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_8_8 loc_7_8 up box4
2
216 0
238 0
4
0 0 53 46
0 3 42 35
0 57 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
235 0
239 0
4
0 0 53 52
0 4 48 47
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
235 0
239 0
4
0 0 53 52
0 1 49 48
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
235 0
239 0
4
0 0 53 52
0 2 48 47
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
235 0
239 0
4
0 0 53 52
0 3 48 47
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
240 0
242 0
4
0 0 53 54
0 4 50 44
0 67 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
240 0
242 0
4
0 0 53 54
0 1 51 45
0 67 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
240 0
242 0
4
0 0 53 54
0 2 50 44
0 67 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
240 0
242 0
4
0 0 53 54
0 3 50 44
0 67 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
220 0
241 0
4
0 0 54 47
0 4 43 36
0 58 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
220 0
241 0
4
0 0 54 47
0 1 44 37
0 58 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
220 0
241 0
4
0 0 54 47
0 2 43 36
0 58 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
220 0
241 0
4
0 0 54 47
0 3 43 36
0 58 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
226 0
242 0
4
0 0 54 48
0 4 44 45
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
226 0
242 0
4
0 0 54 48
0 1 45 46
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
226 0
242 0
4
0 0 54 48
0 2 44 45
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
226 0
242 0
4
0 0 54 48
0 3 44 45
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
239 0
243 0
4
0 0 54 53
0 4 49 48
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
239 0
243 0
4
0 0 54 53
0 1 50 49
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
239 0
243 0
4
0 0 54 53
0 2 49 48
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
239 0
243 0
4
0 0 54 53
0 3 49 48
0 71 0 1
0 72 -1 0
1
end_operator
0
