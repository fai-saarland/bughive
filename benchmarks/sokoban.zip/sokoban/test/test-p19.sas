begin_version
3
end_version
begin_metric
1
end_metric
173
begin_variable
var0
-1
41
at-robot loc_2_3
at-robot loc_2_8
at-robot loc_2_9
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_3_9
at-robot loc_4_10
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_4
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_6_9
at-robot loc_7_4
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_7
at-robot loc_8_8
end_variable
begin_variable
var1
-1
40
at box1 loc_2_3
at box1 loc_2_8
at box1 loc_2_9
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_3_9
at box1 loc_4_10
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_4
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_6_9
at box1 loc_7_4
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_4
at box1 loc_8_7
at box1 loc_8_8
end_variable
begin_variable
var2
-1
40
at box2 loc_2_3
at box2 loc_2_8
at box2 loc_2_9
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_3_8
at box2 loc_3_9
at box2 loc_4_10
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_4_8
at box2 loc_4_9
at box2 loc_5_10
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_4
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_6_9
at box2 loc_7_4
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_4
at box2 loc_8_7
at box2 loc_8_8
end_variable
begin_variable
var3
-1
40
at box3 loc_2_3
at box3 loc_2_8
at box3 loc_2_9
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_3_7
at box3 loc_3_8
at box3 loc_3_9
at box3 loc_4_10
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_4_8
at box3 loc_4_9
at box3 loc_5_10
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_4
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_6_9
at box3 loc_7_4
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_4
at box3 loc_8_7
at box3 loc_8_8
end_variable
begin_variable
var4
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var5
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_2_9
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var49
-1
2
adjacent loc_10_2 loc_9_2 up
none-of-those
end_variable
begin_variable
var50
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var51
-1
2
adjacent loc_2_8 loc_2_9 right
none-of-those
end_variable
begin_variable
var52
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var53
-1
2
adjacent loc_2_9 loc_2_8 left
none-of-those
end_variable
begin_variable
var54
-1
2
adjacent loc_2_9 loc_3_9 down
none-of-those
end_variable
begin_variable
var55
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var56
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var57
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var58
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var59
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var60
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var61
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var62
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var63
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var64
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var65
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var66
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var67
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var68
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var69
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var70
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var71
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var72
-1
2
adjacent loc_3_8 loc_3_9 right
none-of-those
end_variable
begin_variable
var73
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var74
-1
2
adjacent loc_3_9 loc_2_9 up
none-of-those
end_variable
begin_variable
var75
-1
2
adjacent loc_3_9 loc_3_8 left
none-of-those
end_variable
begin_variable
var76
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var77
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var78
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var79
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var80
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var81
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var82
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var83
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var84
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var85
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var86
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var87
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_5_8 loc_6_8 down
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_6_8 loc_5_8 up
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_6_8 loc_6_9 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_6_9 loc_6_8 left
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_9_2 loc_10_2 down
none-of-those
end_variable
0
begin_state
14
17
7
29
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
3
1 3
2 36
3 32
end_goal
377
begin_operator
move loc_2_3 loc_3_3 down
2
9 0
50 0
1
0 0 0 3
1
end_operator
begin_operator
move loc_2_8 loc_2_9 right
2
8 0
51 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
14 0
52 0
1
0 0 1 8
1
end_operator
begin_operator
move loc_2_9 loc_2_8 left
2
7 0
53 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_2_9 loc_3_9 down
2
15 0
54 0
1
0 0 2 9
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
6 0
55 0
1
0 0 3 0
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
10 0
56 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
17 0
57 0
1
0 0 3 11
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
9 0
58 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
11 0
59 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
18 0
60 0
1
0 0 4 12
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
10 0
61 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
12 0
62 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
19 0
63 0
1
0 0 5 13
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
11 0
64 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
13 0
65 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
20 0
66 0
1
0 0 6 14
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
12 0
67 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
14 0
68 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
21 0
69 0
1
0 0 7 15
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
7 0
70 0
1
0 0 8 1
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
13 0
71 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_3_8 loc_3_9 right
2
15 0
72 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
22 0
73 0
1
0 0 8 16
1
end_operator
begin_operator
move loc_3_9 loc_2_9 up
2
8 0
74 0
1
0 0 9 2
1
end_operator
begin_operator
move loc_3_9 loc_3_8 left
2
14 0
75 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
23 0
76 0
1
0 0 9 17
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
23 0
77 0
1
0 0 10 17
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
24 0
78 0
1
0 0 10 18
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
9 0
79 0
1
0 0 11 3
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
18 0
80 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
26 0
81 0
1
0 0 11 20
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
10 0
82 0
1
0 0 12 4
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
17 0
83 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
19 0
84 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
27 0
85 0
1
0 0 12 21
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
11 0
86 0
1
0 0 13 5
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
18 0
87 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
20 0
88 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
28 0
89 0
1
0 0 13 22
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
12 0
90 0
1
0 0 14 6
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
19 0
91 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
21 0
92 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
29 0
93 0
1
0 0 14 23
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
13 0
94 0
1
0 0 15 7
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
20 0
95 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
22 0
96 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
30 0
97 0
1
0 0 15 24
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
14 0
98 0
1
0 0 16 8
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
21 0
99 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
23 0
100 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
31 0
101 0
1
0 0 16 25
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
15 0
102 0
1
0 0 17 9
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
16 0
103 0
1
0 0 17 10
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
22 0
104 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
32 0
105 0
1
0 0 17 26
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
16 0
106 0
1
0 0 18 10
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
32 0
107 0
1
0 0 18 26
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
26 0
108 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
17 0
109 0
1
0 0 20 11
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
25 0
110 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
27 0
111 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
18 0
112 0
1
0 0 21 12
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
26 0
113 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
28 0
114 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
33 0
115 0
1
0 0 21 27
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
19 0
116 0
1
0 0 22 13
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
27 0
117 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
29 0
118 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
20 0
119 0
1
0 0 23 14
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
28 0
120 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
30 0
121 0
1
0 0 23 24
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
34 0
122 0
1
0 0 23 28
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
21 0
123 0
1
0 0 24 15
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
29 0
124 0
1
0 0 24 23
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
31 0
125 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
35 0
126 0
1
0 0 24 29
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
22 0
127 0
1
0 0 25 16
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
30 0
128 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
32 0
129 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_5_8 loc_6_8 down
2
36 0
130 0
1
0 0 25 30
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
23 0
131 0
1
0 0 26 17
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
24 0
132 0
1
0 0 26 18
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
31 0
133 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
37 0
134 0
1
0 0 26 31
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
27 0
135 0
1
0 0 27 21
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
38 0
136 0
1
0 0 27 32
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
29 0
137 0
1
0 0 28 23
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
35 0
138 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
39 0
139 0
1
0 0 28 33
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
30 0
140 0
1
0 0 29 24
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
34 0
141 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
36 0
142 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
40 0
143 0
1
0 0 29 34
1
end_operator
begin_operator
move loc_6_8 loc_5_8 up
2
31 0
144 0
1
0 0 30 25
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
35 0
145 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_6_8 loc_6_9 right
2
37 0
146 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
41 0
147 0
1
0 0 30 35
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
32 0
148 0
1
0 0 31 26
1
end_operator
begin_operator
move loc_6_9 loc_6_8 left
2
36 0
149 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
42 0
150 0
1
0 0 31 36
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
33 0
151 0
1
0 0 32 27
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
44 0
152 0
1
0 0 32 38
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
34 0
153 0
1
0 0 33 28
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
40 0
154 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
35 0
155 0
1
0 0 34 29
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
39 0
156 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
41 0
157 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
45 0
158 0
1
0 0 34 39
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
36 0
159 0
1
0 0 35 30
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
40 0
160 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
42 0
161 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
46 0
162 0
1
0 0 35 40
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
37 0
163 0
1
0 0 36 31
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
41 0
164 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
44 0
165 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
38 0
166 0
1
0 0 38 32
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
43 0
167 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
40 0
168 0
1
0 0 39 34
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
46 0
169 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
41 0
170 0
1
0 0 40 35
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
45 0
171 0
1
0 0 40 39
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box1
2
52 0
73 0
4
0 0 1 8
0 1 8 16
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box2
2
52 0
73 0
4
0 0 1 8
0 2 8 16
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box3
2
52 0
73 0
4
0 0 1 8
0 3 8 16
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box1
2
54 0
76 0
4
0 0 2 9
0 1 9 17
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box2
2
54 0
76 0
4
0 0 2 9
0 2 9 17
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_9 loc_3_9 loc_4_9 down box3
2
54 0
76 0
4
0 0 2 9
0 3 9 17
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
56 0
59 0
4
0 0 3 4
0 1 4 5
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
56 0
59 0
4
0 0 3 4
0 2 4 5
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
56 0
59 0
4
0 0 3 4
0 3 4 5
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
57 0
81 0
4
0 0 3 11
0 1 11 20
0 17 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box2
2
57 0
81 0
4
0 0 3 11
0 2 11 20
0 17 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box3
2
57 0
81 0
4
0 0 3 11
0 3 11 20
0 17 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
59 0
62 0
4
0 0 4 5
0 1 5 6
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
59 0
62 0
4
0 0 4 5
0 2 5 6
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
59 0
62 0
4
0 0 4 5
0 3 5 6
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
60 0
85 0
4
0 0 4 12
0 1 12 21
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
60 0
85 0
4
0 0 4 12
0 2 12 21
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
60 0
85 0
4
0 0 4 12
0 3 12 21
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
58 0
61 0
4
0 0 5 4
0 1 4 3
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
58 0
61 0
4
0 0 5 4
0 2 4 3
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
58 0
61 0
4
0 0 5 4
0 3 4 3
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
62 0
65 0
4
0 0 5 6
0 1 6 7
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
62 0
65 0
4
0 0 5 6
0 2 6 7
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box3
2
62 0
65 0
4
0 0 5 6
0 3 6 7
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
63 0
89 0
4
0 0 5 13
0 1 13 22
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
63 0
89 0
4
0 0 5 13
0 2 13 22
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
63 0
89 0
4
0 0 5 13
0 3 13 22
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
61 0
64 0
4
0 0 6 5
0 1 5 4
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
61 0
64 0
4
0 0 6 5
0 2 5 4
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
61 0
64 0
4
0 0 6 5
0 3 5 4
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
65 0
68 0
4
0 0 6 7
0 1 7 8
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box2
2
65 0
68 0
4
0 0 6 7
0 2 7 8
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box3
2
65 0
68 0
4
0 0 6 7
0 3 7 8
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
66 0
93 0
4
0 0 6 14
0 1 14 23
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
66 0
93 0
4
0 0 6 14
0 2 14 23
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
66 0
93 0
4
0 0 6 14
0 3 14 23
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
64 0
67 0
4
0 0 7 6
0 1 6 5
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
64 0
67 0
4
0 0 7 6
0 2 6 5
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box3
2
64 0
67 0
4
0 0 7 6
0 3 6 5
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box1
2
68 0
72 0
4
0 0 7 8
0 1 8 9
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box2
2
68 0
72 0
4
0 0 7 8
0 2 8 9
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_8 loc_3_9 right box3
2
68 0
72 0
4
0 0 7 8
0 3 8 9
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
69 0
97 0
4
0 0 7 15
0 1 15 24
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box2
2
69 0
97 0
4
0 0 7 15
0 2 15 24
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box3
2
69 0
97 0
4
0 0 7 15
0 3 15 24
0 21 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
67 0
71 0
4
0 0 8 7
0 1 7 6
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box2
2
67 0
71 0
4
0 0 8 7
0 2 7 6
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box3
2
67 0
71 0
4
0 0 8 7
0 3 7 6
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box1
2
73 0
101 0
4
0 0 8 16
0 1 16 25
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box2
2
73 0
101 0
4
0 0 8 16
0 2 16 25
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box3
2
73 0
101 0
4
0 0 8 16
0 3 16 25
0 22 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box1
2
71 0
75 0
4
0 0 9 8
0 1 8 7
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box2
2
71 0
75 0
4
0 0 9 8
0 2 8 7
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_8 loc_3_7 left box3
2
71 0
75 0
4
0 0 9 8
0 3 8 7
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box1
2
76 0
105 0
4
0 0 9 17
0 1 17 26
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box2
2
76 0
105 0
4
0 0 9 17
0 2 17 26
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box3
2
76 0
105 0
4
0 0 9 17
0 3 17 26
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box1
2
77 0
104 0
4
0 0 10 17
0 1 17 16
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box2
2
77 0
104 0
4
0 0 10 17
0 2 17 16
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box3
2
77 0
104 0
4
0 0 10 17
0 3 17 16
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box1
2
55 0
79 0
4
0 0 11 3
0 1 3 0
0 6 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box2
2
55 0
79 0
4
0 0 11 3
0 2 3 0
0 6 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box3
2
55 0
79 0
4
0 0 11 3
0 3 3 0
0 6 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
80 0
84 0
4
0 0 11 12
0 1 12 13
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
80 0
84 0
4
0 0 11 12
0 2 12 13
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
80 0
84 0
4
0 0 11 12
0 3 12 13
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
84 0
88 0
4
0 0 12 13
0 1 13 14
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
84 0
88 0
4
0 0 12 13
0 2 13 14
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
84 0
88 0
4
0 0 12 13
0 3 13 14
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
85 0
115 0
4
0 0 12 21
0 1 21 27
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
85 0
115 0
4
0 0 12 21
0 2 21 27
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
85 0
115 0
4
0 0 12 21
0 3 21 27
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
83 0
87 0
4
0 0 13 12
0 1 12 11
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
83 0
87 0
4
0 0 13 12
0 2 12 11
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
83 0
87 0
4
0 0 13 12
0 3 12 11
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
88 0
92 0
4
0 0 13 14
0 1 14 15
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
88 0
92 0
4
0 0 13 14
0 2 14 15
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
88 0
92 0
4
0 0 13 14
0 3 14 15
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
87 0
91 0
4
0 0 14 13
0 1 13 12
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
87 0
91 0
4
0 0 14 13
0 2 13 12
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
87 0
91 0
4
0 0 14 13
0 3 13 12
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
92 0
96 0
4
0 0 14 15
0 1 15 16
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box2
2
92 0
96 0
4
0 0 14 15
0 2 15 16
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box3
2
92 0
96 0
4
0 0 14 15
0 3 15 16
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
93 0
122 0
4
0 0 14 23
0 1 23 28
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
93 0
122 0
4
0 0 14 23
0 2 23 28
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
93 0
122 0
4
0 0 14 23
0 3 23 28
0 29 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
91 0
95 0
4
0 0 15 14
0 1 14 13
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
91 0
95 0
4
0 0 15 14
0 2 14 13
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
91 0
95 0
4
0 0 15 14
0 3 14 13
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
96 0
100 0
4
0 0 15 16
0 1 16 17
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box2
2
96 0
100 0
4
0 0 15 16
0 2 16 17
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box3
2
96 0
100 0
4
0 0 15 16
0 3 16 17
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
97 0
126 0
4
0 0 15 24
0 1 24 29
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
97 0
126 0
4
0 0 15 24
0 2 24 29
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
97 0
126 0
4
0 0 15 24
0 3 24 29
0 30 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box1
2
70 0
98 0
4
0 0 16 8
0 1 8 1
0 7 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box2
2
70 0
98 0
4
0 0 16 8
0 2 8 1
0 7 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box3
2
70 0
98 0
4
0 0 16 8
0 3 8 1
0 7 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
95 0
99 0
4
0 0 16 15
0 1 15 14
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box2
2
95 0
99 0
4
0 0 16 15
0 2 15 14
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box3
2
95 0
99 0
4
0 0 16 15
0 3 15 14
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box1
2
100 0
103 0
4
0 0 16 17
0 1 17 10
0 16 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box2
2
100 0
103 0
4
0 0 16 17
0 2 17 10
0 16 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box3
2
100 0
103 0
4
0 0 16 17
0 3 17 10
0 16 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box1
2
101 0
130 0
4
0 0 16 25
0 1 25 30
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box2
2
101 0
130 0
4
0 0 16 25
0 2 25 30
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box3
2
101 0
130 0
4
0 0 16 25
0 3 25 30
0 31 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box1
2
74 0
102 0
4
0 0 17 9
0 1 9 2
0 8 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box2
2
74 0
102 0
4
0 0 17 9
0 2 9 2
0 8 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_3_9 loc_2_9 up box3
2
74 0
102 0
4
0 0 17 9
0 3 9 2
0 8 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box1
2
99 0
104 0
4
0 0 17 16
0 1 16 15
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box2
2
99 0
104 0
4
0 0 17 16
0 2 16 15
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box3
2
99 0
104 0
4
0 0 17 16
0 3 16 15
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box1
2
105 0
134 0
4
0 0 17 26
0 1 26 31
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box2
2
105 0
134 0
4
0 0 17 26
0 2 26 31
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box3
2
105 0
134 0
4
0 0 17 26
0 3 26 31
0 32 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box1
2
107 0
133 0
4
0 0 18 26
0 1 26 25
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box2
2
107 0
133 0
4
0 0 18 26
0 2 26 25
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box3
2
107 0
133 0
4
0 0 18 26
0 3 26 25
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
79 0
109 0
4
0 0 20 11
0 1 11 3
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box2
2
79 0
109 0
4
0 0 20 11
0 2 11 3
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box3
2
79 0
109 0
4
0 0 20 11
0 3 11 3
0 9 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
111 0
114 0
4
0 0 20 21
0 1 21 22
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box2
2
111 0
114 0
4
0 0 20 21
0 2 21 22
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box3
2
111 0
114 0
4
0 0 20 21
0 3 21 22
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
82 0
112 0
4
0 0 21 12
0 1 12 4
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
82 0
112 0
4
0 0 21 12
0 2 12 4
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
82 0
112 0
4
0 0 21 12
0 3 12 4
0 10 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
110 0
113 0
4
0 0 21 20
0 1 20 19
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
110 0
113 0
4
0 0 21 20
0 2 20 19
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
110 0
113 0
4
0 0 21 20
0 3 20 19
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
114 0
118 0
4
0 0 21 22
0 1 22 23
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
114 0
118 0
4
0 0 21 22
0 2 22 23
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
114 0
118 0
4
0 0 21 22
0 3 22 23
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
115 0
136 0
4
0 0 21 27
0 1 27 32
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
115 0
136 0
4
0 0 21 27
0 2 27 32
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
115 0
136 0
4
0 0 21 27
0 3 27 32
0 33 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
86 0
116 0
4
0 0 22 13
0 1 13 5
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
86 0
116 0
4
0 0 22 13
0 2 13 5
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
86 0
116 0
4
0 0 22 13
0 3 13 5
0 11 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
113 0
117 0
4
0 0 22 21
0 1 21 20
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
113 0
117 0
4
0 0 22 21
0 2 21 20
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
113 0
117 0
4
0 0 22 21
0 3 21 20
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
118 0
121 0
4
0 0 22 23
0 1 23 24
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
118 0
121 0
4
0 0 22 23
0 2 23 24
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
118 0
121 0
4
0 0 22 23
0 3 23 24
0 29 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
90 0
119 0
4
0 0 23 14
0 1 14 6
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
90 0
119 0
4
0 0 23 14
0 2 14 6
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
90 0
119 0
4
0 0 23 14
0 3 14 6
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
117 0
120 0
4
0 0 23 22
0 1 22 21
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
117 0
120 0
4
0 0 23 22
0 2 22 21
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
117 0
120 0
4
0 0 23 22
0 3 22 21
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
121 0
125 0
4
0 0 23 24
0 1 24 25
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
121 0
125 0
4
0 0 23 24
0 2 24 25
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
121 0
125 0
4
0 0 23 24
0 3 24 25
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
122 0
139 0
4
0 0 23 28
0 1 28 33
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
122 0
139 0
4
0 0 23 28
0 2 28 33
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
122 0
139 0
4
0 0 23 28
0 3 28 33
0 34 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
94 0
123 0
4
0 0 24 15
0 1 15 7
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
94 0
123 0
4
0 0 24 15
0 2 15 7
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
94 0
123 0
4
0 0 24 15
0 3 15 7
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
120 0
124 0
4
0 0 24 23
0 1 23 22
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
120 0
124 0
4
0 0 24 23
0 2 23 22
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
120 0
124 0
4
0 0 24 23
0 3 23 22
0 28 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
125 0
129 0
4
0 0 24 25
0 1 25 26
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
125 0
129 0
4
0 0 24 25
0 2 25 26
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
125 0
129 0
4
0 0 24 25
0 3 25 26
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
126 0
143 0
4
0 0 24 29
0 1 29 34
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
126 0
143 0
4
0 0 24 29
0 2 29 34
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
126 0
143 0
4
0 0 24 29
0 3 29 34
0 35 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box1
2
98 0
127 0
4
0 0 25 16
0 1 16 8
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box2
2
98 0
127 0
4
0 0 25 16
0 2 16 8
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box3
2
98 0
127 0
4
0 0 25 16
0 3 16 8
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
124 0
128 0
4
0 0 25 24
0 1 24 23
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
124 0
128 0
4
0 0 25 24
0 2 24 23
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
124 0
128 0
4
0 0 25 24
0 3 24 23
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box1
2
129 0
132 0
4
0 0 25 26
0 1 26 18
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box2
2
129 0
132 0
4
0 0 25 26
0 2 26 18
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box3
2
129 0
132 0
4
0 0 25 26
0 3 26 18
0 24 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box1
2
130 0
147 0
4
0 0 25 30
0 1 30 35
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box2
2
130 0
147 0
4
0 0 25 30
0 2 30 35
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box3
2
130 0
147 0
4
0 0 25 30
0 3 30 35
0 36 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box1
2
102 0
131 0
4
0 0 26 17
0 1 17 9
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box2
2
102 0
131 0
4
0 0 26 17
0 2 17 9
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box3
2
102 0
131 0
4
0 0 26 17
0 3 17 9
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
128 0
133 0
4
0 0 26 25
0 1 25 24
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
128 0
133 0
4
0 0 26 25
0 2 25 24
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
128 0
133 0
4
0 0 26 25
0 3 25 24
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box1
2
134 0
150 0
4
0 0 26 31
0 1 31 36
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box2
2
134 0
150 0
4
0 0 26 31
0 2 31 36
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box3
2
134 0
150 0
4
0 0 26 31
0 3 31 36
0 37 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
136 0
152 0
4
0 0 27 32
0 1 32 37
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box2
2
136 0
152 0
4
0 0 27 32
0 2 32 37
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box3
2
136 0
152 0
4
0 0 27 32
0 3 32 37
0 38 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
119 0
137 0
4
0 0 28 23
0 1 23 14
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
119 0
137 0
4
0 0 28 23
0 2 23 14
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
119 0
137 0
4
0 0 28 23
0 3 23 14
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
138 0
142 0
4
0 0 28 29
0 1 29 30
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
138 0
142 0
4
0 0 28 29
0 2 29 30
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
138 0
142 0
4
0 0 28 29
0 3 29 30
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
123 0
140 0
4
0 0 29 24
0 1 24 15
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
123 0
140 0
4
0 0 29 24
0 2 24 15
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
123 0
140 0
4
0 0 29 24
0 3 24 15
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box1
2
142 0
146 0
4
0 0 29 30
0 1 30 31
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box2
2
142 0
146 0
4
0 0 29 30
0 2 30 31
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box3
2
142 0
146 0
4
0 0 29 30
0 3 30 31
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
143 0
158 0
4
0 0 29 34
0 1 34 38
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
143 0
158 0
4
0 0 29 34
0 2 34 38
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
143 0
158 0
4
0 0 29 34
0 3 34 38
0 40 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box1
2
127 0
144 0
4
0 0 30 25
0 1 25 16
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box2
2
127 0
144 0
4
0 0 30 25
0 2 25 16
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box3
2
127 0
144 0
4
0 0 30 25
0 3 25 16
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
141 0
145 0
4
0 0 30 29
0 1 29 28
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
141 0
145 0
4
0 0 30 29
0 2 29 28
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
141 0
145 0
4
0 0 30 29
0 3 29 28
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box1
2
147 0
162 0
4
0 0 30 35
0 1 35 39
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box2
2
147 0
162 0
4
0 0 30 35
0 2 35 39
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box3
2
147 0
162 0
4
0 0 30 35
0 3 35 39
0 41 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box1
2
131 0
148 0
4
0 0 31 26
0 1 26 17
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box2
2
131 0
148 0
4
0 0 31 26
0 2 26 17
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box3
2
131 0
148 0
4
0 0 31 26
0 3 26 17
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box1
2
145 0
149 0
4
0 0 31 30
0 1 30 29
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box2
2
145 0
149 0
4
0 0 31 30
0 2 30 29
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box3
2
145 0
149 0
4
0 0 31 30
0 3 30 29
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
137 0
153 0
4
0 0 33 28
0 1 28 23
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
137 0
153 0
4
0 0 33 28
0 2 28 23
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
137 0
153 0
4
0 0 33 28
0 3 28 23
0 29 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
154 0
157 0
4
0 0 33 34
0 1 34 35
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
154 0
157 0
4
0 0 33 34
0 2 34 35
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
154 0
157 0
4
0 0 33 34
0 3 34 35
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
140 0
155 0
4
0 0 34 29
0 1 29 24
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
140 0
155 0
4
0 0 34 29
0 2 29 24
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
140 0
155 0
4
0 0 34 29
0 3 29 24
0 30 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
157 0
161 0
4
0 0 34 35
0 1 35 36
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
157 0
161 0
4
0 0 34 35
0 2 35 36
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
157 0
161 0
4
0 0 34 35
0 3 35 36
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box1
2
144 0
159 0
4
0 0 35 30
0 1 30 25
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box2
2
144 0
159 0
4
0 0 35 30
0 2 30 25
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box3
2
144 0
159 0
4
0 0 35 30
0 3 30 25
0 31 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
156 0
160 0
4
0 0 35 34
0 1 34 33
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
156 0
160 0
4
0 0 35 34
0 2 34 33
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
156 0
160 0
4
0 0 35 34
0 3 34 33
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box1
2
148 0
163 0
4
0 0 36 31
0 1 31 26
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box2
2
148 0
163 0
4
0 0 36 31
0 2 31 26
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box3
2
148 0
163 0
4
0 0 36 31
0 3 31 26
0 32 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
160 0
164 0
4
0 0 36 35
0 1 35 34
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
160 0
164 0
4
0 0 36 35
0 2 35 34
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
160 0
164 0
4
0 0 36 35
0 3 35 34
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
155 0
168 0
4
0 0 39 34
0 1 34 29
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
155 0
168 0
4
0 0 39 34
0 2 34 29
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
155 0
168 0
4
0 0 39 34
0 3 34 29
0 35 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box1
2
159 0
170 0
4
0 0 40 35
0 1 35 30
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box2
2
159 0
170 0
4
0 0 40 35
0 2 35 30
0 36 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box3
2
159 0
170 0
4
0 0 40 35
0 3 35 30
0 36 0 1
0 41 -1 0
1
end_operator
0
