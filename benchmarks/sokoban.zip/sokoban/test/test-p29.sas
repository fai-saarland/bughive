begin_version
3
end_version
begin_metric
1
end_metric
381
begin_variable
var0
-1
90
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_12
at-robot loc_10_2
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_10_9
at-robot loc_11_10
at-robot loc_11_11
at-robot loc_11_12
at-robot loc_11_2
at-robot loc_11_3
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_7
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_12_12
at-robot loc_12_6
at-robot loc_12_7
at-robot loc_2_6
at-robot loc_2_7
at-robot loc_3_11
at-robot loc_3_12
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_8
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_12
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_8
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_2
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_2
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_2
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_12
at-robot loc_9_2
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
86
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_12
at box1 loc_10_2
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_10_9
at box1 loc_11_10
at box1 loc_11_11
at box1 loc_11_12
at box1 loc_11_2
at box1 loc_11_3
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_7
at box1 loc_11_8
at box1 loc_11_9
at box1 loc_12_12
at box1 loc_12_6
at box1 loc_12_7
at box1 loc_2_6
at box1 loc_3_11
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_4_10
at box1 loc_4_11
at box1 loc_4_12
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_5_10
at box1 loc_5_11
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_2
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_2
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_12
at box1 loc_8_2
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_12
at box1 loc_9_2
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var2
-1
86
at box4 loc_10_10
at box4 loc_10_11
at box4 loc_10_12
at box4 loc_10_2
at box4 loc_10_3
at box4 loc_10_4
at box4 loc_10_5
at box4 loc_10_6
at box4 loc_10_7
at box4 loc_10_8
at box4 loc_10_9
at box4 loc_11_10
at box4 loc_11_11
at box4 loc_11_12
at box4 loc_11_2
at box4 loc_11_3
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_7
at box4 loc_11_8
at box4 loc_11_9
at box4 loc_12_12
at box4 loc_12_6
at box4 loc_12_7
at box4 loc_2_6
at box4 loc_3_11
at box4 loc_3_3
at box4 loc_3_4
at box4 loc_3_5
at box4 loc_3_6
at box4 loc_4_10
at box4 loc_4_11
at box4 loc_4_12
at box4 loc_4_2
at box4 loc_4_3
at box4 loc_4_4
at box4 loc_4_5
at box4 loc_4_6
at box4 loc_5_10
at box4 loc_5_11
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_5
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_5_8
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_2
at box4 loc_6_4
at box4 loc_6_5
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_2
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_5
at box4 loc_7_6
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_12
at box4 loc_8_2
at box4 loc_8_3
at box4 loc_8_4
at box4 loc_8_5
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_12
at box4 loc_9_2
at box4 loc_9_3
at box4 loc_9_4
at box4 loc_9_5
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var3
-1
86
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_12
at box2 loc_10_2
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_10_9
at box2 loc_11_10
at box2 loc_11_11
at box2 loc_11_12
at box2 loc_11_2
at box2 loc_11_3
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_7
at box2 loc_11_8
at box2 loc_11_9
at box2 loc_12_12
at box2 loc_12_6
at box2 loc_12_7
at box2 loc_2_6
at box2 loc_3_11
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_4_10
at box2 loc_4_11
at box2 loc_4_12
at box2 loc_4_2
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_5_10
at box2 loc_5_11
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_2
at box2 loc_6_4
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_2
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_12
at box2 loc_8_2
at box2 loc_8_3
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_12
at box2 loc_9_2
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var4
-1
86
at box3 loc_10_10
at box3 loc_10_11
at box3 loc_10_12
at box3 loc_10_2
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_10_9
at box3 loc_11_10
at box3 loc_11_11
at box3 loc_11_12
at box3 loc_11_2
at box3 loc_11_3
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_7
at box3 loc_11_8
at box3 loc_11_9
at box3 loc_12_12
at box3 loc_12_6
at box3 loc_12_7
at box3 loc_2_6
at box3 loc_3_11
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_4_10
at box3 loc_4_11
at box3 loc_4_12
at box3 loc_4_2
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_5_10
at box3 loc_5_11
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_10
at box3 loc_6_11
at box3 loc_6_2
at box3 loc_6_4
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_2
at box3 loc_7_3
at box3 loc_7_4
at box3 loc_7_5
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_12
at box3 loc_8_2
at box3 loc_8_3
at box3 loc_8_4
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_12
at box3 loc_9_2
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var5
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_9_12
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_11_10
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_12_12
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_12_7
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_3_12
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var88
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var89
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var90
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var91
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var92
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var93
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var94
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_10_10 loc_11_10 down
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_10_11 loc_10_12 right
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_10_11 loc_11_11 down
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_10_12 loc_10_11 left
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_10_12 loc_11_12 down
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_10_12 loc_9_12 up
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_10_2 loc_10_3 right
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_10_2 loc_11_2 down
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_10_2 loc_9_2 up
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_10_3 loc_10_2 left
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_10_3 loc_9_3 up
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_10_8 loc_10_9 right
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_10_8 loc_11_8 down
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_10_9 loc_10_8 left
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_10_9 loc_11_9 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_11_10 loc_10_10 up
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_11_10 loc_11_11 right
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_11_10 loc_11_9 left
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_11_11 loc_10_11 up
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_11_11 loc_11_10 left
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_11_11 loc_11_12 right
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_11_12 loc_10_12 up
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_11_12 loc_11_11 left
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_11_12 loc_12_12 down
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_11_2 loc_10_2 up
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_11_6 loc_11_7 right
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_11_6 loc_12_6 down
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_11_7 loc_11_6 left
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_11_7 loc_11_8 right
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_11_7 loc_12_7 down
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_11_8 loc_10_8 up
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_11_8 loc_11_7 left
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_11_9 loc_10_9 up
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_11_9 loc_11_10 right
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_12_12 loc_11_12 up
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_12_6 loc_11_6 up
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_12_6 loc_12_7 right
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_12_7 loc_11_7 up
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_12_7 loc_12_6 left
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_2_6 loc_2_7 right
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_2_7 loc_2_6 left
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_3_11 loc_3_12 right
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_3_11 loc_4_11 down
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_3_12 loc_3_11 left
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_3_12 loc_4_12 down
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_4_11 loc_3_11 up
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_4_11 loc_4_12 right
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_4_12 loc_3_12 up
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_4_12 loc_4_11 left
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_7_2 loc_7_3 right
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_7_3 loc_7_2 left
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_8_12 loc_9_12 down
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_8_3 loc_9_3 down
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var344
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var345
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var346
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var347
-1
2
adjacent loc_9_11 loc_9_12 right
none-of-those
end_variable
begin_variable
var348
-1
2
adjacent loc_9_12 loc_10_12 down
none-of-those
end_variable
begin_variable
var349
-1
2
adjacent loc_9_12 loc_8_12 up
none-of-those
end_variable
begin_variable
var350
-1
2
adjacent loc_9_12 loc_9_11 left
none-of-those
end_variable
begin_variable
var351
-1
2
adjacent loc_9_2 loc_10_2 down
none-of-those
end_variable
begin_variable
var352
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var353
-1
2
adjacent loc_9_2 loc_9_3 right
none-of-those
end_variable
begin_variable
var354
-1
2
adjacent loc_9_3 loc_10_3 down
none-of-those
end_variable
begin_variable
var355
-1
2
adjacent loc_9_3 loc_8_3 up
none-of-those
end_variable
begin_variable
var356
-1
2
adjacent loc_9_3 loc_9_2 left
none-of-those
end_variable
begin_variable
var357
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var358
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var359
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var360
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var361
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var362
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var363
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var364
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var365
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var366
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var367
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var368
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var369
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var370
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var371
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var372
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var373
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var374
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var375
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var376
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var377
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var378
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var379
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var380
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
48
62
79
0
34
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 1
2 0
3 60
4 19
end_goal
1166
begin_operator
move loc_10_10 loc_10_11 right
2
48 0
95 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_10_9 left
2
57 0
96 0
1
0 0 0 10
1
end_operator
begin_operator
move loc_10_10 loc_11_10 down
2
58 0
97 0
1
0 0 0 11
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
36 0
98 0
1
0 0 0 79
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
47 0
99 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_10_12 right
2
49 0
100 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_11 loc_11_11 down
2
59 0
101 0
1
0 0 1 12
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
37 0
102 0
1
0 0 1 80
1
end_operator
begin_operator
move loc_10_12 loc_10_11 left
2
48 0
103 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_12 loc_11_12 down
2
60 0
104 0
1
0 0 2 13
1
end_operator
begin_operator
move loc_10_12 loc_9_12 up
2
38 0
105 0
1
0 0 2 81
1
end_operator
begin_operator
move loc_10_2 loc_10_3 right
2
51 0
106 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_2 loc_11_2 down
2
61 0
107 0
1
0 0 3 14
1
end_operator
begin_operator
move loc_10_2 loc_9_2 up
2
39 0
108 0
1
0 0 3 82
1
end_operator
begin_operator
move loc_10_3 loc_10_2 left
2
50 0
109 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
52 0
110 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
62 0
111 0
1
0 0 4 15
1
end_operator
begin_operator
move loc_10_3 loc_9_3 up
2
40 0
112 0
1
0 0 4 83
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
51 0
113 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
53 0
114 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
41 0
115 0
1
0 0 5 84
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
52 0
116 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
54 0
117 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
63 0
118 0
1
0 0 6 16
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
42 0
119 0
1
0 0 6 85
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
53 0
120 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
55 0
121 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
64 0
122 0
1
0 0 7 17
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
43 0
123 0
1
0 0 7 86
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
54 0
124 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
56 0
125 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
65 0
126 0
1
0 0 8 18
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
44 0
127 0
1
0 0 8 87
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
55 0
128 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_10_8 loc_10_9 right
2
57 0
129 0
1
0 0 9 10
1
end_operator
begin_operator
move loc_10_8 loc_11_8 down
2
66 0
130 0
1
0 0 9 19
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
45 0
131 0
1
0 0 9 88
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
47 0
132 0
1
0 0 10 0
1
end_operator
begin_operator
move loc_10_9 loc_10_8 left
2
56 0
133 0
1
0 0 10 9
1
end_operator
begin_operator
move loc_10_9 loc_11_9 down
2
67 0
134 0
1
0 0 10 20
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
46 0
135 0
1
0 0 10 89
1
end_operator
begin_operator
move loc_11_10 loc_10_10 up
2
47 0
136 0
1
0 0 11 0
1
end_operator
begin_operator
move loc_11_10 loc_11_11 right
2
59 0
137 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_10 loc_11_9 left
2
67 0
138 0
1
0 0 11 20
1
end_operator
begin_operator
move loc_11_11 loc_10_11 up
2
48 0
139 0
1
0 0 12 1
1
end_operator
begin_operator
move loc_11_11 loc_11_10 left
2
58 0
140 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_11 loc_11_12 right
2
60 0
141 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_12 loc_10_12 up
2
49 0
142 0
1
0 0 13 2
1
end_operator
begin_operator
move loc_11_12 loc_11_11 left
2
59 0
143 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_12 loc_12_12 down
2
68 0
144 0
1
0 0 13 21
1
end_operator
begin_operator
move loc_11_2 loc_10_2 up
2
50 0
145 0
1
0 0 14 3
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
62 0
146 0
1
0 0 14 15
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
51 0
147 0
1
0 0 15 4
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
61 0
148 0
1
0 0 15 14
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
53 0
149 0
1
0 0 16 6
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
64 0
150 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
54 0
151 0
1
0 0 17 7
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
63 0
152 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_11_6 loc_11_7 right
2
65 0
153 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_11_6 loc_12_6 down
2
69 0
154 0
1
0 0 17 22
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
55 0
155 0
1
0 0 18 8
1
end_operator
begin_operator
move loc_11_7 loc_11_6 left
2
64 0
156 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_11_7 loc_11_8 right
2
66 0
157 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_11_7 loc_12_7 down
2
70 0
158 0
1
0 0 18 23
1
end_operator
begin_operator
move loc_11_8 loc_10_8 up
2
56 0
159 0
1
0 0 19 9
1
end_operator
begin_operator
move loc_11_8 loc_11_7 left
2
65 0
160 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
67 0
161 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_11_9 loc_10_9 up
2
57 0
162 0
1
0 0 20 10
1
end_operator
begin_operator
move loc_11_9 loc_11_10 right
2
58 0
163 0
1
0 0 20 11
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
66 0
164 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_12_12 loc_11_12 up
2
60 0
165 0
1
0 0 21 13
1
end_operator
begin_operator
move loc_12_6 loc_11_6 up
2
64 0
166 0
1
0 0 22 17
1
end_operator
begin_operator
move loc_12_6 loc_12_7 right
2
70 0
167 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_12_7 loc_11_7 up
2
65 0
168 0
1
0 0 23 18
1
end_operator
begin_operator
move loc_12_7 loc_12_6 left
2
69 0
169 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_2_6 loc_2_7 right
2
72 0
170 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
78 0
171 0
1
0 0 24 31
1
end_operator
begin_operator
move loc_2_7 loc_2_6 left
2
71 0
172 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_3_11 loc_3_12 right
2
74 0
173 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_3_11 loc_4_11 down
2
81 0
174 0
1
0 0 26 34
1
end_operator
begin_operator
move loc_3_12 loc_3_11 left
2
73 0
175 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_3_12 loc_4_12 down
2
82 0
176 0
1
0 0 27 35
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
76 0
177 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
84 0
178 0
1
0 0 28 37
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
75 0
179 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
77 0
180 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
85 0
181 0
1
0 0 29 38
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
76 0
182 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
78 0
183 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
86 0
184 0
1
0 0 30 39
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
71 0
185 0
1
0 0 31 24
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
77 0
186 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
87 0
187 0
1
0 0 31 40
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
88 0
188 0
1
0 0 32 41
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
81 0
189 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
89 0
190 0
1
0 0 33 42
1
end_operator
begin_operator
move loc_4_11 loc_3_11 up
2
73 0
191 0
1
0 0 34 26
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
80 0
192 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_4_11 loc_4_12 right
2
82 0
193 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
90 0
194 0
1
0 0 34 43
1
end_operator
begin_operator
move loc_4_12 loc_3_12 up
2
74 0
195 0
1
0 0 35 27
1
end_operator
begin_operator
move loc_4_12 loc_4_11 left
2
81 0
196 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
84 0
197 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
91 0
198 0
1
0 0 36 44
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
75 0
199 0
1
0 0 37 28
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
83 0
200 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
85 0
201 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
92 0
202 0
1
0 0 37 45
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
76 0
203 0
1
0 0 38 29
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
84 0
204 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
86 0
205 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
93 0
206 0
1
0 0 38 46
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
77 0
207 0
1
0 0 39 30
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
85 0
208 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
87 0
209 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
94 0
210 0
1
0 0 39 47
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
78 0
211 0
1
0 0 40 31
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
86 0
212 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
5 0
213 0
1
0 0 40 48
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
79 0
214 0
1
0 0 41 32
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
7 0
215 0
1
0 0 41 50
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
80 0
216 0
1
0 0 42 33
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
90 0
217 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
8 0
218 0
1
0 0 42 51
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
9 0
219 0
1
0 0 42 52
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
81 0
220 0
1
0 0 43 34
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
89 0
221 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
10 0
222 0
1
0 0 43 53
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
83 0
223 0
1
0 0 44 36
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
92 0
224 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
11 0
225 0
1
0 0 44 54
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
84 0
226 0
1
0 0 45 37
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
91 0
227 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
93 0
228 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
85 0
229 0
1
0 0 46 38
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
92 0
230 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
94 0
231 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
12 0
232 0
1
0 0 46 55
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
86 0
233 0
1
0 0 47 39
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
93 0
234 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
5 0
235 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
13 0
236 0
1
0 0 47 56
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
87 0
237 0
1
0 0 48 40
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
94 0
238 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
6 0
239 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
14 0
240 0
1
0 0 48 57
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
5 0
241 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
7 0
242 0
1
0 0 49 50
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
15 0
243 0
1
0 0 49 58
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
88 0
244 0
1
0 0 50 41
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
6 0
245 0
1
0 0 50 49
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
8 0
246 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
89 0
247 0
1
0 0 51 42
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
7 0
248 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
89 0
249 0
1
0 0 52 42
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
10 0
250 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
16 0
251 0
1
0 0 52 59
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
90 0
252 0
1
0 0 53 43
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
9 0
253 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
17 0
254 0
1
0 0 53 60
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
91 0
255 0
1
0 0 54 44
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
18 0
256 0
1
0 0 54 61
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
93 0
257 0
1
0 0 55 46
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
13 0
258 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
20 0
259 0
1
0 0 55 63
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
94 0
260 0
1
0 0 56 47
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
12 0
261 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
14 0
262 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
21 0
263 0
1
0 0 56 64
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
5 0
264 0
1
0 0 57 48
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
13 0
265 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
15 0
266 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
22 0
267 0
1
0 0 57 65
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
6 0
268 0
1
0 0 58 49
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
14 0
269 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
23 0
270 0
1
0 0 58 66
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
9 0
271 0
1
0 0 59 52
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
17 0
272 0
1
0 0 59 60
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
25 0
273 0
1
0 0 59 68
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
26 0
274 0
1
0 0 59 69
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
10 0
275 0
1
0 0 60 53
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
16 0
276 0
1
0 0 60 59
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
27 0
277 0
1
0 0 60 70
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
11 0
278 0
1
0 0 61 54
1
end_operator
begin_operator
move loc_7_2 loc_7_3 right
2
19 0
279 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
29 0
280 0
1
0 0 61 72
1
end_operator
begin_operator
move loc_7_3 loc_7_2 left
2
18 0
281 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
20 0
282 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
30 0
283 0
1
0 0 62 73
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
12 0
284 0
1
0 0 63 55
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
19 0
285 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
21 0
286 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
31 0
287 0
1
0 0 63 74
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
13 0
288 0
1
0 0 64 56
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
20 0
289 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
22 0
290 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
32 0
291 0
1
0 0 64 75
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
14 0
292 0
1
0 0 65 57
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
21 0
293 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
23 0
294 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
33 0
295 0
1
0 0 65 76
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
15 0
296 0
1
0 0 66 58
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
22 0
297 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
24 0
298 0
1
0 0 66 67
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
34 0
299 0
1
0 0 66 77
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
23 0
300 0
1
0 0 67 66
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
25 0
301 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
16 0
302 0
1
0 0 68 59
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
24 0
303 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
35 0
304 0
1
0 0 68 78
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
16 0
305 0
1
0 0 69 59
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
27 0
306 0
1
0 0 69 70
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
35 0
307 0
1
0 0 69 78
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
36 0
308 0
1
0 0 69 79
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
17 0
309 0
1
0 0 70 60
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
26 0
310 0
1
0 0 70 69
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
28 0
311 0
1
0 0 70 71
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
37 0
312 0
1
0 0 70 80
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
27 0
313 0
1
0 0 71 70
1
end_operator
begin_operator
move loc_8_12 loc_9_12 down
2
38 0
314 0
1
0 0 71 81
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
18 0
315 0
1
0 0 72 61
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
30 0
316 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
39 0
317 0
1
0 0 72 82
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
19 0
318 0
1
0 0 73 62
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
29 0
319 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
31 0
320 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_8_3 loc_9_3 down
2
40 0
321 0
1
0 0 73 83
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
20 0
322 0
1
0 0 74 63
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
30 0
323 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
32 0
324 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
41 0
325 0
1
0 0 74 84
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
21 0
326 0
1
0 0 75 64
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
31 0
327 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
33 0
328 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
42 0
329 0
1
0 0 75 85
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
22 0
330 0
1
0 0 76 65
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
32 0
331 0
1
0 0 76 75
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
34 0
332 0
1
0 0 76 77
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
43 0
333 0
1
0 0 76 86
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
23 0
334 0
1
0 0 77 66
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
33 0
335 0
1
0 0 77 76
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
44 0
336 0
1
0 0 77 87
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
25 0
337 0
1
0 0 78 68
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
26 0
338 0
1
0 0 78 69
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
46 0
339 0
1
0 0 78 89
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
47 0
340 0
1
0 0 79 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
26 0
341 0
1
0 0 79 69
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
37 0
342 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
46 0
343 0
1
0 0 79 89
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
48 0
344 0
1
0 0 80 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
27 0
345 0
1
0 0 80 70
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
36 0
346 0
1
0 0 80 79
1
end_operator
begin_operator
move loc_9_11 loc_9_12 right
2
38 0
347 0
1
0 0 80 81
1
end_operator
begin_operator
move loc_9_12 loc_10_12 down
2
49 0
348 0
1
0 0 81 2
1
end_operator
begin_operator
move loc_9_12 loc_8_12 up
2
28 0
349 0
1
0 0 81 71
1
end_operator
begin_operator
move loc_9_12 loc_9_11 left
2
37 0
350 0
1
0 0 81 80
1
end_operator
begin_operator
move loc_9_2 loc_10_2 down
2
50 0
351 0
1
0 0 82 3
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
29 0
352 0
1
0 0 82 72
1
end_operator
begin_operator
move loc_9_2 loc_9_3 right
2
40 0
353 0
1
0 0 82 83
1
end_operator
begin_operator
move loc_9_3 loc_10_3 down
2
51 0
354 0
1
0 0 83 4
1
end_operator
begin_operator
move loc_9_3 loc_8_3 up
2
30 0
355 0
1
0 0 83 73
1
end_operator
begin_operator
move loc_9_3 loc_9_2 left
2
39 0
356 0
1
0 0 83 82
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
41 0
357 0
1
0 0 83 84
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
52 0
358 0
1
0 0 84 5
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
31 0
359 0
1
0 0 84 74
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
40 0
360 0
1
0 0 84 83
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
42 0
361 0
1
0 0 84 85
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
53 0
362 0
1
0 0 85 6
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
32 0
363 0
1
0 0 85 75
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
41 0
364 0
1
0 0 85 84
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
43 0
365 0
1
0 0 85 86
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
54 0
366 0
1
0 0 86 7
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
33 0
367 0
1
0 0 86 76
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
42 0
368 0
1
0 0 86 85
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
44 0
369 0
1
0 0 86 87
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
55 0
370 0
1
0 0 87 8
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
34 0
371 0
1
0 0 87 77
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
43 0
372 0
1
0 0 87 86
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
45 0
373 0
1
0 0 87 88
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
56 0
374 0
1
0 0 88 9
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
44 0
375 0
1
0 0 88 87
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
46 0
376 0
1
0 0 88 89
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
57 0
377 0
1
0 0 89 10
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
35 0
378 0
1
0 0 89 78
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
36 0
379 0
1
0 0 89 79
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
45 0
380 0
1
0 0 89 88
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box1
2
95 0
100 0
4
0 0 0 1
0 1 1 2
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box2
2
95 0
100 0
4
0 0 0 1
0 3 1 2
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box3
2
95 0
100 0
4
0 0 0 1
0 4 1 2
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_11 loc_10_12 right box4
2
95 0
100 0
4
0 0 0 1
0 2 1 2
0 48 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box1
2
96 0
133 0
4
0 0 0 10
0 1 10 9
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box2
2
96 0
133 0
4
0 0 0 10
0 3 10 9
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box3
2
96 0
133 0
4
0 0 0 10
0 4 10 9
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box4
2
96 0
133 0
4
0 0 0 10
0 2 10 9
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
98 0
341 0
4
0 0 0 79
0 1 75 65
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
98 0
341 0
4
0 0 0 79
0 3 75 65
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
98 0
341 0
4
0 0 0 79
0 4 75 65
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
98 0
341 0
4
0 0 0 79
0 2 75 65
0 26 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box1
2
96 0
99 0
4
0 0 1 0
0 1 0 10
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box2
2
96 0
99 0
4
0 0 1 0
0 3 0 10
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box3
2
96 0
99 0
4
0 0 1 0
0 4 0 10
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_10 loc_10_9 left box4
2
96 0
99 0
4
0 0 1 0
0 2 0 10
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
102 0
345 0
4
0 0 1 80
0 1 76 66
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
102 0
345 0
4
0 0 1 80
0 3 76 66
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
102 0
345 0
4
0 0 1 80
0 4 76 66
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box4
2
102 0
345 0
4
0 0 1 80
0 2 76 66
0 27 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box1
2
99 0
103 0
4
0 0 2 1
0 1 1 0
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box2
2
99 0
103 0
4
0 0 2 1
0 3 1 0
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box3
2
99 0
103 0
4
0 0 2 1
0 4 1 0
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_11 loc_10_10 left box4
2
99 0
103 0
4
0 0 2 1
0 2 1 0
0 47 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box1
2
104 0
144 0
4
0 0 2 13
0 1 13 21
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box2
2
104 0
144 0
4
0 0 2 13
0 3 13 21
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box3
2
104 0
144 0
4
0 0 2 13
0 4 13 21
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box4
2
104 0
144 0
4
0 0 2 13
0 2 13 21
0 60 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box1
2
105 0
349 0
4
0 0 2 81
0 1 77 67
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box2
2
105 0
349 0
4
0 0 2 81
0 3 77 67
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box3
2
105 0
349 0
4
0 0 2 81
0 4 77 67
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box4
2
105 0
349 0
4
0 0 2 81
0 2 77 67
0 28 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box1
2
106 0
110 0
4
0 0 3 4
0 1 4 5
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box2
2
106 0
110 0
4
0 0 3 4
0 3 4 5
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box3
2
106 0
110 0
4
0 0 3 4
0 4 4 5
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_10_2 loc_10_3 loc_10_4 right box4
2
106 0
110 0
4
0 0 3 4
0 2 4 5
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_10_2 loc_9_2 loc_8_2 up box1
2
108 0
352 0
4
0 0 3 82
0 1 78 68
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_10_2 loc_9_2 loc_8_2 up box2
2
108 0
352 0
4
0 0 3 82
0 3 78 68
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_10_2 loc_9_2 loc_8_2 up box3
2
108 0
352 0
4
0 0 3 82
0 4 78 68
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_10_2 loc_9_2 loc_8_2 up box4
2
108 0
352 0
4
0 0 3 82
0 2 78 68
0 29 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
110 0
114 0
4
0 0 4 5
0 1 5 6
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
110 0
114 0
4
0 0 4 5
0 3 5 6
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
110 0
114 0
4
0 0 4 5
0 4 5 6
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box4
2
110 0
114 0
4
0 0 4 5
0 2 5 6
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box1
2
112 0
355 0
4
0 0 4 83
0 1 79 69
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box2
2
112 0
355 0
4
0 0 4 83
0 3 79 69
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box3
2
112 0
355 0
4
0 0 4 83
0 4 79 69
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box4
2
112 0
355 0
4
0 0 4 83
0 2 79 69
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box1
2
109 0
113 0
4
0 0 5 4
0 1 4 3
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box2
2
109 0
113 0
4
0 0 5 4
0 3 4 3
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box3
2
109 0
113 0
4
0 0 5 4
0 4 4 3
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box4
2
109 0
113 0
4
0 0 5 4
0 2 4 3
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
114 0
117 0
4
0 0 5 6
0 1 6 7
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
114 0
117 0
4
0 0 5 6
0 3 6 7
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
114 0
117 0
4
0 0 5 6
0 4 6 7
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box4
2
114 0
117 0
4
0 0 5 6
0 2 6 7
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box1
2
115 0
359 0
4
0 0 5 84
0 1 80 70
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box2
2
115 0
359 0
4
0 0 5 84
0 3 80 70
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box3
2
115 0
359 0
4
0 0 5 84
0 4 80 70
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box4
2
115 0
359 0
4
0 0 5 84
0 2 80 70
0 31 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
113 0
116 0
4
0 0 6 5
0 1 5 4
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
113 0
116 0
4
0 0 6 5
0 3 5 4
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
113 0
116 0
4
0 0 6 5
0 4 5 4
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box4
2
113 0
116 0
4
0 0 6 5
0 2 5 4
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
117 0
121 0
4
0 0 6 7
0 1 7 8
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
117 0
121 0
4
0 0 6 7
0 3 7 8
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
117 0
121 0
4
0 0 6 7
0 4 7 8
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box4
2
117 0
121 0
4
0 0 6 7
0 2 7 8
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
119 0
363 0
4
0 0 6 85
0 1 81 71
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
119 0
363 0
4
0 0 6 85
0 3 81 71
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
119 0
363 0
4
0 0 6 85
0 4 81 71
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box4
2
119 0
363 0
4
0 0 6 85
0 2 81 71
0 32 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
116 0
120 0
4
0 0 7 6
0 1 6 5
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
116 0
120 0
4
0 0 7 6
0 3 6 5
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
116 0
120 0
4
0 0 7 6
0 4 6 5
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box4
2
116 0
120 0
4
0 0 7 6
0 2 6 5
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
121 0
125 0
4
0 0 7 8
0 1 8 9
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
121 0
125 0
4
0 0 7 8
0 3 8 9
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
121 0
125 0
4
0 0 7 8
0 4 8 9
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box4
2
121 0
125 0
4
0 0 7 8
0 2 8 9
0 55 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box1
2
122 0
154 0
4
0 0 7 17
0 1 17 22
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box2
2
122 0
154 0
4
0 0 7 17
0 3 17 22
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box3
2
122 0
154 0
4
0 0 7 17
0 4 17 22
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box4
2
122 0
154 0
4
0 0 7 17
0 2 17 22
0 64 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box1
2
123 0
367 0
4
0 0 7 86
0 1 82 72
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box2
2
123 0
367 0
4
0 0 7 86
0 3 82 72
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box3
2
123 0
367 0
4
0 0 7 86
0 4 82 72
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box4
2
123 0
367 0
4
0 0 7 86
0 2 82 72
0 33 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
120 0
124 0
4
0 0 8 7
0 1 7 6
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
120 0
124 0
4
0 0 8 7
0 3 7 6
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
120 0
124 0
4
0 0 8 7
0 4 7 6
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box4
2
120 0
124 0
4
0 0 8 7
0 2 7 6
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box1
2
125 0
129 0
4
0 0 8 9
0 1 9 10
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box2
2
125 0
129 0
4
0 0 8 9
0 3 9 10
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box3
2
125 0
129 0
4
0 0 8 9
0 4 9 10
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box4
2
125 0
129 0
4
0 0 8 9
0 2 9 10
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box1
2
126 0
158 0
4
0 0 8 18
0 1 18 23
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box2
2
126 0
158 0
4
0 0 8 18
0 3 18 23
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box3
2
126 0
158 0
4
0 0 8 18
0 4 18 23
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box4
2
126 0
158 0
4
0 0 8 18
0 2 18 23
0 65 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
127 0
371 0
4
0 0 8 87
0 1 83 73
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
127 0
371 0
4
0 0 8 87
0 3 83 73
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
127 0
371 0
4
0 0 8 87
0 4 83 73
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box4
2
127 0
371 0
4
0 0 8 87
0 2 83 73
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
124 0
128 0
4
0 0 9 8
0 1 8 7
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
124 0
128 0
4
0 0 9 8
0 3 8 7
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
124 0
128 0
4
0 0 9 8
0 4 8 7
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box4
2
124 0
128 0
4
0 0 9 8
0 2 8 7
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box1
2
129 0
132 0
4
0 0 9 10
0 1 10 0
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box2
2
129 0
132 0
4
0 0 9 10
0 3 10 0
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box3
2
129 0
132 0
4
0 0 9 10
0 4 10 0
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box4
2
129 0
132 0
4
0 0 9 10
0 2 10 0
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box1
2
95 0
132 0
4
0 0 10 0
0 1 0 1
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box2
2
95 0
132 0
4
0 0 10 0
0 3 0 1
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box3
2
95 0
132 0
4
0 0 10 0
0 4 0 1
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_10 loc_10_11 right box4
2
95 0
132 0
4
0 0 10 0
0 2 0 1
0 47 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box1
2
128 0
133 0
4
0 0 10 9
0 1 9 8
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box2
2
128 0
133 0
4
0 0 10 9
0 3 9 8
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box3
2
128 0
133 0
4
0 0 10 9
0 4 9 8
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box4
2
128 0
133 0
4
0 0 10 9
0 2 9 8
0 55 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box1
2
135 0
378 0
4
0 0 10 89
0 1 85 74
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box2
2
135 0
378 0
4
0 0 10 89
0 3 85 74
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box3
2
135 0
378 0
4
0 0 10 89
0 4 85 74
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_9_9 loc_8_9 up box4
2
135 0
378 0
4
0 0 10 89
0 2 85 74
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box1
2
98 0
136 0
4
0 0 11 0
0 1 0 75
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box2
2
98 0
136 0
4
0 0 11 0
0 3 0 75
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box3
2
98 0
136 0
4
0 0 11 0
0 4 0 75
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_10_10 loc_9_10 up box4
2
98 0
136 0
4
0 0 11 0
0 2 0 75
0 36 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box1
2
137 0
141 0
4
0 0 11 12
0 1 12 13
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box2
2
137 0
141 0
4
0 0 11 12
0 3 12 13
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box3
2
137 0
141 0
4
0 0 11 12
0 4 12 13
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_11 loc_11_12 right box4
2
137 0
141 0
4
0 0 11 12
0 2 12 13
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box1
2
138 0
164 0
4
0 0 11 20
0 1 20 19
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box2
2
138 0
164 0
4
0 0 11 20
0 3 20 19
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box3
2
138 0
164 0
4
0 0 11 20
0 4 20 19
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_10 loc_11_9 loc_11_8 left box4
2
138 0
164 0
4
0 0 11 20
0 2 20 19
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box1
2
102 0
139 0
4
0 0 12 1
0 1 1 76
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box2
2
102 0
139 0
4
0 0 12 1
0 3 1 76
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box3
2
102 0
139 0
4
0 0 12 1
0 4 1 76
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box4
2
102 0
139 0
4
0 0 12 1
0 2 1 76
0 37 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box1
2
138 0
140 0
4
0 0 12 11
0 1 11 20
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box2
2
138 0
140 0
4
0 0 12 11
0 3 11 20
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box3
2
138 0
140 0
4
0 0 12 11
0 4 11 20
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_11 loc_11_10 loc_11_9 left box4
2
138 0
140 0
4
0 0 12 11
0 2 11 20
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box1
2
105 0
142 0
4
0 0 13 2
0 1 2 77
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box2
2
105 0
142 0
4
0 0 13 2
0 3 2 77
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box3
2
105 0
142 0
4
0 0 13 2
0 4 2 77
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box4
2
105 0
142 0
4
0 0 13 2
0 2 2 77
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box1
2
140 0
143 0
4
0 0 13 12
0 1 12 11
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box2
2
140 0
143 0
4
0 0 13 12
0 3 12 11
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box3
2
140 0
143 0
4
0 0 13 12
0 4 12 11
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_12 loc_11_11 loc_11_10 left box4
2
140 0
143 0
4
0 0 13 12
0 2 12 11
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box1
2
108 0
145 0
4
0 0 14 3
0 1 3 78
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box2
2
108 0
145 0
4
0 0 14 3
0 3 3 78
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box3
2
108 0
145 0
4
0 0 14 3
0 4 3 78
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_11_2 loc_10_2 loc_9_2 up box4
2
108 0
145 0
4
0 0 14 3
0 2 3 78
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box1
2
112 0
147 0
4
0 0 15 4
0 1 4 79
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box2
2
112 0
147 0
4
0 0 15 4
0 3 4 79
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box3
2
112 0
147 0
4
0 0 15 4
0 4 4 79
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box4
2
112 0
147 0
4
0 0 15 4
0 2 4 79
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
119 0
149 0
4
0 0 16 6
0 1 6 81
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
119 0
149 0
4
0 0 16 6
0 3 6 81
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
119 0
149 0
4
0 0 16 6
0 4 6 81
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box4
2
119 0
149 0
4
0 0 16 6
0 2 6 81
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box1
2
150 0
153 0
4
0 0 16 17
0 1 17 18
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box2
2
150 0
153 0
4
0 0 16 17
0 3 17 18
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box3
2
150 0
153 0
4
0 0 16 17
0 4 17 18
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box4
2
150 0
153 0
4
0 0 16 17
0 2 17 18
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box1
2
123 0
151 0
4
0 0 17 7
0 1 7 82
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box2
2
123 0
151 0
4
0 0 17 7
0 3 7 82
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box3
2
123 0
151 0
4
0 0 17 7
0 4 7 82
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box4
2
123 0
151 0
4
0 0 17 7
0 2 7 82
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box1
2
153 0
157 0
4
0 0 17 18
0 1 18 19
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box2
2
153 0
157 0
4
0 0 17 18
0 3 18 19
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box3
2
153 0
157 0
4
0 0 17 18
0 4 18 19
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_7 loc_11_8 right box4
2
153 0
157 0
4
0 0 17 18
0 2 18 19
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
127 0
155 0
4
0 0 18 8
0 1 8 83
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
127 0
155 0
4
0 0 18 8
0 3 8 83
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
127 0
155 0
4
0 0 18 8
0 4 8 83
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box4
2
127 0
155 0
4
0 0 18 8
0 2 8 83
0 44 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box1
2
152 0
156 0
4
0 0 18 17
0 1 17 16
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box2
2
152 0
156 0
4
0 0 18 17
0 3 17 16
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box3
2
152 0
156 0
4
0 0 18 17
0 4 17 16
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box4
2
152 0
156 0
4
0 0 18 17
0 2 17 16
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box1
2
157 0
161 0
4
0 0 18 19
0 1 19 20
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box2
2
157 0
161 0
4
0 0 18 19
0 3 19 20
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box3
2
157 0
161 0
4
0 0 18 19
0 4 19 20
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_7 loc_11_8 loc_11_9 right box4
2
157 0
161 0
4
0 0 18 19
0 2 19 20
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box1
2
131 0
159 0
4
0 0 19 9
0 1 9 84
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box2
2
131 0
159 0
4
0 0 19 9
0 3 9 84
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box3
2
131 0
159 0
4
0 0 19 9
0 4 9 84
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_10_8 loc_9_8 up box4
2
131 0
159 0
4
0 0 19 9
0 2 9 84
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box1
2
156 0
160 0
4
0 0 19 18
0 1 18 17
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box2
2
156 0
160 0
4
0 0 19 18
0 3 18 17
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box3
2
156 0
160 0
4
0 0 19 18
0 4 18 17
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_7 loc_11_6 left box4
2
156 0
160 0
4
0 0 19 18
0 2 18 17
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box1
2
161 0
163 0
4
0 0 19 20
0 1 20 11
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box2
2
161 0
163 0
4
0 0 19 20
0 3 20 11
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box3
2
161 0
163 0
4
0 0 19 20
0 4 20 11
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_8 loc_11_9 loc_11_10 right box4
2
161 0
163 0
4
0 0 19 20
0 2 20 11
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box1
2
135 0
162 0
4
0 0 20 10
0 1 10 85
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box2
2
135 0
162 0
4
0 0 20 10
0 3 10 85
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box3
2
135 0
162 0
4
0 0 20 10
0 4 10 85
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_10_9 loc_9_9 up box4
2
135 0
162 0
4
0 0 20 10
0 2 10 85
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box1
2
137 0
163 0
4
0 0 20 11
0 1 11 12
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box2
2
137 0
163 0
4
0 0 20 11
0 3 11 12
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box3
2
137 0
163 0
4
0 0 20 11
0 4 11 12
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_10 loc_11_11 right box4
2
137 0
163 0
4
0 0 20 11
0 2 11 12
0 58 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box1
2
160 0
164 0
4
0 0 20 19
0 1 19 18
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box2
2
160 0
164 0
4
0 0 20 19
0 3 19 18
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box3
2
160 0
164 0
4
0 0 20 19
0 4 19 18
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_11_9 loc_11_8 loc_11_7 left box4
2
160 0
164 0
4
0 0 20 19
0 2 19 18
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box1
2
151 0
166 0
4
0 0 22 17
0 1 17 7
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box2
2
151 0
166 0
4
0 0 22 17
0 3 17 7
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box3
2
151 0
166 0
4
0 0 22 17
0 4 17 7
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box4
2
151 0
166 0
4
0 0 22 17
0 2 17 7
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box1
2
155 0
168 0
4
0 0 23 18
0 1 18 8
0 55 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box2
2
155 0
168 0
4
0 0 23 18
0 3 18 8
0 55 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box3
2
155 0
168 0
4
0 0 23 18
0 4 18 8
0 55 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box4
2
155 0
168 0
4
0 0 23 18
0 2 18 8
0 55 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
177 0
180 0
4
0 0 28 29
0 1 27 28
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
177 0
180 0
4
0 0 28 29
0 3 27 28
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
177 0
180 0
4
0 0 28 29
0 4 27 28
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box4
2
177 0
180 0
4
0 0 28 29
0 2 27 28
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
178 0
202 0
4
0 0 28 37
0 1 34 41
0 84 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box2
2
178 0
202 0
4
0 0 28 37
0 3 34 41
0 84 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box3
2
178 0
202 0
4
0 0 28 37
0 4 34 41
0 84 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box4
2
178 0
202 0
4
0 0 28 37
0 2 34 41
0 84 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
180 0
183 0
4
0 0 29 30
0 1 28 29
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
180 0
183 0
4
0 0 29 30
0 3 28 29
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
180 0
183 0
4
0 0 29 30
0 4 28 29
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box4
2
180 0
183 0
4
0 0 29 30
0 2 28 29
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
181 0
206 0
4
0 0 29 38
0 1 35 42
0 85 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
181 0
206 0
4
0 0 29 38
0 3 35 42
0 85 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
181 0
206 0
4
0 0 29 38
0 4 35 42
0 85 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box4
2
181 0
206 0
4
0 0 29 38
0 2 35 42
0 85 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
179 0
182 0
4
0 0 30 29
0 1 27 26
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
179 0
182 0
4
0 0 30 29
0 3 27 26
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
179 0
182 0
4
0 0 30 29
0 4 27 26
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box4
2
179 0
182 0
4
0 0 30 29
0 2 27 26
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
184 0
210 0
4
0 0 30 39
0 1 36 43
0 86 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
184 0
210 0
4
0 0 30 39
0 3 36 43
0 86 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
184 0
210 0
4
0 0 30 39
0 4 36 43
0 86 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box4
2
184 0
210 0
4
0 0 30 39
0 2 36 43
0 86 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
182 0
186 0
4
0 0 31 30
0 1 28 27
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
182 0
186 0
4
0 0 31 30
0 3 28 27
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
182 0
186 0
4
0 0 31 30
0 4 28 27
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box4
2
182 0
186 0
4
0 0 31 30
0 2 28 27
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
187 0
213 0
4
0 0 31 40
0 1 37 44
0 5 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
187 0
213 0
4
0 0 31 40
0 3 37 44
0 5 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
187 0
213 0
4
0 0 31 40
0 4 37 44
0 5 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box4
2
187 0
213 0
4
0 0 31 40
0 2 37 44
0 5 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_11 loc_4_12 right box1
2
189 0
193 0
4
0 0 33 34
0 1 31 32
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_11 loc_4_12 right box2
2
189 0
193 0
4
0 0 33 34
0 3 31 32
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_11 loc_4_12 right box3
2
189 0
193 0
4
0 0 33 34
0 4 31 32
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_11 loc_4_12 right box4
2
189 0
193 0
4
0 0 33 34
0 2 31 32
0 81 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box1
2
190 0
219 0
4
0 0 33 42
0 1 38 48
0 9 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box2
2
190 0
219 0
4
0 0 33 42
0 3 38 48
0 9 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box3
2
190 0
219 0
4
0 0 33 42
0 4 38 48
0 9 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box4
2
190 0
219 0
4
0 0 33 42
0 2 38 48
0 9 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box1
2
194 0
222 0
4
0 0 34 43
0 1 39 49
0 10 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box2
2
194 0
222 0
4
0 0 34 43
0 3 39 49
0 10 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box3
2
194 0
222 0
4
0 0 34 43
0 4 39 49
0 10 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box4
2
194 0
222 0
4
0 0 34 43
0 2 39 49
0 10 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
197 0
201 0
4
0 0 36 37
0 1 34 35
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box2
2
197 0
201 0
4
0 0 36 37
0 3 34 35
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box3
2
197 0
201 0
4
0 0 36 37
0 4 34 35
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box4
2
197 0
201 0
4
0 0 36 37
0 2 34 35
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
198 0
225 0
4
0 0 36 44
0 1 40 50
0 11 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box2
2
198 0
225 0
4
0 0 36 44
0 3 40 50
0 11 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box3
2
198 0
225 0
4
0 0 36 44
0 4 40 50
0 11 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box4
2
198 0
225 0
4
0 0 36 44
0 2 40 50
0 11 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
201 0
205 0
4
0 0 37 38
0 1 35 36
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
201 0
205 0
4
0 0 37 38
0 3 35 36
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
201 0
205 0
4
0 0 37 38
0 4 35 36
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box4
2
201 0
205 0
4
0 0 37 38
0 2 35 36
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
200 0
204 0
4
0 0 38 37
0 1 34 33
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box2
2
200 0
204 0
4
0 0 38 37
0 3 34 33
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box3
2
200 0
204 0
4
0 0 38 37
0 4 34 33
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box4
2
200 0
204 0
4
0 0 38 37
0 2 34 33
0 83 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
205 0
209 0
4
0 0 38 39
0 1 36 37
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
205 0
209 0
4
0 0 38 39
0 3 36 37
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
205 0
209 0
4
0 0 38 39
0 4 36 37
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box4
2
205 0
209 0
4
0 0 38 39
0 2 36 37
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
206 0
232 0
4
0 0 38 46
0 1 42 51
0 12 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
206 0
232 0
4
0 0 38 46
0 3 42 51
0 12 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
206 0
232 0
4
0 0 38 46
0 4 42 51
0 12 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box4
2
206 0
232 0
4
0 0 38 46
0 2 42 51
0 12 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
204 0
208 0
4
0 0 39 38
0 1 35 34
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
204 0
208 0
4
0 0 39 38
0 3 35 34
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
204 0
208 0
4
0 0 39 38
0 4 35 34
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box4
2
204 0
208 0
4
0 0 39 38
0 2 35 34
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
210 0
236 0
4
0 0 39 47
0 1 43 52
0 13 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box2
2
210 0
236 0
4
0 0 39 47
0 3 43 52
0 13 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box3
2
210 0
236 0
4
0 0 39 47
0 4 43 52
0 13 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box4
2
210 0
236 0
4
0 0 39 47
0 2 43 52
0 13 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
185 0
211 0
4
0 0 40 31
0 1 29 24
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box2
2
185 0
211 0
4
0 0 40 31
0 3 29 24
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box3
2
185 0
211 0
4
0 0 40 31
0 4 29 24
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box4
2
185 0
211 0
4
0 0 40 31
0 2 29 24
0 71 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
208 0
212 0
4
0 0 40 39
0 1 36 35
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
208 0
212 0
4
0 0 40 39
0 3 36 35
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
208 0
212 0
4
0 0 40 39
0 4 36 35
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box4
2
208 0
212 0
4
0 0 40 39
0 2 36 35
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
213 0
240 0
4
0 0 40 48
0 1 44 53
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
213 0
240 0
4
0 0 40 48
0 3 44 53
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
213 0
240 0
4
0 0 40 48
0 4 44 53
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box4
2
213 0
240 0
4
0 0 40 48
0 2 44 53
0 5 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box1
2
218 0
248 0
4
0 0 42 51
0 1 47 46
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box2
2
218 0
248 0
4
0 0 42 51
0 3 47 46
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box3
2
218 0
248 0
4
0 0 42 51
0 4 47 46
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box4
2
218 0
248 0
4
0 0 42 51
0 2 47 46
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box1
2
219 0
251 0
4
0 0 42 52
0 1 48 55
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box2
2
219 0
251 0
4
0 0 42 52
0 3 48 55
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box3
2
219 0
251 0
4
0 0 42 52
0 4 48 55
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box4
2
219 0
251 0
4
0 0 42 52
0 2 48 55
0 9 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box1
2
191 0
220 0
4
0 0 43 34
0 1 31 25
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box2
2
191 0
220 0
4
0 0 43 34
0 3 31 25
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box3
2
191 0
220 0
4
0 0 43 34
0 4 31 25
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box4
2
191 0
220 0
4
0 0 43 34
0 2 31 25
0 73 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box1
2
218 0
221 0
4
0 0 43 42
0 1 38 47
0 8 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box2
2
218 0
221 0
4
0 0 43 42
0 3 38 47
0 8 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box3
2
218 0
221 0
4
0 0 43 42
0 4 38 47
0 8 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box4
2
218 0
221 0
4
0 0 43 42
0 2 38 47
0 8 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box1
2
222 0
254 0
4
0 0 43 53
0 1 49 56
0 10 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box2
2
222 0
254 0
4
0 0 43 53
0 3 49 56
0 10 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box3
2
222 0
254 0
4
0 0 43 53
0 4 49 56
0 10 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box4
2
222 0
254 0
4
0 0 43 53
0 2 49 56
0 10 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
224 0
228 0
4
0 0 44 45
0 1 41 42
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box2
2
224 0
228 0
4
0 0 44 45
0 3 41 42
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box3
2
224 0
228 0
4
0 0 44 45
0 4 41 42
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box4
2
224 0
228 0
4
0 0 44 45
0 2 41 42
0 92 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
225 0
256 0
4
0 0 44 54
0 1 50 57
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box2
2
225 0
256 0
4
0 0 44 54
0 3 50 57
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box3
2
225 0
256 0
4
0 0 44 54
0 4 50 57
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box4
2
225 0
256 0
4
0 0 44 54
0 2 50 57
0 11 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
199 0
226 0
4
0 0 45 37
0 1 34 26
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box2
2
199 0
226 0
4
0 0 45 37
0 3 34 26
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box3
2
199 0
226 0
4
0 0 45 37
0 4 34 26
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box4
2
199 0
226 0
4
0 0 45 37
0 2 34 26
0 75 0 1
0 84 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
228 0
231 0
4
0 0 45 46
0 1 42 43
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box2
2
228 0
231 0
4
0 0 45 46
0 3 42 43
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box3
2
228 0
231 0
4
0 0 45 46
0 4 42 43
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box4
2
228 0
231 0
4
0 0 45 46
0 2 42 43
0 93 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
203 0
229 0
4
0 0 46 38
0 1 35 27
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
203 0
229 0
4
0 0 46 38
0 3 35 27
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
203 0
229 0
4
0 0 46 38
0 4 35 27
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box4
2
203 0
229 0
4
0 0 46 38
0 2 35 27
0 76 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
227 0
230 0
4
0 0 46 45
0 1 41 40
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
227 0
230 0
4
0 0 46 45
0 3 41 40
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
227 0
230 0
4
0 0 46 45
0 4 41 40
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
227 0
230 0
4
0 0 46 45
0 2 41 40
0 91 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
231 0
235 0
4
0 0 46 47
0 1 43 44
0 5 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
231 0
235 0
4
0 0 46 47
0 3 43 44
0 5 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
231 0
235 0
4
0 0 46 47
0 4 43 44
0 5 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box4
2
231 0
235 0
4
0 0 46 47
0 2 43 44
0 5 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
232 0
259 0
4
0 0 46 55
0 1 51 59
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
232 0
259 0
4
0 0 46 55
0 3 51 59
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
232 0
259 0
4
0 0 46 55
0 4 51 59
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box4
2
232 0
259 0
4
0 0 46 55
0 2 51 59
0 12 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
207 0
233 0
4
0 0 47 39
0 1 36 28
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
207 0
233 0
4
0 0 47 39
0 3 36 28
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
207 0
233 0
4
0 0 47 39
0 4 36 28
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box4
2
207 0
233 0
4
0 0 47 39
0 2 36 28
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
230 0
234 0
4
0 0 47 46
0 1 42 41
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
230 0
234 0
4
0 0 47 46
0 3 42 41
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
230 0
234 0
4
0 0 47 46
0 4 42 41
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box4
2
230 0
234 0
4
0 0 47 46
0 2 42 41
0 92 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
235 0
239 0
4
0 0 47 48
0 1 44 45
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
235 0
239 0
4
0 0 47 48
0 3 44 45
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
235 0
239 0
4
0 0 47 48
0 4 44 45
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box4
2
235 0
239 0
4
0 0 47 48
0 2 44 45
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
236 0
263 0
4
0 0 47 56
0 1 52 60
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box2
2
236 0
263 0
4
0 0 47 56
0 3 52 60
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box3
2
236 0
263 0
4
0 0 47 56
0 4 52 60
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box4
2
236 0
263 0
4
0 0 47 56
0 2 52 60
0 13 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
211 0
237 0
4
0 0 48 40
0 1 37 29
0 78 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
211 0
237 0
4
0 0 48 40
0 3 37 29
0 78 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
211 0
237 0
4
0 0 48 40
0 4 37 29
0 78 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box4
2
211 0
237 0
4
0 0 48 40
0 2 37 29
0 78 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
234 0
238 0
4
0 0 48 47
0 1 43 42
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
234 0
238 0
4
0 0 48 47
0 3 43 42
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
234 0
238 0
4
0 0 48 47
0 4 43 42
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box4
2
234 0
238 0
4
0 0 48 47
0 2 43 42
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
239 0
242 0
4
0 0 48 49
0 1 45 46
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
239 0
242 0
4
0 0 48 49
0 3 45 46
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
239 0
242 0
4
0 0 48 49
0 4 45 46
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box4
2
239 0
242 0
4
0 0 48 49
0 2 45 46
0 6 -1 0
0 7 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
240 0
267 0
4
0 0 48 57
0 1 53 61
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
240 0
267 0
4
0 0 48 57
0 3 53 61
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
240 0
267 0
4
0 0 48 57
0 4 53 61
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box4
2
240 0
267 0
4
0 0 48 57
0 2 53 61
0 14 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
238 0
241 0
4
0 0 49 48
0 1 44 43
0 5 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
238 0
241 0
4
0 0 49 48
0 3 44 43
0 5 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
238 0
241 0
4
0 0 49 48
0 4 44 43
0 5 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box4
2
238 0
241 0
4
0 0 49 48
0 2 44 43
0 5 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
242 0
246 0
4
0 0 49 50
0 1 46 47
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
242 0
246 0
4
0 0 49 50
0 3 46 47
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
242 0
246 0
4
0 0 49 50
0 4 46 47
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box4
2
242 0
246 0
4
0 0 49 50
0 2 46 47
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
243 0
270 0
4
0 0 49 58
0 1 54 62
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
243 0
270 0
4
0 0 49 58
0 3 54 62
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
243 0
270 0
4
0 0 49 58
0 4 54 62
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box4
2
243 0
270 0
4
0 0 49 58
0 2 54 62
0 15 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
241 0
245 0
4
0 0 50 49
0 1 45 44
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
241 0
245 0
4
0 0 50 49
0 3 45 44
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
241 0
245 0
4
0 0 50 49
0 4 45 44
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box4
2
241 0
245 0
4
0 0 50 49
0 2 45 44
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box1
2
246 0
247 0
4
0 0 50 51
0 1 47 38
0 8 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box2
2
246 0
247 0
4
0 0 50 51
0 3 47 38
0 8 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box3
2
246 0
247 0
4
0 0 50 51
0 4 47 38
0 8 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box4
2
246 0
247 0
4
0 0 50 51
0 2 47 38
0 8 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box1
2
217 0
247 0
4
0 0 51 42
0 1 38 39
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box2
2
217 0
247 0
4
0 0 51 42
0 3 38 39
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box3
2
217 0
247 0
4
0 0 51 42
0 4 38 39
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box4
2
217 0
247 0
4
0 0 51 42
0 2 38 39
0 89 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
245 0
248 0
4
0 0 51 50
0 1 46 45
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
245 0
248 0
4
0 0 51 50
0 3 46 45
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
245 0
248 0
4
0 0 51 50
0 4 46 45
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box4
2
245 0
248 0
4
0 0 51 50
0 2 46 45
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box1
2
216 0
249 0
4
0 0 52 42
0 1 38 30
0 80 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box2
2
216 0
249 0
4
0 0 52 42
0 3 38 30
0 80 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box3
2
216 0
249 0
4
0 0 52 42
0 4 38 30
0 80 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box4
2
216 0
249 0
4
0 0 52 42
0 2 38 30
0 80 0 1
0 89 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
251 0
274 0
4
0 0 52 59
0 1 55 65
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
251 0
274 0
4
0 0 52 59
0 3 55 65
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box3
2
251 0
274 0
4
0 0 52 59
0 4 55 65
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
251 0
274 0
4
0 0 52 59
0 2 55 65
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box1
2
220 0
252 0
4
0 0 53 43
0 1 39 31
0 81 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box2
2
220 0
252 0
4
0 0 53 43
0 3 39 31
0 81 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box3
2
220 0
252 0
4
0 0 53 43
0 4 39 31
0 81 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box4
2
220 0
252 0
4
0 0 53 43
0 2 39 31
0 81 0 1
0 90 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box1
2
254 0
277 0
4
0 0 53 60
0 1 56 66
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box2
2
254 0
277 0
4
0 0 53 60
0 3 56 66
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box3
2
254 0
277 0
4
0 0 53 60
0 4 56 66
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box4
2
254 0
277 0
4
0 0 53 60
0 2 56 66
0 17 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box1
2
223 0
255 0
4
0 0 54 44
0 1 40 33
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box2
2
223 0
255 0
4
0 0 54 44
0 3 40 33
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box3
2
223 0
255 0
4
0 0 54 44
0 4 40 33
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box4
2
223 0
255 0
4
0 0 54 44
0 2 40 33
0 83 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box1
2
256 0
280 0
4
0 0 54 61
0 1 57 68
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box2
2
256 0
280 0
4
0 0 54 61
0 3 57 68
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box3
2
256 0
280 0
4
0 0 54 61
0 4 57 68
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box4
2
256 0
280 0
4
0 0 54 61
0 2 57 68
0 18 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
229 0
257 0
4
0 0 55 46
0 1 42 35
0 85 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
229 0
257 0
4
0 0 55 46
0 3 42 35
0 85 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box3
2
229 0
257 0
4
0 0 55 46
0 4 42 35
0 85 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box4
2
229 0
257 0
4
0 0 55 46
0 2 42 35
0 85 0 1
0 93 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
258 0
262 0
4
0 0 55 56
0 1 52 53
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box2
2
258 0
262 0
4
0 0 55 56
0 3 52 53
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box3
2
258 0
262 0
4
0 0 55 56
0 4 52 53
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box4
2
258 0
262 0
4
0 0 55 56
0 2 52 53
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box1
2
259 0
287 0
4
0 0 55 63
0 1 59 70
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box2
2
259 0
287 0
4
0 0 55 63
0 3 59 70
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box3
2
259 0
287 0
4
0 0 55 63
0 4 59 70
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_6_4 loc_7_4 loc_8_4 down box4
2
259 0
287 0
4
0 0 55 63
0 2 59 70
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
233 0
260 0
4
0 0 56 47
0 1 43 36
0 86 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box2
2
233 0
260 0
4
0 0 56 47
0 3 43 36
0 86 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box3
2
233 0
260 0
4
0 0 56 47
0 4 43 36
0 86 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box4
2
233 0
260 0
4
0 0 56 47
0 2 43 36
0 86 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
262 0
266 0
4
0 0 56 57
0 1 53 54
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
262 0
266 0
4
0 0 56 57
0 3 53 54
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
262 0
266 0
4
0 0 56 57
0 4 53 54
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box4
2
262 0
266 0
4
0 0 56 57
0 2 53 54
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box1
2
263 0
291 0
4
0 0 56 64
0 1 60 71
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box2
2
263 0
291 0
4
0 0 56 64
0 3 60 71
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box3
2
263 0
291 0
4
0 0 56 64
0 4 60 71
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box4
2
263 0
291 0
4
0 0 56 64
0 2 60 71
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
237 0
264 0
4
0 0 57 48
0 1 44 37
0 5 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
237 0
264 0
4
0 0 57 48
0 3 44 37
0 5 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
237 0
264 0
4
0 0 57 48
0 4 44 37
0 5 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box4
2
237 0
264 0
4
0 0 57 48
0 2 44 37
0 5 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
261 0
265 0
4
0 0 57 56
0 1 52 51
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box2
2
261 0
265 0
4
0 0 57 56
0 3 52 51
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box3
2
261 0
265 0
4
0 0 57 56
0 4 52 51
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box4
2
261 0
265 0
4
0 0 57 56
0 2 52 51
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box1
2
267 0
295 0
4
0 0 57 65
0 1 61 72
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box2
2
267 0
295 0
4
0 0 57 65
0 3 61 72
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box3
2
267 0
295 0
4
0 0 57 65
0 4 61 72
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box4
2
267 0
295 0
4
0 0 57 65
0 2 61 72
0 22 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
265 0
269 0
4
0 0 58 57
0 1 53 52
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
265 0
269 0
4
0 0 58 57
0 3 53 52
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
265 0
269 0
4
0 0 58 57
0 4 53 52
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box4
2
265 0
269 0
4
0 0 58 57
0 2 53 52
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
270 0
299 0
4
0 0 58 66
0 1 62 73
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
270 0
299 0
4
0 0 58 66
0 3 62 73
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
270 0
299 0
4
0 0 58 66
0 4 62 73
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box4
2
270 0
299 0
4
0 0 58 66
0 2 62 73
0 23 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
249 0
271 0
4
0 0 59 52
0 1 48 38
0 9 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box2
2
249 0
271 0
4
0 0 59 52
0 3 48 38
0 9 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box3
2
249 0
271 0
4
0 0 59 52
0 4 48 38
0 9 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box4
2
249 0
271 0
4
0 0 59 52
0 2 48 38
0 9 -1 0
0 89 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
273 0
303 0
4
0 0 59 68
0 1 64 63
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
273 0
303 0
4
0 0 59 68
0 3 64 63
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box3
2
273 0
303 0
4
0 0 59 68
0 4 64 63
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box4
2
273 0
303 0
4
0 0 59 68
0 2 64 63
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
274 0
308 0
4
0 0 59 69
0 1 65 75
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
274 0
308 0
4
0 0 59 69
0 3 65 75
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
274 0
308 0
4
0 0 59 69
0 4 65 75
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
274 0
308 0
4
0 0 59 69
0 2 65 75
0 26 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box1
2
252 0
275 0
4
0 0 60 53
0 1 49 39
0 10 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box2
2
252 0
275 0
4
0 0 60 53
0 3 49 39
0 10 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box3
2
252 0
275 0
4
0 0 60 53
0 4 49 39
0 10 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box4
2
252 0
275 0
4
0 0 60 53
0 2 49 39
0 10 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
273 0
276 0
4
0 0 60 59
0 1 55 64
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
273 0
276 0
4
0 0 60 59
0 3 55 64
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
273 0
276 0
4
0 0 60 59
0 4 55 64
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
273 0
276 0
4
0 0 60 59
0 2 55 64
0 16 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
277 0
312 0
4
0 0 60 70
0 1 66 76
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
277 0
312 0
4
0 0 60 70
0 3 66 76
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
277 0
312 0
4
0 0 60 70
0 4 66 76
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
277 0
312 0
4
0 0 60 70
0 2 66 76
0 27 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box1
2
255 0
278 0
4
0 0 61 54
0 1 50 40
0 11 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box2
2
255 0
278 0
4
0 0 61 54
0 3 50 40
0 11 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box3
2
255 0
278 0
4
0 0 61 54
0 4 50 40
0 11 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box4
2
255 0
278 0
4
0 0 61 54
0 2 50 40
0 11 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box1
2
279 0
282 0
4
0 0 61 62
0 1 58 59
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box2
2
279 0
282 0
4
0 0 61 62
0 3 58 59
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box3
2
279 0
282 0
4
0 0 61 62
0 4 58 59
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box4
2
279 0
282 0
4
0 0 61 62
0 2 58 59
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box1
2
280 0
317 0
4
0 0 61 72
0 1 68 78
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box2
2
280 0
317 0
4
0 0 61 72
0 3 68 78
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box3
2
280 0
317 0
4
0 0 61 72
0 4 68 78
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_7_2 loc_8_2 loc_9_2 down box4
2
280 0
317 0
4
0 0 61 72
0 2 68 78
0 29 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
282 0
286 0
4
0 0 62 63
0 1 59 60
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box2
2
282 0
286 0
4
0 0 62 63
0 3 59 60
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box3
2
282 0
286 0
4
0 0 62 63
0 4 59 60
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box4
2
282 0
286 0
4
0 0 62 63
0 2 59 60
0 20 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box1
2
283 0
321 0
4
0 0 62 73
0 1 69 79
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box2
2
283 0
321 0
4
0 0 62 73
0 3 69 79
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box3
2
283 0
321 0
4
0 0 62 73
0 4 69 79
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box4
2
283 0
321 0
4
0 0 62 73
0 2 69 79
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
257 0
284 0
4
0 0 63 55
0 1 51 42
0 12 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
257 0
284 0
4
0 0 63 55
0 3 51 42
0 12 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box3
2
257 0
284 0
4
0 0 63 55
0 4 51 42
0 12 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box4
2
257 0
284 0
4
0 0 63 55
0 2 51 42
0 12 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box1
2
281 0
285 0
4
0 0 63 62
0 1 58 57
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box2
2
281 0
285 0
4
0 0 63 62
0 3 58 57
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box3
2
281 0
285 0
4
0 0 63 62
0 4 58 57
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box4
2
281 0
285 0
4
0 0 63 62
0 2 58 57
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
286 0
290 0
4
0 0 63 64
0 1 60 61
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box2
2
286 0
290 0
4
0 0 63 64
0 3 60 61
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box3
2
286 0
290 0
4
0 0 63 64
0 4 60 61
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box4
2
286 0
290 0
4
0 0 63 64
0 2 60 61
0 21 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
287 0
325 0
4
0 0 63 74
0 1 70 80
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
287 0
325 0
4
0 0 63 74
0 3 70 80
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box3
2
287 0
325 0
4
0 0 63 74
0 4 70 80
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box4
2
287 0
325 0
4
0 0 63 74
0 2 70 80
0 31 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
260 0
288 0
4
0 0 64 56
0 1 52 43
0 13 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box2
2
260 0
288 0
4
0 0 64 56
0 3 52 43
0 13 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box3
2
260 0
288 0
4
0 0 64 56
0 4 52 43
0 13 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box4
2
260 0
288 0
4
0 0 64 56
0 2 52 43
0 13 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box1
2
285 0
289 0
4
0 0 64 63
0 1 59 58
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box2
2
285 0
289 0
4
0 0 64 63
0 3 59 58
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box3
2
285 0
289 0
4
0 0 64 63
0 4 59 58
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box4
2
285 0
289 0
4
0 0 64 63
0 2 59 58
0 19 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
290 0
294 0
4
0 0 64 65
0 1 61 62
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box2
2
290 0
294 0
4
0 0 64 65
0 3 61 62
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box3
2
290 0
294 0
4
0 0 64 65
0 4 61 62
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box4
2
290 0
294 0
4
0 0 64 65
0 2 61 62
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box1
2
291 0
329 0
4
0 0 64 75
0 1 71 81
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box2
2
291 0
329 0
4
0 0 64 75
0 3 71 81
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box3
2
291 0
329 0
4
0 0 64 75
0 4 71 81
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box4
2
291 0
329 0
4
0 0 64 75
0 2 71 81
0 32 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
264 0
292 0
4
0 0 65 57
0 1 53 44
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
264 0
292 0
4
0 0 65 57
0 3 53 44
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
264 0
292 0
4
0 0 65 57
0 4 53 44
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box4
2
264 0
292 0
4
0 0 65 57
0 2 53 44
0 5 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box1
2
289 0
293 0
4
0 0 65 64
0 1 60 59
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box2
2
289 0
293 0
4
0 0 65 64
0 3 60 59
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box3
2
289 0
293 0
4
0 0 65 64
0 4 60 59
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box4
2
289 0
293 0
4
0 0 65 64
0 2 60 59
0 20 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
294 0
298 0
4
0 0 65 66
0 1 62 63
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
294 0
298 0
4
0 0 65 66
0 3 62 63
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
294 0
298 0
4
0 0 65 66
0 4 62 63
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box4
2
294 0
298 0
4
0 0 65 66
0 2 62 63
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box1
2
295 0
333 0
4
0 0 65 76
0 1 72 82
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box2
2
295 0
333 0
4
0 0 65 76
0 3 72 82
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box3
2
295 0
333 0
4
0 0 65 76
0 4 72 82
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_7_6 loc_8_6 loc_9_6 down box4
2
295 0
333 0
4
0 0 65 76
0 2 72 82
0 33 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
268 0
296 0
4
0 0 66 58
0 1 54 45
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
268 0
296 0
4
0 0 66 58
0 3 54 45
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
268 0
296 0
4
0 0 66 58
0 4 54 45
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box4
2
268 0
296 0
4
0 0 66 58
0 2 54 45
0 6 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box1
2
293 0
297 0
4
0 0 66 65
0 1 61 60
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box2
2
293 0
297 0
4
0 0 66 65
0 3 61 60
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box3
2
293 0
297 0
4
0 0 66 65
0 4 61 60
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box4
2
293 0
297 0
4
0 0 66 65
0 2 61 60
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
298 0
301 0
4
0 0 66 67
0 1 63 64
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
298 0
301 0
4
0 0 66 67
0 3 63 64
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
298 0
301 0
4
0 0 66 67
0 4 63 64
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box4
2
298 0
301 0
4
0 0 66 67
0 2 63 64
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
299 0
336 0
4
0 0 66 77
0 1 73 83
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
299 0
336 0
4
0 0 66 77
0 3 73 83
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
299 0
336 0
4
0 0 66 77
0 4 73 83
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box4
2
299 0
336 0
4
0 0 66 77
0 2 73 83
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
297 0
300 0
4
0 0 67 66
0 1 62 61
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
297 0
300 0
4
0 0 67 66
0 3 62 61
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
297 0
300 0
4
0 0 67 66
0 4 62 61
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box4
2
297 0
300 0
4
0 0 67 66
0 2 62 61
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
301 0
302 0
4
0 0 67 68
0 1 64 55
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
301 0
302 0
4
0 0 67 68
0 3 64 55
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box3
2
301 0
302 0
4
0 0 67 68
0 4 64 55
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box4
2
301 0
302 0
4
0 0 67 68
0 2 64 55
0 16 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
272 0
302 0
4
0 0 68 59
0 1 55 56
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
272 0
302 0
4
0 0 68 59
0 3 55 56
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
272 0
302 0
4
0 0 68 59
0 4 55 56
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
272 0
302 0
4
0 0 68 59
0 2 55 56
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
300 0
303 0
4
0 0 68 67
0 1 63 62
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
300 0
303 0
4
0 0 68 67
0 3 63 62
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
300 0
303 0
4
0 0 68 67
0 4 63 62
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box4
2
300 0
303 0
4
0 0 68 67
0 2 63 62
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
304 0
339 0
4
0 0 68 78
0 1 74 85
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
304 0
339 0
4
0 0 68 78
0 3 74 85
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
304 0
339 0
4
0 0 68 78
0 4 74 85
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
304 0
339 0
4
0 0 68 78
0 2 74 85
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
271 0
305 0
4
0 0 69 59
0 1 55 48
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
271 0
305 0
4
0 0 69 59
0 3 55 48
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box3
2
271 0
305 0
4
0 0 69 59
0 4 55 48
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
271 0
305 0
4
0 0 69 59
0 2 55 48
0 9 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box1
2
306 0
311 0
4
0 0 69 70
0 1 66 67
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box2
2
306 0
311 0
4
0 0 69 70
0 3 66 67
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box3
2
306 0
311 0
4
0 0 69 70
0 4 66 67
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box4
2
306 0
311 0
4
0 0 69 70
0 2 66 67
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
308 0
340 0
4
0 0 69 79
0 1 75 0
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
308 0
340 0
4
0 0 69 79
0 3 75 0
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
308 0
340 0
4
0 0 69 79
0 4 75 0
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
308 0
340 0
4
0 0 69 79
0 2 75 0
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
275 0
309 0
4
0 0 70 60
0 1 56 49
0 10 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
275 0
309 0
4
0 0 70 60
0 3 56 49
0 10 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
275 0
309 0
4
0 0 70 60
0 4 56 49
0 10 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box4
2
275 0
309 0
4
0 0 70 60
0 2 56 49
0 10 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
307 0
310 0
4
0 0 70 69
0 1 65 74
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
307 0
310 0
4
0 0 70 69
0 3 65 74
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
307 0
310 0
4
0 0 70 69
0 4 65 74
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
307 0
310 0
4
0 0 70 69
0 2 65 74
0 26 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
312 0
344 0
4
0 0 70 80
0 1 76 1
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
312 0
344 0
4
0 0 70 80
0 3 76 1
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
312 0
344 0
4
0 0 70 80
0 4 76 1
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box4
2
312 0
344 0
4
0 0 70 80
0 2 76 1
0 37 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box1
2
310 0
313 0
4
0 0 71 70
0 1 66 65
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box2
2
310 0
313 0
4
0 0 71 70
0 3 66 65
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box3
2
310 0
313 0
4
0 0 71 70
0 4 66 65
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box4
2
310 0
313 0
4
0 0 71 70
0 2 66 65
0 26 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box1
2
314 0
348 0
4
0 0 71 81
0 1 77 2
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box2
2
314 0
348 0
4
0 0 71 81
0 3 77 2
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box3
2
314 0
348 0
4
0 0 71 81
0 4 77 2
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box4
2
314 0
348 0
4
0 0 71 81
0 2 77 2
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box1
2
278 0
315 0
4
0 0 72 61
0 1 57 50
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box2
2
278 0
315 0
4
0 0 72 61
0 3 57 50
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box3
2
278 0
315 0
4
0 0 72 61
0 4 57 50
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_7_2 loc_6_2 up box4
2
278 0
315 0
4
0 0 72 61
0 2 57 50
0 11 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box1
2
316 0
320 0
4
0 0 72 73
0 1 69 70
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box2
2
316 0
320 0
4
0 0 72 73
0 3 69 70
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box3
2
316 0
320 0
4
0 0 72 73
0 4 69 70
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box4
2
316 0
320 0
4
0 0 72 73
0 2 69 70
0 30 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_8_2 loc_9_2 loc_10_2 down box1
2
317 0
351 0
4
0 0 72 82
0 1 78 3
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_8_2 loc_9_2 loc_10_2 down box2
2
317 0
351 0
4
0 0 72 82
0 3 78 3
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_8_2 loc_9_2 loc_10_2 down box3
2
317 0
351 0
4
0 0 72 82
0 4 78 3
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_8_2 loc_9_2 loc_10_2 down box4
2
317 0
351 0
4
0 0 72 82
0 2 78 3
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box1
2
320 0
324 0
4
0 0 73 74
0 1 70 71
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box2
2
320 0
324 0
4
0 0 73 74
0 3 70 71
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box3
2
320 0
324 0
4
0 0 73 74
0 4 70 71
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box4
2
320 0
324 0
4
0 0 73 74
0 2 70 71
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box1
2
321 0
354 0
4
0 0 73 83
0 1 79 4
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box2
2
321 0
354 0
4
0 0 73 83
0 3 79 4
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box3
2
321 0
354 0
4
0 0 73 83
0 4 79 4
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box4
2
321 0
354 0
4
0 0 73 83
0 2 79 4
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box1
2
284 0
322 0
4
0 0 74 63
0 1 59 51
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box2
2
284 0
322 0
4
0 0 74 63
0 3 59 51
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box3
2
284 0
322 0
4
0 0 74 63
0 4 59 51
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_7_4 loc_6_4 up box4
2
284 0
322 0
4
0 0 74 63
0 2 59 51
0 12 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box1
2
319 0
323 0
4
0 0 74 73
0 1 69 68
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box2
2
319 0
323 0
4
0 0 74 73
0 3 69 68
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box3
2
319 0
323 0
4
0 0 74 73
0 4 69 68
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box4
2
319 0
323 0
4
0 0 74 73
0 2 69 68
0 29 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box1
2
324 0
328 0
4
0 0 74 75
0 1 71 72
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box2
2
324 0
328 0
4
0 0 74 75
0 3 71 72
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box3
2
324 0
328 0
4
0 0 74 75
0 4 71 72
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box4
2
324 0
328 0
4
0 0 74 75
0 2 71 72
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box1
2
325 0
358 0
4
0 0 74 84
0 1 80 5
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box2
2
325 0
358 0
4
0 0 74 84
0 3 80 5
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box3
2
325 0
358 0
4
0 0 74 84
0 4 80 5
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box4
2
325 0
358 0
4
0 0 74 84
0 2 80 5
0 41 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box1
2
288 0
326 0
4
0 0 75 64
0 1 60 52
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box2
2
288 0
326 0
4
0 0 75 64
0 3 60 52
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box3
2
288 0
326 0
4
0 0 75 64
0 4 60 52
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box4
2
288 0
326 0
4
0 0 75 64
0 2 60 52
0 13 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box1
2
323 0
327 0
4
0 0 75 74
0 1 70 69
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box2
2
323 0
327 0
4
0 0 75 74
0 3 70 69
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box3
2
323 0
327 0
4
0 0 75 74
0 4 70 69
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box4
2
323 0
327 0
4
0 0 75 74
0 2 70 69
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
328 0
332 0
4
0 0 75 76
0 1 72 73
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
328 0
332 0
4
0 0 75 76
0 3 72 73
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
328 0
332 0
4
0 0 75 76
0 4 72 73
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box4
2
328 0
332 0
4
0 0 75 76
0 2 72 73
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box1
2
329 0
362 0
4
0 0 75 85
0 1 81 6
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box2
2
329 0
362 0
4
0 0 75 85
0 3 81 6
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box3
2
329 0
362 0
4
0 0 75 85
0 4 81 6
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box4
2
329 0
362 0
4
0 0 75 85
0 2 81 6
0 42 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
292 0
330 0
4
0 0 76 65
0 1 61 53
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
292 0
330 0
4
0 0 76 65
0 3 61 53
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box3
2
292 0
330 0
4
0 0 76 65
0 4 61 53
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box4
2
292 0
330 0
4
0 0 76 65
0 2 61 53
0 14 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
327 0
331 0
4
0 0 76 75
0 1 71 70
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
327 0
331 0
4
0 0 76 75
0 3 71 70
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box3
2
327 0
331 0
4
0 0 76 75
0 4 71 70
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box4
2
327 0
331 0
4
0 0 76 75
0 2 71 70
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box1
2
333 0
366 0
4
0 0 76 86
0 1 82 7
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box2
2
333 0
366 0
4
0 0 76 86
0 3 82 7
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box3
2
333 0
366 0
4
0 0 76 86
0 4 82 7
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box4
2
333 0
366 0
4
0 0 76 86
0 2 82 7
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
296 0
334 0
4
0 0 77 66
0 1 62 54
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
296 0
334 0
4
0 0 77 66
0 3 62 54
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
296 0
334 0
4
0 0 77 66
0 4 62 54
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box4
2
296 0
334 0
4
0 0 77 66
0 2 62 54
0 15 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
331 0
335 0
4
0 0 77 76
0 1 72 71
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
331 0
335 0
4
0 0 77 76
0 3 72 71
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
331 0
335 0
4
0 0 77 76
0 4 72 71
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box4
2
331 0
335 0
4
0 0 77 76
0 2 72 71
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
336 0
370 0
4
0 0 77 87
0 1 83 8
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
336 0
370 0
4
0 0 77 87
0 3 83 8
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
336 0
370 0
4
0 0 77 87
0 4 83 8
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box4
2
336 0
370 0
4
0 0 77 87
0 2 83 8
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
306 0
338 0
4
0 0 78 69
0 1 65 66
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
306 0
338 0
4
0 0 78 69
0 3 65 66
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
306 0
338 0
4
0 0 78 69
0 4 65 66
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
306 0
338 0
4
0 0 78 69
0 2 65 66
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box1
2
339 0
377 0
4
0 0 78 89
0 1 85 10
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box2
2
339 0
377 0
4
0 0 78 89
0 3 85 10
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box3
2
339 0
377 0
4
0 0 78 89
0 4 85 10
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_9 loc_9_9 loc_10_9 down box4
2
339 0
377 0
4
0 0 78 89
0 2 85 10
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box1
2
97 0
340 0
4
0 0 79 0
0 1 0 11
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box2
2
97 0
340 0
4
0 0 79 0
0 3 0 11
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box3
2
97 0
340 0
4
0 0 79 0
0 4 0 11
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_9_10 loc_10_10 loc_11_10 down box4
2
97 0
340 0
4
0 0 79 0
0 2 0 11
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
305 0
341 0
4
0 0 79 69
0 1 65 55
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
305 0
341 0
4
0 0 79 69
0 3 65 55
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
305 0
341 0
4
0 0 79 69
0 4 65 55
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
305 0
341 0
4
0 0 79 69
0 2 65 55
0 16 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box1
2
342 0
347 0
4
0 0 79 80
0 1 76 77
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box2
2
342 0
347 0
4
0 0 79 80
0 3 76 77
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box3
2
342 0
347 0
4
0 0 79 80
0 4 76 77
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box4
2
342 0
347 0
4
0 0 79 80
0 2 76 77
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
343 0
380 0
4
0 0 79 89
0 1 85 84
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
343 0
380 0
4
0 0 79 89
0 3 85 84
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
343 0
380 0
4
0 0 79 89
0 4 85 84
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
343 0
380 0
4
0 0 79 89
0 2 85 84
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box1
2
101 0
344 0
4
0 0 80 1
0 1 1 12
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box2
2
101 0
344 0
4
0 0 80 1
0 3 1 12
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box3
2
101 0
344 0
4
0 0 80 1
0 4 1 12
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box4
2
101 0
344 0
4
0 0 80 1
0 2 1 12
0 48 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
309 0
345 0
4
0 0 80 70
0 1 66 56
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
309 0
345 0
4
0 0 80 70
0 3 66 56
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
309 0
345 0
4
0 0 80 70
0 4 66 56
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
309 0
345 0
4
0 0 80 70
0 2 66 56
0 17 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
343 0
346 0
4
0 0 80 79
0 1 75 85
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
343 0
346 0
4
0 0 80 79
0 3 75 85
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
343 0
346 0
4
0 0 80 79
0 4 75 85
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box4
2
343 0
346 0
4
0 0 80 79
0 2 75 85
0 36 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box1
2
104 0
348 0
4
0 0 81 2
0 1 2 13
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box2
2
104 0
348 0
4
0 0 81 2
0 3 2 13
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box3
2
104 0
348 0
4
0 0 81 2
0 4 2 13
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box4
2
104 0
348 0
4
0 0 81 2
0 2 2 13
0 49 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box1
2
346 0
350 0
4
0 0 81 80
0 1 76 75
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box2
2
346 0
350 0
4
0 0 81 80
0 3 76 75
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box3
2
346 0
350 0
4
0 0 81 80
0 4 76 75
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box4
2
346 0
350 0
4
0 0 81 80
0 2 76 75
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_10_2 loc_11_2 down box1
2
107 0
351 0
4
0 0 82 3
0 1 3 14
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_9_2 loc_10_2 loc_11_2 down box2
2
107 0
351 0
4
0 0 82 3
0 3 3 14
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_9_2 loc_10_2 loc_11_2 down box3
2
107 0
351 0
4
0 0 82 3
0 4 3 14
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_9_2 loc_10_2 loc_11_2 down box4
2
107 0
351 0
4
0 0 82 3
0 2 3 14
0 50 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_9_2 loc_8_2 loc_7_2 up box1
2
315 0
352 0
4
0 0 82 72
0 1 68 57
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_8_2 loc_7_2 up box2
2
315 0
352 0
4
0 0 82 72
0 3 68 57
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_8_2 loc_7_2 up box3
2
315 0
352 0
4
0 0 82 72
0 4 68 57
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_8_2 loc_7_2 up box4
2
315 0
352 0
4
0 0 82 72
0 2 68 57
0 18 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box1
2
353 0
357 0
4
0 0 82 83
0 1 79 80
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box2
2
353 0
357 0
4
0 0 82 83
0 3 79 80
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box3
2
353 0
357 0
4
0 0 82 83
0 4 79 80
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box4
2
353 0
357 0
4
0 0 82 83
0 2 79 80
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box1
2
111 0
354 0
4
0 0 83 4
0 1 4 15
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box2
2
111 0
354 0
4
0 0 83 4
0 3 4 15
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box3
2
111 0
354 0
4
0 0 83 4
0 4 4 15
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box4
2
111 0
354 0
4
0 0 83 4
0 2 4 15
0 51 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box1
2
318 0
355 0
4
0 0 83 73
0 1 69 58
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box2
2
318 0
355 0
4
0 0 83 73
0 3 69 58
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box3
2
318 0
355 0
4
0 0 83 73
0 4 69 58
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box4
2
318 0
355 0
4
0 0 83 73
0 2 69 58
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
357 0
361 0
4
0 0 83 84
0 1 80 81
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
357 0
361 0
4
0 0 83 84
0 3 80 81
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
357 0
361 0
4
0 0 83 84
0 4 80 81
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box4
2
357 0
361 0
4
0 0 83 84
0 2 80 81
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
322 0
359 0
4
0 0 84 74
0 1 70 59
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
322 0
359 0
4
0 0 84 74
0 3 70 59
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box3
2
322 0
359 0
4
0 0 84 74
0 4 70 59
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box4
2
322 0
359 0
4
0 0 84 74
0 2 70 59
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box1
2
356 0
360 0
4
0 0 84 83
0 1 79 78
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box2
2
356 0
360 0
4
0 0 84 83
0 3 79 78
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box3
2
356 0
360 0
4
0 0 84 83
0 4 79 78
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box4
2
356 0
360 0
4
0 0 84 83
0 2 79 78
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
361 0
365 0
4
0 0 84 85
0 1 81 82
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
361 0
365 0
4
0 0 84 85
0 3 81 82
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
361 0
365 0
4
0 0 84 85
0 4 81 82
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box4
2
361 0
365 0
4
0 0 84 85
0 2 81 82
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
118 0
362 0
4
0 0 85 6
0 1 6 16
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
118 0
362 0
4
0 0 85 6
0 3 6 16
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
118 0
362 0
4
0 0 85 6
0 4 6 16
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box4
2
118 0
362 0
4
0 0 85 6
0 2 6 16
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
326 0
363 0
4
0 0 85 75
0 1 71 60
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
326 0
363 0
4
0 0 85 75
0 3 71 60
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box3
2
326 0
363 0
4
0 0 85 75
0 4 71 60
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box4
2
326 0
363 0
4
0 0 85 75
0 2 71 60
0 21 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
360 0
364 0
4
0 0 85 84
0 1 80 79
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
360 0
364 0
4
0 0 85 84
0 3 80 79
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
360 0
364 0
4
0 0 85 84
0 4 80 79
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box4
2
360 0
364 0
4
0 0 85 84
0 2 80 79
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
365 0
369 0
4
0 0 85 86
0 1 82 83
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
365 0
369 0
4
0 0 85 86
0 3 82 83
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
365 0
369 0
4
0 0 85 86
0 4 82 83
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box4
2
365 0
369 0
4
0 0 85 86
0 2 82 83
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box1
2
122 0
366 0
4
0 0 86 7
0 1 7 17
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box2
2
122 0
366 0
4
0 0 86 7
0 3 7 17
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box3
2
122 0
366 0
4
0 0 86 7
0 4 7 17
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box4
2
122 0
366 0
4
0 0 86 7
0 2 7 17
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box1
2
330 0
367 0
4
0 0 86 76
0 1 72 61
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box2
2
330 0
367 0
4
0 0 86 76
0 3 72 61
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box3
2
330 0
367 0
4
0 0 86 76
0 4 72 61
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_8_6 loc_7_6 up box4
2
330 0
367 0
4
0 0 86 76
0 2 72 61
0 22 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
364 0
368 0
4
0 0 86 85
0 1 81 80
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
364 0
368 0
4
0 0 86 85
0 3 81 80
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
364 0
368 0
4
0 0 86 85
0 4 81 80
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box4
2
364 0
368 0
4
0 0 86 85
0 2 81 80
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
369 0
373 0
4
0 0 86 87
0 1 83 84
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
369 0
373 0
4
0 0 86 87
0 3 83 84
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
369 0
373 0
4
0 0 86 87
0 4 83 84
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
369 0
373 0
4
0 0 86 87
0 2 83 84
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
126 0
370 0
4
0 0 87 8
0 1 8 18
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
126 0
370 0
4
0 0 87 8
0 3 8 18
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
126 0
370 0
4
0 0 87 8
0 4 8 18
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box4
2
126 0
370 0
4
0 0 87 8
0 2 8 18
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
334 0
371 0
4
0 0 87 77
0 1 73 62
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
334 0
371 0
4
0 0 87 77
0 3 73 62
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
334 0
371 0
4
0 0 87 77
0 4 73 62
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box4
2
334 0
371 0
4
0 0 87 77
0 2 73 62
0 23 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
368 0
372 0
4
0 0 87 86
0 1 82 81
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
368 0
372 0
4
0 0 87 86
0 3 82 81
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
368 0
372 0
4
0 0 87 86
0 4 82 81
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box4
2
368 0
372 0
4
0 0 87 86
0 2 82 81
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
373 0
376 0
4
0 0 87 88
0 1 84 85
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
373 0
376 0
4
0 0 87 88
0 3 84 85
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
373 0
376 0
4
0 0 87 88
0 4 84 85
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
373 0
376 0
4
0 0 87 88
0 2 84 85
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box1
2
130 0
374 0
4
0 0 88 9
0 1 9 19
0 56 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box2
2
130 0
374 0
4
0 0 88 9
0 3 9 19
0 56 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box3
2
130 0
374 0
4
0 0 88 9
0 4 9 19
0 56 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box4
2
130 0
374 0
4
0 0 88 9
0 2 9 19
0 56 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
372 0
375 0
4
0 0 88 87
0 1 83 82
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
372 0
375 0
4
0 0 88 87
0 3 83 82
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
372 0
375 0
4
0 0 88 87
0 4 83 82
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
372 0
375 0
4
0 0 88 87
0 2 83 82
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
376 0
379 0
4
0 0 88 89
0 1 85 75
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
376 0
379 0
4
0 0 88 89
0 3 85 75
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
376 0
379 0
4
0 0 88 89
0 4 85 75
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
376 0
379 0
4
0 0 88 89
0 2 85 75
0 36 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box1
2
134 0
377 0
4
0 0 89 10
0 1 10 20
0 57 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box2
2
134 0
377 0
4
0 0 89 10
0 3 10 20
0 57 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box3
2
134 0
377 0
4
0 0 89 10
0 4 10 20
0 57 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box4
2
134 0
377 0
4
0 0 89 10
0 2 10 20
0 57 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
337 0
378 0
4
0 0 89 78
0 1 74 64
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
337 0
378 0
4
0 0 89 78
0 3 74 64
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
337 0
378 0
4
0 0 89 78
0 4 74 64
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
337 0
378 0
4
0 0 89 78
0 2 74 64
0 25 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
342 0
379 0
4
0 0 89 79
0 1 75 76
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
342 0
379 0
4
0 0 89 79
0 3 75 76
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
342 0
379 0
4
0 0 89 79
0 4 75 76
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
342 0
379 0
4
0 0 89 79
0 2 75 76
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
375 0
380 0
4
0 0 89 88
0 1 84 83
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
375 0
380 0
4
0 0 89 88
0 3 84 83
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
375 0
380 0
4
0 0 89 88
0 4 84 83
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
375 0
380 0
4
0 0 89 88
0 2 84 83
0 44 0 1
0 45 -1 0
1
end_operator
0
