begin_version
3
end_version
begin_metric
1
end_metric
344
begin_variable
var0
-1
82
at-robot loc_10_10
at-robot loc_10_2
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_10_9
at-robot loc_11_2
at-robot loc_11_4
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_7
at-robot loc_11_9
at-robot loc_2_2
at-robot loc_2_3
at-robot loc_2_4
at-robot loc_2_5
at-robot loc_2_6
at-robot loc_2_7
at-robot loc_2_8
at-robot loc_3_10
at-robot loc_3_11
at-robot loc_3_2
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_3_7
at-robot loc_3_8
at-robot loc_4_10
at-robot loc_4_11
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_11
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_4
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_6_9
at-robot loc_7_11
at-robot loc_7_2
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_6
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_2
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_9
end_variable
begin_variable
var1
-1
78
at box1 loc_10_10
at box1 loc_10_2
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_10_9
at box1 loc_11_4
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_7
at box1 loc_11_9
at box1 loc_2_2
at box1 loc_2_3
at box1 loc_2_4
at box1 loc_2_5
at box1 loc_2_6
at box1 loc_2_7
at box1 loc_2_8
at box1 loc_3_11
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_3_7
at box1 loc_3_8
at box1 loc_4_10
at box1 loc_4_11
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_11
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_4
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_6_9
at box1 loc_7_11
at box1 loc_7_2
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_6
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_2
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_11
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
end_variable
begin_variable
var2
-1
78
at box2 loc_10_10
at box2 loc_10_2
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_10_9
at box2 loc_11_4
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_7
at box2 loc_11_9
at box2 loc_2_2
at box2 loc_2_3
at box2 loc_2_4
at box2 loc_2_5
at box2 loc_2_6
at box2 loc_2_7
at box2 loc_2_8
at box2 loc_3_11
at box2 loc_3_2
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_3_7
at box2 loc_3_8
at box2 loc_4_10
at box2 loc_4_11
at box2 loc_4_2
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_4_8
at box2 loc_4_9
at box2 loc_5_11
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_2
at box2 loc_6_3
at box2 loc_6_4
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_6_9
at box2 loc_7_11
at box2 loc_7_2
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_6
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_2
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_11
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
end_variable
begin_variable
var3
-1
78
at box3 loc_10_10
at box3 loc_10_2
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_10_9
at box3 loc_11_4
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_7
at box3 loc_11_9
at box3 loc_2_2
at box3 loc_2_3
at box3 loc_2_4
at box3 loc_2_5
at box3 loc_2_6
at box3 loc_2_7
at box3 loc_2_8
at box3 loc_3_11
at box3 loc_3_2
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_3_7
at box3 loc_3_8
at box3 loc_4_10
at box3 loc_4_11
at box3 loc_4_2
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_4_8
at box3 loc_4_9
at box3 loc_5_11
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_10
at box3 loc_6_11
at box3 loc_6_2
at box3 loc_6_3
at box3 loc_6_4
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_6_9
at box3 loc_7_11
at box3 loc_7_2
at box3 loc_7_3
at box3 loc_7_4
at box3 loc_7_5
at box3 loc_7_6
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_2
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_8
at box3 loc_8_9
at box3 loc_9_11
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
end_variable
begin_variable
var4
-1
78
at box4 loc_10_10
at box4 loc_10_2
at box4 loc_10_3
at box4 loc_10_4
at box4 loc_10_5
at box4 loc_10_6
at box4 loc_10_7
at box4 loc_10_8
at box4 loc_10_9
at box4 loc_11_4
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_7
at box4 loc_11_9
at box4 loc_2_2
at box4 loc_2_3
at box4 loc_2_4
at box4 loc_2_5
at box4 loc_2_6
at box4 loc_2_7
at box4 loc_2_8
at box4 loc_3_11
at box4 loc_3_2
at box4 loc_3_3
at box4 loc_3_4
at box4 loc_3_5
at box4 loc_3_6
at box4 loc_3_7
at box4 loc_3_8
at box4 loc_4_10
at box4 loc_4_11
at box4 loc_4_2
at box4 loc_4_3
at box4 loc_4_4
at box4 loc_4_5
at box4 loc_4_6
at box4 loc_4_7
at box4 loc_4_8
at box4 loc_4_9
at box4 loc_5_11
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_5
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_5_8
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_2
at box4 loc_6_3
at box4 loc_6_4
at box4 loc_6_5
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_6_8
at box4 loc_6_9
at box4 loc_7_11
at box4 loc_7_2
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_5
at box4 loc_7_6
at box4 loc_7_7
at box4 loc_7_8
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_2
at box4 loc_8_5
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_8
at box4 loc_8_9
at box4 loc_9_11
at box4 loc_9_3
at box4 loc_9_4
at box4 loc_9_5
end_variable
begin_variable
var5
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_10_2
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_10_9
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_11_4
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_2_2
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_2_4
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_2_7
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_3_8
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_4_11
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_6_4
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_7_6
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var88
-1
2
adjacent loc_10_10 loc_10_9 left
none-of-those
end_variable
begin_variable
var89
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var90
-1
2
adjacent loc_10_2 loc_10_3 right
none-of-those
end_variable
begin_variable
var91
-1
2
adjacent loc_10_2 loc_11_2 down
none-of-those
end_variable
begin_variable
var92
-1
2
adjacent loc_10_3 loc_10_2 left
none-of-those
end_variable
begin_variable
var93
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var94
-1
2
adjacent loc_10_3 loc_9_3 up
none-of-those
end_variable
begin_variable
var95
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var96
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var97
-1
2
adjacent loc_10_4 loc_11_4 down
none-of-those
end_variable
begin_variable
var98
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_10_8 loc_10_9 right
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_10_9 loc_10_10 right
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_10_9 loc_10_8 left
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_10_9 loc_11_9 down
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_10_9 loc_9_9 up
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_11_2 loc_10_2 up
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_11_4 loc_10_4 up
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_11_4 loc_11_5 right
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_11_5 loc_11_4 left
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_11_6 loc_11_7 right
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_11_7 loc_11_6 left
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_11_9 loc_10_9 up
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_2_2 loc_2_3 right
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_2_2 loc_3_2 down
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_2_3 loc_2_2 left
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_2_3 loc_2_4 right
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_2_4 loc_2_3 left
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_2_4 loc_2_5 right
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_2_4 loc_3_4 down
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_2_5 loc_2_4 left
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_2_5 loc_2_6 right
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_2_6 loc_2_5 left
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_2_6 loc_2_7 right
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_2_6 loc_3_6 down
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_2_7 loc_2_6 left
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_2_7 loc_2_8 right
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_2_7 loc_3_7 down
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_2_8 loc_2_7 left
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_2_8 loc_3_8 down
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_3_11 loc_4_11 down
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_3_2 loc_2_2 up
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_3_3 loc_4_3 down
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_3_4 loc_2_4 up
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_3_4 loc_4_4 down
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_3_6 loc_2_6 up
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_3_6 loc_3_7 right
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_3_7 loc_2_7 up
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_3_7 loc_3_6 left
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_3_7 loc_3_8 right
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_3_8 loc_2_8 up
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_3_8 loc_3_7 left
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_3_8 loc_4_8 down
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_4_10 loc_4_11 right
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_4_11 loc_3_11 up
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_4_11 loc_4_10 left
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_4_11 loc_5_11 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_4_3 loc_3_3 up
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_4_4 loc_3_4 up
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_4_8 loc_3_8 up
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_5_11 loc_4_11 up
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_5_4 loc_6_4 down
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_5_8 loc_6_8 down
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_6_10 loc_6_9 left
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_6_3 loc_6_4 right
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_6_4 loc_5_4 up
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_6_4 loc_6_3 left
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_6_4 loc_6_5 right
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_6_4 loc_7_4 down
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_6_5 loc_6_4 left
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_6_6 loc_7_6 down
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_6_8 loc_5_8 up
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_6_8 loc_6_9 right
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_6_8 loc_7_8 down
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_6_9 loc_6_10 right
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_6_9 loc_6_8 left
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_7_2 loc_7_3 right
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_7_3 loc_7_2 left
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_7_4 loc_6_4 up
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_7_5 loc_7_6 right
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_7_6 loc_6_6 up
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_7_6 loc_7_5 left
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_7_6 loc_7_7 right
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_7_6 loc_8_6 down
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_7_7 loc_7_6 left
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_7_8 loc_6_8 up
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_8_6 loc_7_6 up
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_9_3 loc_10_3 down
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_9_9 loc_10_9 down
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
0
begin_state
62
52
41
27
46
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
1
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 42
2 32
3 46
4 66
end_goal
1012
begin_operator
move loc_10_10 loc_10_9 left
2
13 0
88 0
1
0 0 0 8
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
82 0
89 0
1
0 0 0 76
1
end_operator
begin_operator
move loc_10_2 loc_10_3 right
2
7 0
90 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_2 loc_11_2 down
2
15 0
91 0
1
0 0 1 9
1
end_operator
begin_operator
move loc_10_3 loc_10_2 left
2
6 0
92 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
8 0
93 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_3 loc_9_3 up
2
84 0
94 0
1
0 0 2 78
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
7 0
95 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
9 0
96 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_4 loc_11_4 down
2
16 0
97 0
1
0 0 3 10
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
85 0
98 0
1
0 0 3 79
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
8 0
99 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
10 0
100 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
17 0
101 0
1
0 0 4 11
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
86 0
102 0
1
0 0 4 80
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
9 0
103 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
11 0
104 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
18 0
105 0
1
0 0 5 12
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
10 0
106 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
12 0
107 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
19 0
108 0
1
0 0 6 13
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
11 0
109 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_8 loc_10_9 right
2
13 0
110 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_9 loc_10_10 right
2
5 0
111 0
1
0 0 8 0
1
end_operator
begin_operator
move loc_10_9 loc_10_8 left
2
12 0
112 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_9 loc_11_9 down
2
20 0
113 0
1
0 0 8 14
1
end_operator
begin_operator
move loc_10_9 loc_9_9 up
2
87 0
114 0
1
0 0 8 81
1
end_operator
begin_operator
move loc_11_2 loc_10_2 up
2
6 0
115 0
1
0 0 9 1
1
end_operator
begin_operator
move loc_11_4 loc_10_4 up
2
8 0
116 0
1
0 0 10 3
1
end_operator
begin_operator
move loc_11_4 loc_11_5 right
2
17 0
117 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
9 0
118 0
1
0 0 11 4
1
end_operator
begin_operator
move loc_11_5 loc_11_4 left
2
16 0
119 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
18 0
120 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
10 0
121 0
1
0 0 12 5
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
17 0
122 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_6 loc_11_7 right
2
19 0
123 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
11 0
124 0
1
0 0 13 6
1
end_operator
begin_operator
move loc_11_7 loc_11_6 left
2
18 0
125 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_9 loc_10_9 up
2
13 0
126 0
1
0 0 14 8
1
end_operator
begin_operator
move loc_2_2 loc_2_3 right
2
22 0
127 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_2_2 loc_3_2 down
2
30 0
128 0
1
0 0 15 24
1
end_operator
begin_operator
move loc_2_3 loc_2_2 left
2
21 0
129 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_2_3 loc_2_4 right
2
23 0
130 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
31 0
131 0
1
0 0 16 25
1
end_operator
begin_operator
move loc_2_4 loc_2_3 left
2
22 0
132 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_2_4 loc_2_5 right
2
24 0
133 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_2_4 loc_3_4 down
2
32 0
134 0
1
0 0 17 26
1
end_operator
begin_operator
move loc_2_5 loc_2_4 left
2
23 0
135 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_2_5 loc_2_6 right
2
25 0
136 0
1
0 0 18 19
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
33 0
137 0
1
0 0 18 27
1
end_operator
begin_operator
move loc_2_6 loc_2_5 left
2
24 0
138 0
1
0 0 19 18
1
end_operator
begin_operator
move loc_2_6 loc_2_7 right
2
26 0
139 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_2_6 loc_3_6 down
2
34 0
140 0
1
0 0 19 28
1
end_operator
begin_operator
move loc_2_7 loc_2_6 left
2
25 0
141 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_2_7 loc_2_8 right
2
27 0
142 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_2_7 loc_3_7 down
2
35 0
143 0
1
0 0 20 29
1
end_operator
begin_operator
move loc_2_8 loc_2_7 left
2
26 0
144 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_2_8 loc_3_8 down
2
36 0
145 0
1
0 0 21 30
1
end_operator
begin_operator
move loc_3_10 loc_3_11 right
2
29 0
146 0
1
0 0 22 23
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
37 0
147 0
1
0 0 22 31
1
end_operator
begin_operator
move loc_3_11 loc_3_10 left
2
28 0
148 0
1
0 0 23 22
1
end_operator
begin_operator
move loc_3_11 loc_4_11 down
2
38 0
149 0
1
0 0 23 32
1
end_operator
begin_operator
move loc_3_2 loc_2_2 up
2
21 0
150 0
1
0 0 24 15
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
31 0
151 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
39 0
152 0
1
0 0 24 33
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
22 0
153 0
1
0 0 25 16
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
30 0
154 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
32 0
155 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_3_3 loc_4_3 down
2
40 0
156 0
1
0 0 25 34
1
end_operator
begin_operator
move loc_3_4 loc_2_4 up
2
23 0
157 0
1
0 0 26 17
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
31 0
158 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
33 0
159 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_3_4 loc_4_4 down
2
41 0
160 0
1
0 0 26 35
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
24 0
161 0
1
0 0 27 18
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
32 0
162 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
34 0
163 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
42 0
164 0
1
0 0 27 36
1
end_operator
begin_operator
move loc_3_6 loc_2_6 up
2
25 0
165 0
1
0 0 28 19
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
33 0
166 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_3_6 loc_3_7 right
2
35 0
167 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
43 0
168 0
1
0 0 28 37
1
end_operator
begin_operator
move loc_3_7 loc_2_7 up
2
26 0
169 0
1
0 0 29 20
1
end_operator
begin_operator
move loc_3_7 loc_3_6 left
2
34 0
170 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_3_7 loc_3_8 right
2
36 0
171 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
44 0
172 0
1
0 0 29 38
1
end_operator
begin_operator
move loc_3_8 loc_2_8 up
2
27 0
173 0
1
0 0 30 21
1
end_operator
begin_operator
move loc_3_8 loc_3_7 left
2
35 0
174 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_3_8 loc_4_8 down
2
45 0
175 0
1
0 0 30 39
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
28 0
176 0
1
0 0 31 22
1
end_operator
begin_operator
move loc_4_10 loc_4_11 right
2
38 0
177 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
46 0
178 0
1
0 0 31 40
1
end_operator
begin_operator
move loc_4_11 loc_3_11 up
2
29 0
179 0
1
0 0 32 23
1
end_operator
begin_operator
move loc_4_11 loc_4_10 left
2
37 0
180 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_4_11 loc_5_11 down
2
47 0
181 0
1
0 0 32 41
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
30 0
182 0
1
0 0 33 24
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
40 0
183 0
1
0 0 33 34
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
48 0
184 0
1
0 0 33 42
1
end_operator
begin_operator
move loc_4_3 loc_3_3 up
2
31 0
185 0
1
0 0 34 25
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
39 0
186 0
1
0 0 34 33
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
41 0
187 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
49 0
188 0
1
0 0 34 43
1
end_operator
begin_operator
move loc_4_4 loc_3_4 up
2
32 0
189 0
1
0 0 35 26
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
40 0
190 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
42 0
191 0
1
0 0 35 36
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
50 0
192 0
1
0 0 35 44
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
33 0
193 0
1
0 0 36 27
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
41 0
194 0
1
0 0 36 35
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
43 0
195 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
51 0
196 0
1
0 0 36 45
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
34 0
197 0
1
0 0 37 28
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
42 0
198 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
44 0
199 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
52 0
200 0
1
0 0 37 46
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
35 0
201 0
1
0 0 38 29
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
43 0
202 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
45 0
203 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
53 0
204 0
1
0 0 38 47
1
end_operator
begin_operator
move loc_4_8 loc_3_8 up
2
36 0
205 0
1
0 0 39 30
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
44 0
206 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
46 0
207 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
54 0
208 0
1
0 0 39 48
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
37 0
209 0
1
0 0 40 31
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
45 0
210 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
55 0
211 0
1
0 0 40 49
1
end_operator
begin_operator
move loc_5_11 loc_4_11 up
2
38 0
212 0
1
0 0 41 32
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
57 0
213 0
1
0 0 41 51
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
39 0
214 0
1
0 0 42 33
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
49 0
215 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
58 0
216 0
1
0 0 42 52
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
40 0
217 0
1
0 0 43 34
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
48 0
218 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
50 0
219 0
1
0 0 43 44
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
59 0
220 0
1
0 0 43 53
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
41 0
221 0
1
0 0 44 35
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
49 0
222 0
1
0 0 44 43
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
51 0
223 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_5_4 loc_6_4 down
2
60 0
224 0
1
0 0 44 54
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
42 0
225 0
1
0 0 45 36
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
50 0
226 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
52 0
227 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
61 0
228 0
1
0 0 45 55
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
43 0
229 0
1
0 0 46 37
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
51 0
230 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
53 0
231 0
1
0 0 46 47
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
62 0
232 0
1
0 0 46 56
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
44 0
233 0
1
0 0 47 38
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
52 0
234 0
1
0 0 47 46
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
54 0
235 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
63 0
236 0
1
0 0 47 57
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
45 0
237 0
1
0 0 48 39
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
53 0
238 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
55 0
239 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_5_8 loc_6_8 down
2
64 0
240 0
1
0 0 48 58
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
46 0
241 0
1
0 0 49 40
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
54 0
242 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
65 0
243 0
1
0 0 49 59
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
57 0
244 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_6_10 loc_6_9 left
2
65 0
245 0
1
0 0 50 59
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
47 0
246 0
1
0 0 51 41
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
56 0
247 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
66 0
248 0
1
0 0 51 60
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
48 0
249 0
1
0 0 52 42
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
59 0
250 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
67 0
251 0
1
0 0 52 61
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
49 0
252 0
1
0 0 53 43
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
58 0
253 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_6_3 loc_6_4 right
2
60 0
254 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
68 0
255 0
1
0 0 53 62
1
end_operator
begin_operator
move loc_6_4 loc_5_4 up
2
50 0
256 0
1
0 0 54 44
1
end_operator
begin_operator
move loc_6_4 loc_6_3 left
2
59 0
257 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_6_4 loc_6_5 right
2
61 0
258 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_6_4 loc_7_4 down
2
69 0
259 0
1
0 0 54 63
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
51 0
260 0
1
0 0 55 45
1
end_operator
begin_operator
move loc_6_5 loc_6_4 left
2
60 0
261 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
62 0
262 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
70 0
263 0
1
0 0 55 64
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
52 0
264 0
1
0 0 56 46
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
61 0
265 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
63 0
266 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_6_6 loc_7_6 down
2
71 0
267 0
1
0 0 56 65
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
53 0
268 0
1
0 0 57 47
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
62 0
269 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
64 0
270 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
72 0
271 0
1
0 0 57 66
1
end_operator
begin_operator
move loc_6_8 loc_5_8 up
2
54 0
272 0
1
0 0 58 48
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
63 0
273 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_6_8 loc_6_9 right
2
65 0
274 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_6_8 loc_7_8 down
2
73 0
275 0
1
0 0 58 67
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
55 0
276 0
1
0 0 59 49
1
end_operator
begin_operator
move loc_6_9 loc_6_10 right
2
56 0
277 0
1
0 0 59 50
1
end_operator
begin_operator
move loc_6_9 loc_6_8 left
2
64 0
278 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
57 0
279 0
1
0 0 60 51
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
75 0
280 0
1
0 0 60 69
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
58 0
281 0
1
0 0 61 52
1
end_operator
begin_operator
move loc_7_2 loc_7_3 right
2
68 0
282 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
76 0
283 0
1
0 0 61 70
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
59 0
284 0
1
0 0 62 53
1
end_operator
begin_operator
move loc_7_3 loc_7_2 left
2
67 0
285 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
69 0
286 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_7_4 loc_6_4 up
2
60 0
287 0
1
0 0 63 54
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
68 0
288 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
70 0
289 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
61 0
290 0
1
0 0 64 55
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
69 0
291 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_7_5 loc_7_6 right
2
71 0
292 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
77 0
293 0
1
0 0 64 71
1
end_operator
begin_operator
move loc_7_6 loc_6_6 up
2
62 0
294 0
1
0 0 65 56
1
end_operator
begin_operator
move loc_7_6 loc_7_5 left
2
70 0
295 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_7_6 loc_7_7 right
2
72 0
296 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_7_6 loc_8_6 down
2
78 0
297 0
1
0 0 65 72
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
63 0
298 0
1
0 0 66 57
1
end_operator
begin_operator
move loc_7_7 loc_7_6 left
2
71 0
299 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
73 0
300 0
1
0 0 66 67
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
79 0
301 0
1
0 0 66 73
1
end_operator
begin_operator
move loc_7_8 loc_6_8 up
2
64 0
302 0
1
0 0 67 58
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
72 0
303 0
1
0 0 67 66
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
80 0
304 0
1
0 0 67 74
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
75 0
305 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
81 0
306 0
1
0 0 68 75
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
82 0
307 0
1
0 0 68 76
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
66 0
308 0
1
0 0 69 60
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
74 0
309 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
83 0
310 0
1
0 0 69 77
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
67 0
311 0
1
0 0 70 61
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
70 0
312 0
1
0 0 71 64
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
78 0
313 0
1
0 0 71 72
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
86 0
314 0
1
0 0 71 80
1
end_operator
begin_operator
move loc_8_6 loc_7_6 up
2
71 0
315 0
1
0 0 72 65
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
77 0
316 0
1
0 0 72 71
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
79 0
317 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
72 0
318 0
1
0 0 73 66
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
78 0
319 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
80 0
320 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
73 0
321 0
1
0 0 74 67
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
79 0
322 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
81 0
323 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
74 0
324 0
1
0 0 75 68
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
80 0
325 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
87 0
326 0
1
0 0 75 81
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
5 0
327 0
1
0 0 76 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
74 0
328 0
1
0 0 76 68
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
83 0
329 0
1
0 0 76 77
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
87 0
330 0
1
0 0 76 81
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
75 0
331 0
1
0 0 77 69
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
82 0
332 0
1
0 0 77 76
1
end_operator
begin_operator
move loc_9_3 loc_10_3 down
2
7 0
333 0
1
0 0 78 2
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
85 0
334 0
1
0 0 78 79
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
8 0
335 0
1
0 0 79 3
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
84 0
336 0
1
0 0 79 78
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
86 0
337 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
9 0
338 0
1
0 0 80 4
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
77 0
339 0
1
0 0 80 71
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
85 0
340 0
1
0 0 80 79
1
end_operator
begin_operator
move loc_9_9 loc_10_9 down
2
13 0
341 0
1
0 0 81 8
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
81 0
342 0
1
0 0 81 75
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
82 0
343 0
1
0 0 81 76
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box1
2
88 0
112 0
4
0 0 0 8
0 1 8 7
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box2
2
88 0
112 0
4
0 0 0 8
0 2 8 7
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box3
2
88 0
112 0
4
0 0 0 8
0 3 8 7
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_10_9 loc_10_8 left box4
2
88 0
112 0
4
0 0 0 8
0 4 8 7
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
93 0
96 0
4
0 0 2 3
0 1 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
93 0
96 0
4
0 0 2 3
0 2 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
93 0
96 0
4
0 0 2 3
0 3 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box4
2
93 0
96 0
4
0 0 2 3
0 4 3 4
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box1
2
92 0
95 0
4
0 0 3 2
0 1 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box2
2
92 0
95 0
4
0 0 3 2
0 2 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box3
2
92 0
95 0
4
0 0 3 2
0 3 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_3 loc_10_2 left box4
2
92 0
95 0
4
0 0 3 2
0 4 2 1
0 6 0 1
0 7 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
96 0
100 0
4
0 0 3 4
0 1 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
96 0
100 0
4
0 0 3 4
0 2 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
96 0
100 0
4
0 0 3 4
0 3 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box4
2
96 0
100 0
4
0 0 3 4
0 4 4 5
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
95 0
99 0
4
0 0 4 3
0 1 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
95 0
99 0
4
0 0 4 3
0 2 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
95 0
99 0
4
0 0 4 3
0 3 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box4
2
95 0
99 0
4
0 0 4 3
0 4 3 2
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
100 0
104 0
4
0 0 4 5
0 1 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
100 0
104 0
4
0 0 4 5
0 2 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
100 0
104 0
4
0 0 4 5
0 3 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box4
2
100 0
104 0
4
0 0 4 5
0 4 5 6
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
102 0
339 0
4
0 0 4 80
0 1 77 69
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
102 0
339 0
4
0 0 4 80
0 2 77 69
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
102 0
339 0
4
0 0 4 80
0 3 77 69
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box4
2
102 0
339 0
4
0 0 4 80
0 4 77 69
0 77 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
99 0
103 0
4
0 0 5 4
0 1 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
99 0
103 0
4
0 0 5 4
0 2 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
99 0
103 0
4
0 0 5 4
0 3 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box4
2
99 0
103 0
4
0 0 5 4
0 4 4 3
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
104 0
107 0
4
0 0 5 6
0 1 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
104 0
107 0
4
0 0 5 6
0 2 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
104 0
107 0
4
0 0 5 6
0 3 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box4
2
104 0
107 0
4
0 0 5 6
0 4 6 7
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
103 0
106 0
4
0 0 6 5
0 1 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
103 0
106 0
4
0 0 6 5
0 2 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
103 0
106 0
4
0 0 6 5
0 3 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box4
2
103 0
106 0
4
0 0 6 5
0 4 5 4
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box1
2
107 0
110 0
4
0 0 6 7
0 1 7 8
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box2
2
107 0
110 0
4
0 0 6 7
0 2 7 8
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box3
2
107 0
110 0
4
0 0 6 7
0 3 7 8
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_7 loc_10_8 loc_10_9 right box4
2
107 0
110 0
4
0 0 6 7
0 4 7 8
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
106 0
109 0
4
0 0 7 6
0 1 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
106 0
109 0
4
0 0 7 6
0 2 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
106 0
109 0
4
0 0 7 6
0 3 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box4
2
106 0
109 0
4
0 0 7 6
0 4 6 5
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box1
2
110 0
111 0
4
0 0 7 8
0 1 8 0
0 5 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box2
2
110 0
111 0
4
0 0 7 8
0 2 8 0
0 5 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box3
2
110 0
111 0
4
0 0 7 8
0 3 8 0
0 5 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_9 loc_10_10 right box4
2
110 0
111 0
4
0 0 7 8
0 4 8 0
0 5 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box1
2
109 0
112 0
4
0 0 8 7
0 1 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box2
2
109 0
112 0
4
0 0 8 7
0 2 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box3
2
109 0
112 0
4
0 0 8 7
0 3 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_9 loc_10_8 loc_10_7 left box4
2
109 0
112 0
4
0 0 8 7
0 4 7 6
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box1
2
98 0
116 0
4
0 0 10 3
0 1 3 76
0 8 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box2
2
98 0
116 0
4
0 0 10 3
0 2 3 76
0 8 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box3
2
98 0
116 0
4
0 0 10 3
0 3 3 76
0 8 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box4
2
98 0
116 0
4
0 0 10 3
0 4 3 76
0 8 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box1
2
117 0
120 0
4
0 0 10 11
0 1 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box2
2
117 0
120 0
4
0 0 10 11
0 2 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box3
2
117 0
120 0
4
0 0 10 11
0 3 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box4
2
117 0
120 0
4
0 0 10 11
0 4 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
102 0
118 0
4
0 0 11 4
0 1 4 77
0 9 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
102 0
118 0
4
0 0 11 4
0 2 4 77
0 9 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
102 0
118 0
4
0 0 11 4
0 3 4 77
0 9 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box4
2
102 0
118 0
4
0 0 11 4
0 4 4 77
0 9 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box1
2
120 0
123 0
4
0 0 11 12
0 1 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box2
2
120 0
123 0
4
0 0 11 12
0 2 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box3
2
120 0
123 0
4
0 0 11 12
0 3 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_6 loc_11_7 right box4
2
120 0
123 0
4
0 0 11 12
0 4 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box1
2
119 0
122 0
4
0 0 12 11
0 1 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box2
2
119 0
122 0
4
0 0 12 11
0 2 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box3
2
119 0
122 0
4
0 0 12 11
0 3 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box4
2
119 0
122 0
4
0 0 12 11
0 4 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box1
2
122 0
125 0
4
0 0 13 12
0 1 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box2
2
122 0
125 0
4
0 0 13 12
0 2 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box3
2
122 0
125 0
4
0 0 13 12
0 3 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_11_6 loc_11_5 left box4
2
122 0
125 0
4
0 0 13 12
0 4 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_2_2 loc_2_3 loc_2_4 right box1
2
127 0
130 0
4
0 0 15 16
0 1 15 16
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_2 loc_2_3 loc_2_4 right box2
2
127 0
130 0
4
0 0 15 16
0 2 15 16
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_2 loc_2_3 loc_2_4 right box3
2
127 0
130 0
4
0 0 15 16
0 3 15 16
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_2 loc_2_3 loc_2_4 right box4
2
127 0
130 0
4
0 0 15 16
0 4 15 16
0 22 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_2_2 loc_3_2 loc_4_2 down box1
2
128 0
152 0
4
0 0 15 24
0 1 22 31
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_2 loc_3_2 loc_4_2 down box2
2
128 0
152 0
4
0 0 15 24
0 2 22 31
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_2 loc_3_2 loc_4_2 down box3
2
128 0
152 0
4
0 0 15 24
0 3 22 31
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_2 loc_3_2 loc_4_2 down box4
2
128 0
152 0
4
0 0 15 24
0 4 22 31
0 30 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_2_3 loc_2_4 loc_2_5 right box1
2
130 0
133 0
4
0 0 16 17
0 1 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_3 loc_2_4 loc_2_5 right box2
2
130 0
133 0
4
0 0 16 17
0 2 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_3 loc_2_4 loc_2_5 right box3
2
130 0
133 0
4
0 0 16 17
0 3 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_3 loc_2_4 loc_2_5 right box4
2
130 0
133 0
4
0 0 16 17
0 4 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box1
2
131 0
156 0
4
0 0 16 25
0 1 23 32
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box2
2
131 0
156 0
4
0 0 16 25
0 2 23 32
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box3
2
131 0
156 0
4
0 0 16 25
0 3 23 32
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_3 loc_3_3 loc_4_3 down box4
2
131 0
156 0
4
0 0 16 25
0 4 23 32
0 31 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_3 loc_2_2 left box1
2
129 0
132 0
4
0 0 17 16
0 1 15 14
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_3 loc_2_2 left box2
2
129 0
132 0
4
0 0 17 16
0 2 15 14
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_3 loc_2_2 left box3
2
129 0
132 0
4
0 0 17 16
0 3 15 14
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_3 loc_2_2 left box4
2
129 0
132 0
4
0 0 17 16
0 4 15 14
0 21 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box1
2
133 0
136 0
4
0 0 17 18
0 1 17 18
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box2
2
133 0
136 0
4
0 0 17 18
0 2 17 18
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box3
2
133 0
136 0
4
0 0 17 18
0 3 17 18
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_2_4 loc_2_5 loc_2_6 right box4
2
133 0
136 0
4
0 0 17 18
0 4 17 18
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box1
2
134 0
160 0
4
0 0 17 26
0 1 24 33
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box2
2
134 0
160 0
4
0 0 17 26
0 2 24 33
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box3
2
134 0
160 0
4
0 0 17 26
0 3 24 33
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_4 loc_3_4 loc_4_4 down box4
2
134 0
160 0
4
0 0 17 26
0 4 24 33
0 32 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_4 loc_2_3 left box1
2
132 0
135 0
4
0 0 18 17
0 1 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_5 loc_2_4 loc_2_3 left box2
2
132 0
135 0
4
0 0 18 17
0 2 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_5 loc_2_4 loc_2_3 left box3
2
132 0
135 0
4
0 0 18 17
0 3 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_5 loc_2_4 loc_2_3 left box4
2
132 0
135 0
4
0 0 18 17
0 4 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_2_5 loc_2_6 loc_2_7 right box1
2
136 0
139 0
4
0 0 18 19
0 1 18 19
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_6 loc_2_7 right box2
2
136 0
139 0
4
0 0 18 19
0 2 18 19
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_6 loc_2_7 right box3
2
136 0
139 0
4
0 0 18 19
0 3 18 19
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_2_5 loc_2_6 loc_2_7 right box4
2
136 0
139 0
4
0 0 18 19
0 4 18 19
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box1
2
137 0
164 0
4
0 0 18 27
0 1 25 34
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box2
2
137 0
164 0
4
0 0 18 27
0 2 25 34
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box3
2
137 0
164 0
4
0 0 18 27
0 3 25 34
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_5 loc_3_5 loc_4_5 down box4
2
137 0
164 0
4
0 0 18 27
0 4 25 34
0 33 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box1
2
135 0
138 0
4
0 0 19 18
0 1 17 16
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box2
2
135 0
138 0
4
0 0 19 18
0 2 17 16
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box3
2
135 0
138 0
4
0 0 19 18
0 3 17 16
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_5 loc_2_4 left box4
2
135 0
138 0
4
0 0 19 18
0 4 17 16
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_2_6 loc_2_7 loc_2_8 right box1
2
139 0
142 0
4
0 0 19 20
0 1 19 20
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_7 loc_2_8 right box2
2
139 0
142 0
4
0 0 19 20
0 2 19 20
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_7 loc_2_8 right box3
2
139 0
142 0
4
0 0 19 20
0 3 19 20
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_2_6 loc_2_7 loc_2_8 right box4
2
139 0
142 0
4
0 0 19 20
0 4 19 20
0 26 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box1
2
140 0
168 0
4
0 0 19 28
0 1 26 35
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box2
2
140 0
168 0
4
0 0 19 28
0 2 26 35
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box3
2
140 0
168 0
4
0 0 19 28
0 3 26 35
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_6 loc_3_6 loc_4_6 down box4
2
140 0
168 0
4
0 0 19 28
0 4 26 35
0 34 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_2_7 loc_2_6 loc_2_5 left box1
2
138 0
141 0
4
0 0 20 19
0 1 18 17
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_2_7 loc_2_6 loc_2_5 left box2
2
138 0
141 0
4
0 0 20 19
0 2 18 17
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_2_7 loc_2_6 loc_2_5 left box3
2
138 0
141 0
4
0 0 20 19
0 3 18 17
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_2_7 loc_2_6 loc_2_5 left box4
2
138 0
141 0
4
0 0 20 19
0 4 18 17
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box1
2
143 0
172 0
4
0 0 20 29
0 1 27 36
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box2
2
143 0
172 0
4
0 0 20 29
0 2 27 36
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box3
2
143 0
172 0
4
0 0 20 29
0 3 27 36
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_2_7 loc_3_7 loc_4_7 down box4
2
143 0
172 0
4
0 0 20 29
0 4 27 36
0 35 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_2_8 loc_2_7 loc_2_6 left box1
2
141 0
144 0
4
0 0 21 20
0 1 19 18
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_2_8 loc_2_7 loc_2_6 left box2
2
141 0
144 0
4
0 0 21 20
0 2 19 18
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_2_8 loc_2_7 loc_2_6 left box3
2
141 0
144 0
4
0 0 21 20
0 3 19 18
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_2_8 loc_2_7 loc_2_6 left box4
2
141 0
144 0
4
0 0 21 20
0 4 19 18
0 25 0 1
0 26 -1 0
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box1
2
145 0
175 0
4
0 0 21 30
0 1 28 37
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box2
2
145 0
175 0
4
0 0 21 30
0 2 28 37
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box3
2
145 0
175 0
4
0 0 21 30
0 3 28 37
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_2_8 loc_3_8 loc_4_8 down box4
2
145 0
175 0
4
0 0 21 30
0 4 28 37
0 36 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box1
2
149 0
181 0
4
0 0 23 32
0 1 30 39
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box2
2
149 0
181 0
4
0 0 23 32
0 2 30 39
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box3
2
149 0
181 0
4
0 0 23 32
0 3 30 39
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_11 loc_4_11 loc_5_11 down box4
2
149 0
181 0
4
0 0 23 32
0 4 30 39
0 38 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
151 0
155 0
4
0 0 24 25
0 1 23 24
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box2
2
151 0
155 0
4
0 0 24 25
0 2 23 24
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box3
2
151 0
155 0
4
0 0 24 25
0 3 23 24
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box4
2
151 0
155 0
4
0 0 24 25
0 4 23 24
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box1
2
152 0
184 0
4
0 0 24 33
0 1 31 40
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box2
2
152 0
184 0
4
0 0 24 33
0 2 31 40
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box3
2
152 0
184 0
4
0 0 24 33
0 3 31 40
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_2 loc_4_2 loc_5_2 down box4
2
152 0
184 0
4
0 0 24 33
0 4 31 40
0 39 -1 0
0 48 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
155 0
159 0
4
0 0 25 26
0 1 24 25
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
155 0
159 0
4
0 0 25 26
0 2 24 25
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
155 0
159 0
4
0 0 25 26
0 3 24 25
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box4
2
155 0
159 0
4
0 0 25 26
0 4 24 25
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box1
2
156 0
188 0
4
0 0 25 34
0 1 32 41
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box2
2
156 0
188 0
4
0 0 25 34
0 2 32 41
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box3
2
156 0
188 0
4
0 0 25 34
0 3 32 41
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_3 loc_4_3 loc_5_3 down box4
2
156 0
188 0
4
0 0 25 34
0 4 32 41
0 40 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
154 0
158 0
4
0 0 26 25
0 1 23 22
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box2
2
154 0
158 0
4
0 0 26 25
0 2 23 22
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box3
2
154 0
158 0
4
0 0 26 25
0 3 23 22
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box4
2
154 0
158 0
4
0 0 26 25
0 4 23 22
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
159 0
163 0
4
0 0 26 27
0 1 25 26
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
159 0
163 0
4
0 0 26 27
0 2 25 26
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
159 0
163 0
4
0 0 26 27
0 3 25 26
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box4
2
159 0
163 0
4
0 0 26 27
0 4 25 26
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box1
2
160 0
192 0
4
0 0 26 35
0 1 33 42
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box2
2
160 0
192 0
4
0 0 26 35
0 2 33 42
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box3
2
160 0
192 0
4
0 0 26 35
0 3 33 42
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_4 loc_4_4 loc_5_4 down box4
2
160 0
192 0
4
0 0 26 35
0 4 33 42
0 41 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
158 0
162 0
4
0 0 27 26
0 1 24 23
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
158 0
162 0
4
0 0 27 26
0 2 24 23
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
158 0
162 0
4
0 0 27 26
0 3 24 23
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box4
2
158 0
162 0
4
0 0 27 26
0 4 24 23
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box1
2
163 0
167 0
4
0 0 27 28
0 1 26 27
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box2
2
163 0
167 0
4
0 0 27 28
0 2 26 27
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box3
2
163 0
167 0
4
0 0 27 28
0 3 26 27
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_6 loc_3_7 right box4
2
163 0
167 0
4
0 0 27 28
0 4 26 27
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
164 0
196 0
4
0 0 27 36
0 1 34 43
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
164 0
196 0
4
0 0 27 36
0 2 34 43
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
164 0
196 0
4
0 0 27 36
0 3 34 43
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box4
2
164 0
196 0
4
0 0 27 36
0 4 34 43
0 42 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
162 0
166 0
4
0 0 28 27
0 1 25 24
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
162 0
166 0
4
0 0 28 27
0 2 25 24
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
162 0
166 0
4
0 0 28 27
0 3 25 24
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box4
2
162 0
166 0
4
0 0 28 27
0 4 25 24
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box1
2
167 0
171 0
4
0 0 28 29
0 1 27 28
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box2
2
167 0
171 0
4
0 0 28 29
0 2 27 28
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box3
2
167 0
171 0
4
0 0 28 29
0 3 27 28
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_7 loc_3_8 right box4
2
167 0
171 0
4
0 0 28 29
0 4 27 28
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
168 0
200 0
4
0 0 28 37
0 1 35 44
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
168 0
200 0
4
0 0 28 37
0 2 35 44
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
168 0
200 0
4
0 0 28 37
0 3 35 44
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box4
2
168 0
200 0
4
0 0 28 37
0 4 35 44
0 43 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box1
2
166 0
170 0
4
0 0 29 28
0 1 26 25
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box2
2
166 0
170 0
4
0 0 29 28
0 2 26 25
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box3
2
166 0
170 0
4
0 0 29 28
0 3 26 25
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_3_6 loc_3_5 left box4
2
166 0
170 0
4
0 0 29 28
0 4 26 25
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box1
2
172 0
204 0
4
0 0 29 38
0 1 36 45
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box2
2
172 0
204 0
4
0 0 29 38
0 2 36 45
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box3
2
172 0
204 0
4
0 0 29 38
0 3 36 45
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_3_7 loc_4_7 loc_5_7 down box4
2
172 0
204 0
4
0 0 29 38
0 4 36 45
0 44 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box1
2
170 0
174 0
4
0 0 30 29
0 1 27 26
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box2
2
170 0
174 0
4
0 0 30 29
0 2 27 26
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box3
2
170 0
174 0
4
0 0 30 29
0 3 27 26
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_3_7 loc_3_6 left box4
2
170 0
174 0
4
0 0 30 29
0 4 27 26
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box1
2
175 0
208 0
4
0 0 30 39
0 1 37 46
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box2
2
175 0
208 0
4
0 0 30 39
0 2 37 46
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box3
2
175 0
208 0
4
0 0 30 39
0 3 37 46
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_3_8 loc_4_8 loc_5_8 down box4
2
175 0
208 0
4
0 0 30 39
0 4 37 46
0 45 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box1
2
178 0
210 0
4
0 0 31 40
0 1 38 37
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box2
2
178 0
210 0
4
0 0 31 40
0 2 38 37
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box3
2
178 0
210 0
4
0 0 31 40
0 3 38 37
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box4
2
178 0
210 0
4
0 0 31 40
0 4 38 37
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box1
2
178 0
180 0
4
0 0 32 31
0 1 29 38
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box2
2
178 0
180 0
4
0 0 32 31
0 2 29 38
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box3
2
178 0
180 0
4
0 0 32 31
0 3 29 38
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_11 loc_4_10 loc_4_9 left box4
2
178 0
180 0
4
0 0 32 31
0 4 29 38
0 37 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box1
2
181 0
213 0
4
0 0 32 41
0 1 39 49
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box2
2
181 0
213 0
4
0 0 32 41
0 2 39 49
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box3
2
181 0
213 0
4
0 0 32 41
0 3 39 49
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_11 loc_5_11 loc_6_11 down box4
2
181 0
213 0
4
0 0 32 41
0 4 39 49
0 47 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box1
2
150 0
182 0
4
0 0 33 24
0 1 22 14
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box2
2
150 0
182 0
4
0 0 33 24
0 2 22 14
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box3
2
150 0
182 0
4
0 0 33 24
0 3 22 14
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_3_2 loc_2_2 up box4
2
150 0
182 0
4
0 0 33 24
0 4 22 14
0 21 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
183 0
187 0
4
0 0 33 34
0 1 32 33
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box2
2
183 0
187 0
4
0 0 33 34
0 2 32 33
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box3
2
183 0
187 0
4
0 0 33 34
0 3 32 33
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box4
2
183 0
187 0
4
0 0 33 34
0 4 32 33
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
184 0
216 0
4
0 0 33 42
0 1 40 50
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box2
2
184 0
216 0
4
0 0 33 42
0 2 40 50
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box3
2
184 0
216 0
4
0 0 33 42
0 3 40 50
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box4
2
184 0
216 0
4
0 0 33 42
0 4 40 50
0 48 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box1
2
153 0
185 0
4
0 0 34 25
0 1 23 15
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box2
2
153 0
185 0
4
0 0 34 25
0 2 23 15
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box3
2
153 0
185 0
4
0 0 34 25
0 3 23 15
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_3_3 loc_2_3 up box4
2
153 0
185 0
4
0 0 34 25
0 4 23 15
0 22 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
187 0
191 0
4
0 0 34 35
0 1 33 34
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
187 0
191 0
4
0 0 34 35
0 2 33 34
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
187 0
191 0
4
0 0 34 35
0 3 33 34
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box4
2
187 0
191 0
4
0 0 34 35
0 4 33 34
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box1
2
188 0
220 0
4
0 0 34 43
0 1 41 51
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box2
2
188 0
220 0
4
0 0 34 43
0 2 41 51
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box3
2
188 0
220 0
4
0 0 34 43
0 3 41 51
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box4
2
188 0
220 0
4
0 0 34 43
0 4 41 51
0 49 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box1
2
157 0
189 0
4
0 0 35 26
0 1 24 16
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box2
2
157 0
189 0
4
0 0 35 26
0 2 24 16
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box3
2
157 0
189 0
4
0 0 35 26
0 3 24 16
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_3_4 loc_2_4 up box4
2
157 0
189 0
4
0 0 35 26
0 4 24 16
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
186 0
190 0
4
0 0 35 34
0 1 32 31
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box2
2
186 0
190 0
4
0 0 35 34
0 2 32 31
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box3
2
186 0
190 0
4
0 0 35 34
0 3 32 31
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box4
2
186 0
190 0
4
0 0 35 34
0 4 32 31
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
191 0
195 0
4
0 0 35 36
0 1 34 35
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
191 0
195 0
4
0 0 35 36
0 2 34 35
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
191 0
195 0
4
0 0 35 36
0 3 34 35
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box4
2
191 0
195 0
4
0 0 35 36
0 4 34 35
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box1
2
192 0
224 0
4
0 0 35 44
0 1 42 52
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box2
2
192 0
224 0
4
0 0 35 44
0 2 42 52
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box3
2
192 0
224 0
4
0 0 35 44
0 3 42 52
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_4_4 loc_5_4 loc_6_4 down box4
2
192 0
224 0
4
0 0 35 44
0 4 42 52
0 50 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
161 0
193 0
4
0 0 36 27
0 1 25 17
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box2
2
161 0
193 0
4
0 0 36 27
0 2 25 17
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box3
2
161 0
193 0
4
0 0 36 27
0 3 25 17
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box4
2
161 0
193 0
4
0 0 36 27
0 4 25 17
0 24 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
190 0
194 0
4
0 0 36 35
0 1 33 32
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
190 0
194 0
4
0 0 36 35
0 2 33 32
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
190 0
194 0
4
0 0 36 35
0 3 33 32
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box4
2
190 0
194 0
4
0 0 36 35
0 4 33 32
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
195 0
199 0
4
0 0 36 37
0 1 35 36
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
195 0
199 0
4
0 0 36 37
0 2 35 36
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
195 0
199 0
4
0 0 36 37
0 3 35 36
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box4
2
195 0
199 0
4
0 0 36 37
0 4 35 36
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
196 0
228 0
4
0 0 36 45
0 1 43 53
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box2
2
196 0
228 0
4
0 0 36 45
0 2 43 53
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box3
2
196 0
228 0
4
0 0 36 45
0 3 43 53
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box4
2
196 0
228 0
4
0 0 36 45
0 4 43 53
0 51 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box1
2
165 0
197 0
4
0 0 37 28
0 1 26 18
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box2
2
165 0
197 0
4
0 0 37 28
0 2 26 18
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box3
2
165 0
197 0
4
0 0 37 28
0 3 26 18
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_3_6 loc_2_6 up box4
2
165 0
197 0
4
0 0 37 28
0 4 26 18
0 25 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
194 0
198 0
4
0 0 37 36
0 1 34 33
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
194 0
198 0
4
0 0 37 36
0 2 34 33
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
194 0
198 0
4
0 0 37 36
0 3 34 33
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box4
2
194 0
198 0
4
0 0 37 36
0 4 34 33
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
199 0
203 0
4
0 0 37 38
0 1 36 37
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box2
2
199 0
203 0
4
0 0 37 38
0 2 36 37
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box3
2
199 0
203 0
4
0 0 37 38
0 3 36 37
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box4
2
199 0
203 0
4
0 0 37 38
0 4 36 37
0 44 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
200 0
232 0
4
0 0 37 46
0 1 44 54
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
200 0
232 0
4
0 0 37 46
0 2 44 54
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
200 0
232 0
4
0 0 37 46
0 3 44 54
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box4
2
200 0
232 0
4
0 0 37 46
0 4 44 54
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box1
2
169 0
201 0
4
0 0 38 29
0 1 27 19
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box2
2
169 0
201 0
4
0 0 38 29
0 2 27 19
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box3
2
169 0
201 0
4
0 0 38 29
0 3 27 19
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_3_7 loc_2_7 up box4
2
169 0
201 0
4
0 0 38 29
0 4 27 19
0 26 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
198 0
202 0
4
0 0 38 37
0 1 35 34
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
198 0
202 0
4
0 0 38 37
0 2 35 34
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
198 0
202 0
4
0 0 38 37
0 3 35 34
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box4
2
198 0
202 0
4
0 0 38 37
0 4 35 34
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
203 0
207 0
4
0 0 38 39
0 1 37 38
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box2
2
203 0
207 0
4
0 0 38 39
0 2 37 38
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box3
2
203 0
207 0
4
0 0 38 39
0 3 37 38
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box4
2
203 0
207 0
4
0 0 38 39
0 4 37 38
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
204 0
236 0
4
0 0 38 47
0 1 45 55
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
204 0
236 0
4
0 0 38 47
0 2 45 55
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
204 0
236 0
4
0 0 38 47
0 3 45 55
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box4
2
204 0
236 0
4
0 0 38 47
0 4 45 55
0 53 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box1
2
173 0
205 0
4
0 0 39 30
0 1 28 20
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box2
2
173 0
205 0
4
0 0 39 30
0 2 28 20
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box3
2
173 0
205 0
4
0 0 39 30
0 3 28 20
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_3_8 loc_2_8 up box4
2
173 0
205 0
4
0 0 39 30
0 4 28 20
0 27 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
202 0
206 0
4
0 0 39 38
0 1 36 35
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box2
2
202 0
206 0
4
0 0 39 38
0 2 36 35
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box3
2
202 0
206 0
4
0 0 39 38
0 3 36 35
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box4
2
202 0
206 0
4
0 0 39 38
0 4 36 35
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box1
2
207 0
209 0
4
0 0 39 40
0 1 38 29
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box2
2
207 0
209 0
4
0 0 39 40
0 2 38 29
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box3
2
207 0
209 0
4
0 0 39 40
0 3 38 29
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box4
2
207 0
209 0
4
0 0 39 40
0 4 38 29
0 37 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box1
2
208 0
240 0
4
0 0 39 48
0 1 46 56
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box2
2
208 0
240 0
4
0 0 39 48
0 2 46 56
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box3
2
208 0
240 0
4
0 0 39 48
0 3 46 56
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box4
2
208 0
240 0
4
0 0 39 48
0 4 46 56
0 54 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box1
2
177 0
209 0
4
0 0 40 31
0 1 29 30
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box2
2
177 0
209 0
4
0 0 40 31
0 2 29 30
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box3
2
177 0
209 0
4
0 0 40 31
0 3 29 30
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_10 loc_4_11 right box4
2
177 0
209 0
4
0 0 40 31
0 4 29 30
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box1
2
206 0
210 0
4
0 0 40 39
0 1 37 36
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box2
2
206 0
210 0
4
0 0 40 39
0 2 37 36
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box3
2
206 0
210 0
4
0 0 40 39
0 3 37 36
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box4
2
206 0
210 0
4
0 0 40 39
0 4 37 36
0 44 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box1
2
211 0
243 0
4
0 0 40 49
0 1 47 57
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box2
2
211 0
243 0
4
0 0 40 49
0 2 47 57
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box3
2
211 0
243 0
4
0 0 40 49
0 3 47 57
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_4_9 loc_5_9 loc_6_9 down box4
2
211 0
243 0
4
0 0 40 49
0 4 47 57
0 55 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box1
2
179 0
212 0
4
0 0 41 32
0 1 30 21
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box2
2
179 0
212 0
4
0 0 41 32
0 2 30 21
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box3
2
179 0
212 0
4
0 0 41 32
0 3 30 21
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_4_11 loc_3_11 up box4
2
179 0
212 0
4
0 0 41 32
0 4 30 21
0 29 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box1
2
213 0
248 0
4
0 0 41 51
0 1 49 58
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box2
2
213 0
248 0
4
0 0 41 51
0 2 49 58
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box3
2
213 0
248 0
4
0 0 41 51
0 3 49 58
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box4
2
213 0
248 0
4
0 0 41 51
0 4 49 58
0 57 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box1
2
182 0
214 0
4
0 0 42 33
0 1 31 22
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box2
2
182 0
214 0
4
0 0 42 33
0 2 31 22
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box3
2
182 0
214 0
4
0 0 42 33
0 3 31 22
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_4_2 loc_3_2 up box4
2
182 0
214 0
4
0 0 42 33
0 4 31 22
0 30 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
215 0
219 0
4
0 0 42 43
0 1 41 42
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box2
2
215 0
219 0
4
0 0 42 43
0 2 41 42
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box3
2
215 0
219 0
4
0 0 42 43
0 3 41 42
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box4
2
215 0
219 0
4
0 0 42 43
0 4 41 42
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box1
2
216 0
251 0
4
0 0 42 52
0 1 50 59
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box2
2
216 0
251 0
4
0 0 42 52
0 2 50 59
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box3
2
216 0
251 0
4
0 0 42 52
0 3 50 59
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_2 loc_6_2 loc_7_2 down box4
2
216 0
251 0
4
0 0 42 52
0 4 50 59
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box1
2
185 0
217 0
4
0 0 43 34
0 1 32 23
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box2
2
185 0
217 0
4
0 0 43 34
0 2 32 23
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box3
2
185 0
217 0
4
0 0 43 34
0 3 32 23
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_4_3 loc_3_3 up box4
2
185 0
217 0
4
0 0 43 34
0 4 32 23
0 31 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
219 0
223 0
4
0 0 43 44
0 1 42 43
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box2
2
219 0
223 0
4
0 0 43 44
0 2 42 43
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box3
2
219 0
223 0
4
0 0 43 44
0 3 42 43
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box4
2
219 0
223 0
4
0 0 43 44
0 4 42 43
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box1
2
220 0
255 0
4
0 0 43 53
0 1 51 60
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box2
2
220 0
255 0
4
0 0 43 53
0 2 51 60
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box3
2
220 0
255 0
4
0 0 43 53
0 3 51 60
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box4
2
220 0
255 0
4
0 0 43 53
0 4 51 60
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box1
2
189 0
221 0
4
0 0 44 35
0 1 33 24
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box2
2
189 0
221 0
4
0 0 44 35
0 2 33 24
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box3
2
189 0
221 0
4
0 0 44 35
0 3 33 24
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_4_4 loc_3_4 up box4
2
189 0
221 0
4
0 0 44 35
0 4 33 24
0 32 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
218 0
222 0
4
0 0 44 43
0 1 41 40
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
218 0
222 0
4
0 0 44 43
0 2 41 40
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
218 0
222 0
4
0 0 44 43
0 3 41 40
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
218 0
222 0
4
0 0 44 43
0 4 41 40
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
223 0
227 0
4
0 0 44 45
0 1 43 44
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
223 0
227 0
4
0 0 44 45
0 2 43 44
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
223 0
227 0
4
0 0 44 45
0 3 43 44
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box4
2
223 0
227 0
4
0 0 44 45
0 4 43 44
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box1
2
224 0
259 0
4
0 0 44 54
0 1 52 61
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box2
2
224 0
259 0
4
0 0 44 54
0 2 52 61
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box3
2
224 0
259 0
4
0 0 44 54
0 3 52 61
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_4 loc_6_4 loc_7_4 down box4
2
224 0
259 0
4
0 0 44 54
0 4 52 61
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
193 0
225 0
4
0 0 45 36
0 1 34 25
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
193 0
225 0
4
0 0 45 36
0 2 34 25
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
193 0
225 0
4
0 0 45 36
0 3 34 25
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box4
2
193 0
225 0
4
0 0 45 36
0 4 34 25
0 33 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
222 0
226 0
4
0 0 45 44
0 1 42 41
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
222 0
226 0
4
0 0 45 44
0 2 42 41
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
222 0
226 0
4
0 0 45 44
0 3 42 41
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box4
2
222 0
226 0
4
0 0 45 44
0 4 42 41
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
227 0
231 0
4
0 0 45 46
0 1 44 45
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
227 0
231 0
4
0 0 45 46
0 2 44 45
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
227 0
231 0
4
0 0 45 46
0 3 44 45
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box4
2
227 0
231 0
4
0 0 45 46
0 4 44 45
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
228 0
263 0
4
0 0 45 55
0 1 53 62
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box2
2
228 0
263 0
4
0 0 45 55
0 2 53 62
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box3
2
228 0
263 0
4
0 0 45 55
0 3 53 62
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box4
2
228 0
263 0
4
0 0 45 55
0 4 53 62
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
197 0
229 0
4
0 0 46 37
0 1 35 26
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
197 0
229 0
4
0 0 46 37
0 2 35 26
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
197 0
229 0
4
0 0 46 37
0 3 35 26
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box4
2
197 0
229 0
4
0 0 46 37
0 4 35 26
0 34 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
226 0
230 0
4
0 0 46 45
0 1 43 42
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
226 0
230 0
4
0 0 46 45
0 2 43 42
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
226 0
230 0
4
0 0 46 45
0 3 43 42
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box4
2
226 0
230 0
4
0 0 46 45
0 4 43 42
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
231 0
235 0
4
0 0 46 47
0 1 45 46
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
231 0
235 0
4
0 0 46 47
0 2 45 46
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
231 0
235 0
4
0 0 46 47
0 3 45 46
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box4
2
231 0
235 0
4
0 0 46 47
0 4 45 46
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box1
2
232 0
267 0
4
0 0 46 56
0 1 54 63
0 62 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box2
2
232 0
267 0
4
0 0 46 56
0 2 54 63
0 62 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box3
2
232 0
267 0
4
0 0 46 56
0 3 54 63
0 62 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_6 loc_6_6 loc_7_6 down box4
2
232 0
267 0
4
0 0 46 56
0 4 54 63
0 62 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
201 0
233 0
4
0 0 47 38
0 1 36 27
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
201 0
233 0
4
0 0 47 38
0 2 36 27
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
201 0
233 0
4
0 0 47 38
0 3 36 27
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box4
2
201 0
233 0
4
0 0 47 38
0 4 36 27
0 35 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
230 0
234 0
4
0 0 47 46
0 1 44 43
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
230 0
234 0
4
0 0 47 46
0 2 44 43
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
230 0
234 0
4
0 0 47 46
0 3 44 43
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box4
2
230 0
234 0
4
0 0 47 46
0 4 44 43
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
235 0
239 0
4
0 0 47 48
0 1 46 47
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
235 0
239 0
4
0 0 47 48
0 2 46 47
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
235 0
239 0
4
0 0 47 48
0 3 46 47
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box4
2
235 0
239 0
4
0 0 47 48
0 4 46 47
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
236 0
271 0
4
0 0 47 57
0 1 55 64
0 63 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
236 0
271 0
4
0 0 47 57
0 2 55 64
0 63 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
236 0
271 0
4
0 0 47 57
0 3 55 64
0 63 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box4
2
236 0
271 0
4
0 0 47 57
0 4 55 64
0 63 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box1
2
205 0
237 0
4
0 0 48 39
0 1 37 28
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box2
2
205 0
237 0
4
0 0 48 39
0 2 37 28
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box3
2
205 0
237 0
4
0 0 48 39
0 3 37 28
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_4_8 loc_3_8 up box4
2
205 0
237 0
4
0 0 48 39
0 4 37 28
0 36 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
234 0
238 0
4
0 0 48 47
0 1 45 44
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
234 0
238 0
4
0 0 48 47
0 2 45 44
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
234 0
238 0
4
0 0 48 47
0 3 45 44
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box4
2
234 0
238 0
4
0 0 48 47
0 4 45 44
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box1
2
240 0
275 0
4
0 0 48 58
0 1 56 65
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box2
2
240 0
275 0
4
0 0 48 58
0 2 56 65
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box3
2
240 0
275 0
4
0 0 48 58
0 3 56 65
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_8 loc_6_8 loc_7_8 down box4
2
240 0
275 0
4
0 0 48 58
0 4 56 65
0 64 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
238 0
242 0
4
0 0 49 48
0 1 46 45
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
238 0
242 0
4
0 0 49 48
0 2 46 45
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
238 0
242 0
4
0 0 49 48
0 3 46 45
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box4
2
238 0
242 0
4
0 0 49 48
0 4 46 45
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box1
2
245 0
278 0
4
0 0 50 59
0 1 57 56
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box2
2
245 0
278 0
4
0 0 50 59
0 2 57 56
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box3
2
245 0
278 0
4
0 0 50 59
0 3 57 56
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_6_9 loc_6_8 left box4
2
245 0
278 0
4
0 0 50 59
0 4 57 56
0 64 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box1
2
212 0
246 0
4
0 0 51 41
0 1 39 30
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box2
2
212 0
246 0
4
0 0 51 41
0 2 39 30
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box3
2
212 0
246 0
4
0 0 51 41
0 3 39 30
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_5_11 loc_4_11 up box4
2
212 0
246 0
4
0 0 51 41
0 4 39 30
0 38 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box1
2
245 0
247 0
4
0 0 51 50
0 1 48 57
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box2
2
245 0
247 0
4
0 0 51 50
0 2 48 57
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box3
2
245 0
247 0
4
0 0 51 50
0 3 48 57
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_11 loc_6_10 loc_6_9 left box4
2
245 0
247 0
4
0 0 51 50
0 4 48 57
0 56 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box1
2
248 0
280 0
4
0 0 51 60
0 1 58 67
0 66 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box2
2
248 0
280 0
4
0 0 51 60
0 2 58 67
0 66 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box3
2
248 0
280 0
4
0 0 51 60
0 3 58 67
0 66 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box4
2
248 0
280 0
4
0 0 51 60
0 4 58 67
0 66 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box1
2
214 0
249 0
4
0 0 52 42
0 1 40 31
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box2
2
214 0
249 0
4
0 0 52 42
0 2 40 31
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box3
2
214 0
249 0
4
0 0 52 42
0 3 40 31
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box4
2
214 0
249 0
4
0 0 52 42
0 4 40 31
0 39 0 1
0 48 -1 0
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box1
2
250 0
254 0
4
0 0 52 53
0 1 51 52
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box2
2
250 0
254 0
4
0 0 52 53
0 2 51 52
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box3
2
250 0
254 0
4
0 0 52 53
0 3 51 52
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_6_2 loc_6_3 loc_6_4 right box4
2
250 0
254 0
4
0 0 52 53
0 4 51 52
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box1
2
251 0
283 0
4
0 0 52 61
0 1 59 68
0 67 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box2
2
251 0
283 0
4
0 0 52 61
0 2 59 68
0 67 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box3
2
251 0
283 0
4
0 0 52 61
0 3 59 68
0 67 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_6_2 loc_7_2 loc_8_2 down box4
2
251 0
283 0
4
0 0 52 61
0 4 59 68
0 67 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box1
2
217 0
252 0
4
0 0 53 43
0 1 41 32
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box2
2
217 0
252 0
4
0 0 53 43
0 2 41 32
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box3
2
217 0
252 0
4
0 0 53 43
0 3 41 32
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box4
2
217 0
252 0
4
0 0 53 43
0 4 41 32
0 40 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box1
2
254 0
258 0
4
0 0 53 54
0 1 52 53
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box2
2
254 0
258 0
4
0 0 53 54
0 2 52 53
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box3
2
254 0
258 0
4
0 0 53 54
0 3 52 53
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_6_3 loc_6_4 loc_6_5 right box4
2
254 0
258 0
4
0 0 53 54
0 4 52 53
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box1
2
221 0
256 0
4
0 0 54 44
0 1 42 33
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box2
2
221 0
256 0
4
0 0 54 44
0 2 42 33
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box3
2
221 0
256 0
4
0 0 54 44
0 3 42 33
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_5_4 loc_4_4 up box4
2
221 0
256 0
4
0 0 54 44
0 4 42 33
0 41 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box1
2
253 0
257 0
4
0 0 54 53
0 1 51 50
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box2
2
253 0
257 0
4
0 0 54 53
0 2 51 50
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box3
2
253 0
257 0
4
0 0 54 53
0 3 51 50
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_3 loc_6_2 left box4
2
253 0
257 0
4
0 0 54 53
0 4 51 50
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box1
2
258 0
262 0
4
0 0 54 55
0 1 53 54
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box2
2
258 0
262 0
4
0 0 54 55
0 2 53 54
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box3
2
258 0
262 0
4
0 0 54 55
0 3 53 54
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_6_4 loc_6_5 loc_6_6 right box4
2
258 0
262 0
4
0 0 54 55
0 4 53 54
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
225 0
260 0
4
0 0 55 45
0 1 43 34
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box2
2
225 0
260 0
4
0 0 55 45
0 2 43 34
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box3
2
225 0
260 0
4
0 0 55 45
0 3 43 34
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box4
2
225 0
260 0
4
0 0 55 45
0 4 43 34
0 42 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box1
2
257 0
261 0
4
0 0 55 54
0 1 52 51
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box2
2
257 0
261 0
4
0 0 55 54
0 2 52 51
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box3
2
257 0
261 0
4
0 0 55 54
0 3 52 51
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_4 loc_6_3 left box4
2
257 0
261 0
4
0 0 55 54
0 4 52 51
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
262 0
266 0
4
0 0 55 56
0 1 54 55
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
262 0
266 0
4
0 0 55 56
0 2 54 55
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
262 0
266 0
4
0 0 55 56
0 3 54 55
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box4
2
262 0
266 0
4
0 0 55 56
0 4 54 55
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box1
2
263 0
293 0
4
0 0 55 64
0 1 62 69
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box2
2
263 0
293 0
4
0 0 55 64
0 2 62 69
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box3
2
263 0
293 0
4
0 0 55 64
0 3 62 69
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box4
2
263 0
293 0
4
0 0 55 64
0 4 62 69
0 70 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
229 0
264 0
4
0 0 56 46
0 1 44 35
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
229 0
264 0
4
0 0 56 46
0 2 44 35
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
229 0
264 0
4
0 0 56 46
0 3 44 35
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box4
2
229 0
264 0
4
0 0 56 46
0 4 44 35
0 43 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box1
2
261 0
265 0
4
0 0 56 55
0 1 53 52
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box2
2
261 0
265 0
4
0 0 56 55
0 2 53 52
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box3
2
261 0
265 0
4
0 0 56 55
0 3 53 52
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_5 loc_6_4 left box4
2
261 0
265 0
4
0 0 56 55
0 4 53 52
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
266 0
270 0
4
0 0 56 57
0 1 55 56
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
266 0
270 0
4
0 0 56 57
0 2 55 56
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
266 0
270 0
4
0 0 56 57
0 3 55 56
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box4
2
266 0
270 0
4
0 0 56 57
0 4 55 56
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box1
2
267 0
297 0
4
0 0 56 65
0 1 63 70
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box2
2
267 0
297 0
4
0 0 56 65
0 2 63 70
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box3
2
267 0
297 0
4
0 0 56 65
0 3 63 70
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_6_6 loc_7_6 loc_8_6 down box4
2
267 0
297 0
4
0 0 56 65
0 4 63 70
0 71 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
233 0
268 0
4
0 0 57 47
0 1 45 36
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
233 0
268 0
4
0 0 57 47
0 2 45 36
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
233 0
268 0
4
0 0 57 47
0 3 45 36
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box4
2
233 0
268 0
4
0 0 57 47
0 4 45 36
0 44 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
265 0
269 0
4
0 0 57 56
0 1 54 53
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
265 0
269 0
4
0 0 57 56
0 2 54 53
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
265 0
269 0
4
0 0 57 56
0 3 54 53
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box4
2
265 0
269 0
4
0 0 57 56
0 4 54 53
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box1
2
270 0
274 0
4
0 0 57 58
0 1 56 57
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box2
2
270 0
274 0
4
0 0 57 58
0 2 56 57
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box3
2
270 0
274 0
4
0 0 57 58
0 3 56 57
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_8 loc_6_9 right box4
2
270 0
274 0
4
0 0 57 58
0 4 56 57
0 64 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
271 0
301 0
4
0 0 57 66
0 1 64 71
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
271 0
301 0
4
0 0 57 66
0 2 64 71
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
271 0
301 0
4
0 0 57 66
0 3 64 71
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box4
2
271 0
301 0
4
0 0 57 66
0 4 64 71
0 72 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box1
2
237 0
272 0
4
0 0 58 48
0 1 46 37
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box2
2
237 0
272 0
4
0 0 58 48
0 2 46 37
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box3
2
237 0
272 0
4
0 0 58 48
0 3 46 37
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box4
2
237 0
272 0
4
0 0 58 48
0 4 46 37
0 45 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
269 0
273 0
4
0 0 58 57
0 1 55 54
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
269 0
273 0
4
0 0 58 57
0 2 55 54
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
269 0
273 0
4
0 0 58 57
0 3 55 54
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box4
2
269 0
273 0
4
0 0 58 57
0 4 55 54
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box1
2
274 0
277 0
4
0 0 58 59
0 1 57 48
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box2
2
274 0
277 0
4
0 0 58 59
0 2 57 48
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box3
2
274 0
277 0
4
0 0 58 59
0 3 57 48
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_9 loc_6_10 right box4
2
274 0
277 0
4
0 0 58 59
0 4 57 48
0 56 0 1
0 65 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box1
2
275 0
304 0
4
0 0 58 67
0 1 65 72
0 73 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box2
2
275 0
304 0
4
0 0 58 67
0 2 65 72
0 73 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box3
2
275 0
304 0
4
0 0 58 67
0 3 65 72
0 73 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_8 loc_7_8 loc_8_8 down box4
2
275 0
304 0
4
0 0 58 67
0 4 65 72
0 73 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box1
2
241 0
276 0
4
0 0 59 49
0 1 47 38
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box2
2
241 0
276 0
4
0 0 59 49
0 2 47 38
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box3
2
241 0
276 0
4
0 0 59 49
0 3 47 38
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_5_9 loc_4_9 up box4
2
241 0
276 0
4
0 0 59 49
0 4 47 38
0 46 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box1
2
244 0
277 0
4
0 0 59 50
0 1 48 49
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box2
2
244 0
277 0
4
0 0 59 50
0 2 48 49
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box3
2
244 0
277 0
4
0 0 59 50
0 3 48 49
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_10 loc_6_11 right box4
2
244 0
277 0
4
0 0 59 50
0 4 48 49
0 56 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box1
2
273 0
278 0
4
0 0 59 58
0 1 56 55
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box2
2
273 0
278 0
4
0 0 59 58
0 2 56 55
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box3
2
273 0
278 0
4
0 0 59 58
0 3 56 55
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_6_9 loc_6_8 loc_6_7 left box4
2
273 0
278 0
4
0 0 59 58
0 4 56 55
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box1
2
246 0
279 0
4
0 0 60 51
0 1 49 39
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box2
2
246 0
279 0
4
0 0 60 51
0 2 49 39
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box3
2
246 0
279 0
4
0 0 60 51
0 3 49 39
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box4
2
246 0
279 0
4
0 0 60 51
0 4 49 39
0 47 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
280 0
310 0
4
0 0 60 69
0 1 67 74
0 75 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
280 0
310 0
4
0 0 60 69
0 2 67 74
0 75 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
280 0
310 0
4
0 0 60 69
0 3 67 74
0 75 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
280 0
310 0
4
0 0 60 69
0 4 67 74
0 75 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box1
2
249 0
281 0
4
0 0 61 52
0 1 50 40
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box2
2
249 0
281 0
4
0 0 61 52
0 2 50 40
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box3
2
249 0
281 0
4
0 0 61 52
0 3 50 40
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_6_2 loc_5_2 up box4
2
249 0
281 0
4
0 0 61 52
0 4 50 40
0 48 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box1
2
282 0
286 0
4
0 0 61 62
0 1 60 61
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box2
2
282 0
286 0
4
0 0 61 62
0 2 60 61
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box3
2
282 0
286 0
4
0 0 61 62
0 3 60 61
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_7_2 loc_7_3 loc_7_4 right box4
2
282 0
286 0
4
0 0 61 62
0 4 60 61
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box1
2
252 0
284 0
4
0 0 62 53
0 1 51 41
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box2
2
252 0
284 0
4
0 0 62 53
0 2 51 41
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box3
2
252 0
284 0
4
0 0 62 53
0 3 51 41
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box4
2
252 0
284 0
4
0 0 62 53
0 4 51 41
0 49 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
286 0
289 0
4
0 0 62 63
0 1 61 62
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box2
2
286 0
289 0
4
0 0 62 63
0 2 61 62
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box3
2
286 0
289 0
4
0 0 62 63
0 3 61 62
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box4
2
286 0
289 0
4
0 0 62 63
0 4 61 62
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box1
2
256 0
287 0
4
0 0 63 54
0 1 52 42
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box2
2
256 0
287 0
4
0 0 63 54
0 2 52 42
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box3
2
256 0
287 0
4
0 0 63 54
0 3 52 42
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_6_4 loc_5_4 up box4
2
256 0
287 0
4
0 0 63 54
0 4 52 42
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box1
2
285 0
288 0
4
0 0 63 62
0 1 60 59
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box2
2
285 0
288 0
4
0 0 63 62
0 2 60 59
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box3
2
285 0
288 0
4
0 0 63 62
0 3 60 59
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_3 loc_7_2 left box4
2
285 0
288 0
4
0 0 63 62
0 4 60 59
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box1
2
289 0
292 0
4
0 0 63 64
0 1 62 63
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box2
2
289 0
292 0
4
0 0 63 64
0 2 62 63
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box3
2
289 0
292 0
4
0 0 63 64
0 3 62 63
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_4 loc_7_5 loc_7_6 right box4
2
289 0
292 0
4
0 0 63 64
0 4 62 63
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
260 0
290 0
4
0 0 64 55
0 1 53 43
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box2
2
260 0
290 0
4
0 0 64 55
0 2 53 43
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box3
2
260 0
290 0
4
0 0 64 55
0 3 53 43
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box4
2
260 0
290 0
4
0 0 64 55
0 4 53 43
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box1
2
288 0
291 0
4
0 0 64 63
0 1 61 60
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box2
2
288 0
291 0
4
0 0 64 63
0 2 61 60
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box3
2
288 0
291 0
4
0 0 64 63
0 3 61 60
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box4
2
288 0
291 0
4
0 0 64 63
0 4 61 60
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box1
2
292 0
296 0
4
0 0 64 65
0 1 63 64
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box2
2
292 0
296 0
4
0 0 64 65
0 2 63 64
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box3
2
292 0
296 0
4
0 0 64 65
0 3 63 64
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_5 loc_7_6 loc_7_7 right box4
2
292 0
296 0
4
0 0 64 65
0 4 63 64
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box1
2
293 0
314 0
4
0 0 64 71
0 1 69 77
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box2
2
293 0
314 0
4
0 0 64 71
0 2 69 77
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box3
2
293 0
314 0
4
0 0 64 71
0 3 69 77
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box4
2
293 0
314 0
4
0 0 64 71
0 4 69 77
0 77 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box1
2
264 0
294 0
4
0 0 65 56
0 1 54 44
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box2
2
264 0
294 0
4
0 0 65 56
0 2 54 44
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box3
2
264 0
294 0
4
0 0 65 56
0 3 54 44
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_6_6 loc_5_6 up box4
2
264 0
294 0
4
0 0 65 56
0 4 54 44
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box1
2
291 0
295 0
4
0 0 65 64
0 1 62 61
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box2
2
291 0
295 0
4
0 0 65 64
0 2 62 61
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box3
2
291 0
295 0
4
0 0 65 64
0 3 62 61
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_5 loc_7_4 left box4
2
291 0
295 0
4
0 0 65 64
0 4 62 61
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box1
2
296 0
300 0
4
0 0 65 66
0 1 64 65
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box2
2
296 0
300 0
4
0 0 65 66
0 2 64 65
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box3
2
296 0
300 0
4
0 0 65 66
0 3 64 65
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_6 loc_7_7 loc_7_8 right box4
2
296 0
300 0
4
0 0 65 66
0 4 64 65
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
268 0
298 0
4
0 0 66 57
0 1 55 45
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
268 0
298 0
4
0 0 66 57
0 2 55 45
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
268 0
298 0
4
0 0 66 57
0 3 55 45
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box4
2
268 0
298 0
4
0 0 66 57
0 4 55 45
0 53 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box1
2
295 0
299 0
4
0 0 66 65
0 1 63 62
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box2
2
295 0
299 0
4
0 0 66 65
0 2 63 62
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box3
2
295 0
299 0
4
0 0 66 65
0 3 63 62
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_6 loc_7_5 left box4
2
295 0
299 0
4
0 0 66 65
0 4 63 62
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box1
2
272 0
302 0
4
0 0 67 58
0 1 56 46
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box2
2
272 0
302 0
4
0 0 67 58
0 2 56 46
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box3
2
272 0
302 0
4
0 0 67 58
0 3 56 46
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_6_8 loc_5_8 up box4
2
272 0
302 0
4
0 0 67 58
0 4 56 46
0 54 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box1
2
299 0
303 0
4
0 0 67 66
0 1 64 63
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box2
2
299 0
303 0
4
0 0 67 66
0 2 64 63
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box3
2
299 0
303 0
4
0 0 67 66
0 3 64 63
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_7 loc_7_6 left box4
2
299 0
303 0
4
0 0 67 66
0 4 64 63
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
306 0
325 0
4
0 0 68 75
0 1 73 72
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
306 0
325 0
4
0 0 68 75
0 2 73 72
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box3
2
306 0
325 0
4
0 0 68 75
0 3 73 72
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box4
2
306 0
325 0
4
0 0 68 75
0 4 73 72
0 80 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
279 0
308 0
4
0 0 69 60
0 1 58 49
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
279 0
308 0
4
0 0 69 60
0 2 58 49
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
279 0
308 0
4
0 0 69 60
0 3 58 49
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box4
2
279 0
308 0
4
0 0 69 60
0 4 58 49
0 57 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
306 0
309 0
4
0 0 69 68
0 1 66 73
0 74 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
306 0
309 0
4
0 0 69 68
0 2 66 73
0 74 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
306 0
309 0
4
0 0 69 68
0 3 66 73
0 74 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
306 0
309 0
4
0 0 69 68
0 4 66 73
0 74 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box1
2
290 0
312 0
4
0 0 71 64
0 1 62 53
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box2
2
290 0
312 0
4
0 0 71 64
0 2 62 53
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box3
2
290 0
312 0
4
0 0 71 64
0 3 62 53
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box4
2
290 0
312 0
4
0 0 71 64
0 4 62 53
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
313 0
317 0
4
0 0 71 72
0 1 70 71
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
313 0
317 0
4
0 0 71 72
0 2 70 71
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
313 0
317 0
4
0 0 71 72
0 3 70 71
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box4
2
313 0
317 0
4
0 0 71 72
0 4 70 71
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box1
2
314 0
338 0
4
0 0 71 80
0 1 77 4
0 9 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box2
2
314 0
338 0
4
0 0 71 80
0 2 77 4
0 9 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box3
2
314 0
338 0
4
0 0 71 80
0 3 77 4
0 9 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box4
2
314 0
338 0
4
0 0 71 80
0 4 77 4
0 9 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box1
2
294 0
315 0
4
0 0 72 65
0 1 63 54
0 62 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box2
2
294 0
315 0
4
0 0 72 65
0 2 63 54
0 62 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box3
2
294 0
315 0
4
0 0 72 65
0 3 63 54
0 62 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_7_6 loc_6_6 up box4
2
294 0
315 0
4
0 0 72 65
0 4 63 54
0 62 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box1
2
317 0
320 0
4
0 0 72 73
0 1 71 72
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box2
2
317 0
320 0
4
0 0 72 73
0 2 71 72
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box3
2
317 0
320 0
4
0 0 72 73
0 3 71 72
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box4
2
317 0
320 0
4
0 0 72 73
0 4 71 72
0 79 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
298 0
318 0
4
0 0 73 66
0 1 64 55
0 63 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
298 0
318 0
4
0 0 73 66
0 2 64 55
0 63 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
298 0
318 0
4
0 0 73 66
0 3 64 55
0 63 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box4
2
298 0
318 0
4
0 0 73 66
0 4 64 55
0 63 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
316 0
319 0
4
0 0 73 72
0 1 70 69
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
316 0
319 0
4
0 0 73 72
0 2 70 69
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
316 0
319 0
4
0 0 73 72
0 3 70 69
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box4
2
316 0
319 0
4
0 0 73 72
0 4 70 69
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
320 0
323 0
4
0 0 73 74
0 1 72 73
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
320 0
323 0
4
0 0 73 74
0 2 72 73
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box3
2
320 0
323 0
4
0 0 73 74
0 3 72 73
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box4
2
320 0
323 0
4
0 0 73 74
0 4 72 73
0 80 -1 0
0 81 0 1
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box1
2
302 0
321 0
4
0 0 74 67
0 1 65 56
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box2
2
302 0
321 0
4
0 0 74 67
0 2 65 56
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box3
2
302 0
321 0
4
0 0 74 67
0 3 65 56
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_7_8 loc_6_8 up box4
2
302 0
321 0
4
0 0 74 67
0 4 65 56
0 64 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box1
2
319 0
322 0
4
0 0 74 73
0 1 71 70
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box2
2
319 0
322 0
4
0 0 74 73
0 2 71 70
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box3
2
319 0
322 0
4
0 0 74 73
0 3 71 70
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box4
2
319 0
322 0
4
0 0 74 73
0 4 71 70
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
323 0
324 0
4
0 0 74 75
0 1 73 66
0 74 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
323 0
324 0
4
0 0 74 75
0 2 73 66
0 74 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box3
2
323 0
324 0
4
0 0 74 75
0 3 73 66
0 74 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box4
2
323 0
324 0
4
0 0 74 75
0 4 73 66
0 74 0 1
0 81 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
305 0
324 0
4
0 0 75 68
0 1 66 67
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
305 0
324 0
4
0 0 75 68
0 2 66 67
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
305 0
324 0
4
0 0 75 68
0 3 66 67
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
305 0
324 0
4
0 0 75 68
0 4 66 67
0 74 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
322 0
325 0
4
0 0 75 74
0 1 72 71
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
322 0
325 0
4
0 0 75 74
0 2 72 71
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box3
2
322 0
325 0
4
0 0 75 74
0 3 72 71
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box4
2
322 0
325 0
4
0 0 75 74
0 4 72 71
0 79 0 1
0 80 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
308 0
331 0
4
0 0 77 69
0 1 67 58
0 66 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
308 0
331 0
4
0 0 77 69
0 2 67 58
0 66 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
308 0
331 0
4
0 0 77 69
0 3 67 58
0 66 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
308 0
331 0
4
0 0 77 69
0 4 67 58
0 66 0 1
0 75 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
334 0
337 0
4
0 0 78 79
0 1 76 77
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
334 0
337 0
4
0 0 78 79
0 2 76 77
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
334 0
337 0
4
0 0 78 79
0 3 76 77
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box4
2
334 0
337 0
4
0 0 78 79
0 4 76 77
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box1
2
97 0
335 0
4
0 0 79 3
0 1 3 9
0 8 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box2
2
97 0
335 0
4
0 0 79 3
0 2 3 9
0 8 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box3
2
97 0
335 0
4
0 0 79 3
0 3 3 9
0 8 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box4
2
97 0
335 0
4
0 0 79 3
0 4 3 9
0 8 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
101 0
338 0
4
0 0 80 4
0 1 4 10
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
101 0
338 0
4
0 0 80 4
0 2 4 10
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
101 0
338 0
4
0 0 80 4
0 3 4 10
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box4
2
101 0
338 0
4
0 0 80 4
0 4 4 10
0 9 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
312 0
339 0
4
0 0 80 71
0 1 69 62
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
312 0
339 0
4
0 0 80 71
0 2 69 62
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box3
2
312 0
339 0
4
0 0 80 71
0 3 69 62
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box4
2
312 0
339 0
4
0 0 80 71
0 4 69 62
0 70 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
336 0
340 0
4
0 0 80 79
0 1 76 75
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
336 0
340 0
4
0 0 80 79
0 2 76 75
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
336 0
340 0
4
0 0 80 79
0 3 76 75
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box4
2
336 0
340 0
4
0 0 80 79
0 4 76 75
0 84 0 1
0 85 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box1
2
113 0
341 0
4
0 0 81 8
0 1 8 13
0 13 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box2
2
113 0
341 0
4
0 0 81 8
0 2 8 13
0 13 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box3
2
113 0
341 0
4
0 0 81 8
0 3 8 13
0 13 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_9 loc_10_9 loc_11_9 down box4
2
113 0
341 0
4
0 0 81 8
0 4 8 13
0 13 -1 0
0 20 0 1
1
end_operator
0
