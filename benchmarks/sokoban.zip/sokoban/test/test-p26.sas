begin_version
3
end_version
begin_metric
1
end_metric
379
begin_variable
var0
-1
93
at-robot loc_10_10
at-robot loc_10_11
at-robot loc_10_3
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_10_8
at-robot loc_11_11
at-robot loc_11_12
at-robot loc_11_2
at-robot loc_11_3
at-robot loc_11_4
at-robot loc_11_5
at-robot loc_11_6
at-robot loc_11_8
at-robot loc_11_9
at-robot loc_12_10
at-robot loc_12_11
at-robot loc_12_3
at-robot loc_12_4
at-robot loc_12_5
at-robot loc_12_6
at-robot loc_12_8
at-robot loc_2_11
at-robot loc_2_12
at-robot loc_2_5
at-robot loc_2_6
at-robot loc_3_10
at-robot loc_3_11
at-robot loc_3_12
at-robot loc_3_5
at-robot loc_3_7
at-robot loc_3_9
at-robot loc_4_10
at-robot loc_4_12
at-robot loc_4_2
at-robot loc_4_3
at-robot loc_4_4
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_4_7
at-robot loc_4_8
at-robot loc_4_9
at-robot loc_5_10
at-robot loc_5_11
at-robot loc_5_12
at-robot loc_5_2
at-robot loc_5_3
at-robot loc_5_4
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_10
at-robot loc_6_11
at-robot loc_6_12
at-robot loc_6_2
at-robot loc_6_3
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_8
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_12
at-robot loc_7_3
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_2
at-robot loc_8_3
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_12
at-robot loc_9_2
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_8
at-robot loc_9_9
end_variable
begin_variable
var1
-1
88
at box1 loc_10_10
at box1 loc_10_11
at box1 loc_10_3
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_10_8
at box1 loc_11_11
at box1 loc_11_2
at box1 loc_11_3
at box1 loc_11_4
at box1 loc_11_5
at box1 loc_11_6
at box1 loc_11_8
at box1 loc_12_11
at box1 loc_12_3
at box1 loc_12_4
at box1 loc_12_5
at box1 loc_12_6
at box1 loc_12_8
at box1 loc_2_12
at box1 loc_2_5
at box1 loc_3_10
at box1 loc_3_11
at box1 loc_3_12
at box1 loc_3_5
at box1 loc_3_7
at box1 loc_3_9
at box1 loc_4_10
at box1 loc_4_12
at box1 loc_4_2
at box1 loc_4_3
at box1 loc_4_4
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_4_7
at box1 loc_4_8
at box1 loc_4_9
at box1 loc_5_10
at box1 loc_5_11
at box1 loc_5_12
at box1 loc_5_2
at box1 loc_5_3
at box1 loc_5_4
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_10
at box1 loc_6_11
at box1 loc_6_12
at box1 loc_6_2
at box1 loc_6_3
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_8
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_12
at box1 loc_7_3
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_12
at box1 loc_8_2
at box1 loc_8_3
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_12
at box1 loc_9_2
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_8
at box1 loc_9_9
end_variable
begin_variable
var2
-1
88
at box4 loc_10_10
at box4 loc_10_11
at box4 loc_10_3
at box4 loc_10_4
at box4 loc_10_5
at box4 loc_10_6
at box4 loc_10_7
at box4 loc_10_8
at box4 loc_11_11
at box4 loc_11_2
at box4 loc_11_3
at box4 loc_11_4
at box4 loc_11_5
at box4 loc_11_6
at box4 loc_11_8
at box4 loc_12_11
at box4 loc_12_3
at box4 loc_12_4
at box4 loc_12_5
at box4 loc_12_6
at box4 loc_12_8
at box4 loc_2_12
at box4 loc_2_5
at box4 loc_3_10
at box4 loc_3_11
at box4 loc_3_12
at box4 loc_3_5
at box4 loc_3_7
at box4 loc_3_9
at box4 loc_4_10
at box4 loc_4_12
at box4 loc_4_2
at box4 loc_4_3
at box4 loc_4_4
at box4 loc_4_5
at box4 loc_4_6
at box4 loc_4_7
at box4 loc_4_8
at box4 loc_4_9
at box4 loc_5_10
at box4 loc_5_11
at box4 loc_5_12
at box4 loc_5_2
at box4 loc_5_3
at box4 loc_5_4
at box4 loc_5_5
at box4 loc_5_6
at box4 loc_5_7
at box4 loc_5_8
at box4 loc_5_9
at box4 loc_6_10
at box4 loc_6_11
at box4 loc_6_12
at box4 loc_6_2
at box4 loc_6_3
at box4 loc_6_5
at box4 loc_6_6
at box4 loc_6_7
at box4 loc_6_8
at box4 loc_7_10
at box4 loc_7_11
at box4 loc_7_12
at box4 loc_7_3
at box4 loc_7_4
at box4 loc_7_5
at box4 loc_7_9
at box4 loc_8_10
at box4 loc_8_11
at box4 loc_8_12
at box4 loc_8_2
at box4 loc_8_3
at box4 loc_8_4
at box4 loc_8_5
at box4 loc_8_6
at box4 loc_8_7
at box4 loc_8_8
at box4 loc_8_9
at box4 loc_9_10
at box4 loc_9_11
at box4 loc_9_12
at box4 loc_9_2
at box4 loc_9_3
at box4 loc_9_4
at box4 loc_9_5
at box4 loc_9_6
at box4 loc_9_7
at box4 loc_9_8
at box4 loc_9_9
end_variable
begin_variable
var3
-1
88
at box2 loc_10_10
at box2 loc_10_11
at box2 loc_10_3
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_10_8
at box2 loc_11_11
at box2 loc_11_2
at box2 loc_11_3
at box2 loc_11_4
at box2 loc_11_5
at box2 loc_11_6
at box2 loc_11_8
at box2 loc_12_11
at box2 loc_12_3
at box2 loc_12_4
at box2 loc_12_5
at box2 loc_12_6
at box2 loc_12_8
at box2 loc_2_12
at box2 loc_2_5
at box2 loc_3_10
at box2 loc_3_11
at box2 loc_3_12
at box2 loc_3_5
at box2 loc_3_7
at box2 loc_3_9
at box2 loc_4_10
at box2 loc_4_12
at box2 loc_4_2
at box2 loc_4_3
at box2 loc_4_4
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_4_7
at box2 loc_4_8
at box2 loc_4_9
at box2 loc_5_10
at box2 loc_5_11
at box2 loc_5_12
at box2 loc_5_2
at box2 loc_5_3
at box2 loc_5_4
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_10
at box2 loc_6_11
at box2 loc_6_12
at box2 loc_6_2
at box2 loc_6_3
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_8
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_12
at box2 loc_7_3
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_12
at box2 loc_8_2
at box2 loc_8_3
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_12
at box2 loc_9_2
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_8
at box2 loc_9_9
end_variable
begin_variable
var4
-1
88
at box3 loc_10_10
at box3 loc_10_11
at box3 loc_10_3
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_10_8
at box3 loc_11_11
at box3 loc_11_2
at box3 loc_11_3
at box3 loc_11_4
at box3 loc_11_5
at box3 loc_11_6
at box3 loc_11_8
at box3 loc_12_11
at box3 loc_12_3
at box3 loc_12_4
at box3 loc_12_5
at box3 loc_12_6
at box3 loc_12_8
at box3 loc_2_12
at box3 loc_2_5
at box3 loc_3_10
at box3 loc_3_11
at box3 loc_3_12
at box3 loc_3_5
at box3 loc_3_7
at box3 loc_3_9
at box3 loc_4_10
at box3 loc_4_12
at box3 loc_4_2
at box3 loc_4_3
at box3 loc_4_4
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_4_7
at box3 loc_4_8
at box3 loc_4_9
at box3 loc_5_10
at box3 loc_5_11
at box3 loc_5_12
at box3 loc_5_2
at box3 loc_5_3
at box3 loc_5_4
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_10
at box3 loc_6_11
at box3 loc_6_12
at box3 loc_6_2
at box3 loc_6_3
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_8
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_12
at box3 loc_7_3
at box3 loc_7_4
at box3 loc_7_5
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_12
at box3 loc_8_2
at box3 loc_8_3
at box3 loc_8_4
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_8
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_12
at box3 loc_9_2
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_8
at box3 loc_9_9
end_variable
begin_variable
var5
-1
2
clear loc_4_8
none-of-those
end_variable
begin_variable
var6
-1
2
clear loc_4_9
none-of-those
end_variable
begin_variable
var7
-1
2
clear loc_5_10
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_5_11
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_5_12
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_5_3
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_5_4
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_6_10
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_6_12
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_6_3
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_6_8
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_7_12
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_7_3
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_8_3
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_9_12
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_9_8
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_10_10
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_10_3
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_10_8
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_11_4
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_11_6
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_11_8
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_11_9
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_12_10
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_12_11
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_12_3
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_12_4
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_12_5
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_12_6
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_12_8
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_2_11
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_2_12
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_2_6
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_3_10
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_3_11
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_3_12
none-of-those
end_variable
begin_variable
var88
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var89
-1
2
clear loc_3_7
none-of-those
end_variable
begin_variable
var90
-1
2
clear loc_3_9
none-of-those
end_variable
begin_variable
var91
-1
2
clear loc_4_10
none-of-those
end_variable
begin_variable
var92
-1
2
clear loc_4_12
none-of-those
end_variable
begin_variable
var93
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var94
-1
2
clear loc_4_3
none-of-those
end_variable
begin_variable
var95
-1
2
clear loc_4_4
none-of-those
end_variable
begin_variable
var96
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var97
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var98
-1
2
clear loc_4_7
none-of-those
end_variable
begin_variable
var99
-1
2
adjacent loc_10_10 loc_10_11 right
none-of-those
end_variable
begin_variable
var100
-1
2
adjacent loc_10_10 loc_9_10 up
none-of-those
end_variable
begin_variable
var101
-1
2
adjacent loc_10_11 loc_10_10 left
none-of-those
end_variable
begin_variable
var102
-1
2
adjacent loc_10_11 loc_11_11 down
none-of-those
end_variable
begin_variable
var103
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var104
-1
2
adjacent loc_10_3 loc_10_4 right
none-of-those
end_variable
begin_variable
var105
-1
2
adjacent loc_10_3 loc_11_3 down
none-of-those
end_variable
begin_variable
var106
-1
2
adjacent loc_10_3 loc_9_3 up
none-of-those
end_variable
begin_variable
var107
-1
2
adjacent loc_10_4 loc_10_3 left
none-of-those
end_variable
begin_variable
var108
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var109
-1
2
adjacent loc_10_4 loc_11_4 down
none-of-those
end_variable
begin_variable
var110
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var111
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var112
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var113
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var114
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var115
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var116
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var117
-1
2
adjacent loc_10_6 loc_11_6 down
none-of-those
end_variable
begin_variable
var118
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var119
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var120
-1
2
adjacent loc_10_7 loc_10_8 right
none-of-those
end_variable
begin_variable
var121
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var122
-1
2
adjacent loc_10_8 loc_10_7 left
none-of-those
end_variable
begin_variable
var123
-1
2
adjacent loc_10_8 loc_11_8 down
none-of-those
end_variable
begin_variable
var124
-1
2
adjacent loc_10_8 loc_9_8 up
none-of-those
end_variable
begin_variable
var125
-1
2
adjacent loc_11_11 loc_10_11 up
none-of-those
end_variable
begin_variable
var126
-1
2
adjacent loc_11_11 loc_11_12 right
none-of-those
end_variable
begin_variable
var127
-1
2
adjacent loc_11_11 loc_12_11 down
none-of-those
end_variable
begin_variable
var128
-1
2
adjacent loc_11_12 loc_11_11 left
none-of-those
end_variable
begin_variable
var129
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var130
-1
2
adjacent loc_11_3 loc_10_3 up
none-of-those
end_variable
begin_variable
var131
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var132
-1
2
adjacent loc_11_3 loc_11_4 right
none-of-those
end_variable
begin_variable
var133
-1
2
adjacent loc_11_3 loc_12_3 down
none-of-those
end_variable
begin_variable
var134
-1
2
adjacent loc_11_4 loc_10_4 up
none-of-those
end_variable
begin_variable
var135
-1
2
adjacent loc_11_4 loc_11_3 left
none-of-those
end_variable
begin_variable
var136
-1
2
adjacent loc_11_4 loc_11_5 right
none-of-those
end_variable
begin_variable
var137
-1
2
adjacent loc_11_4 loc_12_4 down
none-of-those
end_variable
begin_variable
var138
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var139
-1
2
adjacent loc_11_5 loc_11_4 left
none-of-those
end_variable
begin_variable
var140
-1
2
adjacent loc_11_5 loc_11_6 right
none-of-those
end_variable
begin_variable
var141
-1
2
adjacent loc_11_5 loc_12_5 down
none-of-those
end_variable
begin_variable
var142
-1
2
adjacent loc_11_6 loc_10_6 up
none-of-those
end_variable
begin_variable
var143
-1
2
adjacent loc_11_6 loc_11_5 left
none-of-those
end_variable
begin_variable
var144
-1
2
adjacent loc_11_6 loc_12_6 down
none-of-those
end_variable
begin_variable
var145
-1
2
adjacent loc_11_8 loc_10_8 up
none-of-those
end_variable
begin_variable
var146
-1
2
adjacent loc_11_8 loc_11_9 right
none-of-those
end_variable
begin_variable
var147
-1
2
adjacent loc_11_8 loc_12_8 down
none-of-those
end_variable
begin_variable
var148
-1
2
adjacent loc_11_9 loc_11_8 left
none-of-those
end_variable
begin_variable
var149
-1
2
adjacent loc_12_10 loc_12_11 right
none-of-those
end_variable
begin_variable
var150
-1
2
adjacent loc_12_11 loc_11_11 up
none-of-those
end_variable
begin_variable
var151
-1
2
adjacent loc_12_11 loc_12_10 left
none-of-those
end_variable
begin_variable
var152
-1
2
adjacent loc_12_3 loc_11_3 up
none-of-those
end_variable
begin_variable
var153
-1
2
adjacent loc_12_3 loc_12_4 right
none-of-those
end_variable
begin_variable
var154
-1
2
adjacent loc_12_4 loc_11_4 up
none-of-those
end_variable
begin_variable
var155
-1
2
adjacent loc_12_4 loc_12_3 left
none-of-those
end_variable
begin_variable
var156
-1
2
adjacent loc_12_4 loc_12_5 right
none-of-those
end_variable
begin_variable
var157
-1
2
adjacent loc_12_5 loc_11_5 up
none-of-those
end_variable
begin_variable
var158
-1
2
adjacent loc_12_5 loc_12_4 left
none-of-those
end_variable
begin_variable
var159
-1
2
adjacent loc_12_5 loc_12_6 right
none-of-those
end_variable
begin_variable
var160
-1
2
adjacent loc_12_6 loc_11_6 up
none-of-those
end_variable
begin_variable
var161
-1
2
adjacent loc_12_6 loc_12_5 left
none-of-those
end_variable
begin_variable
var162
-1
2
adjacent loc_12_8 loc_11_8 up
none-of-those
end_variable
begin_variable
var163
-1
2
adjacent loc_2_11 loc_2_12 right
none-of-those
end_variable
begin_variable
var164
-1
2
adjacent loc_2_11 loc_3_11 down
none-of-those
end_variable
begin_variable
var165
-1
2
adjacent loc_2_12 loc_2_11 left
none-of-those
end_variable
begin_variable
var166
-1
2
adjacent loc_2_12 loc_3_12 down
none-of-those
end_variable
begin_variable
var167
-1
2
adjacent loc_2_5 loc_2_6 right
none-of-those
end_variable
begin_variable
var168
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var169
-1
2
adjacent loc_2_6 loc_2_5 left
none-of-those
end_variable
begin_variable
var170
-1
2
adjacent loc_3_10 loc_3_11 right
none-of-those
end_variable
begin_variable
var171
-1
2
adjacent loc_3_10 loc_3_9 left
none-of-those
end_variable
begin_variable
var172
-1
2
adjacent loc_3_10 loc_4_10 down
none-of-those
end_variable
begin_variable
var173
-1
2
adjacent loc_3_11 loc_2_11 up
none-of-those
end_variable
begin_variable
var174
-1
2
adjacent loc_3_11 loc_3_10 left
none-of-those
end_variable
begin_variable
var175
-1
2
adjacent loc_3_11 loc_3_12 right
none-of-those
end_variable
begin_variable
var176
-1
2
adjacent loc_3_12 loc_2_12 up
none-of-those
end_variable
begin_variable
var177
-1
2
adjacent loc_3_12 loc_3_11 left
none-of-those
end_variable
begin_variable
var178
-1
2
adjacent loc_3_12 loc_4_12 down
none-of-those
end_variable
begin_variable
var179
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var180
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var181
-1
2
adjacent loc_3_7 loc_4_7 down
none-of-those
end_variable
begin_variable
var182
-1
2
adjacent loc_3_9 loc_3_10 right
none-of-those
end_variable
begin_variable
var183
-1
2
adjacent loc_3_9 loc_4_9 down
none-of-those
end_variable
begin_variable
var184
-1
2
adjacent loc_4_10 loc_3_10 up
none-of-those
end_variable
begin_variable
var185
-1
2
adjacent loc_4_10 loc_4_9 left
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_4_10 loc_5_10 down
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_4_12 loc_3_12 up
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_4_12 loc_5_12 down
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_4_2 loc_4_3 right
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_4_3 loc_4_2 left
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_4_3 loc_4_4 right
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_4_3 loc_5_3 down
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_4_4 loc_4_3 left
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_4_4 loc_4_5 right
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_4_4 loc_5_4 down
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_4_5 loc_4_4 left
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_4_6 loc_4_7 right
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_4_7 loc_3_7 up
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_4_7 loc_4_6 left
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_4_7 loc_4_8 right
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_4_7 loc_5_7 down
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_4_8 loc_4_7 left
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_4_8 loc_4_9 right
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_4_8 loc_5_8 down
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_4_9 loc_3_9 up
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_4_9 loc_4_10 right
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_4_9 loc_4_8 left
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_4_9 loc_5_9 down
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_5_10 loc_4_10 up
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_5_10 loc_5_11 right
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_5_10 loc_5_9 left
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_5_10 loc_6_10 down
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_5_11 loc_5_10 left
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_5_11 loc_5_12 right
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_5_11 loc_6_11 down
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_5_12 loc_4_12 up
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_5_12 loc_5_11 left
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_5_12 loc_6_12 down
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_5_2 loc_5_3 right
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_5_3 loc_4_3 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_5_3 loc_5_2 left
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_5_3 loc_5_4 right
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_5_3 loc_6_3 down
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_5_4 loc_4_4 up
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_5_4 loc_5_3 left
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_5_4 loc_5_5 right
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_5_5 loc_5_4 left
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_5_7 loc_4_7 up
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_5_8 loc_4_8 up
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_5_8 loc_6_8 down
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_5_9 loc_4_9 up
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_5_9 loc_5_10 right
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_6_10 loc_5_10 up
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_6_10 loc_6_11 right
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_6_10 loc_7_10 down
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_6_11 loc_5_11 up
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_6_11 loc_6_10 left
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_6_11 loc_6_12 right
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_6_12 loc_5_12 up
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_6_12 loc_6_11 left
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_6_12 loc_7_12 down
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_6_2 loc_6_3 right
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_6_3 loc_5_3 up
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_6_3 loc_6_2 left
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_6_3 loc_7_3 down
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_6_7 loc_6_8 right
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_6_8 loc_5_8 up
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_6_8 loc_6_7 left
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_7_10 loc_6_10 up
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_7_11 loc_7_12 right
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_7_12 loc_6_12 up
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_7_12 loc_7_11 left
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_7_12 loc_8_12 down
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_7_3 loc_6_3 up
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_7_3 loc_7_4 right
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_7_3 loc_8_3 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_7_4 loc_7_3 left
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_8_12 loc_7_12 up
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_8_12 loc_9_12 down
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_8_2 loc_8_3 right
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_8_3 loc_7_3 up
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_8_3 loc_8_2 left
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_8_3 loc_8_4 right
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_8_3 loc_9_3 down
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_8_4 loc_8_3 left
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_8_8 loc_9_8 down
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_9_10 loc_10_10 down
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var344
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var345
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var346
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var347
-1
2
adjacent loc_9_11 loc_9_12 right
none-of-those
end_variable
begin_variable
var348
-1
2
adjacent loc_9_12 loc_8_12 up
none-of-those
end_variable
begin_variable
var349
-1
2
adjacent loc_9_12 loc_9_11 left
none-of-those
end_variable
begin_variable
var350
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var351
-1
2
adjacent loc_9_2 loc_9_3 right
none-of-those
end_variable
begin_variable
var352
-1
2
adjacent loc_9_3 loc_10_3 down
none-of-those
end_variable
begin_variable
var353
-1
2
adjacent loc_9_3 loc_8_3 up
none-of-those
end_variable
begin_variable
var354
-1
2
adjacent loc_9_3 loc_9_2 left
none-of-those
end_variable
begin_variable
var355
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var356
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var357
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var358
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var359
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var360
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var361
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var362
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var363
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var364
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var365
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var366
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var367
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var368
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var369
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var370
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var371
-1
2
adjacent loc_9_7 loc_9_8 right
none-of-those
end_variable
begin_variable
var372
-1
2
adjacent loc_9_8 loc_10_8 down
none-of-those
end_variable
begin_variable
var373
-1
2
adjacent loc_9_8 loc_8_8 up
none-of-those
end_variable
begin_variable
var374
-1
2
adjacent loc_9_8 loc_9_7 left
none-of-those
end_variable
begin_variable
var375
-1
2
adjacent loc_9_8 loc_9_9 right
none-of-those
end_variable
begin_variable
var376
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var377
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
begin_variable
var378
-1
2
adjacent loc_9_9 loc_9_8 left
none-of-those
end_variable
0
begin_state
30
70
74
39
3
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
4
1 37
2 62
3 2
4 10
end_goal
1072
begin_operator
move loc_10_10 loc_10_11 right
2
57 0
99 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_10 loc_9_10 up
2
45 0
100 0
1
0 0 0 82
1
end_operator
begin_operator
move loc_10_11 loc_10_10 left
2
56 0
101 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_11 loc_11_11 down
2
64 0
102 0
1
0 0 1 8
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
46 0
103 0
1
0 0 1 83
1
end_operator
begin_operator
move loc_10_3 loc_10_4 right
2
59 0
104 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_3 loc_11_3 down
2
67 0
105 0
1
0 0 2 11
1
end_operator
begin_operator
move loc_10_3 loc_9_3 up
2
49 0
106 0
1
0 0 2 86
1
end_operator
begin_operator
move loc_10_4 loc_10_3 left
2
58 0
107 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
60 0
108 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_4 loc_11_4 down
2
68 0
109 0
1
0 0 3 12
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
50 0
110 0
1
0 0 3 87
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
59 0
111 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
61 0
112 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
69 0
113 0
1
0 0 4 13
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
51 0
114 0
1
0 0 4 88
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
60 0
115 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
62 0
116 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_6 loc_11_6 down
2
70 0
117 0
1
0 0 5 14
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
52 0
118 0
1
0 0 5 89
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
61 0
119 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_7 loc_10_8 right
2
63 0
120 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
53 0
121 0
1
0 0 6 90
1
end_operator
begin_operator
move loc_10_8 loc_10_7 left
2
62 0
122 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_8 loc_11_8 down
2
71 0
123 0
1
0 0 7 15
1
end_operator
begin_operator
move loc_10_8 loc_9_8 up
2
54 0
124 0
1
0 0 7 91
1
end_operator
begin_operator
move loc_11_11 loc_10_11 up
2
57 0
125 0
1
0 0 8 1
1
end_operator
begin_operator
move loc_11_11 loc_11_12 right
2
65 0
126 0
1
0 0 8 9
1
end_operator
begin_operator
move loc_11_11 loc_12_11 down
2
74 0
127 0
1
0 0 8 18
1
end_operator
begin_operator
move loc_11_12 loc_11_11 left
2
64 0
128 0
1
0 0 9 8
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
67 0
129 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_11_3 loc_10_3 up
2
58 0
130 0
1
0 0 11 2
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
66 0
131 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_11_3 loc_11_4 right
2
68 0
132 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_11_3 loc_12_3 down
2
75 0
133 0
1
0 0 11 19
1
end_operator
begin_operator
move loc_11_4 loc_10_4 up
2
59 0
134 0
1
0 0 12 3
1
end_operator
begin_operator
move loc_11_4 loc_11_3 left
2
67 0
135 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_11_4 loc_11_5 right
2
69 0
136 0
1
0 0 12 13
1
end_operator
begin_operator
move loc_11_4 loc_12_4 down
2
76 0
137 0
1
0 0 12 20
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
60 0
138 0
1
0 0 13 4
1
end_operator
begin_operator
move loc_11_5 loc_11_4 left
2
68 0
139 0
1
0 0 13 12
1
end_operator
begin_operator
move loc_11_5 loc_11_6 right
2
70 0
140 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_11_5 loc_12_5 down
2
77 0
141 0
1
0 0 13 21
1
end_operator
begin_operator
move loc_11_6 loc_10_6 up
2
61 0
142 0
1
0 0 14 5
1
end_operator
begin_operator
move loc_11_6 loc_11_5 left
2
69 0
143 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_11_6 loc_12_6 down
2
78 0
144 0
1
0 0 14 22
1
end_operator
begin_operator
move loc_11_8 loc_10_8 up
2
63 0
145 0
1
0 0 15 7
1
end_operator
begin_operator
move loc_11_8 loc_11_9 right
2
72 0
146 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_11_8 loc_12_8 down
2
79 0
147 0
1
0 0 15 23
1
end_operator
begin_operator
move loc_11_9 loc_11_8 left
2
71 0
148 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_12_10 loc_12_11 right
2
74 0
149 0
1
0 0 17 18
1
end_operator
begin_operator
move loc_12_11 loc_11_11 up
2
64 0
150 0
1
0 0 18 8
1
end_operator
begin_operator
move loc_12_11 loc_12_10 left
2
73 0
151 0
1
0 0 18 17
1
end_operator
begin_operator
move loc_12_3 loc_11_3 up
2
67 0
152 0
1
0 0 19 11
1
end_operator
begin_operator
move loc_12_3 loc_12_4 right
2
76 0
153 0
1
0 0 19 20
1
end_operator
begin_operator
move loc_12_4 loc_11_4 up
2
68 0
154 0
1
0 0 20 12
1
end_operator
begin_operator
move loc_12_4 loc_12_3 left
2
75 0
155 0
1
0 0 20 19
1
end_operator
begin_operator
move loc_12_4 loc_12_5 right
2
77 0
156 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_12_5 loc_11_5 up
2
69 0
157 0
1
0 0 21 13
1
end_operator
begin_operator
move loc_12_5 loc_12_4 left
2
76 0
158 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_12_5 loc_12_6 right
2
78 0
159 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_12_6 loc_11_6 up
2
70 0
160 0
1
0 0 22 14
1
end_operator
begin_operator
move loc_12_6 loc_12_5 left
2
77 0
161 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_12_8 loc_11_8 up
2
71 0
162 0
1
0 0 23 15
1
end_operator
begin_operator
move loc_2_11 loc_2_12 right
2
81 0
163 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_2_11 loc_3_11 down
2
86 0
164 0
1
0 0 24 29
1
end_operator
begin_operator
move loc_2_12 loc_2_11 left
2
80 0
165 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_2_12 loc_3_12 down
2
87 0
166 0
1
0 0 25 30
1
end_operator
begin_operator
move loc_2_5 loc_2_6 right
2
84 0
167 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
88 0
168 0
1
0 0 26 31
1
end_operator
begin_operator
move loc_2_6 loc_2_5 left
2
83 0
169 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_3_10 loc_3_11 right
2
86 0
170 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_3_10 loc_3_9 left
2
90 0
171 0
1
0 0 28 33
1
end_operator
begin_operator
move loc_3_10 loc_4_10 down
2
91 0
172 0
1
0 0 28 34
1
end_operator
begin_operator
move loc_3_11 loc_2_11 up
2
80 0
173 0
1
0 0 29 24
1
end_operator
begin_operator
move loc_3_11 loc_3_10 left
2
85 0
174 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_3_11 loc_3_12 right
2
87 0
175 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_3_12 loc_2_12 up
2
81 0
176 0
1
0 0 30 25
1
end_operator
begin_operator
move loc_3_12 loc_3_11 left
2
86 0
177 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_3_12 loc_4_12 down
2
92 0
178 0
1
0 0 30 35
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
83 0
179 0
1
0 0 31 26
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
96 0
180 0
1
0 0 31 39
1
end_operator
begin_operator
move loc_3_7 loc_4_7 down
2
98 0
181 0
1
0 0 32 41
1
end_operator
begin_operator
move loc_3_9 loc_3_10 right
2
85 0
182 0
1
0 0 33 28
1
end_operator
begin_operator
move loc_3_9 loc_4_9 down
2
6 0
183 0
1
0 0 33 43
1
end_operator
begin_operator
move loc_4_10 loc_3_10 up
2
85 0
184 0
1
0 0 34 28
1
end_operator
begin_operator
move loc_4_10 loc_4_9 left
2
6 0
185 0
1
0 0 34 43
1
end_operator
begin_operator
move loc_4_10 loc_5_10 down
2
7 0
186 0
1
0 0 34 44
1
end_operator
begin_operator
move loc_4_12 loc_3_12 up
2
87 0
187 0
1
0 0 35 30
1
end_operator
begin_operator
move loc_4_12 loc_5_12 down
2
9 0
188 0
1
0 0 35 46
1
end_operator
begin_operator
move loc_4_2 loc_4_3 right
2
94 0
189 0
1
0 0 36 37
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
10 0
190 0
1
0 0 36 47
1
end_operator
begin_operator
move loc_4_3 loc_4_2 left
2
93 0
191 0
1
0 0 37 36
1
end_operator
begin_operator
move loc_4_3 loc_4_4 right
2
95 0
192 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_4_3 loc_5_3 down
2
11 0
193 0
1
0 0 37 48
1
end_operator
begin_operator
move loc_4_4 loc_4_3 left
2
94 0
194 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_4_4 loc_4_5 right
2
96 0
195 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_4_4 loc_5_4 down
2
12 0
196 0
1
0 0 38 49
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
88 0
197 0
1
0 0 39 31
1
end_operator
begin_operator
move loc_4_5 loc_4_4 left
2
95 0
198 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
97 0
199 0
1
0 0 39 40
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
13 0
200 0
1
0 0 39 50
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
96 0
201 0
1
0 0 40 39
1
end_operator
begin_operator
move loc_4_6 loc_4_7 right
2
98 0
202 0
1
0 0 40 41
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
14 0
203 0
1
0 0 40 51
1
end_operator
begin_operator
move loc_4_7 loc_3_7 up
2
89 0
204 0
1
0 0 41 32
1
end_operator
begin_operator
move loc_4_7 loc_4_6 left
2
97 0
205 0
1
0 0 41 40
1
end_operator
begin_operator
move loc_4_7 loc_4_8 right
2
5 0
206 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_4_7 loc_5_7 down
2
15 0
207 0
1
0 0 41 52
1
end_operator
begin_operator
move loc_4_8 loc_4_7 left
2
98 0
208 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_4_8 loc_4_9 right
2
6 0
209 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_4_8 loc_5_8 down
2
16 0
210 0
1
0 0 42 53
1
end_operator
begin_operator
move loc_4_9 loc_3_9 up
2
90 0
211 0
1
0 0 43 33
1
end_operator
begin_operator
move loc_4_9 loc_4_10 right
2
91 0
212 0
1
0 0 43 34
1
end_operator
begin_operator
move loc_4_9 loc_4_8 left
2
5 0
213 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_4_9 loc_5_9 down
2
17 0
214 0
1
0 0 43 54
1
end_operator
begin_operator
move loc_5_10 loc_4_10 up
2
91 0
215 0
1
0 0 44 34
1
end_operator
begin_operator
move loc_5_10 loc_5_11 right
2
8 0
216 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_5_10 loc_5_9 left
2
17 0
217 0
1
0 0 44 54
1
end_operator
begin_operator
move loc_5_10 loc_6_10 down
2
18 0
218 0
1
0 0 44 55
1
end_operator
begin_operator
move loc_5_11 loc_5_10 left
2
7 0
219 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_5_11 loc_5_12 right
2
9 0
220 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_5_11 loc_6_11 down
2
19 0
221 0
1
0 0 45 56
1
end_operator
begin_operator
move loc_5_12 loc_4_12 up
2
92 0
222 0
1
0 0 46 35
1
end_operator
begin_operator
move loc_5_12 loc_5_11 left
2
8 0
223 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_5_12 loc_6_12 down
2
20 0
224 0
1
0 0 46 57
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
93 0
225 0
1
0 0 47 36
1
end_operator
begin_operator
move loc_5_2 loc_5_3 right
2
11 0
226 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
21 0
227 0
1
0 0 47 58
1
end_operator
begin_operator
move loc_5_3 loc_4_3 up
2
94 0
228 0
1
0 0 48 37
1
end_operator
begin_operator
move loc_5_3 loc_5_2 left
2
10 0
229 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_5_3 loc_5_4 right
2
12 0
230 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_5_3 loc_6_3 down
2
22 0
231 0
1
0 0 48 59
1
end_operator
begin_operator
move loc_5_4 loc_4_4 up
2
95 0
232 0
1
0 0 49 38
1
end_operator
begin_operator
move loc_5_4 loc_5_3 left
2
11 0
233 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_5_4 loc_5_5 right
2
13 0
234 0
1
0 0 49 50
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
96 0
235 0
1
0 0 50 39
1
end_operator
begin_operator
move loc_5_5 loc_5_4 left
2
12 0
236 0
1
0 0 50 49
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
14 0
237 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
23 0
238 0
1
0 0 50 60
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
97 0
239 0
1
0 0 51 40
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
13 0
240 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
15 0
241 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
24 0
242 0
1
0 0 51 61
1
end_operator
begin_operator
move loc_5_7 loc_4_7 up
2
98 0
243 0
1
0 0 52 41
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
14 0
244 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
16 0
245 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
25 0
246 0
1
0 0 52 62
1
end_operator
begin_operator
move loc_5_8 loc_4_8 up
2
5 0
247 0
1
0 0 53 42
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
15 0
248 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
17 0
249 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_5_8 loc_6_8 down
2
26 0
250 0
1
0 0 53 63
1
end_operator
begin_operator
move loc_5_9 loc_4_9 up
2
6 0
251 0
1
0 0 54 43
1
end_operator
begin_operator
move loc_5_9 loc_5_10 right
2
7 0
252 0
1
0 0 54 44
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
16 0
253 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_6_10 loc_5_10 up
2
7 0
254 0
1
0 0 55 44
1
end_operator
begin_operator
move loc_6_10 loc_6_11 right
2
19 0
255 0
1
0 0 55 56
1
end_operator
begin_operator
move loc_6_10 loc_7_10 down
2
27 0
256 0
1
0 0 55 64
1
end_operator
begin_operator
move loc_6_11 loc_5_11 up
2
8 0
257 0
1
0 0 56 45
1
end_operator
begin_operator
move loc_6_11 loc_6_10 left
2
18 0
258 0
1
0 0 56 55
1
end_operator
begin_operator
move loc_6_11 loc_6_12 right
2
20 0
259 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
28 0
260 0
1
0 0 56 65
1
end_operator
begin_operator
move loc_6_12 loc_5_12 up
2
9 0
261 0
1
0 0 57 46
1
end_operator
begin_operator
move loc_6_12 loc_6_11 left
2
19 0
262 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_6_12 loc_7_12 down
2
29 0
263 0
1
0 0 57 66
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
10 0
264 0
1
0 0 58 47
1
end_operator
begin_operator
move loc_6_2 loc_6_3 right
2
22 0
265 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_6_3 loc_5_3 up
2
11 0
266 0
1
0 0 59 48
1
end_operator
begin_operator
move loc_6_3 loc_6_2 left
2
21 0
267 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_6_3 loc_7_3 down
2
30 0
268 0
1
0 0 59 67
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
13 0
269 0
1
0 0 60 50
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
24 0
270 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
32 0
271 0
1
0 0 60 69
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
14 0
272 0
1
0 0 61 51
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
23 0
273 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
25 0
274 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
15 0
275 0
1
0 0 62 52
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
24 0
276 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_6_7 loc_6_8 right
2
26 0
277 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_6_8 loc_5_8 up
2
16 0
278 0
1
0 0 63 53
1
end_operator
begin_operator
move loc_6_8 loc_6_7 left
2
25 0
279 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_7_10 loc_6_10 up
2
18 0
280 0
1
0 0 64 55
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
28 0
281 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
33 0
282 0
1
0 0 64 70
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
34 0
283 0
1
0 0 64 71
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
19 0
284 0
1
0 0 65 56
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
27 0
285 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_7_11 loc_7_12 right
2
29 0
286 0
1
0 0 65 66
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
35 0
287 0
1
0 0 65 72
1
end_operator
begin_operator
move loc_7_12 loc_6_12 up
2
20 0
288 0
1
0 0 66 57
1
end_operator
begin_operator
move loc_7_12 loc_7_11 left
2
28 0
289 0
1
0 0 66 65
1
end_operator
begin_operator
move loc_7_12 loc_8_12 down
2
36 0
290 0
1
0 0 66 73
1
end_operator
begin_operator
move loc_7_3 loc_6_3 up
2
22 0
291 0
1
0 0 67 59
1
end_operator
begin_operator
move loc_7_3 loc_7_4 right
2
31 0
292 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_7_3 loc_8_3 down
2
38 0
293 0
1
0 0 67 75
1
end_operator
begin_operator
move loc_7_4 loc_7_3 left
2
30 0
294 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
32 0
295 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
39 0
296 0
1
0 0 68 76
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
23 0
297 0
1
0 0 69 60
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
31 0
298 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
40 0
299 0
1
0 0 69 77
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
27 0
300 0
1
0 0 70 64
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
44 0
301 0
1
0 0 70 81
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
27 0
302 0
1
0 0 71 64
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
35 0
303 0
1
0 0 71 72
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
44 0
304 0
1
0 0 71 81
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
45 0
305 0
1
0 0 71 82
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
28 0
306 0
1
0 0 72 65
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
34 0
307 0
1
0 0 72 71
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
36 0
308 0
1
0 0 72 73
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
46 0
309 0
1
0 0 72 83
1
end_operator
begin_operator
move loc_8_12 loc_7_12 up
2
29 0
310 0
1
0 0 73 66
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
35 0
311 0
1
0 0 73 72
1
end_operator
begin_operator
move loc_8_12 loc_9_12 down
2
47 0
312 0
1
0 0 73 84
1
end_operator
begin_operator
move loc_8_2 loc_8_3 right
2
38 0
313 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
48 0
314 0
1
0 0 74 85
1
end_operator
begin_operator
move loc_8_3 loc_7_3 up
2
30 0
315 0
1
0 0 75 67
1
end_operator
begin_operator
move loc_8_3 loc_8_2 left
2
37 0
316 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_8_3 loc_8_4 right
2
39 0
317 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_8_3 loc_9_3 down
2
49 0
318 0
1
0 0 75 86
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
31 0
319 0
1
0 0 76 68
1
end_operator
begin_operator
move loc_8_4 loc_8_3 left
2
38 0
320 0
1
0 0 76 75
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
40 0
321 0
1
0 0 76 77
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
50 0
322 0
1
0 0 76 87
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
32 0
323 0
1
0 0 77 69
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
39 0
324 0
1
0 0 77 76
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
41 0
325 0
1
0 0 77 78
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
51 0
326 0
1
0 0 77 88
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
40 0
327 0
1
0 0 78 77
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
42 0
328 0
1
0 0 78 79
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
52 0
329 0
1
0 0 78 89
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
41 0
330 0
1
0 0 79 78
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
43 0
331 0
1
0 0 79 80
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
53 0
332 0
1
0 0 79 90
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
42 0
333 0
1
0 0 80 79
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
44 0
334 0
1
0 0 80 81
1
end_operator
begin_operator
move loc_8_8 loc_9_8 down
2
54 0
335 0
1
0 0 80 91
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
33 0
336 0
1
0 0 81 70
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
34 0
337 0
1
0 0 81 71
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
43 0
338 0
1
0 0 81 80
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
55 0
339 0
1
0 0 81 92
1
end_operator
begin_operator
move loc_9_10 loc_10_10 down
2
56 0
340 0
1
0 0 82 0
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
34 0
341 0
1
0 0 82 71
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
46 0
342 0
1
0 0 82 83
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
55 0
343 0
1
0 0 82 92
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
57 0
344 0
1
0 0 83 1
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
35 0
345 0
1
0 0 83 72
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
45 0
346 0
1
0 0 83 82
1
end_operator
begin_operator
move loc_9_11 loc_9_12 right
2
47 0
347 0
1
0 0 83 84
1
end_operator
begin_operator
move loc_9_12 loc_8_12 up
2
36 0
348 0
1
0 0 84 73
1
end_operator
begin_operator
move loc_9_12 loc_9_11 left
2
46 0
349 0
1
0 0 84 83
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
37 0
350 0
1
0 0 85 74
1
end_operator
begin_operator
move loc_9_2 loc_9_3 right
2
49 0
351 0
1
0 0 85 86
1
end_operator
begin_operator
move loc_9_3 loc_10_3 down
2
58 0
352 0
1
0 0 86 2
1
end_operator
begin_operator
move loc_9_3 loc_8_3 up
2
38 0
353 0
1
0 0 86 75
1
end_operator
begin_operator
move loc_9_3 loc_9_2 left
2
48 0
354 0
1
0 0 86 85
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
50 0
355 0
1
0 0 86 87
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
59 0
356 0
1
0 0 87 3
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
39 0
357 0
1
0 0 87 76
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
49 0
358 0
1
0 0 87 86
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
51 0
359 0
1
0 0 87 88
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
60 0
360 0
1
0 0 88 4
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
40 0
361 0
1
0 0 88 77
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
50 0
362 0
1
0 0 88 87
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
52 0
363 0
1
0 0 88 89
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
61 0
364 0
1
0 0 89 5
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
41 0
365 0
1
0 0 89 78
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
51 0
366 0
1
0 0 89 88
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
53 0
367 0
1
0 0 89 90
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
62 0
368 0
1
0 0 90 6
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
42 0
369 0
1
0 0 90 79
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
52 0
370 0
1
0 0 90 89
1
end_operator
begin_operator
move loc_9_7 loc_9_8 right
2
54 0
371 0
1
0 0 90 91
1
end_operator
begin_operator
move loc_9_8 loc_10_8 down
2
63 0
372 0
1
0 0 91 7
1
end_operator
begin_operator
move loc_9_8 loc_8_8 up
2
43 0
373 0
1
0 0 91 80
1
end_operator
begin_operator
move loc_9_8 loc_9_7 left
2
53 0
374 0
1
0 0 91 90
1
end_operator
begin_operator
move loc_9_8 loc_9_9 right
2
55 0
375 0
1
0 0 91 92
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
44 0
376 0
1
0 0 92 81
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
45 0
377 0
1
0 0 92 82
1
end_operator
begin_operator
move loc_9_9 loc_9_8 left
2
54 0
378 0
1
0 0 92 91
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box1
2
100 0
341 0
4
0 0 0 82
0 1 77 66
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box2
2
100 0
341 0
4
0 0 0 82
0 3 77 66
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box3
2
100 0
341 0
4
0 0 0 82
0 4 77 66
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_10_10 loc_9_10 loc_8_10 up box4
2
100 0
341 0
4
0 0 0 82
0 2 77 66
0 34 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box1
2
102 0
127 0
4
0 0 1 8
0 1 8 15
0 64 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box2
2
102 0
127 0
4
0 0 1 8
0 3 8 15
0 64 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box3
2
102 0
127 0
4
0 0 1 8
0 4 8 15
0 64 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box4
2
102 0
127 0
4
0 0 1 8
0 2 8 15
0 64 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
103 0
345 0
4
0 0 1 83
0 1 78 67
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
103 0
345 0
4
0 0 1 83
0 3 78 67
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
103 0
345 0
4
0 0 1 83
0 4 78 67
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box4
2
103 0
345 0
4
0 0 1 83
0 2 78 67
0 35 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box1
2
104 0
108 0
4
0 0 2 3
0 1 3 4
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box2
2
104 0
108 0
4
0 0 2 3
0 3 3 4
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box3
2
104 0
108 0
4
0 0 2 3
0 4 3 4
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_10_3 loc_10_4 loc_10_5 right box4
2
104 0
108 0
4
0 0 2 3
0 2 3 4
0 59 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box1
2
105 0
133 0
4
0 0 2 11
0 1 10 16
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box2
2
105 0
133 0
4
0 0 2 11
0 3 10 16
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box3
2
105 0
133 0
4
0 0 2 11
0 4 10 16
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_10_3 loc_11_3 loc_12_3 down box4
2
105 0
133 0
4
0 0 2 11
0 2 10 16
0 67 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box1
2
106 0
353 0
4
0 0 2 86
0 1 81 70
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box2
2
106 0
353 0
4
0 0 2 86
0 3 81 70
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box3
2
106 0
353 0
4
0 0 2 86
0 4 81 70
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_10_3 loc_9_3 loc_8_3 up box4
2
106 0
353 0
4
0 0 2 86
0 2 81 70
0 38 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
108 0
112 0
4
0 0 3 4
0 1 4 5
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
108 0
112 0
4
0 0 3 4
0 3 4 5
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
108 0
112 0
4
0 0 3 4
0 4 4 5
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box4
2
108 0
112 0
4
0 0 3 4
0 2 4 5
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_10_4 loc_11_4 loc_12_4 down box1
2
109 0
137 0
4
0 0 3 12
0 1 11 17
0 68 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_10_4 loc_11_4 loc_12_4 down box2
2
109 0
137 0
4
0 0 3 12
0 3 11 17
0 68 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_10_4 loc_11_4 loc_12_4 down box3
2
109 0
137 0
4
0 0 3 12
0 4 11 17
0 68 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_10_4 loc_11_4 loc_12_4 down box4
2
109 0
137 0
4
0 0 3 12
0 2 11 17
0 68 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box1
2
110 0
357 0
4
0 0 3 87
0 1 82 71
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box2
2
110 0
357 0
4
0 0 3 87
0 3 82 71
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box3
2
110 0
357 0
4
0 0 3 87
0 4 82 71
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box4
2
110 0
357 0
4
0 0 3 87
0 2 82 71
0 39 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box1
2
107 0
111 0
4
0 0 4 3
0 1 3 2
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box2
2
107 0
111 0
4
0 0 4 3
0 3 3 2
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box3
2
107 0
111 0
4
0 0 4 3
0 4 3 2
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_4 loc_10_3 left box4
2
107 0
111 0
4
0 0 4 3
0 2 3 2
0 58 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
112 0
116 0
4
0 0 4 5
0 1 5 6
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
112 0
116 0
4
0 0 4 5
0 3 5 6
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
112 0
116 0
4
0 0 4 5
0 4 5 6
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box4
2
112 0
116 0
4
0 0 4 5
0 2 5 6
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box1
2
113 0
141 0
4
0 0 4 13
0 1 12 18
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box2
2
113 0
141 0
4
0 0 4 13
0 3 12 18
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box3
2
113 0
141 0
4
0 0 4 13
0 4 12 18
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_10_5 loc_11_5 loc_12_5 down box4
2
113 0
141 0
4
0 0 4 13
0 2 12 18
0 69 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
114 0
361 0
4
0 0 4 88
0 1 83 72
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
114 0
361 0
4
0 0 4 88
0 3 83 72
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
114 0
361 0
4
0 0 4 88
0 4 83 72
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box4
2
114 0
361 0
4
0 0 4 88
0 2 83 72
0 40 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
111 0
115 0
4
0 0 5 4
0 1 4 3
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
111 0
115 0
4
0 0 5 4
0 3 4 3
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
111 0
115 0
4
0 0 5 4
0 4 4 3
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box4
2
111 0
115 0
4
0 0 5 4
0 2 4 3
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box1
2
116 0
120 0
4
0 0 5 6
0 1 6 7
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box2
2
116 0
120 0
4
0 0 5 6
0 3 6 7
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box3
2
116 0
120 0
4
0 0 5 6
0 4 6 7
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_10_6 loc_10_7 loc_10_8 right box4
2
116 0
120 0
4
0 0 5 6
0 2 6 7
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box1
2
117 0
144 0
4
0 0 5 14
0 1 13 19
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box2
2
117 0
144 0
4
0 0 5 14
0 3 13 19
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box3
2
117 0
144 0
4
0 0 5 14
0 4 13 19
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_10_6 loc_11_6 loc_12_6 down box4
2
117 0
144 0
4
0 0 5 14
0 2 13 19
0 70 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box1
2
118 0
365 0
4
0 0 5 89
0 1 84 73
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box2
2
118 0
365 0
4
0 0 5 89
0 3 84 73
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box3
2
118 0
365 0
4
0 0 5 89
0 4 84 73
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box4
2
118 0
365 0
4
0 0 5 89
0 2 84 73
0 41 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
115 0
119 0
4
0 0 6 5
0 1 5 4
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
115 0
119 0
4
0 0 6 5
0 3 5 4
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
115 0
119 0
4
0 0 6 5
0 4 5 4
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box4
2
115 0
119 0
4
0 0 6 5
0 2 5 4
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
121 0
369 0
4
0 0 6 90
0 1 85 74
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
121 0
369 0
4
0 0 6 90
0 3 85 74
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
121 0
369 0
4
0 0 6 90
0 4 85 74
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box4
2
121 0
369 0
4
0 0 6 90
0 2 85 74
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box1
2
119 0
122 0
4
0 0 7 6
0 1 6 5
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box2
2
119 0
122 0
4
0 0 7 6
0 3 6 5
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box3
2
119 0
122 0
4
0 0 7 6
0 4 6 5
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_10_7 loc_10_6 left box4
2
119 0
122 0
4
0 0 7 6
0 2 6 5
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box1
2
123 0
147 0
4
0 0 7 15
0 1 14 20
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box2
2
123 0
147 0
4
0 0 7 15
0 3 14 20
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box3
2
123 0
147 0
4
0 0 7 15
0 4 14 20
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_10_8 loc_11_8 loc_12_8 down box4
2
123 0
147 0
4
0 0 7 15
0 2 14 20
0 71 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box1
2
124 0
373 0
4
0 0 7 91
0 1 86 75
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box2
2
124 0
373 0
4
0 0 7 91
0 3 86 75
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box3
2
124 0
373 0
4
0 0 7 91
0 4 86 75
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_10_8 loc_9_8 loc_8_8 up box4
2
124 0
373 0
4
0 0 7 91
0 2 86 75
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box1
2
106 0
130 0
4
0 0 11 2
0 1 2 81
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box2
2
106 0
130 0
4
0 0 11 2
0 3 2 81
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box3
2
106 0
130 0
4
0 0 11 2
0 4 2 81
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_10_3 loc_9_3 up box4
2
106 0
130 0
4
0 0 11 2
0 2 2 81
0 49 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box1
2
132 0
136 0
4
0 0 11 12
0 1 11 12
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box2
2
132 0
136 0
4
0 0 11 12
0 3 11 12
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box3
2
132 0
136 0
4
0 0 11 12
0 4 11 12
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_3 loc_11_4 loc_11_5 right box4
2
132 0
136 0
4
0 0 11 12
0 2 11 12
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box1
2
110 0
134 0
4
0 0 12 3
0 1 3 82
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box2
2
110 0
134 0
4
0 0 12 3
0 3 3 82
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box3
2
110 0
134 0
4
0 0 12 3
0 4 3 82
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box4
2
110 0
134 0
4
0 0 12 3
0 2 3 82
0 50 0 1
0 59 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box1
2
131 0
135 0
4
0 0 12 11
0 1 10 9
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box2
2
131 0
135 0
4
0 0 12 11
0 3 10 9
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box3
2
131 0
135 0
4
0 0 12 11
0 4 10 9
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box4
2
131 0
135 0
4
0 0 12 11
0 2 10 9
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box1
2
136 0
140 0
4
0 0 12 13
0 1 12 13
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box2
2
136 0
140 0
4
0 0 12 13
0 3 12 13
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box3
2
136 0
140 0
4
0 0 12 13
0 4 12 13
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_5 loc_11_6 right box4
2
136 0
140 0
4
0 0 12 13
0 2 12 13
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
114 0
138 0
4
0 0 13 4
0 1 4 83
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
114 0
138 0
4
0 0 13 4
0 3 4 83
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
114 0
138 0
4
0 0 13 4
0 4 4 83
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box4
2
114 0
138 0
4
0 0 13 4
0 2 4 83
0 51 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box1
2
135 0
139 0
4
0 0 13 12
0 1 11 10
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box2
2
135 0
139 0
4
0 0 13 12
0 3 11 10
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box3
2
135 0
139 0
4
0 0 13 12
0 4 11 10
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box4
2
135 0
139 0
4
0 0 13 12
0 2 11 10
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box1
2
118 0
142 0
4
0 0 14 5
0 1 5 84
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box2
2
118 0
142 0
4
0 0 14 5
0 3 5 84
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box3
2
118 0
142 0
4
0 0 14 5
0 4 5 84
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_10_6 loc_9_6 up box4
2
118 0
142 0
4
0 0 14 5
0 2 5 84
0 52 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box1
2
139 0
143 0
4
0 0 14 13
0 1 12 11
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box2
2
139 0
143 0
4
0 0 14 13
0 3 12 11
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box3
2
139 0
143 0
4
0 0 14 13
0 4 12 11
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_11_6 loc_11_5 loc_11_4 left box4
2
139 0
143 0
4
0 0 14 13
0 2 12 11
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box1
2
130 0
152 0
4
0 0 19 11
0 1 10 2
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box2
2
130 0
152 0
4
0 0 19 11
0 3 10 2
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box3
2
130 0
152 0
4
0 0 19 11
0 4 10 2
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_11_3 loc_10_3 up box4
2
130 0
152 0
4
0 0 19 11
0 2 10 2
0 58 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box1
2
153 0
156 0
4
0 0 19 20
0 1 17 18
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box2
2
153 0
156 0
4
0 0 19 20
0 3 17 18
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box3
2
153 0
156 0
4
0 0 19 20
0 4 17 18
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_12_3 loc_12_4 loc_12_5 right box4
2
153 0
156 0
4
0 0 19 20
0 2 17 18
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_12_4 loc_11_4 loc_10_4 up box1
2
134 0
154 0
4
0 0 20 12
0 1 11 3
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_12_4 loc_11_4 loc_10_4 up box2
2
134 0
154 0
4
0 0 20 12
0 3 11 3
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_12_4 loc_11_4 loc_10_4 up box3
2
134 0
154 0
4
0 0 20 12
0 4 11 3
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_12_4 loc_11_4 loc_10_4 up box4
2
134 0
154 0
4
0 0 20 12
0 2 11 3
0 59 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box1
2
156 0
159 0
4
0 0 20 21
0 1 18 19
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box2
2
156 0
159 0
4
0 0 20 21
0 3 18 19
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box3
2
156 0
159 0
4
0 0 20 21
0 4 18 19
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_12_4 loc_12_5 loc_12_6 right box4
2
156 0
159 0
4
0 0 20 21
0 2 18 19
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box1
2
138 0
157 0
4
0 0 21 13
0 1 12 4
0 60 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box2
2
138 0
157 0
4
0 0 21 13
0 3 12 4
0 60 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box3
2
138 0
157 0
4
0 0 21 13
0 4 12 4
0 60 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_11_5 loc_10_5 up box4
2
138 0
157 0
4
0 0 21 13
0 2 12 4
0 60 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box1
2
155 0
158 0
4
0 0 21 20
0 1 17 16
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box2
2
155 0
158 0
4
0 0 21 20
0 3 17 16
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box3
2
155 0
158 0
4
0 0 21 20
0 4 17 16
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_12_5 loc_12_4 loc_12_3 left box4
2
155 0
158 0
4
0 0 21 20
0 2 17 16
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box1
2
142 0
160 0
4
0 0 22 14
0 1 13 5
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box2
2
142 0
160 0
4
0 0 22 14
0 3 13 5
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box3
2
142 0
160 0
4
0 0 22 14
0 4 13 5
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_11_6 loc_10_6 up box4
2
142 0
160 0
4
0 0 22 14
0 2 13 5
0 61 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box1
2
158 0
161 0
4
0 0 22 21
0 1 18 17
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box2
2
158 0
161 0
4
0 0 22 21
0 3 18 17
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box3
2
158 0
161 0
4
0 0 22 21
0 4 18 17
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_12_6 loc_12_5 loc_12_4 left box4
2
158 0
161 0
4
0 0 22 21
0 2 18 17
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_2_12 loc_3_12 loc_4_12 down box1
2
166 0
178 0
4
0 0 25 30
0 1 25 30
0 87 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_2_12 loc_3_12 loc_4_12 down box2
2
166 0
178 0
4
0 0 25 30
0 3 25 30
0 87 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_2_12 loc_3_12 loc_4_12 down box3
2
166 0
178 0
4
0 0 25 30
0 4 25 30
0 87 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_2_12 loc_3_12 loc_4_12 down box4
2
166 0
178 0
4
0 0 25 30
0 2 25 30
0 87 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_3_10 loc_3_11 loc_3_12 right box1
2
170 0
175 0
4
0 0 28 29
0 1 24 25
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_3_10 loc_3_11 loc_3_12 right box2
2
170 0
175 0
4
0 0 28 29
0 3 24 25
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_3_10 loc_3_11 loc_3_12 right box3
2
170 0
175 0
4
0 0 28 29
0 4 24 25
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_3_10 loc_3_11 loc_3_12 right box4
2
170 0
175 0
4
0 0 28 29
0 2 24 25
0 86 -1 0
0 87 0 1
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box1
2
172 0
186 0
4
0 0 28 34
0 1 29 39
0 7 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box2
2
172 0
186 0
4
0 0 28 34
0 3 29 39
0 7 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box3
2
172 0
186 0
4
0 0 28 34
0 4 29 39
0 7 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_3_10 loc_4_10 loc_5_10 down box4
2
172 0
186 0
4
0 0 28 34
0 2 29 39
0 7 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box1
2
171 0
174 0
4
0 0 29 28
0 1 23 28
0 85 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box2
2
171 0
174 0
4
0 0 29 28
0 3 23 28
0 85 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box3
2
171 0
174 0
4
0 0 29 28
0 4 23 28
0 85 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_3_11 loc_3_10 loc_3_9 left box4
2
171 0
174 0
4
0 0 29 28
0 2 23 28
0 85 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_3_12 loc_3_11 loc_3_10 left box1
2
174 0
177 0
4
0 0 30 29
0 1 24 23
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_3_11 loc_3_10 left box2
2
174 0
177 0
4
0 0 30 29
0 3 24 23
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_3_11 loc_3_10 left box3
2
174 0
177 0
4
0 0 30 29
0 4 24 23
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_3_11 loc_3_10 left box4
2
174 0
177 0
4
0 0 30 29
0 2 24 23
0 85 0 1
0 86 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_4_12 loc_5_12 down box1
2
178 0
188 0
4
0 0 30 35
0 1 30 41
0 9 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_4_12 loc_5_12 down box2
2
178 0
188 0
4
0 0 30 35
0 3 30 41
0 9 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_4_12 loc_5_12 down box3
2
178 0
188 0
4
0 0 30 35
0 4 30 41
0 9 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_3_12 loc_4_12 loc_5_12 down box4
2
178 0
188 0
4
0 0 30 35
0 2 30 41
0 9 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box1
2
170 0
182 0
4
0 0 33 28
0 1 23 24
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box2
2
170 0
182 0
4
0 0 33 28
0 3 23 24
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box3
2
170 0
182 0
4
0 0 33 28
0 4 23 24
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_3_9 loc_3_10 loc_3_11 right box4
2
170 0
182 0
4
0 0 33 28
0 2 23 24
0 85 -1 0
0 86 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box1
2
183 0
214 0
4
0 0 33 43
0 1 38 49
0 6 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box2
2
183 0
214 0
4
0 0 33 43
0 3 38 49
0 6 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box3
2
183 0
214 0
4
0 0 33 43
0 4 38 49
0 6 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_3_9 loc_4_9 loc_5_9 down box4
2
183 0
214 0
4
0 0 33 43
0 2 38 49
0 6 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box1
2
185 0
213 0
4
0 0 34 43
0 1 38 37
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box2
2
185 0
213 0
4
0 0 34 43
0 3 38 37
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box3
2
185 0
213 0
4
0 0 34 43
0 4 38 37
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_4_9 loc_4_8 left box4
2
185 0
213 0
4
0 0 34 43
0 2 38 37
0 5 0 1
0 6 -1 0
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box1
2
186 0
218 0
4
0 0 34 44
0 1 39 50
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box2
2
186 0
218 0
4
0 0 34 44
0 3 39 50
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box3
2
186 0
218 0
4
0 0 34 44
0 4 39 50
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_4_10 loc_5_10 loc_6_10 down box4
2
186 0
218 0
4
0 0 34 44
0 2 39 50
0 7 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_4_12 loc_3_12 loc_2_12 up box1
2
176 0
187 0
4
0 0 35 30
0 1 25 21
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_4_12 loc_3_12 loc_2_12 up box2
2
176 0
187 0
4
0 0 35 30
0 3 25 21
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_4_12 loc_3_12 loc_2_12 up box3
2
176 0
187 0
4
0 0 35 30
0 4 25 21
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_4_12 loc_3_12 loc_2_12 up box4
2
176 0
187 0
4
0 0 35 30
0 2 25 21
0 81 0 1
0 87 -1 0
1
end_operator
begin_operator
push loc_4_12 loc_5_12 loc_6_12 down box1
2
188 0
224 0
4
0 0 35 46
0 1 41 52
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_12 loc_5_12 loc_6_12 down box2
2
188 0
224 0
4
0 0 35 46
0 3 41 52
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_12 loc_5_12 loc_6_12 down box3
2
188 0
224 0
4
0 0 35 46
0 4 41 52
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_12 loc_5_12 loc_6_12 down box4
2
188 0
224 0
4
0 0 35 46
0 2 41 52
0 9 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box1
2
189 0
192 0
4
0 0 36 37
0 1 32 33
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box2
2
189 0
192 0
4
0 0 36 37
0 3 32 33
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box3
2
189 0
192 0
4
0 0 36 37
0 4 32 33
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
push loc_4_2 loc_4_3 loc_4_4 right box4
2
189 0
192 0
4
0 0 36 37
0 2 32 33
0 94 -1 0
0 95 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box1
2
190 0
227 0
4
0 0 36 47
0 1 42 53
0 10 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box2
2
190 0
227 0
4
0 0 36 47
0 3 42 53
0 10 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box3
2
190 0
227 0
4
0 0 36 47
0 4 42 53
0 10 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_2 loc_5_2 loc_6_2 down box4
2
190 0
227 0
4
0 0 36 47
0 2 42 53
0 10 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box1
2
192 0
195 0
4
0 0 37 38
0 1 33 34
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box2
2
192 0
195 0
4
0 0 37 38
0 3 33 34
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box3
2
192 0
195 0
4
0 0 37 38
0 4 33 34
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_4_3 loc_4_4 loc_4_5 right box4
2
192 0
195 0
4
0 0 37 38
0 2 33 34
0 95 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box1
2
193 0
231 0
4
0 0 37 48
0 1 43 54
0 11 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box2
2
193 0
231 0
4
0 0 37 48
0 3 43 54
0 11 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box3
2
193 0
231 0
4
0 0 37 48
0 4 43 54
0 11 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_3 loc_5_3 loc_6_3 down box4
2
193 0
231 0
4
0 0 37 48
0 2 43 54
0 11 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box1
2
191 0
194 0
4
0 0 38 37
0 1 32 31
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box2
2
191 0
194 0
4
0 0 38 37
0 3 32 31
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box3
2
191 0
194 0
4
0 0 38 37
0 4 32 31
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_3 loc_4_2 left box4
2
191 0
194 0
4
0 0 38 37
0 2 32 31
0 93 0 1
0 94 -1 0
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box1
2
195 0
199 0
4
0 0 38 39
0 1 34 35
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box2
2
195 0
199 0
4
0 0 38 39
0 3 34 35
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box3
2
195 0
199 0
4
0 0 38 39
0 4 34 35
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_4_4 loc_4_5 loc_4_6 right box4
2
195 0
199 0
4
0 0 38 39
0 2 34 35
0 96 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
179 0
197 0
4
0 0 39 31
0 1 26 22
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box2
2
179 0
197 0
4
0 0 39 31
0 3 26 22
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box3
2
179 0
197 0
4
0 0 39 31
0 4 26 22
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box4
2
179 0
197 0
4
0 0 39 31
0 2 26 22
0 83 0 1
0 88 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box1
2
194 0
198 0
4
0 0 39 38
0 1 33 32
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box2
2
194 0
198 0
4
0 0 39 38
0 3 33 32
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box3
2
194 0
198 0
4
0 0 39 38
0 4 33 32
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_4 loc_4_3 left box4
2
194 0
198 0
4
0 0 39 38
0 2 33 32
0 94 0 1
0 95 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box1
2
199 0
202 0
4
0 0 39 40
0 1 35 36
0 97 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box2
2
199 0
202 0
4
0 0 39 40
0 3 35 36
0 97 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box3
2
199 0
202 0
4
0 0 39 40
0 4 35 36
0 97 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_5 loc_4_6 loc_4_7 right box4
2
199 0
202 0
4
0 0 39 40
0 2 35 36
0 97 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
200 0
238 0
4
0 0 39 50
0 1 45 55
0 13 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box2
2
200 0
238 0
4
0 0 39 50
0 3 45 55
0 13 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box3
2
200 0
238 0
4
0 0 39 50
0 4 45 55
0 13 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box4
2
200 0
238 0
4
0 0 39 50
0 2 45 55
0 13 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box1
2
198 0
201 0
4
0 0 40 39
0 1 34 33
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box2
2
198 0
201 0
4
0 0 40 39
0 3 34 33
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box3
2
198 0
201 0
4
0 0 40 39
0 4 34 33
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_5 loc_4_4 left box4
2
198 0
201 0
4
0 0 40 39
0 2 34 33
0 95 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box1
2
202 0
206 0
4
0 0 40 41
0 1 36 37
0 5 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box2
2
202 0
206 0
4
0 0 40 41
0 3 36 37
0 5 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box3
2
202 0
206 0
4
0 0 40 41
0 4 36 37
0 5 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_4_7 loc_4_8 right box4
2
202 0
206 0
4
0 0 40 41
0 2 36 37
0 5 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
203 0
242 0
4
0 0 40 51
0 1 46 56
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
203 0
242 0
4
0 0 40 51
0 3 46 56
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
203 0
242 0
4
0 0 40 51
0 4 46 56
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box4
2
203 0
242 0
4
0 0 40 51
0 2 46 56
0 14 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box1
2
201 0
205 0
4
0 0 41 40
0 1 35 34
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box2
2
201 0
205 0
4
0 0 41 40
0 3 35 34
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box3
2
201 0
205 0
4
0 0 41 40
0 4 35 34
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_6 loc_4_5 left box4
2
201 0
205 0
4
0 0 41 40
0 2 35 34
0 96 0 1
0 97 -1 0
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box1
2
206 0
209 0
4
0 0 41 42
0 1 37 38
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box2
2
206 0
209 0
4
0 0 41 42
0 3 37 38
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box3
2
206 0
209 0
4
0 0 41 42
0 4 37 38
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_4_7 loc_4_8 loc_4_9 right box4
2
206 0
209 0
4
0 0 41 42
0 2 37 38
0 5 -1 0
0 6 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box1
2
207 0
246 0
4
0 0 41 52
0 1 47 57
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box2
2
207 0
246 0
4
0 0 41 52
0 3 47 57
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box3
2
207 0
246 0
4
0 0 41 52
0 4 47 57
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_4_7 loc_5_7 loc_6_7 down box4
2
207 0
246 0
4
0 0 41 52
0 2 47 57
0 15 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box1
2
205 0
208 0
4
0 0 42 41
0 1 36 35
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box2
2
205 0
208 0
4
0 0 42 41
0 3 36 35
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box3
2
205 0
208 0
4
0 0 42 41
0 4 36 35
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_7 loc_4_6 left box4
2
205 0
208 0
4
0 0 42 41
0 2 36 35
0 97 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box1
2
209 0
212 0
4
0 0 42 43
0 1 38 29
0 6 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box2
2
209 0
212 0
4
0 0 42 43
0 3 38 29
0 6 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box3
2
209 0
212 0
4
0 0 42 43
0 4 38 29
0 6 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_4_8 loc_4_9 loc_4_10 right box4
2
209 0
212 0
4
0 0 42 43
0 2 38 29
0 6 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box1
2
210 0
250 0
4
0 0 42 53
0 1 48 58
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box2
2
210 0
250 0
4
0 0 42 53
0 3 48 58
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box3
2
210 0
250 0
4
0 0 42 53
0 4 48 58
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_4_8 loc_5_8 loc_6_8 down box4
2
210 0
250 0
4
0 0 42 53
0 2 48 58
0 16 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box1
2
208 0
213 0
4
0 0 43 42
0 1 37 36
0 5 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box2
2
208 0
213 0
4
0 0 43 42
0 3 37 36
0 5 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box3
2
208 0
213 0
4
0 0 43 42
0 4 37 36
0 5 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_4_9 loc_4_8 loc_4_7 left box4
2
208 0
213 0
4
0 0 43 42
0 2 37 36
0 5 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box1
2
184 0
215 0
4
0 0 44 34
0 1 29 23
0 85 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box2
2
184 0
215 0
4
0 0 44 34
0 3 29 23
0 85 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box3
2
184 0
215 0
4
0 0 44 34
0 4 29 23
0 85 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_4_10 loc_3_10 up box4
2
184 0
215 0
4
0 0 44 34
0 2 29 23
0 85 0 1
0 91 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_11 loc_5_12 right box1
2
216 0
220 0
4
0 0 44 45
0 1 40 41
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_11 loc_5_12 right box2
2
216 0
220 0
4
0 0 44 45
0 3 40 41
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_11 loc_5_12 right box3
2
216 0
220 0
4
0 0 44 45
0 4 40 41
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_11 loc_5_12 right box4
2
216 0
220 0
4
0 0 44 45
0 2 40 41
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box1
2
217 0
253 0
4
0 0 44 54
0 1 49 48
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box2
2
217 0
253 0
4
0 0 44 54
0 3 49 48
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box3
2
217 0
253 0
4
0 0 44 54
0 4 49 48
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_5_9 loc_5_8 left box4
2
217 0
253 0
4
0 0 44 54
0 2 49 48
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box1
2
218 0
256 0
4
0 0 44 55
0 1 50 59
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box2
2
218 0
256 0
4
0 0 44 55
0 3 50 59
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box3
2
218 0
256 0
4
0 0 44 55
0 4 50 59
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_5_10 loc_6_10 loc_7_10 down box4
2
218 0
256 0
4
0 0 44 55
0 2 50 59
0 18 -1 0
0 27 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box1
2
217 0
219 0
4
0 0 45 44
0 1 39 49
0 7 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box2
2
217 0
219 0
4
0 0 45 44
0 3 39 49
0 7 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box3
2
217 0
219 0
4
0 0 45 44
0 4 39 49
0 7 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_5_10 loc_5_9 left box4
2
217 0
219 0
4
0 0 45 44
0 2 39 49
0 7 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box1
2
221 0
260 0
4
0 0 45 56
0 1 51 60
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box2
2
221 0
260 0
4
0 0 45 56
0 3 51 60
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box3
2
221 0
260 0
4
0 0 45 56
0 4 51 60
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_11 loc_6_11 loc_7_11 down box4
2
221 0
260 0
4
0 0 45 56
0 2 51 60
0 19 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_5_12 loc_4_12 loc_3_12 up box1
2
187 0
222 0
4
0 0 46 35
0 1 30 25
0 87 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_4_12 loc_3_12 up box2
2
187 0
222 0
4
0 0 46 35
0 3 30 25
0 87 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_4_12 loc_3_12 up box3
2
187 0
222 0
4
0 0 46 35
0 4 30 25
0 87 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_4_12 loc_3_12 up box4
2
187 0
222 0
4
0 0 46 35
0 2 30 25
0 87 0 1
0 92 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_5_11 loc_5_10 left box1
2
219 0
223 0
4
0 0 46 45
0 1 40 39
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_5_11 loc_5_10 left box2
2
219 0
223 0
4
0 0 46 45
0 3 40 39
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_5_11 loc_5_10 left box3
2
219 0
223 0
4
0 0 46 45
0 4 40 39
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_5_11 loc_5_10 left box4
2
219 0
223 0
4
0 0 46 45
0 2 40 39
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_5_12 loc_6_12 loc_7_12 down box1
2
224 0
263 0
4
0 0 46 57
0 1 52 61
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_12 loc_6_12 loc_7_12 down box2
2
224 0
263 0
4
0 0 46 57
0 3 52 61
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_12 loc_6_12 loc_7_12 down box3
2
224 0
263 0
4
0 0 46 57
0 4 52 61
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_12 loc_6_12 loc_7_12 down box4
2
224 0
263 0
4
0 0 46 57
0 2 52 61
0 20 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box1
2
226 0
230 0
4
0 0 47 48
0 1 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box2
2
226 0
230 0
4
0 0 47 48
0 3 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box3
2
226 0
230 0
4
0 0 47 48
0 4 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_5_2 loc_5_3 loc_5_4 right box4
2
226 0
230 0
4
0 0 47 48
0 2 43 44
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box1
2
230 0
234 0
4
0 0 48 49
0 1 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box2
2
230 0
234 0
4
0 0 48 49
0 3 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box3
2
230 0
234 0
4
0 0 48 49
0 4 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_5_3 loc_5_4 loc_5_5 right box4
2
230 0
234 0
4
0 0 48 49
0 2 44 45
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box1
2
231 0
268 0
4
0 0 48 59
0 1 54 62
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box2
2
231 0
268 0
4
0 0 48 59
0 3 54 62
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box3
2
231 0
268 0
4
0 0 48 59
0 4 54 62
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_3 loc_6_3 loc_7_3 down box4
2
231 0
268 0
4
0 0 48 59
0 2 54 62
0 22 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box1
2
229 0
233 0
4
0 0 49 48
0 1 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box2
2
229 0
233 0
4
0 0 49 48
0 3 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box3
2
229 0
233 0
4
0 0 49 48
0 4 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_3 loc_5_2 left box4
2
229 0
233 0
4
0 0 49 48
0 2 43 42
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box1
2
234 0
237 0
4
0 0 49 50
0 1 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box2
2
234 0
237 0
4
0 0 49 50
0 3 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box3
2
234 0
237 0
4
0 0 49 50
0 4 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_5_4 loc_5_5 loc_5_6 right box4
2
234 0
237 0
4
0 0 49 50
0 2 45 46
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
197 0
235 0
4
0 0 50 39
0 1 34 26
0 88 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
197 0
235 0
4
0 0 50 39
0 3 34 26
0 88 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
197 0
235 0
4
0 0 50 39
0 4 34 26
0 88 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box4
2
197 0
235 0
4
0 0 50 39
0 2 34 26
0 88 0 1
0 96 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box1
2
233 0
236 0
4
0 0 50 49
0 1 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box2
2
233 0
236 0
4
0 0 50 49
0 3 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box3
2
233 0
236 0
4
0 0 50 49
0 4 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_4 loc_5_3 left box4
2
233 0
236 0
4
0 0 50 49
0 2 44 43
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
237 0
241 0
4
0 0 50 51
0 1 46 47
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
237 0
241 0
4
0 0 50 51
0 3 46 47
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
237 0
241 0
4
0 0 50 51
0 4 46 47
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box4
2
237 0
241 0
4
0 0 50 51
0 2 46 47
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
238 0
271 0
4
0 0 50 60
0 1 55 64
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box2
2
238 0
271 0
4
0 0 50 60
0 3 55 64
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box3
2
238 0
271 0
4
0 0 50 60
0 4 55 64
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box4
2
238 0
271 0
4
0 0 50 60
0 2 55 64
0 23 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box1
2
236 0
240 0
4
0 0 51 50
0 1 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box2
2
236 0
240 0
4
0 0 51 50
0 3 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box3
2
236 0
240 0
4
0 0 51 50
0 4 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_5 loc_5_4 left box4
2
236 0
240 0
4
0 0 51 50
0 2 45 44
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
241 0
245 0
4
0 0 51 52
0 1 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
241 0
245 0
4
0 0 51 52
0 3 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
241 0
245 0
4
0 0 51 52
0 4 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box4
2
241 0
245 0
4
0 0 51 52
0 2 47 48
0 15 -1 0
0 16 0 1
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box1
2
204 0
243 0
4
0 0 52 41
0 1 36 27
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box2
2
204 0
243 0
4
0 0 52 41
0 3 36 27
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box3
2
204 0
243 0
4
0 0 52 41
0 4 36 27
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_4_7 loc_3_7 up box4
2
204 0
243 0
4
0 0 52 41
0 2 36 27
0 89 0 1
0 98 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
240 0
244 0
4
0 0 52 51
0 1 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
240 0
244 0
4
0 0 52 51
0 3 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
240 0
244 0
4
0 0 52 51
0 4 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box4
2
240 0
244 0
4
0 0 52 51
0 2 46 45
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
245 0
249 0
4
0 0 52 53
0 1 48 49
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
245 0
249 0
4
0 0 52 53
0 3 48 49
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
245 0
249 0
4
0 0 52 53
0 4 48 49
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box4
2
245 0
249 0
4
0 0 52 53
0 2 48 49
0 16 -1 0
0 17 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
244 0
248 0
4
0 0 53 52
0 1 47 46
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
244 0
248 0
4
0 0 53 52
0 3 47 46
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
244 0
248 0
4
0 0 53 52
0 4 47 46
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box4
2
244 0
248 0
4
0 0 53 52
0 2 47 46
0 14 0 1
0 15 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box1
2
249 0
252 0
4
0 0 53 54
0 1 49 39
0 7 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box2
2
249 0
252 0
4
0 0 53 54
0 3 49 39
0 7 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box3
2
249 0
252 0
4
0 0 53 54
0 4 49 39
0 7 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_9 loc_5_10 right box4
2
249 0
252 0
4
0 0 53 54
0 2 49 39
0 7 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box1
2
211 0
251 0
4
0 0 54 43
0 1 38 28
0 6 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box2
2
211 0
251 0
4
0 0 54 43
0 3 38 28
0 6 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box3
2
211 0
251 0
4
0 0 54 43
0 4 38 28
0 6 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_4_9 loc_3_9 up box4
2
211 0
251 0
4
0 0 54 43
0 2 38 28
0 6 -1 0
0 90 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box1
2
216 0
252 0
4
0 0 54 44
0 1 39 40
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box2
2
216 0
252 0
4
0 0 54 44
0 3 39 40
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box3
2
216 0
252 0
4
0 0 54 44
0 4 39 40
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_10 loc_5_11 right box4
2
216 0
252 0
4
0 0 54 44
0 2 39 40
0 7 -1 0
0 8 0 1
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
248 0
253 0
4
0 0 54 53
0 1 48 47
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
248 0
253 0
4
0 0 54 53
0 3 48 47
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
248 0
253 0
4
0 0 54 53
0 4 48 47
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box4
2
248 0
253 0
4
0 0 54 53
0 2 48 47
0 15 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box1
2
215 0
254 0
4
0 0 55 44
0 1 39 29
0 7 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box2
2
215 0
254 0
4
0 0 55 44
0 3 39 29
0 7 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box3
2
215 0
254 0
4
0 0 55 44
0 4 39 29
0 7 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_6_10 loc_5_10 loc_4_10 up box4
2
215 0
254 0
4
0 0 55 44
0 2 39 29
0 7 -1 0
0 91 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_11 loc_6_12 right box1
2
255 0
259 0
4
0 0 55 56
0 1 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_11 loc_6_12 right box2
2
255 0
259 0
4
0 0 55 56
0 3 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_11 loc_6_12 right box3
2
255 0
259 0
4
0 0 55 56
0 4 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_6_10 loc_6_11 loc_6_12 right box4
2
255 0
259 0
4
0 0 55 56
0 2 51 52
0 19 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box1
2
256 0
283 0
4
0 0 55 64
0 1 59 66
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box2
2
256 0
283 0
4
0 0 55 64
0 3 59 66
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box3
2
256 0
283 0
4
0 0 55 64
0 4 59 66
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_10 loc_7_10 loc_8_10 down box4
2
256 0
283 0
4
0 0 55 64
0 2 59 66
0 27 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box1
2
260 0
287 0
4
0 0 56 65
0 1 60 67
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box2
2
260 0
287 0
4
0 0 56 65
0 3 60 67
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box3
2
260 0
287 0
4
0 0 56 65
0 4 60 67
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_6_11 loc_7_11 loc_8_11 down box4
2
260 0
287 0
4
0 0 56 65
0 2 60 67
0 28 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_6_12 loc_5_12 loc_4_12 up box1
2
222 0
261 0
4
0 0 57 46
0 1 41 30
0 9 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_6_12 loc_5_12 loc_4_12 up box2
2
222 0
261 0
4
0 0 57 46
0 3 41 30
0 9 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_6_12 loc_5_12 loc_4_12 up box3
2
222 0
261 0
4
0 0 57 46
0 4 41 30
0 9 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_6_12 loc_5_12 loc_4_12 up box4
2
222 0
261 0
4
0 0 57 46
0 2 41 30
0 9 -1 0
0 92 0 1
1
end_operator
begin_operator
push loc_6_12 loc_6_11 loc_6_10 left box1
2
258 0
262 0
4
0 0 57 56
0 1 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_12 loc_6_11 loc_6_10 left box2
2
258 0
262 0
4
0 0 57 56
0 3 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_12 loc_6_11 loc_6_10 left box3
2
258 0
262 0
4
0 0 57 56
0 4 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_12 loc_6_11 loc_6_10 left box4
2
258 0
262 0
4
0 0 57 56
0 2 51 50
0 18 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_6_12 loc_7_12 loc_8_12 down box1
2
263 0
290 0
4
0 0 57 66
0 1 61 68
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_12 loc_7_12 loc_8_12 down box2
2
263 0
290 0
4
0 0 57 66
0 3 61 68
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_12 loc_7_12 loc_8_12 down box3
2
263 0
290 0
4
0 0 57 66
0 4 61 68
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_12 loc_7_12 loc_8_12 down box4
2
263 0
290 0
4
0 0 57 66
0 2 61 68
0 29 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box1
2
225 0
264 0
4
0 0 58 47
0 1 42 31
0 10 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box2
2
225 0
264 0
4
0 0 58 47
0 3 42 31
0 10 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box3
2
225 0
264 0
4
0 0 58 47
0 4 42 31
0 10 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_6_2 loc_5_2 loc_4_2 up box4
2
225 0
264 0
4
0 0 58 47
0 2 42 31
0 10 -1 0
0 93 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box1
2
228 0
266 0
4
0 0 59 48
0 1 43 32
0 11 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box2
2
228 0
266 0
4
0 0 59 48
0 3 43 32
0 11 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box3
2
228 0
266 0
4
0 0 59 48
0 4 43 32
0 11 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_6_3 loc_5_3 loc_4_3 up box4
2
228 0
266 0
4
0 0 59 48
0 2 43 32
0 11 -1 0
0 94 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box1
2
268 0
293 0
4
0 0 59 67
0 1 62 70
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box2
2
268 0
293 0
4
0 0 59 67
0 3 62 70
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box3
2
268 0
293 0
4
0 0 59 67
0 4 62 70
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_6_3 loc_7_3 loc_8_3 down box4
2
268 0
293 0
4
0 0 59 67
0 2 62 70
0 30 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
235 0
269 0
4
0 0 60 50
0 1 45 34
0 13 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box2
2
235 0
269 0
4
0 0 60 50
0 3 45 34
0 13 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box3
2
235 0
269 0
4
0 0 60 50
0 4 45 34
0 13 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box4
2
235 0
269 0
4
0 0 60 50
0 2 45 34
0 13 -1 0
0 96 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
270 0
274 0
4
0 0 60 61
0 1 56 57
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
270 0
274 0
4
0 0 60 61
0 3 56 57
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
270 0
274 0
4
0 0 60 61
0 4 56 57
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box4
2
270 0
274 0
4
0 0 60 61
0 2 56 57
0 24 -1 0
0 25 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box1
2
271 0
299 0
4
0 0 60 69
0 1 64 72
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box2
2
271 0
299 0
4
0 0 60 69
0 3 64 72
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box3
2
271 0
299 0
4
0 0 60 69
0 4 64 72
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box4
2
271 0
299 0
4
0 0 60 69
0 2 64 72
0 32 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
239 0
272 0
4
0 0 61 51
0 1 46 35
0 14 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
239 0
272 0
4
0 0 61 51
0 3 46 35
0 14 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
239 0
272 0
4
0 0 61 51
0 4 46 35
0 14 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box4
2
239 0
272 0
4
0 0 61 51
0 2 46 35
0 14 -1 0
0 97 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box1
2
274 0
277 0
4
0 0 61 62
0 1 57 58
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box2
2
274 0
277 0
4
0 0 61 62
0 3 57 58
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box3
2
274 0
277 0
4
0 0 61 62
0 4 57 58
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_6 loc_6_7 loc_6_8 right box4
2
274 0
277 0
4
0 0 61 62
0 2 57 58
0 25 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box1
2
243 0
275 0
4
0 0 62 52
0 1 47 36
0 15 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box2
2
243 0
275 0
4
0 0 62 52
0 3 47 36
0 15 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box3
2
243 0
275 0
4
0 0 62 52
0 4 47 36
0 15 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_6_7 loc_5_7 loc_4_7 up box4
2
243 0
275 0
4
0 0 62 52
0 2 47 36
0 15 -1 0
0 98 0 1
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
273 0
276 0
4
0 0 62 61
0 1 56 55
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
273 0
276 0
4
0 0 62 61
0 3 56 55
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
273 0
276 0
4
0 0 62 61
0 4 56 55
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box4
2
273 0
276 0
4
0 0 62 61
0 2 56 55
0 23 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box1
2
247 0
278 0
4
0 0 63 53
0 1 48 37
0 5 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box2
2
247 0
278 0
4
0 0 63 53
0 3 48 37
0 5 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box3
2
247 0
278 0
4
0 0 63 53
0 4 48 37
0 5 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_5_8 loc_4_8 up box4
2
247 0
278 0
4
0 0 63 53
0 2 48 37
0 5 0 1
0 16 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box1
2
276 0
279 0
4
0 0 63 62
0 1 57 56
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box2
2
276 0
279 0
4
0 0 63 62
0 3 57 56
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box3
2
276 0
279 0
4
0 0 63 62
0 4 57 56
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_6_8 loc_6_7 loc_6_6 left box4
2
276 0
279 0
4
0 0 63 62
0 2 57 56
0 24 0 1
0 25 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box1
2
254 0
280 0
4
0 0 64 55
0 1 50 39
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box2
2
254 0
280 0
4
0 0 64 55
0 3 50 39
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box3
2
254 0
280 0
4
0 0 64 55
0 4 50 39
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_6_10 loc_5_10 up box4
2
254 0
280 0
4
0 0 64 55
0 2 50 39
0 7 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box1
2
281 0
286 0
4
0 0 64 65
0 1 60 61
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box2
2
281 0
286 0
4
0 0 64 65
0 3 60 61
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box3
2
281 0
286 0
4
0 0 64 65
0 4 60 61
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box4
2
281 0
286 0
4
0 0 64 65
0 2 60 61
0 28 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
283 0
305 0
4
0 0 64 71
0 1 66 77
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
283 0
305 0
4
0 0 64 71
0 3 66 77
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
283 0
305 0
4
0 0 64 71
0 4 66 77
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box4
2
283 0
305 0
4
0 0 64 71
0 2 66 77
0 34 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box1
2
257 0
284 0
4
0 0 65 56
0 1 51 40
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box2
2
257 0
284 0
4
0 0 65 56
0 3 51 40
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box3
2
257 0
284 0
4
0 0 65 56
0 4 51 40
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_6_11 loc_5_11 up box4
2
257 0
284 0
4
0 0 65 56
0 2 51 40
0 8 0 1
0 19 -1 0
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
282 0
285 0
4
0 0 65 64
0 1 59 65
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
282 0
285 0
4
0 0 65 64
0 3 59 65
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
282 0
285 0
4
0 0 65 64
0 4 59 65
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box4
2
282 0
285 0
4
0 0 65 64
0 2 59 65
0 27 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
287 0
309 0
4
0 0 65 72
0 1 67 78
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
287 0
309 0
4
0 0 65 72
0 3 67 78
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
287 0
309 0
4
0 0 65 72
0 4 67 78
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box4
2
287 0
309 0
4
0 0 65 72
0 2 67 78
0 35 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_7_12 loc_6_12 loc_5_12 up box1
2
261 0
288 0
4
0 0 66 57
0 1 52 41
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_6_12 loc_5_12 up box2
2
261 0
288 0
4
0 0 66 57
0 3 52 41
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_6_12 loc_5_12 up box3
2
261 0
288 0
4
0 0 66 57
0 4 52 41
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_6_12 loc_5_12 up box4
2
261 0
288 0
4
0 0 66 57
0 2 52 41
0 9 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box1
2
285 0
289 0
4
0 0 66 65
0 1 60 59
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box2
2
285 0
289 0
4
0 0 66 65
0 3 60 59
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box3
2
285 0
289 0
4
0 0 66 65
0 4 60 59
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box4
2
285 0
289 0
4
0 0 66 65
0 2 60 59
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box1
2
290 0
312 0
4
0 0 66 73
0 1 68 79
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box2
2
290 0
312 0
4
0 0 66 73
0 3 68 79
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box3
2
290 0
312 0
4
0 0 66 73
0 4 68 79
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box4
2
290 0
312 0
4
0 0 66 73
0 2 68 79
0 36 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box1
2
266 0
291 0
4
0 0 67 59
0 1 54 43
0 11 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box2
2
266 0
291 0
4
0 0 67 59
0 3 54 43
0 11 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box3
2
266 0
291 0
4
0 0 67 59
0 4 54 43
0 11 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_6_3 loc_5_3 up box4
2
266 0
291 0
4
0 0 67 59
0 2 54 43
0 11 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box1
2
292 0
295 0
4
0 0 67 68
0 1 63 64
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box2
2
292 0
295 0
4
0 0 67 68
0 3 63 64
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box3
2
292 0
295 0
4
0 0 67 68
0 4 63 64
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_7_3 loc_7_4 loc_7_5 right box4
2
292 0
295 0
4
0 0 67 68
0 2 63 64
0 31 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box1
2
293 0
318 0
4
0 0 67 75
0 1 70 81
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box2
2
293 0
318 0
4
0 0 67 75
0 3 70 81
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box3
2
293 0
318 0
4
0 0 67 75
0 4 70 81
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_7_3 loc_8_3 loc_9_3 down box4
2
293 0
318 0
4
0 0 67 75
0 2 70 81
0 38 -1 0
0 49 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
296 0
322 0
4
0 0 68 76
0 1 71 82
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
296 0
322 0
4
0 0 68 76
0 3 71 82
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box3
2
296 0
322 0
4
0 0 68 76
0 4 71 82
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box4
2
296 0
322 0
4
0 0 68 76
0 2 71 82
0 39 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
269 0
297 0
4
0 0 69 60
0 1 55 45
0 13 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box2
2
269 0
297 0
4
0 0 69 60
0 3 55 45
0 13 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box3
2
269 0
297 0
4
0 0 69 60
0 4 55 45
0 13 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box4
2
269 0
297 0
4
0 0 69 60
0 2 55 45
0 13 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box1
2
294 0
298 0
4
0 0 69 68
0 1 63 62
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box2
2
294 0
298 0
4
0 0 69 68
0 3 63 62
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box3
2
294 0
298 0
4
0 0 69 68
0 4 63 62
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_7_4 loc_7_3 left box4
2
294 0
298 0
4
0 0 69 68
0 2 63 62
0 30 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box1
2
299 0
326 0
4
0 0 69 77
0 1 72 83
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box2
2
299 0
326 0
4
0 0 69 77
0 3 72 83
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box3
2
299 0
326 0
4
0 0 69 77
0 4 72 83
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box4
2
299 0
326 0
4
0 0 69 77
0 2 72 83
0 40 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
281 0
300 0
4
0 0 70 64
0 1 59 60
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
281 0
300 0
4
0 0 70 64
0 3 59 60
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
281 0
300 0
4
0 0 70 64
0 4 59 60
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box4
2
281 0
300 0
4
0 0 70 64
0 2 59 60
0 27 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
301 0
339 0
4
0 0 70 81
0 1 76 87
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
301 0
339 0
4
0 0 70 81
0 3 76 87
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
301 0
339 0
4
0 0 70 81
0 4 76 87
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box4
2
301 0
339 0
4
0 0 70 81
0 2 76 87
0 44 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box1
2
280 0
302 0
4
0 0 71 64
0 1 59 50
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box2
2
280 0
302 0
4
0 0 71 64
0 3 59 50
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box3
2
280 0
302 0
4
0 0 71 64
0 4 59 50
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_7_10 loc_6_10 up box4
2
280 0
302 0
4
0 0 71 64
0 2 59 50
0 18 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box1
2
303 0
308 0
4
0 0 71 72
0 1 67 68
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box2
2
303 0
308 0
4
0 0 71 72
0 3 67 68
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box3
2
303 0
308 0
4
0 0 71 72
0 4 67 68
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box4
2
303 0
308 0
4
0 0 71 72
0 2 67 68
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
304 0
338 0
4
0 0 71 81
0 1 76 75
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
304 0
338 0
4
0 0 71 81
0 3 76 75
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box3
2
304 0
338 0
4
0 0 71 81
0 4 76 75
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box4
2
304 0
338 0
4
0 0 71 81
0 2 76 75
0 43 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box1
2
305 0
340 0
4
0 0 71 82
0 1 77 0
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box2
2
305 0
340 0
4
0 0 71 82
0 3 77 0
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box3
2
305 0
340 0
4
0 0 71 82
0 4 77 0
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_8_10 loc_9_10 loc_10_10 down box4
2
305 0
340 0
4
0 0 71 82
0 2 77 0
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
284 0
306 0
4
0 0 72 65
0 1 60 51
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
284 0
306 0
4
0 0 72 65
0 3 60 51
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
284 0
306 0
4
0 0 72 65
0 4 60 51
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box4
2
284 0
306 0
4
0 0 72 65
0 2 60 51
0 19 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
304 0
307 0
4
0 0 72 71
0 1 66 76
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
304 0
307 0
4
0 0 72 71
0 3 66 76
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
304 0
307 0
4
0 0 72 71
0 4 66 76
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box4
2
304 0
307 0
4
0 0 72 71
0 2 66 76
0 34 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
309 0
344 0
4
0 0 72 83
0 1 78 1
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
309 0
344 0
4
0 0 72 83
0 3 78 1
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
309 0
344 0
4
0 0 72 83
0 4 78 1
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box4
2
309 0
344 0
4
0 0 72 83
0 2 78 1
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box1
2
288 0
310 0
4
0 0 73 66
0 1 61 52
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box2
2
288 0
310 0
4
0 0 73 66
0 3 61 52
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box3
2
288 0
310 0
4
0 0 73 66
0 4 61 52
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_7_12 loc_6_12 up box4
2
288 0
310 0
4
0 0 73 66
0 2 61 52
0 20 0 1
0 29 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box1
2
307 0
311 0
4
0 0 73 72
0 1 67 66
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box2
2
307 0
311 0
4
0 0 73 72
0 3 67 66
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box3
2
307 0
311 0
4
0 0 73 72
0 4 67 66
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box4
2
307 0
311 0
4
0 0 73 72
0 2 67 66
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box1
2
313 0
317 0
4
0 0 74 75
0 1 70 71
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box2
2
313 0
317 0
4
0 0 74 75
0 3 70 71
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box3
2
313 0
317 0
4
0 0 74 75
0 4 70 71
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_8_2 loc_8_3 loc_8_4 right box4
2
313 0
317 0
4
0 0 74 75
0 2 70 71
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box1
2
291 0
315 0
4
0 0 75 67
0 1 62 54
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box2
2
291 0
315 0
4
0 0 75 67
0 3 62 54
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box3
2
291 0
315 0
4
0 0 75 67
0 4 62 54
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_7_3 loc_6_3 up box4
2
291 0
315 0
4
0 0 75 67
0 2 62 54
0 22 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box1
2
317 0
321 0
4
0 0 75 76
0 1 71 72
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box2
2
317 0
321 0
4
0 0 75 76
0 3 71 72
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box3
2
317 0
321 0
4
0 0 75 76
0 4 71 72
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_8_3 loc_8_4 loc_8_5 right box4
2
317 0
321 0
4
0 0 75 76
0 2 71 72
0 39 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box1
2
318 0
352 0
4
0 0 75 86
0 1 81 2
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box2
2
318 0
352 0
4
0 0 75 86
0 3 81 2
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box3
2
318 0
352 0
4
0 0 75 86
0 4 81 2
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_8_3 loc_9_3 loc_10_3 down box4
2
318 0
352 0
4
0 0 75 86
0 2 81 2
0 49 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box1
2
316 0
320 0
4
0 0 76 75
0 1 70 69
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box2
2
316 0
320 0
4
0 0 76 75
0 3 70 69
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box3
2
316 0
320 0
4
0 0 76 75
0 4 70 69
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_3 loc_8_2 left box4
2
316 0
320 0
4
0 0 76 75
0 2 70 69
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box1
2
321 0
325 0
4
0 0 76 77
0 1 72 73
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box2
2
321 0
325 0
4
0 0 76 77
0 3 72 73
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box3
2
321 0
325 0
4
0 0 76 77
0 4 72 73
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box4
2
321 0
325 0
4
0 0 76 77
0 2 72 73
0 40 -1 0
0 41 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box1
2
322 0
356 0
4
0 0 76 87
0 1 82 3
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box2
2
322 0
356 0
4
0 0 76 87
0 3 82 3
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box3
2
322 0
356 0
4
0 0 76 87
0 4 82 3
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box4
2
322 0
356 0
4
0 0 76 87
0 2 82 3
0 50 -1 0
0 59 0 1
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box1
2
297 0
323 0
4
0 0 77 69
0 1 64 55
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box2
2
297 0
323 0
4
0 0 77 69
0 3 64 55
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box3
2
297 0
323 0
4
0 0 77 69
0 4 64 55
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box4
2
297 0
323 0
4
0 0 77 69
0 2 64 55
0 23 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box1
2
320 0
324 0
4
0 0 77 76
0 1 71 70
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box2
2
320 0
324 0
4
0 0 77 76
0 3 71 70
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box3
2
320 0
324 0
4
0 0 77 76
0 4 71 70
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_4 loc_8_3 left box4
2
320 0
324 0
4
0 0 77 76
0 2 71 70
0 38 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
325 0
328 0
4
0 0 77 78
0 1 73 74
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
325 0
328 0
4
0 0 77 78
0 3 73 74
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
325 0
328 0
4
0 0 77 78
0 4 73 74
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box4
2
325 0
328 0
4
0 0 77 78
0 2 73 74
0 41 -1 0
0 42 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box1
2
326 0
360 0
4
0 0 77 88
0 1 83 4
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box2
2
326 0
360 0
4
0 0 77 88
0 3 83 4
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box3
2
326 0
360 0
4
0 0 77 88
0 4 83 4
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box4
2
326 0
360 0
4
0 0 77 88
0 2 83 4
0 51 -1 0
0 60 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
324 0
327 0
4
0 0 78 77
0 1 72 71
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
324 0
327 0
4
0 0 78 77
0 3 72 71
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box3
2
324 0
327 0
4
0 0 78 77
0 4 72 71
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box4
2
324 0
327 0
4
0 0 78 77
0 2 72 71
0 39 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box1
2
328 0
331 0
4
0 0 78 79
0 1 74 75
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box2
2
328 0
331 0
4
0 0 78 79
0 3 74 75
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box3
2
328 0
331 0
4
0 0 78 79
0 4 74 75
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box4
2
328 0
331 0
4
0 0 78 79
0 2 74 75
0 42 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box1
2
329 0
364 0
4
0 0 78 89
0 1 84 5
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box2
2
329 0
364 0
4
0 0 78 89
0 3 84 5
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box3
2
329 0
364 0
4
0 0 78 89
0 4 84 5
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box4
2
329 0
364 0
4
0 0 78 89
0 2 84 5
0 52 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
327 0
330 0
4
0 0 79 78
0 1 73 72
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
327 0
330 0
4
0 0 79 78
0 3 73 72
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
327 0
330 0
4
0 0 79 78
0 4 73 72
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box4
2
327 0
330 0
4
0 0 79 78
0 2 73 72
0 40 0 1
0 41 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
331 0
334 0
4
0 0 79 80
0 1 75 76
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
331 0
334 0
4
0 0 79 80
0 3 75 76
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box3
2
331 0
334 0
4
0 0 79 80
0 4 75 76
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box4
2
331 0
334 0
4
0 0 79 80
0 2 75 76
0 43 -1 0
0 44 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
332 0
368 0
4
0 0 79 90
0 1 85 6
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
332 0
368 0
4
0 0 79 90
0 3 85 6
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
332 0
368 0
4
0 0 79 90
0 4 85 6
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box4
2
332 0
368 0
4
0 0 79 90
0 2 85 6
0 53 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box1
2
330 0
333 0
4
0 0 80 79
0 1 74 73
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box2
2
330 0
333 0
4
0 0 80 79
0 3 74 73
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box3
2
330 0
333 0
4
0 0 80 79
0 4 74 73
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box4
2
330 0
333 0
4
0 0 80 79
0 2 74 73
0 41 0 1
0 42 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
334 0
337 0
4
0 0 80 81
0 1 76 66
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
334 0
337 0
4
0 0 80 81
0 3 76 66
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box3
2
334 0
337 0
4
0 0 80 81
0 4 76 66
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box4
2
334 0
337 0
4
0 0 80 81
0 2 76 66
0 34 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box1
2
335 0
372 0
4
0 0 80 91
0 1 86 7
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box2
2
335 0
372 0
4
0 0 80 91
0 3 86 7
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box3
2
335 0
372 0
4
0 0 80 91
0 4 86 7
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_8_8 loc_9_8 loc_10_8 down box4
2
335 0
372 0
4
0 0 80 91
0 2 86 7
0 54 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
303 0
337 0
4
0 0 81 71
0 1 66 67
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
303 0
337 0
4
0 0 81 71
0 3 66 67
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
303 0
337 0
4
0 0 81 71
0 4 66 67
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box4
2
303 0
337 0
4
0 0 81 71
0 2 66 67
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
333 0
338 0
4
0 0 81 80
0 1 75 74
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
333 0
338 0
4
0 0 81 80
0 3 75 74
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box3
2
333 0
338 0
4
0 0 81 80
0 4 75 74
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box4
2
333 0
338 0
4
0 0 81 80
0 2 75 74
0 42 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
302 0
341 0
4
0 0 82 71
0 1 66 59
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
302 0
341 0
4
0 0 82 71
0 3 66 59
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
302 0
341 0
4
0 0 82 71
0 4 66 59
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box4
2
302 0
341 0
4
0 0 82 71
0 2 66 59
0 27 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box1
2
342 0
347 0
4
0 0 82 83
0 1 78 79
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box2
2
342 0
347 0
4
0 0 82 83
0 3 78 79
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box3
2
342 0
347 0
4
0 0 82 83
0 4 78 79
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box4
2
342 0
347 0
4
0 0 82 83
0 2 78 79
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box1
2
343 0
378 0
4
0 0 82 92
0 1 87 86
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box2
2
343 0
378 0
4
0 0 82 92
0 3 87 86
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box3
2
343 0
378 0
4
0 0 82 92
0 4 87 86
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_9 loc_9_8 left box4
2
343 0
378 0
4
0 0 82 92
0 2 87 86
0 54 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box1
2
102 0
344 0
4
0 0 83 1
0 1 1 8
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box2
2
102 0
344 0
4
0 0 83 1
0 3 1 8
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box3
2
102 0
344 0
4
0 0 83 1
0 4 1 8
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box4
2
102 0
344 0
4
0 0 83 1
0 2 1 8
0 57 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
306 0
345 0
4
0 0 83 72
0 1 67 60
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
306 0
345 0
4
0 0 83 72
0 3 67 60
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
306 0
345 0
4
0 0 83 72
0 4 67 60
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box4
2
306 0
345 0
4
0 0 83 72
0 2 67 60
0 28 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
343 0
346 0
4
0 0 83 82
0 1 77 87
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
343 0
346 0
4
0 0 83 82
0 3 77 87
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
343 0
346 0
4
0 0 83 82
0 4 77 87
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box4
2
343 0
346 0
4
0 0 83 82
0 2 77 87
0 45 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box1
2
310 0
348 0
4
0 0 84 73
0 1 68 61
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box2
2
310 0
348 0
4
0 0 84 73
0 3 68 61
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box3
2
310 0
348 0
4
0 0 84 73
0 4 68 61
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box4
2
310 0
348 0
4
0 0 84 73
0 2 68 61
0 29 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box1
2
346 0
349 0
4
0 0 84 83
0 1 78 77
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box2
2
346 0
349 0
4
0 0 84 83
0 3 78 77
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box3
2
346 0
349 0
4
0 0 84 83
0 4 78 77
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box4
2
346 0
349 0
4
0 0 84 83
0 2 78 77
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box1
2
351 0
355 0
4
0 0 85 86
0 1 81 82
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box2
2
351 0
355 0
4
0 0 85 86
0 3 81 82
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box3
2
351 0
355 0
4
0 0 85 86
0 4 81 82
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box4
2
351 0
355 0
4
0 0 85 86
0 2 81 82
0 49 -1 0
0 50 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box1
2
105 0
352 0
4
0 0 86 2
0 1 2 10
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box2
2
105 0
352 0
4
0 0 86 2
0 3 2 10
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box3
2
105 0
352 0
4
0 0 86 2
0 4 2 10
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_3 loc_10_3 loc_11_3 down box4
2
105 0
352 0
4
0 0 86 2
0 2 2 10
0 58 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box1
2
315 0
353 0
4
0 0 86 75
0 1 70 62
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box2
2
315 0
353 0
4
0 0 86 75
0 3 70 62
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box3
2
315 0
353 0
4
0 0 86 75
0 4 70 62
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_8_3 loc_7_3 up box4
2
315 0
353 0
4
0 0 86 75
0 2 70 62
0 30 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
355 0
359 0
4
0 0 86 87
0 1 82 83
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
355 0
359 0
4
0 0 86 87
0 3 82 83
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
355 0
359 0
4
0 0 86 87
0 4 82 83
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box4
2
355 0
359 0
4
0 0 86 87
0 2 82 83
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box1
2
109 0
356 0
4
0 0 87 3
0 1 3 11
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box2
2
109 0
356 0
4
0 0 87 3
0 3 3 11
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box3
2
109 0
356 0
4
0 0 87 3
0 4 3 11
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box4
2
109 0
356 0
4
0 0 87 3
0 2 3 11
0 59 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
319 0
357 0
4
0 0 87 76
0 1 71 63
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
319 0
357 0
4
0 0 87 76
0 3 71 63
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box3
2
319 0
357 0
4
0 0 87 76
0 4 71 63
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box4
2
319 0
357 0
4
0 0 87 76
0 2 71 63
0 31 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box1
2
354 0
358 0
4
0 0 87 86
0 1 81 80
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box2
2
354 0
358 0
4
0 0 87 86
0 3 81 80
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box3
2
354 0
358 0
4
0 0 87 86
0 4 81 80
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box4
2
354 0
358 0
4
0 0 87 86
0 2 81 80
0 48 0 1
0 49 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
359 0
363 0
4
0 0 87 88
0 1 83 84
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
359 0
363 0
4
0 0 87 88
0 3 83 84
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
359 0
363 0
4
0 0 87 88
0 4 83 84
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box4
2
359 0
363 0
4
0 0 87 88
0 2 83 84
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
113 0
360 0
4
0 0 88 4
0 1 4 12
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
113 0
360 0
4
0 0 88 4
0 3 4 12
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
113 0
360 0
4
0 0 88 4
0 4 4 12
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box4
2
113 0
360 0
4
0 0 88 4
0 2 4 12
0 60 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
323 0
361 0
4
0 0 88 77
0 1 72 64
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
323 0
361 0
4
0 0 88 77
0 3 72 64
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box3
2
323 0
361 0
4
0 0 88 77
0 4 72 64
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box4
2
323 0
361 0
4
0 0 88 77
0 2 72 64
0 32 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
358 0
362 0
4
0 0 88 87
0 1 82 81
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
358 0
362 0
4
0 0 88 87
0 3 82 81
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
358 0
362 0
4
0 0 88 87
0 4 82 81
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box4
2
358 0
362 0
4
0 0 88 87
0 2 82 81
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
363 0
367 0
4
0 0 88 89
0 1 84 85
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
363 0
367 0
4
0 0 88 89
0 3 84 85
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
363 0
367 0
4
0 0 88 89
0 4 84 85
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box4
2
363 0
367 0
4
0 0 88 89
0 2 84 85
0 52 -1 0
0 53 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box1
2
117 0
364 0
4
0 0 89 5
0 1 5 13
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box2
2
117 0
364 0
4
0 0 89 5
0 3 5 13
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box3
2
117 0
364 0
4
0 0 89 5
0 4 5 13
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_9_6 loc_10_6 loc_11_6 down box4
2
117 0
364 0
4
0 0 89 5
0 2 5 13
0 61 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
362 0
366 0
4
0 0 89 88
0 1 83 82
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
362 0
366 0
4
0 0 89 88
0 3 83 82
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
362 0
366 0
4
0 0 89 88
0 4 83 82
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box4
2
362 0
366 0
4
0 0 89 88
0 2 83 82
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box1
2
367 0
371 0
4
0 0 89 90
0 1 85 86
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box2
2
367 0
371 0
4
0 0 89 90
0 3 85 86
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box3
2
367 0
371 0
4
0 0 89 90
0 4 85 86
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_7 loc_9_8 right box4
2
367 0
371 0
4
0 0 89 90
0 2 85 86
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
366 0
370 0
4
0 0 90 89
0 1 84 83
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
366 0
370 0
4
0 0 90 89
0 3 84 83
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
366 0
370 0
4
0 0 90 89
0 4 84 83
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box4
2
366 0
370 0
4
0 0 90 89
0 2 84 83
0 51 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box1
2
371 0
375 0
4
0 0 90 91
0 1 86 87
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box2
2
371 0
375 0
4
0 0 90 91
0 3 86 87
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box3
2
371 0
375 0
4
0 0 90 91
0 4 86 87
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_7 loc_9_8 loc_9_9 right box4
2
371 0
375 0
4
0 0 90 91
0 2 86 87
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box1
2
123 0
372 0
4
0 0 91 7
0 1 7 14
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box2
2
123 0
372 0
4
0 0 91 7
0 3 7 14
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box3
2
123 0
372 0
4
0 0 91 7
0 4 7 14
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_8 loc_10_8 loc_11_8 down box4
2
123 0
372 0
4
0 0 91 7
0 2 7 14
0 63 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box1
2
370 0
374 0
4
0 0 91 90
0 1 85 84
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box2
2
370 0
374 0
4
0 0 91 90
0 3 85 84
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box3
2
370 0
374 0
4
0 0 91 90
0 4 85 84
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_7 loc_9_6 left box4
2
370 0
374 0
4
0 0 91 90
0 2 85 84
0 52 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box1
2
375 0
377 0
4
0 0 91 92
0 1 87 77
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box2
2
375 0
377 0
4
0 0 91 92
0 3 87 77
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box3
2
375 0
377 0
4
0 0 91 92
0 4 87 77
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_8 loc_9_9 loc_9_10 right box4
2
375 0
377 0
4
0 0 91 92
0 2 87 77
0 45 0 1
0 55 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
336 0
376 0
4
0 0 92 81
0 1 76 65
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
336 0
376 0
4
0 0 92 81
0 3 76 65
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
336 0
376 0
4
0 0 92 81
0 4 76 65
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box4
2
336 0
376 0
4
0 0 92 81
0 2 76 65
0 33 0 1
0 44 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
342 0
377 0
4
0 0 92 82
0 1 77 78
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
342 0
377 0
4
0 0 92 82
0 3 77 78
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
342 0
377 0
4
0 0 92 82
0 4 77 78
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box4
2
342 0
377 0
4
0 0 92 82
0 2 77 78
0 45 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box1
2
374 0
378 0
4
0 0 92 91
0 1 86 85
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box2
2
374 0
378 0
4
0 0 92 91
0 3 86 85
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box3
2
374 0
378 0
4
0 0 92 91
0 4 86 85
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_8 loc_9_7 left box4
2
374 0
378 0
4
0 0 92 91
0 2 86 85
0 53 0 1
0 54 -1 0
1
end_operator
0
