begin_version
3
end_version
begin_metric
1
end_metric
644
begin_variable
var0
-1
154
at-robot loc_10_11
at-robot loc_10_12
at-robot loc_10_13
at-robot loc_10_14
at-robot loc_10_15
at-robot loc_10_16
at-robot loc_10_17
at-robot loc_10_18
at-robot loc_10_19
at-robot loc_10_4
at-robot loc_10_5
at-robot loc_10_6
at-robot loc_10_7
at-robot loc_11_11
at-robot loc_11_12
at-robot loc_11_17
at-robot loc_11_18
at-robot loc_11_19
at-robot loc_11_2
at-robot loc_11_20
at-robot loc_11_3
at-robot loc_11_4
at-robot loc_11_5
at-robot loc_11_7
at-robot loc_12_11
at-robot loc_12_12
at-robot loc_12_13
at-robot loc_12_14
at-robot loc_12_15
at-robot loc_12_16
at-robot loc_12_17
at-robot loc_12_18
at-robot loc_12_19
at-robot loc_12_7
at-robot loc_13_10
at-robot loc_13_11
at-robot loc_13_15
at-robot loc_13_17
at-robot loc_13_18
at-robot loc_13_19
at-robot loc_13_4
at-robot loc_13_5
at-robot loc_13_6
at-robot loc_13_7
at-robot loc_14_10
at-robot loc_14_11
at-robot loc_14_12
at-robot loc_14_17
at-robot loc_14_18
at-robot loc_14_19
at-robot loc_14_4
at-robot loc_14_5
at-robot loc_14_6
at-robot loc_14_7
at-robot loc_14_8
at-robot loc_14_9
at-robot loc_15_10
at-robot loc_15_11
at-robot loc_15_12
at-robot loc_15_13
at-robot loc_15_14
at-robot loc_15_15
at-robot loc_15_16
at-robot loc_15_17
at-robot loc_15_18
at-robot loc_15_19
at-robot loc_15_5
at-robot loc_15_6
at-robot loc_15_7
at-robot loc_15_8
at-robot loc_15_9
at-robot loc_16_10
at-robot loc_16_15
at-robot loc_16_17
at-robot loc_16_18
at-robot loc_16_19
at-robot loc_16_20
at-robot loc_17_16
at-robot loc_17_17
at-robot loc_18_16
at-robot loc_2_3
at-robot loc_2_5
at-robot loc_3_2
at-robot loc_3_20
at-robot loc_3_3
at-robot loc_3_4
at-robot loc_3_5
at-robot loc_3_6
at-robot loc_4_2
at-robot loc_4_20
at-robot loc_4_5
at-robot loc_4_6
at-robot loc_5_18
at-robot loc_5_19
at-robot loc_5_2
at-robot loc_5_20
at-robot loc_5_5
at-robot loc_5_6
at-robot loc_5_7
at-robot loc_5_8
at-robot loc_5_9
at-robot loc_6_11
at-robot loc_6_17
at-robot loc_6_18
at-robot loc_6_19
at-robot loc_6_2
at-robot loc_6_5
at-robot loc_6_6
at-robot loc_6_7
at-robot loc_6_9
at-robot loc_7_10
at-robot loc_7_11
at-robot loc_7_12
at-robot loc_7_17
at-robot loc_7_18
at-robot loc_7_19
at-robot loc_7_2
at-robot loc_7_4
at-robot loc_7_5
at-robot loc_7_7
at-robot loc_7_8
at-robot loc_7_9
at-robot loc_8_10
at-robot loc_8_11
at-robot loc_8_12
at-robot loc_8_13
at-robot loc_8_17
at-robot loc_8_18
at-robot loc_8_19
at-robot loc_8_2
at-robot loc_8_4
at-robot loc_8_5
at-robot loc_8_6
at-robot loc_8_7
at-robot loc_8_8
at-robot loc_8_9
at-robot loc_9_10
at-robot loc_9_11
at-robot loc_9_12
at-robot loc_9_13
at-robot loc_9_14
at-robot loc_9_15
at-robot loc_9_16
at-robot loc_9_17
at-robot loc_9_18
at-robot loc_9_19
at-robot loc_9_2
at-robot loc_9_20
at-robot loc_9_3
at-robot loc_9_4
at-robot loc_9_5
at-robot loc_9_6
at-robot loc_9_7
at-robot loc_9_9
end_variable
begin_variable
var1
-1
142
at box6 loc_10_11
at box6 loc_10_12
at box6 loc_10_13
at box6 loc_10_14
at box6 loc_10_15
at box6 loc_10_16
at box6 loc_10_17
at box6 loc_10_18
at box6 loc_10_19
at box6 loc_10_4
at box6 loc_10_5
at box6 loc_10_6
at box6 loc_10_7
at box6 loc_11_11
at box6 loc_11_12
at box6 loc_11_17
at box6 loc_11_18
at box6 loc_11_19
at box6 loc_11_2
at box6 loc_11_20
at box6 loc_11_3
at box6 loc_11_4
at box6 loc_11_5
at box6 loc_11_7
at box6 loc_12_11
at box6 loc_12_12
at box6 loc_12_13
at box6 loc_12_14
at box6 loc_12_15
at box6 loc_12_16
at box6 loc_12_17
at box6 loc_12_18
at box6 loc_12_19
at box6 loc_12_7
at box6 loc_13_10
at box6 loc_13_11
at box6 loc_13_17
at box6 loc_13_18
at box6 loc_13_19
at box6 loc_13_4
at box6 loc_13_5
at box6 loc_13_6
at box6 loc_13_7
at box6 loc_14_10
at box6 loc_14_11
at box6 loc_14_12
at box6 loc_14_17
at box6 loc_14_18
at box6 loc_14_19
at box6 loc_14_4
at box6 loc_14_5
at box6 loc_14_6
at box6 loc_14_7
at box6 loc_14_8
at box6 loc_14_9
at box6 loc_15_10
at box6 loc_15_11
at box6 loc_15_12
at box6 loc_15_13
at box6 loc_15_14
at box6 loc_15_15
at box6 loc_15_16
at box6 loc_15_17
at box6 loc_15_18
at box6 loc_15_19
at box6 loc_15_5
at box6 loc_15_6
at box6 loc_15_7
at box6 loc_15_8
at box6 loc_15_9
at box6 loc_16_10
at box6 loc_16_17
at box6 loc_16_18
at box6 loc_16_19
at box6 loc_16_20
at box6 loc_17_17
at box6 loc_2_5
at box6 loc_3_2
at box6 loc_3_3
at box6 loc_3_4
at box6 loc_3_5
at box6 loc_3_6
at box6 loc_4_5
at box6 loc_4_6
at box6 loc_5_18
at box6 loc_5_19
at box6 loc_5_20
at box6 loc_5_5
at box6 loc_5_6
at box6 loc_5_7
at box6 loc_5_8
at box6 loc_5_9
at box6 loc_6_11
at box6 loc_6_17
at box6 loc_6_18
at box6 loc_6_19
at box6 loc_6_5
at box6 loc_6_6
at box6 loc_6_7
at box6 loc_6_9
at box6 loc_7_10
at box6 loc_7_11
at box6 loc_7_12
at box6 loc_7_17
at box6 loc_7_18
at box6 loc_7_19
at box6 loc_7_4
at box6 loc_7_5
at box6 loc_7_7
at box6 loc_7_8
at box6 loc_7_9
at box6 loc_8_10
at box6 loc_8_11
at box6 loc_8_12
at box6 loc_8_13
at box6 loc_8_17
at box6 loc_8_18
at box6 loc_8_19
at box6 loc_8_4
at box6 loc_8_5
at box6 loc_8_6
at box6 loc_8_7
at box6 loc_8_8
at box6 loc_8_9
at box6 loc_9_10
at box6 loc_9_11
at box6 loc_9_12
at box6 loc_9_13
at box6 loc_9_14
at box6 loc_9_15
at box6 loc_9_16
at box6 loc_9_17
at box6 loc_9_18
at box6 loc_9_19
at box6 loc_9_2
at box6 loc_9_20
at box6 loc_9_3
at box6 loc_9_4
at box6 loc_9_5
at box6 loc_9_6
at box6 loc_9_7
at box6 loc_9_9
end_variable
begin_variable
var2
-1
142
at box2 loc_10_11
at box2 loc_10_12
at box2 loc_10_13
at box2 loc_10_14
at box2 loc_10_15
at box2 loc_10_16
at box2 loc_10_17
at box2 loc_10_18
at box2 loc_10_19
at box2 loc_10_4
at box2 loc_10_5
at box2 loc_10_6
at box2 loc_10_7
at box2 loc_11_11
at box2 loc_11_12
at box2 loc_11_17
at box2 loc_11_18
at box2 loc_11_19
at box2 loc_11_2
at box2 loc_11_20
at box2 loc_11_3
at box2 loc_11_4
at box2 loc_11_5
at box2 loc_11_7
at box2 loc_12_11
at box2 loc_12_12
at box2 loc_12_13
at box2 loc_12_14
at box2 loc_12_15
at box2 loc_12_16
at box2 loc_12_17
at box2 loc_12_18
at box2 loc_12_19
at box2 loc_12_7
at box2 loc_13_10
at box2 loc_13_11
at box2 loc_13_17
at box2 loc_13_18
at box2 loc_13_19
at box2 loc_13_4
at box2 loc_13_5
at box2 loc_13_6
at box2 loc_13_7
at box2 loc_14_10
at box2 loc_14_11
at box2 loc_14_12
at box2 loc_14_17
at box2 loc_14_18
at box2 loc_14_19
at box2 loc_14_4
at box2 loc_14_5
at box2 loc_14_6
at box2 loc_14_7
at box2 loc_14_8
at box2 loc_14_9
at box2 loc_15_10
at box2 loc_15_11
at box2 loc_15_12
at box2 loc_15_13
at box2 loc_15_14
at box2 loc_15_15
at box2 loc_15_16
at box2 loc_15_17
at box2 loc_15_18
at box2 loc_15_19
at box2 loc_15_5
at box2 loc_15_6
at box2 loc_15_7
at box2 loc_15_8
at box2 loc_15_9
at box2 loc_16_10
at box2 loc_16_17
at box2 loc_16_18
at box2 loc_16_19
at box2 loc_16_20
at box2 loc_17_17
at box2 loc_2_5
at box2 loc_3_2
at box2 loc_3_3
at box2 loc_3_4
at box2 loc_3_5
at box2 loc_3_6
at box2 loc_4_5
at box2 loc_4_6
at box2 loc_5_18
at box2 loc_5_19
at box2 loc_5_20
at box2 loc_5_5
at box2 loc_5_6
at box2 loc_5_7
at box2 loc_5_8
at box2 loc_5_9
at box2 loc_6_11
at box2 loc_6_17
at box2 loc_6_18
at box2 loc_6_19
at box2 loc_6_5
at box2 loc_6_6
at box2 loc_6_7
at box2 loc_6_9
at box2 loc_7_10
at box2 loc_7_11
at box2 loc_7_12
at box2 loc_7_17
at box2 loc_7_18
at box2 loc_7_19
at box2 loc_7_4
at box2 loc_7_5
at box2 loc_7_7
at box2 loc_7_8
at box2 loc_7_9
at box2 loc_8_10
at box2 loc_8_11
at box2 loc_8_12
at box2 loc_8_13
at box2 loc_8_17
at box2 loc_8_18
at box2 loc_8_19
at box2 loc_8_4
at box2 loc_8_5
at box2 loc_8_6
at box2 loc_8_7
at box2 loc_8_8
at box2 loc_8_9
at box2 loc_9_10
at box2 loc_9_11
at box2 loc_9_12
at box2 loc_9_13
at box2 loc_9_14
at box2 loc_9_15
at box2 loc_9_16
at box2 loc_9_17
at box2 loc_9_18
at box2 loc_9_19
at box2 loc_9_2
at box2 loc_9_20
at box2 loc_9_3
at box2 loc_9_4
at box2 loc_9_5
at box2 loc_9_6
at box2 loc_9_7
at box2 loc_9_9
end_variable
begin_variable
var3
-1
142
at box5 loc_10_11
at box5 loc_10_12
at box5 loc_10_13
at box5 loc_10_14
at box5 loc_10_15
at box5 loc_10_16
at box5 loc_10_17
at box5 loc_10_18
at box5 loc_10_19
at box5 loc_10_4
at box5 loc_10_5
at box5 loc_10_6
at box5 loc_10_7
at box5 loc_11_11
at box5 loc_11_12
at box5 loc_11_17
at box5 loc_11_18
at box5 loc_11_19
at box5 loc_11_2
at box5 loc_11_20
at box5 loc_11_3
at box5 loc_11_4
at box5 loc_11_5
at box5 loc_11_7
at box5 loc_12_11
at box5 loc_12_12
at box5 loc_12_13
at box5 loc_12_14
at box5 loc_12_15
at box5 loc_12_16
at box5 loc_12_17
at box5 loc_12_18
at box5 loc_12_19
at box5 loc_12_7
at box5 loc_13_10
at box5 loc_13_11
at box5 loc_13_17
at box5 loc_13_18
at box5 loc_13_19
at box5 loc_13_4
at box5 loc_13_5
at box5 loc_13_6
at box5 loc_13_7
at box5 loc_14_10
at box5 loc_14_11
at box5 loc_14_12
at box5 loc_14_17
at box5 loc_14_18
at box5 loc_14_19
at box5 loc_14_4
at box5 loc_14_5
at box5 loc_14_6
at box5 loc_14_7
at box5 loc_14_8
at box5 loc_14_9
at box5 loc_15_10
at box5 loc_15_11
at box5 loc_15_12
at box5 loc_15_13
at box5 loc_15_14
at box5 loc_15_15
at box5 loc_15_16
at box5 loc_15_17
at box5 loc_15_18
at box5 loc_15_19
at box5 loc_15_5
at box5 loc_15_6
at box5 loc_15_7
at box5 loc_15_8
at box5 loc_15_9
at box5 loc_16_10
at box5 loc_16_17
at box5 loc_16_18
at box5 loc_16_19
at box5 loc_16_20
at box5 loc_17_17
at box5 loc_2_5
at box5 loc_3_2
at box5 loc_3_3
at box5 loc_3_4
at box5 loc_3_5
at box5 loc_3_6
at box5 loc_4_5
at box5 loc_4_6
at box5 loc_5_18
at box5 loc_5_19
at box5 loc_5_20
at box5 loc_5_5
at box5 loc_5_6
at box5 loc_5_7
at box5 loc_5_8
at box5 loc_5_9
at box5 loc_6_11
at box5 loc_6_17
at box5 loc_6_18
at box5 loc_6_19
at box5 loc_6_5
at box5 loc_6_6
at box5 loc_6_7
at box5 loc_6_9
at box5 loc_7_10
at box5 loc_7_11
at box5 loc_7_12
at box5 loc_7_17
at box5 loc_7_18
at box5 loc_7_19
at box5 loc_7_4
at box5 loc_7_5
at box5 loc_7_7
at box5 loc_7_8
at box5 loc_7_9
at box5 loc_8_10
at box5 loc_8_11
at box5 loc_8_12
at box5 loc_8_13
at box5 loc_8_17
at box5 loc_8_18
at box5 loc_8_19
at box5 loc_8_4
at box5 loc_8_5
at box5 loc_8_6
at box5 loc_8_7
at box5 loc_8_8
at box5 loc_8_9
at box5 loc_9_10
at box5 loc_9_11
at box5 loc_9_12
at box5 loc_9_13
at box5 loc_9_14
at box5 loc_9_15
at box5 loc_9_16
at box5 loc_9_17
at box5 loc_9_18
at box5 loc_9_19
at box5 loc_9_2
at box5 loc_9_20
at box5 loc_9_3
at box5 loc_9_4
at box5 loc_9_5
at box5 loc_9_6
at box5 loc_9_7
at box5 loc_9_9
end_variable
begin_variable
var4
-1
142
at box1 loc_10_11
at box1 loc_10_12
at box1 loc_10_13
at box1 loc_10_14
at box1 loc_10_15
at box1 loc_10_16
at box1 loc_10_17
at box1 loc_10_18
at box1 loc_10_19
at box1 loc_10_4
at box1 loc_10_5
at box1 loc_10_6
at box1 loc_10_7
at box1 loc_11_11
at box1 loc_11_12
at box1 loc_11_17
at box1 loc_11_18
at box1 loc_11_19
at box1 loc_11_2
at box1 loc_11_20
at box1 loc_11_3
at box1 loc_11_4
at box1 loc_11_5
at box1 loc_11_7
at box1 loc_12_11
at box1 loc_12_12
at box1 loc_12_13
at box1 loc_12_14
at box1 loc_12_15
at box1 loc_12_16
at box1 loc_12_17
at box1 loc_12_18
at box1 loc_12_19
at box1 loc_12_7
at box1 loc_13_10
at box1 loc_13_11
at box1 loc_13_17
at box1 loc_13_18
at box1 loc_13_19
at box1 loc_13_4
at box1 loc_13_5
at box1 loc_13_6
at box1 loc_13_7
at box1 loc_14_10
at box1 loc_14_11
at box1 loc_14_12
at box1 loc_14_17
at box1 loc_14_18
at box1 loc_14_19
at box1 loc_14_4
at box1 loc_14_5
at box1 loc_14_6
at box1 loc_14_7
at box1 loc_14_8
at box1 loc_14_9
at box1 loc_15_10
at box1 loc_15_11
at box1 loc_15_12
at box1 loc_15_13
at box1 loc_15_14
at box1 loc_15_15
at box1 loc_15_16
at box1 loc_15_17
at box1 loc_15_18
at box1 loc_15_19
at box1 loc_15_5
at box1 loc_15_6
at box1 loc_15_7
at box1 loc_15_8
at box1 loc_15_9
at box1 loc_16_10
at box1 loc_16_17
at box1 loc_16_18
at box1 loc_16_19
at box1 loc_16_20
at box1 loc_17_17
at box1 loc_2_5
at box1 loc_3_2
at box1 loc_3_3
at box1 loc_3_4
at box1 loc_3_5
at box1 loc_3_6
at box1 loc_4_5
at box1 loc_4_6
at box1 loc_5_18
at box1 loc_5_19
at box1 loc_5_20
at box1 loc_5_5
at box1 loc_5_6
at box1 loc_5_7
at box1 loc_5_8
at box1 loc_5_9
at box1 loc_6_11
at box1 loc_6_17
at box1 loc_6_18
at box1 loc_6_19
at box1 loc_6_5
at box1 loc_6_6
at box1 loc_6_7
at box1 loc_6_9
at box1 loc_7_10
at box1 loc_7_11
at box1 loc_7_12
at box1 loc_7_17
at box1 loc_7_18
at box1 loc_7_19
at box1 loc_7_4
at box1 loc_7_5
at box1 loc_7_7
at box1 loc_7_8
at box1 loc_7_9
at box1 loc_8_10
at box1 loc_8_11
at box1 loc_8_12
at box1 loc_8_13
at box1 loc_8_17
at box1 loc_8_18
at box1 loc_8_19
at box1 loc_8_4
at box1 loc_8_5
at box1 loc_8_6
at box1 loc_8_7
at box1 loc_8_8
at box1 loc_8_9
at box1 loc_9_10
at box1 loc_9_11
at box1 loc_9_12
at box1 loc_9_13
at box1 loc_9_14
at box1 loc_9_15
at box1 loc_9_16
at box1 loc_9_17
at box1 loc_9_18
at box1 loc_9_19
at box1 loc_9_2
at box1 loc_9_20
at box1 loc_9_3
at box1 loc_9_4
at box1 loc_9_5
at box1 loc_9_6
at box1 loc_9_7
at box1 loc_9_9
end_variable
begin_variable
var5
-1
142
at box3 loc_10_11
at box3 loc_10_12
at box3 loc_10_13
at box3 loc_10_14
at box3 loc_10_15
at box3 loc_10_16
at box3 loc_10_17
at box3 loc_10_18
at box3 loc_10_19
at box3 loc_10_4
at box3 loc_10_5
at box3 loc_10_6
at box3 loc_10_7
at box3 loc_11_11
at box3 loc_11_12
at box3 loc_11_17
at box3 loc_11_18
at box3 loc_11_19
at box3 loc_11_2
at box3 loc_11_20
at box3 loc_11_3
at box3 loc_11_4
at box3 loc_11_5
at box3 loc_11_7
at box3 loc_12_11
at box3 loc_12_12
at box3 loc_12_13
at box3 loc_12_14
at box3 loc_12_15
at box3 loc_12_16
at box3 loc_12_17
at box3 loc_12_18
at box3 loc_12_19
at box3 loc_12_7
at box3 loc_13_10
at box3 loc_13_11
at box3 loc_13_17
at box3 loc_13_18
at box3 loc_13_19
at box3 loc_13_4
at box3 loc_13_5
at box3 loc_13_6
at box3 loc_13_7
at box3 loc_14_10
at box3 loc_14_11
at box3 loc_14_12
at box3 loc_14_17
at box3 loc_14_18
at box3 loc_14_19
at box3 loc_14_4
at box3 loc_14_5
at box3 loc_14_6
at box3 loc_14_7
at box3 loc_14_8
at box3 loc_14_9
at box3 loc_15_10
at box3 loc_15_11
at box3 loc_15_12
at box3 loc_15_13
at box3 loc_15_14
at box3 loc_15_15
at box3 loc_15_16
at box3 loc_15_17
at box3 loc_15_18
at box3 loc_15_19
at box3 loc_15_5
at box3 loc_15_6
at box3 loc_15_7
at box3 loc_15_8
at box3 loc_15_9
at box3 loc_16_10
at box3 loc_16_17
at box3 loc_16_18
at box3 loc_16_19
at box3 loc_16_20
at box3 loc_17_17
at box3 loc_2_5
at box3 loc_3_2
at box3 loc_3_3
at box3 loc_3_4
at box3 loc_3_5
at box3 loc_3_6
at box3 loc_4_5
at box3 loc_4_6
at box3 loc_5_18
at box3 loc_5_19
at box3 loc_5_20
at box3 loc_5_5
at box3 loc_5_6
at box3 loc_5_7
at box3 loc_5_8
at box3 loc_5_9
at box3 loc_6_11
at box3 loc_6_17
at box3 loc_6_18
at box3 loc_6_19
at box3 loc_6_5
at box3 loc_6_6
at box3 loc_6_7
at box3 loc_6_9
at box3 loc_7_10
at box3 loc_7_11
at box3 loc_7_12
at box3 loc_7_17
at box3 loc_7_18
at box3 loc_7_19
at box3 loc_7_4
at box3 loc_7_5
at box3 loc_7_7
at box3 loc_7_8
at box3 loc_7_9
at box3 loc_8_10
at box3 loc_8_11
at box3 loc_8_12
at box3 loc_8_13
at box3 loc_8_17
at box3 loc_8_18
at box3 loc_8_19
at box3 loc_8_4
at box3 loc_8_5
at box3 loc_8_6
at box3 loc_8_7
at box3 loc_8_8
at box3 loc_8_9
at box3 loc_9_10
at box3 loc_9_11
at box3 loc_9_12
at box3 loc_9_13
at box3 loc_9_14
at box3 loc_9_15
at box3 loc_9_16
at box3 loc_9_17
at box3 loc_9_18
at box3 loc_9_19
at box3 loc_9_2
at box3 loc_9_20
at box3 loc_9_3
at box3 loc_9_4
at box3 loc_9_5
at box3 loc_9_6
at box3 loc_9_7
at box3 loc_9_9
end_variable
begin_variable
var6
-1
16
at box4 loc_10_19
at box4 loc_11_19
at box4 loc_11_20
at box4 loc_12_19
at box4 loc_13_19
at box4 loc_14_19
at box4 loc_15_19
at box4 loc_16_19
at box4 loc_16_20
at box4 loc_5_19
at box4 loc_5_20
at box4 loc_6_19
at box4 loc_7_19
at box4 loc_8_19
at box4 loc_9_19
at box4 loc_9_20
end_variable
begin_variable
var7
-1
2
clear loc_10_11
none-of-those
end_variable
begin_variable
var8
-1
2
clear loc_10_12
none-of-those
end_variable
begin_variable
var9
-1
2
clear loc_10_13
none-of-those
end_variable
begin_variable
var10
-1
2
clear loc_10_14
none-of-those
end_variable
begin_variable
var11
-1
2
clear loc_10_15
none-of-those
end_variable
begin_variable
var12
-1
2
clear loc_10_16
none-of-those
end_variable
begin_variable
var13
-1
2
clear loc_10_17
none-of-those
end_variable
begin_variable
var14
-1
2
clear loc_10_18
none-of-those
end_variable
begin_variable
var15
-1
2
clear loc_10_19
none-of-those
end_variable
begin_variable
var16
-1
2
clear loc_10_4
none-of-those
end_variable
begin_variable
var17
-1
2
clear loc_10_5
none-of-those
end_variable
begin_variable
var18
-1
2
clear loc_10_6
none-of-those
end_variable
begin_variable
var19
-1
2
clear loc_10_7
none-of-those
end_variable
begin_variable
var20
-1
2
clear loc_11_11
none-of-those
end_variable
begin_variable
var21
-1
2
clear loc_11_12
none-of-those
end_variable
begin_variable
var22
-1
2
clear loc_11_17
none-of-those
end_variable
begin_variable
var23
-1
2
clear loc_11_18
none-of-those
end_variable
begin_variable
var24
-1
2
clear loc_11_19
none-of-those
end_variable
begin_variable
var25
-1
2
clear loc_11_2
none-of-those
end_variable
begin_variable
var26
-1
2
clear loc_11_20
none-of-those
end_variable
begin_variable
var27
-1
2
clear loc_11_3
none-of-those
end_variable
begin_variable
var28
-1
2
clear loc_11_4
none-of-those
end_variable
begin_variable
var29
-1
2
clear loc_11_5
none-of-those
end_variable
begin_variable
var30
-1
2
clear loc_11_7
none-of-those
end_variable
begin_variable
var31
-1
2
clear loc_12_11
none-of-those
end_variable
begin_variable
var32
-1
2
clear loc_12_12
none-of-those
end_variable
begin_variable
var33
-1
2
clear loc_12_13
none-of-those
end_variable
begin_variable
var34
-1
2
clear loc_12_14
none-of-those
end_variable
begin_variable
var35
-1
2
clear loc_12_15
none-of-those
end_variable
begin_variable
var36
-1
2
clear loc_12_16
none-of-those
end_variable
begin_variable
var37
-1
2
clear loc_12_17
none-of-those
end_variable
begin_variable
var38
-1
2
clear loc_12_18
none-of-those
end_variable
begin_variable
var39
-1
2
clear loc_12_19
none-of-those
end_variable
begin_variable
var40
-1
2
clear loc_12_7
none-of-those
end_variable
begin_variable
var41
-1
2
clear loc_12_9
none-of-those
end_variable
begin_variable
var42
-1
2
clear loc_13_10
none-of-those
end_variable
begin_variable
var43
-1
2
clear loc_13_11
none-of-those
end_variable
begin_variable
var44
-1
2
clear loc_13_15
none-of-those
end_variable
begin_variable
var45
-1
2
clear loc_13_17
none-of-those
end_variable
begin_variable
var46
-1
2
clear loc_13_18
none-of-those
end_variable
begin_variable
var47
-1
2
clear loc_13_19
none-of-those
end_variable
begin_variable
var48
-1
2
clear loc_13_2
none-of-those
end_variable
begin_variable
var49
-1
2
clear loc_13_4
none-of-those
end_variable
begin_variable
var50
-1
2
clear loc_13_5
none-of-those
end_variable
begin_variable
var51
-1
2
clear loc_13_6
none-of-those
end_variable
begin_variable
var52
-1
2
clear loc_13_7
none-of-those
end_variable
begin_variable
var53
-1
2
clear loc_14_10
none-of-those
end_variable
begin_variable
var54
-1
2
clear loc_14_11
none-of-those
end_variable
begin_variable
var55
-1
2
clear loc_14_12
none-of-those
end_variable
begin_variable
var56
-1
2
clear loc_14_17
none-of-those
end_variable
begin_variable
var57
-1
2
clear loc_14_18
none-of-those
end_variable
begin_variable
var58
-1
2
clear loc_14_19
none-of-those
end_variable
begin_variable
var59
-1
2
clear loc_14_4
none-of-those
end_variable
begin_variable
var60
-1
2
clear loc_14_5
none-of-those
end_variable
begin_variable
var61
-1
2
clear loc_14_6
none-of-those
end_variable
begin_variable
var62
-1
2
clear loc_14_7
none-of-those
end_variable
begin_variable
var63
-1
2
clear loc_14_8
none-of-those
end_variable
begin_variable
var64
-1
2
clear loc_14_9
none-of-those
end_variable
begin_variable
var65
-1
2
clear loc_15_10
none-of-those
end_variable
begin_variable
var66
-1
2
clear loc_15_11
none-of-those
end_variable
begin_variable
var67
-1
2
clear loc_15_12
none-of-those
end_variable
begin_variable
var68
-1
2
clear loc_15_13
none-of-those
end_variable
begin_variable
var69
-1
2
clear loc_15_14
none-of-those
end_variable
begin_variable
var70
-1
2
clear loc_15_15
none-of-those
end_variable
begin_variable
var71
-1
2
clear loc_15_16
none-of-those
end_variable
begin_variable
var72
-1
2
clear loc_15_17
none-of-those
end_variable
begin_variable
var73
-1
2
clear loc_15_18
none-of-those
end_variable
begin_variable
var74
-1
2
clear loc_15_19
none-of-those
end_variable
begin_variable
var75
-1
2
clear loc_15_5
none-of-those
end_variable
begin_variable
var76
-1
2
clear loc_15_6
none-of-those
end_variable
begin_variable
var77
-1
2
clear loc_15_7
none-of-those
end_variable
begin_variable
var78
-1
2
clear loc_15_8
none-of-those
end_variable
begin_variable
var79
-1
2
clear loc_15_9
none-of-those
end_variable
begin_variable
var80
-1
2
clear loc_16_10
none-of-those
end_variable
begin_variable
var81
-1
2
clear loc_16_15
none-of-those
end_variable
begin_variable
var82
-1
2
clear loc_16_17
none-of-those
end_variable
begin_variable
var83
-1
2
clear loc_16_18
none-of-those
end_variable
begin_variable
var84
-1
2
clear loc_16_19
none-of-those
end_variable
begin_variable
var85
-1
2
clear loc_16_20
none-of-those
end_variable
begin_variable
var86
-1
2
clear loc_17_13
none-of-those
end_variable
begin_variable
var87
-1
2
clear loc_17_16
none-of-those
end_variable
begin_variable
var88
-1
2
clear loc_17_17
none-of-those
end_variable
begin_variable
var89
-1
2
clear loc_17_3
none-of-those
end_variable
begin_variable
var90
-1
2
clear loc_17_4
none-of-those
end_variable
begin_variable
var91
-1
2
clear loc_18_14
none-of-those
end_variable
begin_variable
var92
-1
2
clear loc_18_16
none-of-those
end_variable
begin_variable
var93
-1
2
clear loc_18_19
none-of-those
end_variable
begin_variable
var94
-1
2
clear loc_18_6
none-of-those
end_variable
begin_variable
var95
-1
2
clear loc_18_7
none-of-those
end_variable
begin_variable
var96
-1
2
clear loc_19_17
none-of-those
end_variable
begin_variable
var97
-1
2
clear loc_19_18
none-of-those
end_variable
begin_variable
var98
-1
2
clear loc_19_6
none-of-those
end_variable
begin_variable
var99
-1
2
clear loc_19_9
none-of-those
end_variable
begin_variable
var100
-1
2
clear loc_20_7
none-of-those
end_variable
begin_variable
var101
-1
2
clear loc_20_9
none-of-those
end_variable
begin_variable
var102
-1
2
clear loc_2_14
none-of-those
end_variable
begin_variable
var103
-1
2
clear loc_2_17
none-of-those
end_variable
begin_variable
var104
-1
2
clear loc_2_3
none-of-those
end_variable
begin_variable
var105
-1
2
clear loc_2_5
none-of-those
end_variable
begin_variable
var106
-1
2
clear loc_2_8
none-of-those
end_variable
begin_variable
var107
-1
2
clear loc_2_9
none-of-those
end_variable
begin_variable
var108
-1
2
clear loc_3_15
none-of-those
end_variable
begin_variable
var109
-1
2
clear loc_3_2
none-of-those
end_variable
begin_variable
var110
-1
2
clear loc_3_20
none-of-those
end_variable
begin_variable
var111
-1
2
clear loc_3_3
none-of-those
end_variable
begin_variable
var112
-1
2
clear loc_3_4
none-of-those
end_variable
begin_variable
var113
-1
2
clear loc_3_5
none-of-those
end_variable
begin_variable
var114
-1
2
clear loc_3_6
none-of-those
end_variable
begin_variable
var115
-1
2
clear loc_4_14
none-of-those
end_variable
begin_variable
var116
-1
2
clear loc_4_15
none-of-those
end_variable
begin_variable
var117
-1
2
clear loc_4_17
none-of-those
end_variable
begin_variable
var118
-1
2
clear loc_4_2
none-of-those
end_variable
begin_variable
var119
-1
2
clear loc_4_20
none-of-those
end_variable
begin_variable
var120
-1
2
clear loc_4_5
none-of-those
end_variable
begin_variable
var121
-1
2
clear loc_4_6
none-of-those
end_variable
begin_variable
var122
-1
2
clear loc_5_12
none-of-those
end_variable
begin_variable
var123
-1
2
clear loc_5_15
none-of-those
end_variable
begin_variable
var124
-1
2
clear loc_5_18
none-of-those
end_variable
begin_variable
var125
-1
2
clear loc_5_19
none-of-those
end_variable
begin_variable
var126
-1
2
clear loc_5_2
none-of-those
end_variable
begin_variable
var127
-1
2
clear loc_5_20
none-of-those
end_variable
begin_variable
var128
-1
2
clear loc_5_5
none-of-those
end_variable
begin_variable
var129
-1
2
clear loc_5_6
none-of-those
end_variable
begin_variable
var130
-1
2
clear loc_5_7
none-of-those
end_variable
begin_variable
var131
-1
2
clear loc_5_8
none-of-those
end_variable
begin_variable
var132
-1
2
clear loc_5_9
none-of-those
end_variable
begin_variable
var133
-1
2
clear loc_6_11
none-of-those
end_variable
begin_variable
var134
-1
2
clear loc_6_17
none-of-those
end_variable
begin_variable
var135
-1
2
clear loc_6_18
none-of-those
end_variable
begin_variable
var136
-1
2
clear loc_6_19
none-of-those
end_variable
begin_variable
var137
-1
2
clear loc_6_2
none-of-those
end_variable
begin_variable
var138
-1
2
clear loc_6_5
none-of-those
end_variable
begin_variable
var139
-1
2
clear loc_6_6
none-of-those
end_variable
begin_variable
var140
-1
2
clear loc_6_7
none-of-those
end_variable
begin_variable
var141
-1
2
clear loc_6_9
none-of-those
end_variable
begin_variable
var142
-1
2
clear loc_7_10
none-of-those
end_variable
begin_variable
var143
-1
2
clear loc_7_11
none-of-those
end_variable
begin_variable
var144
-1
2
clear loc_7_12
none-of-those
end_variable
begin_variable
var145
-1
2
clear loc_7_17
none-of-those
end_variable
begin_variable
var146
-1
2
clear loc_7_18
none-of-those
end_variable
begin_variable
var147
-1
2
clear loc_7_19
none-of-those
end_variable
begin_variable
var148
-1
2
clear loc_7_2
none-of-those
end_variable
begin_variable
var149
-1
2
clear loc_7_4
none-of-those
end_variable
begin_variable
var150
-1
2
clear loc_7_5
none-of-those
end_variable
begin_variable
var151
-1
2
clear loc_7_7
none-of-those
end_variable
begin_variable
var152
-1
2
clear loc_7_8
none-of-those
end_variable
begin_variable
var153
-1
2
clear loc_7_9
none-of-those
end_variable
begin_variable
var154
-1
2
clear loc_8_10
none-of-those
end_variable
begin_variable
var155
-1
2
clear loc_8_11
none-of-those
end_variable
begin_variable
var156
-1
2
clear loc_8_12
none-of-those
end_variable
begin_variable
var157
-1
2
clear loc_8_13
none-of-those
end_variable
begin_variable
var158
-1
2
clear loc_8_17
none-of-those
end_variable
begin_variable
var159
-1
2
clear loc_8_18
none-of-those
end_variable
begin_variable
var160
-1
2
clear loc_8_19
none-of-those
end_variable
begin_variable
var161
-1
2
clear loc_8_2
none-of-those
end_variable
begin_variable
var162
-1
2
clear loc_8_4
none-of-those
end_variable
begin_variable
var163
-1
2
clear loc_8_5
none-of-those
end_variable
begin_variable
var164
-1
2
clear loc_8_6
none-of-those
end_variable
begin_variable
var165
-1
2
clear loc_8_7
none-of-those
end_variable
begin_variable
var166
-1
2
clear loc_8_8
none-of-those
end_variable
begin_variable
var167
-1
2
clear loc_8_9
none-of-those
end_variable
begin_variable
var168
-1
2
clear loc_9_10
none-of-those
end_variable
begin_variable
var169
-1
2
clear loc_9_11
none-of-those
end_variable
begin_variable
var170
-1
2
clear loc_9_12
none-of-those
end_variable
begin_variable
var171
-1
2
clear loc_9_13
none-of-those
end_variable
begin_variable
var172
-1
2
clear loc_9_14
none-of-those
end_variable
begin_variable
var173
-1
2
clear loc_9_15
none-of-those
end_variable
begin_variable
var174
-1
2
clear loc_9_16
none-of-those
end_variable
begin_variable
var175
-1
2
clear loc_9_17
none-of-those
end_variable
begin_variable
var176
-1
2
clear loc_9_18
none-of-those
end_variable
begin_variable
var177
-1
2
clear loc_9_19
none-of-those
end_variable
begin_variable
var178
-1
2
clear loc_9_2
none-of-those
end_variable
begin_variable
var179
-1
2
clear loc_9_20
none-of-those
end_variable
begin_variable
var180
-1
2
clear loc_9_3
none-of-those
end_variable
begin_variable
var181
-1
2
clear loc_9_4
none-of-those
end_variable
begin_variable
var182
-1
2
clear loc_9_5
none-of-those
end_variable
begin_variable
var183
-1
2
clear loc_9_6
none-of-those
end_variable
begin_variable
var184
-1
2
clear loc_9_7
none-of-those
end_variable
begin_variable
var185
-1
2
clear loc_9_9
none-of-those
end_variable
begin_variable
var186
-1
2
adjacent loc_10_11 loc_10_12 right
none-of-those
end_variable
begin_variable
var187
-1
2
adjacent loc_10_11 loc_11_11 down
none-of-those
end_variable
begin_variable
var188
-1
2
adjacent loc_10_11 loc_9_11 up
none-of-those
end_variable
begin_variable
var189
-1
2
adjacent loc_10_12 loc_10_11 left
none-of-those
end_variable
begin_variable
var190
-1
2
adjacent loc_10_12 loc_10_13 right
none-of-those
end_variable
begin_variable
var191
-1
2
adjacent loc_10_12 loc_11_12 down
none-of-those
end_variable
begin_variable
var192
-1
2
adjacent loc_10_12 loc_9_12 up
none-of-those
end_variable
begin_variable
var193
-1
2
adjacent loc_10_13 loc_10_12 left
none-of-those
end_variable
begin_variable
var194
-1
2
adjacent loc_10_13 loc_10_14 right
none-of-those
end_variable
begin_variable
var195
-1
2
adjacent loc_10_13 loc_9_13 up
none-of-those
end_variable
begin_variable
var196
-1
2
adjacent loc_10_14 loc_10_13 left
none-of-those
end_variable
begin_variable
var197
-1
2
adjacent loc_10_14 loc_10_15 right
none-of-those
end_variable
begin_variable
var198
-1
2
adjacent loc_10_14 loc_9_14 up
none-of-those
end_variable
begin_variable
var199
-1
2
adjacent loc_10_15 loc_10_14 left
none-of-those
end_variable
begin_variable
var200
-1
2
adjacent loc_10_15 loc_10_16 right
none-of-those
end_variable
begin_variable
var201
-1
2
adjacent loc_10_15 loc_9_15 up
none-of-those
end_variable
begin_variable
var202
-1
2
adjacent loc_10_16 loc_10_15 left
none-of-those
end_variable
begin_variable
var203
-1
2
adjacent loc_10_16 loc_10_17 right
none-of-those
end_variable
begin_variable
var204
-1
2
adjacent loc_10_16 loc_9_16 up
none-of-those
end_variable
begin_variable
var205
-1
2
adjacent loc_10_17 loc_10_16 left
none-of-those
end_variable
begin_variable
var206
-1
2
adjacent loc_10_17 loc_10_18 right
none-of-those
end_variable
begin_variable
var207
-1
2
adjacent loc_10_17 loc_11_17 down
none-of-those
end_variable
begin_variable
var208
-1
2
adjacent loc_10_17 loc_9_17 up
none-of-those
end_variable
begin_variable
var209
-1
2
adjacent loc_10_18 loc_10_17 left
none-of-those
end_variable
begin_variable
var210
-1
2
adjacent loc_10_18 loc_10_19 right
none-of-those
end_variable
begin_variable
var211
-1
2
adjacent loc_10_18 loc_11_18 down
none-of-those
end_variable
begin_variable
var212
-1
2
adjacent loc_10_18 loc_9_18 up
none-of-those
end_variable
begin_variable
var213
-1
2
adjacent loc_10_19 loc_10_18 left
none-of-those
end_variable
begin_variable
var214
-1
2
adjacent loc_10_19 loc_11_19 down
none-of-those
end_variable
begin_variable
var215
-1
2
adjacent loc_10_19 loc_9_19 up
none-of-those
end_variable
begin_variable
var216
-1
2
adjacent loc_10_4 loc_10_5 right
none-of-those
end_variable
begin_variable
var217
-1
2
adjacent loc_10_4 loc_11_4 down
none-of-those
end_variable
begin_variable
var218
-1
2
adjacent loc_10_4 loc_9_4 up
none-of-those
end_variable
begin_variable
var219
-1
2
adjacent loc_10_5 loc_10_4 left
none-of-those
end_variable
begin_variable
var220
-1
2
adjacent loc_10_5 loc_10_6 right
none-of-those
end_variable
begin_variable
var221
-1
2
adjacent loc_10_5 loc_11_5 down
none-of-those
end_variable
begin_variable
var222
-1
2
adjacent loc_10_5 loc_9_5 up
none-of-those
end_variable
begin_variable
var223
-1
2
adjacent loc_10_6 loc_10_5 left
none-of-those
end_variable
begin_variable
var224
-1
2
adjacent loc_10_6 loc_10_7 right
none-of-those
end_variable
begin_variable
var225
-1
2
adjacent loc_10_6 loc_9_6 up
none-of-those
end_variable
begin_variable
var226
-1
2
adjacent loc_10_7 loc_10_6 left
none-of-those
end_variable
begin_variable
var227
-1
2
adjacent loc_10_7 loc_11_7 down
none-of-those
end_variable
begin_variable
var228
-1
2
adjacent loc_10_7 loc_9_7 up
none-of-those
end_variable
begin_variable
var229
-1
2
adjacent loc_11_11 loc_10_11 up
none-of-those
end_variable
begin_variable
var230
-1
2
adjacent loc_11_11 loc_11_12 right
none-of-those
end_variable
begin_variable
var231
-1
2
adjacent loc_11_11 loc_12_11 down
none-of-those
end_variable
begin_variable
var232
-1
2
adjacent loc_11_12 loc_10_12 up
none-of-those
end_variable
begin_variable
var233
-1
2
adjacent loc_11_12 loc_11_11 left
none-of-those
end_variable
begin_variable
var234
-1
2
adjacent loc_11_12 loc_12_12 down
none-of-those
end_variable
begin_variable
var235
-1
2
adjacent loc_11_17 loc_10_17 up
none-of-those
end_variable
begin_variable
var236
-1
2
adjacent loc_11_17 loc_11_18 right
none-of-those
end_variable
begin_variable
var237
-1
2
adjacent loc_11_17 loc_12_17 down
none-of-those
end_variable
begin_variable
var238
-1
2
adjacent loc_11_18 loc_10_18 up
none-of-those
end_variable
begin_variable
var239
-1
2
adjacent loc_11_18 loc_11_17 left
none-of-those
end_variable
begin_variable
var240
-1
2
adjacent loc_11_18 loc_11_19 right
none-of-those
end_variable
begin_variable
var241
-1
2
adjacent loc_11_18 loc_12_18 down
none-of-those
end_variable
begin_variable
var242
-1
2
adjacent loc_11_19 loc_10_19 up
none-of-those
end_variable
begin_variable
var243
-1
2
adjacent loc_11_19 loc_11_18 left
none-of-those
end_variable
begin_variable
var244
-1
2
adjacent loc_11_19 loc_11_20 right
none-of-those
end_variable
begin_variable
var245
-1
2
adjacent loc_11_19 loc_12_19 down
none-of-those
end_variable
begin_variable
var246
-1
2
adjacent loc_11_2 loc_11_3 right
none-of-those
end_variable
begin_variable
var247
-1
2
adjacent loc_11_20 loc_11_19 left
none-of-those
end_variable
begin_variable
var248
-1
2
adjacent loc_11_3 loc_11_2 left
none-of-those
end_variable
begin_variable
var249
-1
2
adjacent loc_11_3 loc_11_4 right
none-of-those
end_variable
begin_variable
var250
-1
2
adjacent loc_11_4 loc_10_4 up
none-of-those
end_variable
begin_variable
var251
-1
2
adjacent loc_11_4 loc_11_3 left
none-of-those
end_variable
begin_variable
var252
-1
2
adjacent loc_11_4 loc_11_5 right
none-of-those
end_variable
begin_variable
var253
-1
2
adjacent loc_11_5 loc_10_5 up
none-of-those
end_variable
begin_variable
var254
-1
2
adjacent loc_11_5 loc_11_4 left
none-of-those
end_variable
begin_variable
var255
-1
2
adjacent loc_11_7 loc_10_7 up
none-of-those
end_variable
begin_variable
var256
-1
2
adjacent loc_11_7 loc_12_7 down
none-of-those
end_variable
begin_variable
var257
-1
2
adjacent loc_12_11 loc_11_11 up
none-of-those
end_variable
begin_variable
var258
-1
2
adjacent loc_12_11 loc_12_12 right
none-of-those
end_variable
begin_variable
var259
-1
2
adjacent loc_12_11 loc_13_11 down
none-of-those
end_variable
begin_variable
var260
-1
2
adjacent loc_12_12 loc_11_12 up
none-of-those
end_variable
begin_variable
var261
-1
2
adjacent loc_12_12 loc_12_11 left
none-of-those
end_variable
begin_variable
var262
-1
2
adjacent loc_12_12 loc_12_13 right
none-of-those
end_variable
begin_variable
var263
-1
2
adjacent loc_12_13 loc_12_12 left
none-of-those
end_variable
begin_variable
var264
-1
2
adjacent loc_12_13 loc_12_14 right
none-of-those
end_variable
begin_variable
var265
-1
2
adjacent loc_12_14 loc_12_13 left
none-of-those
end_variable
begin_variable
var266
-1
2
adjacent loc_12_14 loc_12_15 right
none-of-those
end_variable
begin_variable
var267
-1
2
adjacent loc_12_15 loc_12_14 left
none-of-those
end_variable
begin_variable
var268
-1
2
adjacent loc_12_15 loc_12_16 right
none-of-those
end_variable
begin_variable
var269
-1
2
adjacent loc_12_15 loc_13_15 down
none-of-those
end_variable
begin_variable
var270
-1
2
adjacent loc_12_16 loc_12_15 left
none-of-those
end_variable
begin_variable
var271
-1
2
adjacent loc_12_16 loc_12_17 right
none-of-those
end_variable
begin_variable
var272
-1
2
adjacent loc_12_17 loc_11_17 up
none-of-those
end_variable
begin_variable
var273
-1
2
adjacent loc_12_17 loc_12_16 left
none-of-those
end_variable
begin_variable
var274
-1
2
adjacent loc_12_17 loc_12_18 right
none-of-those
end_variable
begin_variable
var275
-1
2
adjacent loc_12_17 loc_13_17 down
none-of-those
end_variable
begin_variable
var276
-1
2
adjacent loc_12_18 loc_11_18 up
none-of-those
end_variable
begin_variable
var277
-1
2
adjacent loc_12_18 loc_12_17 left
none-of-those
end_variable
begin_variable
var278
-1
2
adjacent loc_12_18 loc_12_19 right
none-of-those
end_variable
begin_variable
var279
-1
2
adjacent loc_12_18 loc_13_18 down
none-of-those
end_variable
begin_variable
var280
-1
2
adjacent loc_12_19 loc_11_19 up
none-of-those
end_variable
begin_variable
var281
-1
2
adjacent loc_12_19 loc_12_18 left
none-of-those
end_variable
begin_variable
var282
-1
2
adjacent loc_12_19 loc_13_19 down
none-of-those
end_variable
begin_variable
var283
-1
2
adjacent loc_12_7 loc_11_7 up
none-of-those
end_variable
begin_variable
var284
-1
2
adjacent loc_12_7 loc_13_7 down
none-of-those
end_variable
begin_variable
var285
-1
2
adjacent loc_13_10 loc_13_11 right
none-of-those
end_variable
begin_variable
var286
-1
2
adjacent loc_13_10 loc_14_10 down
none-of-those
end_variable
begin_variable
var287
-1
2
adjacent loc_13_11 loc_12_11 up
none-of-those
end_variable
begin_variable
var288
-1
2
adjacent loc_13_11 loc_13_10 left
none-of-those
end_variable
begin_variable
var289
-1
2
adjacent loc_13_11 loc_14_11 down
none-of-those
end_variable
begin_variable
var290
-1
2
adjacent loc_13_15 loc_12_15 up
none-of-those
end_variable
begin_variable
var291
-1
2
adjacent loc_13_17 loc_12_17 up
none-of-those
end_variable
begin_variable
var292
-1
2
adjacent loc_13_17 loc_13_18 right
none-of-those
end_variable
begin_variable
var293
-1
2
adjacent loc_13_17 loc_14_17 down
none-of-those
end_variable
begin_variable
var294
-1
2
adjacent loc_13_18 loc_12_18 up
none-of-those
end_variable
begin_variable
var295
-1
2
adjacent loc_13_18 loc_13_17 left
none-of-those
end_variable
begin_variable
var296
-1
2
adjacent loc_13_18 loc_13_19 right
none-of-those
end_variable
begin_variable
var297
-1
2
adjacent loc_13_18 loc_14_18 down
none-of-those
end_variable
begin_variable
var298
-1
2
adjacent loc_13_19 loc_12_19 up
none-of-those
end_variable
begin_variable
var299
-1
2
adjacent loc_13_19 loc_13_18 left
none-of-those
end_variable
begin_variable
var300
-1
2
adjacent loc_13_19 loc_14_19 down
none-of-those
end_variable
begin_variable
var301
-1
2
adjacent loc_13_4 loc_13_5 right
none-of-those
end_variable
begin_variable
var302
-1
2
adjacent loc_13_4 loc_14_4 down
none-of-those
end_variable
begin_variable
var303
-1
2
adjacent loc_13_5 loc_13_4 left
none-of-those
end_variable
begin_variable
var304
-1
2
adjacent loc_13_5 loc_13_6 right
none-of-those
end_variable
begin_variable
var305
-1
2
adjacent loc_13_5 loc_14_5 down
none-of-those
end_variable
begin_variable
var306
-1
2
adjacent loc_13_6 loc_13_5 left
none-of-those
end_variable
begin_variable
var307
-1
2
adjacent loc_13_6 loc_13_7 right
none-of-those
end_variable
begin_variable
var308
-1
2
adjacent loc_13_6 loc_14_6 down
none-of-those
end_variable
begin_variable
var309
-1
2
adjacent loc_13_7 loc_12_7 up
none-of-those
end_variable
begin_variable
var310
-1
2
adjacent loc_13_7 loc_13_6 left
none-of-those
end_variable
begin_variable
var311
-1
2
adjacent loc_13_7 loc_14_7 down
none-of-those
end_variable
begin_variable
var312
-1
2
adjacent loc_14_10 loc_13_10 up
none-of-those
end_variable
begin_variable
var313
-1
2
adjacent loc_14_10 loc_14_11 right
none-of-those
end_variable
begin_variable
var314
-1
2
adjacent loc_14_10 loc_14_9 left
none-of-those
end_variable
begin_variable
var315
-1
2
adjacent loc_14_10 loc_15_10 down
none-of-those
end_variable
begin_variable
var316
-1
2
adjacent loc_14_11 loc_13_11 up
none-of-those
end_variable
begin_variable
var317
-1
2
adjacent loc_14_11 loc_14_10 left
none-of-those
end_variable
begin_variable
var318
-1
2
adjacent loc_14_11 loc_14_12 right
none-of-those
end_variable
begin_variable
var319
-1
2
adjacent loc_14_11 loc_15_11 down
none-of-those
end_variable
begin_variable
var320
-1
2
adjacent loc_14_12 loc_14_11 left
none-of-those
end_variable
begin_variable
var321
-1
2
adjacent loc_14_12 loc_15_12 down
none-of-those
end_variable
begin_variable
var322
-1
2
adjacent loc_14_17 loc_13_17 up
none-of-those
end_variable
begin_variable
var323
-1
2
adjacent loc_14_17 loc_14_18 right
none-of-those
end_variable
begin_variable
var324
-1
2
adjacent loc_14_17 loc_15_17 down
none-of-those
end_variable
begin_variable
var325
-1
2
adjacent loc_14_18 loc_13_18 up
none-of-those
end_variable
begin_variable
var326
-1
2
adjacent loc_14_18 loc_14_17 left
none-of-those
end_variable
begin_variable
var327
-1
2
adjacent loc_14_18 loc_14_19 right
none-of-those
end_variable
begin_variable
var328
-1
2
adjacent loc_14_18 loc_15_18 down
none-of-those
end_variable
begin_variable
var329
-1
2
adjacent loc_14_19 loc_13_19 up
none-of-those
end_variable
begin_variable
var330
-1
2
adjacent loc_14_19 loc_14_18 left
none-of-those
end_variable
begin_variable
var331
-1
2
adjacent loc_14_19 loc_15_19 down
none-of-those
end_variable
begin_variable
var332
-1
2
adjacent loc_14_4 loc_13_4 up
none-of-those
end_variable
begin_variable
var333
-1
2
adjacent loc_14_4 loc_14_5 right
none-of-those
end_variable
begin_variable
var334
-1
2
adjacent loc_14_5 loc_13_5 up
none-of-those
end_variable
begin_variable
var335
-1
2
adjacent loc_14_5 loc_14_4 left
none-of-those
end_variable
begin_variable
var336
-1
2
adjacent loc_14_5 loc_14_6 right
none-of-those
end_variable
begin_variable
var337
-1
2
adjacent loc_14_5 loc_15_5 down
none-of-those
end_variable
begin_variable
var338
-1
2
adjacent loc_14_6 loc_13_6 up
none-of-those
end_variable
begin_variable
var339
-1
2
adjacent loc_14_6 loc_14_5 left
none-of-those
end_variable
begin_variable
var340
-1
2
adjacent loc_14_6 loc_14_7 right
none-of-those
end_variable
begin_variable
var341
-1
2
adjacent loc_14_6 loc_15_6 down
none-of-those
end_variable
begin_variable
var342
-1
2
adjacent loc_14_7 loc_13_7 up
none-of-those
end_variable
begin_variable
var343
-1
2
adjacent loc_14_7 loc_14_6 left
none-of-those
end_variable
begin_variable
var344
-1
2
adjacent loc_14_7 loc_14_8 right
none-of-those
end_variable
begin_variable
var345
-1
2
adjacent loc_14_7 loc_15_7 down
none-of-those
end_variable
begin_variable
var346
-1
2
adjacent loc_14_8 loc_14_7 left
none-of-those
end_variable
begin_variable
var347
-1
2
adjacent loc_14_8 loc_14_9 right
none-of-those
end_variable
begin_variable
var348
-1
2
adjacent loc_14_8 loc_15_8 down
none-of-those
end_variable
begin_variable
var349
-1
2
adjacent loc_14_9 loc_14_10 right
none-of-those
end_variable
begin_variable
var350
-1
2
adjacent loc_14_9 loc_14_8 left
none-of-those
end_variable
begin_variable
var351
-1
2
adjacent loc_14_9 loc_15_9 down
none-of-those
end_variable
begin_variable
var352
-1
2
adjacent loc_15_10 loc_14_10 up
none-of-those
end_variable
begin_variable
var353
-1
2
adjacent loc_15_10 loc_15_11 right
none-of-those
end_variable
begin_variable
var354
-1
2
adjacent loc_15_10 loc_15_9 left
none-of-those
end_variable
begin_variable
var355
-1
2
adjacent loc_15_10 loc_16_10 down
none-of-those
end_variable
begin_variable
var356
-1
2
adjacent loc_15_11 loc_14_11 up
none-of-those
end_variable
begin_variable
var357
-1
2
adjacent loc_15_11 loc_15_10 left
none-of-those
end_variable
begin_variable
var358
-1
2
adjacent loc_15_11 loc_15_12 right
none-of-those
end_variable
begin_variable
var359
-1
2
adjacent loc_15_12 loc_14_12 up
none-of-those
end_variable
begin_variable
var360
-1
2
adjacent loc_15_12 loc_15_11 left
none-of-those
end_variable
begin_variable
var361
-1
2
adjacent loc_15_12 loc_15_13 right
none-of-those
end_variable
begin_variable
var362
-1
2
adjacent loc_15_13 loc_15_12 left
none-of-those
end_variable
begin_variable
var363
-1
2
adjacent loc_15_13 loc_15_14 right
none-of-those
end_variable
begin_variable
var364
-1
2
adjacent loc_15_14 loc_15_13 left
none-of-those
end_variable
begin_variable
var365
-1
2
adjacent loc_15_14 loc_15_15 right
none-of-those
end_variable
begin_variable
var366
-1
2
adjacent loc_15_15 loc_15_14 left
none-of-those
end_variable
begin_variable
var367
-1
2
adjacent loc_15_15 loc_15_16 right
none-of-those
end_variable
begin_variable
var368
-1
2
adjacent loc_15_15 loc_16_15 down
none-of-those
end_variable
begin_variable
var369
-1
2
adjacent loc_15_16 loc_15_15 left
none-of-those
end_variable
begin_variable
var370
-1
2
adjacent loc_15_16 loc_15_17 right
none-of-those
end_variable
begin_variable
var371
-1
2
adjacent loc_15_17 loc_14_17 up
none-of-those
end_variable
begin_variable
var372
-1
2
adjacent loc_15_17 loc_15_16 left
none-of-those
end_variable
begin_variable
var373
-1
2
adjacent loc_15_17 loc_15_18 right
none-of-those
end_variable
begin_variable
var374
-1
2
adjacent loc_15_17 loc_16_17 down
none-of-those
end_variable
begin_variable
var375
-1
2
adjacent loc_15_18 loc_14_18 up
none-of-those
end_variable
begin_variable
var376
-1
2
adjacent loc_15_18 loc_15_17 left
none-of-those
end_variable
begin_variable
var377
-1
2
adjacent loc_15_18 loc_15_19 right
none-of-those
end_variable
begin_variable
var378
-1
2
adjacent loc_15_18 loc_16_18 down
none-of-those
end_variable
begin_variable
var379
-1
2
adjacent loc_15_19 loc_14_19 up
none-of-those
end_variable
begin_variable
var380
-1
2
adjacent loc_15_19 loc_15_18 left
none-of-those
end_variable
begin_variable
var381
-1
2
adjacent loc_15_19 loc_16_19 down
none-of-those
end_variable
begin_variable
var382
-1
2
adjacent loc_15_5 loc_14_5 up
none-of-those
end_variable
begin_variable
var383
-1
2
adjacent loc_15_5 loc_15_6 right
none-of-those
end_variable
begin_variable
var384
-1
2
adjacent loc_15_6 loc_14_6 up
none-of-those
end_variable
begin_variable
var385
-1
2
adjacent loc_15_6 loc_15_5 left
none-of-those
end_variable
begin_variable
var386
-1
2
adjacent loc_15_6 loc_15_7 right
none-of-those
end_variable
begin_variable
var387
-1
2
adjacent loc_15_7 loc_14_7 up
none-of-those
end_variable
begin_variable
var388
-1
2
adjacent loc_15_7 loc_15_6 left
none-of-those
end_variable
begin_variable
var389
-1
2
adjacent loc_15_7 loc_15_8 right
none-of-those
end_variable
begin_variable
var390
-1
2
adjacent loc_15_8 loc_14_8 up
none-of-those
end_variable
begin_variable
var391
-1
2
adjacent loc_15_8 loc_15_7 left
none-of-those
end_variable
begin_variable
var392
-1
2
adjacent loc_15_8 loc_15_9 right
none-of-those
end_variable
begin_variable
var393
-1
2
adjacent loc_15_9 loc_14_9 up
none-of-those
end_variable
begin_variable
var394
-1
2
adjacent loc_15_9 loc_15_10 right
none-of-those
end_variable
begin_variable
var395
-1
2
adjacent loc_15_9 loc_15_8 left
none-of-those
end_variable
begin_variable
var396
-1
2
adjacent loc_16_10 loc_15_10 up
none-of-those
end_variable
begin_variable
var397
-1
2
adjacent loc_16_15 loc_15_15 up
none-of-those
end_variable
begin_variable
var398
-1
2
adjacent loc_16_17 loc_15_17 up
none-of-those
end_variable
begin_variable
var399
-1
2
adjacent loc_16_17 loc_16_18 right
none-of-those
end_variable
begin_variable
var400
-1
2
adjacent loc_16_17 loc_17_17 down
none-of-those
end_variable
begin_variable
var401
-1
2
adjacent loc_16_18 loc_15_18 up
none-of-those
end_variable
begin_variable
var402
-1
2
adjacent loc_16_18 loc_16_17 left
none-of-those
end_variable
begin_variable
var403
-1
2
adjacent loc_16_18 loc_16_19 right
none-of-those
end_variable
begin_variable
var404
-1
2
adjacent loc_16_19 loc_15_19 up
none-of-those
end_variable
begin_variable
var405
-1
2
adjacent loc_16_19 loc_16_18 left
none-of-those
end_variable
begin_variable
var406
-1
2
adjacent loc_16_19 loc_16_20 right
none-of-those
end_variable
begin_variable
var407
-1
2
adjacent loc_16_20 loc_16_19 left
none-of-those
end_variable
begin_variable
var408
-1
2
adjacent loc_17_16 loc_17_17 right
none-of-those
end_variable
begin_variable
var409
-1
2
adjacent loc_17_16 loc_18_16 down
none-of-those
end_variable
begin_variable
var410
-1
2
adjacent loc_17_17 loc_16_17 up
none-of-those
end_variable
begin_variable
var411
-1
2
adjacent loc_17_17 loc_17_16 left
none-of-those
end_variable
begin_variable
var412
-1
2
adjacent loc_17_3 loc_17_4 right
none-of-those
end_variable
begin_variable
var413
-1
2
adjacent loc_17_4 loc_17_3 left
none-of-those
end_variable
begin_variable
var414
-1
2
adjacent loc_18_16 loc_17_16 up
none-of-those
end_variable
begin_variable
var415
-1
2
adjacent loc_18_6 loc_18_7 right
none-of-those
end_variable
begin_variable
var416
-1
2
adjacent loc_18_6 loc_19_6 down
none-of-those
end_variable
begin_variable
var417
-1
2
adjacent loc_18_7 loc_18_6 left
none-of-those
end_variable
begin_variable
var418
-1
2
adjacent loc_19_17 loc_19_18 right
none-of-those
end_variable
begin_variable
var419
-1
2
adjacent loc_19_18 loc_19_17 left
none-of-those
end_variable
begin_variable
var420
-1
2
adjacent loc_19_6 loc_18_6 up
none-of-those
end_variable
begin_variable
var421
-1
2
adjacent loc_19_9 loc_20_9 down
none-of-those
end_variable
begin_variable
var422
-1
2
adjacent loc_20_9 loc_19_9 up
none-of-those
end_variable
begin_variable
var423
-1
2
adjacent loc_2_3 loc_3_3 down
none-of-those
end_variable
begin_variable
var424
-1
2
adjacent loc_2_5 loc_3_5 down
none-of-those
end_variable
begin_variable
var425
-1
2
adjacent loc_2_8 loc_2_9 right
none-of-those
end_variable
begin_variable
var426
-1
2
adjacent loc_2_9 loc_2_8 left
none-of-those
end_variable
begin_variable
var427
-1
2
adjacent loc_3_15 loc_4_15 down
none-of-those
end_variable
begin_variable
var428
-1
2
adjacent loc_3_2 loc_3_3 right
none-of-those
end_variable
begin_variable
var429
-1
2
adjacent loc_3_2 loc_4_2 down
none-of-those
end_variable
begin_variable
var430
-1
2
adjacent loc_3_20 loc_4_20 down
none-of-those
end_variable
begin_variable
var431
-1
2
adjacent loc_3_3 loc_2_3 up
none-of-those
end_variable
begin_variable
var432
-1
2
adjacent loc_3_3 loc_3_2 left
none-of-those
end_variable
begin_variable
var433
-1
2
adjacent loc_3_3 loc_3_4 right
none-of-those
end_variable
begin_variable
var434
-1
2
adjacent loc_3_4 loc_3_3 left
none-of-those
end_variable
begin_variable
var435
-1
2
adjacent loc_3_4 loc_3_5 right
none-of-those
end_variable
begin_variable
var436
-1
2
adjacent loc_3_5 loc_2_5 up
none-of-those
end_variable
begin_variable
var437
-1
2
adjacent loc_3_5 loc_3_4 left
none-of-those
end_variable
begin_variable
var438
-1
2
adjacent loc_3_5 loc_3_6 right
none-of-those
end_variable
begin_variable
var439
-1
2
adjacent loc_3_5 loc_4_5 down
none-of-those
end_variable
begin_variable
var440
-1
2
adjacent loc_3_6 loc_3_5 left
none-of-those
end_variable
begin_variable
var441
-1
2
adjacent loc_3_6 loc_4_6 down
none-of-those
end_variable
begin_variable
var442
-1
2
adjacent loc_4_14 loc_4_15 right
none-of-those
end_variable
begin_variable
var443
-1
2
adjacent loc_4_15 loc_3_15 up
none-of-those
end_variable
begin_variable
var444
-1
2
adjacent loc_4_15 loc_4_14 left
none-of-those
end_variable
begin_variable
var445
-1
2
adjacent loc_4_15 loc_5_15 down
none-of-those
end_variable
begin_variable
var446
-1
2
adjacent loc_4_2 loc_3_2 up
none-of-those
end_variable
begin_variable
var447
-1
2
adjacent loc_4_2 loc_5_2 down
none-of-those
end_variable
begin_variable
var448
-1
2
adjacent loc_4_20 loc_3_20 up
none-of-those
end_variable
begin_variable
var449
-1
2
adjacent loc_4_20 loc_5_20 down
none-of-those
end_variable
begin_variable
var450
-1
2
adjacent loc_4_5 loc_3_5 up
none-of-those
end_variable
begin_variable
var451
-1
2
adjacent loc_4_5 loc_4_6 right
none-of-those
end_variable
begin_variable
var452
-1
2
adjacent loc_4_5 loc_5_5 down
none-of-those
end_variable
begin_variable
var453
-1
2
adjacent loc_4_6 loc_3_6 up
none-of-those
end_variable
begin_variable
var454
-1
2
adjacent loc_4_6 loc_4_5 left
none-of-those
end_variable
begin_variable
var455
-1
2
adjacent loc_4_6 loc_5_6 down
none-of-those
end_variable
begin_variable
var456
-1
2
adjacent loc_5_15 loc_4_15 up
none-of-those
end_variable
begin_variable
var457
-1
2
adjacent loc_5_18 loc_5_19 right
none-of-those
end_variable
begin_variable
var458
-1
2
adjacent loc_5_18 loc_6_18 down
none-of-those
end_variable
begin_variable
var459
-1
2
adjacent loc_5_19 loc_5_18 left
none-of-those
end_variable
begin_variable
var460
-1
2
adjacent loc_5_19 loc_5_20 right
none-of-those
end_variable
begin_variable
var461
-1
2
adjacent loc_5_19 loc_6_19 down
none-of-those
end_variable
begin_variable
var462
-1
2
adjacent loc_5_2 loc_4_2 up
none-of-those
end_variable
begin_variable
var463
-1
2
adjacent loc_5_2 loc_6_2 down
none-of-those
end_variable
begin_variable
var464
-1
2
adjacent loc_5_20 loc_4_20 up
none-of-those
end_variable
begin_variable
var465
-1
2
adjacent loc_5_20 loc_5_19 left
none-of-those
end_variable
begin_variable
var466
-1
2
adjacent loc_5_5 loc_4_5 up
none-of-those
end_variable
begin_variable
var467
-1
2
adjacent loc_5_5 loc_5_6 right
none-of-those
end_variable
begin_variable
var468
-1
2
adjacent loc_5_5 loc_6_5 down
none-of-those
end_variable
begin_variable
var469
-1
2
adjacent loc_5_6 loc_4_6 up
none-of-those
end_variable
begin_variable
var470
-1
2
adjacent loc_5_6 loc_5_5 left
none-of-those
end_variable
begin_variable
var471
-1
2
adjacent loc_5_6 loc_5_7 right
none-of-those
end_variable
begin_variable
var472
-1
2
adjacent loc_5_6 loc_6_6 down
none-of-those
end_variable
begin_variable
var473
-1
2
adjacent loc_5_7 loc_5_6 left
none-of-those
end_variable
begin_variable
var474
-1
2
adjacent loc_5_7 loc_5_8 right
none-of-those
end_variable
begin_variable
var475
-1
2
adjacent loc_5_7 loc_6_7 down
none-of-those
end_variable
begin_variable
var476
-1
2
adjacent loc_5_8 loc_5_7 left
none-of-those
end_variable
begin_variable
var477
-1
2
adjacent loc_5_8 loc_5_9 right
none-of-those
end_variable
begin_variable
var478
-1
2
adjacent loc_5_9 loc_5_8 left
none-of-those
end_variable
begin_variable
var479
-1
2
adjacent loc_5_9 loc_6_9 down
none-of-those
end_variable
begin_variable
var480
-1
2
adjacent loc_6_11 loc_7_11 down
none-of-those
end_variable
begin_variable
var481
-1
2
adjacent loc_6_17 loc_6_18 right
none-of-those
end_variable
begin_variable
var482
-1
2
adjacent loc_6_17 loc_7_17 down
none-of-those
end_variable
begin_variable
var483
-1
2
adjacent loc_6_18 loc_5_18 up
none-of-those
end_variable
begin_variable
var484
-1
2
adjacent loc_6_18 loc_6_17 left
none-of-those
end_variable
begin_variable
var485
-1
2
adjacent loc_6_18 loc_6_19 right
none-of-those
end_variable
begin_variable
var486
-1
2
adjacent loc_6_18 loc_7_18 down
none-of-those
end_variable
begin_variable
var487
-1
2
adjacent loc_6_19 loc_5_19 up
none-of-those
end_variable
begin_variable
var488
-1
2
adjacent loc_6_19 loc_6_18 left
none-of-those
end_variable
begin_variable
var489
-1
2
adjacent loc_6_19 loc_7_19 down
none-of-those
end_variable
begin_variable
var490
-1
2
adjacent loc_6_2 loc_5_2 up
none-of-those
end_variable
begin_variable
var491
-1
2
adjacent loc_6_2 loc_7_2 down
none-of-those
end_variable
begin_variable
var492
-1
2
adjacent loc_6_5 loc_5_5 up
none-of-those
end_variable
begin_variable
var493
-1
2
adjacent loc_6_5 loc_6_6 right
none-of-those
end_variable
begin_variable
var494
-1
2
adjacent loc_6_5 loc_7_5 down
none-of-those
end_variable
begin_variable
var495
-1
2
adjacent loc_6_6 loc_5_6 up
none-of-those
end_variable
begin_variable
var496
-1
2
adjacent loc_6_6 loc_6_5 left
none-of-those
end_variable
begin_variable
var497
-1
2
adjacent loc_6_6 loc_6_7 right
none-of-those
end_variable
begin_variable
var498
-1
2
adjacent loc_6_7 loc_5_7 up
none-of-those
end_variable
begin_variable
var499
-1
2
adjacent loc_6_7 loc_6_6 left
none-of-those
end_variable
begin_variable
var500
-1
2
adjacent loc_6_7 loc_7_7 down
none-of-those
end_variable
begin_variable
var501
-1
2
adjacent loc_6_9 loc_5_9 up
none-of-those
end_variable
begin_variable
var502
-1
2
adjacent loc_6_9 loc_7_9 down
none-of-those
end_variable
begin_variable
var503
-1
2
adjacent loc_7_10 loc_7_11 right
none-of-those
end_variable
begin_variable
var504
-1
2
adjacent loc_7_10 loc_7_9 left
none-of-those
end_variable
begin_variable
var505
-1
2
adjacent loc_7_10 loc_8_10 down
none-of-those
end_variable
begin_variable
var506
-1
2
adjacent loc_7_11 loc_6_11 up
none-of-those
end_variable
begin_variable
var507
-1
2
adjacent loc_7_11 loc_7_10 left
none-of-those
end_variable
begin_variable
var508
-1
2
adjacent loc_7_11 loc_7_12 right
none-of-those
end_variable
begin_variable
var509
-1
2
adjacent loc_7_11 loc_8_11 down
none-of-those
end_variable
begin_variable
var510
-1
2
adjacent loc_7_12 loc_7_11 left
none-of-those
end_variable
begin_variable
var511
-1
2
adjacent loc_7_12 loc_8_12 down
none-of-those
end_variable
begin_variable
var512
-1
2
adjacent loc_7_17 loc_6_17 up
none-of-those
end_variable
begin_variable
var513
-1
2
adjacent loc_7_17 loc_7_18 right
none-of-those
end_variable
begin_variable
var514
-1
2
adjacent loc_7_17 loc_8_17 down
none-of-those
end_variable
begin_variable
var515
-1
2
adjacent loc_7_18 loc_6_18 up
none-of-those
end_variable
begin_variable
var516
-1
2
adjacent loc_7_18 loc_7_17 left
none-of-those
end_variable
begin_variable
var517
-1
2
adjacent loc_7_18 loc_7_19 right
none-of-those
end_variable
begin_variable
var518
-1
2
adjacent loc_7_18 loc_8_18 down
none-of-those
end_variable
begin_variable
var519
-1
2
adjacent loc_7_19 loc_6_19 up
none-of-those
end_variable
begin_variable
var520
-1
2
adjacent loc_7_19 loc_7_18 left
none-of-those
end_variable
begin_variable
var521
-1
2
adjacent loc_7_19 loc_8_19 down
none-of-those
end_variable
begin_variable
var522
-1
2
adjacent loc_7_2 loc_6_2 up
none-of-those
end_variable
begin_variable
var523
-1
2
adjacent loc_7_2 loc_8_2 down
none-of-those
end_variable
begin_variable
var524
-1
2
adjacent loc_7_4 loc_7_5 right
none-of-those
end_variable
begin_variable
var525
-1
2
adjacent loc_7_4 loc_8_4 down
none-of-those
end_variable
begin_variable
var526
-1
2
adjacent loc_7_5 loc_6_5 up
none-of-those
end_variable
begin_variable
var527
-1
2
adjacent loc_7_5 loc_7_4 left
none-of-those
end_variable
begin_variable
var528
-1
2
adjacent loc_7_5 loc_8_5 down
none-of-those
end_variable
begin_variable
var529
-1
2
adjacent loc_7_7 loc_6_7 up
none-of-those
end_variable
begin_variable
var530
-1
2
adjacent loc_7_7 loc_7_8 right
none-of-those
end_variable
begin_variable
var531
-1
2
adjacent loc_7_7 loc_8_7 down
none-of-those
end_variable
begin_variable
var532
-1
2
adjacent loc_7_8 loc_7_7 left
none-of-those
end_variable
begin_variable
var533
-1
2
adjacent loc_7_8 loc_7_9 right
none-of-those
end_variable
begin_variable
var534
-1
2
adjacent loc_7_8 loc_8_8 down
none-of-those
end_variable
begin_variable
var535
-1
2
adjacent loc_7_9 loc_6_9 up
none-of-those
end_variable
begin_variable
var536
-1
2
adjacent loc_7_9 loc_7_10 right
none-of-those
end_variable
begin_variable
var537
-1
2
adjacent loc_7_9 loc_7_8 left
none-of-those
end_variable
begin_variable
var538
-1
2
adjacent loc_7_9 loc_8_9 down
none-of-those
end_variable
begin_variable
var539
-1
2
adjacent loc_8_10 loc_7_10 up
none-of-those
end_variable
begin_variable
var540
-1
2
adjacent loc_8_10 loc_8_11 right
none-of-those
end_variable
begin_variable
var541
-1
2
adjacent loc_8_10 loc_8_9 left
none-of-those
end_variable
begin_variable
var542
-1
2
adjacent loc_8_10 loc_9_10 down
none-of-those
end_variable
begin_variable
var543
-1
2
adjacent loc_8_11 loc_7_11 up
none-of-those
end_variable
begin_variable
var544
-1
2
adjacent loc_8_11 loc_8_10 left
none-of-those
end_variable
begin_variable
var545
-1
2
adjacent loc_8_11 loc_8_12 right
none-of-those
end_variable
begin_variable
var546
-1
2
adjacent loc_8_11 loc_9_11 down
none-of-those
end_variable
begin_variable
var547
-1
2
adjacent loc_8_12 loc_7_12 up
none-of-those
end_variable
begin_variable
var548
-1
2
adjacent loc_8_12 loc_8_11 left
none-of-those
end_variable
begin_variable
var549
-1
2
adjacent loc_8_12 loc_8_13 right
none-of-those
end_variable
begin_variable
var550
-1
2
adjacent loc_8_12 loc_9_12 down
none-of-those
end_variable
begin_variable
var551
-1
2
adjacent loc_8_13 loc_8_12 left
none-of-those
end_variable
begin_variable
var552
-1
2
adjacent loc_8_13 loc_9_13 down
none-of-those
end_variable
begin_variable
var553
-1
2
adjacent loc_8_17 loc_7_17 up
none-of-those
end_variable
begin_variable
var554
-1
2
adjacent loc_8_17 loc_8_18 right
none-of-those
end_variable
begin_variable
var555
-1
2
adjacent loc_8_17 loc_9_17 down
none-of-those
end_variable
begin_variable
var556
-1
2
adjacent loc_8_18 loc_7_18 up
none-of-those
end_variable
begin_variable
var557
-1
2
adjacent loc_8_18 loc_8_17 left
none-of-those
end_variable
begin_variable
var558
-1
2
adjacent loc_8_18 loc_8_19 right
none-of-those
end_variable
begin_variable
var559
-1
2
adjacent loc_8_18 loc_9_18 down
none-of-those
end_variable
begin_variable
var560
-1
2
adjacent loc_8_19 loc_7_19 up
none-of-those
end_variable
begin_variable
var561
-1
2
adjacent loc_8_19 loc_8_18 left
none-of-those
end_variable
begin_variable
var562
-1
2
adjacent loc_8_19 loc_9_19 down
none-of-those
end_variable
begin_variable
var563
-1
2
adjacent loc_8_2 loc_7_2 up
none-of-those
end_variable
begin_variable
var564
-1
2
adjacent loc_8_2 loc_9_2 down
none-of-those
end_variable
begin_variable
var565
-1
2
adjacent loc_8_4 loc_7_4 up
none-of-those
end_variable
begin_variable
var566
-1
2
adjacent loc_8_4 loc_8_5 right
none-of-those
end_variable
begin_variable
var567
-1
2
adjacent loc_8_4 loc_9_4 down
none-of-those
end_variable
begin_variable
var568
-1
2
adjacent loc_8_5 loc_7_5 up
none-of-those
end_variable
begin_variable
var569
-1
2
adjacent loc_8_5 loc_8_4 left
none-of-those
end_variable
begin_variable
var570
-1
2
adjacent loc_8_5 loc_8_6 right
none-of-those
end_variable
begin_variable
var571
-1
2
adjacent loc_8_5 loc_9_5 down
none-of-those
end_variable
begin_variable
var572
-1
2
adjacent loc_8_6 loc_8_5 left
none-of-those
end_variable
begin_variable
var573
-1
2
adjacent loc_8_6 loc_8_7 right
none-of-those
end_variable
begin_variable
var574
-1
2
adjacent loc_8_6 loc_9_6 down
none-of-those
end_variable
begin_variable
var575
-1
2
adjacent loc_8_7 loc_7_7 up
none-of-those
end_variable
begin_variable
var576
-1
2
adjacent loc_8_7 loc_8_6 left
none-of-those
end_variable
begin_variable
var577
-1
2
adjacent loc_8_7 loc_8_8 right
none-of-those
end_variable
begin_variable
var578
-1
2
adjacent loc_8_7 loc_9_7 down
none-of-those
end_variable
begin_variable
var579
-1
2
adjacent loc_8_8 loc_7_8 up
none-of-those
end_variable
begin_variable
var580
-1
2
adjacent loc_8_8 loc_8_7 left
none-of-those
end_variable
begin_variable
var581
-1
2
adjacent loc_8_8 loc_8_9 right
none-of-those
end_variable
begin_variable
var582
-1
2
adjacent loc_8_9 loc_7_9 up
none-of-those
end_variable
begin_variable
var583
-1
2
adjacent loc_8_9 loc_8_10 right
none-of-those
end_variable
begin_variable
var584
-1
2
adjacent loc_8_9 loc_8_8 left
none-of-those
end_variable
begin_variable
var585
-1
2
adjacent loc_8_9 loc_9_9 down
none-of-those
end_variable
begin_variable
var586
-1
2
adjacent loc_9_10 loc_8_10 up
none-of-those
end_variable
begin_variable
var587
-1
2
adjacent loc_9_10 loc_9_11 right
none-of-those
end_variable
begin_variable
var588
-1
2
adjacent loc_9_10 loc_9_9 left
none-of-those
end_variable
begin_variable
var589
-1
2
adjacent loc_9_11 loc_10_11 down
none-of-those
end_variable
begin_variable
var590
-1
2
adjacent loc_9_11 loc_8_11 up
none-of-those
end_variable
begin_variable
var591
-1
2
adjacent loc_9_11 loc_9_10 left
none-of-those
end_variable
begin_variable
var592
-1
2
adjacent loc_9_11 loc_9_12 right
none-of-those
end_variable
begin_variable
var593
-1
2
adjacent loc_9_12 loc_10_12 down
none-of-those
end_variable
begin_variable
var594
-1
2
adjacent loc_9_12 loc_8_12 up
none-of-those
end_variable
begin_variable
var595
-1
2
adjacent loc_9_12 loc_9_11 left
none-of-those
end_variable
begin_variable
var596
-1
2
adjacent loc_9_12 loc_9_13 right
none-of-those
end_variable
begin_variable
var597
-1
2
adjacent loc_9_13 loc_10_13 down
none-of-those
end_variable
begin_variable
var598
-1
2
adjacent loc_9_13 loc_8_13 up
none-of-those
end_variable
begin_variable
var599
-1
2
adjacent loc_9_13 loc_9_12 left
none-of-those
end_variable
begin_variable
var600
-1
2
adjacent loc_9_13 loc_9_14 right
none-of-those
end_variable
begin_variable
var601
-1
2
adjacent loc_9_14 loc_10_14 down
none-of-those
end_variable
begin_variable
var602
-1
2
adjacent loc_9_14 loc_9_13 left
none-of-those
end_variable
begin_variable
var603
-1
2
adjacent loc_9_14 loc_9_15 right
none-of-those
end_variable
begin_variable
var604
-1
2
adjacent loc_9_15 loc_10_15 down
none-of-those
end_variable
begin_variable
var605
-1
2
adjacent loc_9_15 loc_9_14 left
none-of-those
end_variable
begin_variable
var606
-1
2
adjacent loc_9_15 loc_9_16 right
none-of-those
end_variable
begin_variable
var607
-1
2
adjacent loc_9_16 loc_10_16 down
none-of-those
end_variable
begin_variable
var608
-1
2
adjacent loc_9_16 loc_9_15 left
none-of-those
end_variable
begin_variable
var609
-1
2
adjacent loc_9_16 loc_9_17 right
none-of-those
end_variable
begin_variable
var610
-1
2
adjacent loc_9_17 loc_10_17 down
none-of-those
end_variable
begin_variable
var611
-1
2
adjacent loc_9_17 loc_8_17 up
none-of-those
end_variable
begin_variable
var612
-1
2
adjacent loc_9_17 loc_9_16 left
none-of-those
end_variable
begin_variable
var613
-1
2
adjacent loc_9_17 loc_9_18 right
none-of-those
end_variable
begin_variable
var614
-1
2
adjacent loc_9_18 loc_10_18 down
none-of-those
end_variable
begin_variable
var615
-1
2
adjacent loc_9_18 loc_8_18 up
none-of-those
end_variable
begin_variable
var616
-1
2
adjacent loc_9_18 loc_9_17 left
none-of-those
end_variable
begin_variable
var617
-1
2
adjacent loc_9_18 loc_9_19 right
none-of-those
end_variable
begin_variable
var618
-1
2
adjacent loc_9_19 loc_10_19 down
none-of-those
end_variable
begin_variable
var619
-1
2
adjacent loc_9_19 loc_8_19 up
none-of-those
end_variable
begin_variable
var620
-1
2
adjacent loc_9_19 loc_9_18 left
none-of-those
end_variable
begin_variable
var621
-1
2
adjacent loc_9_19 loc_9_20 right
none-of-those
end_variable
begin_variable
var622
-1
2
adjacent loc_9_2 loc_8_2 up
none-of-those
end_variable
begin_variable
var623
-1
2
adjacent loc_9_2 loc_9_3 right
none-of-those
end_variable
begin_variable
var624
-1
2
adjacent loc_9_20 loc_9_19 left
none-of-those
end_variable
begin_variable
var625
-1
2
adjacent loc_9_3 loc_9_2 left
none-of-those
end_variable
begin_variable
var626
-1
2
adjacent loc_9_3 loc_9_4 right
none-of-those
end_variable
begin_variable
var627
-1
2
adjacent loc_9_4 loc_10_4 down
none-of-those
end_variable
begin_variable
var628
-1
2
adjacent loc_9_4 loc_8_4 up
none-of-those
end_variable
begin_variable
var629
-1
2
adjacent loc_9_4 loc_9_3 left
none-of-those
end_variable
begin_variable
var630
-1
2
adjacent loc_9_4 loc_9_5 right
none-of-those
end_variable
begin_variable
var631
-1
2
adjacent loc_9_5 loc_10_5 down
none-of-those
end_variable
begin_variable
var632
-1
2
adjacent loc_9_5 loc_8_5 up
none-of-those
end_variable
begin_variable
var633
-1
2
adjacent loc_9_5 loc_9_4 left
none-of-those
end_variable
begin_variable
var634
-1
2
adjacent loc_9_5 loc_9_6 right
none-of-those
end_variable
begin_variable
var635
-1
2
adjacent loc_9_6 loc_10_6 down
none-of-those
end_variable
begin_variable
var636
-1
2
adjacent loc_9_6 loc_8_6 up
none-of-those
end_variable
begin_variable
var637
-1
2
adjacent loc_9_6 loc_9_5 left
none-of-those
end_variable
begin_variable
var638
-1
2
adjacent loc_9_6 loc_9_7 right
none-of-those
end_variable
begin_variable
var639
-1
2
adjacent loc_9_7 loc_10_7 down
none-of-those
end_variable
begin_variable
var640
-1
2
adjacent loc_9_7 loc_8_7 up
none-of-those
end_variable
begin_variable
var641
-1
2
adjacent loc_9_7 loc_9_6 left
none-of-those
end_variable
begin_variable
var642
-1
2
adjacent loc_9_9 loc_8_9 up
none-of-those
end_variable
begin_variable
var643
-1
2
adjacent loc_9_9 loc_9_10 right
none-of-those
end_variable
0
begin_state
82
27
90
12
108
113
5
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
6
1 85
2 79
3 116
4 34
5 20
6 14
end_goal
1984
begin_operator
move loc_10_11 loc_10_12 right
2
8 0
186 0
1
0 0 0 1
1
end_operator
begin_operator
move loc_10_11 loc_11_11 down
2
20 0
187 0
1
0 0 0 13
1
end_operator
begin_operator
move loc_10_11 loc_9_11 up
2
169 0
188 0
1
0 0 0 137
1
end_operator
begin_operator
move loc_10_12 loc_10_11 left
2
7 0
189 0
1
0 0 1 0
1
end_operator
begin_operator
move loc_10_12 loc_10_13 right
2
9 0
190 0
1
0 0 1 2
1
end_operator
begin_operator
move loc_10_12 loc_11_12 down
2
21 0
191 0
1
0 0 1 14
1
end_operator
begin_operator
move loc_10_12 loc_9_12 up
2
170 0
192 0
1
0 0 1 138
1
end_operator
begin_operator
move loc_10_13 loc_10_12 left
2
8 0
193 0
1
0 0 2 1
1
end_operator
begin_operator
move loc_10_13 loc_10_14 right
2
10 0
194 0
1
0 0 2 3
1
end_operator
begin_operator
move loc_10_13 loc_9_13 up
2
171 0
195 0
1
0 0 2 139
1
end_operator
begin_operator
move loc_10_14 loc_10_13 left
2
9 0
196 0
1
0 0 3 2
1
end_operator
begin_operator
move loc_10_14 loc_10_15 right
2
11 0
197 0
1
0 0 3 4
1
end_operator
begin_operator
move loc_10_14 loc_9_14 up
2
172 0
198 0
1
0 0 3 140
1
end_operator
begin_operator
move loc_10_15 loc_10_14 left
2
10 0
199 0
1
0 0 4 3
1
end_operator
begin_operator
move loc_10_15 loc_10_16 right
2
12 0
200 0
1
0 0 4 5
1
end_operator
begin_operator
move loc_10_15 loc_9_15 up
2
173 0
201 0
1
0 0 4 141
1
end_operator
begin_operator
move loc_10_16 loc_10_15 left
2
11 0
202 0
1
0 0 5 4
1
end_operator
begin_operator
move loc_10_16 loc_10_17 right
2
13 0
203 0
1
0 0 5 6
1
end_operator
begin_operator
move loc_10_16 loc_9_16 up
2
174 0
204 0
1
0 0 5 142
1
end_operator
begin_operator
move loc_10_17 loc_10_16 left
2
12 0
205 0
1
0 0 6 5
1
end_operator
begin_operator
move loc_10_17 loc_10_18 right
2
14 0
206 0
1
0 0 6 7
1
end_operator
begin_operator
move loc_10_17 loc_11_17 down
2
22 0
207 0
1
0 0 6 15
1
end_operator
begin_operator
move loc_10_17 loc_9_17 up
2
175 0
208 0
1
0 0 6 143
1
end_operator
begin_operator
move loc_10_18 loc_10_17 left
2
13 0
209 0
1
0 0 7 6
1
end_operator
begin_operator
move loc_10_18 loc_10_19 right
2
15 0
210 0
1
0 0 7 8
1
end_operator
begin_operator
move loc_10_18 loc_11_18 down
2
23 0
211 0
1
0 0 7 16
1
end_operator
begin_operator
move loc_10_18 loc_9_18 up
2
176 0
212 0
1
0 0 7 144
1
end_operator
begin_operator
move loc_10_19 loc_10_18 left
2
14 0
213 0
1
0 0 8 7
1
end_operator
begin_operator
move loc_10_19 loc_11_19 down
2
24 0
214 0
1
0 0 8 17
1
end_operator
begin_operator
move loc_10_19 loc_9_19 up
2
177 0
215 0
1
0 0 8 145
1
end_operator
begin_operator
move loc_10_4 loc_10_5 right
2
17 0
216 0
1
0 0 9 10
1
end_operator
begin_operator
move loc_10_4 loc_11_4 down
2
28 0
217 0
1
0 0 9 21
1
end_operator
begin_operator
move loc_10_4 loc_9_4 up
2
181 0
218 0
1
0 0 9 149
1
end_operator
begin_operator
move loc_10_5 loc_10_4 left
2
16 0
219 0
1
0 0 10 9
1
end_operator
begin_operator
move loc_10_5 loc_10_6 right
2
18 0
220 0
1
0 0 10 11
1
end_operator
begin_operator
move loc_10_5 loc_11_5 down
2
29 0
221 0
1
0 0 10 22
1
end_operator
begin_operator
move loc_10_5 loc_9_5 up
2
182 0
222 0
1
0 0 10 150
1
end_operator
begin_operator
move loc_10_6 loc_10_5 left
2
17 0
223 0
1
0 0 11 10
1
end_operator
begin_operator
move loc_10_6 loc_10_7 right
2
19 0
224 0
1
0 0 11 12
1
end_operator
begin_operator
move loc_10_6 loc_9_6 up
2
183 0
225 0
1
0 0 11 151
1
end_operator
begin_operator
move loc_10_7 loc_10_6 left
2
18 0
226 0
1
0 0 12 11
1
end_operator
begin_operator
move loc_10_7 loc_11_7 down
2
30 0
227 0
1
0 0 12 23
1
end_operator
begin_operator
move loc_10_7 loc_9_7 up
2
184 0
228 0
1
0 0 12 152
1
end_operator
begin_operator
move loc_11_11 loc_10_11 up
2
7 0
229 0
1
0 0 13 0
1
end_operator
begin_operator
move loc_11_11 loc_11_12 right
2
21 0
230 0
1
0 0 13 14
1
end_operator
begin_operator
move loc_11_11 loc_12_11 down
2
31 0
231 0
1
0 0 13 24
1
end_operator
begin_operator
move loc_11_12 loc_10_12 up
2
8 0
232 0
1
0 0 14 1
1
end_operator
begin_operator
move loc_11_12 loc_11_11 left
2
20 0
233 0
1
0 0 14 13
1
end_operator
begin_operator
move loc_11_12 loc_12_12 down
2
32 0
234 0
1
0 0 14 25
1
end_operator
begin_operator
move loc_11_17 loc_10_17 up
2
13 0
235 0
1
0 0 15 6
1
end_operator
begin_operator
move loc_11_17 loc_11_18 right
2
23 0
236 0
1
0 0 15 16
1
end_operator
begin_operator
move loc_11_17 loc_12_17 down
2
37 0
237 0
1
0 0 15 30
1
end_operator
begin_operator
move loc_11_18 loc_10_18 up
2
14 0
238 0
1
0 0 16 7
1
end_operator
begin_operator
move loc_11_18 loc_11_17 left
2
22 0
239 0
1
0 0 16 15
1
end_operator
begin_operator
move loc_11_18 loc_11_19 right
2
24 0
240 0
1
0 0 16 17
1
end_operator
begin_operator
move loc_11_18 loc_12_18 down
2
38 0
241 0
1
0 0 16 31
1
end_operator
begin_operator
move loc_11_19 loc_10_19 up
2
15 0
242 0
1
0 0 17 8
1
end_operator
begin_operator
move loc_11_19 loc_11_18 left
2
23 0
243 0
1
0 0 17 16
1
end_operator
begin_operator
move loc_11_19 loc_11_20 right
2
26 0
244 0
1
0 0 17 19
1
end_operator
begin_operator
move loc_11_19 loc_12_19 down
2
39 0
245 0
1
0 0 17 32
1
end_operator
begin_operator
move loc_11_2 loc_11_3 right
2
27 0
246 0
1
0 0 18 20
1
end_operator
begin_operator
move loc_11_20 loc_11_19 left
2
24 0
247 0
1
0 0 19 17
1
end_operator
begin_operator
move loc_11_3 loc_11_2 left
2
25 0
248 0
1
0 0 20 18
1
end_operator
begin_operator
move loc_11_3 loc_11_4 right
2
28 0
249 0
1
0 0 20 21
1
end_operator
begin_operator
move loc_11_4 loc_10_4 up
2
16 0
250 0
1
0 0 21 9
1
end_operator
begin_operator
move loc_11_4 loc_11_3 left
2
27 0
251 0
1
0 0 21 20
1
end_operator
begin_operator
move loc_11_4 loc_11_5 right
2
29 0
252 0
1
0 0 21 22
1
end_operator
begin_operator
move loc_11_5 loc_10_5 up
2
17 0
253 0
1
0 0 22 10
1
end_operator
begin_operator
move loc_11_5 loc_11_4 left
2
28 0
254 0
1
0 0 22 21
1
end_operator
begin_operator
move loc_11_7 loc_10_7 up
2
19 0
255 0
1
0 0 23 12
1
end_operator
begin_operator
move loc_11_7 loc_12_7 down
2
40 0
256 0
1
0 0 23 33
1
end_operator
begin_operator
move loc_12_11 loc_11_11 up
2
20 0
257 0
1
0 0 24 13
1
end_operator
begin_operator
move loc_12_11 loc_12_12 right
2
32 0
258 0
1
0 0 24 25
1
end_operator
begin_operator
move loc_12_11 loc_13_11 down
2
43 0
259 0
1
0 0 24 35
1
end_operator
begin_operator
move loc_12_12 loc_11_12 up
2
21 0
260 0
1
0 0 25 14
1
end_operator
begin_operator
move loc_12_12 loc_12_11 left
2
31 0
261 0
1
0 0 25 24
1
end_operator
begin_operator
move loc_12_12 loc_12_13 right
2
33 0
262 0
1
0 0 25 26
1
end_operator
begin_operator
move loc_12_13 loc_12_12 left
2
32 0
263 0
1
0 0 26 25
1
end_operator
begin_operator
move loc_12_13 loc_12_14 right
2
34 0
264 0
1
0 0 26 27
1
end_operator
begin_operator
move loc_12_14 loc_12_13 left
2
33 0
265 0
1
0 0 27 26
1
end_operator
begin_operator
move loc_12_14 loc_12_15 right
2
35 0
266 0
1
0 0 27 28
1
end_operator
begin_operator
move loc_12_15 loc_12_14 left
2
34 0
267 0
1
0 0 28 27
1
end_operator
begin_operator
move loc_12_15 loc_12_16 right
2
36 0
268 0
1
0 0 28 29
1
end_operator
begin_operator
move loc_12_15 loc_13_15 down
2
44 0
269 0
1
0 0 28 36
1
end_operator
begin_operator
move loc_12_16 loc_12_15 left
2
35 0
270 0
1
0 0 29 28
1
end_operator
begin_operator
move loc_12_16 loc_12_17 right
2
37 0
271 0
1
0 0 29 30
1
end_operator
begin_operator
move loc_12_17 loc_11_17 up
2
22 0
272 0
1
0 0 30 15
1
end_operator
begin_operator
move loc_12_17 loc_12_16 left
2
36 0
273 0
1
0 0 30 29
1
end_operator
begin_operator
move loc_12_17 loc_12_18 right
2
38 0
274 0
1
0 0 30 31
1
end_operator
begin_operator
move loc_12_17 loc_13_17 down
2
45 0
275 0
1
0 0 30 37
1
end_operator
begin_operator
move loc_12_18 loc_11_18 up
2
23 0
276 0
1
0 0 31 16
1
end_operator
begin_operator
move loc_12_18 loc_12_17 left
2
37 0
277 0
1
0 0 31 30
1
end_operator
begin_operator
move loc_12_18 loc_12_19 right
2
39 0
278 0
1
0 0 31 32
1
end_operator
begin_operator
move loc_12_18 loc_13_18 down
2
46 0
279 0
1
0 0 31 38
1
end_operator
begin_operator
move loc_12_19 loc_11_19 up
2
24 0
280 0
1
0 0 32 17
1
end_operator
begin_operator
move loc_12_19 loc_12_18 left
2
38 0
281 0
1
0 0 32 31
1
end_operator
begin_operator
move loc_12_19 loc_13_19 down
2
47 0
282 0
1
0 0 32 39
1
end_operator
begin_operator
move loc_12_7 loc_11_7 up
2
30 0
283 0
1
0 0 33 23
1
end_operator
begin_operator
move loc_12_7 loc_13_7 down
2
52 0
284 0
1
0 0 33 43
1
end_operator
begin_operator
move loc_13_10 loc_13_11 right
2
43 0
285 0
1
0 0 34 35
1
end_operator
begin_operator
move loc_13_10 loc_14_10 down
2
53 0
286 0
1
0 0 34 44
1
end_operator
begin_operator
move loc_13_11 loc_12_11 up
2
31 0
287 0
1
0 0 35 24
1
end_operator
begin_operator
move loc_13_11 loc_13_10 left
2
42 0
288 0
1
0 0 35 34
1
end_operator
begin_operator
move loc_13_11 loc_14_11 down
2
54 0
289 0
1
0 0 35 45
1
end_operator
begin_operator
move loc_13_15 loc_12_15 up
2
35 0
290 0
1
0 0 36 28
1
end_operator
begin_operator
move loc_13_17 loc_12_17 up
2
37 0
291 0
1
0 0 37 30
1
end_operator
begin_operator
move loc_13_17 loc_13_18 right
2
46 0
292 0
1
0 0 37 38
1
end_operator
begin_operator
move loc_13_17 loc_14_17 down
2
56 0
293 0
1
0 0 37 47
1
end_operator
begin_operator
move loc_13_18 loc_12_18 up
2
38 0
294 0
1
0 0 38 31
1
end_operator
begin_operator
move loc_13_18 loc_13_17 left
2
45 0
295 0
1
0 0 38 37
1
end_operator
begin_operator
move loc_13_18 loc_13_19 right
2
47 0
296 0
1
0 0 38 39
1
end_operator
begin_operator
move loc_13_18 loc_14_18 down
2
57 0
297 0
1
0 0 38 48
1
end_operator
begin_operator
move loc_13_19 loc_12_19 up
2
39 0
298 0
1
0 0 39 32
1
end_operator
begin_operator
move loc_13_19 loc_13_18 left
2
46 0
299 0
1
0 0 39 38
1
end_operator
begin_operator
move loc_13_19 loc_14_19 down
2
58 0
300 0
1
0 0 39 49
1
end_operator
begin_operator
move loc_13_4 loc_13_5 right
2
50 0
301 0
1
0 0 40 41
1
end_operator
begin_operator
move loc_13_4 loc_14_4 down
2
59 0
302 0
1
0 0 40 50
1
end_operator
begin_operator
move loc_13_5 loc_13_4 left
2
49 0
303 0
1
0 0 41 40
1
end_operator
begin_operator
move loc_13_5 loc_13_6 right
2
51 0
304 0
1
0 0 41 42
1
end_operator
begin_operator
move loc_13_5 loc_14_5 down
2
60 0
305 0
1
0 0 41 51
1
end_operator
begin_operator
move loc_13_6 loc_13_5 left
2
50 0
306 0
1
0 0 42 41
1
end_operator
begin_operator
move loc_13_6 loc_13_7 right
2
52 0
307 0
1
0 0 42 43
1
end_operator
begin_operator
move loc_13_6 loc_14_6 down
2
61 0
308 0
1
0 0 42 52
1
end_operator
begin_operator
move loc_13_7 loc_12_7 up
2
40 0
309 0
1
0 0 43 33
1
end_operator
begin_operator
move loc_13_7 loc_13_6 left
2
51 0
310 0
1
0 0 43 42
1
end_operator
begin_operator
move loc_13_7 loc_14_7 down
2
62 0
311 0
1
0 0 43 53
1
end_operator
begin_operator
move loc_14_10 loc_13_10 up
2
42 0
312 0
1
0 0 44 34
1
end_operator
begin_operator
move loc_14_10 loc_14_11 right
2
54 0
313 0
1
0 0 44 45
1
end_operator
begin_operator
move loc_14_10 loc_14_9 left
2
64 0
314 0
1
0 0 44 55
1
end_operator
begin_operator
move loc_14_10 loc_15_10 down
2
65 0
315 0
1
0 0 44 56
1
end_operator
begin_operator
move loc_14_11 loc_13_11 up
2
43 0
316 0
1
0 0 45 35
1
end_operator
begin_operator
move loc_14_11 loc_14_10 left
2
53 0
317 0
1
0 0 45 44
1
end_operator
begin_operator
move loc_14_11 loc_14_12 right
2
55 0
318 0
1
0 0 45 46
1
end_operator
begin_operator
move loc_14_11 loc_15_11 down
2
66 0
319 0
1
0 0 45 57
1
end_operator
begin_operator
move loc_14_12 loc_14_11 left
2
54 0
320 0
1
0 0 46 45
1
end_operator
begin_operator
move loc_14_12 loc_15_12 down
2
67 0
321 0
1
0 0 46 58
1
end_operator
begin_operator
move loc_14_17 loc_13_17 up
2
45 0
322 0
1
0 0 47 37
1
end_operator
begin_operator
move loc_14_17 loc_14_18 right
2
57 0
323 0
1
0 0 47 48
1
end_operator
begin_operator
move loc_14_17 loc_15_17 down
2
72 0
324 0
1
0 0 47 63
1
end_operator
begin_operator
move loc_14_18 loc_13_18 up
2
46 0
325 0
1
0 0 48 38
1
end_operator
begin_operator
move loc_14_18 loc_14_17 left
2
56 0
326 0
1
0 0 48 47
1
end_operator
begin_operator
move loc_14_18 loc_14_19 right
2
58 0
327 0
1
0 0 48 49
1
end_operator
begin_operator
move loc_14_18 loc_15_18 down
2
73 0
328 0
1
0 0 48 64
1
end_operator
begin_operator
move loc_14_19 loc_13_19 up
2
47 0
329 0
1
0 0 49 39
1
end_operator
begin_operator
move loc_14_19 loc_14_18 left
2
57 0
330 0
1
0 0 49 48
1
end_operator
begin_operator
move loc_14_19 loc_15_19 down
2
74 0
331 0
1
0 0 49 65
1
end_operator
begin_operator
move loc_14_4 loc_13_4 up
2
49 0
332 0
1
0 0 50 40
1
end_operator
begin_operator
move loc_14_4 loc_14_5 right
2
60 0
333 0
1
0 0 50 51
1
end_operator
begin_operator
move loc_14_5 loc_13_5 up
2
50 0
334 0
1
0 0 51 41
1
end_operator
begin_operator
move loc_14_5 loc_14_4 left
2
59 0
335 0
1
0 0 51 50
1
end_operator
begin_operator
move loc_14_5 loc_14_6 right
2
61 0
336 0
1
0 0 51 52
1
end_operator
begin_operator
move loc_14_5 loc_15_5 down
2
75 0
337 0
1
0 0 51 66
1
end_operator
begin_operator
move loc_14_6 loc_13_6 up
2
51 0
338 0
1
0 0 52 42
1
end_operator
begin_operator
move loc_14_6 loc_14_5 left
2
60 0
339 0
1
0 0 52 51
1
end_operator
begin_operator
move loc_14_6 loc_14_7 right
2
62 0
340 0
1
0 0 52 53
1
end_operator
begin_operator
move loc_14_6 loc_15_6 down
2
76 0
341 0
1
0 0 52 67
1
end_operator
begin_operator
move loc_14_7 loc_13_7 up
2
52 0
342 0
1
0 0 53 43
1
end_operator
begin_operator
move loc_14_7 loc_14_6 left
2
61 0
343 0
1
0 0 53 52
1
end_operator
begin_operator
move loc_14_7 loc_14_8 right
2
63 0
344 0
1
0 0 53 54
1
end_operator
begin_operator
move loc_14_7 loc_15_7 down
2
77 0
345 0
1
0 0 53 68
1
end_operator
begin_operator
move loc_14_8 loc_14_7 left
2
62 0
346 0
1
0 0 54 53
1
end_operator
begin_operator
move loc_14_8 loc_14_9 right
2
64 0
347 0
1
0 0 54 55
1
end_operator
begin_operator
move loc_14_8 loc_15_8 down
2
78 0
348 0
1
0 0 54 69
1
end_operator
begin_operator
move loc_14_9 loc_14_10 right
2
53 0
349 0
1
0 0 55 44
1
end_operator
begin_operator
move loc_14_9 loc_14_8 left
2
63 0
350 0
1
0 0 55 54
1
end_operator
begin_operator
move loc_14_9 loc_15_9 down
2
79 0
351 0
1
0 0 55 70
1
end_operator
begin_operator
move loc_15_10 loc_14_10 up
2
53 0
352 0
1
0 0 56 44
1
end_operator
begin_operator
move loc_15_10 loc_15_11 right
2
66 0
353 0
1
0 0 56 57
1
end_operator
begin_operator
move loc_15_10 loc_15_9 left
2
79 0
354 0
1
0 0 56 70
1
end_operator
begin_operator
move loc_15_10 loc_16_10 down
2
80 0
355 0
1
0 0 56 71
1
end_operator
begin_operator
move loc_15_11 loc_14_11 up
2
54 0
356 0
1
0 0 57 45
1
end_operator
begin_operator
move loc_15_11 loc_15_10 left
2
65 0
357 0
1
0 0 57 56
1
end_operator
begin_operator
move loc_15_11 loc_15_12 right
2
67 0
358 0
1
0 0 57 58
1
end_operator
begin_operator
move loc_15_12 loc_14_12 up
2
55 0
359 0
1
0 0 58 46
1
end_operator
begin_operator
move loc_15_12 loc_15_11 left
2
66 0
360 0
1
0 0 58 57
1
end_operator
begin_operator
move loc_15_12 loc_15_13 right
2
68 0
361 0
1
0 0 58 59
1
end_operator
begin_operator
move loc_15_13 loc_15_12 left
2
67 0
362 0
1
0 0 59 58
1
end_operator
begin_operator
move loc_15_13 loc_15_14 right
2
69 0
363 0
1
0 0 59 60
1
end_operator
begin_operator
move loc_15_14 loc_15_13 left
2
68 0
364 0
1
0 0 60 59
1
end_operator
begin_operator
move loc_15_14 loc_15_15 right
2
70 0
365 0
1
0 0 60 61
1
end_operator
begin_operator
move loc_15_15 loc_15_14 left
2
69 0
366 0
1
0 0 61 60
1
end_operator
begin_operator
move loc_15_15 loc_15_16 right
2
71 0
367 0
1
0 0 61 62
1
end_operator
begin_operator
move loc_15_15 loc_16_15 down
2
81 0
368 0
1
0 0 61 72
1
end_operator
begin_operator
move loc_15_16 loc_15_15 left
2
70 0
369 0
1
0 0 62 61
1
end_operator
begin_operator
move loc_15_16 loc_15_17 right
2
72 0
370 0
1
0 0 62 63
1
end_operator
begin_operator
move loc_15_17 loc_14_17 up
2
56 0
371 0
1
0 0 63 47
1
end_operator
begin_operator
move loc_15_17 loc_15_16 left
2
71 0
372 0
1
0 0 63 62
1
end_operator
begin_operator
move loc_15_17 loc_15_18 right
2
73 0
373 0
1
0 0 63 64
1
end_operator
begin_operator
move loc_15_17 loc_16_17 down
2
82 0
374 0
1
0 0 63 73
1
end_operator
begin_operator
move loc_15_18 loc_14_18 up
2
57 0
375 0
1
0 0 64 48
1
end_operator
begin_operator
move loc_15_18 loc_15_17 left
2
72 0
376 0
1
0 0 64 63
1
end_operator
begin_operator
move loc_15_18 loc_15_19 right
2
74 0
377 0
1
0 0 64 65
1
end_operator
begin_operator
move loc_15_18 loc_16_18 down
2
83 0
378 0
1
0 0 64 74
1
end_operator
begin_operator
move loc_15_19 loc_14_19 up
2
58 0
379 0
1
0 0 65 49
1
end_operator
begin_operator
move loc_15_19 loc_15_18 left
2
73 0
380 0
1
0 0 65 64
1
end_operator
begin_operator
move loc_15_19 loc_16_19 down
2
84 0
381 0
1
0 0 65 75
1
end_operator
begin_operator
move loc_15_5 loc_14_5 up
2
60 0
382 0
1
0 0 66 51
1
end_operator
begin_operator
move loc_15_5 loc_15_6 right
2
76 0
383 0
1
0 0 66 67
1
end_operator
begin_operator
move loc_15_6 loc_14_6 up
2
61 0
384 0
1
0 0 67 52
1
end_operator
begin_operator
move loc_15_6 loc_15_5 left
2
75 0
385 0
1
0 0 67 66
1
end_operator
begin_operator
move loc_15_6 loc_15_7 right
2
77 0
386 0
1
0 0 67 68
1
end_operator
begin_operator
move loc_15_7 loc_14_7 up
2
62 0
387 0
1
0 0 68 53
1
end_operator
begin_operator
move loc_15_7 loc_15_6 left
2
76 0
388 0
1
0 0 68 67
1
end_operator
begin_operator
move loc_15_7 loc_15_8 right
2
78 0
389 0
1
0 0 68 69
1
end_operator
begin_operator
move loc_15_8 loc_14_8 up
2
63 0
390 0
1
0 0 69 54
1
end_operator
begin_operator
move loc_15_8 loc_15_7 left
2
77 0
391 0
1
0 0 69 68
1
end_operator
begin_operator
move loc_15_8 loc_15_9 right
2
79 0
392 0
1
0 0 69 70
1
end_operator
begin_operator
move loc_15_9 loc_14_9 up
2
64 0
393 0
1
0 0 70 55
1
end_operator
begin_operator
move loc_15_9 loc_15_10 right
2
65 0
394 0
1
0 0 70 56
1
end_operator
begin_operator
move loc_15_9 loc_15_8 left
2
78 0
395 0
1
0 0 70 69
1
end_operator
begin_operator
move loc_16_10 loc_15_10 up
2
65 0
396 0
1
0 0 71 56
1
end_operator
begin_operator
move loc_16_15 loc_15_15 up
2
70 0
397 0
1
0 0 72 61
1
end_operator
begin_operator
move loc_16_17 loc_15_17 up
2
72 0
398 0
1
0 0 73 63
1
end_operator
begin_operator
move loc_16_17 loc_16_18 right
2
83 0
399 0
1
0 0 73 74
1
end_operator
begin_operator
move loc_16_17 loc_17_17 down
2
88 0
400 0
1
0 0 73 78
1
end_operator
begin_operator
move loc_16_18 loc_15_18 up
2
73 0
401 0
1
0 0 74 64
1
end_operator
begin_operator
move loc_16_18 loc_16_17 left
2
82 0
402 0
1
0 0 74 73
1
end_operator
begin_operator
move loc_16_18 loc_16_19 right
2
84 0
403 0
1
0 0 74 75
1
end_operator
begin_operator
move loc_16_19 loc_15_19 up
2
74 0
404 0
1
0 0 75 65
1
end_operator
begin_operator
move loc_16_19 loc_16_18 left
2
83 0
405 0
1
0 0 75 74
1
end_operator
begin_operator
move loc_16_19 loc_16_20 right
2
85 0
406 0
1
0 0 75 76
1
end_operator
begin_operator
move loc_16_20 loc_16_19 left
2
84 0
407 0
1
0 0 76 75
1
end_operator
begin_operator
move loc_17_16 loc_17_17 right
2
88 0
408 0
1
0 0 77 78
1
end_operator
begin_operator
move loc_17_16 loc_18_16 down
2
92 0
409 0
1
0 0 77 79
1
end_operator
begin_operator
move loc_17_17 loc_16_17 up
2
82 0
410 0
1
0 0 78 73
1
end_operator
begin_operator
move loc_17_17 loc_17_16 left
2
87 0
411 0
1
0 0 78 77
1
end_operator
begin_operator
move loc_18_16 loc_17_16 up
2
87 0
414 0
1
0 0 79 77
1
end_operator
begin_operator
move loc_2_3 loc_3_3 down
2
111 0
423 0
1
0 0 80 84
1
end_operator
begin_operator
move loc_2_5 loc_3_5 down
2
113 0
424 0
1
0 0 81 86
1
end_operator
begin_operator
move loc_3_2 loc_3_3 right
2
111 0
428 0
1
0 0 82 84
1
end_operator
begin_operator
move loc_3_2 loc_4_2 down
2
118 0
429 0
1
0 0 82 88
1
end_operator
begin_operator
move loc_3_20 loc_4_20 down
2
119 0
430 0
1
0 0 83 89
1
end_operator
begin_operator
move loc_3_3 loc_2_3 up
2
104 0
431 0
1
0 0 84 80
1
end_operator
begin_operator
move loc_3_3 loc_3_2 left
2
109 0
432 0
1
0 0 84 82
1
end_operator
begin_operator
move loc_3_3 loc_3_4 right
2
112 0
433 0
1
0 0 84 85
1
end_operator
begin_operator
move loc_3_4 loc_3_3 left
2
111 0
434 0
1
0 0 85 84
1
end_operator
begin_operator
move loc_3_4 loc_3_5 right
2
113 0
435 0
1
0 0 85 86
1
end_operator
begin_operator
move loc_3_5 loc_2_5 up
2
105 0
436 0
1
0 0 86 81
1
end_operator
begin_operator
move loc_3_5 loc_3_4 left
2
112 0
437 0
1
0 0 86 85
1
end_operator
begin_operator
move loc_3_5 loc_3_6 right
2
114 0
438 0
1
0 0 86 87
1
end_operator
begin_operator
move loc_3_5 loc_4_5 down
2
120 0
439 0
1
0 0 86 90
1
end_operator
begin_operator
move loc_3_6 loc_3_5 left
2
113 0
440 0
1
0 0 87 86
1
end_operator
begin_operator
move loc_3_6 loc_4_6 down
2
121 0
441 0
1
0 0 87 91
1
end_operator
begin_operator
move loc_4_2 loc_3_2 up
2
109 0
446 0
1
0 0 88 82
1
end_operator
begin_operator
move loc_4_2 loc_5_2 down
2
126 0
447 0
1
0 0 88 94
1
end_operator
begin_operator
move loc_4_20 loc_3_20 up
2
110 0
448 0
1
0 0 89 83
1
end_operator
begin_operator
move loc_4_20 loc_5_20 down
2
127 0
449 0
1
0 0 89 95
1
end_operator
begin_operator
move loc_4_5 loc_3_5 up
2
113 0
450 0
1
0 0 90 86
1
end_operator
begin_operator
move loc_4_5 loc_4_6 right
2
121 0
451 0
1
0 0 90 91
1
end_operator
begin_operator
move loc_4_5 loc_5_5 down
2
128 0
452 0
1
0 0 90 96
1
end_operator
begin_operator
move loc_4_6 loc_3_6 up
2
114 0
453 0
1
0 0 91 87
1
end_operator
begin_operator
move loc_4_6 loc_4_5 left
2
120 0
454 0
1
0 0 91 90
1
end_operator
begin_operator
move loc_4_6 loc_5_6 down
2
129 0
455 0
1
0 0 91 97
1
end_operator
begin_operator
move loc_5_18 loc_5_19 right
2
125 0
457 0
1
0 0 92 93
1
end_operator
begin_operator
move loc_5_18 loc_6_18 down
2
135 0
458 0
1
0 0 92 103
1
end_operator
begin_operator
move loc_5_19 loc_5_18 left
2
124 0
459 0
1
0 0 93 92
1
end_operator
begin_operator
move loc_5_19 loc_5_20 right
2
127 0
460 0
1
0 0 93 95
1
end_operator
begin_operator
move loc_5_19 loc_6_19 down
2
136 0
461 0
1
0 0 93 104
1
end_operator
begin_operator
move loc_5_2 loc_4_2 up
2
118 0
462 0
1
0 0 94 88
1
end_operator
begin_operator
move loc_5_2 loc_6_2 down
2
137 0
463 0
1
0 0 94 105
1
end_operator
begin_operator
move loc_5_20 loc_4_20 up
2
119 0
464 0
1
0 0 95 89
1
end_operator
begin_operator
move loc_5_20 loc_5_19 left
2
125 0
465 0
1
0 0 95 93
1
end_operator
begin_operator
move loc_5_5 loc_4_5 up
2
120 0
466 0
1
0 0 96 90
1
end_operator
begin_operator
move loc_5_5 loc_5_6 right
2
129 0
467 0
1
0 0 96 97
1
end_operator
begin_operator
move loc_5_5 loc_6_5 down
2
138 0
468 0
1
0 0 96 106
1
end_operator
begin_operator
move loc_5_6 loc_4_6 up
2
121 0
469 0
1
0 0 97 91
1
end_operator
begin_operator
move loc_5_6 loc_5_5 left
2
128 0
470 0
1
0 0 97 96
1
end_operator
begin_operator
move loc_5_6 loc_5_7 right
2
130 0
471 0
1
0 0 97 98
1
end_operator
begin_operator
move loc_5_6 loc_6_6 down
2
139 0
472 0
1
0 0 97 107
1
end_operator
begin_operator
move loc_5_7 loc_5_6 left
2
129 0
473 0
1
0 0 98 97
1
end_operator
begin_operator
move loc_5_7 loc_5_8 right
2
131 0
474 0
1
0 0 98 99
1
end_operator
begin_operator
move loc_5_7 loc_6_7 down
2
140 0
475 0
1
0 0 98 108
1
end_operator
begin_operator
move loc_5_8 loc_5_7 left
2
130 0
476 0
1
0 0 99 98
1
end_operator
begin_operator
move loc_5_8 loc_5_9 right
2
132 0
477 0
1
0 0 99 100
1
end_operator
begin_operator
move loc_5_9 loc_5_8 left
2
131 0
478 0
1
0 0 100 99
1
end_operator
begin_operator
move loc_5_9 loc_6_9 down
2
141 0
479 0
1
0 0 100 109
1
end_operator
begin_operator
move loc_6_11 loc_7_11 down
2
143 0
480 0
1
0 0 101 111
1
end_operator
begin_operator
move loc_6_17 loc_6_18 right
2
135 0
481 0
1
0 0 102 103
1
end_operator
begin_operator
move loc_6_17 loc_7_17 down
2
145 0
482 0
1
0 0 102 113
1
end_operator
begin_operator
move loc_6_18 loc_5_18 up
2
124 0
483 0
1
0 0 103 92
1
end_operator
begin_operator
move loc_6_18 loc_6_17 left
2
134 0
484 0
1
0 0 103 102
1
end_operator
begin_operator
move loc_6_18 loc_6_19 right
2
136 0
485 0
1
0 0 103 104
1
end_operator
begin_operator
move loc_6_18 loc_7_18 down
2
146 0
486 0
1
0 0 103 114
1
end_operator
begin_operator
move loc_6_19 loc_5_19 up
2
125 0
487 0
1
0 0 104 93
1
end_operator
begin_operator
move loc_6_19 loc_6_18 left
2
135 0
488 0
1
0 0 104 103
1
end_operator
begin_operator
move loc_6_19 loc_7_19 down
2
147 0
489 0
1
0 0 104 115
1
end_operator
begin_operator
move loc_6_2 loc_5_2 up
2
126 0
490 0
1
0 0 105 94
1
end_operator
begin_operator
move loc_6_2 loc_7_2 down
2
148 0
491 0
1
0 0 105 116
1
end_operator
begin_operator
move loc_6_5 loc_5_5 up
2
128 0
492 0
1
0 0 106 96
1
end_operator
begin_operator
move loc_6_5 loc_6_6 right
2
139 0
493 0
1
0 0 106 107
1
end_operator
begin_operator
move loc_6_5 loc_7_5 down
2
150 0
494 0
1
0 0 106 118
1
end_operator
begin_operator
move loc_6_6 loc_5_6 up
2
129 0
495 0
1
0 0 107 97
1
end_operator
begin_operator
move loc_6_6 loc_6_5 left
2
138 0
496 0
1
0 0 107 106
1
end_operator
begin_operator
move loc_6_6 loc_6_7 right
2
140 0
497 0
1
0 0 107 108
1
end_operator
begin_operator
move loc_6_7 loc_5_7 up
2
130 0
498 0
1
0 0 108 98
1
end_operator
begin_operator
move loc_6_7 loc_6_6 left
2
139 0
499 0
1
0 0 108 107
1
end_operator
begin_operator
move loc_6_7 loc_7_7 down
2
151 0
500 0
1
0 0 108 119
1
end_operator
begin_operator
move loc_6_9 loc_5_9 up
2
132 0
501 0
1
0 0 109 100
1
end_operator
begin_operator
move loc_6_9 loc_7_9 down
2
153 0
502 0
1
0 0 109 121
1
end_operator
begin_operator
move loc_7_10 loc_7_11 right
2
143 0
503 0
1
0 0 110 111
1
end_operator
begin_operator
move loc_7_10 loc_7_9 left
2
153 0
504 0
1
0 0 110 121
1
end_operator
begin_operator
move loc_7_10 loc_8_10 down
2
154 0
505 0
1
0 0 110 122
1
end_operator
begin_operator
move loc_7_11 loc_6_11 up
2
133 0
506 0
1
0 0 111 101
1
end_operator
begin_operator
move loc_7_11 loc_7_10 left
2
142 0
507 0
1
0 0 111 110
1
end_operator
begin_operator
move loc_7_11 loc_7_12 right
2
144 0
508 0
1
0 0 111 112
1
end_operator
begin_operator
move loc_7_11 loc_8_11 down
2
155 0
509 0
1
0 0 111 123
1
end_operator
begin_operator
move loc_7_12 loc_7_11 left
2
143 0
510 0
1
0 0 112 111
1
end_operator
begin_operator
move loc_7_12 loc_8_12 down
2
156 0
511 0
1
0 0 112 124
1
end_operator
begin_operator
move loc_7_17 loc_6_17 up
2
134 0
512 0
1
0 0 113 102
1
end_operator
begin_operator
move loc_7_17 loc_7_18 right
2
146 0
513 0
1
0 0 113 114
1
end_operator
begin_operator
move loc_7_17 loc_8_17 down
2
158 0
514 0
1
0 0 113 126
1
end_operator
begin_operator
move loc_7_18 loc_6_18 up
2
135 0
515 0
1
0 0 114 103
1
end_operator
begin_operator
move loc_7_18 loc_7_17 left
2
145 0
516 0
1
0 0 114 113
1
end_operator
begin_operator
move loc_7_18 loc_7_19 right
2
147 0
517 0
1
0 0 114 115
1
end_operator
begin_operator
move loc_7_18 loc_8_18 down
2
159 0
518 0
1
0 0 114 127
1
end_operator
begin_operator
move loc_7_19 loc_6_19 up
2
136 0
519 0
1
0 0 115 104
1
end_operator
begin_operator
move loc_7_19 loc_7_18 left
2
146 0
520 0
1
0 0 115 114
1
end_operator
begin_operator
move loc_7_19 loc_8_19 down
2
160 0
521 0
1
0 0 115 128
1
end_operator
begin_operator
move loc_7_2 loc_6_2 up
2
137 0
522 0
1
0 0 116 105
1
end_operator
begin_operator
move loc_7_2 loc_8_2 down
2
161 0
523 0
1
0 0 116 129
1
end_operator
begin_operator
move loc_7_4 loc_7_5 right
2
150 0
524 0
1
0 0 117 118
1
end_operator
begin_operator
move loc_7_4 loc_8_4 down
2
162 0
525 0
1
0 0 117 130
1
end_operator
begin_operator
move loc_7_5 loc_6_5 up
2
138 0
526 0
1
0 0 118 106
1
end_operator
begin_operator
move loc_7_5 loc_7_4 left
2
149 0
527 0
1
0 0 118 117
1
end_operator
begin_operator
move loc_7_5 loc_8_5 down
2
163 0
528 0
1
0 0 118 131
1
end_operator
begin_operator
move loc_7_7 loc_6_7 up
2
140 0
529 0
1
0 0 119 108
1
end_operator
begin_operator
move loc_7_7 loc_7_8 right
2
152 0
530 0
1
0 0 119 120
1
end_operator
begin_operator
move loc_7_7 loc_8_7 down
2
165 0
531 0
1
0 0 119 133
1
end_operator
begin_operator
move loc_7_8 loc_7_7 left
2
151 0
532 0
1
0 0 120 119
1
end_operator
begin_operator
move loc_7_8 loc_7_9 right
2
153 0
533 0
1
0 0 120 121
1
end_operator
begin_operator
move loc_7_8 loc_8_8 down
2
166 0
534 0
1
0 0 120 134
1
end_operator
begin_operator
move loc_7_9 loc_6_9 up
2
141 0
535 0
1
0 0 121 109
1
end_operator
begin_operator
move loc_7_9 loc_7_10 right
2
142 0
536 0
1
0 0 121 110
1
end_operator
begin_operator
move loc_7_9 loc_7_8 left
2
152 0
537 0
1
0 0 121 120
1
end_operator
begin_operator
move loc_7_9 loc_8_9 down
2
167 0
538 0
1
0 0 121 135
1
end_operator
begin_operator
move loc_8_10 loc_7_10 up
2
142 0
539 0
1
0 0 122 110
1
end_operator
begin_operator
move loc_8_10 loc_8_11 right
2
155 0
540 0
1
0 0 122 123
1
end_operator
begin_operator
move loc_8_10 loc_8_9 left
2
167 0
541 0
1
0 0 122 135
1
end_operator
begin_operator
move loc_8_10 loc_9_10 down
2
168 0
542 0
1
0 0 122 136
1
end_operator
begin_operator
move loc_8_11 loc_7_11 up
2
143 0
543 0
1
0 0 123 111
1
end_operator
begin_operator
move loc_8_11 loc_8_10 left
2
154 0
544 0
1
0 0 123 122
1
end_operator
begin_operator
move loc_8_11 loc_8_12 right
2
156 0
545 0
1
0 0 123 124
1
end_operator
begin_operator
move loc_8_11 loc_9_11 down
2
169 0
546 0
1
0 0 123 137
1
end_operator
begin_operator
move loc_8_12 loc_7_12 up
2
144 0
547 0
1
0 0 124 112
1
end_operator
begin_operator
move loc_8_12 loc_8_11 left
2
155 0
548 0
1
0 0 124 123
1
end_operator
begin_operator
move loc_8_12 loc_8_13 right
2
157 0
549 0
1
0 0 124 125
1
end_operator
begin_operator
move loc_8_12 loc_9_12 down
2
170 0
550 0
1
0 0 124 138
1
end_operator
begin_operator
move loc_8_13 loc_8_12 left
2
156 0
551 0
1
0 0 125 124
1
end_operator
begin_operator
move loc_8_13 loc_9_13 down
2
171 0
552 0
1
0 0 125 139
1
end_operator
begin_operator
move loc_8_17 loc_7_17 up
2
145 0
553 0
1
0 0 126 113
1
end_operator
begin_operator
move loc_8_17 loc_8_18 right
2
159 0
554 0
1
0 0 126 127
1
end_operator
begin_operator
move loc_8_17 loc_9_17 down
2
175 0
555 0
1
0 0 126 143
1
end_operator
begin_operator
move loc_8_18 loc_7_18 up
2
146 0
556 0
1
0 0 127 114
1
end_operator
begin_operator
move loc_8_18 loc_8_17 left
2
158 0
557 0
1
0 0 127 126
1
end_operator
begin_operator
move loc_8_18 loc_8_19 right
2
160 0
558 0
1
0 0 127 128
1
end_operator
begin_operator
move loc_8_18 loc_9_18 down
2
176 0
559 0
1
0 0 127 144
1
end_operator
begin_operator
move loc_8_19 loc_7_19 up
2
147 0
560 0
1
0 0 128 115
1
end_operator
begin_operator
move loc_8_19 loc_8_18 left
2
159 0
561 0
1
0 0 128 127
1
end_operator
begin_operator
move loc_8_19 loc_9_19 down
2
177 0
562 0
1
0 0 128 145
1
end_operator
begin_operator
move loc_8_2 loc_7_2 up
2
148 0
563 0
1
0 0 129 116
1
end_operator
begin_operator
move loc_8_2 loc_9_2 down
2
178 0
564 0
1
0 0 129 146
1
end_operator
begin_operator
move loc_8_4 loc_7_4 up
2
149 0
565 0
1
0 0 130 117
1
end_operator
begin_operator
move loc_8_4 loc_8_5 right
2
163 0
566 0
1
0 0 130 131
1
end_operator
begin_operator
move loc_8_4 loc_9_4 down
2
181 0
567 0
1
0 0 130 149
1
end_operator
begin_operator
move loc_8_5 loc_7_5 up
2
150 0
568 0
1
0 0 131 118
1
end_operator
begin_operator
move loc_8_5 loc_8_4 left
2
162 0
569 0
1
0 0 131 130
1
end_operator
begin_operator
move loc_8_5 loc_8_6 right
2
164 0
570 0
1
0 0 131 132
1
end_operator
begin_operator
move loc_8_5 loc_9_5 down
2
182 0
571 0
1
0 0 131 150
1
end_operator
begin_operator
move loc_8_6 loc_8_5 left
2
163 0
572 0
1
0 0 132 131
1
end_operator
begin_operator
move loc_8_6 loc_8_7 right
2
165 0
573 0
1
0 0 132 133
1
end_operator
begin_operator
move loc_8_6 loc_9_6 down
2
183 0
574 0
1
0 0 132 151
1
end_operator
begin_operator
move loc_8_7 loc_7_7 up
2
151 0
575 0
1
0 0 133 119
1
end_operator
begin_operator
move loc_8_7 loc_8_6 left
2
164 0
576 0
1
0 0 133 132
1
end_operator
begin_operator
move loc_8_7 loc_8_8 right
2
166 0
577 0
1
0 0 133 134
1
end_operator
begin_operator
move loc_8_7 loc_9_7 down
2
184 0
578 0
1
0 0 133 152
1
end_operator
begin_operator
move loc_8_8 loc_7_8 up
2
152 0
579 0
1
0 0 134 120
1
end_operator
begin_operator
move loc_8_8 loc_8_7 left
2
165 0
580 0
1
0 0 134 133
1
end_operator
begin_operator
move loc_8_8 loc_8_9 right
2
167 0
581 0
1
0 0 134 135
1
end_operator
begin_operator
move loc_8_9 loc_7_9 up
2
153 0
582 0
1
0 0 135 121
1
end_operator
begin_operator
move loc_8_9 loc_8_10 right
2
154 0
583 0
1
0 0 135 122
1
end_operator
begin_operator
move loc_8_9 loc_8_8 left
2
166 0
584 0
1
0 0 135 134
1
end_operator
begin_operator
move loc_8_9 loc_9_9 down
2
185 0
585 0
1
0 0 135 153
1
end_operator
begin_operator
move loc_9_10 loc_8_10 up
2
154 0
586 0
1
0 0 136 122
1
end_operator
begin_operator
move loc_9_10 loc_9_11 right
2
169 0
587 0
1
0 0 136 137
1
end_operator
begin_operator
move loc_9_10 loc_9_9 left
2
185 0
588 0
1
0 0 136 153
1
end_operator
begin_operator
move loc_9_11 loc_10_11 down
2
7 0
589 0
1
0 0 137 0
1
end_operator
begin_operator
move loc_9_11 loc_8_11 up
2
155 0
590 0
1
0 0 137 123
1
end_operator
begin_operator
move loc_9_11 loc_9_10 left
2
168 0
591 0
1
0 0 137 136
1
end_operator
begin_operator
move loc_9_11 loc_9_12 right
2
170 0
592 0
1
0 0 137 138
1
end_operator
begin_operator
move loc_9_12 loc_10_12 down
2
8 0
593 0
1
0 0 138 1
1
end_operator
begin_operator
move loc_9_12 loc_8_12 up
2
156 0
594 0
1
0 0 138 124
1
end_operator
begin_operator
move loc_9_12 loc_9_11 left
2
169 0
595 0
1
0 0 138 137
1
end_operator
begin_operator
move loc_9_12 loc_9_13 right
2
171 0
596 0
1
0 0 138 139
1
end_operator
begin_operator
move loc_9_13 loc_10_13 down
2
9 0
597 0
1
0 0 139 2
1
end_operator
begin_operator
move loc_9_13 loc_8_13 up
2
157 0
598 0
1
0 0 139 125
1
end_operator
begin_operator
move loc_9_13 loc_9_12 left
2
170 0
599 0
1
0 0 139 138
1
end_operator
begin_operator
move loc_9_13 loc_9_14 right
2
172 0
600 0
1
0 0 139 140
1
end_operator
begin_operator
move loc_9_14 loc_10_14 down
2
10 0
601 0
1
0 0 140 3
1
end_operator
begin_operator
move loc_9_14 loc_9_13 left
2
171 0
602 0
1
0 0 140 139
1
end_operator
begin_operator
move loc_9_14 loc_9_15 right
2
173 0
603 0
1
0 0 140 141
1
end_operator
begin_operator
move loc_9_15 loc_10_15 down
2
11 0
604 0
1
0 0 141 4
1
end_operator
begin_operator
move loc_9_15 loc_9_14 left
2
172 0
605 0
1
0 0 141 140
1
end_operator
begin_operator
move loc_9_15 loc_9_16 right
2
174 0
606 0
1
0 0 141 142
1
end_operator
begin_operator
move loc_9_16 loc_10_16 down
2
12 0
607 0
1
0 0 142 5
1
end_operator
begin_operator
move loc_9_16 loc_9_15 left
2
173 0
608 0
1
0 0 142 141
1
end_operator
begin_operator
move loc_9_16 loc_9_17 right
2
175 0
609 0
1
0 0 142 143
1
end_operator
begin_operator
move loc_9_17 loc_10_17 down
2
13 0
610 0
1
0 0 143 6
1
end_operator
begin_operator
move loc_9_17 loc_8_17 up
2
158 0
611 0
1
0 0 143 126
1
end_operator
begin_operator
move loc_9_17 loc_9_16 left
2
174 0
612 0
1
0 0 143 142
1
end_operator
begin_operator
move loc_9_17 loc_9_18 right
2
176 0
613 0
1
0 0 143 144
1
end_operator
begin_operator
move loc_9_18 loc_10_18 down
2
14 0
614 0
1
0 0 144 7
1
end_operator
begin_operator
move loc_9_18 loc_8_18 up
2
159 0
615 0
1
0 0 144 127
1
end_operator
begin_operator
move loc_9_18 loc_9_17 left
2
175 0
616 0
1
0 0 144 143
1
end_operator
begin_operator
move loc_9_18 loc_9_19 right
2
177 0
617 0
1
0 0 144 145
1
end_operator
begin_operator
move loc_9_19 loc_10_19 down
2
15 0
618 0
1
0 0 145 8
1
end_operator
begin_operator
move loc_9_19 loc_8_19 up
2
160 0
619 0
1
0 0 145 128
1
end_operator
begin_operator
move loc_9_19 loc_9_18 left
2
176 0
620 0
1
0 0 145 144
1
end_operator
begin_operator
move loc_9_19 loc_9_20 right
2
179 0
621 0
1
0 0 145 147
1
end_operator
begin_operator
move loc_9_2 loc_8_2 up
2
161 0
622 0
1
0 0 146 129
1
end_operator
begin_operator
move loc_9_2 loc_9_3 right
2
180 0
623 0
1
0 0 146 148
1
end_operator
begin_operator
move loc_9_20 loc_9_19 left
2
177 0
624 0
1
0 0 147 145
1
end_operator
begin_operator
move loc_9_3 loc_9_2 left
2
178 0
625 0
1
0 0 148 146
1
end_operator
begin_operator
move loc_9_3 loc_9_4 right
2
181 0
626 0
1
0 0 148 149
1
end_operator
begin_operator
move loc_9_4 loc_10_4 down
2
16 0
627 0
1
0 0 149 9
1
end_operator
begin_operator
move loc_9_4 loc_8_4 up
2
162 0
628 0
1
0 0 149 130
1
end_operator
begin_operator
move loc_9_4 loc_9_3 left
2
180 0
629 0
1
0 0 149 148
1
end_operator
begin_operator
move loc_9_4 loc_9_5 right
2
182 0
630 0
1
0 0 149 150
1
end_operator
begin_operator
move loc_9_5 loc_10_5 down
2
17 0
631 0
1
0 0 150 10
1
end_operator
begin_operator
move loc_9_5 loc_8_5 up
2
163 0
632 0
1
0 0 150 131
1
end_operator
begin_operator
move loc_9_5 loc_9_4 left
2
181 0
633 0
1
0 0 150 149
1
end_operator
begin_operator
move loc_9_5 loc_9_6 right
2
183 0
634 0
1
0 0 150 151
1
end_operator
begin_operator
move loc_9_6 loc_10_6 down
2
18 0
635 0
1
0 0 151 11
1
end_operator
begin_operator
move loc_9_6 loc_8_6 up
2
164 0
636 0
1
0 0 151 132
1
end_operator
begin_operator
move loc_9_6 loc_9_5 left
2
182 0
637 0
1
0 0 151 150
1
end_operator
begin_operator
move loc_9_6 loc_9_7 right
2
184 0
638 0
1
0 0 151 152
1
end_operator
begin_operator
move loc_9_7 loc_10_7 down
2
19 0
639 0
1
0 0 152 12
1
end_operator
begin_operator
move loc_9_7 loc_8_7 up
2
165 0
640 0
1
0 0 152 133
1
end_operator
begin_operator
move loc_9_7 loc_9_6 left
2
183 0
641 0
1
0 0 152 151
1
end_operator
begin_operator
move loc_9_9 loc_8_9 up
2
167 0
642 0
1
0 0 153 135
1
end_operator
begin_operator
move loc_9_9 loc_9_10 right
2
168 0
643 0
1
0 0 153 136
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box1
2
186 0
190 0
4
0 0 0 1
0 4 1 2
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box2
2
186 0
190 0
4
0 0 0 1
0 2 1 2
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box3
2
186 0
190 0
4
0 0 0 1
0 5 1 2
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box5
2
186 0
190 0
4
0 0 0 1
0 3 1 2
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_11 loc_10_12 loc_10_13 right box6
2
186 0
190 0
4
0 0 0 1
0 1 1 2
0 8 -1 0
0 9 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box1
2
187 0
231 0
4
0 0 0 13
0 4 13 24
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box2
2
187 0
231 0
4
0 0 0 13
0 2 13 24
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box3
2
187 0
231 0
4
0 0 0 13
0 5 13 24
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box5
2
187 0
231 0
4
0 0 0 13
0 3 13 24
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_10_11 loc_11_11 loc_12_11 down box6
2
187 0
231 0
4
0 0 0 13
0 1 13 24
0 20 -1 0
0 31 0 1
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box1
2
188 0
590 0
4
0 0 0 137
0 4 125 112
0 155 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box2
2
188 0
590 0
4
0 0 0 137
0 2 125 112
0 155 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box3
2
188 0
590 0
4
0 0 0 137
0 5 125 112
0 155 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box5
2
188 0
590 0
4
0 0 0 137
0 3 125 112
0 155 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_10_11 loc_9_11 loc_8_11 up box6
2
188 0
590 0
4
0 0 0 137
0 1 125 112
0 155 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box1
2
190 0
194 0
4
0 0 1 2
0 4 2 3
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box2
2
190 0
194 0
4
0 0 1 2
0 2 2 3
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box3
2
190 0
194 0
4
0 0 1 2
0 5 2 3
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box5
2
190 0
194 0
4
0 0 1 2
0 3 2 3
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_12 loc_10_13 loc_10_14 right box6
2
190 0
194 0
4
0 0 1 2
0 1 2 3
0 9 -1 0
0 10 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box1
2
191 0
234 0
4
0 0 1 14
0 4 14 25
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box2
2
191 0
234 0
4
0 0 1 14
0 2 14 25
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box3
2
191 0
234 0
4
0 0 1 14
0 5 14 25
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box5
2
191 0
234 0
4
0 0 1 14
0 3 14 25
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_10_12 loc_11_12 loc_12_12 down box6
2
191 0
234 0
4
0 0 1 14
0 1 14 25
0 21 -1 0
0 32 0 1
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box1
2
192 0
594 0
4
0 0 1 138
0 4 126 113
0 156 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box2
2
192 0
594 0
4
0 0 1 138
0 2 126 113
0 156 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box3
2
192 0
594 0
4
0 0 1 138
0 5 126 113
0 156 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box5
2
192 0
594 0
4
0 0 1 138
0 3 126 113
0 156 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_10_12 loc_9_12 loc_8_12 up box6
2
192 0
594 0
4
0 0 1 138
0 1 126 113
0 156 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box1
2
189 0
193 0
4
0 0 2 1
0 4 1 0
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box2
2
189 0
193 0
4
0 0 2 1
0 2 1 0
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box3
2
189 0
193 0
4
0 0 2 1
0 5 1 0
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box5
2
189 0
193 0
4
0 0 2 1
0 3 1 0
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_12 loc_10_11 left box6
2
189 0
193 0
4
0 0 2 1
0 1 1 0
0 7 0 1
0 8 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box1
2
194 0
197 0
4
0 0 2 3
0 4 3 4
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box2
2
194 0
197 0
4
0 0 2 3
0 2 3 4
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box3
2
194 0
197 0
4
0 0 2 3
0 5 3 4
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box5
2
194 0
197 0
4
0 0 2 3
0 3 3 4
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_13 loc_10_14 loc_10_15 right box6
2
194 0
197 0
4
0 0 2 3
0 1 3 4
0 10 -1 0
0 11 0 1
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box1
2
195 0
598 0
4
0 0 2 139
0 4 127 114
0 157 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box2
2
195 0
598 0
4
0 0 2 139
0 2 127 114
0 157 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box3
2
195 0
598 0
4
0 0 2 139
0 5 127 114
0 157 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box5
2
195 0
598 0
4
0 0 2 139
0 3 127 114
0 157 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_10_13 loc_9_13 loc_8_13 up box6
2
195 0
598 0
4
0 0 2 139
0 1 127 114
0 157 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box1
2
193 0
196 0
4
0 0 3 2
0 4 2 1
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box2
2
193 0
196 0
4
0 0 3 2
0 2 2 1
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box3
2
193 0
196 0
4
0 0 3 2
0 5 2 1
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box5
2
193 0
196 0
4
0 0 3 2
0 3 2 1
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_13 loc_10_12 left box6
2
193 0
196 0
4
0 0 3 2
0 1 2 1
0 8 0 1
0 9 -1 0
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box1
2
197 0
200 0
4
0 0 3 4
0 4 4 5
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box2
2
197 0
200 0
4
0 0 3 4
0 2 4 5
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box3
2
197 0
200 0
4
0 0 3 4
0 5 4 5
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box5
2
197 0
200 0
4
0 0 3 4
0 3 4 5
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_14 loc_10_15 loc_10_16 right box6
2
197 0
200 0
4
0 0 3 4
0 1 4 5
0 11 -1 0
0 12 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box1
2
196 0
199 0
4
0 0 4 3
0 4 3 2
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box2
2
196 0
199 0
4
0 0 4 3
0 2 3 2
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box3
2
196 0
199 0
4
0 0 4 3
0 5 3 2
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box5
2
196 0
199 0
4
0 0 4 3
0 3 3 2
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_14 loc_10_13 left box6
2
196 0
199 0
4
0 0 4 3
0 1 3 2
0 9 0 1
0 10 -1 0
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box1
2
200 0
203 0
4
0 0 4 5
0 4 5 6
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box2
2
200 0
203 0
4
0 0 4 5
0 2 5 6
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box3
2
200 0
203 0
4
0 0 4 5
0 5 5 6
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box5
2
200 0
203 0
4
0 0 4 5
0 3 5 6
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_15 loc_10_16 loc_10_17 right box6
2
200 0
203 0
4
0 0 4 5
0 1 5 6
0 12 -1 0
0 13 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box1
2
199 0
202 0
4
0 0 5 4
0 4 4 3
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box2
2
199 0
202 0
4
0 0 5 4
0 2 4 3
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box3
2
199 0
202 0
4
0 0 5 4
0 5 4 3
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box5
2
199 0
202 0
4
0 0 5 4
0 3 4 3
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_15 loc_10_14 left box6
2
199 0
202 0
4
0 0 5 4
0 1 4 3
0 10 0 1
0 11 -1 0
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box1
2
203 0
206 0
4
0 0 5 6
0 4 6 7
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box2
2
203 0
206 0
4
0 0 5 6
0 2 6 7
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box3
2
203 0
206 0
4
0 0 5 6
0 5 6 7
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box5
2
203 0
206 0
4
0 0 5 6
0 3 6 7
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_10_16 loc_10_17 loc_10_18 right box6
2
203 0
206 0
4
0 0 5 6
0 1 6 7
0 13 -1 0
0 14 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box1
2
202 0
205 0
4
0 0 6 5
0 4 5 4
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box2
2
202 0
205 0
4
0 0 6 5
0 2 5 4
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box3
2
202 0
205 0
4
0 0 6 5
0 5 5 4
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box5
2
202 0
205 0
4
0 0 6 5
0 3 5 4
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_16 loc_10_15 left box6
2
202 0
205 0
4
0 0 6 5
0 1 5 4
0 11 0 1
0 12 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box1
2
206 0
210 0
4
0 0 6 7
0 4 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box2
2
206 0
210 0
4
0 0 6 7
0 2 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box3
2
206 0
210 0
4
0 0 6 7
0 5 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box5
2
206 0
210 0
4
0 0 6 7
0 3 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_10_17 loc_10_18 loc_10_19 right box6
2
206 0
210 0
4
0 0 6 7
0 1 7 8
0 14 -1 0
0 15 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box1
2
207 0
237 0
4
0 0 6 15
0 4 15 30
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box2
2
207 0
237 0
4
0 0 6 15
0 2 15 30
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box3
2
207 0
237 0
4
0 0 6 15
0 5 15 30
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box5
2
207 0
237 0
4
0 0 6 15
0 3 15 30
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_17 loc_11_17 loc_12_17 down box6
2
207 0
237 0
4
0 0 6 15
0 1 15 30
0 22 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box1
2
208 0
611 0
4
0 0 6 143
0 4 131 115
0 158 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box2
2
208 0
611 0
4
0 0 6 143
0 2 131 115
0 158 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box3
2
208 0
611 0
4
0 0 6 143
0 5 131 115
0 158 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box5
2
208 0
611 0
4
0 0 6 143
0 3 131 115
0 158 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_17 loc_9_17 loc_8_17 up box6
2
208 0
611 0
4
0 0 6 143
0 1 131 115
0 158 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box1
2
205 0
209 0
4
0 0 7 6
0 4 6 5
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box2
2
205 0
209 0
4
0 0 7 6
0 2 6 5
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box3
2
205 0
209 0
4
0 0 7 6
0 5 6 5
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box5
2
205 0
209 0
4
0 0 7 6
0 3 6 5
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_10_17 loc_10_16 left box6
2
205 0
209 0
4
0 0 7 6
0 1 6 5
0 12 0 1
0 13 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box1
2
211 0
241 0
4
0 0 7 16
0 4 16 31
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box2
2
211 0
241 0
4
0 0 7 16
0 2 16 31
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box3
2
211 0
241 0
4
0 0 7 16
0 5 16 31
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box5
2
211 0
241 0
4
0 0 7 16
0 3 16 31
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_10_18 loc_11_18 loc_12_18 down box6
2
211 0
241 0
4
0 0 7 16
0 1 16 31
0 23 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_10_18 loc_9_18 loc_8_18 up box1
2
212 0
615 0
4
0 0 7 144
0 4 132 116
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_9_18 loc_8_18 up box2
2
212 0
615 0
4
0 0 7 144
0 2 132 116
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_9_18 loc_8_18 up box3
2
212 0
615 0
4
0 0 7 144
0 5 132 116
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_9_18 loc_8_18 up box5
2
212 0
615 0
4
0 0 7 144
0 3 132 116
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_18 loc_9_18 loc_8_18 up box6
2
212 0
615 0
4
0 0 7 144
0 1 132 116
0 159 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box1
2
209 0
213 0
4
0 0 8 7
0 4 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box2
2
209 0
213 0
4
0 0 8 7
0 2 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box3
2
209 0
213 0
4
0 0 8 7
0 5 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box5
2
209 0
213 0
4
0 0 8 7
0 3 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_10_18 loc_10_17 left box6
2
209 0
213 0
4
0 0 8 7
0 1 7 6
0 13 0 1
0 14 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box1
2
214 0
245 0
4
0 0 8 17
0 4 17 32
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box2
2
214 0
245 0
4
0 0 8 17
0 2 17 32
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box3
2
214 0
245 0
4
0 0 8 17
0 5 17 32
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box4
2
214 0
245 0
4
0 0 8 17
0 6 1 3
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box5
2
214 0
245 0
4
0 0 8 17
0 3 17 32
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_11_19 loc_12_19 down box6
2
214 0
245 0
4
0 0 8 17
0 1 17 32
0 24 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box1
2
215 0
619 0
4
0 0 8 145
0 4 133 117
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box2
2
215 0
619 0
4
0 0 8 145
0 2 133 117
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box3
2
215 0
619 0
4
0 0 8 145
0 5 133 117
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box4
2
215 0
619 0
4
0 0 8 145
0 6 14 13
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box5
2
215 0
619 0
4
0 0 8 145
0 3 133 117
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_19 loc_9_19 loc_8_19 up box6
2
215 0
619 0
4
0 0 8 145
0 1 133 117
0 160 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box1
2
216 0
220 0
4
0 0 9 10
0 4 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box2
2
216 0
220 0
4
0 0 9 10
0 2 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box3
2
216 0
220 0
4
0 0 9 10
0 5 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box5
2
216 0
220 0
4
0 0 9 10
0 3 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_4 loc_10_5 loc_10_6 right box6
2
216 0
220 0
4
0 0 9 10
0 1 10 11
0 17 -1 0
0 18 0 1
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box1
2
218 0
628 0
4
0 0 9 149
0 4 137 118
0 162 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box2
2
218 0
628 0
4
0 0 9 149
0 2 137 118
0 162 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box3
2
218 0
628 0
4
0 0 9 149
0 5 137 118
0 162 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box5
2
218 0
628 0
4
0 0 9 149
0 3 137 118
0 162 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_4 loc_9_4 loc_8_4 up box6
2
218 0
628 0
4
0 0 9 149
0 1 137 118
0 162 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box1
2
220 0
224 0
4
0 0 10 11
0 4 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box2
2
220 0
224 0
4
0 0 10 11
0 2 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box3
2
220 0
224 0
4
0 0 10 11
0 5 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box5
2
220 0
224 0
4
0 0 10 11
0 3 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_10_6 loc_10_7 right box6
2
220 0
224 0
4
0 0 10 11
0 1 11 12
0 18 -1 0
0 19 0 1
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box1
2
222 0
632 0
4
0 0 10 150
0 4 138 119
0 163 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box2
2
222 0
632 0
4
0 0 10 150
0 2 138 119
0 163 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box3
2
222 0
632 0
4
0 0 10 150
0 5 138 119
0 163 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box5
2
222 0
632 0
4
0 0 10 150
0 3 138 119
0 163 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_10_5 loc_9_5 loc_8_5 up box6
2
222 0
632 0
4
0 0 10 150
0 1 138 119
0 163 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box1
2
219 0
223 0
4
0 0 11 10
0 4 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box2
2
219 0
223 0
4
0 0 11 10
0 2 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box3
2
219 0
223 0
4
0 0 11 10
0 5 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box5
2
219 0
223 0
4
0 0 11 10
0 3 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_10_5 loc_10_4 left box6
2
219 0
223 0
4
0 0 11 10
0 1 10 9
0 16 0 1
0 17 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box1
2
225 0
636 0
4
0 0 11 151
0 4 139 120
0 164 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box2
2
225 0
636 0
4
0 0 11 151
0 2 139 120
0 164 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box3
2
225 0
636 0
4
0 0 11 151
0 5 139 120
0 164 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box5
2
225 0
636 0
4
0 0 11 151
0 3 139 120
0 164 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_10_6 loc_9_6 loc_8_6 up box6
2
225 0
636 0
4
0 0 11 151
0 1 139 120
0 164 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box1
2
223 0
226 0
4
0 0 12 11
0 4 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box2
2
223 0
226 0
4
0 0 12 11
0 2 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box3
2
223 0
226 0
4
0 0 12 11
0 5 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box5
2
223 0
226 0
4
0 0 12 11
0 3 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_10_6 loc_10_5 left box6
2
223 0
226 0
4
0 0 12 11
0 1 11 10
0 17 0 1
0 18 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box1
2
227 0
256 0
4
0 0 12 23
0 4 23 33
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box2
2
227 0
256 0
4
0 0 12 23
0 2 23 33
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box3
2
227 0
256 0
4
0 0 12 23
0 5 23 33
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box5
2
227 0
256 0
4
0 0 12 23
0 3 23 33
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_10_7 loc_11_7 loc_12_7 down box6
2
227 0
256 0
4
0 0 12 23
0 1 23 33
0 30 -1 0
0 40 0 1
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box1
2
228 0
640 0
4
0 0 12 152
0 4 140 121
0 165 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box2
2
228 0
640 0
4
0 0 12 152
0 2 140 121
0 165 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box3
2
228 0
640 0
4
0 0 12 152
0 5 140 121
0 165 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box5
2
228 0
640 0
4
0 0 12 152
0 3 140 121
0 165 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_10_7 loc_9_7 loc_8_7 up box6
2
228 0
640 0
4
0 0 12 152
0 1 140 121
0 165 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box1
2
188 0
229 0
4
0 0 13 0
0 4 0 125
0 7 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box2
2
188 0
229 0
4
0 0 13 0
0 2 0 125
0 7 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box3
2
188 0
229 0
4
0 0 13 0
0 5 0 125
0 7 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box5
2
188 0
229 0
4
0 0 13 0
0 3 0 125
0 7 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_10_11 loc_9_11 up box6
2
188 0
229 0
4
0 0 13 0
0 1 0 125
0 7 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box1
2
231 0
259 0
4
0 0 13 24
0 4 24 35
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box2
2
231 0
259 0
4
0 0 13 24
0 2 24 35
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box3
2
231 0
259 0
4
0 0 13 24
0 5 24 35
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box5
2
231 0
259 0
4
0 0 13 24
0 3 24 35
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_11_11 loc_12_11 loc_13_11 down box6
2
231 0
259 0
4
0 0 13 24
0 1 24 35
0 31 -1 0
0 43 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box1
2
192 0
232 0
4
0 0 14 1
0 4 1 126
0 8 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box2
2
192 0
232 0
4
0 0 14 1
0 2 1 126
0 8 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box3
2
192 0
232 0
4
0 0 14 1
0 5 1 126
0 8 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box5
2
192 0
232 0
4
0 0 14 1
0 3 1 126
0 8 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_12 loc_10_12 loc_9_12 up box6
2
192 0
232 0
4
0 0 14 1
0 1 1 126
0 8 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box1
2
208 0
235 0
4
0 0 15 6
0 4 6 131
0 13 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box2
2
208 0
235 0
4
0 0 15 6
0 2 6 131
0 13 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box3
2
208 0
235 0
4
0 0 15 6
0 5 6 131
0 13 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box5
2
208 0
235 0
4
0 0 15 6
0 3 6 131
0 13 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_10_17 loc_9_17 up box6
2
208 0
235 0
4
0 0 15 6
0 1 6 131
0 13 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box1
2
236 0
240 0
4
0 0 15 16
0 4 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box2
2
236 0
240 0
4
0 0 15 16
0 2 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box3
2
236 0
240 0
4
0 0 15 16
0 5 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box5
2
236 0
240 0
4
0 0 15 16
0 3 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_17 loc_11_18 loc_11_19 right box6
2
236 0
240 0
4
0 0 15 16
0 1 16 17
0 23 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box1
2
237 0
275 0
4
0 0 15 30
0 4 30 36
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box2
2
237 0
275 0
4
0 0 15 30
0 2 30 36
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box3
2
237 0
275 0
4
0 0 15 30
0 5 30 36
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box5
2
237 0
275 0
4
0 0 15 30
0 3 30 36
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_11_17 loc_12_17 loc_13_17 down box6
2
237 0
275 0
4
0 0 15 30
0 1 30 36
0 37 -1 0
0 45 0 1
1
end_operator
begin_operator
push loc_11_18 loc_10_18 loc_9_18 up box1
2
212 0
238 0
4
0 0 16 7
0 4 7 132
0 14 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_10_18 loc_9_18 up box2
2
212 0
238 0
4
0 0 16 7
0 2 7 132
0 14 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_10_18 loc_9_18 up box3
2
212 0
238 0
4
0 0 16 7
0 5 7 132
0 14 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_10_18 loc_9_18 up box5
2
212 0
238 0
4
0 0 16 7
0 3 7 132
0 14 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_10_18 loc_9_18 up box6
2
212 0
238 0
4
0 0 16 7
0 1 7 132
0 14 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box1
2
240 0
244 0
4
0 0 16 17
0 4 17 19
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box2
2
240 0
244 0
4
0 0 16 17
0 2 17 19
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box3
2
240 0
244 0
4
0 0 16 17
0 5 17 19
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box4
2
240 0
244 0
4
0 0 16 17
0 6 1 2
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box5
2
240 0
244 0
4
0 0 16 17
0 3 17 19
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_11_19 loc_11_20 right box6
2
240 0
244 0
4
0 0 16 17
0 1 17 19
0 24 -1 0
0 26 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box1
2
241 0
279 0
4
0 0 16 31
0 4 31 37
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box2
2
241 0
279 0
4
0 0 16 31
0 2 31 37
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box3
2
241 0
279 0
4
0 0 16 31
0 5 31 37
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box5
2
241 0
279 0
4
0 0 16 31
0 3 31 37
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_11_18 loc_12_18 loc_13_18 down box6
2
241 0
279 0
4
0 0 16 31
0 1 31 37
0 38 -1 0
0 46 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box1
2
215 0
242 0
4
0 0 17 8
0 4 8 133
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box2
2
215 0
242 0
4
0 0 17 8
0 2 8 133
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box3
2
215 0
242 0
4
0 0 17 8
0 5 8 133
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box4
2
215 0
242 0
4
0 0 17 8
0 6 0 14
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box5
2
215 0
242 0
4
0 0 17 8
0 3 8 133
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_10_19 loc_9_19 up box6
2
215 0
242 0
4
0 0 17 8
0 1 8 133
0 15 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box1
2
239 0
243 0
4
0 0 17 16
0 4 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box2
2
239 0
243 0
4
0 0 17 16
0 2 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box3
2
239 0
243 0
4
0 0 17 16
0 5 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box5
2
239 0
243 0
4
0 0 17 16
0 3 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_11_18 loc_11_17 left box6
2
239 0
243 0
4
0 0 17 16
0 1 16 15
0 22 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box1
2
245 0
282 0
4
0 0 17 32
0 4 32 38
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box2
2
245 0
282 0
4
0 0 17 32
0 2 32 38
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box3
2
245 0
282 0
4
0 0 17 32
0 5 32 38
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box4
2
245 0
282 0
4
0 0 17 32
0 6 3 4
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box5
2
245 0
282 0
4
0 0 17 32
0 3 32 38
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_19 loc_12_19 loc_13_19 down box6
2
245 0
282 0
4
0 0 17 32
0 1 32 38
0 39 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box1
2
218 0
250 0
4
0 0 21 9
0 4 9 137
0 16 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box2
2
218 0
250 0
4
0 0 21 9
0 2 9 137
0 16 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box3
2
218 0
250 0
4
0 0 21 9
0 5 9 137
0 16 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box5
2
218 0
250 0
4
0 0 21 9
0 3 9 137
0 16 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_4 loc_10_4 loc_9_4 up box6
2
218 0
250 0
4
0 0 21 9
0 1 9 137
0 16 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box1
2
248 0
251 0
4
0 0 21 20
0 4 20 18
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box2
2
248 0
251 0
4
0 0 21 20
0 2 20 18
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box3
2
248 0
251 0
4
0 0 21 20
0 5 20 18
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box5
2
248 0
251 0
4
0 0 21 20
0 3 20 18
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_4 loc_11_3 loc_11_2 left box6
2
248 0
251 0
4
0 0 21 20
0 1 20 18
0 25 0 1
0 27 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box1
2
222 0
253 0
4
0 0 22 10
0 4 10 138
0 17 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box2
2
222 0
253 0
4
0 0 22 10
0 2 10 138
0 17 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box3
2
222 0
253 0
4
0 0 22 10
0 5 10 138
0 17 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box5
2
222 0
253 0
4
0 0 22 10
0 3 10 138
0 17 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_5 loc_10_5 loc_9_5 up box6
2
222 0
253 0
4
0 0 22 10
0 1 10 138
0 17 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box1
2
251 0
254 0
4
0 0 22 21
0 4 21 20
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box2
2
251 0
254 0
4
0 0 22 21
0 2 21 20
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box3
2
251 0
254 0
4
0 0 22 21
0 5 21 20
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box5
2
251 0
254 0
4
0 0 22 21
0 3 21 20
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_11_5 loc_11_4 loc_11_3 left box6
2
251 0
254 0
4
0 0 22 21
0 1 21 20
0 27 0 1
0 28 -1 0
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box1
2
228 0
255 0
4
0 0 23 12
0 4 12 140
0 19 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box2
2
228 0
255 0
4
0 0 23 12
0 2 12 140
0 19 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box3
2
228 0
255 0
4
0 0 23 12
0 5 12 140
0 19 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box5
2
228 0
255 0
4
0 0 23 12
0 3 12 140
0 19 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_7 loc_10_7 loc_9_7 up box6
2
228 0
255 0
4
0 0 23 12
0 1 12 140
0 19 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box1
2
256 0
284 0
4
0 0 23 33
0 4 33 42
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box2
2
256 0
284 0
4
0 0 23 33
0 2 33 42
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box3
2
256 0
284 0
4
0 0 23 33
0 5 33 42
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box5
2
256 0
284 0
4
0 0 23 33
0 3 33 42
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_11_7 loc_12_7 loc_13_7 down box6
2
256 0
284 0
4
0 0 23 33
0 1 33 42
0 40 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box1
2
229 0
257 0
4
0 0 24 13
0 4 13 0
0 7 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box2
2
229 0
257 0
4
0 0 24 13
0 2 13 0
0 7 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box3
2
229 0
257 0
4
0 0 24 13
0 5 13 0
0 7 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box5
2
229 0
257 0
4
0 0 24 13
0 3 13 0
0 7 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_11_11 loc_10_11 up box6
2
229 0
257 0
4
0 0 24 13
0 1 13 0
0 7 0 1
0 20 -1 0
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box1
2
258 0
262 0
4
0 0 24 25
0 4 25 26
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box2
2
258 0
262 0
4
0 0 24 25
0 2 25 26
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box3
2
258 0
262 0
4
0 0 24 25
0 5 25 26
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box5
2
258 0
262 0
4
0 0 24 25
0 3 25 26
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_12_11 loc_12_12 loc_12_13 right box6
2
258 0
262 0
4
0 0 24 25
0 1 25 26
0 32 -1 0
0 33 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box1
2
259 0
289 0
4
0 0 24 35
0 4 35 44
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box2
2
259 0
289 0
4
0 0 24 35
0 2 35 44
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box3
2
259 0
289 0
4
0 0 24 35
0 5 35 44
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box5
2
259 0
289 0
4
0 0 24 35
0 3 35 44
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_12_11 loc_13_11 loc_14_11 down box6
2
259 0
289 0
4
0 0 24 35
0 1 35 44
0 43 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box1
2
232 0
260 0
4
0 0 25 14
0 4 14 1
0 8 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box2
2
232 0
260 0
4
0 0 25 14
0 2 14 1
0 8 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box3
2
232 0
260 0
4
0 0 25 14
0 5 14 1
0 8 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box5
2
232 0
260 0
4
0 0 25 14
0 3 14 1
0 8 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_11_12 loc_10_12 up box6
2
232 0
260 0
4
0 0 25 14
0 1 14 1
0 8 0 1
0 21 -1 0
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box1
2
262 0
264 0
4
0 0 25 26
0 4 26 27
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box2
2
262 0
264 0
4
0 0 25 26
0 2 26 27
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box3
2
262 0
264 0
4
0 0 25 26
0 5 26 27
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box5
2
262 0
264 0
4
0 0 25 26
0 3 26 27
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_12_12 loc_12_13 loc_12_14 right box6
2
262 0
264 0
4
0 0 25 26
0 1 26 27
0 33 -1 0
0 34 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box1
2
261 0
263 0
4
0 0 26 25
0 4 25 24
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box2
2
261 0
263 0
4
0 0 26 25
0 2 25 24
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box3
2
261 0
263 0
4
0 0 26 25
0 5 25 24
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box5
2
261 0
263 0
4
0 0 26 25
0 3 25 24
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_12 loc_12_11 left box6
2
261 0
263 0
4
0 0 26 25
0 1 25 24
0 31 0 1
0 32 -1 0
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box1
2
264 0
266 0
4
0 0 26 27
0 4 27 28
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box2
2
264 0
266 0
4
0 0 26 27
0 2 27 28
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box3
2
264 0
266 0
4
0 0 26 27
0 5 27 28
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box5
2
264 0
266 0
4
0 0 26 27
0 3 27 28
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_12_13 loc_12_14 loc_12_15 right box6
2
264 0
266 0
4
0 0 26 27
0 1 27 28
0 34 -1 0
0 35 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box1
2
263 0
265 0
4
0 0 27 26
0 4 26 25
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box2
2
263 0
265 0
4
0 0 27 26
0 2 26 25
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box3
2
263 0
265 0
4
0 0 27 26
0 5 26 25
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box5
2
263 0
265 0
4
0 0 27 26
0 3 26 25
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_13 loc_12_12 left box6
2
263 0
265 0
4
0 0 27 26
0 1 26 25
0 32 0 1
0 33 -1 0
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box1
2
266 0
268 0
4
0 0 27 28
0 4 28 29
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box2
2
266 0
268 0
4
0 0 27 28
0 2 28 29
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box3
2
266 0
268 0
4
0 0 27 28
0 5 28 29
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box5
2
266 0
268 0
4
0 0 27 28
0 3 28 29
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_14 loc_12_15 loc_12_16 right box6
2
266 0
268 0
4
0 0 27 28
0 1 28 29
0 35 -1 0
0 36 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box1
2
265 0
267 0
4
0 0 28 27
0 4 27 26
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box2
2
265 0
267 0
4
0 0 28 27
0 2 27 26
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box3
2
265 0
267 0
4
0 0 28 27
0 5 27 26
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box5
2
265 0
267 0
4
0 0 28 27
0 3 27 26
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_14 loc_12_13 left box6
2
265 0
267 0
4
0 0 28 27
0 1 27 26
0 33 0 1
0 34 -1 0
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box1
2
268 0
271 0
4
0 0 28 29
0 4 29 30
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box2
2
268 0
271 0
4
0 0 28 29
0 2 29 30
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box3
2
268 0
271 0
4
0 0 28 29
0 5 29 30
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box5
2
268 0
271 0
4
0 0 28 29
0 3 29 30
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_12_15 loc_12_16 loc_12_17 right box6
2
268 0
271 0
4
0 0 28 29
0 1 29 30
0 36 -1 0
0 37 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box1
2
267 0
270 0
4
0 0 29 28
0 4 28 27
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box2
2
267 0
270 0
4
0 0 29 28
0 2 28 27
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box3
2
267 0
270 0
4
0 0 29 28
0 5 28 27
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box5
2
267 0
270 0
4
0 0 29 28
0 3 28 27
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_15 loc_12_14 left box6
2
267 0
270 0
4
0 0 29 28
0 1 28 27
0 34 0 1
0 35 -1 0
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box1
2
271 0
274 0
4
0 0 29 30
0 4 30 31
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box2
2
271 0
274 0
4
0 0 29 30
0 2 30 31
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box3
2
271 0
274 0
4
0 0 29 30
0 5 30 31
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box5
2
271 0
274 0
4
0 0 29 30
0 3 30 31
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_16 loc_12_17 loc_12_18 right box6
2
271 0
274 0
4
0 0 29 30
0 1 30 31
0 37 -1 0
0 38 0 1
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box1
2
235 0
272 0
4
0 0 30 15
0 4 15 6
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box2
2
235 0
272 0
4
0 0 30 15
0 2 15 6
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box3
2
235 0
272 0
4
0 0 30 15
0 5 15 6
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box5
2
235 0
272 0
4
0 0 30 15
0 3 15 6
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_11_17 loc_10_17 up box6
2
235 0
272 0
4
0 0 30 15
0 1 15 6
0 13 0 1
0 22 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box1
2
270 0
273 0
4
0 0 30 29
0 4 29 28
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box2
2
270 0
273 0
4
0 0 30 29
0 2 29 28
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box3
2
270 0
273 0
4
0 0 30 29
0 5 29 28
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box5
2
270 0
273 0
4
0 0 30 29
0 3 29 28
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_16 loc_12_15 left box6
2
270 0
273 0
4
0 0 30 29
0 1 29 28
0 35 0 1
0 36 -1 0
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box1
2
274 0
278 0
4
0 0 30 31
0 4 31 32
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box2
2
274 0
278 0
4
0 0 30 31
0 2 31 32
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box3
2
274 0
278 0
4
0 0 30 31
0 5 31 32
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box5
2
274 0
278 0
4
0 0 30 31
0 3 31 32
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_17 loc_12_18 loc_12_19 right box6
2
274 0
278 0
4
0 0 30 31
0 1 31 32
0 38 -1 0
0 39 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box1
2
275 0
293 0
4
0 0 30 37
0 4 36 46
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box2
2
275 0
293 0
4
0 0 30 37
0 2 36 46
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box3
2
275 0
293 0
4
0 0 30 37
0 5 36 46
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box5
2
275 0
293 0
4
0 0 30 37
0 3 36 46
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_12_17 loc_13_17 loc_14_17 down box6
2
275 0
293 0
4
0 0 30 37
0 1 36 46
0 45 -1 0
0 56 0 1
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box1
2
238 0
276 0
4
0 0 31 16
0 4 16 7
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box2
2
238 0
276 0
4
0 0 31 16
0 2 16 7
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box3
2
238 0
276 0
4
0 0 31 16
0 5 16 7
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box5
2
238 0
276 0
4
0 0 31 16
0 3 16 7
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_11_18 loc_10_18 up box6
2
238 0
276 0
4
0 0 31 16
0 1 16 7
0 14 0 1
0 23 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box1
2
273 0
277 0
4
0 0 31 30
0 4 30 29
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box2
2
273 0
277 0
4
0 0 31 30
0 2 30 29
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box3
2
273 0
277 0
4
0 0 31 30
0 5 30 29
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box5
2
273 0
277 0
4
0 0 31 30
0 3 30 29
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_12_17 loc_12_16 left box6
2
273 0
277 0
4
0 0 31 30
0 1 30 29
0 36 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box1
2
279 0
297 0
4
0 0 31 38
0 4 37 47
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box2
2
279 0
297 0
4
0 0 31 38
0 2 37 47
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box3
2
279 0
297 0
4
0 0 31 38
0 5 37 47
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box5
2
279 0
297 0
4
0 0 31 38
0 3 37 47
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_12_18 loc_13_18 loc_14_18 down box6
2
279 0
297 0
4
0 0 31 38
0 1 37 47
0 46 -1 0
0 57 0 1
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box1
2
242 0
280 0
4
0 0 32 17
0 4 17 8
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box2
2
242 0
280 0
4
0 0 32 17
0 2 17 8
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box3
2
242 0
280 0
4
0 0 32 17
0 5 17 8
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box4
2
242 0
280 0
4
0 0 32 17
0 6 1 0
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box5
2
242 0
280 0
4
0 0 32 17
0 3 17 8
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_11_19 loc_10_19 up box6
2
242 0
280 0
4
0 0 32 17
0 1 17 8
0 15 0 1
0 24 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box1
2
277 0
281 0
4
0 0 32 31
0 4 31 30
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box2
2
277 0
281 0
4
0 0 32 31
0 2 31 30
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box3
2
277 0
281 0
4
0 0 32 31
0 5 31 30
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box5
2
277 0
281 0
4
0 0 32 31
0 3 31 30
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_12_18 loc_12_17 left box6
2
277 0
281 0
4
0 0 32 31
0 1 31 30
0 37 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box1
2
282 0
300 0
4
0 0 32 39
0 4 38 48
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box2
2
282 0
300 0
4
0 0 32 39
0 2 38 48
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box3
2
282 0
300 0
4
0 0 32 39
0 5 38 48
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box4
2
282 0
300 0
4
0 0 32 39
0 6 4 5
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box5
2
282 0
300 0
4
0 0 32 39
0 3 38 48
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_19 loc_13_19 loc_14_19 down box6
2
282 0
300 0
4
0 0 32 39
0 1 38 48
0 47 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box1
2
255 0
283 0
4
0 0 33 23
0 4 23 12
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box2
2
255 0
283 0
4
0 0 33 23
0 2 23 12
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box3
2
255 0
283 0
4
0 0 33 23
0 5 23 12
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box5
2
255 0
283 0
4
0 0 33 23
0 3 23 12
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_11_7 loc_10_7 up box6
2
255 0
283 0
4
0 0 33 23
0 1 23 12
0 19 0 1
0 30 -1 0
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box1
2
284 0
311 0
4
0 0 33 43
0 4 42 52
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box2
2
284 0
311 0
4
0 0 33 43
0 2 42 52
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box3
2
284 0
311 0
4
0 0 33 43
0 5 42 52
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box5
2
284 0
311 0
4
0 0 33 43
0 3 42 52
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_12_7 loc_13_7 loc_14_7 down box6
2
284 0
311 0
4
0 0 33 43
0 1 42 52
0 52 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box1
2
286 0
315 0
4
0 0 34 44
0 4 43 55
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box2
2
286 0
315 0
4
0 0 34 44
0 2 43 55
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box3
2
286 0
315 0
4
0 0 34 44
0 5 43 55
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box5
2
286 0
315 0
4
0 0 34 44
0 3 43 55
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_13_10 loc_14_10 loc_15_10 down box6
2
286 0
315 0
4
0 0 34 44
0 1 43 55
0 53 -1 0
0 65 0 1
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box1
2
257 0
287 0
4
0 0 35 24
0 4 24 13
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box2
2
257 0
287 0
4
0 0 35 24
0 2 24 13
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box3
2
257 0
287 0
4
0 0 35 24
0 5 24 13
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box5
2
257 0
287 0
4
0 0 35 24
0 3 24 13
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_12_11 loc_11_11 up box6
2
257 0
287 0
4
0 0 35 24
0 1 24 13
0 20 0 1
0 31 -1 0
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box1
2
289 0
319 0
4
0 0 35 45
0 4 44 56
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box2
2
289 0
319 0
4
0 0 35 45
0 2 44 56
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box3
2
289 0
319 0
4
0 0 35 45
0 5 44 56
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box5
2
289 0
319 0
4
0 0 35 45
0 3 44 56
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_13_11 loc_14_11 loc_15_11 down box6
2
289 0
319 0
4
0 0 35 45
0 1 44 56
0 54 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box1
2
272 0
291 0
4
0 0 37 30
0 4 30 15
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box2
2
272 0
291 0
4
0 0 37 30
0 2 30 15
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box3
2
272 0
291 0
4
0 0 37 30
0 5 30 15
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box5
2
272 0
291 0
4
0 0 37 30
0 3 30 15
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_12_17 loc_11_17 up box6
2
272 0
291 0
4
0 0 37 30
0 1 30 15
0 22 0 1
0 37 -1 0
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box1
2
292 0
296 0
4
0 0 37 38
0 4 37 38
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box2
2
292 0
296 0
4
0 0 37 38
0 2 37 38
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box3
2
292 0
296 0
4
0 0 37 38
0 5 37 38
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box5
2
292 0
296 0
4
0 0 37 38
0 3 37 38
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_13_17 loc_13_18 loc_13_19 right box6
2
292 0
296 0
4
0 0 37 38
0 1 37 38
0 46 -1 0
0 47 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box1
2
293 0
324 0
4
0 0 37 47
0 4 46 62
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box2
2
293 0
324 0
4
0 0 37 47
0 2 46 62
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box3
2
293 0
324 0
4
0 0 37 47
0 5 46 62
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box5
2
293 0
324 0
4
0 0 37 47
0 3 46 62
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_13_17 loc_14_17 loc_15_17 down box6
2
293 0
324 0
4
0 0 37 47
0 1 46 62
0 56 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box1
2
276 0
294 0
4
0 0 38 31
0 4 31 16
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box2
2
276 0
294 0
4
0 0 38 31
0 2 31 16
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box3
2
276 0
294 0
4
0 0 38 31
0 5 31 16
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box5
2
276 0
294 0
4
0 0 38 31
0 3 31 16
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_12_18 loc_11_18 up box6
2
276 0
294 0
4
0 0 38 31
0 1 31 16
0 23 0 1
0 38 -1 0
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box1
2
297 0
328 0
4
0 0 38 48
0 4 47 63
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box2
2
297 0
328 0
4
0 0 38 48
0 2 47 63
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box3
2
297 0
328 0
4
0 0 38 48
0 5 47 63
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box5
2
297 0
328 0
4
0 0 38 48
0 3 47 63
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_13_18 loc_14_18 loc_15_18 down box6
2
297 0
328 0
4
0 0 38 48
0 1 47 63
0 57 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box1
2
280 0
298 0
4
0 0 39 32
0 4 32 17
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box2
2
280 0
298 0
4
0 0 39 32
0 2 32 17
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box3
2
280 0
298 0
4
0 0 39 32
0 5 32 17
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box4
2
280 0
298 0
4
0 0 39 32
0 6 3 1
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box5
2
280 0
298 0
4
0 0 39 32
0 3 32 17
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_12_19 loc_11_19 up box6
2
280 0
298 0
4
0 0 39 32
0 1 32 17
0 24 0 1
0 39 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box1
2
295 0
299 0
4
0 0 39 38
0 4 37 36
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box2
2
295 0
299 0
4
0 0 39 38
0 2 37 36
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box3
2
295 0
299 0
4
0 0 39 38
0 5 37 36
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box5
2
295 0
299 0
4
0 0 39 38
0 3 37 36
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_13_18 loc_13_17 left box6
2
295 0
299 0
4
0 0 39 38
0 1 37 36
0 45 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box1
2
300 0
331 0
4
0 0 39 49
0 4 48 64
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box2
2
300 0
331 0
4
0 0 39 49
0 2 48 64
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box3
2
300 0
331 0
4
0 0 39 49
0 5 48 64
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box4
2
300 0
331 0
4
0 0 39 49
0 6 5 6
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box5
2
300 0
331 0
4
0 0 39 49
0 3 48 64
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_19 loc_14_19 loc_15_19 down box6
2
300 0
331 0
4
0 0 39 49
0 1 48 64
0 58 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box1
2
301 0
304 0
4
0 0 40 41
0 4 40 41
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box2
2
301 0
304 0
4
0 0 40 41
0 2 40 41
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box3
2
301 0
304 0
4
0 0 40 41
0 5 40 41
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box5
2
301 0
304 0
4
0 0 40 41
0 3 40 41
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_13_4 loc_13_5 loc_13_6 right box6
2
301 0
304 0
4
0 0 40 41
0 1 40 41
0 50 -1 0
0 51 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box1
2
304 0
307 0
4
0 0 41 42
0 4 41 42
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box2
2
304 0
307 0
4
0 0 41 42
0 2 41 42
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box3
2
304 0
307 0
4
0 0 41 42
0 5 41 42
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box5
2
304 0
307 0
4
0 0 41 42
0 3 41 42
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_13_5 loc_13_6 loc_13_7 right box6
2
304 0
307 0
4
0 0 41 42
0 1 41 42
0 51 -1 0
0 52 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box1
2
305 0
337 0
4
0 0 41 51
0 4 50 65
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box2
2
305 0
337 0
4
0 0 41 51
0 2 50 65
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box3
2
305 0
337 0
4
0 0 41 51
0 5 50 65
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box5
2
305 0
337 0
4
0 0 41 51
0 3 50 65
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_13_5 loc_14_5 loc_15_5 down box6
2
305 0
337 0
4
0 0 41 51
0 1 50 65
0 60 -1 0
0 75 0 1
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box1
2
303 0
306 0
4
0 0 42 41
0 4 40 39
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box2
2
303 0
306 0
4
0 0 42 41
0 2 40 39
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box3
2
303 0
306 0
4
0 0 42 41
0 5 40 39
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box5
2
303 0
306 0
4
0 0 42 41
0 3 40 39
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_13_5 loc_13_4 left box6
2
303 0
306 0
4
0 0 42 41
0 1 40 39
0 49 0 1
0 50 -1 0
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box1
2
308 0
341 0
4
0 0 42 52
0 4 51 66
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box2
2
308 0
341 0
4
0 0 42 52
0 2 51 66
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box3
2
308 0
341 0
4
0 0 42 52
0 5 51 66
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box5
2
308 0
341 0
4
0 0 42 52
0 3 51 66
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_13_6 loc_14_6 loc_15_6 down box6
2
308 0
341 0
4
0 0 42 52
0 1 51 66
0 61 -1 0
0 76 0 1
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box1
2
283 0
309 0
4
0 0 43 33
0 4 33 23
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box2
2
283 0
309 0
4
0 0 43 33
0 2 33 23
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box3
2
283 0
309 0
4
0 0 43 33
0 5 33 23
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box5
2
283 0
309 0
4
0 0 43 33
0 3 33 23
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_12_7 loc_11_7 up box6
2
283 0
309 0
4
0 0 43 33
0 1 33 23
0 30 0 1
0 40 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box1
2
306 0
310 0
4
0 0 43 42
0 4 41 40
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box2
2
306 0
310 0
4
0 0 43 42
0 2 41 40
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box3
2
306 0
310 0
4
0 0 43 42
0 5 41 40
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box5
2
306 0
310 0
4
0 0 43 42
0 3 41 40
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_13_6 loc_13_5 left box6
2
306 0
310 0
4
0 0 43 42
0 1 41 40
0 50 0 1
0 51 -1 0
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box1
2
311 0
345 0
4
0 0 43 53
0 4 52 67
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box2
2
311 0
345 0
4
0 0 43 53
0 2 52 67
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box3
2
311 0
345 0
4
0 0 43 53
0 5 52 67
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box5
2
311 0
345 0
4
0 0 43 53
0 3 52 67
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_13_7 loc_14_7 loc_15_7 down box6
2
311 0
345 0
4
0 0 43 53
0 1 52 67
0 62 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box1
2
313 0
318 0
4
0 0 44 45
0 4 44 45
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box2
2
313 0
318 0
4
0 0 44 45
0 2 44 45
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box3
2
313 0
318 0
4
0 0 44 45
0 5 44 45
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box5
2
313 0
318 0
4
0 0 44 45
0 3 44 45
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_11 loc_14_12 right box6
2
313 0
318 0
4
0 0 44 45
0 1 44 45
0 54 -1 0
0 55 0 1
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box1
2
314 0
350 0
4
0 0 44 55
0 4 54 53
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box2
2
314 0
350 0
4
0 0 44 55
0 2 54 53
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box3
2
314 0
350 0
4
0 0 44 55
0 5 54 53
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box5
2
314 0
350 0
4
0 0 44 55
0 3 54 53
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_14_9 loc_14_8 left box6
2
314 0
350 0
4
0 0 44 55
0 1 54 53
0 63 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box1
2
315 0
355 0
4
0 0 44 56
0 4 55 70
0 65 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box2
2
315 0
355 0
4
0 0 44 56
0 2 55 70
0 65 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box3
2
315 0
355 0
4
0 0 44 56
0 5 55 70
0 65 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box5
2
315 0
355 0
4
0 0 44 56
0 3 55 70
0 65 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_14_10 loc_15_10 loc_16_10 down box6
2
315 0
355 0
4
0 0 44 56
0 1 55 70
0 65 -1 0
0 80 0 1
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box1
2
287 0
316 0
4
0 0 45 35
0 4 35 24
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box2
2
287 0
316 0
4
0 0 45 35
0 2 35 24
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box3
2
287 0
316 0
4
0 0 45 35
0 5 35 24
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box5
2
287 0
316 0
4
0 0 45 35
0 3 35 24
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_13_11 loc_12_11 up box6
2
287 0
316 0
4
0 0 45 35
0 1 35 24
0 31 0 1
0 43 -1 0
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box1
2
314 0
317 0
4
0 0 45 44
0 4 43 54
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box2
2
314 0
317 0
4
0 0 45 44
0 2 43 54
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box3
2
314 0
317 0
4
0 0 45 44
0 5 43 54
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box5
2
314 0
317 0
4
0 0 45 44
0 3 43 54
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_11 loc_14_10 loc_14_9 left box6
2
314 0
317 0
4
0 0 45 44
0 1 43 54
0 53 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box1
2
317 0
320 0
4
0 0 46 45
0 4 44 43
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box2
2
317 0
320 0
4
0 0 46 45
0 2 44 43
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box3
2
317 0
320 0
4
0 0 46 45
0 5 44 43
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box5
2
317 0
320 0
4
0 0 46 45
0 3 44 43
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_14_12 loc_14_11 loc_14_10 left box6
2
317 0
320 0
4
0 0 46 45
0 1 44 43
0 53 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box1
2
291 0
322 0
4
0 0 47 37
0 4 36 30
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box2
2
291 0
322 0
4
0 0 47 37
0 2 36 30
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box3
2
291 0
322 0
4
0 0 47 37
0 5 36 30
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box5
2
291 0
322 0
4
0 0 47 37
0 3 36 30
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_13_17 loc_12_17 up box6
2
291 0
322 0
4
0 0 47 37
0 1 36 30
0 37 0 1
0 45 -1 0
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box1
2
323 0
327 0
4
0 0 47 48
0 4 47 48
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box2
2
323 0
327 0
4
0 0 47 48
0 2 47 48
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box3
2
323 0
327 0
4
0 0 47 48
0 5 47 48
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box5
2
323 0
327 0
4
0 0 47 48
0 3 47 48
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_17 loc_14_18 loc_14_19 right box6
2
323 0
327 0
4
0 0 47 48
0 1 47 48
0 57 -1 0
0 58 0 1
1
end_operator
begin_operator
push loc_14_17 loc_15_17 loc_16_17 down box1
2
324 0
374 0
4
0 0 47 63
0 4 62 71
0 72 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_14_17 loc_15_17 loc_16_17 down box2
2
324 0
374 0
4
0 0 47 63
0 2 62 71
0 72 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_14_17 loc_15_17 loc_16_17 down box3
2
324 0
374 0
4
0 0 47 63
0 5 62 71
0 72 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_14_17 loc_15_17 loc_16_17 down box5
2
324 0
374 0
4
0 0 47 63
0 3 62 71
0 72 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_14_17 loc_15_17 loc_16_17 down box6
2
324 0
374 0
4
0 0 47 63
0 1 62 71
0 72 -1 0
0 82 0 1
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box1
2
294 0
325 0
4
0 0 48 38
0 4 37 31
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box2
2
294 0
325 0
4
0 0 48 38
0 2 37 31
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box3
2
294 0
325 0
4
0 0 48 38
0 5 37 31
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box5
2
294 0
325 0
4
0 0 48 38
0 3 37 31
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_13_18 loc_12_18 up box6
2
294 0
325 0
4
0 0 48 38
0 1 37 31
0 38 0 1
0 46 -1 0
1
end_operator
begin_operator
push loc_14_18 loc_15_18 loc_16_18 down box1
2
328 0
378 0
4
0 0 48 64
0 4 63 72
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_14_18 loc_15_18 loc_16_18 down box2
2
328 0
378 0
4
0 0 48 64
0 2 63 72
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_14_18 loc_15_18 loc_16_18 down box3
2
328 0
378 0
4
0 0 48 64
0 5 63 72
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_14_18 loc_15_18 loc_16_18 down box5
2
328 0
378 0
4
0 0 48 64
0 3 63 72
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_14_18 loc_15_18 loc_16_18 down box6
2
328 0
378 0
4
0 0 48 64
0 1 63 72
0 73 -1 0
0 83 0 1
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box1
2
298 0
329 0
4
0 0 49 39
0 4 38 32
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box2
2
298 0
329 0
4
0 0 49 39
0 2 38 32
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box3
2
298 0
329 0
4
0 0 49 39
0 5 38 32
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box4
2
298 0
329 0
4
0 0 49 39
0 6 4 3
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box5
2
298 0
329 0
4
0 0 49 39
0 3 38 32
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_13_19 loc_12_19 up box6
2
298 0
329 0
4
0 0 49 39
0 1 38 32
0 39 0 1
0 47 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box1
2
326 0
330 0
4
0 0 49 48
0 4 47 46
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box2
2
326 0
330 0
4
0 0 49 48
0 2 47 46
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box3
2
326 0
330 0
4
0 0 49 48
0 5 47 46
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box5
2
326 0
330 0
4
0 0 49 48
0 3 47 46
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_14_18 loc_14_17 left box6
2
326 0
330 0
4
0 0 49 48
0 1 47 46
0 56 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box1
2
331 0
381 0
4
0 0 49 65
0 4 64 73
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box2
2
331 0
381 0
4
0 0 49 65
0 2 64 73
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box3
2
331 0
381 0
4
0 0 49 65
0 5 64 73
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box4
2
331 0
381 0
4
0 0 49 65
0 6 6 7
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box5
2
331 0
381 0
4
0 0 49 65
0 3 64 73
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_19 loc_15_19 loc_16_19 down box6
2
331 0
381 0
4
0 0 49 65
0 1 64 73
0 74 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_14_4 loc_14_5 loc_14_6 right box1
2
333 0
336 0
4
0 0 50 51
0 4 50 51
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_14_4 loc_14_5 loc_14_6 right box2
2
333 0
336 0
4
0 0 50 51
0 2 50 51
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_14_4 loc_14_5 loc_14_6 right box3
2
333 0
336 0
4
0 0 50 51
0 5 50 51
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_14_4 loc_14_5 loc_14_6 right box5
2
333 0
336 0
4
0 0 50 51
0 3 50 51
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_14_4 loc_14_5 loc_14_6 right box6
2
333 0
336 0
4
0 0 50 51
0 1 50 51
0 60 -1 0
0 61 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box1
2
336 0
340 0
4
0 0 51 52
0 4 51 52
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box2
2
336 0
340 0
4
0 0 51 52
0 2 51 52
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box3
2
336 0
340 0
4
0 0 51 52
0 5 51 52
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box5
2
336 0
340 0
4
0 0 51 52
0 3 51 52
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_5 loc_14_6 loc_14_7 right box6
2
336 0
340 0
4
0 0 51 52
0 1 51 52
0 61 -1 0
0 62 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_5 loc_14_4 left box1
2
335 0
339 0
4
0 0 52 51
0 4 50 49
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_5 loc_14_4 left box2
2
335 0
339 0
4
0 0 52 51
0 2 50 49
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_5 loc_14_4 left box3
2
335 0
339 0
4
0 0 52 51
0 5 50 49
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_5 loc_14_4 left box5
2
335 0
339 0
4
0 0 52 51
0 3 50 49
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_5 loc_14_4 left box6
2
335 0
339 0
4
0 0 52 51
0 1 50 49
0 59 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box1
2
340 0
344 0
4
0 0 52 53
0 4 52 53
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box2
2
340 0
344 0
4
0 0 52 53
0 2 52 53
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box3
2
340 0
344 0
4
0 0 52 53
0 5 52 53
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box5
2
340 0
344 0
4
0 0 52 53
0 3 52 53
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_6 loc_14_7 loc_14_8 right box6
2
340 0
344 0
4
0 0 52 53
0 1 52 53
0 62 -1 0
0 63 0 1
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box1
2
309 0
342 0
4
0 0 53 43
0 4 42 33
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box2
2
309 0
342 0
4
0 0 53 43
0 2 42 33
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box3
2
309 0
342 0
4
0 0 53 43
0 5 42 33
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box5
2
309 0
342 0
4
0 0 53 43
0 3 42 33
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_13_7 loc_12_7 up box6
2
309 0
342 0
4
0 0 53 43
0 1 42 33
0 40 0 1
0 52 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box1
2
339 0
343 0
4
0 0 53 52
0 4 51 50
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box2
2
339 0
343 0
4
0 0 53 52
0 2 51 50
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box3
2
339 0
343 0
4
0 0 53 52
0 5 51 50
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box5
2
339 0
343 0
4
0 0 53 52
0 3 51 50
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_6 loc_14_5 left box6
2
339 0
343 0
4
0 0 53 52
0 1 51 50
0 60 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box1
2
344 0
347 0
4
0 0 53 54
0 4 53 54
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box2
2
344 0
347 0
4
0 0 53 54
0 2 53 54
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box3
2
344 0
347 0
4
0 0 53 54
0 5 53 54
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box5
2
344 0
347 0
4
0 0 53 54
0 3 53 54
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_7 loc_14_8 loc_14_9 right box6
2
344 0
347 0
4
0 0 53 54
0 1 53 54
0 63 -1 0
0 64 0 1
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box1
2
343 0
346 0
4
0 0 54 53
0 4 52 51
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box2
2
343 0
346 0
4
0 0 54 53
0 2 52 51
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box3
2
343 0
346 0
4
0 0 54 53
0 5 52 51
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box5
2
343 0
346 0
4
0 0 54 53
0 3 52 51
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_7 loc_14_6 left box6
2
343 0
346 0
4
0 0 54 53
0 1 52 51
0 61 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box1
2
347 0
349 0
4
0 0 54 55
0 4 54 43
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box2
2
347 0
349 0
4
0 0 54 55
0 2 54 43
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box3
2
347 0
349 0
4
0 0 54 55
0 5 54 43
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box5
2
347 0
349 0
4
0 0 54 55
0 3 54 43
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_8 loc_14_9 loc_14_10 right box6
2
347 0
349 0
4
0 0 54 55
0 1 54 43
0 53 0 1
0 64 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box1
2
313 0
349 0
4
0 0 55 44
0 4 43 44
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box2
2
313 0
349 0
4
0 0 55 44
0 2 43 44
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box3
2
313 0
349 0
4
0 0 55 44
0 5 43 44
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box5
2
313 0
349 0
4
0 0 55 44
0 3 43 44
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_10 loc_14_11 right box6
2
313 0
349 0
4
0 0 55 44
0 1 43 44
0 53 -1 0
0 54 0 1
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box1
2
346 0
350 0
4
0 0 55 54
0 4 53 52
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box2
2
346 0
350 0
4
0 0 55 54
0 2 53 52
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box3
2
346 0
350 0
4
0 0 55 54
0 5 53 52
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box5
2
346 0
350 0
4
0 0 55 54
0 3 53 52
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_14_9 loc_14_8 loc_14_7 left box6
2
346 0
350 0
4
0 0 55 54
0 1 53 52
0 62 0 1
0 63 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box1
2
312 0
352 0
4
0 0 56 44
0 4 43 34
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box2
2
312 0
352 0
4
0 0 56 44
0 2 43 34
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box3
2
312 0
352 0
4
0 0 56 44
0 5 43 34
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box5
2
312 0
352 0
4
0 0 56 44
0 3 43 34
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_14_10 loc_13_10 up box6
2
312 0
352 0
4
0 0 56 44
0 1 43 34
0 42 0 1
0 53 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box1
2
353 0
358 0
4
0 0 56 57
0 4 56 57
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box2
2
353 0
358 0
4
0 0 56 57
0 2 56 57
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box3
2
353 0
358 0
4
0 0 56 57
0 5 56 57
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box5
2
353 0
358 0
4
0 0 56 57
0 3 56 57
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_11 loc_15_12 right box6
2
353 0
358 0
4
0 0 56 57
0 1 56 57
0 66 -1 0
0 67 0 1
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box1
2
354 0
395 0
4
0 0 56 70
0 4 69 68
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box2
2
354 0
395 0
4
0 0 56 70
0 2 69 68
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box3
2
354 0
395 0
4
0 0 56 70
0 5 69 68
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box5
2
354 0
395 0
4
0 0 56 70
0 3 69 68
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_10 loc_15_9 loc_15_8 left box6
2
354 0
395 0
4
0 0 56 70
0 1 69 68
0 78 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box1
2
316 0
356 0
4
0 0 57 45
0 4 44 35
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box2
2
316 0
356 0
4
0 0 57 45
0 2 44 35
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box3
2
316 0
356 0
4
0 0 57 45
0 5 44 35
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box5
2
316 0
356 0
4
0 0 57 45
0 3 44 35
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_14_11 loc_13_11 up box6
2
316 0
356 0
4
0 0 57 45
0 1 44 35
0 43 0 1
0 54 -1 0
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box1
2
354 0
357 0
4
0 0 57 56
0 4 55 69
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box2
2
354 0
357 0
4
0 0 57 56
0 2 55 69
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box3
2
354 0
357 0
4
0 0 57 56
0 5 55 69
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box5
2
354 0
357 0
4
0 0 57 56
0 3 55 69
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_10 loc_15_9 left box6
2
354 0
357 0
4
0 0 57 56
0 1 55 69
0 65 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box1
2
358 0
361 0
4
0 0 57 58
0 4 57 58
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box2
2
358 0
361 0
4
0 0 57 58
0 2 57 58
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box3
2
358 0
361 0
4
0 0 57 58
0 5 57 58
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box5
2
358 0
361 0
4
0 0 57 58
0 3 57 58
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_11 loc_15_12 loc_15_13 right box6
2
358 0
361 0
4
0 0 57 58
0 1 57 58
0 67 -1 0
0 68 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box1
2
357 0
360 0
4
0 0 58 57
0 4 56 55
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box2
2
357 0
360 0
4
0 0 58 57
0 2 56 55
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box3
2
357 0
360 0
4
0 0 58 57
0 5 56 55
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box5
2
357 0
360 0
4
0 0 58 57
0 3 56 55
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_11 loc_15_10 left box6
2
357 0
360 0
4
0 0 58 57
0 1 56 55
0 65 0 1
0 66 -1 0
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box1
2
361 0
363 0
4
0 0 58 59
0 4 58 59
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box2
2
361 0
363 0
4
0 0 58 59
0 2 58 59
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box3
2
361 0
363 0
4
0 0 58 59
0 5 58 59
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box5
2
361 0
363 0
4
0 0 58 59
0 3 58 59
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_15_12 loc_15_13 loc_15_14 right box6
2
361 0
363 0
4
0 0 58 59
0 1 58 59
0 68 -1 0
0 69 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box1
2
360 0
362 0
4
0 0 59 58
0 4 57 56
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box2
2
360 0
362 0
4
0 0 59 58
0 2 57 56
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box3
2
360 0
362 0
4
0 0 59 58
0 5 57 56
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box5
2
360 0
362 0
4
0 0 59 58
0 3 57 56
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_12 loc_15_11 left box6
2
360 0
362 0
4
0 0 59 58
0 1 57 56
0 66 0 1
0 67 -1 0
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box1
2
363 0
365 0
4
0 0 59 60
0 4 59 60
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box2
2
363 0
365 0
4
0 0 59 60
0 2 59 60
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box3
2
363 0
365 0
4
0 0 59 60
0 5 59 60
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box5
2
363 0
365 0
4
0 0 59 60
0 3 59 60
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_15_13 loc_15_14 loc_15_15 right box6
2
363 0
365 0
4
0 0 59 60
0 1 59 60
0 69 -1 0
0 70 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box1
2
362 0
364 0
4
0 0 60 59
0 4 58 57
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box2
2
362 0
364 0
4
0 0 60 59
0 2 58 57
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box3
2
362 0
364 0
4
0 0 60 59
0 5 58 57
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box5
2
362 0
364 0
4
0 0 60 59
0 3 58 57
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_13 loc_15_12 left box6
2
362 0
364 0
4
0 0 60 59
0 1 58 57
0 67 0 1
0 68 -1 0
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box1
2
365 0
367 0
4
0 0 60 61
0 4 60 61
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box2
2
365 0
367 0
4
0 0 60 61
0 2 60 61
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box3
2
365 0
367 0
4
0 0 60 61
0 5 60 61
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box5
2
365 0
367 0
4
0 0 60 61
0 3 60 61
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_15_14 loc_15_15 loc_15_16 right box6
2
365 0
367 0
4
0 0 60 61
0 1 60 61
0 70 -1 0
0 71 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box1
2
364 0
366 0
4
0 0 61 60
0 4 59 58
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box2
2
364 0
366 0
4
0 0 61 60
0 2 59 58
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box3
2
364 0
366 0
4
0 0 61 60
0 5 59 58
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box5
2
364 0
366 0
4
0 0 61 60
0 3 59 58
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_14 loc_15_13 left box6
2
364 0
366 0
4
0 0 61 60
0 1 59 58
0 68 0 1
0 69 -1 0
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box1
2
367 0
370 0
4
0 0 61 62
0 4 61 62
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box2
2
367 0
370 0
4
0 0 61 62
0 2 61 62
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box3
2
367 0
370 0
4
0 0 61 62
0 5 61 62
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box5
2
367 0
370 0
4
0 0 61 62
0 3 61 62
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_15 loc_15_16 loc_15_17 right box6
2
367 0
370 0
4
0 0 61 62
0 1 61 62
0 71 -1 0
0 72 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box1
2
366 0
369 0
4
0 0 62 61
0 4 60 59
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box2
2
366 0
369 0
4
0 0 62 61
0 2 60 59
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box3
2
366 0
369 0
4
0 0 62 61
0 5 60 59
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box5
2
366 0
369 0
4
0 0 62 61
0 3 60 59
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_15 loc_15_14 left box6
2
366 0
369 0
4
0 0 62 61
0 1 60 59
0 69 0 1
0 70 -1 0
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box1
2
370 0
373 0
4
0 0 62 63
0 4 62 63
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box2
2
370 0
373 0
4
0 0 62 63
0 2 62 63
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box3
2
370 0
373 0
4
0 0 62 63
0 5 62 63
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box5
2
370 0
373 0
4
0 0 62 63
0 3 62 63
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_16 loc_15_17 loc_15_18 right box6
2
370 0
373 0
4
0 0 62 63
0 1 62 63
0 72 -1 0
0 73 0 1
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box1
2
322 0
371 0
4
0 0 63 47
0 4 46 36
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box2
2
322 0
371 0
4
0 0 63 47
0 2 46 36
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box3
2
322 0
371 0
4
0 0 63 47
0 5 46 36
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box5
2
322 0
371 0
4
0 0 63 47
0 3 46 36
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_14_17 loc_13_17 up box6
2
322 0
371 0
4
0 0 63 47
0 1 46 36
0 45 0 1
0 56 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box1
2
369 0
372 0
4
0 0 63 62
0 4 61 60
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box2
2
369 0
372 0
4
0 0 63 62
0 2 61 60
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box3
2
369 0
372 0
4
0 0 63 62
0 5 61 60
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box5
2
369 0
372 0
4
0 0 63 62
0 3 61 60
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_16 loc_15_15 left box6
2
369 0
372 0
4
0 0 63 62
0 1 61 60
0 70 0 1
0 71 -1 0
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box1
2
373 0
377 0
4
0 0 63 64
0 4 63 64
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box2
2
373 0
377 0
4
0 0 63 64
0 2 63 64
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box3
2
373 0
377 0
4
0 0 63 64
0 5 63 64
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box5
2
373 0
377 0
4
0 0 63 64
0 3 63 64
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_15_17 loc_15_18 loc_15_19 right box6
2
373 0
377 0
4
0 0 63 64
0 1 63 64
0 73 -1 0
0 74 0 1
1
end_operator
begin_operator
push loc_15_17 loc_16_17 loc_17_17 down box1
2
374 0
400 0
4
0 0 63 73
0 4 71 75
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_15_17 loc_16_17 loc_17_17 down box2
2
374 0
400 0
4
0 0 63 73
0 2 71 75
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_15_17 loc_16_17 loc_17_17 down box3
2
374 0
400 0
4
0 0 63 73
0 5 71 75
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_15_17 loc_16_17 loc_17_17 down box5
2
374 0
400 0
4
0 0 63 73
0 3 71 75
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_15_17 loc_16_17 loc_17_17 down box6
2
374 0
400 0
4
0 0 63 73
0 1 71 75
0 82 -1 0
0 88 0 1
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box1
2
325 0
375 0
4
0 0 64 48
0 4 47 37
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box2
2
325 0
375 0
4
0 0 64 48
0 2 47 37
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box3
2
325 0
375 0
4
0 0 64 48
0 5 47 37
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box5
2
325 0
375 0
4
0 0 64 48
0 3 47 37
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_14_18 loc_13_18 up box6
2
325 0
375 0
4
0 0 64 48
0 1 47 37
0 46 0 1
0 57 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box1
2
372 0
376 0
4
0 0 64 63
0 4 62 61
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box2
2
372 0
376 0
4
0 0 64 63
0 2 62 61
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box3
2
372 0
376 0
4
0 0 64 63
0 5 62 61
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box5
2
372 0
376 0
4
0 0 64 63
0 3 62 61
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_15_18 loc_15_17 loc_15_16 left box6
2
372 0
376 0
4
0 0 64 63
0 1 62 61
0 71 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box1
2
329 0
379 0
4
0 0 65 49
0 4 48 38
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box2
2
329 0
379 0
4
0 0 65 49
0 2 48 38
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box3
2
329 0
379 0
4
0 0 65 49
0 5 48 38
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box4
2
329 0
379 0
4
0 0 65 49
0 6 5 4
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box5
2
329 0
379 0
4
0 0 65 49
0 3 48 38
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_14_19 loc_13_19 up box6
2
329 0
379 0
4
0 0 65 49
0 1 48 38
0 47 0 1
0 58 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box1
2
376 0
380 0
4
0 0 65 64
0 4 63 62
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box2
2
376 0
380 0
4
0 0 65 64
0 2 63 62
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box3
2
376 0
380 0
4
0 0 65 64
0 5 63 62
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box5
2
376 0
380 0
4
0 0 65 64
0 3 63 62
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_15_19 loc_15_18 loc_15_17 left box6
2
376 0
380 0
4
0 0 65 64
0 1 63 62
0 72 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box1
2
334 0
382 0
4
0 0 66 51
0 4 50 40
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box2
2
334 0
382 0
4
0 0 66 51
0 2 50 40
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box3
2
334 0
382 0
4
0 0 66 51
0 5 50 40
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box5
2
334 0
382 0
4
0 0 66 51
0 3 50 40
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_14_5 loc_13_5 up box6
2
334 0
382 0
4
0 0 66 51
0 1 50 40
0 50 0 1
0 60 -1 0
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box1
2
383 0
386 0
4
0 0 66 67
0 4 66 67
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box2
2
383 0
386 0
4
0 0 66 67
0 2 66 67
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box3
2
383 0
386 0
4
0 0 66 67
0 5 66 67
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box5
2
383 0
386 0
4
0 0 66 67
0 3 66 67
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_15_5 loc_15_6 loc_15_7 right box6
2
383 0
386 0
4
0 0 66 67
0 1 66 67
0 76 -1 0
0 77 0 1
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box1
2
338 0
384 0
4
0 0 67 52
0 4 51 41
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box2
2
338 0
384 0
4
0 0 67 52
0 2 51 41
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box3
2
338 0
384 0
4
0 0 67 52
0 5 51 41
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box5
2
338 0
384 0
4
0 0 67 52
0 3 51 41
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_14_6 loc_13_6 up box6
2
338 0
384 0
4
0 0 67 52
0 1 51 41
0 51 0 1
0 61 -1 0
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box1
2
386 0
389 0
4
0 0 67 68
0 4 67 68
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box2
2
386 0
389 0
4
0 0 67 68
0 2 67 68
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box3
2
386 0
389 0
4
0 0 67 68
0 5 67 68
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box5
2
386 0
389 0
4
0 0 67 68
0 3 67 68
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_15_6 loc_15_7 loc_15_8 right box6
2
386 0
389 0
4
0 0 67 68
0 1 67 68
0 77 -1 0
0 78 0 1
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box1
2
342 0
387 0
4
0 0 68 53
0 4 52 42
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box2
2
342 0
387 0
4
0 0 68 53
0 2 52 42
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box3
2
342 0
387 0
4
0 0 68 53
0 5 52 42
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box5
2
342 0
387 0
4
0 0 68 53
0 3 52 42
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_14_7 loc_13_7 up box6
2
342 0
387 0
4
0 0 68 53
0 1 52 42
0 52 0 1
0 62 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box1
2
385 0
388 0
4
0 0 68 67
0 4 66 65
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box2
2
385 0
388 0
4
0 0 68 67
0 2 66 65
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box3
2
385 0
388 0
4
0 0 68 67
0 5 66 65
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box5
2
385 0
388 0
4
0 0 68 67
0 3 66 65
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_6 loc_15_5 left box6
2
385 0
388 0
4
0 0 68 67
0 1 66 65
0 75 0 1
0 76 -1 0
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box1
2
389 0
392 0
4
0 0 68 69
0 4 68 69
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box2
2
389 0
392 0
4
0 0 68 69
0 2 68 69
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box3
2
389 0
392 0
4
0 0 68 69
0 5 68 69
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box5
2
389 0
392 0
4
0 0 68 69
0 3 68 69
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_7 loc_15_8 loc_15_9 right box6
2
389 0
392 0
4
0 0 68 69
0 1 68 69
0 78 -1 0
0 79 0 1
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box1
2
388 0
391 0
4
0 0 69 68
0 4 67 66
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box2
2
388 0
391 0
4
0 0 69 68
0 2 67 66
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box3
2
388 0
391 0
4
0 0 69 68
0 5 67 66
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box5
2
388 0
391 0
4
0 0 69 68
0 3 67 66
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_7 loc_15_6 left box6
2
388 0
391 0
4
0 0 69 68
0 1 67 66
0 76 0 1
0 77 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box1
2
392 0
394 0
4
0 0 69 70
0 4 69 55
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box2
2
392 0
394 0
4
0 0 69 70
0 2 69 55
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box3
2
392 0
394 0
4
0 0 69 70
0 5 69 55
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box5
2
392 0
394 0
4
0 0 69 70
0 3 69 55
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_8 loc_15_9 loc_15_10 right box6
2
392 0
394 0
4
0 0 69 70
0 1 69 55
0 65 0 1
0 79 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box1
2
353 0
394 0
4
0 0 70 56
0 4 55 56
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box2
2
353 0
394 0
4
0 0 70 56
0 2 55 56
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box3
2
353 0
394 0
4
0 0 70 56
0 5 55 56
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box5
2
353 0
394 0
4
0 0 70 56
0 3 55 56
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_10 loc_15_11 right box6
2
353 0
394 0
4
0 0 70 56
0 1 55 56
0 65 -1 0
0 66 0 1
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box1
2
391 0
395 0
4
0 0 70 69
0 4 68 67
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box2
2
391 0
395 0
4
0 0 70 69
0 2 68 67
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box3
2
391 0
395 0
4
0 0 70 69
0 5 68 67
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box5
2
391 0
395 0
4
0 0 70 69
0 3 68 67
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_15_9 loc_15_8 loc_15_7 left box6
2
391 0
395 0
4
0 0 70 69
0 1 68 67
0 77 0 1
0 78 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_15_17 loc_14_17 up box1
2
371 0
398 0
4
0 0 73 63
0 4 62 46
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_15_17 loc_14_17 up box2
2
371 0
398 0
4
0 0 73 63
0 2 62 46
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_15_17 loc_14_17 up box3
2
371 0
398 0
4
0 0 73 63
0 5 62 46
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_15_17 loc_14_17 up box5
2
371 0
398 0
4
0 0 73 63
0 3 62 46
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_15_17 loc_14_17 up box6
2
371 0
398 0
4
0 0 73 63
0 1 62 46
0 56 0 1
0 72 -1 0
1
end_operator
begin_operator
push loc_16_17 loc_16_18 loc_16_19 right box1
2
399 0
403 0
4
0 0 73 74
0 4 72 73
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_17 loc_16_18 loc_16_19 right box2
2
399 0
403 0
4
0 0 73 74
0 2 72 73
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_17 loc_16_18 loc_16_19 right box3
2
399 0
403 0
4
0 0 73 74
0 5 72 73
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_17 loc_16_18 loc_16_19 right box5
2
399 0
403 0
4
0 0 73 74
0 3 72 73
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_17 loc_16_18 loc_16_19 right box6
2
399 0
403 0
4
0 0 73 74
0 1 72 73
0 83 -1 0
0 84 0 1
1
end_operator
begin_operator
push loc_16_18 loc_15_18 loc_14_18 up box1
2
375 0
401 0
4
0 0 74 64
0 4 63 47
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_16_18 loc_15_18 loc_14_18 up box2
2
375 0
401 0
4
0 0 74 64
0 2 63 47
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_16_18 loc_15_18 loc_14_18 up box3
2
375 0
401 0
4
0 0 74 64
0 5 63 47
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_16_18 loc_15_18 loc_14_18 up box5
2
375 0
401 0
4
0 0 74 64
0 3 63 47
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_16_18 loc_15_18 loc_14_18 up box6
2
375 0
401 0
4
0 0 74 64
0 1 63 47
0 57 0 1
0 73 -1 0
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box1
2
403 0
406 0
4
0 0 74 75
0 4 73 74
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box2
2
403 0
406 0
4
0 0 74 75
0 2 73 74
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box3
2
403 0
406 0
4
0 0 74 75
0 5 73 74
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box4
2
403 0
406 0
4
0 0 74 75
0 6 7 8
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box5
2
403 0
406 0
4
0 0 74 75
0 3 73 74
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_18 loc_16_19 loc_16_20 right box6
2
403 0
406 0
4
0 0 74 75
0 1 73 74
0 84 -1 0
0 85 0 1
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box1
2
379 0
404 0
4
0 0 75 65
0 4 64 48
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box2
2
379 0
404 0
4
0 0 75 65
0 2 64 48
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box3
2
379 0
404 0
4
0 0 75 65
0 5 64 48
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box4
2
379 0
404 0
4
0 0 75 65
0 6 6 5
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box5
2
379 0
404 0
4
0 0 75 65
0 3 64 48
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_15_19 loc_14_19 up box6
2
379 0
404 0
4
0 0 75 65
0 1 64 48
0 58 0 1
0 74 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_16_18 loc_16_17 left box1
2
402 0
405 0
4
0 0 75 74
0 4 72 71
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_16_18 loc_16_17 left box2
2
402 0
405 0
4
0 0 75 74
0 2 72 71
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_16_18 loc_16_17 left box3
2
402 0
405 0
4
0 0 75 74
0 5 72 71
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_16_18 loc_16_17 left box5
2
402 0
405 0
4
0 0 75 74
0 3 72 71
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_16_19 loc_16_18 loc_16_17 left box6
2
402 0
405 0
4
0 0 75 74
0 1 72 71
0 82 0 1
0 83 -1 0
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box1
2
428 0
433 0
4
0 0 82 84
0 4 78 79
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box2
2
428 0
433 0
4
0 0 82 84
0 2 78 79
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box3
2
428 0
433 0
4
0 0 82 84
0 5 78 79
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box5
2
428 0
433 0
4
0 0 82 84
0 3 78 79
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_2 loc_3_3 loc_3_4 right box6
2
428 0
433 0
4
0 0 82 84
0 1 78 79
0 111 -1 0
0 112 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box1
2
433 0
435 0
4
0 0 84 85
0 4 79 80
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box2
2
433 0
435 0
4
0 0 84 85
0 2 79 80
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box3
2
433 0
435 0
4
0 0 84 85
0 5 79 80
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box5
2
433 0
435 0
4
0 0 84 85
0 3 79 80
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_3 loc_3_4 loc_3_5 right box6
2
433 0
435 0
4
0 0 84 85
0 1 79 80
0 112 -1 0
0 113 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box1
2
432 0
434 0
4
0 0 85 84
0 4 78 77
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box2
2
432 0
434 0
4
0 0 85 84
0 2 78 77
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box3
2
432 0
434 0
4
0 0 85 84
0 5 78 77
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box5
2
432 0
434 0
4
0 0 85 84
0 3 78 77
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_3 loc_3_2 left box6
2
432 0
434 0
4
0 0 85 84
0 1 78 77
0 109 0 1
0 111 -1 0
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box1
2
435 0
438 0
4
0 0 85 86
0 4 80 81
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box2
2
435 0
438 0
4
0 0 85 86
0 2 80 81
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box3
2
435 0
438 0
4
0 0 85 86
0 5 80 81
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box5
2
435 0
438 0
4
0 0 85 86
0 3 80 81
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_4 loc_3_5 loc_3_6 right box6
2
435 0
438 0
4
0 0 85 86
0 1 80 81
0 113 -1 0
0 114 0 1
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box1
2
434 0
437 0
4
0 0 86 85
0 4 79 78
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box2
2
434 0
437 0
4
0 0 86 85
0 2 79 78
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box3
2
434 0
437 0
4
0 0 86 85
0 5 79 78
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box5
2
434 0
437 0
4
0 0 86 85
0 3 79 78
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_3_4 loc_3_3 left box6
2
434 0
437 0
4
0 0 86 85
0 1 79 78
0 111 0 1
0 112 -1 0
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box1
2
439 0
452 0
4
0 0 86 90
0 4 82 87
0 120 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box2
2
439 0
452 0
4
0 0 86 90
0 2 82 87
0 120 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box3
2
439 0
452 0
4
0 0 86 90
0 5 82 87
0 120 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box5
2
439 0
452 0
4
0 0 86 90
0 3 82 87
0 120 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_3_5 loc_4_5 loc_5_5 down box6
2
439 0
452 0
4
0 0 86 90
0 1 82 87
0 120 -1 0
0 128 0 1
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box1
2
437 0
440 0
4
0 0 87 86
0 4 80 79
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box2
2
437 0
440 0
4
0 0 87 86
0 2 80 79
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box3
2
437 0
440 0
4
0 0 87 86
0 5 80 79
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box5
2
437 0
440 0
4
0 0 87 86
0 3 80 79
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_3_5 loc_3_4 left box6
2
437 0
440 0
4
0 0 87 86
0 1 80 79
0 112 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box1
2
441 0
455 0
4
0 0 87 91
0 4 83 88
0 121 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box2
2
441 0
455 0
4
0 0 87 91
0 2 83 88
0 121 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box3
2
441 0
455 0
4
0 0 87 91
0 5 83 88
0 121 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box5
2
441 0
455 0
4
0 0 87 91
0 3 83 88
0 121 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_3_6 loc_4_6 loc_5_6 down box6
2
441 0
455 0
4
0 0 87 91
0 1 83 88
0 121 -1 0
0 129 0 1
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box1
2
436 0
450 0
4
0 0 90 86
0 4 80 76
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box2
2
436 0
450 0
4
0 0 90 86
0 2 80 76
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box3
2
436 0
450 0
4
0 0 90 86
0 5 80 76
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box5
2
436 0
450 0
4
0 0 90 86
0 3 80 76
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_3_5 loc_2_5 up box6
2
436 0
450 0
4
0 0 90 86
0 1 80 76
0 105 0 1
0 113 -1 0
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box1
2
452 0
468 0
4
0 0 90 96
0 4 87 96
0 128 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box2
2
452 0
468 0
4
0 0 90 96
0 2 87 96
0 128 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box3
2
452 0
468 0
4
0 0 90 96
0 5 87 96
0 128 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box5
2
452 0
468 0
4
0 0 90 96
0 3 87 96
0 128 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_4_5 loc_5_5 loc_6_5 down box6
2
452 0
468 0
4
0 0 90 96
0 1 87 96
0 128 -1 0
0 138 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box1
2
455 0
472 0
4
0 0 91 97
0 4 88 97
0 129 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box2
2
455 0
472 0
4
0 0 91 97
0 2 88 97
0 129 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box3
2
455 0
472 0
4
0 0 91 97
0 5 88 97
0 129 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box5
2
455 0
472 0
4
0 0 91 97
0 3 88 97
0 129 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_4_6 loc_5_6 loc_6_6 down box6
2
455 0
472 0
4
0 0 91 97
0 1 88 97
0 129 -1 0
0 139 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box1
2
457 0
460 0
4
0 0 92 93
0 4 85 86
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box2
2
457 0
460 0
4
0 0 92 93
0 2 85 86
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box3
2
457 0
460 0
4
0 0 92 93
0 5 85 86
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box4
2
457 0
460 0
4
0 0 92 93
0 6 9 10
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box5
2
457 0
460 0
4
0 0 92 93
0 3 85 86
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_5_19 loc_5_20 right box6
2
457 0
460 0
4
0 0 92 93
0 1 85 86
0 125 -1 0
0 127 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box1
2
458 0
486 0
4
0 0 92 103
0 4 94 104
0 135 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box2
2
458 0
486 0
4
0 0 92 103
0 2 94 104
0 135 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box3
2
458 0
486 0
4
0 0 92 103
0 5 94 104
0 135 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box5
2
458 0
486 0
4
0 0 92 103
0 3 94 104
0 135 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_18 loc_6_18 loc_7_18 down box6
2
458 0
486 0
4
0 0 92 103
0 1 94 104
0 135 -1 0
0 146 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box1
2
461 0
489 0
4
0 0 93 104
0 4 95 105
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box2
2
461 0
489 0
4
0 0 93 104
0 2 95 105
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box3
2
461 0
489 0
4
0 0 93 104
0 5 95 105
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box4
2
461 0
489 0
4
0 0 93 104
0 6 11 12
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box5
2
461 0
489 0
4
0 0 93 104
0 3 95 105
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_19 loc_6_19 loc_7_19 down box6
2
461 0
489 0
4
0 0 93 104
0 1 95 105
0 136 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box1
2
450 0
466 0
4
0 0 96 90
0 4 82 80
0 113 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box2
2
450 0
466 0
4
0 0 96 90
0 2 82 80
0 113 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box3
2
450 0
466 0
4
0 0 96 90
0 5 82 80
0 113 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box5
2
450 0
466 0
4
0 0 96 90
0 3 82 80
0 113 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_4_5 loc_3_5 up box6
2
450 0
466 0
4
0 0 96 90
0 1 82 80
0 113 0 1
0 120 -1 0
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box1
2
467 0
471 0
4
0 0 96 97
0 4 88 89
0 129 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box2
2
467 0
471 0
4
0 0 96 97
0 2 88 89
0 129 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box3
2
467 0
471 0
4
0 0 96 97
0 5 88 89
0 129 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box5
2
467 0
471 0
4
0 0 96 97
0 3 88 89
0 129 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_5_5 loc_5_6 loc_5_7 right box6
2
467 0
471 0
4
0 0 96 97
0 1 88 89
0 129 -1 0
0 130 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box1
2
468 0
494 0
4
0 0 96 106
0 4 96 107
0 138 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box2
2
468 0
494 0
4
0 0 96 106
0 2 96 107
0 138 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box3
2
468 0
494 0
4
0 0 96 106
0 5 96 107
0 138 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box5
2
468 0
494 0
4
0 0 96 106
0 3 96 107
0 138 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_5_5 loc_6_5 loc_7_5 down box6
2
468 0
494 0
4
0 0 96 106
0 1 96 107
0 138 -1 0
0 150 0 1
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box1
2
453 0
469 0
4
0 0 97 91
0 4 83 81
0 114 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box2
2
453 0
469 0
4
0 0 97 91
0 2 83 81
0 114 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box3
2
453 0
469 0
4
0 0 97 91
0 5 83 81
0 114 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box5
2
453 0
469 0
4
0 0 97 91
0 3 83 81
0 114 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_4_6 loc_3_6 up box6
2
453 0
469 0
4
0 0 97 91
0 1 83 81
0 114 0 1
0 121 -1 0
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box1
2
471 0
474 0
4
0 0 97 98
0 4 89 90
0 130 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box2
2
471 0
474 0
4
0 0 97 98
0 2 89 90
0 130 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box3
2
471 0
474 0
4
0 0 97 98
0 5 89 90
0 130 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box5
2
471 0
474 0
4
0 0 97 98
0 3 89 90
0 130 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_5_6 loc_5_7 loc_5_8 right box6
2
471 0
474 0
4
0 0 97 98
0 1 89 90
0 130 -1 0
0 131 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box1
2
470 0
473 0
4
0 0 98 97
0 4 88 87
0 128 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box2
2
470 0
473 0
4
0 0 98 97
0 2 88 87
0 128 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box3
2
470 0
473 0
4
0 0 98 97
0 5 88 87
0 128 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box5
2
470 0
473 0
4
0 0 98 97
0 3 88 87
0 128 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_6 loc_5_5 left box6
2
470 0
473 0
4
0 0 98 97
0 1 88 87
0 128 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box1
2
474 0
477 0
4
0 0 98 99
0 4 90 91
0 131 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box2
2
474 0
477 0
4
0 0 98 99
0 2 90 91
0 131 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box3
2
474 0
477 0
4
0 0 98 99
0 5 90 91
0 131 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box5
2
474 0
477 0
4
0 0 98 99
0 3 90 91
0 131 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_5_7 loc_5_8 loc_5_9 right box6
2
474 0
477 0
4
0 0 98 99
0 1 90 91
0 131 -1 0
0 132 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box1
2
475 0
500 0
4
0 0 98 108
0 4 98 108
0 140 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box2
2
475 0
500 0
4
0 0 98 108
0 2 98 108
0 140 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box3
2
475 0
500 0
4
0 0 98 108
0 5 98 108
0 140 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box5
2
475 0
500 0
4
0 0 98 108
0 3 98 108
0 140 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_5_7 loc_6_7 loc_7_7 down box6
2
475 0
500 0
4
0 0 98 108
0 1 98 108
0 140 -1 0
0 151 0 1
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box1
2
473 0
476 0
4
0 0 99 98
0 4 89 88
0 129 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box2
2
473 0
476 0
4
0 0 99 98
0 2 89 88
0 129 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box3
2
473 0
476 0
4
0 0 99 98
0 5 89 88
0 129 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box5
2
473 0
476 0
4
0 0 99 98
0 3 89 88
0 129 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_5_8 loc_5_7 loc_5_6 left box6
2
473 0
476 0
4
0 0 99 98
0 1 89 88
0 129 0 1
0 130 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box1
2
476 0
478 0
4
0 0 100 99
0 4 90 89
0 130 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box2
2
476 0
478 0
4
0 0 100 99
0 2 90 89
0 130 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box3
2
476 0
478 0
4
0 0 100 99
0 5 90 89
0 130 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box5
2
476 0
478 0
4
0 0 100 99
0 3 90 89
0 130 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_5_8 loc_5_7 left box6
2
476 0
478 0
4
0 0 100 99
0 1 90 89
0 130 0 1
0 131 -1 0
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box1
2
479 0
502 0
4
0 0 100 109
0 4 99 110
0 141 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box2
2
479 0
502 0
4
0 0 100 109
0 2 99 110
0 141 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box3
2
479 0
502 0
4
0 0 100 109
0 5 99 110
0 141 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box5
2
479 0
502 0
4
0 0 100 109
0 3 99 110
0 141 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_5_9 loc_6_9 loc_7_9 down box6
2
479 0
502 0
4
0 0 100 109
0 1 99 110
0 141 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_6_17 loc_6_18 loc_6_19 right box1
2
481 0
485 0
4
0 0 102 103
0 4 94 95
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_6_17 loc_6_18 loc_6_19 right box2
2
481 0
485 0
4
0 0 102 103
0 2 94 95
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_6_17 loc_6_18 loc_6_19 right box3
2
481 0
485 0
4
0 0 102 103
0 5 94 95
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_6_17 loc_6_18 loc_6_19 right box5
2
481 0
485 0
4
0 0 102 103
0 3 94 95
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_6_17 loc_6_18 loc_6_19 right box6
2
481 0
485 0
4
0 0 102 103
0 1 94 95
0 135 -1 0
0 136 0 1
1
end_operator
begin_operator
push loc_6_17 loc_7_17 loc_8_17 down box1
2
482 0
514 0
4
0 0 102 113
0 4 103 115
0 145 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_6_17 loc_7_17 loc_8_17 down box2
2
482 0
514 0
4
0 0 102 113
0 2 103 115
0 145 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_6_17 loc_7_17 loc_8_17 down box3
2
482 0
514 0
4
0 0 102 113
0 5 103 115
0 145 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_6_17 loc_7_17 loc_8_17 down box5
2
482 0
514 0
4
0 0 102 113
0 3 103 115
0 145 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_6_17 loc_7_17 loc_8_17 down box6
2
482 0
514 0
4
0 0 102 113
0 1 103 115
0 145 -1 0
0 158 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box1
2
486 0
518 0
4
0 0 103 114
0 4 104 116
0 146 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box2
2
486 0
518 0
4
0 0 103 114
0 2 104 116
0 146 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box3
2
486 0
518 0
4
0 0 103 114
0 5 104 116
0 146 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box5
2
486 0
518 0
4
0 0 103 114
0 3 104 116
0 146 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_6_18 loc_7_18 loc_8_18 down box6
2
486 0
518 0
4
0 0 103 114
0 1 104 116
0 146 -1 0
0 159 0 1
1
end_operator
begin_operator
push loc_6_19 loc_6_18 loc_6_17 left box1
2
484 0
488 0
4
0 0 104 103
0 4 94 93
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_19 loc_6_18 loc_6_17 left box2
2
484 0
488 0
4
0 0 104 103
0 2 94 93
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_19 loc_6_18 loc_6_17 left box3
2
484 0
488 0
4
0 0 104 103
0 5 94 93
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_19 loc_6_18 loc_6_17 left box5
2
484 0
488 0
4
0 0 104 103
0 3 94 93
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_19 loc_6_18 loc_6_17 left box6
2
484 0
488 0
4
0 0 104 103
0 1 94 93
0 134 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box1
2
489 0
521 0
4
0 0 104 115
0 4 105 117
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box2
2
489 0
521 0
4
0 0 104 115
0 2 105 117
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box3
2
489 0
521 0
4
0 0 104 115
0 5 105 117
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box4
2
489 0
521 0
4
0 0 104 115
0 6 12 13
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box5
2
489 0
521 0
4
0 0 104 115
0 3 105 117
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_19 loc_7_19 loc_8_19 down box6
2
489 0
521 0
4
0 0 104 115
0 1 105 117
0 147 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box1
2
466 0
492 0
4
0 0 106 96
0 4 87 82
0 120 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box2
2
466 0
492 0
4
0 0 106 96
0 2 87 82
0 120 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box3
2
466 0
492 0
4
0 0 106 96
0 5 87 82
0 120 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box5
2
466 0
492 0
4
0 0 106 96
0 3 87 82
0 120 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_5_5 loc_4_5 up box6
2
466 0
492 0
4
0 0 106 96
0 1 87 82
0 120 0 1
0 128 -1 0
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box1
2
493 0
497 0
4
0 0 106 107
0 4 97 98
0 139 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box2
2
493 0
497 0
4
0 0 106 107
0 2 97 98
0 139 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box3
2
493 0
497 0
4
0 0 106 107
0 5 97 98
0 139 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box5
2
493 0
497 0
4
0 0 106 107
0 3 97 98
0 139 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_6_5 loc_6_6 loc_6_7 right box6
2
493 0
497 0
4
0 0 106 107
0 1 97 98
0 139 -1 0
0 140 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box1
2
494 0
528 0
4
0 0 106 118
0 4 107 119
0 150 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box2
2
494 0
528 0
4
0 0 106 118
0 2 107 119
0 150 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box3
2
494 0
528 0
4
0 0 106 118
0 5 107 119
0 150 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box5
2
494 0
528 0
4
0 0 106 118
0 3 107 119
0 150 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_6_5 loc_7_5 loc_8_5 down box6
2
494 0
528 0
4
0 0 106 118
0 1 107 119
0 150 -1 0
0 163 0 1
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box1
2
469 0
495 0
4
0 0 107 97
0 4 88 83
0 121 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box2
2
469 0
495 0
4
0 0 107 97
0 2 88 83
0 121 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box3
2
469 0
495 0
4
0 0 107 97
0 5 88 83
0 121 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box5
2
469 0
495 0
4
0 0 107 97
0 3 88 83
0 121 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_6_6 loc_5_6 loc_4_6 up box6
2
469 0
495 0
4
0 0 107 97
0 1 88 83
0 121 0 1
0 129 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box1
2
496 0
499 0
4
0 0 108 107
0 4 97 96
0 138 0 1
0 139 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box2
2
496 0
499 0
4
0 0 108 107
0 2 97 96
0 138 0 1
0 139 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box3
2
496 0
499 0
4
0 0 108 107
0 5 97 96
0 138 0 1
0 139 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box5
2
496 0
499 0
4
0 0 108 107
0 3 97 96
0 138 0 1
0 139 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_6_6 loc_6_5 left box6
2
496 0
499 0
4
0 0 108 107
0 1 97 96
0 138 0 1
0 139 -1 0
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box1
2
500 0
531 0
4
0 0 108 119
0 4 108 121
0 151 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box2
2
500 0
531 0
4
0 0 108 119
0 2 108 121
0 151 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box3
2
500 0
531 0
4
0 0 108 119
0 5 108 121
0 151 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box5
2
500 0
531 0
4
0 0 108 119
0 3 108 121
0 151 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_6_7 loc_7_7 loc_8_7 down box6
2
500 0
531 0
4
0 0 108 119
0 1 108 121
0 151 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box1
2
502 0
538 0
4
0 0 109 121
0 4 110 123
0 153 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box2
2
502 0
538 0
4
0 0 109 121
0 2 110 123
0 153 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box3
2
502 0
538 0
4
0 0 109 121
0 5 110 123
0 153 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box5
2
502 0
538 0
4
0 0 109 121
0 3 110 123
0 153 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_6_9 loc_7_9 loc_8_9 down box6
2
502 0
538 0
4
0 0 109 121
0 1 110 123
0 153 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box1
2
503 0
508 0
4
0 0 110 111
0 4 101 102
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box2
2
503 0
508 0
4
0 0 110 111
0 2 101 102
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box3
2
503 0
508 0
4
0 0 110 111
0 5 101 102
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box5
2
503 0
508 0
4
0 0 110 111
0 3 101 102
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_11 loc_7_12 right box6
2
503 0
508 0
4
0 0 110 111
0 1 101 102
0 143 -1 0
0 144 0 1
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box1
2
504 0
537 0
4
0 0 110 121
0 4 110 109
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box2
2
504 0
537 0
4
0 0 110 121
0 2 110 109
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box3
2
504 0
537 0
4
0 0 110 121
0 5 110 109
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box5
2
504 0
537 0
4
0 0 110 121
0 3 110 109
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_7_9 loc_7_8 left box6
2
504 0
537 0
4
0 0 110 121
0 1 110 109
0 152 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box1
2
505 0
542 0
4
0 0 110 122
0 4 111 124
0 154 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box2
2
505 0
542 0
4
0 0 110 122
0 2 111 124
0 154 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box3
2
505 0
542 0
4
0 0 110 122
0 5 111 124
0 154 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box5
2
505 0
542 0
4
0 0 110 122
0 3 111 124
0 154 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_7_10 loc_8_10 loc_9_10 down box6
2
505 0
542 0
4
0 0 110 122
0 1 111 124
0 154 -1 0
0 168 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box1
2
504 0
507 0
4
0 0 111 110
0 4 100 110
0 142 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box2
2
504 0
507 0
4
0 0 111 110
0 2 100 110
0 142 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box3
2
504 0
507 0
4
0 0 111 110
0 5 100 110
0 142 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box5
2
504 0
507 0
4
0 0 111 110
0 3 100 110
0 142 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_11 loc_7_10 loc_7_9 left box6
2
504 0
507 0
4
0 0 111 110
0 1 100 110
0 142 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box1
2
509 0
546 0
4
0 0 111 123
0 4 112 125
0 155 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box2
2
509 0
546 0
4
0 0 111 123
0 2 112 125
0 155 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box3
2
509 0
546 0
4
0 0 111 123
0 5 112 125
0 155 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box5
2
509 0
546 0
4
0 0 111 123
0 3 112 125
0 155 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_7_11 loc_8_11 loc_9_11 down box6
2
509 0
546 0
4
0 0 111 123
0 1 112 125
0 155 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box1
2
507 0
510 0
4
0 0 112 111
0 4 101 100
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box2
2
507 0
510 0
4
0 0 112 111
0 2 101 100
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box3
2
507 0
510 0
4
0 0 112 111
0 5 101 100
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box5
2
507 0
510 0
4
0 0 112 111
0 3 101 100
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_7_11 loc_7_10 left box6
2
507 0
510 0
4
0 0 112 111
0 1 101 100
0 142 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box1
2
511 0
550 0
4
0 0 112 124
0 4 113 126
0 156 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box2
2
511 0
550 0
4
0 0 112 124
0 2 113 126
0 156 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box3
2
511 0
550 0
4
0 0 112 124
0 5 113 126
0 156 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box5
2
511 0
550 0
4
0 0 112 124
0 3 113 126
0 156 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_7_12 loc_8_12 loc_9_12 down box6
2
511 0
550 0
4
0 0 112 124
0 1 113 126
0 156 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_7_17 loc_7_18 loc_7_19 right box1
2
513 0
517 0
4
0 0 113 114
0 4 104 105
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_7_17 loc_7_18 loc_7_19 right box2
2
513 0
517 0
4
0 0 113 114
0 2 104 105
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_7_17 loc_7_18 loc_7_19 right box3
2
513 0
517 0
4
0 0 113 114
0 5 104 105
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_7_17 loc_7_18 loc_7_19 right box5
2
513 0
517 0
4
0 0 113 114
0 3 104 105
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_7_17 loc_7_18 loc_7_19 right box6
2
513 0
517 0
4
0 0 113 114
0 1 104 105
0 146 -1 0
0 147 0 1
1
end_operator
begin_operator
push loc_7_17 loc_8_17 loc_9_17 down box1
2
514 0
555 0
4
0 0 113 126
0 4 115 131
0 158 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_7_17 loc_8_17 loc_9_17 down box2
2
514 0
555 0
4
0 0 113 126
0 2 115 131
0 158 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_7_17 loc_8_17 loc_9_17 down box3
2
514 0
555 0
4
0 0 113 126
0 5 115 131
0 158 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_7_17 loc_8_17 loc_9_17 down box5
2
514 0
555 0
4
0 0 113 126
0 3 115 131
0 158 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_7_17 loc_8_17 loc_9_17 down box6
2
514 0
555 0
4
0 0 113 126
0 1 115 131
0 158 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box1
2
483 0
515 0
4
0 0 114 103
0 4 94 84
0 124 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box2
2
483 0
515 0
4
0 0 114 103
0 2 94 84
0 124 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box3
2
483 0
515 0
4
0 0 114 103
0 5 94 84
0 124 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box5
2
483 0
515 0
4
0 0 114 103
0 3 94 84
0 124 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_6_18 loc_5_18 up box6
2
483 0
515 0
4
0 0 114 103
0 1 94 84
0 124 0 1
0 135 -1 0
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box1
2
518 0
559 0
4
0 0 114 127
0 4 116 132
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box2
2
518 0
559 0
4
0 0 114 127
0 2 116 132
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box3
2
518 0
559 0
4
0 0 114 127
0 5 116 132
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box5
2
518 0
559 0
4
0 0 114 127
0 3 116 132
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_7_18 loc_8_18 loc_9_18 down box6
2
518 0
559 0
4
0 0 114 127
0 1 116 132
0 159 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box1
2
487 0
519 0
4
0 0 115 104
0 4 95 85
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box2
2
487 0
519 0
4
0 0 115 104
0 2 95 85
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box3
2
487 0
519 0
4
0 0 115 104
0 5 95 85
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box4
2
487 0
519 0
4
0 0 115 104
0 6 11 9
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box5
2
487 0
519 0
4
0 0 115 104
0 3 95 85
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_6_19 loc_5_19 up box6
2
487 0
519 0
4
0 0 115 104
0 1 95 85
0 125 0 1
0 136 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_7_18 loc_7_17 left box1
2
516 0
520 0
4
0 0 115 114
0 4 104 103
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_7_18 loc_7_17 left box2
2
516 0
520 0
4
0 0 115 114
0 2 104 103
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_7_18 loc_7_17 left box3
2
516 0
520 0
4
0 0 115 114
0 5 104 103
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_7_18 loc_7_17 left box5
2
516 0
520 0
4
0 0 115 114
0 3 104 103
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_7_18 loc_7_17 left box6
2
516 0
520 0
4
0 0 115 114
0 1 104 103
0 145 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box1
2
521 0
562 0
4
0 0 115 128
0 4 117 133
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box2
2
521 0
562 0
4
0 0 115 128
0 2 117 133
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box3
2
521 0
562 0
4
0 0 115 128
0 5 117 133
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box4
2
521 0
562 0
4
0 0 115 128
0 6 13 14
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box5
2
521 0
562 0
4
0 0 115 128
0 3 117 133
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_19 loc_8_19 loc_9_19 down box6
2
521 0
562 0
4
0 0 115 128
0 1 117 133
0 160 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box1
2
525 0
567 0
4
0 0 117 130
0 4 118 137
0 162 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box2
2
525 0
567 0
4
0 0 117 130
0 2 118 137
0 162 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box3
2
525 0
567 0
4
0 0 117 130
0 5 118 137
0 162 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box5
2
525 0
567 0
4
0 0 117 130
0 3 118 137
0 162 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_4 loc_8_4 loc_9_4 down box6
2
525 0
567 0
4
0 0 117 130
0 1 118 137
0 162 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box1
2
492 0
526 0
4
0 0 118 106
0 4 96 87
0 128 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box2
2
492 0
526 0
4
0 0 118 106
0 2 96 87
0 128 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box3
2
492 0
526 0
4
0 0 118 106
0 5 96 87
0 128 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box5
2
492 0
526 0
4
0 0 118 106
0 3 96 87
0 128 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_6_5 loc_5_5 up box6
2
492 0
526 0
4
0 0 118 106
0 1 96 87
0 128 0 1
0 138 -1 0
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box1
2
528 0
571 0
4
0 0 118 131
0 4 119 138
0 163 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box2
2
528 0
571 0
4
0 0 118 131
0 2 119 138
0 163 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box3
2
528 0
571 0
4
0 0 118 131
0 5 119 138
0 163 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box5
2
528 0
571 0
4
0 0 118 131
0 3 119 138
0 163 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_7_5 loc_8_5 loc_9_5 down box6
2
528 0
571 0
4
0 0 118 131
0 1 119 138
0 163 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box1
2
498 0
529 0
4
0 0 119 108
0 4 98 89
0 130 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box2
2
498 0
529 0
4
0 0 119 108
0 2 98 89
0 130 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box3
2
498 0
529 0
4
0 0 119 108
0 5 98 89
0 130 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box5
2
498 0
529 0
4
0 0 119 108
0 3 98 89
0 130 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_6_7 loc_5_7 up box6
2
498 0
529 0
4
0 0 119 108
0 1 98 89
0 130 0 1
0 140 -1 0
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box1
2
530 0
533 0
4
0 0 119 120
0 4 109 110
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box2
2
530 0
533 0
4
0 0 119 120
0 2 109 110
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box3
2
530 0
533 0
4
0 0 119 120
0 5 109 110
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box5
2
530 0
533 0
4
0 0 119 120
0 3 109 110
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_7 loc_7_8 loc_7_9 right box6
2
530 0
533 0
4
0 0 119 120
0 1 109 110
0 152 -1 0
0 153 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box1
2
531 0
578 0
4
0 0 119 133
0 4 121 140
0 165 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box2
2
531 0
578 0
4
0 0 119 133
0 2 121 140
0 165 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box3
2
531 0
578 0
4
0 0 119 133
0 5 121 140
0 165 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box5
2
531 0
578 0
4
0 0 119 133
0 3 121 140
0 165 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_7 loc_8_7 loc_9_7 down box6
2
531 0
578 0
4
0 0 119 133
0 1 121 140
0 165 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box1
2
533 0
536 0
4
0 0 120 121
0 4 110 100
0 142 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box2
2
533 0
536 0
4
0 0 120 121
0 2 110 100
0 142 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box3
2
533 0
536 0
4
0 0 120 121
0 5 110 100
0 142 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box5
2
533 0
536 0
4
0 0 120 121
0 3 110 100
0 142 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_8 loc_7_9 loc_7_10 right box6
2
533 0
536 0
4
0 0 120 121
0 1 110 100
0 142 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box1
2
501 0
535 0
4
0 0 121 109
0 4 99 91
0 132 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box2
2
501 0
535 0
4
0 0 121 109
0 2 99 91
0 132 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box3
2
501 0
535 0
4
0 0 121 109
0 5 99 91
0 132 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box5
2
501 0
535 0
4
0 0 121 109
0 3 99 91
0 132 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_6_9 loc_5_9 up box6
2
501 0
535 0
4
0 0 121 109
0 1 99 91
0 132 0 1
0 141 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box1
2
503 0
536 0
4
0 0 121 110
0 4 100 101
0 142 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box2
2
503 0
536 0
4
0 0 121 110
0 2 100 101
0 142 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box3
2
503 0
536 0
4
0 0 121 110
0 5 100 101
0 142 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box5
2
503 0
536 0
4
0 0 121 110
0 3 100 101
0 142 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_10 loc_7_11 right box6
2
503 0
536 0
4
0 0 121 110
0 1 100 101
0 142 -1 0
0 143 0 1
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box1
2
532 0
537 0
4
0 0 121 120
0 4 109 108
0 151 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box2
2
532 0
537 0
4
0 0 121 120
0 2 109 108
0 151 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box3
2
532 0
537 0
4
0 0 121 120
0 5 109 108
0 151 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box5
2
532 0
537 0
4
0 0 121 120
0 3 109 108
0 151 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_7_8 loc_7_7 left box6
2
532 0
537 0
4
0 0 121 120
0 1 109 108
0 151 0 1
0 152 -1 0
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box1
2
538 0
585 0
4
0 0 121 135
0 4 123 141
0 167 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box2
2
538 0
585 0
4
0 0 121 135
0 2 123 141
0 167 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box3
2
538 0
585 0
4
0 0 121 135
0 5 123 141
0 167 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box5
2
538 0
585 0
4
0 0 121 135
0 3 123 141
0 167 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_7_9 loc_8_9 loc_9_9 down box6
2
538 0
585 0
4
0 0 121 135
0 1 123 141
0 167 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box1
2
540 0
545 0
4
0 0 122 123
0 4 112 113
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box2
2
540 0
545 0
4
0 0 122 123
0 2 112 113
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box3
2
540 0
545 0
4
0 0 122 123
0 5 112 113
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box5
2
540 0
545 0
4
0 0 122 123
0 3 112 113
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_11 loc_8_12 right box6
2
540 0
545 0
4
0 0 122 123
0 1 112 113
0 155 -1 0
0 156 0 1
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box1
2
541 0
584 0
4
0 0 122 135
0 4 123 122
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box2
2
541 0
584 0
4
0 0 122 135
0 2 123 122
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box3
2
541 0
584 0
4
0 0 122 135
0 5 123 122
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box5
2
541 0
584 0
4
0 0 122 135
0 3 123 122
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_10 loc_8_9 loc_8_8 left box6
2
541 0
584 0
4
0 0 122 135
0 1 123 122
0 166 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box1
2
506 0
543 0
4
0 0 123 111
0 4 101 92
0 133 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box2
2
506 0
543 0
4
0 0 123 111
0 2 101 92
0 133 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box3
2
506 0
543 0
4
0 0 123 111
0 5 101 92
0 133 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box5
2
506 0
543 0
4
0 0 123 111
0 3 101 92
0 133 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_7_11 loc_6_11 up box6
2
506 0
543 0
4
0 0 123 111
0 1 101 92
0 133 0 1
0 143 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box1
2
541 0
544 0
4
0 0 123 122
0 4 111 123
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box2
2
541 0
544 0
4
0 0 123 122
0 2 111 123
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box3
2
541 0
544 0
4
0 0 123 122
0 5 111 123
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box5
2
541 0
544 0
4
0 0 123 122
0 3 111 123
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_10 loc_8_9 left box6
2
541 0
544 0
4
0 0 123 122
0 1 111 123
0 154 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box1
2
545 0
549 0
4
0 0 123 124
0 4 113 114
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box2
2
545 0
549 0
4
0 0 123 124
0 2 113 114
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box3
2
545 0
549 0
4
0 0 123 124
0 5 113 114
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box5
2
545 0
549 0
4
0 0 123 124
0 3 113 114
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_8_11 loc_8_12 loc_8_13 right box6
2
545 0
549 0
4
0 0 123 124
0 1 113 114
0 156 -1 0
0 157 0 1
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box1
2
546 0
589 0
4
0 0 123 137
0 4 125 0
0 7 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box2
2
546 0
589 0
4
0 0 123 137
0 2 125 0
0 7 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box3
2
546 0
589 0
4
0 0 123 137
0 5 125 0
0 7 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box5
2
546 0
589 0
4
0 0 123 137
0 3 125 0
0 7 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_8_11 loc_9_11 loc_10_11 down box6
2
546 0
589 0
4
0 0 123 137
0 1 125 0
0 7 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box1
2
544 0
548 0
4
0 0 124 123
0 4 112 111
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box2
2
544 0
548 0
4
0 0 124 123
0 2 112 111
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box3
2
544 0
548 0
4
0 0 124 123
0 5 112 111
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box5
2
544 0
548 0
4
0 0 124 123
0 3 112 111
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_8_11 loc_8_10 left box6
2
544 0
548 0
4
0 0 124 123
0 1 112 111
0 154 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box1
2
550 0
593 0
4
0 0 124 138
0 4 126 1
0 8 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box2
2
550 0
593 0
4
0 0 124 138
0 2 126 1
0 8 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box3
2
550 0
593 0
4
0 0 124 138
0 5 126 1
0 8 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box5
2
550 0
593 0
4
0 0 124 138
0 3 126 1
0 8 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_8_12 loc_9_12 loc_10_12 down box6
2
550 0
593 0
4
0 0 124 138
0 1 126 1
0 8 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box1
2
548 0
551 0
4
0 0 125 124
0 4 113 112
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box2
2
548 0
551 0
4
0 0 125 124
0 2 113 112
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box3
2
548 0
551 0
4
0 0 125 124
0 5 113 112
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box5
2
548 0
551 0
4
0 0 125 124
0 3 113 112
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_8_12 loc_8_11 left box6
2
548 0
551 0
4
0 0 125 124
0 1 113 112
0 155 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box1
2
552 0
597 0
4
0 0 125 139
0 4 127 2
0 9 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box2
2
552 0
597 0
4
0 0 125 139
0 2 127 2
0 9 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box3
2
552 0
597 0
4
0 0 125 139
0 5 127 2
0 9 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box5
2
552 0
597 0
4
0 0 125 139
0 3 127 2
0 9 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_13 loc_9_13 loc_10_13 down box6
2
552 0
597 0
4
0 0 125 139
0 1 127 2
0 9 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_7_17 loc_6_17 up box1
2
512 0
553 0
4
0 0 126 113
0 4 103 93
0 134 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_7_17 loc_6_17 up box2
2
512 0
553 0
4
0 0 126 113
0 2 103 93
0 134 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_7_17 loc_6_17 up box3
2
512 0
553 0
4
0 0 126 113
0 5 103 93
0 134 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_7_17 loc_6_17 up box5
2
512 0
553 0
4
0 0 126 113
0 3 103 93
0 134 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_7_17 loc_6_17 up box6
2
512 0
553 0
4
0 0 126 113
0 1 103 93
0 134 0 1
0 145 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_8_18 loc_8_19 right box1
2
554 0
558 0
4
0 0 126 127
0 4 116 117
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_8_17 loc_8_18 loc_8_19 right box2
2
554 0
558 0
4
0 0 126 127
0 2 116 117
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_8_17 loc_8_18 loc_8_19 right box3
2
554 0
558 0
4
0 0 126 127
0 5 116 117
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_8_17 loc_8_18 loc_8_19 right box5
2
554 0
558 0
4
0 0 126 127
0 3 116 117
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_8_17 loc_8_18 loc_8_19 right box6
2
554 0
558 0
4
0 0 126 127
0 1 116 117
0 159 -1 0
0 160 0 1
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box1
2
555 0
610 0
4
0 0 126 143
0 4 131 6
0 13 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box2
2
555 0
610 0
4
0 0 126 143
0 2 131 6
0 13 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box3
2
555 0
610 0
4
0 0 126 143
0 5 131 6
0 13 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box5
2
555 0
610 0
4
0 0 126 143
0 3 131 6
0 13 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_8_17 loc_9_17 loc_10_17 down box6
2
555 0
610 0
4
0 0 126 143
0 1 131 6
0 13 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box1
2
515 0
556 0
4
0 0 127 114
0 4 104 94
0 135 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box2
2
515 0
556 0
4
0 0 127 114
0 2 104 94
0 135 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box3
2
515 0
556 0
4
0 0 127 114
0 5 104 94
0 135 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box5
2
515 0
556 0
4
0 0 127 114
0 3 104 94
0 135 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_7_18 loc_6_18 up box6
2
515 0
556 0
4
0 0 127 114
0 1 104 94
0 135 0 1
0 146 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_9_18 loc_10_18 down box1
2
559 0
614 0
4
0 0 127 144
0 4 132 7
0 14 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_9_18 loc_10_18 down box2
2
559 0
614 0
4
0 0 127 144
0 2 132 7
0 14 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_9_18 loc_10_18 down box3
2
559 0
614 0
4
0 0 127 144
0 5 132 7
0 14 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_9_18 loc_10_18 down box5
2
559 0
614 0
4
0 0 127 144
0 3 132 7
0 14 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_8_18 loc_9_18 loc_10_18 down box6
2
559 0
614 0
4
0 0 127 144
0 1 132 7
0 14 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box1
2
519 0
560 0
4
0 0 128 115
0 4 105 95
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box2
2
519 0
560 0
4
0 0 128 115
0 2 105 95
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box3
2
519 0
560 0
4
0 0 128 115
0 5 105 95
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box4
2
519 0
560 0
4
0 0 128 115
0 6 12 11
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box5
2
519 0
560 0
4
0 0 128 115
0 3 105 95
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_7_19 loc_6_19 up box6
2
519 0
560 0
4
0 0 128 115
0 1 105 95
0 136 0 1
0 147 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_8_18 loc_8_17 left box1
2
557 0
561 0
4
0 0 128 127
0 4 116 115
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_8_18 loc_8_17 left box2
2
557 0
561 0
4
0 0 128 127
0 2 116 115
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_8_18 loc_8_17 left box3
2
557 0
561 0
4
0 0 128 127
0 5 116 115
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_8_18 loc_8_17 left box5
2
557 0
561 0
4
0 0 128 127
0 3 116 115
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_8_18 loc_8_17 left box6
2
557 0
561 0
4
0 0 128 127
0 1 116 115
0 158 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box1
2
562 0
618 0
4
0 0 128 145
0 4 133 8
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box2
2
562 0
618 0
4
0 0 128 145
0 2 133 8
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box3
2
562 0
618 0
4
0 0 128 145
0 5 133 8
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box4
2
562 0
618 0
4
0 0 128 145
0 6 14 0
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box5
2
562 0
618 0
4
0 0 128 145
0 3 133 8
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_19 loc_9_19 loc_10_19 down box6
2
562 0
618 0
4
0 0 128 145
0 1 133 8
0 15 0 1
0 177 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box1
2
566 0
570 0
4
0 0 130 131
0 4 119 120
0 163 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box2
2
566 0
570 0
4
0 0 130 131
0 2 119 120
0 163 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box3
2
566 0
570 0
4
0 0 130 131
0 5 119 120
0 163 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box5
2
566 0
570 0
4
0 0 130 131
0 3 119 120
0 163 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_8_4 loc_8_5 loc_8_6 right box6
2
566 0
570 0
4
0 0 130 131
0 1 119 120
0 163 -1 0
0 164 0 1
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box1
2
567 0
627 0
4
0 0 130 149
0 4 137 9
0 16 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box2
2
567 0
627 0
4
0 0 130 149
0 2 137 9
0 16 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box3
2
567 0
627 0
4
0 0 130 149
0 5 137 9
0 16 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box5
2
567 0
627 0
4
0 0 130 149
0 3 137 9
0 16 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_8_4 loc_9_4 loc_10_4 down box6
2
567 0
627 0
4
0 0 130 149
0 1 137 9
0 16 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box1
2
526 0
568 0
4
0 0 131 118
0 4 107 96
0 138 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box2
2
526 0
568 0
4
0 0 131 118
0 2 107 96
0 138 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box3
2
526 0
568 0
4
0 0 131 118
0 5 107 96
0 138 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box5
2
526 0
568 0
4
0 0 131 118
0 3 107 96
0 138 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_7_5 loc_6_5 up box6
2
526 0
568 0
4
0 0 131 118
0 1 107 96
0 138 0 1
0 150 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box1
2
570 0
573 0
4
0 0 131 132
0 4 120 121
0 164 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box2
2
570 0
573 0
4
0 0 131 132
0 2 120 121
0 164 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box3
2
570 0
573 0
4
0 0 131 132
0 5 120 121
0 164 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box5
2
570 0
573 0
4
0 0 131 132
0 3 120 121
0 164 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_8_5 loc_8_6 loc_8_7 right box6
2
570 0
573 0
4
0 0 131 132
0 1 120 121
0 164 -1 0
0 165 0 1
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box1
2
571 0
631 0
4
0 0 131 150
0 4 138 10
0 17 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box2
2
571 0
631 0
4
0 0 131 150
0 2 138 10
0 17 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box3
2
571 0
631 0
4
0 0 131 150
0 5 138 10
0 17 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box5
2
571 0
631 0
4
0 0 131 150
0 3 138 10
0 17 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_8_5 loc_9_5 loc_10_5 down box6
2
571 0
631 0
4
0 0 131 150
0 1 138 10
0 17 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box1
2
569 0
572 0
4
0 0 132 131
0 4 119 118
0 162 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box2
2
569 0
572 0
4
0 0 132 131
0 2 119 118
0 162 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box3
2
569 0
572 0
4
0 0 132 131
0 5 119 118
0 162 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box5
2
569 0
572 0
4
0 0 132 131
0 3 119 118
0 162 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_5 loc_8_4 left box6
2
569 0
572 0
4
0 0 132 131
0 1 119 118
0 162 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box1
2
573 0
577 0
4
0 0 132 133
0 4 121 122
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box2
2
573 0
577 0
4
0 0 132 133
0 2 121 122
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box3
2
573 0
577 0
4
0 0 132 133
0 5 121 122
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box5
2
573 0
577 0
4
0 0 132 133
0 3 121 122
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_8_6 loc_8_7 loc_8_8 right box6
2
573 0
577 0
4
0 0 132 133
0 1 121 122
0 165 -1 0
0 166 0 1
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box1
2
574 0
635 0
4
0 0 132 151
0 4 139 11
0 18 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box2
2
574 0
635 0
4
0 0 132 151
0 2 139 11
0 18 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box3
2
574 0
635 0
4
0 0 132 151
0 5 139 11
0 18 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box5
2
574 0
635 0
4
0 0 132 151
0 3 139 11
0 18 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_8_6 loc_9_6 loc_10_6 down box6
2
574 0
635 0
4
0 0 132 151
0 1 139 11
0 18 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box1
2
529 0
575 0
4
0 0 133 119
0 4 108 98
0 140 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box2
2
529 0
575 0
4
0 0 133 119
0 2 108 98
0 140 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box3
2
529 0
575 0
4
0 0 133 119
0 5 108 98
0 140 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box5
2
529 0
575 0
4
0 0 133 119
0 3 108 98
0 140 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_7_7 loc_6_7 up box6
2
529 0
575 0
4
0 0 133 119
0 1 108 98
0 140 0 1
0 151 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box1
2
572 0
576 0
4
0 0 133 132
0 4 120 119
0 163 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box2
2
572 0
576 0
4
0 0 133 132
0 2 120 119
0 163 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box3
2
572 0
576 0
4
0 0 133 132
0 5 120 119
0 163 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box5
2
572 0
576 0
4
0 0 133 132
0 3 120 119
0 163 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_6 loc_8_5 left box6
2
572 0
576 0
4
0 0 133 132
0 1 120 119
0 163 0 1
0 164 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box1
2
577 0
581 0
4
0 0 133 134
0 4 122 123
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box2
2
577 0
581 0
4
0 0 133 134
0 2 122 123
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box3
2
577 0
581 0
4
0 0 133 134
0 5 122 123
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box5
2
577 0
581 0
4
0 0 133 134
0 3 122 123
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_7 loc_8_8 loc_8_9 right box6
2
577 0
581 0
4
0 0 133 134
0 1 122 123
0 166 -1 0
0 167 0 1
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box1
2
578 0
639 0
4
0 0 133 152
0 4 140 12
0 19 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box2
2
578 0
639 0
4
0 0 133 152
0 2 140 12
0 19 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box3
2
578 0
639 0
4
0 0 133 152
0 5 140 12
0 19 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box5
2
578 0
639 0
4
0 0 133 152
0 3 140 12
0 19 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_8_7 loc_9_7 loc_10_7 down box6
2
578 0
639 0
4
0 0 133 152
0 1 140 12
0 19 0 1
0 184 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box1
2
576 0
580 0
4
0 0 134 133
0 4 121 120
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box2
2
576 0
580 0
4
0 0 134 133
0 2 121 120
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box3
2
576 0
580 0
4
0 0 134 133
0 5 121 120
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box5
2
576 0
580 0
4
0 0 134 133
0 3 121 120
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_7 loc_8_6 left box6
2
576 0
580 0
4
0 0 134 133
0 1 121 120
0 164 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box1
2
581 0
583 0
4
0 0 134 135
0 4 123 111
0 154 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box2
2
581 0
583 0
4
0 0 134 135
0 2 123 111
0 154 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box3
2
581 0
583 0
4
0 0 134 135
0 5 123 111
0 154 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box5
2
581 0
583 0
4
0 0 134 135
0 3 123 111
0 154 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_8 loc_8_9 loc_8_10 right box6
2
581 0
583 0
4
0 0 134 135
0 1 123 111
0 154 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box1
2
535 0
582 0
4
0 0 135 121
0 4 110 99
0 141 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box2
2
535 0
582 0
4
0 0 135 121
0 2 110 99
0 141 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box3
2
535 0
582 0
4
0 0 135 121
0 5 110 99
0 141 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box5
2
535 0
582 0
4
0 0 135 121
0 3 110 99
0 141 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_7_9 loc_6_9 up box6
2
535 0
582 0
4
0 0 135 121
0 1 110 99
0 141 0 1
0 153 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box1
2
540 0
583 0
4
0 0 135 122
0 4 111 112
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box2
2
540 0
583 0
4
0 0 135 122
0 2 111 112
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box3
2
540 0
583 0
4
0 0 135 122
0 5 111 112
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box5
2
540 0
583 0
4
0 0 135 122
0 3 111 112
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_10 loc_8_11 right box6
2
540 0
583 0
4
0 0 135 122
0 1 111 112
0 154 -1 0
0 155 0 1
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box1
2
580 0
584 0
4
0 0 135 134
0 4 122 121
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box2
2
580 0
584 0
4
0 0 135 134
0 2 122 121
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box3
2
580 0
584 0
4
0 0 135 134
0 5 122 121
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box5
2
580 0
584 0
4
0 0 135 134
0 3 122 121
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_8_9 loc_8_8 loc_8_7 left box6
2
580 0
584 0
4
0 0 135 134
0 1 122 121
0 165 0 1
0 166 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box1
2
539 0
586 0
4
0 0 136 122
0 4 111 100
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box2
2
539 0
586 0
4
0 0 136 122
0 2 111 100
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box3
2
539 0
586 0
4
0 0 136 122
0 5 111 100
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box5
2
539 0
586 0
4
0 0 136 122
0 3 111 100
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_8_10 loc_7_10 up box6
2
539 0
586 0
4
0 0 136 122
0 1 111 100
0 142 0 1
0 154 -1 0
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box1
2
587 0
592 0
4
0 0 136 137
0 4 125 126
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box2
2
587 0
592 0
4
0 0 136 137
0 2 125 126
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box3
2
587 0
592 0
4
0 0 136 137
0 5 125 126
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box5
2
587 0
592 0
4
0 0 136 137
0 3 125 126
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_9_10 loc_9_11 loc_9_12 right box6
2
587 0
592 0
4
0 0 136 137
0 1 125 126
0 169 -1 0
0 170 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box1
2
187 0
589 0
4
0 0 137 0
0 4 0 13
0 7 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box2
2
187 0
589 0
4
0 0 137 0
0 2 0 13
0 7 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box3
2
187 0
589 0
4
0 0 137 0
0 5 0 13
0 7 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box5
2
187 0
589 0
4
0 0 137 0
0 3 0 13
0 7 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_11 loc_10_11 loc_11_11 down box6
2
187 0
589 0
4
0 0 137 0
0 1 0 13
0 7 -1 0
0 20 0 1
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box1
2
543 0
590 0
4
0 0 137 123
0 4 112 101
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box2
2
543 0
590 0
4
0 0 137 123
0 2 112 101
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box3
2
543 0
590 0
4
0 0 137 123
0 5 112 101
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box5
2
543 0
590 0
4
0 0 137 123
0 3 112 101
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_8_11 loc_7_11 up box6
2
543 0
590 0
4
0 0 137 123
0 1 112 101
0 143 0 1
0 155 -1 0
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box1
2
588 0
591 0
4
0 0 137 136
0 4 124 141
0 168 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box2
2
588 0
591 0
4
0 0 137 136
0 2 124 141
0 168 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box3
2
588 0
591 0
4
0 0 137 136
0 5 124 141
0 168 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box5
2
588 0
591 0
4
0 0 137 136
0 3 124 141
0 168 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_10 loc_9_9 left box6
2
588 0
591 0
4
0 0 137 136
0 1 124 141
0 168 -1 0
0 185 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_12 loc_9_13 right box1
2
592 0
596 0
4
0 0 137 138
0 4 126 127
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_12 loc_9_13 right box2
2
592 0
596 0
4
0 0 137 138
0 2 126 127
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_12 loc_9_13 right box3
2
592 0
596 0
4
0 0 137 138
0 5 126 127
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_12 loc_9_13 right box5
2
592 0
596 0
4
0 0 137 138
0 3 126 127
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_9_11 loc_9_12 loc_9_13 right box6
2
592 0
596 0
4
0 0 137 138
0 1 126 127
0 170 -1 0
0 171 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box1
2
191 0
593 0
4
0 0 138 1
0 4 1 14
0 8 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box2
2
191 0
593 0
4
0 0 138 1
0 2 1 14
0 8 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box3
2
191 0
593 0
4
0 0 138 1
0 5 1 14
0 8 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box5
2
191 0
593 0
4
0 0 138 1
0 3 1 14
0 8 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_12 loc_10_12 loc_11_12 down box6
2
191 0
593 0
4
0 0 138 1
0 1 1 14
0 8 -1 0
0 21 0 1
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box1
2
547 0
594 0
4
0 0 138 124
0 4 113 102
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box2
2
547 0
594 0
4
0 0 138 124
0 2 113 102
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box3
2
547 0
594 0
4
0 0 138 124
0 5 113 102
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box5
2
547 0
594 0
4
0 0 138 124
0 3 113 102
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_8_12 loc_7_12 up box6
2
547 0
594 0
4
0 0 138 124
0 1 113 102
0 144 0 1
0 156 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box1
2
591 0
595 0
4
0 0 138 137
0 4 125 124
0 168 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box2
2
591 0
595 0
4
0 0 138 137
0 2 125 124
0 168 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box3
2
591 0
595 0
4
0 0 138 137
0 5 125 124
0 168 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box5
2
591 0
595 0
4
0 0 138 137
0 3 125 124
0 168 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_11 loc_9_10 left box6
2
591 0
595 0
4
0 0 138 137
0 1 125 124
0 168 0 1
0 169 -1 0
1
end_operator
begin_operator
push loc_9_12 loc_9_13 loc_9_14 right box1
2
596 0
600 0
4
0 0 138 139
0 4 127 128
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_9_12 loc_9_13 loc_9_14 right box2
2
596 0
600 0
4
0 0 138 139
0 2 127 128
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_9_12 loc_9_13 loc_9_14 right box3
2
596 0
600 0
4
0 0 138 139
0 5 127 128
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_9_12 loc_9_13 loc_9_14 right box5
2
596 0
600 0
4
0 0 138 139
0 3 127 128
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_9_12 loc_9_13 loc_9_14 right box6
2
596 0
600 0
4
0 0 138 139
0 1 127 128
0 171 -1 0
0 172 0 1
1
end_operator
begin_operator
push loc_9_13 loc_9_12 loc_9_11 left box1
2
595 0
599 0
4
0 0 139 138
0 4 126 125
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_13 loc_9_12 loc_9_11 left box2
2
595 0
599 0
4
0 0 139 138
0 2 126 125
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_13 loc_9_12 loc_9_11 left box3
2
595 0
599 0
4
0 0 139 138
0 5 126 125
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_13 loc_9_12 loc_9_11 left box5
2
595 0
599 0
4
0 0 139 138
0 3 126 125
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_13 loc_9_12 loc_9_11 left box6
2
595 0
599 0
4
0 0 139 138
0 1 126 125
0 169 0 1
0 170 -1 0
1
end_operator
begin_operator
push loc_9_13 loc_9_14 loc_9_15 right box1
2
600 0
603 0
4
0 0 139 140
0 4 128 129
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_9_13 loc_9_14 loc_9_15 right box2
2
600 0
603 0
4
0 0 139 140
0 2 128 129
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_9_13 loc_9_14 loc_9_15 right box3
2
600 0
603 0
4
0 0 139 140
0 5 128 129
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_9_13 loc_9_14 loc_9_15 right box5
2
600 0
603 0
4
0 0 139 140
0 3 128 129
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_9_13 loc_9_14 loc_9_15 right box6
2
600 0
603 0
4
0 0 139 140
0 1 128 129
0 172 -1 0
0 173 0 1
1
end_operator
begin_operator
push loc_9_14 loc_9_13 loc_9_12 left box1
2
599 0
602 0
4
0 0 140 139
0 4 127 126
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_14 loc_9_13 loc_9_12 left box2
2
599 0
602 0
4
0 0 140 139
0 2 127 126
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_14 loc_9_13 loc_9_12 left box3
2
599 0
602 0
4
0 0 140 139
0 5 127 126
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_14 loc_9_13 loc_9_12 left box5
2
599 0
602 0
4
0 0 140 139
0 3 127 126
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_14 loc_9_13 loc_9_12 left box6
2
599 0
602 0
4
0 0 140 139
0 1 127 126
0 170 0 1
0 171 -1 0
1
end_operator
begin_operator
push loc_9_14 loc_9_15 loc_9_16 right box1
2
603 0
606 0
4
0 0 140 141
0 4 129 130
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_14 loc_9_15 loc_9_16 right box2
2
603 0
606 0
4
0 0 140 141
0 2 129 130
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_14 loc_9_15 loc_9_16 right box3
2
603 0
606 0
4
0 0 140 141
0 5 129 130
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_14 loc_9_15 loc_9_16 right box5
2
603 0
606 0
4
0 0 140 141
0 3 129 130
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_14 loc_9_15 loc_9_16 right box6
2
603 0
606 0
4
0 0 140 141
0 1 129 130
0 173 -1 0
0 174 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_14 loc_9_13 left box1
2
602 0
605 0
4
0 0 141 140
0 4 128 127
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_14 loc_9_13 left box2
2
602 0
605 0
4
0 0 141 140
0 2 128 127
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_14 loc_9_13 left box3
2
602 0
605 0
4
0 0 141 140
0 5 128 127
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_14 loc_9_13 left box5
2
602 0
605 0
4
0 0 141 140
0 3 128 127
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_14 loc_9_13 left box6
2
602 0
605 0
4
0 0 141 140
0 1 128 127
0 171 0 1
0 172 -1 0
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box1
2
606 0
609 0
4
0 0 141 142
0 4 130 131
0 174 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box2
2
606 0
609 0
4
0 0 141 142
0 2 130 131
0 174 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box3
2
606 0
609 0
4
0 0 141 142
0 5 130 131
0 174 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box5
2
606 0
609 0
4
0 0 141 142
0 3 130 131
0 174 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_9_15 loc_9_16 loc_9_17 right box6
2
606 0
609 0
4
0 0 141 142
0 1 130 131
0 174 -1 0
0 175 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_15 loc_9_14 left box1
2
605 0
608 0
4
0 0 142 141
0 4 129 128
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_9_16 loc_9_15 loc_9_14 left box2
2
605 0
608 0
4
0 0 142 141
0 2 129 128
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_9_16 loc_9_15 loc_9_14 left box3
2
605 0
608 0
4
0 0 142 141
0 5 129 128
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_9_16 loc_9_15 loc_9_14 left box5
2
605 0
608 0
4
0 0 142 141
0 3 129 128
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_9_16 loc_9_15 loc_9_14 left box6
2
605 0
608 0
4
0 0 142 141
0 1 129 128
0 172 0 1
0 173 -1 0
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box1
2
609 0
613 0
4
0 0 142 143
0 4 131 132
0 175 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box2
2
609 0
613 0
4
0 0 142 143
0 2 131 132
0 175 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box3
2
609 0
613 0
4
0 0 142 143
0 5 131 132
0 175 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box5
2
609 0
613 0
4
0 0 142 143
0 3 131 132
0 175 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_9_16 loc_9_17 loc_9_18 right box6
2
609 0
613 0
4
0 0 142 143
0 1 131 132
0 175 -1 0
0 176 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box1
2
207 0
610 0
4
0 0 143 6
0 4 6 15
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box2
2
207 0
610 0
4
0 0 143 6
0 2 6 15
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box3
2
207 0
610 0
4
0 0 143 6
0 5 6 15
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box5
2
207 0
610 0
4
0 0 143 6
0 3 6 15
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_17 loc_10_17 loc_11_17 down box6
2
207 0
610 0
4
0 0 143 6
0 1 6 15
0 13 -1 0
0 22 0 1
1
end_operator
begin_operator
push loc_9_17 loc_8_17 loc_7_17 up box1
2
553 0
611 0
4
0 0 143 126
0 4 115 103
0 145 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_8_17 loc_7_17 up box2
2
553 0
611 0
4
0 0 143 126
0 2 115 103
0 145 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_8_17 loc_7_17 up box3
2
553 0
611 0
4
0 0 143 126
0 5 115 103
0 145 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_8_17 loc_7_17 up box5
2
553 0
611 0
4
0 0 143 126
0 3 115 103
0 145 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_8_17 loc_7_17 up box6
2
553 0
611 0
4
0 0 143 126
0 1 115 103
0 145 0 1
0 158 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box1
2
608 0
612 0
4
0 0 143 142
0 4 130 129
0 173 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box2
2
608 0
612 0
4
0 0 143 142
0 2 130 129
0 173 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box3
2
608 0
612 0
4
0 0 143 142
0 5 130 129
0 173 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box5
2
608 0
612 0
4
0 0 143 142
0 3 130 129
0 173 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_16 loc_9_15 left box6
2
608 0
612 0
4
0 0 143 142
0 1 130 129
0 173 0 1
0 174 -1 0
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box1
2
613 0
617 0
4
0 0 143 144
0 4 132 133
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box2
2
613 0
617 0
4
0 0 143 144
0 2 132 133
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box3
2
613 0
617 0
4
0 0 143 144
0 5 132 133
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box5
2
613 0
617 0
4
0 0 143 144
0 3 132 133
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_9_17 loc_9_18 loc_9_19 right box6
2
613 0
617 0
4
0 0 143 144
0 1 132 133
0 176 -1 0
0 177 0 1
1
end_operator
begin_operator
push loc_9_18 loc_10_18 loc_11_18 down box1
2
211 0
614 0
4
0 0 144 7
0 4 7 16
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_9_18 loc_10_18 loc_11_18 down box2
2
211 0
614 0
4
0 0 144 7
0 2 7 16
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_9_18 loc_10_18 loc_11_18 down box3
2
211 0
614 0
4
0 0 144 7
0 5 7 16
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_9_18 loc_10_18 loc_11_18 down box5
2
211 0
614 0
4
0 0 144 7
0 3 7 16
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_9_18 loc_10_18 loc_11_18 down box6
2
211 0
614 0
4
0 0 144 7
0 1 7 16
0 14 -1 0
0 23 0 1
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box1
2
556 0
615 0
4
0 0 144 127
0 4 116 104
0 146 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box2
2
556 0
615 0
4
0 0 144 127
0 2 116 104
0 146 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box3
2
556 0
615 0
4
0 0 144 127
0 5 116 104
0 146 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box5
2
556 0
615 0
4
0 0 144 127
0 3 116 104
0 146 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_8_18 loc_7_18 up box6
2
556 0
615 0
4
0 0 144 127
0 1 116 104
0 146 0 1
0 159 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box1
2
612 0
616 0
4
0 0 144 143
0 4 131 130
0 174 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box2
2
612 0
616 0
4
0 0 144 143
0 2 131 130
0 174 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box3
2
612 0
616 0
4
0 0 144 143
0 5 131 130
0 174 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box5
2
612 0
616 0
4
0 0 144 143
0 3 131 130
0 174 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_17 loc_9_16 left box6
2
612 0
616 0
4
0 0 144 143
0 1 131 130
0 174 0 1
0 175 -1 0
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box1
2
617 0
621 0
4
0 0 144 145
0 4 133 135
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box2
2
617 0
621 0
4
0 0 144 145
0 2 133 135
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box3
2
617 0
621 0
4
0 0 144 145
0 5 133 135
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box4
2
617 0
621 0
4
0 0 144 145
0 6 14 15
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box5
2
617 0
621 0
4
0 0 144 145
0 3 133 135
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_18 loc_9_19 loc_9_20 right box6
2
617 0
621 0
4
0 0 144 145
0 1 133 135
0 177 -1 0
0 179 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box1
2
214 0
618 0
4
0 0 145 8
0 4 8 17
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box2
2
214 0
618 0
4
0 0 145 8
0 2 8 17
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box3
2
214 0
618 0
4
0 0 145 8
0 5 8 17
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box4
2
214 0
618 0
4
0 0 145 8
0 6 0 1
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box5
2
214 0
618 0
4
0 0 145 8
0 3 8 17
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_10_19 loc_11_19 down box6
2
214 0
618 0
4
0 0 145 8
0 1 8 17
0 15 -1 0
0 24 0 1
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box1
2
560 0
619 0
4
0 0 145 128
0 4 117 105
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box2
2
560 0
619 0
4
0 0 145 128
0 2 117 105
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box3
2
560 0
619 0
4
0 0 145 128
0 5 117 105
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box4
2
560 0
619 0
4
0 0 145 128
0 6 13 12
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box5
2
560 0
619 0
4
0 0 145 128
0 3 117 105
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_8_19 loc_7_19 up box6
2
560 0
619 0
4
0 0 145 128
0 1 117 105
0 147 0 1
0 160 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box1
2
616 0
620 0
4
0 0 145 144
0 4 132 131
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box2
2
616 0
620 0
4
0 0 145 144
0 2 132 131
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box3
2
616 0
620 0
4
0 0 145 144
0 5 132 131
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box5
2
616 0
620 0
4
0 0 145 144
0 3 132 131
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_9_19 loc_9_18 loc_9_17 left box6
2
616 0
620 0
4
0 0 145 144
0 1 132 131
0 175 0 1
0 176 -1 0
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box1
2
623 0
626 0
4
0 0 146 148
0 4 136 137
0 180 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box2
2
623 0
626 0
4
0 0 146 148
0 2 136 137
0 180 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box3
2
623 0
626 0
4
0 0 146 148
0 5 136 137
0 180 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box5
2
623 0
626 0
4
0 0 146 148
0 3 136 137
0 180 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_9_2 loc_9_3 loc_9_4 right box6
2
623 0
626 0
4
0 0 146 148
0 1 136 137
0 180 -1 0
0 181 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box1
2
626 0
630 0
4
0 0 148 149
0 4 137 138
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box2
2
626 0
630 0
4
0 0 148 149
0 2 137 138
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box3
2
626 0
630 0
4
0 0 148 149
0 5 137 138
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box5
2
626 0
630 0
4
0 0 148 149
0 3 137 138
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_3 loc_9_4 loc_9_5 right box6
2
626 0
630 0
4
0 0 148 149
0 1 137 138
0 181 -1 0
0 182 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box1
2
217 0
627 0
4
0 0 149 9
0 4 9 21
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box2
2
217 0
627 0
4
0 0 149 9
0 2 9 21
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box3
2
217 0
627 0
4
0 0 149 9
0 5 9 21
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box5
2
217 0
627 0
4
0 0 149 9
0 3 9 21
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_4 loc_10_4 loc_11_4 down box6
2
217 0
627 0
4
0 0 149 9
0 1 9 21
0 16 -1 0
0 28 0 1
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box1
2
565 0
628 0
4
0 0 149 130
0 4 118 106
0 149 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box2
2
565 0
628 0
4
0 0 149 130
0 2 118 106
0 149 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box3
2
565 0
628 0
4
0 0 149 130
0 5 118 106
0 149 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box5
2
565 0
628 0
4
0 0 149 130
0 3 118 106
0 149 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_8_4 loc_7_4 up box6
2
565 0
628 0
4
0 0 149 130
0 1 118 106
0 149 0 1
0 162 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box1
2
625 0
629 0
4
0 0 149 148
0 4 136 134
0 178 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box2
2
625 0
629 0
4
0 0 149 148
0 2 136 134
0 178 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box3
2
625 0
629 0
4
0 0 149 148
0 5 136 134
0 178 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box5
2
625 0
629 0
4
0 0 149 148
0 3 136 134
0 178 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_3 loc_9_2 left box6
2
625 0
629 0
4
0 0 149 148
0 1 136 134
0 178 0 1
0 180 -1 0
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box1
2
630 0
634 0
4
0 0 149 150
0 4 138 139
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box2
2
630 0
634 0
4
0 0 149 150
0 2 138 139
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box3
2
630 0
634 0
4
0 0 149 150
0 5 138 139
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box5
2
630 0
634 0
4
0 0 149 150
0 3 138 139
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_4 loc_9_5 loc_9_6 right box6
2
630 0
634 0
4
0 0 149 150
0 1 138 139
0 182 -1 0
0 183 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box1
2
221 0
631 0
4
0 0 150 10
0 4 10 22
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box2
2
221 0
631 0
4
0 0 150 10
0 2 10 22
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box3
2
221 0
631 0
4
0 0 150 10
0 5 10 22
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box5
2
221 0
631 0
4
0 0 150 10
0 3 10 22
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_9_5 loc_10_5 loc_11_5 down box6
2
221 0
631 0
4
0 0 150 10
0 1 10 22
0 17 -1 0
0 29 0 1
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box1
2
568 0
632 0
4
0 0 150 131
0 4 119 107
0 150 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box2
2
568 0
632 0
4
0 0 150 131
0 2 119 107
0 150 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box3
2
568 0
632 0
4
0 0 150 131
0 5 119 107
0 150 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box5
2
568 0
632 0
4
0 0 150 131
0 3 119 107
0 150 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_8_5 loc_7_5 up box6
2
568 0
632 0
4
0 0 150 131
0 1 119 107
0 150 0 1
0 163 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box1
2
629 0
633 0
4
0 0 150 149
0 4 137 136
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box2
2
629 0
633 0
4
0 0 150 149
0 2 137 136
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box3
2
629 0
633 0
4
0 0 150 149
0 5 137 136
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box5
2
629 0
633 0
4
0 0 150 149
0 3 137 136
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_4 loc_9_3 left box6
2
629 0
633 0
4
0 0 150 149
0 1 137 136
0 180 0 1
0 181 -1 0
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box1
2
634 0
638 0
4
0 0 150 151
0 4 139 140
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box2
2
634 0
638 0
4
0 0 150 151
0 2 139 140
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box3
2
634 0
638 0
4
0 0 150 151
0 5 139 140
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box5
2
634 0
638 0
4
0 0 150 151
0 3 139 140
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_5 loc_9_6 loc_9_7 right box6
2
634 0
638 0
4
0 0 150 151
0 1 139 140
0 183 -1 0
0 184 0 1
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box1
2
633 0
637 0
4
0 0 151 150
0 4 138 137
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box2
2
633 0
637 0
4
0 0 151 150
0 2 138 137
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box3
2
633 0
637 0
4
0 0 151 150
0 5 138 137
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box5
2
633 0
637 0
4
0 0 151 150
0 3 138 137
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_6 loc_9_5 loc_9_4 left box6
2
633 0
637 0
4
0 0 151 150
0 1 138 137
0 181 0 1
0 182 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box1
2
227 0
639 0
4
0 0 152 12
0 4 12 23
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box2
2
227 0
639 0
4
0 0 152 12
0 2 12 23
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box3
2
227 0
639 0
4
0 0 152 12
0 5 12 23
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box5
2
227 0
639 0
4
0 0 152 12
0 3 12 23
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_9_7 loc_10_7 loc_11_7 down box6
2
227 0
639 0
4
0 0 152 12
0 1 12 23
0 19 -1 0
0 30 0 1
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box1
2
575 0
640 0
4
0 0 152 133
0 4 121 108
0 151 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box2
2
575 0
640 0
4
0 0 152 133
0 2 121 108
0 151 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box3
2
575 0
640 0
4
0 0 152 133
0 5 121 108
0 151 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box5
2
575 0
640 0
4
0 0 152 133
0 3 121 108
0 151 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_8_7 loc_7_7 up box6
2
575 0
640 0
4
0 0 152 133
0 1 121 108
0 151 0 1
0 165 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box1
2
637 0
641 0
4
0 0 152 151
0 4 139 138
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box2
2
637 0
641 0
4
0 0 152 151
0 2 139 138
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box3
2
637 0
641 0
4
0 0 152 151
0 5 139 138
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box5
2
637 0
641 0
4
0 0 152 151
0 3 139 138
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_7 loc_9_6 loc_9_5 left box6
2
637 0
641 0
4
0 0 152 151
0 1 139 138
0 182 0 1
0 183 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box1
2
582 0
642 0
4
0 0 153 135
0 4 123 110
0 153 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box2
2
582 0
642 0
4
0 0 153 135
0 2 123 110
0 153 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box3
2
582 0
642 0
4
0 0 153 135
0 5 123 110
0 153 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box5
2
582 0
642 0
4
0 0 153 135
0 3 123 110
0 153 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_8_9 loc_7_9 up box6
2
582 0
642 0
4
0 0 153 135
0 1 123 110
0 153 0 1
0 167 -1 0
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box1
2
587 0
643 0
4
0 0 153 136
0 4 124 125
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box2
2
587 0
643 0
4
0 0 153 136
0 2 124 125
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box3
2
587 0
643 0
4
0 0 153 136
0 5 124 125
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box5
2
587 0
643 0
4
0 0 153 136
0 3 124 125
0 168 -1 0
0 169 0 1
1
end_operator
begin_operator
push loc_9_9 loc_9_10 loc_9_11 right box6
2
587 0
643 0
4
0 0 153 136
0 1 124 125
0 168 -1 0
0 169 0 1
1
end_operator
0
