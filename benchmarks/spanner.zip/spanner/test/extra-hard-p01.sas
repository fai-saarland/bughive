begin_version
3
end_version
begin_metric
1
end_metric
352
begin_variable
var0
-1
52
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location29
at bob location3
at bob location30
at bob location31
at bob location32
at bob location33
at bob location34
at bob location35
at bob location36
at bob location37
at bob location38
at bob location39
at bob location4
at bob location40
at bob location41
at bob location42
at bob location43
at bob location44
at bob location45
at bob location46
at bob location47
at bob location48
at bob location49
at bob location5
at bob location50
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var2
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var3
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var4
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var5
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var6
-1
2
at spanner1 location3
carrying bob spanner1
end_variable
begin_variable
var7
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var8
-1
2
at spanner10 location4
carrying bob spanner10
end_variable
begin_variable
var9
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var10
-1
2
at spanner100 location4
carrying bob spanner100
end_variable
begin_variable
var11
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var12
-1
2
at spanner11 location41
carrying bob spanner11
end_variable
begin_variable
var13
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var14
-1
2
at spanner12 location13
carrying bob spanner12
end_variable
begin_variable
var15
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var16
-1
2
at spanner13 location36
carrying bob spanner13
end_variable
begin_variable
var17
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var18
-1
2
at spanner14 location4
carrying bob spanner14
end_variable
begin_variable
var19
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var20
-1
2
at spanner15 location29
carrying bob spanner15
end_variable
begin_variable
var21
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var22
-1
2
at spanner16 location38
carrying bob spanner16
end_variable
begin_variable
var23
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var24
-1
2
at spanner17 location19
carrying bob spanner17
end_variable
begin_variable
var25
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var26
-1
2
at spanner18 location47
carrying bob spanner18
end_variable
begin_variable
var27
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var28
-1
2
at spanner19 location40
carrying bob spanner19
end_variable
begin_variable
var29
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var30
-1
2
at spanner2 location39
carrying bob spanner2
end_variable
begin_variable
var31
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var32
-1
2
at spanner20 location3
carrying bob spanner20
end_variable
begin_variable
var33
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var34
-1
2
at spanner21 location3
carrying bob spanner21
end_variable
begin_variable
var35
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var36
-1
2
at spanner22 location28
carrying bob spanner22
end_variable
begin_variable
var37
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var38
-1
2
at spanner23 location13
carrying bob spanner23
end_variable
begin_variable
var39
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var40
-1
2
at spanner24 location16
carrying bob spanner24
end_variable
begin_variable
var41
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var42
-1
2
at spanner25 location46
carrying bob spanner25
end_variable
begin_variable
var43
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var44
-1
2
at spanner26 location5
carrying bob spanner26
end_variable
begin_variable
var45
-1
2
loose nut31
tightened nut31
end_variable
begin_variable
var46
-1
2
at spanner27 location8
carrying bob spanner27
end_variable
begin_variable
var47
-1
2
loose nut32
tightened nut32
end_variable
begin_variable
var48
-1
2
at spanner28 location43
carrying bob spanner28
end_variable
begin_variable
var49
-1
2
loose nut33
tightened nut33
end_variable
begin_variable
var50
-1
2
at spanner29 location41
carrying bob spanner29
end_variable
begin_variable
var51
-1
2
loose nut34
tightened nut34
end_variable
begin_variable
var52
-1
2
at spanner3 location12
carrying bob spanner3
end_variable
begin_variable
var53
-1
2
loose nut35
tightened nut35
end_variable
begin_variable
var54
-1
2
at spanner30 location4
carrying bob spanner30
end_variable
begin_variable
var55
-1
2
loose nut36
tightened nut36
end_variable
begin_variable
var56
-1
2
at spanner31 location18
carrying bob spanner31
end_variable
begin_variable
var57
-1
2
loose nut37
tightened nut37
end_variable
begin_variable
var58
-1
2
at spanner32 location45
carrying bob spanner32
end_variable
begin_variable
var59
-1
2
loose nut38
tightened nut38
end_variable
begin_variable
var60
-1
2
at spanner33 location42
carrying bob spanner33
end_variable
begin_variable
var61
-1
2
loose nut39
tightened nut39
end_variable
begin_variable
var62
-1
2
at spanner34 location28
carrying bob spanner34
end_variable
begin_variable
var63
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var64
-1
2
at spanner35 location19
carrying bob spanner35
end_variable
begin_variable
var65
-1
2
loose nut40
tightened nut40
end_variable
begin_variable
var66
-1
2
at spanner36 location19
carrying bob spanner36
end_variable
begin_variable
var67
-1
2
loose nut41
tightened nut41
end_variable
begin_variable
var68
-1
2
at spanner37 location15
carrying bob spanner37
end_variable
begin_variable
var69
-1
2
loose nut42
tightened nut42
end_variable
begin_variable
var70
-1
2
at spanner38 location41
carrying bob spanner38
end_variable
begin_variable
var71
-1
2
loose nut43
tightened nut43
end_variable
begin_variable
var72
-1
2
at spanner39 location2
carrying bob spanner39
end_variable
begin_variable
var73
-1
2
loose nut44
tightened nut44
end_variable
begin_variable
var74
-1
2
at spanner4 location20
carrying bob spanner4
end_variable
begin_variable
var75
-1
2
loose nut45
tightened nut45
end_variable
begin_variable
var76
-1
2
at spanner40 location22
carrying bob spanner40
end_variable
begin_variable
var77
-1
2
loose nut46
tightened nut46
end_variable
begin_variable
var78
-1
2
at spanner41 location37
carrying bob spanner41
end_variable
begin_variable
var79
-1
2
loose nut47
tightened nut47
end_variable
begin_variable
var80
-1
2
at spanner42 location21
carrying bob spanner42
end_variable
begin_variable
var81
-1
2
loose nut48
tightened nut48
end_variable
begin_variable
var82
-1
2
at spanner43 location6
carrying bob spanner43
end_variable
begin_variable
var83
-1
2
loose nut49
tightened nut49
end_variable
begin_variable
var84
-1
2
at spanner44 location16
carrying bob spanner44
end_variable
begin_variable
var85
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var86
-1
2
at spanner45 location1
carrying bob spanner45
end_variable
begin_variable
var87
-1
2
loose nut50
tightened nut50
end_variable
begin_variable
var88
-1
2
at spanner46 location4
carrying bob spanner46
end_variable
begin_variable
var89
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var90
-1
2
at spanner47 location38
carrying bob spanner47
end_variable
begin_variable
var91
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var92
-1
2
at spanner48 location29
carrying bob spanner48
end_variable
begin_variable
var93
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var94
-1
2
at spanner49 location8
carrying bob spanner49
end_variable
begin_variable
var95
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var96
-1
2
at spanner5 location48
carrying bob spanner5
end_variable
begin_variable
var97
-1
2
at spanner50 location30
carrying bob spanner50
end_variable
begin_variable
var98
-1
2
at spanner51 location26
carrying bob spanner51
end_variable
begin_variable
var99
-1
2
at spanner52 location19
carrying bob spanner52
end_variable
begin_variable
var100
-1
2
at spanner53 location49
carrying bob spanner53
end_variable
begin_variable
var101
-1
2
at spanner54 location28
carrying bob spanner54
end_variable
begin_variable
var102
-1
2
at spanner55 location18
carrying bob spanner55
end_variable
begin_variable
var103
-1
2
at spanner56 location3
carrying bob spanner56
end_variable
begin_variable
var104
-1
2
at spanner57 location25
carrying bob spanner57
end_variable
begin_variable
var105
-1
2
at spanner58 location18
carrying bob spanner58
end_variable
begin_variable
var106
-1
2
at spanner59 location27
carrying bob spanner59
end_variable
begin_variable
var107
-1
2
at spanner6 location46
carrying bob spanner6
end_variable
begin_variable
var108
-1
2
at spanner60 location12
carrying bob spanner60
end_variable
begin_variable
var109
-1
2
at spanner61 location13
carrying bob spanner61
end_variable
begin_variable
var110
-1
2
at spanner62 location2
carrying bob spanner62
end_variable
begin_variable
var111
-1
2
at spanner63 location34
carrying bob spanner63
end_variable
begin_variable
var112
-1
2
at spanner64 location32
carrying bob spanner64
end_variable
begin_variable
var113
-1
2
at spanner65 location30
carrying bob spanner65
end_variable
begin_variable
var114
-1
2
at spanner66 location39
carrying bob spanner66
end_variable
begin_variable
var115
-1
2
at spanner67 location12
carrying bob spanner67
end_variable
begin_variable
var116
-1
2
at spanner68 location31
carrying bob spanner68
end_variable
begin_variable
var117
-1
2
at spanner69 location13
carrying bob spanner69
end_variable
begin_variable
var118
-1
2
at spanner7 location12
carrying bob spanner7
end_variable
begin_variable
var119
-1
2
at spanner70 location8
carrying bob spanner70
end_variable
begin_variable
var120
-1
2
at spanner71 location16
carrying bob spanner71
end_variable
begin_variable
var121
-1
2
at spanner72 location5
carrying bob spanner72
end_variable
begin_variable
var122
-1
2
at spanner73 location24
carrying bob spanner73
end_variable
begin_variable
var123
-1
2
at spanner74 location21
carrying bob spanner74
end_variable
begin_variable
var124
-1
2
at spanner75 location24
carrying bob spanner75
end_variable
begin_variable
var125
-1
2
at spanner76 location1
carrying bob spanner76
end_variable
begin_variable
var126
-1
2
at spanner77 location12
carrying bob spanner77
end_variable
begin_variable
var127
-1
2
at spanner78 location34
carrying bob spanner78
end_variable
begin_variable
var128
-1
2
at spanner79 location10
carrying bob spanner79
end_variable
begin_variable
var129
-1
2
at spanner8 location15
carrying bob spanner8
end_variable
begin_variable
var130
-1
2
at spanner80 location41
carrying bob spanner80
end_variable
begin_variable
var131
-1
2
at spanner81 location17
carrying bob spanner81
end_variable
begin_variable
var132
-1
2
at spanner82 location46
carrying bob spanner82
end_variable
begin_variable
var133
-1
2
at spanner83 location40
carrying bob spanner83
end_variable
begin_variable
var134
-1
2
at spanner84 location25
carrying bob spanner84
end_variable
begin_variable
var135
-1
2
at spanner85 location14
carrying bob spanner85
end_variable
begin_variable
var136
-1
2
at spanner86 location36
carrying bob spanner86
end_variable
begin_variable
var137
-1
2
at spanner87 location19
carrying bob spanner87
end_variable
begin_variable
var138
-1
2
at spanner88 location7
carrying bob spanner88
end_variable
begin_variable
var139
-1
2
at spanner89 location49
carrying bob spanner89
end_variable
begin_variable
var140
-1
2
at spanner9 location34
carrying bob spanner9
end_variable
begin_variable
var141
-1
2
at spanner90 location44
carrying bob spanner90
end_variable
begin_variable
var142
-1
2
at spanner91 location17
carrying bob spanner91
end_variable
begin_variable
var143
-1
2
at spanner92 location4
carrying bob spanner92
end_variable
begin_variable
var144
-1
2
at spanner93 location15
carrying bob spanner93
end_variable
begin_variable
var145
-1
2
at spanner94 location12
carrying bob spanner94
end_variable
begin_variable
var146
-1
2
at spanner95 location21
carrying bob spanner95
end_variable
begin_variable
var147
-1
2
at spanner96 location39
carrying bob spanner96
end_variable
begin_variable
var148
-1
2
at spanner97 location42
carrying bob spanner97
end_variable
begin_variable
var149
-1
2
at spanner98 location16
carrying bob spanner98
end_variable
begin_variable
var150
-1
2
at spanner99 location24
carrying bob spanner99
end_variable
begin_variable
var151
-1
2
usable spanner62
none-of-those
end_variable
begin_variable
var152
-1
2
usable spanner63
none-of-those
end_variable
begin_variable
var153
-1
2
usable spanner64
none-of-those
end_variable
begin_variable
var154
-1
2
usable spanner65
none-of-those
end_variable
begin_variable
var155
-1
2
usable spanner66
none-of-those
end_variable
begin_variable
var156
-1
2
usable spanner67
none-of-those
end_variable
begin_variable
var157
-1
2
usable spanner68
none-of-those
end_variable
begin_variable
var158
-1
2
usable spanner69
none-of-those
end_variable
begin_variable
var159
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var160
-1
2
usable spanner70
none-of-those
end_variable
begin_variable
var161
-1
2
usable spanner71
none-of-those
end_variable
begin_variable
var162
-1
2
usable spanner72
none-of-those
end_variable
begin_variable
var163
-1
2
usable spanner73
none-of-those
end_variable
begin_variable
var164
-1
2
usable spanner74
none-of-those
end_variable
begin_variable
var165
-1
2
usable spanner75
none-of-those
end_variable
begin_variable
var166
-1
2
usable spanner76
none-of-those
end_variable
begin_variable
var167
-1
2
usable spanner77
none-of-those
end_variable
begin_variable
var168
-1
2
usable spanner78
none-of-those
end_variable
begin_variable
var169
-1
2
usable spanner79
none-of-those
end_variable
begin_variable
var170
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var171
-1
2
usable spanner80
none-of-those
end_variable
begin_variable
var172
-1
2
usable spanner81
none-of-those
end_variable
begin_variable
var173
-1
2
usable spanner82
none-of-those
end_variable
begin_variable
var174
-1
2
usable spanner83
none-of-those
end_variable
begin_variable
var175
-1
2
usable spanner84
none-of-those
end_variable
begin_variable
var176
-1
2
usable spanner85
none-of-those
end_variable
begin_variable
var177
-1
2
usable spanner86
none-of-those
end_variable
begin_variable
var178
-1
2
usable spanner87
none-of-those
end_variable
begin_variable
var179
-1
2
usable spanner88
none-of-those
end_variable
begin_variable
var180
-1
2
usable spanner89
none-of-those
end_variable
begin_variable
var181
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var182
-1
2
usable spanner90
none-of-those
end_variable
begin_variable
var183
-1
2
usable spanner91
none-of-those
end_variable
begin_variable
var184
-1
2
usable spanner92
none-of-those
end_variable
begin_variable
var185
-1
2
usable spanner93
none-of-those
end_variable
begin_variable
var186
-1
2
usable spanner94
none-of-those
end_variable
begin_variable
var187
-1
2
usable spanner95
none-of-those
end_variable
begin_variable
var188
-1
2
usable spanner96
none-of-those
end_variable
begin_variable
var189
-1
2
usable spanner97
none-of-those
end_variable
begin_variable
var190
-1
2
usable spanner98
none-of-those
end_variable
begin_variable
var191
-1
2
usable spanner99
none-of-those
end_variable
begin_variable
var192
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var193
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var194
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var195
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var196
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var197
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var198
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var199
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var200
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var201
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var202
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var203
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var204
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var205
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var206
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var207
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var208
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var209
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var210
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var211
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var212
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var213
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var214
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var215
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var216
-1
2
at nut31 gate
none-of-those
end_variable
begin_variable
var217
-1
2
at nut32 gate
none-of-those
end_variable
begin_variable
var218
-1
2
at nut33 gate
none-of-those
end_variable
begin_variable
var219
-1
2
at nut34 gate
none-of-those
end_variable
begin_variable
var220
-1
2
at nut35 gate
none-of-those
end_variable
begin_variable
var221
-1
2
at nut36 gate
none-of-those
end_variable
begin_variable
var222
-1
2
at nut37 gate
none-of-those
end_variable
begin_variable
var223
-1
2
at nut38 gate
none-of-those
end_variable
begin_variable
var224
-1
2
at nut39 gate
none-of-those
end_variable
begin_variable
var225
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var226
-1
2
at nut40 gate
none-of-those
end_variable
begin_variable
var227
-1
2
at nut41 gate
none-of-those
end_variable
begin_variable
var228
-1
2
at nut42 gate
none-of-those
end_variable
begin_variable
var229
-1
2
at nut43 gate
none-of-those
end_variable
begin_variable
var230
-1
2
at nut44 gate
none-of-those
end_variable
begin_variable
var231
-1
2
at nut45 gate
none-of-those
end_variable
begin_variable
var232
-1
2
at nut46 gate
none-of-those
end_variable
begin_variable
var233
-1
2
at nut47 gate
none-of-those
end_variable
begin_variable
var234
-1
2
at nut48 gate
none-of-those
end_variable
begin_variable
var235
-1
2
at nut49 gate
none-of-those
end_variable
begin_variable
var236
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var237
-1
2
at nut50 gate
none-of-those
end_variable
begin_variable
var238
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var239
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var240
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var241
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var242
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var243
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var244
-1
2
usable spanner100
none-of-those
end_variable
begin_variable
var245
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var246
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var247
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var248
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var249
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var250
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var251
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var252
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var253
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var254
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var255
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var256
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var257
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var258
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var259
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var260
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var261
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var262
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var263
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var264
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var265
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var266
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var267
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var268
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var269
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var270
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var271
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var272
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var273
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var274
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var275
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var276
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var277
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var278
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var279
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var280
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var281
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var282
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var283
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var284
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var285
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var286
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var287
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var288
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var289
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var290
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var291
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var292
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var293
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var294
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var295
-1
2
usable spanner57
none-of-those
end_variable
begin_variable
var296
-1
2
usable spanner58
none-of-those
end_variable
begin_variable
var297
-1
2
usable spanner59
none-of-those
end_variable
begin_variable
var298
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var299
-1
2
usable spanner60
none-of-those
end_variable
begin_variable
var300
-1
2
usable spanner61
none-of-those
end_variable
begin_variable
var301
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var302
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var303
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var304
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var305
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var306
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var307
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var308
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var309
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var310
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var311
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var312
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var313
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var314
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var315
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var316
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var317
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var318
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var319
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var320
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var321
-1
2
link location28 location29
none-of-those
end_variable
begin_variable
var322
-1
2
link location29 location30
none-of-those
end_variable
begin_variable
var323
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var324
-1
2
link location30 location31
none-of-those
end_variable
begin_variable
var325
-1
2
link location31 location32
none-of-those
end_variable
begin_variable
var326
-1
2
link location32 location33
none-of-those
end_variable
begin_variable
var327
-1
2
link location33 location34
none-of-those
end_variable
begin_variable
var328
-1
2
link location34 location35
none-of-those
end_variable
begin_variable
var329
-1
2
link location35 location36
none-of-those
end_variable
begin_variable
var330
-1
2
link location36 location37
none-of-those
end_variable
begin_variable
var331
-1
2
link location37 location38
none-of-those
end_variable
begin_variable
var332
-1
2
link location38 location39
none-of-those
end_variable
begin_variable
var333
-1
2
link location39 location40
none-of-those
end_variable
begin_variable
var334
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var335
-1
2
link location40 location41
none-of-those
end_variable
begin_variable
var336
-1
2
link location41 location42
none-of-those
end_variable
begin_variable
var337
-1
2
link location42 location43
none-of-those
end_variable
begin_variable
var338
-1
2
link location43 location44
none-of-those
end_variable
begin_variable
var339
-1
2
link location44 location45
none-of-those
end_variable
begin_variable
var340
-1
2
link location45 location46
none-of-those
end_variable
begin_variable
var341
-1
2
link location46 location47
none-of-those
end_variable
begin_variable
var342
-1
2
link location47 location48
none-of-those
end_variable
begin_variable
var343
-1
2
link location48 location49
none-of-those
end_variable
begin_variable
var344
-1
2
link location49 location50
none-of-those
end_variable
begin_variable
var345
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var346
-1
2
link location50 gate
none-of-those
end_variable
begin_variable
var347
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var348
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var349
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var350
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var351
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
51
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
50
1 1
2 1
3 1
4 1
5 1
7 1
9 1
11 1
13 1
15 1
17 1
19 1
21 1
23 1
25 1
27 1
29 1
31 1
33 1
35 1
37 1
39 1
41 1
43 1
45 1
47 1
49 1
51 1
53 1
55 1
57 1
59 1
61 1
63 1
65 1
67 1
69 1
71 1
73 1
75 1
77 1
79 1
81 1
83 1
85 1
87 1
89 1
91 1
93 1
95 1
end_goal
5151
begin_operator
pickup_spanner location1 spanner45 bob
1
0 1
1
0 86 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner76 bob
1
0 1
1
0 125 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner79 bob
1
0 2
1
0 128 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner3 bob
1
0 4
1
0 52 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner60 bob
1
0 4
1
0 108 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner67 bob
1
0 4
1
0 115 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner7 bob
1
0 4
1
0 118 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner77 bob
1
0 4
1
0 126 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner94 bob
1
0 4
1
0 145 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner12 bob
1
0 5
1
0 14 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner23 bob
1
0 5
1
0 38 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner61 bob
1
0 5
1
0 109 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner69 bob
1
0 5
1
0 117 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner85 bob
1
0 6
1
0 135 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner37 bob
1
0 7
1
0 68 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner8 bob
1
0 7
1
0 129 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner93 bob
1
0 7
1
0 144 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner24 bob
1
0 8
1
0 40 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner44 bob
1
0 8
1
0 84 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner71 bob
1
0 8
1
0 120 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner98 bob
1
0 8
1
0 149 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner81 bob
1
0 9
1
0 131 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner91 bob
1
0 9
1
0 142 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner31 bob
1
0 10
1
0 56 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner55 bob
1
0 10
1
0 102 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner58 bob
1
0 10
1
0 105 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner17 bob
1
0 11
1
0 24 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner35 bob
1
0 11
1
0 64 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner36 bob
1
0 11
1
0 66 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner52 bob
1
0 11
1
0 99 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner87 bob
1
0 11
1
0 137 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner39 bob
1
0 12
1
0 72 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner62 bob
1
0 12
1
0 110 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner4 bob
1
0 13
1
0 74 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner42 bob
1
0 14
1
0 80 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner74 bob
1
0 14
1
0 123 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner95 bob
1
0 14
1
0 146 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner40 bob
1
0 15
1
0 76 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner73 bob
1
0 17
1
0 122 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner75 bob
1
0 17
1
0 124 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner99 bob
1
0 17
1
0 150 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner57 bob
1
0 18
1
0 104 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner84 bob
1
0 18
1
0 134 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner51 bob
1
0 19
1
0 98 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner59 bob
1
0 20
1
0 106 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner22 bob
1
0 21
1
0 36 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner34 bob
1
0 21
1
0 62 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner54 bob
1
0 21
1
0 101 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner15 bob
1
0 22
1
0 20 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner48 bob
1
0 22
1
0 92 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner1 bob
1
0 23
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner20 bob
1
0 23
1
0 32 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner21 bob
1
0 23
1
0 34 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner56 bob
1
0 23
1
0 103 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner50 bob
1
0 24
1
0 97 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner65 bob
1
0 24
1
0 113 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner68 bob
1
0 25
1
0 116 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner64 bob
1
0 26
1
0 112 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner63 bob
1
0 28
1
0 111 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner78 bob
1
0 28
1
0 127 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner9 bob
1
0 28
1
0 140 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner13 bob
1
0 30
1
0 16 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner86 bob
1
0 30
1
0 136 0 1
1
end_operator
begin_operator
pickup_spanner location37 spanner41 bob
1
0 31
1
0 78 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner16 bob
1
0 32
1
0 22 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner47 bob
1
0 32
1
0 90 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner2 bob
1
0 33
1
0 30 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner66 bob
1
0 33
1
0 114 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner96 bob
1
0 33
1
0 147 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner10 bob
1
0 34
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner100 bob
1
0 34
1
0 10 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner14 bob
1
0 34
1
0 18 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner30 bob
1
0 34
1
0 54 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner46 bob
1
0 34
1
0 88 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner92 bob
1
0 34
1
0 143 0 1
1
end_operator
begin_operator
pickup_spanner location40 spanner19 bob
1
0 35
1
0 28 0 1
1
end_operator
begin_operator
pickup_spanner location40 spanner83 bob
1
0 35
1
0 133 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner11 bob
1
0 36
1
0 12 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner29 bob
1
0 36
1
0 50 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner38 bob
1
0 36
1
0 70 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner80 bob
1
0 36
1
0 130 0 1
1
end_operator
begin_operator
pickup_spanner location42 spanner33 bob
1
0 37
1
0 60 0 1
1
end_operator
begin_operator
pickup_spanner location42 spanner97 bob
1
0 37
1
0 148 0 1
1
end_operator
begin_operator
pickup_spanner location43 spanner28 bob
1
0 38
1
0 48 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner90 bob
1
0 39
1
0 141 0 1
1
end_operator
begin_operator
pickup_spanner location45 spanner32 bob
1
0 40
1
0 58 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner25 bob
1
0 41
1
0 42 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner6 bob
1
0 41
1
0 107 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner82 bob
1
0 41
1
0 132 0 1
1
end_operator
begin_operator
pickup_spanner location47 spanner18 bob
1
0 42
1
0 26 0 1
1
end_operator
begin_operator
pickup_spanner location48 spanner5 bob
1
0 43
1
0 96 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner53 bob
1
0 44
1
0 100 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner89 bob
1
0 44
1
0 139 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner26 bob
1
0 45
1
0 44 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner72 bob
1
0 45
1
0 121 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner43 bob
1
0 47
1
0 82 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner88 bob
1
0 48
1
0 138 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner27 bob
1
0 49
1
0 46 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner49 bob
1
0 49
1
0 94 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner70 bob
1
0 49
1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
6 1
192 0
2
0 1 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
6 1
193 0
2
0 2 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
6 1
194 0
2
0 3 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
6 1
195 0
2
0 4 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
6 1
196 0
2
0 5 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
6 1
197 0
2
0 7 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
6 1
198 0
2
0 9 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
6 1
199 0
2
0 11 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
6 1
200 0
2
0 13 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
6 1
201 0
2
0 15 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
6 1
202 0
2
0 17 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
6 1
203 0
2
0 19 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
6 1
204 0
2
0 21 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
6 1
205 0
2
0 23 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
6 1
206 0
2
0 25 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
6 1
207 0
2
0 27 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
6 1
208 0
2
0 29 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
6 1
209 0
2
0 31 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
6 1
210 0
2
0 33 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
6 1
211 0
2
0 35 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
6 1
212 0
2
0 37 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
6 1
213 0
2
0 39 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
6 1
214 0
2
0 41 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
6 1
215 0
2
0 43 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut31
3
0 0
6 1
216 0
2
0 45 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut32
3
0 0
6 1
217 0
2
0 47 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut33
3
0 0
6 1
218 0
2
0 49 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut34
3
0 0
6 1
219 0
2
0 51 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut35
3
0 0
6 1
220 0
2
0 53 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut36
3
0 0
6 1
221 0
2
0 55 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut37
3
0 0
6 1
222 0
2
0 57 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut38
3
0 0
6 1
223 0
2
0 59 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut39
3
0 0
6 1
224 0
2
0 61 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
6 1
225 0
2
0 63 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut40
3
0 0
6 1
226 0
2
0 65 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut41
3
0 0
6 1
227 0
2
0 67 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut42
3
0 0
6 1
228 0
2
0 69 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut43
3
0 0
6 1
229 0
2
0 71 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut44
3
0 0
6 1
230 0
2
0 73 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut45
3
0 0
6 1
231 0
2
0 75 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut46
3
0 0
6 1
232 0
2
0 77 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut47
3
0 0
6 1
233 0
2
0 79 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut48
3
0 0
6 1
234 0
2
0 81 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut49
3
0 0
6 1
235 0
2
0 83 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
6 1
236 0
2
0 85 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut50
3
0 0
6 1
237 0
2
0 87 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
6 1
238 0
2
0 89 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
6 1
239 0
2
0 91 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
6 1
240 0
2
0 93 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
6 1
241 0
2
0 95 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
8 1
192 0
2
0 1 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
8 1
193 0
2
0 2 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
8 1
194 0
2
0 3 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
8 1
195 0
2
0 4 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
8 1
196 0
2
0 5 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
8 1
197 0
2
0 7 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
8 1
198 0
2
0 9 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
8 1
199 0
2
0 11 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
8 1
200 0
2
0 13 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
8 1
201 0
2
0 15 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
8 1
202 0
2
0 17 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
8 1
203 0
2
0 19 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
8 1
204 0
2
0 21 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
8 1
205 0
2
0 23 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
8 1
206 0
2
0 25 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
8 1
207 0
2
0 27 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
8 1
208 0
2
0 29 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
8 1
209 0
2
0 31 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
8 1
210 0
2
0 33 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
8 1
211 0
2
0 35 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
8 1
212 0
2
0 37 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
8 1
213 0
2
0 39 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
8 1
214 0
2
0 41 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
8 1
215 0
2
0 43 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut31
3
0 0
8 1
216 0
2
0 45 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut32
3
0 0
8 1
217 0
2
0 47 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut33
3
0 0
8 1
218 0
2
0 49 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut34
3
0 0
8 1
219 0
2
0 51 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut35
3
0 0
8 1
220 0
2
0 53 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut36
3
0 0
8 1
221 0
2
0 55 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut37
3
0 0
8 1
222 0
2
0 57 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut38
3
0 0
8 1
223 0
2
0 59 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut39
3
0 0
8 1
224 0
2
0 61 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
8 1
225 0
2
0 63 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut40
3
0 0
8 1
226 0
2
0 65 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut41
3
0 0
8 1
227 0
2
0 67 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut42
3
0 0
8 1
228 0
2
0 69 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut43
3
0 0
8 1
229 0
2
0 71 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut44
3
0 0
8 1
230 0
2
0 73 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut45
3
0 0
8 1
231 0
2
0 75 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut46
3
0 0
8 1
232 0
2
0 77 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut47
3
0 0
8 1
233 0
2
0 79 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut48
3
0 0
8 1
234 0
2
0 81 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut49
3
0 0
8 1
235 0
2
0 83 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
8 1
236 0
2
0 85 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut50
3
0 0
8 1
237 0
2
0 87 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
8 1
238 0
2
0 89 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
8 1
239 0
2
0 91 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
8 1
240 0
2
0 93 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
8 1
241 0
2
0 95 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut1
3
0 0
10 1
192 0
2
0 1 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut10
3
0 0
10 1
193 0
2
0 2 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut11
3
0 0
10 1
194 0
2
0 3 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut12
3
0 0
10 1
195 0
2
0 4 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut13
3
0 0
10 1
196 0
2
0 5 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut14
3
0 0
10 1
197 0
2
0 7 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut15
3
0 0
10 1
198 0
2
0 9 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut16
3
0 0
10 1
199 0
2
0 11 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut17
3
0 0
10 1
200 0
2
0 13 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut18
3
0 0
10 1
201 0
2
0 15 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut19
3
0 0
10 1
202 0
2
0 17 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut2
3
0 0
10 1
203 0
2
0 19 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut20
3
0 0
10 1
204 0
2
0 21 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut21
3
0 0
10 1
205 0
2
0 23 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut22
3
0 0
10 1
206 0
2
0 25 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut23
3
0 0
10 1
207 0
2
0 27 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut24
3
0 0
10 1
208 0
2
0 29 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut25
3
0 0
10 1
209 0
2
0 31 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut26
3
0 0
10 1
210 0
2
0 33 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut27
3
0 0
10 1
211 0
2
0 35 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut28
3
0 0
10 1
212 0
2
0 37 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut29
3
0 0
10 1
213 0
2
0 39 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut3
3
0 0
10 1
214 0
2
0 41 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut30
3
0 0
10 1
215 0
2
0 43 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut31
3
0 0
10 1
216 0
2
0 45 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut32
3
0 0
10 1
217 0
2
0 47 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut33
3
0 0
10 1
218 0
2
0 49 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut34
3
0 0
10 1
219 0
2
0 51 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut35
3
0 0
10 1
220 0
2
0 53 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut36
3
0 0
10 1
221 0
2
0 55 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut37
3
0 0
10 1
222 0
2
0 57 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut38
3
0 0
10 1
223 0
2
0 59 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut39
3
0 0
10 1
224 0
2
0 61 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut4
3
0 0
10 1
225 0
2
0 63 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut40
3
0 0
10 1
226 0
2
0 65 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut41
3
0 0
10 1
227 0
2
0 67 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut42
3
0 0
10 1
228 0
2
0 69 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut43
3
0 0
10 1
229 0
2
0 71 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut44
3
0 0
10 1
230 0
2
0 73 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut45
3
0 0
10 1
231 0
2
0 75 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut46
3
0 0
10 1
232 0
2
0 77 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut47
3
0 0
10 1
233 0
2
0 79 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut48
3
0 0
10 1
234 0
2
0 81 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut49
3
0 0
10 1
235 0
2
0 83 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut5
3
0 0
10 1
236 0
2
0 85 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut50
3
0 0
10 1
237 0
2
0 87 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut6
3
0 0
10 1
238 0
2
0 89 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut7
3
0 0
10 1
239 0
2
0 91 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut8
3
0 0
10 1
240 0
2
0 93 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut9
3
0 0
10 1
241 0
2
0 95 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
12 1
192 0
2
0 1 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
12 1
193 0
2
0 2 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
12 1
194 0
2
0 3 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
12 1
195 0
2
0 4 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
12 1
196 0
2
0 5 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
12 1
197 0
2
0 7 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
12 1
198 0
2
0 9 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
12 1
199 0
2
0 11 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
12 1
200 0
2
0 13 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
12 1
201 0
2
0 15 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
12 1
202 0
2
0 17 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
12 1
203 0
2
0 19 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
12 1
204 0
2
0 21 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
12 1
205 0
2
0 23 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
12 1
206 0
2
0 25 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
12 1
207 0
2
0 27 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
12 1
208 0
2
0 29 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
12 1
209 0
2
0 31 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
12 1
210 0
2
0 33 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
12 1
211 0
2
0 35 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
12 1
212 0
2
0 37 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
12 1
213 0
2
0 39 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
12 1
214 0
2
0 41 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
12 1
215 0
2
0 43 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut31
3
0 0
12 1
216 0
2
0 45 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut32
3
0 0
12 1
217 0
2
0 47 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut33
3
0 0
12 1
218 0
2
0 49 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut34
3
0 0
12 1
219 0
2
0 51 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut35
3
0 0
12 1
220 0
2
0 53 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut36
3
0 0
12 1
221 0
2
0 55 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut37
3
0 0
12 1
222 0
2
0 57 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut38
3
0 0
12 1
223 0
2
0 59 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut39
3
0 0
12 1
224 0
2
0 61 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
12 1
225 0
2
0 63 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut40
3
0 0
12 1
226 0
2
0 65 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut41
3
0 0
12 1
227 0
2
0 67 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut42
3
0 0
12 1
228 0
2
0 69 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut43
3
0 0
12 1
229 0
2
0 71 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut44
3
0 0
12 1
230 0
2
0 73 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut45
3
0 0
12 1
231 0
2
0 75 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut46
3
0 0
12 1
232 0
2
0 77 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut47
3
0 0
12 1
233 0
2
0 79 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut48
3
0 0
12 1
234 0
2
0 81 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut49
3
0 0
12 1
235 0
2
0 83 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
12 1
236 0
2
0 85 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut50
3
0 0
12 1
237 0
2
0 87 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
12 1
238 0
2
0 89 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
12 1
239 0
2
0 91 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
12 1
240 0
2
0 93 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
12 1
241 0
2
0 95 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
14 1
192 0
2
0 1 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
14 1
193 0
2
0 2 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
14 1
194 0
2
0 3 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
14 1
195 0
2
0 4 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
14 1
196 0
2
0 5 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
14 1
197 0
2
0 7 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
14 1
198 0
2
0 9 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
14 1
199 0
2
0 11 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
14 1
200 0
2
0 13 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
14 1
201 0
2
0 15 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
14 1
202 0
2
0 17 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
14 1
203 0
2
0 19 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
14 1
204 0
2
0 21 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
14 1
205 0
2
0 23 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
14 1
206 0
2
0 25 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
14 1
207 0
2
0 27 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
14 1
208 0
2
0 29 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
14 1
209 0
2
0 31 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
14 1
210 0
2
0 33 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
14 1
211 0
2
0 35 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
14 1
212 0
2
0 37 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
14 1
213 0
2
0 39 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
14 1
214 0
2
0 41 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
14 1
215 0
2
0 43 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut31
3
0 0
14 1
216 0
2
0 45 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut32
3
0 0
14 1
217 0
2
0 47 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut33
3
0 0
14 1
218 0
2
0 49 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut34
3
0 0
14 1
219 0
2
0 51 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut35
3
0 0
14 1
220 0
2
0 53 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut36
3
0 0
14 1
221 0
2
0 55 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut37
3
0 0
14 1
222 0
2
0 57 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut38
3
0 0
14 1
223 0
2
0 59 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut39
3
0 0
14 1
224 0
2
0 61 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
14 1
225 0
2
0 63 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut40
3
0 0
14 1
226 0
2
0 65 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut41
3
0 0
14 1
227 0
2
0 67 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut42
3
0 0
14 1
228 0
2
0 69 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut43
3
0 0
14 1
229 0
2
0 71 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut44
3
0 0
14 1
230 0
2
0 73 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut45
3
0 0
14 1
231 0
2
0 75 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut46
3
0 0
14 1
232 0
2
0 77 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut47
3
0 0
14 1
233 0
2
0 79 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut48
3
0 0
14 1
234 0
2
0 81 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut49
3
0 0
14 1
235 0
2
0 83 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
14 1
236 0
2
0 85 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut50
3
0 0
14 1
237 0
2
0 87 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
14 1
238 0
2
0 89 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
14 1
239 0
2
0 91 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
14 1
240 0
2
0 93 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
14 1
241 0
2
0 95 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
16 1
192 0
2
0 1 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
16 1
193 0
2
0 2 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
16 1
194 0
2
0 3 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
16 1
195 0
2
0 4 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
16 1
196 0
2
0 5 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
16 1
197 0
2
0 7 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
16 1
198 0
2
0 9 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
16 1
199 0
2
0 11 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
16 1
200 0
2
0 13 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
16 1
201 0
2
0 15 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
16 1
202 0
2
0 17 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
16 1
203 0
2
0 19 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
16 1
204 0
2
0 21 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
16 1
205 0
2
0 23 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
16 1
206 0
2
0 25 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
16 1
207 0
2
0 27 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
16 1
208 0
2
0 29 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
16 1
209 0
2
0 31 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
16 1
210 0
2
0 33 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
16 1
211 0
2
0 35 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
16 1
212 0
2
0 37 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
16 1
213 0
2
0 39 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
16 1
214 0
2
0 41 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
16 1
215 0
2
0 43 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut31
3
0 0
16 1
216 0
2
0 45 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut32
3
0 0
16 1
217 0
2
0 47 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut33
3
0 0
16 1
218 0
2
0 49 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut34
3
0 0
16 1
219 0
2
0 51 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut35
3
0 0
16 1
220 0
2
0 53 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut36
3
0 0
16 1
221 0
2
0 55 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut37
3
0 0
16 1
222 0
2
0 57 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut38
3
0 0
16 1
223 0
2
0 59 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut39
3
0 0
16 1
224 0
2
0 61 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
16 1
225 0
2
0 63 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut40
3
0 0
16 1
226 0
2
0 65 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut41
3
0 0
16 1
227 0
2
0 67 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut42
3
0 0
16 1
228 0
2
0 69 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut43
3
0 0
16 1
229 0
2
0 71 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut44
3
0 0
16 1
230 0
2
0 73 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut45
3
0 0
16 1
231 0
2
0 75 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut46
3
0 0
16 1
232 0
2
0 77 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut47
3
0 0
16 1
233 0
2
0 79 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut48
3
0 0
16 1
234 0
2
0 81 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut49
3
0 0
16 1
235 0
2
0 83 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
16 1
236 0
2
0 85 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut50
3
0 0
16 1
237 0
2
0 87 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
16 1
238 0
2
0 89 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
16 1
239 0
2
0 91 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
16 1
240 0
2
0 93 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
16 1
241 0
2
0 95 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
18 1
192 0
2
0 1 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
18 1
193 0
2
0 2 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
18 1
194 0
2
0 3 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
18 1
195 0
2
0 4 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
18 1
196 0
2
0 5 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
18 1
197 0
2
0 7 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
18 1
198 0
2
0 9 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
18 1
199 0
2
0 11 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
18 1
200 0
2
0 13 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
18 1
201 0
2
0 15 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
18 1
202 0
2
0 17 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
18 1
203 0
2
0 19 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
18 1
204 0
2
0 21 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
18 1
205 0
2
0 23 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
18 1
206 0
2
0 25 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
18 1
207 0
2
0 27 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
18 1
208 0
2
0 29 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
18 1
209 0
2
0 31 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
18 1
210 0
2
0 33 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
18 1
211 0
2
0 35 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
18 1
212 0
2
0 37 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
18 1
213 0
2
0 39 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
18 1
214 0
2
0 41 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
18 1
215 0
2
0 43 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut31
3
0 0
18 1
216 0
2
0 45 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut32
3
0 0
18 1
217 0
2
0 47 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut33
3
0 0
18 1
218 0
2
0 49 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut34
3
0 0
18 1
219 0
2
0 51 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut35
3
0 0
18 1
220 0
2
0 53 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut36
3
0 0
18 1
221 0
2
0 55 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut37
3
0 0
18 1
222 0
2
0 57 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut38
3
0 0
18 1
223 0
2
0 59 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut39
3
0 0
18 1
224 0
2
0 61 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
18 1
225 0
2
0 63 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut40
3
0 0
18 1
226 0
2
0 65 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut41
3
0 0
18 1
227 0
2
0 67 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut42
3
0 0
18 1
228 0
2
0 69 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut43
3
0 0
18 1
229 0
2
0 71 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut44
3
0 0
18 1
230 0
2
0 73 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut45
3
0 0
18 1
231 0
2
0 75 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut46
3
0 0
18 1
232 0
2
0 77 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut47
3
0 0
18 1
233 0
2
0 79 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut48
3
0 0
18 1
234 0
2
0 81 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut49
3
0 0
18 1
235 0
2
0 83 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
18 1
236 0
2
0 85 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut50
3
0 0
18 1
237 0
2
0 87 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
18 1
238 0
2
0 89 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
18 1
239 0
2
0 91 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
18 1
240 0
2
0 93 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
18 1
241 0
2
0 95 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
20 1
192 0
2
0 1 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
20 1
193 0
2
0 2 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
20 1
194 0
2
0 3 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
20 1
195 0
2
0 4 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
20 1
196 0
2
0 5 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
20 1
197 0
2
0 7 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
20 1
198 0
2
0 9 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
20 1
199 0
2
0 11 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
20 1
200 0
2
0 13 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
20 1
201 0
2
0 15 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
20 1
202 0
2
0 17 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
20 1
203 0
2
0 19 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
20 1
204 0
2
0 21 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
20 1
205 0
2
0 23 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
20 1
206 0
2
0 25 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
20 1
207 0
2
0 27 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
20 1
208 0
2
0 29 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
20 1
209 0
2
0 31 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
20 1
210 0
2
0 33 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
20 1
211 0
2
0 35 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
20 1
212 0
2
0 37 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
20 1
213 0
2
0 39 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
20 1
214 0
2
0 41 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
20 1
215 0
2
0 43 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut31
3
0 0
20 1
216 0
2
0 45 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut32
3
0 0
20 1
217 0
2
0 47 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut33
3
0 0
20 1
218 0
2
0 49 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut34
3
0 0
20 1
219 0
2
0 51 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut35
3
0 0
20 1
220 0
2
0 53 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut36
3
0 0
20 1
221 0
2
0 55 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut37
3
0 0
20 1
222 0
2
0 57 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut38
3
0 0
20 1
223 0
2
0 59 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut39
3
0 0
20 1
224 0
2
0 61 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
20 1
225 0
2
0 63 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut40
3
0 0
20 1
226 0
2
0 65 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut41
3
0 0
20 1
227 0
2
0 67 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut42
3
0 0
20 1
228 0
2
0 69 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut43
3
0 0
20 1
229 0
2
0 71 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut44
3
0 0
20 1
230 0
2
0 73 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut45
3
0 0
20 1
231 0
2
0 75 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut46
3
0 0
20 1
232 0
2
0 77 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut47
3
0 0
20 1
233 0
2
0 79 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut48
3
0 0
20 1
234 0
2
0 81 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut49
3
0 0
20 1
235 0
2
0 83 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
20 1
236 0
2
0 85 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut50
3
0 0
20 1
237 0
2
0 87 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
20 1
238 0
2
0 89 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
20 1
239 0
2
0 91 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
20 1
240 0
2
0 93 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
20 1
241 0
2
0 95 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
22 1
192 0
2
0 1 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
22 1
193 0
2
0 2 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
22 1
194 0
2
0 3 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
22 1
195 0
2
0 4 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
22 1
196 0
2
0 5 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
22 1
197 0
2
0 7 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
22 1
198 0
2
0 9 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
22 1
199 0
2
0 11 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
22 1
200 0
2
0 13 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
22 1
201 0
2
0 15 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
22 1
202 0
2
0 17 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
22 1
203 0
2
0 19 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
22 1
204 0
2
0 21 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
22 1
205 0
2
0 23 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
22 1
206 0
2
0 25 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
22 1
207 0
2
0 27 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
22 1
208 0
2
0 29 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
22 1
209 0
2
0 31 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
22 1
210 0
2
0 33 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
22 1
211 0
2
0 35 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
22 1
212 0
2
0 37 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
22 1
213 0
2
0 39 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
22 1
214 0
2
0 41 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
22 1
215 0
2
0 43 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut31
3
0 0
22 1
216 0
2
0 45 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut32
3
0 0
22 1
217 0
2
0 47 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut33
3
0 0
22 1
218 0
2
0 49 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut34
3
0 0
22 1
219 0
2
0 51 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut35
3
0 0
22 1
220 0
2
0 53 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut36
3
0 0
22 1
221 0
2
0 55 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut37
3
0 0
22 1
222 0
2
0 57 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut38
3
0 0
22 1
223 0
2
0 59 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut39
3
0 0
22 1
224 0
2
0 61 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
22 1
225 0
2
0 63 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut40
3
0 0
22 1
226 0
2
0 65 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut41
3
0 0
22 1
227 0
2
0 67 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut42
3
0 0
22 1
228 0
2
0 69 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut43
3
0 0
22 1
229 0
2
0 71 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut44
3
0 0
22 1
230 0
2
0 73 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut45
3
0 0
22 1
231 0
2
0 75 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut46
3
0 0
22 1
232 0
2
0 77 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut47
3
0 0
22 1
233 0
2
0 79 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut48
3
0 0
22 1
234 0
2
0 81 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut49
3
0 0
22 1
235 0
2
0 83 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
22 1
236 0
2
0 85 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut50
3
0 0
22 1
237 0
2
0 87 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
22 1
238 0
2
0 89 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
22 1
239 0
2
0 91 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
22 1
240 0
2
0 93 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
22 1
241 0
2
0 95 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
24 1
192 0
2
0 1 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
24 1
193 0
2
0 2 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
24 1
194 0
2
0 3 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
24 1
195 0
2
0 4 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
24 1
196 0
2
0 5 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
24 1
197 0
2
0 7 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
24 1
198 0
2
0 9 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
24 1
199 0
2
0 11 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
24 1
200 0
2
0 13 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
24 1
201 0
2
0 15 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
24 1
202 0
2
0 17 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
24 1
203 0
2
0 19 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
24 1
204 0
2
0 21 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
24 1
205 0
2
0 23 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
24 1
206 0
2
0 25 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
24 1
207 0
2
0 27 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
24 1
208 0
2
0 29 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
24 1
209 0
2
0 31 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
24 1
210 0
2
0 33 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
24 1
211 0
2
0 35 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
24 1
212 0
2
0 37 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
24 1
213 0
2
0 39 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
24 1
214 0
2
0 41 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
24 1
215 0
2
0 43 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut31
3
0 0
24 1
216 0
2
0 45 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut32
3
0 0
24 1
217 0
2
0 47 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut33
3
0 0
24 1
218 0
2
0 49 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut34
3
0 0
24 1
219 0
2
0 51 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut35
3
0 0
24 1
220 0
2
0 53 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut36
3
0 0
24 1
221 0
2
0 55 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut37
3
0 0
24 1
222 0
2
0 57 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut38
3
0 0
24 1
223 0
2
0 59 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut39
3
0 0
24 1
224 0
2
0 61 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
24 1
225 0
2
0 63 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut40
3
0 0
24 1
226 0
2
0 65 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut41
3
0 0
24 1
227 0
2
0 67 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut42
3
0 0
24 1
228 0
2
0 69 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut43
3
0 0
24 1
229 0
2
0 71 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut44
3
0 0
24 1
230 0
2
0 73 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut45
3
0 0
24 1
231 0
2
0 75 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut46
3
0 0
24 1
232 0
2
0 77 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut47
3
0 0
24 1
233 0
2
0 79 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut48
3
0 0
24 1
234 0
2
0 81 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut49
3
0 0
24 1
235 0
2
0 83 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
24 1
236 0
2
0 85 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut50
3
0 0
24 1
237 0
2
0 87 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
24 1
238 0
2
0 89 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
24 1
239 0
2
0 91 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
24 1
240 0
2
0 93 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
24 1
241 0
2
0 95 0 1
0 251 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
26 1
192 0
2
0 1 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
26 1
193 0
2
0 2 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
26 1
194 0
2
0 3 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
26 1
195 0
2
0 4 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
26 1
196 0
2
0 5 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
26 1
197 0
2
0 7 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
26 1
198 0
2
0 9 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
26 1
199 0
2
0 11 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
26 1
200 0
2
0 13 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
26 1
201 0
2
0 15 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
26 1
202 0
2
0 17 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
26 1
203 0
2
0 19 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
26 1
204 0
2
0 21 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
26 1
205 0
2
0 23 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
26 1
206 0
2
0 25 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
26 1
207 0
2
0 27 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
26 1
208 0
2
0 29 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
26 1
209 0
2
0 31 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
26 1
210 0
2
0 33 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
26 1
211 0
2
0 35 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
26 1
212 0
2
0 37 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
26 1
213 0
2
0 39 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
26 1
214 0
2
0 41 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
26 1
215 0
2
0 43 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut31
3
0 0
26 1
216 0
2
0 45 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut32
3
0 0
26 1
217 0
2
0 47 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut33
3
0 0
26 1
218 0
2
0 49 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut34
3
0 0
26 1
219 0
2
0 51 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut35
3
0 0
26 1
220 0
2
0 53 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut36
3
0 0
26 1
221 0
2
0 55 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut37
3
0 0
26 1
222 0
2
0 57 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut38
3
0 0
26 1
223 0
2
0 59 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut39
3
0 0
26 1
224 0
2
0 61 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
26 1
225 0
2
0 63 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut40
3
0 0
26 1
226 0
2
0 65 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut41
3
0 0
26 1
227 0
2
0 67 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut42
3
0 0
26 1
228 0
2
0 69 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut43
3
0 0
26 1
229 0
2
0 71 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut44
3
0 0
26 1
230 0
2
0 73 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut45
3
0 0
26 1
231 0
2
0 75 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut46
3
0 0
26 1
232 0
2
0 77 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut47
3
0 0
26 1
233 0
2
0 79 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut48
3
0 0
26 1
234 0
2
0 81 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut49
3
0 0
26 1
235 0
2
0 83 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
26 1
236 0
2
0 85 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut50
3
0 0
26 1
237 0
2
0 87 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
26 1
238 0
2
0 89 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
26 1
239 0
2
0 91 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
26 1
240 0
2
0 93 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
26 1
241 0
2
0 95 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
28 1
192 0
2
0 1 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
28 1
193 0
2
0 2 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
28 1
194 0
2
0 3 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
28 1
195 0
2
0 4 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
28 1
196 0
2
0 5 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
28 1
197 0
2
0 7 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
28 1
198 0
2
0 9 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
28 1
199 0
2
0 11 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
28 1
200 0
2
0 13 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
28 1
201 0
2
0 15 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
28 1
202 0
2
0 17 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
28 1
203 0
2
0 19 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
28 1
204 0
2
0 21 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
28 1
205 0
2
0 23 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
28 1
206 0
2
0 25 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
28 1
207 0
2
0 27 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
28 1
208 0
2
0 29 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
28 1
209 0
2
0 31 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
28 1
210 0
2
0 33 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
28 1
211 0
2
0 35 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
28 1
212 0
2
0 37 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
28 1
213 0
2
0 39 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
28 1
214 0
2
0 41 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
28 1
215 0
2
0 43 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut31
3
0 0
28 1
216 0
2
0 45 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut32
3
0 0
28 1
217 0
2
0 47 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut33
3
0 0
28 1
218 0
2
0 49 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut34
3
0 0
28 1
219 0
2
0 51 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut35
3
0 0
28 1
220 0
2
0 53 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut36
3
0 0
28 1
221 0
2
0 55 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut37
3
0 0
28 1
222 0
2
0 57 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut38
3
0 0
28 1
223 0
2
0 59 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut39
3
0 0
28 1
224 0
2
0 61 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
28 1
225 0
2
0 63 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut40
3
0 0
28 1
226 0
2
0 65 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut41
3
0 0
28 1
227 0
2
0 67 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut42
3
0 0
28 1
228 0
2
0 69 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut43
3
0 0
28 1
229 0
2
0 71 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut44
3
0 0
28 1
230 0
2
0 73 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut45
3
0 0
28 1
231 0
2
0 75 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut46
3
0 0
28 1
232 0
2
0 77 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut47
3
0 0
28 1
233 0
2
0 79 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut48
3
0 0
28 1
234 0
2
0 81 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut49
3
0 0
28 1
235 0
2
0 83 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
28 1
236 0
2
0 85 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut50
3
0 0
28 1
237 0
2
0 87 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
28 1
238 0
2
0 89 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
28 1
239 0
2
0 91 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
28 1
240 0
2
0 93 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
28 1
241 0
2
0 95 0 1
0 253 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
30 1
192 0
2
0 1 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
30 1
193 0
2
0 2 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
30 1
194 0
2
0 3 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
30 1
195 0
2
0 4 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
30 1
196 0
2
0 5 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
30 1
197 0
2
0 7 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
30 1
198 0
2
0 9 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
30 1
199 0
2
0 11 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
30 1
200 0
2
0 13 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
30 1
201 0
2
0 15 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
30 1
202 0
2
0 17 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
30 1
203 0
2
0 19 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
30 1
204 0
2
0 21 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
30 1
205 0
2
0 23 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
30 1
206 0
2
0 25 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
30 1
207 0
2
0 27 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
30 1
208 0
2
0 29 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
30 1
209 0
2
0 31 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
30 1
210 0
2
0 33 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
30 1
211 0
2
0 35 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
30 1
212 0
2
0 37 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
30 1
213 0
2
0 39 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
30 1
214 0
2
0 41 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
30 1
215 0
2
0 43 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut31
3
0 0
30 1
216 0
2
0 45 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut32
3
0 0
30 1
217 0
2
0 47 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut33
3
0 0
30 1
218 0
2
0 49 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut34
3
0 0
30 1
219 0
2
0 51 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut35
3
0 0
30 1
220 0
2
0 53 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut36
3
0 0
30 1
221 0
2
0 55 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut37
3
0 0
30 1
222 0
2
0 57 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut38
3
0 0
30 1
223 0
2
0 59 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut39
3
0 0
30 1
224 0
2
0 61 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
30 1
225 0
2
0 63 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut40
3
0 0
30 1
226 0
2
0 65 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut41
3
0 0
30 1
227 0
2
0 67 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut42
3
0 0
30 1
228 0
2
0 69 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut43
3
0 0
30 1
229 0
2
0 71 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut44
3
0 0
30 1
230 0
2
0 73 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut45
3
0 0
30 1
231 0
2
0 75 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut46
3
0 0
30 1
232 0
2
0 77 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut47
3
0 0
30 1
233 0
2
0 79 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut48
3
0 0
30 1
234 0
2
0 81 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut49
3
0 0
30 1
235 0
2
0 83 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
30 1
236 0
2
0 85 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut50
3
0 0
30 1
237 0
2
0 87 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
30 1
238 0
2
0 89 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
30 1
239 0
2
0 91 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
30 1
240 0
2
0 93 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
30 1
241 0
2
0 95 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
32 1
192 0
2
0 1 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
32 1
193 0
2
0 2 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
32 1
194 0
2
0 3 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
32 1
195 0
2
0 4 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
32 1
196 0
2
0 5 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
32 1
197 0
2
0 7 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
32 1
198 0
2
0 9 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
32 1
199 0
2
0 11 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
32 1
200 0
2
0 13 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
32 1
201 0
2
0 15 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
32 1
202 0
2
0 17 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
32 1
203 0
2
0 19 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
32 1
204 0
2
0 21 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
32 1
205 0
2
0 23 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
32 1
206 0
2
0 25 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
32 1
207 0
2
0 27 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
32 1
208 0
2
0 29 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
32 1
209 0
2
0 31 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
32 1
210 0
2
0 33 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
32 1
211 0
2
0 35 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
32 1
212 0
2
0 37 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
32 1
213 0
2
0 39 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
32 1
214 0
2
0 41 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
32 1
215 0
2
0 43 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut31
3
0 0
32 1
216 0
2
0 45 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut32
3
0 0
32 1
217 0
2
0 47 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut33
3
0 0
32 1
218 0
2
0 49 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut34
3
0 0
32 1
219 0
2
0 51 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut35
3
0 0
32 1
220 0
2
0 53 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut36
3
0 0
32 1
221 0
2
0 55 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut37
3
0 0
32 1
222 0
2
0 57 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut38
3
0 0
32 1
223 0
2
0 59 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut39
3
0 0
32 1
224 0
2
0 61 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
32 1
225 0
2
0 63 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut40
3
0 0
32 1
226 0
2
0 65 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut41
3
0 0
32 1
227 0
2
0 67 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut42
3
0 0
32 1
228 0
2
0 69 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut43
3
0 0
32 1
229 0
2
0 71 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut44
3
0 0
32 1
230 0
2
0 73 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut45
3
0 0
32 1
231 0
2
0 75 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut46
3
0 0
32 1
232 0
2
0 77 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut47
3
0 0
32 1
233 0
2
0 79 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut48
3
0 0
32 1
234 0
2
0 81 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut49
3
0 0
32 1
235 0
2
0 83 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
32 1
236 0
2
0 85 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut50
3
0 0
32 1
237 0
2
0 87 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
32 1
238 0
2
0 89 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
32 1
239 0
2
0 91 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
32 1
240 0
2
0 93 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
32 1
241 0
2
0 95 0 1
0 255 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
34 1
192 0
2
0 1 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
34 1
193 0
2
0 2 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
34 1
194 0
2
0 3 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
34 1
195 0
2
0 4 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
34 1
196 0
2
0 5 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
34 1
197 0
2
0 7 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
34 1
198 0
2
0 9 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
34 1
199 0
2
0 11 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
34 1
200 0
2
0 13 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
34 1
201 0
2
0 15 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
34 1
202 0
2
0 17 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
34 1
203 0
2
0 19 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
34 1
204 0
2
0 21 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
34 1
205 0
2
0 23 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
34 1
206 0
2
0 25 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
34 1
207 0
2
0 27 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
34 1
208 0
2
0 29 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
34 1
209 0
2
0 31 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
34 1
210 0
2
0 33 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
34 1
211 0
2
0 35 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
34 1
212 0
2
0 37 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
34 1
213 0
2
0 39 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
34 1
214 0
2
0 41 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
34 1
215 0
2
0 43 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut31
3
0 0
34 1
216 0
2
0 45 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut32
3
0 0
34 1
217 0
2
0 47 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut33
3
0 0
34 1
218 0
2
0 49 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut34
3
0 0
34 1
219 0
2
0 51 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut35
3
0 0
34 1
220 0
2
0 53 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut36
3
0 0
34 1
221 0
2
0 55 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut37
3
0 0
34 1
222 0
2
0 57 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut38
3
0 0
34 1
223 0
2
0 59 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut39
3
0 0
34 1
224 0
2
0 61 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
34 1
225 0
2
0 63 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut40
3
0 0
34 1
226 0
2
0 65 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut41
3
0 0
34 1
227 0
2
0 67 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut42
3
0 0
34 1
228 0
2
0 69 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut43
3
0 0
34 1
229 0
2
0 71 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut44
3
0 0
34 1
230 0
2
0 73 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut45
3
0 0
34 1
231 0
2
0 75 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut46
3
0 0
34 1
232 0
2
0 77 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut47
3
0 0
34 1
233 0
2
0 79 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut48
3
0 0
34 1
234 0
2
0 81 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut49
3
0 0
34 1
235 0
2
0 83 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
34 1
236 0
2
0 85 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut50
3
0 0
34 1
237 0
2
0 87 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
34 1
238 0
2
0 89 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
34 1
239 0
2
0 91 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
34 1
240 0
2
0 93 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
34 1
241 0
2
0 95 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
36 1
192 0
2
0 1 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
36 1
193 0
2
0 2 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
36 1
194 0
2
0 3 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
36 1
195 0
2
0 4 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
36 1
196 0
2
0 5 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
36 1
197 0
2
0 7 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
36 1
198 0
2
0 9 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
36 1
199 0
2
0 11 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
36 1
200 0
2
0 13 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
36 1
201 0
2
0 15 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
36 1
202 0
2
0 17 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
36 1
203 0
2
0 19 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
36 1
204 0
2
0 21 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
36 1
205 0
2
0 23 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
36 1
206 0
2
0 25 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
36 1
207 0
2
0 27 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
36 1
208 0
2
0 29 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
36 1
209 0
2
0 31 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
36 1
210 0
2
0 33 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
36 1
211 0
2
0 35 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
36 1
212 0
2
0 37 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
36 1
213 0
2
0 39 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
36 1
214 0
2
0 41 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
36 1
215 0
2
0 43 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut31
3
0 0
36 1
216 0
2
0 45 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut32
3
0 0
36 1
217 0
2
0 47 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut33
3
0 0
36 1
218 0
2
0 49 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut34
3
0 0
36 1
219 0
2
0 51 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut35
3
0 0
36 1
220 0
2
0 53 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut36
3
0 0
36 1
221 0
2
0 55 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut37
3
0 0
36 1
222 0
2
0 57 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut38
3
0 0
36 1
223 0
2
0 59 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut39
3
0 0
36 1
224 0
2
0 61 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
36 1
225 0
2
0 63 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut40
3
0 0
36 1
226 0
2
0 65 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut41
3
0 0
36 1
227 0
2
0 67 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut42
3
0 0
36 1
228 0
2
0 69 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut43
3
0 0
36 1
229 0
2
0 71 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut44
3
0 0
36 1
230 0
2
0 73 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut45
3
0 0
36 1
231 0
2
0 75 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut46
3
0 0
36 1
232 0
2
0 77 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut47
3
0 0
36 1
233 0
2
0 79 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut48
3
0 0
36 1
234 0
2
0 81 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut49
3
0 0
36 1
235 0
2
0 83 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
36 1
236 0
2
0 85 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut50
3
0 0
36 1
237 0
2
0 87 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
36 1
238 0
2
0 89 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
36 1
239 0
2
0 91 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
36 1
240 0
2
0 93 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
36 1
241 0
2
0 95 0 1
0 257 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
38 1
192 0
2
0 1 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
38 1
193 0
2
0 2 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
38 1
194 0
2
0 3 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
38 1
195 0
2
0 4 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
38 1
196 0
2
0 5 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
38 1
197 0
2
0 7 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
38 1
198 0
2
0 9 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
38 1
199 0
2
0 11 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
38 1
200 0
2
0 13 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
38 1
201 0
2
0 15 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
38 1
202 0
2
0 17 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
38 1
203 0
2
0 19 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
38 1
204 0
2
0 21 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
38 1
205 0
2
0 23 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
38 1
206 0
2
0 25 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
38 1
207 0
2
0 27 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
38 1
208 0
2
0 29 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
38 1
209 0
2
0 31 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
38 1
210 0
2
0 33 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
38 1
211 0
2
0 35 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
38 1
212 0
2
0 37 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
38 1
213 0
2
0 39 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
38 1
214 0
2
0 41 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
38 1
215 0
2
0 43 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut31
3
0 0
38 1
216 0
2
0 45 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut32
3
0 0
38 1
217 0
2
0 47 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut33
3
0 0
38 1
218 0
2
0 49 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut34
3
0 0
38 1
219 0
2
0 51 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut35
3
0 0
38 1
220 0
2
0 53 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut36
3
0 0
38 1
221 0
2
0 55 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut37
3
0 0
38 1
222 0
2
0 57 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut38
3
0 0
38 1
223 0
2
0 59 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut39
3
0 0
38 1
224 0
2
0 61 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
38 1
225 0
2
0 63 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut40
3
0 0
38 1
226 0
2
0 65 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut41
3
0 0
38 1
227 0
2
0 67 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut42
3
0 0
38 1
228 0
2
0 69 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut43
3
0 0
38 1
229 0
2
0 71 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut44
3
0 0
38 1
230 0
2
0 73 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut45
3
0 0
38 1
231 0
2
0 75 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut46
3
0 0
38 1
232 0
2
0 77 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut47
3
0 0
38 1
233 0
2
0 79 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut48
3
0 0
38 1
234 0
2
0 81 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut49
3
0 0
38 1
235 0
2
0 83 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
38 1
236 0
2
0 85 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut50
3
0 0
38 1
237 0
2
0 87 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
38 1
238 0
2
0 89 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
38 1
239 0
2
0 91 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
38 1
240 0
2
0 93 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
38 1
241 0
2
0 95 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
40 1
192 0
2
0 1 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
40 1
193 0
2
0 2 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
40 1
194 0
2
0 3 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
40 1
195 0
2
0 4 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
40 1
196 0
2
0 5 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
40 1
197 0
2
0 7 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
40 1
198 0
2
0 9 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
40 1
199 0
2
0 11 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
40 1
200 0
2
0 13 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
40 1
201 0
2
0 15 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
40 1
202 0
2
0 17 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
40 1
203 0
2
0 19 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
40 1
204 0
2
0 21 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
40 1
205 0
2
0 23 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
40 1
206 0
2
0 25 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
40 1
207 0
2
0 27 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
40 1
208 0
2
0 29 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
40 1
209 0
2
0 31 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
40 1
210 0
2
0 33 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
40 1
211 0
2
0 35 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
40 1
212 0
2
0 37 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
40 1
213 0
2
0 39 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
40 1
214 0
2
0 41 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
40 1
215 0
2
0 43 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut31
3
0 0
40 1
216 0
2
0 45 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut32
3
0 0
40 1
217 0
2
0 47 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut33
3
0 0
40 1
218 0
2
0 49 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut34
3
0 0
40 1
219 0
2
0 51 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut35
3
0 0
40 1
220 0
2
0 53 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut36
3
0 0
40 1
221 0
2
0 55 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut37
3
0 0
40 1
222 0
2
0 57 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut38
3
0 0
40 1
223 0
2
0 59 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut39
3
0 0
40 1
224 0
2
0 61 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
40 1
225 0
2
0 63 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut40
3
0 0
40 1
226 0
2
0 65 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut41
3
0 0
40 1
227 0
2
0 67 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut42
3
0 0
40 1
228 0
2
0 69 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut43
3
0 0
40 1
229 0
2
0 71 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut44
3
0 0
40 1
230 0
2
0 73 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut45
3
0 0
40 1
231 0
2
0 75 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut46
3
0 0
40 1
232 0
2
0 77 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut47
3
0 0
40 1
233 0
2
0 79 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut48
3
0 0
40 1
234 0
2
0 81 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut49
3
0 0
40 1
235 0
2
0 83 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
40 1
236 0
2
0 85 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut50
3
0 0
40 1
237 0
2
0 87 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
40 1
238 0
2
0 89 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
40 1
239 0
2
0 91 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
40 1
240 0
2
0 93 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
40 1
241 0
2
0 95 0 1
0 259 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
42 1
192 0
2
0 1 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
42 1
193 0
2
0 2 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
42 1
194 0
2
0 3 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
42 1
195 0
2
0 4 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
42 1
196 0
2
0 5 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
42 1
197 0
2
0 7 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
42 1
198 0
2
0 9 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
42 1
199 0
2
0 11 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
42 1
200 0
2
0 13 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
42 1
201 0
2
0 15 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
42 1
202 0
2
0 17 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
42 1
203 0
2
0 19 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
42 1
204 0
2
0 21 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
42 1
205 0
2
0 23 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
42 1
206 0
2
0 25 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
42 1
207 0
2
0 27 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
42 1
208 0
2
0 29 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
42 1
209 0
2
0 31 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
42 1
210 0
2
0 33 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
42 1
211 0
2
0 35 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
42 1
212 0
2
0 37 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
42 1
213 0
2
0 39 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
42 1
214 0
2
0 41 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
42 1
215 0
2
0 43 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut31
3
0 0
42 1
216 0
2
0 45 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut32
3
0 0
42 1
217 0
2
0 47 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut33
3
0 0
42 1
218 0
2
0 49 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut34
3
0 0
42 1
219 0
2
0 51 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut35
3
0 0
42 1
220 0
2
0 53 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut36
3
0 0
42 1
221 0
2
0 55 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut37
3
0 0
42 1
222 0
2
0 57 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut38
3
0 0
42 1
223 0
2
0 59 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut39
3
0 0
42 1
224 0
2
0 61 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
42 1
225 0
2
0 63 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut40
3
0 0
42 1
226 0
2
0 65 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut41
3
0 0
42 1
227 0
2
0 67 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut42
3
0 0
42 1
228 0
2
0 69 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut43
3
0 0
42 1
229 0
2
0 71 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut44
3
0 0
42 1
230 0
2
0 73 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut45
3
0 0
42 1
231 0
2
0 75 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut46
3
0 0
42 1
232 0
2
0 77 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut47
3
0 0
42 1
233 0
2
0 79 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut48
3
0 0
42 1
234 0
2
0 81 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut49
3
0 0
42 1
235 0
2
0 83 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
42 1
236 0
2
0 85 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut50
3
0 0
42 1
237 0
2
0 87 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
42 1
238 0
2
0 89 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
42 1
239 0
2
0 91 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
42 1
240 0
2
0 93 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
42 1
241 0
2
0 95 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
44 1
192 0
2
0 1 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
44 1
193 0
2
0 2 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
44 1
194 0
2
0 3 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
44 1
195 0
2
0 4 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
44 1
196 0
2
0 5 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
44 1
197 0
2
0 7 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
44 1
198 0
2
0 9 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
44 1
199 0
2
0 11 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
44 1
200 0
2
0 13 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
44 1
201 0
2
0 15 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
44 1
202 0
2
0 17 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
44 1
203 0
2
0 19 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
44 1
204 0
2
0 21 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
44 1
205 0
2
0 23 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
44 1
206 0
2
0 25 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
44 1
207 0
2
0 27 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
44 1
208 0
2
0 29 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
44 1
209 0
2
0 31 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
44 1
210 0
2
0 33 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
44 1
211 0
2
0 35 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
44 1
212 0
2
0 37 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
44 1
213 0
2
0 39 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
44 1
214 0
2
0 41 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
44 1
215 0
2
0 43 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut31
3
0 0
44 1
216 0
2
0 45 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut32
3
0 0
44 1
217 0
2
0 47 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut33
3
0 0
44 1
218 0
2
0 49 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut34
3
0 0
44 1
219 0
2
0 51 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut35
3
0 0
44 1
220 0
2
0 53 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut36
3
0 0
44 1
221 0
2
0 55 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut37
3
0 0
44 1
222 0
2
0 57 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut38
3
0 0
44 1
223 0
2
0 59 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut39
3
0 0
44 1
224 0
2
0 61 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
44 1
225 0
2
0 63 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut40
3
0 0
44 1
226 0
2
0 65 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut41
3
0 0
44 1
227 0
2
0 67 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut42
3
0 0
44 1
228 0
2
0 69 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut43
3
0 0
44 1
229 0
2
0 71 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut44
3
0 0
44 1
230 0
2
0 73 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut45
3
0 0
44 1
231 0
2
0 75 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut46
3
0 0
44 1
232 0
2
0 77 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut47
3
0 0
44 1
233 0
2
0 79 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut48
3
0 0
44 1
234 0
2
0 81 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut49
3
0 0
44 1
235 0
2
0 83 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
44 1
236 0
2
0 85 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut50
3
0 0
44 1
237 0
2
0 87 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
44 1
238 0
2
0 89 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
44 1
239 0
2
0 91 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
44 1
240 0
2
0 93 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
44 1
241 0
2
0 95 0 1
0 261 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
46 1
192 0
2
0 1 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
46 1
193 0
2
0 2 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
46 1
194 0
2
0 3 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
46 1
195 0
2
0 4 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
46 1
196 0
2
0 5 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
46 1
197 0
2
0 7 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
46 1
198 0
2
0 9 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
46 1
199 0
2
0 11 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
46 1
200 0
2
0 13 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
46 1
201 0
2
0 15 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
46 1
202 0
2
0 17 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
46 1
203 0
2
0 19 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
46 1
204 0
2
0 21 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
46 1
205 0
2
0 23 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
46 1
206 0
2
0 25 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
46 1
207 0
2
0 27 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
46 1
208 0
2
0 29 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
46 1
209 0
2
0 31 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
46 1
210 0
2
0 33 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
46 1
211 0
2
0 35 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
46 1
212 0
2
0 37 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
46 1
213 0
2
0 39 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
46 1
214 0
2
0 41 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
46 1
215 0
2
0 43 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut31
3
0 0
46 1
216 0
2
0 45 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut32
3
0 0
46 1
217 0
2
0 47 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut33
3
0 0
46 1
218 0
2
0 49 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut34
3
0 0
46 1
219 0
2
0 51 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut35
3
0 0
46 1
220 0
2
0 53 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut36
3
0 0
46 1
221 0
2
0 55 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut37
3
0 0
46 1
222 0
2
0 57 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut38
3
0 0
46 1
223 0
2
0 59 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut39
3
0 0
46 1
224 0
2
0 61 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
46 1
225 0
2
0 63 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut40
3
0 0
46 1
226 0
2
0 65 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut41
3
0 0
46 1
227 0
2
0 67 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut42
3
0 0
46 1
228 0
2
0 69 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut43
3
0 0
46 1
229 0
2
0 71 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut44
3
0 0
46 1
230 0
2
0 73 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut45
3
0 0
46 1
231 0
2
0 75 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut46
3
0 0
46 1
232 0
2
0 77 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut47
3
0 0
46 1
233 0
2
0 79 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut48
3
0 0
46 1
234 0
2
0 81 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut49
3
0 0
46 1
235 0
2
0 83 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
46 1
236 0
2
0 85 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut50
3
0 0
46 1
237 0
2
0 87 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
46 1
238 0
2
0 89 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
46 1
239 0
2
0 91 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
46 1
240 0
2
0 93 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
46 1
241 0
2
0 95 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
48 1
192 0
2
0 1 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
48 1
193 0
2
0 2 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
48 1
194 0
2
0 3 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
48 1
195 0
2
0 4 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
48 1
196 0
2
0 5 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
48 1
197 0
2
0 7 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
48 1
198 0
2
0 9 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
48 1
199 0
2
0 11 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
48 1
200 0
2
0 13 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
48 1
201 0
2
0 15 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
48 1
202 0
2
0 17 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
48 1
203 0
2
0 19 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
48 1
204 0
2
0 21 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
48 1
205 0
2
0 23 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
48 1
206 0
2
0 25 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
48 1
207 0
2
0 27 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
48 1
208 0
2
0 29 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
48 1
209 0
2
0 31 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
48 1
210 0
2
0 33 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
48 1
211 0
2
0 35 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
48 1
212 0
2
0 37 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
48 1
213 0
2
0 39 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
48 1
214 0
2
0 41 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
48 1
215 0
2
0 43 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut31
3
0 0
48 1
216 0
2
0 45 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut32
3
0 0
48 1
217 0
2
0 47 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut33
3
0 0
48 1
218 0
2
0 49 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut34
3
0 0
48 1
219 0
2
0 51 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut35
3
0 0
48 1
220 0
2
0 53 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut36
3
0 0
48 1
221 0
2
0 55 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut37
3
0 0
48 1
222 0
2
0 57 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut38
3
0 0
48 1
223 0
2
0 59 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut39
3
0 0
48 1
224 0
2
0 61 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
48 1
225 0
2
0 63 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut40
3
0 0
48 1
226 0
2
0 65 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut41
3
0 0
48 1
227 0
2
0 67 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut42
3
0 0
48 1
228 0
2
0 69 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut43
3
0 0
48 1
229 0
2
0 71 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut44
3
0 0
48 1
230 0
2
0 73 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut45
3
0 0
48 1
231 0
2
0 75 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut46
3
0 0
48 1
232 0
2
0 77 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut47
3
0 0
48 1
233 0
2
0 79 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut48
3
0 0
48 1
234 0
2
0 81 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut49
3
0 0
48 1
235 0
2
0 83 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
48 1
236 0
2
0 85 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut50
3
0 0
48 1
237 0
2
0 87 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
48 1
238 0
2
0 89 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
48 1
239 0
2
0 91 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
48 1
240 0
2
0 93 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
48 1
241 0
2
0 95 0 1
0 263 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
50 1
192 0
2
0 1 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
50 1
193 0
2
0 2 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
50 1
194 0
2
0 3 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
50 1
195 0
2
0 4 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
50 1
196 0
2
0 5 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
50 1
197 0
2
0 7 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
50 1
198 0
2
0 9 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
50 1
199 0
2
0 11 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
50 1
200 0
2
0 13 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
50 1
201 0
2
0 15 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
50 1
202 0
2
0 17 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
50 1
203 0
2
0 19 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
50 1
204 0
2
0 21 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
50 1
205 0
2
0 23 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
50 1
206 0
2
0 25 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
50 1
207 0
2
0 27 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
50 1
208 0
2
0 29 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
50 1
209 0
2
0 31 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
50 1
210 0
2
0 33 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
50 1
211 0
2
0 35 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
50 1
212 0
2
0 37 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
50 1
213 0
2
0 39 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
50 1
214 0
2
0 41 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
50 1
215 0
2
0 43 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut31
3
0 0
50 1
216 0
2
0 45 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut32
3
0 0
50 1
217 0
2
0 47 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut33
3
0 0
50 1
218 0
2
0 49 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut34
3
0 0
50 1
219 0
2
0 51 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut35
3
0 0
50 1
220 0
2
0 53 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut36
3
0 0
50 1
221 0
2
0 55 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut37
3
0 0
50 1
222 0
2
0 57 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut38
3
0 0
50 1
223 0
2
0 59 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut39
3
0 0
50 1
224 0
2
0 61 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
50 1
225 0
2
0 63 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut40
3
0 0
50 1
226 0
2
0 65 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut41
3
0 0
50 1
227 0
2
0 67 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut42
3
0 0
50 1
228 0
2
0 69 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut43
3
0 0
50 1
229 0
2
0 71 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut44
3
0 0
50 1
230 0
2
0 73 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut45
3
0 0
50 1
231 0
2
0 75 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut46
3
0 0
50 1
232 0
2
0 77 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut47
3
0 0
50 1
233 0
2
0 79 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut48
3
0 0
50 1
234 0
2
0 81 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut49
3
0 0
50 1
235 0
2
0 83 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
50 1
236 0
2
0 85 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut50
3
0 0
50 1
237 0
2
0 87 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
50 1
238 0
2
0 89 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
50 1
239 0
2
0 91 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
50 1
240 0
2
0 93 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
50 1
241 0
2
0 95 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
52 1
192 0
2
0 1 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
52 1
193 0
2
0 2 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
52 1
194 0
2
0 3 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
52 1
195 0
2
0 4 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
52 1
196 0
2
0 5 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
52 1
197 0
2
0 7 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
52 1
198 0
2
0 9 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
52 1
199 0
2
0 11 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
52 1
200 0
2
0 13 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
52 1
201 0
2
0 15 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
52 1
202 0
2
0 17 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
52 1
203 0
2
0 19 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
52 1
204 0
2
0 21 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
52 1
205 0
2
0 23 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
52 1
206 0
2
0 25 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
52 1
207 0
2
0 27 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
52 1
208 0
2
0 29 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
52 1
209 0
2
0 31 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
52 1
210 0
2
0 33 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
52 1
211 0
2
0 35 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
52 1
212 0
2
0 37 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
52 1
213 0
2
0 39 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
52 1
214 0
2
0 41 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
52 1
215 0
2
0 43 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut31
3
0 0
52 1
216 0
2
0 45 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut32
3
0 0
52 1
217 0
2
0 47 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut33
3
0 0
52 1
218 0
2
0 49 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut34
3
0 0
52 1
219 0
2
0 51 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut35
3
0 0
52 1
220 0
2
0 53 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut36
3
0 0
52 1
221 0
2
0 55 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut37
3
0 0
52 1
222 0
2
0 57 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut38
3
0 0
52 1
223 0
2
0 59 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut39
3
0 0
52 1
224 0
2
0 61 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
52 1
225 0
2
0 63 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut40
3
0 0
52 1
226 0
2
0 65 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut41
3
0 0
52 1
227 0
2
0 67 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut42
3
0 0
52 1
228 0
2
0 69 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut43
3
0 0
52 1
229 0
2
0 71 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut44
3
0 0
52 1
230 0
2
0 73 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut45
3
0 0
52 1
231 0
2
0 75 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut46
3
0 0
52 1
232 0
2
0 77 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut47
3
0 0
52 1
233 0
2
0 79 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut48
3
0 0
52 1
234 0
2
0 81 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut49
3
0 0
52 1
235 0
2
0 83 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
52 1
236 0
2
0 85 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut50
3
0 0
52 1
237 0
2
0 87 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
52 1
238 0
2
0 89 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
52 1
239 0
2
0 91 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
52 1
240 0
2
0 93 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
52 1
241 0
2
0 95 0 1
0 265 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
54 1
192 0
2
0 1 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
54 1
193 0
2
0 2 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
54 1
194 0
2
0 3 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
54 1
195 0
2
0 4 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
54 1
196 0
2
0 5 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
54 1
197 0
2
0 7 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
54 1
198 0
2
0 9 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
54 1
199 0
2
0 11 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
54 1
200 0
2
0 13 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
54 1
201 0
2
0 15 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
54 1
202 0
2
0 17 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
54 1
203 0
2
0 19 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
54 1
204 0
2
0 21 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
54 1
205 0
2
0 23 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
54 1
206 0
2
0 25 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
54 1
207 0
2
0 27 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
54 1
208 0
2
0 29 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
54 1
209 0
2
0 31 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
54 1
210 0
2
0 33 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
54 1
211 0
2
0 35 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
54 1
212 0
2
0 37 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
54 1
213 0
2
0 39 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
54 1
214 0
2
0 41 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
54 1
215 0
2
0 43 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut31
3
0 0
54 1
216 0
2
0 45 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut32
3
0 0
54 1
217 0
2
0 47 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut33
3
0 0
54 1
218 0
2
0 49 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut34
3
0 0
54 1
219 0
2
0 51 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut35
3
0 0
54 1
220 0
2
0 53 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut36
3
0 0
54 1
221 0
2
0 55 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut37
3
0 0
54 1
222 0
2
0 57 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut38
3
0 0
54 1
223 0
2
0 59 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut39
3
0 0
54 1
224 0
2
0 61 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
54 1
225 0
2
0 63 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut40
3
0 0
54 1
226 0
2
0 65 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut41
3
0 0
54 1
227 0
2
0 67 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut42
3
0 0
54 1
228 0
2
0 69 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut43
3
0 0
54 1
229 0
2
0 71 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut44
3
0 0
54 1
230 0
2
0 73 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut45
3
0 0
54 1
231 0
2
0 75 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut46
3
0 0
54 1
232 0
2
0 77 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut47
3
0 0
54 1
233 0
2
0 79 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut48
3
0 0
54 1
234 0
2
0 81 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut49
3
0 0
54 1
235 0
2
0 83 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
54 1
236 0
2
0 85 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut50
3
0 0
54 1
237 0
2
0 87 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
54 1
238 0
2
0 89 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
54 1
239 0
2
0 91 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
54 1
240 0
2
0 93 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
54 1
241 0
2
0 95 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
56 1
192 0
2
0 1 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
56 1
193 0
2
0 2 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
56 1
194 0
2
0 3 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
56 1
195 0
2
0 4 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
56 1
196 0
2
0 5 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
56 1
197 0
2
0 7 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
56 1
198 0
2
0 9 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
56 1
199 0
2
0 11 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
56 1
200 0
2
0 13 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
56 1
201 0
2
0 15 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
56 1
202 0
2
0 17 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
56 1
203 0
2
0 19 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
56 1
204 0
2
0 21 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
56 1
205 0
2
0 23 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
56 1
206 0
2
0 25 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
56 1
207 0
2
0 27 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
56 1
208 0
2
0 29 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
56 1
209 0
2
0 31 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
56 1
210 0
2
0 33 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
56 1
211 0
2
0 35 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
56 1
212 0
2
0 37 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
56 1
213 0
2
0 39 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
56 1
214 0
2
0 41 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
56 1
215 0
2
0 43 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut31
3
0 0
56 1
216 0
2
0 45 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut32
3
0 0
56 1
217 0
2
0 47 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut33
3
0 0
56 1
218 0
2
0 49 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut34
3
0 0
56 1
219 0
2
0 51 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut35
3
0 0
56 1
220 0
2
0 53 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut36
3
0 0
56 1
221 0
2
0 55 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut37
3
0 0
56 1
222 0
2
0 57 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut38
3
0 0
56 1
223 0
2
0 59 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut39
3
0 0
56 1
224 0
2
0 61 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
56 1
225 0
2
0 63 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut40
3
0 0
56 1
226 0
2
0 65 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut41
3
0 0
56 1
227 0
2
0 67 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut42
3
0 0
56 1
228 0
2
0 69 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut43
3
0 0
56 1
229 0
2
0 71 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut44
3
0 0
56 1
230 0
2
0 73 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut45
3
0 0
56 1
231 0
2
0 75 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut46
3
0 0
56 1
232 0
2
0 77 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut47
3
0 0
56 1
233 0
2
0 79 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut48
3
0 0
56 1
234 0
2
0 81 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut49
3
0 0
56 1
235 0
2
0 83 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
56 1
236 0
2
0 85 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut50
3
0 0
56 1
237 0
2
0 87 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
56 1
238 0
2
0 89 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
56 1
239 0
2
0 91 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
56 1
240 0
2
0 93 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
56 1
241 0
2
0 95 0 1
0 267 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
58 1
192 0
2
0 1 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
58 1
193 0
2
0 2 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
58 1
194 0
2
0 3 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
58 1
195 0
2
0 4 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
58 1
196 0
2
0 5 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
58 1
197 0
2
0 7 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
58 1
198 0
2
0 9 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
58 1
199 0
2
0 11 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
58 1
200 0
2
0 13 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
58 1
201 0
2
0 15 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
58 1
202 0
2
0 17 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
58 1
203 0
2
0 19 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
58 1
204 0
2
0 21 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
58 1
205 0
2
0 23 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
58 1
206 0
2
0 25 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
58 1
207 0
2
0 27 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
58 1
208 0
2
0 29 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
58 1
209 0
2
0 31 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
58 1
210 0
2
0 33 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
58 1
211 0
2
0 35 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
58 1
212 0
2
0 37 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
58 1
213 0
2
0 39 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
58 1
214 0
2
0 41 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
58 1
215 0
2
0 43 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut31
3
0 0
58 1
216 0
2
0 45 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut32
3
0 0
58 1
217 0
2
0 47 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut33
3
0 0
58 1
218 0
2
0 49 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut34
3
0 0
58 1
219 0
2
0 51 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut35
3
0 0
58 1
220 0
2
0 53 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut36
3
0 0
58 1
221 0
2
0 55 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut37
3
0 0
58 1
222 0
2
0 57 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut38
3
0 0
58 1
223 0
2
0 59 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut39
3
0 0
58 1
224 0
2
0 61 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
58 1
225 0
2
0 63 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut40
3
0 0
58 1
226 0
2
0 65 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut41
3
0 0
58 1
227 0
2
0 67 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut42
3
0 0
58 1
228 0
2
0 69 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut43
3
0 0
58 1
229 0
2
0 71 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut44
3
0 0
58 1
230 0
2
0 73 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut45
3
0 0
58 1
231 0
2
0 75 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut46
3
0 0
58 1
232 0
2
0 77 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut47
3
0 0
58 1
233 0
2
0 79 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut48
3
0 0
58 1
234 0
2
0 81 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut49
3
0 0
58 1
235 0
2
0 83 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
58 1
236 0
2
0 85 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut50
3
0 0
58 1
237 0
2
0 87 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
58 1
238 0
2
0 89 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
58 1
239 0
2
0 91 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
58 1
240 0
2
0 93 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
58 1
241 0
2
0 95 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
60 1
192 0
2
0 1 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
60 1
193 0
2
0 2 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
60 1
194 0
2
0 3 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
60 1
195 0
2
0 4 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
60 1
196 0
2
0 5 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
60 1
197 0
2
0 7 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
60 1
198 0
2
0 9 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
60 1
199 0
2
0 11 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
60 1
200 0
2
0 13 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
60 1
201 0
2
0 15 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
60 1
202 0
2
0 17 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
60 1
203 0
2
0 19 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
60 1
204 0
2
0 21 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
60 1
205 0
2
0 23 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
60 1
206 0
2
0 25 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
60 1
207 0
2
0 27 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
60 1
208 0
2
0 29 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
60 1
209 0
2
0 31 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
60 1
210 0
2
0 33 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
60 1
211 0
2
0 35 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
60 1
212 0
2
0 37 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
60 1
213 0
2
0 39 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
60 1
214 0
2
0 41 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
60 1
215 0
2
0 43 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut31
3
0 0
60 1
216 0
2
0 45 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut32
3
0 0
60 1
217 0
2
0 47 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut33
3
0 0
60 1
218 0
2
0 49 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut34
3
0 0
60 1
219 0
2
0 51 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut35
3
0 0
60 1
220 0
2
0 53 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut36
3
0 0
60 1
221 0
2
0 55 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut37
3
0 0
60 1
222 0
2
0 57 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut38
3
0 0
60 1
223 0
2
0 59 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut39
3
0 0
60 1
224 0
2
0 61 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
60 1
225 0
2
0 63 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut40
3
0 0
60 1
226 0
2
0 65 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut41
3
0 0
60 1
227 0
2
0 67 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut42
3
0 0
60 1
228 0
2
0 69 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut43
3
0 0
60 1
229 0
2
0 71 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut44
3
0 0
60 1
230 0
2
0 73 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut45
3
0 0
60 1
231 0
2
0 75 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut46
3
0 0
60 1
232 0
2
0 77 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut47
3
0 0
60 1
233 0
2
0 79 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut48
3
0 0
60 1
234 0
2
0 81 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut49
3
0 0
60 1
235 0
2
0 83 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
60 1
236 0
2
0 85 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut50
3
0 0
60 1
237 0
2
0 87 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
60 1
238 0
2
0 89 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
60 1
239 0
2
0 91 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
60 1
240 0
2
0 93 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
60 1
241 0
2
0 95 0 1
0 269 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
62 1
192 0
2
0 1 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
62 1
193 0
2
0 2 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
62 1
194 0
2
0 3 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
62 1
195 0
2
0 4 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
62 1
196 0
2
0 5 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
62 1
197 0
2
0 7 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
62 1
198 0
2
0 9 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
62 1
199 0
2
0 11 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
62 1
200 0
2
0 13 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
62 1
201 0
2
0 15 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
62 1
202 0
2
0 17 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
62 1
203 0
2
0 19 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
62 1
204 0
2
0 21 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
62 1
205 0
2
0 23 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
62 1
206 0
2
0 25 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
62 1
207 0
2
0 27 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
62 1
208 0
2
0 29 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
62 1
209 0
2
0 31 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
62 1
210 0
2
0 33 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
62 1
211 0
2
0 35 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
62 1
212 0
2
0 37 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
62 1
213 0
2
0 39 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
62 1
214 0
2
0 41 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
62 1
215 0
2
0 43 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut31
3
0 0
62 1
216 0
2
0 45 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut32
3
0 0
62 1
217 0
2
0 47 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut33
3
0 0
62 1
218 0
2
0 49 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut34
3
0 0
62 1
219 0
2
0 51 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut35
3
0 0
62 1
220 0
2
0 53 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut36
3
0 0
62 1
221 0
2
0 55 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut37
3
0 0
62 1
222 0
2
0 57 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut38
3
0 0
62 1
223 0
2
0 59 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut39
3
0 0
62 1
224 0
2
0 61 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
62 1
225 0
2
0 63 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut40
3
0 0
62 1
226 0
2
0 65 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut41
3
0 0
62 1
227 0
2
0 67 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut42
3
0 0
62 1
228 0
2
0 69 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut43
3
0 0
62 1
229 0
2
0 71 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut44
3
0 0
62 1
230 0
2
0 73 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut45
3
0 0
62 1
231 0
2
0 75 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut46
3
0 0
62 1
232 0
2
0 77 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut47
3
0 0
62 1
233 0
2
0 79 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut48
3
0 0
62 1
234 0
2
0 81 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut49
3
0 0
62 1
235 0
2
0 83 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
62 1
236 0
2
0 85 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut50
3
0 0
62 1
237 0
2
0 87 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
62 1
238 0
2
0 89 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
62 1
239 0
2
0 91 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
62 1
240 0
2
0 93 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
62 1
241 0
2
0 95 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
64 1
192 0
2
0 1 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
64 1
193 0
2
0 2 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
64 1
194 0
2
0 3 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
64 1
195 0
2
0 4 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
64 1
196 0
2
0 5 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
64 1
197 0
2
0 7 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
64 1
198 0
2
0 9 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
64 1
199 0
2
0 11 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
64 1
200 0
2
0 13 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
64 1
201 0
2
0 15 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
64 1
202 0
2
0 17 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
64 1
203 0
2
0 19 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
64 1
204 0
2
0 21 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
64 1
205 0
2
0 23 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
64 1
206 0
2
0 25 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
64 1
207 0
2
0 27 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
64 1
208 0
2
0 29 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
64 1
209 0
2
0 31 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
64 1
210 0
2
0 33 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
64 1
211 0
2
0 35 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
64 1
212 0
2
0 37 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
64 1
213 0
2
0 39 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
64 1
214 0
2
0 41 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
64 1
215 0
2
0 43 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut31
3
0 0
64 1
216 0
2
0 45 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut32
3
0 0
64 1
217 0
2
0 47 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut33
3
0 0
64 1
218 0
2
0 49 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut34
3
0 0
64 1
219 0
2
0 51 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut35
3
0 0
64 1
220 0
2
0 53 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut36
3
0 0
64 1
221 0
2
0 55 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut37
3
0 0
64 1
222 0
2
0 57 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut38
3
0 0
64 1
223 0
2
0 59 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut39
3
0 0
64 1
224 0
2
0 61 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
64 1
225 0
2
0 63 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut40
3
0 0
64 1
226 0
2
0 65 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut41
3
0 0
64 1
227 0
2
0 67 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut42
3
0 0
64 1
228 0
2
0 69 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut43
3
0 0
64 1
229 0
2
0 71 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut44
3
0 0
64 1
230 0
2
0 73 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut45
3
0 0
64 1
231 0
2
0 75 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut46
3
0 0
64 1
232 0
2
0 77 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut47
3
0 0
64 1
233 0
2
0 79 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut48
3
0 0
64 1
234 0
2
0 81 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut49
3
0 0
64 1
235 0
2
0 83 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
64 1
236 0
2
0 85 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut50
3
0 0
64 1
237 0
2
0 87 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
64 1
238 0
2
0 89 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
64 1
239 0
2
0 91 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
64 1
240 0
2
0 93 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
64 1
241 0
2
0 95 0 1
0 271 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
66 1
192 0
2
0 1 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
66 1
193 0
2
0 2 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
66 1
194 0
2
0 3 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
66 1
195 0
2
0 4 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
66 1
196 0
2
0 5 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
66 1
197 0
2
0 7 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
66 1
198 0
2
0 9 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
66 1
199 0
2
0 11 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
66 1
200 0
2
0 13 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
66 1
201 0
2
0 15 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
66 1
202 0
2
0 17 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
66 1
203 0
2
0 19 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
66 1
204 0
2
0 21 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
66 1
205 0
2
0 23 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
66 1
206 0
2
0 25 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
66 1
207 0
2
0 27 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
66 1
208 0
2
0 29 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
66 1
209 0
2
0 31 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
66 1
210 0
2
0 33 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
66 1
211 0
2
0 35 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
66 1
212 0
2
0 37 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
66 1
213 0
2
0 39 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
66 1
214 0
2
0 41 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
66 1
215 0
2
0 43 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut31
3
0 0
66 1
216 0
2
0 45 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut32
3
0 0
66 1
217 0
2
0 47 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut33
3
0 0
66 1
218 0
2
0 49 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut34
3
0 0
66 1
219 0
2
0 51 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut35
3
0 0
66 1
220 0
2
0 53 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut36
3
0 0
66 1
221 0
2
0 55 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut37
3
0 0
66 1
222 0
2
0 57 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut38
3
0 0
66 1
223 0
2
0 59 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut39
3
0 0
66 1
224 0
2
0 61 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
66 1
225 0
2
0 63 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut40
3
0 0
66 1
226 0
2
0 65 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut41
3
0 0
66 1
227 0
2
0 67 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut42
3
0 0
66 1
228 0
2
0 69 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut43
3
0 0
66 1
229 0
2
0 71 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut44
3
0 0
66 1
230 0
2
0 73 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut45
3
0 0
66 1
231 0
2
0 75 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut46
3
0 0
66 1
232 0
2
0 77 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut47
3
0 0
66 1
233 0
2
0 79 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut48
3
0 0
66 1
234 0
2
0 81 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut49
3
0 0
66 1
235 0
2
0 83 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
66 1
236 0
2
0 85 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut50
3
0 0
66 1
237 0
2
0 87 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
66 1
238 0
2
0 89 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
66 1
239 0
2
0 91 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
66 1
240 0
2
0 93 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
66 1
241 0
2
0 95 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
68 1
192 0
2
0 1 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
68 1
193 0
2
0 2 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
68 1
194 0
2
0 3 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
68 1
195 0
2
0 4 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
68 1
196 0
2
0 5 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
68 1
197 0
2
0 7 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
68 1
198 0
2
0 9 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
68 1
199 0
2
0 11 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
68 1
200 0
2
0 13 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
68 1
201 0
2
0 15 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
68 1
202 0
2
0 17 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
68 1
203 0
2
0 19 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
68 1
204 0
2
0 21 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
68 1
205 0
2
0 23 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
68 1
206 0
2
0 25 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
68 1
207 0
2
0 27 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
68 1
208 0
2
0 29 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
68 1
209 0
2
0 31 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
68 1
210 0
2
0 33 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
68 1
211 0
2
0 35 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
68 1
212 0
2
0 37 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
68 1
213 0
2
0 39 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
68 1
214 0
2
0 41 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
68 1
215 0
2
0 43 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut31
3
0 0
68 1
216 0
2
0 45 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut32
3
0 0
68 1
217 0
2
0 47 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut33
3
0 0
68 1
218 0
2
0 49 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut34
3
0 0
68 1
219 0
2
0 51 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut35
3
0 0
68 1
220 0
2
0 53 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut36
3
0 0
68 1
221 0
2
0 55 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut37
3
0 0
68 1
222 0
2
0 57 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut38
3
0 0
68 1
223 0
2
0 59 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut39
3
0 0
68 1
224 0
2
0 61 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
68 1
225 0
2
0 63 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut40
3
0 0
68 1
226 0
2
0 65 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut41
3
0 0
68 1
227 0
2
0 67 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut42
3
0 0
68 1
228 0
2
0 69 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut43
3
0 0
68 1
229 0
2
0 71 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut44
3
0 0
68 1
230 0
2
0 73 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut45
3
0 0
68 1
231 0
2
0 75 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut46
3
0 0
68 1
232 0
2
0 77 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut47
3
0 0
68 1
233 0
2
0 79 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut48
3
0 0
68 1
234 0
2
0 81 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut49
3
0 0
68 1
235 0
2
0 83 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
68 1
236 0
2
0 85 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut50
3
0 0
68 1
237 0
2
0 87 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
68 1
238 0
2
0 89 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
68 1
239 0
2
0 91 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
68 1
240 0
2
0 93 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
68 1
241 0
2
0 95 0 1
0 273 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
70 1
192 0
2
0 1 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
70 1
193 0
2
0 2 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
70 1
194 0
2
0 3 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
70 1
195 0
2
0 4 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
70 1
196 0
2
0 5 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
70 1
197 0
2
0 7 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
70 1
198 0
2
0 9 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
70 1
199 0
2
0 11 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
70 1
200 0
2
0 13 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
70 1
201 0
2
0 15 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
70 1
202 0
2
0 17 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
70 1
203 0
2
0 19 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
70 1
204 0
2
0 21 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
70 1
205 0
2
0 23 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
70 1
206 0
2
0 25 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
70 1
207 0
2
0 27 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
70 1
208 0
2
0 29 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
70 1
209 0
2
0 31 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
70 1
210 0
2
0 33 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
70 1
211 0
2
0 35 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
70 1
212 0
2
0 37 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
70 1
213 0
2
0 39 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
70 1
214 0
2
0 41 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
70 1
215 0
2
0 43 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut31
3
0 0
70 1
216 0
2
0 45 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut32
3
0 0
70 1
217 0
2
0 47 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut33
3
0 0
70 1
218 0
2
0 49 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut34
3
0 0
70 1
219 0
2
0 51 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut35
3
0 0
70 1
220 0
2
0 53 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut36
3
0 0
70 1
221 0
2
0 55 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut37
3
0 0
70 1
222 0
2
0 57 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut38
3
0 0
70 1
223 0
2
0 59 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut39
3
0 0
70 1
224 0
2
0 61 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
70 1
225 0
2
0 63 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut40
3
0 0
70 1
226 0
2
0 65 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut41
3
0 0
70 1
227 0
2
0 67 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut42
3
0 0
70 1
228 0
2
0 69 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut43
3
0 0
70 1
229 0
2
0 71 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut44
3
0 0
70 1
230 0
2
0 73 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut45
3
0 0
70 1
231 0
2
0 75 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut46
3
0 0
70 1
232 0
2
0 77 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut47
3
0 0
70 1
233 0
2
0 79 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut48
3
0 0
70 1
234 0
2
0 81 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut49
3
0 0
70 1
235 0
2
0 83 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
70 1
236 0
2
0 85 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut50
3
0 0
70 1
237 0
2
0 87 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
70 1
238 0
2
0 89 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
70 1
239 0
2
0 91 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
70 1
240 0
2
0 93 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
70 1
241 0
2
0 95 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
72 1
192 0
2
0 1 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
72 1
193 0
2
0 2 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
72 1
194 0
2
0 3 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
72 1
195 0
2
0 4 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
72 1
196 0
2
0 5 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
72 1
197 0
2
0 7 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
72 1
198 0
2
0 9 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
72 1
199 0
2
0 11 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
72 1
200 0
2
0 13 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
72 1
201 0
2
0 15 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
72 1
202 0
2
0 17 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
72 1
203 0
2
0 19 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
72 1
204 0
2
0 21 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
72 1
205 0
2
0 23 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
72 1
206 0
2
0 25 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
72 1
207 0
2
0 27 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
72 1
208 0
2
0 29 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
72 1
209 0
2
0 31 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
72 1
210 0
2
0 33 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
72 1
211 0
2
0 35 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
72 1
212 0
2
0 37 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
72 1
213 0
2
0 39 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
72 1
214 0
2
0 41 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
72 1
215 0
2
0 43 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut31
3
0 0
72 1
216 0
2
0 45 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut32
3
0 0
72 1
217 0
2
0 47 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut33
3
0 0
72 1
218 0
2
0 49 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut34
3
0 0
72 1
219 0
2
0 51 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut35
3
0 0
72 1
220 0
2
0 53 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut36
3
0 0
72 1
221 0
2
0 55 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut37
3
0 0
72 1
222 0
2
0 57 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut38
3
0 0
72 1
223 0
2
0 59 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut39
3
0 0
72 1
224 0
2
0 61 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
72 1
225 0
2
0 63 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut40
3
0 0
72 1
226 0
2
0 65 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut41
3
0 0
72 1
227 0
2
0 67 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut42
3
0 0
72 1
228 0
2
0 69 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut43
3
0 0
72 1
229 0
2
0 71 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut44
3
0 0
72 1
230 0
2
0 73 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut45
3
0 0
72 1
231 0
2
0 75 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut46
3
0 0
72 1
232 0
2
0 77 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut47
3
0 0
72 1
233 0
2
0 79 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut48
3
0 0
72 1
234 0
2
0 81 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut49
3
0 0
72 1
235 0
2
0 83 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
72 1
236 0
2
0 85 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut50
3
0 0
72 1
237 0
2
0 87 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
72 1
238 0
2
0 89 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
72 1
239 0
2
0 91 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
72 1
240 0
2
0 93 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
72 1
241 0
2
0 95 0 1
0 275 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
74 1
192 0
2
0 1 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
74 1
193 0
2
0 2 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
74 1
194 0
2
0 3 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
74 1
195 0
2
0 4 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
74 1
196 0
2
0 5 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
74 1
197 0
2
0 7 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
74 1
198 0
2
0 9 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
74 1
199 0
2
0 11 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
74 1
200 0
2
0 13 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
74 1
201 0
2
0 15 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
74 1
202 0
2
0 17 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
74 1
203 0
2
0 19 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
74 1
204 0
2
0 21 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
74 1
205 0
2
0 23 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
74 1
206 0
2
0 25 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
74 1
207 0
2
0 27 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
74 1
208 0
2
0 29 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
74 1
209 0
2
0 31 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
74 1
210 0
2
0 33 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
74 1
211 0
2
0 35 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
74 1
212 0
2
0 37 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
74 1
213 0
2
0 39 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
74 1
214 0
2
0 41 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
74 1
215 0
2
0 43 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut31
3
0 0
74 1
216 0
2
0 45 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut32
3
0 0
74 1
217 0
2
0 47 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut33
3
0 0
74 1
218 0
2
0 49 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut34
3
0 0
74 1
219 0
2
0 51 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut35
3
0 0
74 1
220 0
2
0 53 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut36
3
0 0
74 1
221 0
2
0 55 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut37
3
0 0
74 1
222 0
2
0 57 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut38
3
0 0
74 1
223 0
2
0 59 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut39
3
0 0
74 1
224 0
2
0 61 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
74 1
225 0
2
0 63 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut40
3
0 0
74 1
226 0
2
0 65 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut41
3
0 0
74 1
227 0
2
0 67 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut42
3
0 0
74 1
228 0
2
0 69 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut43
3
0 0
74 1
229 0
2
0 71 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut44
3
0 0
74 1
230 0
2
0 73 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut45
3
0 0
74 1
231 0
2
0 75 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut46
3
0 0
74 1
232 0
2
0 77 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut47
3
0 0
74 1
233 0
2
0 79 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut48
3
0 0
74 1
234 0
2
0 81 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut49
3
0 0
74 1
235 0
2
0 83 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
74 1
236 0
2
0 85 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut50
3
0 0
74 1
237 0
2
0 87 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
74 1
238 0
2
0 89 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
74 1
239 0
2
0 91 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
74 1
240 0
2
0 93 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
74 1
241 0
2
0 95 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
76 1
192 0
2
0 1 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
76 1
193 0
2
0 2 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
76 1
194 0
2
0 3 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
76 1
195 0
2
0 4 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
76 1
196 0
2
0 5 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
76 1
197 0
2
0 7 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
76 1
198 0
2
0 9 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
76 1
199 0
2
0 11 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
76 1
200 0
2
0 13 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
76 1
201 0
2
0 15 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
76 1
202 0
2
0 17 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
76 1
203 0
2
0 19 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
76 1
204 0
2
0 21 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
76 1
205 0
2
0 23 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
76 1
206 0
2
0 25 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
76 1
207 0
2
0 27 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
76 1
208 0
2
0 29 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
76 1
209 0
2
0 31 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
76 1
210 0
2
0 33 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
76 1
211 0
2
0 35 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
76 1
212 0
2
0 37 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
76 1
213 0
2
0 39 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
76 1
214 0
2
0 41 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
76 1
215 0
2
0 43 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut31
3
0 0
76 1
216 0
2
0 45 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut32
3
0 0
76 1
217 0
2
0 47 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut33
3
0 0
76 1
218 0
2
0 49 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut34
3
0 0
76 1
219 0
2
0 51 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut35
3
0 0
76 1
220 0
2
0 53 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut36
3
0 0
76 1
221 0
2
0 55 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut37
3
0 0
76 1
222 0
2
0 57 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut38
3
0 0
76 1
223 0
2
0 59 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut39
3
0 0
76 1
224 0
2
0 61 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
76 1
225 0
2
0 63 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut40
3
0 0
76 1
226 0
2
0 65 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut41
3
0 0
76 1
227 0
2
0 67 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut42
3
0 0
76 1
228 0
2
0 69 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut43
3
0 0
76 1
229 0
2
0 71 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut44
3
0 0
76 1
230 0
2
0 73 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut45
3
0 0
76 1
231 0
2
0 75 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut46
3
0 0
76 1
232 0
2
0 77 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut47
3
0 0
76 1
233 0
2
0 79 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut48
3
0 0
76 1
234 0
2
0 81 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut49
3
0 0
76 1
235 0
2
0 83 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
76 1
236 0
2
0 85 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut50
3
0 0
76 1
237 0
2
0 87 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
76 1
238 0
2
0 89 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
76 1
239 0
2
0 91 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
76 1
240 0
2
0 93 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
76 1
241 0
2
0 95 0 1
0 277 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
78 1
192 0
2
0 1 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
78 1
193 0
2
0 2 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
78 1
194 0
2
0 3 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
78 1
195 0
2
0 4 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
78 1
196 0
2
0 5 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
78 1
197 0
2
0 7 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
78 1
198 0
2
0 9 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
78 1
199 0
2
0 11 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
78 1
200 0
2
0 13 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
78 1
201 0
2
0 15 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
78 1
202 0
2
0 17 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
78 1
203 0
2
0 19 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
78 1
204 0
2
0 21 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
78 1
205 0
2
0 23 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
78 1
206 0
2
0 25 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
78 1
207 0
2
0 27 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
78 1
208 0
2
0 29 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
78 1
209 0
2
0 31 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
78 1
210 0
2
0 33 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
78 1
211 0
2
0 35 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
78 1
212 0
2
0 37 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
78 1
213 0
2
0 39 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
78 1
214 0
2
0 41 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
78 1
215 0
2
0 43 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut31
3
0 0
78 1
216 0
2
0 45 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut32
3
0 0
78 1
217 0
2
0 47 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut33
3
0 0
78 1
218 0
2
0 49 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut34
3
0 0
78 1
219 0
2
0 51 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut35
3
0 0
78 1
220 0
2
0 53 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut36
3
0 0
78 1
221 0
2
0 55 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut37
3
0 0
78 1
222 0
2
0 57 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut38
3
0 0
78 1
223 0
2
0 59 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut39
3
0 0
78 1
224 0
2
0 61 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
78 1
225 0
2
0 63 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut40
3
0 0
78 1
226 0
2
0 65 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut41
3
0 0
78 1
227 0
2
0 67 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut42
3
0 0
78 1
228 0
2
0 69 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut43
3
0 0
78 1
229 0
2
0 71 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut44
3
0 0
78 1
230 0
2
0 73 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut45
3
0 0
78 1
231 0
2
0 75 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut46
3
0 0
78 1
232 0
2
0 77 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut47
3
0 0
78 1
233 0
2
0 79 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut48
3
0 0
78 1
234 0
2
0 81 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut49
3
0 0
78 1
235 0
2
0 83 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
78 1
236 0
2
0 85 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut50
3
0 0
78 1
237 0
2
0 87 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
78 1
238 0
2
0 89 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
78 1
239 0
2
0 91 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
78 1
240 0
2
0 93 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
78 1
241 0
2
0 95 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
80 1
192 0
2
0 1 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
80 1
193 0
2
0 2 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
80 1
194 0
2
0 3 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
80 1
195 0
2
0 4 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
80 1
196 0
2
0 5 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
80 1
197 0
2
0 7 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
80 1
198 0
2
0 9 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
80 1
199 0
2
0 11 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
80 1
200 0
2
0 13 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
80 1
201 0
2
0 15 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
80 1
202 0
2
0 17 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
80 1
203 0
2
0 19 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
80 1
204 0
2
0 21 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
80 1
205 0
2
0 23 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
80 1
206 0
2
0 25 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
80 1
207 0
2
0 27 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
80 1
208 0
2
0 29 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
80 1
209 0
2
0 31 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
80 1
210 0
2
0 33 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
80 1
211 0
2
0 35 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
80 1
212 0
2
0 37 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
80 1
213 0
2
0 39 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
80 1
214 0
2
0 41 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
80 1
215 0
2
0 43 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut31
3
0 0
80 1
216 0
2
0 45 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut32
3
0 0
80 1
217 0
2
0 47 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut33
3
0 0
80 1
218 0
2
0 49 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut34
3
0 0
80 1
219 0
2
0 51 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut35
3
0 0
80 1
220 0
2
0 53 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut36
3
0 0
80 1
221 0
2
0 55 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut37
3
0 0
80 1
222 0
2
0 57 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut38
3
0 0
80 1
223 0
2
0 59 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut39
3
0 0
80 1
224 0
2
0 61 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
80 1
225 0
2
0 63 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut40
3
0 0
80 1
226 0
2
0 65 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut41
3
0 0
80 1
227 0
2
0 67 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut42
3
0 0
80 1
228 0
2
0 69 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut43
3
0 0
80 1
229 0
2
0 71 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut44
3
0 0
80 1
230 0
2
0 73 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut45
3
0 0
80 1
231 0
2
0 75 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut46
3
0 0
80 1
232 0
2
0 77 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut47
3
0 0
80 1
233 0
2
0 79 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut48
3
0 0
80 1
234 0
2
0 81 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut49
3
0 0
80 1
235 0
2
0 83 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
80 1
236 0
2
0 85 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut50
3
0 0
80 1
237 0
2
0 87 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
80 1
238 0
2
0 89 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
80 1
239 0
2
0 91 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
80 1
240 0
2
0 93 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
80 1
241 0
2
0 95 0 1
0 279 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
82 1
192 0
2
0 1 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
82 1
193 0
2
0 2 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
82 1
194 0
2
0 3 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
82 1
195 0
2
0 4 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
82 1
196 0
2
0 5 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
82 1
197 0
2
0 7 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
82 1
198 0
2
0 9 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
82 1
199 0
2
0 11 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
82 1
200 0
2
0 13 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
82 1
201 0
2
0 15 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
82 1
202 0
2
0 17 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
82 1
203 0
2
0 19 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
82 1
204 0
2
0 21 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
82 1
205 0
2
0 23 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
82 1
206 0
2
0 25 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
82 1
207 0
2
0 27 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
82 1
208 0
2
0 29 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
82 1
209 0
2
0 31 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
82 1
210 0
2
0 33 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
82 1
211 0
2
0 35 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
82 1
212 0
2
0 37 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
82 1
213 0
2
0 39 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
82 1
214 0
2
0 41 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
82 1
215 0
2
0 43 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut31
3
0 0
82 1
216 0
2
0 45 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut32
3
0 0
82 1
217 0
2
0 47 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut33
3
0 0
82 1
218 0
2
0 49 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut34
3
0 0
82 1
219 0
2
0 51 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut35
3
0 0
82 1
220 0
2
0 53 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut36
3
0 0
82 1
221 0
2
0 55 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut37
3
0 0
82 1
222 0
2
0 57 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut38
3
0 0
82 1
223 0
2
0 59 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut39
3
0 0
82 1
224 0
2
0 61 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
82 1
225 0
2
0 63 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut40
3
0 0
82 1
226 0
2
0 65 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut41
3
0 0
82 1
227 0
2
0 67 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut42
3
0 0
82 1
228 0
2
0 69 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut43
3
0 0
82 1
229 0
2
0 71 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut44
3
0 0
82 1
230 0
2
0 73 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut45
3
0 0
82 1
231 0
2
0 75 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut46
3
0 0
82 1
232 0
2
0 77 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut47
3
0 0
82 1
233 0
2
0 79 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut48
3
0 0
82 1
234 0
2
0 81 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut49
3
0 0
82 1
235 0
2
0 83 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
82 1
236 0
2
0 85 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut50
3
0 0
82 1
237 0
2
0 87 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
82 1
238 0
2
0 89 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
82 1
239 0
2
0 91 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
82 1
240 0
2
0 93 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
82 1
241 0
2
0 95 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
84 1
192 0
2
0 1 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
84 1
193 0
2
0 2 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
84 1
194 0
2
0 3 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
84 1
195 0
2
0 4 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
84 1
196 0
2
0 5 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
84 1
197 0
2
0 7 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
84 1
198 0
2
0 9 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
84 1
199 0
2
0 11 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
84 1
200 0
2
0 13 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
84 1
201 0
2
0 15 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
84 1
202 0
2
0 17 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
84 1
203 0
2
0 19 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
84 1
204 0
2
0 21 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
84 1
205 0
2
0 23 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
84 1
206 0
2
0 25 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
84 1
207 0
2
0 27 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
84 1
208 0
2
0 29 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
84 1
209 0
2
0 31 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
84 1
210 0
2
0 33 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
84 1
211 0
2
0 35 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
84 1
212 0
2
0 37 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
84 1
213 0
2
0 39 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
84 1
214 0
2
0 41 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
84 1
215 0
2
0 43 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut31
3
0 0
84 1
216 0
2
0 45 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut32
3
0 0
84 1
217 0
2
0 47 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut33
3
0 0
84 1
218 0
2
0 49 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut34
3
0 0
84 1
219 0
2
0 51 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut35
3
0 0
84 1
220 0
2
0 53 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut36
3
0 0
84 1
221 0
2
0 55 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut37
3
0 0
84 1
222 0
2
0 57 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut38
3
0 0
84 1
223 0
2
0 59 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut39
3
0 0
84 1
224 0
2
0 61 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
84 1
225 0
2
0 63 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut40
3
0 0
84 1
226 0
2
0 65 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut41
3
0 0
84 1
227 0
2
0 67 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut42
3
0 0
84 1
228 0
2
0 69 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut43
3
0 0
84 1
229 0
2
0 71 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut44
3
0 0
84 1
230 0
2
0 73 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut45
3
0 0
84 1
231 0
2
0 75 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut46
3
0 0
84 1
232 0
2
0 77 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut47
3
0 0
84 1
233 0
2
0 79 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut48
3
0 0
84 1
234 0
2
0 81 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut49
3
0 0
84 1
235 0
2
0 83 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
84 1
236 0
2
0 85 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut50
3
0 0
84 1
237 0
2
0 87 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
84 1
238 0
2
0 89 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
84 1
239 0
2
0 91 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
84 1
240 0
2
0 93 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
84 1
241 0
2
0 95 0 1
0 281 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
86 1
192 0
2
0 1 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
86 1
193 0
2
0 2 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
86 1
194 0
2
0 3 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
86 1
195 0
2
0 4 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
86 1
196 0
2
0 5 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
86 1
197 0
2
0 7 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
86 1
198 0
2
0 9 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
86 1
199 0
2
0 11 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
86 1
200 0
2
0 13 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
86 1
201 0
2
0 15 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
86 1
202 0
2
0 17 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
86 1
203 0
2
0 19 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
86 1
204 0
2
0 21 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
86 1
205 0
2
0 23 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
86 1
206 0
2
0 25 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
86 1
207 0
2
0 27 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
86 1
208 0
2
0 29 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
86 1
209 0
2
0 31 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
86 1
210 0
2
0 33 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
86 1
211 0
2
0 35 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
86 1
212 0
2
0 37 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
86 1
213 0
2
0 39 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
86 1
214 0
2
0 41 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
86 1
215 0
2
0 43 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut31
3
0 0
86 1
216 0
2
0 45 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut32
3
0 0
86 1
217 0
2
0 47 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut33
3
0 0
86 1
218 0
2
0 49 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut34
3
0 0
86 1
219 0
2
0 51 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut35
3
0 0
86 1
220 0
2
0 53 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut36
3
0 0
86 1
221 0
2
0 55 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut37
3
0 0
86 1
222 0
2
0 57 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut38
3
0 0
86 1
223 0
2
0 59 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut39
3
0 0
86 1
224 0
2
0 61 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
86 1
225 0
2
0 63 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut40
3
0 0
86 1
226 0
2
0 65 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut41
3
0 0
86 1
227 0
2
0 67 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut42
3
0 0
86 1
228 0
2
0 69 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut43
3
0 0
86 1
229 0
2
0 71 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut44
3
0 0
86 1
230 0
2
0 73 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut45
3
0 0
86 1
231 0
2
0 75 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut46
3
0 0
86 1
232 0
2
0 77 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut47
3
0 0
86 1
233 0
2
0 79 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut48
3
0 0
86 1
234 0
2
0 81 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut49
3
0 0
86 1
235 0
2
0 83 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
86 1
236 0
2
0 85 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut50
3
0 0
86 1
237 0
2
0 87 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
86 1
238 0
2
0 89 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
86 1
239 0
2
0 91 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
86 1
240 0
2
0 93 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
86 1
241 0
2
0 95 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
88 1
192 0
2
0 1 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
88 1
193 0
2
0 2 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
88 1
194 0
2
0 3 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
88 1
195 0
2
0 4 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
88 1
196 0
2
0 5 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
88 1
197 0
2
0 7 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
88 1
198 0
2
0 9 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
88 1
199 0
2
0 11 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
88 1
200 0
2
0 13 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
88 1
201 0
2
0 15 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
88 1
202 0
2
0 17 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
88 1
203 0
2
0 19 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
88 1
204 0
2
0 21 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
88 1
205 0
2
0 23 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
88 1
206 0
2
0 25 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
88 1
207 0
2
0 27 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
88 1
208 0
2
0 29 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
88 1
209 0
2
0 31 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
88 1
210 0
2
0 33 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
88 1
211 0
2
0 35 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
88 1
212 0
2
0 37 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
88 1
213 0
2
0 39 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
88 1
214 0
2
0 41 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
88 1
215 0
2
0 43 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut31
3
0 0
88 1
216 0
2
0 45 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut32
3
0 0
88 1
217 0
2
0 47 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut33
3
0 0
88 1
218 0
2
0 49 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut34
3
0 0
88 1
219 0
2
0 51 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut35
3
0 0
88 1
220 0
2
0 53 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut36
3
0 0
88 1
221 0
2
0 55 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut37
3
0 0
88 1
222 0
2
0 57 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut38
3
0 0
88 1
223 0
2
0 59 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut39
3
0 0
88 1
224 0
2
0 61 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
88 1
225 0
2
0 63 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut40
3
0 0
88 1
226 0
2
0 65 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut41
3
0 0
88 1
227 0
2
0 67 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut42
3
0 0
88 1
228 0
2
0 69 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut43
3
0 0
88 1
229 0
2
0 71 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut44
3
0 0
88 1
230 0
2
0 73 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut45
3
0 0
88 1
231 0
2
0 75 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut46
3
0 0
88 1
232 0
2
0 77 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut47
3
0 0
88 1
233 0
2
0 79 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut48
3
0 0
88 1
234 0
2
0 81 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut49
3
0 0
88 1
235 0
2
0 83 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
88 1
236 0
2
0 85 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut50
3
0 0
88 1
237 0
2
0 87 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
88 1
238 0
2
0 89 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
88 1
239 0
2
0 91 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
88 1
240 0
2
0 93 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
88 1
241 0
2
0 95 0 1
0 283 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
90 1
192 0
2
0 1 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
90 1
193 0
2
0 2 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
90 1
194 0
2
0 3 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
90 1
195 0
2
0 4 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
90 1
196 0
2
0 5 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
90 1
197 0
2
0 7 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
90 1
198 0
2
0 9 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
90 1
199 0
2
0 11 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
90 1
200 0
2
0 13 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
90 1
201 0
2
0 15 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
90 1
202 0
2
0 17 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
90 1
203 0
2
0 19 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
90 1
204 0
2
0 21 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
90 1
205 0
2
0 23 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
90 1
206 0
2
0 25 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
90 1
207 0
2
0 27 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
90 1
208 0
2
0 29 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
90 1
209 0
2
0 31 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
90 1
210 0
2
0 33 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
90 1
211 0
2
0 35 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
90 1
212 0
2
0 37 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
90 1
213 0
2
0 39 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
90 1
214 0
2
0 41 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
90 1
215 0
2
0 43 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut31
3
0 0
90 1
216 0
2
0 45 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut32
3
0 0
90 1
217 0
2
0 47 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut33
3
0 0
90 1
218 0
2
0 49 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut34
3
0 0
90 1
219 0
2
0 51 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut35
3
0 0
90 1
220 0
2
0 53 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut36
3
0 0
90 1
221 0
2
0 55 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut37
3
0 0
90 1
222 0
2
0 57 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut38
3
0 0
90 1
223 0
2
0 59 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut39
3
0 0
90 1
224 0
2
0 61 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
90 1
225 0
2
0 63 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut40
3
0 0
90 1
226 0
2
0 65 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut41
3
0 0
90 1
227 0
2
0 67 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut42
3
0 0
90 1
228 0
2
0 69 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut43
3
0 0
90 1
229 0
2
0 71 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut44
3
0 0
90 1
230 0
2
0 73 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut45
3
0 0
90 1
231 0
2
0 75 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut46
3
0 0
90 1
232 0
2
0 77 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut47
3
0 0
90 1
233 0
2
0 79 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut48
3
0 0
90 1
234 0
2
0 81 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut49
3
0 0
90 1
235 0
2
0 83 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
90 1
236 0
2
0 85 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut50
3
0 0
90 1
237 0
2
0 87 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
90 1
238 0
2
0 89 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
90 1
239 0
2
0 91 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
90 1
240 0
2
0 93 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
90 1
241 0
2
0 95 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
92 1
192 0
2
0 1 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
92 1
193 0
2
0 2 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
92 1
194 0
2
0 3 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
92 1
195 0
2
0 4 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
92 1
196 0
2
0 5 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
92 1
197 0
2
0 7 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
92 1
198 0
2
0 9 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
92 1
199 0
2
0 11 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
92 1
200 0
2
0 13 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
92 1
201 0
2
0 15 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
92 1
202 0
2
0 17 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
92 1
203 0
2
0 19 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
92 1
204 0
2
0 21 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
92 1
205 0
2
0 23 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
92 1
206 0
2
0 25 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
92 1
207 0
2
0 27 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
92 1
208 0
2
0 29 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
92 1
209 0
2
0 31 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
92 1
210 0
2
0 33 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
92 1
211 0
2
0 35 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
92 1
212 0
2
0 37 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
92 1
213 0
2
0 39 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
92 1
214 0
2
0 41 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
92 1
215 0
2
0 43 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut31
3
0 0
92 1
216 0
2
0 45 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut32
3
0 0
92 1
217 0
2
0 47 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut33
3
0 0
92 1
218 0
2
0 49 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut34
3
0 0
92 1
219 0
2
0 51 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut35
3
0 0
92 1
220 0
2
0 53 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut36
3
0 0
92 1
221 0
2
0 55 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut37
3
0 0
92 1
222 0
2
0 57 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut38
3
0 0
92 1
223 0
2
0 59 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut39
3
0 0
92 1
224 0
2
0 61 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
92 1
225 0
2
0 63 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut40
3
0 0
92 1
226 0
2
0 65 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut41
3
0 0
92 1
227 0
2
0 67 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut42
3
0 0
92 1
228 0
2
0 69 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut43
3
0 0
92 1
229 0
2
0 71 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut44
3
0 0
92 1
230 0
2
0 73 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut45
3
0 0
92 1
231 0
2
0 75 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut46
3
0 0
92 1
232 0
2
0 77 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut47
3
0 0
92 1
233 0
2
0 79 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut48
3
0 0
92 1
234 0
2
0 81 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut49
3
0 0
92 1
235 0
2
0 83 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
92 1
236 0
2
0 85 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut50
3
0 0
92 1
237 0
2
0 87 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
92 1
238 0
2
0 89 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
92 1
239 0
2
0 91 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
92 1
240 0
2
0 93 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
92 1
241 0
2
0 95 0 1
0 285 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
94 1
192 0
2
0 1 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
94 1
193 0
2
0 2 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
94 1
194 0
2
0 3 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
94 1
195 0
2
0 4 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
94 1
196 0
2
0 5 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
94 1
197 0
2
0 7 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
94 1
198 0
2
0 9 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
94 1
199 0
2
0 11 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
94 1
200 0
2
0 13 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
94 1
201 0
2
0 15 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
94 1
202 0
2
0 17 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
94 1
203 0
2
0 19 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
94 1
204 0
2
0 21 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
94 1
205 0
2
0 23 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
94 1
206 0
2
0 25 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
94 1
207 0
2
0 27 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
94 1
208 0
2
0 29 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
94 1
209 0
2
0 31 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
94 1
210 0
2
0 33 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
94 1
211 0
2
0 35 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
94 1
212 0
2
0 37 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
94 1
213 0
2
0 39 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
94 1
214 0
2
0 41 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
94 1
215 0
2
0 43 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut31
3
0 0
94 1
216 0
2
0 45 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut32
3
0 0
94 1
217 0
2
0 47 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut33
3
0 0
94 1
218 0
2
0 49 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut34
3
0 0
94 1
219 0
2
0 51 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut35
3
0 0
94 1
220 0
2
0 53 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut36
3
0 0
94 1
221 0
2
0 55 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut37
3
0 0
94 1
222 0
2
0 57 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut38
3
0 0
94 1
223 0
2
0 59 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut39
3
0 0
94 1
224 0
2
0 61 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
94 1
225 0
2
0 63 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut40
3
0 0
94 1
226 0
2
0 65 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut41
3
0 0
94 1
227 0
2
0 67 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut42
3
0 0
94 1
228 0
2
0 69 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut43
3
0 0
94 1
229 0
2
0 71 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut44
3
0 0
94 1
230 0
2
0 73 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut45
3
0 0
94 1
231 0
2
0 75 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut46
3
0 0
94 1
232 0
2
0 77 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut47
3
0 0
94 1
233 0
2
0 79 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut48
3
0 0
94 1
234 0
2
0 81 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut49
3
0 0
94 1
235 0
2
0 83 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
94 1
236 0
2
0 85 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut50
3
0 0
94 1
237 0
2
0 87 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
94 1
238 0
2
0 89 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
94 1
239 0
2
0 91 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
94 1
240 0
2
0 93 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
94 1
241 0
2
0 95 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
96 1
192 0
2
0 1 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
96 1
193 0
2
0 2 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
96 1
194 0
2
0 3 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
96 1
195 0
2
0 4 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
96 1
196 0
2
0 5 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
96 1
197 0
2
0 7 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
96 1
198 0
2
0 9 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
96 1
199 0
2
0 11 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
96 1
200 0
2
0 13 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
96 1
201 0
2
0 15 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
96 1
202 0
2
0 17 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
96 1
203 0
2
0 19 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
96 1
204 0
2
0 21 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
96 1
205 0
2
0 23 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
96 1
206 0
2
0 25 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
96 1
207 0
2
0 27 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
96 1
208 0
2
0 29 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
96 1
209 0
2
0 31 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
96 1
210 0
2
0 33 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
96 1
211 0
2
0 35 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
96 1
212 0
2
0 37 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
96 1
213 0
2
0 39 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
96 1
214 0
2
0 41 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
96 1
215 0
2
0 43 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut31
3
0 0
96 1
216 0
2
0 45 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut32
3
0 0
96 1
217 0
2
0 47 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut33
3
0 0
96 1
218 0
2
0 49 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut34
3
0 0
96 1
219 0
2
0 51 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut35
3
0 0
96 1
220 0
2
0 53 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut36
3
0 0
96 1
221 0
2
0 55 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut37
3
0 0
96 1
222 0
2
0 57 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut38
3
0 0
96 1
223 0
2
0 59 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut39
3
0 0
96 1
224 0
2
0 61 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
96 1
225 0
2
0 63 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut40
3
0 0
96 1
226 0
2
0 65 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut41
3
0 0
96 1
227 0
2
0 67 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut42
3
0 0
96 1
228 0
2
0 69 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut43
3
0 0
96 1
229 0
2
0 71 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut44
3
0 0
96 1
230 0
2
0 73 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut45
3
0 0
96 1
231 0
2
0 75 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut46
3
0 0
96 1
232 0
2
0 77 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut47
3
0 0
96 1
233 0
2
0 79 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut48
3
0 0
96 1
234 0
2
0 81 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut49
3
0 0
96 1
235 0
2
0 83 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
96 1
236 0
2
0 85 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut50
3
0 0
96 1
237 0
2
0 87 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
96 1
238 0
2
0 89 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
96 1
239 0
2
0 91 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
96 1
240 0
2
0 93 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
96 1
241 0
2
0 95 0 1
0 287 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
97 1
192 0
2
0 1 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
97 1
193 0
2
0 2 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
97 1
194 0
2
0 3 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
97 1
195 0
2
0 4 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
97 1
196 0
2
0 5 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
97 1
197 0
2
0 7 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
97 1
198 0
2
0 9 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
97 1
199 0
2
0 11 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
97 1
200 0
2
0 13 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
97 1
201 0
2
0 15 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
97 1
202 0
2
0 17 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
97 1
203 0
2
0 19 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
97 1
204 0
2
0 21 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
97 1
205 0
2
0 23 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
97 1
206 0
2
0 25 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
97 1
207 0
2
0 27 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
97 1
208 0
2
0 29 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
97 1
209 0
2
0 31 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
97 1
210 0
2
0 33 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
97 1
211 0
2
0 35 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
97 1
212 0
2
0 37 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
97 1
213 0
2
0 39 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
97 1
214 0
2
0 41 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
97 1
215 0
2
0 43 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut31
3
0 0
97 1
216 0
2
0 45 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut32
3
0 0
97 1
217 0
2
0 47 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut33
3
0 0
97 1
218 0
2
0 49 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut34
3
0 0
97 1
219 0
2
0 51 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut35
3
0 0
97 1
220 0
2
0 53 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut36
3
0 0
97 1
221 0
2
0 55 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut37
3
0 0
97 1
222 0
2
0 57 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut38
3
0 0
97 1
223 0
2
0 59 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut39
3
0 0
97 1
224 0
2
0 61 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
97 1
225 0
2
0 63 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut40
3
0 0
97 1
226 0
2
0 65 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut41
3
0 0
97 1
227 0
2
0 67 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut42
3
0 0
97 1
228 0
2
0 69 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut43
3
0 0
97 1
229 0
2
0 71 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut44
3
0 0
97 1
230 0
2
0 73 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut45
3
0 0
97 1
231 0
2
0 75 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut46
3
0 0
97 1
232 0
2
0 77 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut47
3
0 0
97 1
233 0
2
0 79 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut48
3
0 0
97 1
234 0
2
0 81 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut49
3
0 0
97 1
235 0
2
0 83 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
97 1
236 0
2
0 85 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut50
3
0 0
97 1
237 0
2
0 87 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
97 1
238 0
2
0 89 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
97 1
239 0
2
0 91 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
97 1
240 0
2
0 93 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
97 1
241 0
2
0 95 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
98 1
192 0
2
0 1 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
98 1
193 0
2
0 2 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
98 1
194 0
2
0 3 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
98 1
195 0
2
0 4 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
98 1
196 0
2
0 5 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
98 1
197 0
2
0 7 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
98 1
198 0
2
0 9 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
98 1
199 0
2
0 11 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
98 1
200 0
2
0 13 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
98 1
201 0
2
0 15 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
98 1
202 0
2
0 17 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
98 1
203 0
2
0 19 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
98 1
204 0
2
0 21 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
98 1
205 0
2
0 23 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
98 1
206 0
2
0 25 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
98 1
207 0
2
0 27 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
98 1
208 0
2
0 29 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
98 1
209 0
2
0 31 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
98 1
210 0
2
0 33 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
98 1
211 0
2
0 35 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
98 1
212 0
2
0 37 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
98 1
213 0
2
0 39 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
98 1
214 0
2
0 41 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
98 1
215 0
2
0 43 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut31
3
0 0
98 1
216 0
2
0 45 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut32
3
0 0
98 1
217 0
2
0 47 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut33
3
0 0
98 1
218 0
2
0 49 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut34
3
0 0
98 1
219 0
2
0 51 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut35
3
0 0
98 1
220 0
2
0 53 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut36
3
0 0
98 1
221 0
2
0 55 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut37
3
0 0
98 1
222 0
2
0 57 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut38
3
0 0
98 1
223 0
2
0 59 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut39
3
0 0
98 1
224 0
2
0 61 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
98 1
225 0
2
0 63 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut40
3
0 0
98 1
226 0
2
0 65 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut41
3
0 0
98 1
227 0
2
0 67 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut42
3
0 0
98 1
228 0
2
0 69 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut43
3
0 0
98 1
229 0
2
0 71 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut44
3
0 0
98 1
230 0
2
0 73 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut45
3
0 0
98 1
231 0
2
0 75 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut46
3
0 0
98 1
232 0
2
0 77 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut47
3
0 0
98 1
233 0
2
0 79 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut48
3
0 0
98 1
234 0
2
0 81 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut49
3
0 0
98 1
235 0
2
0 83 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
98 1
236 0
2
0 85 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut50
3
0 0
98 1
237 0
2
0 87 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
98 1
238 0
2
0 89 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
98 1
239 0
2
0 91 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
98 1
240 0
2
0 93 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
98 1
241 0
2
0 95 0 1
0 289 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
99 1
192 0
2
0 1 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
99 1
193 0
2
0 2 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
99 1
194 0
2
0 3 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
99 1
195 0
2
0 4 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
99 1
196 0
2
0 5 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
99 1
197 0
2
0 7 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
99 1
198 0
2
0 9 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
99 1
199 0
2
0 11 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
99 1
200 0
2
0 13 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
99 1
201 0
2
0 15 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
99 1
202 0
2
0 17 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
99 1
203 0
2
0 19 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
99 1
204 0
2
0 21 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
99 1
205 0
2
0 23 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
99 1
206 0
2
0 25 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
99 1
207 0
2
0 27 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
99 1
208 0
2
0 29 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
99 1
209 0
2
0 31 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
99 1
210 0
2
0 33 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
99 1
211 0
2
0 35 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
99 1
212 0
2
0 37 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
99 1
213 0
2
0 39 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
99 1
214 0
2
0 41 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
99 1
215 0
2
0 43 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut31
3
0 0
99 1
216 0
2
0 45 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut32
3
0 0
99 1
217 0
2
0 47 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut33
3
0 0
99 1
218 0
2
0 49 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut34
3
0 0
99 1
219 0
2
0 51 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut35
3
0 0
99 1
220 0
2
0 53 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut36
3
0 0
99 1
221 0
2
0 55 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut37
3
0 0
99 1
222 0
2
0 57 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut38
3
0 0
99 1
223 0
2
0 59 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut39
3
0 0
99 1
224 0
2
0 61 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
99 1
225 0
2
0 63 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut40
3
0 0
99 1
226 0
2
0 65 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut41
3
0 0
99 1
227 0
2
0 67 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut42
3
0 0
99 1
228 0
2
0 69 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut43
3
0 0
99 1
229 0
2
0 71 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut44
3
0 0
99 1
230 0
2
0 73 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut45
3
0 0
99 1
231 0
2
0 75 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut46
3
0 0
99 1
232 0
2
0 77 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut47
3
0 0
99 1
233 0
2
0 79 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut48
3
0 0
99 1
234 0
2
0 81 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut49
3
0 0
99 1
235 0
2
0 83 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
99 1
236 0
2
0 85 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut50
3
0 0
99 1
237 0
2
0 87 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
99 1
238 0
2
0 89 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
99 1
239 0
2
0 91 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
99 1
240 0
2
0 93 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
99 1
241 0
2
0 95 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
100 1
192 0
2
0 1 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
100 1
193 0
2
0 2 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
100 1
194 0
2
0 3 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
100 1
195 0
2
0 4 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
100 1
196 0
2
0 5 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
100 1
197 0
2
0 7 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
100 1
198 0
2
0 9 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
100 1
199 0
2
0 11 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
100 1
200 0
2
0 13 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
100 1
201 0
2
0 15 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
100 1
202 0
2
0 17 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
100 1
203 0
2
0 19 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
100 1
204 0
2
0 21 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
100 1
205 0
2
0 23 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
100 1
206 0
2
0 25 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
100 1
207 0
2
0 27 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
100 1
208 0
2
0 29 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
100 1
209 0
2
0 31 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
100 1
210 0
2
0 33 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
100 1
211 0
2
0 35 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
100 1
212 0
2
0 37 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
100 1
213 0
2
0 39 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
100 1
214 0
2
0 41 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
100 1
215 0
2
0 43 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut31
3
0 0
100 1
216 0
2
0 45 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut32
3
0 0
100 1
217 0
2
0 47 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut33
3
0 0
100 1
218 0
2
0 49 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut34
3
0 0
100 1
219 0
2
0 51 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut35
3
0 0
100 1
220 0
2
0 53 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut36
3
0 0
100 1
221 0
2
0 55 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut37
3
0 0
100 1
222 0
2
0 57 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut38
3
0 0
100 1
223 0
2
0 59 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut39
3
0 0
100 1
224 0
2
0 61 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
100 1
225 0
2
0 63 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut40
3
0 0
100 1
226 0
2
0 65 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut41
3
0 0
100 1
227 0
2
0 67 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut42
3
0 0
100 1
228 0
2
0 69 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut43
3
0 0
100 1
229 0
2
0 71 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut44
3
0 0
100 1
230 0
2
0 73 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut45
3
0 0
100 1
231 0
2
0 75 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut46
3
0 0
100 1
232 0
2
0 77 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut47
3
0 0
100 1
233 0
2
0 79 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut48
3
0 0
100 1
234 0
2
0 81 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut49
3
0 0
100 1
235 0
2
0 83 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
100 1
236 0
2
0 85 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut50
3
0 0
100 1
237 0
2
0 87 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
100 1
238 0
2
0 89 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
100 1
239 0
2
0 91 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
100 1
240 0
2
0 93 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
100 1
241 0
2
0 95 0 1
0 291 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
101 1
192 0
2
0 1 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
101 1
193 0
2
0 2 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
101 1
194 0
2
0 3 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
101 1
195 0
2
0 4 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
101 1
196 0
2
0 5 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
101 1
197 0
2
0 7 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
101 1
198 0
2
0 9 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
101 1
199 0
2
0 11 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
101 1
200 0
2
0 13 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
101 1
201 0
2
0 15 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
101 1
202 0
2
0 17 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
101 1
203 0
2
0 19 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
101 1
204 0
2
0 21 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
101 1
205 0
2
0 23 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
101 1
206 0
2
0 25 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
101 1
207 0
2
0 27 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
101 1
208 0
2
0 29 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
101 1
209 0
2
0 31 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
101 1
210 0
2
0 33 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
101 1
211 0
2
0 35 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
101 1
212 0
2
0 37 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
101 1
213 0
2
0 39 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
101 1
214 0
2
0 41 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
101 1
215 0
2
0 43 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut31
3
0 0
101 1
216 0
2
0 45 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut32
3
0 0
101 1
217 0
2
0 47 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut33
3
0 0
101 1
218 0
2
0 49 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut34
3
0 0
101 1
219 0
2
0 51 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut35
3
0 0
101 1
220 0
2
0 53 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut36
3
0 0
101 1
221 0
2
0 55 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut37
3
0 0
101 1
222 0
2
0 57 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut38
3
0 0
101 1
223 0
2
0 59 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut39
3
0 0
101 1
224 0
2
0 61 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
101 1
225 0
2
0 63 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut40
3
0 0
101 1
226 0
2
0 65 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut41
3
0 0
101 1
227 0
2
0 67 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut42
3
0 0
101 1
228 0
2
0 69 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut43
3
0 0
101 1
229 0
2
0 71 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut44
3
0 0
101 1
230 0
2
0 73 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut45
3
0 0
101 1
231 0
2
0 75 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut46
3
0 0
101 1
232 0
2
0 77 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut47
3
0 0
101 1
233 0
2
0 79 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut48
3
0 0
101 1
234 0
2
0 81 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut49
3
0 0
101 1
235 0
2
0 83 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
101 1
236 0
2
0 85 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut50
3
0 0
101 1
237 0
2
0 87 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
101 1
238 0
2
0 89 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
101 1
239 0
2
0 91 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
101 1
240 0
2
0 93 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
101 1
241 0
2
0 95 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
102 1
192 0
2
0 1 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
102 1
193 0
2
0 2 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
102 1
194 0
2
0 3 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
102 1
195 0
2
0 4 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
102 1
196 0
2
0 5 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
102 1
197 0
2
0 7 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
102 1
198 0
2
0 9 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
102 1
199 0
2
0 11 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
102 1
200 0
2
0 13 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
102 1
201 0
2
0 15 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
102 1
202 0
2
0 17 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
102 1
203 0
2
0 19 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
102 1
204 0
2
0 21 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
102 1
205 0
2
0 23 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
102 1
206 0
2
0 25 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
102 1
207 0
2
0 27 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
102 1
208 0
2
0 29 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
102 1
209 0
2
0 31 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
102 1
210 0
2
0 33 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
102 1
211 0
2
0 35 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
102 1
212 0
2
0 37 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
102 1
213 0
2
0 39 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
102 1
214 0
2
0 41 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
102 1
215 0
2
0 43 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut31
3
0 0
102 1
216 0
2
0 45 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut32
3
0 0
102 1
217 0
2
0 47 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut33
3
0 0
102 1
218 0
2
0 49 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut34
3
0 0
102 1
219 0
2
0 51 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut35
3
0 0
102 1
220 0
2
0 53 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut36
3
0 0
102 1
221 0
2
0 55 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut37
3
0 0
102 1
222 0
2
0 57 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut38
3
0 0
102 1
223 0
2
0 59 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut39
3
0 0
102 1
224 0
2
0 61 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
102 1
225 0
2
0 63 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut40
3
0 0
102 1
226 0
2
0 65 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut41
3
0 0
102 1
227 0
2
0 67 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut42
3
0 0
102 1
228 0
2
0 69 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut43
3
0 0
102 1
229 0
2
0 71 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut44
3
0 0
102 1
230 0
2
0 73 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut45
3
0 0
102 1
231 0
2
0 75 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut46
3
0 0
102 1
232 0
2
0 77 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut47
3
0 0
102 1
233 0
2
0 79 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut48
3
0 0
102 1
234 0
2
0 81 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut49
3
0 0
102 1
235 0
2
0 83 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
102 1
236 0
2
0 85 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut50
3
0 0
102 1
237 0
2
0 87 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
102 1
238 0
2
0 89 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
102 1
239 0
2
0 91 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
102 1
240 0
2
0 93 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
102 1
241 0
2
0 95 0 1
0 293 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
103 1
192 0
2
0 1 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
103 1
193 0
2
0 2 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
103 1
194 0
2
0 3 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
103 1
195 0
2
0 4 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
103 1
196 0
2
0 5 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
103 1
197 0
2
0 7 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
103 1
198 0
2
0 9 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
103 1
199 0
2
0 11 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
103 1
200 0
2
0 13 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
103 1
201 0
2
0 15 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
103 1
202 0
2
0 17 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
103 1
203 0
2
0 19 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
103 1
204 0
2
0 21 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
103 1
205 0
2
0 23 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
103 1
206 0
2
0 25 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
103 1
207 0
2
0 27 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
103 1
208 0
2
0 29 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
103 1
209 0
2
0 31 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
103 1
210 0
2
0 33 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
103 1
211 0
2
0 35 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
103 1
212 0
2
0 37 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
103 1
213 0
2
0 39 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
103 1
214 0
2
0 41 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
103 1
215 0
2
0 43 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut31
3
0 0
103 1
216 0
2
0 45 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut32
3
0 0
103 1
217 0
2
0 47 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut33
3
0 0
103 1
218 0
2
0 49 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut34
3
0 0
103 1
219 0
2
0 51 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut35
3
0 0
103 1
220 0
2
0 53 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut36
3
0 0
103 1
221 0
2
0 55 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut37
3
0 0
103 1
222 0
2
0 57 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut38
3
0 0
103 1
223 0
2
0 59 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut39
3
0 0
103 1
224 0
2
0 61 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
103 1
225 0
2
0 63 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut40
3
0 0
103 1
226 0
2
0 65 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut41
3
0 0
103 1
227 0
2
0 67 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut42
3
0 0
103 1
228 0
2
0 69 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut43
3
0 0
103 1
229 0
2
0 71 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut44
3
0 0
103 1
230 0
2
0 73 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut45
3
0 0
103 1
231 0
2
0 75 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut46
3
0 0
103 1
232 0
2
0 77 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut47
3
0 0
103 1
233 0
2
0 79 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut48
3
0 0
103 1
234 0
2
0 81 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut49
3
0 0
103 1
235 0
2
0 83 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
103 1
236 0
2
0 85 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut50
3
0 0
103 1
237 0
2
0 87 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
103 1
238 0
2
0 89 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
103 1
239 0
2
0 91 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
103 1
240 0
2
0 93 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
103 1
241 0
2
0 95 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut1
3
0 0
104 1
192 0
2
0 1 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut10
3
0 0
104 1
193 0
2
0 2 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut11
3
0 0
104 1
194 0
2
0 3 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut12
3
0 0
104 1
195 0
2
0 4 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut13
3
0 0
104 1
196 0
2
0 5 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut14
3
0 0
104 1
197 0
2
0 7 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut15
3
0 0
104 1
198 0
2
0 9 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut16
3
0 0
104 1
199 0
2
0 11 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut17
3
0 0
104 1
200 0
2
0 13 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut18
3
0 0
104 1
201 0
2
0 15 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut19
3
0 0
104 1
202 0
2
0 17 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut2
3
0 0
104 1
203 0
2
0 19 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut20
3
0 0
104 1
204 0
2
0 21 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut21
3
0 0
104 1
205 0
2
0 23 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut22
3
0 0
104 1
206 0
2
0 25 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut23
3
0 0
104 1
207 0
2
0 27 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut24
3
0 0
104 1
208 0
2
0 29 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut25
3
0 0
104 1
209 0
2
0 31 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut26
3
0 0
104 1
210 0
2
0 33 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut27
3
0 0
104 1
211 0
2
0 35 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut28
3
0 0
104 1
212 0
2
0 37 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut29
3
0 0
104 1
213 0
2
0 39 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut3
3
0 0
104 1
214 0
2
0 41 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut30
3
0 0
104 1
215 0
2
0 43 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut31
3
0 0
104 1
216 0
2
0 45 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut32
3
0 0
104 1
217 0
2
0 47 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut33
3
0 0
104 1
218 0
2
0 49 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut34
3
0 0
104 1
219 0
2
0 51 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut35
3
0 0
104 1
220 0
2
0 53 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut36
3
0 0
104 1
221 0
2
0 55 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut37
3
0 0
104 1
222 0
2
0 57 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut38
3
0 0
104 1
223 0
2
0 59 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut39
3
0 0
104 1
224 0
2
0 61 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut4
3
0 0
104 1
225 0
2
0 63 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut40
3
0 0
104 1
226 0
2
0 65 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut41
3
0 0
104 1
227 0
2
0 67 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut42
3
0 0
104 1
228 0
2
0 69 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut43
3
0 0
104 1
229 0
2
0 71 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut44
3
0 0
104 1
230 0
2
0 73 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut45
3
0 0
104 1
231 0
2
0 75 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut46
3
0 0
104 1
232 0
2
0 77 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut47
3
0 0
104 1
233 0
2
0 79 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut48
3
0 0
104 1
234 0
2
0 81 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut49
3
0 0
104 1
235 0
2
0 83 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut5
3
0 0
104 1
236 0
2
0 85 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut50
3
0 0
104 1
237 0
2
0 87 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut6
3
0 0
104 1
238 0
2
0 89 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut7
3
0 0
104 1
239 0
2
0 91 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut8
3
0 0
104 1
240 0
2
0 93 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut9
3
0 0
104 1
241 0
2
0 95 0 1
0 295 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut1
3
0 0
105 1
192 0
2
0 1 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut10
3
0 0
105 1
193 0
2
0 2 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut11
3
0 0
105 1
194 0
2
0 3 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut12
3
0 0
105 1
195 0
2
0 4 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut13
3
0 0
105 1
196 0
2
0 5 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut14
3
0 0
105 1
197 0
2
0 7 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut15
3
0 0
105 1
198 0
2
0 9 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut16
3
0 0
105 1
199 0
2
0 11 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut17
3
0 0
105 1
200 0
2
0 13 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut18
3
0 0
105 1
201 0
2
0 15 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut19
3
0 0
105 1
202 0
2
0 17 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut2
3
0 0
105 1
203 0
2
0 19 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut20
3
0 0
105 1
204 0
2
0 21 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut21
3
0 0
105 1
205 0
2
0 23 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut22
3
0 0
105 1
206 0
2
0 25 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut23
3
0 0
105 1
207 0
2
0 27 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut24
3
0 0
105 1
208 0
2
0 29 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut25
3
0 0
105 1
209 0
2
0 31 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut26
3
0 0
105 1
210 0
2
0 33 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut27
3
0 0
105 1
211 0
2
0 35 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut28
3
0 0
105 1
212 0
2
0 37 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut29
3
0 0
105 1
213 0
2
0 39 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut3
3
0 0
105 1
214 0
2
0 41 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut30
3
0 0
105 1
215 0
2
0 43 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut31
3
0 0
105 1
216 0
2
0 45 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut32
3
0 0
105 1
217 0
2
0 47 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut33
3
0 0
105 1
218 0
2
0 49 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut34
3
0 0
105 1
219 0
2
0 51 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut35
3
0 0
105 1
220 0
2
0 53 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut36
3
0 0
105 1
221 0
2
0 55 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut37
3
0 0
105 1
222 0
2
0 57 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut38
3
0 0
105 1
223 0
2
0 59 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut39
3
0 0
105 1
224 0
2
0 61 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut4
3
0 0
105 1
225 0
2
0 63 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut40
3
0 0
105 1
226 0
2
0 65 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut41
3
0 0
105 1
227 0
2
0 67 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut42
3
0 0
105 1
228 0
2
0 69 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut43
3
0 0
105 1
229 0
2
0 71 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut44
3
0 0
105 1
230 0
2
0 73 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut45
3
0 0
105 1
231 0
2
0 75 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut46
3
0 0
105 1
232 0
2
0 77 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut47
3
0 0
105 1
233 0
2
0 79 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut48
3
0 0
105 1
234 0
2
0 81 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut49
3
0 0
105 1
235 0
2
0 83 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut5
3
0 0
105 1
236 0
2
0 85 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut50
3
0 0
105 1
237 0
2
0 87 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut6
3
0 0
105 1
238 0
2
0 89 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut7
3
0 0
105 1
239 0
2
0 91 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut8
3
0 0
105 1
240 0
2
0 93 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut9
3
0 0
105 1
241 0
2
0 95 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut1
3
0 0
106 1
192 0
2
0 1 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut10
3
0 0
106 1
193 0
2
0 2 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut11
3
0 0
106 1
194 0
2
0 3 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut12
3
0 0
106 1
195 0
2
0 4 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut13
3
0 0
106 1
196 0
2
0 5 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut14
3
0 0
106 1
197 0
2
0 7 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut15
3
0 0
106 1
198 0
2
0 9 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut16
3
0 0
106 1
199 0
2
0 11 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut17
3
0 0
106 1
200 0
2
0 13 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut18
3
0 0
106 1
201 0
2
0 15 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut19
3
0 0
106 1
202 0
2
0 17 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut2
3
0 0
106 1
203 0
2
0 19 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut20
3
0 0
106 1
204 0
2
0 21 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut21
3
0 0
106 1
205 0
2
0 23 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut22
3
0 0
106 1
206 0
2
0 25 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut23
3
0 0
106 1
207 0
2
0 27 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut24
3
0 0
106 1
208 0
2
0 29 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut25
3
0 0
106 1
209 0
2
0 31 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut26
3
0 0
106 1
210 0
2
0 33 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut27
3
0 0
106 1
211 0
2
0 35 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut28
3
0 0
106 1
212 0
2
0 37 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut29
3
0 0
106 1
213 0
2
0 39 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut3
3
0 0
106 1
214 0
2
0 41 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut30
3
0 0
106 1
215 0
2
0 43 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut31
3
0 0
106 1
216 0
2
0 45 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut32
3
0 0
106 1
217 0
2
0 47 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut33
3
0 0
106 1
218 0
2
0 49 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut34
3
0 0
106 1
219 0
2
0 51 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut35
3
0 0
106 1
220 0
2
0 53 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut36
3
0 0
106 1
221 0
2
0 55 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut37
3
0 0
106 1
222 0
2
0 57 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut38
3
0 0
106 1
223 0
2
0 59 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut39
3
0 0
106 1
224 0
2
0 61 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut4
3
0 0
106 1
225 0
2
0 63 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut40
3
0 0
106 1
226 0
2
0 65 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut41
3
0 0
106 1
227 0
2
0 67 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut42
3
0 0
106 1
228 0
2
0 69 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut43
3
0 0
106 1
229 0
2
0 71 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut44
3
0 0
106 1
230 0
2
0 73 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut45
3
0 0
106 1
231 0
2
0 75 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut46
3
0 0
106 1
232 0
2
0 77 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut47
3
0 0
106 1
233 0
2
0 79 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut48
3
0 0
106 1
234 0
2
0 81 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut49
3
0 0
106 1
235 0
2
0 83 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut5
3
0 0
106 1
236 0
2
0 85 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut50
3
0 0
106 1
237 0
2
0 87 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut6
3
0 0
106 1
238 0
2
0 89 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut7
3
0 0
106 1
239 0
2
0 91 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut8
3
0 0
106 1
240 0
2
0 93 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut9
3
0 0
106 1
241 0
2
0 95 0 1
0 297 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
107 1
192 0
2
0 1 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
107 1
193 0
2
0 2 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
107 1
194 0
2
0 3 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
107 1
195 0
2
0 4 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
107 1
196 0
2
0 5 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
107 1
197 0
2
0 7 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
107 1
198 0
2
0 9 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
107 1
199 0
2
0 11 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
107 1
200 0
2
0 13 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
107 1
201 0
2
0 15 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
107 1
202 0
2
0 17 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
107 1
203 0
2
0 19 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
107 1
204 0
2
0 21 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
107 1
205 0
2
0 23 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
107 1
206 0
2
0 25 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
107 1
207 0
2
0 27 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
107 1
208 0
2
0 29 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
107 1
209 0
2
0 31 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
107 1
210 0
2
0 33 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
107 1
211 0
2
0 35 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
107 1
212 0
2
0 37 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
107 1
213 0
2
0 39 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
107 1
214 0
2
0 41 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
107 1
215 0
2
0 43 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut31
3
0 0
107 1
216 0
2
0 45 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut32
3
0 0
107 1
217 0
2
0 47 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut33
3
0 0
107 1
218 0
2
0 49 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut34
3
0 0
107 1
219 0
2
0 51 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut35
3
0 0
107 1
220 0
2
0 53 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut36
3
0 0
107 1
221 0
2
0 55 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut37
3
0 0
107 1
222 0
2
0 57 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut38
3
0 0
107 1
223 0
2
0 59 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut39
3
0 0
107 1
224 0
2
0 61 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
107 1
225 0
2
0 63 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut40
3
0 0
107 1
226 0
2
0 65 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut41
3
0 0
107 1
227 0
2
0 67 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut42
3
0 0
107 1
228 0
2
0 69 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut43
3
0 0
107 1
229 0
2
0 71 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut44
3
0 0
107 1
230 0
2
0 73 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut45
3
0 0
107 1
231 0
2
0 75 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut46
3
0 0
107 1
232 0
2
0 77 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut47
3
0 0
107 1
233 0
2
0 79 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut48
3
0 0
107 1
234 0
2
0 81 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut49
3
0 0
107 1
235 0
2
0 83 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
107 1
236 0
2
0 85 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut50
3
0 0
107 1
237 0
2
0 87 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
107 1
238 0
2
0 89 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
107 1
239 0
2
0 91 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
107 1
240 0
2
0 93 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
107 1
241 0
2
0 95 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut1
3
0 0
108 1
192 0
2
0 1 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut10
3
0 0
108 1
193 0
2
0 2 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut11
3
0 0
108 1
194 0
2
0 3 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut12
3
0 0
108 1
195 0
2
0 4 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut13
3
0 0
108 1
196 0
2
0 5 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut14
3
0 0
108 1
197 0
2
0 7 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut15
3
0 0
108 1
198 0
2
0 9 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut16
3
0 0
108 1
199 0
2
0 11 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut17
3
0 0
108 1
200 0
2
0 13 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut18
3
0 0
108 1
201 0
2
0 15 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut19
3
0 0
108 1
202 0
2
0 17 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut2
3
0 0
108 1
203 0
2
0 19 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut20
3
0 0
108 1
204 0
2
0 21 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut21
3
0 0
108 1
205 0
2
0 23 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut22
3
0 0
108 1
206 0
2
0 25 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut23
3
0 0
108 1
207 0
2
0 27 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut24
3
0 0
108 1
208 0
2
0 29 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut25
3
0 0
108 1
209 0
2
0 31 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut26
3
0 0
108 1
210 0
2
0 33 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut27
3
0 0
108 1
211 0
2
0 35 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut28
3
0 0
108 1
212 0
2
0 37 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut29
3
0 0
108 1
213 0
2
0 39 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut3
3
0 0
108 1
214 0
2
0 41 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut30
3
0 0
108 1
215 0
2
0 43 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut31
3
0 0
108 1
216 0
2
0 45 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut32
3
0 0
108 1
217 0
2
0 47 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut33
3
0 0
108 1
218 0
2
0 49 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut34
3
0 0
108 1
219 0
2
0 51 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut35
3
0 0
108 1
220 0
2
0 53 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut36
3
0 0
108 1
221 0
2
0 55 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut37
3
0 0
108 1
222 0
2
0 57 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut38
3
0 0
108 1
223 0
2
0 59 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut39
3
0 0
108 1
224 0
2
0 61 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut4
3
0 0
108 1
225 0
2
0 63 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut40
3
0 0
108 1
226 0
2
0 65 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut41
3
0 0
108 1
227 0
2
0 67 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut42
3
0 0
108 1
228 0
2
0 69 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut43
3
0 0
108 1
229 0
2
0 71 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut44
3
0 0
108 1
230 0
2
0 73 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut45
3
0 0
108 1
231 0
2
0 75 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut46
3
0 0
108 1
232 0
2
0 77 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut47
3
0 0
108 1
233 0
2
0 79 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut48
3
0 0
108 1
234 0
2
0 81 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut49
3
0 0
108 1
235 0
2
0 83 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut5
3
0 0
108 1
236 0
2
0 85 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut50
3
0 0
108 1
237 0
2
0 87 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut6
3
0 0
108 1
238 0
2
0 89 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut7
3
0 0
108 1
239 0
2
0 91 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut8
3
0 0
108 1
240 0
2
0 93 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut9
3
0 0
108 1
241 0
2
0 95 0 1
0 299 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut1
3
0 0
109 1
192 0
2
0 1 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut10
3
0 0
109 1
193 0
2
0 2 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut11
3
0 0
109 1
194 0
2
0 3 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut12
3
0 0
109 1
195 0
2
0 4 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut13
3
0 0
109 1
196 0
2
0 5 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut14
3
0 0
109 1
197 0
2
0 7 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut15
3
0 0
109 1
198 0
2
0 9 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut16
3
0 0
109 1
199 0
2
0 11 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut17
3
0 0
109 1
200 0
2
0 13 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut18
3
0 0
109 1
201 0
2
0 15 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut19
3
0 0
109 1
202 0
2
0 17 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut2
3
0 0
109 1
203 0
2
0 19 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut20
3
0 0
109 1
204 0
2
0 21 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut21
3
0 0
109 1
205 0
2
0 23 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut22
3
0 0
109 1
206 0
2
0 25 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut23
3
0 0
109 1
207 0
2
0 27 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut24
3
0 0
109 1
208 0
2
0 29 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut25
3
0 0
109 1
209 0
2
0 31 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut26
3
0 0
109 1
210 0
2
0 33 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut27
3
0 0
109 1
211 0
2
0 35 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut28
3
0 0
109 1
212 0
2
0 37 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut29
3
0 0
109 1
213 0
2
0 39 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut3
3
0 0
109 1
214 0
2
0 41 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut30
3
0 0
109 1
215 0
2
0 43 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut31
3
0 0
109 1
216 0
2
0 45 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut32
3
0 0
109 1
217 0
2
0 47 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut33
3
0 0
109 1
218 0
2
0 49 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut34
3
0 0
109 1
219 0
2
0 51 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut35
3
0 0
109 1
220 0
2
0 53 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut36
3
0 0
109 1
221 0
2
0 55 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut37
3
0 0
109 1
222 0
2
0 57 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut38
3
0 0
109 1
223 0
2
0 59 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut39
3
0 0
109 1
224 0
2
0 61 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut4
3
0 0
109 1
225 0
2
0 63 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut40
3
0 0
109 1
226 0
2
0 65 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut41
3
0 0
109 1
227 0
2
0 67 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut42
3
0 0
109 1
228 0
2
0 69 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut43
3
0 0
109 1
229 0
2
0 71 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut44
3
0 0
109 1
230 0
2
0 73 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut45
3
0 0
109 1
231 0
2
0 75 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut46
3
0 0
109 1
232 0
2
0 77 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut47
3
0 0
109 1
233 0
2
0 79 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut48
3
0 0
109 1
234 0
2
0 81 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut49
3
0 0
109 1
235 0
2
0 83 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut5
3
0 0
109 1
236 0
2
0 85 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut50
3
0 0
109 1
237 0
2
0 87 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut6
3
0 0
109 1
238 0
2
0 89 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut7
3
0 0
109 1
239 0
2
0 91 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut8
3
0 0
109 1
240 0
2
0 93 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut9
3
0 0
109 1
241 0
2
0 95 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut1
3
0 0
110 1
192 0
2
0 1 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut10
3
0 0
110 1
193 0
2
0 2 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut11
3
0 0
110 1
194 0
2
0 3 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut12
3
0 0
110 1
195 0
2
0 4 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut13
3
0 0
110 1
196 0
2
0 5 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut14
3
0 0
110 1
197 0
2
0 7 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut15
3
0 0
110 1
198 0
2
0 9 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut16
3
0 0
110 1
199 0
2
0 11 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut17
3
0 0
110 1
200 0
2
0 13 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut18
3
0 0
110 1
201 0
2
0 15 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut19
3
0 0
110 1
202 0
2
0 17 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut2
3
0 0
110 1
203 0
2
0 19 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut20
3
0 0
110 1
204 0
2
0 21 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut21
3
0 0
110 1
205 0
2
0 23 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut22
3
0 0
110 1
206 0
2
0 25 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut23
3
0 0
110 1
207 0
2
0 27 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut24
3
0 0
110 1
208 0
2
0 29 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut25
3
0 0
110 1
209 0
2
0 31 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut26
3
0 0
110 1
210 0
2
0 33 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut27
3
0 0
110 1
211 0
2
0 35 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut28
3
0 0
110 1
212 0
2
0 37 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut29
3
0 0
110 1
213 0
2
0 39 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut3
3
0 0
110 1
214 0
2
0 41 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut30
3
0 0
110 1
215 0
2
0 43 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut31
3
0 0
110 1
216 0
2
0 45 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut32
3
0 0
110 1
217 0
2
0 47 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut33
3
0 0
110 1
218 0
2
0 49 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut34
3
0 0
110 1
219 0
2
0 51 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut35
3
0 0
110 1
220 0
2
0 53 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut36
3
0 0
110 1
221 0
2
0 55 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut37
3
0 0
110 1
222 0
2
0 57 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut38
3
0 0
110 1
223 0
2
0 59 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut39
3
0 0
110 1
224 0
2
0 61 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut4
3
0 0
110 1
225 0
2
0 63 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut40
3
0 0
110 1
226 0
2
0 65 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut41
3
0 0
110 1
227 0
2
0 67 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut42
3
0 0
110 1
228 0
2
0 69 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut43
3
0 0
110 1
229 0
2
0 71 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut44
3
0 0
110 1
230 0
2
0 73 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut45
3
0 0
110 1
231 0
2
0 75 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut46
3
0 0
110 1
232 0
2
0 77 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut47
3
0 0
110 1
233 0
2
0 79 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut48
3
0 0
110 1
234 0
2
0 81 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut49
3
0 0
110 1
235 0
2
0 83 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut5
3
0 0
110 1
236 0
2
0 85 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut50
3
0 0
110 1
237 0
2
0 87 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut6
3
0 0
110 1
238 0
2
0 89 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut7
3
0 0
110 1
239 0
2
0 91 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut8
3
0 0
110 1
240 0
2
0 93 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut9
3
0 0
110 1
241 0
2
0 95 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut1
3
0 0
111 1
192 0
2
0 1 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut10
3
0 0
111 1
193 0
2
0 2 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut11
3
0 0
111 1
194 0
2
0 3 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut12
3
0 0
111 1
195 0
2
0 4 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut13
3
0 0
111 1
196 0
2
0 5 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut14
3
0 0
111 1
197 0
2
0 7 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut15
3
0 0
111 1
198 0
2
0 9 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut16
3
0 0
111 1
199 0
2
0 11 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut17
3
0 0
111 1
200 0
2
0 13 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut18
3
0 0
111 1
201 0
2
0 15 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut19
3
0 0
111 1
202 0
2
0 17 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut2
3
0 0
111 1
203 0
2
0 19 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut20
3
0 0
111 1
204 0
2
0 21 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut21
3
0 0
111 1
205 0
2
0 23 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut22
3
0 0
111 1
206 0
2
0 25 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut23
3
0 0
111 1
207 0
2
0 27 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut24
3
0 0
111 1
208 0
2
0 29 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut25
3
0 0
111 1
209 0
2
0 31 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut26
3
0 0
111 1
210 0
2
0 33 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut27
3
0 0
111 1
211 0
2
0 35 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut28
3
0 0
111 1
212 0
2
0 37 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut29
3
0 0
111 1
213 0
2
0 39 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut3
3
0 0
111 1
214 0
2
0 41 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut30
3
0 0
111 1
215 0
2
0 43 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut31
3
0 0
111 1
216 0
2
0 45 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut32
3
0 0
111 1
217 0
2
0 47 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut33
3
0 0
111 1
218 0
2
0 49 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut34
3
0 0
111 1
219 0
2
0 51 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut35
3
0 0
111 1
220 0
2
0 53 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut36
3
0 0
111 1
221 0
2
0 55 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut37
3
0 0
111 1
222 0
2
0 57 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut38
3
0 0
111 1
223 0
2
0 59 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut39
3
0 0
111 1
224 0
2
0 61 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut4
3
0 0
111 1
225 0
2
0 63 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut40
3
0 0
111 1
226 0
2
0 65 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut41
3
0 0
111 1
227 0
2
0 67 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut42
3
0 0
111 1
228 0
2
0 69 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut43
3
0 0
111 1
229 0
2
0 71 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut44
3
0 0
111 1
230 0
2
0 73 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut45
3
0 0
111 1
231 0
2
0 75 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut46
3
0 0
111 1
232 0
2
0 77 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut47
3
0 0
111 1
233 0
2
0 79 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut48
3
0 0
111 1
234 0
2
0 81 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut49
3
0 0
111 1
235 0
2
0 83 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut5
3
0 0
111 1
236 0
2
0 85 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut50
3
0 0
111 1
237 0
2
0 87 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut6
3
0 0
111 1
238 0
2
0 89 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut7
3
0 0
111 1
239 0
2
0 91 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut8
3
0 0
111 1
240 0
2
0 93 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut9
3
0 0
111 1
241 0
2
0 95 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut1
3
0 0
112 1
192 0
2
0 1 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut10
3
0 0
112 1
193 0
2
0 2 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut11
3
0 0
112 1
194 0
2
0 3 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut12
3
0 0
112 1
195 0
2
0 4 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut13
3
0 0
112 1
196 0
2
0 5 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut14
3
0 0
112 1
197 0
2
0 7 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut15
3
0 0
112 1
198 0
2
0 9 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut16
3
0 0
112 1
199 0
2
0 11 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut17
3
0 0
112 1
200 0
2
0 13 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut18
3
0 0
112 1
201 0
2
0 15 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut19
3
0 0
112 1
202 0
2
0 17 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut2
3
0 0
112 1
203 0
2
0 19 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut20
3
0 0
112 1
204 0
2
0 21 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut21
3
0 0
112 1
205 0
2
0 23 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut22
3
0 0
112 1
206 0
2
0 25 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut23
3
0 0
112 1
207 0
2
0 27 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut24
3
0 0
112 1
208 0
2
0 29 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut25
3
0 0
112 1
209 0
2
0 31 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut26
3
0 0
112 1
210 0
2
0 33 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut27
3
0 0
112 1
211 0
2
0 35 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut28
3
0 0
112 1
212 0
2
0 37 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut29
3
0 0
112 1
213 0
2
0 39 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut3
3
0 0
112 1
214 0
2
0 41 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut30
3
0 0
112 1
215 0
2
0 43 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut31
3
0 0
112 1
216 0
2
0 45 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut32
3
0 0
112 1
217 0
2
0 47 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut33
3
0 0
112 1
218 0
2
0 49 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut34
3
0 0
112 1
219 0
2
0 51 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut35
3
0 0
112 1
220 0
2
0 53 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut36
3
0 0
112 1
221 0
2
0 55 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut37
3
0 0
112 1
222 0
2
0 57 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut38
3
0 0
112 1
223 0
2
0 59 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut39
3
0 0
112 1
224 0
2
0 61 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut4
3
0 0
112 1
225 0
2
0 63 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut40
3
0 0
112 1
226 0
2
0 65 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut41
3
0 0
112 1
227 0
2
0 67 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut42
3
0 0
112 1
228 0
2
0 69 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut43
3
0 0
112 1
229 0
2
0 71 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut44
3
0 0
112 1
230 0
2
0 73 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut45
3
0 0
112 1
231 0
2
0 75 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut46
3
0 0
112 1
232 0
2
0 77 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut47
3
0 0
112 1
233 0
2
0 79 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut48
3
0 0
112 1
234 0
2
0 81 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut49
3
0 0
112 1
235 0
2
0 83 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut5
3
0 0
112 1
236 0
2
0 85 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut50
3
0 0
112 1
237 0
2
0 87 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut6
3
0 0
112 1
238 0
2
0 89 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut7
3
0 0
112 1
239 0
2
0 91 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut8
3
0 0
112 1
240 0
2
0 93 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut9
3
0 0
112 1
241 0
2
0 95 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut1
3
0 0
113 1
192 0
2
0 1 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut10
3
0 0
113 1
193 0
2
0 2 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut11
3
0 0
113 1
194 0
2
0 3 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut12
3
0 0
113 1
195 0
2
0 4 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut13
3
0 0
113 1
196 0
2
0 5 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut14
3
0 0
113 1
197 0
2
0 7 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut15
3
0 0
113 1
198 0
2
0 9 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut16
3
0 0
113 1
199 0
2
0 11 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut17
3
0 0
113 1
200 0
2
0 13 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut18
3
0 0
113 1
201 0
2
0 15 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut19
3
0 0
113 1
202 0
2
0 17 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut2
3
0 0
113 1
203 0
2
0 19 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut20
3
0 0
113 1
204 0
2
0 21 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut21
3
0 0
113 1
205 0
2
0 23 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut22
3
0 0
113 1
206 0
2
0 25 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut23
3
0 0
113 1
207 0
2
0 27 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut24
3
0 0
113 1
208 0
2
0 29 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut25
3
0 0
113 1
209 0
2
0 31 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut26
3
0 0
113 1
210 0
2
0 33 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut27
3
0 0
113 1
211 0
2
0 35 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut28
3
0 0
113 1
212 0
2
0 37 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut29
3
0 0
113 1
213 0
2
0 39 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut3
3
0 0
113 1
214 0
2
0 41 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut30
3
0 0
113 1
215 0
2
0 43 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut31
3
0 0
113 1
216 0
2
0 45 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut32
3
0 0
113 1
217 0
2
0 47 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut33
3
0 0
113 1
218 0
2
0 49 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut34
3
0 0
113 1
219 0
2
0 51 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut35
3
0 0
113 1
220 0
2
0 53 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut36
3
0 0
113 1
221 0
2
0 55 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut37
3
0 0
113 1
222 0
2
0 57 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut38
3
0 0
113 1
223 0
2
0 59 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut39
3
0 0
113 1
224 0
2
0 61 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut4
3
0 0
113 1
225 0
2
0 63 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut40
3
0 0
113 1
226 0
2
0 65 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut41
3
0 0
113 1
227 0
2
0 67 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut42
3
0 0
113 1
228 0
2
0 69 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut43
3
0 0
113 1
229 0
2
0 71 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut44
3
0 0
113 1
230 0
2
0 73 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut45
3
0 0
113 1
231 0
2
0 75 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut46
3
0 0
113 1
232 0
2
0 77 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut47
3
0 0
113 1
233 0
2
0 79 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut48
3
0 0
113 1
234 0
2
0 81 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut49
3
0 0
113 1
235 0
2
0 83 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut5
3
0 0
113 1
236 0
2
0 85 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut50
3
0 0
113 1
237 0
2
0 87 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut6
3
0 0
113 1
238 0
2
0 89 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut7
3
0 0
113 1
239 0
2
0 91 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut8
3
0 0
113 1
240 0
2
0 93 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut9
3
0 0
113 1
241 0
2
0 95 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut1
3
0 0
114 1
192 0
2
0 1 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut10
3
0 0
114 1
193 0
2
0 2 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut11
3
0 0
114 1
194 0
2
0 3 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut12
3
0 0
114 1
195 0
2
0 4 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut13
3
0 0
114 1
196 0
2
0 5 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut14
3
0 0
114 1
197 0
2
0 7 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut15
3
0 0
114 1
198 0
2
0 9 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut16
3
0 0
114 1
199 0
2
0 11 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut17
3
0 0
114 1
200 0
2
0 13 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut18
3
0 0
114 1
201 0
2
0 15 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut19
3
0 0
114 1
202 0
2
0 17 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut2
3
0 0
114 1
203 0
2
0 19 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut20
3
0 0
114 1
204 0
2
0 21 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut21
3
0 0
114 1
205 0
2
0 23 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut22
3
0 0
114 1
206 0
2
0 25 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut23
3
0 0
114 1
207 0
2
0 27 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut24
3
0 0
114 1
208 0
2
0 29 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut25
3
0 0
114 1
209 0
2
0 31 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut26
3
0 0
114 1
210 0
2
0 33 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut27
3
0 0
114 1
211 0
2
0 35 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut28
3
0 0
114 1
212 0
2
0 37 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut29
3
0 0
114 1
213 0
2
0 39 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut3
3
0 0
114 1
214 0
2
0 41 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut30
3
0 0
114 1
215 0
2
0 43 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut31
3
0 0
114 1
216 0
2
0 45 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut32
3
0 0
114 1
217 0
2
0 47 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut33
3
0 0
114 1
218 0
2
0 49 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut34
3
0 0
114 1
219 0
2
0 51 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut35
3
0 0
114 1
220 0
2
0 53 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut36
3
0 0
114 1
221 0
2
0 55 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut37
3
0 0
114 1
222 0
2
0 57 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut38
3
0 0
114 1
223 0
2
0 59 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut39
3
0 0
114 1
224 0
2
0 61 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut4
3
0 0
114 1
225 0
2
0 63 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut40
3
0 0
114 1
226 0
2
0 65 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut41
3
0 0
114 1
227 0
2
0 67 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut42
3
0 0
114 1
228 0
2
0 69 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut43
3
0 0
114 1
229 0
2
0 71 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut44
3
0 0
114 1
230 0
2
0 73 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut45
3
0 0
114 1
231 0
2
0 75 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut46
3
0 0
114 1
232 0
2
0 77 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut47
3
0 0
114 1
233 0
2
0 79 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut48
3
0 0
114 1
234 0
2
0 81 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut49
3
0 0
114 1
235 0
2
0 83 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut5
3
0 0
114 1
236 0
2
0 85 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut50
3
0 0
114 1
237 0
2
0 87 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut6
3
0 0
114 1
238 0
2
0 89 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut7
3
0 0
114 1
239 0
2
0 91 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut8
3
0 0
114 1
240 0
2
0 93 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut9
3
0 0
114 1
241 0
2
0 95 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut1
3
0 0
115 1
192 0
2
0 1 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut10
3
0 0
115 1
193 0
2
0 2 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut11
3
0 0
115 1
194 0
2
0 3 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut12
3
0 0
115 1
195 0
2
0 4 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut13
3
0 0
115 1
196 0
2
0 5 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut14
3
0 0
115 1
197 0
2
0 7 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut15
3
0 0
115 1
198 0
2
0 9 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut16
3
0 0
115 1
199 0
2
0 11 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut17
3
0 0
115 1
200 0
2
0 13 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut18
3
0 0
115 1
201 0
2
0 15 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut19
3
0 0
115 1
202 0
2
0 17 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut2
3
0 0
115 1
203 0
2
0 19 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut20
3
0 0
115 1
204 0
2
0 21 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut21
3
0 0
115 1
205 0
2
0 23 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut22
3
0 0
115 1
206 0
2
0 25 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut23
3
0 0
115 1
207 0
2
0 27 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut24
3
0 0
115 1
208 0
2
0 29 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut25
3
0 0
115 1
209 0
2
0 31 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut26
3
0 0
115 1
210 0
2
0 33 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut27
3
0 0
115 1
211 0
2
0 35 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut28
3
0 0
115 1
212 0
2
0 37 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut29
3
0 0
115 1
213 0
2
0 39 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut3
3
0 0
115 1
214 0
2
0 41 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut30
3
0 0
115 1
215 0
2
0 43 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut31
3
0 0
115 1
216 0
2
0 45 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut32
3
0 0
115 1
217 0
2
0 47 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut33
3
0 0
115 1
218 0
2
0 49 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut34
3
0 0
115 1
219 0
2
0 51 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut35
3
0 0
115 1
220 0
2
0 53 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut36
3
0 0
115 1
221 0
2
0 55 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut37
3
0 0
115 1
222 0
2
0 57 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut38
3
0 0
115 1
223 0
2
0 59 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut39
3
0 0
115 1
224 0
2
0 61 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut4
3
0 0
115 1
225 0
2
0 63 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut40
3
0 0
115 1
226 0
2
0 65 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut41
3
0 0
115 1
227 0
2
0 67 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut42
3
0 0
115 1
228 0
2
0 69 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut43
3
0 0
115 1
229 0
2
0 71 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut44
3
0 0
115 1
230 0
2
0 73 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut45
3
0 0
115 1
231 0
2
0 75 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut46
3
0 0
115 1
232 0
2
0 77 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut47
3
0 0
115 1
233 0
2
0 79 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut48
3
0 0
115 1
234 0
2
0 81 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut49
3
0 0
115 1
235 0
2
0 83 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut5
3
0 0
115 1
236 0
2
0 85 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut50
3
0 0
115 1
237 0
2
0 87 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut6
3
0 0
115 1
238 0
2
0 89 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut7
3
0 0
115 1
239 0
2
0 91 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut8
3
0 0
115 1
240 0
2
0 93 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut9
3
0 0
115 1
241 0
2
0 95 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut1
3
0 0
116 1
192 0
2
0 1 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut10
3
0 0
116 1
193 0
2
0 2 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut11
3
0 0
116 1
194 0
2
0 3 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut12
3
0 0
116 1
195 0
2
0 4 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut13
3
0 0
116 1
196 0
2
0 5 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut14
3
0 0
116 1
197 0
2
0 7 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut15
3
0 0
116 1
198 0
2
0 9 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut16
3
0 0
116 1
199 0
2
0 11 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut17
3
0 0
116 1
200 0
2
0 13 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut18
3
0 0
116 1
201 0
2
0 15 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut19
3
0 0
116 1
202 0
2
0 17 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut2
3
0 0
116 1
203 0
2
0 19 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut20
3
0 0
116 1
204 0
2
0 21 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut21
3
0 0
116 1
205 0
2
0 23 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut22
3
0 0
116 1
206 0
2
0 25 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut23
3
0 0
116 1
207 0
2
0 27 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut24
3
0 0
116 1
208 0
2
0 29 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut25
3
0 0
116 1
209 0
2
0 31 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut26
3
0 0
116 1
210 0
2
0 33 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut27
3
0 0
116 1
211 0
2
0 35 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut28
3
0 0
116 1
212 0
2
0 37 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut29
3
0 0
116 1
213 0
2
0 39 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut3
3
0 0
116 1
214 0
2
0 41 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut30
3
0 0
116 1
215 0
2
0 43 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut31
3
0 0
116 1
216 0
2
0 45 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut32
3
0 0
116 1
217 0
2
0 47 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut33
3
0 0
116 1
218 0
2
0 49 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut34
3
0 0
116 1
219 0
2
0 51 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut35
3
0 0
116 1
220 0
2
0 53 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut36
3
0 0
116 1
221 0
2
0 55 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut37
3
0 0
116 1
222 0
2
0 57 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut38
3
0 0
116 1
223 0
2
0 59 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut39
3
0 0
116 1
224 0
2
0 61 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut4
3
0 0
116 1
225 0
2
0 63 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut40
3
0 0
116 1
226 0
2
0 65 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut41
3
0 0
116 1
227 0
2
0 67 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut42
3
0 0
116 1
228 0
2
0 69 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut43
3
0 0
116 1
229 0
2
0 71 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut44
3
0 0
116 1
230 0
2
0 73 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut45
3
0 0
116 1
231 0
2
0 75 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut46
3
0 0
116 1
232 0
2
0 77 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut47
3
0 0
116 1
233 0
2
0 79 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut48
3
0 0
116 1
234 0
2
0 81 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut49
3
0 0
116 1
235 0
2
0 83 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut5
3
0 0
116 1
236 0
2
0 85 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut50
3
0 0
116 1
237 0
2
0 87 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut6
3
0 0
116 1
238 0
2
0 89 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut7
3
0 0
116 1
239 0
2
0 91 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut8
3
0 0
116 1
240 0
2
0 93 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut9
3
0 0
116 1
241 0
2
0 95 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut1
3
0 0
117 1
192 0
2
0 1 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut10
3
0 0
117 1
193 0
2
0 2 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut11
3
0 0
117 1
194 0
2
0 3 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut12
3
0 0
117 1
195 0
2
0 4 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut13
3
0 0
117 1
196 0
2
0 5 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut14
3
0 0
117 1
197 0
2
0 7 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut15
3
0 0
117 1
198 0
2
0 9 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut16
3
0 0
117 1
199 0
2
0 11 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut17
3
0 0
117 1
200 0
2
0 13 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut18
3
0 0
117 1
201 0
2
0 15 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut19
3
0 0
117 1
202 0
2
0 17 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut2
3
0 0
117 1
203 0
2
0 19 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut20
3
0 0
117 1
204 0
2
0 21 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut21
3
0 0
117 1
205 0
2
0 23 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut22
3
0 0
117 1
206 0
2
0 25 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut23
3
0 0
117 1
207 0
2
0 27 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut24
3
0 0
117 1
208 0
2
0 29 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut25
3
0 0
117 1
209 0
2
0 31 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut26
3
0 0
117 1
210 0
2
0 33 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut27
3
0 0
117 1
211 0
2
0 35 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut28
3
0 0
117 1
212 0
2
0 37 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut29
3
0 0
117 1
213 0
2
0 39 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut3
3
0 0
117 1
214 0
2
0 41 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut30
3
0 0
117 1
215 0
2
0 43 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut31
3
0 0
117 1
216 0
2
0 45 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut32
3
0 0
117 1
217 0
2
0 47 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut33
3
0 0
117 1
218 0
2
0 49 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut34
3
0 0
117 1
219 0
2
0 51 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut35
3
0 0
117 1
220 0
2
0 53 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut36
3
0 0
117 1
221 0
2
0 55 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut37
3
0 0
117 1
222 0
2
0 57 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut38
3
0 0
117 1
223 0
2
0 59 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut39
3
0 0
117 1
224 0
2
0 61 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut4
3
0 0
117 1
225 0
2
0 63 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut40
3
0 0
117 1
226 0
2
0 65 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut41
3
0 0
117 1
227 0
2
0 67 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut42
3
0 0
117 1
228 0
2
0 69 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut43
3
0 0
117 1
229 0
2
0 71 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut44
3
0 0
117 1
230 0
2
0 73 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut45
3
0 0
117 1
231 0
2
0 75 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut46
3
0 0
117 1
232 0
2
0 77 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut47
3
0 0
117 1
233 0
2
0 79 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut48
3
0 0
117 1
234 0
2
0 81 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut49
3
0 0
117 1
235 0
2
0 83 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut5
3
0 0
117 1
236 0
2
0 85 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut50
3
0 0
117 1
237 0
2
0 87 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut6
3
0 0
117 1
238 0
2
0 89 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut7
3
0 0
117 1
239 0
2
0 91 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut8
3
0 0
117 1
240 0
2
0 93 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut9
3
0 0
117 1
241 0
2
0 95 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
118 1
192 0
2
0 1 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
118 1
193 0
2
0 2 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
118 1
194 0
2
0 3 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
118 1
195 0
2
0 4 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
118 1
196 0
2
0 5 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
118 1
197 0
2
0 7 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
118 1
198 0
2
0 9 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
118 1
199 0
2
0 11 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
118 1
200 0
2
0 13 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
118 1
201 0
2
0 15 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
118 1
202 0
2
0 17 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
118 1
203 0
2
0 19 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
118 1
204 0
2
0 21 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
118 1
205 0
2
0 23 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
118 1
206 0
2
0 25 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
118 1
207 0
2
0 27 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
118 1
208 0
2
0 29 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
118 1
209 0
2
0 31 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
118 1
210 0
2
0 33 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
118 1
211 0
2
0 35 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
118 1
212 0
2
0 37 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
118 1
213 0
2
0 39 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
118 1
214 0
2
0 41 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
118 1
215 0
2
0 43 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut31
3
0 0
118 1
216 0
2
0 45 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut32
3
0 0
118 1
217 0
2
0 47 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut33
3
0 0
118 1
218 0
2
0 49 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut34
3
0 0
118 1
219 0
2
0 51 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut35
3
0 0
118 1
220 0
2
0 53 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut36
3
0 0
118 1
221 0
2
0 55 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut37
3
0 0
118 1
222 0
2
0 57 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut38
3
0 0
118 1
223 0
2
0 59 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut39
3
0 0
118 1
224 0
2
0 61 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
118 1
225 0
2
0 63 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut40
3
0 0
118 1
226 0
2
0 65 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut41
3
0 0
118 1
227 0
2
0 67 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut42
3
0 0
118 1
228 0
2
0 69 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut43
3
0 0
118 1
229 0
2
0 71 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut44
3
0 0
118 1
230 0
2
0 73 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut45
3
0 0
118 1
231 0
2
0 75 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut46
3
0 0
118 1
232 0
2
0 77 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut47
3
0 0
118 1
233 0
2
0 79 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut48
3
0 0
118 1
234 0
2
0 81 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut49
3
0 0
118 1
235 0
2
0 83 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
118 1
236 0
2
0 85 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut50
3
0 0
118 1
237 0
2
0 87 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
118 1
238 0
2
0 89 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
118 1
239 0
2
0 91 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
118 1
240 0
2
0 93 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
118 1
241 0
2
0 95 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut1
3
0 0
119 1
192 0
2
0 1 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut10
3
0 0
119 1
193 0
2
0 2 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut11
3
0 0
119 1
194 0
2
0 3 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut12
3
0 0
119 1
195 0
2
0 4 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut13
3
0 0
119 1
196 0
2
0 5 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut14
3
0 0
119 1
197 0
2
0 7 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut15
3
0 0
119 1
198 0
2
0 9 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut16
3
0 0
119 1
199 0
2
0 11 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut17
3
0 0
119 1
200 0
2
0 13 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut18
3
0 0
119 1
201 0
2
0 15 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut19
3
0 0
119 1
202 0
2
0 17 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut2
3
0 0
119 1
203 0
2
0 19 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut20
3
0 0
119 1
204 0
2
0 21 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut21
3
0 0
119 1
205 0
2
0 23 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut22
3
0 0
119 1
206 0
2
0 25 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut23
3
0 0
119 1
207 0
2
0 27 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut24
3
0 0
119 1
208 0
2
0 29 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut25
3
0 0
119 1
209 0
2
0 31 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut26
3
0 0
119 1
210 0
2
0 33 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut27
3
0 0
119 1
211 0
2
0 35 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut28
3
0 0
119 1
212 0
2
0 37 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut29
3
0 0
119 1
213 0
2
0 39 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut3
3
0 0
119 1
214 0
2
0 41 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut30
3
0 0
119 1
215 0
2
0 43 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut31
3
0 0
119 1
216 0
2
0 45 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut32
3
0 0
119 1
217 0
2
0 47 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut33
3
0 0
119 1
218 0
2
0 49 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut34
3
0 0
119 1
219 0
2
0 51 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut35
3
0 0
119 1
220 0
2
0 53 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut36
3
0 0
119 1
221 0
2
0 55 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut37
3
0 0
119 1
222 0
2
0 57 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut38
3
0 0
119 1
223 0
2
0 59 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut39
3
0 0
119 1
224 0
2
0 61 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut4
3
0 0
119 1
225 0
2
0 63 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut40
3
0 0
119 1
226 0
2
0 65 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut41
3
0 0
119 1
227 0
2
0 67 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut42
3
0 0
119 1
228 0
2
0 69 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut43
3
0 0
119 1
229 0
2
0 71 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut44
3
0 0
119 1
230 0
2
0 73 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut45
3
0 0
119 1
231 0
2
0 75 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut46
3
0 0
119 1
232 0
2
0 77 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut47
3
0 0
119 1
233 0
2
0 79 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut48
3
0 0
119 1
234 0
2
0 81 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut49
3
0 0
119 1
235 0
2
0 83 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut5
3
0 0
119 1
236 0
2
0 85 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut50
3
0 0
119 1
237 0
2
0 87 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut6
3
0 0
119 1
238 0
2
0 89 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut7
3
0 0
119 1
239 0
2
0 91 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut8
3
0 0
119 1
240 0
2
0 93 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut9
3
0 0
119 1
241 0
2
0 95 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut1
3
0 0
120 1
192 0
2
0 1 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut10
3
0 0
120 1
193 0
2
0 2 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut11
3
0 0
120 1
194 0
2
0 3 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut12
3
0 0
120 1
195 0
2
0 4 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut13
3
0 0
120 1
196 0
2
0 5 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut14
3
0 0
120 1
197 0
2
0 7 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut15
3
0 0
120 1
198 0
2
0 9 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut16
3
0 0
120 1
199 0
2
0 11 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut17
3
0 0
120 1
200 0
2
0 13 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut18
3
0 0
120 1
201 0
2
0 15 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut19
3
0 0
120 1
202 0
2
0 17 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut2
3
0 0
120 1
203 0
2
0 19 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut20
3
0 0
120 1
204 0
2
0 21 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut21
3
0 0
120 1
205 0
2
0 23 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut22
3
0 0
120 1
206 0
2
0 25 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut23
3
0 0
120 1
207 0
2
0 27 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut24
3
0 0
120 1
208 0
2
0 29 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut25
3
0 0
120 1
209 0
2
0 31 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut26
3
0 0
120 1
210 0
2
0 33 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut27
3
0 0
120 1
211 0
2
0 35 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut28
3
0 0
120 1
212 0
2
0 37 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut29
3
0 0
120 1
213 0
2
0 39 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut3
3
0 0
120 1
214 0
2
0 41 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut30
3
0 0
120 1
215 0
2
0 43 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut31
3
0 0
120 1
216 0
2
0 45 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut32
3
0 0
120 1
217 0
2
0 47 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut33
3
0 0
120 1
218 0
2
0 49 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut34
3
0 0
120 1
219 0
2
0 51 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut35
3
0 0
120 1
220 0
2
0 53 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut36
3
0 0
120 1
221 0
2
0 55 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut37
3
0 0
120 1
222 0
2
0 57 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut38
3
0 0
120 1
223 0
2
0 59 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut39
3
0 0
120 1
224 0
2
0 61 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut4
3
0 0
120 1
225 0
2
0 63 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut40
3
0 0
120 1
226 0
2
0 65 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut41
3
0 0
120 1
227 0
2
0 67 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut42
3
0 0
120 1
228 0
2
0 69 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut43
3
0 0
120 1
229 0
2
0 71 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut44
3
0 0
120 1
230 0
2
0 73 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut45
3
0 0
120 1
231 0
2
0 75 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut46
3
0 0
120 1
232 0
2
0 77 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut47
3
0 0
120 1
233 0
2
0 79 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut48
3
0 0
120 1
234 0
2
0 81 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut49
3
0 0
120 1
235 0
2
0 83 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut5
3
0 0
120 1
236 0
2
0 85 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut50
3
0 0
120 1
237 0
2
0 87 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut6
3
0 0
120 1
238 0
2
0 89 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut7
3
0 0
120 1
239 0
2
0 91 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut8
3
0 0
120 1
240 0
2
0 93 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut9
3
0 0
120 1
241 0
2
0 95 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut1
3
0 0
121 1
192 0
2
0 1 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut10
3
0 0
121 1
193 0
2
0 2 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut11
3
0 0
121 1
194 0
2
0 3 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut12
3
0 0
121 1
195 0
2
0 4 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut13
3
0 0
121 1
196 0
2
0 5 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut14
3
0 0
121 1
197 0
2
0 7 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut15
3
0 0
121 1
198 0
2
0 9 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut16
3
0 0
121 1
199 0
2
0 11 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut17
3
0 0
121 1
200 0
2
0 13 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut18
3
0 0
121 1
201 0
2
0 15 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut19
3
0 0
121 1
202 0
2
0 17 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut2
3
0 0
121 1
203 0
2
0 19 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut20
3
0 0
121 1
204 0
2
0 21 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut21
3
0 0
121 1
205 0
2
0 23 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut22
3
0 0
121 1
206 0
2
0 25 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut23
3
0 0
121 1
207 0
2
0 27 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut24
3
0 0
121 1
208 0
2
0 29 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut25
3
0 0
121 1
209 0
2
0 31 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut26
3
0 0
121 1
210 0
2
0 33 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut27
3
0 0
121 1
211 0
2
0 35 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut28
3
0 0
121 1
212 0
2
0 37 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut29
3
0 0
121 1
213 0
2
0 39 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut3
3
0 0
121 1
214 0
2
0 41 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut30
3
0 0
121 1
215 0
2
0 43 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut31
3
0 0
121 1
216 0
2
0 45 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut32
3
0 0
121 1
217 0
2
0 47 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut33
3
0 0
121 1
218 0
2
0 49 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut34
3
0 0
121 1
219 0
2
0 51 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut35
3
0 0
121 1
220 0
2
0 53 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut36
3
0 0
121 1
221 0
2
0 55 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut37
3
0 0
121 1
222 0
2
0 57 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut38
3
0 0
121 1
223 0
2
0 59 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut39
3
0 0
121 1
224 0
2
0 61 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut4
3
0 0
121 1
225 0
2
0 63 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut40
3
0 0
121 1
226 0
2
0 65 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut41
3
0 0
121 1
227 0
2
0 67 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut42
3
0 0
121 1
228 0
2
0 69 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut43
3
0 0
121 1
229 0
2
0 71 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut44
3
0 0
121 1
230 0
2
0 73 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut45
3
0 0
121 1
231 0
2
0 75 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut46
3
0 0
121 1
232 0
2
0 77 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut47
3
0 0
121 1
233 0
2
0 79 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut48
3
0 0
121 1
234 0
2
0 81 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut49
3
0 0
121 1
235 0
2
0 83 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut5
3
0 0
121 1
236 0
2
0 85 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut50
3
0 0
121 1
237 0
2
0 87 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut6
3
0 0
121 1
238 0
2
0 89 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut7
3
0 0
121 1
239 0
2
0 91 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut8
3
0 0
121 1
240 0
2
0 93 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut9
3
0 0
121 1
241 0
2
0 95 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut1
3
0 0
122 1
192 0
2
0 1 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut10
3
0 0
122 1
193 0
2
0 2 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut11
3
0 0
122 1
194 0
2
0 3 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut12
3
0 0
122 1
195 0
2
0 4 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut13
3
0 0
122 1
196 0
2
0 5 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut14
3
0 0
122 1
197 0
2
0 7 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut15
3
0 0
122 1
198 0
2
0 9 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut16
3
0 0
122 1
199 0
2
0 11 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut17
3
0 0
122 1
200 0
2
0 13 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut18
3
0 0
122 1
201 0
2
0 15 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut19
3
0 0
122 1
202 0
2
0 17 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut2
3
0 0
122 1
203 0
2
0 19 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut20
3
0 0
122 1
204 0
2
0 21 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut21
3
0 0
122 1
205 0
2
0 23 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut22
3
0 0
122 1
206 0
2
0 25 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut23
3
0 0
122 1
207 0
2
0 27 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut24
3
0 0
122 1
208 0
2
0 29 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut25
3
0 0
122 1
209 0
2
0 31 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut26
3
0 0
122 1
210 0
2
0 33 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut27
3
0 0
122 1
211 0
2
0 35 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut28
3
0 0
122 1
212 0
2
0 37 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut29
3
0 0
122 1
213 0
2
0 39 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut3
3
0 0
122 1
214 0
2
0 41 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut30
3
0 0
122 1
215 0
2
0 43 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut31
3
0 0
122 1
216 0
2
0 45 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut32
3
0 0
122 1
217 0
2
0 47 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut33
3
0 0
122 1
218 0
2
0 49 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut34
3
0 0
122 1
219 0
2
0 51 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut35
3
0 0
122 1
220 0
2
0 53 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut36
3
0 0
122 1
221 0
2
0 55 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut37
3
0 0
122 1
222 0
2
0 57 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut38
3
0 0
122 1
223 0
2
0 59 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut39
3
0 0
122 1
224 0
2
0 61 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut4
3
0 0
122 1
225 0
2
0 63 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut40
3
0 0
122 1
226 0
2
0 65 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut41
3
0 0
122 1
227 0
2
0 67 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut42
3
0 0
122 1
228 0
2
0 69 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut43
3
0 0
122 1
229 0
2
0 71 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut44
3
0 0
122 1
230 0
2
0 73 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut45
3
0 0
122 1
231 0
2
0 75 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut46
3
0 0
122 1
232 0
2
0 77 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut47
3
0 0
122 1
233 0
2
0 79 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut48
3
0 0
122 1
234 0
2
0 81 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut49
3
0 0
122 1
235 0
2
0 83 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut5
3
0 0
122 1
236 0
2
0 85 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut50
3
0 0
122 1
237 0
2
0 87 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut6
3
0 0
122 1
238 0
2
0 89 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut7
3
0 0
122 1
239 0
2
0 91 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut8
3
0 0
122 1
240 0
2
0 93 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut9
3
0 0
122 1
241 0
2
0 95 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut1
3
0 0
123 1
192 0
2
0 1 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut10
3
0 0
123 1
193 0
2
0 2 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut11
3
0 0
123 1
194 0
2
0 3 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut12
3
0 0
123 1
195 0
2
0 4 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut13
3
0 0
123 1
196 0
2
0 5 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut14
3
0 0
123 1
197 0
2
0 7 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut15
3
0 0
123 1
198 0
2
0 9 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut16
3
0 0
123 1
199 0
2
0 11 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut17
3
0 0
123 1
200 0
2
0 13 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut18
3
0 0
123 1
201 0
2
0 15 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut19
3
0 0
123 1
202 0
2
0 17 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut2
3
0 0
123 1
203 0
2
0 19 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut20
3
0 0
123 1
204 0
2
0 21 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut21
3
0 0
123 1
205 0
2
0 23 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut22
3
0 0
123 1
206 0
2
0 25 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut23
3
0 0
123 1
207 0
2
0 27 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut24
3
0 0
123 1
208 0
2
0 29 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut25
3
0 0
123 1
209 0
2
0 31 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut26
3
0 0
123 1
210 0
2
0 33 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut27
3
0 0
123 1
211 0
2
0 35 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut28
3
0 0
123 1
212 0
2
0 37 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut29
3
0 0
123 1
213 0
2
0 39 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut3
3
0 0
123 1
214 0
2
0 41 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut30
3
0 0
123 1
215 0
2
0 43 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut31
3
0 0
123 1
216 0
2
0 45 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut32
3
0 0
123 1
217 0
2
0 47 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut33
3
0 0
123 1
218 0
2
0 49 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut34
3
0 0
123 1
219 0
2
0 51 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut35
3
0 0
123 1
220 0
2
0 53 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut36
3
0 0
123 1
221 0
2
0 55 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut37
3
0 0
123 1
222 0
2
0 57 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut38
3
0 0
123 1
223 0
2
0 59 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut39
3
0 0
123 1
224 0
2
0 61 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut4
3
0 0
123 1
225 0
2
0 63 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut40
3
0 0
123 1
226 0
2
0 65 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut41
3
0 0
123 1
227 0
2
0 67 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut42
3
0 0
123 1
228 0
2
0 69 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut43
3
0 0
123 1
229 0
2
0 71 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut44
3
0 0
123 1
230 0
2
0 73 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut45
3
0 0
123 1
231 0
2
0 75 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut46
3
0 0
123 1
232 0
2
0 77 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut47
3
0 0
123 1
233 0
2
0 79 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut48
3
0 0
123 1
234 0
2
0 81 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut49
3
0 0
123 1
235 0
2
0 83 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut5
3
0 0
123 1
236 0
2
0 85 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut50
3
0 0
123 1
237 0
2
0 87 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut6
3
0 0
123 1
238 0
2
0 89 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut7
3
0 0
123 1
239 0
2
0 91 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut8
3
0 0
123 1
240 0
2
0 93 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut9
3
0 0
123 1
241 0
2
0 95 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut1
3
0 0
124 1
192 0
2
0 1 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut10
3
0 0
124 1
193 0
2
0 2 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut11
3
0 0
124 1
194 0
2
0 3 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut12
3
0 0
124 1
195 0
2
0 4 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut13
3
0 0
124 1
196 0
2
0 5 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut14
3
0 0
124 1
197 0
2
0 7 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut15
3
0 0
124 1
198 0
2
0 9 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut16
3
0 0
124 1
199 0
2
0 11 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut17
3
0 0
124 1
200 0
2
0 13 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut18
3
0 0
124 1
201 0
2
0 15 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut19
3
0 0
124 1
202 0
2
0 17 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut2
3
0 0
124 1
203 0
2
0 19 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut20
3
0 0
124 1
204 0
2
0 21 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut21
3
0 0
124 1
205 0
2
0 23 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut22
3
0 0
124 1
206 0
2
0 25 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut23
3
0 0
124 1
207 0
2
0 27 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut24
3
0 0
124 1
208 0
2
0 29 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut25
3
0 0
124 1
209 0
2
0 31 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut26
3
0 0
124 1
210 0
2
0 33 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut27
3
0 0
124 1
211 0
2
0 35 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut28
3
0 0
124 1
212 0
2
0 37 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut29
3
0 0
124 1
213 0
2
0 39 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut3
3
0 0
124 1
214 0
2
0 41 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut30
3
0 0
124 1
215 0
2
0 43 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut31
3
0 0
124 1
216 0
2
0 45 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut32
3
0 0
124 1
217 0
2
0 47 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut33
3
0 0
124 1
218 0
2
0 49 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut34
3
0 0
124 1
219 0
2
0 51 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut35
3
0 0
124 1
220 0
2
0 53 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut36
3
0 0
124 1
221 0
2
0 55 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut37
3
0 0
124 1
222 0
2
0 57 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut38
3
0 0
124 1
223 0
2
0 59 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut39
3
0 0
124 1
224 0
2
0 61 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut4
3
0 0
124 1
225 0
2
0 63 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut40
3
0 0
124 1
226 0
2
0 65 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut41
3
0 0
124 1
227 0
2
0 67 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut42
3
0 0
124 1
228 0
2
0 69 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut43
3
0 0
124 1
229 0
2
0 71 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut44
3
0 0
124 1
230 0
2
0 73 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut45
3
0 0
124 1
231 0
2
0 75 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut46
3
0 0
124 1
232 0
2
0 77 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut47
3
0 0
124 1
233 0
2
0 79 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut48
3
0 0
124 1
234 0
2
0 81 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut49
3
0 0
124 1
235 0
2
0 83 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut5
3
0 0
124 1
236 0
2
0 85 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut50
3
0 0
124 1
237 0
2
0 87 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut6
3
0 0
124 1
238 0
2
0 89 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut7
3
0 0
124 1
239 0
2
0 91 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut8
3
0 0
124 1
240 0
2
0 93 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut9
3
0 0
124 1
241 0
2
0 95 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut1
3
0 0
125 1
192 0
2
0 1 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut10
3
0 0
125 1
193 0
2
0 2 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut11
3
0 0
125 1
194 0
2
0 3 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut12
3
0 0
125 1
195 0
2
0 4 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut13
3
0 0
125 1
196 0
2
0 5 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut14
3
0 0
125 1
197 0
2
0 7 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut15
3
0 0
125 1
198 0
2
0 9 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut16
3
0 0
125 1
199 0
2
0 11 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut17
3
0 0
125 1
200 0
2
0 13 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut18
3
0 0
125 1
201 0
2
0 15 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut19
3
0 0
125 1
202 0
2
0 17 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut2
3
0 0
125 1
203 0
2
0 19 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut20
3
0 0
125 1
204 0
2
0 21 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut21
3
0 0
125 1
205 0
2
0 23 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut22
3
0 0
125 1
206 0
2
0 25 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut23
3
0 0
125 1
207 0
2
0 27 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut24
3
0 0
125 1
208 0
2
0 29 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut25
3
0 0
125 1
209 0
2
0 31 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut26
3
0 0
125 1
210 0
2
0 33 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut27
3
0 0
125 1
211 0
2
0 35 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut28
3
0 0
125 1
212 0
2
0 37 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut29
3
0 0
125 1
213 0
2
0 39 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut3
3
0 0
125 1
214 0
2
0 41 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut30
3
0 0
125 1
215 0
2
0 43 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut31
3
0 0
125 1
216 0
2
0 45 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut32
3
0 0
125 1
217 0
2
0 47 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut33
3
0 0
125 1
218 0
2
0 49 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut34
3
0 0
125 1
219 0
2
0 51 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut35
3
0 0
125 1
220 0
2
0 53 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut36
3
0 0
125 1
221 0
2
0 55 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut37
3
0 0
125 1
222 0
2
0 57 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut38
3
0 0
125 1
223 0
2
0 59 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut39
3
0 0
125 1
224 0
2
0 61 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut4
3
0 0
125 1
225 0
2
0 63 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut40
3
0 0
125 1
226 0
2
0 65 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut41
3
0 0
125 1
227 0
2
0 67 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut42
3
0 0
125 1
228 0
2
0 69 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut43
3
0 0
125 1
229 0
2
0 71 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut44
3
0 0
125 1
230 0
2
0 73 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut45
3
0 0
125 1
231 0
2
0 75 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut46
3
0 0
125 1
232 0
2
0 77 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut47
3
0 0
125 1
233 0
2
0 79 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut48
3
0 0
125 1
234 0
2
0 81 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut49
3
0 0
125 1
235 0
2
0 83 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut5
3
0 0
125 1
236 0
2
0 85 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut50
3
0 0
125 1
237 0
2
0 87 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut6
3
0 0
125 1
238 0
2
0 89 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut7
3
0 0
125 1
239 0
2
0 91 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut8
3
0 0
125 1
240 0
2
0 93 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut9
3
0 0
125 1
241 0
2
0 95 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut1
3
0 0
126 1
192 0
2
0 1 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut10
3
0 0
126 1
193 0
2
0 2 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut11
3
0 0
126 1
194 0
2
0 3 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut12
3
0 0
126 1
195 0
2
0 4 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut13
3
0 0
126 1
196 0
2
0 5 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut14
3
0 0
126 1
197 0
2
0 7 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut15
3
0 0
126 1
198 0
2
0 9 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut16
3
0 0
126 1
199 0
2
0 11 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut17
3
0 0
126 1
200 0
2
0 13 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut18
3
0 0
126 1
201 0
2
0 15 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut19
3
0 0
126 1
202 0
2
0 17 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut2
3
0 0
126 1
203 0
2
0 19 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut20
3
0 0
126 1
204 0
2
0 21 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut21
3
0 0
126 1
205 0
2
0 23 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut22
3
0 0
126 1
206 0
2
0 25 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut23
3
0 0
126 1
207 0
2
0 27 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut24
3
0 0
126 1
208 0
2
0 29 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut25
3
0 0
126 1
209 0
2
0 31 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut26
3
0 0
126 1
210 0
2
0 33 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut27
3
0 0
126 1
211 0
2
0 35 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut28
3
0 0
126 1
212 0
2
0 37 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut29
3
0 0
126 1
213 0
2
0 39 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut3
3
0 0
126 1
214 0
2
0 41 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut30
3
0 0
126 1
215 0
2
0 43 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut31
3
0 0
126 1
216 0
2
0 45 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut32
3
0 0
126 1
217 0
2
0 47 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut33
3
0 0
126 1
218 0
2
0 49 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut34
3
0 0
126 1
219 0
2
0 51 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut35
3
0 0
126 1
220 0
2
0 53 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut36
3
0 0
126 1
221 0
2
0 55 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut37
3
0 0
126 1
222 0
2
0 57 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut38
3
0 0
126 1
223 0
2
0 59 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut39
3
0 0
126 1
224 0
2
0 61 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut4
3
0 0
126 1
225 0
2
0 63 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut40
3
0 0
126 1
226 0
2
0 65 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut41
3
0 0
126 1
227 0
2
0 67 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut42
3
0 0
126 1
228 0
2
0 69 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut43
3
0 0
126 1
229 0
2
0 71 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut44
3
0 0
126 1
230 0
2
0 73 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut45
3
0 0
126 1
231 0
2
0 75 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut46
3
0 0
126 1
232 0
2
0 77 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut47
3
0 0
126 1
233 0
2
0 79 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut48
3
0 0
126 1
234 0
2
0 81 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut49
3
0 0
126 1
235 0
2
0 83 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut5
3
0 0
126 1
236 0
2
0 85 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut50
3
0 0
126 1
237 0
2
0 87 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut6
3
0 0
126 1
238 0
2
0 89 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut7
3
0 0
126 1
239 0
2
0 91 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut8
3
0 0
126 1
240 0
2
0 93 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut9
3
0 0
126 1
241 0
2
0 95 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut1
3
0 0
127 1
192 0
2
0 1 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut10
3
0 0
127 1
193 0
2
0 2 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut11
3
0 0
127 1
194 0
2
0 3 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut12
3
0 0
127 1
195 0
2
0 4 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut13
3
0 0
127 1
196 0
2
0 5 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut14
3
0 0
127 1
197 0
2
0 7 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut15
3
0 0
127 1
198 0
2
0 9 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut16
3
0 0
127 1
199 0
2
0 11 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut17
3
0 0
127 1
200 0
2
0 13 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut18
3
0 0
127 1
201 0
2
0 15 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut19
3
0 0
127 1
202 0
2
0 17 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut2
3
0 0
127 1
203 0
2
0 19 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut20
3
0 0
127 1
204 0
2
0 21 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut21
3
0 0
127 1
205 0
2
0 23 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut22
3
0 0
127 1
206 0
2
0 25 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut23
3
0 0
127 1
207 0
2
0 27 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut24
3
0 0
127 1
208 0
2
0 29 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut25
3
0 0
127 1
209 0
2
0 31 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut26
3
0 0
127 1
210 0
2
0 33 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut27
3
0 0
127 1
211 0
2
0 35 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut28
3
0 0
127 1
212 0
2
0 37 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut29
3
0 0
127 1
213 0
2
0 39 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut3
3
0 0
127 1
214 0
2
0 41 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut30
3
0 0
127 1
215 0
2
0 43 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut31
3
0 0
127 1
216 0
2
0 45 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut32
3
0 0
127 1
217 0
2
0 47 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut33
3
0 0
127 1
218 0
2
0 49 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut34
3
0 0
127 1
219 0
2
0 51 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut35
3
0 0
127 1
220 0
2
0 53 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut36
3
0 0
127 1
221 0
2
0 55 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut37
3
0 0
127 1
222 0
2
0 57 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut38
3
0 0
127 1
223 0
2
0 59 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut39
3
0 0
127 1
224 0
2
0 61 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut4
3
0 0
127 1
225 0
2
0 63 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut40
3
0 0
127 1
226 0
2
0 65 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut41
3
0 0
127 1
227 0
2
0 67 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut42
3
0 0
127 1
228 0
2
0 69 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut43
3
0 0
127 1
229 0
2
0 71 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut44
3
0 0
127 1
230 0
2
0 73 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut45
3
0 0
127 1
231 0
2
0 75 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut46
3
0 0
127 1
232 0
2
0 77 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut47
3
0 0
127 1
233 0
2
0 79 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut48
3
0 0
127 1
234 0
2
0 81 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut49
3
0 0
127 1
235 0
2
0 83 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut5
3
0 0
127 1
236 0
2
0 85 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut50
3
0 0
127 1
237 0
2
0 87 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut6
3
0 0
127 1
238 0
2
0 89 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut7
3
0 0
127 1
239 0
2
0 91 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut8
3
0 0
127 1
240 0
2
0 93 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut9
3
0 0
127 1
241 0
2
0 95 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut1
3
0 0
128 1
192 0
2
0 1 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut10
3
0 0
128 1
193 0
2
0 2 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut11
3
0 0
128 1
194 0
2
0 3 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut12
3
0 0
128 1
195 0
2
0 4 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut13
3
0 0
128 1
196 0
2
0 5 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut14
3
0 0
128 1
197 0
2
0 7 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut15
3
0 0
128 1
198 0
2
0 9 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut16
3
0 0
128 1
199 0
2
0 11 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut17
3
0 0
128 1
200 0
2
0 13 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut18
3
0 0
128 1
201 0
2
0 15 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut19
3
0 0
128 1
202 0
2
0 17 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut2
3
0 0
128 1
203 0
2
0 19 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut20
3
0 0
128 1
204 0
2
0 21 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut21
3
0 0
128 1
205 0
2
0 23 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut22
3
0 0
128 1
206 0
2
0 25 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut23
3
0 0
128 1
207 0
2
0 27 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut24
3
0 0
128 1
208 0
2
0 29 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut25
3
0 0
128 1
209 0
2
0 31 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut26
3
0 0
128 1
210 0
2
0 33 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut27
3
0 0
128 1
211 0
2
0 35 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut28
3
0 0
128 1
212 0
2
0 37 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut29
3
0 0
128 1
213 0
2
0 39 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut3
3
0 0
128 1
214 0
2
0 41 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut30
3
0 0
128 1
215 0
2
0 43 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut31
3
0 0
128 1
216 0
2
0 45 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut32
3
0 0
128 1
217 0
2
0 47 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut33
3
0 0
128 1
218 0
2
0 49 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut34
3
0 0
128 1
219 0
2
0 51 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut35
3
0 0
128 1
220 0
2
0 53 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut36
3
0 0
128 1
221 0
2
0 55 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut37
3
0 0
128 1
222 0
2
0 57 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut38
3
0 0
128 1
223 0
2
0 59 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut39
3
0 0
128 1
224 0
2
0 61 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut4
3
0 0
128 1
225 0
2
0 63 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut40
3
0 0
128 1
226 0
2
0 65 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut41
3
0 0
128 1
227 0
2
0 67 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut42
3
0 0
128 1
228 0
2
0 69 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut43
3
0 0
128 1
229 0
2
0 71 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut44
3
0 0
128 1
230 0
2
0 73 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut45
3
0 0
128 1
231 0
2
0 75 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut46
3
0 0
128 1
232 0
2
0 77 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut47
3
0 0
128 1
233 0
2
0 79 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut48
3
0 0
128 1
234 0
2
0 81 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut49
3
0 0
128 1
235 0
2
0 83 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut5
3
0 0
128 1
236 0
2
0 85 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut50
3
0 0
128 1
237 0
2
0 87 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut6
3
0 0
128 1
238 0
2
0 89 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut7
3
0 0
128 1
239 0
2
0 91 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut8
3
0 0
128 1
240 0
2
0 93 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut9
3
0 0
128 1
241 0
2
0 95 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
129 1
192 0
2
0 1 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
129 1
193 0
2
0 2 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
129 1
194 0
2
0 3 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
129 1
195 0
2
0 4 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
129 1
196 0
2
0 5 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
129 1
197 0
2
0 7 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
129 1
198 0
2
0 9 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
129 1
199 0
2
0 11 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
129 1
200 0
2
0 13 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
129 1
201 0
2
0 15 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
129 1
202 0
2
0 17 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
129 1
203 0
2
0 19 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
129 1
204 0
2
0 21 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
129 1
205 0
2
0 23 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
129 1
206 0
2
0 25 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
129 1
207 0
2
0 27 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
129 1
208 0
2
0 29 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
129 1
209 0
2
0 31 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
129 1
210 0
2
0 33 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
129 1
211 0
2
0 35 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
129 1
212 0
2
0 37 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
129 1
213 0
2
0 39 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
129 1
214 0
2
0 41 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
129 1
215 0
2
0 43 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut31
3
0 0
129 1
216 0
2
0 45 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut32
3
0 0
129 1
217 0
2
0 47 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut33
3
0 0
129 1
218 0
2
0 49 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut34
3
0 0
129 1
219 0
2
0 51 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut35
3
0 0
129 1
220 0
2
0 53 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut36
3
0 0
129 1
221 0
2
0 55 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut37
3
0 0
129 1
222 0
2
0 57 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut38
3
0 0
129 1
223 0
2
0 59 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut39
3
0 0
129 1
224 0
2
0 61 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
129 1
225 0
2
0 63 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut40
3
0 0
129 1
226 0
2
0 65 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut41
3
0 0
129 1
227 0
2
0 67 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut42
3
0 0
129 1
228 0
2
0 69 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut43
3
0 0
129 1
229 0
2
0 71 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut44
3
0 0
129 1
230 0
2
0 73 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut45
3
0 0
129 1
231 0
2
0 75 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut46
3
0 0
129 1
232 0
2
0 77 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut47
3
0 0
129 1
233 0
2
0 79 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut48
3
0 0
129 1
234 0
2
0 81 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut49
3
0 0
129 1
235 0
2
0 83 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
129 1
236 0
2
0 85 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut50
3
0 0
129 1
237 0
2
0 87 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
129 1
238 0
2
0 89 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
129 1
239 0
2
0 91 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
129 1
240 0
2
0 93 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
129 1
241 0
2
0 95 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut1
3
0 0
130 1
192 0
2
0 1 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut10
3
0 0
130 1
193 0
2
0 2 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut11
3
0 0
130 1
194 0
2
0 3 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut12
3
0 0
130 1
195 0
2
0 4 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut13
3
0 0
130 1
196 0
2
0 5 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut14
3
0 0
130 1
197 0
2
0 7 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut15
3
0 0
130 1
198 0
2
0 9 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut16
3
0 0
130 1
199 0
2
0 11 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut17
3
0 0
130 1
200 0
2
0 13 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut18
3
0 0
130 1
201 0
2
0 15 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut19
3
0 0
130 1
202 0
2
0 17 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut2
3
0 0
130 1
203 0
2
0 19 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut20
3
0 0
130 1
204 0
2
0 21 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut21
3
0 0
130 1
205 0
2
0 23 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut22
3
0 0
130 1
206 0
2
0 25 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut23
3
0 0
130 1
207 0
2
0 27 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut24
3
0 0
130 1
208 0
2
0 29 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut25
3
0 0
130 1
209 0
2
0 31 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut26
3
0 0
130 1
210 0
2
0 33 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut27
3
0 0
130 1
211 0
2
0 35 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut28
3
0 0
130 1
212 0
2
0 37 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut29
3
0 0
130 1
213 0
2
0 39 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut3
3
0 0
130 1
214 0
2
0 41 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut30
3
0 0
130 1
215 0
2
0 43 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut31
3
0 0
130 1
216 0
2
0 45 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut32
3
0 0
130 1
217 0
2
0 47 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut33
3
0 0
130 1
218 0
2
0 49 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut34
3
0 0
130 1
219 0
2
0 51 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut35
3
0 0
130 1
220 0
2
0 53 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut36
3
0 0
130 1
221 0
2
0 55 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut37
3
0 0
130 1
222 0
2
0 57 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut38
3
0 0
130 1
223 0
2
0 59 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut39
3
0 0
130 1
224 0
2
0 61 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut4
3
0 0
130 1
225 0
2
0 63 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut40
3
0 0
130 1
226 0
2
0 65 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut41
3
0 0
130 1
227 0
2
0 67 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut42
3
0 0
130 1
228 0
2
0 69 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut43
3
0 0
130 1
229 0
2
0 71 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut44
3
0 0
130 1
230 0
2
0 73 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut45
3
0 0
130 1
231 0
2
0 75 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut46
3
0 0
130 1
232 0
2
0 77 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut47
3
0 0
130 1
233 0
2
0 79 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut48
3
0 0
130 1
234 0
2
0 81 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut49
3
0 0
130 1
235 0
2
0 83 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut5
3
0 0
130 1
236 0
2
0 85 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut50
3
0 0
130 1
237 0
2
0 87 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut6
3
0 0
130 1
238 0
2
0 89 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut7
3
0 0
130 1
239 0
2
0 91 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut8
3
0 0
130 1
240 0
2
0 93 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut9
3
0 0
130 1
241 0
2
0 95 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut1
3
0 0
131 1
192 0
2
0 1 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut10
3
0 0
131 1
193 0
2
0 2 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut11
3
0 0
131 1
194 0
2
0 3 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut12
3
0 0
131 1
195 0
2
0 4 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut13
3
0 0
131 1
196 0
2
0 5 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut14
3
0 0
131 1
197 0
2
0 7 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut15
3
0 0
131 1
198 0
2
0 9 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut16
3
0 0
131 1
199 0
2
0 11 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut17
3
0 0
131 1
200 0
2
0 13 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut18
3
0 0
131 1
201 0
2
0 15 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut19
3
0 0
131 1
202 0
2
0 17 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut2
3
0 0
131 1
203 0
2
0 19 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut20
3
0 0
131 1
204 0
2
0 21 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut21
3
0 0
131 1
205 0
2
0 23 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut22
3
0 0
131 1
206 0
2
0 25 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut23
3
0 0
131 1
207 0
2
0 27 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut24
3
0 0
131 1
208 0
2
0 29 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut25
3
0 0
131 1
209 0
2
0 31 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut26
3
0 0
131 1
210 0
2
0 33 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut27
3
0 0
131 1
211 0
2
0 35 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut28
3
0 0
131 1
212 0
2
0 37 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut29
3
0 0
131 1
213 0
2
0 39 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut3
3
0 0
131 1
214 0
2
0 41 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut30
3
0 0
131 1
215 0
2
0 43 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut31
3
0 0
131 1
216 0
2
0 45 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut32
3
0 0
131 1
217 0
2
0 47 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut33
3
0 0
131 1
218 0
2
0 49 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut34
3
0 0
131 1
219 0
2
0 51 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut35
3
0 0
131 1
220 0
2
0 53 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut36
3
0 0
131 1
221 0
2
0 55 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut37
3
0 0
131 1
222 0
2
0 57 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut38
3
0 0
131 1
223 0
2
0 59 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut39
3
0 0
131 1
224 0
2
0 61 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut4
3
0 0
131 1
225 0
2
0 63 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut40
3
0 0
131 1
226 0
2
0 65 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut41
3
0 0
131 1
227 0
2
0 67 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut42
3
0 0
131 1
228 0
2
0 69 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut43
3
0 0
131 1
229 0
2
0 71 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut44
3
0 0
131 1
230 0
2
0 73 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut45
3
0 0
131 1
231 0
2
0 75 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut46
3
0 0
131 1
232 0
2
0 77 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut47
3
0 0
131 1
233 0
2
0 79 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut48
3
0 0
131 1
234 0
2
0 81 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut49
3
0 0
131 1
235 0
2
0 83 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut5
3
0 0
131 1
236 0
2
0 85 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut50
3
0 0
131 1
237 0
2
0 87 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut6
3
0 0
131 1
238 0
2
0 89 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut7
3
0 0
131 1
239 0
2
0 91 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut8
3
0 0
131 1
240 0
2
0 93 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut9
3
0 0
131 1
241 0
2
0 95 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut1
3
0 0
132 1
192 0
2
0 1 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut10
3
0 0
132 1
193 0
2
0 2 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut11
3
0 0
132 1
194 0
2
0 3 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut12
3
0 0
132 1
195 0
2
0 4 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut13
3
0 0
132 1
196 0
2
0 5 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut14
3
0 0
132 1
197 0
2
0 7 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut15
3
0 0
132 1
198 0
2
0 9 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut16
3
0 0
132 1
199 0
2
0 11 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut17
3
0 0
132 1
200 0
2
0 13 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut18
3
0 0
132 1
201 0
2
0 15 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut19
3
0 0
132 1
202 0
2
0 17 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut2
3
0 0
132 1
203 0
2
0 19 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut20
3
0 0
132 1
204 0
2
0 21 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut21
3
0 0
132 1
205 0
2
0 23 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut22
3
0 0
132 1
206 0
2
0 25 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut23
3
0 0
132 1
207 0
2
0 27 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut24
3
0 0
132 1
208 0
2
0 29 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut25
3
0 0
132 1
209 0
2
0 31 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut26
3
0 0
132 1
210 0
2
0 33 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut27
3
0 0
132 1
211 0
2
0 35 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut28
3
0 0
132 1
212 0
2
0 37 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut29
3
0 0
132 1
213 0
2
0 39 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut3
3
0 0
132 1
214 0
2
0 41 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut30
3
0 0
132 1
215 0
2
0 43 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut31
3
0 0
132 1
216 0
2
0 45 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut32
3
0 0
132 1
217 0
2
0 47 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut33
3
0 0
132 1
218 0
2
0 49 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut34
3
0 0
132 1
219 0
2
0 51 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut35
3
0 0
132 1
220 0
2
0 53 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut36
3
0 0
132 1
221 0
2
0 55 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut37
3
0 0
132 1
222 0
2
0 57 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut38
3
0 0
132 1
223 0
2
0 59 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut39
3
0 0
132 1
224 0
2
0 61 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut4
3
0 0
132 1
225 0
2
0 63 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut40
3
0 0
132 1
226 0
2
0 65 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut41
3
0 0
132 1
227 0
2
0 67 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut42
3
0 0
132 1
228 0
2
0 69 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut43
3
0 0
132 1
229 0
2
0 71 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut44
3
0 0
132 1
230 0
2
0 73 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut45
3
0 0
132 1
231 0
2
0 75 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut46
3
0 0
132 1
232 0
2
0 77 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut47
3
0 0
132 1
233 0
2
0 79 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut48
3
0 0
132 1
234 0
2
0 81 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut49
3
0 0
132 1
235 0
2
0 83 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut5
3
0 0
132 1
236 0
2
0 85 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut50
3
0 0
132 1
237 0
2
0 87 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut6
3
0 0
132 1
238 0
2
0 89 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut7
3
0 0
132 1
239 0
2
0 91 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut8
3
0 0
132 1
240 0
2
0 93 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut9
3
0 0
132 1
241 0
2
0 95 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut1
3
0 0
133 1
192 0
2
0 1 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut10
3
0 0
133 1
193 0
2
0 2 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut11
3
0 0
133 1
194 0
2
0 3 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut12
3
0 0
133 1
195 0
2
0 4 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut13
3
0 0
133 1
196 0
2
0 5 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut14
3
0 0
133 1
197 0
2
0 7 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut15
3
0 0
133 1
198 0
2
0 9 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut16
3
0 0
133 1
199 0
2
0 11 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut17
3
0 0
133 1
200 0
2
0 13 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut18
3
0 0
133 1
201 0
2
0 15 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut19
3
0 0
133 1
202 0
2
0 17 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut2
3
0 0
133 1
203 0
2
0 19 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut20
3
0 0
133 1
204 0
2
0 21 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut21
3
0 0
133 1
205 0
2
0 23 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut22
3
0 0
133 1
206 0
2
0 25 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut23
3
0 0
133 1
207 0
2
0 27 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut24
3
0 0
133 1
208 0
2
0 29 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut25
3
0 0
133 1
209 0
2
0 31 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut26
3
0 0
133 1
210 0
2
0 33 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut27
3
0 0
133 1
211 0
2
0 35 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut28
3
0 0
133 1
212 0
2
0 37 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut29
3
0 0
133 1
213 0
2
0 39 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut3
3
0 0
133 1
214 0
2
0 41 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut30
3
0 0
133 1
215 0
2
0 43 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut31
3
0 0
133 1
216 0
2
0 45 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut32
3
0 0
133 1
217 0
2
0 47 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut33
3
0 0
133 1
218 0
2
0 49 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut34
3
0 0
133 1
219 0
2
0 51 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut35
3
0 0
133 1
220 0
2
0 53 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut36
3
0 0
133 1
221 0
2
0 55 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut37
3
0 0
133 1
222 0
2
0 57 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut38
3
0 0
133 1
223 0
2
0 59 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut39
3
0 0
133 1
224 0
2
0 61 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut4
3
0 0
133 1
225 0
2
0 63 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut40
3
0 0
133 1
226 0
2
0 65 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut41
3
0 0
133 1
227 0
2
0 67 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut42
3
0 0
133 1
228 0
2
0 69 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut43
3
0 0
133 1
229 0
2
0 71 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut44
3
0 0
133 1
230 0
2
0 73 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut45
3
0 0
133 1
231 0
2
0 75 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut46
3
0 0
133 1
232 0
2
0 77 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut47
3
0 0
133 1
233 0
2
0 79 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut48
3
0 0
133 1
234 0
2
0 81 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut49
3
0 0
133 1
235 0
2
0 83 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut5
3
0 0
133 1
236 0
2
0 85 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut50
3
0 0
133 1
237 0
2
0 87 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut6
3
0 0
133 1
238 0
2
0 89 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut7
3
0 0
133 1
239 0
2
0 91 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut8
3
0 0
133 1
240 0
2
0 93 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut9
3
0 0
133 1
241 0
2
0 95 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut1
3
0 0
134 1
192 0
2
0 1 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut10
3
0 0
134 1
193 0
2
0 2 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut11
3
0 0
134 1
194 0
2
0 3 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut12
3
0 0
134 1
195 0
2
0 4 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut13
3
0 0
134 1
196 0
2
0 5 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut14
3
0 0
134 1
197 0
2
0 7 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut15
3
0 0
134 1
198 0
2
0 9 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut16
3
0 0
134 1
199 0
2
0 11 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut17
3
0 0
134 1
200 0
2
0 13 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut18
3
0 0
134 1
201 0
2
0 15 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut19
3
0 0
134 1
202 0
2
0 17 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut2
3
0 0
134 1
203 0
2
0 19 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut20
3
0 0
134 1
204 0
2
0 21 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut21
3
0 0
134 1
205 0
2
0 23 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut22
3
0 0
134 1
206 0
2
0 25 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut23
3
0 0
134 1
207 0
2
0 27 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut24
3
0 0
134 1
208 0
2
0 29 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut25
3
0 0
134 1
209 0
2
0 31 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut26
3
0 0
134 1
210 0
2
0 33 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut27
3
0 0
134 1
211 0
2
0 35 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut28
3
0 0
134 1
212 0
2
0 37 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut29
3
0 0
134 1
213 0
2
0 39 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut3
3
0 0
134 1
214 0
2
0 41 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut30
3
0 0
134 1
215 0
2
0 43 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut31
3
0 0
134 1
216 0
2
0 45 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut32
3
0 0
134 1
217 0
2
0 47 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut33
3
0 0
134 1
218 0
2
0 49 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut34
3
0 0
134 1
219 0
2
0 51 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut35
3
0 0
134 1
220 0
2
0 53 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut36
3
0 0
134 1
221 0
2
0 55 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut37
3
0 0
134 1
222 0
2
0 57 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut38
3
0 0
134 1
223 0
2
0 59 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut39
3
0 0
134 1
224 0
2
0 61 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut4
3
0 0
134 1
225 0
2
0 63 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut40
3
0 0
134 1
226 0
2
0 65 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut41
3
0 0
134 1
227 0
2
0 67 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut42
3
0 0
134 1
228 0
2
0 69 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut43
3
0 0
134 1
229 0
2
0 71 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut44
3
0 0
134 1
230 0
2
0 73 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut45
3
0 0
134 1
231 0
2
0 75 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut46
3
0 0
134 1
232 0
2
0 77 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut47
3
0 0
134 1
233 0
2
0 79 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut48
3
0 0
134 1
234 0
2
0 81 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut49
3
0 0
134 1
235 0
2
0 83 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut5
3
0 0
134 1
236 0
2
0 85 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut50
3
0 0
134 1
237 0
2
0 87 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut6
3
0 0
134 1
238 0
2
0 89 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut7
3
0 0
134 1
239 0
2
0 91 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut8
3
0 0
134 1
240 0
2
0 93 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut9
3
0 0
134 1
241 0
2
0 95 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut1
3
0 0
135 1
192 0
2
0 1 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut10
3
0 0
135 1
193 0
2
0 2 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut11
3
0 0
135 1
194 0
2
0 3 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut12
3
0 0
135 1
195 0
2
0 4 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut13
3
0 0
135 1
196 0
2
0 5 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut14
3
0 0
135 1
197 0
2
0 7 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut15
3
0 0
135 1
198 0
2
0 9 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut16
3
0 0
135 1
199 0
2
0 11 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut17
3
0 0
135 1
200 0
2
0 13 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut18
3
0 0
135 1
201 0
2
0 15 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut19
3
0 0
135 1
202 0
2
0 17 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut2
3
0 0
135 1
203 0
2
0 19 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut20
3
0 0
135 1
204 0
2
0 21 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut21
3
0 0
135 1
205 0
2
0 23 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut22
3
0 0
135 1
206 0
2
0 25 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut23
3
0 0
135 1
207 0
2
0 27 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut24
3
0 0
135 1
208 0
2
0 29 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut25
3
0 0
135 1
209 0
2
0 31 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut26
3
0 0
135 1
210 0
2
0 33 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut27
3
0 0
135 1
211 0
2
0 35 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut28
3
0 0
135 1
212 0
2
0 37 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut29
3
0 0
135 1
213 0
2
0 39 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut3
3
0 0
135 1
214 0
2
0 41 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut30
3
0 0
135 1
215 0
2
0 43 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut31
3
0 0
135 1
216 0
2
0 45 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut32
3
0 0
135 1
217 0
2
0 47 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut33
3
0 0
135 1
218 0
2
0 49 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut34
3
0 0
135 1
219 0
2
0 51 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut35
3
0 0
135 1
220 0
2
0 53 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut36
3
0 0
135 1
221 0
2
0 55 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut37
3
0 0
135 1
222 0
2
0 57 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut38
3
0 0
135 1
223 0
2
0 59 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut39
3
0 0
135 1
224 0
2
0 61 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut4
3
0 0
135 1
225 0
2
0 63 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut40
3
0 0
135 1
226 0
2
0 65 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut41
3
0 0
135 1
227 0
2
0 67 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut42
3
0 0
135 1
228 0
2
0 69 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut43
3
0 0
135 1
229 0
2
0 71 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut44
3
0 0
135 1
230 0
2
0 73 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut45
3
0 0
135 1
231 0
2
0 75 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut46
3
0 0
135 1
232 0
2
0 77 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut47
3
0 0
135 1
233 0
2
0 79 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut48
3
0 0
135 1
234 0
2
0 81 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut49
3
0 0
135 1
235 0
2
0 83 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut5
3
0 0
135 1
236 0
2
0 85 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut50
3
0 0
135 1
237 0
2
0 87 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut6
3
0 0
135 1
238 0
2
0 89 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut7
3
0 0
135 1
239 0
2
0 91 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut8
3
0 0
135 1
240 0
2
0 93 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut9
3
0 0
135 1
241 0
2
0 95 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut1
3
0 0
136 1
192 0
2
0 1 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut10
3
0 0
136 1
193 0
2
0 2 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut11
3
0 0
136 1
194 0
2
0 3 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut12
3
0 0
136 1
195 0
2
0 4 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut13
3
0 0
136 1
196 0
2
0 5 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut14
3
0 0
136 1
197 0
2
0 7 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut15
3
0 0
136 1
198 0
2
0 9 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut16
3
0 0
136 1
199 0
2
0 11 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut17
3
0 0
136 1
200 0
2
0 13 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut18
3
0 0
136 1
201 0
2
0 15 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut19
3
0 0
136 1
202 0
2
0 17 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut2
3
0 0
136 1
203 0
2
0 19 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut20
3
0 0
136 1
204 0
2
0 21 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut21
3
0 0
136 1
205 0
2
0 23 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut22
3
0 0
136 1
206 0
2
0 25 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut23
3
0 0
136 1
207 0
2
0 27 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut24
3
0 0
136 1
208 0
2
0 29 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut25
3
0 0
136 1
209 0
2
0 31 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut26
3
0 0
136 1
210 0
2
0 33 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut27
3
0 0
136 1
211 0
2
0 35 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut28
3
0 0
136 1
212 0
2
0 37 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut29
3
0 0
136 1
213 0
2
0 39 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut3
3
0 0
136 1
214 0
2
0 41 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut30
3
0 0
136 1
215 0
2
0 43 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut31
3
0 0
136 1
216 0
2
0 45 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut32
3
0 0
136 1
217 0
2
0 47 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut33
3
0 0
136 1
218 0
2
0 49 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut34
3
0 0
136 1
219 0
2
0 51 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut35
3
0 0
136 1
220 0
2
0 53 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut36
3
0 0
136 1
221 0
2
0 55 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut37
3
0 0
136 1
222 0
2
0 57 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut38
3
0 0
136 1
223 0
2
0 59 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut39
3
0 0
136 1
224 0
2
0 61 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut4
3
0 0
136 1
225 0
2
0 63 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut40
3
0 0
136 1
226 0
2
0 65 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut41
3
0 0
136 1
227 0
2
0 67 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut42
3
0 0
136 1
228 0
2
0 69 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut43
3
0 0
136 1
229 0
2
0 71 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut44
3
0 0
136 1
230 0
2
0 73 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut45
3
0 0
136 1
231 0
2
0 75 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut46
3
0 0
136 1
232 0
2
0 77 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut47
3
0 0
136 1
233 0
2
0 79 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut48
3
0 0
136 1
234 0
2
0 81 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut49
3
0 0
136 1
235 0
2
0 83 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut5
3
0 0
136 1
236 0
2
0 85 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut50
3
0 0
136 1
237 0
2
0 87 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut6
3
0 0
136 1
238 0
2
0 89 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut7
3
0 0
136 1
239 0
2
0 91 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut8
3
0 0
136 1
240 0
2
0 93 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut9
3
0 0
136 1
241 0
2
0 95 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut1
3
0 0
137 1
192 0
2
0 1 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut10
3
0 0
137 1
193 0
2
0 2 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut11
3
0 0
137 1
194 0
2
0 3 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut12
3
0 0
137 1
195 0
2
0 4 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut13
3
0 0
137 1
196 0
2
0 5 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut14
3
0 0
137 1
197 0
2
0 7 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut15
3
0 0
137 1
198 0
2
0 9 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut16
3
0 0
137 1
199 0
2
0 11 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut17
3
0 0
137 1
200 0
2
0 13 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut18
3
0 0
137 1
201 0
2
0 15 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut19
3
0 0
137 1
202 0
2
0 17 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut2
3
0 0
137 1
203 0
2
0 19 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut20
3
0 0
137 1
204 0
2
0 21 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut21
3
0 0
137 1
205 0
2
0 23 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut22
3
0 0
137 1
206 0
2
0 25 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut23
3
0 0
137 1
207 0
2
0 27 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut24
3
0 0
137 1
208 0
2
0 29 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut25
3
0 0
137 1
209 0
2
0 31 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut26
3
0 0
137 1
210 0
2
0 33 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut27
3
0 0
137 1
211 0
2
0 35 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut28
3
0 0
137 1
212 0
2
0 37 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut29
3
0 0
137 1
213 0
2
0 39 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut3
3
0 0
137 1
214 0
2
0 41 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut30
3
0 0
137 1
215 0
2
0 43 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut31
3
0 0
137 1
216 0
2
0 45 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut32
3
0 0
137 1
217 0
2
0 47 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut33
3
0 0
137 1
218 0
2
0 49 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut34
3
0 0
137 1
219 0
2
0 51 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut35
3
0 0
137 1
220 0
2
0 53 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut36
3
0 0
137 1
221 0
2
0 55 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut37
3
0 0
137 1
222 0
2
0 57 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut38
3
0 0
137 1
223 0
2
0 59 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut39
3
0 0
137 1
224 0
2
0 61 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut4
3
0 0
137 1
225 0
2
0 63 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut40
3
0 0
137 1
226 0
2
0 65 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut41
3
0 0
137 1
227 0
2
0 67 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut42
3
0 0
137 1
228 0
2
0 69 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut43
3
0 0
137 1
229 0
2
0 71 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut44
3
0 0
137 1
230 0
2
0 73 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut45
3
0 0
137 1
231 0
2
0 75 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut46
3
0 0
137 1
232 0
2
0 77 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut47
3
0 0
137 1
233 0
2
0 79 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut48
3
0 0
137 1
234 0
2
0 81 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut49
3
0 0
137 1
235 0
2
0 83 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut5
3
0 0
137 1
236 0
2
0 85 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut50
3
0 0
137 1
237 0
2
0 87 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut6
3
0 0
137 1
238 0
2
0 89 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut7
3
0 0
137 1
239 0
2
0 91 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut8
3
0 0
137 1
240 0
2
0 93 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut9
3
0 0
137 1
241 0
2
0 95 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut1
3
0 0
138 1
192 0
2
0 1 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut10
3
0 0
138 1
193 0
2
0 2 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut11
3
0 0
138 1
194 0
2
0 3 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut12
3
0 0
138 1
195 0
2
0 4 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut13
3
0 0
138 1
196 0
2
0 5 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut14
3
0 0
138 1
197 0
2
0 7 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut15
3
0 0
138 1
198 0
2
0 9 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut16
3
0 0
138 1
199 0
2
0 11 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut17
3
0 0
138 1
200 0
2
0 13 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut18
3
0 0
138 1
201 0
2
0 15 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut19
3
0 0
138 1
202 0
2
0 17 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut2
3
0 0
138 1
203 0
2
0 19 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut20
3
0 0
138 1
204 0
2
0 21 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut21
3
0 0
138 1
205 0
2
0 23 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut22
3
0 0
138 1
206 0
2
0 25 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut23
3
0 0
138 1
207 0
2
0 27 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut24
3
0 0
138 1
208 0
2
0 29 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut25
3
0 0
138 1
209 0
2
0 31 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut26
3
0 0
138 1
210 0
2
0 33 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut27
3
0 0
138 1
211 0
2
0 35 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut28
3
0 0
138 1
212 0
2
0 37 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut29
3
0 0
138 1
213 0
2
0 39 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut3
3
0 0
138 1
214 0
2
0 41 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut30
3
0 0
138 1
215 0
2
0 43 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut31
3
0 0
138 1
216 0
2
0 45 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut32
3
0 0
138 1
217 0
2
0 47 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut33
3
0 0
138 1
218 0
2
0 49 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut34
3
0 0
138 1
219 0
2
0 51 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut35
3
0 0
138 1
220 0
2
0 53 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut36
3
0 0
138 1
221 0
2
0 55 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut37
3
0 0
138 1
222 0
2
0 57 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut38
3
0 0
138 1
223 0
2
0 59 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut39
3
0 0
138 1
224 0
2
0 61 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut4
3
0 0
138 1
225 0
2
0 63 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut40
3
0 0
138 1
226 0
2
0 65 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut41
3
0 0
138 1
227 0
2
0 67 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut42
3
0 0
138 1
228 0
2
0 69 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut43
3
0 0
138 1
229 0
2
0 71 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut44
3
0 0
138 1
230 0
2
0 73 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut45
3
0 0
138 1
231 0
2
0 75 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut46
3
0 0
138 1
232 0
2
0 77 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut47
3
0 0
138 1
233 0
2
0 79 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut48
3
0 0
138 1
234 0
2
0 81 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut49
3
0 0
138 1
235 0
2
0 83 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut5
3
0 0
138 1
236 0
2
0 85 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut50
3
0 0
138 1
237 0
2
0 87 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut6
3
0 0
138 1
238 0
2
0 89 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut7
3
0 0
138 1
239 0
2
0 91 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut8
3
0 0
138 1
240 0
2
0 93 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut9
3
0 0
138 1
241 0
2
0 95 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut1
3
0 0
139 1
192 0
2
0 1 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut10
3
0 0
139 1
193 0
2
0 2 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut11
3
0 0
139 1
194 0
2
0 3 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut12
3
0 0
139 1
195 0
2
0 4 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut13
3
0 0
139 1
196 0
2
0 5 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut14
3
0 0
139 1
197 0
2
0 7 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut15
3
0 0
139 1
198 0
2
0 9 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut16
3
0 0
139 1
199 0
2
0 11 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut17
3
0 0
139 1
200 0
2
0 13 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut18
3
0 0
139 1
201 0
2
0 15 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut19
3
0 0
139 1
202 0
2
0 17 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut2
3
0 0
139 1
203 0
2
0 19 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut20
3
0 0
139 1
204 0
2
0 21 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut21
3
0 0
139 1
205 0
2
0 23 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut22
3
0 0
139 1
206 0
2
0 25 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut23
3
0 0
139 1
207 0
2
0 27 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut24
3
0 0
139 1
208 0
2
0 29 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut25
3
0 0
139 1
209 0
2
0 31 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut26
3
0 0
139 1
210 0
2
0 33 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut27
3
0 0
139 1
211 0
2
0 35 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut28
3
0 0
139 1
212 0
2
0 37 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut29
3
0 0
139 1
213 0
2
0 39 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut3
3
0 0
139 1
214 0
2
0 41 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut30
3
0 0
139 1
215 0
2
0 43 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut31
3
0 0
139 1
216 0
2
0 45 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut32
3
0 0
139 1
217 0
2
0 47 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut33
3
0 0
139 1
218 0
2
0 49 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut34
3
0 0
139 1
219 0
2
0 51 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut35
3
0 0
139 1
220 0
2
0 53 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut36
3
0 0
139 1
221 0
2
0 55 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut37
3
0 0
139 1
222 0
2
0 57 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut38
3
0 0
139 1
223 0
2
0 59 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut39
3
0 0
139 1
224 0
2
0 61 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut4
3
0 0
139 1
225 0
2
0 63 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut40
3
0 0
139 1
226 0
2
0 65 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut41
3
0 0
139 1
227 0
2
0 67 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut42
3
0 0
139 1
228 0
2
0 69 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut43
3
0 0
139 1
229 0
2
0 71 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut44
3
0 0
139 1
230 0
2
0 73 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut45
3
0 0
139 1
231 0
2
0 75 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut46
3
0 0
139 1
232 0
2
0 77 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut47
3
0 0
139 1
233 0
2
0 79 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut48
3
0 0
139 1
234 0
2
0 81 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut49
3
0 0
139 1
235 0
2
0 83 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut5
3
0 0
139 1
236 0
2
0 85 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut50
3
0 0
139 1
237 0
2
0 87 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut6
3
0 0
139 1
238 0
2
0 89 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut7
3
0 0
139 1
239 0
2
0 91 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut8
3
0 0
139 1
240 0
2
0 93 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut9
3
0 0
139 1
241 0
2
0 95 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
140 1
192 0
2
0 1 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
140 1
193 0
2
0 2 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
140 1
194 0
2
0 3 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
140 1
195 0
2
0 4 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
140 1
196 0
2
0 5 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
140 1
197 0
2
0 7 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
140 1
198 0
2
0 9 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
140 1
199 0
2
0 11 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
140 1
200 0
2
0 13 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
140 1
201 0
2
0 15 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
140 1
202 0
2
0 17 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
140 1
203 0
2
0 19 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
140 1
204 0
2
0 21 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
140 1
205 0
2
0 23 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
140 1
206 0
2
0 25 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
140 1
207 0
2
0 27 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
140 1
208 0
2
0 29 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
140 1
209 0
2
0 31 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
140 1
210 0
2
0 33 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
140 1
211 0
2
0 35 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
140 1
212 0
2
0 37 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
140 1
213 0
2
0 39 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
140 1
214 0
2
0 41 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
140 1
215 0
2
0 43 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut31
3
0 0
140 1
216 0
2
0 45 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut32
3
0 0
140 1
217 0
2
0 47 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut33
3
0 0
140 1
218 0
2
0 49 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut34
3
0 0
140 1
219 0
2
0 51 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut35
3
0 0
140 1
220 0
2
0 53 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut36
3
0 0
140 1
221 0
2
0 55 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut37
3
0 0
140 1
222 0
2
0 57 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut38
3
0 0
140 1
223 0
2
0 59 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut39
3
0 0
140 1
224 0
2
0 61 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
140 1
225 0
2
0 63 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut40
3
0 0
140 1
226 0
2
0 65 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut41
3
0 0
140 1
227 0
2
0 67 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut42
3
0 0
140 1
228 0
2
0 69 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut43
3
0 0
140 1
229 0
2
0 71 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut44
3
0 0
140 1
230 0
2
0 73 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut45
3
0 0
140 1
231 0
2
0 75 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut46
3
0 0
140 1
232 0
2
0 77 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut47
3
0 0
140 1
233 0
2
0 79 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut48
3
0 0
140 1
234 0
2
0 81 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut49
3
0 0
140 1
235 0
2
0 83 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
140 1
236 0
2
0 85 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut50
3
0 0
140 1
237 0
2
0 87 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
140 1
238 0
2
0 89 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
140 1
239 0
2
0 91 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
140 1
240 0
2
0 93 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
140 1
241 0
2
0 95 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut1
3
0 0
141 1
192 0
2
0 1 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut10
3
0 0
141 1
193 0
2
0 2 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut11
3
0 0
141 1
194 0
2
0 3 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut12
3
0 0
141 1
195 0
2
0 4 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut13
3
0 0
141 1
196 0
2
0 5 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut14
3
0 0
141 1
197 0
2
0 7 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut15
3
0 0
141 1
198 0
2
0 9 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut16
3
0 0
141 1
199 0
2
0 11 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut17
3
0 0
141 1
200 0
2
0 13 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut18
3
0 0
141 1
201 0
2
0 15 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut19
3
0 0
141 1
202 0
2
0 17 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut2
3
0 0
141 1
203 0
2
0 19 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut20
3
0 0
141 1
204 0
2
0 21 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut21
3
0 0
141 1
205 0
2
0 23 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut22
3
0 0
141 1
206 0
2
0 25 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut23
3
0 0
141 1
207 0
2
0 27 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut24
3
0 0
141 1
208 0
2
0 29 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut25
3
0 0
141 1
209 0
2
0 31 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut26
3
0 0
141 1
210 0
2
0 33 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut27
3
0 0
141 1
211 0
2
0 35 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut28
3
0 0
141 1
212 0
2
0 37 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut29
3
0 0
141 1
213 0
2
0 39 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut3
3
0 0
141 1
214 0
2
0 41 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut30
3
0 0
141 1
215 0
2
0 43 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut31
3
0 0
141 1
216 0
2
0 45 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut32
3
0 0
141 1
217 0
2
0 47 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut33
3
0 0
141 1
218 0
2
0 49 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut34
3
0 0
141 1
219 0
2
0 51 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut35
3
0 0
141 1
220 0
2
0 53 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut36
3
0 0
141 1
221 0
2
0 55 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut37
3
0 0
141 1
222 0
2
0 57 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut38
3
0 0
141 1
223 0
2
0 59 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut39
3
0 0
141 1
224 0
2
0 61 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut4
3
0 0
141 1
225 0
2
0 63 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut40
3
0 0
141 1
226 0
2
0 65 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut41
3
0 0
141 1
227 0
2
0 67 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut42
3
0 0
141 1
228 0
2
0 69 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut43
3
0 0
141 1
229 0
2
0 71 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut44
3
0 0
141 1
230 0
2
0 73 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut45
3
0 0
141 1
231 0
2
0 75 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut46
3
0 0
141 1
232 0
2
0 77 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut47
3
0 0
141 1
233 0
2
0 79 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut48
3
0 0
141 1
234 0
2
0 81 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut49
3
0 0
141 1
235 0
2
0 83 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut5
3
0 0
141 1
236 0
2
0 85 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut50
3
0 0
141 1
237 0
2
0 87 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut6
3
0 0
141 1
238 0
2
0 89 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut7
3
0 0
141 1
239 0
2
0 91 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut8
3
0 0
141 1
240 0
2
0 93 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut9
3
0 0
141 1
241 0
2
0 95 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut1
3
0 0
142 1
192 0
2
0 1 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut10
3
0 0
142 1
193 0
2
0 2 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut11
3
0 0
142 1
194 0
2
0 3 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut12
3
0 0
142 1
195 0
2
0 4 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut13
3
0 0
142 1
196 0
2
0 5 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut14
3
0 0
142 1
197 0
2
0 7 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut15
3
0 0
142 1
198 0
2
0 9 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut16
3
0 0
142 1
199 0
2
0 11 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut17
3
0 0
142 1
200 0
2
0 13 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut18
3
0 0
142 1
201 0
2
0 15 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut19
3
0 0
142 1
202 0
2
0 17 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut2
3
0 0
142 1
203 0
2
0 19 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut20
3
0 0
142 1
204 0
2
0 21 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut21
3
0 0
142 1
205 0
2
0 23 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut22
3
0 0
142 1
206 0
2
0 25 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut23
3
0 0
142 1
207 0
2
0 27 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut24
3
0 0
142 1
208 0
2
0 29 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut25
3
0 0
142 1
209 0
2
0 31 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut26
3
0 0
142 1
210 0
2
0 33 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut27
3
0 0
142 1
211 0
2
0 35 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut28
3
0 0
142 1
212 0
2
0 37 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut29
3
0 0
142 1
213 0
2
0 39 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut3
3
0 0
142 1
214 0
2
0 41 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut30
3
0 0
142 1
215 0
2
0 43 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut31
3
0 0
142 1
216 0
2
0 45 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut32
3
0 0
142 1
217 0
2
0 47 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut33
3
0 0
142 1
218 0
2
0 49 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut34
3
0 0
142 1
219 0
2
0 51 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut35
3
0 0
142 1
220 0
2
0 53 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut36
3
0 0
142 1
221 0
2
0 55 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut37
3
0 0
142 1
222 0
2
0 57 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut38
3
0 0
142 1
223 0
2
0 59 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut39
3
0 0
142 1
224 0
2
0 61 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut4
3
0 0
142 1
225 0
2
0 63 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut40
3
0 0
142 1
226 0
2
0 65 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut41
3
0 0
142 1
227 0
2
0 67 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut42
3
0 0
142 1
228 0
2
0 69 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut43
3
0 0
142 1
229 0
2
0 71 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut44
3
0 0
142 1
230 0
2
0 73 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut45
3
0 0
142 1
231 0
2
0 75 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut46
3
0 0
142 1
232 0
2
0 77 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut47
3
0 0
142 1
233 0
2
0 79 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut48
3
0 0
142 1
234 0
2
0 81 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut49
3
0 0
142 1
235 0
2
0 83 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut5
3
0 0
142 1
236 0
2
0 85 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut50
3
0 0
142 1
237 0
2
0 87 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut6
3
0 0
142 1
238 0
2
0 89 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut7
3
0 0
142 1
239 0
2
0 91 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut8
3
0 0
142 1
240 0
2
0 93 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut9
3
0 0
142 1
241 0
2
0 95 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut1
3
0 0
143 1
192 0
2
0 1 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut10
3
0 0
143 1
193 0
2
0 2 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut11
3
0 0
143 1
194 0
2
0 3 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut12
3
0 0
143 1
195 0
2
0 4 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut13
3
0 0
143 1
196 0
2
0 5 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut14
3
0 0
143 1
197 0
2
0 7 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut15
3
0 0
143 1
198 0
2
0 9 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut16
3
0 0
143 1
199 0
2
0 11 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut17
3
0 0
143 1
200 0
2
0 13 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut18
3
0 0
143 1
201 0
2
0 15 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut19
3
0 0
143 1
202 0
2
0 17 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut2
3
0 0
143 1
203 0
2
0 19 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut20
3
0 0
143 1
204 0
2
0 21 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut21
3
0 0
143 1
205 0
2
0 23 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut22
3
0 0
143 1
206 0
2
0 25 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut23
3
0 0
143 1
207 0
2
0 27 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut24
3
0 0
143 1
208 0
2
0 29 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut25
3
0 0
143 1
209 0
2
0 31 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut26
3
0 0
143 1
210 0
2
0 33 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut27
3
0 0
143 1
211 0
2
0 35 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut28
3
0 0
143 1
212 0
2
0 37 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut29
3
0 0
143 1
213 0
2
0 39 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut3
3
0 0
143 1
214 0
2
0 41 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut30
3
0 0
143 1
215 0
2
0 43 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut31
3
0 0
143 1
216 0
2
0 45 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut32
3
0 0
143 1
217 0
2
0 47 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut33
3
0 0
143 1
218 0
2
0 49 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut34
3
0 0
143 1
219 0
2
0 51 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut35
3
0 0
143 1
220 0
2
0 53 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut36
3
0 0
143 1
221 0
2
0 55 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut37
3
0 0
143 1
222 0
2
0 57 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut38
3
0 0
143 1
223 0
2
0 59 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut39
3
0 0
143 1
224 0
2
0 61 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut4
3
0 0
143 1
225 0
2
0 63 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut40
3
0 0
143 1
226 0
2
0 65 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut41
3
0 0
143 1
227 0
2
0 67 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut42
3
0 0
143 1
228 0
2
0 69 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut43
3
0 0
143 1
229 0
2
0 71 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut44
3
0 0
143 1
230 0
2
0 73 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut45
3
0 0
143 1
231 0
2
0 75 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut46
3
0 0
143 1
232 0
2
0 77 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut47
3
0 0
143 1
233 0
2
0 79 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut48
3
0 0
143 1
234 0
2
0 81 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut49
3
0 0
143 1
235 0
2
0 83 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut5
3
0 0
143 1
236 0
2
0 85 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut50
3
0 0
143 1
237 0
2
0 87 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut6
3
0 0
143 1
238 0
2
0 89 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut7
3
0 0
143 1
239 0
2
0 91 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut8
3
0 0
143 1
240 0
2
0 93 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut9
3
0 0
143 1
241 0
2
0 95 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut1
3
0 0
144 1
192 0
2
0 1 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut10
3
0 0
144 1
193 0
2
0 2 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut11
3
0 0
144 1
194 0
2
0 3 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut12
3
0 0
144 1
195 0
2
0 4 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut13
3
0 0
144 1
196 0
2
0 5 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut14
3
0 0
144 1
197 0
2
0 7 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut15
3
0 0
144 1
198 0
2
0 9 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut16
3
0 0
144 1
199 0
2
0 11 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut17
3
0 0
144 1
200 0
2
0 13 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut18
3
0 0
144 1
201 0
2
0 15 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut19
3
0 0
144 1
202 0
2
0 17 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut2
3
0 0
144 1
203 0
2
0 19 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut20
3
0 0
144 1
204 0
2
0 21 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut21
3
0 0
144 1
205 0
2
0 23 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut22
3
0 0
144 1
206 0
2
0 25 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut23
3
0 0
144 1
207 0
2
0 27 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut24
3
0 0
144 1
208 0
2
0 29 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut25
3
0 0
144 1
209 0
2
0 31 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut26
3
0 0
144 1
210 0
2
0 33 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut27
3
0 0
144 1
211 0
2
0 35 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut28
3
0 0
144 1
212 0
2
0 37 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut29
3
0 0
144 1
213 0
2
0 39 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut3
3
0 0
144 1
214 0
2
0 41 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut30
3
0 0
144 1
215 0
2
0 43 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut31
3
0 0
144 1
216 0
2
0 45 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut32
3
0 0
144 1
217 0
2
0 47 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut33
3
0 0
144 1
218 0
2
0 49 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut34
3
0 0
144 1
219 0
2
0 51 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut35
3
0 0
144 1
220 0
2
0 53 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut36
3
0 0
144 1
221 0
2
0 55 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut37
3
0 0
144 1
222 0
2
0 57 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut38
3
0 0
144 1
223 0
2
0 59 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut39
3
0 0
144 1
224 0
2
0 61 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut4
3
0 0
144 1
225 0
2
0 63 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut40
3
0 0
144 1
226 0
2
0 65 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut41
3
0 0
144 1
227 0
2
0 67 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut42
3
0 0
144 1
228 0
2
0 69 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut43
3
0 0
144 1
229 0
2
0 71 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut44
3
0 0
144 1
230 0
2
0 73 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut45
3
0 0
144 1
231 0
2
0 75 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut46
3
0 0
144 1
232 0
2
0 77 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut47
3
0 0
144 1
233 0
2
0 79 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut48
3
0 0
144 1
234 0
2
0 81 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut49
3
0 0
144 1
235 0
2
0 83 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut5
3
0 0
144 1
236 0
2
0 85 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut50
3
0 0
144 1
237 0
2
0 87 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut6
3
0 0
144 1
238 0
2
0 89 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut7
3
0 0
144 1
239 0
2
0 91 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut8
3
0 0
144 1
240 0
2
0 93 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut9
3
0 0
144 1
241 0
2
0 95 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut1
3
0 0
145 1
192 0
2
0 1 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut10
3
0 0
145 1
193 0
2
0 2 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut11
3
0 0
145 1
194 0
2
0 3 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut12
3
0 0
145 1
195 0
2
0 4 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut13
3
0 0
145 1
196 0
2
0 5 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut14
3
0 0
145 1
197 0
2
0 7 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut15
3
0 0
145 1
198 0
2
0 9 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut16
3
0 0
145 1
199 0
2
0 11 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut17
3
0 0
145 1
200 0
2
0 13 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut18
3
0 0
145 1
201 0
2
0 15 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut19
3
0 0
145 1
202 0
2
0 17 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut2
3
0 0
145 1
203 0
2
0 19 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut20
3
0 0
145 1
204 0
2
0 21 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut21
3
0 0
145 1
205 0
2
0 23 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut22
3
0 0
145 1
206 0
2
0 25 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut23
3
0 0
145 1
207 0
2
0 27 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut24
3
0 0
145 1
208 0
2
0 29 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut25
3
0 0
145 1
209 0
2
0 31 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut26
3
0 0
145 1
210 0
2
0 33 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut27
3
0 0
145 1
211 0
2
0 35 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut28
3
0 0
145 1
212 0
2
0 37 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut29
3
0 0
145 1
213 0
2
0 39 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut3
3
0 0
145 1
214 0
2
0 41 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut30
3
0 0
145 1
215 0
2
0 43 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut31
3
0 0
145 1
216 0
2
0 45 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut32
3
0 0
145 1
217 0
2
0 47 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut33
3
0 0
145 1
218 0
2
0 49 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut34
3
0 0
145 1
219 0
2
0 51 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut35
3
0 0
145 1
220 0
2
0 53 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut36
3
0 0
145 1
221 0
2
0 55 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut37
3
0 0
145 1
222 0
2
0 57 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut38
3
0 0
145 1
223 0
2
0 59 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut39
3
0 0
145 1
224 0
2
0 61 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut4
3
0 0
145 1
225 0
2
0 63 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut40
3
0 0
145 1
226 0
2
0 65 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut41
3
0 0
145 1
227 0
2
0 67 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut42
3
0 0
145 1
228 0
2
0 69 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut43
3
0 0
145 1
229 0
2
0 71 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut44
3
0 0
145 1
230 0
2
0 73 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut45
3
0 0
145 1
231 0
2
0 75 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut46
3
0 0
145 1
232 0
2
0 77 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut47
3
0 0
145 1
233 0
2
0 79 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut48
3
0 0
145 1
234 0
2
0 81 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut49
3
0 0
145 1
235 0
2
0 83 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut5
3
0 0
145 1
236 0
2
0 85 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut50
3
0 0
145 1
237 0
2
0 87 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut6
3
0 0
145 1
238 0
2
0 89 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut7
3
0 0
145 1
239 0
2
0 91 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut8
3
0 0
145 1
240 0
2
0 93 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut9
3
0 0
145 1
241 0
2
0 95 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut1
3
0 0
146 1
192 0
2
0 1 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut10
3
0 0
146 1
193 0
2
0 2 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut11
3
0 0
146 1
194 0
2
0 3 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut12
3
0 0
146 1
195 0
2
0 4 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut13
3
0 0
146 1
196 0
2
0 5 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut14
3
0 0
146 1
197 0
2
0 7 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut15
3
0 0
146 1
198 0
2
0 9 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut16
3
0 0
146 1
199 0
2
0 11 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut17
3
0 0
146 1
200 0
2
0 13 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut18
3
0 0
146 1
201 0
2
0 15 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut19
3
0 0
146 1
202 0
2
0 17 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut2
3
0 0
146 1
203 0
2
0 19 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut20
3
0 0
146 1
204 0
2
0 21 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut21
3
0 0
146 1
205 0
2
0 23 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut22
3
0 0
146 1
206 0
2
0 25 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut23
3
0 0
146 1
207 0
2
0 27 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut24
3
0 0
146 1
208 0
2
0 29 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut25
3
0 0
146 1
209 0
2
0 31 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut26
3
0 0
146 1
210 0
2
0 33 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut27
3
0 0
146 1
211 0
2
0 35 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut28
3
0 0
146 1
212 0
2
0 37 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut29
3
0 0
146 1
213 0
2
0 39 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut3
3
0 0
146 1
214 0
2
0 41 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut30
3
0 0
146 1
215 0
2
0 43 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut31
3
0 0
146 1
216 0
2
0 45 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut32
3
0 0
146 1
217 0
2
0 47 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut33
3
0 0
146 1
218 0
2
0 49 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut34
3
0 0
146 1
219 0
2
0 51 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut35
3
0 0
146 1
220 0
2
0 53 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut36
3
0 0
146 1
221 0
2
0 55 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut37
3
0 0
146 1
222 0
2
0 57 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut38
3
0 0
146 1
223 0
2
0 59 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut39
3
0 0
146 1
224 0
2
0 61 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut4
3
0 0
146 1
225 0
2
0 63 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut40
3
0 0
146 1
226 0
2
0 65 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut41
3
0 0
146 1
227 0
2
0 67 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut42
3
0 0
146 1
228 0
2
0 69 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut43
3
0 0
146 1
229 0
2
0 71 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut44
3
0 0
146 1
230 0
2
0 73 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut45
3
0 0
146 1
231 0
2
0 75 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut46
3
0 0
146 1
232 0
2
0 77 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut47
3
0 0
146 1
233 0
2
0 79 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut48
3
0 0
146 1
234 0
2
0 81 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut49
3
0 0
146 1
235 0
2
0 83 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut5
3
0 0
146 1
236 0
2
0 85 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut50
3
0 0
146 1
237 0
2
0 87 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut6
3
0 0
146 1
238 0
2
0 89 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut7
3
0 0
146 1
239 0
2
0 91 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut8
3
0 0
146 1
240 0
2
0 93 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut9
3
0 0
146 1
241 0
2
0 95 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut1
3
0 0
147 1
192 0
2
0 1 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut10
3
0 0
147 1
193 0
2
0 2 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut11
3
0 0
147 1
194 0
2
0 3 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut12
3
0 0
147 1
195 0
2
0 4 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut13
3
0 0
147 1
196 0
2
0 5 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut14
3
0 0
147 1
197 0
2
0 7 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut15
3
0 0
147 1
198 0
2
0 9 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut16
3
0 0
147 1
199 0
2
0 11 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut17
3
0 0
147 1
200 0
2
0 13 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut18
3
0 0
147 1
201 0
2
0 15 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut19
3
0 0
147 1
202 0
2
0 17 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut2
3
0 0
147 1
203 0
2
0 19 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut20
3
0 0
147 1
204 0
2
0 21 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut21
3
0 0
147 1
205 0
2
0 23 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut22
3
0 0
147 1
206 0
2
0 25 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut23
3
0 0
147 1
207 0
2
0 27 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut24
3
0 0
147 1
208 0
2
0 29 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut25
3
0 0
147 1
209 0
2
0 31 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut26
3
0 0
147 1
210 0
2
0 33 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut27
3
0 0
147 1
211 0
2
0 35 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut28
3
0 0
147 1
212 0
2
0 37 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut29
3
0 0
147 1
213 0
2
0 39 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut3
3
0 0
147 1
214 0
2
0 41 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut30
3
0 0
147 1
215 0
2
0 43 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut31
3
0 0
147 1
216 0
2
0 45 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut32
3
0 0
147 1
217 0
2
0 47 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut33
3
0 0
147 1
218 0
2
0 49 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut34
3
0 0
147 1
219 0
2
0 51 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut35
3
0 0
147 1
220 0
2
0 53 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut36
3
0 0
147 1
221 0
2
0 55 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut37
3
0 0
147 1
222 0
2
0 57 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut38
3
0 0
147 1
223 0
2
0 59 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut39
3
0 0
147 1
224 0
2
0 61 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut4
3
0 0
147 1
225 0
2
0 63 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut40
3
0 0
147 1
226 0
2
0 65 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut41
3
0 0
147 1
227 0
2
0 67 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut42
3
0 0
147 1
228 0
2
0 69 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut43
3
0 0
147 1
229 0
2
0 71 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut44
3
0 0
147 1
230 0
2
0 73 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut45
3
0 0
147 1
231 0
2
0 75 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut46
3
0 0
147 1
232 0
2
0 77 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut47
3
0 0
147 1
233 0
2
0 79 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut48
3
0 0
147 1
234 0
2
0 81 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut49
3
0 0
147 1
235 0
2
0 83 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut5
3
0 0
147 1
236 0
2
0 85 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut50
3
0 0
147 1
237 0
2
0 87 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut6
3
0 0
147 1
238 0
2
0 89 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut7
3
0 0
147 1
239 0
2
0 91 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut8
3
0 0
147 1
240 0
2
0 93 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut9
3
0 0
147 1
241 0
2
0 95 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut1
3
0 0
148 1
192 0
2
0 1 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut10
3
0 0
148 1
193 0
2
0 2 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut11
3
0 0
148 1
194 0
2
0 3 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut12
3
0 0
148 1
195 0
2
0 4 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut13
3
0 0
148 1
196 0
2
0 5 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut14
3
0 0
148 1
197 0
2
0 7 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut15
3
0 0
148 1
198 0
2
0 9 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut16
3
0 0
148 1
199 0
2
0 11 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut17
3
0 0
148 1
200 0
2
0 13 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut18
3
0 0
148 1
201 0
2
0 15 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut19
3
0 0
148 1
202 0
2
0 17 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut2
3
0 0
148 1
203 0
2
0 19 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut20
3
0 0
148 1
204 0
2
0 21 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut21
3
0 0
148 1
205 0
2
0 23 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut22
3
0 0
148 1
206 0
2
0 25 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut23
3
0 0
148 1
207 0
2
0 27 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut24
3
0 0
148 1
208 0
2
0 29 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut25
3
0 0
148 1
209 0
2
0 31 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut26
3
0 0
148 1
210 0
2
0 33 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut27
3
0 0
148 1
211 0
2
0 35 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut28
3
0 0
148 1
212 0
2
0 37 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut29
3
0 0
148 1
213 0
2
0 39 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut3
3
0 0
148 1
214 0
2
0 41 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut30
3
0 0
148 1
215 0
2
0 43 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut31
3
0 0
148 1
216 0
2
0 45 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut32
3
0 0
148 1
217 0
2
0 47 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut33
3
0 0
148 1
218 0
2
0 49 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut34
3
0 0
148 1
219 0
2
0 51 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut35
3
0 0
148 1
220 0
2
0 53 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut36
3
0 0
148 1
221 0
2
0 55 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut37
3
0 0
148 1
222 0
2
0 57 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut38
3
0 0
148 1
223 0
2
0 59 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut39
3
0 0
148 1
224 0
2
0 61 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut4
3
0 0
148 1
225 0
2
0 63 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut40
3
0 0
148 1
226 0
2
0 65 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut41
3
0 0
148 1
227 0
2
0 67 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut42
3
0 0
148 1
228 0
2
0 69 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut43
3
0 0
148 1
229 0
2
0 71 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut44
3
0 0
148 1
230 0
2
0 73 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut45
3
0 0
148 1
231 0
2
0 75 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut46
3
0 0
148 1
232 0
2
0 77 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut47
3
0 0
148 1
233 0
2
0 79 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut48
3
0 0
148 1
234 0
2
0 81 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut49
3
0 0
148 1
235 0
2
0 83 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut5
3
0 0
148 1
236 0
2
0 85 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut50
3
0 0
148 1
237 0
2
0 87 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut6
3
0 0
148 1
238 0
2
0 89 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut7
3
0 0
148 1
239 0
2
0 91 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut8
3
0 0
148 1
240 0
2
0 93 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut9
3
0 0
148 1
241 0
2
0 95 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut1
3
0 0
149 1
192 0
2
0 1 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut10
3
0 0
149 1
193 0
2
0 2 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut11
3
0 0
149 1
194 0
2
0 3 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut12
3
0 0
149 1
195 0
2
0 4 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut13
3
0 0
149 1
196 0
2
0 5 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut14
3
0 0
149 1
197 0
2
0 7 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut15
3
0 0
149 1
198 0
2
0 9 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut16
3
0 0
149 1
199 0
2
0 11 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut17
3
0 0
149 1
200 0
2
0 13 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut18
3
0 0
149 1
201 0
2
0 15 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut19
3
0 0
149 1
202 0
2
0 17 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut2
3
0 0
149 1
203 0
2
0 19 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut20
3
0 0
149 1
204 0
2
0 21 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut21
3
0 0
149 1
205 0
2
0 23 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut22
3
0 0
149 1
206 0
2
0 25 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut23
3
0 0
149 1
207 0
2
0 27 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut24
3
0 0
149 1
208 0
2
0 29 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut25
3
0 0
149 1
209 0
2
0 31 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut26
3
0 0
149 1
210 0
2
0 33 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut27
3
0 0
149 1
211 0
2
0 35 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut28
3
0 0
149 1
212 0
2
0 37 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut29
3
0 0
149 1
213 0
2
0 39 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut3
3
0 0
149 1
214 0
2
0 41 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut30
3
0 0
149 1
215 0
2
0 43 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut31
3
0 0
149 1
216 0
2
0 45 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut32
3
0 0
149 1
217 0
2
0 47 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut33
3
0 0
149 1
218 0
2
0 49 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut34
3
0 0
149 1
219 0
2
0 51 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut35
3
0 0
149 1
220 0
2
0 53 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut36
3
0 0
149 1
221 0
2
0 55 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut37
3
0 0
149 1
222 0
2
0 57 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut38
3
0 0
149 1
223 0
2
0 59 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut39
3
0 0
149 1
224 0
2
0 61 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut4
3
0 0
149 1
225 0
2
0 63 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut40
3
0 0
149 1
226 0
2
0 65 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut41
3
0 0
149 1
227 0
2
0 67 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut42
3
0 0
149 1
228 0
2
0 69 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut43
3
0 0
149 1
229 0
2
0 71 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut44
3
0 0
149 1
230 0
2
0 73 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut45
3
0 0
149 1
231 0
2
0 75 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut46
3
0 0
149 1
232 0
2
0 77 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut47
3
0 0
149 1
233 0
2
0 79 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut48
3
0 0
149 1
234 0
2
0 81 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut49
3
0 0
149 1
235 0
2
0 83 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut5
3
0 0
149 1
236 0
2
0 85 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut50
3
0 0
149 1
237 0
2
0 87 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut6
3
0 0
149 1
238 0
2
0 89 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut7
3
0 0
149 1
239 0
2
0 91 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut8
3
0 0
149 1
240 0
2
0 93 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut9
3
0 0
149 1
241 0
2
0 95 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut1
3
0 0
150 1
192 0
2
0 1 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut10
3
0 0
150 1
193 0
2
0 2 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut11
3
0 0
150 1
194 0
2
0 3 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut12
3
0 0
150 1
195 0
2
0 4 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut13
3
0 0
150 1
196 0
2
0 5 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut14
3
0 0
150 1
197 0
2
0 7 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut15
3
0 0
150 1
198 0
2
0 9 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut16
3
0 0
150 1
199 0
2
0 11 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut17
3
0 0
150 1
200 0
2
0 13 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut18
3
0 0
150 1
201 0
2
0 15 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut19
3
0 0
150 1
202 0
2
0 17 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut2
3
0 0
150 1
203 0
2
0 19 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut20
3
0 0
150 1
204 0
2
0 21 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut21
3
0 0
150 1
205 0
2
0 23 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut22
3
0 0
150 1
206 0
2
0 25 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut23
3
0 0
150 1
207 0
2
0 27 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut24
3
0 0
150 1
208 0
2
0 29 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut25
3
0 0
150 1
209 0
2
0 31 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut26
3
0 0
150 1
210 0
2
0 33 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut27
3
0 0
150 1
211 0
2
0 35 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut28
3
0 0
150 1
212 0
2
0 37 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut29
3
0 0
150 1
213 0
2
0 39 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut3
3
0 0
150 1
214 0
2
0 41 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut30
3
0 0
150 1
215 0
2
0 43 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut31
3
0 0
150 1
216 0
2
0 45 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut32
3
0 0
150 1
217 0
2
0 47 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut33
3
0 0
150 1
218 0
2
0 49 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut34
3
0 0
150 1
219 0
2
0 51 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut35
3
0 0
150 1
220 0
2
0 53 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut36
3
0 0
150 1
221 0
2
0 55 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut37
3
0 0
150 1
222 0
2
0 57 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut38
3
0 0
150 1
223 0
2
0 59 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut39
3
0 0
150 1
224 0
2
0 61 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut4
3
0 0
150 1
225 0
2
0 63 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut40
3
0 0
150 1
226 0
2
0 65 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut41
3
0 0
150 1
227 0
2
0 67 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut42
3
0 0
150 1
228 0
2
0 69 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut43
3
0 0
150 1
229 0
2
0 71 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut44
3
0 0
150 1
230 0
2
0 73 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut45
3
0 0
150 1
231 0
2
0 75 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut46
3
0 0
150 1
232 0
2
0 77 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut47
3
0 0
150 1
233 0
2
0 79 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut48
3
0 0
150 1
234 0
2
0 81 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut49
3
0 0
150 1
235 0
2
0 83 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut5
3
0 0
150 1
236 0
2
0 85 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut50
3
0 0
150 1
237 0
2
0 87 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut6
3
0 0
150 1
238 0
2
0 89 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut7
3
0 0
150 1
239 0
2
0 91 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut8
3
0 0
150 1
240 0
2
0 93 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut9
3
0 0
150 1
241 0
2
0 95 0 1
0 191 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
301 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
302 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
303 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
304 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
305 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
306 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
307 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
308 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
309 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
310 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
311 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
312 0
1
0 0 12 23
1
end_operator
begin_operator
walk location20 location21 bob
1
313 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
314 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
315 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
316 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
317 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
318 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
319 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
320 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 location29 bob
1
321 0
1
0 0 21 22
1
end_operator
begin_operator
walk location29 location30 bob
1
322 0
1
0 0 22 24
1
end_operator
begin_operator
walk location3 location4 bob
1
323 0
1
0 0 23 34
1
end_operator
begin_operator
walk location30 location31 bob
1
324 0
1
0 0 24 25
1
end_operator
begin_operator
walk location31 location32 bob
1
325 0
1
0 0 25 26
1
end_operator
begin_operator
walk location32 location33 bob
1
326 0
1
0 0 26 27
1
end_operator
begin_operator
walk location33 location34 bob
1
327 0
1
0 0 27 28
1
end_operator
begin_operator
walk location34 location35 bob
1
328 0
1
0 0 28 29
1
end_operator
begin_operator
walk location35 location36 bob
1
329 0
1
0 0 29 30
1
end_operator
begin_operator
walk location36 location37 bob
1
330 0
1
0 0 30 31
1
end_operator
begin_operator
walk location37 location38 bob
1
331 0
1
0 0 31 32
1
end_operator
begin_operator
walk location38 location39 bob
1
332 0
1
0 0 32 33
1
end_operator
begin_operator
walk location39 location40 bob
1
333 0
1
0 0 33 35
1
end_operator
begin_operator
walk location4 location5 bob
1
334 0
1
0 0 34 45
1
end_operator
begin_operator
walk location40 location41 bob
1
335 0
1
0 0 35 36
1
end_operator
begin_operator
walk location41 location42 bob
1
336 0
1
0 0 36 37
1
end_operator
begin_operator
walk location42 location43 bob
1
337 0
1
0 0 37 38
1
end_operator
begin_operator
walk location43 location44 bob
1
338 0
1
0 0 38 39
1
end_operator
begin_operator
walk location44 location45 bob
1
339 0
1
0 0 39 40
1
end_operator
begin_operator
walk location45 location46 bob
1
340 0
1
0 0 40 41
1
end_operator
begin_operator
walk location46 location47 bob
1
341 0
1
0 0 41 42
1
end_operator
begin_operator
walk location47 location48 bob
1
342 0
1
0 0 42 43
1
end_operator
begin_operator
walk location48 location49 bob
1
343 0
1
0 0 43 44
1
end_operator
begin_operator
walk location49 location50 bob
1
344 0
1
0 0 44 46
1
end_operator
begin_operator
walk location5 location6 bob
1
345 0
1
0 0 45 47
1
end_operator
begin_operator
walk location50 gate bob
1
346 0
1
0 0 46 0
1
end_operator
begin_operator
walk location6 location7 bob
1
347 0
1
0 0 47 48
1
end_operator
begin_operator
walk location7 location8 bob
1
348 0
1
0 0 48 49
1
end_operator
begin_operator
walk location8 location9 bob
1
349 0
1
0 0 49 50
1
end_operator
begin_operator
walk location9 location10 bob
1
350 0
1
0 0 50 2
1
end_operator
begin_operator
walk shed location1 bob
1
351 0
1
0 0 51 1
1
end_operator
0
