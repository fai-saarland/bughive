begin_version
3
end_version
begin_metric
1
end_metric
144
begin_variable
var0
-1
22
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location3
at bob location4
at bob location5
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location11
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner10 location14
carrying bob spanner10
end_variable
begin_variable
var3
-1
2
at spanner11 location18
carrying bob spanner11
end_variable
begin_variable
var4
-1
2
at spanner12 location19
carrying bob spanner12
end_variable
begin_variable
var5
-1
2
at spanner13 location7
carrying bob spanner13
end_variable
begin_variable
var6
-1
2
at spanner14 location5
carrying bob spanner14
end_variable
begin_variable
var7
-1
2
at spanner15 location15
carrying bob spanner15
end_variable
begin_variable
var8
-1
2
at spanner16 location14
carrying bob spanner16
end_variable
begin_variable
var9
-1
2
at spanner17 location1
carrying bob spanner17
end_variable
begin_variable
var10
-1
2
at spanner18 location13
carrying bob spanner18
end_variable
begin_variable
var11
-1
2
at spanner19 location15
carrying bob spanner19
end_variable
begin_variable
var12
-1
2
at spanner2 location6
carrying bob spanner2
end_variable
begin_variable
var13
-1
2
at spanner20 location4
carrying bob spanner20
end_variable
begin_variable
var14
-1
2
at spanner21 location16
carrying bob spanner21
end_variable
begin_variable
var15
-1
2
at spanner22 location20
carrying bob spanner22
end_variable
begin_variable
var16
-1
2
at spanner23 location8
carrying bob spanner23
end_variable
begin_variable
var17
-1
2
at spanner24 location13
carrying bob spanner24
end_variable
begin_variable
var18
-1
2
at spanner25 location16
carrying bob spanner25
end_variable
begin_variable
var19
-1
2
at spanner26 location12
carrying bob spanner26
end_variable
begin_variable
var20
-1
2
at spanner27 location6
carrying bob spanner27
end_variable
begin_variable
var21
-1
2
at spanner28 location7
carrying bob spanner28
end_variable
begin_variable
var22
-1
2
at spanner29 location20
carrying bob spanner29
end_variable
begin_variable
var23
-1
2
at spanner3 location5
carrying bob spanner3
end_variable
begin_variable
var24
-1
2
at spanner30 location13
carrying bob spanner30
end_variable
begin_variable
var25
-1
2
at spanner31 location18
carrying bob spanner31
end_variable
begin_variable
var26
-1
2
at spanner32 location5
carrying bob spanner32
end_variable
begin_variable
var27
-1
2
at spanner33 location16
carrying bob spanner33
end_variable
begin_variable
var28
-1
2
at spanner34 location18
carrying bob spanner34
end_variable
begin_variable
var29
-1
2
at spanner35 location10
carrying bob spanner35
end_variable
begin_variable
var30
-1
2
at spanner36 location8
carrying bob spanner36
end_variable
begin_variable
var31
-1
2
at spanner37 location4
carrying bob spanner37
end_variable
begin_variable
var32
-1
2
at spanner38 location6
carrying bob spanner38
end_variable
begin_variable
var33
-1
2
at spanner39 location1
carrying bob spanner39
end_variable
begin_variable
var34
-1
2
at spanner4 location13
carrying bob spanner4
end_variable
begin_variable
var35
-1
2
at spanner40 location9
carrying bob spanner40
end_variable
begin_variable
var36
-1
2
at spanner5 location7
carrying bob spanner5
end_variable
begin_variable
var37
-1
2
at spanner6 location20
carrying bob spanner6
end_variable
begin_variable
var38
-1
2
at spanner7 location1
carrying bob spanner7
end_variable
begin_variable
var39
-1
2
at spanner8 location12
carrying bob spanner8
end_variable
begin_variable
var40
-1
2
at spanner9 location9
carrying bob spanner9
end_variable
begin_variable
var41
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var42
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var43
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var44
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var45
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var46
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var47
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var48
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var49
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var50
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var51
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var52
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var53
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var54
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var55
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var56
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var57
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var58
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var59
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var60
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var61
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var62
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var63
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var64
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var65
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var66
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var67
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var68
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var69
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var70
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var71
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var72
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var73
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var74
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var75
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var76
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var77
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var78
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var79
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var80
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var81
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var82
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var83
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var84
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var85
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var86
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var87
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var88
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var89
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var90
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var91
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var92
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var93
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var94
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var95
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var96
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var97
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var98
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var99
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var100
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var101
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var102
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var103
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var104
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var105
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var106
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var107
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var108
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var109
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var110
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var111
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var112
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var113
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var114
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var115
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var116
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var117
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var118
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var119
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var120
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var121
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var122
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var123
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var124
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var125
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var126
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var127
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var128
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var129
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var130
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var131
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var132
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var133
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var134
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var135
-1
2
link location20 gate
none-of-those
end_variable
begin_variable
var136
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var137
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var138
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var139
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var140
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var141
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var142
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var143
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
21
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
21
41 1
42 1
43 1
44 1
45 1
46 1
47 1
48 1
49 1
50 1
51 1
52 1
53 1
54 1
55 1
56 1
57 1
58 1
59 1
60 1
61 1
end_goal
901
begin_operator
pickup_spanner location1 spanner17 bob
1
0 1
1
0 9 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner39 bob
1
0 1
1
0 33 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner7 bob
1
0 1
1
0 38 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner35 bob
1
0 2
1
0 29 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner1 bob
1
0 3
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner26 bob
1
0 4
1
0 19 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner8 bob
1
0 4
1
0 39 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner18 bob
1
0 5
1
0 10 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner24 bob
1
0 5
1
0 17 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner30 bob
1
0 5
1
0 24 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner4 bob
1
0 5
1
0 34 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner10 bob
1
0 6
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner16 bob
1
0 6
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner15 bob
1
0 7
1
0 7 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner19 bob
1
0 7
1
0 11 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner21 bob
1
0 8
1
0 14 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner25 bob
1
0 8
1
0 18 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner33 bob
1
0 8
1
0 27 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner11 bob
1
0 10
1
0 3 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner31 bob
1
0 10
1
0 25 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner34 bob
1
0 10
1
0 28 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner12 bob
1
0 11
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner22 bob
1
0 13
1
0 15 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner29 bob
1
0 13
1
0 22 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner6 bob
1
0 13
1
0 37 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner20 bob
1
0 15
1
0 13 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner37 bob
1
0 15
1
0 31 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner14 bob
1
0 16
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner3 bob
1
0 16
1
0 23 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner32 bob
1
0 16
1
0 26 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner2 bob
1
0 17
1
0 12 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner27 bob
1
0 17
1
0 20 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner38 bob
1
0 17
1
0 32 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner13 bob
1
0 18
1
0 5 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner28 bob
1
0 18
1
0 21 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner5 bob
1
0 18
1
0 36 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner23 bob
1
0 19
1
0 16 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner36 bob
1
0 19
1
0 30 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner40 bob
1
0 20
1
0 35 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner9 bob
1
0 20
1
0 40 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
62 0
2
0 41 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
1 1
63 0
2
0 42 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
1 1
64 0
2
0 43 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
1 1
65 0
2
0 44 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
1 1
66 0
2
0 45 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
1 1
67 0
2
0 46 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
1 1
68 0
2
0 47 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
1 1
69 0
2
0 48 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
1 1
70 0
2
0 49 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
1 1
71 0
2
0 50 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
1 1
72 0
2
0 51 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
73 0
2
0 52 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
1 1
74 0
2
0 53 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
1 1
75 0
2
0 54 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
1 1
76 0
2
0 55 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
1 1
77 0
2
0 56 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
1 1
78 0
2
0 57 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
1 1
79 0
2
0 58 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
1 1
80 0
2
0 59 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
1 1
81 0
2
0 60 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
1 1
82 0
2
0 61 0 1
0 83 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
2 1
62 0
2
0 41 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
2 1
63 0
2
0 42 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
2 1
64 0
2
0 43 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
2 1
65 0
2
0 44 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
2 1
66 0
2
0 45 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
2 1
67 0
2
0 46 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
2 1
68 0
2
0 47 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
2 1
69 0
2
0 48 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
2 1
70 0
2
0 49 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
2 1
71 0
2
0 50 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
2 1
72 0
2
0 51 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
2 1
73 0
2
0 52 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
2 1
74 0
2
0 53 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
2 1
75 0
2
0 54 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
2 1
76 0
2
0 55 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
2 1
77 0
2
0 56 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
2 1
78 0
2
0 57 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
2 1
79 0
2
0 58 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
2 1
80 0
2
0 59 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
2 1
81 0
2
0 60 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
2 1
82 0
2
0 61 0 1
0 84 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
3 1
62 0
2
0 41 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
3 1
63 0
2
0 42 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
3 1
64 0
2
0 43 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
3 1
65 0
2
0 44 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
3 1
66 0
2
0 45 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
3 1
67 0
2
0 46 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
3 1
68 0
2
0 47 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
3 1
69 0
2
0 48 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
3 1
70 0
2
0 49 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
3 1
71 0
2
0 50 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
3 1
72 0
2
0 51 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
3 1
73 0
2
0 52 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
3 1
74 0
2
0 53 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
3 1
75 0
2
0 54 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
3 1
76 0
2
0 55 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
3 1
77 0
2
0 56 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
3 1
78 0
2
0 57 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
3 1
79 0
2
0 58 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
3 1
80 0
2
0 59 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
3 1
81 0
2
0 60 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
3 1
82 0
2
0 61 0 1
0 85 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
4 1
62 0
2
0 41 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
4 1
63 0
2
0 42 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
4 1
64 0
2
0 43 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
4 1
65 0
2
0 44 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
4 1
66 0
2
0 45 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
4 1
67 0
2
0 46 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
4 1
68 0
2
0 47 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
4 1
69 0
2
0 48 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
4 1
70 0
2
0 49 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
4 1
71 0
2
0 50 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
4 1
72 0
2
0 51 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
4 1
73 0
2
0 52 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
4 1
74 0
2
0 53 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
4 1
75 0
2
0 54 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
4 1
76 0
2
0 55 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
4 1
77 0
2
0 56 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
4 1
78 0
2
0 57 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
4 1
79 0
2
0 58 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
4 1
80 0
2
0 59 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
4 1
81 0
2
0 60 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
4 1
82 0
2
0 61 0 1
0 86 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
5 1
62 0
2
0 41 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
5 1
63 0
2
0 42 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
5 1
64 0
2
0 43 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
5 1
65 0
2
0 44 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
5 1
66 0
2
0 45 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
5 1
67 0
2
0 46 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
5 1
68 0
2
0 47 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
5 1
69 0
2
0 48 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
5 1
70 0
2
0 49 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
5 1
71 0
2
0 50 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
5 1
72 0
2
0 51 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
5 1
73 0
2
0 52 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
5 1
74 0
2
0 53 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
5 1
75 0
2
0 54 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
5 1
76 0
2
0 55 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
5 1
77 0
2
0 56 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
5 1
78 0
2
0 57 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
5 1
79 0
2
0 58 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
5 1
80 0
2
0 59 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
5 1
81 0
2
0 60 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
5 1
82 0
2
0 61 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
6 1
62 0
2
0 41 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
6 1
63 0
2
0 42 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
6 1
64 0
2
0 43 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
6 1
65 0
2
0 44 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
6 1
66 0
2
0 45 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
6 1
67 0
2
0 46 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
6 1
68 0
2
0 47 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
6 1
69 0
2
0 48 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
6 1
70 0
2
0 49 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
6 1
71 0
2
0 50 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
6 1
72 0
2
0 51 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
6 1
73 0
2
0 52 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
6 1
74 0
2
0 53 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
6 1
75 0
2
0 54 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
6 1
76 0
2
0 55 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
6 1
77 0
2
0 56 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
6 1
78 0
2
0 57 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
6 1
79 0
2
0 58 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
6 1
80 0
2
0 59 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
6 1
81 0
2
0 60 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
6 1
82 0
2
0 61 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
7 1
62 0
2
0 41 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
7 1
63 0
2
0 42 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
7 1
64 0
2
0 43 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
7 1
65 0
2
0 44 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
7 1
66 0
2
0 45 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
7 1
67 0
2
0 46 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
7 1
68 0
2
0 47 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
7 1
69 0
2
0 48 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
7 1
70 0
2
0 49 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
7 1
71 0
2
0 50 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
7 1
72 0
2
0 51 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
7 1
73 0
2
0 52 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
7 1
74 0
2
0 53 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
7 1
75 0
2
0 54 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
7 1
76 0
2
0 55 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
7 1
77 0
2
0 56 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
7 1
78 0
2
0 57 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
7 1
79 0
2
0 58 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
7 1
80 0
2
0 59 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
7 1
81 0
2
0 60 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
7 1
82 0
2
0 61 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
8 1
62 0
2
0 41 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
8 1
63 0
2
0 42 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
8 1
64 0
2
0 43 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
8 1
65 0
2
0 44 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
8 1
66 0
2
0 45 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
8 1
67 0
2
0 46 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
8 1
68 0
2
0 47 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
8 1
69 0
2
0 48 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
8 1
70 0
2
0 49 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
8 1
71 0
2
0 50 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
8 1
72 0
2
0 51 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
8 1
73 0
2
0 52 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
8 1
74 0
2
0 53 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
8 1
75 0
2
0 54 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
8 1
76 0
2
0 55 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
8 1
77 0
2
0 56 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
8 1
78 0
2
0 57 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
8 1
79 0
2
0 58 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
8 1
80 0
2
0 59 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
8 1
81 0
2
0 60 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
8 1
82 0
2
0 61 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
9 1
62 0
2
0 41 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
9 1
63 0
2
0 42 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
9 1
64 0
2
0 43 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
9 1
65 0
2
0 44 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
9 1
66 0
2
0 45 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
9 1
67 0
2
0 46 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
9 1
68 0
2
0 47 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
9 1
69 0
2
0 48 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
9 1
70 0
2
0 49 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
9 1
71 0
2
0 50 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
9 1
72 0
2
0 51 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
9 1
73 0
2
0 52 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
9 1
74 0
2
0 53 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
9 1
75 0
2
0 54 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
9 1
76 0
2
0 55 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
9 1
77 0
2
0 56 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
9 1
78 0
2
0 57 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
9 1
79 0
2
0 58 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
9 1
80 0
2
0 59 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
9 1
81 0
2
0 60 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
9 1
82 0
2
0 61 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
10 1
62 0
2
0 41 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
10 1
63 0
2
0 42 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
10 1
64 0
2
0 43 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
10 1
65 0
2
0 44 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
10 1
66 0
2
0 45 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
10 1
67 0
2
0 46 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
10 1
68 0
2
0 47 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
10 1
69 0
2
0 48 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
10 1
70 0
2
0 49 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
10 1
71 0
2
0 50 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
10 1
72 0
2
0 51 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
10 1
73 0
2
0 52 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
10 1
74 0
2
0 53 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
10 1
75 0
2
0 54 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
10 1
76 0
2
0 55 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
10 1
77 0
2
0 56 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
10 1
78 0
2
0 57 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
10 1
79 0
2
0 58 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
10 1
80 0
2
0 59 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
10 1
81 0
2
0 60 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
10 1
82 0
2
0 61 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
11 1
62 0
2
0 41 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
11 1
63 0
2
0 42 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
11 1
64 0
2
0 43 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
11 1
65 0
2
0 44 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
11 1
66 0
2
0 45 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
11 1
67 0
2
0 46 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
11 1
68 0
2
0 47 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
11 1
69 0
2
0 48 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
11 1
70 0
2
0 49 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
11 1
71 0
2
0 50 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
11 1
72 0
2
0 51 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
11 1
73 0
2
0 52 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
11 1
74 0
2
0 53 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
11 1
75 0
2
0 54 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
11 1
76 0
2
0 55 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
11 1
77 0
2
0 56 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
11 1
78 0
2
0 57 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
11 1
79 0
2
0 58 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
11 1
80 0
2
0 59 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
11 1
81 0
2
0 60 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
11 1
82 0
2
0 61 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
12 1
62 0
2
0 41 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
12 1
63 0
2
0 42 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
12 1
64 0
2
0 43 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
12 1
65 0
2
0 44 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
12 1
66 0
2
0 45 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
12 1
67 0
2
0 46 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
12 1
68 0
2
0 47 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
12 1
69 0
2
0 48 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
12 1
70 0
2
0 49 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
12 1
71 0
2
0 50 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
12 1
72 0
2
0 51 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
12 1
73 0
2
0 52 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
12 1
74 0
2
0 53 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
12 1
75 0
2
0 54 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
12 1
76 0
2
0 55 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
12 1
77 0
2
0 56 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
12 1
78 0
2
0 57 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
12 1
79 0
2
0 58 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
12 1
80 0
2
0 59 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
12 1
81 0
2
0 60 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
12 1
82 0
2
0 61 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
13 1
62 0
2
0 41 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
13 1
63 0
2
0 42 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
13 1
64 0
2
0 43 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
13 1
65 0
2
0 44 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
13 1
66 0
2
0 45 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
13 1
67 0
2
0 46 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
13 1
68 0
2
0 47 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
13 1
69 0
2
0 48 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
13 1
70 0
2
0 49 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
13 1
71 0
2
0 50 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
13 1
72 0
2
0 51 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
13 1
73 0
2
0 52 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
13 1
74 0
2
0 53 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
13 1
75 0
2
0 54 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
13 1
76 0
2
0 55 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
13 1
77 0
2
0 56 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
13 1
78 0
2
0 57 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
13 1
79 0
2
0 58 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
13 1
80 0
2
0 59 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
13 1
81 0
2
0 60 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
13 1
82 0
2
0 61 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
14 1
62 0
2
0 41 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
14 1
63 0
2
0 42 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
14 1
64 0
2
0 43 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
14 1
65 0
2
0 44 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
14 1
66 0
2
0 45 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
14 1
67 0
2
0 46 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
14 1
68 0
2
0 47 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
14 1
69 0
2
0 48 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
14 1
70 0
2
0 49 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
14 1
71 0
2
0 50 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
14 1
72 0
2
0 51 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
14 1
73 0
2
0 52 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
14 1
74 0
2
0 53 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
14 1
75 0
2
0 54 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
14 1
76 0
2
0 55 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
14 1
77 0
2
0 56 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
14 1
78 0
2
0 57 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
14 1
79 0
2
0 58 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
14 1
80 0
2
0 59 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
14 1
81 0
2
0 60 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
14 1
82 0
2
0 61 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
15 1
62 0
2
0 41 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
15 1
63 0
2
0 42 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
15 1
64 0
2
0 43 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
15 1
65 0
2
0 44 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
15 1
66 0
2
0 45 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
15 1
67 0
2
0 46 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
15 1
68 0
2
0 47 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
15 1
69 0
2
0 48 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
15 1
70 0
2
0 49 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
15 1
71 0
2
0 50 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
15 1
72 0
2
0 51 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
15 1
73 0
2
0 52 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
15 1
74 0
2
0 53 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
15 1
75 0
2
0 54 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
15 1
76 0
2
0 55 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
15 1
77 0
2
0 56 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
15 1
78 0
2
0 57 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
15 1
79 0
2
0 58 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
15 1
80 0
2
0 59 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
15 1
81 0
2
0 60 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
15 1
82 0
2
0 61 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
16 1
62 0
2
0 41 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
16 1
63 0
2
0 42 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
16 1
64 0
2
0 43 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
16 1
65 0
2
0 44 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
16 1
66 0
2
0 45 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
16 1
67 0
2
0 46 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
16 1
68 0
2
0 47 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
16 1
69 0
2
0 48 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
16 1
70 0
2
0 49 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
16 1
71 0
2
0 50 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
16 1
72 0
2
0 51 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
16 1
73 0
2
0 52 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
16 1
74 0
2
0 53 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
16 1
75 0
2
0 54 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
16 1
76 0
2
0 55 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
16 1
77 0
2
0 56 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
16 1
78 0
2
0 57 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
16 1
79 0
2
0 58 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
16 1
80 0
2
0 59 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
16 1
81 0
2
0 60 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
16 1
82 0
2
0 61 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
17 1
62 0
2
0 41 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
17 1
63 0
2
0 42 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
17 1
64 0
2
0 43 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
17 1
65 0
2
0 44 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
17 1
66 0
2
0 45 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
17 1
67 0
2
0 46 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
17 1
68 0
2
0 47 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
17 1
69 0
2
0 48 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
17 1
70 0
2
0 49 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
17 1
71 0
2
0 50 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
17 1
72 0
2
0 51 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
17 1
73 0
2
0 52 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
17 1
74 0
2
0 53 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
17 1
75 0
2
0 54 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
17 1
76 0
2
0 55 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
17 1
77 0
2
0 56 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
17 1
78 0
2
0 57 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
17 1
79 0
2
0 58 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
17 1
80 0
2
0 59 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
17 1
81 0
2
0 60 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
17 1
82 0
2
0 61 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
18 1
62 0
2
0 41 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
18 1
63 0
2
0 42 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
18 1
64 0
2
0 43 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
18 1
65 0
2
0 44 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
18 1
66 0
2
0 45 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
18 1
67 0
2
0 46 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
18 1
68 0
2
0 47 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
18 1
69 0
2
0 48 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
18 1
70 0
2
0 49 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
18 1
71 0
2
0 50 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
18 1
72 0
2
0 51 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
18 1
73 0
2
0 52 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
18 1
74 0
2
0 53 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
18 1
75 0
2
0 54 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
18 1
76 0
2
0 55 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
18 1
77 0
2
0 56 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
18 1
78 0
2
0 57 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
18 1
79 0
2
0 58 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
18 1
80 0
2
0 59 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
18 1
81 0
2
0 60 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
18 1
82 0
2
0 61 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
19 1
62 0
2
0 41 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
19 1
63 0
2
0 42 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
19 1
64 0
2
0 43 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
19 1
65 0
2
0 44 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
19 1
66 0
2
0 45 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
19 1
67 0
2
0 46 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
19 1
68 0
2
0 47 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
19 1
69 0
2
0 48 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
19 1
70 0
2
0 49 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
19 1
71 0
2
0 50 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
19 1
72 0
2
0 51 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
19 1
73 0
2
0 52 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
19 1
74 0
2
0 53 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
19 1
75 0
2
0 54 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
19 1
76 0
2
0 55 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
19 1
77 0
2
0 56 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
19 1
78 0
2
0 57 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
19 1
79 0
2
0 58 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
19 1
80 0
2
0 59 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
19 1
81 0
2
0 60 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
19 1
82 0
2
0 61 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
20 1
62 0
2
0 41 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
20 1
63 0
2
0 42 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
20 1
64 0
2
0 43 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
20 1
65 0
2
0 44 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
20 1
66 0
2
0 45 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
20 1
67 0
2
0 46 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
20 1
68 0
2
0 47 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
20 1
69 0
2
0 48 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
20 1
70 0
2
0 49 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
20 1
71 0
2
0 50 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
20 1
72 0
2
0 51 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
20 1
73 0
2
0 52 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
20 1
74 0
2
0 53 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
20 1
75 0
2
0 54 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
20 1
76 0
2
0 55 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
20 1
77 0
2
0 56 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
20 1
78 0
2
0 57 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
20 1
79 0
2
0 58 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
20 1
80 0
2
0 59 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
20 1
81 0
2
0 60 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
20 1
82 0
2
0 61 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
21 1
62 0
2
0 41 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
21 1
63 0
2
0 42 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
21 1
64 0
2
0 43 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
21 1
65 0
2
0 44 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
21 1
66 0
2
0 45 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
21 1
67 0
2
0 46 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
21 1
68 0
2
0 47 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
21 1
69 0
2
0 48 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
21 1
70 0
2
0 49 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
21 1
71 0
2
0 50 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
21 1
72 0
2
0 51 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
21 1
73 0
2
0 52 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
21 1
74 0
2
0 53 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
21 1
75 0
2
0 54 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
21 1
76 0
2
0 55 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
21 1
77 0
2
0 56 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
21 1
78 0
2
0 57 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
21 1
79 0
2
0 58 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
21 1
80 0
2
0 59 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
21 1
81 0
2
0 60 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
21 1
82 0
2
0 61 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
22 1
62 0
2
0 41 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
22 1
63 0
2
0 42 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
22 1
64 0
2
0 43 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
22 1
65 0
2
0 44 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
22 1
66 0
2
0 45 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
22 1
67 0
2
0 46 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
22 1
68 0
2
0 47 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
22 1
69 0
2
0 48 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
22 1
70 0
2
0 49 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
22 1
71 0
2
0 50 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
22 1
72 0
2
0 51 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
22 1
73 0
2
0 52 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
22 1
74 0
2
0 53 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
22 1
75 0
2
0 54 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
22 1
76 0
2
0 55 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
22 1
77 0
2
0 56 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
22 1
78 0
2
0 57 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
22 1
79 0
2
0 58 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
22 1
80 0
2
0 59 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
22 1
81 0
2
0 60 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
22 1
82 0
2
0 61 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
23 1
62 0
2
0 41 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
23 1
63 0
2
0 42 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
23 1
64 0
2
0 43 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
23 1
65 0
2
0 44 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
23 1
66 0
2
0 45 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
23 1
67 0
2
0 46 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
23 1
68 0
2
0 47 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
23 1
69 0
2
0 48 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
23 1
70 0
2
0 49 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
23 1
71 0
2
0 50 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
23 1
72 0
2
0 51 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
23 1
73 0
2
0 52 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
23 1
74 0
2
0 53 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
23 1
75 0
2
0 54 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
23 1
76 0
2
0 55 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
23 1
77 0
2
0 56 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
23 1
78 0
2
0 57 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
23 1
79 0
2
0 58 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
23 1
80 0
2
0 59 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
23 1
81 0
2
0 60 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
23 1
82 0
2
0 61 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
24 1
62 0
2
0 41 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
24 1
63 0
2
0 42 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
24 1
64 0
2
0 43 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
24 1
65 0
2
0 44 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
24 1
66 0
2
0 45 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
24 1
67 0
2
0 46 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
24 1
68 0
2
0 47 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
24 1
69 0
2
0 48 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
24 1
70 0
2
0 49 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
24 1
71 0
2
0 50 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
24 1
72 0
2
0 51 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
24 1
73 0
2
0 52 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
24 1
74 0
2
0 53 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
24 1
75 0
2
0 54 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
24 1
76 0
2
0 55 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
24 1
77 0
2
0 56 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
24 1
78 0
2
0 57 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
24 1
79 0
2
0 58 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
24 1
80 0
2
0 59 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
24 1
81 0
2
0 60 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
24 1
82 0
2
0 61 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
25 1
62 0
2
0 41 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
25 1
63 0
2
0 42 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
25 1
64 0
2
0 43 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
25 1
65 0
2
0 44 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
25 1
66 0
2
0 45 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
25 1
67 0
2
0 46 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
25 1
68 0
2
0 47 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
25 1
69 0
2
0 48 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
25 1
70 0
2
0 49 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
25 1
71 0
2
0 50 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
25 1
72 0
2
0 51 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
25 1
73 0
2
0 52 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
25 1
74 0
2
0 53 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
25 1
75 0
2
0 54 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
25 1
76 0
2
0 55 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
25 1
77 0
2
0 56 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
25 1
78 0
2
0 57 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
25 1
79 0
2
0 58 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
25 1
80 0
2
0 59 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
25 1
81 0
2
0 60 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
25 1
82 0
2
0 61 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
26 1
62 0
2
0 41 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
26 1
63 0
2
0 42 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
26 1
64 0
2
0 43 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
26 1
65 0
2
0 44 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
26 1
66 0
2
0 45 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
26 1
67 0
2
0 46 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
26 1
68 0
2
0 47 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
26 1
69 0
2
0 48 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
26 1
70 0
2
0 49 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
26 1
71 0
2
0 50 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
26 1
72 0
2
0 51 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
26 1
73 0
2
0 52 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
26 1
74 0
2
0 53 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
26 1
75 0
2
0 54 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
26 1
76 0
2
0 55 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
26 1
77 0
2
0 56 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
26 1
78 0
2
0 57 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
26 1
79 0
2
0 58 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
26 1
80 0
2
0 59 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
26 1
81 0
2
0 60 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
26 1
82 0
2
0 61 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
27 1
62 0
2
0 41 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
27 1
63 0
2
0 42 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
27 1
64 0
2
0 43 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
27 1
65 0
2
0 44 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
27 1
66 0
2
0 45 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
27 1
67 0
2
0 46 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
27 1
68 0
2
0 47 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
27 1
69 0
2
0 48 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
27 1
70 0
2
0 49 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
27 1
71 0
2
0 50 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
27 1
72 0
2
0 51 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
27 1
73 0
2
0 52 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
27 1
74 0
2
0 53 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
27 1
75 0
2
0 54 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
27 1
76 0
2
0 55 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
27 1
77 0
2
0 56 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
27 1
78 0
2
0 57 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
27 1
79 0
2
0 58 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
27 1
80 0
2
0 59 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
27 1
81 0
2
0 60 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
27 1
82 0
2
0 61 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
28 1
62 0
2
0 41 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
28 1
63 0
2
0 42 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
28 1
64 0
2
0 43 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
28 1
65 0
2
0 44 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
28 1
66 0
2
0 45 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
28 1
67 0
2
0 46 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
28 1
68 0
2
0 47 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
28 1
69 0
2
0 48 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
28 1
70 0
2
0 49 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
28 1
71 0
2
0 50 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
28 1
72 0
2
0 51 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
28 1
73 0
2
0 52 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
28 1
74 0
2
0 53 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
28 1
75 0
2
0 54 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
28 1
76 0
2
0 55 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
28 1
77 0
2
0 56 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
28 1
78 0
2
0 57 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
28 1
79 0
2
0 58 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
28 1
80 0
2
0 59 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
28 1
81 0
2
0 60 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
28 1
82 0
2
0 61 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
29 1
62 0
2
0 41 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
29 1
63 0
2
0 42 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
29 1
64 0
2
0 43 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
29 1
65 0
2
0 44 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
29 1
66 0
2
0 45 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
29 1
67 0
2
0 46 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
29 1
68 0
2
0 47 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
29 1
69 0
2
0 48 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
29 1
70 0
2
0 49 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
29 1
71 0
2
0 50 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
29 1
72 0
2
0 51 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
29 1
73 0
2
0 52 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
29 1
74 0
2
0 53 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
29 1
75 0
2
0 54 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
29 1
76 0
2
0 55 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
29 1
77 0
2
0 56 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
29 1
78 0
2
0 57 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
29 1
79 0
2
0 58 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
29 1
80 0
2
0 59 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
29 1
81 0
2
0 60 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
29 1
82 0
2
0 61 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
30 1
62 0
2
0 41 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
30 1
63 0
2
0 42 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
30 1
64 0
2
0 43 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
30 1
65 0
2
0 44 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
30 1
66 0
2
0 45 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
30 1
67 0
2
0 46 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
30 1
68 0
2
0 47 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
30 1
69 0
2
0 48 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
30 1
70 0
2
0 49 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
30 1
71 0
2
0 50 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
30 1
72 0
2
0 51 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
30 1
73 0
2
0 52 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
30 1
74 0
2
0 53 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
30 1
75 0
2
0 54 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
30 1
76 0
2
0 55 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
30 1
77 0
2
0 56 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
30 1
78 0
2
0 57 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
30 1
79 0
2
0 58 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
30 1
80 0
2
0 59 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
30 1
81 0
2
0 60 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
30 1
82 0
2
0 61 0 1
0 112 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
31 1
62 0
2
0 41 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
31 1
63 0
2
0 42 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
31 1
64 0
2
0 43 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
31 1
65 0
2
0 44 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
31 1
66 0
2
0 45 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
31 1
67 0
2
0 46 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
31 1
68 0
2
0 47 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
31 1
69 0
2
0 48 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
31 1
70 0
2
0 49 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
31 1
71 0
2
0 50 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
31 1
72 0
2
0 51 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
31 1
73 0
2
0 52 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
31 1
74 0
2
0 53 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
31 1
75 0
2
0 54 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
31 1
76 0
2
0 55 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
31 1
77 0
2
0 56 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
31 1
78 0
2
0 57 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
31 1
79 0
2
0 58 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
31 1
80 0
2
0 59 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
31 1
81 0
2
0 60 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
31 1
82 0
2
0 61 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
32 1
62 0
2
0 41 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
32 1
63 0
2
0 42 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
32 1
64 0
2
0 43 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
32 1
65 0
2
0 44 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
32 1
66 0
2
0 45 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
32 1
67 0
2
0 46 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
32 1
68 0
2
0 47 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
32 1
69 0
2
0 48 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
32 1
70 0
2
0 49 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
32 1
71 0
2
0 50 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
32 1
72 0
2
0 51 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
32 1
73 0
2
0 52 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
32 1
74 0
2
0 53 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
32 1
75 0
2
0 54 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
32 1
76 0
2
0 55 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
32 1
77 0
2
0 56 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
32 1
78 0
2
0 57 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
32 1
79 0
2
0 58 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
32 1
80 0
2
0 59 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
32 1
81 0
2
0 60 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
32 1
82 0
2
0 61 0 1
0 114 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
33 1
62 0
2
0 41 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
33 1
63 0
2
0 42 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
33 1
64 0
2
0 43 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
33 1
65 0
2
0 44 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
33 1
66 0
2
0 45 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
33 1
67 0
2
0 46 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
33 1
68 0
2
0 47 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
33 1
69 0
2
0 48 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
33 1
70 0
2
0 49 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
33 1
71 0
2
0 50 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
33 1
72 0
2
0 51 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
33 1
73 0
2
0 52 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
33 1
74 0
2
0 53 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
33 1
75 0
2
0 54 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
33 1
76 0
2
0 55 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
33 1
77 0
2
0 56 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
33 1
78 0
2
0 57 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
33 1
79 0
2
0 58 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
33 1
80 0
2
0 59 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
33 1
81 0
2
0 60 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
33 1
82 0
2
0 61 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
34 1
62 0
2
0 41 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
34 1
63 0
2
0 42 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
34 1
64 0
2
0 43 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
34 1
65 0
2
0 44 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
34 1
66 0
2
0 45 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
34 1
67 0
2
0 46 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
34 1
68 0
2
0 47 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
34 1
69 0
2
0 48 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
34 1
70 0
2
0 49 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
34 1
71 0
2
0 50 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
34 1
72 0
2
0 51 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
34 1
73 0
2
0 52 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
34 1
74 0
2
0 53 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
34 1
75 0
2
0 54 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
34 1
76 0
2
0 55 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
34 1
77 0
2
0 56 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
34 1
78 0
2
0 57 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
34 1
79 0
2
0 58 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
34 1
80 0
2
0 59 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
34 1
81 0
2
0 60 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
34 1
82 0
2
0 61 0 1
0 116 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
35 1
62 0
2
0 41 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
35 1
63 0
2
0 42 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
35 1
64 0
2
0 43 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
35 1
65 0
2
0 44 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
35 1
66 0
2
0 45 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
35 1
67 0
2
0 46 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
35 1
68 0
2
0 47 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
35 1
69 0
2
0 48 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
35 1
70 0
2
0 49 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
35 1
71 0
2
0 50 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
35 1
72 0
2
0 51 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
35 1
73 0
2
0 52 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
35 1
74 0
2
0 53 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
35 1
75 0
2
0 54 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
35 1
76 0
2
0 55 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
35 1
77 0
2
0 56 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
35 1
78 0
2
0 57 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
35 1
79 0
2
0 58 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
35 1
80 0
2
0 59 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
35 1
81 0
2
0 60 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
35 1
82 0
2
0 61 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
36 1
62 0
2
0 41 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
36 1
63 0
2
0 42 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
36 1
64 0
2
0 43 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
36 1
65 0
2
0 44 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
36 1
66 0
2
0 45 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
36 1
67 0
2
0 46 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
36 1
68 0
2
0 47 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
36 1
69 0
2
0 48 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
36 1
70 0
2
0 49 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
36 1
71 0
2
0 50 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
36 1
72 0
2
0 51 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
36 1
73 0
2
0 52 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
36 1
74 0
2
0 53 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
36 1
75 0
2
0 54 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
36 1
76 0
2
0 55 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
36 1
77 0
2
0 56 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
36 1
78 0
2
0 57 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
36 1
79 0
2
0 58 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
36 1
80 0
2
0 59 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
36 1
81 0
2
0 60 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
36 1
82 0
2
0 61 0 1
0 118 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
37 1
62 0
2
0 41 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
37 1
63 0
2
0 42 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
37 1
64 0
2
0 43 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
37 1
65 0
2
0 44 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
37 1
66 0
2
0 45 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
37 1
67 0
2
0 46 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
37 1
68 0
2
0 47 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
37 1
69 0
2
0 48 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
37 1
70 0
2
0 49 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
37 1
71 0
2
0 50 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
37 1
72 0
2
0 51 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
37 1
73 0
2
0 52 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
37 1
74 0
2
0 53 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
37 1
75 0
2
0 54 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
37 1
76 0
2
0 55 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
37 1
77 0
2
0 56 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
37 1
78 0
2
0 57 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
37 1
79 0
2
0 58 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
37 1
80 0
2
0 59 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
37 1
81 0
2
0 60 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
37 1
82 0
2
0 61 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
38 1
62 0
2
0 41 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
38 1
63 0
2
0 42 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
38 1
64 0
2
0 43 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
38 1
65 0
2
0 44 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
38 1
66 0
2
0 45 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
38 1
67 0
2
0 46 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
38 1
68 0
2
0 47 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
38 1
69 0
2
0 48 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
38 1
70 0
2
0 49 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
38 1
71 0
2
0 50 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
38 1
72 0
2
0 51 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
38 1
73 0
2
0 52 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
38 1
74 0
2
0 53 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
38 1
75 0
2
0 54 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
38 1
76 0
2
0 55 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
38 1
77 0
2
0 56 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
38 1
78 0
2
0 57 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
38 1
79 0
2
0 58 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
38 1
80 0
2
0 59 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
38 1
81 0
2
0 60 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
38 1
82 0
2
0 61 0 1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
39 1
62 0
2
0 41 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
39 1
63 0
2
0 42 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
39 1
64 0
2
0 43 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
39 1
65 0
2
0 44 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
39 1
66 0
2
0 45 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
39 1
67 0
2
0 46 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
39 1
68 0
2
0 47 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
39 1
69 0
2
0 48 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
39 1
70 0
2
0 49 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
39 1
71 0
2
0 50 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
39 1
72 0
2
0 51 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
39 1
73 0
2
0 52 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
39 1
74 0
2
0 53 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
39 1
75 0
2
0 54 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
39 1
76 0
2
0 55 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
39 1
77 0
2
0 56 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
39 1
78 0
2
0 57 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
39 1
79 0
2
0 58 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
39 1
80 0
2
0 59 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
39 1
81 0
2
0 60 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
39 1
82 0
2
0 61 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
40 1
62 0
2
0 41 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
40 1
63 0
2
0 42 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
40 1
64 0
2
0 43 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
40 1
65 0
2
0 44 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
40 1
66 0
2
0 45 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
40 1
67 0
2
0 46 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
40 1
68 0
2
0 47 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
40 1
69 0
2
0 48 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
40 1
70 0
2
0 49 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
40 1
71 0
2
0 50 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
40 1
72 0
2
0 51 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
40 1
73 0
2
0 52 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
40 1
74 0
2
0 53 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
40 1
75 0
2
0 54 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
40 1
76 0
2
0 55 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
40 1
77 0
2
0 56 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
40 1
78 0
2
0 57 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
40 1
79 0
2
0 58 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
40 1
80 0
2
0 59 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
40 1
81 0
2
0 60 0 1
0 122 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
40 1
82 0
2
0 61 0 1
0 122 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
123 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
124 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
125 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
126 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
127 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
128 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
129 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
130 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
131 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
132 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
133 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
134 0
1
0 0 12 14
1
end_operator
begin_operator
walk location20 gate bob
1
135 0
1
0 0 13 0
1
end_operator
begin_operator
walk location3 location4 bob
1
136 0
1
0 0 14 15
1
end_operator
begin_operator
walk location4 location5 bob
1
137 0
1
0 0 15 16
1
end_operator
begin_operator
walk location5 location6 bob
1
138 0
1
0 0 16 17
1
end_operator
begin_operator
walk location6 location7 bob
1
139 0
1
0 0 17 18
1
end_operator
begin_operator
walk location7 location8 bob
1
140 0
1
0 0 18 19
1
end_operator
begin_operator
walk location8 location9 bob
1
141 0
1
0 0 19 20
1
end_operator
begin_operator
walk location9 location10 bob
1
142 0
1
0 0 20 2
1
end_operator
begin_operator
walk shed location1 bob
1
143 0
1
0 0 21 1
1
end_operator
0
