begin_version
3
end_version
begin_metric
1
end_metric
12
begin_variable
var0
-1
6
at bob gate
at bob location1
at bob location2
at bob location3
at bob location4
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location2
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner2 location1
carrying bob spanner2
end_variable
begin_variable
var3
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var4
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var5
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var6
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var7
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var8
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var9
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var10
-1
2
link location4 gate
none-of-those
end_variable
begin_variable
var11
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
5
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
1
3 1
end_goal
9
begin_operator
pickup_spanner location1 spanner2 bob
1
0 1
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner1 bob
1
0 2
1
0 1 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
4 0
2
0 3 0 1
0 5 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
2 1
4 0
2
0 3 0 1
0 6 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
7 0
1
0 0 1 2
1
end_operator
begin_operator
walk location2 location3 bob
1
8 0
1
0 0 2 3
1
end_operator
begin_operator
walk location3 location4 bob
1
9 0
1
0 0 3 4
1
end_operator
begin_operator
walk location4 gate bob
1
10 0
1
0 0 4 0
1
end_operator
begin_operator
walk shed location1 bob
1
11 0
1
0 0 5 1
1
end_operator
0
