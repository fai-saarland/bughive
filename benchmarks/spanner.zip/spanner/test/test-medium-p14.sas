begin_version
3
end_version
begin_metric
1
end_metric
202
begin_variable
var0
-1
30
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location3
at bob location4
at bob location5
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location4
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner10 location6
carrying bob spanner10
end_variable
begin_variable
var3
-1
2
at spanner11 location20
carrying bob spanner11
end_variable
begin_variable
var4
-1
2
at spanner12 location9
carrying bob spanner12
end_variable
begin_variable
var5
-1
2
at spanner13 location12
carrying bob spanner13
end_variable
begin_variable
var6
-1
2
at spanner14 location14
carrying bob spanner14
end_variable
begin_variable
var7
-1
2
at spanner15 location17
carrying bob spanner15
end_variable
begin_variable
var8
-1
2
at spanner16 location17
carrying bob spanner16
end_variable
begin_variable
var9
-1
2
at spanner17 location9
carrying bob spanner17
end_variable
begin_variable
var10
-1
2
at spanner18 location10
carrying bob spanner18
end_variable
begin_variable
var11
-1
2
at spanner19 location14
carrying bob spanner19
end_variable
begin_variable
var12
-1
2
at spanner2 location1
carrying bob spanner2
end_variable
begin_variable
var13
-1
2
at spanner20 location2
carrying bob spanner20
end_variable
begin_variable
var14
-1
2
at spanner21 location15
carrying bob spanner21
end_variable
begin_variable
var15
-1
2
at spanner22 location5
carrying bob spanner22
end_variable
begin_variable
var16
-1
2
at spanner23 location2
carrying bob spanner23
end_variable
begin_variable
var17
-1
2
at spanner24 location20
carrying bob spanner24
end_variable
begin_variable
var18
-1
2
at spanner25 location24
carrying bob spanner25
end_variable
begin_variable
var19
-1
2
at spanner26 location16
carrying bob spanner26
end_variable
begin_variable
var20
-1
2
at spanner27 location6
carrying bob spanner27
end_variable
begin_variable
var21
-1
2
at spanner28 location14
carrying bob spanner28
end_variable
begin_variable
var22
-1
2
at spanner29 location19
carrying bob spanner29
end_variable
begin_variable
var23
-1
2
at spanner3 location15
carrying bob spanner3
end_variable
begin_variable
var24
-1
2
at spanner30 location21
carrying bob spanner30
end_variable
begin_variable
var25
-1
2
at spanner31 location4
carrying bob spanner31
end_variable
begin_variable
var26
-1
2
at spanner32 location3
carrying bob spanner32
end_variable
begin_variable
var27
-1
2
at spanner33 location5
carrying bob spanner33
end_variable
begin_variable
var28
-1
2
at spanner34 location13
carrying bob spanner34
end_variable
begin_variable
var29
-1
2
at spanner35 location25
carrying bob spanner35
end_variable
begin_variable
var30
-1
2
at spanner36 location13
carrying bob spanner36
end_variable
begin_variable
var31
-1
2
at spanner37 location17
carrying bob spanner37
end_variable
begin_variable
var32
-1
2
at spanner38 location3
carrying bob spanner38
end_variable
begin_variable
var33
-1
2
at spanner39 location21
carrying bob spanner39
end_variable
begin_variable
var34
-1
2
at spanner4 location25
carrying bob spanner4
end_variable
begin_variable
var35
-1
2
at spanner40 location16
carrying bob spanner40
end_variable
begin_variable
var36
-1
2
at spanner41 location1
carrying bob spanner41
end_variable
begin_variable
var37
-1
2
at spanner42 location13
carrying bob spanner42
end_variable
begin_variable
var38
-1
2
at spanner43 location13
carrying bob spanner43
end_variable
begin_variable
var39
-1
2
at spanner44 location8
carrying bob spanner44
end_variable
begin_variable
var40
-1
2
at spanner45 location6
carrying bob spanner45
end_variable
begin_variable
var41
-1
2
at spanner46 location10
carrying bob spanner46
end_variable
begin_variable
var42
-1
2
at spanner47 location4
carrying bob spanner47
end_variable
begin_variable
var43
-1
2
at spanner48 location26
carrying bob spanner48
end_variable
begin_variable
var44
-1
2
at spanner49 location5
carrying bob spanner49
end_variable
begin_variable
var45
-1
2
at spanner5 location13
carrying bob spanner5
end_variable
begin_variable
var46
-1
2
at spanner50 location26
carrying bob spanner50
end_variable
begin_variable
var47
-1
2
at spanner51 location6
carrying bob spanner51
end_variable
begin_variable
var48
-1
2
at spanner52 location11
carrying bob spanner52
end_variable
begin_variable
var49
-1
2
at spanner53 location8
carrying bob spanner53
end_variable
begin_variable
var50
-1
2
at spanner54 location9
carrying bob spanner54
end_variable
begin_variable
var51
-1
2
at spanner55 location12
carrying bob spanner55
end_variable
begin_variable
var52
-1
2
at spanner56 location28
carrying bob spanner56
end_variable
begin_variable
var53
-1
2
at spanner6 location19
carrying bob spanner6
end_variable
begin_variable
var54
-1
2
at spanner7 location6
carrying bob spanner7
end_variable
begin_variable
var55
-1
2
at spanner8 location10
carrying bob spanner8
end_variable
begin_variable
var56
-1
2
at spanner9 location25
carrying bob spanner9
end_variable
begin_variable
var57
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var58
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var59
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var60
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var61
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var62
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var63
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var64
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var65
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var66
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var67
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var68
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var69
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var70
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var71
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var72
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var73
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var74
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var75
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var76
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var77
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var78
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var79
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var80
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var81
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var82
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var83
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var84
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var85
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var86
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var87
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var88
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var89
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var90
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var91
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var92
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var93
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var94
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var95
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var96
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var97
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var98
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var99
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var100
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var101
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var102
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var103
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var104
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var105
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var106
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var107
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var108
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var109
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var110
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var111
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var112
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var113
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var114
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var115
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var116
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var117
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var118
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var119
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var120
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var121
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var122
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var123
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var124
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var125
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var126
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var127
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var128
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var129
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var130
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var131
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var132
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var133
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var134
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var135
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var136
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var137
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var138
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var139
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var140
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var141
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var142
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var143
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var144
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var145
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var146
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var147
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var148
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var149
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var150
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var151
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var152
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var153
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var154
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var155
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var156
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var157
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var158
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var159
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var160
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var161
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var162
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var163
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var164
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var165
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var166
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var167
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var168
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var169
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var170
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var171
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var172
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var173
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var174
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var175
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var176
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var177
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var178
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var179
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var180
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var181
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var182
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var183
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var184
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var185
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var186
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var187
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var188
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var189
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var190
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var191
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var192
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var193
-1
2
link location28 gate
none-of-those
end_variable
begin_variable
var194
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var195
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var196
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var197
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var198
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var199
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var200
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var201
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
29
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
30
57 1
58 1
59 1
60 1
61 1
62 1
63 1
64 1
65 1
66 1
67 1
68 1
69 1
70 1
71 1
72 1
73 1
74 1
75 1
76 1
77 1
78 1
79 1
80 1
81 1
82 1
83 1
84 1
85 1
86 1
end_goal
1765
begin_operator
pickup_spanner location1 spanner2 bob
1
0 1
1
0 12 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner41 bob
1
0 1
1
0 36 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner18 bob
1
0 2
1
0 10 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner46 bob
1
0 2
1
0 41 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner8 bob
1
0 2
1
0 55 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner52 bob
1
0 3
1
0 48 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner13 bob
1
0 4
1
0 5 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner55 bob
1
0 4
1
0 51 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner34 bob
1
0 5
1
0 28 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner36 bob
1
0 5
1
0 30 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner42 bob
1
0 5
1
0 37 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner43 bob
1
0 5
1
0 38 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner5 bob
1
0 5
1
0 45 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner14 bob
1
0 6
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner19 bob
1
0 6
1
0 11 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner28 bob
1
0 6
1
0 21 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner21 bob
1
0 7
1
0 14 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner3 bob
1
0 7
1
0 23 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner26 bob
1
0 8
1
0 19 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner40 bob
1
0 8
1
0 35 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner15 bob
1
0 9
1
0 7 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner16 bob
1
0 9
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner37 bob
1
0 9
1
0 31 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner29 bob
1
0 11
1
0 22 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner6 bob
1
0 11
1
0 53 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner20 bob
1
0 12
1
0 13 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner23 bob
1
0 12
1
0 16 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner11 bob
1
0 13
1
0 3 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner24 bob
1
0 13
1
0 17 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner30 bob
1
0 14
1
0 24 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner39 bob
1
0 14
1
0 33 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner25 bob
1
0 17
1
0 18 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner35 bob
1
0 18
1
0 29 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner4 bob
1
0 18
1
0 34 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner9 bob
1
0 18
1
0 56 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner48 bob
1
0 19
1
0 43 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner50 bob
1
0 19
1
0 46 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner56 bob
1
0 21
1
0 52 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner32 bob
1
0 22
1
0 26 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner38 bob
1
0 22
1
0 32 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner1 bob
1
0 23
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner31 bob
1
0 23
1
0 25 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner47 bob
1
0 23
1
0 42 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner22 bob
1
0 24
1
0 15 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner33 bob
1
0 24
1
0 27 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner49 bob
1
0 24
1
0 44 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner10 bob
1
0 25
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner27 bob
1
0 25
1
0 20 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner45 bob
1
0 25
1
0 40 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner51 bob
1
0 25
1
0 47 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner7 bob
1
0 25
1
0 54 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner44 bob
1
0 27
1
0 39 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner53 bob
1
0 27
1
0 49 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner12 bob
1
0 28
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner17 bob
1
0 28
1
0 9 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner54 bob
1
0 28
1
0 50 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
112 0
2
0 57 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
1 1
114 0
2
0 58 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
1 1
116 0
2
0 59 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
1 1
118 0
2
0 60 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
1 1
120 0
2
0 61 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
1 1
122 0
2
0 62 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
1 1
124 0
2
0 63 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
1 1
126 0
2
0 64 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
1 1
128 0
2
0 65 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
1 1
130 0
2
0 66 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
1 1
132 0
2
0 67 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
134 0
2
0 68 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
1 1
136 0
2
0 69 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
1 1
138 0
2
0 70 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
1 1
140 0
2
0 71 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
1 1
142 0
2
0 72 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
1 1
144 0
2
0 73 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
1 1
146 0
2
0 74 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
1 1
148 0
2
0 75 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
1 1
150 0
2
0 76 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
1 1
152 0
2
0 77 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
1 1
154 0
2
0 78 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
1 1
156 0
2
0 79 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
1 1
158 0
2
0 80 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
1 1
160 0
2
0 81 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
1 1
162 0
2
0 82 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
1 1
164 0
2
0 83 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
1 1
166 0
2
0 84 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
1 1
168 0
2
0 85 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
1 1
170 0
2
0 86 0 1
0 87 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
2 1
112 0
2
0 57 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
2 1
114 0
2
0 58 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
2 1
116 0
2
0 59 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
2 1
118 0
2
0 60 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
2 1
120 0
2
0 61 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
2 1
122 0
2
0 62 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
2 1
124 0
2
0 63 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
2 1
126 0
2
0 64 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
2 1
128 0
2
0 65 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
2 1
130 0
2
0 66 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
2 1
132 0
2
0 67 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
2 1
134 0
2
0 68 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
2 1
136 0
2
0 69 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
2 1
138 0
2
0 70 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
2 1
140 0
2
0 71 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
2 1
142 0
2
0 72 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
2 1
144 0
2
0 73 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
2 1
146 0
2
0 74 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
2 1
148 0
2
0 75 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
2 1
150 0
2
0 76 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
2 1
152 0
2
0 77 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
2 1
154 0
2
0 78 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
2 1
156 0
2
0 79 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
2 1
158 0
2
0 80 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
2 1
160 0
2
0 81 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
2 1
162 0
2
0 82 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
2 1
164 0
2
0 83 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
2 1
166 0
2
0 84 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
2 1
168 0
2
0 85 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
2 1
170 0
2
0 86 0 1
0 88 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
3 1
112 0
2
0 57 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
3 1
114 0
2
0 58 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
3 1
116 0
2
0 59 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
3 1
118 0
2
0 60 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
3 1
120 0
2
0 61 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
3 1
122 0
2
0 62 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
3 1
124 0
2
0 63 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
3 1
126 0
2
0 64 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
3 1
128 0
2
0 65 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
3 1
130 0
2
0 66 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
3 1
132 0
2
0 67 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
3 1
134 0
2
0 68 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
3 1
136 0
2
0 69 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
3 1
138 0
2
0 70 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
3 1
140 0
2
0 71 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
3 1
142 0
2
0 72 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
3 1
144 0
2
0 73 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
3 1
146 0
2
0 74 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
3 1
148 0
2
0 75 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
3 1
150 0
2
0 76 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
3 1
152 0
2
0 77 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
3 1
154 0
2
0 78 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
3 1
156 0
2
0 79 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
3 1
158 0
2
0 80 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
3 1
160 0
2
0 81 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
3 1
162 0
2
0 82 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
3 1
164 0
2
0 83 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
3 1
166 0
2
0 84 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
3 1
168 0
2
0 85 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
3 1
170 0
2
0 86 0 1
0 89 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
4 1
112 0
2
0 57 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
4 1
114 0
2
0 58 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
4 1
116 0
2
0 59 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
4 1
118 0
2
0 60 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
4 1
120 0
2
0 61 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
4 1
122 0
2
0 62 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
4 1
124 0
2
0 63 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
4 1
126 0
2
0 64 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
4 1
128 0
2
0 65 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
4 1
130 0
2
0 66 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
4 1
132 0
2
0 67 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
4 1
134 0
2
0 68 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
4 1
136 0
2
0 69 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
4 1
138 0
2
0 70 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
4 1
140 0
2
0 71 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
4 1
142 0
2
0 72 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
4 1
144 0
2
0 73 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
4 1
146 0
2
0 74 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
4 1
148 0
2
0 75 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
4 1
150 0
2
0 76 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
4 1
152 0
2
0 77 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
4 1
154 0
2
0 78 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
4 1
156 0
2
0 79 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
4 1
158 0
2
0 80 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
4 1
160 0
2
0 81 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
4 1
162 0
2
0 82 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
4 1
164 0
2
0 83 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
4 1
166 0
2
0 84 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
4 1
168 0
2
0 85 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
4 1
170 0
2
0 86 0 1
0 90 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
5 1
112 0
2
0 57 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
5 1
114 0
2
0 58 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
5 1
116 0
2
0 59 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
5 1
118 0
2
0 60 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
5 1
120 0
2
0 61 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
5 1
122 0
2
0 62 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
5 1
124 0
2
0 63 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
5 1
126 0
2
0 64 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
5 1
128 0
2
0 65 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
5 1
130 0
2
0 66 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
5 1
132 0
2
0 67 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
5 1
134 0
2
0 68 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
5 1
136 0
2
0 69 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
5 1
138 0
2
0 70 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
5 1
140 0
2
0 71 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
5 1
142 0
2
0 72 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
5 1
144 0
2
0 73 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
5 1
146 0
2
0 74 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
5 1
148 0
2
0 75 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
5 1
150 0
2
0 76 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
5 1
152 0
2
0 77 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
5 1
154 0
2
0 78 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
5 1
156 0
2
0 79 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
5 1
158 0
2
0 80 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
5 1
160 0
2
0 81 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
5 1
162 0
2
0 82 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
5 1
164 0
2
0 83 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
5 1
166 0
2
0 84 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
5 1
168 0
2
0 85 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
5 1
170 0
2
0 86 0 1
0 91 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
6 1
112 0
2
0 57 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
6 1
114 0
2
0 58 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
6 1
116 0
2
0 59 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
6 1
118 0
2
0 60 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
6 1
120 0
2
0 61 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
6 1
122 0
2
0 62 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
6 1
124 0
2
0 63 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
6 1
126 0
2
0 64 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
6 1
128 0
2
0 65 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
6 1
130 0
2
0 66 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
6 1
132 0
2
0 67 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
6 1
134 0
2
0 68 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
6 1
136 0
2
0 69 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
6 1
138 0
2
0 70 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
6 1
140 0
2
0 71 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
6 1
142 0
2
0 72 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
6 1
144 0
2
0 73 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
6 1
146 0
2
0 74 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
6 1
148 0
2
0 75 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
6 1
150 0
2
0 76 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
6 1
152 0
2
0 77 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
6 1
154 0
2
0 78 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
6 1
156 0
2
0 79 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
6 1
158 0
2
0 80 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
6 1
160 0
2
0 81 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
6 1
162 0
2
0 82 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
6 1
164 0
2
0 83 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
6 1
166 0
2
0 84 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
6 1
168 0
2
0 85 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
6 1
170 0
2
0 86 0 1
0 92 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
7 1
112 0
2
0 57 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
7 1
114 0
2
0 58 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
7 1
116 0
2
0 59 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
7 1
118 0
2
0 60 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
7 1
120 0
2
0 61 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
7 1
122 0
2
0 62 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
7 1
124 0
2
0 63 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
7 1
126 0
2
0 64 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
7 1
128 0
2
0 65 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
7 1
130 0
2
0 66 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
7 1
132 0
2
0 67 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
7 1
134 0
2
0 68 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
7 1
136 0
2
0 69 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
7 1
138 0
2
0 70 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
7 1
140 0
2
0 71 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
7 1
142 0
2
0 72 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
7 1
144 0
2
0 73 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
7 1
146 0
2
0 74 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
7 1
148 0
2
0 75 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
7 1
150 0
2
0 76 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
7 1
152 0
2
0 77 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
7 1
154 0
2
0 78 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
7 1
156 0
2
0 79 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
7 1
158 0
2
0 80 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
7 1
160 0
2
0 81 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
7 1
162 0
2
0 82 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
7 1
164 0
2
0 83 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
7 1
166 0
2
0 84 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
7 1
168 0
2
0 85 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
7 1
170 0
2
0 86 0 1
0 93 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
8 1
112 0
2
0 57 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
8 1
114 0
2
0 58 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
8 1
116 0
2
0 59 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
8 1
118 0
2
0 60 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
8 1
120 0
2
0 61 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
8 1
122 0
2
0 62 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
8 1
124 0
2
0 63 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
8 1
126 0
2
0 64 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
8 1
128 0
2
0 65 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
8 1
130 0
2
0 66 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
8 1
132 0
2
0 67 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
8 1
134 0
2
0 68 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
8 1
136 0
2
0 69 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
8 1
138 0
2
0 70 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
8 1
140 0
2
0 71 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
8 1
142 0
2
0 72 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
8 1
144 0
2
0 73 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
8 1
146 0
2
0 74 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
8 1
148 0
2
0 75 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
8 1
150 0
2
0 76 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
8 1
152 0
2
0 77 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
8 1
154 0
2
0 78 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
8 1
156 0
2
0 79 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
8 1
158 0
2
0 80 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
8 1
160 0
2
0 81 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
8 1
162 0
2
0 82 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
8 1
164 0
2
0 83 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
8 1
166 0
2
0 84 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
8 1
168 0
2
0 85 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
8 1
170 0
2
0 86 0 1
0 94 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
9 1
112 0
2
0 57 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
9 1
114 0
2
0 58 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
9 1
116 0
2
0 59 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
9 1
118 0
2
0 60 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
9 1
120 0
2
0 61 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
9 1
122 0
2
0 62 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
9 1
124 0
2
0 63 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
9 1
126 0
2
0 64 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
9 1
128 0
2
0 65 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
9 1
130 0
2
0 66 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
9 1
132 0
2
0 67 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
9 1
134 0
2
0 68 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
9 1
136 0
2
0 69 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
9 1
138 0
2
0 70 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
9 1
140 0
2
0 71 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
9 1
142 0
2
0 72 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
9 1
144 0
2
0 73 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
9 1
146 0
2
0 74 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
9 1
148 0
2
0 75 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
9 1
150 0
2
0 76 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
9 1
152 0
2
0 77 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
9 1
154 0
2
0 78 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
9 1
156 0
2
0 79 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
9 1
158 0
2
0 80 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
9 1
160 0
2
0 81 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
9 1
162 0
2
0 82 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
9 1
164 0
2
0 83 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
9 1
166 0
2
0 84 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
9 1
168 0
2
0 85 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
9 1
170 0
2
0 86 0 1
0 95 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
10 1
112 0
2
0 57 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
10 1
114 0
2
0 58 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
10 1
116 0
2
0 59 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
10 1
118 0
2
0 60 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
10 1
120 0
2
0 61 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
10 1
122 0
2
0 62 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
10 1
124 0
2
0 63 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
10 1
126 0
2
0 64 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
10 1
128 0
2
0 65 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
10 1
130 0
2
0 66 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
10 1
132 0
2
0 67 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
10 1
134 0
2
0 68 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
10 1
136 0
2
0 69 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
10 1
138 0
2
0 70 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
10 1
140 0
2
0 71 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
10 1
142 0
2
0 72 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
10 1
144 0
2
0 73 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
10 1
146 0
2
0 74 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
10 1
148 0
2
0 75 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
10 1
150 0
2
0 76 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
10 1
152 0
2
0 77 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
10 1
154 0
2
0 78 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
10 1
156 0
2
0 79 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
10 1
158 0
2
0 80 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
10 1
160 0
2
0 81 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
10 1
162 0
2
0 82 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
10 1
164 0
2
0 83 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
10 1
166 0
2
0 84 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
10 1
168 0
2
0 85 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
10 1
170 0
2
0 86 0 1
0 96 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
11 1
112 0
2
0 57 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
11 1
114 0
2
0 58 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
11 1
116 0
2
0 59 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
11 1
118 0
2
0 60 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
11 1
120 0
2
0 61 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
11 1
122 0
2
0 62 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
11 1
124 0
2
0 63 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
11 1
126 0
2
0 64 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
11 1
128 0
2
0 65 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
11 1
130 0
2
0 66 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
11 1
132 0
2
0 67 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
11 1
134 0
2
0 68 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
11 1
136 0
2
0 69 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
11 1
138 0
2
0 70 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
11 1
140 0
2
0 71 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
11 1
142 0
2
0 72 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
11 1
144 0
2
0 73 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
11 1
146 0
2
0 74 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
11 1
148 0
2
0 75 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
11 1
150 0
2
0 76 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
11 1
152 0
2
0 77 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
11 1
154 0
2
0 78 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
11 1
156 0
2
0 79 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
11 1
158 0
2
0 80 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
11 1
160 0
2
0 81 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
11 1
162 0
2
0 82 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
11 1
164 0
2
0 83 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
11 1
166 0
2
0 84 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
11 1
168 0
2
0 85 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
11 1
170 0
2
0 86 0 1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
12 1
112 0
2
0 57 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
12 1
114 0
2
0 58 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
12 1
116 0
2
0 59 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
12 1
118 0
2
0 60 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
12 1
120 0
2
0 61 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
12 1
122 0
2
0 62 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
12 1
124 0
2
0 63 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
12 1
126 0
2
0 64 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
12 1
128 0
2
0 65 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
12 1
130 0
2
0 66 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
12 1
132 0
2
0 67 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
12 1
134 0
2
0 68 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
12 1
136 0
2
0 69 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
12 1
138 0
2
0 70 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
12 1
140 0
2
0 71 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
12 1
142 0
2
0 72 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
12 1
144 0
2
0 73 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
12 1
146 0
2
0 74 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
12 1
148 0
2
0 75 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
12 1
150 0
2
0 76 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
12 1
152 0
2
0 77 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
12 1
154 0
2
0 78 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
12 1
156 0
2
0 79 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
12 1
158 0
2
0 80 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
12 1
160 0
2
0 81 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
12 1
162 0
2
0 82 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
12 1
164 0
2
0 83 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
12 1
166 0
2
0 84 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
12 1
168 0
2
0 85 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
12 1
170 0
2
0 86 0 1
0 98 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
13 1
112 0
2
0 57 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
13 1
114 0
2
0 58 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
13 1
116 0
2
0 59 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
13 1
118 0
2
0 60 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
13 1
120 0
2
0 61 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
13 1
122 0
2
0 62 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
13 1
124 0
2
0 63 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
13 1
126 0
2
0 64 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
13 1
128 0
2
0 65 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
13 1
130 0
2
0 66 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
13 1
132 0
2
0 67 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
13 1
134 0
2
0 68 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
13 1
136 0
2
0 69 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
13 1
138 0
2
0 70 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
13 1
140 0
2
0 71 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
13 1
142 0
2
0 72 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
13 1
144 0
2
0 73 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
13 1
146 0
2
0 74 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
13 1
148 0
2
0 75 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
13 1
150 0
2
0 76 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
13 1
152 0
2
0 77 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
13 1
154 0
2
0 78 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
13 1
156 0
2
0 79 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
13 1
158 0
2
0 80 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
13 1
160 0
2
0 81 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
13 1
162 0
2
0 82 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
13 1
164 0
2
0 83 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
13 1
166 0
2
0 84 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
13 1
168 0
2
0 85 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
13 1
170 0
2
0 86 0 1
0 99 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
14 1
112 0
2
0 57 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
14 1
114 0
2
0 58 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
14 1
116 0
2
0 59 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
14 1
118 0
2
0 60 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
14 1
120 0
2
0 61 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
14 1
122 0
2
0 62 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
14 1
124 0
2
0 63 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
14 1
126 0
2
0 64 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
14 1
128 0
2
0 65 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
14 1
130 0
2
0 66 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
14 1
132 0
2
0 67 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
14 1
134 0
2
0 68 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
14 1
136 0
2
0 69 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
14 1
138 0
2
0 70 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
14 1
140 0
2
0 71 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
14 1
142 0
2
0 72 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
14 1
144 0
2
0 73 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
14 1
146 0
2
0 74 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
14 1
148 0
2
0 75 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
14 1
150 0
2
0 76 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
14 1
152 0
2
0 77 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
14 1
154 0
2
0 78 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
14 1
156 0
2
0 79 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
14 1
158 0
2
0 80 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
14 1
160 0
2
0 81 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
14 1
162 0
2
0 82 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
14 1
164 0
2
0 83 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
14 1
166 0
2
0 84 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
14 1
168 0
2
0 85 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
14 1
170 0
2
0 86 0 1
0 100 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
15 1
112 0
2
0 57 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
15 1
114 0
2
0 58 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
15 1
116 0
2
0 59 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
15 1
118 0
2
0 60 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
15 1
120 0
2
0 61 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
15 1
122 0
2
0 62 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
15 1
124 0
2
0 63 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
15 1
126 0
2
0 64 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
15 1
128 0
2
0 65 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
15 1
130 0
2
0 66 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
15 1
132 0
2
0 67 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
15 1
134 0
2
0 68 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
15 1
136 0
2
0 69 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
15 1
138 0
2
0 70 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
15 1
140 0
2
0 71 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
15 1
142 0
2
0 72 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
15 1
144 0
2
0 73 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
15 1
146 0
2
0 74 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
15 1
148 0
2
0 75 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
15 1
150 0
2
0 76 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
15 1
152 0
2
0 77 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
15 1
154 0
2
0 78 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
15 1
156 0
2
0 79 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
15 1
158 0
2
0 80 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
15 1
160 0
2
0 81 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
15 1
162 0
2
0 82 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
15 1
164 0
2
0 83 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
15 1
166 0
2
0 84 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
15 1
168 0
2
0 85 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
15 1
170 0
2
0 86 0 1
0 101 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
16 1
112 0
2
0 57 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
16 1
114 0
2
0 58 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
16 1
116 0
2
0 59 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
16 1
118 0
2
0 60 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
16 1
120 0
2
0 61 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
16 1
122 0
2
0 62 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
16 1
124 0
2
0 63 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
16 1
126 0
2
0 64 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
16 1
128 0
2
0 65 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
16 1
130 0
2
0 66 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
16 1
132 0
2
0 67 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
16 1
134 0
2
0 68 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
16 1
136 0
2
0 69 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
16 1
138 0
2
0 70 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
16 1
140 0
2
0 71 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
16 1
142 0
2
0 72 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
16 1
144 0
2
0 73 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
16 1
146 0
2
0 74 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
16 1
148 0
2
0 75 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
16 1
150 0
2
0 76 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
16 1
152 0
2
0 77 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
16 1
154 0
2
0 78 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
16 1
156 0
2
0 79 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
16 1
158 0
2
0 80 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
16 1
160 0
2
0 81 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
16 1
162 0
2
0 82 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
16 1
164 0
2
0 83 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
16 1
166 0
2
0 84 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
16 1
168 0
2
0 85 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
16 1
170 0
2
0 86 0 1
0 102 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
17 1
112 0
2
0 57 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
17 1
114 0
2
0 58 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
17 1
116 0
2
0 59 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
17 1
118 0
2
0 60 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
17 1
120 0
2
0 61 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
17 1
122 0
2
0 62 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
17 1
124 0
2
0 63 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
17 1
126 0
2
0 64 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
17 1
128 0
2
0 65 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
17 1
130 0
2
0 66 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
17 1
132 0
2
0 67 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
17 1
134 0
2
0 68 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
17 1
136 0
2
0 69 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
17 1
138 0
2
0 70 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
17 1
140 0
2
0 71 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
17 1
142 0
2
0 72 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
17 1
144 0
2
0 73 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
17 1
146 0
2
0 74 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
17 1
148 0
2
0 75 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
17 1
150 0
2
0 76 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
17 1
152 0
2
0 77 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
17 1
154 0
2
0 78 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
17 1
156 0
2
0 79 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
17 1
158 0
2
0 80 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
17 1
160 0
2
0 81 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
17 1
162 0
2
0 82 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
17 1
164 0
2
0 83 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
17 1
166 0
2
0 84 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
17 1
168 0
2
0 85 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
17 1
170 0
2
0 86 0 1
0 103 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
18 1
112 0
2
0 57 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
18 1
114 0
2
0 58 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
18 1
116 0
2
0 59 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
18 1
118 0
2
0 60 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
18 1
120 0
2
0 61 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
18 1
122 0
2
0 62 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
18 1
124 0
2
0 63 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
18 1
126 0
2
0 64 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
18 1
128 0
2
0 65 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
18 1
130 0
2
0 66 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
18 1
132 0
2
0 67 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
18 1
134 0
2
0 68 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
18 1
136 0
2
0 69 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
18 1
138 0
2
0 70 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
18 1
140 0
2
0 71 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
18 1
142 0
2
0 72 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
18 1
144 0
2
0 73 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
18 1
146 0
2
0 74 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
18 1
148 0
2
0 75 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
18 1
150 0
2
0 76 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
18 1
152 0
2
0 77 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
18 1
154 0
2
0 78 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
18 1
156 0
2
0 79 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
18 1
158 0
2
0 80 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
18 1
160 0
2
0 81 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
18 1
162 0
2
0 82 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
18 1
164 0
2
0 83 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
18 1
166 0
2
0 84 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
18 1
168 0
2
0 85 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
18 1
170 0
2
0 86 0 1
0 104 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
19 1
112 0
2
0 57 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
19 1
114 0
2
0 58 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
19 1
116 0
2
0 59 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
19 1
118 0
2
0 60 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
19 1
120 0
2
0 61 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
19 1
122 0
2
0 62 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
19 1
124 0
2
0 63 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
19 1
126 0
2
0 64 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
19 1
128 0
2
0 65 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
19 1
130 0
2
0 66 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
19 1
132 0
2
0 67 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
19 1
134 0
2
0 68 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
19 1
136 0
2
0 69 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
19 1
138 0
2
0 70 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
19 1
140 0
2
0 71 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
19 1
142 0
2
0 72 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
19 1
144 0
2
0 73 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
19 1
146 0
2
0 74 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
19 1
148 0
2
0 75 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
19 1
150 0
2
0 76 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
19 1
152 0
2
0 77 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
19 1
154 0
2
0 78 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
19 1
156 0
2
0 79 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
19 1
158 0
2
0 80 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
19 1
160 0
2
0 81 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
19 1
162 0
2
0 82 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
19 1
164 0
2
0 83 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
19 1
166 0
2
0 84 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
19 1
168 0
2
0 85 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
19 1
170 0
2
0 86 0 1
0 105 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
20 1
112 0
2
0 57 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
20 1
114 0
2
0 58 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
20 1
116 0
2
0 59 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
20 1
118 0
2
0 60 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
20 1
120 0
2
0 61 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
20 1
122 0
2
0 62 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
20 1
124 0
2
0 63 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
20 1
126 0
2
0 64 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
20 1
128 0
2
0 65 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
20 1
130 0
2
0 66 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
20 1
132 0
2
0 67 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
20 1
134 0
2
0 68 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
20 1
136 0
2
0 69 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
20 1
138 0
2
0 70 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
20 1
140 0
2
0 71 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
20 1
142 0
2
0 72 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
20 1
144 0
2
0 73 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
20 1
146 0
2
0 74 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
20 1
148 0
2
0 75 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
20 1
150 0
2
0 76 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
20 1
152 0
2
0 77 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
20 1
154 0
2
0 78 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
20 1
156 0
2
0 79 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
20 1
158 0
2
0 80 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
20 1
160 0
2
0 81 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
20 1
162 0
2
0 82 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
20 1
164 0
2
0 83 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
20 1
166 0
2
0 84 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
20 1
168 0
2
0 85 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
20 1
170 0
2
0 86 0 1
0 106 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
21 1
112 0
2
0 57 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
21 1
114 0
2
0 58 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
21 1
116 0
2
0 59 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
21 1
118 0
2
0 60 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
21 1
120 0
2
0 61 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
21 1
122 0
2
0 62 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
21 1
124 0
2
0 63 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
21 1
126 0
2
0 64 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
21 1
128 0
2
0 65 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
21 1
130 0
2
0 66 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
21 1
132 0
2
0 67 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
21 1
134 0
2
0 68 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
21 1
136 0
2
0 69 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
21 1
138 0
2
0 70 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
21 1
140 0
2
0 71 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
21 1
142 0
2
0 72 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
21 1
144 0
2
0 73 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
21 1
146 0
2
0 74 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
21 1
148 0
2
0 75 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
21 1
150 0
2
0 76 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
21 1
152 0
2
0 77 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
21 1
154 0
2
0 78 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
21 1
156 0
2
0 79 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
21 1
158 0
2
0 80 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
21 1
160 0
2
0 81 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
21 1
162 0
2
0 82 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
21 1
164 0
2
0 83 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
21 1
166 0
2
0 84 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
21 1
168 0
2
0 85 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
21 1
170 0
2
0 86 0 1
0 107 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
22 1
112 0
2
0 57 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
22 1
114 0
2
0 58 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
22 1
116 0
2
0 59 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
22 1
118 0
2
0 60 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
22 1
120 0
2
0 61 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
22 1
122 0
2
0 62 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
22 1
124 0
2
0 63 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
22 1
126 0
2
0 64 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
22 1
128 0
2
0 65 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
22 1
130 0
2
0 66 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
22 1
132 0
2
0 67 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
22 1
134 0
2
0 68 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
22 1
136 0
2
0 69 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
22 1
138 0
2
0 70 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
22 1
140 0
2
0 71 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
22 1
142 0
2
0 72 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
22 1
144 0
2
0 73 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
22 1
146 0
2
0 74 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
22 1
148 0
2
0 75 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
22 1
150 0
2
0 76 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
22 1
152 0
2
0 77 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
22 1
154 0
2
0 78 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
22 1
156 0
2
0 79 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
22 1
158 0
2
0 80 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
22 1
160 0
2
0 81 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
22 1
162 0
2
0 82 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
22 1
164 0
2
0 83 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
22 1
166 0
2
0 84 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
22 1
168 0
2
0 85 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
22 1
170 0
2
0 86 0 1
0 108 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
23 1
112 0
2
0 57 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
23 1
114 0
2
0 58 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
23 1
116 0
2
0 59 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
23 1
118 0
2
0 60 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
23 1
120 0
2
0 61 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
23 1
122 0
2
0 62 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
23 1
124 0
2
0 63 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
23 1
126 0
2
0 64 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
23 1
128 0
2
0 65 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
23 1
130 0
2
0 66 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
23 1
132 0
2
0 67 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
23 1
134 0
2
0 68 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
23 1
136 0
2
0 69 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
23 1
138 0
2
0 70 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
23 1
140 0
2
0 71 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
23 1
142 0
2
0 72 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
23 1
144 0
2
0 73 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
23 1
146 0
2
0 74 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
23 1
148 0
2
0 75 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
23 1
150 0
2
0 76 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
23 1
152 0
2
0 77 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
23 1
154 0
2
0 78 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
23 1
156 0
2
0 79 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
23 1
158 0
2
0 80 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
23 1
160 0
2
0 81 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
23 1
162 0
2
0 82 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
23 1
164 0
2
0 83 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
23 1
166 0
2
0 84 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
23 1
168 0
2
0 85 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
23 1
170 0
2
0 86 0 1
0 109 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
24 1
112 0
2
0 57 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
24 1
114 0
2
0 58 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
24 1
116 0
2
0 59 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
24 1
118 0
2
0 60 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
24 1
120 0
2
0 61 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
24 1
122 0
2
0 62 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
24 1
124 0
2
0 63 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
24 1
126 0
2
0 64 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
24 1
128 0
2
0 65 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
24 1
130 0
2
0 66 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
24 1
132 0
2
0 67 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
24 1
134 0
2
0 68 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
24 1
136 0
2
0 69 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
24 1
138 0
2
0 70 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
24 1
140 0
2
0 71 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
24 1
142 0
2
0 72 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
24 1
144 0
2
0 73 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
24 1
146 0
2
0 74 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
24 1
148 0
2
0 75 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
24 1
150 0
2
0 76 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
24 1
152 0
2
0 77 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
24 1
154 0
2
0 78 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
24 1
156 0
2
0 79 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
24 1
158 0
2
0 80 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
24 1
160 0
2
0 81 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
24 1
162 0
2
0 82 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
24 1
164 0
2
0 83 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
24 1
166 0
2
0 84 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
24 1
168 0
2
0 85 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
24 1
170 0
2
0 86 0 1
0 110 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
25 1
112 0
2
0 57 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
25 1
114 0
2
0 58 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
25 1
116 0
2
0 59 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
25 1
118 0
2
0 60 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
25 1
120 0
2
0 61 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
25 1
122 0
2
0 62 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
25 1
124 0
2
0 63 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
25 1
126 0
2
0 64 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
25 1
128 0
2
0 65 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
25 1
130 0
2
0 66 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
25 1
132 0
2
0 67 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
25 1
134 0
2
0 68 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
25 1
136 0
2
0 69 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
25 1
138 0
2
0 70 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
25 1
140 0
2
0 71 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
25 1
142 0
2
0 72 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
25 1
144 0
2
0 73 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
25 1
146 0
2
0 74 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
25 1
148 0
2
0 75 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
25 1
150 0
2
0 76 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
25 1
152 0
2
0 77 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
25 1
154 0
2
0 78 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
25 1
156 0
2
0 79 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
25 1
158 0
2
0 80 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
25 1
160 0
2
0 81 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
25 1
162 0
2
0 82 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
25 1
164 0
2
0 83 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
25 1
166 0
2
0 84 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
25 1
168 0
2
0 85 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
25 1
170 0
2
0 86 0 1
0 111 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
26 1
112 0
2
0 57 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
26 1
114 0
2
0 58 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
26 1
116 0
2
0 59 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
26 1
118 0
2
0 60 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
26 1
120 0
2
0 61 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
26 1
122 0
2
0 62 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
26 1
124 0
2
0 63 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
26 1
126 0
2
0 64 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
26 1
128 0
2
0 65 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
26 1
130 0
2
0 66 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
26 1
132 0
2
0 67 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
26 1
134 0
2
0 68 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
26 1
136 0
2
0 69 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
26 1
138 0
2
0 70 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
26 1
140 0
2
0 71 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
26 1
142 0
2
0 72 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
26 1
144 0
2
0 73 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
26 1
146 0
2
0 74 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
26 1
148 0
2
0 75 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
26 1
150 0
2
0 76 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
26 1
152 0
2
0 77 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
26 1
154 0
2
0 78 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
26 1
156 0
2
0 79 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
26 1
158 0
2
0 80 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
26 1
160 0
2
0 81 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
26 1
162 0
2
0 82 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
26 1
164 0
2
0 83 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
26 1
166 0
2
0 84 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
26 1
168 0
2
0 85 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
26 1
170 0
2
0 86 0 1
0 113 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
27 1
112 0
2
0 57 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
27 1
114 0
2
0 58 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
27 1
116 0
2
0 59 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
27 1
118 0
2
0 60 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
27 1
120 0
2
0 61 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
27 1
122 0
2
0 62 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
27 1
124 0
2
0 63 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
27 1
126 0
2
0 64 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
27 1
128 0
2
0 65 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
27 1
130 0
2
0 66 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
27 1
132 0
2
0 67 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
27 1
134 0
2
0 68 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
27 1
136 0
2
0 69 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
27 1
138 0
2
0 70 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
27 1
140 0
2
0 71 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
27 1
142 0
2
0 72 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
27 1
144 0
2
0 73 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
27 1
146 0
2
0 74 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
27 1
148 0
2
0 75 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
27 1
150 0
2
0 76 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
27 1
152 0
2
0 77 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
27 1
154 0
2
0 78 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
27 1
156 0
2
0 79 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
27 1
158 0
2
0 80 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
27 1
160 0
2
0 81 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
27 1
162 0
2
0 82 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
27 1
164 0
2
0 83 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
27 1
166 0
2
0 84 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
27 1
168 0
2
0 85 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
27 1
170 0
2
0 86 0 1
0 115 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
28 1
112 0
2
0 57 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
28 1
114 0
2
0 58 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
28 1
116 0
2
0 59 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
28 1
118 0
2
0 60 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
28 1
120 0
2
0 61 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
28 1
122 0
2
0 62 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
28 1
124 0
2
0 63 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
28 1
126 0
2
0 64 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
28 1
128 0
2
0 65 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
28 1
130 0
2
0 66 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
28 1
132 0
2
0 67 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
28 1
134 0
2
0 68 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
28 1
136 0
2
0 69 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
28 1
138 0
2
0 70 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
28 1
140 0
2
0 71 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
28 1
142 0
2
0 72 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
28 1
144 0
2
0 73 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
28 1
146 0
2
0 74 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
28 1
148 0
2
0 75 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
28 1
150 0
2
0 76 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
28 1
152 0
2
0 77 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
28 1
154 0
2
0 78 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
28 1
156 0
2
0 79 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
28 1
158 0
2
0 80 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
28 1
160 0
2
0 81 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
28 1
162 0
2
0 82 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
28 1
164 0
2
0 83 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
28 1
166 0
2
0 84 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
28 1
168 0
2
0 85 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
28 1
170 0
2
0 86 0 1
0 117 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
29 1
112 0
2
0 57 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
29 1
114 0
2
0 58 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
29 1
116 0
2
0 59 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
29 1
118 0
2
0 60 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
29 1
120 0
2
0 61 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
29 1
122 0
2
0 62 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
29 1
124 0
2
0 63 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
29 1
126 0
2
0 64 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
29 1
128 0
2
0 65 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
29 1
130 0
2
0 66 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
29 1
132 0
2
0 67 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
29 1
134 0
2
0 68 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
29 1
136 0
2
0 69 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
29 1
138 0
2
0 70 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
29 1
140 0
2
0 71 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
29 1
142 0
2
0 72 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
29 1
144 0
2
0 73 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
29 1
146 0
2
0 74 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
29 1
148 0
2
0 75 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
29 1
150 0
2
0 76 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
29 1
152 0
2
0 77 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
29 1
154 0
2
0 78 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
29 1
156 0
2
0 79 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
29 1
158 0
2
0 80 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
29 1
160 0
2
0 81 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
29 1
162 0
2
0 82 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
29 1
164 0
2
0 83 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
29 1
166 0
2
0 84 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
29 1
168 0
2
0 85 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
29 1
170 0
2
0 86 0 1
0 119 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
30 1
112 0
2
0 57 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
30 1
114 0
2
0 58 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
30 1
116 0
2
0 59 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
30 1
118 0
2
0 60 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
30 1
120 0
2
0 61 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
30 1
122 0
2
0 62 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
30 1
124 0
2
0 63 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
30 1
126 0
2
0 64 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
30 1
128 0
2
0 65 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
30 1
130 0
2
0 66 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
30 1
132 0
2
0 67 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
30 1
134 0
2
0 68 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
30 1
136 0
2
0 69 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
30 1
138 0
2
0 70 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
30 1
140 0
2
0 71 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
30 1
142 0
2
0 72 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
30 1
144 0
2
0 73 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
30 1
146 0
2
0 74 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
30 1
148 0
2
0 75 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
30 1
150 0
2
0 76 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
30 1
152 0
2
0 77 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
30 1
154 0
2
0 78 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
30 1
156 0
2
0 79 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
30 1
158 0
2
0 80 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
30 1
160 0
2
0 81 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
30 1
162 0
2
0 82 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
30 1
164 0
2
0 83 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
30 1
166 0
2
0 84 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
30 1
168 0
2
0 85 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
30 1
170 0
2
0 86 0 1
0 121 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
31 1
112 0
2
0 57 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
31 1
114 0
2
0 58 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
31 1
116 0
2
0 59 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
31 1
118 0
2
0 60 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
31 1
120 0
2
0 61 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
31 1
122 0
2
0 62 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
31 1
124 0
2
0 63 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
31 1
126 0
2
0 64 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
31 1
128 0
2
0 65 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
31 1
130 0
2
0 66 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
31 1
132 0
2
0 67 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
31 1
134 0
2
0 68 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
31 1
136 0
2
0 69 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
31 1
138 0
2
0 70 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
31 1
140 0
2
0 71 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
31 1
142 0
2
0 72 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
31 1
144 0
2
0 73 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
31 1
146 0
2
0 74 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
31 1
148 0
2
0 75 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
31 1
150 0
2
0 76 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
31 1
152 0
2
0 77 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
31 1
154 0
2
0 78 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
31 1
156 0
2
0 79 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
31 1
158 0
2
0 80 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
31 1
160 0
2
0 81 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
31 1
162 0
2
0 82 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
31 1
164 0
2
0 83 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
31 1
166 0
2
0 84 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
31 1
168 0
2
0 85 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
31 1
170 0
2
0 86 0 1
0 123 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
32 1
112 0
2
0 57 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
32 1
114 0
2
0 58 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
32 1
116 0
2
0 59 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
32 1
118 0
2
0 60 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
32 1
120 0
2
0 61 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
32 1
122 0
2
0 62 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
32 1
124 0
2
0 63 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
32 1
126 0
2
0 64 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
32 1
128 0
2
0 65 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
32 1
130 0
2
0 66 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
32 1
132 0
2
0 67 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
32 1
134 0
2
0 68 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
32 1
136 0
2
0 69 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
32 1
138 0
2
0 70 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
32 1
140 0
2
0 71 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
32 1
142 0
2
0 72 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
32 1
144 0
2
0 73 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
32 1
146 0
2
0 74 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
32 1
148 0
2
0 75 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
32 1
150 0
2
0 76 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
32 1
152 0
2
0 77 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
32 1
154 0
2
0 78 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
32 1
156 0
2
0 79 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
32 1
158 0
2
0 80 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
32 1
160 0
2
0 81 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
32 1
162 0
2
0 82 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
32 1
164 0
2
0 83 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
32 1
166 0
2
0 84 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
32 1
168 0
2
0 85 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
32 1
170 0
2
0 86 0 1
0 125 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
33 1
112 0
2
0 57 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
33 1
114 0
2
0 58 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
33 1
116 0
2
0 59 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
33 1
118 0
2
0 60 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
33 1
120 0
2
0 61 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
33 1
122 0
2
0 62 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
33 1
124 0
2
0 63 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
33 1
126 0
2
0 64 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
33 1
128 0
2
0 65 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
33 1
130 0
2
0 66 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
33 1
132 0
2
0 67 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
33 1
134 0
2
0 68 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
33 1
136 0
2
0 69 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
33 1
138 0
2
0 70 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
33 1
140 0
2
0 71 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
33 1
142 0
2
0 72 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
33 1
144 0
2
0 73 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
33 1
146 0
2
0 74 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
33 1
148 0
2
0 75 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
33 1
150 0
2
0 76 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
33 1
152 0
2
0 77 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
33 1
154 0
2
0 78 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
33 1
156 0
2
0 79 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
33 1
158 0
2
0 80 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
33 1
160 0
2
0 81 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
33 1
162 0
2
0 82 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
33 1
164 0
2
0 83 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
33 1
166 0
2
0 84 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
33 1
168 0
2
0 85 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
33 1
170 0
2
0 86 0 1
0 127 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
34 1
112 0
2
0 57 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
34 1
114 0
2
0 58 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
34 1
116 0
2
0 59 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
34 1
118 0
2
0 60 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
34 1
120 0
2
0 61 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
34 1
122 0
2
0 62 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
34 1
124 0
2
0 63 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
34 1
126 0
2
0 64 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
34 1
128 0
2
0 65 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
34 1
130 0
2
0 66 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
34 1
132 0
2
0 67 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
34 1
134 0
2
0 68 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
34 1
136 0
2
0 69 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
34 1
138 0
2
0 70 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
34 1
140 0
2
0 71 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
34 1
142 0
2
0 72 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
34 1
144 0
2
0 73 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
34 1
146 0
2
0 74 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
34 1
148 0
2
0 75 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
34 1
150 0
2
0 76 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
34 1
152 0
2
0 77 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
34 1
154 0
2
0 78 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
34 1
156 0
2
0 79 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
34 1
158 0
2
0 80 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
34 1
160 0
2
0 81 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
34 1
162 0
2
0 82 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
34 1
164 0
2
0 83 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
34 1
166 0
2
0 84 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
34 1
168 0
2
0 85 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
34 1
170 0
2
0 86 0 1
0 129 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
35 1
112 0
2
0 57 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
35 1
114 0
2
0 58 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
35 1
116 0
2
0 59 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
35 1
118 0
2
0 60 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
35 1
120 0
2
0 61 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
35 1
122 0
2
0 62 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
35 1
124 0
2
0 63 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
35 1
126 0
2
0 64 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
35 1
128 0
2
0 65 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
35 1
130 0
2
0 66 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
35 1
132 0
2
0 67 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
35 1
134 0
2
0 68 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
35 1
136 0
2
0 69 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
35 1
138 0
2
0 70 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
35 1
140 0
2
0 71 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
35 1
142 0
2
0 72 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
35 1
144 0
2
0 73 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
35 1
146 0
2
0 74 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
35 1
148 0
2
0 75 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
35 1
150 0
2
0 76 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
35 1
152 0
2
0 77 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
35 1
154 0
2
0 78 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
35 1
156 0
2
0 79 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
35 1
158 0
2
0 80 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
35 1
160 0
2
0 81 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
35 1
162 0
2
0 82 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
35 1
164 0
2
0 83 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
35 1
166 0
2
0 84 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
35 1
168 0
2
0 85 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
35 1
170 0
2
0 86 0 1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
36 1
112 0
2
0 57 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
36 1
114 0
2
0 58 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
36 1
116 0
2
0 59 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
36 1
118 0
2
0 60 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
36 1
120 0
2
0 61 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
36 1
122 0
2
0 62 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
36 1
124 0
2
0 63 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
36 1
126 0
2
0 64 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
36 1
128 0
2
0 65 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
36 1
130 0
2
0 66 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
36 1
132 0
2
0 67 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
36 1
134 0
2
0 68 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
36 1
136 0
2
0 69 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
36 1
138 0
2
0 70 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
36 1
140 0
2
0 71 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
36 1
142 0
2
0 72 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
36 1
144 0
2
0 73 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
36 1
146 0
2
0 74 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
36 1
148 0
2
0 75 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
36 1
150 0
2
0 76 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
36 1
152 0
2
0 77 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
36 1
154 0
2
0 78 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
36 1
156 0
2
0 79 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
36 1
158 0
2
0 80 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
36 1
160 0
2
0 81 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
36 1
162 0
2
0 82 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
36 1
164 0
2
0 83 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
36 1
166 0
2
0 84 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
36 1
168 0
2
0 85 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
36 1
170 0
2
0 86 0 1
0 133 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
37 1
112 0
2
0 57 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
37 1
114 0
2
0 58 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
37 1
116 0
2
0 59 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
37 1
118 0
2
0 60 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
37 1
120 0
2
0 61 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
37 1
122 0
2
0 62 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
37 1
124 0
2
0 63 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
37 1
126 0
2
0 64 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
37 1
128 0
2
0 65 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
37 1
130 0
2
0 66 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
37 1
132 0
2
0 67 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
37 1
134 0
2
0 68 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
37 1
136 0
2
0 69 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
37 1
138 0
2
0 70 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
37 1
140 0
2
0 71 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
37 1
142 0
2
0 72 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
37 1
144 0
2
0 73 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
37 1
146 0
2
0 74 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
37 1
148 0
2
0 75 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
37 1
150 0
2
0 76 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
37 1
152 0
2
0 77 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
37 1
154 0
2
0 78 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
37 1
156 0
2
0 79 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
37 1
158 0
2
0 80 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
37 1
160 0
2
0 81 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
37 1
162 0
2
0 82 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
37 1
164 0
2
0 83 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
37 1
166 0
2
0 84 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
37 1
168 0
2
0 85 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
37 1
170 0
2
0 86 0 1
0 135 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
38 1
112 0
2
0 57 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
38 1
114 0
2
0 58 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
38 1
116 0
2
0 59 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
38 1
118 0
2
0 60 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
38 1
120 0
2
0 61 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
38 1
122 0
2
0 62 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
38 1
124 0
2
0 63 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
38 1
126 0
2
0 64 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
38 1
128 0
2
0 65 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
38 1
130 0
2
0 66 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
38 1
132 0
2
0 67 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
38 1
134 0
2
0 68 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
38 1
136 0
2
0 69 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
38 1
138 0
2
0 70 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
38 1
140 0
2
0 71 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
38 1
142 0
2
0 72 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
38 1
144 0
2
0 73 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
38 1
146 0
2
0 74 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
38 1
148 0
2
0 75 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
38 1
150 0
2
0 76 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
38 1
152 0
2
0 77 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
38 1
154 0
2
0 78 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
38 1
156 0
2
0 79 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
38 1
158 0
2
0 80 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
38 1
160 0
2
0 81 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
38 1
162 0
2
0 82 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
38 1
164 0
2
0 83 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
38 1
166 0
2
0 84 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
38 1
168 0
2
0 85 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
38 1
170 0
2
0 86 0 1
0 137 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
39 1
112 0
2
0 57 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
39 1
114 0
2
0 58 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
39 1
116 0
2
0 59 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
39 1
118 0
2
0 60 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
39 1
120 0
2
0 61 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
39 1
122 0
2
0 62 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
39 1
124 0
2
0 63 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
39 1
126 0
2
0 64 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
39 1
128 0
2
0 65 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
39 1
130 0
2
0 66 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
39 1
132 0
2
0 67 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
39 1
134 0
2
0 68 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
39 1
136 0
2
0 69 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
39 1
138 0
2
0 70 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
39 1
140 0
2
0 71 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
39 1
142 0
2
0 72 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
39 1
144 0
2
0 73 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
39 1
146 0
2
0 74 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
39 1
148 0
2
0 75 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
39 1
150 0
2
0 76 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
39 1
152 0
2
0 77 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
39 1
154 0
2
0 78 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
39 1
156 0
2
0 79 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
39 1
158 0
2
0 80 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
39 1
160 0
2
0 81 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
39 1
162 0
2
0 82 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
39 1
164 0
2
0 83 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
39 1
166 0
2
0 84 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
39 1
168 0
2
0 85 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
39 1
170 0
2
0 86 0 1
0 139 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
40 1
112 0
2
0 57 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
40 1
114 0
2
0 58 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
40 1
116 0
2
0 59 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
40 1
118 0
2
0 60 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
40 1
120 0
2
0 61 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
40 1
122 0
2
0 62 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
40 1
124 0
2
0 63 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
40 1
126 0
2
0 64 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
40 1
128 0
2
0 65 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
40 1
130 0
2
0 66 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
40 1
132 0
2
0 67 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
40 1
134 0
2
0 68 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
40 1
136 0
2
0 69 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
40 1
138 0
2
0 70 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
40 1
140 0
2
0 71 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
40 1
142 0
2
0 72 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
40 1
144 0
2
0 73 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
40 1
146 0
2
0 74 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
40 1
148 0
2
0 75 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
40 1
150 0
2
0 76 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
40 1
152 0
2
0 77 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
40 1
154 0
2
0 78 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
40 1
156 0
2
0 79 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
40 1
158 0
2
0 80 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
40 1
160 0
2
0 81 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
40 1
162 0
2
0 82 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
40 1
164 0
2
0 83 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
40 1
166 0
2
0 84 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
40 1
168 0
2
0 85 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
40 1
170 0
2
0 86 0 1
0 141 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
41 1
112 0
2
0 57 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
41 1
114 0
2
0 58 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
41 1
116 0
2
0 59 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
41 1
118 0
2
0 60 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
41 1
120 0
2
0 61 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
41 1
122 0
2
0 62 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
41 1
124 0
2
0 63 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
41 1
126 0
2
0 64 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
41 1
128 0
2
0 65 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
41 1
130 0
2
0 66 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
41 1
132 0
2
0 67 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
41 1
134 0
2
0 68 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
41 1
136 0
2
0 69 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
41 1
138 0
2
0 70 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
41 1
140 0
2
0 71 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
41 1
142 0
2
0 72 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
41 1
144 0
2
0 73 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
41 1
146 0
2
0 74 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
41 1
148 0
2
0 75 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
41 1
150 0
2
0 76 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
41 1
152 0
2
0 77 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
41 1
154 0
2
0 78 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
41 1
156 0
2
0 79 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
41 1
158 0
2
0 80 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
41 1
160 0
2
0 81 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
41 1
162 0
2
0 82 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
41 1
164 0
2
0 83 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
41 1
166 0
2
0 84 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
41 1
168 0
2
0 85 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
41 1
170 0
2
0 86 0 1
0 143 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
42 1
112 0
2
0 57 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
42 1
114 0
2
0 58 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
42 1
116 0
2
0 59 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
42 1
118 0
2
0 60 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
42 1
120 0
2
0 61 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
42 1
122 0
2
0 62 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
42 1
124 0
2
0 63 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
42 1
126 0
2
0 64 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
42 1
128 0
2
0 65 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
42 1
130 0
2
0 66 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
42 1
132 0
2
0 67 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
42 1
134 0
2
0 68 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
42 1
136 0
2
0 69 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
42 1
138 0
2
0 70 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
42 1
140 0
2
0 71 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
42 1
142 0
2
0 72 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
42 1
144 0
2
0 73 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
42 1
146 0
2
0 74 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
42 1
148 0
2
0 75 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
42 1
150 0
2
0 76 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
42 1
152 0
2
0 77 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
42 1
154 0
2
0 78 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
42 1
156 0
2
0 79 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
42 1
158 0
2
0 80 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
42 1
160 0
2
0 81 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
42 1
162 0
2
0 82 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
42 1
164 0
2
0 83 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
42 1
166 0
2
0 84 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
42 1
168 0
2
0 85 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
42 1
170 0
2
0 86 0 1
0 145 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
43 1
112 0
2
0 57 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
43 1
114 0
2
0 58 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
43 1
116 0
2
0 59 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
43 1
118 0
2
0 60 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
43 1
120 0
2
0 61 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
43 1
122 0
2
0 62 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
43 1
124 0
2
0 63 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
43 1
126 0
2
0 64 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
43 1
128 0
2
0 65 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
43 1
130 0
2
0 66 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
43 1
132 0
2
0 67 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
43 1
134 0
2
0 68 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
43 1
136 0
2
0 69 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
43 1
138 0
2
0 70 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
43 1
140 0
2
0 71 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
43 1
142 0
2
0 72 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
43 1
144 0
2
0 73 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
43 1
146 0
2
0 74 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
43 1
148 0
2
0 75 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
43 1
150 0
2
0 76 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
43 1
152 0
2
0 77 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
43 1
154 0
2
0 78 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
43 1
156 0
2
0 79 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
43 1
158 0
2
0 80 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
43 1
160 0
2
0 81 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
43 1
162 0
2
0 82 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
43 1
164 0
2
0 83 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
43 1
166 0
2
0 84 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
43 1
168 0
2
0 85 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
43 1
170 0
2
0 86 0 1
0 147 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
44 1
112 0
2
0 57 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
44 1
114 0
2
0 58 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
44 1
116 0
2
0 59 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
44 1
118 0
2
0 60 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
44 1
120 0
2
0 61 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
44 1
122 0
2
0 62 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
44 1
124 0
2
0 63 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
44 1
126 0
2
0 64 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
44 1
128 0
2
0 65 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
44 1
130 0
2
0 66 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
44 1
132 0
2
0 67 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
44 1
134 0
2
0 68 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
44 1
136 0
2
0 69 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
44 1
138 0
2
0 70 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
44 1
140 0
2
0 71 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
44 1
142 0
2
0 72 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
44 1
144 0
2
0 73 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
44 1
146 0
2
0 74 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
44 1
148 0
2
0 75 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
44 1
150 0
2
0 76 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
44 1
152 0
2
0 77 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
44 1
154 0
2
0 78 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
44 1
156 0
2
0 79 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
44 1
158 0
2
0 80 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
44 1
160 0
2
0 81 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
44 1
162 0
2
0 82 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
44 1
164 0
2
0 83 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
44 1
166 0
2
0 84 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
44 1
168 0
2
0 85 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
44 1
170 0
2
0 86 0 1
0 149 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
45 1
112 0
2
0 57 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
45 1
114 0
2
0 58 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
45 1
116 0
2
0 59 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
45 1
118 0
2
0 60 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
45 1
120 0
2
0 61 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
45 1
122 0
2
0 62 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
45 1
124 0
2
0 63 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
45 1
126 0
2
0 64 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
45 1
128 0
2
0 65 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
45 1
130 0
2
0 66 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
45 1
132 0
2
0 67 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
45 1
134 0
2
0 68 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
45 1
136 0
2
0 69 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
45 1
138 0
2
0 70 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
45 1
140 0
2
0 71 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
45 1
142 0
2
0 72 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
45 1
144 0
2
0 73 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
45 1
146 0
2
0 74 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
45 1
148 0
2
0 75 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
45 1
150 0
2
0 76 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
45 1
152 0
2
0 77 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
45 1
154 0
2
0 78 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
45 1
156 0
2
0 79 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
45 1
158 0
2
0 80 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
45 1
160 0
2
0 81 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
45 1
162 0
2
0 82 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
45 1
164 0
2
0 83 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
45 1
166 0
2
0 84 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
45 1
168 0
2
0 85 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
45 1
170 0
2
0 86 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
46 1
112 0
2
0 57 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
46 1
114 0
2
0 58 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
46 1
116 0
2
0 59 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
46 1
118 0
2
0 60 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
46 1
120 0
2
0 61 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
46 1
122 0
2
0 62 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
46 1
124 0
2
0 63 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
46 1
126 0
2
0 64 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
46 1
128 0
2
0 65 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
46 1
130 0
2
0 66 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
46 1
132 0
2
0 67 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
46 1
134 0
2
0 68 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
46 1
136 0
2
0 69 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
46 1
138 0
2
0 70 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
46 1
140 0
2
0 71 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
46 1
142 0
2
0 72 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
46 1
144 0
2
0 73 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
46 1
146 0
2
0 74 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
46 1
148 0
2
0 75 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
46 1
150 0
2
0 76 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
46 1
152 0
2
0 77 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
46 1
154 0
2
0 78 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
46 1
156 0
2
0 79 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
46 1
158 0
2
0 80 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
46 1
160 0
2
0 81 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
46 1
162 0
2
0 82 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
46 1
164 0
2
0 83 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
46 1
166 0
2
0 84 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
46 1
168 0
2
0 85 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
46 1
170 0
2
0 86 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
47 1
112 0
2
0 57 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
47 1
114 0
2
0 58 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
47 1
116 0
2
0 59 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
47 1
118 0
2
0 60 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
47 1
120 0
2
0 61 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
47 1
122 0
2
0 62 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
47 1
124 0
2
0 63 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
47 1
126 0
2
0 64 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
47 1
128 0
2
0 65 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
47 1
130 0
2
0 66 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
47 1
132 0
2
0 67 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
47 1
134 0
2
0 68 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
47 1
136 0
2
0 69 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
47 1
138 0
2
0 70 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
47 1
140 0
2
0 71 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
47 1
142 0
2
0 72 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
47 1
144 0
2
0 73 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
47 1
146 0
2
0 74 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
47 1
148 0
2
0 75 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
47 1
150 0
2
0 76 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
47 1
152 0
2
0 77 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
47 1
154 0
2
0 78 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
47 1
156 0
2
0 79 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
47 1
158 0
2
0 80 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
47 1
160 0
2
0 81 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
47 1
162 0
2
0 82 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
47 1
164 0
2
0 83 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
47 1
166 0
2
0 84 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
47 1
168 0
2
0 85 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
47 1
170 0
2
0 86 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
48 1
112 0
2
0 57 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
48 1
114 0
2
0 58 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
48 1
116 0
2
0 59 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
48 1
118 0
2
0 60 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
48 1
120 0
2
0 61 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
48 1
122 0
2
0 62 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
48 1
124 0
2
0 63 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
48 1
126 0
2
0 64 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
48 1
128 0
2
0 65 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
48 1
130 0
2
0 66 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
48 1
132 0
2
0 67 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
48 1
134 0
2
0 68 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
48 1
136 0
2
0 69 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
48 1
138 0
2
0 70 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
48 1
140 0
2
0 71 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
48 1
142 0
2
0 72 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
48 1
144 0
2
0 73 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
48 1
146 0
2
0 74 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
48 1
148 0
2
0 75 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
48 1
150 0
2
0 76 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
48 1
152 0
2
0 77 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
48 1
154 0
2
0 78 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
48 1
156 0
2
0 79 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
48 1
158 0
2
0 80 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
48 1
160 0
2
0 81 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
48 1
162 0
2
0 82 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
48 1
164 0
2
0 83 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
48 1
166 0
2
0 84 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
48 1
168 0
2
0 85 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
48 1
170 0
2
0 86 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
49 1
112 0
2
0 57 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
49 1
114 0
2
0 58 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
49 1
116 0
2
0 59 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
49 1
118 0
2
0 60 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
49 1
120 0
2
0 61 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
49 1
122 0
2
0 62 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
49 1
124 0
2
0 63 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
49 1
126 0
2
0 64 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
49 1
128 0
2
0 65 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
49 1
130 0
2
0 66 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
49 1
132 0
2
0 67 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
49 1
134 0
2
0 68 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
49 1
136 0
2
0 69 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
49 1
138 0
2
0 70 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
49 1
140 0
2
0 71 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
49 1
142 0
2
0 72 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
49 1
144 0
2
0 73 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
49 1
146 0
2
0 74 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
49 1
148 0
2
0 75 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
49 1
150 0
2
0 76 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
49 1
152 0
2
0 77 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
49 1
154 0
2
0 78 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
49 1
156 0
2
0 79 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
49 1
158 0
2
0 80 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
49 1
160 0
2
0 81 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
49 1
162 0
2
0 82 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
49 1
164 0
2
0 83 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
49 1
166 0
2
0 84 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
49 1
168 0
2
0 85 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
49 1
170 0
2
0 86 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
50 1
112 0
2
0 57 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
50 1
114 0
2
0 58 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
50 1
116 0
2
0 59 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
50 1
118 0
2
0 60 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
50 1
120 0
2
0 61 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
50 1
122 0
2
0 62 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
50 1
124 0
2
0 63 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
50 1
126 0
2
0 64 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
50 1
128 0
2
0 65 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
50 1
130 0
2
0 66 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
50 1
132 0
2
0 67 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
50 1
134 0
2
0 68 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
50 1
136 0
2
0 69 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
50 1
138 0
2
0 70 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
50 1
140 0
2
0 71 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
50 1
142 0
2
0 72 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
50 1
144 0
2
0 73 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
50 1
146 0
2
0 74 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
50 1
148 0
2
0 75 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
50 1
150 0
2
0 76 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
50 1
152 0
2
0 77 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
50 1
154 0
2
0 78 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
50 1
156 0
2
0 79 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
50 1
158 0
2
0 80 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
50 1
160 0
2
0 81 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
50 1
162 0
2
0 82 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
50 1
164 0
2
0 83 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
50 1
166 0
2
0 84 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
50 1
168 0
2
0 85 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
50 1
170 0
2
0 86 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
51 1
112 0
2
0 57 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
51 1
114 0
2
0 58 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
51 1
116 0
2
0 59 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
51 1
118 0
2
0 60 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
51 1
120 0
2
0 61 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
51 1
122 0
2
0 62 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
51 1
124 0
2
0 63 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
51 1
126 0
2
0 64 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
51 1
128 0
2
0 65 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
51 1
130 0
2
0 66 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
51 1
132 0
2
0 67 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
51 1
134 0
2
0 68 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
51 1
136 0
2
0 69 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
51 1
138 0
2
0 70 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
51 1
140 0
2
0 71 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
51 1
142 0
2
0 72 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
51 1
144 0
2
0 73 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
51 1
146 0
2
0 74 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
51 1
148 0
2
0 75 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
51 1
150 0
2
0 76 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
51 1
152 0
2
0 77 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
51 1
154 0
2
0 78 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
51 1
156 0
2
0 79 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
51 1
158 0
2
0 80 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
51 1
160 0
2
0 81 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
51 1
162 0
2
0 82 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
51 1
164 0
2
0 83 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
51 1
166 0
2
0 84 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
51 1
168 0
2
0 85 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
51 1
170 0
2
0 86 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
52 1
112 0
2
0 57 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
52 1
114 0
2
0 58 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
52 1
116 0
2
0 59 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
52 1
118 0
2
0 60 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
52 1
120 0
2
0 61 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
52 1
122 0
2
0 62 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
52 1
124 0
2
0 63 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
52 1
126 0
2
0 64 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
52 1
128 0
2
0 65 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
52 1
130 0
2
0 66 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
52 1
132 0
2
0 67 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
52 1
134 0
2
0 68 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
52 1
136 0
2
0 69 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
52 1
138 0
2
0 70 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
52 1
140 0
2
0 71 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
52 1
142 0
2
0 72 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
52 1
144 0
2
0 73 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
52 1
146 0
2
0 74 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
52 1
148 0
2
0 75 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
52 1
150 0
2
0 76 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
52 1
152 0
2
0 77 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
52 1
154 0
2
0 78 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
52 1
156 0
2
0 79 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
52 1
158 0
2
0 80 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
52 1
160 0
2
0 81 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
52 1
162 0
2
0 82 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
52 1
164 0
2
0 83 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
52 1
166 0
2
0 84 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
52 1
168 0
2
0 85 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
52 1
170 0
2
0 86 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
53 1
112 0
2
0 57 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
53 1
114 0
2
0 58 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
53 1
116 0
2
0 59 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
53 1
118 0
2
0 60 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
53 1
120 0
2
0 61 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
53 1
122 0
2
0 62 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
53 1
124 0
2
0 63 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
53 1
126 0
2
0 64 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
53 1
128 0
2
0 65 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
53 1
130 0
2
0 66 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
53 1
132 0
2
0 67 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
53 1
134 0
2
0 68 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
53 1
136 0
2
0 69 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
53 1
138 0
2
0 70 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
53 1
140 0
2
0 71 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
53 1
142 0
2
0 72 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
53 1
144 0
2
0 73 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
53 1
146 0
2
0 74 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
53 1
148 0
2
0 75 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
53 1
150 0
2
0 76 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
53 1
152 0
2
0 77 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
53 1
154 0
2
0 78 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
53 1
156 0
2
0 79 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
53 1
158 0
2
0 80 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
53 1
160 0
2
0 81 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
53 1
162 0
2
0 82 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
53 1
164 0
2
0 83 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
53 1
166 0
2
0 84 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
53 1
168 0
2
0 85 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
53 1
170 0
2
0 86 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
54 1
112 0
2
0 57 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
54 1
114 0
2
0 58 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
54 1
116 0
2
0 59 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
54 1
118 0
2
0 60 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
54 1
120 0
2
0 61 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
54 1
122 0
2
0 62 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
54 1
124 0
2
0 63 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
54 1
126 0
2
0 64 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
54 1
128 0
2
0 65 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
54 1
130 0
2
0 66 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
54 1
132 0
2
0 67 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
54 1
134 0
2
0 68 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
54 1
136 0
2
0 69 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
54 1
138 0
2
0 70 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
54 1
140 0
2
0 71 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
54 1
142 0
2
0 72 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
54 1
144 0
2
0 73 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
54 1
146 0
2
0 74 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
54 1
148 0
2
0 75 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
54 1
150 0
2
0 76 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
54 1
152 0
2
0 77 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
54 1
154 0
2
0 78 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
54 1
156 0
2
0 79 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
54 1
158 0
2
0 80 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
54 1
160 0
2
0 81 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
54 1
162 0
2
0 82 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
54 1
164 0
2
0 83 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
54 1
166 0
2
0 84 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
54 1
168 0
2
0 85 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
54 1
170 0
2
0 86 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
55 1
112 0
2
0 57 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
55 1
114 0
2
0 58 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
55 1
116 0
2
0 59 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
55 1
118 0
2
0 60 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
55 1
120 0
2
0 61 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
55 1
122 0
2
0 62 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
55 1
124 0
2
0 63 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
55 1
126 0
2
0 64 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
55 1
128 0
2
0 65 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
55 1
130 0
2
0 66 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
55 1
132 0
2
0 67 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
55 1
134 0
2
0 68 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
55 1
136 0
2
0 69 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
55 1
138 0
2
0 70 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
55 1
140 0
2
0 71 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
55 1
142 0
2
0 72 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
55 1
144 0
2
0 73 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
55 1
146 0
2
0 74 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
55 1
148 0
2
0 75 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
55 1
150 0
2
0 76 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
55 1
152 0
2
0 77 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
55 1
154 0
2
0 78 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
55 1
156 0
2
0 79 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
55 1
158 0
2
0 80 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
55 1
160 0
2
0 81 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
55 1
162 0
2
0 82 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
55 1
164 0
2
0 83 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
55 1
166 0
2
0 84 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
55 1
168 0
2
0 85 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
55 1
170 0
2
0 86 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
56 1
112 0
2
0 57 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
56 1
114 0
2
0 58 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
56 1
116 0
2
0 59 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
56 1
118 0
2
0 60 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
56 1
120 0
2
0 61 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
56 1
122 0
2
0 62 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
56 1
124 0
2
0 63 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
56 1
126 0
2
0 64 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
56 1
128 0
2
0 65 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
56 1
130 0
2
0 66 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
56 1
132 0
2
0 67 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
56 1
134 0
2
0 68 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
56 1
136 0
2
0 69 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
56 1
138 0
2
0 70 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
56 1
140 0
2
0 71 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
56 1
142 0
2
0 72 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
56 1
144 0
2
0 73 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
56 1
146 0
2
0 74 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
56 1
148 0
2
0 75 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
56 1
150 0
2
0 76 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
56 1
152 0
2
0 77 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
56 1
154 0
2
0 78 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
56 1
156 0
2
0 79 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
56 1
158 0
2
0 80 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
56 1
160 0
2
0 81 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
56 1
162 0
2
0 82 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
56 1
164 0
2
0 83 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
56 1
166 0
2
0 84 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
56 1
168 0
2
0 85 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
56 1
170 0
2
0 86 0 1
0 172 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
173 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
174 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
175 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
176 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
177 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
178 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
179 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
180 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
181 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
182 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
183 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
184 0
1
0 0 12 22
1
end_operator
begin_operator
walk location20 location21 bob
1
185 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
186 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
187 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
188 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
189 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
190 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
191 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
192 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 gate bob
1
193 0
1
0 0 21 0
1
end_operator
begin_operator
walk location3 location4 bob
1
194 0
1
0 0 22 23
1
end_operator
begin_operator
walk location4 location5 bob
1
195 0
1
0 0 23 24
1
end_operator
begin_operator
walk location5 location6 bob
1
196 0
1
0 0 24 25
1
end_operator
begin_operator
walk location6 location7 bob
1
197 0
1
0 0 25 26
1
end_operator
begin_operator
walk location7 location8 bob
1
198 0
1
0 0 26 27
1
end_operator
begin_operator
walk location8 location9 bob
1
199 0
1
0 0 27 28
1
end_operator
begin_operator
walk location9 location10 bob
1
200 0
1
0 0 28 2
1
end_operator
begin_operator
walk shed location1 bob
1
201 0
1
0 0 29 1
1
end_operator
0
