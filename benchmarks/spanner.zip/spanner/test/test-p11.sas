begin_version
3
end_version
begin_metric
1
end_metric
20
begin_variable
var0
-1
8
at bob gate
at bob location1
at bob location2
at bob location3
at bob location4
at bob location5
at bob location6
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location4
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner2 location6
carrying bob spanner2
end_variable
begin_variable
var3
-1
2
at spanner3 location4
carrying bob spanner3
end_variable
begin_variable
var4
-1
2
at spanner4 location2
carrying bob spanner4
end_variable
begin_variable
var5
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var6
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var7
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var8
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var9
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var10
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var11
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var12
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var13
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var14
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var15
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var16
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var17
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var18
-1
2
link location6 gate
none-of-those
end_variable
begin_variable
var19
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
7
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
2
5 1
6 1
end_goal
19
begin_operator
pickup_spanner location2 spanner4 bob
1
0 2
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner1 bob
1
0 4
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner3 bob
1
0 4
1
0 3 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner2 bob
1
0 6
1
0 2 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
7 0
2
0 5 0 1
0 9 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
8 0
2
0 6 0 1
0 9 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
2 1
7 0
2
0 5 0 1
0 10 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
2 1
8 0
2
0 6 0 1
0 10 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
3 1
7 0
2
0 5 0 1
0 11 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
3 1
8 0
2
0 6 0 1
0 11 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
4 1
7 0
2
0 5 0 1
0 12 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
4 1
8 0
2
0 6 0 1
0 12 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
13 0
1
0 0 1 2
1
end_operator
begin_operator
walk location2 location3 bob
1
14 0
1
0 0 2 3
1
end_operator
begin_operator
walk location3 location4 bob
1
15 0
1
0 0 3 4
1
end_operator
begin_operator
walk location4 location5 bob
1
16 0
1
0 0 4 5
1
end_operator
begin_operator
walk location5 location6 bob
1
17 0
1
0 0 5 6
1
end_operator
begin_operator
walk location6 gate bob
1
18 0
1
0 0 6 0
1
end_operator
begin_operator
walk shed location1 bob
1
19 0
1
0 0 7 1
1
end_operator
0
