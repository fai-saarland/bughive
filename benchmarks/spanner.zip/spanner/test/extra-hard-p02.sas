begin_version
3
end_version
begin_metric
1
end_metric
391
begin_variable
var0
-1
53
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location29
at bob location3
at bob location30
at bob location31
at bob location32
at bob location33
at bob location34
at bob location35
at bob location36
at bob location37
at bob location38
at bob location39
at bob location4
at bob location40
at bob location41
at bob location42
at bob location43
at bob location44
at bob location45
at bob location46
at bob location47
at bob location48
at bob location49
at bob location5
at bob location50
at bob location51
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location34
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner10 location46
carrying bob spanner10
end_variable
begin_variable
var3
-1
2
at spanner100 location33
carrying bob spanner100
end_variable
begin_variable
var4
-1
2
at spanner101 location11
carrying bob spanner101
end_variable
begin_variable
var5
-1
2
at spanner102 location32
carrying bob spanner102
end_variable
begin_variable
var6
-1
2
at spanner103 location28
carrying bob spanner103
end_variable
begin_variable
var7
-1
2
at spanner104 location41
carrying bob spanner104
end_variable
begin_variable
var8
-1
2
at spanner105 location23
carrying bob spanner105
end_variable
begin_variable
var9
-1
2
at spanner106 location16
carrying bob spanner106
end_variable
begin_variable
var10
-1
2
at spanner107 location47
carrying bob spanner107
end_variable
begin_variable
var11
-1
2
at spanner108 location34
carrying bob spanner108
end_variable
begin_variable
var12
-1
2
at spanner109 location19
carrying bob spanner109
end_variable
begin_variable
var13
-1
2
at spanner11 location10
carrying bob spanner11
end_variable
begin_variable
var14
-1
2
at spanner110 location44
carrying bob spanner110
end_variable
begin_variable
var15
-1
2
at spanner111 location7
carrying bob spanner111
end_variable
begin_variable
var16
-1
2
at spanner112 location11
carrying bob spanner112
end_variable
begin_variable
var17
-1
2
at spanner113 location11
carrying bob spanner113
end_variable
begin_variable
var18
-1
2
at spanner12 location44
carrying bob spanner12
end_variable
begin_variable
var19
-1
2
at spanner13 location38
carrying bob spanner13
end_variable
begin_variable
var20
-1
2
at spanner14 location8
carrying bob spanner14
end_variable
begin_variable
var21
-1
2
at spanner15 location38
carrying bob spanner15
end_variable
begin_variable
var22
-1
2
at spanner16 location23
carrying bob spanner16
end_variable
begin_variable
var23
-1
2
at spanner17 location43
carrying bob spanner17
end_variable
begin_variable
var24
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var25
-1
2
at spanner18 location1
carrying bob spanner18
end_variable
begin_variable
var26
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var27
-1
2
at spanner19 location35
carrying bob spanner19
end_variable
begin_variable
var28
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var29
-1
2
at spanner2 location29
carrying bob spanner2
end_variable
begin_variable
var30
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var31
-1
2
at spanner20 location51
carrying bob spanner20
end_variable
begin_variable
var32
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var33
-1
2
at spanner21 location21
carrying bob spanner21
end_variable
begin_variable
var34
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var35
-1
2
at spanner22 location17
carrying bob spanner22
end_variable
begin_variable
var36
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var37
-1
2
at spanner23 location15
carrying bob spanner23
end_variable
begin_variable
var38
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var39
-1
2
at spanner24 location32
carrying bob spanner24
end_variable
begin_variable
var40
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var41
-1
2
at spanner25 location10
carrying bob spanner25
end_variable
begin_variable
var42
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var43
-1
2
at spanner26 location35
carrying bob spanner26
end_variable
begin_variable
var44
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var45
-1
2
at spanner27 location3
carrying bob spanner27
end_variable
begin_variable
var46
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var47
-1
2
at spanner28 location14
carrying bob spanner28
end_variable
begin_variable
var48
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var49
-1
2
at spanner29 location10
carrying bob spanner29
end_variable
begin_variable
var50
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var51
-1
2
at spanner3 location22
carrying bob spanner3
end_variable
begin_variable
var52
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var53
-1
2
at spanner30 location48
carrying bob spanner30
end_variable
begin_variable
var54
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var55
-1
2
at spanner31 location7
carrying bob spanner31
end_variable
begin_variable
var56
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var57
-1
2
at spanner32 location15
carrying bob spanner32
end_variable
begin_variable
var58
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var59
-1
2
at spanner33 location25
carrying bob spanner33
end_variable
begin_variable
var60
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var61
-1
2
at spanner34 location23
carrying bob spanner34
end_variable
begin_variable
var62
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var63
-1
2
at spanner35 location7
carrying bob spanner35
end_variable
begin_variable
var64
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var65
-1
2
at spanner36 location7
carrying bob spanner36
end_variable
begin_variable
var66
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var67
-1
2
at spanner37 location10
carrying bob spanner37
end_variable
begin_variable
var68
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var69
-1
2
at spanner38 location51
carrying bob spanner38
end_variable
begin_variable
var70
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var71
-1
2
at spanner39 location15
carrying bob spanner39
end_variable
begin_variable
var72
-1
2
loose nut31
tightened nut31
end_variable
begin_variable
var73
-1
2
at spanner4 location6
carrying bob spanner4
end_variable
begin_variable
var74
-1
2
loose nut32
tightened nut32
end_variable
begin_variable
var75
-1
2
at spanner40 location24
carrying bob spanner40
end_variable
begin_variable
var76
-1
2
loose nut33
tightened nut33
end_variable
begin_variable
var77
-1
2
at spanner41 location16
carrying bob spanner41
end_variable
begin_variable
var78
-1
2
loose nut34
tightened nut34
end_variable
begin_variable
var79
-1
2
at spanner42 location15
carrying bob spanner42
end_variable
begin_variable
var80
-1
2
loose nut35
tightened nut35
end_variable
begin_variable
var81
-1
2
at spanner43 location7
carrying bob spanner43
end_variable
begin_variable
var82
-1
2
loose nut36
tightened nut36
end_variable
begin_variable
var83
-1
2
at spanner44 location29
carrying bob spanner44
end_variable
begin_variable
var84
-1
2
loose nut37
tightened nut37
end_variable
begin_variable
var85
-1
2
at spanner45 location47
carrying bob spanner45
end_variable
begin_variable
var86
-1
2
loose nut38
tightened nut38
end_variable
begin_variable
var87
-1
2
at spanner46 location29
carrying bob spanner46
end_variable
begin_variable
var88
-1
2
loose nut39
tightened nut39
end_variable
begin_variable
var89
-1
2
at spanner47 location20
carrying bob spanner47
end_variable
begin_variable
var90
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var91
-1
2
at spanner48 location22
carrying bob spanner48
end_variable
begin_variable
var92
-1
2
loose nut40
tightened nut40
end_variable
begin_variable
var93
-1
2
at spanner49 location50
carrying bob spanner49
end_variable
begin_variable
var94
-1
2
loose nut41
tightened nut41
end_variable
begin_variable
var95
-1
2
at spanner5 location46
carrying bob spanner5
end_variable
begin_variable
var96
-1
2
loose nut42
tightened nut42
end_variable
begin_variable
var97
-1
2
at spanner50 location9
carrying bob spanner50
end_variable
begin_variable
var98
-1
2
loose nut43
tightened nut43
end_variable
begin_variable
var99
-1
2
at spanner51 location29
carrying bob spanner51
end_variable
begin_variable
var100
-1
2
loose nut44
tightened nut44
end_variable
begin_variable
var101
-1
2
at spanner52 location24
carrying bob spanner52
end_variable
begin_variable
var102
-1
2
loose nut45
tightened nut45
end_variable
begin_variable
var103
-1
2
at spanner53 location30
carrying bob spanner53
end_variable
begin_variable
var104
-1
2
loose nut46
tightened nut46
end_variable
begin_variable
var105
-1
2
at spanner54 location50
carrying bob spanner54
end_variable
begin_variable
var106
-1
2
loose nut47
tightened nut47
end_variable
begin_variable
var107
-1
2
at spanner55 location37
carrying bob spanner55
end_variable
begin_variable
var108
-1
2
loose nut48
tightened nut48
end_variable
begin_variable
var109
-1
2
at spanner56 location21
carrying bob spanner56
end_variable
begin_variable
var110
-1
2
loose nut49
tightened nut49
end_variable
begin_variable
var111
-1
2
at spanner57 location44
carrying bob spanner57
end_variable
begin_variable
var112
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var113
-1
2
at spanner58 location27
carrying bob spanner58
end_variable
begin_variable
var114
-1
2
loose nut50
tightened nut50
end_variable
begin_variable
var115
-1
2
at spanner59 location43
carrying bob spanner59
end_variable
begin_variable
var116
-1
2
loose nut51
tightened nut51
end_variable
begin_variable
var117
-1
2
at spanner6 location50
carrying bob spanner6
end_variable
begin_variable
var118
-1
2
loose nut52
tightened nut52
end_variable
begin_variable
var119
-1
2
at spanner60 location24
carrying bob spanner60
end_variable
begin_variable
var120
-1
2
loose nut53
tightened nut53
end_variable
begin_variable
var121
-1
2
at spanner61 location37
carrying bob spanner61
end_variable
begin_variable
var122
-1
2
loose nut54
tightened nut54
end_variable
begin_variable
var123
-1
2
at spanner62 location23
carrying bob spanner62
end_variable
begin_variable
var124
-1
2
loose nut55
tightened nut55
end_variable
begin_variable
var125
-1
2
at spanner63 location27
carrying bob spanner63
end_variable
begin_variable
var126
-1
2
loose nut56
tightened nut56
end_variable
begin_variable
var127
-1
2
at spanner64 location49
carrying bob spanner64
end_variable
begin_variable
var128
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var129
-1
2
at spanner65 location23
carrying bob spanner65
end_variable
begin_variable
var130
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var131
-1
2
at spanner66 location4
carrying bob spanner66
end_variable
begin_variable
var132
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var133
-1
2
at spanner67 location35
carrying bob spanner67
end_variable
begin_variable
var134
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var135
-1
2
at spanner68 location33
carrying bob spanner68
end_variable
begin_variable
var136
-1
2
at spanner69 location16
carrying bob spanner69
end_variable
begin_variable
var137
-1
2
at spanner7 location7
carrying bob spanner7
end_variable
begin_variable
var138
-1
2
at spanner70 location32
carrying bob spanner70
end_variable
begin_variable
var139
-1
2
at spanner71 location10
carrying bob spanner71
end_variable
begin_variable
var140
-1
2
at spanner72 location20
carrying bob spanner72
end_variable
begin_variable
var141
-1
2
at spanner73 location4
carrying bob spanner73
end_variable
begin_variable
var142
-1
2
at spanner74 location15
carrying bob spanner74
end_variable
begin_variable
var143
-1
2
at spanner75 location32
carrying bob spanner75
end_variable
begin_variable
var144
-1
2
at spanner76 location18
carrying bob spanner76
end_variable
begin_variable
var145
-1
2
at spanner77 location21
carrying bob spanner77
end_variable
begin_variable
var146
-1
2
at spanner78 location29
carrying bob spanner78
end_variable
begin_variable
var147
-1
2
at spanner79 location50
carrying bob spanner79
end_variable
begin_variable
var148
-1
2
at spanner8 location4
carrying bob spanner8
end_variable
begin_variable
var149
-1
2
at spanner80 location43
carrying bob spanner80
end_variable
begin_variable
var150
-1
2
at spanner81 location32
carrying bob spanner81
end_variable
begin_variable
var151
-1
2
at spanner82 location32
carrying bob spanner82
end_variable
begin_variable
var152
-1
2
at spanner83 location30
carrying bob spanner83
end_variable
begin_variable
var153
-1
2
at spanner84 location15
carrying bob spanner84
end_variable
begin_variable
var154
-1
2
at spanner85 location35
carrying bob spanner85
end_variable
begin_variable
var155
-1
2
at spanner86 location42
carrying bob spanner86
end_variable
begin_variable
var156
-1
2
at spanner87 location3
carrying bob spanner87
end_variable
begin_variable
var157
-1
2
at spanner88 location45
carrying bob spanner88
end_variable
begin_variable
var158
-1
2
at spanner89 location47
carrying bob spanner89
end_variable
begin_variable
var159
-1
2
at spanner9 location43
carrying bob spanner9
end_variable
begin_variable
var160
-1
2
at spanner90 location8
carrying bob spanner90
end_variable
begin_variable
var161
-1
2
at spanner91 location7
carrying bob spanner91
end_variable
begin_variable
var162
-1
2
at spanner92 location36
carrying bob spanner92
end_variable
begin_variable
var163
-1
2
at spanner93 location50
carrying bob spanner93
end_variable
begin_variable
var164
-1
2
at spanner94 location31
carrying bob spanner94
end_variable
begin_variable
var165
-1
2
at spanner95 location17
carrying bob spanner95
end_variable
begin_variable
var166
-1
2
at spanner96 location3
carrying bob spanner96
end_variable
begin_variable
var167
-1
2
at spanner97 location6
carrying bob spanner97
end_variable
begin_variable
var168
-1
2
at spanner98 location10
carrying bob spanner98
end_variable
begin_variable
var169
-1
2
at spanner99 location4
carrying bob spanner99
end_variable
begin_variable
var170
-1
2
usable spanner110
none-of-those
end_variable
begin_variable
var171
-1
2
usable spanner111
none-of-those
end_variable
begin_variable
var172
-1
2
usable spanner112
none-of-those
end_variable
begin_variable
var173
-1
2
usable spanner113
none-of-those
end_variable
begin_variable
var174
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var175
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var176
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var177
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var178
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var179
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var180
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var181
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var182
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var183
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var184
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var185
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var186
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var187
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var188
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var189
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var190
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var191
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var192
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var193
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var194
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var195
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var196
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var197
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var198
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var199
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var200
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var201
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var202
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var203
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var204
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var205
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var206
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var207
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var208
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var209
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var210
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var211
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var212
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var213
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var214
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var215
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var216
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var217
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var218
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var219
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var220
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var221
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var222
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var223
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var224
-1
2
usable spanner57
none-of-those
end_variable
begin_variable
var225
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var226
-1
2
usable spanner58
none-of-those
end_variable
begin_variable
var227
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var228
-1
2
usable spanner59
none-of-those
end_variable
begin_variable
var229
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var230
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var231
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var232
-1
2
usable spanner60
none-of-those
end_variable
begin_variable
var233
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var234
-1
2
usable spanner61
none-of-those
end_variable
begin_variable
var235
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var236
-1
2
usable spanner62
none-of-those
end_variable
begin_variable
var237
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var238
-1
2
usable spanner63
none-of-those
end_variable
begin_variable
var239
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var240
-1
2
usable spanner64
none-of-those
end_variable
begin_variable
var241
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var242
-1
2
usable spanner65
none-of-those
end_variable
begin_variable
var243
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var244
-1
2
usable spanner66
none-of-those
end_variable
begin_variable
var245
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var246
-1
2
usable spanner67
none-of-those
end_variable
begin_variable
var247
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var248
-1
2
usable spanner68
none-of-those
end_variable
begin_variable
var249
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var250
-1
2
usable spanner69
none-of-those
end_variable
begin_variable
var251
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var252
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var253
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var254
-1
2
usable spanner70
none-of-those
end_variable
begin_variable
var255
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var256
-1
2
usable spanner71
none-of-those
end_variable
begin_variable
var257
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var258
-1
2
usable spanner72
none-of-those
end_variable
begin_variable
var259
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var260
-1
2
usable spanner73
none-of-those
end_variable
begin_variable
var261
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var262
-1
2
usable spanner74
none-of-those
end_variable
begin_variable
var263
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var264
-1
2
usable spanner75
none-of-those
end_variable
begin_variable
var265
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var266
-1
2
usable spanner76
none-of-those
end_variable
begin_variable
var267
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var268
-1
2
usable spanner77
none-of-those
end_variable
begin_variable
var269
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var270
-1
2
usable spanner78
none-of-those
end_variable
begin_variable
var271
-1
2
at nut31 gate
none-of-those
end_variable
begin_variable
var272
-1
2
usable spanner79
none-of-those
end_variable
begin_variable
var273
-1
2
at nut32 gate
none-of-those
end_variable
begin_variable
var274
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var275
-1
2
at nut33 gate
none-of-those
end_variable
begin_variable
var276
-1
2
usable spanner80
none-of-those
end_variable
begin_variable
var277
-1
2
at nut34 gate
none-of-those
end_variable
begin_variable
var278
-1
2
usable spanner81
none-of-those
end_variable
begin_variable
var279
-1
2
at nut35 gate
none-of-those
end_variable
begin_variable
var280
-1
2
usable spanner82
none-of-those
end_variable
begin_variable
var281
-1
2
at nut36 gate
none-of-those
end_variable
begin_variable
var282
-1
2
usable spanner83
none-of-those
end_variable
begin_variable
var283
-1
2
at nut37 gate
none-of-those
end_variable
begin_variable
var284
-1
2
usable spanner84
none-of-those
end_variable
begin_variable
var285
-1
2
at nut38 gate
none-of-those
end_variable
begin_variable
var286
-1
2
usable spanner85
none-of-those
end_variable
begin_variable
var287
-1
2
at nut39 gate
none-of-those
end_variable
begin_variable
var288
-1
2
usable spanner86
none-of-those
end_variable
begin_variable
var289
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var290
-1
2
usable spanner87
none-of-those
end_variable
begin_variable
var291
-1
2
at nut40 gate
none-of-those
end_variable
begin_variable
var292
-1
2
usable spanner88
none-of-those
end_variable
begin_variable
var293
-1
2
at nut41 gate
none-of-those
end_variable
begin_variable
var294
-1
2
usable spanner89
none-of-those
end_variable
begin_variable
var295
-1
2
at nut42 gate
none-of-those
end_variable
begin_variable
var296
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var297
-1
2
at nut43 gate
none-of-those
end_variable
begin_variable
var298
-1
2
usable spanner90
none-of-those
end_variable
begin_variable
var299
-1
2
at nut44 gate
none-of-those
end_variable
begin_variable
var300
-1
2
usable spanner91
none-of-those
end_variable
begin_variable
var301
-1
2
at nut45 gate
none-of-those
end_variable
begin_variable
var302
-1
2
usable spanner92
none-of-those
end_variable
begin_variable
var303
-1
2
at nut46 gate
none-of-those
end_variable
begin_variable
var304
-1
2
usable spanner93
none-of-those
end_variable
begin_variable
var305
-1
2
at nut47 gate
none-of-those
end_variable
begin_variable
var306
-1
2
usable spanner94
none-of-those
end_variable
begin_variable
var307
-1
2
at nut48 gate
none-of-those
end_variable
begin_variable
var308
-1
2
usable spanner95
none-of-those
end_variable
begin_variable
var309
-1
2
at nut49 gate
none-of-those
end_variable
begin_variable
var310
-1
2
usable spanner96
none-of-those
end_variable
begin_variable
var311
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var312
-1
2
usable spanner97
none-of-those
end_variable
begin_variable
var313
-1
2
at nut50 gate
none-of-those
end_variable
begin_variable
var314
-1
2
usable spanner98
none-of-those
end_variable
begin_variable
var315
-1
2
at nut51 gate
none-of-those
end_variable
begin_variable
var316
-1
2
usable spanner99
none-of-those
end_variable
begin_variable
var317
-1
2
at nut52 gate
none-of-those
end_variable
begin_variable
var318
-1
2
at nut53 gate
none-of-those
end_variable
begin_variable
var319
-1
2
at nut54 gate
none-of-those
end_variable
begin_variable
var320
-1
2
at nut55 gate
none-of-those
end_variable
begin_variable
var321
-1
2
at nut56 gate
none-of-those
end_variable
begin_variable
var322
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var323
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var324
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var325
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var326
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var327
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var328
-1
2
usable spanner100
none-of-those
end_variable
begin_variable
var329
-1
2
usable spanner101
none-of-those
end_variable
begin_variable
var330
-1
2
usable spanner102
none-of-those
end_variable
begin_variable
var331
-1
2
usable spanner103
none-of-those
end_variable
begin_variable
var332
-1
2
usable spanner104
none-of-those
end_variable
begin_variable
var333
-1
2
usable spanner105
none-of-those
end_variable
begin_variable
var334
-1
2
usable spanner106
none-of-those
end_variable
begin_variable
var335
-1
2
usable spanner107
none-of-those
end_variable
begin_variable
var336
-1
2
usable spanner108
none-of-those
end_variable
begin_variable
var337
-1
2
usable spanner109
none-of-those
end_variable
begin_variable
var338
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var339
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var340
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var341
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var342
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var343
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var344
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var345
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var346
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var347
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var348
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var349
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var350
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var351
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var352
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var353
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var354
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var355
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var356
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var357
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var358
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var359
-1
2
link location28 location29
none-of-those
end_variable
begin_variable
var360
-1
2
link location29 location30
none-of-those
end_variable
begin_variable
var361
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var362
-1
2
link location30 location31
none-of-those
end_variable
begin_variable
var363
-1
2
link location31 location32
none-of-those
end_variable
begin_variable
var364
-1
2
link location32 location33
none-of-those
end_variable
begin_variable
var365
-1
2
link location33 location34
none-of-those
end_variable
begin_variable
var366
-1
2
link location34 location35
none-of-those
end_variable
begin_variable
var367
-1
2
link location35 location36
none-of-those
end_variable
begin_variable
var368
-1
2
link location36 location37
none-of-those
end_variable
begin_variable
var369
-1
2
link location37 location38
none-of-those
end_variable
begin_variable
var370
-1
2
link location38 location39
none-of-those
end_variable
begin_variable
var371
-1
2
link location39 location40
none-of-those
end_variable
begin_variable
var372
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var373
-1
2
link location40 location41
none-of-those
end_variable
begin_variable
var374
-1
2
link location41 location42
none-of-those
end_variable
begin_variable
var375
-1
2
link location42 location43
none-of-those
end_variable
begin_variable
var376
-1
2
link location43 location44
none-of-those
end_variable
begin_variable
var377
-1
2
link location44 location45
none-of-those
end_variable
begin_variable
var378
-1
2
link location45 location46
none-of-those
end_variable
begin_variable
var379
-1
2
link location46 location47
none-of-those
end_variable
begin_variable
var380
-1
2
link location47 location48
none-of-those
end_variable
begin_variable
var381
-1
2
link location48 location49
none-of-those
end_variable
begin_variable
var382
-1
2
link location49 location50
none-of-those
end_variable
begin_variable
var383
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var384
-1
2
link location50 location51
none-of-those
end_variable
begin_variable
var385
-1
2
link location51 gate
none-of-those
end_variable
begin_variable
var386
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var387
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var388
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var389
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var390
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
52
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
56
24 1
26 1
28 1
30 1
32 1
34 1
36 1
38 1
40 1
42 1
44 1
46 1
48 1
50 1
52 1
54 1
56 1
58 1
60 1
62 1
64 1
66 1
68 1
70 1
72 1
74 1
76 1
78 1
80 1
82 1
84 1
86 1
88 1
90 1
92 1
94 1
96 1
98 1
100 1
102 1
104 1
106 1
108 1
110 1
112 1
114 1
116 1
118 1
120 1
122 1
124 1
126 1
128 1
130 1
132 1
134 1
end_goal
6493
begin_operator
pickup_spanner location1 spanner18 bob
1
0 1
1
0 25 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner11 bob
1
0 2
1
0 13 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner25 bob
1
0 2
1
0 41 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner29 bob
1
0 2
1
0 49 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner37 bob
1
0 2
1
0 67 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner71 bob
1
0 2
1
0 139 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner98 bob
1
0 2
1
0 168 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner101 bob
1
0 3
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner112 bob
1
0 3
1
0 16 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner113 bob
1
0 3
1
0 17 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner28 bob
1
0 6
1
0 47 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner23 bob
1
0 7
1
0 37 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner32 bob
1
0 7
1
0 57 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner39 bob
1
0 7
1
0 71 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner42 bob
1
0 7
1
0 79 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner74 bob
1
0 7
1
0 142 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner84 bob
1
0 7
1
0 153 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner106 bob
1
0 8
1
0 9 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner41 bob
1
0 8
1
0 77 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner69 bob
1
0 8
1
0 136 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner22 bob
1
0 9
1
0 35 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner95 bob
1
0 9
1
0 165 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner76 bob
1
0 10
1
0 144 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner109 bob
1
0 11
1
0 12 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner47 bob
1
0 13
1
0 89 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner72 bob
1
0 13
1
0 140 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner21 bob
1
0 14
1
0 33 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner56 bob
1
0 14
1
0 109 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner77 bob
1
0 14
1
0 145 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner3 bob
1
0 15
1
0 51 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner48 bob
1
0 15
1
0 91 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner105 bob
1
0 16
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner16 bob
1
0 16
1
0 22 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner34 bob
1
0 16
1
0 61 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner62 bob
1
0 16
1
0 123 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner65 bob
1
0 16
1
0 129 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner40 bob
1
0 17
1
0 75 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner52 bob
1
0 17
1
0 101 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner60 bob
1
0 17
1
0 119 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner33 bob
1
0 18
1
0 59 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner58 bob
1
0 20
1
0 113 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner63 bob
1
0 20
1
0 125 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner103 bob
1
0 21
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner2 bob
1
0 22
1
0 29 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner44 bob
1
0 22
1
0 83 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner46 bob
1
0 22
1
0 87 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner51 bob
1
0 22
1
0 99 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner78 bob
1
0 22
1
0 146 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner27 bob
1
0 23
1
0 45 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner87 bob
1
0 23
1
0 156 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner96 bob
1
0 23
1
0 166 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner53 bob
1
0 24
1
0 103 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner83 bob
1
0 24
1
0 152 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner94 bob
1
0 25
1
0 164 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner102 bob
1
0 26
1
0 5 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner24 bob
1
0 26
1
0 39 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner70 bob
1
0 26
1
0 138 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner75 bob
1
0 26
1
0 143 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner81 bob
1
0 26
1
0 150 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner82 bob
1
0 26
1
0 151 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner100 bob
1
0 27
1
0 3 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner68 bob
1
0 27
1
0 135 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner1 bob
1
0 28
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner108 bob
1
0 28
1
0 11 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner19 bob
1
0 29
1
0 27 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner26 bob
1
0 29
1
0 43 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner67 bob
1
0 29
1
0 133 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner85 bob
1
0 29
1
0 154 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner92 bob
1
0 30
1
0 162 0 1
1
end_operator
begin_operator
pickup_spanner location37 spanner55 bob
1
0 31
1
0 107 0 1
1
end_operator
begin_operator
pickup_spanner location37 spanner61 bob
1
0 31
1
0 121 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner13 bob
1
0 32
1
0 19 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner15 bob
1
0 32
1
0 21 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner66 bob
1
0 34
1
0 131 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner73 bob
1
0 34
1
0 141 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner8 bob
1
0 34
1
0 148 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner99 bob
1
0 34
1
0 169 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner104 bob
1
0 36
1
0 7 0 1
1
end_operator
begin_operator
pickup_spanner location42 spanner86 bob
1
0 37
1
0 155 0 1
1
end_operator
begin_operator
pickup_spanner location43 spanner17 bob
1
0 38
1
0 23 0 1
1
end_operator
begin_operator
pickup_spanner location43 spanner59 bob
1
0 38
1
0 115 0 1
1
end_operator
begin_operator
pickup_spanner location43 spanner80 bob
1
0 38
1
0 149 0 1
1
end_operator
begin_operator
pickup_spanner location43 spanner9 bob
1
0 38
1
0 159 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner110 bob
1
0 39
1
0 14 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner12 bob
1
0 39
1
0 18 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner57 bob
1
0 39
1
0 111 0 1
1
end_operator
begin_operator
pickup_spanner location45 spanner88 bob
1
0 40
1
0 157 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner10 bob
1
0 41
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner5 bob
1
0 41
1
0 95 0 1
1
end_operator
begin_operator
pickup_spanner location47 spanner107 bob
1
0 42
1
0 10 0 1
1
end_operator
begin_operator
pickup_spanner location47 spanner45 bob
1
0 42
1
0 85 0 1
1
end_operator
begin_operator
pickup_spanner location47 spanner89 bob
1
0 42
1
0 158 0 1
1
end_operator
begin_operator
pickup_spanner location48 spanner30 bob
1
0 43
1
0 53 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner64 bob
1
0 44
1
0 127 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner49 bob
1
0 46
1
0 93 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner54 bob
1
0 46
1
0 105 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner6 bob
1
0 46
1
0 117 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner79 bob
1
0 46
1
0 147 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner93 bob
1
0 46
1
0 163 0 1
1
end_operator
begin_operator
pickup_spanner location51 spanner20 bob
1
0 47
1
0 31 0 1
1
end_operator
begin_operator
pickup_spanner location51 spanner38 bob
1
0 47
1
0 69 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner4 bob
1
0 48
1
0 73 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner97 bob
1
0 48
1
0 167 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner111 bob
1
0 49
1
0 15 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner31 bob
1
0 49
1
0 55 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner35 bob
1
0 49
1
0 63 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner36 bob
1
0 49
1
0 65 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner43 bob
1
0 49
1
0 81 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner7 bob
1
0 49
1
0 137 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner91 bob
1
0 49
1
0 161 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner14 bob
1
0 50
1
0 20 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner90 bob
1
0 50
1
0 160 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner50 bob
1
0 51
1
0 97 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
223 0
2
0 24 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
1 1
225 0
2
0 26 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
1 1
227 0
2
0 28 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
1 1
229 0
2
0 30 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
1 1
231 0
2
0 32 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
1 1
233 0
2
0 34 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
1 1
235 0
2
0 36 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
1 1
237 0
2
0 38 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
1 1
239 0
2
0 40 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
1 1
241 0
2
0 42 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
1 1
243 0
2
0 44 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
245 0
2
0 46 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
1 1
247 0
2
0 48 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
1 1
249 0
2
0 50 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
1 1
251 0
2
0 52 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
1 1
253 0
2
0 54 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
1 1
255 0
2
0 56 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
1 1
257 0
2
0 58 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
1 1
259 0
2
0 60 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
1 1
261 0
2
0 62 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
1 1
263 0
2
0 64 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
1 1
265 0
2
0 66 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
1 1
267 0
2
0 68 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
1 1
269 0
2
0 70 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut31
3
0 0
1 1
271 0
2
0 72 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut32
3
0 0
1 1
273 0
2
0 74 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut33
3
0 0
1 1
275 0
2
0 76 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut34
3
0 0
1 1
277 0
2
0 78 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut35
3
0 0
1 1
279 0
2
0 80 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut36
3
0 0
1 1
281 0
2
0 82 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut37
3
0 0
1 1
283 0
2
0 84 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut38
3
0 0
1 1
285 0
2
0 86 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut39
3
0 0
1 1
287 0
2
0 88 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
1 1
289 0
2
0 90 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut40
3
0 0
1 1
291 0
2
0 92 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut41
3
0 0
1 1
293 0
2
0 94 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut42
3
0 0
1 1
295 0
2
0 96 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut43
3
0 0
1 1
297 0
2
0 98 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut44
3
0 0
1 1
299 0
2
0 100 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut45
3
0 0
1 1
301 0
2
0 102 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut46
3
0 0
1 1
303 0
2
0 104 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut47
3
0 0
1 1
305 0
2
0 106 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut48
3
0 0
1 1
307 0
2
0 108 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut49
3
0 0
1 1
309 0
2
0 110 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
1 1
311 0
2
0 112 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut50
3
0 0
1 1
313 0
2
0 114 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut51
3
0 0
1 1
315 0
2
0 116 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut52
3
0 0
1 1
317 0
2
0 118 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut53
3
0 0
1 1
318 0
2
0 120 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut54
3
0 0
1 1
319 0
2
0 122 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut55
3
0 0
1 1
320 0
2
0 124 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut56
3
0 0
1 1
321 0
2
0 126 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
1 1
322 0
2
0 128 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
1 1
323 0
2
0 130 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
1 1
324 0
2
0 132 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
1 1
325 0
2
0 134 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
2 1
223 0
2
0 24 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
2 1
225 0
2
0 26 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
2 1
227 0
2
0 28 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
2 1
229 0
2
0 30 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
2 1
231 0
2
0 32 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
2 1
233 0
2
0 34 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
2 1
235 0
2
0 36 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
2 1
237 0
2
0 38 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
2 1
239 0
2
0 40 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
2 1
241 0
2
0 42 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
2 1
243 0
2
0 44 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
2 1
245 0
2
0 46 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
2 1
247 0
2
0 48 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
2 1
249 0
2
0 50 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
2 1
251 0
2
0 52 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
2 1
253 0
2
0 54 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
2 1
255 0
2
0 56 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
2 1
257 0
2
0 58 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
2 1
259 0
2
0 60 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
2 1
261 0
2
0 62 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
2 1
263 0
2
0 64 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
2 1
265 0
2
0 66 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
2 1
267 0
2
0 68 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
2 1
269 0
2
0 70 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut31
3
0 0
2 1
271 0
2
0 72 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut32
3
0 0
2 1
273 0
2
0 74 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut33
3
0 0
2 1
275 0
2
0 76 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut34
3
0 0
2 1
277 0
2
0 78 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut35
3
0 0
2 1
279 0
2
0 80 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut36
3
0 0
2 1
281 0
2
0 82 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut37
3
0 0
2 1
283 0
2
0 84 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut38
3
0 0
2 1
285 0
2
0 86 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut39
3
0 0
2 1
287 0
2
0 88 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
2 1
289 0
2
0 90 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut40
3
0 0
2 1
291 0
2
0 92 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut41
3
0 0
2 1
293 0
2
0 94 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut42
3
0 0
2 1
295 0
2
0 96 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut43
3
0 0
2 1
297 0
2
0 98 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut44
3
0 0
2 1
299 0
2
0 100 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut45
3
0 0
2 1
301 0
2
0 102 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut46
3
0 0
2 1
303 0
2
0 104 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut47
3
0 0
2 1
305 0
2
0 106 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut48
3
0 0
2 1
307 0
2
0 108 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut49
3
0 0
2 1
309 0
2
0 110 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
2 1
311 0
2
0 112 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut50
3
0 0
2 1
313 0
2
0 114 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut51
3
0 0
2 1
315 0
2
0 116 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut52
3
0 0
2 1
317 0
2
0 118 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut53
3
0 0
2 1
318 0
2
0 120 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut54
3
0 0
2 1
319 0
2
0 122 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut55
3
0 0
2 1
320 0
2
0 124 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut56
3
0 0
2 1
321 0
2
0 126 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
2 1
322 0
2
0 128 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
2 1
323 0
2
0 130 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
2 1
324 0
2
0 132 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
2 1
325 0
2
0 134 0 1
0 327 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut1
3
0 0
3 1
223 0
2
0 24 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut10
3
0 0
3 1
225 0
2
0 26 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut11
3
0 0
3 1
227 0
2
0 28 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut12
3
0 0
3 1
229 0
2
0 30 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut13
3
0 0
3 1
231 0
2
0 32 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut14
3
0 0
3 1
233 0
2
0 34 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut15
3
0 0
3 1
235 0
2
0 36 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut16
3
0 0
3 1
237 0
2
0 38 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut17
3
0 0
3 1
239 0
2
0 40 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut18
3
0 0
3 1
241 0
2
0 42 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut19
3
0 0
3 1
243 0
2
0 44 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut2
3
0 0
3 1
245 0
2
0 46 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut20
3
0 0
3 1
247 0
2
0 48 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut21
3
0 0
3 1
249 0
2
0 50 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut22
3
0 0
3 1
251 0
2
0 52 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut23
3
0 0
3 1
253 0
2
0 54 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut24
3
0 0
3 1
255 0
2
0 56 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut25
3
0 0
3 1
257 0
2
0 58 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut26
3
0 0
3 1
259 0
2
0 60 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut27
3
0 0
3 1
261 0
2
0 62 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut28
3
0 0
3 1
263 0
2
0 64 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut29
3
0 0
3 1
265 0
2
0 66 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut3
3
0 0
3 1
267 0
2
0 68 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut30
3
0 0
3 1
269 0
2
0 70 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut31
3
0 0
3 1
271 0
2
0 72 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut32
3
0 0
3 1
273 0
2
0 74 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut33
3
0 0
3 1
275 0
2
0 76 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut34
3
0 0
3 1
277 0
2
0 78 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut35
3
0 0
3 1
279 0
2
0 80 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut36
3
0 0
3 1
281 0
2
0 82 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut37
3
0 0
3 1
283 0
2
0 84 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut38
3
0 0
3 1
285 0
2
0 86 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut39
3
0 0
3 1
287 0
2
0 88 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut4
3
0 0
3 1
289 0
2
0 90 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut40
3
0 0
3 1
291 0
2
0 92 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut41
3
0 0
3 1
293 0
2
0 94 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut42
3
0 0
3 1
295 0
2
0 96 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut43
3
0 0
3 1
297 0
2
0 98 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut44
3
0 0
3 1
299 0
2
0 100 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut45
3
0 0
3 1
301 0
2
0 102 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut46
3
0 0
3 1
303 0
2
0 104 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut47
3
0 0
3 1
305 0
2
0 106 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut48
3
0 0
3 1
307 0
2
0 108 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut49
3
0 0
3 1
309 0
2
0 110 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut5
3
0 0
3 1
311 0
2
0 112 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut50
3
0 0
3 1
313 0
2
0 114 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut51
3
0 0
3 1
315 0
2
0 116 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut52
3
0 0
3 1
317 0
2
0 118 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut53
3
0 0
3 1
318 0
2
0 120 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut54
3
0 0
3 1
319 0
2
0 122 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut55
3
0 0
3 1
320 0
2
0 124 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut56
3
0 0
3 1
321 0
2
0 126 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut6
3
0 0
3 1
322 0
2
0 128 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut7
3
0 0
3 1
323 0
2
0 130 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut8
3
0 0
3 1
324 0
2
0 132 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut9
3
0 0
3 1
325 0
2
0 134 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut1
3
0 0
4 1
223 0
2
0 24 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut10
3
0 0
4 1
225 0
2
0 26 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut11
3
0 0
4 1
227 0
2
0 28 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut12
3
0 0
4 1
229 0
2
0 30 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut13
3
0 0
4 1
231 0
2
0 32 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut14
3
0 0
4 1
233 0
2
0 34 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut15
3
0 0
4 1
235 0
2
0 36 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut16
3
0 0
4 1
237 0
2
0 38 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut17
3
0 0
4 1
239 0
2
0 40 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut18
3
0 0
4 1
241 0
2
0 42 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut19
3
0 0
4 1
243 0
2
0 44 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut2
3
0 0
4 1
245 0
2
0 46 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut20
3
0 0
4 1
247 0
2
0 48 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut21
3
0 0
4 1
249 0
2
0 50 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut22
3
0 0
4 1
251 0
2
0 52 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut23
3
0 0
4 1
253 0
2
0 54 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut24
3
0 0
4 1
255 0
2
0 56 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut25
3
0 0
4 1
257 0
2
0 58 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut26
3
0 0
4 1
259 0
2
0 60 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut27
3
0 0
4 1
261 0
2
0 62 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut28
3
0 0
4 1
263 0
2
0 64 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut29
3
0 0
4 1
265 0
2
0 66 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut3
3
0 0
4 1
267 0
2
0 68 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut30
3
0 0
4 1
269 0
2
0 70 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut31
3
0 0
4 1
271 0
2
0 72 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut32
3
0 0
4 1
273 0
2
0 74 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut33
3
0 0
4 1
275 0
2
0 76 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut34
3
0 0
4 1
277 0
2
0 78 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut35
3
0 0
4 1
279 0
2
0 80 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut36
3
0 0
4 1
281 0
2
0 82 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut37
3
0 0
4 1
283 0
2
0 84 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut38
3
0 0
4 1
285 0
2
0 86 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut39
3
0 0
4 1
287 0
2
0 88 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut4
3
0 0
4 1
289 0
2
0 90 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut40
3
0 0
4 1
291 0
2
0 92 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut41
3
0 0
4 1
293 0
2
0 94 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut42
3
0 0
4 1
295 0
2
0 96 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut43
3
0 0
4 1
297 0
2
0 98 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut44
3
0 0
4 1
299 0
2
0 100 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut45
3
0 0
4 1
301 0
2
0 102 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut46
3
0 0
4 1
303 0
2
0 104 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut47
3
0 0
4 1
305 0
2
0 106 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut48
3
0 0
4 1
307 0
2
0 108 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut49
3
0 0
4 1
309 0
2
0 110 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut5
3
0 0
4 1
311 0
2
0 112 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut50
3
0 0
4 1
313 0
2
0 114 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut51
3
0 0
4 1
315 0
2
0 116 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut52
3
0 0
4 1
317 0
2
0 118 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut53
3
0 0
4 1
318 0
2
0 120 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut54
3
0 0
4 1
319 0
2
0 122 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut55
3
0 0
4 1
320 0
2
0 124 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut56
3
0 0
4 1
321 0
2
0 126 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut6
3
0 0
4 1
322 0
2
0 128 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut7
3
0 0
4 1
323 0
2
0 130 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut8
3
0 0
4 1
324 0
2
0 132 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut9
3
0 0
4 1
325 0
2
0 134 0 1
0 329 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut1
3
0 0
5 1
223 0
2
0 24 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut10
3
0 0
5 1
225 0
2
0 26 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut11
3
0 0
5 1
227 0
2
0 28 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut12
3
0 0
5 1
229 0
2
0 30 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut13
3
0 0
5 1
231 0
2
0 32 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut14
3
0 0
5 1
233 0
2
0 34 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut15
3
0 0
5 1
235 0
2
0 36 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut16
3
0 0
5 1
237 0
2
0 38 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut17
3
0 0
5 1
239 0
2
0 40 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut18
3
0 0
5 1
241 0
2
0 42 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut19
3
0 0
5 1
243 0
2
0 44 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut2
3
0 0
5 1
245 0
2
0 46 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut20
3
0 0
5 1
247 0
2
0 48 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut21
3
0 0
5 1
249 0
2
0 50 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut22
3
0 0
5 1
251 0
2
0 52 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut23
3
0 0
5 1
253 0
2
0 54 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut24
3
0 0
5 1
255 0
2
0 56 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut25
3
0 0
5 1
257 0
2
0 58 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut26
3
0 0
5 1
259 0
2
0 60 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut27
3
0 0
5 1
261 0
2
0 62 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut28
3
0 0
5 1
263 0
2
0 64 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut29
3
0 0
5 1
265 0
2
0 66 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut3
3
0 0
5 1
267 0
2
0 68 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut30
3
0 0
5 1
269 0
2
0 70 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut31
3
0 0
5 1
271 0
2
0 72 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut32
3
0 0
5 1
273 0
2
0 74 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut33
3
0 0
5 1
275 0
2
0 76 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut34
3
0 0
5 1
277 0
2
0 78 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut35
3
0 0
5 1
279 0
2
0 80 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut36
3
0 0
5 1
281 0
2
0 82 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut37
3
0 0
5 1
283 0
2
0 84 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut38
3
0 0
5 1
285 0
2
0 86 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut39
3
0 0
5 1
287 0
2
0 88 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut4
3
0 0
5 1
289 0
2
0 90 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut40
3
0 0
5 1
291 0
2
0 92 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut41
3
0 0
5 1
293 0
2
0 94 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut42
3
0 0
5 1
295 0
2
0 96 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut43
3
0 0
5 1
297 0
2
0 98 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut44
3
0 0
5 1
299 0
2
0 100 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut45
3
0 0
5 1
301 0
2
0 102 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut46
3
0 0
5 1
303 0
2
0 104 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut47
3
0 0
5 1
305 0
2
0 106 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut48
3
0 0
5 1
307 0
2
0 108 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut49
3
0 0
5 1
309 0
2
0 110 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut5
3
0 0
5 1
311 0
2
0 112 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut50
3
0 0
5 1
313 0
2
0 114 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut51
3
0 0
5 1
315 0
2
0 116 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut52
3
0 0
5 1
317 0
2
0 118 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut53
3
0 0
5 1
318 0
2
0 120 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut54
3
0 0
5 1
319 0
2
0 122 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut55
3
0 0
5 1
320 0
2
0 124 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut56
3
0 0
5 1
321 0
2
0 126 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut6
3
0 0
5 1
322 0
2
0 128 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut7
3
0 0
5 1
323 0
2
0 130 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut8
3
0 0
5 1
324 0
2
0 132 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut9
3
0 0
5 1
325 0
2
0 134 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut1
3
0 0
6 1
223 0
2
0 24 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut10
3
0 0
6 1
225 0
2
0 26 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut11
3
0 0
6 1
227 0
2
0 28 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut12
3
0 0
6 1
229 0
2
0 30 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut13
3
0 0
6 1
231 0
2
0 32 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut14
3
0 0
6 1
233 0
2
0 34 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut15
3
0 0
6 1
235 0
2
0 36 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut16
3
0 0
6 1
237 0
2
0 38 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut17
3
0 0
6 1
239 0
2
0 40 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut18
3
0 0
6 1
241 0
2
0 42 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut19
3
0 0
6 1
243 0
2
0 44 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut2
3
0 0
6 1
245 0
2
0 46 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut20
3
0 0
6 1
247 0
2
0 48 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut21
3
0 0
6 1
249 0
2
0 50 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut22
3
0 0
6 1
251 0
2
0 52 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut23
3
0 0
6 1
253 0
2
0 54 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut24
3
0 0
6 1
255 0
2
0 56 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut25
3
0 0
6 1
257 0
2
0 58 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut26
3
0 0
6 1
259 0
2
0 60 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut27
3
0 0
6 1
261 0
2
0 62 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut28
3
0 0
6 1
263 0
2
0 64 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut29
3
0 0
6 1
265 0
2
0 66 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut3
3
0 0
6 1
267 0
2
0 68 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut30
3
0 0
6 1
269 0
2
0 70 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut31
3
0 0
6 1
271 0
2
0 72 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut32
3
0 0
6 1
273 0
2
0 74 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut33
3
0 0
6 1
275 0
2
0 76 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut34
3
0 0
6 1
277 0
2
0 78 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut35
3
0 0
6 1
279 0
2
0 80 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut36
3
0 0
6 1
281 0
2
0 82 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut37
3
0 0
6 1
283 0
2
0 84 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut38
3
0 0
6 1
285 0
2
0 86 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut39
3
0 0
6 1
287 0
2
0 88 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut4
3
0 0
6 1
289 0
2
0 90 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut40
3
0 0
6 1
291 0
2
0 92 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut41
3
0 0
6 1
293 0
2
0 94 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut42
3
0 0
6 1
295 0
2
0 96 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut43
3
0 0
6 1
297 0
2
0 98 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut44
3
0 0
6 1
299 0
2
0 100 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut45
3
0 0
6 1
301 0
2
0 102 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut46
3
0 0
6 1
303 0
2
0 104 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut47
3
0 0
6 1
305 0
2
0 106 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut48
3
0 0
6 1
307 0
2
0 108 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut49
3
0 0
6 1
309 0
2
0 110 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut5
3
0 0
6 1
311 0
2
0 112 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut50
3
0 0
6 1
313 0
2
0 114 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut51
3
0 0
6 1
315 0
2
0 116 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut52
3
0 0
6 1
317 0
2
0 118 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut53
3
0 0
6 1
318 0
2
0 120 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut54
3
0 0
6 1
319 0
2
0 122 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut55
3
0 0
6 1
320 0
2
0 124 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut56
3
0 0
6 1
321 0
2
0 126 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut6
3
0 0
6 1
322 0
2
0 128 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut7
3
0 0
6 1
323 0
2
0 130 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut8
3
0 0
6 1
324 0
2
0 132 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut9
3
0 0
6 1
325 0
2
0 134 0 1
0 331 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut1
3
0 0
7 1
223 0
2
0 24 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut10
3
0 0
7 1
225 0
2
0 26 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut11
3
0 0
7 1
227 0
2
0 28 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut12
3
0 0
7 1
229 0
2
0 30 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut13
3
0 0
7 1
231 0
2
0 32 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut14
3
0 0
7 1
233 0
2
0 34 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut15
3
0 0
7 1
235 0
2
0 36 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut16
3
0 0
7 1
237 0
2
0 38 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut17
3
0 0
7 1
239 0
2
0 40 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut18
3
0 0
7 1
241 0
2
0 42 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut19
3
0 0
7 1
243 0
2
0 44 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut2
3
0 0
7 1
245 0
2
0 46 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut20
3
0 0
7 1
247 0
2
0 48 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut21
3
0 0
7 1
249 0
2
0 50 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut22
3
0 0
7 1
251 0
2
0 52 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut23
3
0 0
7 1
253 0
2
0 54 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut24
3
0 0
7 1
255 0
2
0 56 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut25
3
0 0
7 1
257 0
2
0 58 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut26
3
0 0
7 1
259 0
2
0 60 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut27
3
0 0
7 1
261 0
2
0 62 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut28
3
0 0
7 1
263 0
2
0 64 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut29
3
0 0
7 1
265 0
2
0 66 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut3
3
0 0
7 1
267 0
2
0 68 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut30
3
0 0
7 1
269 0
2
0 70 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut31
3
0 0
7 1
271 0
2
0 72 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut32
3
0 0
7 1
273 0
2
0 74 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut33
3
0 0
7 1
275 0
2
0 76 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut34
3
0 0
7 1
277 0
2
0 78 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut35
3
0 0
7 1
279 0
2
0 80 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut36
3
0 0
7 1
281 0
2
0 82 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut37
3
0 0
7 1
283 0
2
0 84 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut38
3
0 0
7 1
285 0
2
0 86 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut39
3
0 0
7 1
287 0
2
0 88 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut4
3
0 0
7 1
289 0
2
0 90 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut40
3
0 0
7 1
291 0
2
0 92 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut41
3
0 0
7 1
293 0
2
0 94 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut42
3
0 0
7 1
295 0
2
0 96 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut43
3
0 0
7 1
297 0
2
0 98 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut44
3
0 0
7 1
299 0
2
0 100 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut45
3
0 0
7 1
301 0
2
0 102 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut46
3
0 0
7 1
303 0
2
0 104 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut47
3
0 0
7 1
305 0
2
0 106 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut48
3
0 0
7 1
307 0
2
0 108 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut49
3
0 0
7 1
309 0
2
0 110 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut5
3
0 0
7 1
311 0
2
0 112 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut50
3
0 0
7 1
313 0
2
0 114 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut51
3
0 0
7 1
315 0
2
0 116 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut52
3
0 0
7 1
317 0
2
0 118 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut53
3
0 0
7 1
318 0
2
0 120 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut54
3
0 0
7 1
319 0
2
0 122 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut55
3
0 0
7 1
320 0
2
0 124 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut56
3
0 0
7 1
321 0
2
0 126 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut6
3
0 0
7 1
322 0
2
0 128 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut7
3
0 0
7 1
323 0
2
0 130 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut8
3
0 0
7 1
324 0
2
0 132 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut9
3
0 0
7 1
325 0
2
0 134 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut1
3
0 0
8 1
223 0
2
0 24 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut10
3
0 0
8 1
225 0
2
0 26 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut11
3
0 0
8 1
227 0
2
0 28 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut12
3
0 0
8 1
229 0
2
0 30 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut13
3
0 0
8 1
231 0
2
0 32 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut14
3
0 0
8 1
233 0
2
0 34 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut15
3
0 0
8 1
235 0
2
0 36 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut16
3
0 0
8 1
237 0
2
0 38 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut17
3
0 0
8 1
239 0
2
0 40 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut18
3
0 0
8 1
241 0
2
0 42 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut19
3
0 0
8 1
243 0
2
0 44 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut2
3
0 0
8 1
245 0
2
0 46 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut20
3
0 0
8 1
247 0
2
0 48 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut21
3
0 0
8 1
249 0
2
0 50 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut22
3
0 0
8 1
251 0
2
0 52 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut23
3
0 0
8 1
253 0
2
0 54 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut24
3
0 0
8 1
255 0
2
0 56 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut25
3
0 0
8 1
257 0
2
0 58 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut26
3
0 0
8 1
259 0
2
0 60 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut27
3
0 0
8 1
261 0
2
0 62 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut28
3
0 0
8 1
263 0
2
0 64 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut29
3
0 0
8 1
265 0
2
0 66 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut3
3
0 0
8 1
267 0
2
0 68 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut30
3
0 0
8 1
269 0
2
0 70 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut31
3
0 0
8 1
271 0
2
0 72 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut32
3
0 0
8 1
273 0
2
0 74 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut33
3
0 0
8 1
275 0
2
0 76 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut34
3
0 0
8 1
277 0
2
0 78 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut35
3
0 0
8 1
279 0
2
0 80 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut36
3
0 0
8 1
281 0
2
0 82 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut37
3
0 0
8 1
283 0
2
0 84 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut38
3
0 0
8 1
285 0
2
0 86 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut39
3
0 0
8 1
287 0
2
0 88 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut4
3
0 0
8 1
289 0
2
0 90 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut40
3
0 0
8 1
291 0
2
0 92 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut41
3
0 0
8 1
293 0
2
0 94 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut42
3
0 0
8 1
295 0
2
0 96 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut43
3
0 0
8 1
297 0
2
0 98 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut44
3
0 0
8 1
299 0
2
0 100 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut45
3
0 0
8 1
301 0
2
0 102 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut46
3
0 0
8 1
303 0
2
0 104 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut47
3
0 0
8 1
305 0
2
0 106 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut48
3
0 0
8 1
307 0
2
0 108 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut49
3
0 0
8 1
309 0
2
0 110 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut5
3
0 0
8 1
311 0
2
0 112 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut50
3
0 0
8 1
313 0
2
0 114 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut51
3
0 0
8 1
315 0
2
0 116 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut52
3
0 0
8 1
317 0
2
0 118 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut53
3
0 0
8 1
318 0
2
0 120 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut54
3
0 0
8 1
319 0
2
0 122 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut55
3
0 0
8 1
320 0
2
0 124 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut56
3
0 0
8 1
321 0
2
0 126 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut6
3
0 0
8 1
322 0
2
0 128 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut7
3
0 0
8 1
323 0
2
0 130 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut8
3
0 0
8 1
324 0
2
0 132 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut9
3
0 0
8 1
325 0
2
0 134 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut1
3
0 0
9 1
223 0
2
0 24 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut10
3
0 0
9 1
225 0
2
0 26 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut11
3
0 0
9 1
227 0
2
0 28 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut12
3
0 0
9 1
229 0
2
0 30 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut13
3
0 0
9 1
231 0
2
0 32 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut14
3
0 0
9 1
233 0
2
0 34 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut15
3
0 0
9 1
235 0
2
0 36 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut16
3
0 0
9 1
237 0
2
0 38 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut17
3
0 0
9 1
239 0
2
0 40 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut18
3
0 0
9 1
241 0
2
0 42 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut19
3
0 0
9 1
243 0
2
0 44 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut2
3
0 0
9 1
245 0
2
0 46 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut20
3
0 0
9 1
247 0
2
0 48 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut21
3
0 0
9 1
249 0
2
0 50 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut22
3
0 0
9 1
251 0
2
0 52 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut23
3
0 0
9 1
253 0
2
0 54 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut24
3
0 0
9 1
255 0
2
0 56 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut25
3
0 0
9 1
257 0
2
0 58 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut26
3
0 0
9 1
259 0
2
0 60 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut27
3
0 0
9 1
261 0
2
0 62 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut28
3
0 0
9 1
263 0
2
0 64 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut29
3
0 0
9 1
265 0
2
0 66 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut3
3
0 0
9 1
267 0
2
0 68 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut30
3
0 0
9 1
269 0
2
0 70 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut31
3
0 0
9 1
271 0
2
0 72 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut32
3
0 0
9 1
273 0
2
0 74 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut33
3
0 0
9 1
275 0
2
0 76 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut34
3
0 0
9 1
277 0
2
0 78 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut35
3
0 0
9 1
279 0
2
0 80 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut36
3
0 0
9 1
281 0
2
0 82 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut37
3
0 0
9 1
283 0
2
0 84 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut38
3
0 0
9 1
285 0
2
0 86 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut39
3
0 0
9 1
287 0
2
0 88 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut4
3
0 0
9 1
289 0
2
0 90 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut40
3
0 0
9 1
291 0
2
0 92 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut41
3
0 0
9 1
293 0
2
0 94 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut42
3
0 0
9 1
295 0
2
0 96 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut43
3
0 0
9 1
297 0
2
0 98 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut44
3
0 0
9 1
299 0
2
0 100 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut45
3
0 0
9 1
301 0
2
0 102 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut46
3
0 0
9 1
303 0
2
0 104 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut47
3
0 0
9 1
305 0
2
0 106 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut48
3
0 0
9 1
307 0
2
0 108 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut49
3
0 0
9 1
309 0
2
0 110 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut5
3
0 0
9 1
311 0
2
0 112 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut50
3
0 0
9 1
313 0
2
0 114 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut51
3
0 0
9 1
315 0
2
0 116 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut52
3
0 0
9 1
317 0
2
0 118 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut53
3
0 0
9 1
318 0
2
0 120 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut54
3
0 0
9 1
319 0
2
0 122 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut55
3
0 0
9 1
320 0
2
0 124 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut56
3
0 0
9 1
321 0
2
0 126 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut6
3
0 0
9 1
322 0
2
0 128 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut7
3
0 0
9 1
323 0
2
0 130 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut8
3
0 0
9 1
324 0
2
0 132 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut9
3
0 0
9 1
325 0
2
0 134 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut1
3
0 0
10 1
223 0
2
0 24 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut10
3
0 0
10 1
225 0
2
0 26 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut11
3
0 0
10 1
227 0
2
0 28 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut12
3
0 0
10 1
229 0
2
0 30 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut13
3
0 0
10 1
231 0
2
0 32 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut14
3
0 0
10 1
233 0
2
0 34 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut15
3
0 0
10 1
235 0
2
0 36 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut16
3
0 0
10 1
237 0
2
0 38 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut17
3
0 0
10 1
239 0
2
0 40 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut18
3
0 0
10 1
241 0
2
0 42 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut19
3
0 0
10 1
243 0
2
0 44 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut2
3
0 0
10 1
245 0
2
0 46 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut20
3
0 0
10 1
247 0
2
0 48 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut21
3
0 0
10 1
249 0
2
0 50 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut22
3
0 0
10 1
251 0
2
0 52 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut23
3
0 0
10 1
253 0
2
0 54 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut24
3
0 0
10 1
255 0
2
0 56 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut25
3
0 0
10 1
257 0
2
0 58 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut26
3
0 0
10 1
259 0
2
0 60 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut27
3
0 0
10 1
261 0
2
0 62 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut28
3
0 0
10 1
263 0
2
0 64 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut29
3
0 0
10 1
265 0
2
0 66 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut3
3
0 0
10 1
267 0
2
0 68 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut30
3
0 0
10 1
269 0
2
0 70 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut31
3
0 0
10 1
271 0
2
0 72 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut32
3
0 0
10 1
273 0
2
0 74 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut33
3
0 0
10 1
275 0
2
0 76 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut34
3
0 0
10 1
277 0
2
0 78 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut35
3
0 0
10 1
279 0
2
0 80 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut36
3
0 0
10 1
281 0
2
0 82 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut37
3
0 0
10 1
283 0
2
0 84 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut38
3
0 0
10 1
285 0
2
0 86 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut39
3
0 0
10 1
287 0
2
0 88 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut4
3
0 0
10 1
289 0
2
0 90 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut40
3
0 0
10 1
291 0
2
0 92 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut41
3
0 0
10 1
293 0
2
0 94 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut42
3
0 0
10 1
295 0
2
0 96 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut43
3
0 0
10 1
297 0
2
0 98 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut44
3
0 0
10 1
299 0
2
0 100 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut45
3
0 0
10 1
301 0
2
0 102 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut46
3
0 0
10 1
303 0
2
0 104 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut47
3
0 0
10 1
305 0
2
0 106 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut48
3
0 0
10 1
307 0
2
0 108 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut49
3
0 0
10 1
309 0
2
0 110 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut5
3
0 0
10 1
311 0
2
0 112 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut50
3
0 0
10 1
313 0
2
0 114 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut51
3
0 0
10 1
315 0
2
0 116 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut52
3
0 0
10 1
317 0
2
0 118 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut53
3
0 0
10 1
318 0
2
0 120 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut54
3
0 0
10 1
319 0
2
0 122 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut55
3
0 0
10 1
320 0
2
0 124 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut56
3
0 0
10 1
321 0
2
0 126 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut6
3
0 0
10 1
322 0
2
0 128 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut7
3
0 0
10 1
323 0
2
0 130 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut8
3
0 0
10 1
324 0
2
0 132 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut9
3
0 0
10 1
325 0
2
0 134 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut1
3
0 0
11 1
223 0
2
0 24 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut10
3
0 0
11 1
225 0
2
0 26 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut11
3
0 0
11 1
227 0
2
0 28 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut12
3
0 0
11 1
229 0
2
0 30 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut13
3
0 0
11 1
231 0
2
0 32 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut14
3
0 0
11 1
233 0
2
0 34 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut15
3
0 0
11 1
235 0
2
0 36 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut16
3
0 0
11 1
237 0
2
0 38 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut17
3
0 0
11 1
239 0
2
0 40 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut18
3
0 0
11 1
241 0
2
0 42 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut19
3
0 0
11 1
243 0
2
0 44 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut2
3
0 0
11 1
245 0
2
0 46 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut20
3
0 0
11 1
247 0
2
0 48 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut21
3
0 0
11 1
249 0
2
0 50 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut22
3
0 0
11 1
251 0
2
0 52 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut23
3
0 0
11 1
253 0
2
0 54 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut24
3
0 0
11 1
255 0
2
0 56 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut25
3
0 0
11 1
257 0
2
0 58 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut26
3
0 0
11 1
259 0
2
0 60 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut27
3
0 0
11 1
261 0
2
0 62 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut28
3
0 0
11 1
263 0
2
0 64 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut29
3
0 0
11 1
265 0
2
0 66 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut3
3
0 0
11 1
267 0
2
0 68 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut30
3
0 0
11 1
269 0
2
0 70 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut31
3
0 0
11 1
271 0
2
0 72 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut32
3
0 0
11 1
273 0
2
0 74 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut33
3
0 0
11 1
275 0
2
0 76 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut34
3
0 0
11 1
277 0
2
0 78 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut35
3
0 0
11 1
279 0
2
0 80 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut36
3
0 0
11 1
281 0
2
0 82 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut37
3
0 0
11 1
283 0
2
0 84 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut38
3
0 0
11 1
285 0
2
0 86 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut39
3
0 0
11 1
287 0
2
0 88 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut4
3
0 0
11 1
289 0
2
0 90 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut40
3
0 0
11 1
291 0
2
0 92 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut41
3
0 0
11 1
293 0
2
0 94 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut42
3
0 0
11 1
295 0
2
0 96 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut43
3
0 0
11 1
297 0
2
0 98 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut44
3
0 0
11 1
299 0
2
0 100 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut45
3
0 0
11 1
301 0
2
0 102 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut46
3
0 0
11 1
303 0
2
0 104 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut47
3
0 0
11 1
305 0
2
0 106 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut48
3
0 0
11 1
307 0
2
0 108 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut49
3
0 0
11 1
309 0
2
0 110 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut5
3
0 0
11 1
311 0
2
0 112 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut50
3
0 0
11 1
313 0
2
0 114 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut51
3
0 0
11 1
315 0
2
0 116 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut52
3
0 0
11 1
317 0
2
0 118 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut53
3
0 0
11 1
318 0
2
0 120 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut54
3
0 0
11 1
319 0
2
0 122 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut55
3
0 0
11 1
320 0
2
0 124 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut56
3
0 0
11 1
321 0
2
0 126 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut6
3
0 0
11 1
322 0
2
0 128 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut7
3
0 0
11 1
323 0
2
0 130 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut8
3
0 0
11 1
324 0
2
0 132 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut9
3
0 0
11 1
325 0
2
0 134 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut1
3
0 0
12 1
223 0
2
0 24 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut10
3
0 0
12 1
225 0
2
0 26 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut11
3
0 0
12 1
227 0
2
0 28 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut12
3
0 0
12 1
229 0
2
0 30 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut13
3
0 0
12 1
231 0
2
0 32 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut14
3
0 0
12 1
233 0
2
0 34 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut15
3
0 0
12 1
235 0
2
0 36 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut16
3
0 0
12 1
237 0
2
0 38 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut17
3
0 0
12 1
239 0
2
0 40 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut18
3
0 0
12 1
241 0
2
0 42 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut19
3
0 0
12 1
243 0
2
0 44 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut2
3
0 0
12 1
245 0
2
0 46 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut20
3
0 0
12 1
247 0
2
0 48 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut21
3
0 0
12 1
249 0
2
0 50 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut22
3
0 0
12 1
251 0
2
0 52 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut23
3
0 0
12 1
253 0
2
0 54 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut24
3
0 0
12 1
255 0
2
0 56 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut25
3
0 0
12 1
257 0
2
0 58 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut26
3
0 0
12 1
259 0
2
0 60 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut27
3
0 0
12 1
261 0
2
0 62 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut28
3
0 0
12 1
263 0
2
0 64 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut29
3
0 0
12 1
265 0
2
0 66 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut3
3
0 0
12 1
267 0
2
0 68 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut30
3
0 0
12 1
269 0
2
0 70 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut31
3
0 0
12 1
271 0
2
0 72 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut32
3
0 0
12 1
273 0
2
0 74 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut33
3
0 0
12 1
275 0
2
0 76 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut34
3
0 0
12 1
277 0
2
0 78 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut35
3
0 0
12 1
279 0
2
0 80 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut36
3
0 0
12 1
281 0
2
0 82 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut37
3
0 0
12 1
283 0
2
0 84 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut38
3
0 0
12 1
285 0
2
0 86 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut39
3
0 0
12 1
287 0
2
0 88 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut4
3
0 0
12 1
289 0
2
0 90 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut40
3
0 0
12 1
291 0
2
0 92 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut41
3
0 0
12 1
293 0
2
0 94 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut42
3
0 0
12 1
295 0
2
0 96 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut43
3
0 0
12 1
297 0
2
0 98 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut44
3
0 0
12 1
299 0
2
0 100 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut45
3
0 0
12 1
301 0
2
0 102 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut46
3
0 0
12 1
303 0
2
0 104 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut47
3
0 0
12 1
305 0
2
0 106 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut48
3
0 0
12 1
307 0
2
0 108 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut49
3
0 0
12 1
309 0
2
0 110 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut5
3
0 0
12 1
311 0
2
0 112 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut50
3
0 0
12 1
313 0
2
0 114 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut51
3
0 0
12 1
315 0
2
0 116 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut52
3
0 0
12 1
317 0
2
0 118 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut53
3
0 0
12 1
318 0
2
0 120 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut54
3
0 0
12 1
319 0
2
0 122 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut55
3
0 0
12 1
320 0
2
0 124 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut56
3
0 0
12 1
321 0
2
0 126 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut6
3
0 0
12 1
322 0
2
0 128 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut7
3
0 0
12 1
323 0
2
0 130 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut8
3
0 0
12 1
324 0
2
0 132 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut9
3
0 0
12 1
325 0
2
0 134 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
13 1
223 0
2
0 24 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
13 1
225 0
2
0 26 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
13 1
227 0
2
0 28 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
13 1
229 0
2
0 30 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
13 1
231 0
2
0 32 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
13 1
233 0
2
0 34 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
13 1
235 0
2
0 36 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
13 1
237 0
2
0 38 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
13 1
239 0
2
0 40 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
13 1
241 0
2
0 42 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
13 1
243 0
2
0 44 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
13 1
245 0
2
0 46 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
13 1
247 0
2
0 48 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
13 1
249 0
2
0 50 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
13 1
251 0
2
0 52 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
13 1
253 0
2
0 54 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
13 1
255 0
2
0 56 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
13 1
257 0
2
0 58 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
13 1
259 0
2
0 60 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
13 1
261 0
2
0 62 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
13 1
263 0
2
0 64 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
13 1
265 0
2
0 66 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
13 1
267 0
2
0 68 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
13 1
269 0
2
0 70 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut31
3
0 0
13 1
271 0
2
0 72 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut32
3
0 0
13 1
273 0
2
0 74 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut33
3
0 0
13 1
275 0
2
0 76 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut34
3
0 0
13 1
277 0
2
0 78 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut35
3
0 0
13 1
279 0
2
0 80 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut36
3
0 0
13 1
281 0
2
0 82 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut37
3
0 0
13 1
283 0
2
0 84 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut38
3
0 0
13 1
285 0
2
0 86 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut39
3
0 0
13 1
287 0
2
0 88 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
13 1
289 0
2
0 90 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut40
3
0 0
13 1
291 0
2
0 92 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut41
3
0 0
13 1
293 0
2
0 94 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut42
3
0 0
13 1
295 0
2
0 96 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut43
3
0 0
13 1
297 0
2
0 98 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut44
3
0 0
13 1
299 0
2
0 100 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut45
3
0 0
13 1
301 0
2
0 102 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut46
3
0 0
13 1
303 0
2
0 104 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut47
3
0 0
13 1
305 0
2
0 106 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut48
3
0 0
13 1
307 0
2
0 108 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut49
3
0 0
13 1
309 0
2
0 110 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
13 1
311 0
2
0 112 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut50
3
0 0
13 1
313 0
2
0 114 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut51
3
0 0
13 1
315 0
2
0 116 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut52
3
0 0
13 1
317 0
2
0 118 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut53
3
0 0
13 1
318 0
2
0 120 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut54
3
0 0
13 1
319 0
2
0 122 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut55
3
0 0
13 1
320 0
2
0 124 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut56
3
0 0
13 1
321 0
2
0 126 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
13 1
322 0
2
0 128 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
13 1
323 0
2
0 130 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
13 1
324 0
2
0 132 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
13 1
325 0
2
0 134 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut1
3
0 0
14 1
223 0
2
0 24 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut10
3
0 0
14 1
225 0
2
0 26 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut11
3
0 0
14 1
227 0
2
0 28 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut12
3
0 0
14 1
229 0
2
0 30 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut13
3
0 0
14 1
231 0
2
0 32 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut14
3
0 0
14 1
233 0
2
0 34 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut15
3
0 0
14 1
235 0
2
0 36 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut16
3
0 0
14 1
237 0
2
0 38 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut17
3
0 0
14 1
239 0
2
0 40 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut18
3
0 0
14 1
241 0
2
0 42 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut19
3
0 0
14 1
243 0
2
0 44 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut2
3
0 0
14 1
245 0
2
0 46 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut20
3
0 0
14 1
247 0
2
0 48 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut21
3
0 0
14 1
249 0
2
0 50 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut22
3
0 0
14 1
251 0
2
0 52 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut23
3
0 0
14 1
253 0
2
0 54 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut24
3
0 0
14 1
255 0
2
0 56 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut25
3
0 0
14 1
257 0
2
0 58 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut26
3
0 0
14 1
259 0
2
0 60 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut27
3
0 0
14 1
261 0
2
0 62 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut28
3
0 0
14 1
263 0
2
0 64 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut29
3
0 0
14 1
265 0
2
0 66 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut3
3
0 0
14 1
267 0
2
0 68 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut30
3
0 0
14 1
269 0
2
0 70 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut31
3
0 0
14 1
271 0
2
0 72 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut32
3
0 0
14 1
273 0
2
0 74 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut33
3
0 0
14 1
275 0
2
0 76 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut34
3
0 0
14 1
277 0
2
0 78 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut35
3
0 0
14 1
279 0
2
0 80 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut36
3
0 0
14 1
281 0
2
0 82 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut37
3
0 0
14 1
283 0
2
0 84 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut38
3
0 0
14 1
285 0
2
0 86 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut39
3
0 0
14 1
287 0
2
0 88 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut4
3
0 0
14 1
289 0
2
0 90 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut40
3
0 0
14 1
291 0
2
0 92 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut41
3
0 0
14 1
293 0
2
0 94 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut42
3
0 0
14 1
295 0
2
0 96 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut43
3
0 0
14 1
297 0
2
0 98 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut44
3
0 0
14 1
299 0
2
0 100 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut45
3
0 0
14 1
301 0
2
0 102 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut46
3
0 0
14 1
303 0
2
0 104 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut47
3
0 0
14 1
305 0
2
0 106 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut48
3
0 0
14 1
307 0
2
0 108 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut49
3
0 0
14 1
309 0
2
0 110 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut5
3
0 0
14 1
311 0
2
0 112 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut50
3
0 0
14 1
313 0
2
0 114 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut51
3
0 0
14 1
315 0
2
0 116 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut52
3
0 0
14 1
317 0
2
0 118 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut53
3
0 0
14 1
318 0
2
0 120 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut54
3
0 0
14 1
319 0
2
0 122 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut55
3
0 0
14 1
320 0
2
0 124 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut56
3
0 0
14 1
321 0
2
0 126 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut6
3
0 0
14 1
322 0
2
0 128 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut7
3
0 0
14 1
323 0
2
0 130 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut8
3
0 0
14 1
324 0
2
0 132 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut9
3
0 0
14 1
325 0
2
0 134 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut1
3
0 0
15 1
223 0
2
0 24 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut10
3
0 0
15 1
225 0
2
0 26 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut11
3
0 0
15 1
227 0
2
0 28 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut12
3
0 0
15 1
229 0
2
0 30 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut13
3
0 0
15 1
231 0
2
0 32 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut14
3
0 0
15 1
233 0
2
0 34 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut15
3
0 0
15 1
235 0
2
0 36 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut16
3
0 0
15 1
237 0
2
0 38 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut17
3
0 0
15 1
239 0
2
0 40 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut18
3
0 0
15 1
241 0
2
0 42 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut19
3
0 0
15 1
243 0
2
0 44 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut2
3
0 0
15 1
245 0
2
0 46 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut20
3
0 0
15 1
247 0
2
0 48 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut21
3
0 0
15 1
249 0
2
0 50 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut22
3
0 0
15 1
251 0
2
0 52 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut23
3
0 0
15 1
253 0
2
0 54 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut24
3
0 0
15 1
255 0
2
0 56 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut25
3
0 0
15 1
257 0
2
0 58 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut26
3
0 0
15 1
259 0
2
0 60 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut27
3
0 0
15 1
261 0
2
0 62 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut28
3
0 0
15 1
263 0
2
0 64 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut29
3
0 0
15 1
265 0
2
0 66 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut3
3
0 0
15 1
267 0
2
0 68 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut30
3
0 0
15 1
269 0
2
0 70 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut31
3
0 0
15 1
271 0
2
0 72 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut32
3
0 0
15 1
273 0
2
0 74 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut33
3
0 0
15 1
275 0
2
0 76 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut34
3
0 0
15 1
277 0
2
0 78 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut35
3
0 0
15 1
279 0
2
0 80 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut36
3
0 0
15 1
281 0
2
0 82 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut37
3
0 0
15 1
283 0
2
0 84 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut38
3
0 0
15 1
285 0
2
0 86 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut39
3
0 0
15 1
287 0
2
0 88 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut4
3
0 0
15 1
289 0
2
0 90 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut40
3
0 0
15 1
291 0
2
0 92 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut41
3
0 0
15 1
293 0
2
0 94 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut42
3
0 0
15 1
295 0
2
0 96 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut43
3
0 0
15 1
297 0
2
0 98 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut44
3
0 0
15 1
299 0
2
0 100 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut45
3
0 0
15 1
301 0
2
0 102 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut46
3
0 0
15 1
303 0
2
0 104 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut47
3
0 0
15 1
305 0
2
0 106 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut48
3
0 0
15 1
307 0
2
0 108 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut49
3
0 0
15 1
309 0
2
0 110 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut5
3
0 0
15 1
311 0
2
0 112 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut50
3
0 0
15 1
313 0
2
0 114 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut51
3
0 0
15 1
315 0
2
0 116 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut52
3
0 0
15 1
317 0
2
0 118 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut53
3
0 0
15 1
318 0
2
0 120 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut54
3
0 0
15 1
319 0
2
0 122 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut55
3
0 0
15 1
320 0
2
0 124 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut56
3
0 0
15 1
321 0
2
0 126 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut6
3
0 0
15 1
322 0
2
0 128 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut7
3
0 0
15 1
323 0
2
0 130 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut8
3
0 0
15 1
324 0
2
0 132 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut9
3
0 0
15 1
325 0
2
0 134 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut1
3
0 0
16 1
223 0
2
0 24 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut10
3
0 0
16 1
225 0
2
0 26 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut11
3
0 0
16 1
227 0
2
0 28 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut12
3
0 0
16 1
229 0
2
0 30 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut13
3
0 0
16 1
231 0
2
0 32 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut14
3
0 0
16 1
233 0
2
0 34 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut15
3
0 0
16 1
235 0
2
0 36 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut16
3
0 0
16 1
237 0
2
0 38 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut17
3
0 0
16 1
239 0
2
0 40 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut18
3
0 0
16 1
241 0
2
0 42 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut19
3
0 0
16 1
243 0
2
0 44 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut2
3
0 0
16 1
245 0
2
0 46 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut20
3
0 0
16 1
247 0
2
0 48 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut21
3
0 0
16 1
249 0
2
0 50 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut22
3
0 0
16 1
251 0
2
0 52 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut23
3
0 0
16 1
253 0
2
0 54 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut24
3
0 0
16 1
255 0
2
0 56 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut25
3
0 0
16 1
257 0
2
0 58 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut26
3
0 0
16 1
259 0
2
0 60 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut27
3
0 0
16 1
261 0
2
0 62 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut28
3
0 0
16 1
263 0
2
0 64 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut29
3
0 0
16 1
265 0
2
0 66 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut3
3
0 0
16 1
267 0
2
0 68 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut30
3
0 0
16 1
269 0
2
0 70 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut31
3
0 0
16 1
271 0
2
0 72 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut32
3
0 0
16 1
273 0
2
0 74 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut33
3
0 0
16 1
275 0
2
0 76 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut34
3
0 0
16 1
277 0
2
0 78 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut35
3
0 0
16 1
279 0
2
0 80 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut36
3
0 0
16 1
281 0
2
0 82 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut37
3
0 0
16 1
283 0
2
0 84 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut38
3
0 0
16 1
285 0
2
0 86 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut39
3
0 0
16 1
287 0
2
0 88 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut4
3
0 0
16 1
289 0
2
0 90 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut40
3
0 0
16 1
291 0
2
0 92 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut41
3
0 0
16 1
293 0
2
0 94 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut42
3
0 0
16 1
295 0
2
0 96 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut43
3
0 0
16 1
297 0
2
0 98 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut44
3
0 0
16 1
299 0
2
0 100 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut45
3
0 0
16 1
301 0
2
0 102 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut46
3
0 0
16 1
303 0
2
0 104 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut47
3
0 0
16 1
305 0
2
0 106 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut48
3
0 0
16 1
307 0
2
0 108 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut49
3
0 0
16 1
309 0
2
0 110 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut5
3
0 0
16 1
311 0
2
0 112 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut50
3
0 0
16 1
313 0
2
0 114 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut51
3
0 0
16 1
315 0
2
0 116 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut52
3
0 0
16 1
317 0
2
0 118 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut53
3
0 0
16 1
318 0
2
0 120 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut54
3
0 0
16 1
319 0
2
0 122 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut55
3
0 0
16 1
320 0
2
0 124 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut56
3
0 0
16 1
321 0
2
0 126 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut6
3
0 0
16 1
322 0
2
0 128 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut7
3
0 0
16 1
323 0
2
0 130 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut8
3
0 0
16 1
324 0
2
0 132 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut9
3
0 0
16 1
325 0
2
0 134 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut1
3
0 0
17 1
223 0
2
0 24 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut10
3
0 0
17 1
225 0
2
0 26 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut11
3
0 0
17 1
227 0
2
0 28 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut12
3
0 0
17 1
229 0
2
0 30 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut13
3
0 0
17 1
231 0
2
0 32 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut14
3
0 0
17 1
233 0
2
0 34 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut15
3
0 0
17 1
235 0
2
0 36 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut16
3
0 0
17 1
237 0
2
0 38 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut17
3
0 0
17 1
239 0
2
0 40 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut18
3
0 0
17 1
241 0
2
0 42 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut19
3
0 0
17 1
243 0
2
0 44 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut2
3
0 0
17 1
245 0
2
0 46 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut20
3
0 0
17 1
247 0
2
0 48 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut21
3
0 0
17 1
249 0
2
0 50 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut22
3
0 0
17 1
251 0
2
0 52 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut23
3
0 0
17 1
253 0
2
0 54 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut24
3
0 0
17 1
255 0
2
0 56 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut25
3
0 0
17 1
257 0
2
0 58 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut26
3
0 0
17 1
259 0
2
0 60 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut27
3
0 0
17 1
261 0
2
0 62 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut28
3
0 0
17 1
263 0
2
0 64 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut29
3
0 0
17 1
265 0
2
0 66 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut3
3
0 0
17 1
267 0
2
0 68 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut30
3
0 0
17 1
269 0
2
0 70 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut31
3
0 0
17 1
271 0
2
0 72 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut32
3
0 0
17 1
273 0
2
0 74 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut33
3
0 0
17 1
275 0
2
0 76 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut34
3
0 0
17 1
277 0
2
0 78 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut35
3
0 0
17 1
279 0
2
0 80 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut36
3
0 0
17 1
281 0
2
0 82 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut37
3
0 0
17 1
283 0
2
0 84 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut38
3
0 0
17 1
285 0
2
0 86 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut39
3
0 0
17 1
287 0
2
0 88 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut4
3
0 0
17 1
289 0
2
0 90 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut40
3
0 0
17 1
291 0
2
0 92 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut41
3
0 0
17 1
293 0
2
0 94 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut42
3
0 0
17 1
295 0
2
0 96 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut43
3
0 0
17 1
297 0
2
0 98 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut44
3
0 0
17 1
299 0
2
0 100 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut45
3
0 0
17 1
301 0
2
0 102 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut46
3
0 0
17 1
303 0
2
0 104 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut47
3
0 0
17 1
305 0
2
0 106 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut48
3
0 0
17 1
307 0
2
0 108 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut49
3
0 0
17 1
309 0
2
0 110 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut5
3
0 0
17 1
311 0
2
0 112 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut50
3
0 0
17 1
313 0
2
0 114 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut51
3
0 0
17 1
315 0
2
0 116 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut52
3
0 0
17 1
317 0
2
0 118 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut53
3
0 0
17 1
318 0
2
0 120 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut54
3
0 0
17 1
319 0
2
0 122 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut55
3
0 0
17 1
320 0
2
0 124 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut56
3
0 0
17 1
321 0
2
0 126 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut6
3
0 0
17 1
322 0
2
0 128 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut7
3
0 0
17 1
323 0
2
0 130 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut8
3
0 0
17 1
324 0
2
0 132 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut9
3
0 0
17 1
325 0
2
0 134 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
18 1
223 0
2
0 24 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
18 1
225 0
2
0 26 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
18 1
227 0
2
0 28 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
18 1
229 0
2
0 30 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
18 1
231 0
2
0 32 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
18 1
233 0
2
0 34 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
18 1
235 0
2
0 36 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
18 1
237 0
2
0 38 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
18 1
239 0
2
0 40 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
18 1
241 0
2
0 42 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
18 1
243 0
2
0 44 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
18 1
245 0
2
0 46 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
18 1
247 0
2
0 48 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
18 1
249 0
2
0 50 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
18 1
251 0
2
0 52 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
18 1
253 0
2
0 54 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
18 1
255 0
2
0 56 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
18 1
257 0
2
0 58 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
18 1
259 0
2
0 60 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
18 1
261 0
2
0 62 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
18 1
263 0
2
0 64 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
18 1
265 0
2
0 66 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
18 1
267 0
2
0 68 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
18 1
269 0
2
0 70 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut31
3
0 0
18 1
271 0
2
0 72 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut32
3
0 0
18 1
273 0
2
0 74 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut33
3
0 0
18 1
275 0
2
0 76 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut34
3
0 0
18 1
277 0
2
0 78 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut35
3
0 0
18 1
279 0
2
0 80 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut36
3
0 0
18 1
281 0
2
0 82 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut37
3
0 0
18 1
283 0
2
0 84 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut38
3
0 0
18 1
285 0
2
0 86 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut39
3
0 0
18 1
287 0
2
0 88 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
18 1
289 0
2
0 90 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut40
3
0 0
18 1
291 0
2
0 92 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut41
3
0 0
18 1
293 0
2
0 94 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut42
3
0 0
18 1
295 0
2
0 96 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut43
3
0 0
18 1
297 0
2
0 98 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut44
3
0 0
18 1
299 0
2
0 100 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut45
3
0 0
18 1
301 0
2
0 102 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut46
3
0 0
18 1
303 0
2
0 104 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut47
3
0 0
18 1
305 0
2
0 106 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut48
3
0 0
18 1
307 0
2
0 108 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut49
3
0 0
18 1
309 0
2
0 110 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
18 1
311 0
2
0 112 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut50
3
0 0
18 1
313 0
2
0 114 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut51
3
0 0
18 1
315 0
2
0 116 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut52
3
0 0
18 1
317 0
2
0 118 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut53
3
0 0
18 1
318 0
2
0 120 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut54
3
0 0
18 1
319 0
2
0 122 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut55
3
0 0
18 1
320 0
2
0 124 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut56
3
0 0
18 1
321 0
2
0 126 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
18 1
322 0
2
0 128 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
18 1
323 0
2
0 130 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
18 1
324 0
2
0 132 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
18 1
325 0
2
0 134 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
19 1
223 0
2
0 24 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
19 1
225 0
2
0 26 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
19 1
227 0
2
0 28 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
19 1
229 0
2
0 30 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
19 1
231 0
2
0 32 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
19 1
233 0
2
0 34 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
19 1
235 0
2
0 36 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
19 1
237 0
2
0 38 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
19 1
239 0
2
0 40 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
19 1
241 0
2
0 42 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
19 1
243 0
2
0 44 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
19 1
245 0
2
0 46 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
19 1
247 0
2
0 48 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
19 1
249 0
2
0 50 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
19 1
251 0
2
0 52 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
19 1
253 0
2
0 54 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
19 1
255 0
2
0 56 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
19 1
257 0
2
0 58 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
19 1
259 0
2
0 60 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
19 1
261 0
2
0 62 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
19 1
263 0
2
0 64 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
19 1
265 0
2
0 66 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
19 1
267 0
2
0 68 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
19 1
269 0
2
0 70 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut31
3
0 0
19 1
271 0
2
0 72 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut32
3
0 0
19 1
273 0
2
0 74 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut33
3
0 0
19 1
275 0
2
0 76 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut34
3
0 0
19 1
277 0
2
0 78 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut35
3
0 0
19 1
279 0
2
0 80 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut36
3
0 0
19 1
281 0
2
0 82 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut37
3
0 0
19 1
283 0
2
0 84 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut38
3
0 0
19 1
285 0
2
0 86 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut39
3
0 0
19 1
287 0
2
0 88 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
19 1
289 0
2
0 90 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut40
3
0 0
19 1
291 0
2
0 92 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut41
3
0 0
19 1
293 0
2
0 94 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut42
3
0 0
19 1
295 0
2
0 96 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut43
3
0 0
19 1
297 0
2
0 98 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut44
3
0 0
19 1
299 0
2
0 100 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut45
3
0 0
19 1
301 0
2
0 102 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut46
3
0 0
19 1
303 0
2
0 104 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut47
3
0 0
19 1
305 0
2
0 106 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut48
3
0 0
19 1
307 0
2
0 108 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut49
3
0 0
19 1
309 0
2
0 110 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
19 1
311 0
2
0 112 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut50
3
0 0
19 1
313 0
2
0 114 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut51
3
0 0
19 1
315 0
2
0 116 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut52
3
0 0
19 1
317 0
2
0 118 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut53
3
0 0
19 1
318 0
2
0 120 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut54
3
0 0
19 1
319 0
2
0 122 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut55
3
0 0
19 1
320 0
2
0 124 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut56
3
0 0
19 1
321 0
2
0 126 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
19 1
322 0
2
0 128 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
19 1
323 0
2
0 130 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
19 1
324 0
2
0 132 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
19 1
325 0
2
0 134 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
20 1
223 0
2
0 24 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
20 1
225 0
2
0 26 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
20 1
227 0
2
0 28 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
20 1
229 0
2
0 30 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
20 1
231 0
2
0 32 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
20 1
233 0
2
0 34 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
20 1
235 0
2
0 36 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
20 1
237 0
2
0 38 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
20 1
239 0
2
0 40 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
20 1
241 0
2
0 42 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
20 1
243 0
2
0 44 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
20 1
245 0
2
0 46 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
20 1
247 0
2
0 48 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
20 1
249 0
2
0 50 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
20 1
251 0
2
0 52 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
20 1
253 0
2
0 54 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
20 1
255 0
2
0 56 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
20 1
257 0
2
0 58 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
20 1
259 0
2
0 60 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
20 1
261 0
2
0 62 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
20 1
263 0
2
0 64 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
20 1
265 0
2
0 66 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
20 1
267 0
2
0 68 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
20 1
269 0
2
0 70 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut31
3
0 0
20 1
271 0
2
0 72 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut32
3
0 0
20 1
273 0
2
0 74 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut33
3
0 0
20 1
275 0
2
0 76 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut34
3
0 0
20 1
277 0
2
0 78 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut35
3
0 0
20 1
279 0
2
0 80 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut36
3
0 0
20 1
281 0
2
0 82 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut37
3
0 0
20 1
283 0
2
0 84 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut38
3
0 0
20 1
285 0
2
0 86 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut39
3
0 0
20 1
287 0
2
0 88 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
20 1
289 0
2
0 90 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut40
3
0 0
20 1
291 0
2
0 92 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut41
3
0 0
20 1
293 0
2
0 94 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut42
3
0 0
20 1
295 0
2
0 96 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut43
3
0 0
20 1
297 0
2
0 98 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut44
3
0 0
20 1
299 0
2
0 100 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut45
3
0 0
20 1
301 0
2
0 102 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut46
3
0 0
20 1
303 0
2
0 104 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut47
3
0 0
20 1
305 0
2
0 106 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut48
3
0 0
20 1
307 0
2
0 108 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut49
3
0 0
20 1
309 0
2
0 110 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
20 1
311 0
2
0 112 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut50
3
0 0
20 1
313 0
2
0 114 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut51
3
0 0
20 1
315 0
2
0 116 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut52
3
0 0
20 1
317 0
2
0 118 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut53
3
0 0
20 1
318 0
2
0 120 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut54
3
0 0
20 1
319 0
2
0 122 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut55
3
0 0
20 1
320 0
2
0 124 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut56
3
0 0
20 1
321 0
2
0 126 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
20 1
322 0
2
0 128 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
20 1
323 0
2
0 130 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
20 1
324 0
2
0 132 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
20 1
325 0
2
0 134 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
21 1
223 0
2
0 24 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
21 1
225 0
2
0 26 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
21 1
227 0
2
0 28 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
21 1
229 0
2
0 30 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
21 1
231 0
2
0 32 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
21 1
233 0
2
0 34 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
21 1
235 0
2
0 36 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
21 1
237 0
2
0 38 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
21 1
239 0
2
0 40 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
21 1
241 0
2
0 42 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
21 1
243 0
2
0 44 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
21 1
245 0
2
0 46 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
21 1
247 0
2
0 48 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
21 1
249 0
2
0 50 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
21 1
251 0
2
0 52 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
21 1
253 0
2
0 54 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
21 1
255 0
2
0 56 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
21 1
257 0
2
0 58 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
21 1
259 0
2
0 60 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
21 1
261 0
2
0 62 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
21 1
263 0
2
0 64 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
21 1
265 0
2
0 66 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
21 1
267 0
2
0 68 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
21 1
269 0
2
0 70 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut31
3
0 0
21 1
271 0
2
0 72 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut32
3
0 0
21 1
273 0
2
0 74 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut33
3
0 0
21 1
275 0
2
0 76 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut34
3
0 0
21 1
277 0
2
0 78 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut35
3
0 0
21 1
279 0
2
0 80 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut36
3
0 0
21 1
281 0
2
0 82 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut37
3
0 0
21 1
283 0
2
0 84 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut38
3
0 0
21 1
285 0
2
0 86 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut39
3
0 0
21 1
287 0
2
0 88 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
21 1
289 0
2
0 90 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut40
3
0 0
21 1
291 0
2
0 92 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut41
3
0 0
21 1
293 0
2
0 94 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut42
3
0 0
21 1
295 0
2
0 96 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut43
3
0 0
21 1
297 0
2
0 98 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut44
3
0 0
21 1
299 0
2
0 100 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut45
3
0 0
21 1
301 0
2
0 102 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut46
3
0 0
21 1
303 0
2
0 104 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut47
3
0 0
21 1
305 0
2
0 106 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut48
3
0 0
21 1
307 0
2
0 108 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut49
3
0 0
21 1
309 0
2
0 110 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
21 1
311 0
2
0 112 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut50
3
0 0
21 1
313 0
2
0 114 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut51
3
0 0
21 1
315 0
2
0 116 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut52
3
0 0
21 1
317 0
2
0 118 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut53
3
0 0
21 1
318 0
2
0 120 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut54
3
0 0
21 1
319 0
2
0 122 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut55
3
0 0
21 1
320 0
2
0 124 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut56
3
0 0
21 1
321 0
2
0 126 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
21 1
322 0
2
0 128 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
21 1
323 0
2
0 130 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
21 1
324 0
2
0 132 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
21 1
325 0
2
0 134 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
22 1
223 0
2
0 24 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
22 1
225 0
2
0 26 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
22 1
227 0
2
0 28 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
22 1
229 0
2
0 30 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
22 1
231 0
2
0 32 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
22 1
233 0
2
0 34 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
22 1
235 0
2
0 36 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
22 1
237 0
2
0 38 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
22 1
239 0
2
0 40 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
22 1
241 0
2
0 42 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
22 1
243 0
2
0 44 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
22 1
245 0
2
0 46 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
22 1
247 0
2
0 48 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
22 1
249 0
2
0 50 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
22 1
251 0
2
0 52 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
22 1
253 0
2
0 54 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
22 1
255 0
2
0 56 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
22 1
257 0
2
0 58 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
22 1
259 0
2
0 60 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
22 1
261 0
2
0 62 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
22 1
263 0
2
0 64 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
22 1
265 0
2
0 66 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
22 1
267 0
2
0 68 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
22 1
269 0
2
0 70 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut31
3
0 0
22 1
271 0
2
0 72 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut32
3
0 0
22 1
273 0
2
0 74 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut33
3
0 0
22 1
275 0
2
0 76 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut34
3
0 0
22 1
277 0
2
0 78 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut35
3
0 0
22 1
279 0
2
0 80 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut36
3
0 0
22 1
281 0
2
0 82 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut37
3
0 0
22 1
283 0
2
0 84 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut38
3
0 0
22 1
285 0
2
0 86 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut39
3
0 0
22 1
287 0
2
0 88 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
22 1
289 0
2
0 90 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut40
3
0 0
22 1
291 0
2
0 92 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut41
3
0 0
22 1
293 0
2
0 94 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut42
3
0 0
22 1
295 0
2
0 96 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut43
3
0 0
22 1
297 0
2
0 98 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut44
3
0 0
22 1
299 0
2
0 100 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut45
3
0 0
22 1
301 0
2
0 102 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut46
3
0 0
22 1
303 0
2
0 104 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut47
3
0 0
22 1
305 0
2
0 106 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut48
3
0 0
22 1
307 0
2
0 108 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut49
3
0 0
22 1
309 0
2
0 110 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
22 1
311 0
2
0 112 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut50
3
0 0
22 1
313 0
2
0 114 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut51
3
0 0
22 1
315 0
2
0 116 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut52
3
0 0
22 1
317 0
2
0 118 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut53
3
0 0
22 1
318 0
2
0 120 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut54
3
0 0
22 1
319 0
2
0 122 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut55
3
0 0
22 1
320 0
2
0 124 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut56
3
0 0
22 1
321 0
2
0 126 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
22 1
322 0
2
0 128 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
22 1
323 0
2
0 130 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
22 1
324 0
2
0 132 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
22 1
325 0
2
0 134 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
23 1
223 0
2
0 24 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
23 1
225 0
2
0 26 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
23 1
227 0
2
0 28 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
23 1
229 0
2
0 30 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
23 1
231 0
2
0 32 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
23 1
233 0
2
0 34 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
23 1
235 0
2
0 36 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
23 1
237 0
2
0 38 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
23 1
239 0
2
0 40 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
23 1
241 0
2
0 42 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
23 1
243 0
2
0 44 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
23 1
245 0
2
0 46 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
23 1
247 0
2
0 48 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
23 1
249 0
2
0 50 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
23 1
251 0
2
0 52 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
23 1
253 0
2
0 54 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
23 1
255 0
2
0 56 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
23 1
257 0
2
0 58 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
23 1
259 0
2
0 60 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
23 1
261 0
2
0 62 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
23 1
263 0
2
0 64 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
23 1
265 0
2
0 66 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
23 1
267 0
2
0 68 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
23 1
269 0
2
0 70 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut31
3
0 0
23 1
271 0
2
0 72 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut32
3
0 0
23 1
273 0
2
0 74 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut33
3
0 0
23 1
275 0
2
0 76 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut34
3
0 0
23 1
277 0
2
0 78 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut35
3
0 0
23 1
279 0
2
0 80 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut36
3
0 0
23 1
281 0
2
0 82 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut37
3
0 0
23 1
283 0
2
0 84 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut38
3
0 0
23 1
285 0
2
0 86 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut39
3
0 0
23 1
287 0
2
0 88 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
23 1
289 0
2
0 90 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut40
3
0 0
23 1
291 0
2
0 92 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut41
3
0 0
23 1
293 0
2
0 94 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut42
3
0 0
23 1
295 0
2
0 96 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut43
3
0 0
23 1
297 0
2
0 98 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut44
3
0 0
23 1
299 0
2
0 100 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut45
3
0 0
23 1
301 0
2
0 102 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut46
3
0 0
23 1
303 0
2
0 104 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut47
3
0 0
23 1
305 0
2
0 106 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut48
3
0 0
23 1
307 0
2
0 108 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut49
3
0 0
23 1
309 0
2
0 110 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
23 1
311 0
2
0 112 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut50
3
0 0
23 1
313 0
2
0 114 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut51
3
0 0
23 1
315 0
2
0 116 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut52
3
0 0
23 1
317 0
2
0 118 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut53
3
0 0
23 1
318 0
2
0 120 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut54
3
0 0
23 1
319 0
2
0 122 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut55
3
0 0
23 1
320 0
2
0 124 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut56
3
0 0
23 1
321 0
2
0 126 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
23 1
322 0
2
0 128 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
23 1
323 0
2
0 130 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
23 1
324 0
2
0 132 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
23 1
325 0
2
0 134 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
25 1
223 0
2
0 24 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
25 1
225 0
2
0 26 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
25 1
227 0
2
0 28 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
25 1
229 0
2
0 30 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
25 1
231 0
2
0 32 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
25 1
233 0
2
0 34 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
25 1
235 0
2
0 36 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
25 1
237 0
2
0 38 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
25 1
239 0
2
0 40 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
25 1
241 0
2
0 42 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
25 1
243 0
2
0 44 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
25 1
245 0
2
0 46 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
25 1
247 0
2
0 48 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
25 1
249 0
2
0 50 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
25 1
251 0
2
0 52 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
25 1
253 0
2
0 54 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
25 1
255 0
2
0 56 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
25 1
257 0
2
0 58 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
25 1
259 0
2
0 60 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
25 1
261 0
2
0 62 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
25 1
263 0
2
0 64 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
25 1
265 0
2
0 66 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
25 1
267 0
2
0 68 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
25 1
269 0
2
0 70 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut31
3
0 0
25 1
271 0
2
0 72 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut32
3
0 0
25 1
273 0
2
0 74 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut33
3
0 0
25 1
275 0
2
0 76 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut34
3
0 0
25 1
277 0
2
0 78 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut35
3
0 0
25 1
279 0
2
0 80 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut36
3
0 0
25 1
281 0
2
0 82 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut37
3
0 0
25 1
283 0
2
0 84 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut38
3
0 0
25 1
285 0
2
0 86 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut39
3
0 0
25 1
287 0
2
0 88 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
25 1
289 0
2
0 90 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut40
3
0 0
25 1
291 0
2
0 92 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut41
3
0 0
25 1
293 0
2
0 94 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut42
3
0 0
25 1
295 0
2
0 96 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut43
3
0 0
25 1
297 0
2
0 98 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut44
3
0 0
25 1
299 0
2
0 100 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut45
3
0 0
25 1
301 0
2
0 102 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut46
3
0 0
25 1
303 0
2
0 104 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut47
3
0 0
25 1
305 0
2
0 106 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut48
3
0 0
25 1
307 0
2
0 108 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut49
3
0 0
25 1
309 0
2
0 110 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
25 1
311 0
2
0 112 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut50
3
0 0
25 1
313 0
2
0 114 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut51
3
0 0
25 1
315 0
2
0 116 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut52
3
0 0
25 1
317 0
2
0 118 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut53
3
0 0
25 1
318 0
2
0 120 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut54
3
0 0
25 1
319 0
2
0 122 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut55
3
0 0
25 1
320 0
2
0 124 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut56
3
0 0
25 1
321 0
2
0 126 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
25 1
322 0
2
0 128 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
25 1
323 0
2
0 130 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
25 1
324 0
2
0 132 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
25 1
325 0
2
0 134 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
27 1
223 0
2
0 24 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
27 1
225 0
2
0 26 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
27 1
227 0
2
0 28 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
27 1
229 0
2
0 30 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
27 1
231 0
2
0 32 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
27 1
233 0
2
0 34 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
27 1
235 0
2
0 36 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
27 1
237 0
2
0 38 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
27 1
239 0
2
0 40 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
27 1
241 0
2
0 42 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
27 1
243 0
2
0 44 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
27 1
245 0
2
0 46 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
27 1
247 0
2
0 48 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
27 1
249 0
2
0 50 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
27 1
251 0
2
0 52 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
27 1
253 0
2
0 54 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
27 1
255 0
2
0 56 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
27 1
257 0
2
0 58 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
27 1
259 0
2
0 60 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
27 1
261 0
2
0 62 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
27 1
263 0
2
0 64 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
27 1
265 0
2
0 66 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
27 1
267 0
2
0 68 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
27 1
269 0
2
0 70 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut31
3
0 0
27 1
271 0
2
0 72 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut32
3
0 0
27 1
273 0
2
0 74 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut33
3
0 0
27 1
275 0
2
0 76 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut34
3
0 0
27 1
277 0
2
0 78 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut35
3
0 0
27 1
279 0
2
0 80 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut36
3
0 0
27 1
281 0
2
0 82 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut37
3
0 0
27 1
283 0
2
0 84 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut38
3
0 0
27 1
285 0
2
0 86 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut39
3
0 0
27 1
287 0
2
0 88 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
27 1
289 0
2
0 90 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut40
3
0 0
27 1
291 0
2
0 92 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut41
3
0 0
27 1
293 0
2
0 94 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut42
3
0 0
27 1
295 0
2
0 96 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut43
3
0 0
27 1
297 0
2
0 98 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut44
3
0 0
27 1
299 0
2
0 100 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut45
3
0 0
27 1
301 0
2
0 102 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut46
3
0 0
27 1
303 0
2
0 104 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut47
3
0 0
27 1
305 0
2
0 106 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut48
3
0 0
27 1
307 0
2
0 108 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut49
3
0 0
27 1
309 0
2
0 110 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
27 1
311 0
2
0 112 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut50
3
0 0
27 1
313 0
2
0 114 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut51
3
0 0
27 1
315 0
2
0 116 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut52
3
0 0
27 1
317 0
2
0 118 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut53
3
0 0
27 1
318 0
2
0 120 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut54
3
0 0
27 1
319 0
2
0 122 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut55
3
0 0
27 1
320 0
2
0 124 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut56
3
0 0
27 1
321 0
2
0 126 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
27 1
322 0
2
0 128 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
27 1
323 0
2
0 130 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
27 1
324 0
2
0 132 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
27 1
325 0
2
0 134 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
29 1
223 0
2
0 24 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
29 1
225 0
2
0 26 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
29 1
227 0
2
0 28 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
29 1
229 0
2
0 30 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
29 1
231 0
2
0 32 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
29 1
233 0
2
0 34 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
29 1
235 0
2
0 36 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
29 1
237 0
2
0 38 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
29 1
239 0
2
0 40 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
29 1
241 0
2
0 42 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
29 1
243 0
2
0 44 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
29 1
245 0
2
0 46 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
29 1
247 0
2
0 48 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
29 1
249 0
2
0 50 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
29 1
251 0
2
0 52 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
29 1
253 0
2
0 54 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
29 1
255 0
2
0 56 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
29 1
257 0
2
0 58 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
29 1
259 0
2
0 60 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
29 1
261 0
2
0 62 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
29 1
263 0
2
0 64 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
29 1
265 0
2
0 66 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
29 1
267 0
2
0 68 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
29 1
269 0
2
0 70 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut31
3
0 0
29 1
271 0
2
0 72 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut32
3
0 0
29 1
273 0
2
0 74 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut33
3
0 0
29 1
275 0
2
0 76 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut34
3
0 0
29 1
277 0
2
0 78 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut35
3
0 0
29 1
279 0
2
0 80 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut36
3
0 0
29 1
281 0
2
0 82 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut37
3
0 0
29 1
283 0
2
0 84 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut38
3
0 0
29 1
285 0
2
0 86 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut39
3
0 0
29 1
287 0
2
0 88 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
29 1
289 0
2
0 90 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut40
3
0 0
29 1
291 0
2
0 92 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut41
3
0 0
29 1
293 0
2
0 94 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut42
3
0 0
29 1
295 0
2
0 96 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut43
3
0 0
29 1
297 0
2
0 98 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut44
3
0 0
29 1
299 0
2
0 100 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut45
3
0 0
29 1
301 0
2
0 102 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut46
3
0 0
29 1
303 0
2
0 104 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut47
3
0 0
29 1
305 0
2
0 106 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut48
3
0 0
29 1
307 0
2
0 108 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut49
3
0 0
29 1
309 0
2
0 110 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
29 1
311 0
2
0 112 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut50
3
0 0
29 1
313 0
2
0 114 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut51
3
0 0
29 1
315 0
2
0 116 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut52
3
0 0
29 1
317 0
2
0 118 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut53
3
0 0
29 1
318 0
2
0 120 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut54
3
0 0
29 1
319 0
2
0 122 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut55
3
0 0
29 1
320 0
2
0 124 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut56
3
0 0
29 1
321 0
2
0 126 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
29 1
322 0
2
0 128 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
29 1
323 0
2
0 130 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
29 1
324 0
2
0 132 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
29 1
325 0
2
0 134 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
31 1
223 0
2
0 24 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
31 1
225 0
2
0 26 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
31 1
227 0
2
0 28 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
31 1
229 0
2
0 30 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
31 1
231 0
2
0 32 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
31 1
233 0
2
0 34 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
31 1
235 0
2
0 36 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
31 1
237 0
2
0 38 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
31 1
239 0
2
0 40 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
31 1
241 0
2
0 42 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
31 1
243 0
2
0 44 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
31 1
245 0
2
0 46 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
31 1
247 0
2
0 48 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
31 1
249 0
2
0 50 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
31 1
251 0
2
0 52 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
31 1
253 0
2
0 54 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
31 1
255 0
2
0 56 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
31 1
257 0
2
0 58 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
31 1
259 0
2
0 60 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
31 1
261 0
2
0 62 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
31 1
263 0
2
0 64 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
31 1
265 0
2
0 66 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
31 1
267 0
2
0 68 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
31 1
269 0
2
0 70 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut31
3
0 0
31 1
271 0
2
0 72 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut32
3
0 0
31 1
273 0
2
0 74 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut33
3
0 0
31 1
275 0
2
0 76 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut34
3
0 0
31 1
277 0
2
0 78 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut35
3
0 0
31 1
279 0
2
0 80 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut36
3
0 0
31 1
281 0
2
0 82 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut37
3
0 0
31 1
283 0
2
0 84 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut38
3
0 0
31 1
285 0
2
0 86 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut39
3
0 0
31 1
287 0
2
0 88 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
31 1
289 0
2
0 90 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut40
3
0 0
31 1
291 0
2
0 92 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut41
3
0 0
31 1
293 0
2
0 94 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut42
3
0 0
31 1
295 0
2
0 96 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut43
3
0 0
31 1
297 0
2
0 98 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut44
3
0 0
31 1
299 0
2
0 100 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut45
3
0 0
31 1
301 0
2
0 102 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut46
3
0 0
31 1
303 0
2
0 104 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut47
3
0 0
31 1
305 0
2
0 106 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut48
3
0 0
31 1
307 0
2
0 108 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut49
3
0 0
31 1
309 0
2
0 110 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
31 1
311 0
2
0 112 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut50
3
0 0
31 1
313 0
2
0 114 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut51
3
0 0
31 1
315 0
2
0 116 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut52
3
0 0
31 1
317 0
2
0 118 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut53
3
0 0
31 1
318 0
2
0 120 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut54
3
0 0
31 1
319 0
2
0 122 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut55
3
0 0
31 1
320 0
2
0 124 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut56
3
0 0
31 1
321 0
2
0 126 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
31 1
322 0
2
0 128 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
31 1
323 0
2
0 130 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
31 1
324 0
2
0 132 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
31 1
325 0
2
0 134 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
33 1
223 0
2
0 24 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
33 1
225 0
2
0 26 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
33 1
227 0
2
0 28 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
33 1
229 0
2
0 30 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
33 1
231 0
2
0 32 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
33 1
233 0
2
0 34 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
33 1
235 0
2
0 36 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
33 1
237 0
2
0 38 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
33 1
239 0
2
0 40 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
33 1
241 0
2
0 42 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
33 1
243 0
2
0 44 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
33 1
245 0
2
0 46 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
33 1
247 0
2
0 48 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
33 1
249 0
2
0 50 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
33 1
251 0
2
0 52 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
33 1
253 0
2
0 54 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
33 1
255 0
2
0 56 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
33 1
257 0
2
0 58 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
33 1
259 0
2
0 60 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
33 1
261 0
2
0 62 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
33 1
263 0
2
0 64 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
33 1
265 0
2
0 66 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
33 1
267 0
2
0 68 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
33 1
269 0
2
0 70 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut31
3
0 0
33 1
271 0
2
0 72 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut32
3
0 0
33 1
273 0
2
0 74 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut33
3
0 0
33 1
275 0
2
0 76 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut34
3
0 0
33 1
277 0
2
0 78 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut35
3
0 0
33 1
279 0
2
0 80 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut36
3
0 0
33 1
281 0
2
0 82 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut37
3
0 0
33 1
283 0
2
0 84 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut38
3
0 0
33 1
285 0
2
0 86 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut39
3
0 0
33 1
287 0
2
0 88 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
33 1
289 0
2
0 90 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut40
3
0 0
33 1
291 0
2
0 92 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut41
3
0 0
33 1
293 0
2
0 94 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut42
3
0 0
33 1
295 0
2
0 96 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut43
3
0 0
33 1
297 0
2
0 98 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut44
3
0 0
33 1
299 0
2
0 100 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut45
3
0 0
33 1
301 0
2
0 102 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut46
3
0 0
33 1
303 0
2
0 104 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut47
3
0 0
33 1
305 0
2
0 106 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut48
3
0 0
33 1
307 0
2
0 108 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut49
3
0 0
33 1
309 0
2
0 110 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
33 1
311 0
2
0 112 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut50
3
0 0
33 1
313 0
2
0 114 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut51
3
0 0
33 1
315 0
2
0 116 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut52
3
0 0
33 1
317 0
2
0 118 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut53
3
0 0
33 1
318 0
2
0 120 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut54
3
0 0
33 1
319 0
2
0 122 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut55
3
0 0
33 1
320 0
2
0 124 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut56
3
0 0
33 1
321 0
2
0 126 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
33 1
322 0
2
0 128 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
33 1
323 0
2
0 130 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
33 1
324 0
2
0 132 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
33 1
325 0
2
0 134 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
35 1
223 0
2
0 24 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
35 1
225 0
2
0 26 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
35 1
227 0
2
0 28 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
35 1
229 0
2
0 30 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
35 1
231 0
2
0 32 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
35 1
233 0
2
0 34 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
35 1
235 0
2
0 36 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
35 1
237 0
2
0 38 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
35 1
239 0
2
0 40 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
35 1
241 0
2
0 42 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
35 1
243 0
2
0 44 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
35 1
245 0
2
0 46 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
35 1
247 0
2
0 48 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
35 1
249 0
2
0 50 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
35 1
251 0
2
0 52 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
35 1
253 0
2
0 54 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
35 1
255 0
2
0 56 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
35 1
257 0
2
0 58 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
35 1
259 0
2
0 60 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
35 1
261 0
2
0 62 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
35 1
263 0
2
0 64 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
35 1
265 0
2
0 66 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
35 1
267 0
2
0 68 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
35 1
269 0
2
0 70 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut31
3
0 0
35 1
271 0
2
0 72 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut32
3
0 0
35 1
273 0
2
0 74 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut33
3
0 0
35 1
275 0
2
0 76 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut34
3
0 0
35 1
277 0
2
0 78 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut35
3
0 0
35 1
279 0
2
0 80 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut36
3
0 0
35 1
281 0
2
0 82 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut37
3
0 0
35 1
283 0
2
0 84 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut38
3
0 0
35 1
285 0
2
0 86 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut39
3
0 0
35 1
287 0
2
0 88 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
35 1
289 0
2
0 90 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut40
3
0 0
35 1
291 0
2
0 92 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut41
3
0 0
35 1
293 0
2
0 94 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut42
3
0 0
35 1
295 0
2
0 96 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut43
3
0 0
35 1
297 0
2
0 98 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut44
3
0 0
35 1
299 0
2
0 100 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut45
3
0 0
35 1
301 0
2
0 102 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut46
3
0 0
35 1
303 0
2
0 104 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut47
3
0 0
35 1
305 0
2
0 106 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut48
3
0 0
35 1
307 0
2
0 108 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut49
3
0 0
35 1
309 0
2
0 110 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
35 1
311 0
2
0 112 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut50
3
0 0
35 1
313 0
2
0 114 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut51
3
0 0
35 1
315 0
2
0 116 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut52
3
0 0
35 1
317 0
2
0 118 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut53
3
0 0
35 1
318 0
2
0 120 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut54
3
0 0
35 1
319 0
2
0 122 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut55
3
0 0
35 1
320 0
2
0 124 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut56
3
0 0
35 1
321 0
2
0 126 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
35 1
322 0
2
0 128 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
35 1
323 0
2
0 130 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
35 1
324 0
2
0 132 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
35 1
325 0
2
0 134 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
37 1
223 0
2
0 24 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
37 1
225 0
2
0 26 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
37 1
227 0
2
0 28 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
37 1
229 0
2
0 30 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
37 1
231 0
2
0 32 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
37 1
233 0
2
0 34 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
37 1
235 0
2
0 36 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
37 1
237 0
2
0 38 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
37 1
239 0
2
0 40 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
37 1
241 0
2
0 42 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
37 1
243 0
2
0 44 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
37 1
245 0
2
0 46 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
37 1
247 0
2
0 48 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
37 1
249 0
2
0 50 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
37 1
251 0
2
0 52 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
37 1
253 0
2
0 54 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
37 1
255 0
2
0 56 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
37 1
257 0
2
0 58 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
37 1
259 0
2
0 60 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
37 1
261 0
2
0 62 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
37 1
263 0
2
0 64 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
37 1
265 0
2
0 66 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
37 1
267 0
2
0 68 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
37 1
269 0
2
0 70 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut31
3
0 0
37 1
271 0
2
0 72 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut32
3
0 0
37 1
273 0
2
0 74 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut33
3
0 0
37 1
275 0
2
0 76 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut34
3
0 0
37 1
277 0
2
0 78 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut35
3
0 0
37 1
279 0
2
0 80 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut36
3
0 0
37 1
281 0
2
0 82 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut37
3
0 0
37 1
283 0
2
0 84 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut38
3
0 0
37 1
285 0
2
0 86 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut39
3
0 0
37 1
287 0
2
0 88 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
37 1
289 0
2
0 90 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut40
3
0 0
37 1
291 0
2
0 92 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut41
3
0 0
37 1
293 0
2
0 94 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut42
3
0 0
37 1
295 0
2
0 96 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut43
3
0 0
37 1
297 0
2
0 98 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut44
3
0 0
37 1
299 0
2
0 100 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut45
3
0 0
37 1
301 0
2
0 102 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut46
3
0 0
37 1
303 0
2
0 104 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut47
3
0 0
37 1
305 0
2
0 106 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut48
3
0 0
37 1
307 0
2
0 108 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut49
3
0 0
37 1
309 0
2
0 110 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
37 1
311 0
2
0 112 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut50
3
0 0
37 1
313 0
2
0 114 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut51
3
0 0
37 1
315 0
2
0 116 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut52
3
0 0
37 1
317 0
2
0 118 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut53
3
0 0
37 1
318 0
2
0 120 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut54
3
0 0
37 1
319 0
2
0 122 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut55
3
0 0
37 1
320 0
2
0 124 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut56
3
0 0
37 1
321 0
2
0 126 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
37 1
322 0
2
0 128 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
37 1
323 0
2
0 130 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
37 1
324 0
2
0 132 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
37 1
325 0
2
0 134 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
39 1
223 0
2
0 24 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
39 1
225 0
2
0 26 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
39 1
227 0
2
0 28 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
39 1
229 0
2
0 30 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
39 1
231 0
2
0 32 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
39 1
233 0
2
0 34 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
39 1
235 0
2
0 36 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
39 1
237 0
2
0 38 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
39 1
239 0
2
0 40 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
39 1
241 0
2
0 42 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
39 1
243 0
2
0 44 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
39 1
245 0
2
0 46 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
39 1
247 0
2
0 48 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
39 1
249 0
2
0 50 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
39 1
251 0
2
0 52 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
39 1
253 0
2
0 54 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
39 1
255 0
2
0 56 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
39 1
257 0
2
0 58 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
39 1
259 0
2
0 60 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
39 1
261 0
2
0 62 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
39 1
263 0
2
0 64 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
39 1
265 0
2
0 66 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
39 1
267 0
2
0 68 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
39 1
269 0
2
0 70 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut31
3
0 0
39 1
271 0
2
0 72 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut32
3
0 0
39 1
273 0
2
0 74 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut33
3
0 0
39 1
275 0
2
0 76 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut34
3
0 0
39 1
277 0
2
0 78 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut35
3
0 0
39 1
279 0
2
0 80 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut36
3
0 0
39 1
281 0
2
0 82 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut37
3
0 0
39 1
283 0
2
0 84 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut38
3
0 0
39 1
285 0
2
0 86 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut39
3
0 0
39 1
287 0
2
0 88 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
39 1
289 0
2
0 90 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut40
3
0 0
39 1
291 0
2
0 92 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut41
3
0 0
39 1
293 0
2
0 94 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut42
3
0 0
39 1
295 0
2
0 96 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut43
3
0 0
39 1
297 0
2
0 98 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut44
3
0 0
39 1
299 0
2
0 100 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut45
3
0 0
39 1
301 0
2
0 102 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut46
3
0 0
39 1
303 0
2
0 104 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut47
3
0 0
39 1
305 0
2
0 106 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut48
3
0 0
39 1
307 0
2
0 108 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut49
3
0 0
39 1
309 0
2
0 110 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
39 1
311 0
2
0 112 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut50
3
0 0
39 1
313 0
2
0 114 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut51
3
0 0
39 1
315 0
2
0 116 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut52
3
0 0
39 1
317 0
2
0 118 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut53
3
0 0
39 1
318 0
2
0 120 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut54
3
0 0
39 1
319 0
2
0 122 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut55
3
0 0
39 1
320 0
2
0 124 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut56
3
0 0
39 1
321 0
2
0 126 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
39 1
322 0
2
0 128 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
39 1
323 0
2
0 130 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
39 1
324 0
2
0 132 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
39 1
325 0
2
0 134 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
41 1
223 0
2
0 24 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
41 1
225 0
2
0 26 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
41 1
227 0
2
0 28 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
41 1
229 0
2
0 30 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
41 1
231 0
2
0 32 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
41 1
233 0
2
0 34 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
41 1
235 0
2
0 36 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
41 1
237 0
2
0 38 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
41 1
239 0
2
0 40 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
41 1
241 0
2
0 42 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
41 1
243 0
2
0 44 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
41 1
245 0
2
0 46 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
41 1
247 0
2
0 48 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
41 1
249 0
2
0 50 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
41 1
251 0
2
0 52 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
41 1
253 0
2
0 54 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
41 1
255 0
2
0 56 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
41 1
257 0
2
0 58 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
41 1
259 0
2
0 60 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
41 1
261 0
2
0 62 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
41 1
263 0
2
0 64 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
41 1
265 0
2
0 66 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
41 1
267 0
2
0 68 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
41 1
269 0
2
0 70 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut31
3
0 0
41 1
271 0
2
0 72 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut32
3
0 0
41 1
273 0
2
0 74 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut33
3
0 0
41 1
275 0
2
0 76 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut34
3
0 0
41 1
277 0
2
0 78 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut35
3
0 0
41 1
279 0
2
0 80 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut36
3
0 0
41 1
281 0
2
0 82 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut37
3
0 0
41 1
283 0
2
0 84 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut38
3
0 0
41 1
285 0
2
0 86 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut39
3
0 0
41 1
287 0
2
0 88 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
41 1
289 0
2
0 90 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut40
3
0 0
41 1
291 0
2
0 92 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut41
3
0 0
41 1
293 0
2
0 94 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut42
3
0 0
41 1
295 0
2
0 96 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut43
3
0 0
41 1
297 0
2
0 98 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut44
3
0 0
41 1
299 0
2
0 100 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut45
3
0 0
41 1
301 0
2
0 102 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut46
3
0 0
41 1
303 0
2
0 104 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut47
3
0 0
41 1
305 0
2
0 106 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut48
3
0 0
41 1
307 0
2
0 108 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut49
3
0 0
41 1
309 0
2
0 110 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
41 1
311 0
2
0 112 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut50
3
0 0
41 1
313 0
2
0 114 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut51
3
0 0
41 1
315 0
2
0 116 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut52
3
0 0
41 1
317 0
2
0 118 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut53
3
0 0
41 1
318 0
2
0 120 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut54
3
0 0
41 1
319 0
2
0 122 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut55
3
0 0
41 1
320 0
2
0 124 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut56
3
0 0
41 1
321 0
2
0 126 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
41 1
322 0
2
0 128 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
41 1
323 0
2
0 130 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
41 1
324 0
2
0 132 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
41 1
325 0
2
0 134 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
43 1
223 0
2
0 24 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
43 1
225 0
2
0 26 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
43 1
227 0
2
0 28 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
43 1
229 0
2
0 30 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
43 1
231 0
2
0 32 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
43 1
233 0
2
0 34 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
43 1
235 0
2
0 36 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
43 1
237 0
2
0 38 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
43 1
239 0
2
0 40 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
43 1
241 0
2
0 42 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
43 1
243 0
2
0 44 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
43 1
245 0
2
0 46 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
43 1
247 0
2
0 48 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
43 1
249 0
2
0 50 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
43 1
251 0
2
0 52 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
43 1
253 0
2
0 54 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
43 1
255 0
2
0 56 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
43 1
257 0
2
0 58 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
43 1
259 0
2
0 60 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
43 1
261 0
2
0 62 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
43 1
263 0
2
0 64 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
43 1
265 0
2
0 66 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
43 1
267 0
2
0 68 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
43 1
269 0
2
0 70 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut31
3
0 0
43 1
271 0
2
0 72 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut32
3
0 0
43 1
273 0
2
0 74 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut33
3
0 0
43 1
275 0
2
0 76 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut34
3
0 0
43 1
277 0
2
0 78 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut35
3
0 0
43 1
279 0
2
0 80 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut36
3
0 0
43 1
281 0
2
0 82 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut37
3
0 0
43 1
283 0
2
0 84 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut38
3
0 0
43 1
285 0
2
0 86 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut39
3
0 0
43 1
287 0
2
0 88 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
43 1
289 0
2
0 90 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut40
3
0 0
43 1
291 0
2
0 92 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut41
3
0 0
43 1
293 0
2
0 94 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut42
3
0 0
43 1
295 0
2
0 96 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut43
3
0 0
43 1
297 0
2
0 98 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut44
3
0 0
43 1
299 0
2
0 100 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut45
3
0 0
43 1
301 0
2
0 102 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut46
3
0 0
43 1
303 0
2
0 104 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut47
3
0 0
43 1
305 0
2
0 106 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut48
3
0 0
43 1
307 0
2
0 108 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut49
3
0 0
43 1
309 0
2
0 110 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
43 1
311 0
2
0 112 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut50
3
0 0
43 1
313 0
2
0 114 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut51
3
0 0
43 1
315 0
2
0 116 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut52
3
0 0
43 1
317 0
2
0 118 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut53
3
0 0
43 1
318 0
2
0 120 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut54
3
0 0
43 1
319 0
2
0 122 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut55
3
0 0
43 1
320 0
2
0 124 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut56
3
0 0
43 1
321 0
2
0 126 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
43 1
322 0
2
0 128 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
43 1
323 0
2
0 130 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
43 1
324 0
2
0 132 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
43 1
325 0
2
0 134 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
45 1
223 0
2
0 24 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
45 1
225 0
2
0 26 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
45 1
227 0
2
0 28 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
45 1
229 0
2
0 30 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
45 1
231 0
2
0 32 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
45 1
233 0
2
0 34 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
45 1
235 0
2
0 36 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
45 1
237 0
2
0 38 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
45 1
239 0
2
0 40 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
45 1
241 0
2
0 42 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
45 1
243 0
2
0 44 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
45 1
245 0
2
0 46 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
45 1
247 0
2
0 48 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
45 1
249 0
2
0 50 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
45 1
251 0
2
0 52 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
45 1
253 0
2
0 54 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
45 1
255 0
2
0 56 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
45 1
257 0
2
0 58 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
45 1
259 0
2
0 60 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
45 1
261 0
2
0 62 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
45 1
263 0
2
0 64 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
45 1
265 0
2
0 66 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
45 1
267 0
2
0 68 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
45 1
269 0
2
0 70 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut31
3
0 0
45 1
271 0
2
0 72 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut32
3
0 0
45 1
273 0
2
0 74 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut33
3
0 0
45 1
275 0
2
0 76 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut34
3
0 0
45 1
277 0
2
0 78 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut35
3
0 0
45 1
279 0
2
0 80 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut36
3
0 0
45 1
281 0
2
0 82 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut37
3
0 0
45 1
283 0
2
0 84 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut38
3
0 0
45 1
285 0
2
0 86 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut39
3
0 0
45 1
287 0
2
0 88 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
45 1
289 0
2
0 90 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut40
3
0 0
45 1
291 0
2
0 92 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut41
3
0 0
45 1
293 0
2
0 94 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut42
3
0 0
45 1
295 0
2
0 96 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut43
3
0 0
45 1
297 0
2
0 98 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut44
3
0 0
45 1
299 0
2
0 100 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut45
3
0 0
45 1
301 0
2
0 102 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut46
3
0 0
45 1
303 0
2
0 104 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut47
3
0 0
45 1
305 0
2
0 106 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut48
3
0 0
45 1
307 0
2
0 108 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut49
3
0 0
45 1
309 0
2
0 110 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
45 1
311 0
2
0 112 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut50
3
0 0
45 1
313 0
2
0 114 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut51
3
0 0
45 1
315 0
2
0 116 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut52
3
0 0
45 1
317 0
2
0 118 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut53
3
0 0
45 1
318 0
2
0 120 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut54
3
0 0
45 1
319 0
2
0 122 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut55
3
0 0
45 1
320 0
2
0 124 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut56
3
0 0
45 1
321 0
2
0 126 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
45 1
322 0
2
0 128 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
45 1
323 0
2
0 130 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
45 1
324 0
2
0 132 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
45 1
325 0
2
0 134 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
47 1
223 0
2
0 24 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
47 1
225 0
2
0 26 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
47 1
227 0
2
0 28 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
47 1
229 0
2
0 30 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
47 1
231 0
2
0 32 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
47 1
233 0
2
0 34 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
47 1
235 0
2
0 36 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
47 1
237 0
2
0 38 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
47 1
239 0
2
0 40 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
47 1
241 0
2
0 42 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
47 1
243 0
2
0 44 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
47 1
245 0
2
0 46 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
47 1
247 0
2
0 48 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
47 1
249 0
2
0 50 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
47 1
251 0
2
0 52 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
47 1
253 0
2
0 54 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
47 1
255 0
2
0 56 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
47 1
257 0
2
0 58 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
47 1
259 0
2
0 60 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
47 1
261 0
2
0 62 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
47 1
263 0
2
0 64 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
47 1
265 0
2
0 66 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
47 1
267 0
2
0 68 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
47 1
269 0
2
0 70 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut31
3
0 0
47 1
271 0
2
0 72 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut32
3
0 0
47 1
273 0
2
0 74 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut33
3
0 0
47 1
275 0
2
0 76 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut34
3
0 0
47 1
277 0
2
0 78 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut35
3
0 0
47 1
279 0
2
0 80 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut36
3
0 0
47 1
281 0
2
0 82 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut37
3
0 0
47 1
283 0
2
0 84 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut38
3
0 0
47 1
285 0
2
0 86 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut39
3
0 0
47 1
287 0
2
0 88 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
47 1
289 0
2
0 90 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut40
3
0 0
47 1
291 0
2
0 92 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut41
3
0 0
47 1
293 0
2
0 94 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut42
3
0 0
47 1
295 0
2
0 96 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut43
3
0 0
47 1
297 0
2
0 98 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut44
3
0 0
47 1
299 0
2
0 100 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut45
3
0 0
47 1
301 0
2
0 102 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut46
3
0 0
47 1
303 0
2
0 104 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut47
3
0 0
47 1
305 0
2
0 106 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut48
3
0 0
47 1
307 0
2
0 108 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut49
3
0 0
47 1
309 0
2
0 110 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
47 1
311 0
2
0 112 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut50
3
0 0
47 1
313 0
2
0 114 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut51
3
0 0
47 1
315 0
2
0 116 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut52
3
0 0
47 1
317 0
2
0 118 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut53
3
0 0
47 1
318 0
2
0 120 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut54
3
0 0
47 1
319 0
2
0 122 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut55
3
0 0
47 1
320 0
2
0 124 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut56
3
0 0
47 1
321 0
2
0 126 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
47 1
322 0
2
0 128 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
47 1
323 0
2
0 130 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
47 1
324 0
2
0 132 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
47 1
325 0
2
0 134 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
49 1
223 0
2
0 24 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
49 1
225 0
2
0 26 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
49 1
227 0
2
0 28 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
49 1
229 0
2
0 30 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
49 1
231 0
2
0 32 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
49 1
233 0
2
0 34 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
49 1
235 0
2
0 36 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
49 1
237 0
2
0 38 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
49 1
239 0
2
0 40 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
49 1
241 0
2
0 42 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
49 1
243 0
2
0 44 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
49 1
245 0
2
0 46 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
49 1
247 0
2
0 48 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
49 1
249 0
2
0 50 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
49 1
251 0
2
0 52 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
49 1
253 0
2
0 54 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
49 1
255 0
2
0 56 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
49 1
257 0
2
0 58 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
49 1
259 0
2
0 60 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
49 1
261 0
2
0 62 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
49 1
263 0
2
0 64 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
49 1
265 0
2
0 66 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
49 1
267 0
2
0 68 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
49 1
269 0
2
0 70 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut31
3
0 0
49 1
271 0
2
0 72 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut32
3
0 0
49 1
273 0
2
0 74 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut33
3
0 0
49 1
275 0
2
0 76 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut34
3
0 0
49 1
277 0
2
0 78 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut35
3
0 0
49 1
279 0
2
0 80 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut36
3
0 0
49 1
281 0
2
0 82 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut37
3
0 0
49 1
283 0
2
0 84 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut38
3
0 0
49 1
285 0
2
0 86 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut39
3
0 0
49 1
287 0
2
0 88 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
49 1
289 0
2
0 90 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut40
3
0 0
49 1
291 0
2
0 92 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut41
3
0 0
49 1
293 0
2
0 94 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut42
3
0 0
49 1
295 0
2
0 96 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut43
3
0 0
49 1
297 0
2
0 98 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut44
3
0 0
49 1
299 0
2
0 100 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut45
3
0 0
49 1
301 0
2
0 102 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut46
3
0 0
49 1
303 0
2
0 104 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut47
3
0 0
49 1
305 0
2
0 106 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut48
3
0 0
49 1
307 0
2
0 108 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut49
3
0 0
49 1
309 0
2
0 110 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
49 1
311 0
2
0 112 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut50
3
0 0
49 1
313 0
2
0 114 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut51
3
0 0
49 1
315 0
2
0 116 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut52
3
0 0
49 1
317 0
2
0 118 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut53
3
0 0
49 1
318 0
2
0 120 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut54
3
0 0
49 1
319 0
2
0 122 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut55
3
0 0
49 1
320 0
2
0 124 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut56
3
0 0
49 1
321 0
2
0 126 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
49 1
322 0
2
0 128 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
49 1
323 0
2
0 130 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
49 1
324 0
2
0 132 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
49 1
325 0
2
0 134 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
51 1
223 0
2
0 24 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
51 1
225 0
2
0 26 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
51 1
227 0
2
0 28 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
51 1
229 0
2
0 30 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
51 1
231 0
2
0 32 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
51 1
233 0
2
0 34 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
51 1
235 0
2
0 36 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
51 1
237 0
2
0 38 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
51 1
239 0
2
0 40 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
51 1
241 0
2
0 42 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
51 1
243 0
2
0 44 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
51 1
245 0
2
0 46 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
51 1
247 0
2
0 48 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
51 1
249 0
2
0 50 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
51 1
251 0
2
0 52 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
51 1
253 0
2
0 54 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
51 1
255 0
2
0 56 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
51 1
257 0
2
0 58 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
51 1
259 0
2
0 60 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
51 1
261 0
2
0 62 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
51 1
263 0
2
0 64 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
51 1
265 0
2
0 66 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
51 1
267 0
2
0 68 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
51 1
269 0
2
0 70 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut31
3
0 0
51 1
271 0
2
0 72 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut32
3
0 0
51 1
273 0
2
0 74 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut33
3
0 0
51 1
275 0
2
0 76 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut34
3
0 0
51 1
277 0
2
0 78 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut35
3
0 0
51 1
279 0
2
0 80 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut36
3
0 0
51 1
281 0
2
0 82 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut37
3
0 0
51 1
283 0
2
0 84 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut38
3
0 0
51 1
285 0
2
0 86 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut39
3
0 0
51 1
287 0
2
0 88 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
51 1
289 0
2
0 90 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut40
3
0 0
51 1
291 0
2
0 92 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut41
3
0 0
51 1
293 0
2
0 94 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut42
3
0 0
51 1
295 0
2
0 96 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut43
3
0 0
51 1
297 0
2
0 98 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut44
3
0 0
51 1
299 0
2
0 100 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut45
3
0 0
51 1
301 0
2
0 102 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut46
3
0 0
51 1
303 0
2
0 104 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut47
3
0 0
51 1
305 0
2
0 106 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut48
3
0 0
51 1
307 0
2
0 108 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut49
3
0 0
51 1
309 0
2
0 110 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
51 1
311 0
2
0 112 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut50
3
0 0
51 1
313 0
2
0 114 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut51
3
0 0
51 1
315 0
2
0 116 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut52
3
0 0
51 1
317 0
2
0 118 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut53
3
0 0
51 1
318 0
2
0 120 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut54
3
0 0
51 1
319 0
2
0 122 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut55
3
0 0
51 1
320 0
2
0 124 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut56
3
0 0
51 1
321 0
2
0 126 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
51 1
322 0
2
0 128 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
51 1
323 0
2
0 130 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
51 1
324 0
2
0 132 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
51 1
325 0
2
0 134 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
53 1
223 0
2
0 24 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
53 1
225 0
2
0 26 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
53 1
227 0
2
0 28 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
53 1
229 0
2
0 30 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
53 1
231 0
2
0 32 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
53 1
233 0
2
0 34 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
53 1
235 0
2
0 36 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
53 1
237 0
2
0 38 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
53 1
239 0
2
0 40 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
53 1
241 0
2
0 42 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
53 1
243 0
2
0 44 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
53 1
245 0
2
0 46 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
53 1
247 0
2
0 48 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
53 1
249 0
2
0 50 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
53 1
251 0
2
0 52 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
53 1
253 0
2
0 54 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
53 1
255 0
2
0 56 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
53 1
257 0
2
0 58 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
53 1
259 0
2
0 60 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
53 1
261 0
2
0 62 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
53 1
263 0
2
0 64 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
53 1
265 0
2
0 66 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
53 1
267 0
2
0 68 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
53 1
269 0
2
0 70 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut31
3
0 0
53 1
271 0
2
0 72 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut32
3
0 0
53 1
273 0
2
0 74 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut33
3
0 0
53 1
275 0
2
0 76 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut34
3
0 0
53 1
277 0
2
0 78 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut35
3
0 0
53 1
279 0
2
0 80 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut36
3
0 0
53 1
281 0
2
0 82 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut37
3
0 0
53 1
283 0
2
0 84 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut38
3
0 0
53 1
285 0
2
0 86 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut39
3
0 0
53 1
287 0
2
0 88 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
53 1
289 0
2
0 90 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut40
3
0 0
53 1
291 0
2
0 92 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut41
3
0 0
53 1
293 0
2
0 94 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut42
3
0 0
53 1
295 0
2
0 96 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut43
3
0 0
53 1
297 0
2
0 98 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut44
3
0 0
53 1
299 0
2
0 100 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut45
3
0 0
53 1
301 0
2
0 102 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut46
3
0 0
53 1
303 0
2
0 104 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut47
3
0 0
53 1
305 0
2
0 106 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut48
3
0 0
53 1
307 0
2
0 108 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut49
3
0 0
53 1
309 0
2
0 110 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
53 1
311 0
2
0 112 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut50
3
0 0
53 1
313 0
2
0 114 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut51
3
0 0
53 1
315 0
2
0 116 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut52
3
0 0
53 1
317 0
2
0 118 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut53
3
0 0
53 1
318 0
2
0 120 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut54
3
0 0
53 1
319 0
2
0 122 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut55
3
0 0
53 1
320 0
2
0 124 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut56
3
0 0
53 1
321 0
2
0 126 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
53 1
322 0
2
0 128 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
53 1
323 0
2
0 130 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
53 1
324 0
2
0 132 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
53 1
325 0
2
0 134 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
55 1
223 0
2
0 24 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
55 1
225 0
2
0 26 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
55 1
227 0
2
0 28 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
55 1
229 0
2
0 30 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
55 1
231 0
2
0 32 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
55 1
233 0
2
0 34 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
55 1
235 0
2
0 36 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
55 1
237 0
2
0 38 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
55 1
239 0
2
0 40 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
55 1
241 0
2
0 42 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
55 1
243 0
2
0 44 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
55 1
245 0
2
0 46 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
55 1
247 0
2
0 48 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
55 1
249 0
2
0 50 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
55 1
251 0
2
0 52 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
55 1
253 0
2
0 54 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
55 1
255 0
2
0 56 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
55 1
257 0
2
0 58 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
55 1
259 0
2
0 60 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
55 1
261 0
2
0 62 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
55 1
263 0
2
0 64 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
55 1
265 0
2
0 66 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
55 1
267 0
2
0 68 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
55 1
269 0
2
0 70 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut31
3
0 0
55 1
271 0
2
0 72 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut32
3
0 0
55 1
273 0
2
0 74 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut33
3
0 0
55 1
275 0
2
0 76 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut34
3
0 0
55 1
277 0
2
0 78 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut35
3
0 0
55 1
279 0
2
0 80 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut36
3
0 0
55 1
281 0
2
0 82 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut37
3
0 0
55 1
283 0
2
0 84 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut38
3
0 0
55 1
285 0
2
0 86 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut39
3
0 0
55 1
287 0
2
0 88 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
55 1
289 0
2
0 90 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut40
3
0 0
55 1
291 0
2
0 92 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut41
3
0 0
55 1
293 0
2
0 94 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut42
3
0 0
55 1
295 0
2
0 96 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut43
3
0 0
55 1
297 0
2
0 98 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut44
3
0 0
55 1
299 0
2
0 100 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut45
3
0 0
55 1
301 0
2
0 102 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut46
3
0 0
55 1
303 0
2
0 104 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut47
3
0 0
55 1
305 0
2
0 106 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut48
3
0 0
55 1
307 0
2
0 108 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut49
3
0 0
55 1
309 0
2
0 110 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
55 1
311 0
2
0 112 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut50
3
0 0
55 1
313 0
2
0 114 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut51
3
0 0
55 1
315 0
2
0 116 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut52
3
0 0
55 1
317 0
2
0 118 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut53
3
0 0
55 1
318 0
2
0 120 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut54
3
0 0
55 1
319 0
2
0 122 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut55
3
0 0
55 1
320 0
2
0 124 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut56
3
0 0
55 1
321 0
2
0 126 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
55 1
322 0
2
0 128 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
55 1
323 0
2
0 130 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
55 1
324 0
2
0 132 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
55 1
325 0
2
0 134 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
57 1
223 0
2
0 24 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
57 1
225 0
2
0 26 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
57 1
227 0
2
0 28 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
57 1
229 0
2
0 30 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
57 1
231 0
2
0 32 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
57 1
233 0
2
0 34 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
57 1
235 0
2
0 36 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
57 1
237 0
2
0 38 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
57 1
239 0
2
0 40 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
57 1
241 0
2
0 42 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
57 1
243 0
2
0 44 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
57 1
245 0
2
0 46 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
57 1
247 0
2
0 48 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
57 1
249 0
2
0 50 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
57 1
251 0
2
0 52 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
57 1
253 0
2
0 54 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
57 1
255 0
2
0 56 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
57 1
257 0
2
0 58 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
57 1
259 0
2
0 60 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
57 1
261 0
2
0 62 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
57 1
263 0
2
0 64 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
57 1
265 0
2
0 66 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
57 1
267 0
2
0 68 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
57 1
269 0
2
0 70 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut31
3
0 0
57 1
271 0
2
0 72 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut32
3
0 0
57 1
273 0
2
0 74 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut33
3
0 0
57 1
275 0
2
0 76 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut34
3
0 0
57 1
277 0
2
0 78 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut35
3
0 0
57 1
279 0
2
0 80 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut36
3
0 0
57 1
281 0
2
0 82 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut37
3
0 0
57 1
283 0
2
0 84 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut38
3
0 0
57 1
285 0
2
0 86 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut39
3
0 0
57 1
287 0
2
0 88 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
57 1
289 0
2
0 90 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut40
3
0 0
57 1
291 0
2
0 92 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut41
3
0 0
57 1
293 0
2
0 94 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut42
3
0 0
57 1
295 0
2
0 96 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut43
3
0 0
57 1
297 0
2
0 98 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut44
3
0 0
57 1
299 0
2
0 100 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut45
3
0 0
57 1
301 0
2
0 102 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut46
3
0 0
57 1
303 0
2
0 104 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut47
3
0 0
57 1
305 0
2
0 106 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut48
3
0 0
57 1
307 0
2
0 108 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut49
3
0 0
57 1
309 0
2
0 110 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
57 1
311 0
2
0 112 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut50
3
0 0
57 1
313 0
2
0 114 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut51
3
0 0
57 1
315 0
2
0 116 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut52
3
0 0
57 1
317 0
2
0 118 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut53
3
0 0
57 1
318 0
2
0 120 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut54
3
0 0
57 1
319 0
2
0 122 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut55
3
0 0
57 1
320 0
2
0 124 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut56
3
0 0
57 1
321 0
2
0 126 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
57 1
322 0
2
0 128 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
57 1
323 0
2
0 130 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
57 1
324 0
2
0 132 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
57 1
325 0
2
0 134 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
59 1
223 0
2
0 24 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
59 1
225 0
2
0 26 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
59 1
227 0
2
0 28 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
59 1
229 0
2
0 30 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
59 1
231 0
2
0 32 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
59 1
233 0
2
0 34 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
59 1
235 0
2
0 36 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
59 1
237 0
2
0 38 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
59 1
239 0
2
0 40 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
59 1
241 0
2
0 42 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
59 1
243 0
2
0 44 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
59 1
245 0
2
0 46 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
59 1
247 0
2
0 48 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
59 1
249 0
2
0 50 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
59 1
251 0
2
0 52 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
59 1
253 0
2
0 54 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
59 1
255 0
2
0 56 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
59 1
257 0
2
0 58 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
59 1
259 0
2
0 60 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
59 1
261 0
2
0 62 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
59 1
263 0
2
0 64 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
59 1
265 0
2
0 66 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
59 1
267 0
2
0 68 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
59 1
269 0
2
0 70 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut31
3
0 0
59 1
271 0
2
0 72 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut32
3
0 0
59 1
273 0
2
0 74 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut33
3
0 0
59 1
275 0
2
0 76 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut34
3
0 0
59 1
277 0
2
0 78 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut35
3
0 0
59 1
279 0
2
0 80 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut36
3
0 0
59 1
281 0
2
0 82 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut37
3
0 0
59 1
283 0
2
0 84 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut38
3
0 0
59 1
285 0
2
0 86 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut39
3
0 0
59 1
287 0
2
0 88 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
59 1
289 0
2
0 90 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut40
3
0 0
59 1
291 0
2
0 92 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut41
3
0 0
59 1
293 0
2
0 94 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut42
3
0 0
59 1
295 0
2
0 96 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut43
3
0 0
59 1
297 0
2
0 98 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut44
3
0 0
59 1
299 0
2
0 100 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut45
3
0 0
59 1
301 0
2
0 102 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut46
3
0 0
59 1
303 0
2
0 104 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut47
3
0 0
59 1
305 0
2
0 106 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut48
3
0 0
59 1
307 0
2
0 108 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut49
3
0 0
59 1
309 0
2
0 110 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
59 1
311 0
2
0 112 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut50
3
0 0
59 1
313 0
2
0 114 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut51
3
0 0
59 1
315 0
2
0 116 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut52
3
0 0
59 1
317 0
2
0 118 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut53
3
0 0
59 1
318 0
2
0 120 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut54
3
0 0
59 1
319 0
2
0 122 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut55
3
0 0
59 1
320 0
2
0 124 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut56
3
0 0
59 1
321 0
2
0 126 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
59 1
322 0
2
0 128 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
59 1
323 0
2
0 130 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
59 1
324 0
2
0 132 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
59 1
325 0
2
0 134 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
61 1
223 0
2
0 24 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
61 1
225 0
2
0 26 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
61 1
227 0
2
0 28 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
61 1
229 0
2
0 30 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
61 1
231 0
2
0 32 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
61 1
233 0
2
0 34 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
61 1
235 0
2
0 36 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
61 1
237 0
2
0 38 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
61 1
239 0
2
0 40 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
61 1
241 0
2
0 42 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
61 1
243 0
2
0 44 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
61 1
245 0
2
0 46 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
61 1
247 0
2
0 48 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
61 1
249 0
2
0 50 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
61 1
251 0
2
0 52 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
61 1
253 0
2
0 54 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
61 1
255 0
2
0 56 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
61 1
257 0
2
0 58 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
61 1
259 0
2
0 60 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
61 1
261 0
2
0 62 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
61 1
263 0
2
0 64 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
61 1
265 0
2
0 66 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
61 1
267 0
2
0 68 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
61 1
269 0
2
0 70 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut31
3
0 0
61 1
271 0
2
0 72 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut32
3
0 0
61 1
273 0
2
0 74 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut33
3
0 0
61 1
275 0
2
0 76 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut34
3
0 0
61 1
277 0
2
0 78 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut35
3
0 0
61 1
279 0
2
0 80 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut36
3
0 0
61 1
281 0
2
0 82 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut37
3
0 0
61 1
283 0
2
0 84 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut38
3
0 0
61 1
285 0
2
0 86 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut39
3
0 0
61 1
287 0
2
0 88 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
61 1
289 0
2
0 90 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut40
3
0 0
61 1
291 0
2
0 92 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut41
3
0 0
61 1
293 0
2
0 94 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut42
3
0 0
61 1
295 0
2
0 96 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut43
3
0 0
61 1
297 0
2
0 98 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut44
3
0 0
61 1
299 0
2
0 100 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut45
3
0 0
61 1
301 0
2
0 102 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut46
3
0 0
61 1
303 0
2
0 104 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut47
3
0 0
61 1
305 0
2
0 106 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut48
3
0 0
61 1
307 0
2
0 108 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut49
3
0 0
61 1
309 0
2
0 110 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
61 1
311 0
2
0 112 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut50
3
0 0
61 1
313 0
2
0 114 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut51
3
0 0
61 1
315 0
2
0 116 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut52
3
0 0
61 1
317 0
2
0 118 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut53
3
0 0
61 1
318 0
2
0 120 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut54
3
0 0
61 1
319 0
2
0 122 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut55
3
0 0
61 1
320 0
2
0 124 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut56
3
0 0
61 1
321 0
2
0 126 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
61 1
322 0
2
0 128 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
61 1
323 0
2
0 130 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
61 1
324 0
2
0 132 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
61 1
325 0
2
0 134 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
63 1
223 0
2
0 24 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
63 1
225 0
2
0 26 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
63 1
227 0
2
0 28 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
63 1
229 0
2
0 30 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
63 1
231 0
2
0 32 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
63 1
233 0
2
0 34 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
63 1
235 0
2
0 36 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
63 1
237 0
2
0 38 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
63 1
239 0
2
0 40 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
63 1
241 0
2
0 42 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
63 1
243 0
2
0 44 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
63 1
245 0
2
0 46 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
63 1
247 0
2
0 48 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
63 1
249 0
2
0 50 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
63 1
251 0
2
0 52 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
63 1
253 0
2
0 54 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
63 1
255 0
2
0 56 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
63 1
257 0
2
0 58 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
63 1
259 0
2
0 60 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
63 1
261 0
2
0 62 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
63 1
263 0
2
0 64 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
63 1
265 0
2
0 66 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
63 1
267 0
2
0 68 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
63 1
269 0
2
0 70 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut31
3
0 0
63 1
271 0
2
0 72 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut32
3
0 0
63 1
273 0
2
0 74 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut33
3
0 0
63 1
275 0
2
0 76 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut34
3
0 0
63 1
277 0
2
0 78 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut35
3
0 0
63 1
279 0
2
0 80 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut36
3
0 0
63 1
281 0
2
0 82 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut37
3
0 0
63 1
283 0
2
0 84 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut38
3
0 0
63 1
285 0
2
0 86 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut39
3
0 0
63 1
287 0
2
0 88 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
63 1
289 0
2
0 90 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut40
3
0 0
63 1
291 0
2
0 92 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut41
3
0 0
63 1
293 0
2
0 94 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut42
3
0 0
63 1
295 0
2
0 96 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut43
3
0 0
63 1
297 0
2
0 98 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut44
3
0 0
63 1
299 0
2
0 100 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut45
3
0 0
63 1
301 0
2
0 102 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut46
3
0 0
63 1
303 0
2
0 104 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut47
3
0 0
63 1
305 0
2
0 106 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut48
3
0 0
63 1
307 0
2
0 108 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut49
3
0 0
63 1
309 0
2
0 110 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
63 1
311 0
2
0 112 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut50
3
0 0
63 1
313 0
2
0 114 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut51
3
0 0
63 1
315 0
2
0 116 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut52
3
0 0
63 1
317 0
2
0 118 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut53
3
0 0
63 1
318 0
2
0 120 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut54
3
0 0
63 1
319 0
2
0 122 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut55
3
0 0
63 1
320 0
2
0 124 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut56
3
0 0
63 1
321 0
2
0 126 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
63 1
322 0
2
0 128 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
63 1
323 0
2
0 130 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
63 1
324 0
2
0 132 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
63 1
325 0
2
0 134 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
65 1
223 0
2
0 24 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
65 1
225 0
2
0 26 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
65 1
227 0
2
0 28 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
65 1
229 0
2
0 30 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
65 1
231 0
2
0 32 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
65 1
233 0
2
0 34 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
65 1
235 0
2
0 36 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
65 1
237 0
2
0 38 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
65 1
239 0
2
0 40 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
65 1
241 0
2
0 42 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
65 1
243 0
2
0 44 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
65 1
245 0
2
0 46 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
65 1
247 0
2
0 48 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
65 1
249 0
2
0 50 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
65 1
251 0
2
0 52 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
65 1
253 0
2
0 54 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
65 1
255 0
2
0 56 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
65 1
257 0
2
0 58 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
65 1
259 0
2
0 60 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
65 1
261 0
2
0 62 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
65 1
263 0
2
0 64 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
65 1
265 0
2
0 66 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
65 1
267 0
2
0 68 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
65 1
269 0
2
0 70 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut31
3
0 0
65 1
271 0
2
0 72 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut32
3
0 0
65 1
273 0
2
0 74 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut33
3
0 0
65 1
275 0
2
0 76 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut34
3
0 0
65 1
277 0
2
0 78 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut35
3
0 0
65 1
279 0
2
0 80 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut36
3
0 0
65 1
281 0
2
0 82 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut37
3
0 0
65 1
283 0
2
0 84 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut38
3
0 0
65 1
285 0
2
0 86 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut39
3
0 0
65 1
287 0
2
0 88 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
65 1
289 0
2
0 90 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut40
3
0 0
65 1
291 0
2
0 92 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut41
3
0 0
65 1
293 0
2
0 94 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut42
3
0 0
65 1
295 0
2
0 96 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut43
3
0 0
65 1
297 0
2
0 98 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut44
3
0 0
65 1
299 0
2
0 100 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut45
3
0 0
65 1
301 0
2
0 102 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut46
3
0 0
65 1
303 0
2
0 104 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut47
3
0 0
65 1
305 0
2
0 106 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut48
3
0 0
65 1
307 0
2
0 108 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut49
3
0 0
65 1
309 0
2
0 110 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
65 1
311 0
2
0 112 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut50
3
0 0
65 1
313 0
2
0 114 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut51
3
0 0
65 1
315 0
2
0 116 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut52
3
0 0
65 1
317 0
2
0 118 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut53
3
0 0
65 1
318 0
2
0 120 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut54
3
0 0
65 1
319 0
2
0 122 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut55
3
0 0
65 1
320 0
2
0 124 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut56
3
0 0
65 1
321 0
2
0 126 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
65 1
322 0
2
0 128 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
65 1
323 0
2
0 130 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
65 1
324 0
2
0 132 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
65 1
325 0
2
0 134 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
67 1
223 0
2
0 24 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
67 1
225 0
2
0 26 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
67 1
227 0
2
0 28 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
67 1
229 0
2
0 30 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
67 1
231 0
2
0 32 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
67 1
233 0
2
0 34 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
67 1
235 0
2
0 36 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
67 1
237 0
2
0 38 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
67 1
239 0
2
0 40 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
67 1
241 0
2
0 42 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
67 1
243 0
2
0 44 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
67 1
245 0
2
0 46 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
67 1
247 0
2
0 48 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
67 1
249 0
2
0 50 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
67 1
251 0
2
0 52 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
67 1
253 0
2
0 54 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
67 1
255 0
2
0 56 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
67 1
257 0
2
0 58 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
67 1
259 0
2
0 60 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
67 1
261 0
2
0 62 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
67 1
263 0
2
0 64 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
67 1
265 0
2
0 66 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
67 1
267 0
2
0 68 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
67 1
269 0
2
0 70 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut31
3
0 0
67 1
271 0
2
0 72 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut32
3
0 0
67 1
273 0
2
0 74 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut33
3
0 0
67 1
275 0
2
0 76 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut34
3
0 0
67 1
277 0
2
0 78 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut35
3
0 0
67 1
279 0
2
0 80 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut36
3
0 0
67 1
281 0
2
0 82 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut37
3
0 0
67 1
283 0
2
0 84 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut38
3
0 0
67 1
285 0
2
0 86 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut39
3
0 0
67 1
287 0
2
0 88 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
67 1
289 0
2
0 90 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut40
3
0 0
67 1
291 0
2
0 92 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut41
3
0 0
67 1
293 0
2
0 94 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut42
3
0 0
67 1
295 0
2
0 96 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut43
3
0 0
67 1
297 0
2
0 98 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut44
3
0 0
67 1
299 0
2
0 100 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut45
3
0 0
67 1
301 0
2
0 102 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut46
3
0 0
67 1
303 0
2
0 104 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut47
3
0 0
67 1
305 0
2
0 106 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut48
3
0 0
67 1
307 0
2
0 108 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut49
3
0 0
67 1
309 0
2
0 110 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
67 1
311 0
2
0 112 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut50
3
0 0
67 1
313 0
2
0 114 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut51
3
0 0
67 1
315 0
2
0 116 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut52
3
0 0
67 1
317 0
2
0 118 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut53
3
0 0
67 1
318 0
2
0 120 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut54
3
0 0
67 1
319 0
2
0 122 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut55
3
0 0
67 1
320 0
2
0 124 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut56
3
0 0
67 1
321 0
2
0 126 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
67 1
322 0
2
0 128 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
67 1
323 0
2
0 130 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
67 1
324 0
2
0 132 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
67 1
325 0
2
0 134 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
69 1
223 0
2
0 24 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
69 1
225 0
2
0 26 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
69 1
227 0
2
0 28 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
69 1
229 0
2
0 30 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
69 1
231 0
2
0 32 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
69 1
233 0
2
0 34 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
69 1
235 0
2
0 36 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
69 1
237 0
2
0 38 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
69 1
239 0
2
0 40 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
69 1
241 0
2
0 42 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
69 1
243 0
2
0 44 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
69 1
245 0
2
0 46 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
69 1
247 0
2
0 48 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
69 1
249 0
2
0 50 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
69 1
251 0
2
0 52 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
69 1
253 0
2
0 54 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
69 1
255 0
2
0 56 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
69 1
257 0
2
0 58 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
69 1
259 0
2
0 60 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
69 1
261 0
2
0 62 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
69 1
263 0
2
0 64 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
69 1
265 0
2
0 66 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
69 1
267 0
2
0 68 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
69 1
269 0
2
0 70 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut31
3
0 0
69 1
271 0
2
0 72 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut32
3
0 0
69 1
273 0
2
0 74 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut33
3
0 0
69 1
275 0
2
0 76 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut34
3
0 0
69 1
277 0
2
0 78 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut35
3
0 0
69 1
279 0
2
0 80 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut36
3
0 0
69 1
281 0
2
0 82 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut37
3
0 0
69 1
283 0
2
0 84 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut38
3
0 0
69 1
285 0
2
0 86 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut39
3
0 0
69 1
287 0
2
0 88 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
69 1
289 0
2
0 90 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut40
3
0 0
69 1
291 0
2
0 92 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut41
3
0 0
69 1
293 0
2
0 94 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut42
3
0 0
69 1
295 0
2
0 96 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut43
3
0 0
69 1
297 0
2
0 98 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut44
3
0 0
69 1
299 0
2
0 100 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut45
3
0 0
69 1
301 0
2
0 102 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut46
3
0 0
69 1
303 0
2
0 104 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut47
3
0 0
69 1
305 0
2
0 106 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut48
3
0 0
69 1
307 0
2
0 108 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut49
3
0 0
69 1
309 0
2
0 110 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
69 1
311 0
2
0 112 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut50
3
0 0
69 1
313 0
2
0 114 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut51
3
0 0
69 1
315 0
2
0 116 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut52
3
0 0
69 1
317 0
2
0 118 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut53
3
0 0
69 1
318 0
2
0 120 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut54
3
0 0
69 1
319 0
2
0 122 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut55
3
0 0
69 1
320 0
2
0 124 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut56
3
0 0
69 1
321 0
2
0 126 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
69 1
322 0
2
0 128 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
69 1
323 0
2
0 130 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
69 1
324 0
2
0 132 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
69 1
325 0
2
0 134 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
71 1
223 0
2
0 24 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
71 1
225 0
2
0 26 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
71 1
227 0
2
0 28 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
71 1
229 0
2
0 30 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
71 1
231 0
2
0 32 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
71 1
233 0
2
0 34 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
71 1
235 0
2
0 36 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
71 1
237 0
2
0 38 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
71 1
239 0
2
0 40 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
71 1
241 0
2
0 42 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
71 1
243 0
2
0 44 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
71 1
245 0
2
0 46 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
71 1
247 0
2
0 48 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
71 1
249 0
2
0 50 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
71 1
251 0
2
0 52 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
71 1
253 0
2
0 54 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
71 1
255 0
2
0 56 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
71 1
257 0
2
0 58 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
71 1
259 0
2
0 60 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
71 1
261 0
2
0 62 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
71 1
263 0
2
0 64 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
71 1
265 0
2
0 66 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
71 1
267 0
2
0 68 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
71 1
269 0
2
0 70 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut31
3
0 0
71 1
271 0
2
0 72 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut32
3
0 0
71 1
273 0
2
0 74 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut33
3
0 0
71 1
275 0
2
0 76 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut34
3
0 0
71 1
277 0
2
0 78 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut35
3
0 0
71 1
279 0
2
0 80 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut36
3
0 0
71 1
281 0
2
0 82 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut37
3
0 0
71 1
283 0
2
0 84 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut38
3
0 0
71 1
285 0
2
0 86 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut39
3
0 0
71 1
287 0
2
0 88 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
71 1
289 0
2
0 90 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut40
3
0 0
71 1
291 0
2
0 92 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut41
3
0 0
71 1
293 0
2
0 94 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut42
3
0 0
71 1
295 0
2
0 96 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut43
3
0 0
71 1
297 0
2
0 98 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut44
3
0 0
71 1
299 0
2
0 100 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut45
3
0 0
71 1
301 0
2
0 102 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut46
3
0 0
71 1
303 0
2
0 104 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut47
3
0 0
71 1
305 0
2
0 106 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut48
3
0 0
71 1
307 0
2
0 108 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut49
3
0 0
71 1
309 0
2
0 110 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
71 1
311 0
2
0 112 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut50
3
0 0
71 1
313 0
2
0 114 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut51
3
0 0
71 1
315 0
2
0 116 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut52
3
0 0
71 1
317 0
2
0 118 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut53
3
0 0
71 1
318 0
2
0 120 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut54
3
0 0
71 1
319 0
2
0 122 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut55
3
0 0
71 1
320 0
2
0 124 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut56
3
0 0
71 1
321 0
2
0 126 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
71 1
322 0
2
0 128 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
71 1
323 0
2
0 130 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
71 1
324 0
2
0 132 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
71 1
325 0
2
0 134 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
73 1
223 0
2
0 24 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
73 1
225 0
2
0 26 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
73 1
227 0
2
0 28 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
73 1
229 0
2
0 30 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
73 1
231 0
2
0 32 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
73 1
233 0
2
0 34 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
73 1
235 0
2
0 36 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
73 1
237 0
2
0 38 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
73 1
239 0
2
0 40 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
73 1
241 0
2
0 42 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
73 1
243 0
2
0 44 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
73 1
245 0
2
0 46 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
73 1
247 0
2
0 48 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
73 1
249 0
2
0 50 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
73 1
251 0
2
0 52 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
73 1
253 0
2
0 54 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
73 1
255 0
2
0 56 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
73 1
257 0
2
0 58 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
73 1
259 0
2
0 60 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
73 1
261 0
2
0 62 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
73 1
263 0
2
0 64 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
73 1
265 0
2
0 66 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
73 1
267 0
2
0 68 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
73 1
269 0
2
0 70 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut31
3
0 0
73 1
271 0
2
0 72 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut32
3
0 0
73 1
273 0
2
0 74 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut33
3
0 0
73 1
275 0
2
0 76 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut34
3
0 0
73 1
277 0
2
0 78 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut35
3
0 0
73 1
279 0
2
0 80 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut36
3
0 0
73 1
281 0
2
0 82 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut37
3
0 0
73 1
283 0
2
0 84 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut38
3
0 0
73 1
285 0
2
0 86 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut39
3
0 0
73 1
287 0
2
0 88 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
73 1
289 0
2
0 90 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut40
3
0 0
73 1
291 0
2
0 92 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut41
3
0 0
73 1
293 0
2
0 94 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut42
3
0 0
73 1
295 0
2
0 96 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut43
3
0 0
73 1
297 0
2
0 98 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut44
3
0 0
73 1
299 0
2
0 100 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut45
3
0 0
73 1
301 0
2
0 102 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut46
3
0 0
73 1
303 0
2
0 104 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut47
3
0 0
73 1
305 0
2
0 106 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut48
3
0 0
73 1
307 0
2
0 108 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut49
3
0 0
73 1
309 0
2
0 110 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
73 1
311 0
2
0 112 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut50
3
0 0
73 1
313 0
2
0 114 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut51
3
0 0
73 1
315 0
2
0 116 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut52
3
0 0
73 1
317 0
2
0 118 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut53
3
0 0
73 1
318 0
2
0 120 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut54
3
0 0
73 1
319 0
2
0 122 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut55
3
0 0
73 1
320 0
2
0 124 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut56
3
0 0
73 1
321 0
2
0 126 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
73 1
322 0
2
0 128 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
73 1
323 0
2
0 130 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
73 1
324 0
2
0 132 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
73 1
325 0
2
0 134 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
75 1
223 0
2
0 24 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
75 1
225 0
2
0 26 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
75 1
227 0
2
0 28 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
75 1
229 0
2
0 30 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
75 1
231 0
2
0 32 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
75 1
233 0
2
0 34 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
75 1
235 0
2
0 36 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
75 1
237 0
2
0 38 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
75 1
239 0
2
0 40 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
75 1
241 0
2
0 42 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
75 1
243 0
2
0 44 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
75 1
245 0
2
0 46 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
75 1
247 0
2
0 48 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
75 1
249 0
2
0 50 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
75 1
251 0
2
0 52 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
75 1
253 0
2
0 54 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
75 1
255 0
2
0 56 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
75 1
257 0
2
0 58 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
75 1
259 0
2
0 60 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
75 1
261 0
2
0 62 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
75 1
263 0
2
0 64 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
75 1
265 0
2
0 66 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
75 1
267 0
2
0 68 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
75 1
269 0
2
0 70 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut31
3
0 0
75 1
271 0
2
0 72 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut32
3
0 0
75 1
273 0
2
0 74 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut33
3
0 0
75 1
275 0
2
0 76 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut34
3
0 0
75 1
277 0
2
0 78 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut35
3
0 0
75 1
279 0
2
0 80 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut36
3
0 0
75 1
281 0
2
0 82 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut37
3
0 0
75 1
283 0
2
0 84 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut38
3
0 0
75 1
285 0
2
0 86 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut39
3
0 0
75 1
287 0
2
0 88 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
75 1
289 0
2
0 90 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut40
3
0 0
75 1
291 0
2
0 92 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut41
3
0 0
75 1
293 0
2
0 94 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut42
3
0 0
75 1
295 0
2
0 96 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut43
3
0 0
75 1
297 0
2
0 98 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut44
3
0 0
75 1
299 0
2
0 100 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut45
3
0 0
75 1
301 0
2
0 102 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut46
3
0 0
75 1
303 0
2
0 104 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut47
3
0 0
75 1
305 0
2
0 106 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut48
3
0 0
75 1
307 0
2
0 108 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut49
3
0 0
75 1
309 0
2
0 110 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
75 1
311 0
2
0 112 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut50
3
0 0
75 1
313 0
2
0 114 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut51
3
0 0
75 1
315 0
2
0 116 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut52
3
0 0
75 1
317 0
2
0 118 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut53
3
0 0
75 1
318 0
2
0 120 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut54
3
0 0
75 1
319 0
2
0 122 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut55
3
0 0
75 1
320 0
2
0 124 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut56
3
0 0
75 1
321 0
2
0 126 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
75 1
322 0
2
0 128 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
75 1
323 0
2
0 130 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
75 1
324 0
2
0 132 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
75 1
325 0
2
0 134 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
77 1
223 0
2
0 24 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
77 1
225 0
2
0 26 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
77 1
227 0
2
0 28 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
77 1
229 0
2
0 30 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
77 1
231 0
2
0 32 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
77 1
233 0
2
0 34 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
77 1
235 0
2
0 36 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
77 1
237 0
2
0 38 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
77 1
239 0
2
0 40 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
77 1
241 0
2
0 42 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
77 1
243 0
2
0 44 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
77 1
245 0
2
0 46 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
77 1
247 0
2
0 48 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
77 1
249 0
2
0 50 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
77 1
251 0
2
0 52 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
77 1
253 0
2
0 54 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
77 1
255 0
2
0 56 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
77 1
257 0
2
0 58 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
77 1
259 0
2
0 60 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
77 1
261 0
2
0 62 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
77 1
263 0
2
0 64 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
77 1
265 0
2
0 66 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
77 1
267 0
2
0 68 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
77 1
269 0
2
0 70 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut31
3
0 0
77 1
271 0
2
0 72 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut32
3
0 0
77 1
273 0
2
0 74 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut33
3
0 0
77 1
275 0
2
0 76 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut34
3
0 0
77 1
277 0
2
0 78 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut35
3
0 0
77 1
279 0
2
0 80 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut36
3
0 0
77 1
281 0
2
0 82 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut37
3
0 0
77 1
283 0
2
0 84 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut38
3
0 0
77 1
285 0
2
0 86 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut39
3
0 0
77 1
287 0
2
0 88 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
77 1
289 0
2
0 90 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut40
3
0 0
77 1
291 0
2
0 92 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut41
3
0 0
77 1
293 0
2
0 94 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut42
3
0 0
77 1
295 0
2
0 96 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut43
3
0 0
77 1
297 0
2
0 98 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut44
3
0 0
77 1
299 0
2
0 100 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut45
3
0 0
77 1
301 0
2
0 102 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut46
3
0 0
77 1
303 0
2
0 104 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut47
3
0 0
77 1
305 0
2
0 106 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut48
3
0 0
77 1
307 0
2
0 108 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut49
3
0 0
77 1
309 0
2
0 110 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
77 1
311 0
2
0 112 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut50
3
0 0
77 1
313 0
2
0 114 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut51
3
0 0
77 1
315 0
2
0 116 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut52
3
0 0
77 1
317 0
2
0 118 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut53
3
0 0
77 1
318 0
2
0 120 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut54
3
0 0
77 1
319 0
2
0 122 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut55
3
0 0
77 1
320 0
2
0 124 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut56
3
0 0
77 1
321 0
2
0 126 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
77 1
322 0
2
0 128 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
77 1
323 0
2
0 130 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
77 1
324 0
2
0 132 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
77 1
325 0
2
0 134 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
79 1
223 0
2
0 24 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
79 1
225 0
2
0 26 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
79 1
227 0
2
0 28 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
79 1
229 0
2
0 30 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
79 1
231 0
2
0 32 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
79 1
233 0
2
0 34 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
79 1
235 0
2
0 36 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
79 1
237 0
2
0 38 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
79 1
239 0
2
0 40 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
79 1
241 0
2
0 42 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
79 1
243 0
2
0 44 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
79 1
245 0
2
0 46 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
79 1
247 0
2
0 48 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
79 1
249 0
2
0 50 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
79 1
251 0
2
0 52 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
79 1
253 0
2
0 54 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
79 1
255 0
2
0 56 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
79 1
257 0
2
0 58 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
79 1
259 0
2
0 60 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
79 1
261 0
2
0 62 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
79 1
263 0
2
0 64 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
79 1
265 0
2
0 66 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
79 1
267 0
2
0 68 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
79 1
269 0
2
0 70 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut31
3
0 0
79 1
271 0
2
0 72 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut32
3
0 0
79 1
273 0
2
0 74 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut33
3
0 0
79 1
275 0
2
0 76 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut34
3
0 0
79 1
277 0
2
0 78 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut35
3
0 0
79 1
279 0
2
0 80 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut36
3
0 0
79 1
281 0
2
0 82 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut37
3
0 0
79 1
283 0
2
0 84 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut38
3
0 0
79 1
285 0
2
0 86 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut39
3
0 0
79 1
287 0
2
0 88 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
79 1
289 0
2
0 90 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut40
3
0 0
79 1
291 0
2
0 92 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut41
3
0 0
79 1
293 0
2
0 94 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut42
3
0 0
79 1
295 0
2
0 96 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut43
3
0 0
79 1
297 0
2
0 98 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut44
3
0 0
79 1
299 0
2
0 100 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut45
3
0 0
79 1
301 0
2
0 102 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut46
3
0 0
79 1
303 0
2
0 104 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut47
3
0 0
79 1
305 0
2
0 106 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut48
3
0 0
79 1
307 0
2
0 108 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut49
3
0 0
79 1
309 0
2
0 110 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
79 1
311 0
2
0 112 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut50
3
0 0
79 1
313 0
2
0 114 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut51
3
0 0
79 1
315 0
2
0 116 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut52
3
0 0
79 1
317 0
2
0 118 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut53
3
0 0
79 1
318 0
2
0 120 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut54
3
0 0
79 1
319 0
2
0 122 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut55
3
0 0
79 1
320 0
2
0 124 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut56
3
0 0
79 1
321 0
2
0 126 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
79 1
322 0
2
0 128 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
79 1
323 0
2
0 130 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
79 1
324 0
2
0 132 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
79 1
325 0
2
0 134 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
81 1
223 0
2
0 24 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
81 1
225 0
2
0 26 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
81 1
227 0
2
0 28 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
81 1
229 0
2
0 30 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
81 1
231 0
2
0 32 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
81 1
233 0
2
0 34 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
81 1
235 0
2
0 36 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
81 1
237 0
2
0 38 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
81 1
239 0
2
0 40 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
81 1
241 0
2
0 42 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
81 1
243 0
2
0 44 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
81 1
245 0
2
0 46 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
81 1
247 0
2
0 48 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
81 1
249 0
2
0 50 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
81 1
251 0
2
0 52 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
81 1
253 0
2
0 54 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
81 1
255 0
2
0 56 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
81 1
257 0
2
0 58 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
81 1
259 0
2
0 60 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
81 1
261 0
2
0 62 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
81 1
263 0
2
0 64 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
81 1
265 0
2
0 66 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
81 1
267 0
2
0 68 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
81 1
269 0
2
0 70 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut31
3
0 0
81 1
271 0
2
0 72 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut32
3
0 0
81 1
273 0
2
0 74 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut33
3
0 0
81 1
275 0
2
0 76 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut34
3
0 0
81 1
277 0
2
0 78 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut35
3
0 0
81 1
279 0
2
0 80 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut36
3
0 0
81 1
281 0
2
0 82 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut37
3
0 0
81 1
283 0
2
0 84 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut38
3
0 0
81 1
285 0
2
0 86 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut39
3
0 0
81 1
287 0
2
0 88 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
81 1
289 0
2
0 90 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut40
3
0 0
81 1
291 0
2
0 92 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut41
3
0 0
81 1
293 0
2
0 94 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut42
3
0 0
81 1
295 0
2
0 96 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut43
3
0 0
81 1
297 0
2
0 98 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut44
3
0 0
81 1
299 0
2
0 100 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut45
3
0 0
81 1
301 0
2
0 102 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut46
3
0 0
81 1
303 0
2
0 104 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut47
3
0 0
81 1
305 0
2
0 106 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut48
3
0 0
81 1
307 0
2
0 108 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut49
3
0 0
81 1
309 0
2
0 110 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
81 1
311 0
2
0 112 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut50
3
0 0
81 1
313 0
2
0 114 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut51
3
0 0
81 1
315 0
2
0 116 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut52
3
0 0
81 1
317 0
2
0 118 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut53
3
0 0
81 1
318 0
2
0 120 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut54
3
0 0
81 1
319 0
2
0 122 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut55
3
0 0
81 1
320 0
2
0 124 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut56
3
0 0
81 1
321 0
2
0 126 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
81 1
322 0
2
0 128 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
81 1
323 0
2
0 130 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
81 1
324 0
2
0 132 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
81 1
325 0
2
0 134 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
83 1
223 0
2
0 24 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
83 1
225 0
2
0 26 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
83 1
227 0
2
0 28 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
83 1
229 0
2
0 30 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
83 1
231 0
2
0 32 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
83 1
233 0
2
0 34 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
83 1
235 0
2
0 36 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
83 1
237 0
2
0 38 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
83 1
239 0
2
0 40 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
83 1
241 0
2
0 42 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
83 1
243 0
2
0 44 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
83 1
245 0
2
0 46 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
83 1
247 0
2
0 48 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
83 1
249 0
2
0 50 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
83 1
251 0
2
0 52 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
83 1
253 0
2
0 54 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
83 1
255 0
2
0 56 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
83 1
257 0
2
0 58 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
83 1
259 0
2
0 60 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
83 1
261 0
2
0 62 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
83 1
263 0
2
0 64 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
83 1
265 0
2
0 66 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
83 1
267 0
2
0 68 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
83 1
269 0
2
0 70 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut31
3
0 0
83 1
271 0
2
0 72 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut32
3
0 0
83 1
273 0
2
0 74 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut33
3
0 0
83 1
275 0
2
0 76 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut34
3
0 0
83 1
277 0
2
0 78 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut35
3
0 0
83 1
279 0
2
0 80 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut36
3
0 0
83 1
281 0
2
0 82 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut37
3
0 0
83 1
283 0
2
0 84 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut38
3
0 0
83 1
285 0
2
0 86 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut39
3
0 0
83 1
287 0
2
0 88 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
83 1
289 0
2
0 90 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut40
3
0 0
83 1
291 0
2
0 92 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut41
3
0 0
83 1
293 0
2
0 94 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut42
3
0 0
83 1
295 0
2
0 96 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut43
3
0 0
83 1
297 0
2
0 98 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut44
3
0 0
83 1
299 0
2
0 100 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut45
3
0 0
83 1
301 0
2
0 102 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut46
3
0 0
83 1
303 0
2
0 104 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut47
3
0 0
83 1
305 0
2
0 106 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut48
3
0 0
83 1
307 0
2
0 108 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut49
3
0 0
83 1
309 0
2
0 110 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
83 1
311 0
2
0 112 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut50
3
0 0
83 1
313 0
2
0 114 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut51
3
0 0
83 1
315 0
2
0 116 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut52
3
0 0
83 1
317 0
2
0 118 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut53
3
0 0
83 1
318 0
2
0 120 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut54
3
0 0
83 1
319 0
2
0 122 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut55
3
0 0
83 1
320 0
2
0 124 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut56
3
0 0
83 1
321 0
2
0 126 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
83 1
322 0
2
0 128 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
83 1
323 0
2
0 130 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
83 1
324 0
2
0 132 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
83 1
325 0
2
0 134 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
85 1
223 0
2
0 24 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
85 1
225 0
2
0 26 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
85 1
227 0
2
0 28 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
85 1
229 0
2
0 30 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
85 1
231 0
2
0 32 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
85 1
233 0
2
0 34 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
85 1
235 0
2
0 36 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
85 1
237 0
2
0 38 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
85 1
239 0
2
0 40 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
85 1
241 0
2
0 42 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
85 1
243 0
2
0 44 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
85 1
245 0
2
0 46 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
85 1
247 0
2
0 48 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
85 1
249 0
2
0 50 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
85 1
251 0
2
0 52 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
85 1
253 0
2
0 54 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
85 1
255 0
2
0 56 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
85 1
257 0
2
0 58 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
85 1
259 0
2
0 60 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
85 1
261 0
2
0 62 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
85 1
263 0
2
0 64 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
85 1
265 0
2
0 66 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
85 1
267 0
2
0 68 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
85 1
269 0
2
0 70 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut31
3
0 0
85 1
271 0
2
0 72 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut32
3
0 0
85 1
273 0
2
0 74 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut33
3
0 0
85 1
275 0
2
0 76 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut34
3
0 0
85 1
277 0
2
0 78 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut35
3
0 0
85 1
279 0
2
0 80 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut36
3
0 0
85 1
281 0
2
0 82 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut37
3
0 0
85 1
283 0
2
0 84 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut38
3
0 0
85 1
285 0
2
0 86 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut39
3
0 0
85 1
287 0
2
0 88 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
85 1
289 0
2
0 90 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut40
3
0 0
85 1
291 0
2
0 92 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut41
3
0 0
85 1
293 0
2
0 94 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut42
3
0 0
85 1
295 0
2
0 96 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut43
3
0 0
85 1
297 0
2
0 98 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut44
3
0 0
85 1
299 0
2
0 100 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut45
3
0 0
85 1
301 0
2
0 102 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut46
3
0 0
85 1
303 0
2
0 104 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut47
3
0 0
85 1
305 0
2
0 106 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut48
3
0 0
85 1
307 0
2
0 108 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut49
3
0 0
85 1
309 0
2
0 110 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
85 1
311 0
2
0 112 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut50
3
0 0
85 1
313 0
2
0 114 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut51
3
0 0
85 1
315 0
2
0 116 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut52
3
0 0
85 1
317 0
2
0 118 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut53
3
0 0
85 1
318 0
2
0 120 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut54
3
0 0
85 1
319 0
2
0 122 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut55
3
0 0
85 1
320 0
2
0 124 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut56
3
0 0
85 1
321 0
2
0 126 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
85 1
322 0
2
0 128 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
85 1
323 0
2
0 130 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
85 1
324 0
2
0 132 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
85 1
325 0
2
0 134 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
87 1
223 0
2
0 24 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
87 1
225 0
2
0 26 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
87 1
227 0
2
0 28 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
87 1
229 0
2
0 30 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
87 1
231 0
2
0 32 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
87 1
233 0
2
0 34 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
87 1
235 0
2
0 36 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
87 1
237 0
2
0 38 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
87 1
239 0
2
0 40 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
87 1
241 0
2
0 42 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
87 1
243 0
2
0 44 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
87 1
245 0
2
0 46 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
87 1
247 0
2
0 48 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
87 1
249 0
2
0 50 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
87 1
251 0
2
0 52 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
87 1
253 0
2
0 54 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
87 1
255 0
2
0 56 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
87 1
257 0
2
0 58 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
87 1
259 0
2
0 60 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
87 1
261 0
2
0 62 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
87 1
263 0
2
0 64 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
87 1
265 0
2
0 66 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
87 1
267 0
2
0 68 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
87 1
269 0
2
0 70 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut31
3
0 0
87 1
271 0
2
0 72 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut32
3
0 0
87 1
273 0
2
0 74 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut33
3
0 0
87 1
275 0
2
0 76 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut34
3
0 0
87 1
277 0
2
0 78 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut35
3
0 0
87 1
279 0
2
0 80 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut36
3
0 0
87 1
281 0
2
0 82 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut37
3
0 0
87 1
283 0
2
0 84 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut38
3
0 0
87 1
285 0
2
0 86 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut39
3
0 0
87 1
287 0
2
0 88 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
87 1
289 0
2
0 90 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut40
3
0 0
87 1
291 0
2
0 92 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut41
3
0 0
87 1
293 0
2
0 94 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut42
3
0 0
87 1
295 0
2
0 96 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut43
3
0 0
87 1
297 0
2
0 98 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut44
3
0 0
87 1
299 0
2
0 100 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut45
3
0 0
87 1
301 0
2
0 102 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut46
3
0 0
87 1
303 0
2
0 104 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut47
3
0 0
87 1
305 0
2
0 106 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut48
3
0 0
87 1
307 0
2
0 108 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut49
3
0 0
87 1
309 0
2
0 110 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
87 1
311 0
2
0 112 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut50
3
0 0
87 1
313 0
2
0 114 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut51
3
0 0
87 1
315 0
2
0 116 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut52
3
0 0
87 1
317 0
2
0 118 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut53
3
0 0
87 1
318 0
2
0 120 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut54
3
0 0
87 1
319 0
2
0 122 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut55
3
0 0
87 1
320 0
2
0 124 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut56
3
0 0
87 1
321 0
2
0 126 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
87 1
322 0
2
0 128 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
87 1
323 0
2
0 130 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
87 1
324 0
2
0 132 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
87 1
325 0
2
0 134 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
89 1
223 0
2
0 24 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
89 1
225 0
2
0 26 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
89 1
227 0
2
0 28 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
89 1
229 0
2
0 30 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
89 1
231 0
2
0 32 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
89 1
233 0
2
0 34 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
89 1
235 0
2
0 36 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
89 1
237 0
2
0 38 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
89 1
239 0
2
0 40 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
89 1
241 0
2
0 42 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
89 1
243 0
2
0 44 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
89 1
245 0
2
0 46 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
89 1
247 0
2
0 48 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
89 1
249 0
2
0 50 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
89 1
251 0
2
0 52 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
89 1
253 0
2
0 54 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
89 1
255 0
2
0 56 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
89 1
257 0
2
0 58 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
89 1
259 0
2
0 60 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
89 1
261 0
2
0 62 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
89 1
263 0
2
0 64 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
89 1
265 0
2
0 66 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
89 1
267 0
2
0 68 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
89 1
269 0
2
0 70 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut31
3
0 0
89 1
271 0
2
0 72 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut32
3
0 0
89 1
273 0
2
0 74 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut33
3
0 0
89 1
275 0
2
0 76 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut34
3
0 0
89 1
277 0
2
0 78 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut35
3
0 0
89 1
279 0
2
0 80 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut36
3
0 0
89 1
281 0
2
0 82 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut37
3
0 0
89 1
283 0
2
0 84 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut38
3
0 0
89 1
285 0
2
0 86 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut39
3
0 0
89 1
287 0
2
0 88 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
89 1
289 0
2
0 90 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut40
3
0 0
89 1
291 0
2
0 92 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut41
3
0 0
89 1
293 0
2
0 94 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut42
3
0 0
89 1
295 0
2
0 96 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut43
3
0 0
89 1
297 0
2
0 98 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut44
3
0 0
89 1
299 0
2
0 100 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut45
3
0 0
89 1
301 0
2
0 102 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut46
3
0 0
89 1
303 0
2
0 104 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut47
3
0 0
89 1
305 0
2
0 106 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut48
3
0 0
89 1
307 0
2
0 108 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut49
3
0 0
89 1
309 0
2
0 110 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
89 1
311 0
2
0 112 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut50
3
0 0
89 1
313 0
2
0 114 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut51
3
0 0
89 1
315 0
2
0 116 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut52
3
0 0
89 1
317 0
2
0 118 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut53
3
0 0
89 1
318 0
2
0 120 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut54
3
0 0
89 1
319 0
2
0 122 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut55
3
0 0
89 1
320 0
2
0 124 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut56
3
0 0
89 1
321 0
2
0 126 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
89 1
322 0
2
0 128 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
89 1
323 0
2
0 130 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
89 1
324 0
2
0 132 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
89 1
325 0
2
0 134 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
91 1
223 0
2
0 24 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
91 1
225 0
2
0 26 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
91 1
227 0
2
0 28 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
91 1
229 0
2
0 30 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
91 1
231 0
2
0 32 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
91 1
233 0
2
0 34 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
91 1
235 0
2
0 36 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
91 1
237 0
2
0 38 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
91 1
239 0
2
0 40 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
91 1
241 0
2
0 42 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
91 1
243 0
2
0 44 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
91 1
245 0
2
0 46 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
91 1
247 0
2
0 48 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
91 1
249 0
2
0 50 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
91 1
251 0
2
0 52 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
91 1
253 0
2
0 54 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
91 1
255 0
2
0 56 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
91 1
257 0
2
0 58 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
91 1
259 0
2
0 60 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
91 1
261 0
2
0 62 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
91 1
263 0
2
0 64 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
91 1
265 0
2
0 66 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
91 1
267 0
2
0 68 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
91 1
269 0
2
0 70 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut31
3
0 0
91 1
271 0
2
0 72 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut32
3
0 0
91 1
273 0
2
0 74 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut33
3
0 0
91 1
275 0
2
0 76 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut34
3
0 0
91 1
277 0
2
0 78 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut35
3
0 0
91 1
279 0
2
0 80 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut36
3
0 0
91 1
281 0
2
0 82 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut37
3
0 0
91 1
283 0
2
0 84 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut38
3
0 0
91 1
285 0
2
0 86 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut39
3
0 0
91 1
287 0
2
0 88 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
91 1
289 0
2
0 90 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut40
3
0 0
91 1
291 0
2
0 92 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut41
3
0 0
91 1
293 0
2
0 94 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut42
3
0 0
91 1
295 0
2
0 96 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut43
3
0 0
91 1
297 0
2
0 98 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut44
3
0 0
91 1
299 0
2
0 100 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut45
3
0 0
91 1
301 0
2
0 102 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut46
3
0 0
91 1
303 0
2
0 104 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut47
3
0 0
91 1
305 0
2
0 106 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut48
3
0 0
91 1
307 0
2
0 108 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut49
3
0 0
91 1
309 0
2
0 110 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
91 1
311 0
2
0 112 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut50
3
0 0
91 1
313 0
2
0 114 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut51
3
0 0
91 1
315 0
2
0 116 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut52
3
0 0
91 1
317 0
2
0 118 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut53
3
0 0
91 1
318 0
2
0 120 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut54
3
0 0
91 1
319 0
2
0 122 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut55
3
0 0
91 1
320 0
2
0 124 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut56
3
0 0
91 1
321 0
2
0 126 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
91 1
322 0
2
0 128 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
91 1
323 0
2
0 130 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
91 1
324 0
2
0 132 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
91 1
325 0
2
0 134 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
93 1
223 0
2
0 24 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
93 1
225 0
2
0 26 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
93 1
227 0
2
0 28 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
93 1
229 0
2
0 30 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
93 1
231 0
2
0 32 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
93 1
233 0
2
0 34 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
93 1
235 0
2
0 36 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
93 1
237 0
2
0 38 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
93 1
239 0
2
0 40 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
93 1
241 0
2
0 42 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
93 1
243 0
2
0 44 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
93 1
245 0
2
0 46 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
93 1
247 0
2
0 48 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
93 1
249 0
2
0 50 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
93 1
251 0
2
0 52 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
93 1
253 0
2
0 54 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
93 1
255 0
2
0 56 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
93 1
257 0
2
0 58 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
93 1
259 0
2
0 60 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
93 1
261 0
2
0 62 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
93 1
263 0
2
0 64 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
93 1
265 0
2
0 66 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
93 1
267 0
2
0 68 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
93 1
269 0
2
0 70 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut31
3
0 0
93 1
271 0
2
0 72 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut32
3
0 0
93 1
273 0
2
0 74 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut33
3
0 0
93 1
275 0
2
0 76 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut34
3
0 0
93 1
277 0
2
0 78 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut35
3
0 0
93 1
279 0
2
0 80 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut36
3
0 0
93 1
281 0
2
0 82 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut37
3
0 0
93 1
283 0
2
0 84 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut38
3
0 0
93 1
285 0
2
0 86 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut39
3
0 0
93 1
287 0
2
0 88 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
93 1
289 0
2
0 90 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut40
3
0 0
93 1
291 0
2
0 92 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut41
3
0 0
93 1
293 0
2
0 94 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut42
3
0 0
93 1
295 0
2
0 96 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut43
3
0 0
93 1
297 0
2
0 98 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut44
3
0 0
93 1
299 0
2
0 100 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut45
3
0 0
93 1
301 0
2
0 102 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut46
3
0 0
93 1
303 0
2
0 104 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut47
3
0 0
93 1
305 0
2
0 106 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut48
3
0 0
93 1
307 0
2
0 108 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut49
3
0 0
93 1
309 0
2
0 110 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
93 1
311 0
2
0 112 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut50
3
0 0
93 1
313 0
2
0 114 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut51
3
0 0
93 1
315 0
2
0 116 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut52
3
0 0
93 1
317 0
2
0 118 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut53
3
0 0
93 1
318 0
2
0 120 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut54
3
0 0
93 1
319 0
2
0 122 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut55
3
0 0
93 1
320 0
2
0 124 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut56
3
0 0
93 1
321 0
2
0 126 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
93 1
322 0
2
0 128 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
93 1
323 0
2
0 130 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
93 1
324 0
2
0 132 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
93 1
325 0
2
0 134 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
95 1
223 0
2
0 24 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
95 1
225 0
2
0 26 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
95 1
227 0
2
0 28 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
95 1
229 0
2
0 30 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
95 1
231 0
2
0 32 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
95 1
233 0
2
0 34 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
95 1
235 0
2
0 36 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
95 1
237 0
2
0 38 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
95 1
239 0
2
0 40 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
95 1
241 0
2
0 42 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
95 1
243 0
2
0 44 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
95 1
245 0
2
0 46 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
95 1
247 0
2
0 48 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
95 1
249 0
2
0 50 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
95 1
251 0
2
0 52 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
95 1
253 0
2
0 54 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
95 1
255 0
2
0 56 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
95 1
257 0
2
0 58 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
95 1
259 0
2
0 60 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
95 1
261 0
2
0 62 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
95 1
263 0
2
0 64 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
95 1
265 0
2
0 66 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
95 1
267 0
2
0 68 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
95 1
269 0
2
0 70 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut31
3
0 0
95 1
271 0
2
0 72 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut32
3
0 0
95 1
273 0
2
0 74 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut33
3
0 0
95 1
275 0
2
0 76 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut34
3
0 0
95 1
277 0
2
0 78 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut35
3
0 0
95 1
279 0
2
0 80 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut36
3
0 0
95 1
281 0
2
0 82 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut37
3
0 0
95 1
283 0
2
0 84 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut38
3
0 0
95 1
285 0
2
0 86 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut39
3
0 0
95 1
287 0
2
0 88 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
95 1
289 0
2
0 90 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut40
3
0 0
95 1
291 0
2
0 92 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut41
3
0 0
95 1
293 0
2
0 94 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut42
3
0 0
95 1
295 0
2
0 96 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut43
3
0 0
95 1
297 0
2
0 98 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut44
3
0 0
95 1
299 0
2
0 100 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut45
3
0 0
95 1
301 0
2
0 102 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut46
3
0 0
95 1
303 0
2
0 104 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut47
3
0 0
95 1
305 0
2
0 106 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut48
3
0 0
95 1
307 0
2
0 108 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut49
3
0 0
95 1
309 0
2
0 110 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
95 1
311 0
2
0 112 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut50
3
0 0
95 1
313 0
2
0 114 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut51
3
0 0
95 1
315 0
2
0 116 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut52
3
0 0
95 1
317 0
2
0 118 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut53
3
0 0
95 1
318 0
2
0 120 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut54
3
0 0
95 1
319 0
2
0 122 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut55
3
0 0
95 1
320 0
2
0 124 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut56
3
0 0
95 1
321 0
2
0 126 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
95 1
322 0
2
0 128 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
95 1
323 0
2
0 130 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
95 1
324 0
2
0 132 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
95 1
325 0
2
0 134 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
97 1
223 0
2
0 24 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
97 1
225 0
2
0 26 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
97 1
227 0
2
0 28 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
97 1
229 0
2
0 30 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
97 1
231 0
2
0 32 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
97 1
233 0
2
0 34 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
97 1
235 0
2
0 36 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
97 1
237 0
2
0 38 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
97 1
239 0
2
0 40 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
97 1
241 0
2
0 42 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
97 1
243 0
2
0 44 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
97 1
245 0
2
0 46 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
97 1
247 0
2
0 48 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
97 1
249 0
2
0 50 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
97 1
251 0
2
0 52 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
97 1
253 0
2
0 54 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
97 1
255 0
2
0 56 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
97 1
257 0
2
0 58 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
97 1
259 0
2
0 60 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
97 1
261 0
2
0 62 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
97 1
263 0
2
0 64 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
97 1
265 0
2
0 66 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
97 1
267 0
2
0 68 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
97 1
269 0
2
0 70 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut31
3
0 0
97 1
271 0
2
0 72 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut32
3
0 0
97 1
273 0
2
0 74 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut33
3
0 0
97 1
275 0
2
0 76 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut34
3
0 0
97 1
277 0
2
0 78 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut35
3
0 0
97 1
279 0
2
0 80 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut36
3
0 0
97 1
281 0
2
0 82 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut37
3
0 0
97 1
283 0
2
0 84 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut38
3
0 0
97 1
285 0
2
0 86 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut39
3
0 0
97 1
287 0
2
0 88 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
97 1
289 0
2
0 90 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut40
3
0 0
97 1
291 0
2
0 92 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut41
3
0 0
97 1
293 0
2
0 94 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut42
3
0 0
97 1
295 0
2
0 96 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut43
3
0 0
97 1
297 0
2
0 98 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut44
3
0 0
97 1
299 0
2
0 100 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut45
3
0 0
97 1
301 0
2
0 102 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut46
3
0 0
97 1
303 0
2
0 104 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut47
3
0 0
97 1
305 0
2
0 106 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut48
3
0 0
97 1
307 0
2
0 108 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut49
3
0 0
97 1
309 0
2
0 110 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
97 1
311 0
2
0 112 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut50
3
0 0
97 1
313 0
2
0 114 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut51
3
0 0
97 1
315 0
2
0 116 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut52
3
0 0
97 1
317 0
2
0 118 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut53
3
0 0
97 1
318 0
2
0 120 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut54
3
0 0
97 1
319 0
2
0 122 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut55
3
0 0
97 1
320 0
2
0 124 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut56
3
0 0
97 1
321 0
2
0 126 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
97 1
322 0
2
0 128 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
97 1
323 0
2
0 130 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
97 1
324 0
2
0 132 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
97 1
325 0
2
0 134 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
99 1
223 0
2
0 24 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
99 1
225 0
2
0 26 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
99 1
227 0
2
0 28 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
99 1
229 0
2
0 30 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
99 1
231 0
2
0 32 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
99 1
233 0
2
0 34 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
99 1
235 0
2
0 36 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
99 1
237 0
2
0 38 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
99 1
239 0
2
0 40 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
99 1
241 0
2
0 42 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
99 1
243 0
2
0 44 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
99 1
245 0
2
0 46 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
99 1
247 0
2
0 48 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
99 1
249 0
2
0 50 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
99 1
251 0
2
0 52 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
99 1
253 0
2
0 54 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
99 1
255 0
2
0 56 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
99 1
257 0
2
0 58 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
99 1
259 0
2
0 60 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
99 1
261 0
2
0 62 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
99 1
263 0
2
0 64 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
99 1
265 0
2
0 66 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
99 1
267 0
2
0 68 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
99 1
269 0
2
0 70 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut31
3
0 0
99 1
271 0
2
0 72 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut32
3
0 0
99 1
273 0
2
0 74 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut33
3
0 0
99 1
275 0
2
0 76 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut34
3
0 0
99 1
277 0
2
0 78 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut35
3
0 0
99 1
279 0
2
0 80 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut36
3
0 0
99 1
281 0
2
0 82 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut37
3
0 0
99 1
283 0
2
0 84 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut38
3
0 0
99 1
285 0
2
0 86 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut39
3
0 0
99 1
287 0
2
0 88 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
99 1
289 0
2
0 90 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut40
3
0 0
99 1
291 0
2
0 92 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut41
3
0 0
99 1
293 0
2
0 94 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut42
3
0 0
99 1
295 0
2
0 96 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut43
3
0 0
99 1
297 0
2
0 98 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut44
3
0 0
99 1
299 0
2
0 100 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut45
3
0 0
99 1
301 0
2
0 102 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut46
3
0 0
99 1
303 0
2
0 104 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut47
3
0 0
99 1
305 0
2
0 106 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut48
3
0 0
99 1
307 0
2
0 108 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut49
3
0 0
99 1
309 0
2
0 110 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
99 1
311 0
2
0 112 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut50
3
0 0
99 1
313 0
2
0 114 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut51
3
0 0
99 1
315 0
2
0 116 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut52
3
0 0
99 1
317 0
2
0 118 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut53
3
0 0
99 1
318 0
2
0 120 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut54
3
0 0
99 1
319 0
2
0 122 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut55
3
0 0
99 1
320 0
2
0 124 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut56
3
0 0
99 1
321 0
2
0 126 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
99 1
322 0
2
0 128 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
99 1
323 0
2
0 130 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
99 1
324 0
2
0 132 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
99 1
325 0
2
0 134 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
101 1
223 0
2
0 24 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
101 1
225 0
2
0 26 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
101 1
227 0
2
0 28 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
101 1
229 0
2
0 30 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
101 1
231 0
2
0 32 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
101 1
233 0
2
0 34 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
101 1
235 0
2
0 36 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
101 1
237 0
2
0 38 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
101 1
239 0
2
0 40 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
101 1
241 0
2
0 42 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
101 1
243 0
2
0 44 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
101 1
245 0
2
0 46 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
101 1
247 0
2
0 48 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
101 1
249 0
2
0 50 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
101 1
251 0
2
0 52 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
101 1
253 0
2
0 54 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
101 1
255 0
2
0 56 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
101 1
257 0
2
0 58 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
101 1
259 0
2
0 60 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
101 1
261 0
2
0 62 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
101 1
263 0
2
0 64 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
101 1
265 0
2
0 66 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
101 1
267 0
2
0 68 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
101 1
269 0
2
0 70 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut31
3
0 0
101 1
271 0
2
0 72 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut32
3
0 0
101 1
273 0
2
0 74 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut33
3
0 0
101 1
275 0
2
0 76 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut34
3
0 0
101 1
277 0
2
0 78 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut35
3
0 0
101 1
279 0
2
0 80 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut36
3
0 0
101 1
281 0
2
0 82 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut37
3
0 0
101 1
283 0
2
0 84 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut38
3
0 0
101 1
285 0
2
0 86 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut39
3
0 0
101 1
287 0
2
0 88 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
101 1
289 0
2
0 90 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut40
3
0 0
101 1
291 0
2
0 92 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut41
3
0 0
101 1
293 0
2
0 94 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut42
3
0 0
101 1
295 0
2
0 96 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut43
3
0 0
101 1
297 0
2
0 98 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut44
3
0 0
101 1
299 0
2
0 100 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut45
3
0 0
101 1
301 0
2
0 102 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut46
3
0 0
101 1
303 0
2
0 104 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut47
3
0 0
101 1
305 0
2
0 106 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut48
3
0 0
101 1
307 0
2
0 108 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut49
3
0 0
101 1
309 0
2
0 110 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
101 1
311 0
2
0 112 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut50
3
0 0
101 1
313 0
2
0 114 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut51
3
0 0
101 1
315 0
2
0 116 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut52
3
0 0
101 1
317 0
2
0 118 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut53
3
0 0
101 1
318 0
2
0 120 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut54
3
0 0
101 1
319 0
2
0 122 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut55
3
0 0
101 1
320 0
2
0 124 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut56
3
0 0
101 1
321 0
2
0 126 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
101 1
322 0
2
0 128 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
101 1
323 0
2
0 130 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
101 1
324 0
2
0 132 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
101 1
325 0
2
0 134 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
103 1
223 0
2
0 24 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
103 1
225 0
2
0 26 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
103 1
227 0
2
0 28 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
103 1
229 0
2
0 30 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
103 1
231 0
2
0 32 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
103 1
233 0
2
0 34 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
103 1
235 0
2
0 36 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
103 1
237 0
2
0 38 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
103 1
239 0
2
0 40 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
103 1
241 0
2
0 42 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
103 1
243 0
2
0 44 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
103 1
245 0
2
0 46 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
103 1
247 0
2
0 48 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
103 1
249 0
2
0 50 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
103 1
251 0
2
0 52 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
103 1
253 0
2
0 54 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
103 1
255 0
2
0 56 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
103 1
257 0
2
0 58 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
103 1
259 0
2
0 60 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
103 1
261 0
2
0 62 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
103 1
263 0
2
0 64 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
103 1
265 0
2
0 66 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
103 1
267 0
2
0 68 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
103 1
269 0
2
0 70 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut31
3
0 0
103 1
271 0
2
0 72 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut32
3
0 0
103 1
273 0
2
0 74 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut33
3
0 0
103 1
275 0
2
0 76 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut34
3
0 0
103 1
277 0
2
0 78 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut35
3
0 0
103 1
279 0
2
0 80 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut36
3
0 0
103 1
281 0
2
0 82 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut37
3
0 0
103 1
283 0
2
0 84 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut38
3
0 0
103 1
285 0
2
0 86 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut39
3
0 0
103 1
287 0
2
0 88 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
103 1
289 0
2
0 90 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut40
3
0 0
103 1
291 0
2
0 92 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut41
3
0 0
103 1
293 0
2
0 94 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut42
3
0 0
103 1
295 0
2
0 96 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut43
3
0 0
103 1
297 0
2
0 98 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut44
3
0 0
103 1
299 0
2
0 100 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut45
3
0 0
103 1
301 0
2
0 102 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut46
3
0 0
103 1
303 0
2
0 104 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut47
3
0 0
103 1
305 0
2
0 106 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut48
3
0 0
103 1
307 0
2
0 108 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut49
3
0 0
103 1
309 0
2
0 110 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
103 1
311 0
2
0 112 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut50
3
0 0
103 1
313 0
2
0 114 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut51
3
0 0
103 1
315 0
2
0 116 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut52
3
0 0
103 1
317 0
2
0 118 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut53
3
0 0
103 1
318 0
2
0 120 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut54
3
0 0
103 1
319 0
2
0 122 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut55
3
0 0
103 1
320 0
2
0 124 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut56
3
0 0
103 1
321 0
2
0 126 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
103 1
322 0
2
0 128 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
103 1
323 0
2
0 130 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
103 1
324 0
2
0 132 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
103 1
325 0
2
0 134 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
105 1
223 0
2
0 24 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
105 1
225 0
2
0 26 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
105 1
227 0
2
0 28 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
105 1
229 0
2
0 30 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
105 1
231 0
2
0 32 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
105 1
233 0
2
0 34 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
105 1
235 0
2
0 36 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
105 1
237 0
2
0 38 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
105 1
239 0
2
0 40 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
105 1
241 0
2
0 42 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
105 1
243 0
2
0 44 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
105 1
245 0
2
0 46 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
105 1
247 0
2
0 48 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
105 1
249 0
2
0 50 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
105 1
251 0
2
0 52 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
105 1
253 0
2
0 54 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
105 1
255 0
2
0 56 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
105 1
257 0
2
0 58 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
105 1
259 0
2
0 60 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
105 1
261 0
2
0 62 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
105 1
263 0
2
0 64 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
105 1
265 0
2
0 66 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
105 1
267 0
2
0 68 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
105 1
269 0
2
0 70 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut31
3
0 0
105 1
271 0
2
0 72 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut32
3
0 0
105 1
273 0
2
0 74 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut33
3
0 0
105 1
275 0
2
0 76 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut34
3
0 0
105 1
277 0
2
0 78 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut35
3
0 0
105 1
279 0
2
0 80 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut36
3
0 0
105 1
281 0
2
0 82 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut37
3
0 0
105 1
283 0
2
0 84 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut38
3
0 0
105 1
285 0
2
0 86 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut39
3
0 0
105 1
287 0
2
0 88 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
105 1
289 0
2
0 90 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut40
3
0 0
105 1
291 0
2
0 92 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut41
3
0 0
105 1
293 0
2
0 94 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut42
3
0 0
105 1
295 0
2
0 96 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut43
3
0 0
105 1
297 0
2
0 98 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut44
3
0 0
105 1
299 0
2
0 100 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut45
3
0 0
105 1
301 0
2
0 102 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut46
3
0 0
105 1
303 0
2
0 104 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut47
3
0 0
105 1
305 0
2
0 106 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut48
3
0 0
105 1
307 0
2
0 108 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut49
3
0 0
105 1
309 0
2
0 110 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
105 1
311 0
2
0 112 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut50
3
0 0
105 1
313 0
2
0 114 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut51
3
0 0
105 1
315 0
2
0 116 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut52
3
0 0
105 1
317 0
2
0 118 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut53
3
0 0
105 1
318 0
2
0 120 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut54
3
0 0
105 1
319 0
2
0 122 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut55
3
0 0
105 1
320 0
2
0 124 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut56
3
0 0
105 1
321 0
2
0 126 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
105 1
322 0
2
0 128 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
105 1
323 0
2
0 130 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
105 1
324 0
2
0 132 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
105 1
325 0
2
0 134 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
107 1
223 0
2
0 24 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
107 1
225 0
2
0 26 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
107 1
227 0
2
0 28 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
107 1
229 0
2
0 30 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
107 1
231 0
2
0 32 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
107 1
233 0
2
0 34 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
107 1
235 0
2
0 36 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
107 1
237 0
2
0 38 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
107 1
239 0
2
0 40 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
107 1
241 0
2
0 42 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
107 1
243 0
2
0 44 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
107 1
245 0
2
0 46 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
107 1
247 0
2
0 48 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
107 1
249 0
2
0 50 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
107 1
251 0
2
0 52 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
107 1
253 0
2
0 54 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
107 1
255 0
2
0 56 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
107 1
257 0
2
0 58 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
107 1
259 0
2
0 60 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
107 1
261 0
2
0 62 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
107 1
263 0
2
0 64 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
107 1
265 0
2
0 66 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
107 1
267 0
2
0 68 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
107 1
269 0
2
0 70 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut31
3
0 0
107 1
271 0
2
0 72 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut32
3
0 0
107 1
273 0
2
0 74 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut33
3
0 0
107 1
275 0
2
0 76 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut34
3
0 0
107 1
277 0
2
0 78 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut35
3
0 0
107 1
279 0
2
0 80 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut36
3
0 0
107 1
281 0
2
0 82 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut37
3
0 0
107 1
283 0
2
0 84 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut38
3
0 0
107 1
285 0
2
0 86 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut39
3
0 0
107 1
287 0
2
0 88 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
107 1
289 0
2
0 90 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut40
3
0 0
107 1
291 0
2
0 92 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut41
3
0 0
107 1
293 0
2
0 94 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut42
3
0 0
107 1
295 0
2
0 96 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut43
3
0 0
107 1
297 0
2
0 98 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut44
3
0 0
107 1
299 0
2
0 100 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut45
3
0 0
107 1
301 0
2
0 102 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut46
3
0 0
107 1
303 0
2
0 104 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut47
3
0 0
107 1
305 0
2
0 106 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut48
3
0 0
107 1
307 0
2
0 108 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut49
3
0 0
107 1
309 0
2
0 110 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
107 1
311 0
2
0 112 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut50
3
0 0
107 1
313 0
2
0 114 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut51
3
0 0
107 1
315 0
2
0 116 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut52
3
0 0
107 1
317 0
2
0 118 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut53
3
0 0
107 1
318 0
2
0 120 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut54
3
0 0
107 1
319 0
2
0 122 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut55
3
0 0
107 1
320 0
2
0 124 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut56
3
0 0
107 1
321 0
2
0 126 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
107 1
322 0
2
0 128 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
107 1
323 0
2
0 130 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
107 1
324 0
2
0 132 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
107 1
325 0
2
0 134 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
109 1
223 0
2
0 24 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
109 1
225 0
2
0 26 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
109 1
227 0
2
0 28 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
109 1
229 0
2
0 30 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
109 1
231 0
2
0 32 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
109 1
233 0
2
0 34 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
109 1
235 0
2
0 36 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
109 1
237 0
2
0 38 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
109 1
239 0
2
0 40 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
109 1
241 0
2
0 42 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
109 1
243 0
2
0 44 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
109 1
245 0
2
0 46 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
109 1
247 0
2
0 48 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
109 1
249 0
2
0 50 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
109 1
251 0
2
0 52 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
109 1
253 0
2
0 54 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
109 1
255 0
2
0 56 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
109 1
257 0
2
0 58 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
109 1
259 0
2
0 60 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
109 1
261 0
2
0 62 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
109 1
263 0
2
0 64 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
109 1
265 0
2
0 66 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
109 1
267 0
2
0 68 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
109 1
269 0
2
0 70 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut31
3
0 0
109 1
271 0
2
0 72 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut32
3
0 0
109 1
273 0
2
0 74 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut33
3
0 0
109 1
275 0
2
0 76 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut34
3
0 0
109 1
277 0
2
0 78 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut35
3
0 0
109 1
279 0
2
0 80 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut36
3
0 0
109 1
281 0
2
0 82 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut37
3
0 0
109 1
283 0
2
0 84 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut38
3
0 0
109 1
285 0
2
0 86 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut39
3
0 0
109 1
287 0
2
0 88 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
109 1
289 0
2
0 90 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut40
3
0 0
109 1
291 0
2
0 92 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut41
3
0 0
109 1
293 0
2
0 94 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut42
3
0 0
109 1
295 0
2
0 96 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut43
3
0 0
109 1
297 0
2
0 98 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut44
3
0 0
109 1
299 0
2
0 100 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut45
3
0 0
109 1
301 0
2
0 102 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut46
3
0 0
109 1
303 0
2
0 104 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut47
3
0 0
109 1
305 0
2
0 106 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut48
3
0 0
109 1
307 0
2
0 108 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut49
3
0 0
109 1
309 0
2
0 110 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
109 1
311 0
2
0 112 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut50
3
0 0
109 1
313 0
2
0 114 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut51
3
0 0
109 1
315 0
2
0 116 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut52
3
0 0
109 1
317 0
2
0 118 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut53
3
0 0
109 1
318 0
2
0 120 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut54
3
0 0
109 1
319 0
2
0 122 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut55
3
0 0
109 1
320 0
2
0 124 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut56
3
0 0
109 1
321 0
2
0 126 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
109 1
322 0
2
0 128 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
109 1
323 0
2
0 130 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
109 1
324 0
2
0 132 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
109 1
325 0
2
0 134 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut1
3
0 0
111 1
223 0
2
0 24 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut10
3
0 0
111 1
225 0
2
0 26 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut11
3
0 0
111 1
227 0
2
0 28 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut12
3
0 0
111 1
229 0
2
0 30 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut13
3
0 0
111 1
231 0
2
0 32 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut14
3
0 0
111 1
233 0
2
0 34 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut15
3
0 0
111 1
235 0
2
0 36 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut16
3
0 0
111 1
237 0
2
0 38 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut17
3
0 0
111 1
239 0
2
0 40 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut18
3
0 0
111 1
241 0
2
0 42 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut19
3
0 0
111 1
243 0
2
0 44 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut2
3
0 0
111 1
245 0
2
0 46 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut20
3
0 0
111 1
247 0
2
0 48 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut21
3
0 0
111 1
249 0
2
0 50 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut22
3
0 0
111 1
251 0
2
0 52 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut23
3
0 0
111 1
253 0
2
0 54 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut24
3
0 0
111 1
255 0
2
0 56 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut25
3
0 0
111 1
257 0
2
0 58 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut26
3
0 0
111 1
259 0
2
0 60 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut27
3
0 0
111 1
261 0
2
0 62 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut28
3
0 0
111 1
263 0
2
0 64 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut29
3
0 0
111 1
265 0
2
0 66 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut3
3
0 0
111 1
267 0
2
0 68 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut30
3
0 0
111 1
269 0
2
0 70 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut31
3
0 0
111 1
271 0
2
0 72 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut32
3
0 0
111 1
273 0
2
0 74 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut33
3
0 0
111 1
275 0
2
0 76 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut34
3
0 0
111 1
277 0
2
0 78 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut35
3
0 0
111 1
279 0
2
0 80 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut36
3
0 0
111 1
281 0
2
0 82 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut37
3
0 0
111 1
283 0
2
0 84 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut38
3
0 0
111 1
285 0
2
0 86 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut39
3
0 0
111 1
287 0
2
0 88 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut4
3
0 0
111 1
289 0
2
0 90 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut40
3
0 0
111 1
291 0
2
0 92 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut41
3
0 0
111 1
293 0
2
0 94 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut42
3
0 0
111 1
295 0
2
0 96 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut43
3
0 0
111 1
297 0
2
0 98 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut44
3
0 0
111 1
299 0
2
0 100 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut45
3
0 0
111 1
301 0
2
0 102 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut46
3
0 0
111 1
303 0
2
0 104 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut47
3
0 0
111 1
305 0
2
0 106 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut48
3
0 0
111 1
307 0
2
0 108 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut49
3
0 0
111 1
309 0
2
0 110 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut5
3
0 0
111 1
311 0
2
0 112 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut50
3
0 0
111 1
313 0
2
0 114 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut51
3
0 0
111 1
315 0
2
0 116 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut52
3
0 0
111 1
317 0
2
0 118 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut53
3
0 0
111 1
318 0
2
0 120 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut54
3
0 0
111 1
319 0
2
0 122 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut55
3
0 0
111 1
320 0
2
0 124 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut56
3
0 0
111 1
321 0
2
0 126 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut6
3
0 0
111 1
322 0
2
0 128 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut7
3
0 0
111 1
323 0
2
0 130 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut8
3
0 0
111 1
324 0
2
0 132 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut9
3
0 0
111 1
325 0
2
0 134 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut1
3
0 0
113 1
223 0
2
0 24 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut10
3
0 0
113 1
225 0
2
0 26 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut11
3
0 0
113 1
227 0
2
0 28 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut12
3
0 0
113 1
229 0
2
0 30 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut13
3
0 0
113 1
231 0
2
0 32 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut14
3
0 0
113 1
233 0
2
0 34 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut15
3
0 0
113 1
235 0
2
0 36 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut16
3
0 0
113 1
237 0
2
0 38 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut17
3
0 0
113 1
239 0
2
0 40 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut18
3
0 0
113 1
241 0
2
0 42 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut19
3
0 0
113 1
243 0
2
0 44 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut2
3
0 0
113 1
245 0
2
0 46 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut20
3
0 0
113 1
247 0
2
0 48 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut21
3
0 0
113 1
249 0
2
0 50 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut22
3
0 0
113 1
251 0
2
0 52 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut23
3
0 0
113 1
253 0
2
0 54 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut24
3
0 0
113 1
255 0
2
0 56 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut25
3
0 0
113 1
257 0
2
0 58 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut26
3
0 0
113 1
259 0
2
0 60 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut27
3
0 0
113 1
261 0
2
0 62 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut28
3
0 0
113 1
263 0
2
0 64 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut29
3
0 0
113 1
265 0
2
0 66 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut3
3
0 0
113 1
267 0
2
0 68 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut30
3
0 0
113 1
269 0
2
0 70 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut31
3
0 0
113 1
271 0
2
0 72 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut32
3
0 0
113 1
273 0
2
0 74 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut33
3
0 0
113 1
275 0
2
0 76 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut34
3
0 0
113 1
277 0
2
0 78 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut35
3
0 0
113 1
279 0
2
0 80 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut36
3
0 0
113 1
281 0
2
0 82 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut37
3
0 0
113 1
283 0
2
0 84 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut38
3
0 0
113 1
285 0
2
0 86 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut39
3
0 0
113 1
287 0
2
0 88 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut4
3
0 0
113 1
289 0
2
0 90 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut40
3
0 0
113 1
291 0
2
0 92 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut41
3
0 0
113 1
293 0
2
0 94 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut42
3
0 0
113 1
295 0
2
0 96 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut43
3
0 0
113 1
297 0
2
0 98 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut44
3
0 0
113 1
299 0
2
0 100 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut45
3
0 0
113 1
301 0
2
0 102 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut46
3
0 0
113 1
303 0
2
0 104 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut47
3
0 0
113 1
305 0
2
0 106 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut48
3
0 0
113 1
307 0
2
0 108 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut49
3
0 0
113 1
309 0
2
0 110 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut5
3
0 0
113 1
311 0
2
0 112 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut50
3
0 0
113 1
313 0
2
0 114 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut51
3
0 0
113 1
315 0
2
0 116 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut52
3
0 0
113 1
317 0
2
0 118 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut53
3
0 0
113 1
318 0
2
0 120 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut54
3
0 0
113 1
319 0
2
0 122 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut55
3
0 0
113 1
320 0
2
0 124 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut56
3
0 0
113 1
321 0
2
0 126 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut6
3
0 0
113 1
322 0
2
0 128 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut7
3
0 0
113 1
323 0
2
0 130 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut8
3
0 0
113 1
324 0
2
0 132 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut9
3
0 0
113 1
325 0
2
0 134 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut1
3
0 0
115 1
223 0
2
0 24 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut10
3
0 0
115 1
225 0
2
0 26 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut11
3
0 0
115 1
227 0
2
0 28 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut12
3
0 0
115 1
229 0
2
0 30 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut13
3
0 0
115 1
231 0
2
0 32 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut14
3
0 0
115 1
233 0
2
0 34 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut15
3
0 0
115 1
235 0
2
0 36 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut16
3
0 0
115 1
237 0
2
0 38 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut17
3
0 0
115 1
239 0
2
0 40 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut18
3
0 0
115 1
241 0
2
0 42 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut19
3
0 0
115 1
243 0
2
0 44 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut2
3
0 0
115 1
245 0
2
0 46 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut20
3
0 0
115 1
247 0
2
0 48 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut21
3
0 0
115 1
249 0
2
0 50 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut22
3
0 0
115 1
251 0
2
0 52 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut23
3
0 0
115 1
253 0
2
0 54 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut24
3
0 0
115 1
255 0
2
0 56 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut25
3
0 0
115 1
257 0
2
0 58 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut26
3
0 0
115 1
259 0
2
0 60 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut27
3
0 0
115 1
261 0
2
0 62 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut28
3
0 0
115 1
263 0
2
0 64 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut29
3
0 0
115 1
265 0
2
0 66 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut3
3
0 0
115 1
267 0
2
0 68 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut30
3
0 0
115 1
269 0
2
0 70 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut31
3
0 0
115 1
271 0
2
0 72 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut32
3
0 0
115 1
273 0
2
0 74 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut33
3
0 0
115 1
275 0
2
0 76 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut34
3
0 0
115 1
277 0
2
0 78 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut35
3
0 0
115 1
279 0
2
0 80 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut36
3
0 0
115 1
281 0
2
0 82 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut37
3
0 0
115 1
283 0
2
0 84 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut38
3
0 0
115 1
285 0
2
0 86 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut39
3
0 0
115 1
287 0
2
0 88 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut4
3
0 0
115 1
289 0
2
0 90 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut40
3
0 0
115 1
291 0
2
0 92 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut41
3
0 0
115 1
293 0
2
0 94 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut42
3
0 0
115 1
295 0
2
0 96 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut43
3
0 0
115 1
297 0
2
0 98 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut44
3
0 0
115 1
299 0
2
0 100 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut45
3
0 0
115 1
301 0
2
0 102 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut46
3
0 0
115 1
303 0
2
0 104 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut47
3
0 0
115 1
305 0
2
0 106 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut48
3
0 0
115 1
307 0
2
0 108 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut49
3
0 0
115 1
309 0
2
0 110 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut5
3
0 0
115 1
311 0
2
0 112 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut50
3
0 0
115 1
313 0
2
0 114 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut51
3
0 0
115 1
315 0
2
0 116 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut52
3
0 0
115 1
317 0
2
0 118 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut53
3
0 0
115 1
318 0
2
0 120 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut54
3
0 0
115 1
319 0
2
0 122 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut55
3
0 0
115 1
320 0
2
0 124 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut56
3
0 0
115 1
321 0
2
0 126 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut6
3
0 0
115 1
322 0
2
0 128 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut7
3
0 0
115 1
323 0
2
0 130 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut8
3
0 0
115 1
324 0
2
0 132 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut9
3
0 0
115 1
325 0
2
0 134 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
117 1
223 0
2
0 24 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
117 1
225 0
2
0 26 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
117 1
227 0
2
0 28 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
117 1
229 0
2
0 30 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
117 1
231 0
2
0 32 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
117 1
233 0
2
0 34 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
117 1
235 0
2
0 36 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
117 1
237 0
2
0 38 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
117 1
239 0
2
0 40 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
117 1
241 0
2
0 42 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
117 1
243 0
2
0 44 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
117 1
245 0
2
0 46 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
117 1
247 0
2
0 48 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
117 1
249 0
2
0 50 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
117 1
251 0
2
0 52 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
117 1
253 0
2
0 54 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
117 1
255 0
2
0 56 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
117 1
257 0
2
0 58 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
117 1
259 0
2
0 60 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
117 1
261 0
2
0 62 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
117 1
263 0
2
0 64 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
117 1
265 0
2
0 66 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
117 1
267 0
2
0 68 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
117 1
269 0
2
0 70 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut31
3
0 0
117 1
271 0
2
0 72 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut32
3
0 0
117 1
273 0
2
0 74 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut33
3
0 0
117 1
275 0
2
0 76 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut34
3
0 0
117 1
277 0
2
0 78 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut35
3
0 0
117 1
279 0
2
0 80 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut36
3
0 0
117 1
281 0
2
0 82 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut37
3
0 0
117 1
283 0
2
0 84 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut38
3
0 0
117 1
285 0
2
0 86 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut39
3
0 0
117 1
287 0
2
0 88 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
117 1
289 0
2
0 90 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut40
3
0 0
117 1
291 0
2
0 92 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut41
3
0 0
117 1
293 0
2
0 94 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut42
3
0 0
117 1
295 0
2
0 96 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut43
3
0 0
117 1
297 0
2
0 98 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut44
3
0 0
117 1
299 0
2
0 100 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut45
3
0 0
117 1
301 0
2
0 102 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut46
3
0 0
117 1
303 0
2
0 104 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut47
3
0 0
117 1
305 0
2
0 106 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut48
3
0 0
117 1
307 0
2
0 108 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut49
3
0 0
117 1
309 0
2
0 110 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
117 1
311 0
2
0 112 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut50
3
0 0
117 1
313 0
2
0 114 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut51
3
0 0
117 1
315 0
2
0 116 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut52
3
0 0
117 1
317 0
2
0 118 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut53
3
0 0
117 1
318 0
2
0 120 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut54
3
0 0
117 1
319 0
2
0 122 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut55
3
0 0
117 1
320 0
2
0 124 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut56
3
0 0
117 1
321 0
2
0 126 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
117 1
322 0
2
0 128 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
117 1
323 0
2
0 130 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
117 1
324 0
2
0 132 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
117 1
325 0
2
0 134 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut1
3
0 0
119 1
223 0
2
0 24 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut10
3
0 0
119 1
225 0
2
0 26 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut11
3
0 0
119 1
227 0
2
0 28 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut12
3
0 0
119 1
229 0
2
0 30 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut13
3
0 0
119 1
231 0
2
0 32 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut14
3
0 0
119 1
233 0
2
0 34 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut15
3
0 0
119 1
235 0
2
0 36 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut16
3
0 0
119 1
237 0
2
0 38 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut17
3
0 0
119 1
239 0
2
0 40 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut18
3
0 0
119 1
241 0
2
0 42 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut19
3
0 0
119 1
243 0
2
0 44 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut2
3
0 0
119 1
245 0
2
0 46 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut20
3
0 0
119 1
247 0
2
0 48 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut21
3
0 0
119 1
249 0
2
0 50 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut22
3
0 0
119 1
251 0
2
0 52 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut23
3
0 0
119 1
253 0
2
0 54 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut24
3
0 0
119 1
255 0
2
0 56 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut25
3
0 0
119 1
257 0
2
0 58 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut26
3
0 0
119 1
259 0
2
0 60 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut27
3
0 0
119 1
261 0
2
0 62 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut28
3
0 0
119 1
263 0
2
0 64 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut29
3
0 0
119 1
265 0
2
0 66 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut3
3
0 0
119 1
267 0
2
0 68 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut30
3
0 0
119 1
269 0
2
0 70 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut31
3
0 0
119 1
271 0
2
0 72 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut32
3
0 0
119 1
273 0
2
0 74 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut33
3
0 0
119 1
275 0
2
0 76 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut34
3
0 0
119 1
277 0
2
0 78 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut35
3
0 0
119 1
279 0
2
0 80 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut36
3
0 0
119 1
281 0
2
0 82 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut37
3
0 0
119 1
283 0
2
0 84 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut38
3
0 0
119 1
285 0
2
0 86 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut39
3
0 0
119 1
287 0
2
0 88 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut4
3
0 0
119 1
289 0
2
0 90 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut40
3
0 0
119 1
291 0
2
0 92 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut41
3
0 0
119 1
293 0
2
0 94 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut42
3
0 0
119 1
295 0
2
0 96 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut43
3
0 0
119 1
297 0
2
0 98 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut44
3
0 0
119 1
299 0
2
0 100 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut45
3
0 0
119 1
301 0
2
0 102 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut46
3
0 0
119 1
303 0
2
0 104 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut47
3
0 0
119 1
305 0
2
0 106 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut48
3
0 0
119 1
307 0
2
0 108 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut49
3
0 0
119 1
309 0
2
0 110 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut5
3
0 0
119 1
311 0
2
0 112 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut50
3
0 0
119 1
313 0
2
0 114 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut51
3
0 0
119 1
315 0
2
0 116 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut52
3
0 0
119 1
317 0
2
0 118 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut53
3
0 0
119 1
318 0
2
0 120 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut54
3
0 0
119 1
319 0
2
0 122 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut55
3
0 0
119 1
320 0
2
0 124 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut56
3
0 0
119 1
321 0
2
0 126 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut6
3
0 0
119 1
322 0
2
0 128 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut7
3
0 0
119 1
323 0
2
0 130 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut8
3
0 0
119 1
324 0
2
0 132 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut9
3
0 0
119 1
325 0
2
0 134 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut1
3
0 0
121 1
223 0
2
0 24 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut10
3
0 0
121 1
225 0
2
0 26 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut11
3
0 0
121 1
227 0
2
0 28 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut12
3
0 0
121 1
229 0
2
0 30 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut13
3
0 0
121 1
231 0
2
0 32 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut14
3
0 0
121 1
233 0
2
0 34 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut15
3
0 0
121 1
235 0
2
0 36 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut16
3
0 0
121 1
237 0
2
0 38 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut17
3
0 0
121 1
239 0
2
0 40 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut18
3
0 0
121 1
241 0
2
0 42 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut19
3
0 0
121 1
243 0
2
0 44 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut2
3
0 0
121 1
245 0
2
0 46 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut20
3
0 0
121 1
247 0
2
0 48 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut21
3
0 0
121 1
249 0
2
0 50 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut22
3
0 0
121 1
251 0
2
0 52 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut23
3
0 0
121 1
253 0
2
0 54 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut24
3
0 0
121 1
255 0
2
0 56 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut25
3
0 0
121 1
257 0
2
0 58 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut26
3
0 0
121 1
259 0
2
0 60 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut27
3
0 0
121 1
261 0
2
0 62 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut28
3
0 0
121 1
263 0
2
0 64 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut29
3
0 0
121 1
265 0
2
0 66 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut3
3
0 0
121 1
267 0
2
0 68 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut30
3
0 0
121 1
269 0
2
0 70 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut31
3
0 0
121 1
271 0
2
0 72 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut32
3
0 0
121 1
273 0
2
0 74 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut33
3
0 0
121 1
275 0
2
0 76 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut34
3
0 0
121 1
277 0
2
0 78 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut35
3
0 0
121 1
279 0
2
0 80 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut36
3
0 0
121 1
281 0
2
0 82 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut37
3
0 0
121 1
283 0
2
0 84 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut38
3
0 0
121 1
285 0
2
0 86 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut39
3
0 0
121 1
287 0
2
0 88 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut4
3
0 0
121 1
289 0
2
0 90 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut40
3
0 0
121 1
291 0
2
0 92 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut41
3
0 0
121 1
293 0
2
0 94 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut42
3
0 0
121 1
295 0
2
0 96 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut43
3
0 0
121 1
297 0
2
0 98 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut44
3
0 0
121 1
299 0
2
0 100 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut45
3
0 0
121 1
301 0
2
0 102 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut46
3
0 0
121 1
303 0
2
0 104 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut47
3
0 0
121 1
305 0
2
0 106 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut48
3
0 0
121 1
307 0
2
0 108 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut49
3
0 0
121 1
309 0
2
0 110 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut5
3
0 0
121 1
311 0
2
0 112 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut50
3
0 0
121 1
313 0
2
0 114 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut51
3
0 0
121 1
315 0
2
0 116 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut52
3
0 0
121 1
317 0
2
0 118 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut53
3
0 0
121 1
318 0
2
0 120 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut54
3
0 0
121 1
319 0
2
0 122 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut55
3
0 0
121 1
320 0
2
0 124 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut56
3
0 0
121 1
321 0
2
0 126 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut6
3
0 0
121 1
322 0
2
0 128 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut7
3
0 0
121 1
323 0
2
0 130 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut8
3
0 0
121 1
324 0
2
0 132 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut9
3
0 0
121 1
325 0
2
0 134 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut1
3
0 0
123 1
223 0
2
0 24 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut10
3
0 0
123 1
225 0
2
0 26 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut11
3
0 0
123 1
227 0
2
0 28 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut12
3
0 0
123 1
229 0
2
0 30 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut13
3
0 0
123 1
231 0
2
0 32 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut14
3
0 0
123 1
233 0
2
0 34 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut15
3
0 0
123 1
235 0
2
0 36 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut16
3
0 0
123 1
237 0
2
0 38 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut17
3
0 0
123 1
239 0
2
0 40 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut18
3
0 0
123 1
241 0
2
0 42 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut19
3
0 0
123 1
243 0
2
0 44 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut2
3
0 0
123 1
245 0
2
0 46 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut20
3
0 0
123 1
247 0
2
0 48 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut21
3
0 0
123 1
249 0
2
0 50 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut22
3
0 0
123 1
251 0
2
0 52 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut23
3
0 0
123 1
253 0
2
0 54 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut24
3
0 0
123 1
255 0
2
0 56 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut25
3
0 0
123 1
257 0
2
0 58 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut26
3
0 0
123 1
259 0
2
0 60 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut27
3
0 0
123 1
261 0
2
0 62 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut28
3
0 0
123 1
263 0
2
0 64 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut29
3
0 0
123 1
265 0
2
0 66 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut3
3
0 0
123 1
267 0
2
0 68 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut30
3
0 0
123 1
269 0
2
0 70 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut31
3
0 0
123 1
271 0
2
0 72 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut32
3
0 0
123 1
273 0
2
0 74 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut33
3
0 0
123 1
275 0
2
0 76 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut34
3
0 0
123 1
277 0
2
0 78 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut35
3
0 0
123 1
279 0
2
0 80 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut36
3
0 0
123 1
281 0
2
0 82 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut37
3
0 0
123 1
283 0
2
0 84 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut38
3
0 0
123 1
285 0
2
0 86 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut39
3
0 0
123 1
287 0
2
0 88 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut4
3
0 0
123 1
289 0
2
0 90 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut40
3
0 0
123 1
291 0
2
0 92 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut41
3
0 0
123 1
293 0
2
0 94 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut42
3
0 0
123 1
295 0
2
0 96 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut43
3
0 0
123 1
297 0
2
0 98 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut44
3
0 0
123 1
299 0
2
0 100 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut45
3
0 0
123 1
301 0
2
0 102 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut46
3
0 0
123 1
303 0
2
0 104 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut47
3
0 0
123 1
305 0
2
0 106 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut48
3
0 0
123 1
307 0
2
0 108 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut49
3
0 0
123 1
309 0
2
0 110 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut5
3
0 0
123 1
311 0
2
0 112 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut50
3
0 0
123 1
313 0
2
0 114 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut51
3
0 0
123 1
315 0
2
0 116 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut52
3
0 0
123 1
317 0
2
0 118 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut53
3
0 0
123 1
318 0
2
0 120 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut54
3
0 0
123 1
319 0
2
0 122 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut55
3
0 0
123 1
320 0
2
0 124 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut56
3
0 0
123 1
321 0
2
0 126 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut6
3
0 0
123 1
322 0
2
0 128 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut7
3
0 0
123 1
323 0
2
0 130 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut8
3
0 0
123 1
324 0
2
0 132 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut9
3
0 0
123 1
325 0
2
0 134 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut1
3
0 0
125 1
223 0
2
0 24 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut10
3
0 0
125 1
225 0
2
0 26 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut11
3
0 0
125 1
227 0
2
0 28 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut12
3
0 0
125 1
229 0
2
0 30 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut13
3
0 0
125 1
231 0
2
0 32 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut14
3
0 0
125 1
233 0
2
0 34 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut15
3
0 0
125 1
235 0
2
0 36 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut16
3
0 0
125 1
237 0
2
0 38 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut17
3
0 0
125 1
239 0
2
0 40 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut18
3
0 0
125 1
241 0
2
0 42 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut19
3
0 0
125 1
243 0
2
0 44 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut2
3
0 0
125 1
245 0
2
0 46 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut20
3
0 0
125 1
247 0
2
0 48 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut21
3
0 0
125 1
249 0
2
0 50 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut22
3
0 0
125 1
251 0
2
0 52 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut23
3
0 0
125 1
253 0
2
0 54 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut24
3
0 0
125 1
255 0
2
0 56 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut25
3
0 0
125 1
257 0
2
0 58 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut26
3
0 0
125 1
259 0
2
0 60 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut27
3
0 0
125 1
261 0
2
0 62 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut28
3
0 0
125 1
263 0
2
0 64 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut29
3
0 0
125 1
265 0
2
0 66 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut3
3
0 0
125 1
267 0
2
0 68 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut30
3
0 0
125 1
269 0
2
0 70 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut31
3
0 0
125 1
271 0
2
0 72 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut32
3
0 0
125 1
273 0
2
0 74 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut33
3
0 0
125 1
275 0
2
0 76 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut34
3
0 0
125 1
277 0
2
0 78 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut35
3
0 0
125 1
279 0
2
0 80 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut36
3
0 0
125 1
281 0
2
0 82 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut37
3
0 0
125 1
283 0
2
0 84 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut38
3
0 0
125 1
285 0
2
0 86 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut39
3
0 0
125 1
287 0
2
0 88 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut4
3
0 0
125 1
289 0
2
0 90 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut40
3
0 0
125 1
291 0
2
0 92 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut41
3
0 0
125 1
293 0
2
0 94 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut42
3
0 0
125 1
295 0
2
0 96 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut43
3
0 0
125 1
297 0
2
0 98 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut44
3
0 0
125 1
299 0
2
0 100 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut45
3
0 0
125 1
301 0
2
0 102 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut46
3
0 0
125 1
303 0
2
0 104 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut47
3
0 0
125 1
305 0
2
0 106 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut48
3
0 0
125 1
307 0
2
0 108 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut49
3
0 0
125 1
309 0
2
0 110 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut5
3
0 0
125 1
311 0
2
0 112 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut50
3
0 0
125 1
313 0
2
0 114 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut51
3
0 0
125 1
315 0
2
0 116 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut52
3
0 0
125 1
317 0
2
0 118 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut53
3
0 0
125 1
318 0
2
0 120 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut54
3
0 0
125 1
319 0
2
0 122 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut55
3
0 0
125 1
320 0
2
0 124 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut56
3
0 0
125 1
321 0
2
0 126 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut6
3
0 0
125 1
322 0
2
0 128 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut7
3
0 0
125 1
323 0
2
0 130 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut8
3
0 0
125 1
324 0
2
0 132 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut9
3
0 0
125 1
325 0
2
0 134 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut1
3
0 0
127 1
223 0
2
0 24 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut10
3
0 0
127 1
225 0
2
0 26 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut11
3
0 0
127 1
227 0
2
0 28 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut12
3
0 0
127 1
229 0
2
0 30 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut13
3
0 0
127 1
231 0
2
0 32 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut14
3
0 0
127 1
233 0
2
0 34 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut15
3
0 0
127 1
235 0
2
0 36 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut16
3
0 0
127 1
237 0
2
0 38 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut17
3
0 0
127 1
239 0
2
0 40 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut18
3
0 0
127 1
241 0
2
0 42 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut19
3
0 0
127 1
243 0
2
0 44 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut2
3
0 0
127 1
245 0
2
0 46 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut20
3
0 0
127 1
247 0
2
0 48 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut21
3
0 0
127 1
249 0
2
0 50 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut22
3
0 0
127 1
251 0
2
0 52 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut23
3
0 0
127 1
253 0
2
0 54 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut24
3
0 0
127 1
255 0
2
0 56 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut25
3
0 0
127 1
257 0
2
0 58 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut26
3
0 0
127 1
259 0
2
0 60 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut27
3
0 0
127 1
261 0
2
0 62 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut28
3
0 0
127 1
263 0
2
0 64 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut29
3
0 0
127 1
265 0
2
0 66 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut3
3
0 0
127 1
267 0
2
0 68 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut30
3
0 0
127 1
269 0
2
0 70 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut31
3
0 0
127 1
271 0
2
0 72 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut32
3
0 0
127 1
273 0
2
0 74 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut33
3
0 0
127 1
275 0
2
0 76 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut34
3
0 0
127 1
277 0
2
0 78 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut35
3
0 0
127 1
279 0
2
0 80 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut36
3
0 0
127 1
281 0
2
0 82 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut37
3
0 0
127 1
283 0
2
0 84 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut38
3
0 0
127 1
285 0
2
0 86 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut39
3
0 0
127 1
287 0
2
0 88 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut4
3
0 0
127 1
289 0
2
0 90 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut40
3
0 0
127 1
291 0
2
0 92 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut41
3
0 0
127 1
293 0
2
0 94 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut42
3
0 0
127 1
295 0
2
0 96 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut43
3
0 0
127 1
297 0
2
0 98 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut44
3
0 0
127 1
299 0
2
0 100 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut45
3
0 0
127 1
301 0
2
0 102 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut46
3
0 0
127 1
303 0
2
0 104 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut47
3
0 0
127 1
305 0
2
0 106 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut48
3
0 0
127 1
307 0
2
0 108 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut49
3
0 0
127 1
309 0
2
0 110 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut5
3
0 0
127 1
311 0
2
0 112 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut50
3
0 0
127 1
313 0
2
0 114 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut51
3
0 0
127 1
315 0
2
0 116 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut52
3
0 0
127 1
317 0
2
0 118 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut53
3
0 0
127 1
318 0
2
0 120 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut54
3
0 0
127 1
319 0
2
0 122 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut55
3
0 0
127 1
320 0
2
0 124 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut56
3
0 0
127 1
321 0
2
0 126 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut6
3
0 0
127 1
322 0
2
0 128 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut7
3
0 0
127 1
323 0
2
0 130 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut8
3
0 0
127 1
324 0
2
0 132 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut9
3
0 0
127 1
325 0
2
0 134 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut1
3
0 0
129 1
223 0
2
0 24 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut10
3
0 0
129 1
225 0
2
0 26 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut11
3
0 0
129 1
227 0
2
0 28 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut12
3
0 0
129 1
229 0
2
0 30 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut13
3
0 0
129 1
231 0
2
0 32 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut14
3
0 0
129 1
233 0
2
0 34 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut15
3
0 0
129 1
235 0
2
0 36 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut16
3
0 0
129 1
237 0
2
0 38 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut17
3
0 0
129 1
239 0
2
0 40 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut18
3
0 0
129 1
241 0
2
0 42 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut19
3
0 0
129 1
243 0
2
0 44 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut2
3
0 0
129 1
245 0
2
0 46 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut20
3
0 0
129 1
247 0
2
0 48 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut21
3
0 0
129 1
249 0
2
0 50 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut22
3
0 0
129 1
251 0
2
0 52 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut23
3
0 0
129 1
253 0
2
0 54 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut24
3
0 0
129 1
255 0
2
0 56 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut25
3
0 0
129 1
257 0
2
0 58 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut26
3
0 0
129 1
259 0
2
0 60 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut27
3
0 0
129 1
261 0
2
0 62 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut28
3
0 0
129 1
263 0
2
0 64 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut29
3
0 0
129 1
265 0
2
0 66 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut3
3
0 0
129 1
267 0
2
0 68 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut30
3
0 0
129 1
269 0
2
0 70 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut31
3
0 0
129 1
271 0
2
0 72 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut32
3
0 0
129 1
273 0
2
0 74 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut33
3
0 0
129 1
275 0
2
0 76 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut34
3
0 0
129 1
277 0
2
0 78 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut35
3
0 0
129 1
279 0
2
0 80 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut36
3
0 0
129 1
281 0
2
0 82 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut37
3
0 0
129 1
283 0
2
0 84 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut38
3
0 0
129 1
285 0
2
0 86 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut39
3
0 0
129 1
287 0
2
0 88 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut4
3
0 0
129 1
289 0
2
0 90 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut40
3
0 0
129 1
291 0
2
0 92 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut41
3
0 0
129 1
293 0
2
0 94 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut42
3
0 0
129 1
295 0
2
0 96 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut43
3
0 0
129 1
297 0
2
0 98 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut44
3
0 0
129 1
299 0
2
0 100 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut45
3
0 0
129 1
301 0
2
0 102 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut46
3
0 0
129 1
303 0
2
0 104 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut47
3
0 0
129 1
305 0
2
0 106 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut48
3
0 0
129 1
307 0
2
0 108 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut49
3
0 0
129 1
309 0
2
0 110 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut5
3
0 0
129 1
311 0
2
0 112 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut50
3
0 0
129 1
313 0
2
0 114 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut51
3
0 0
129 1
315 0
2
0 116 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut52
3
0 0
129 1
317 0
2
0 118 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut53
3
0 0
129 1
318 0
2
0 120 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut54
3
0 0
129 1
319 0
2
0 122 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut55
3
0 0
129 1
320 0
2
0 124 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut56
3
0 0
129 1
321 0
2
0 126 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut6
3
0 0
129 1
322 0
2
0 128 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut7
3
0 0
129 1
323 0
2
0 130 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut8
3
0 0
129 1
324 0
2
0 132 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut9
3
0 0
129 1
325 0
2
0 134 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut1
3
0 0
131 1
223 0
2
0 24 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut10
3
0 0
131 1
225 0
2
0 26 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut11
3
0 0
131 1
227 0
2
0 28 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut12
3
0 0
131 1
229 0
2
0 30 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut13
3
0 0
131 1
231 0
2
0 32 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut14
3
0 0
131 1
233 0
2
0 34 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut15
3
0 0
131 1
235 0
2
0 36 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut16
3
0 0
131 1
237 0
2
0 38 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut17
3
0 0
131 1
239 0
2
0 40 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut18
3
0 0
131 1
241 0
2
0 42 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut19
3
0 0
131 1
243 0
2
0 44 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut2
3
0 0
131 1
245 0
2
0 46 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut20
3
0 0
131 1
247 0
2
0 48 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut21
3
0 0
131 1
249 0
2
0 50 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut22
3
0 0
131 1
251 0
2
0 52 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut23
3
0 0
131 1
253 0
2
0 54 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut24
3
0 0
131 1
255 0
2
0 56 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut25
3
0 0
131 1
257 0
2
0 58 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut26
3
0 0
131 1
259 0
2
0 60 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut27
3
0 0
131 1
261 0
2
0 62 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut28
3
0 0
131 1
263 0
2
0 64 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut29
3
0 0
131 1
265 0
2
0 66 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut3
3
0 0
131 1
267 0
2
0 68 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut30
3
0 0
131 1
269 0
2
0 70 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut31
3
0 0
131 1
271 0
2
0 72 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut32
3
0 0
131 1
273 0
2
0 74 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut33
3
0 0
131 1
275 0
2
0 76 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut34
3
0 0
131 1
277 0
2
0 78 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut35
3
0 0
131 1
279 0
2
0 80 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut36
3
0 0
131 1
281 0
2
0 82 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut37
3
0 0
131 1
283 0
2
0 84 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut38
3
0 0
131 1
285 0
2
0 86 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut39
3
0 0
131 1
287 0
2
0 88 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut4
3
0 0
131 1
289 0
2
0 90 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut40
3
0 0
131 1
291 0
2
0 92 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut41
3
0 0
131 1
293 0
2
0 94 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut42
3
0 0
131 1
295 0
2
0 96 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut43
3
0 0
131 1
297 0
2
0 98 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut44
3
0 0
131 1
299 0
2
0 100 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut45
3
0 0
131 1
301 0
2
0 102 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut46
3
0 0
131 1
303 0
2
0 104 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut47
3
0 0
131 1
305 0
2
0 106 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut48
3
0 0
131 1
307 0
2
0 108 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut49
3
0 0
131 1
309 0
2
0 110 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut5
3
0 0
131 1
311 0
2
0 112 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut50
3
0 0
131 1
313 0
2
0 114 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut51
3
0 0
131 1
315 0
2
0 116 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut52
3
0 0
131 1
317 0
2
0 118 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut53
3
0 0
131 1
318 0
2
0 120 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut54
3
0 0
131 1
319 0
2
0 122 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut55
3
0 0
131 1
320 0
2
0 124 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut56
3
0 0
131 1
321 0
2
0 126 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut6
3
0 0
131 1
322 0
2
0 128 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut7
3
0 0
131 1
323 0
2
0 130 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut8
3
0 0
131 1
324 0
2
0 132 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut9
3
0 0
131 1
325 0
2
0 134 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut1
3
0 0
133 1
223 0
2
0 24 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut10
3
0 0
133 1
225 0
2
0 26 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut11
3
0 0
133 1
227 0
2
0 28 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut12
3
0 0
133 1
229 0
2
0 30 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut13
3
0 0
133 1
231 0
2
0 32 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut14
3
0 0
133 1
233 0
2
0 34 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut15
3
0 0
133 1
235 0
2
0 36 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut16
3
0 0
133 1
237 0
2
0 38 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut17
3
0 0
133 1
239 0
2
0 40 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut18
3
0 0
133 1
241 0
2
0 42 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut19
3
0 0
133 1
243 0
2
0 44 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut2
3
0 0
133 1
245 0
2
0 46 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut20
3
0 0
133 1
247 0
2
0 48 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut21
3
0 0
133 1
249 0
2
0 50 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut22
3
0 0
133 1
251 0
2
0 52 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut23
3
0 0
133 1
253 0
2
0 54 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut24
3
0 0
133 1
255 0
2
0 56 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut25
3
0 0
133 1
257 0
2
0 58 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut26
3
0 0
133 1
259 0
2
0 60 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut27
3
0 0
133 1
261 0
2
0 62 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut28
3
0 0
133 1
263 0
2
0 64 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut29
3
0 0
133 1
265 0
2
0 66 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut3
3
0 0
133 1
267 0
2
0 68 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut30
3
0 0
133 1
269 0
2
0 70 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut31
3
0 0
133 1
271 0
2
0 72 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut32
3
0 0
133 1
273 0
2
0 74 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut33
3
0 0
133 1
275 0
2
0 76 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut34
3
0 0
133 1
277 0
2
0 78 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut35
3
0 0
133 1
279 0
2
0 80 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut36
3
0 0
133 1
281 0
2
0 82 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut37
3
0 0
133 1
283 0
2
0 84 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut38
3
0 0
133 1
285 0
2
0 86 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut39
3
0 0
133 1
287 0
2
0 88 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut4
3
0 0
133 1
289 0
2
0 90 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut40
3
0 0
133 1
291 0
2
0 92 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut41
3
0 0
133 1
293 0
2
0 94 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut42
3
0 0
133 1
295 0
2
0 96 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut43
3
0 0
133 1
297 0
2
0 98 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut44
3
0 0
133 1
299 0
2
0 100 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut45
3
0 0
133 1
301 0
2
0 102 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut46
3
0 0
133 1
303 0
2
0 104 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut47
3
0 0
133 1
305 0
2
0 106 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut48
3
0 0
133 1
307 0
2
0 108 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut49
3
0 0
133 1
309 0
2
0 110 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut5
3
0 0
133 1
311 0
2
0 112 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut50
3
0 0
133 1
313 0
2
0 114 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut51
3
0 0
133 1
315 0
2
0 116 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut52
3
0 0
133 1
317 0
2
0 118 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut53
3
0 0
133 1
318 0
2
0 120 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut54
3
0 0
133 1
319 0
2
0 122 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut55
3
0 0
133 1
320 0
2
0 124 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut56
3
0 0
133 1
321 0
2
0 126 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut6
3
0 0
133 1
322 0
2
0 128 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut7
3
0 0
133 1
323 0
2
0 130 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut8
3
0 0
133 1
324 0
2
0 132 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut9
3
0 0
133 1
325 0
2
0 134 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut1
3
0 0
135 1
223 0
2
0 24 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut10
3
0 0
135 1
225 0
2
0 26 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut11
3
0 0
135 1
227 0
2
0 28 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut12
3
0 0
135 1
229 0
2
0 30 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut13
3
0 0
135 1
231 0
2
0 32 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut14
3
0 0
135 1
233 0
2
0 34 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut15
3
0 0
135 1
235 0
2
0 36 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut16
3
0 0
135 1
237 0
2
0 38 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut17
3
0 0
135 1
239 0
2
0 40 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut18
3
0 0
135 1
241 0
2
0 42 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut19
3
0 0
135 1
243 0
2
0 44 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut2
3
0 0
135 1
245 0
2
0 46 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut20
3
0 0
135 1
247 0
2
0 48 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut21
3
0 0
135 1
249 0
2
0 50 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut22
3
0 0
135 1
251 0
2
0 52 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut23
3
0 0
135 1
253 0
2
0 54 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut24
3
0 0
135 1
255 0
2
0 56 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut25
3
0 0
135 1
257 0
2
0 58 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut26
3
0 0
135 1
259 0
2
0 60 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut27
3
0 0
135 1
261 0
2
0 62 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut28
3
0 0
135 1
263 0
2
0 64 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut29
3
0 0
135 1
265 0
2
0 66 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut3
3
0 0
135 1
267 0
2
0 68 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut30
3
0 0
135 1
269 0
2
0 70 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut31
3
0 0
135 1
271 0
2
0 72 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut32
3
0 0
135 1
273 0
2
0 74 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut33
3
0 0
135 1
275 0
2
0 76 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut34
3
0 0
135 1
277 0
2
0 78 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut35
3
0 0
135 1
279 0
2
0 80 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut36
3
0 0
135 1
281 0
2
0 82 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut37
3
0 0
135 1
283 0
2
0 84 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut38
3
0 0
135 1
285 0
2
0 86 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut39
3
0 0
135 1
287 0
2
0 88 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut4
3
0 0
135 1
289 0
2
0 90 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut40
3
0 0
135 1
291 0
2
0 92 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut41
3
0 0
135 1
293 0
2
0 94 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut42
3
0 0
135 1
295 0
2
0 96 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut43
3
0 0
135 1
297 0
2
0 98 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut44
3
0 0
135 1
299 0
2
0 100 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut45
3
0 0
135 1
301 0
2
0 102 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut46
3
0 0
135 1
303 0
2
0 104 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut47
3
0 0
135 1
305 0
2
0 106 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut48
3
0 0
135 1
307 0
2
0 108 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut49
3
0 0
135 1
309 0
2
0 110 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut5
3
0 0
135 1
311 0
2
0 112 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut50
3
0 0
135 1
313 0
2
0 114 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut51
3
0 0
135 1
315 0
2
0 116 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut52
3
0 0
135 1
317 0
2
0 118 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut53
3
0 0
135 1
318 0
2
0 120 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut54
3
0 0
135 1
319 0
2
0 122 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut55
3
0 0
135 1
320 0
2
0 124 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut56
3
0 0
135 1
321 0
2
0 126 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut6
3
0 0
135 1
322 0
2
0 128 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut7
3
0 0
135 1
323 0
2
0 130 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut8
3
0 0
135 1
324 0
2
0 132 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut9
3
0 0
135 1
325 0
2
0 134 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut1
3
0 0
136 1
223 0
2
0 24 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut10
3
0 0
136 1
225 0
2
0 26 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut11
3
0 0
136 1
227 0
2
0 28 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut12
3
0 0
136 1
229 0
2
0 30 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut13
3
0 0
136 1
231 0
2
0 32 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut14
3
0 0
136 1
233 0
2
0 34 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut15
3
0 0
136 1
235 0
2
0 36 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut16
3
0 0
136 1
237 0
2
0 38 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut17
3
0 0
136 1
239 0
2
0 40 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut18
3
0 0
136 1
241 0
2
0 42 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut19
3
0 0
136 1
243 0
2
0 44 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut2
3
0 0
136 1
245 0
2
0 46 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut20
3
0 0
136 1
247 0
2
0 48 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut21
3
0 0
136 1
249 0
2
0 50 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut22
3
0 0
136 1
251 0
2
0 52 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut23
3
0 0
136 1
253 0
2
0 54 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut24
3
0 0
136 1
255 0
2
0 56 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut25
3
0 0
136 1
257 0
2
0 58 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut26
3
0 0
136 1
259 0
2
0 60 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut27
3
0 0
136 1
261 0
2
0 62 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut28
3
0 0
136 1
263 0
2
0 64 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut29
3
0 0
136 1
265 0
2
0 66 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut3
3
0 0
136 1
267 0
2
0 68 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut30
3
0 0
136 1
269 0
2
0 70 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut31
3
0 0
136 1
271 0
2
0 72 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut32
3
0 0
136 1
273 0
2
0 74 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut33
3
0 0
136 1
275 0
2
0 76 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut34
3
0 0
136 1
277 0
2
0 78 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut35
3
0 0
136 1
279 0
2
0 80 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut36
3
0 0
136 1
281 0
2
0 82 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut37
3
0 0
136 1
283 0
2
0 84 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut38
3
0 0
136 1
285 0
2
0 86 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut39
3
0 0
136 1
287 0
2
0 88 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut4
3
0 0
136 1
289 0
2
0 90 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut40
3
0 0
136 1
291 0
2
0 92 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut41
3
0 0
136 1
293 0
2
0 94 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut42
3
0 0
136 1
295 0
2
0 96 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut43
3
0 0
136 1
297 0
2
0 98 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut44
3
0 0
136 1
299 0
2
0 100 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut45
3
0 0
136 1
301 0
2
0 102 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut46
3
0 0
136 1
303 0
2
0 104 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut47
3
0 0
136 1
305 0
2
0 106 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut48
3
0 0
136 1
307 0
2
0 108 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut49
3
0 0
136 1
309 0
2
0 110 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut5
3
0 0
136 1
311 0
2
0 112 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut50
3
0 0
136 1
313 0
2
0 114 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut51
3
0 0
136 1
315 0
2
0 116 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut52
3
0 0
136 1
317 0
2
0 118 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut53
3
0 0
136 1
318 0
2
0 120 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut54
3
0 0
136 1
319 0
2
0 122 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut55
3
0 0
136 1
320 0
2
0 124 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut56
3
0 0
136 1
321 0
2
0 126 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut6
3
0 0
136 1
322 0
2
0 128 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut7
3
0 0
136 1
323 0
2
0 130 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut8
3
0 0
136 1
324 0
2
0 132 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut9
3
0 0
136 1
325 0
2
0 134 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
137 1
223 0
2
0 24 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
137 1
225 0
2
0 26 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
137 1
227 0
2
0 28 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
137 1
229 0
2
0 30 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
137 1
231 0
2
0 32 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
137 1
233 0
2
0 34 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
137 1
235 0
2
0 36 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
137 1
237 0
2
0 38 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
137 1
239 0
2
0 40 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
137 1
241 0
2
0 42 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
137 1
243 0
2
0 44 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
137 1
245 0
2
0 46 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
137 1
247 0
2
0 48 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
137 1
249 0
2
0 50 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
137 1
251 0
2
0 52 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
137 1
253 0
2
0 54 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
137 1
255 0
2
0 56 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
137 1
257 0
2
0 58 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
137 1
259 0
2
0 60 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
137 1
261 0
2
0 62 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
137 1
263 0
2
0 64 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
137 1
265 0
2
0 66 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
137 1
267 0
2
0 68 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
137 1
269 0
2
0 70 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut31
3
0 0
137 1
271 0
2
0 72 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut32
3
0 0
137 1
273 0
2
0 74 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut33
3
0 0
137 1
275 0
2
0 76 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut34
3
0 0
137 1
277 0
2
0 78 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut35
3
0 0
137 1
279 0
2
0 80 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut36
3
0 0
137 1
281 0
2
0 82 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut37
3
0 0
137 1
283 0
2
0 84 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut38
3
0 0
137 1
285 0
2
0 86 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut39
3
0 0
137 1
287 0
2
0 88 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
137 1
289 0
2
0 90 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut40
3
0 0
137 1
291 0
2
0 92 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut41
3
0 0
137 1
293 0
2
0 94 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut42
3
0 0
137 1
295 0
2
0 96 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut43
3
0 0
137 1
297 0
2
0 98 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut44
3
0 0
137 1
299 0
2
0 100 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut45
3
0 0
137 1
301 0
2
0 102 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut46
3
0 0
137 1
303 0
2
0 104 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut47
3
0 0
137 1
305 0
2
0 106 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut48
3
0 0
137 1
307 0
2
0 108 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut49
3
0 0
137 1
309 0
2
0 110 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
137 1
311 0
2
0 112 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut50
3
0 0
137 1
313 0
2
0 114 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut51
3
0 0
137 1
315 0
2
0 116 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut52
3
0 0
137 1
317 0
2
0 118 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut53
3
0 0
137 1
318 0
2
0 120 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut54
3
0 0
137 1
319 0
2
0 122 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut55
3
0 0
137 1
320 0
2
0 124 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut56
3
0 0
137 1
321 0
2
0 126 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
137 1
322 0
2
0 128 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
137 1
323 0
2
0 130 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
137 1
324 0
2
0 132 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
137 1
325 0
2
0 134 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut1
3
0 0
138 1
223 0
2
0 24 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut10
3
0 0
138 1
225 0
2
0 26 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut11
3
0 0
138 1
227 0
2
0 28 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut12
3
0 0
138 1
229 0
2
0 30 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut13
3
0 0
138 1
231 0
2
0 32 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut14
3
0 0
138 1
233 0
2
0 34 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut15
3
0 0
138 1
235 0
2
0 36 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut16
3
0 0
138 1
237 0
2
0 38 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut17
3
0 0
138 1
239 0
2
0 40 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut18
3
0 0
138 1
241 0
2
0 42 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut19
3
0 0
138 1
243 0
2
0 44 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut2
3
0 0
138 1
245 0
2
0 46 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut20
3
0 0
138 1
247 0
2
0 48 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut21
3
0 0
138 1
249 0
2
0 50 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut22
3
0 0
138 1
251 0
2
0 52 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut23
3
0 0
138 1
253 0
2
0 54 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut24
3
0 0
138 1
255 0
2
0 56 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut25
3
0 0
138 1
257 0
2
0 58 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut26
3
0 0
138 1
259 0
2
0 60 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut27
3
0 0
138 1
261 0
2
0 62 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut28
3
0 0
138 1
263 0
2
0 64 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut29
3
0 0
138 1
265 0
2
0 66 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut3
3
0 0
138 1
267 0
2
0 68 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut30
3
0 0
138 1
269 0
2
0 70 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut31
3
0 0
138 1
271 0
2
0 72 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut32
3
0 0
138 1
273 0
2
0 74 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut33
3
0 0
138 1
275 0
2
0 76 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut34
3
0 0
138 1
277 0
2
0 78 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut35
3
0 0
138 1
279 0
2
0 80 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut36
3
0 0
138 1
281 0
2
0 82 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut37
3
0 0
138 1
283 0
2
0 84 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut38
3
0 0
138 1
285 0
2
0 86 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut39
3
0 0
138 1
287 0
2
0 88 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut4
3
0 0
138 1
289 0
2
0 90 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut40
3
0 0
138 1
291 0
2
0 92 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut41
3
0 0
138 1
293 0
2
0 94 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut42
3
0 0
138 1
295 0
2
0 96 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut43
3
0 0
138 1
297 0
2
0 98 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut44
3
0 0
138 1
299 0
2
0 100 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut45
3
0 0
138 1
301 0
2
0 102 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut46
3
0 0
138 1
303 0
2
0 104 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut47
3
0 0
138 1
305 0
2
0 106 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut48
3
0 0
138 1
307 0
2
0 108 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut49
3
0 0
138 1
309 0
2
0 110 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut5
3
0 0
138 1
311 0
2
0 112 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut50
3
0 0
138 1
313 0
2
0 114 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut51
3
0 0
138 1
315 0
2
0 116 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut52
3
0 0
138 1
317 0
2
0 118 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut53
3
0 0
138 1
318 0
2
0 120 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut54
3
0 0
138 1
319 0
2
0 122 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut55
3
0 0
138 1
320 0
2
0 124 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut56
3
0 0
138 1
321 0
2
0 126 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut6
3
0 0
138 1
322 0
2
0 128 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut7
3
0 0
138 1
323 0
2
0 130 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut8
3
0 0
138 1
324 0
2
0 132 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut9
3
0 0
138 1
325 0
2
0 134 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut1
3
0 0
139 1
223 0
2
0 24 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut10
3
0 0
139 1
225 0
2
0 26 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut11
3
0 0
139 1
227 0
2
0 28 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut12
3
0 0
139 1
229 0
2
0 30 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut13
3
0 0
139 1
231 0
2
0 32 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut14
3
0 0
139 1
233 0
2
0 34 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut15
3
0 0
139 1
235 0
2
0 36 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut16
3
0 0
139 1
237 0
2
0 38 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut17
3
0 0
139 1
239 0
2
0 40 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut18
3
0 0
139 1
241 0
2
0 42 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut19
3
0 0
139 1
243 0
2
0 44 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut2
3
0 0
139 1
245 0
2
0 46 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut20
3
0 0
139 1
247 0
2
0 48 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut21
3
0 0
139 1
249 0
2
0 50 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut22
3
0 0
139 1
251 0
2
0 52 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut23
3
0 0
139 1
253 0
2
0 54 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut24
3
0 0
139 1
255 0
2
0 56 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut25
3
0 0
139 1
257 0
2
0 58 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut26
3
0 0
139 1
259 0
2
0 60 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut27
3
0 0
139 1
261 0
2
0 62 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut28
3
0 0
139 1
263 0
2
0 64 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut29
3
0 0
139 1
265 0
2
0 66 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut3
3
0 0
139 1
267 0
2
0 68 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut30
3
0 0
139 1
269 0
2
0 70 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut31
3
0 0
139 1
271 0
2
0 72 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut32
3
0 0
139 1
273 0
2
0 74 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut33
3
0 0
139 1
275 0
2
0 76 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut34
3
0 0
139 1
277 0
2
0 78 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut35
3
0 0
139 1
279 0
2
0 80 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut36
3
0 0
139 1
281 0
2
0 82 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut37
3
0 0
139 1
283 0
2
0 84 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut38
3
0 0
139 1
285 0
2
0 86 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut39
3
0 0
139 1
287 0
2
0 88 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut4
3
0 0
139 1
289 0
2
0 90 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut40
3
0 0
139 1
291 0
2
0 92 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut41
3
0 0
139 1
293 0
2
0 94 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut42
3
0 0
139 1
295 0
2
0 96 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut43
3
0 0
139 1
297 0
2
0 98 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut44
3
0 0
139 1
299 0
2
0 100 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut45
3
0 0
139 1
301 0
2
0 102 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut46
3
0 0
139 1
303 0
2
0 104 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut47
3
0 0
139 1
305 0
2
0 106 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut48
3
0 0
139 1
307 0
2
0 108 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut49
3
0 0
139 1
309 0
2
0 110 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut5
3
0 0
139 1
311 0
2
0 112 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut50
3
0 0
139 1
313 0
2
0 114 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut51
3
0 0
139 1
315 0
2
0 116 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut52
3
0 0
139 1
317 0
2
0 118 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut53
3
0 0
139 1
318 0
2
0 120 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut54
3
0 0
139 1
319 0
2
0 122 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut55
3
0 0
139 1
320 0
2
0 124 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut56
3
0 0
139 1
321 0
2
0 126 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut6
3
0 0
139 1
322 0
2
0 128 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut7
3
0 0
139 1
323 0
2
0 130 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut8
3
0 0
139 1
324 0
2
0 132 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut9
3
0 0
139 1
325 0
2
0 134 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut1
3
0 0
140 1
223 0
2
0 24 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut10
3
0 0
140 1
225 0
2
0 26 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut11
3
0 0
140 1
227 0
2
0 28 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut12
3
0 0
140 1
229 0
2
0 30 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut13
3
0 0
140 1
231 0
2
0 32 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut14
3
0 0
140 1
233 0
2
0 34 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut15
3
0 0
140 1
235 0
2
0 36 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut16
3
0 0
140 1
237 0
2
0 38 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut17
3
0 0
140 1
239 0
2
0 40 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut18
3
0 0
140 1
241 0
2
0 42 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut19
3
0 0
140 1
243 0
2
0 44 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut2
3
0 0
140 1
245 0
2
0 46 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut20
3
0 0
140 1
247 0
2
0 48 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut21
3
0 0
140 1
249 0
2
0 50 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut22
3
0 0
140 1
251 0
2
0 52 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut23
3
0 0
140 1
253 0
2
0 54 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut24
3
0 0
140 1
255 0
2
0 56 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut25
3
0 0
140 1
257 0
2
0 58 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut26
3
0 0
140 1
259 0
2
0 60 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut27
3
0 0
140 1
261 0
2
0 62 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut28
3
0 0
140 1
263 0
2
0 64 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut29
3
0 0
140 1
265 0
2
0 66 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut3
3
0 0
140 1
267 0
2
0 68 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut30
3
0 0
140 1
269 0
2
0 70 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut31
3
0 0
140 1
271 0
2
0 72 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut32
3
0 0
140 1
273 0
2
0 74 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut33
3
0 0
140 1
275 0
2
0 76 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut34
3
0 0
140 1
277 0
2
0 78 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut35
3
0 0
140 1
279 0
2
0 80 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut36
3
0 0
140 1
281 0
2
0 82 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut37
3
0 0
140 1
283 0
2
0 84 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut38
3
0 0
140 1
285 0
2
0 86 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut39
3
0 0
140 1
287 0
2
0 88 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut4
3
0 0
140 1
289 0
2
0 90 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut40
3
0 0
140 1
291 0
2
0 92 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut41
3
0 0
140 1
293 0
2
0 94 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut42
3
0 0
140 1
295 0
2
0 96 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut43
3
0 0
140 1
297 0
2
0 98 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut44
3
0 0
140 1
299 0
2
0 100 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut45
3
0 0
140 1
301 0
2
0 102 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut46
3
0 0
140 1
303 0
2
0 104 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut47
3
0 0
140 1
305 0
2
0 106 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut48
3
0 0
140 1
307 0
2
0 108 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut49
3
0 0
140 1
309 0
2
0 110 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut5
3
0 0
140 1
311 0
2
0 112 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut50
3
0 0
140 1
313 0
2
0 114 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut51
3
0 0
140 1
315 0
2
0 116 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut52
3
0 0
140 1
317 0
2
0 118 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut53
3
0 0
140 1
318 0
2
0 120 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut54
3
0 0
140 1
319 0
2
0 122 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut55
3
0 0
140 1
320 0
2
0 124 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut56
3
0 0
140 1
321 0
2
0 126 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut6
3
0 0
140 1
322 0
2
0 128 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut7
3
0 0
140 1
323 0
2
0 130 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut8
3
0 0
140 1
324 0
2
0 132 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut9
3
0 0
140 1
325 0
2
0 134 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut1
3
0 0
141 1
223 0
2
0 24 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut10
3
0 0
141 1
225 0
2
0 26 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut11
3
0 0
141 1
227 0
2
0 28 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut12
3
0 0
141 1
229 0
2
0 30 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut13
3
0 0
141 1
231 0
2
0 32 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut14
3
0 0
141 1
233 0
2
0 34 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut15
3
0 0
141 1
235 0
2
0 36 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut16
3
0 0
141 1
237 0
2
0 38 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut17
3
0 0
141 1
239 0
2
0 40 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut18
3
0 0
141 1
241 0
2
0 42 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut19
3
0 0
141 1
243 0
2
0 44 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut2
3
0 0
141 1
245 0
2
0 46 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut20
3
0 0
141 1
247 0
2
0 48 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut21
3
0 0
141 1
249 0
2
0 50 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut22
3
0 0
141 1
251 0
2
0 52 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut23
3
0 0
141 1
253 0
2
0 54 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut24
3
0 0
141 1
255 0
2
0 56 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut25
3
0 0
141 1
257 0
2
0 58 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut26
3
0 0
141 1
259 0
2
0 60 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut27
3
0 0
141 1
261 0
2
0 62 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut28
3
0 0
141 1
263 0
2
0 64 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut29
3
0 0
141 1
265 0
2
0 66 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut3
3
0 0
141 1
267 0
2
0 68 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut30
3
0 0
141 1
269 0
2
0 70 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut31
3
0 0
141 1
271 0
2
0 72 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut32
3
0 0
141 1
273 0
2
0 74 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut33
3
0 0
141 1
275 0
2
0 76 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut34
3
0 0
141 1
277 0
2
0 78 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut35
3
0 0
141 1
279 0
2
0 80 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut36
3
0 0
141 1
281 0
2
0 82 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut37
3
0 0
141 1
283 0
2
0 84 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut38
3
0 0
141 1
285 0
2
0 86 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut39
3
0 0
141 1
287 0
2
0 88 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut4
3
0 0
141 1
289 0
2
0 90 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut40
3
0 0
141 1
291 0
2
0 92 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut41
3
0 0
141 1
293 0
2
0 94 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut42
3
0 0
141 1
295 0
2
0 96 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut43
3
0 0
141 1
297 0
2
0 98 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut44
3
0 0
141 1
299 0
2
0 100 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut45
3
0 0
141 1
301 0
2
0 102 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut46
3
0 0
141 1
303 0
2
0 104 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut47
3
0 0
141 1
305 0
2
0 106 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut48
3
0 0
141 1
307 0
2
0 108 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut49
3
0 0
141 1
309 0
2
0 110 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut5
3
0 0
141 1
311 0
2
0 112 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut50
3
0 0
141 1
313 0
2
0 114 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut51
3
0 0
141 1
315 0
2
0 116 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut52
3
0 0
141 1
317 0
2
0 118 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut53
3
0 0
141 1
318 0
2
0 120 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut54
3
0 0
141 1
319 0
2
0 122 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut55
3
0 0
141 1
320 0
2
0 124 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut56
3
0 0
141 1
321 0
2
0 126 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut6
3
0 0
141 1
322 0
2
0 128 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut7
3
0 0
141 1
323 0
2
0 130 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut8
3
0 0
141 1
324 0
2
0 132 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut9
3
0 0
141 1
325 0
2
0 134 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut1
3
0 0
142 1
223 0
2
0 24 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut10
3
0 0
142 1
225 0
2
0 26 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut11
3
0 0
142 1
227 0
2
0 28 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut12
3
0 0
142 1
229 0
2
0 30 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut13
3
0 0
142 1
231 0
2
0 32 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut14
3
0 0
142 1
233 0
2
0 34 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut15
3
0 0
142 1
235 0
2
0 36 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut16
3
0 0
142 1
237 0
2
0 38 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut17
3
0 0
142 1
239 0
2
0 40 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut18
3
0 0
142 1
241 0
2
0 42 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut19
3
0 0
142 1
243 0
2
0 44 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut2
3
0 0
142 1
245 0
2
0 46 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut20
3
0 0
142 1
247 0
2
0 48 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut21
3
0 0
142 1
249 0
2
0 50 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut22
3
0 0
142 1
251 0
2
0 52 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut23
3
0 0
142 1
253 0
2
0 54 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut24
3
0 0
142 1
255 0
2
0 56 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut25
3
0 0
142 1
257 0
2
0 58 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut26
3
0 0
142 1
259 0
2
0 60 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut27
3
0 0
142 1
261 0
2
0 62 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut28
3
0 0
142 1
263 0
2
0 64 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut29
3
0 0
142 1
265 0
2
0 66 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut3
3
0 0
142 1
267 0
2
0 68 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut30
3
0 0
142 1
269 0
2
0 70 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut31
3
0 0
142 1
271 0
2
0 72 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut32
3
0 0
142 1
273 0
2
0 74 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut33
3
0 0
142 1
275 0
2
0 76 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut34
3
0 0
142 1
277 0
2
0 78 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut35
3
0 0
142 1
279 0
2
0 80 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut36
3
0 0
142 1
281 0
2
0 82 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut37
3
0 0
142 1
283 0
2
0 84 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut38
3
0 0
142 1
285 0
2
0 86 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut39
3
0 0
142 1
287 0
2
0 88 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut4
3
0 0
142 1
289 0
2
0 90 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut40
3
0 0
142 1
291 0
2
0 92 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut41
3
0 0
142 1
293 0
2
0 94 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut42
3
0 0
142 1
295 0
2
0 96 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut43
3
0 0
142 1
297 0
2
0 98 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut44
3
0 0
142 1
299 0
2
0 100 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut45
3
0 0
142 1
301 0
2
0 102 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut46
3
0 0
142 1
303 0
2
0 104 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut47
3
0 0
142 1
305 0
2
0 106 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut48
3
0 0
142 1
307 0
2
0 108 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut49
3
0 0
142 1
309 0
2
0 110 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut5
3
0 0
142 1
311 0
2
0 112 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut50
3
0 0
142 1
313 0
2
0 114 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut51
3
0 0
142 1
315 0
2
0 116 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut52
3
0 0
142 1
317 0
2
0 118 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut53
3
0 0
142 1
318 0
2
0 120 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut54
3
0 0
142 1
319 0
2
0 122 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut55
3
0 0
142 1
320 0
2
0 124 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut56
3
0 0
142 1
321 0
2
0 126 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut6
3
0 0
142 1
322 0
2
0 128 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut7
3
0 0
142 1
323 0
2
0 130 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut8
3
0 0
142 1
324 0
2
0 132 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut9
3
0 0
142 1
325 0
2
0 134 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut1
3
0 0
143 1
223 0
2
0 24 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut10
3
0 0
143 1
225 0
2
0 26 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut11
3
0 0
143 1
227 0
2
0 28 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut12
3
0 0
143 1
229 0
2
0 30 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut13
3
0 0
143 1
231 0
2
0 32 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut14
3
0 0
143 1
233 0
2
0 34 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut15
3
0 0
143 1
235 0
2
0 36 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut16
3
0 0
143 1
237 0
2
0 38 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut17
3
0 0
143 1
239 0
2
0 40 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut18
3
0 0
143 1
241 0
2
0 42 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut19
3
0 0
143 1
243 0
2
0 44 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut2
3
0 0
143 1
245 0
2
0 46 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut20
3
0 0
143 1
247 0
2
0 48 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut21
3
0 0
143 1
249 0
2
0 50 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut22
3
0 0
143 1
251 0
2
0 52 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut23
3
0 0
143 1
253 0
2
0 54 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut24
3
0 0
143 1
255 0
2
0 56 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut25
3
0 0
143 1
257 0
2
0 58 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut26
3
0 0
143 1
259 0
2
0 60 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut27
3
0 0
143 1
261 0
2
0 62 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut28
3
0 0
143 1
263 0
2
0 64 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut29
3
0 0
143 1
265 0
2
0 66 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut3
3
0 0
143 1
267 0
2
0 68 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut30
3
0 0
143 1
269 0
2
0 70 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut31
3
0 0
143 1
271 0
2
0 72 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut32
3
0 0
143 1
273 0
2
0 74 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut33
3
0 0
143 1
275 0
2
0 76 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut34
3
0 0
143 1
277 0
2
0 78 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut35
3
0 0
143 1
279 0
2
0 80 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut36
3
0 0
143 1
281 0
2
0 82 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut37
3
0 0
143 1
283 0
2
0 84 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut38
3
0 0
143 1
285 0
2
0 86 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut39
3
0 0
143 1
287 0
2
0 88 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut4
3
0 0
143 1
289 0
2
0 90 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut40
3
0 0
143 1
291 0
2
0 92 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut41
3
0 0
143 1
293 0
2
0 94 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut42
3
0 0
143 1
295 0
2
0 96 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut43
3
0 0
143 1
297 0
2
0 98 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut44
3
0 0
143 1
299 0
2
0 100 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut45
3
0 0
143 1
301 0
2
0 102 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut46
3
0 0
143 1
303 0
2
0 104 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut47
3
0 0
143 1
305 0
2
0 106 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut48
3
0 0
143 1
307 0
2
0 108 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut49
3
0 0
143 1
309 0
2
0 110 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut5
3
0 0
143 1
311 0
2
0 112 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut50
3
0 0
143 1
313 0
2
0 114 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut51
3
0 0
143 1
315 0
2
0 116 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut52
3
0 0
143 1
317 0
2
0 118 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut53
3
0 0
143 1
318 0
2
0 120 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut54
3
0 0
143 1
319 0
2
0 122 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut55
3
0 0
143 1
320 0
2
0 124 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut56
3
0 0
143 1
321 0
2
0 126 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut6
3
0 0
143 1
322 0
2
0 128 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut7
3
0 0
143 1
323 0
2
0 130 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut8
3
0 0
143 1
324 0
2
0 132 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut9
3
0 0
143 1
325 0
2
0 134 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut1
3
0 0
144 1
223 0
2
0 24 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut10
3
0 0
144 1
225 0
2
0 26 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut11
3
0 0
144 1
227 0
2
0 28 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut12
3
0 0
144 1
229 0
2
0 30 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut13
3
0 0
144 1
231 0
2
0 32 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut14
3
0 0
144 1
233 0
2
0 34 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut15
3
0 0
144 1
235 0
2
0 36 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut16
3
0 0
144 1
237 0
2
0 38 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut17
3
0 0
144 1
239 0
2
0 40 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut18
3
0 0
144 1
241 0
2
0 42 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut19
3
0 0
144 1
243 0
2
0 44 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut2
3
0 0
144 1
245 0
2
0 46 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut20
3
0 0
144 1
247 0
2
0 48 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut21
3
0 0
144 1
249 0
2
0 50 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut22
3
0 0
144 1
251 0
2
0 52 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut23
3
0 0
144 1
253 0
2
0 54 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut24
3
0 0
144 1
255 0
2
0 56 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut25
3
0 0
144 1
257 0
2
0 58 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut26
3
0 0
144 1
259 0
2
0 60 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut27
3
0 0
144 1
261 0
2
0 62 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut28
3
0 0
144 1
263 0
2
0 64 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut29
3
0 0
144 1
265 0
2
0 66 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut3
3
0 0
144 1
267 0
2
0 68 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut30
3
0 0
144 1
269 0
2
0 70 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut31
3
0 0
144 1
271 0
2
0 72 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut32
3
0 0
144 1
273 0
2
0 74 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut33
3
0 0
144 1
275 0
2
0 76 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut34
3
0 0
144 1
277 0
2
0 78 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut35
3
0 0
144 1
279 0
2
0 80 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut36
3
0 0
144 1
281 0
2
0 82 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut37
3
0 0
144 1
283 0
2
0 84 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut38
3
0 0
144 1
285 0
2
0 86 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut39
3
0 0
144 1
287 0
2
0 88 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut4
3
0 0
144 1
289 0
2
0 90 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut40
3
0 0
144 1
291 0
2
0 92 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut41
3
0 0
144 1
293 0
2
0 94 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut42
3
0 0
144 1
295 0
2
0 96 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut43
3
0 0
144 1
297 0
2
0 98 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut44
3
0 0
144 1
299 0
2
0 100 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut45
3
0 0
144 1
301 0
2
0 102 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut46
3
0 0
144 1
303 0
2
0 104 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut47
3
0 0
144 1
305 0
2
0 106 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut48
3
0 0
144 1
307 0
2
0 108 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut49
3
0 0
144 1
309 0
2
0 110 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut5
3
0 0
144 1
311 0
2
0 112 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut50
3
0 0
144 1
313 0
2
0 114 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut51
3
0 0
144 1
315 0
2
0 116 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut52
3
0 0
144 1
317 0
2
0 118 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut53
3
0 0
144 1
318 0
2
0 120 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut54
3
0 0
144 1
319 0
2
0 122 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut55
3
0 0
144 1
320 0
2
0 124 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut56
3
0 0
144 1
321 0
2
0 126 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut6
3
0 0
144 1
322 0
2
0 128 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut7
3
0 0
144 1
323 0
2
0 130 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut8
3
0 0
144 1
324 0
2
0 132 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut9
3
0 0
144 1
325 0
2
0 134 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut1
3
0 0
145 1
223 0
2
0 24 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut10
3
0 0
145 1
225 0
2
0 26 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut11
3
0 0
145 1
227 0
2
0 28 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut12
3
0 0
145 1
229 0
2
0 30 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut13
3
0 0
145 1
231 0
2
0 32 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut14
3
0 0
145 1
233 0
2
0 34 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut15
3
0 0
145 1
235 0
2
0 36 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut16
3
0 0
145 1
237 0
2
0 38 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut17
3
0 0
145 1
239 0
2
0 40 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut18
3
0 0
145 1
241 0
2
0 42 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut19
3
0 0
145 1
243 0
2
0 44 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut2
3
0 0
145 1
245 0
2
0 46 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut20
3
0 0
145 1
247 0
2
0 48 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut21
3
0 0
145 1
249 0
2
0 50 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut22
3
0 0
145 1
251 0
2
0 52 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut23
3
0 0
145 1
253 0
2
0 54 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut24
3
0 0
145 1
255 0
2
0 56 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut25
3
0 0
145 1
257 0
2
0 58 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut26
3
0 0
145 1
259 0
2
0 60 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut27
3
0 0
145 1
261 0
2
0 62 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut28
3
0 0
145 1
263 0
2
0 64 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut29
3
0 0
145 1
265 0
2
0 66 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut3
3
0 0
145 1
267 0
2
0 68 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut30
3
0 0
145 1
269 0
2
0 70 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut31
3
0 0
145 1
271 0
2
0 72 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut32
3
0 0
145 1
273 0
2
0 74 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut33
3
0 0
145 1
275 0
2
0 76 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut34
3
0 0
145 1
277 0
2
0 78 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut35
3
0 0
145 1
279 0
2
0 80 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut36
3
0 0
145 1
281 0
2
0 82 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut37
3
0 0
145 1
283 0
2
0 84 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut38
3
0 0
145 1
285 0
2
0 86 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut39
3
0 0
145 1
287 0
2
0 88 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut4
3
0 0
145 1
289 0
2
0 90 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut40
3
0 0
145 1
291 0
2
0 92 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut41
3
0 0
145 1
293 0
2
0 94 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut42
3
0 0
145 1
295 0
2
0 96 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut43
3
0 0
145 1
297 0
2
0 98 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut44
3
0 0
145 1
299 0
2
0 100 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut45
3
0 0
145 1
301 0
2
0 102 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut46
3
0 0
145 1
303 0
2
0 104 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut47
3
0 0
145 1
305 0
2
0 106 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut48
3
0 0
145 1
307 0
2
0 108 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut49
3
0 0
145 1
309 0
2
0 110 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut5
3
0 0
145 1
311 0
2
0 112 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut50
3
0 0
145 1
313 0
2
0 114 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut51
3
0 0
145 1
315 0
2
0 116 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut52
3
0 0
145 1
317 0
2
0 118 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut53
3
0 0
145 1
318 0
2
0 120 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut54
3
0 0
145 1
319 0
2
0 122 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut55
3
0 0
145 1
320 0
2
0 124 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut56
3
0 0
145 1
321 0
2
0 126 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut6
3
0 0
145 1
322 0
2
0 128 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut7
3
0 0
145 1
323 0
2
0 130 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut8
3
0 0
145 1
324 0
2
0 132 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut9
3
0 0
145 1
325 0
2
0 134 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut1
3
0 0
146 1
223 0
2
0 24 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut10
3
0 0
146 1
225 0
2
0 26 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut11
3
0 0
146 1
227 0
2
0 28 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut12
3
0 0
146 1
229 0
2
0 30 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut13
3
0 0
146 1
231 0
2
0 32 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut14
3
0 0
146 1
233 0
2
0 34 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut15
3
0 0
146 1
235 0
2
0 36 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut16
3
0 0
146 1
237 0
2
0 38 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut17
3
0 0
146 1
239 0
2
0 40 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut18
3
0 0
146 1
241 0
2
0 42 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut19
3
0 0
146 1
243 0
2
0 44 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut2
3
0 0
146 1
245 0
2
0 46 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut20
3
0 0
146 1
247 0
2
0 48 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut21
3
0 0
146 1
249 0
2
0 50 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut22
3
0 0
146 1
251 0
2
0 52 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut23
3
0 0
146 1
253 0
2
0 54 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut24
3
0 0
146 1
255 0
2
0 56 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut25
3
0 0
146 1
257 0
2
0 58 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut26
3
0 0
146 1
259 0
2
0 60 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut27
3
0 0
146 1
261 0
2
0 62 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut28
3
0 0
146 1
263 0
2
0 64 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut29
3
0 0
146 1
265 0
2
0 66 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut3
3
0 0
146 1
267 0
2
0 68 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut30
3
0 0
146 1
269 0
2
0 70 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut31
3
0 0
146 1
271 0
2
0 72 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut32
3
0 0
146 1
273 0
2
0 74 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut33
3
0 0
146 1
275 0
2
0 76 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut34
3
0 0
146 1
277 0
2
0 78 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut35
3
0 0
146 1
279 0
2
0 80 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut36
3
0 0
146 1
281 0
2
0 82 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut37
3
0 0
146 1
283 0
2
0 84 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut38
3
0 0
146 1
285 0
2
0 86 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut39
3
0 0
146 1
287 0
2
0 88 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut4
3
0 0
146 1
289 0
2
0 90 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut40
3
0 0
146 1
291 0
2
0 92 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut41
3
0 0
146 1
293 0
2
0 94 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut42
3
0 0
146 1
295 0
2
0 96 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut43
3
0 0
146 1
297 0
2
0 98 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut44
3
0 0
146 1
299 0
2
0 100 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut45
3
0 0
146 1
301 0
2
0 102 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut46
3
0 0
146 1
303 0
2
0 104 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut47
3
0 0
146 1
305 0
2
0 106 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut48
3
0 0
146 1
307 0
2
0 108 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut49
3
0 0
146 1
309 0
2
0 110 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut5
3
0 0
146 1
311 0
2
0 112 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut50
3
0 0
146 1
313 0
2
0 114 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut51
3
0 0
146 1
315 0
2
0 116 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut52
3
0 0
146 1
317 0
2
0 118 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut53
3
0 0
146 1
318 0
2
0 120 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut54
3
0 0
146 1
319 0
2
0 122 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut55
3
0 0
146 1
320 0
2
0 124 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut56
3
0 0
146 1
321 0
2
0 126 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut6
3
0 0
146 1
322 0
2
0 128 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut7
3
0 0
146 1
323 0
2
0 130 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut8
3
0 0
146 1
324 0
2
0 132 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut9
3
0 0
146 1
325 0
2
0 134 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut1
3
0 0
147 1
223 0
2
0 24 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut10
3
0 0
147 1
225 0
2
0 26 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut11
3
0 0
147 1
227 0
2
0 28 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut12
3
0 0
147 1
229 0
2
0 30 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut13
3
0 0
147 1
231 0
2
0 32 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut14
3
0 0
147 1
233 0
2
0 34 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut15
3
0 0
147 1
235 0
2
0 36 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut16
3
0 0
147 1
237 0
2
0 38 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut17
3
0 0
147 1
239 0
2
0 40 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut18
3
0 0
147 1
241 0
2
0 42 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut19
3
0 0
147 1
243 0
2
0 44 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut2
3
0 0
147 1
245 0
2
0 46 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut20
3
0 0
147 1
247 0
2
0 48 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut21
3
0 0
147 1
249 0
2
0 50 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut22
3
0 0
147 1
251 0
2
0 52 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut23
3
0 0
147 1
253 0
2
0 54 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut24
3
0 0
147 1
255 0
2
0 56 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut25
3
0 0
147 1
257 0
2
0 58 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut26
3
0 0
147 1
259 0
2
0 60 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut27
3
0 0
147 1
261 0
2
0 62 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut28
3
0 0
147 1
263 0
2
0 64 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut29
3
0 0
147 1
265 0
2
0 66 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut3
3
0 0
147 1
267 0
2
0 68 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut30
3
0 0
147 1
269 0
2
0 70 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut31
3
0 0
147 1
271 0
2
0 72 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut32
3
0 0
147 1
273 0
2
0 74 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut33
3
0 0
147 1
275 0
2
0 76 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut34
3
0 0
147 1
277 0
2
0 78 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut35
3
0 0
147 1
279 0
2
0 80 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut36
3
0 0
147 1
281 0
2
0 82 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut37
3
0 0
147 1
283 0
2
0 84 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut38
3
0 0
147 1
285 0
2
0 86 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut39
3
0 0
147 1
287 0
2
0 88 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut4
3
0 0
147 1
289 0
2
0 90 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut40
3
0 0
147 1
291 0
2
0 92 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut41
3
0 0
147 1
293 0
2
0 94 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut42
3
0 0
147 1
295 0
2
0 96 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut43
3
0 0
147 1
297 0
2
0 98 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut44
3
0 0
147 1
299 0
2
0 100 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut45
3
0 0
147 1
301 0
2
0 102 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut46
3
0 0
147 1
303 0
2
0 104 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut47
3
0 0
147 1
305 0
2
0 106 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut48
3
0 0
147 1
307 0
2
0 108 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut49
3
0 0
147 1
309 0
2
0 110 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut5
3
0 0
147 1
311 0
2
0 112 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut50
3
0 0
147 1
313 0
2
0 114 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut51
3
0 0
147 1
315 0
2
0 116 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut52
3
0 0
147 1
317 0
2
0 118 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut53
3
0 0
147 1
318 0
2
0 120 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut54
3
0 0
147 1
319 0
2
0 122 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut55
3
0 0
147 1
320 0
2
0 124 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut56
3
0 0
147 1
321 0
2
0 126 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut6
3
0 0
147 1
322 0
2
0 128 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut7
3
0 0
147 1
323 0
2
0 130 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut8
3
0 0
147 1
324 0
2
0 132 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut9
3
0 0
147 1
325 0
2
0 134 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
148 1
223 0
2
0 24 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
148 1
225 0
2
0 26 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
148 1
227 0
2
0 28 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
148 1
229 0
2
0 30 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
148 1
231 0
2
0 32 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
148 1
233 0
2
0 34 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
148 1
235 0
2
0 36 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
148 1
237 0
2
0 38 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
148 1
239 0
2
0 40 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
148 1
241 0
2
0 42 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
148 1
243 0
2
0 44 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
148 1
245 0
2
0 46 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
148 1
247 0
2
0 48 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
148 1
249 0
2
0 50 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
148 1
251 0
2
0 52 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
148 1
253 0
2
0 54 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
148 1
255 0
2
0 56 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
148 1
257 0
2
0 58 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
148 1
259 0
2
0 60 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
148 1
261 0
2
0 62 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
148 1
263 0
2
0 64 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
148 1
265 0
2
0 66 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
148 1
267 0
2
0 68 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
148 1
269 0
2
0 70 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut31
3
0 0
148 1
271 0
2
0 72 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut32
3
0 0
148 1
273 0
2
0 74 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut33
3
0 0
148 1
275 0
2
0 76 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut34
3
0 0
148 1
277 0
2
0 78 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut35
3
0 0
148 1
279 0
2
0 80 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut36
3
0 0
148 1
281 0
2
0 82 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut37
3
0 0
148 1
283 0
2
0 84 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut38
3
0 0
148 1
285 0
2
0 86 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut39
3
0 0
148 1
287 0
2
0 88 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
148 1
289 0
2
0 90 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut40
3
0 0
148 1
291 0
2
0 92 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut41
3
0 0
148 1
293 0
2
0 94 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut42
3
0 0
148 1
295 0
2
0 96 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut43
3
0 0
148 1
297 0
2
0 98 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut44
3
0 0
148 1
299 0
2
0 100 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut45
3
0 0
148 1
301 0
2
0 102 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut46
3
0 0
148 1
303 0
2
0 104 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut47
3
0 0
148 1
305 0
2
0 106 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut48
3
0 0
148 1
307 0
2
0 108 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut49
3
0 0
148 1
309 0
2
0 110 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
148 1
311 0
2
0 112 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut50
3
0 0
148 1
313 0
2
0 114 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut51
3
0 0
148 1
315 0
2
0 116 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut52
3
0 0
148 1
317 0
2
0 118 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut53
3
0 0
148 1
318 0
2
0 120 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut54
3
0 0
148 1
319 0
2
0 122 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut55
3
0 0
148 1
320 0
2
0 124 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut56
3
0 0
148 1
321 0
2
0 126 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
148 1
322 0
2
0 128 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
148 1
323 0
2
0 130 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
148 1
324 0
2
0 132 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
148 1
325 0
2
0 134 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut1
3
0 0
149 1
223 0
2
0 24 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut10
3
0 0
149 1
225 0
2
0 26 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut11
3
0 0
149 1
227 0
2
0 28 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut12
3
0 0
149 1
229 0
2
0 30 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut13
3
0 0
149 1
231 0
2
0 32 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut14
3
0 0
149 1
233 0
2
0 34 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut15
3
0 0
149 1
235 0
2
0 36 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut16
3
0 0
149 1
237 0
2
0 38 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut17
3
0 0
149 1
239 0
2
0 40 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut18
3
0 0
149 1
241 0
2
0 42 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut19
3
0 0
149 1
243 0
2
0 44 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut2
3
0 0
149 1
245 0
2
0 46 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut20
3
0 0
149 1
247 0
2
0 48 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut21
3
0 0
149 1
249 0
2
0 50 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut22
3
0 0
149 1
251 0
2
0 52 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut23
3
0 0
149 1
253 0
2
0 54 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut24
3
0 0
149 1
255 0
2
0 56 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut25
3
0 0
149 1
257 0
2
0 58 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut26
3
0 0
149 1
259 0
2
0 60 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut27
3
0 0
149 1
261 0
2
0 62 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut28
3
0 0
149 1
263 0
2
0 64 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut29
3
0 0
149 1
265 0
2
0 66 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut3
3
0 0
149 1
267 0
2
0 68 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut30
3
0 0
149 1
269 0
2
0 70 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut31
3
0 0
149 1
271 0
2
0 72 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut32
3
0 0
149 1
273 0
2
0 74 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut33
3
0 0
149 1
275 0
2
0 76 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut34
3
0 0
149 1
277 0
2
0 78 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut35
3
0 0
149 1
279 0
2
0 80 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut36
3
0 0
149 1
281 0
2
0 82 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut37
3
0 0
149 1
283 0
2
0 84 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut38
3
0 0
149 1
285 0
2
0 86 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut39
3
0 0
149 1
287 0
2
0 88 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut4
3
0 0
149 1
289 0
2
0 90 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut40
3
0 0
149 1
291 0
2
0 92 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut41
3
0 0
149 1
293 0
2
0 94 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut42
3
0 0
149 1
295 0
2
0 96 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut43
3
0 0
149 1
297 0
2
0 98 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut44
3
0 0
149 1
299 0
2
0 100 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut45
3
0 0
149 1
301 0
2
0 102 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut46
3
0 0
149 1
303 0
2
0 104 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut47
3
0 0
149 1
305 0
2
0 106 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut48
3
0 0
149 1
307 0
2
0 108 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut49
3
0 0
149 1
309 0
2
0 110 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut5
3
0 0
149 1
311 0
2
0 112 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut50
3
0 0
149 1
313 0
2
0 114 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut51
3
0 0
149 1
315 0
2
0 116 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut52
3
0 0
149 1
317 0
2
0 118 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut53
3
0 0
149 1
318 0
2
0 120 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut54
3
0 0
149 1
319 0
2
0 122 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut55
3
0 0
149 1
320 0
2
0 124 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut56
3
0 0
149 1
321 0
2
0 126 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut6
3
0 0
149 1
322 0
2
0 128 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut7
3
0 0
149 1
323 0
2
0 130 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut8
3
0 0
149 1
324 0
2
0 132 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut9
3
0 0
149 1
325 0
2
0 134 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut1
3
0 0
150 1
223 0
2
0 24 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut10
3
0 0
150 1
225 0
2
0 26 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut11
3
0 0
150 1
227 0
2
0 28 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut12
3
0 0
150 1
229 0
2
0 30 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut13
3
0 0
150 1
231 0
2
0 32 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut14
3
0 0
150 1
233 0
2
0 34 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut15
3
0 0
150 1
235 0
2
0 36 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut16
3
0 0
150 1
237 0
2
0 38 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut17
3
0 0
150 1
239 0
2
0 40 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut18
3
0 0
150 1
241 0
2
0 42 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut19
3
0 0
150 1
243 0
2
0 44 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut2
3
0 0
150 1
245 0
2
0 46 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut20
3
0 0
150 1
247 0
2
0 48 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut21
3
0 0
150 1
249 0
2
0 50 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut22
3
0 0
150 1
251 0
2
0 52 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut23
3
0 0
150 1
253 0
2
0 54 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut24
3
0 0
150 1
255 0
2
0 56 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut25
3
0 0
150 1
257 0
2
0 58 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut26
3
0 0
150 1
259 0
2
0 60 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut27
3
0 0
150 1
261 0
2
0 62 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut28
3
0 0
150 1
263 0
2
0 64 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut29
3
0 0
150 1
265 0
2
0 66 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut3
3
0 0
150 1
267 0
2
0 68 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut30
3
0 0
150 1
269 0
2
0 70 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut31
3
0 0
150 1
271 0
2
0 72 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut32
3
0 0
150 1
273 0
2
0 74 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut33
3
0 0
150 1
275 0
2
0 76 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut34
3
0 0
150 1
277 0
2
0 78 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut35
3
0 0
150 1
279 0
2
0 80 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut36
3
0 0
150 1
281 0
2
0 82 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut37
3
0 0
150 1
283 0
2
0 84 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut38
3
0 0
150 1
285 0
2
0 86 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut39
3
0 0
150 1
287 0
2
0 88 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut4
3
0 0
150 1
289 0
2
0 90 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut40
3
0 0
150 1
291 0
2
0 92 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut41
3
0 0
150 1
293 0
2
0 94 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut42
3
0 0
150 1
295 0
2
0 96 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut43
3
0 0
150 1
297 0
2
0 98 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut44
3
0 0
150 1
299 0
2
0 100 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut45
3
0 0
150 1
301 0
2
0 102 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut46
3
0 0
150 1
303 0
2
0 104 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut47
3
0 0
150 1
305 0
2
0 106 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut48
3
0 0
150 1
307 0
2
0 108 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut49
3
0 0
150 1
309 0
2
0 110 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut5
3
0 0
150 1
311 0
2
0 112 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut50
3
0 0
150 1
313 0
2
0 114 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut51
3
0 0
150 1
315 0
2
0 116 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut52
3
0 0
150 1
317 0
2
0 118 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut53
3
0 0
150 1
318 0
2
0 120 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut54
3
0 0
150 1
319 0
2
0 122 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut55
3
0 0
150 1
320 0
2
0 124 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut56
3
0 0
150 1
321 0
2
0 126 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut6
3
0 0
150 1
322 0
2
0 128 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut7
3
0 0
150 1
323 0
2
0 130 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut8
3
0 0
150 1
324 0
2
0 132 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut9
3
0 0
150 1
325 0
2
0 134 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut1
3
0 0
151 1
223 0
2
0 24 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut10
3
0 0
151 1
225 0
2
0 26 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut11
3
0 0
151 1
227 0
2
0 28 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut12
3
0 0
151 1
229 0
2
0 30 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut13
3
0 0
151 1
231 0
2
0 32 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut14
3
0 0
151 1
233 0
2
0 34 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut15
3
0 0
151 1
235 0
2
0 36 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut16
3
0 0
151 1
237 0
2
0 38 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut17
3
0 0
151 1
239 0
2
0 40 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut18
3
0 0
151 1
241 0
2
0 42 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut19
3
0 0
151 1
243 0
2
0 44 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut2
3
0 0
151 1
245 0
2
0 46 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut20
3
0 0
151 1
247 0
2
0 48 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut21
3
0 0
151 1
249 0
2
0 50 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut22
3
0 0
151 1
251 0
2
0 52 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut23
3
0 0
151 1
253 0
2
0 54 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut24
3
0 0
151 1
255 0
2
0 56 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut25
3
0 0
151 1
257 0
2
0 58 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut26
3
0 0
151 1
259 0
2
0 60 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut27
3
0 0
151 1
261 0
2
0 62 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut28
3
0 0
151 1
263 0
2
0 64 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut29
3
0 0
151 1
265 0
2
0 66 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut3
3
0 0
151 1
267 0
2
0 68 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut30
3
0 0
151 1
269 0
2
0 70 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut31
3
0 0
151 1
271 0
2
0 72 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut32
3
0 0
151 1
273 0
2
0 74 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut33
3
0 0
151 1
275 0
2
0 76 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut34
3
0 0
151 1
277 0
2
0 78 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut35
3
0 0
151 1
279 0
2
0 80 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut36
3
0 0
151 1
281 0
2
0 82 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut37
3
0 0
151 1
283 0
2
0 84 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut38
3
0 0
151 1
285 0
2
0 86 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut39
3
0 0
151 1
287 0
2
0 88 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut4
3
0 0
151 1
289 0
2
0 90 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut40
3
0 0
151 1
291 0
2
0 92 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut41
3
0 0
151 1
293 0
2
0 94 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut42
3
0 0
151 1
295 0
2
0 96 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut43
3
0 0
151 1
297 0
2
0 98 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut44
3
0 0
151 1
299 0
2
0 100 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut45
3
0 0
151 1
301 0
2
0 102 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut46
3
0 0
151 1
303 0
2
0 104 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut47
3
0 0
151 1
305 0
2
0 106 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut48
3
0 0
151 1
307 0
2
0 108 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut49
3
0 0
151 1
309 0
2
0 110 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut5
3
0 0
151 1
311 0
2
0 112 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut50
3
0 0
151 1
313 0
2
0 114 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut51
3
0 0
151 1
315 0
2
0 116 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut52
3
0 0
151 1
317 0
2
0 118 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut53
3
0 0
151 1
318 0
2
0 120 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut54
3
0 0
151 1
319 0
2
0 122 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut55
3
0 0
151 1
320 0
2
0 124 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut56
3
0 0
151 1
321 0
2
0 126 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut6
3
0 0
151 1
322 0
2
0 128 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut7
3
0 0
151 1
323 0
2
0 130 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut8
3
0 0
151 1
324 0
2
0 132 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut9
3
0 0
151 1
325 0
2
0 134 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut1
3
0 0
152 1
223 0
2
0 24 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut10
3
0 0
152 1
225 0
2
0 26 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut11
3
0 0
152 1
227 0
2
0 28 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut12
3
0 0
152 1
229 0
2
0 30 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut13
3
0 0
152 1
231 0
2
0 32 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut14
3
0 0
152 1
233 0
2
0 34 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut15
3
0 0
152 1
235 0
2
0 36 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut16
3
0 0
152 1
237 0
2
0 38 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut17
3
0 0
152 1
239 0
2
0 40 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut18
3
0 0
152 1
241 0
2
0 42 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut19
3
0 0
152 1
243 0
2
0 44 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut2
3
0 0
152 1
245 0
2
0 46 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut20
3
0 0
152 1
247 0
2
0 48 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut21
3
0 0
152 1
249 0
2
0 50 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut22
3
0 0
152 1
251 0
2
0 52 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut23
3
0 0
152 1
253 0
2
0 54 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut24
3
0 0
152 1
255 0
2
0 56 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut25
3
0 0
152 1
257 0
2
0 58 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut26
3
0 0
152 1
259 0
2
0 60 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut27
3
0 0
152 1
261 0
2
0 62 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut28
3
0 0
152 1
263 0
2
0 64 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut29
3
0 0
152 1
265 0
2
0 66 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut3
3
0 0
152 1
267 0
2
0 68 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut30
3
0 0
152 1
269 0
2
0 70 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut31
3
0 0
152 1
271 0
2
0 72 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut32
3
0 0
152 1
273 0
2
0 74 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut33
3
0 0
152 1
275 0
2
0 76 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut34
3
0 0
152 1
277 0
2
0 78 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut35
3
0 0
152 1
279 0
2
0 80 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut36
3
0 0
152 1
281 0
2
0 82 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut37
3
0 0
152 1
283 0
2
0 84 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut38
3
0 0
152 1
285 0
2
0 86 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut39
3
0 0
152 1
287 0
2
0 88 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut4
3
0 0
152 1
289 0
2
0 90 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut40
3
0 0
152 1
291 0
2
0 92 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut41
3
0 0
152 1
293 0
2
0 94 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut42
3
0 0
152 1
295 0
2
0 96 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut43
3
0 0
152 1
297 0
2
0 98 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut44
3
0 0
152 1
299 0
2
0 100 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut45
3
0 0
152 1
301 0
2
0 102 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut46
3
0 0
152 1
303 0
2
0 104 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut47
3
0 0
152 1
305 0
2
0 106 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut48
3
0 0
152 1
307 0
2
0 108 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut49
3
0 0
152 1
309 0
2
0 110 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut5
3
0 0
152 1
311 0
2
0 112 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut50
3
0 0
152 1
313 0
2
0 114 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut51
3
0 0
152 1
315 0
2
0 116 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut52
3
0 0
152 1
317 0
2
0 118 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut53
3
0 0
152 1
318 0
2
0 120 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut54
3
0 0
152 1
319 0
2
0 122 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut55
3
0 0
152 1
320 0
2
0 124 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut56
3
0 0
152 1
321 0
2
0 126 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut6
3
0 0
152 1
322 0
2
0 128 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut7
3
0 0
152 1
323 0
2
0 130 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut8
3
0 0
152 1
324 0
2
0 132 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut9
3
0 0
152 1
325 0
2
0 134 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut1
3
0 0
153 1
223 0
2
0 24 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut10
3
0 0
153 1
225 0
2
0 26 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut11
3
0 0
153 1
227 0
2
0 28 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut12
3
0 0
153 1
229 0
2
0 30 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut13
3
0 0
153 1
231 0
2
0 32 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut14
3
0 0
153 1
233 0
2
0 34 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut15
3
0 0
153 1
235 0
2
0 36 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut16
3
0 0
153 1
237 0
2
0 38 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut17
3
0 0
153 1
239 0
2
0 40 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut18
3
0 0
153 1
241 0
2
0 42 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut19
3
0 0
153 1
243 0
2
0 44 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut2
3
0 0
153 1
245 0
2
0 46 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut20
3
0 0
153 1
247 0
2
0 48 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut21
3
0 0
153 1
249 0
2
0 50 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut22
3
0 0
153 1
251 0
2
0 52 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut23
3
0 0
153 1
253 0
2
0 54 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut24
3
0 0
153 1
255 0
2
0 56 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut25
3
0 0
153 1
257 0
2
0 58 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut26
3
0 0
153 1
259 0
2
0 60 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut27
3
0 0
153 1
261 0
2
0 62 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut28
3
0 0
153 1
263 0
2
0 64 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut29
3
0 0
153 1
265 0
2
0 66 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut3
3
0 0
153 1
267 0
2
0 68 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut30
3
0 0
153 1
269 0
2
0 70 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut31
3
0 0
153 1
271 0
2
0 72 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut32
3
0 0
153 1
273 0
2
0 74 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut33
3
0 0
153 1
275 0
2
0 76 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut34
3
0 0
153 1
277 0
2
0 78 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut35
3
0 0
153 1
279 0
2
0 80 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut36
3
0 0
153 1
281 0
2
0 82 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut37
3
0 0
153 1
283 0
2
0 84 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut38
3
0 0
153 1
285 0
2
0 86 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut39
3
0 0
153 1
287 0
2
0 88 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut4
3
0 0
153 1
289 0
2
0 90 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut40
3
0 0
153 1
291 0
2
0 92 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut41
3
0 0
153 1
293 0
2
0 94 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut42
3
0 0
153 1
295 0
2
0 96 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut43
3
0 0
153 1
297 0
2
0 98 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut44
3
0 0
153 1
299 0
2
0 100 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut45
3
0 0
153 1
301 0
2
0 102 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut46
3
0 0
153 1
303 0
2
0 104 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut47
3
0 0
153 1
305 0
2
0 106 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut48
3
0 0
153 1
307 0
2
0 108 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut49
3
0 0
153 1
309 0
2
0 110 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut5
3
0 0
153 1
311 0
2
0 112 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut50
3
0 0
153 1
313 0
2
0 114 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut51
3
0 0
153 1
315 0
2
0 116 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut52
3
0 0
153 1
317 0
2
0 118 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut53
3
0 0
153 1
318 0
2
0 120 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut54
3
0 0
153 1
319 0
2
0 122 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut55
3
0 0
153 1
320 0
2
0 124 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut56
3
0 0
153 1
321 0
2
0 126 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut6
3
0 0
153 1
322 0
2
0 128 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut7
3
0 0
153 1
323 0
2
0 130 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut8
3
0 0
153 1
324 0
2
0 132 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut9
3
0 0
153 1
325 0
2
0 134 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut1
3
0 0
154 1
223 0
2
0 24 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut10
3
0 0
154 1
225 0
2
0 26 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut11
3
0 0
154 1
227 0
2
0 28 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut12
3
0 0
154 1
229 0
2
0 30 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut13
3
0 0
154 1
231 0
2
0 32 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut14
3
0 0
154 1
233 0
2
0 34 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut15
3
0 0
154 1
235 0
2
0 36 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut16
3
0 0
154 1
237 0
2
0 38 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut17
3
0 0
154 1
239 0
2
0 40 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut18
3
0 0
154 1
241 0
2
0 42 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut19
3
0 0
154 1
243 0
2
0 44 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut2
3
0 0
154 1
245 0
2
0 46 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut20
3
0 0
154 1
247 0
2
0 48 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut21
3
0 0
154 1
249 0
2
0 50 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut22
3
0 0
154 1
251 0
2
0 52 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut23
3
0 0
154 1
253 0
2
0 54 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut24
3
0 0
154 1
255 0
2
0 56 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut25
3
0 0
154 1
257 0
2
0 58 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut26
3
0 0
154 1
259 0
2
0 60 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut27
3
0 0
154 1
261 0
2
0 62 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut28
3
0 0
154 1
263 0
2
0 64 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut29
3
0 0
154 1
265 0
2
0 66 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut3
3
0 0
154 1
267 0
2
0 68 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut30
3
0 0
154 1
269 0
2
0 70 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut31
3
0 0
154 1
271 0
2
0 72 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut32
3
0 0
154 1
273 0
2
0 74 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut33
3
0 0
154 1
275 0
2
0 76 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut34
3
0 0
154 1
277 0
2
0 78 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut35
3
0 0
154 1
279 0
2
0 80 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut36
3
0 0
154 1
281 0
2
0 82 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut37
3
0 0
154 1
283 0
2
0 84 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut38
3
0 0
154 1
285 0
2
0 86 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut39
3
0 0
154 1
287 0
2
0 88 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut4
3
0 0
154 1
289 0
2
0 90 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut40
3
0 0
154 1
291 0
2
0 92 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut41
3
0 0
154 1
293 0
2
0 94 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut42
3
0 0
154 1
295 0
2
0 96 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut43
3
0 0
154 1
297 0
2
0 98 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut44
3
0 0
154 1
299 0
2
0 100 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut45
3
0 0
154 1
301 0
2
0 102 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut46
3
0 0
154 1
303 0
2
0 104 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut47
3
0 0
154 1
305 0
2
0 106 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut48
3
0 0
154 1
307 0
2
0 108 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut49
3
0 0
154 1
309 0
2
0 110 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut5
3
0 0
154 1
311 0
2
0 112 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut50
3
0 0
154 1
313 0
2
0 114 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut51
3
0 0
154 1
315 0
2
0 116 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut52
3
0 0
154 1
317 0
2
0 118 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut53
3
0 0
154 1
318 0
2
0 120 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut54
3
0 0
154 1
319 0
2
0 122 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut55
3
0 0
154 1
320 0
2
0 124 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut56
3
0 0
154 1
321 0
2
0 126 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut6
3
0 0
154 1
322 0
2
0 128 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut7
3
0 0
154 1
323 0
2
0 130 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut8
3
0 0
154 1
324 0
2
0 132 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut9
3
0 0
154 1
325 0
2
0 134 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut1
3
0 0
155 1
223 0
2
0 24 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut10
3
0 0
155 1
225 0
2
0 26 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut11
3
0 0
155 1
227 0
2
0 28 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut12
3
0 0
155 1
229 0
2
0 30 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut13
3
0 0
155 1
231 0
2
0 32 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut14
3
0 0
155 1
233 0
2
0 34 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut15
3
0 0
155 1
235 0
2
0 36 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut16
3
0 0
155 1
237 0
2
0 38 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut17
3
0 0
155 1
239 0
2
0 40 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut18
3
0 0
155 1
241 0
2
0 42 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut19
3
0 0
155 1
243 0
2
0 44 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut2
3
0 0
155 1
245 0
2
0 46 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut20
3
0 0
155 1
247 0
2
0 48 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut21
3
0 0
155 1
249 0
2
0 50 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut22
3
0 0
155 1
251 0
2
0 52 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut23
3
0 0
155 1
253 0
2
0 54 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut24
3
0 0
155 1
255 0
2
0 56 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut25
3
0 0
155 1
257 0
2
0 58 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut26
3
0 0
155 1
259 0
2
0 60 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut27
3
0 0
155 1
261 0
2
0 62 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut28
3
0 0
155 1
263 0
2
0 64 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut29
3
0 0
155 1
265 0
2
0 66 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut3
3
0 0
155 1
267 0
2
0 68 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut30
3
0 0
155 1
269 0
2
0 70 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut31
3
0 0
155 1
271 0
2
0 72 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut32
3
0 0
155 1
273 0
2
0 74 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut33
3
0 0
155 1
275 0
2
0 76 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut34
3
0 0
155 1
277 0
2
0 78 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut35
3
0 0
155 1
279 0
2
0 80 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut36
3
0 0
155 1
281 0
2
0 82 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut37
3
0 0
155 1
283 0
2
0 84 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut38
3
0 0
155 1
285 0
2
0 86 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut39
3
0 0
155 1
287 0
2
0 88 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut4
3
0 0
155 1
289 0
2
0 90 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut40
3
0 0
155 1
291 0
2
0 92 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut41
3
0 0
155 1
293 0
2
0 94 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut42
3
0 0
155 1
295 0
2
0 96 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut43
3
0 0
155 1
297 0
2
0 98 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut44
3
0 0
155 1
299 0
2
0 100 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut45
3
0 0
155 1
301 0
2
0 102 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut46
3
0 0
155 1
303 0
2
0 104 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut47
3
0 0
155 1
305 0
2
0 106 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut48
3
0 0
155 1
307 0
2
0 108 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut49
3
0 0
155 1
309 0
2
0 110 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut5
3
0 0
155 1
311 0
2
0 112 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut50
3
0 0
155 1
313 0
2
0 114 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut51
3
0 0
155 1
315 0
2
0 116 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut52
3
0 0
155 1
317 0
2
0 118 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut53
3
0 0
155 1
318 0
2
0 120 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut54
3
0 0
155 1
319 0
2
0 122 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut55
3
0 0
155 1
320 0
2
0 124 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut56
3
0 0
155 1
321 0
2
0 126 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut6
3
0 0
155 1
322 0
2
0 128 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut7
3
0 0
155 1
323 0
2
0 130 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut8
3
0 0
155 1
324 0
2
0 132 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut9
3
0 0
155 1
325 0
2
0 134 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut1
3
0 0
156 1
223 0
2
0 24 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut10
3
0 0
156 1
225 0
2
0 26 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut11
3
0 0
156 1
227 0
2
0 28 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut12
3
0 0
156 1
229 0
2
0 30 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut13
3
0 0
156 1
231 0
2
0 32 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut14
3
0 0
156 1
233 0
2
0 34 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut15
3
0 0
156 1
235 0
2
0 36 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut16
3
0 0
156 1
237 0
2
0 38 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut17
3
0 0
156 1
239 0
2
0 40 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut18
3
0 0
156 1
241 0
2
0 42 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut19
3
0 0
156 1
243 0
2
0 44 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut2
3
0 0
156 1
245 0
2
0 46 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut20
3
0 0
156 1
247 0
2
0 48 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut21
3
0 0
156 1
249 0
2
0 50 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut22
3
0 0
156 1
251 0
2
0 52 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut23
3
0 0
156 1
253 0
2
0 54 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut24
3
0 0
156 1
255 0
2
0 56 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut25
3
0 0
156 1
257 0
2
0 58 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut26
3
0 0
156 1
259 0
2
0 60 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut27
3
0 0
156 1
261 0
2
0 62 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut28
3
0 0
156 1
263 0
2
0 64 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut29
3
0 0
156 1
265 0
2
0 66 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut3
3
0 0
156 1
267 0
2
0 68 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut30
3
0 0
156 1
269 0
2
0 70 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut31
3
0 0
156 1
271 0
2
0 72 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut32
3
0 0
156 1
273 0
2
0 74 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut33
3
0 0
156 1
275 0
2
0 76 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut34
3
0 0
156 1
277 0
2
0 78 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut35
3
0 0
156 1
279 0
2
0 80 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut36
3
0 0
156 1
281 0
2
0 82 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut37
3
0 0
156 1
283 0
2
0 84 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut38
3
0 0
156 1
285 0
2
0 86 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut39
3
0 0
156 1
287 0
2
0 88 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut4
3
0 0
156 1
289 0
2
0 90 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut40
3
0 0
156 1
291 0
2
0 92 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut41
3
0 0
156 1
293 0
2
0 94 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut42
3
0 0
156 1
295 0
2
0 96 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut43
3
0 0
156 1
297 0
2
0 98 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut44
3
0 0
156 1
299 0
2
0 100 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut45
3
0 0
156 1
301 0
2
0 102 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut46
3
0 0
156 1
303 0
2
0 104 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut47
3
0 0
156 1
305 0
2
0 106 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut48
3
0 0
156 1
307 0
2
0 108 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut49
3
0 0
156 1
309 0
2
0 110 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut5
3
0 0
156 1
311 0
2
0 112 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut50
3
0 0
156 1
313 0
2
0 114 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut51
3
0 0
156 1
315 0
2
0 116 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut52
3
0 0
156 1
317 0
2
0 118 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut53
3
0 0
156 1
318 0
2
0 120 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut54
3
0 0
156 1
319 0
2
0 122 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut55
3
0 0
156 1
320 0
2
0 124 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut56
3
0 0
156 1
321 0
2
0 126 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut6
3
0 0
156 1
322 0
2
0 128 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut7
3
0 0
156 1
323 0
2
0 130 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut8
3
0 0
156 1
324 0
2
0 132 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut9
3
0 0
156 1
325 0
2
0 134 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut1
3
0 0
157 1
223 0
2
0 24 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut10
3
0 0
157 1
225 0
2
0 26 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut11
3
0 0
157 1
227 0
2
0 28 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut12
3
0 0
157 1
229 0
2
0 30 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut13
3
0 0
157 1
231 0
2
0 32 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut14
3
0 0
157 1
233 0
2
0 34 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut15
3
0 0
157 1
235 0
2
0 36 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut16
3
0 0
157 1
237 0
2
0 38 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut17
3
0 0
157 1
239 0
2
0 40 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut18
3
0 0
157 1
241 0
2
0 42 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut19
3
0 0
157 1
243 0
2
0 44 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut2
3
0 0
157 1
245 0
2
0 46 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut20
3
0 0
157 1
247 0
2
0 48 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut21
3
0 0
157 1
249 0
2
0 50 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut22
3
0 0
157 1
251 0
2
0 52 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut23
3
0 0
157 1
253 0
2
0 54 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut24
3
0 0
157 1
255 0
2
0 56 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut25
3
0 0
157 1
257 0
2
0 58 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut26
3
0 0
157 1
259 0
2
0 60 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut27
3
0 0
157 1
261 0
2
0 62 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut28
3
0 0
157 1
263 0
2
0 64 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut29
3
0 0
157 1
265 0
2
0 66 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut3
3
0 0
157 1
267 0
2
0 68 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut30
3
0 0
157 1
269 0
2
0 70 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut31
3
0 0
157 1
271 0
2
0 72 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut32
3
0 0
157 1
273 0
2
0 74 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut33
3
0 0
157 1
275 0
2
0 76 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut34
3
0 0
157 1
277 0
2
0 78 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut35
3
0 0
157 1
279 0
2
0 80 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut36
3
0 0
157 1
281 0
2
0 82 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut37
3
0 0
157 1
283 0
2
0 84 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut38
3
0 0
157 1
285 0
2
0 86 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut39
3
0 0
157 1
287 0
2
0 88 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut4
3
0 0
157 1
289 0
2
0 90 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut40
3
0 0
157 1
291 0
2
0 92 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut41
3
0 0
157 1
293 0
2
0 94 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut42
3
0 0
157 1
295 0
2
0 96 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut43
3
0 0
157 1
297 0
2
0 98 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut44
3
0 0
157 1
299 0
2
0 100 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut45
3
0 0
157 1
301 0
2
0 102 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut46
3
0 0
157 1
303 0
2
0 104 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut47
3
0 0
157 1
305 0
2
0 106 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut48
3
0 0
157 1
307 0
2
0 108 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut49
3
0 0
157 1
309 0
2
0 110 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut5
3
0 0
157 1
311 0
2
0 112 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut50
3
0 0
157 1
313 0
2
0 114 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut51
3
0 0
157 1
315 0
2
0 116 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut52
3
0 0
157 1
317 0
2
0 118 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut53
3
0 0
157 1
318 0
2
0 120 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut54
3
0 0
157 1
319 0
2
0 122 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut55
3
0 0
157 1
320 0
2
0 124 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut56
3
0 0
157 1
321 0
2
0 126 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut6
3
0 0
157 1
322 0
2
0 128 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut7
3
0 0
157 1
323 0
2
0 130 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut8
3
0 0
157 1
324 0
2
0 132 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut9
3
0 0
157 1
325 0
2
0 134 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut1
3
0 0
158 1
223 0
2
0 24 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut10
3
0 0
158 1
225 0
2
0 26 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut11
3
0 0
158 1
227 0
2
0 28 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut12
3
0 0
158 1
229 0
2
0 30 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut13
3
0 0
158 1
231 0
2
0 32 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut14
3
0 0
158 1
233 0
2
0 34 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut15
3
0 0
158 1
235 0
2
0 36 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut16
3
0 0
158 1
237 0
2
0 38 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut17
3
0 0
158 1
239 0
2
0 40 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut18
3
0 0
158 1
241 0
2
0 42 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut19
3
0 0
158 1
243 0
2
0 44 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut2
3
0 0
158 1
245 0
2
0 46 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut20
3
0 0
158 1
247 0
2
0 48 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut21
3
0 0
158 1
249 0
2
0 50 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut22
3
0 0
158 1
251 0
2
0 52 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut23
3
0 0
158 1
253 0
2
0 54 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut24
3
0 0
158 1
255 0
2
0 56 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut25
3
0 0
158 1
257 0
2
0 58 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut26
3
0 0
158 1
259 0
2
0 60 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut27
3
0 0
158 1
261 0
2
0 62 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut28
3
0 0
158 1
263 0
2
0 64 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut29
3
0 0
158 1
265 0
2
0 66 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut3
3
0 0
158 1
267 0
2
0 68 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut30
3
0 0
158 1
269 0
2
0 70 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut31
3
0 0
158 1
271 0
2
0 72 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut32
3
0 0
158 1
273 0
2
0 74 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut33
3
0 0
158 1
275 0
2
0 76 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut34
3
0 0
158 1
277 0
2
0 78 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut35
3
0 0
158 1
279 0
2
0 80 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut36
3
0 0
158 1
281 0
2
0 82 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut37
3
0 0
158 1
283 0
2
0 84 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut38
3
0 0
158 1
285 0
2
0 86 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut39
3
0 0
158 1
287 0
2
0 88 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut4
3
0 0
158 1
289 0
2
0 90 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut40
3
0 0
158 1
291 0
2
0 92 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut41
3
0 0
158 1
293 0
2
0 94 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut42
3
0 0
158 1
295 0
2
0 96 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut43
3
0 0
158 1
297 0
2
0 98 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut44
3
0 0
158 1
299 0
2
0 100 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut45
3
0 0
158 1
301 0
2
0 102 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut46
3
0 0
158 1
303 0
2
0 104 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut47
3
0 0
158 1
305 0
2
0 106 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut48
3
0 0
158 1
307 0
2
0 108 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut49
3
0 0
158 1
309 0
2
0 110 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut5
3
0 0
158 1
311 0
2
0 112 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut50
3
0 0
158 1
313 0
2
0 114 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut51
3
0 0
158 1
315 0
2
0 116 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut52
3
0 0
158 1
317 0
2
0 118 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut53
3
0 0
158 1
318 0
2
0 120 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut54
3
0 0
158 1
319 0
2
0 122 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut55
3
0 0
158 1
320 0
2
0 124 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut56
3
0 0
158 1
321 0
2
0 126 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut6
3
0 0
158 1
322 0
2
0 128 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut7
3
0 0
158 1
323 0
2
0 130 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut8
3
0 0
158 1
324 0
2
0 132 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut9
3
0 0
158 1
325 0
2
0 134 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
159 1
223 0
2
0 24 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
159 1
225 0
2
0 26 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
159 1
227 0
2
0 28 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
159 1
229 0
2
0 30 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
159 1
231 0
2
0 32 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
159 1
233 0
2
0 34 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
159 1
235 0
2
0 36 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
159 1
237 0
2
0 38 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
159 1
239 0
2
0 40 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
159 1
241 0
2
0 42 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
159 1
243 0
2
0 44 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
159 1
245 0
2
0 46 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
159 1
247 0
2
0 48 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
159 1
249 0
2
0 50 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
159 1
251 0
2
0 52 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
159 1
253 0
2
0 54 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
159 1
255 0
2
0 56 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
159 1
257 0
2
0 58 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
159 1
259 0
2
0 60 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
159 1
261 0
2
0 62 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
159 1
263 0
2
0 64 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
159 1
265 0
2
0 66 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
159 1
267 0
2
0 68 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
159 1
269 0
2
0 70 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut31
3
0 0
159 1
271 0
2
0 72 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut32
3
0 0
159 1
273 0
2
0 74 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut33
3
0 0
159 1
275 0
2
0 76 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut34
3
0 0
159 1
277 0
2
0 78 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut35
3
0 0
159 1
279 0
2
0 80 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut36
3
0 0
159 1
281 0
2
0 82 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut37
3
0 0
159 1
283 0
2
0 84 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut38
3
0 0
159 1
285 0
2
0 86 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut39
3
0 0
159 1
287 0
2
0 88 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
159 1
289 0
2
0 90 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut40
3
0 0
159 1
291 0
2
0 92 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut41
3
0 0
159 1
293 0
2
0 94 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut42
3
0 0
159 1
295 0
2
0 96 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut43
3
0 0
159 1
297 0
2
0 98 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut44
3
0 0
159 1
299 0
2
0 100 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut45
3
0 0
159 1
301 0
2
0 102 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut46
3
0 0
159 1
303 0
2
0 104 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut47
3
0 0
159 1
305 0
2
0 106 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut48
3
0 0
159 1
307 0
2
0 108 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut49
3
0 0
159 1
309 0
2
0 110 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
159 1
311 0
2
0 112 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut50
3
0 0
159 1
313 0
2
0 114 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut51
3
0 0
159 1
315 0
2
0 116 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut52
3
0 0
159 1
317 0
2
0 118 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut53
3
0 0
159 1
318 0
2
0 120 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut54
3
0 0
159 1
319 0
2
0 122 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut55
3
0 0
159 1
320 0
2
0 124 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut56
3
0 0
159 1
321 0
2
0 126 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
159 1
322 0
2
0 128 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
159 1
323 0
2
0 130 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
159 1
324 0
2
0 132 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
159 1
325 0
2
0 134 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut1
3
0 0
160 1
223 0
2
0 24 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut10
3
0 0
160 1
225 0
2
0 26 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut11
3
0 0
160 1
227 0
2
0 28 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut12
3
0 0
160 1
229 0
2
0 30 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut13
3
0 0
160 1
231 0
2
0 32 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut14
3
0 0
160 1
233 0
2
0 34 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut15
3
0 0
160 1
235 0
2
0 36 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut16
3
0 0
160 1
237 0
2
0 38 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut17
3
0 0
160 1
239 0
2
0 40 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut18
3
0 0
160 1
241 0
2
0 42 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut19
3
0 0
160 1
243 0
2
0 44 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut2
3
0 0
160 1
245 0
2
0 46 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut20
3
0 0
160 1
247 0
2
0 48 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut21
3
0 0
160 1
249 0
2
0 50 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut22
3
0 0
160 1
251 0
2
0 52 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut23
3
0 0
160 1
253 0
2
0 54 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut24
3
0 0
160 1
255 0
2
0 56 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut25
3
0 0
160 1
257 0
2
0 58 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut26
3
0 0
160 1
259 0
2
0 60 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut27
3
0 0
160 1
261 0
2
0 62 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut28
3
0 0
160 1
263 0
2
0 64 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut29
3
0 0
160 1
265 0
2
0 66 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut3
3
0 0
160 1
267 0
2
0 68 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut30
3
0 0
160 1
269 0
2
0 70 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut31
3
0 0
160 1
271 0
2
0 72 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut32
3
0 0
160 1
273 0
2
0 74 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut33
3
0 0
160 1
275 0
2
0 76 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut34
3
0 0
160 1
277 0
2
0 78 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut35
3
0 0
160 1
279 0
2
0 80 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut36
3
0 0
160 1
281 0
2
0 82 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut37
3
0 0
160 1
283 0
2
0 84 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut38
3
0 0
160 1
285 0
2
0 86 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut39
3
0 0
160 1
287 0
2
0 88 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut4
3
0 0
160 1
289 0
2
0 90 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut40
3
0 0
160 1
291 0
2
0 92 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut41
3
0 0
160 1
293 0
2
0 94 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut42
3
0 0
160 1
295 0
2
0 96 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut43
3
0 0
160 1
297 0
2
0 98 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut44
3
0 0
160 1
299 0
2
0 100 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut45
3
0 0
160 1
301 0
2
0 102 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut46
3
0 0
160 1
303 0
2
0 104 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut47
3
0 0
160 1
305 0
2
0 106 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut48
3
0 0
160 1
307 0
2
0 108 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut49
3
0 0
160 1
309 0
2
0 110 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut5
3
0 0
160 1
311 0
2
0 112 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut50
3
0 0
160 1
313 0
2
0 114 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut51
3
0 0
160 1
315 0
2
0 116 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut52
3
0 0
160 1
317 0
2
0 118 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut53
3
0 0
160 1
318 0
2
0 120 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut54
3
0 0
160 1
319 0
2
0 122 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut55
3
0 0
160 1
320 0
2
0 124 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut56
3
0 0
160 1
321 0
2
0 126 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut6
3
0 0
160 1
322 0
2
0 128 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut7
3
0 0
160 1
323 0
2
0 130 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut8
3
0 0
160 1
324 0
2
0 132 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut9
3
0 0
160 1
325 0
2
0 134 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut1
3
0 0
161 1
223 0
2
0 24 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut10
3
0 0
161 1
225 0
2
0 26 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut11
3
0 0
161 1
227 0
2
0 28 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut12
3
0 0
161 1
229 0
2
0 30 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut13
3
0 0
161 1
231 0
2
0 32 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut14
3
0 0
161 1
233 0
2
0 34 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut15
3
0 0
161 1
235 0
2
0 36 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut16
3
0 0
161 1
237 0
2
0 38 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut17
3
0 0
161 1
239 0
2
0 40 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut18
3
0 0
161 1
241 0
2
0 42 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut19
3
0 0
161 1
243 0
2
0 44 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut2
3
0 0
161 1
245 0
2
0 46 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut20
3
0 0
161 1
247 0
2
0 48 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut21
3
0 0
161 1
249 0
2
0 50 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut22
3
0 0
161 1
251 0
2
0 52 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut23
3
0 0
161 1
253 0
2
0 54 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut24
3
0 0
161 1
255 0
2
0 56 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut25
3
0 0
161 1
257 0
2
0 58 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut26
3
0 0
161 1
259 0
2
0 60 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut27
3
0 0
161 1
261 0
2
0 62 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut28
3
0 0
161 1
263 0
2
0 64 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut29
3
0 0
161 1
265 0
2
0 66 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut3
3
0 0
161 1
267 0
2
0 68 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut30
3
0 0
161 1
269 0
2
0 70 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut31
3
0 0
161 1
271 0
2
0 72 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut32
3
0 0
161 1
273 0
2
0 74 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut33
3
0 0
161 1
275 0
2
0 76 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut34
3
0 0
161 1
277 0
2
0 78 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut35
3
0 0
161 1
279 0
2
0 80 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut36
3
0 0
161 1
281 0
2
0 82 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut37
3
0 0
161 1
283 0
2
0 84 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut38
3
0 0
161 1
285 0
2
0 86 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut39
3
0 0
161 1
287 0
2
0 88 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut4
3
0 0
161 1
289 0
2
0 90 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut40
3
0 0
161 1
291 0
2
0 92 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut41
3
0 0
161 1
293 0
2
0 94 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut42
3
0 0
161 1
295 0
2
0 96 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut43
3
0 0
161 1
297 0
2
0 98 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut44
3
0 0
161 1
299 0
2
0 100 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut45
3
0 0
161 1
301 0
2
0 102 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut46
3
0 0
161 1
303 0
2
0 104 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut47
3
0 0
161 1
305 0
2
0 106 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut48
3
0 0
161 1
307 0
2
0 108 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut49
3
0 0
161 1
309 0
2
0 110 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut5
3
0 0
161 1
311 0
2
0 112 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut50
3
0 0
161 1
313 0
2
0 114 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut51
3
0 0
161 1
315 0
2
0 116 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut52
3
0 0
161 1
317 0
2
0 118 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut53
3
0 0
161 1
318 0
2
0 120 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut54
3
0 0
161 1
319 0
2
0 122 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut55
3
0 0
161 1
320 0
2
0 124 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut56
3
0 0
161 1
321 0
2
0 126 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut6
3
0 0
161 1
322 0
2
0 128 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut7
3
0 0
161 1
323 0
2
0 130 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut8
3
0 0
161 1
324 0
2
0 132 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut9
3
0 0
161 1
325 0
2
0 134 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut1
3
0 0
162 1
223 0
2
0 24 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut10
3
0 0
162 1
225 0
2
0 26 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut11
3
0 0
162 1
227 0
2
0 28 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut12
3
0 0
162 1
229 0
2
0 30 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut13
3
0 0
162 1
231 0
2
0 32 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut14
3
0 0
162 1
233 0
2
0 34 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut15
3
0 0
162 1
235 0
2
0 36 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut16
3
0 0
162 1
237 0
2
0 38 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut17
3
0 0
162 1
239 0
2
0 40 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut18
3
0 0
162 1
241 0
2
0 42 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut19
3
0 0
162 1
243 0
2
0 44 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut2
3
0 0
162 1
245 0
2
0 46 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut20
3
0 0
162 1
247 0
2
0 48 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut21
3
0 0
162 1
249 0
2
0 50 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut22
3
0 0
162 1
251 0
2
0 52 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut23
3
0 0
162 1
253 0
2
0 54 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut24
3
0 0
162 1
255 0
2
0 56 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut25
3
0 0
162 1
257 0
2
0 58 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut26
3
0 0
162 1
259 0
2
0 60 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut27
3
0 0
162 1
261 0
2
0 62 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut28
3
0 0
162 1
263 0
2
0 64 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut29
3
0 0
162 1
265 0
2
0 66 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut3
3
0 0
162 1
267 0
2
0 68 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut30
3
0 0
162 1
269 0
2
0 70 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut31
3
0 0
162 1
271 0
2
0 72 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut32
3
0 0
162 1
273 0
2
0 74 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut33
3
0 0
162 1
275 0
2
0 76 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut34
3
0 0
162 1
277 0
2
0 78 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut35
3
0 0
162 1
279 0
2
0 80 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut36
3
0 0
162 1
281 0
2
0 82 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut37
3
0 0
162 1
283 0
2
0 84 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut38
3
0 0
162 1
285 0
2
0 86 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut39
3
0 0
162 1
287 0
2
0 88 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut4
3
0 0
162 1
289 0
2
0 90 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut40
3
0 0
162 1
291 0
2
0 92 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut41
3
0 0
162 1
293 0
2
0 94 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut42
3
0 0
162 1
295 0
2
0 96 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut43
3
0 0
162 1
297 0
2
0 98 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut44
3
0 0
162 1
299 0
2
0 100 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut45
3
0 0
162 1
301 0
2
0 102 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut46
3
0 0
162 1
303 0
2
0 104 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut47
3
0 0
162 1
305 0
2
0 106 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut48
3
0 0
162 1
307 0
2
0 108 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut49
3
0 0
162 1
309 0
2
0 110 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut5
3
0 0
162 1
311 0
2
0 112 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut50
3
0 0
162 1
313 0
2
0 114 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut51
3
0 0
162 1
315 0
2
0 116 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut52
3
0 0
162 1
317 0
2
0 118 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut53
3
0 0
162 1
318 0
2
0 120 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut54
3
0 0
162 1
319 0
2
0 122 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut55
3
0 0
162 1
320 0
2
0 124 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut56
3
0 0
162 1
321 0
2
0 126 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut6
3
0 0
162 1
322 0
2
0 128 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut7
3
0 0
162 1
323 0
2
0 130 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut8
3
0 0
162 1
324 0
2
0 132 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut9
3
0 0
162 1
325 0
2
0 134 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut1
3
0 0
163 1
223 0
2
0 24 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut10
3
0 0
163 1
225 0
2
0 26 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut11
3
0 0
163 1
227 0
2
0 28 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut12
3
0 0
163 1
229 0
2
0 30 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut13
3
0 0
163 1
231 0
2
0 32 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut14
3
0 0
163 1
233 0
2
0 34 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut15
3
0 0
163 1
235 0
2
0 36 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut16
3
0 0
163 1
237 0
2
0 38 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut17
3
0 0
163 1
239 0
2
0 40 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut18
3
0 0
163 1
241 0
2
0 42 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut19
3
0 0
163 1
243 0
2
0 44 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut2
3
0 0
163 1
245 0
2
0 46 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut20
3
0 0
163 1
247 0
2
0 48 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut21
3
0 0
163 1
249 0
2
0 50 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut22
3
0 0
163 1
251 0
2
0 52 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut23
3
0 0
163 1
253 0
2
0 54 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut24
3
0 0
163 1
255 0
2
0 56 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut25
3
0 0
163 1
257 0
2
0 58 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut26
3
0 0
163 1
259 0
2
0 60 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut27
3
0 0
163 1
261 0
2
0 62 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut28
3
0 0
163 1
263 0
2
0 64 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut29
3
0 0
163 1
265 0
2
0 66 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut3
3
0 0
163 1
267 0
2
0 68 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut30
3
0 0
163 1
269 0
2
0 70 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut31
3
0 0
163 1
271 0
2
0 72 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut32
3
0 0
163 1
273 0
2
0 74 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut33
3
0 0
163 1
275 0
2
0 76 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut34
3
0 0
163 1
277 0
2
0 78 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut35
3
0 0
163 1
279 0
2
0 80 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut36
3
0 0
163 1
281 0
2
0 82 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut37
3
0 0
163 1
283 0
2
0 84 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut38
3
0 0
163 1
285 0
2
0 86 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut39
3
0 0
163 1
287 0
2
0 88 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut4
3
0 0
163 1
289 0
2
0 90 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut40
3
0 0
163 1
291 0
2
0 92 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut41
3
0 0
163 1
293 0
2
0 94 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut42
3
0 0
163 1
295 0
2
0 96 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut43
3
0 0
163 1
297 0
2
0 98 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut44
3
0 0
163 1
299 0
2
0 100 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut45
3
0 0
163 1
301 0
2
0 102 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut46
3
0 0
163 1
303 0
2
0 104 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut47
3
0 0
163 1
305 0
2
0 106 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut48
3
0 0
163 1
307 0
2
0 108 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut49
3
0 0
163 1
309 0
2
0 110 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut5
3
0 0
163 1
311 0
2
0 112 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut50
3
0 0
163 1
313 0
2
0 114 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut51
3
0 0
163 1
315 0
2
0 116 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut52
3
0 0
163 1
317 0
2
0 118 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut53
3
0 0
163 1
318 0
2
0 120 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut54
3
0 0
163 1
319 0
2
0 122 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut55
3
0 0
163 1
320 0
2
0 124 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut56
3
0 0
163 1
321 0
2
0 126 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut6
3
0 0
163 1
322 0
2
0 128 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut7
3
0 0
163 1
323 0
2
0 130 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut8
3
0 0
163 1
324 0
2
0 132 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut9
3
0 0
163 1
325 0
2
0 134 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut1
3
0 0
164 1
223 0
2
0 24 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut10
3
0 0
164 1
225 0
2
0 26 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut11
3
0 0
164 1
227 0
2
0 28 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut12
3
0 0
164 1
229 0
2
0 30 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut13
3
0 0
164 1
231 0
2
0 32 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut14
3
0 0
164 1
233 0
2
0 34 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut15
3
0 0
164 1
235 0
2
0 36 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut16
3
0 0
164 1
237 0
2
0 38 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut17
3
0 0
164 1
239 0
2
0 40 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut18
3
0 0
164 1
241 0
2
0 42 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut19
3
0 0
164 1
243 0
2
0 44 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut2
3
0 0
164 1
245 0
2
0 46 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut20
3
0 0
164 1
247 0
2
0 48 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut21
3
0 0
164 1
249 0
2
0 50 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut22
3
0 0
164 1
251 0
2
0 52 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut23
3
0 0
164 1
253 0
2
0 54 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut24
3
0 0
164 1
255 0
2
0 56 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut25
3
0 0
164 1
257 0
2
0 58 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut26
3
0 0
164 1
259 0
2
0 60 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut27
3
0 0
164 1
261 0
2
0 62 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut28
3
0 0
164 1
263 0
2
0 64 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut29
3
0 0
164 1
265 0
2
0 66 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut3
3
0 0
164 1
267 0
2
0 68 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut30
3
0 0
164 1
269 0
2
0 70 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut31
3
0 0
164 1
271 0
2
0 72 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut32
3
0 0
164 1
273 0
2
0 74 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut33
3
0 0
164 1
275 0
2
0 76 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut34
3
0 0
164 1
277 0
2
0 78 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut35
3
0 0
164 1
279 0
2
0 80 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut36
3
0 0
164 1
281 0
2
0 82 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut37
3
0 0
164 1
283 0
2
0 84 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut38
3
0 0
164 1
285 0
2
0 86 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut39
3
0 0
164 1
287 0
2
0 88 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut4
3
0 0
164 1
289 0
2
0 90 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut40
3
0 0
164 1
291 0
2
0 92 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut41
3
0 0
164 1
293 0
2
0 94 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut42
3
0 0
164 1
295 0
2
0 96 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut43
3
0 0
164 1
297 0
2
0 98 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut44
3
0 0
164 1
299 0
2
0 100 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut45
3
0 0
164 1
301 0
2
0 102 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut46
3
0 0
164 1
303 0
2
0 104 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut47
3
0 0
164 1
305 0
2
0 106 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut48
3
0 0
164 1
307 0
2
0 108 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut49
3
0 0
164 1
309 0
2
0 110 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut5
3
0 0
164 1
311 0
2
0 112 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut50
3
0 0
164 1
313 0
2
0 114 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut51
3
0 0
164 1
315 0
2
0 116 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut52
3
0 0
164 1
317 0
2
0 118 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut53
3
0 0
164 1
318 0
2
0 120 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut54
3
0 0
164 1
319 0
2
0 122 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut55
3
0 0
164 1
320 0
2
0 124 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut56
3
0 0
164 1
321 0
2
0 126 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut6
3
0 0
164 1
322 0
2
0 128 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut7
3
0 0
164 1
323 0
2
0 130 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut8
3
0 0
164 1
324 0
2
0 132 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut9
3
0 0
164 1
325 0
2
0 134 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut1
3
0 0
165 1
223 0
2
0 24 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut10
3
0 0
165 1
225 0
2
0 26 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut11
3
0 0
165 1
227 0
2
0 28 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut12
3
0 0
165 1
229 0
2
0 30 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut13
3
0 0
165 1
231 0
2
0 32 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut14
3
0 0
165 1
233 0
2
0 34 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut15
3
0 0
165 1
235 0
2
0 36 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut16
3
0 0
165 1
237 0
2
0 38 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut17
3
0 0
165 1
239 0
2
0 40 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut18
3
0 0
165 1
241 0
2
0 42 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut19
3
0 0
165 1
243 0
2
0 44 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut2
3
0 0
165 1
245 0
2
0 46 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut20
3
0 0
165 1
247 0
2
0 48 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut21
3
0 0
165 1
249 0
2
0 50 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut22
3
0 0
165 1
251 0
2
0 52 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut23
3
0 0
165 1
253 0
2
0 54 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut24
3
0 0
165 1
255 0
2
0 56 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut25
3
0 0
165 1
257 0
2
0 58 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut26
3
0 0
165 1
259 0
2
0 60 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut27
3
0 0
165 1
261 0
2
0 62 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut28
3
0 0
165 1
263 0
2
0 64 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut29
3
0 0
165 1
265 0
2
0 66 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut3
3
0 0
165 1
267 0
2
0 68 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut30
3
0 0
165 1
269 0
2
0 70 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut31
3
0 0
165 1
271 0
2
0 72 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut32
3
0 0
165 1
273 0
2
0 74 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut33
3
0 0
165 1
275 0
2
0 76 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut34
3
0 0
165 1
277 0
2
0 78 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut35
3
0 0
165 1
279 0
2
0 80 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut36
3
0 0
165 1
281 0
2
0 82 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut37
3
0 0
165 1
283 0
2
0 84 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut38
3
0 0
165 1
285 0
2
0 86 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut39
3
0 0
165 1
287 0
2
0 88 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut4
3
0 0
165 1
289 0
2
0 90 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut40
3
0 0
165 1
291 0
2
0 92 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut41
3
0 0
165 1
293 0
2
0 94 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut42
3
0 0
165 1
295 0
2
0 96 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut43
3
0 0
165 1
297 0
2
0 98 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut44
3
0 0
165 1
299 0
2
0 100 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut45
3
0 0
165 1
301 0
2
0 102 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut46
3
0 0
165 1
303 0
2
0 104 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut47
3
0 0
165 1
305 0
2
0 106 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut48
3
0 0
165 1
307 0
2
0 108 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut49
3
0 0
165 1
309 0
2
0 110 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut5
3
0 0
165 1
311 0
2
0 112 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut50
3
0 0
165 1
313 0
2
0 114 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut51
3
0 0
165 1
315 0
2
0 116 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut52
3
0 0
165 1
317 0
2
0 118 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut53
3
0 0
165 1
318 0
2
0 120 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut54
3
0 0
165 1
319 0
2
0 122 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut55
3
0 0
165 1
320 0
2
0 124 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut56
3
0 0
165 1
321 0
2
0 126 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut6
3
0 0
165 1
322 0
2
0 128 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut7
3
0 0
165 1
323 0
2
0 130 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut8
3
0 0
165 1
324 0
2
0 132 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut9
3
0 0
165 1
325 0
2
0 134 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut1
3
0 0
166 1
223 0
2
0 24 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut10
3
0 0
166 1
225 0
2
0 26 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut11
3
0 0
166 1
227 0
2
0 28 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut12
3
0 0
166 1
229 0
2
0 30 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut13
3
0 0
166 1
231 0
2
0 32 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut14
3
0 0
166 1
233 0
2
0 34 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut15
3
0 0
166 1
235 0
2
0 36 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut16
3
0 0
166 1
237 0
2
0 38 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut17
3
0 0
166 1
239 0
2
0 40 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut18
3
0 0
166 1
241 0
2
0 42 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut19
3
0 0
166 1
243 0
2
0 44 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut2
3
0 0
166 1
245 0
2
0 46 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut20
3
0 0
166 1
247 0
2
0 48 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut21
3
0 0
166 1
249 0
2
0 50 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut22
3
0 0
166 1
251 0
2
0 52 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut23
3
0 0
166 1
253 0
2
0 54 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut24
3
0 0
166 1
255 0
2
0 56 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut25
3
0 0
166 1
257 0
2
0 58 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut26
3
0 0
166 1
259 0
2
0 60 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut27
3
0 0
166 1
261 0
2
0 62 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut28
3
0 0
166 1
263 0
2
0 64 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut29
3
0 0
166 1
265 0
2
0 66 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut3
3
0 0
166 1
267 0
2
0 68 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut30
3
0 0
166 1
269 0
2
0 70 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut31
3
0 0
166 1
271 0
2
0 72 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut32
3
0 0
166 1
273 0
2
0 74 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut33
3
0 0
166 1
275 0
2
0 76 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut34
3
0 0
166 1
277 0
2
0 78 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut35
3
0 0
166 1
279 0
2
0 80 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut36
3
0 0
166 1
281 0
2
0 82 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut37
3
0 0
166 1
283 0
2
0 84 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut38
3
0 0
166 1
285 0
2
0 86 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut39
3
0 0
166 1
287 0
2
0 88 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut4
3
0 0
166 1
289 0
2
0 90 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut40
3
0 0
166 1
291 0
2
0 92 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut41
3
0 0
166 1
293 0
2
0 94 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut42
3
0 0
166 1
295 0
2
0 96 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut43
3
0 0
166 1
297 0
2
0 98 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut44
3
0 0
166 1
299 0
2
0 100 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut45
3
0 0
166 1
301 0
2
0 102 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut46
3
0 0
166 1
303 0
2
0 104 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut47
3
0 0
166 1
305 0
2
0 106 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut48
3
0 0
166 1
307 0
2
0 108 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut49
3
0 0
166 1
309 0
2
0 110 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut5
3
0 0
166 1
311 0
2
0 112 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut50
3
0 0
166 1
313 0
2
0 114 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut51
3
0 0
166 1
315 0
2
0 116 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut52
3
0 0
166 1
317 0
2
0 118 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut53
3
0 0
166 1
318 0
2
0 120 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut54
3
0 0
166 1
319 0
2
0 122 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut55
3
0 0
166 1
320 0
2
0 124 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut56
3
0 0
166 1
321 0
2
0 126 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut6
3
0 0
166 1
322 0
2
0 128 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut7
3
0 0
166 1
323 0
2
0 130 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut8
3
0 0
166 1
324 0
2
0 132 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut9
3
0 0
166 1
325 0
2
0 134 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut1
3
0 0
167 1
223 0
2
0 24 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut10
3
0 0
167 1
225 0
2
0 26 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut11
3
0 0
167 1
227 0
2
0 28 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut12
3
0 0
167 1
229 0
2
0 30 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut13
3
0 0
167 1
231 0
2
0 32 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut14
3
0 0
167 1
233 0
2
0 34 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut15
3
0 0
167 1
235 0
2
0 36 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut16
3
0 0
167 1
237 0
2
0 38 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut17
3
0 0
167 1
239 0
2
0 40 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut18
3
0 0
167 1
241 0
2
0 42 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut19
3
0 0
167 1
243 0
2
0 44 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut2
3
0 0
167 1
245 0
2
0 46 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut20
3
0 0
167 1
247 0
2
0 48 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut21
3
0 0
167 1
249 0
2
0 50 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut22
3
0 0
167 1
251 0
2
0 52 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut23
3
0 0
167 1
253 0
2
0 54 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut24
3
0 0
167 1
255 0
2
0 56 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut25
3
0 0
167 1
257 0
2
0 58 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut26
3
0 0
167 1
259 0
2
0 60 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut27
3
0 0
167 1
261 0
2
0 62 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut28
3
0 0
167 1
263 0
2
0 64 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut29
3
0 0
167 1
265 0
2
0 66 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut3
3
0 0
167 1
267 0
2
0 68 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut30
3
0 0
167 1
269 0
2
0 70 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut31
3
0 0
167 1
271 0
2
0 72 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut32
3
0 0
167 1
273 0
2
0 74 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut33
3
0 0
167 1
275 0
2
0 76 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut34
3
0 0
167 1
277 0
2
0 78 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut35
3
0 0
167 1
279 0
2
0 80 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut36
3
0 0
167 1
281 0
2
0 82 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut37
3
0 0
167 1
283 0
2
0 84 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut38
3
0 0
167 1
285 0
2
0 86 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut39
3
0 0
167 1
287 0
2
0 88 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut4
3
0 0
167 1
289 0
2
0 90 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut40
3
0 0
167 1
291 0
2
0 92 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut41
3
0 0
167 1
293 0
2
0 94 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut42
3
0 0
167 1
295 0
2
0 96 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut43
3
0 0
167 1
297 0
2
0 98 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut44
3
0 0
167 1
299 0
2
0 100 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut45
3
0 0
167 1
301 0
2
0 102 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut46
3
0 0
167 1
303 0
2
0 104 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut47
3
0 0
167 1
305 0
2
0 106 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut48
3
0 0
167 1
307 0
2
0 108 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut49
3
0 0
167 1
309 0
2
0 110 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut5
3
0 0
167 1
311 0
2
0 112 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut50
3
0 0
167 1
313 0
2
0 114 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut51
3
0 0
167 1
315 0
2
0 116 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut52
3
0 0
167 1
317 0
2
0 118 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut53
3
0 0
167 1
318 0
2
0 120 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut54
3
0 0
167 1
319 0
2
0 122 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut55
3
0 0
167 1
320 0
2
0 124 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut56
3
0 0
167 1
321 0
2
0 126 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut6
3
0 0
167 1
322 0
2
0 128 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut7
3
0 0
167 1
323 0
2
0 130 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut8
3
0 0
167 1
324 0
2
0 132 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut9
3
0 0
167 1
325 0
2
0 134 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut1
3
0 0
168 1
223 0
2
0 24 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut10
3
0 0
168 1
225 0
2
0 26 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut11
3
0 0
168 1
227 0
2
0 28 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut12
3
0 0
168 1
229 0
2
0 30 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut13
3
0 0
168 1
231 0
2
0 32 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut14
3
0 0
168 1
233 0
2
0 34 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut15
3
0 0
168 1
235 0
2
0 36 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut16
3
0 0
168 1
237 0
2
0 38 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut17
3
0 0
168 1
239 0
2
0 40 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut18
3
0 0
168 1
241 0
2
0 42 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut19
3
0 0
168 1
243 0
2
0 44 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut2
3
0 0
168 1
245 0
2
0 46 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut20
3
0 0
168 1
247 0
2
0 48 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut21
3
0 0
168 1
249 0
2
0 50 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut22
3
0 0
168 1
251 0
2
0 52 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut23
3
0 0
168 1
253 0
2
0 54 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut24
3
0 0
168 1
255 0
2
0 56 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut25
3
0 0
168 1
257 0
2
0 58 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut26
3
0 0
168 1
259 0
2
0 60 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut27
3
0 0
168 1
261 0
2
0 62 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut28
3
0 0
168 1
263 0
2
0 64 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut29
3
0 0
168 1
265 0
2
0 66 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut3
3
0 0
168 1
267 0
2
0 68 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut30
3
0 0
168 1
269 0
2
0 70 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut31
3
0 0
168 1
271 0
2
0 72 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut32
3
0 0
168 1
273 0
2
0 74 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut33
3
0 0
168 1
275 0
2
0 76 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut34
3
0 0
168 1
277 0
2
0 78 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut35
3
0 0
168 1
279 0
2
0 80 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut36
3
0 0
168 1
281 0
2
0 82 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut37
3
0 0
168 1
283 0
2
0 84 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut38
3
0 0
168 1
285 0
2
0 86 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut39
3
0 0
168 1
287 0
2
0 88 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut4
3
0 0
168 1
289 0
2
0 90 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut40
3
0 0
168 1
291 0
2
0 92 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut41
3
0 0
168 1
293 0
2
0 94 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut42
3
0 0
168 1
295 0
2
0 96 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut43
3
0 0
168 1
297 0
2
0 98 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut44
3
0 0
168 1
299 0
2
0 100 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut45
3
0 0
168 1
301 0
2
0 102 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut46
3
0 0
168 1
303 0
2
0 104 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut47
3
0 0
168 1
305 0
2
0 106 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut48
3
0 0
168 1
307 0
2
0 108 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut49
3
0 0
168 1
309 0
2
0 110 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut5
3
0 0
168 1
311 0
2
0 112 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut50
3
0 0
168 1
313 0
2
0 114 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut51
3
0 0
168 1
315 0
2
0 116 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut52
3
0 0
168 1
317 0
2
0 118 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut53
3
0 0
168 1
318 0
2
0 120 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut54
3
0 0
168 1
319 0
2
0 122 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut55
3
0 0
168 1
320 0
2
0 124 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut56
3
0 0
168 1
321 0
2
0 126 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut6
3
0 0
168 1
322 0
2
0 128 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut7
3
0 0
168 1
323 0
2
0 130 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut8
3
0 0
168 1
324 0
2
0 132 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut9
3
0 0
168 1
325 0
2
0 134 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut1
3
0 0
169 1
223 0
2
0 24 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut10
3
0 0
169 1
225 0
2
0 26 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut11
3
0 0
169 1
227 0
2
0 28 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut12
3
0 0
169 1
229 0
2
0 30 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut13
3
0 0
169 1
231 0
2
0 32 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut14
3
0 0
169 1
233 0
2
0 34 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut15
3
0 0
169 1
235 0
2
0 36 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut16
3
0 0
169 1
237 0
2
0 38 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut17
3
0 0
169 1
239 0
2
0 40 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut18
3
0 0
169 1
241 0
2
0 42 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut19
3
0 0
169 1
243 0
2
0 44 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut2
3
0 0
169 1
245 0
2
0 46 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut20
3
0 0
169 1
247 0
2
0 48 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut21
3
0 0
169 1
249 0
2
0 50 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut22
3
0 0
169 1
251 0
2
0 52 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut23
3
0 0
169 1
253 0
2
0 54 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut24
3
0 0
169 1
255 0
2
0 56 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut25
3
0 0
169 1
257 0
2
0 58 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut26
3
0 0
169 1
259 0
2
0 60 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut27
3
0 0
169 1
261 0
2
0 62 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut28
3
0 0
169 1
263 0
2
0 64 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut29
3
0 0
169 1
265 0
2
0 66 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut3
3
0 0
169 1
267 0
2
0 68 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut30
3
0 0
169 1
269 0
2
0 70 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut31
3
0 0
169 1
271 0
2
0 72 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut32
3
0 0
169 1
273 0
2
0 74 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut33
3
0 0
169 1
275 0
2
0 76 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut34
3
0 0
169 1
277 0
2
0 78 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut35
3
0 0
169 1
279 0
2
0 80 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut36
3
0 0
169 1
281 0
2
0 82 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut37
3
0 0
169 1
283 0
2
0 84 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut38
3
0 0
169 1
285 0
2
0 86 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut39
3
0 0
169 1
287 0
2
0 88 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut4
3
0 0
169 1
289 0
2
0 90 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut40
3
0 0
169 1
291 0
2
0 92 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut41
3
0 0
169 1
293 0
2
0 94 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut42
3
0 0
169 1
295 0
2
0 96 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut43
3
0 0
169 1
297 0
2
0 98 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut44
3
0 0
169 1
299 0
2
0 100 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut45
3
0 0
169 1
301 0
2
0 102 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut46
3
0 0
169 1
303 0
2
0 104 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut47
3
0 0
169 1
305 0
2
0 106 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut48
3
0 0
169 1
307 0
2
0 108 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut49
3
0 0
169 1
309 0
2
0 110 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut5
3
0 0
169 1
311 0
2
0 112 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut50
3
0 0
169 1
313 0
2
0 114 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut51
3
0 0
169 1
315 0
2
0 116 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut52
3
0 0
169 1
317 0
2
0 118 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut53
3
0 0
169 1
318 0
2
0 120 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut54
3
0 0
169 1
319 0
2
0 122 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut55
3
0 0
169 1
320 0
2
0 124 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut56
3
0 0
169 1
321 0
2
0 126 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut6
3
0 0
169 1
322 0
2
0 128 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut7
3
0 0
169 1
323 0
2
0 130 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut8
3
0 0
169 1
324 0
2
0 132 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut9
3
0 0
169 1
325 0
2
0 134 0 1
0 316 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
339 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
340 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
341 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
342 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
343 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
344 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
345 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
346 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
347 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
348 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
349 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
350 0
1
0 0 12 23
1
end_operator
begin_operator
walk location20 location21 bob
1
351 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
352 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
353 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
354 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
355 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
356 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
357 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
358 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 location29 bob
1
359 0
1
0 0 21 22
1
end_operator
begin_operator
walk location29 location30 bob
1
360 0
1
0 0 22 24
1
end_operator
begin_operator
walk location3 location4 bob
1
361 0
1
0 0 23 34
1
end_operator
begin_operator
walk location30 location31 bob
1
362 0
1
0 0 24 25
1
end_operator
begin_operator
walk location31 location32 bob
1
363 0
1
0 0 25 26
1
end_operator
begin_operator
walk location32 location33 bob
1
364 0
1
0 0 26 27
1
end_operator
begin_operator
walk location33 location34 bob
1
365 0
1
0 0 27 28
1
end_operator
begin_operator
walk location34 location35 bob
1
366 0
1
0 0 28 29
1
end_operator
begin_operator
walk location35 location36 bob
1
367 0
1
0 0 29 30
1
end_operator
begin_operator
walk location36 location37 bob
1
368 0
1
0 0 30 31
1
end_operator
begin_operator
walk location37 location38 bob
1
369 0
1
0 0 31 32
1
end_operator
begin_operator
walk location38 location39 bob
1
370 0
1
0 0 32 33
1
end_operator
begin_operator
walk location39 location40 bob
1
371 0
1
0 0 33 35
1
end_operator
begin_operator
walk location4 location5 bob
1
372 0
1
0 0 34 45
1
end_operator
begin_operator
walk location40 location41 bob
1
373 0
1
0 0 35 36
1
end_operator
begin_operator
walk location41 location42 bob
1
374 0
1
0 0 36 37
1
end_operator
begin_operator
walk location42 location43 bob
1
375 0
1
0 0 37 38
1
end_operator
begin_operator
walk location43 location44 bob
1
376 0
1
0 0 38 39
1
end_operator
begin_operator
walk location44 location45 bob
1
377 0
1
0 0 39 40
1
end_operator
begin_operator
walk location45 location46 bob
1
378 0
1
0 0 40 41
1
end_operator
begin_operator
walk location46 location47 bob
1
379 0
1
0 0 41 42
1
end_operator
begin_operator
walk location47 location48 bob
1
380 0
1
0 0 42 43
1
end_operator
begin_operator
walk location48 location49 bob
1
381 0
1
0 0 43 44
1
end_operator
begin_operator
walk location49 location50 bob
1
382 0
1
0 0 44 46
1
end_operator
begin_operator
walk location5 location6 bob
1
383 0
1
0 0 45 48
1
end_operator
begin_operator
walk location50 location51 bob
1
384 0
1
0 0 46 47
1
end_operator
begin_operator
walk location51 gate bob
1
385 0
1
0 0 47 0
1
end_operator
begin_operator
walk location6 location7 bob
1
386 0
1
0 0 48 49
1
end_operator
begin_operator
walk location7 location8 bob
1
387 0
1
0 0 49 50
1
end_operator
begin_operator
walk location8 location9 bob
1
388 0
1
0 0 50 51
1
end_operator
begin_operator
walk location9 location10 bob
1
389 0
1
0 0 51 2
1
end_operator
begin_operator
walk shed location1 bob
1
390 0
1
0 0 52 1
1
end_operator
0
