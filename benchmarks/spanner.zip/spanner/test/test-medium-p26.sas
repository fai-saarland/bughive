begin_version
3
end_version
begin_metric
1
end_metric
292
begin_variable
var0
-1
42
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location29
at bob location3
at bob location30
at bob location31
at bob location32
at bob location33
at bob location34
at bob location35
at bob location36
at bob location37
at bob location38
at bob location39
at bob location4
at bob location40
at bob location5
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var2
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var3
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var4
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var5
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var6
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var7
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var8
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var9
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var10
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var11
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var12
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var13
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var14
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var15
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var16
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var17
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var18
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var19
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var20
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var21
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var22
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var23
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var24
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var25
-1
2
loose nut31
tightened nut31
end_variable
begin_variable
var26
-1
2
loose nut32
tightened nut32
end_variable
begin_variable
var27
-1
2
loose nut33
tightened nut33
end_variable
begin_variable
var28
-1
2
loose nut34
tightened nut34
end_variable
begin_variable
var29
-1
2
loose nut35
tightened nut35
end_variable
begin_variable
var30
-1
2
loose nut36
tightened nut36
end_variable
begin_variable
var31
-1
2
loose nut37
tightened nut37
end_variable
begin_variable
var32
-1
2
loose nut38
tightened nut38
end_variable
begin_variable
var33
-1
2
loose nut39
tightened nut39
end_variable
begin_variable
var34
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var35
-1
2
loose nut40
tightened nut40
end_variable
begin_variable
var36
-1
2
loose nut41
tightened nut41
end_variable
begin_variable
var37
-1
2
loose nut42
tightened nut42
end_variable
begin_variable
var38
-1
2
loose nut43
tightened nut43
end_variable
begin_variable
var39
-1
2
loose nut44
tightened nut44
end_variable
begin_variable
var40
-1
2
loose nut45
tightened nut45
end_variable
begin_variable
var41
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var42
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var43
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var44
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var45
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var46
-1
2
at spanner1 location25
carrying bob spanner1
end_variable
begin_variable
var47
-1
2
at spanner10 location4
carrying bob spanner10
end_variable
begin_variable
var48
-1
2
at spanner11 location24
carrying bob spanner11
end_variable
begin_variable
var49
-1
2
at spanner12 location2
carrying bob spanner12
end_variable
begin_variable
var50
-1
2
at spanner13 location13
carrying bob spanner13
end_variable
begin_variable
var51
-1
2
at spanner14 location20
carrying bob spanner14
end_variable
begin_variable
var52
-1
2
at spanner15 location25
carrying bob spanner15
end_variable
begin_variable
var53
-1
2
at spanner16 location27
carrying bob spanner16
end_variable
begin_variable
var54
-1
2
at spanner17 location9
carrying bob spanner17
end_variable
begin_variable
var55
-1
2
at spanner18 location36
carrying bob spanner18
end_variable
begin_variable
var56
-1
2
at spanner19 location24
carrying bob spanner19
end_variable
begin_variable
var57
-1
2
at spanner2 location35
carrying bob spanner2
end_variable
begin_variable
var58
-1
2
at spanner20 location17
carrying bob spanner20
end_variable
begin_variable
var59
-1
2
at spanner21 location34
carrying bob spanner21
end_variable
begin_variable
var60
-1
2
at spanner22 location2
carrying bob spanner22
end_variable
begin_variable
var61
-1
2
at spanner23 location3
carrying bob spanner23
end_variable
begin_variable
var62
-1
2
at spanner24 location37
carrying bob spanner24
end_variable
begin_variable
var63
-1
2
at spanner25 location17
carrying bob spanner25
end_variable
begin_variable
var64
-1
2
at spanner26 location17
carrying bob spanner26
end_variable
begin_variable
var65
-1
2
at spanner27 location17
carrying bob spanner27
end_variable
begin_variable
var66
-1
2
at spanner28 location5
carrying bob spanner28
end_variable
begin_variable
var67
-1
2
at spanner29 location23
carrying bob spanner29
end_variable
begin_variable
var68
-1
2
at spanner3 location28
carrying bob spanner3
end_variable
begin_variable
var69
-1
2
at spanner30 location3
carrying bob spanner30
end_variable
begin_variable
var70
-1
2
at spanner31 location28
carrying bob spanner31
end_variable
begin_variable
var71
-1
2
at spanner32 location3
carrying bob spanner32
end_variable
begin_variable
var72
-1
2
at spanner33 location15
carrying bob spanner33
end_variable
begin_variable
var73
-1
2
at spanner34 location26
carrying bob spanner34
end_variable
begin_variable
var74
-1
2
at spanner35 location36
carrying bob spanner35
end_variable
begin_variable
var75
-1
2
at spanner36 location9
carrying bob spanner36
end_variable
begin_variable
var76
-1
2
at spanner37 location9
carrying bob spanner37
end_variable
begin_variable
var77
-1
2
at spanner38 location3
carrying bob spanner38
end_variable
begin_variable
var78
-1
2
at spanner39 location21
carrying bob spanner39
end_variable
begin_variable
var79
-1
2
at spanner4 location11
carrying bob spanner4
end_variable
begin_variable
var80
-1
2
at spanner40 location38
carrying bob spanner40
end_variable
begin_variable
var81
-1
2
at spanner41 location30
carrying bob spanner41
end_variable
begin_variable
var82
-1
2
at spanner42 location36
carrying bob spanner42
end_variable
begin_variable
var83
-1
2
at spanner43 location19
carrying bob spanner43
end_variable
begin_variable
var84
-1
2
at spanner44 location7
carrying bob spanner44
end_variable
begin_variable
var85
-1
2
at spanner45 location30
carrying bob spanner45
end_variable
begin_variable
var86
-1
2
at spanner46 location33
carrying bob spanner46
end_variable
begin_variable
var87
-1
2
at spanner47 location30
carrying bob spanner47
end_variable
begin_variable
var88
-1
2
at spanner48 location4
carrying bob spanner48
end_variable
begin_variable
var89
-1
2
at spanner49 location29
carrying bob spanner49
end_variable
begin_variable
var90
-1
2
at spanner5 location22
carrying bob spanner5
end_variable
begin_variable
var91
-1
2
at spanner50 location12
carrying bob spanner50
end_variable
begin_variable
var92
-1
2
at spanner51 location5
carrying bob spanner51
end_variable
begin_variable
var93
-1
2
at spanner52 location24
carrying bob spanner52
end_variable
begin_variable
var94
-1
2
at spanner53 location25
carrying bob spanner53
end_variable
begin_variable
var95
-1
2
at spanner54 location25
carrying bob spanner54
end_variable
begin_variable
var96
-1
2
at spanner55 location36
carrying bob spanner55
end_variable
begin_variable
var97
-1
2
at spanner56 location23
carrying bob spanner56
end_variable
begin_variable
var98
-1
2
at spanner57 location14
carrying bob spanner57
end_variable
begin_variable
var99
-1
2
at spanner58 location39
carrying bob spanner58
end_variable
begin_variable
var100
-1
2
at spanner59 location7
carrying bob spanner59
end_variable
begin_variable
var101
-1
2
at spanner6 location14
carrying bob spanner6
end_variable
begin_variable
var102
-1
2
at spanner60 location12
carrying bob spanner60
end_variable
begin_variable
var103
-1
2
at spanner61 location35
carrying bob spanner61
end_variable
begin_variable
var104
-1
2
at spanner62 location39
carrying bob spanner62
end_variable
begin_variable
var105
-1
2
at spanner63 location31
carrying bob spanner63
end_variable
begin_variable
var106
-1
2
at spanner64 location23
carrying bob spanner64
end_variable
begin_variable
var107
-1
2
at spanner65 location16
carrying bob spanner65
end_variable
begin_variable
var108
-1
2
at spanner66 location1
carrying bob spanner66
end_variable
begin_variable
var109
-1
2
at spanner67 location27
carrying bob spanner67
end_variable
begin_variable
var110
-1
2
at spanner68 location16
carrying bob spanner68
end_variable
begin_variable
var111
-1
2
at spanner69 location11
carrying bob spanner69
end_variable
begin_variable
var112
-1
2
at spanner7 location30
carrying bob spanner7
end_variable
begin_variable
var113
-1
2
at spanner70 location13
carrying bob spanner70
end_variable
begin_variable
var114
-1
2
at spanner71 location40
carrying bob spanner71
end_variable
begin_variable
var115
-1
2
at spanner72 location32
carrying bob spanner72
end_variable
begin_variable
var116
-1
2
at spanner73 location40
carrying bob spanner73
end_variable
begin_variable
var117
-1
2
at spanner74 location24
carrying bob spanner74
end_variable
begin_variable
var118
-1
2
at spanner75 location21
carrying bob spanner75
end_variable
begin_variable
var119
-1
2
at spanner76 location29
carrying bob spanner76
end_variable
begin_variable
var120
-1
2
at spanner77 location9
carrying bob spanner77
end_variable
begin_variable
var121
-1
2
at spanner78 location25
carrying bob spanner78
end_variable
begin_variable
var122
-1
2
at spanner79 location28
carrying bob spanner79
end_variable
begin_variable
var123
-1
2
at spanner8 location19
carrying bob spanner8
end_variable
begin_variable
var124
-1
2
at spanner80 location8
carrying bob spanner80
end_variable
begin_variable
var125
-1
2
at spanner9 location14
carrying bob spanner9
end_variable
begin_variable
var126
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var127
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var128
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var129
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var130
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var131
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var132
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var133
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var134
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var135
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var136
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var137
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var138
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var139
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var140
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var141
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var142
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var143
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var144
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var145
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var146
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var147
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var148
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var149
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var150
-1
2
at nut31 gate
none-of-those
end_variable
begin_variable
var151
-1
2
at nut32 gate
none-of-those
end_variable
begin_variable
var152
-1
2
at nut33 gate
none-of-those
end_variable
begin_variable
var153
-1
2
at nut34 gate
none-of-those
end_variable
begin_variable
var154
-1
2
at nut35 gate
none-of-those
end_variable
begin_variable
var155
-1
2
at nut36 gate
none-of-those
end_variable
begin_variable
var156
-1
2
at nut37 gate
none-of-those
end_variable
begin_variable
var157
-1
2
at nut38 gate
none-of-those
end_variable
begin_variable
var158
-1
2
at nut39 gate
none-of-those
end_variable
begin_variable
var159
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var160
-1
2
at nut40 gate
none-of-those
end_variable
begin_variable
var161
-1
2
at nut41 gate
none-of-those
end_variable
begin_variable
var162
-1
2
at nut42 gate
none-of-those
end_variable
begin_variable
var163
-1
2
at nut43 gate
none-of-those
end_variable
begin_variable
var164
-1
2
at nut44 gate
none-of-those
end_variable
begin_variable
var165
-1
2
at nut45 gate
none-of-those
end_variable
begin_variable
var166
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var167
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var168
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var169
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var170
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var171
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var172
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var173
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var174
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var175
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var176
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var177
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var178
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var179
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var180
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var181
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var182
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var183
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var184
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var185
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var186
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var187
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var188
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var189
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var190
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var191
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var192
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var193
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var194
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var195
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var196
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var197
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var198
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var199
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var200
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var201
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var202
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var203
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var204
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var205
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var206
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var207
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var208
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var209
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var210
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var211
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var212
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var213
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var214
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var215
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var216
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var217
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var218
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var219
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var220
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var221
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var222
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var223
-1
2
usable spanner57
none-of-those
end_variable
begin_variable
var224
-1
2
usable spanner58
none-of-those
end_variable
begin_variable
var225
-1
2
usable spanner59
none-of-those
end_variable
begin_variable
var226
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var227
-1
2
usable spanner60
none-of-those
end_variable
begin_variable
var228
-1
2
usable spanner61
none-of-those
end_variable
begin_variable
var229
-1
2
usable spanner62
none-of-those
end_variable
begin_variable
var230
-1
2
usable spanner63
none-of-those
end_variable
begin_variable
var231
-1
2
usable spanner64
none-of-those
end_variable
begin_variable
var232
-1
2
usable spanner65
none-of-those
end_variable
begin_variable
var233
-1
2
usable spanner66
none-of-those
end_variable
begin_variable
var234
-1
2
usable spanner67
none-of-those
end_variable
begin_variable
var235
-1
2
usable spanner68
none-of-those
end_variable
begin_variable
var236
-1
2
usable spanner69
none-of-those
end_variable
begin_variable
var237
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var238
-1
2
usable spanner70
none-of-those
end_variable
begin_variable
var239
-1
2
usable spanner71
none-of-those
end_variable
begin_variable
var240
-1
2
usable spanner72
none-of-those
end_variable
begin_variable
var241
-1
2
usable spanner73
none-of-those
end_variable
begin_variable
var242
-1
2
usable spanner74
none-of-those
end_variable
begin_variable
var243
-1
2
usable spanner75
none-of-those
end_variable
begin_variable
var244
-1
2
usable spanner76
none-of-those
end_variable
begin_variable
var245
-1
2
usable spanner77
none-of-those
end_variable
begin_variable
var246
-1
2
usable spanner78
none-of-those
end_variable
begin_variable
var247
-1
2
usable spanner79
none-of-those
end_variable
begin_variable
var248
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var249
-1
2
usable spanner80
none-of-those
end_variable
begin_variable
var250
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var251
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var252
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var253
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var254
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var255
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var256
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var257
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var258
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var259
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var260
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var261
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var262
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var263
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var264
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var265
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var266
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var267
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var268
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var269
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var270
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var271
-1
2
link location28 location29
none-of-those
end_variable
begin_variable
var272
-1
2
link location29 location30
none-of-those
end_variable
begin_variable
var273
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var274
-1
2
link location30 location31
none-of-those
end_variable
begin_variable
var275
-1
2
link location31 location32
none-of-those
end_variable
begin_variable
var276
-1
2
link location32 location33
none-of-those
end_variable
begin_variable
var277
-1
2
link location33 location34
none-of-those
end_variable
begin_variable
var278
-1
2
link location34 location35
none-of-those
end_variable
begin_variable
var279
-1
2
link location35 location36
none-of-those
end_variable
begin_variable
var280
-1
2
link location36 location37
none-of-those
end_variable
begin_variable
var281
-1
2
link location37 location38
none-of-those
end_variable
begin_variable
var282
-1
2
link location38 location39
none-of-those
end_variable
begin_variable
var283
-1
2
link location39 location40
none-of-those
end_variable
begin_variable
var284
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var285
-1
2
link location40 gate
none-of-those
end_variable
begin_variable
var286
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var287
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var288
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var289
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var290
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var291
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
41
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
45
1 1
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
36 1
37 1
38 1
39 1
40 1
41 1
42 1
43 1
44 1
45 1
end_goal
3721
begin_operator
pickup_spanner location1 spanner66 bob
1
0 1
1
0 108 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner4 bob
1
0 3
1
0 79 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner69 bob
1
0 3
1
0 111 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner50 bob
1
0 4
1
0 91 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner60 bob
1
0 4
1
0 102 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner13 bob
1
0 5
1
0 50 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner70 bob
1
0 5
1
0 113 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner57 bob
1
0 6
1
0 98 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner6 bob
1
0 6
1
0 101 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner9 bob
1
0 6
1
0 125 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner33 bob
1
0 7
1
0 72 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner65 bob
1
0 8
1
0 107 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner68 bob
1
0 8
1
0 110 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner20 bob
1
0 9
1
0 58 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner25 bob
1
0 9
1
0 63 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner26 bob
1
0 9
1
0 64 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner27 bob
1
0 9
1
0 65 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner43 bob
1
0 11
1
0 83 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner8 bob
1
0 11
1
0 123 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner12 bob
1
0 12
1
0 49 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner22 bob
1
0 12
1
0 60 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner14 bob
1
0 13
1
0 51 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner39 bob
1
0 14
1
0 78 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner75 bob
1
0 14
1
0 118 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner5 bob
1
0 15
1
0 90 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner29 bob
1
0 16
1
0 67 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner56 bob
1
0 16
1
0 97 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner64 bob
1
0 16
1
0 106 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner11 bob
1
0 17
1
0 48 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner19 bob
1
0 17
1
0 56 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner52 bob
1
0 17
1
0 93 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner74 bob
1
0 17
1
0 117 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner1 bob
1
0 18
1
0 46 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner15 bob
1
0 18
1
0 52 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner53 bob
1
0 18
1
0 94 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner54 bob
1
0 18
1
0 95 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner78 bob
1
0 18
1
0 121 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner34 bob
1
0 19
1
0 73 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner16 bob
1
0 20
1
0 53 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner67 bob
1
0 20
1
0 109 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner3 bob
1
0 21
1
0 68 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner31 bob
1
0 21
1
0 70 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner79 bob
1
0 21
1
0 122 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner49 bob
1
0 22
1
0 89 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner76 bob
1
0 22
1
0 119 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner23 bob
1
0 23
1
0 61 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner30 bob
1
0 23
1
0 69 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner32 bob
1
0 23
1
0 71 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner38 bob
1
0 23
1
0 77 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner41 bob
1
0 24
1
0 81 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner45 bob
1
0 24
1
0 85 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner47 bob
1
0 24
1
0 87 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner7 bob
1
0 24
1
0 112 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner63 bob
1
0 25
1
0 105 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner72 bob
1
0 26
1
0 115 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner46 bob
1
0 27
1
0 86 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner21 bob
1
0 28
1
0 59 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner2 bob
1
0 29
1
0 57 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner61 bob
1
0 29
1
0 103 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner18 bob
1
0 30
1
0 55 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner35 bob
1
0 30
1
0 74 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner42 bob
1
0 30
1
0 82 0 1
1
end_operator
begin_operator
pickup_spanner location36 spanner55 bob
1
0 30
1
0 96 0 1
1
end_operator
begin_operator
pickup_spanner location37 spanner24 bob
1
0 31
1
0 62 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner40 bob
1
0 32
1
0 80 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner58 bob
1
0 33
1
0 99 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner62 bob
1
0 33
1
0 104 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner10 bob
1
0 34
1
0 47 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner48 bob
1
0 34
1
0 88 0 1
1
end_operator
begin_operator
pickup_spanner location40 spanner71 bob
1
0 35
1
0 114 0 1
1
end_operator
begin_operator
pickup_spanner location40 spanner73 bob
1
0 35
1
0 116 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner28 bob
1
0 36
1
0 66 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner51 bob
1
0 36
1
0 92 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner44 bob
1
0 38
1
0 84 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner59 bob
1
0 38
1
0 100 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner80 bob
1
0 39
1
0 124 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner17 bob
1
0 40
1
0 54 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner36 bob
1
0 40
1
0 75 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner37 bob
1
0 40
1
0 76 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner77 bob
1
0 40
1
0 120 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
46 1
126 0
2
0 1 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
46 1
127 0
2
0 2 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
46 1
128 0
2
0 3 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
46 1
129 0
2
0 4 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
46 1
130 0
2
0 5 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
46 1
131 0
2
0 6 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
46 1
132 0
2
0 7 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
46 1
133 0
2
0 8 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
46 1
134 0
2
0 9 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
46 1
135 0
2
0 10 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
46 1
136 0
2
0 11 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
46 1
137 0
2
0 12 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
46 1
138 0
2
0 13 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
46 1
139 0
2
0 14 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
46 1
140 0
2
0 15 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
46 1
141 0
2
0 16 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
46 1
142 0
2
0 17 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
46 1
143 0
2
0 18 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
46 1
144 0
2
0 19 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
46 1
145 0
2
0 20 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
46 1
146 0
2
0 21 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
46 1
147 0
2
0 22 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
46 1
148 0
2
0 23 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
46 1
149 0
2
0 24 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut31
3
0 0
46 1
150 0
2
0 25 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut32
3
0 0
46 1
151 0
2
0 26 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut33
3
0 0
46 1
152 0
2
0 27 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut34
3
0 0
46 1
153 0
2
0 28 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut35
3
0 0
46 1
154 0
2
0 29 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut36
3
0 0
46 1
155 0
2
0 30 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut37
3
0 0
46 1
156 0
2
0 31 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut38
3
0 0
46 1
157 0
2
0 32 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut39
3
0 0
46 1
158 0
2
0 33 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
46 1
159 0
2
0 34 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut40
3
0 0
46 1
160 0
2
0 35 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut41
3
0 0
46 1
161 0
2
0 36 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut42
3
0 0
46 1
162 0
2
0 37 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut43
3
0 0
46 1
163 0
2
0 38 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut44
3
0 0
46 1
164 0
2
0 39 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut45
3
0 0
46 1
165 0
2
0 40 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
46 1
166 0
2
0 41 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
46 1
167 0
2
0 42 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
46 1
168 0
2
0 43 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
46 1
169 0
2
0 44 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
46 1
170 0
2
0 45 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
47 1
126 0
2
0 1 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
47 1
127 0
2
0 2 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
47 1
128 0
2
0 3 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
47 1
129 0
2
0 4 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
47 1
130 0
2
0 5 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
47 1
131 0
2
0 6 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
47 1
132 0
2
0 7 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
47 1
133 0
2
0 8 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
47 1
134 0
2
0 9 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
47 1
135 0
2
0 10 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
47 1
136 0
2
0 11 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
47 1
137 0
2
0 12 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
47 1
138 0
2
0 13 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
47 1
139 0
2
0 14 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
47 1
140 0
2
0 15 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
47 1
141 0
2
0 16 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
47 1
142 0
2
0 17 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
47 1
143 0
2
0 18 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
47 1
144 0
2
0 19 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
47 1
145 0
2
0 20 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
47 1
146 0
2
0 21 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
47 1
147 0
2
0 22 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
47 1
148 0
2
0 23 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
47 1
149 0
2
0 24 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut31
3
0 0
47 1
150 0
2
0 25 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut32
3
0 0
47 1
151 0
2
0 26 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut33
3
0 0
47 1
152 0
2
0 27 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut34
3
0 0
47 1
153 0
2
0 28 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut35
3
0 0
47 1
154 0
2
0 29 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut36
3
0 0
47 1
155 0
2
0 30 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut37
3
0 0
47 1
156 0
2
0 31 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut38
3
0 0
47 1
157 0
2
0 32 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut39
3
0 0
47 1
158 0
2
0 33 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
47 1
159 0
2
0 34 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut40
3
0 0
47 1
160 0
2
0 35 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut41
3
0 0
47 1
161 0
2
0 36 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut42
3
0 0
47 1
162 0
2
0 37 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut43
3
0 0
47 1
163 0
2
0 38 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut44
3
0 0
47 1
164 0
2
0 39 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut45
3
0 0
47 1
165 0
2
0 40 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
47 1
166 0
2
0 41 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
47 1
167 0
2
0 42 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
47 1
168 0
2
0 43 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
47 1
169 0
2
0 44 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
47 1
170 0
2
0 45 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
48 1
126 0
2
0 1 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
48 1
127 0
2
0 2 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
48 1
128 0
2
0 3 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
48 1
129 0
2
0 4 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
48 1
130 0
2
0 5 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
48 1
131 0
2
0 6 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
48 1
132 0
2
0 7 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
48 1
133 0
2
0 8 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
48 1
134 0
2
0 9 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
48 1
135 0
2
0 10 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
48 1
136 0
2
0 11 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
48 1
137 0
2
0 12 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
48 1
138 0
2
0 13 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
48 1
139 0
2
0 14 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
48 1
140 0
2
0 15 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
48 1
141 0
2
0 16 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
48 1
142 0
2
0 17 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
48 1
143 0
2
0 18 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
48 1
144 0
2
0 19 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
48 1
145 0
2
0 20 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
48 1
146 0
2
0 21 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
48 1
147 0
2
0 22 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
48 1
148 0
2
0 23 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
48 1
149 0
2
0 24 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut31
3
0 0
48 1
150 0
2
0 25 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut32
3
0 0
48 1
151 0
2
0 26 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut33
3
0 0
48 1
152 0
2
0 27 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut34
3
0 0
48 1
153 0
2
0 28 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut35
3
0 0
48 1
154 0
2
0 29 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut36
3
0 0
48 1
155 0
2
0 30 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut37
3
0 0
48 1
156 0
2
0 31 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut38
3
0 0
48 1
157 0
2
0 32 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut39
3
0 0
48 1
158 0
2
0 33 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
48 1
159 0
2
0 34 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut40
3
0 0
48 1
160 0
2
0 35 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut41
3
0 0
48 1
161 0
2
0 36 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut42
3
0 0
48 1
162 0
2
0 37 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut43
3
0 0
48 1
163 0
2
0 38 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut44
3
0 0
48 1
164 0
2
0 39 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut45
3
0 0
48 1
165 0
2
0 40 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
48 1
166 0
2
0 41 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
48 1
167 0
2
0 42 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
48 1
168 0
2
0 43 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
48 1
169 0
2
0 44 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
48 1
170 0
2
0 45 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
49 1
126 0
2
0 1 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
49 1
127 0
2
0 2 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
49 1
128 0
2
0 3 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
49 1
129 0
2
0 4 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
49 1
130 0
2
0 5 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
49 1
131 0
2
0 6 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
49 1
132 0
2
0 7 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
49 1
133 0
2
0 8 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
49 1
134 0
2
0 9 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
49 1
135 0
2
0 10 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
49 1
136 0
2
0 11 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
49 1
137 0
2
0 12 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
49 1
138 0
2
0 13 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
49 1
139 0
2
0 14 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
49 1
140 0
2
0 15 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
49 1
141 0
2
0 16 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
49 1
142 0
2
0 17 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
49 1
143 0
2
0 18 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
49 1
144 0
2
0 19 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
49 1
145 0
2
0 20 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
49 1
146 0
2
0 21 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
49 1
147 0
2
0 22 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
49 1
148 0
2
0 23 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
49 1
149 0
2
0 24 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut31
3
0 0
49 1
150 0
2
0 25 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut32
3
0 0
49 1
151 0
2
0 26 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut33
3
0 0
49 1
152 0
2
0 27 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut34
3
0 0
49 1
153 0
2
0 28 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut35
3
0 0
49 1
154 0
2
0 29 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut36
3
0 0
49 1
155 0
2
0 30 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut37
3
0 0
49 1
156 0
2
0 31 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut38
3
0 0
49 1
157 0
2
0 32 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut39
3
0 0
49 1
158 0
2
0 33 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
49 1
159 0
2
0 34 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut40
3
0 0
49 1
160 0
2
0 35 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut41
3
0 0
49 1
161 0
2
0 36 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut42
3
0 0
49 1
162 0
2
0 37 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut43
3
0 0
49 1
163 0
2
0 38 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut44
3
0 0
49 1
164 0
2
0 39 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut45
3
0 0
49 1
165 0
2
0 40 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
49 1
166 0
2
0 41 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
49 1
167 0
2
0 42 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
49 1
168 0
2
0 43 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
49 1
169 0
2
0 44 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
49 1
170 0
2
0 45 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
50 1
126 0
2
0 1 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
50 1
127 0
2
0 2 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
50 1
128 0
2
0 3 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
50 1
129 0
2
0 4 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
50 1
130 0
2
0 5 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
50 1
131 0
2
0 6 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
50 1
132 0
2
0 7 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
50 1
133 0
2
0 8 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
50 1
134 0
2
0 9 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
50 1
135 0
2
0 10 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
50 1
136 0
2
0 11 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
50 1
137 0
2
0 12 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
50 1
138 0
2
0 13 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
50 1
139 0
2
0 14 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
50 1
140 0
2
0 15 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
50 1
141 0
2
0 16 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
50 1
142 0
2
0 17 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
50 1
143 0
2
0 18 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
50 1
144 0
2
0 19 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
50 1
145 0
2
0 20 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
50 1
146 0
2
0 21 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
50 1
147 0
2
0 22 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
50 1
148 0
2
0 23 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
50 1
149 0
2
0 24 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut31
3
0 0
50 1
150 0
2
0 25 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut32
3
0 0
50 1
151 0
2
0 26 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut33
3
0 0
50 1
152 0
2
0 27 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut34
3
0 0
50 1
153 0
2
0 28 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut35
3
0 0
50 1
154 0
2
0 29 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut36
3
0 0
50 1
155 0
2
0 30 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut37
3
0 0
50 1
156 0
2
0 31 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut38
3
0 0
50 1
157 0
2
0 32 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut39
3
0 0
50 1
158 0
2
0 33 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
50 1
159 0
2
0 34 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut40
3
0 0
50 1
160 0
2
0 35 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut41
3
0 0
50 1
161 0
2
0 36 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut42
3
0 0
50 1
162 0
2
0 37 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut43
3
0 0
50 1
163 0
2
0 38 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut44
3
0 0
50 1
164 0
2
0 39 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut45
3
0 0
50 1
165 0
2
0 40 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
50 1
166 0
2
0 41 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
50 1
167 0
2
0 42 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
50 1
168 0
2
0 43 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
50 1
169 0
2
0 44 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
50 1
170 0
2
0 45 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
51 1
126 0
2
0 1 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
51 1
127 0
2
0 2 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
51 1
128 0
2
0 3 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
51 1
129 0
2
0 4 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
51 1
130 0
2
0 5 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
51 1
131 0
2
0 6 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
51 1
132 0
2
0 7 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
51 1
133 0
2
0 8 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
51 1
134 0
2
0 9 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
51 1
135 0
2
0 10 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
51 1
136 0
2
0 11 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
51 1
137 0
2
0 12 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
51 1
138 0
2
0 13 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
51 1
139 0
2
0 14 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
51 1
140 0
2
0 15 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
51 1
141 0
2
0 16 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
51 1
142 0
2
0 17 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
51 1
143 0
2
0 18 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
51 1
144 0
2
0 19 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
51 1
145 0
2
0 20 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
51 1
146 0
2
0 21 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
51 1
147 0
2
0 22 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
51 1
148 0
2
0 23 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
51 1
149 0
2
0 24 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut31
3
0 0
51 1
150 0
2
0 25 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut32
3
0 0
51 1
151 0
2
0 26 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut33
3
0 0
51 1
152 0
2
0 27 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut34
3
0 0
51 1
153 0
2
0 28 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut35
3
0 0
51 1
154 0
2
0 29 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut36
3
0 0
51 1
155 0
2
0 30 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut37
3
0 0
51 1
156 0
2
0 31 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut38
3
0 0
51 1
157 0
2
0 32 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut39
3
0 0
51 1
158 0
2
0 33 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
51 1
159 0
2
0 34 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut40
3
0 0
51 1
160 0
2
0 35 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut41
3
0 0
51 1
161 0
2
0 36 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut42
3
0 0
51 1
162 0
2
0 37 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut43
3
0 0
51 1
163 0
2
0 38 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut44
3
0 0
51 1
164 0
2
0 39 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut45
3
0 0
51 1
165 0
2
0 40 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
51 1
166 0
2
0 41 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
51 1
167 0
2
0 42 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
51 1
168 0
2
0 43 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
51 1
169 0
2
0 44 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
51 1
170 0
2
0 45 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
52 1
126 0
2
0 1 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
52 1
127 0
2
0 2 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
52 1
128 0
2
0 3 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
52 1
129 0
2
0 4 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
52 1
130 0
2
0 5 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
52 1
131 0
2
0 6 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
52 1
132 0
2
0 7 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
52 1
133 0
2
0 8 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
52 1
134 0
2
0 9 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
52 1
135 0
2
0 10 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
52 1
136 0
2
0 11 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
52 1
137 0
2
0 12 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
52 1
138 0
2
0 13 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
52 1
139 0
2
0 14 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
52 1
140 0
2
0 15 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
52 1
141 0
2
0 16 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
52 1
142 0
2
0 17 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
52 1
143 0
2
0 18 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
52 1
144 0
2
0 19 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
52 1
145 0
2
0 20 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
52 1
146 0
2
0 21 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
52 1
147 0
2
0 22 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
52 1
148 0
2
0 23 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
52 1
149 0
2
0 24 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut31
3
0 0
52 1
150 0
2
0 25 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut32
3
0 0
52 1
151 0
2
0 26 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut33
3
0 0
52 1
152 0
2
0 27 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut34
3
0 0
52 1
153 0
2
0 28 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut35
3
0 0
52 1
154 0
2
0 29 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut36
3
0 0
52 1
155 0
2
0 30 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut37
3
0 0
52 1
156 0
2
0 31 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut38
3
0 0
52 1
157 0
2
0 32 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut39
3
0 0
52 1
158 0
2
0 33 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
52 1
159 0
2
0 34 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut40
3
0 0
52 1
160 0
2
0 35 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut41
3
0 0
52 1
161 0
2
0 36 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut42
3
0 0
52 1
162 0
2
0 37 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut43
3
0 0
52 1
163 0
2
0 38 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut44
3
0 0
52 1
164 0
2
0 39 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut45
3
0 0
52 1
165 0
2
0 40 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
52 1
166 0
2
0 41 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
52 1
167 0
2
0 42 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
52 1
168 0
2
0 43 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
52 1
169 0
2
0 44 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
52 1
170 0
2
0 45 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
53 1
126 0
2
0 1 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
53 1
127 0
2
0 2 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
53 1
128 0
2
0 3 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
53 1
129 0
2
0 4 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
53 1
130 0
2
0 5 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
53 1
131 0
2
0 6 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
53 1
132 0
2
0 7 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
53 1
133 0
2
0 8 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
53 1
134 0
2
0 9 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
53 1
135 0
2
0 10 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
53 1
136 0
2
0 11 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
53 1
137 0
2
0 12 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
53 1
138 0
2
0 13 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
53 1
139 0
2
0 14 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
53 1
140 0
2
0 15 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
53 1
141 0
2
0 16 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
53 1
142 0
2
0 17 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
53 1
143 0
2
0 18 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
53 1
144 0
2
0 19 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
53 1
145 0
2
0 20 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
53 1
146 0
2
0 21 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
53 1
147 0
2
0 22 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
53 1
148 0
2
0 23 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
53 1
149 0
2
0 24 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut31
3
0 0
53 1
150 0
2
0 25 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut32
3
0 0
53 1
151 0
2
0 26 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut33
3
0 0
53 1
152 0
2
0 27 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut34
3
0 0
53 1
153 0
2
0 28 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut35
3
0 0
53 1
154 0
2
0 29 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut36
3
0 0
53 1
155 0
2
0 30 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut37
3
0 0
53 1
156 0
2
0 31 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut38
3
0 0
53 1
157 0
2
0 32 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut39
3
0 0
53 1
158 0
2
0 33 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
53 1
159 0
2
0 34 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut40
3
0 0
53 1
160 0
2
0 35 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut41
3
0 0
53 1
161 0
2
0 36 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut42
3
0 0
53 1
162 0
2
0 37 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut43
3
0 0
53 1
163 0
2
0 38 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut44
3
0 0
53 1
164 0
2
0 39 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut45
3
0 0
53 1
165 0
2
0 40 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
53 1
166 0
2
0 41 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
53 1
167 0
2
0 42 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
53 1
168 0
2
0 43 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
53 1
169 0
2
0 44 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
53 1
170 0
2
0 45 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
54 1
126 0
2
0 1 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
54 1
127 0
2
0 2 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
54 1
128 0
2
0 3 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
54 1
129 0
2
0 4 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
54 1
130 0
2
0 5 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
54 1
131 0
2
0 6 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
54 1
132 0
2
0 7 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
54 1
133 0
2
0 8 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
54 1
134 0
2
0 9 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
54 1
135 0
2
0 10 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
54 1
136 0
2
0 11 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
54 1
137 0
2
0 12 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
54 1
138 0
2
0 13 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
54 1
139 0
2
0 14 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
54 1
140 0
2
0 15 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
54 1
141 0
2
0 16 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
54 1
142 0
2
0 17 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
54 1
143 0
2
0 18 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
54 1
144 0
2
0 19 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
54 1
145 0
2
0 20 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
54 1
146 0
2
0 21 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
54 1
147 0
2
0 22 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
54 1
148 0
2
0 23 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
54 1
149 0
2
0 24 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut31
3
0 0
54 1
150 0
2
0 25 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut32
3
0 0
54 1
151 0
2
0 26 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut33
3
0 0
54 1
152 0
2
0 27 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut34
3
0 0
54 1
153 0
2
0 28 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut35
3
0 0
54 1
154 0
2
0 29 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut36
3
0 0
54 1
155 0
2
0 30 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut37
3
0 0
54 1
156 0
2
0 31 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut38
3
0 0
54 1
157 0
2
0 32 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut39
3
0 0
54 1
158 0
2
0 33 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
54 1
159 0
2
0 34 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut40
3
0 0
54 1
160 0
2
0 35 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut41
3
0 0
54 1
161 0
2
0 36 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut42
3
0 0
54 1
162 0
2
0 37 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut43
3
0 0
54 1
163 0
2
0 38 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut44
3
0 0
54 1
164 0
2
0 39 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut45
3
0 0
54 1
165 0
2
0 40 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
54 1
166 0
2
0 41 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
54 1
167 0
2
0 42 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
54 1
168 0
2
0 43 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
54 1
169 0
2
0 44 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
54 1
170 0
2
0 45 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
55 1
126 0
2
0 1 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
55 1
127 0
2
0 2 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
55 1
128 0
2
0 3 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
55 1
129 0
2
0 4 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
55 1
130 0
2
0 5 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
55 1
131 0
2
0 6 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
55 1
132 0
2
0 7 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
55 1
133 0
2
0 8 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
55 1
134 0
2
0 9 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
55 1
135 0
2
0 10 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
55 1
136 0
2
0 11 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
55 1
137 0
2
0 12 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
55 1
138 0
2
0 13 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
55 1
139 0
2
0 14 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
55 1
140 0
2
0 15 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
55 1
141 0
2
0 16 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
55 1
142 0
2
0 17 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
55 1
143 0
2
0 18 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
55 1
144 0
2
0 19 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
55 1
145 0
2
0 20 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
55 1
146 0
2
0 21 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
55 1
147 0
2
0 22 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
55 1
148 0
2
0 23 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
55 1
149 0
2
0 24 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut31
3
0 0
55 1
150 0
2
0 25 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut32
3
0 0
55 1
151 0
2
0 26 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut33
3
0 0
55 1
152 0
2
0 27 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut34
3
0 0
55 1
153 0
2
0 28 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut35
3
0 0
55 1
154 0
2
0 29 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut36
3
0 0
55 1
155 0
2
0 30 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut37
3
0 0
55 1
156 0
2
0 31 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut38
3
0 0
55 1
157 0
2
0 32 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut39
3
0 0
55 1
158 0
2
0 33 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
55 1
159 0
2
0 34 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut40
3
0 0
55 1
160 0
2
0 35 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut41
3
0 0
55 1
161 0
2
0 36 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut42
3
0 0
55 1
162 0
2
0 37 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut43
3
0 0
55 1
163 0
2
0 38 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut44
3
0 0
55 1
164 0
2
0 39 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut45
3
0 0
55 1
165 0
2
0 40 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
55 1
166 0
2
0 41 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
55 1
167 0
2
0 42 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
55 1
168 0
2
0 43 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
55 1
169 0
2
0 44 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
55 1
170 0
2
0 45 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
56 1
126 0
2
0 1 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
56 1
127 0
2
0 2 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
56 1
128 0
2
0 3 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
56 1
129 0
2
0 4 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
56 1
130 0
2
0 5 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
56 1
131 0
2
0 6 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
56 1
132 0
2
0 7 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
56 1
133 0
2
0 8 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
56 1
134 0
2
0 9 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
56 1
135 0
2
0 10 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
56 1
136 0
2
0 11 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
56 1
137 0
2
0 12 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
56 1
138 0
2
0 13 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
56 1
139 0
2
0 14 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
56 1
140 0
2
0 15 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
56 1
141 0
2
0 16 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
56 1
142 0
2
0 17 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
56 1
143 0
2
0 18 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
56 1
144 0
2
0 19 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
56 1
145 0
2
0 20 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
56 1
146 0
2
0 21 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
56 1
147 0
2
0 22 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
56 1
148 0
2
0 23 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
56 1
149 0
2
0 24 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut31
3
0 0
56 1
150 0
2
0 25 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut32
3
0 0
56 1
151 0
2
0 26 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut33
3
0 0
56 1
152 0
2
0 27 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut34
3
0 0
56 1
153 0
2
0 28 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut35
3
0 0
56 1
154 0
2
0 29 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut36
3
0 0
56 1
155 0
2
0 30 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut37
3
0 0
56 1
156 0
2
0 31 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut38
3
0 0
56 1
157 0
2
0 32 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut39
3
0 0
56 1
158 0
2
0 33 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
56 1
159 0
2
0 34 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut40
3
0 0
56 1
160 0
2
0 35 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut41
3
0 0
56 1
161 0
2
0 36 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut42
3
0 0
56 1
162 0
2
0 37 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut43
3
0 0
56 1
163 0
2
0 38 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut44
3
0 0
56 1
164 0
2
0 39 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut45
3
0 0
56 1
165 0
2
0 40 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
56 1
166 0
2
0 41 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
56 1
167 0
2
0 42 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
56 1
168 0
2
0 43 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
56 1
169 0
2
0 44 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
56 1
170 0
2
0 45 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
57 1
126 0
2
0 1 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
57 1
127 0
2
0 2 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
57 1
128 0
2
0 3 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
57 1
129 0
2
0 4 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
57 1
130 0
2
0 5 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
57 1
131 0
2
0 6 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
57 1
132 0
2
0 7 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
57 1
133 0
2
0 8 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
57 1
134 0
2
0 9 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
57 1
135 0
2
0 10 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
57 1
136 0
2
0 11 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
57 1
137 0
2
0 12 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
57 1
138 0
2
0 13 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
57 1
139 0
2
0 14 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
57 1
140 0
2
0 15 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
57 1
141 0
2
0 16 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
57 1
142 0
2
0 17 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
57 1
143 0
2
0 18 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
57 1
144 0
2
0 19 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
57 1
145 0
2
0 20 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
57 1
146 0
2
0 21 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
57 1
147 0
2
0 22 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
57 1
148 0
2
0 23 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
57 1
149 0
2
0 24 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut31
3
0 0
57 1
150 0
2
0 25 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut32
3
0 0
57 1
151 0
2
0 26 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut33
3
0 0
57 1
152 0
2
0 27 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut34
3
0 0
57 1
153 0
2
0 28 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut35
3
0 0
57 1
154 0
2
0 29 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut36
3
0 0
57 1
155 0
2
0 30 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut37
3
0 0
57 1
156 0
2
0 31 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut38
3
0 0
57 1
157 0
2
0 32 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut39
3
0 0
57 1
158 0
2
0 33 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
57 1
159 0
2
0 34 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut40
3
0 0
57 1
160 0
2
0 35 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut41
3
0 0
57 1
161 0
2
0 36 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut42
3
0 0
57 1
162 0
2
0 37 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut43
3
0 0
57 1
163 0
2
0 38 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut44
3
0 0
57 1
164 0
2
0 39 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut45
3
0 0
57 1
165 0
2
0 40 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
57 1
166 0
2
0 41 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
57 1
167 0
2
0 42 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
57 1
168 0
2
0 43 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
57 1
169 0
2
0 44 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
57 1
170 0
2
0 45 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
58 1
126 0
2
0 1 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
58 1
127 0
2
0 2 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
58 1
128 0
2
0 3 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
58 1
129 0
2
0 4 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
58 1
130 0
2
0 5 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
58 1
131 0
2
0 6 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
58 1
132 0
2
0 7 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
58 1
133 0
2
0 8 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
58 1
134 0
2
0 9 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
58 1
135 0
2
0 10 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
58 1
136 0
2
0 11 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
58 1
137 0
2
0 12 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
58 1
138 0
2
0 13 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
58 1
139 0
2
0 14 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
58 1
140 0
2
0 15 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
58 1
141 0
2
0 16 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
58 1
142 0
2
0 17 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
58 1
143 0
2
0 18 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
58 1
144 0
2
0 19 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
58 1
145 0
2
0 20 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
58 1
146 0
2
0 21 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
58 1
147 0
2
0 22 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
58 1
148 0
2
0 23 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
58 1
149 0
2
0 24 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut31
3
0 0
58 1
150 0
2
0 25 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut32
3
0 0
58 1
151 0
2
0 26 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut33
3
0 0
58 1
152 0
2
0 27 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut34
3
0 0
58 1
153 0
2
0 28 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut35
3
0 0
58 1
154 0
2
0 29 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut36
3
0 0
58 1
155 0
2
0 30 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut37
3
0 0
58 1
156 0
2
0 31 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut38
3
0 0
58 1
157 0
2
0 32 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut39
3
0 0
58 1
158 0
2
0 33 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
58 1
159 0
2
0 34 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut40
3
0 0
58 1
160 0
2
0 35 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut41
3
0 0
58 1
161 0
2
0 36 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut42
3
0 0
58 1
162 0
2
0 37 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut43
3
0 0
58 1
163 0
2
0 38 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut44
3
0 0
58 1
164 0
2
0 39 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut45
3
0 0
58 1
165 0
2
0 40 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
58 1
166 0
2
0 41 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
58 1
167 0
2
0 42 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
58 1
168 0
2
0 43 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
58 1
169 0
2
0 44 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
58 1
170 0
2
0 45 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
59 1
126 0
2
0 1 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
59 1
127 0
2
0 2 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
59 1
128 0
2
0 3 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
59 1
129 0
2
0 4 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
59 1
130 0
2
0 5 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
59 1
131 0
2
0 6 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
59 1
132 0
2
0 7 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
59 1
133 0
2
0 8 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
59 1
134 0
2
0 9 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
59 1
135 0
2
0 10 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
59 1
136 0
2
0 11 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
59 1
137 0
2
0 12 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
59 1
138 0
2
0 13 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
59 1
139 0
2
0 14 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
59 1
140 0
2
0 15 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
59 1
141 0
2
0 16 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
59 1
142 0
2
0 17 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
59 1
143 0
2
0 18 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
59 1
144 0
2
0 19 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
59 1
145 0
2
0 20 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
59 1
146 0
2
0 21 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
59 1
147 0
2
0 22 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
59 1
148 0
2
0 23 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
59 1
149 0
2
0 24 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut31
3
0 0
59 1
150 0
2
0 25 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut32
3
0 0
59 1
151 0
2
0 26 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut33
3
0 0
59 1
152 0
2
0 27 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut34
3
0 0
59 1
153 0
2
0 28 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut35
3
0 0
59 1
154 0
2
0 29 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut36
3
0 0
59 1
155 0
2
0 30 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut37
3
0 0
59 1
156 0
2
0 31 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut38
3
0 0
59 1
157 0
2
0 32 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut39
3
0 0
59 1
158 0
2
0 33 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
59 1
159 0
2
0 34 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut40
3
0 0
59 1
160 0
2
0 35 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut41
3
0 0
59 1
161 0
2
0 36 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut42
3
0 0
59 1
162 0
2
0 37 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut43
3
0 0
59 1
163 0
2
0 38 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut44
3
0 0
59 1
164 0
2
0 39 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut45
3
0 0
59 1
165 0
2
0 40 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
59 1
166 0
2
0 41 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
59 1
167 0
2
0 42 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
59 1
168 0
2
0 43 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
59 1
169 0
2
0 44 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
59 1
170 0
2
0 45 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
60 1
126 0
2
0 1 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
60 1
127 0
2
0 2 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
60 1
128 0
2
0 3 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
60 1
129 0
2
0 4 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
60 1
130 0
2
0 5 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
60 1
131 0
2
0 6 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
60 1
132 0
2
0 7 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
60 1
133 0
2
0 8 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
60 1
134 0
2
0 9 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
60 1
135 0
2
0 10 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
60 1
136 0
2
0 11 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
60 1
137 0
2
0 12 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
60 1
138 0
2
0 13 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
60 1
139 0
2
0 14 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
60 1
140 0
2
0 15 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
60 1
141 0
2
0 16 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
60 1
142 0
2
0 17 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
60 1
143 0
2
0 18 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
60 1
144 0
2
0 19 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
60 1
145 0
2
0 20 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
60 1
146 0
2
0 21 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
60 1
147 0
2
0 22 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
60 1
148 0
2
0 23 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
60 1
149 0
2
0 24 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut31
3
0 0
60 1
150 0
2
0 25 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut32
3
0 0
60 1
151 0
2
0 26 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut33
3
0 0
60 1
152 0
2
0 27 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut34
3
0 0
60 1
153 0
2
0 28 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut35
3
0 0
60 1
154 0
2
0 29 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut36
3
0 0
60 1
155 0
2
0 30 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut37
3
0 0
60 1
156 0
2
0 31 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut38
3
0 0
60 1
157 0
2
0 32 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut39
3
0 0
60 1
158 0
2
0 33 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
60 1
159 0
2
0 34 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut40
3
0 0
60 1
160 0
2
0 35 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut41
3
0 0
60 1
161 0
2
0 36 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut42
3
0 0
60 1
162 0
2
0 37 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut43
3
0 0
60 1
163 0
2
0 38 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut44
3
0 0
60 1
164 0
2
0 39 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut45
3
0 0
60 1
165 0
2
0 40 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
60 1
166 0
2
0 41 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
60 1
167 0
2
0 42 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
60 1
168 0
2
0 43 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
60 1
169 0
2
0 44 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
60 1
170 0
2
0 45 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
61 1
126 0
2
0 1 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
61 1
127 0
2
0 2 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
61 1
128 0
2
0 3 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
61 1
129 0
2
0 4 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
61 1
130 0
2
0 5 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
61 1
131 0
2
0 6 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
61 1
132 0
2
0 7 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
61 1
133 0
2
0 8 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
61 1
134 0
2
0 9 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
61 1
135 0
2
0 10 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
61 1
136 0
2
0 11 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
61 1
137 0
2
0 12 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
61 1
138 0
2
0 13 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
61 1
139 0
2
0 14 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
61 1
140 0
2
0 15 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
61 1
141 0
2
0 16 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
61 1
142 0
2
0 17 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
61 1
143 0
2
0 18 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
61 1
144 0
2
0 19 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
61 1
145 0
2
0 20 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
61 1
146 0
2
0 21 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
61 1
147 0
2
0 22 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
61 1
148 0
2
0 23 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
61 1
149 0
2
0 24 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut31
3
0 0
61 1
150 0
2
0 25 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut32
3
0 0
61 1
151 0
2
0 26 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut33
3
0 0
61 1
152 0
2
0 27 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut34
3
0 0
61 1
153 0
2
0 28 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut35
3
0 0
61 1
154 0
2
0 29 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut36
3
0 0
61 1
155 0
2
0 30 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut37
3
0 0
61 1
156 0
2
0 31 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut38
3
0 0
61 1
157 0
2
0 32 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut39
3
0 0
61 1
158 0
2
0 33 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
61 1
159 0
2
0 34 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut40
3
0 0
61 1
160 0
2
0 35 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut41
3
0 0
61 1
161 0
2
0 36 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut42
3
0 0
61 1
162 0
2
0 37 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut43
3
0 0
61 1
163 0
2
0 38 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut44
3
0 0
61 1
164 0
2
0 39 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut45
3
0 0
61 1
165 0
2
0 40 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
61 1
166 0
2
0 41 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
61 1
167 0
2
0 42 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
61 1
168 0
2
0 43 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
61 1
169 0
2
0 44 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
61 1
170 0
2
0 45 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
62 1
126 0
2
0 1 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
62 1
127 0
2
0 2 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
62 1
128 0
2
0 3 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
62 1
129 0
2
0 4 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
62 1
130 0
2
0 5 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
62 1
131 0
2
0 6 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
62 1
132 0
2
0 7 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
62 1
133 0
2
0 8 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
62 1
134 0
2
0 9 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
62 1
135 0
2
0 10 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
62 1
136 0
2
0 11 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
62 1
137 0
2
0 12 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
62 1
138 0
2
0 13 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
62 1
139 0
2
0 14 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
62 1
140 0
2
0 15 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
62 1
141 0
2
0 16 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
62 1
142 0
2
0 17 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
62 1
143 0
2
0 18 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
62 1
144 0
2
0 19 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
62 1
145 0
2
0 20 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
62 1
146 0
2
0 21 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
62 1
147 0
2
0 22 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
62 1
148 0
2
0 23 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
62 1
149 0
2
0 24 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut31
3
0 0
62 1
150 0
2
0 25 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut32
3
0 0
62 1
151 0
2
0 26 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut33
3
0 0
62 1
152 0
2
0 27 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut34
3
0 0
62 1
153 0
2
0 28 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut35
3
0 0
62 1
154 0
2
0 29 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut36
3
0 0
62 1
155 0
2
0 30 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut37
3
0 0
62 1
156 0
2
0 31 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut38
3
0 0
62 1
157 0
2
0 32 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut39
3
0 0
62 1
158 0
2
0 33 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
62 1
159 0
2
0 34 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut40
3
0 0
62 1
160 0
2
0 35 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut41
3
0 0
62 1
161 0
2
0 36 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut42
3
0 0
62 1
162 0
2
0 37 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut43
3
0 0
62 1
163 0
2
0 38 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut44
3
0 0
62 1
164 0
2
0 39 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut45
3
0 0
62 1
165 0
2
0 40 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
62 1
166 0
2
0 41 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
62 1
167 0
2
0 42 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
62 1
168 0
2
0 43 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
62 1
169 0
2
0 44 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
62 1
170 0
2
0 45 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
63 1
126 0
2
0 1 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
63 1
127 0
2
0 2 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
63 1
128 0
2
0 3 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
63 1
129 0
2
0 4 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
63 1
130 0
2
0 5 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
63 1
131 0
2
0 6 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
63 1
132 0
2
0 7 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
63 1
133 0
2
0 8 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
63 1
134 0
2
0 9 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
63 1
135 0
2
0 10 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
63 1
136 0
2
0 11 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
63 1
137 0
2
0 12 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
63 1
138 0
2
0 13 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
63 1
139 0
2
0 14 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
63 1
140 0
2
0 15 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
63 1
141 0
2
0 16 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
63 1
142 0
2
0 17 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
63 1
143 0
2
0 18 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
63 1
144 0
2
0 19 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
63 1
145 0
2
0 20 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
63 1
146 0
2
0 21 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
63 1
147 0
2
0 22 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
63 1
148 0
2
0 23 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
63 1
149 0
2
0 24 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut31
3
0 0
63 1
150 0
2
0 25 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut32
3
0 0
63 1
151 0
2
0 26 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut33
3
0 0
63 1
152 0
2
0 27 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut34
3
0 0
63 1
153 0
2
0 28 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut35
3
0 0
63 1
154 0
2
0 29 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut36
3
0 0
63 1
155 0
2
0 30 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut37
3
0 0
63 1
156 0
2
0 31 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut38
3
0 0
63 1
157 0
2
0 32 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut39
3
0 0
63 1
158 0
2
0 33 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
63 1
159 0
2
0 34 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut40
3
0 0
63 1
160 0
2
0 35 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut41
3
0 0
63 1
161 0
2
0 36 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut42
3
0 0
63 1
162 0
2
0 37 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut43
3
0 0
63 1
163 0
2
0 38 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut44
3
0 0
63 1
164 0
2
0 39 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut45
3
0 0
63 1
165 0
2
0 40 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
63 1
166 0
2
0 41 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
63 1
167 0
2
0 42 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
63 1
168 0
2
0 43 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
63 1
169 0
2
0 44 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
63 1
170 0
2
0 45 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
64 1
126 0
2
0 1 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
64 1
127 0
2
0 2 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
64 1
128 0
2
0 3 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
64 1
129 0
2
0 4 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
64 1
130 0
2
0 5 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
64 1
131 0
2
0 6 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
64 1
132 0
2
0 7 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
64 1
133 0
2
0 8 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
64 1
134 0
2
0 9 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
64 1
135 0
2
0 10 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
64 1
136 0
2
0 11 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
64 1
137 0
2
0 12 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
64 1
138 0
2
0 13 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
64 1
139 0
2
0 14 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
64 1
140 0
2
0 15 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
64 1
141 0
2
0 16 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
64 1
142 0
2
0 17 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
64 1
143 0
2
0 18 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
64 1
144 0
2
0 19 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
64 1
145 0
2
0 20 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
64 1
146 0
2
0 21 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
64 1
147 0
2
0 22 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
64 1
148 0
2
0 23 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
64 1
149 0
2
0 24 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut31
3
0 0
64 1
150 0
2
0 25 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut32
3
0 0
64 1
151 0
2
0 26 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut33
3
0 0
64 1
152 0
2
0 27 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut34
3
0 0
64 1
153 0
2
0 28 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut35
3
0 0
64 1
154 0
2
0 29 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut36
3
0 0
64 1
155 0
2
0 30 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut37
3
0 0
64 1
156 0
2
0 31 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut38
3
0 0
64 1
157 0
2
0 32 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut39
3
0 0
64 1
158 0
2
0 33 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
64 1
159 0
2
0 34 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut40
3
0 0
64 1
160 0
2
0 35 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut41
3
0 0
64 1
161 0
2
0 36 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut42
3
0 0
64 1
162 0
2
0 37 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut43
3
0 0
64 1
163 0
2
0 38 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut44
3
0 0
64 1
164 0
2
0 39 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut45
3
0 0
64 1
165 0
2
0 40 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
64 1
166 0
2
0 41 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
64 1
167 0
2
0 42 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
64 1
168 0
2
0 43 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
64 1
169 0
2
0 44 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
64 1
170 0
2
0 45 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
65 1
126 0
2
0 1 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
65 1
127 0
2
0 2 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
65 1
128 0
2
0 3 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
65 1
129 0
2
0 4 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
65 1
130 0
2
0 5 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
65 1
131 0
2
0 6 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
65 1
132 0
2
0 7 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
65 1
133 0
2
0 8 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
65 1
134 0
2
0 9 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
65 1
135 0
2
0 10 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
65 1
136 0
2
0 11 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
65 1
137 0
2
0 12 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
65 1
138 0
2
0 13 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
65 1
139 0
2
0 14 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
65 1
140 0
2
0 15 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
65 1
141 0
2
0 16 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
65 1
142 0
2
0 17 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
65 1
143 0
2
0 18 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
65 1
144 0
2
0 19 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
65 1
145 0
2
0 20 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
65 1
146 0
2
0 21 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
65 1
147 0
2
0 22 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
65 1
148 0
2
0 23 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
65 1
149 0
2
0 24 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut31
3
0 0
65 1
150 0
2
0 25 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut32
3
0 0
65 1
151 0
2
0 26 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut33
3
0 0
65 1
152 0
2
0 27 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut34
3
0 0
65 1
153 0
2
0 28 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut35
3
0 0
65 1
154 0
2
0 29 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut36
3
0 0
65 1
155 0
2
0 30 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut37
3
0 0
65 1
156 0
2
0 31 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut38
3
0 0
65 1
157 0
2
0 32 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut39
3
0 0
65 1
158 0
2
0 33 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
65 1
159 0
2
0 34 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut40
3
0 0
65 1
160 0
2
0 35 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut41
3
0 0
65 1
161 0
2
0 36 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut42
3
0 0
65 1
162 0
2
0 37 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut43
3
0 0
65 1
163 0
2
0 38 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut44
3
0 0
65 1
164 0
2
0 39 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut45
3
0 0
65 1
165 0
2
0 40 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
65 1
166 0
2
0 41 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
65 1
167 0
2
0 42 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
65 1
168 0
2
0 43 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
65 1
169 0
2
0 44 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
65 1
170 0
2
0 45 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
66 1
126 0
2
0 1 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
66 1
127 0
2
0 2 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
66 1
128 0
2
0 3 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
66 1
129 0
2
0 4 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
66 1
130 0
2
0 5 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
66 1
131 0
2
0 6 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
66 1
132 0
2
0 7 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
66 1
133 0
2
0 8 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
66 1
134 0
2
0 9 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
66 1
135 0
2
0 10 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
66 1
136 0
2
0 11 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
66 1
137 0
2
0 12 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
66 1
138 0
2
0 13 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
66 1
139 0
2
0 14 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
66 1
140 0
2
0 15 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
66 1
141 0
2
0 16 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
66 1
142 0
2
0 17 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
66 1
143 0
2
0 18 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
66 1
144 0
2
0 19 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
66 1
145 0
2
0 20 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
66 1
146 0
2
0 21 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
66 1
147 0
2
0 22 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
66 1
148 0
2
0 23 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
66 1
149 0
2
0 24 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut31
3
0 0
66 1
150 0
2
0 25 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut32
3
0 0
66 1
151 0
2
0 26 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut33
3
0 0
66 1
152 0
2
0 27 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut34
3
0 0
66 1
153 0
2
0 28 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut35
3
0 0
66 1
154 0
2
0 29 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut36
3
0 0
66 1
155 0
2
0 30 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut37
3
0 0
66 1
156 0
2
0 31 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut38
3
0 0
66 1
157 0
2
0 32 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut39
3
0 0
66 1
158 0
2
0 33 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
66 1
159 0
2
0 34 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut40
3
0 0
66 1
160 0
2
0 35 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut41
3
0 0
66 1
161 0
2
0 36 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut42
3
0 0
66 1
162 0
2
0 37 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut43
3
0 0
66 1
163 0
2
0 38 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut44
3
0 0
66 1
164 0
2
0 39 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut45
3
0 0
66 1
165 0
2
0 40 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
66 1
166 0
2
0 41 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
66 1
167 0
2
0 42 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
66 1
168 0
2
0 43 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
66 1
169 0
2
0 44 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
66 1
170 0
2
0 45 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
67 1
126 0
2
0 1 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
67 1
127 0
2
0 2 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
67 1
128 0
2
0 3 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
67 1
129 0
2
0 4 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
67 1
130 0
2
0 5 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
67 1
131 0
2
0 6 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
67 1
132 0
2
0 7 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
67 1
133 0
2
0 8 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
67 1
134 0
2
0 9 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
67 1
135 0
2
0 10 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
67 1
136 0
2
0 11 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
67 1
137 0
2
0 12 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
67 1
138 0
2
0 13 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
67 1
139 0
2
0 14 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
67 1
140 0
2
0 15 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
67 1
141 0
2
0 16 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
67 1
142 0
2
0 17 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
67 1
143 0
2
0 18 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
67 1
144 0
2
0 19 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
67 1
145 0
2
0 20 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
67 1
146 0
2
0 21 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
67 1
147 0
2
0 22 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
67 1
148 0
2
0 23 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
67 1
149 0
2
0 24 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut31
3
0 0
67 1
150 0
2
0 25 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut32
3
0 0
67 1
151 0
2
0 26 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut33
3
0 0
67 1
152 0
2
0 27 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut34
3
0 0
67 1
153 0
2
0 28 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut35
3
0 0
67 1
154 0
2
0 29 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut36
3
0 0
67 1
155 0
2
0 30 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut37
3
0 0
67 1
156 0
2
0 31 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut38
3
0 0
67 1
157 0
2
0 32 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut39
3
0 0
67 1
158 0
2
0 33 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
67 1
159 0
2
0 34 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut40
3
0 0
67 1
160 0
2
0 35 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut41
3
0 0
67 1
161 0
2
0 36 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut42
3
0 0
67 1
162 0
2
0 37 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut43
3
0 0
67 1
163 0
2
0 38 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut44
3
0 0
67 1
164 0
2
0 39 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut45
3
0 0
67 1
165 0
2
0 40 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
67 1
166 0
2
0 41 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
67 1
167 0
2
0 42 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
67 1
168 0
2
0 43 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
67 1
169 0
2
0 44 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
67 1
170 0
2
0 45 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
68 1
126 0
2
0 1 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
68 1
127 0
2
0 2 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
68 1
128 0
2
0 3 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
68 1
129 0
2
0 4 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
68 1
130 0
2
0 5 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
68 1
131 0
2
0 6 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
68 1
132 0
2
0 7 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
68 1
133 0
2
0 8 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
68 1
134 0
2
0 9 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
68 1
135 0
2
0 10 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
68 1
136 0
2
0 11 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
68 1
137 0
2
0 12 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
68 1
138 0
2
0 13 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
68 1
139 0
2
0 14 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
68 1
140 0
2
0 15 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
68 1
141 0
2
0 16 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
68 1
142 0
2
0 17 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
68 1
143 0
2
0 18 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
68 1
144 0
2
0 19 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
68 1
145 0
2
0 20 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
68 1
146 0
2
0 21 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
68 1
147 0
2
0 22 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
68 1
148 0
2
0 23 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
68 1
149 0
2
0 24 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut31
3
0 0
68 1
150 0
2
0 25 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut32
3
0 0
68 1
151 0
2
0 26 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut33
3
0 0
68 1
152 0
2
0 27 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut34
3
0 0
68 1
153 0
2
0 28 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut35
3
0 0
68 1
154 0
2
0 29 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut36
3
0 0
68 1
155 0
2
0 30 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut37
3
0 0
68 1
156 0
2
0 31 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut38
3
0 0
68 1
157 0
2
0 32 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut39
3
0 0
68 1
158 0
2
0 33 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
68 1
159 0
2
0 34 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut40
3
0 0
68 1
160 0
2
0 35 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut41
3
0 0
68 1
161 0
2
0 36 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut42
3
0 0
68 1
162 0
2
0 37 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut43
3
0 0
68 1
163 0
2
0 38 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut44
3
0 0
68 1
164 0
2
0 39 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut45
3
0 0
68 1
165 0
2
0 40 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
68 1
166 0
2
0 41 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
68 1
167 0
2
0 42 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
68 1
168 0
2
0 43 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
68 1
169 0
2
0 44 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
68 1
170 0
2
0 45 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
69 1
126 0
2
0 1 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
69 1
127 0
2
0 2 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
69 1
128 0
2
0 3 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
69 1
129 0
2
0 4 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
69 1
130 0
2
0 5 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
69 1
131 0
2
0 6 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
69 1
132 0
2
0 7 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
69 1
133 0
2
0 8 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
69 1
134 0
2
0 9 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
69 1
135 0
2
0 10 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
69 1
136 0
2
0 11 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
69 1
137 0
2
0 12 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
69 1
138 0
2
0 13 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
69 1
139 0
2
0 14 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
69 1
140 0
2
0 15 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
69 1
141 0
2
0 16 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
69 1
142 0
2
0 17 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
69 1
143 0
2
0 18 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
69 1
144 0
2
0 19 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
69 1
145 0
2
0 20 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
69 1
146 0
2
0 21 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
69 1
147 0
2
0 22 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
69 1
148 0
2
0 23 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
69 1
149 0
2
0 24 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut31
3
0 0
69 1
150 0
2
0 25 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut32
3
0 0
69 1
151 0
2
0 26 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut33
3
0 0
69 1
152 0
2
0 27 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut34
3
0 0
69 1
153 0
2
0 28 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut35
3
0 0
69 1
154 0
2
0 29 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut36
3
0 0
69 1
155 0
2
0 30 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut37
3
0 0
69 1
156 0
2
0 31 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut38
3
0 0
69 1
157 0
2
0 32 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut39
3
0 0
69 1
158 0
2
0 33 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
69 1
159 0
2
0 34 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut40
3
0 0
69 1
160 0
2
0 35 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut41
3
0 0
69 1
161 0
2
0 36 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut42
3
0 0
69 1
162 0
2
0 37 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut43
3
0 0
69 1
163 0
2
0 38 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut44
3
0 0
69 1
164 0
2
0 39 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut45
3
0 0
69 1
165 0
2
0 40 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
69 1
166 0
2
0 41 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
69 1
167 0
2
0 42 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
69 1
168 0
2
0 43 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
69 1
169 0
2
0 44 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
69 1
170 0
2
0 45 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
70 1
126 0
2
0 1 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
70 1
127 0
2
0 2 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
70 1
128 0
2
0 3 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
70 1
129 0
2
0 4 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
70 1
130 0
2
0 5 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
70 1
131 0
2
0 6 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
70 1
132 0
2
0 7 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
70 1
133 0
2
0 8 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
70 1
134 0
2
0 9 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
70 1
135 0
2
0 10 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
70 1
136 0
2
0 11 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
70 1
137 0
2
0 12 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
70 1
138 0
2
0 13 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
70 1
139 0
2
0 14 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
70 1
140 0
2
0 15 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
70 1
141 0
2
0 16 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
70 1
142 0
2
0 17 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
70 1
143 0
2
0 18 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
70 1
144 0
2
0 19 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
70 1
145 0
2
0 20 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
70 1
146 0
2
0 21 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
70 1
147 0
2
0 22 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
70 1
148 0
2
0 23 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
70 1
149 0
2
0 24 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut31
3
0 0
70 1
150 0
2
0 25 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut32
3
0 0
70 1
151 0
2
0 26 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut33
3
0 0
70 1
152 0
2
0 27 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut34
3
0 0
70 1
153 0
2
0 28 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut35
3
0 0
70 1
154 0
2
0 29 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut36
3
0 0
70 1
155 0
2
0 30 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut37
3
0 0
70 1
156 0
2
0 31 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut38
3
0 0
70 1
157 0
2
0 32 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut39
3
0 0
70 1
158 0
2
0 33 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
70 1
159 0
2
0 34 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut40
3
0 0
70 1
160 0
2
0 35 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut41
3
0 0
70 1
161 0
2
0 36 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut42
3
0 0
70 1
162 0
2
0 37 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut43
3
0 0
70 1
163 0
2
0 38 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut44
3
0 0
70 1
164 0
2
0 39 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut45
3
0 0
70 1
165 0
2
0 40 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
70 1
166 0
2
0 41 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
70 1
167 0
2
0 42 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
70 1
168 0
2
0 43 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
70 1
169 0
2
0 44 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
70 1
170 0
2
0 45 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
71 1
126 0
2
0 1 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
71 1
127 0
2
0 2 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
71 1
128 0
2
0 3 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
71 1
129 0
2
0 4 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
71 1
130 0
2
0 5 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
71 1
131 0
2
0 6 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
71 1
132 0
2
0 7 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
71 1
133 0
2
0 8 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
71 1
134 0
2
0 9 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
71 1
135 0
2
0 10 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
71 1
136 0
2
0 11 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
71 1
137 0
2
0 12 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
71 1
138 0
2
0 13 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
71 1
139 0
2
0 14 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
71 1
140 0
2
0 15 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
71 1
141 0
2
0 16 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
71 1
142 0
2
0 17 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
71 1
143 0
2
0 18 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
71 1
144 0
2
0 19 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
71 1
145 0
2
0 20 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
71 1
146 0
2
0 21 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
71 1
147 0
2
0 22 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
71 1
148 0
2
0 23 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
71 1
149 0
2
0 24 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut31
3
0 0
71 1
150 0
2
0 25 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut32
3
0 0
71 1
151 0
2
0 26 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut33
3
0 0
71 1
152 0
2
0 27 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut34
3
0 0
71 1
153 0
2
0 28 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut35
3
0 0
71 1
154 0
2
0 29 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut36
3
0 0
71 1
155 0
2
0 30 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut37
3
0 0
71 1
156 0
2
0 31 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut38
3
0 0
71 1
157 0
2
0 32 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut39
3
0 0
71 1
158 0
2
0 33 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
71 1
159 0
2
0 34 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut40
3
0 0
71 1
160 0
2
0 35 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut41
3
0 0
71 1
161 0
2
0 36 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut42
3
0 0
71 1
162 0
2
0 37 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut43
3
0 0
71 1
163 0
2
0 38 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut44
3
0 0
71 1
164 0
2
0 39 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut45
3
0 0
71 1
165 0
2
0 40 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
71 1
166 0
2
0 41 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
71 1
167 0
2
0 42 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
71 1
168 0
2
0 43 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
71 1
169 0
2
0 44 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
71 1
170 0
2
0 45 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
72 1
126 0
2
0 1 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
72 1
127 0
2
0 2 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
72 1
128 0
2
0 3 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
72 1
129 0
2
0 4 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
72 1
130 0
2
0 5 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
72 1
131 0
2
0 6 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
72 1
132 0
2
0 7 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
72 1
133 0
2
0 8 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
72 1
134 0
2
0 9 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
72 1
135 0
2
0 10 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
72 1
136 0
2
0 11 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
72 1
137 0
2
0 12 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
72 1
138 0
2
0 13 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
72 1
139 0
2
0 14 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
72 1
140 0
2
0 15 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
72 1
141 0
2
0 16 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
72 1
142 0
2
0 17 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
72 1
143 0
2
0 18 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
72 1
144 0
2
0 19 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
72 1
145 0
2
0 20 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
72 1
146 0
2
0 21 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
72 1
147 0
2
0 22 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
72 1
148 0
2
0 23 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
72 1
149 0
2
0 24 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut31
3
0 0
72 1
150 0
2
0 25 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut32
3
0 0
72 1
151 0
2
0 26 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut33
3
0 0
72 1
152 0
2
0 27 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut34
3
0 0
72 1
153 0
2
0 28 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut35
3
0 0
72 1
154 0
2
0 29 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut36
3
0 0
72 1
155 0
2
0 30 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut37
3
0 0
72 1
156 0
2
0 31 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut38
3
0 0
72 1
157 0
2
0 32 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut39
3
0 0
72 1
158 0
2
0 33 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
72 1
159 0
2
0 34 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut40
3
0 0
72 1
160 0
2
0 35 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut41
3
0 0
72 1
161 0
2
0 36 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut42
3
0 0
72 1
162 0
2
0 37 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut43
3
0 0
72 1
163 0
2
0 38 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut44
3
0 0
72 1
164 0
2
0 39 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut45
3
0 0
72 1
165 0
2
0 40 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
72 1
166 0
2
0 41 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
72 1
167 0
2
0 42 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
72 1
168 0
2
0 43 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
72 1
169 0
2
0 44 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
72 1
170 0
2
0 45 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
73 1
126 0
2
0 1 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
73 1
127 0
2
0 2 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
73 1
128 0
2
0 3 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
73 1
129 0
2
0 4 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
73 1
130 0
2
0 5 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
73 1
131 0
2
0 6 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
73 1
132 0
2
0 7 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
73 1
133 0
2
0 8 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
73 1
134 0
2
0 9 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
73 1
135 0
2
0 10 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
73 1
136 0
2
0 11 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
73 1
137 0
2
0 12 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
73 1
138 0
2
0 13 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
73 1
139 0
2
0 14 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
73 1
140 0
2
0 15 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
73 1
141 0
2
0 16 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
73 1
142 0
2
0 17 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
73 1
143 0
2
0 18 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
73 1
144 0
2
0 19 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
73 1
145 0
2
0 20 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
73 1
146 0
2
0 21 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
73 1
147 0
2
0 22 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
73 1
148 0
2
0 23 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
73 1
149 0
2
0 24 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut31
3
0 0
73 1
150 0
2
0 25 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut32
3
0 0
73 1
151 0
2
0 26 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut33
3
0 0
73 1
152 0
2
0 27 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut34
3
0 0
73 1
153 0
2
0 28 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut35
3
0 0
73 1
154 0
2
0 29 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut36
3
0 0
73 1
155 0
2
0 30 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut37
3
0 0
73 1
156 0
2
0 31 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut38
3
0 0
73 1
157 0
2
0 32 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut39
3
0 0
73 1
158 0
2
0 33 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
73 1
159 0
2
0 34 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut40
3
0 0
73 1
160 0
2
0 35 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut41
3
0 0
73 1
161 0
2
0 36 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut42
3
0 0
73 1
162 0
2
0 37 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut43
3
0 0
73 1
163 0
2
0 38 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut44
3
0 0
73 1
164 0
2
0 39 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut45
3
0 0
73 1
165 0
2
0 40 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
73 1
166 0
2
0 41 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
73 1
167 0
2
0 42 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
73 1
168 0
2
0 43 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
73 1
169 0
2
0 44 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
73 1
170 0
2
0 45 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
74 1
126 0
2
0 1 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
74 1
127 0
2
0 2 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
74 1
128 0
2
0 3 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
74 1
129 0
2
0 4 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
74 1
130 0
2
0 5 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
74 1
131 0
2
0 6 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
74 1
132 0
2
0 7 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
74 1
133 0
2
0 8 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
74 1
134 0
2
0 9 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
74 1
135 0
2
0 10 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
74 1
136 0
2
0 11 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
74 1
137 0
2
0 12 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
74 1
138 0
2
0 13 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
74 1
139 0
2
0 14 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
74 1
140 0
2
0 15 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
74 1
141 0
2
0 16 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
74 1
142 0
2
0 17 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
74 1
143 0
2
0 18 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
74 1
144 0
2
0 19 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
74 1
145 0
2
0 20 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
74 1
146 0
2
0 21 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
74 1
147 0
2
0 22 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
74 1
148 0
2
0 23 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
74 1
149 0
2
0 24 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut31
3
0 0
74 1
150 0
2
0 25 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut32
3
0 0
74 1
151 0
2
0 26 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut33
3
0 0
74 1
152 0
2
0 27 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut34
3
0 0
74 1
153 0
2
0 28 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut35
3
0 0
74 1
154 0
2
0 29 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut36
3
0 0
74 1
155 0
2
0 30 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut37
3
0 0
74 1
156 0
2
0 31 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut38
3
0 0
74 1
157 0
2
0 32 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut39
3
0 0
74 1
158 0
2
0 33 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
74 1
159 0
2
0 34 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut40
3
0 0
74 1
160 0
2
0 35 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut41
3
0 0
74 1
161 0
2
0 36 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut42
3
0 0
74 1
162 0
2
0 37 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut43
3
0 0
74 1
163 0
2
0 38 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut44
3
0 0
74 1
164 0
2
0 39 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut45
3
0 0
74 1
165 0
2
0 40 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
74 1
166 0
2
0 41 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
74 1
167 0
2
0 42 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
74 1
168 0
2
0 43 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
74 1
169 0
2
0 44 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
74 1
170 0
2
0 45 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
75 1
126 0
2
0 1 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
75 1
127 0
2
0 2 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
75 1
128 0
2
0 3 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
75 1
129 0
2
0 4 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
75 1
130 0
2
0 5 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
75 1
131 0
2
0 6 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
75 1
132 0
2
0 7 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
75 1
133 0
2
0 8 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
75 1
134 0
2
0 9 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
75 1
135 0
2
0 10 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
75 1
136 0
2
0 11 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
75 1
137 0
2
0 12 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
75 1
138 0
2
0 13 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
75 1
139 0
2
0 14 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
75 1
140 0
2
0 15 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
75 1
141 0
2
0 16 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
75 1
142 0
2
0 17 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
75 1
143 0
2
0 18 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
75 1
144 0
2
0 19 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
75 1
145 0
2
0 20 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
75 1
146 0
2
0 21 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
75 1
147 0
2
0 22 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
75 1
148 0
2
0 23 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
75 1
149 0
2
0 24 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut31
3
0 0
75 1
150 0
2
0 25 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut32
3
0 0
75 1
151 0
2
0 26 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut33
3
0 0
75 1
152 0
2
0 27 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut34
3
0 0
75 1
153 0
2
0 28 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut35
3
0 0
75 1
154 0
2
0 29 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut36
3
0 0
75 1
155 0
2
0 30 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut37
3
0 0
75 1
156 0
2
0 31 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut38
3
0 0
75 1
157 0
2
0 32 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut39
3
0 0
75 1
158 0
2
0 33 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
75 1
159 0
2
0 34 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut40
3
0 0
75 1
160 0
2
0 35 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut41
3
0 0
75 1
161 0
2
0 36 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut42
3
0 0
75 1
162 0
2
0 37 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut43
3
0 0
75 1
163 0
2
0 38 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut44
3
0 0
75 1
164 0
2
0 39 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut45
3
0 0
75 1
165 0
2
0 40 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
75 1
166 0
2
0 41 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
75 1
167 0
2
0 42 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
75 1
168 0
2
0 43 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
75 1
169 0
2
0 44 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
75 1
170 0
2
0 45 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
76 1
126 0
2
0 1 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
76 1
127 0
2
0 2 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
76 1
128 0
2
0 3 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
76 1
129 0
2
0 4 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
76 1
130 0
2
0 5 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
76 1
131 0
2
0 6 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
76 1
132 0
2
0 7 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
76 1
133 0
2
0 8 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
76 1
134 0
2
0 9 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
76 1
135 0
2
0 10 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
76 1
136 0
2
0 11 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
76 1
137 0
2
0 12 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
76 1
138 0
2
0 13 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
76 1
139 0
2
0 14 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
76 1
140 0
2
0 15 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
76 1
141 0
2
0 16 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
76 1
142 0
2
0 17 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
76 1
143 0
2
0 18 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
76 1
144 0
2
0 19 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
76 1
145 0
2
0 20 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
76 1
146 0
2
0 21 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
76 1
147 0
2
0 22 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
76 1
148 0
2
0 23 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
76 1
149 0
2
0 24 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut31
3
0 0
76 1
150 0
2
0 25 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut32
3
0 0
76 1
151 0
2
0 26 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut33
3
0 0
76 1
152 0
2
0 27 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut34
3
0 0
76 1
153 0
2
0 28 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut35
3
0 0
76 1
154 0
2
0 29 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut36
3
0 0
76 1
155 0
2
0 30 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut37
3
0 0
76 1
156 0
2
0 31 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut38
3
0 0
76 1
157 0
2
0 32 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut39
3
0 0
76 1
158 0
2
0 33 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
76 1
159 0
2
0 34 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut40
3
0 0
76 1
160 0
2
0 35 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut41
3
0 0
76 1
161 0
2
0 36 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut42
3
0 0
76 1
162 0
2
0 37 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut43
3
0 0
76 1
163 0
2
0 38 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut44
3
0 0
76 1
164 0
2
0 39 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut45
3
0 0
76 1
165 0
2
0 40 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
76 1
166 0
2
0 41 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
76 1
167 0
2
0 42 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
76 1
168 0
2
0 43 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
76 1
169 0
2
0 44 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
76 1
170 0
2
0 45 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
77 1
126 0
2
0 1 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
77 1
127 0
2
0 2 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
77 1
128 0
2
0 3 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
77 1
129 0
2
0 4 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
77 1
130 0
2
0 5 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
77 1
131 0
2
0 6 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
77 1
132 0
2
0 7 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
77 1
133 0
2
0 8 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
77 1
134 0
2
0 9 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
77 1
135 0
2
0 10 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
77 1
136 0
2
0 11 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
77 1
137 0
2
0 12 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
77 1
138 0
2
0 13 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
77 1
139 0
2
0 14 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
77 1
140 0
2
0 15 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
77 1
141 0
2
0 16 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
77 1
142 0
2
0 17 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
77 1
143 0
2
0 18 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
77 1
144 0
2
0 19 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
77 1
145 0
2
0 20 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
77 1
146 0
2
0 21 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
77 1
147 0
2
0 22 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
77 1
148 0
2
0 23 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
77 1
149 0
2
0 24 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut31
3
0 0
77 1
150 0
2
0 25 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut32
3
0 0
77 1
151 0
2
0 26 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut33
3
0 0
77 1
152 0
2
0 27 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut34
3
0 0
77 1
153 0
2
0 28 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut35
3
0 0
77 1
154 0
2
0 29 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut36
3
0 0
77 1
155 0
2
0 30 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut37
3
0 0
77 1
156 0
2
0 31 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut38
3
0 0
77 1
157 0
2
0 32 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut39
3
0 0
77 1
158 0
2
0 33 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
77 1
159 0
2
0 34 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut40
3
0 0
77 1
160 0
2
0 35 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut41
3
0 0
77 1
161 0
2
0 36 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut42
3
0 0
77 1
162 0
2
0 37 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut43
3
0 0
77 1
163 0
2
0 38 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut44
3
0 0
77 1
164 0
2
0 39 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut45
3
0 0
77 1
165 0
2
0 40 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
77 1
166 0
2
0 41 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
77 1
167 0
2
0 42 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
77 1
168 0
2
0 43 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
77 1
169 0
2
0 44 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
77 1
170 0
2
0 45 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
78 1
126 0
2
0 1 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
78 1
127 0
2
0 2 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
78 1
128 0
2
0 3 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
78 1
129 0
2
0 4 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
78 1
130 0
2
0 5 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
78 1
131 0
2
0 6 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
78 1
132 0
2
0 7 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
78 1
133 0
2
0 8 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
78 1
134 0
2
0 9 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
78 1
135 0
2
0 10 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
78 1
136 0
2
0 11 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
78 1
137 0
2
0 12 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
78 1
138 0
2
0 13 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
78 1
139 0
2
0 14 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
78 1
140 0
2
0 15 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
78 1
141 0
2
0 16 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
78 1
142 0
2
0 17 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
78 1
143 0
2
0 18 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
78 1
144 0
2
0 19 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
78 1
145 0
2
0 20 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
78 1
146 0
2
0 21 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
78 1
147 0
2
0 22 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
78 1
148 0
2
0 23 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
78 1
149 0
2
0 24 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut31
3
0 0
78 1
150 0
2
0 25 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut32
3
0 0
78 1
151 0
2
0 26 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut33
3
0 0
78 1
152 0
2
0 27 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut34
3
0 0
78 1
153 0
2
0 28 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut35
3
0 0
78 1
154 0
2
0 29 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut36
3
0 0
78 1
155 0
2
0 30 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut37
3
0 0
78 1
156 0
2
0 31 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut38
3
0 0
78 1
157 0
2
0 32 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut39
3
0 0
78 1
158 0
2
0 33 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
78 1
159 0
2
0 34 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut40
3
0 0
78 1
160 0
2
0 35 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut41
3
0 0
78 1
161 0
2
0 36 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut42
3
0 0
78 1
162 0
2
0 37 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut43
3
0 0
78 1
163 0
2
0 38 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut44
3
0 0
78 1
164 0
2
0 39 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut45
3
0 0
78 1
165 0
2
0 40 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
78 1
166 0
2
0 41 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
78 1
167 0
2
0 42 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
78 1
168 0
2
0 43 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
78 1
169 0
2
0 44 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
78 1
170 0
2
0 45 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
79 1
126 0
2
0 1 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
79 1
127 0
2
0 2 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
79 1
128 0
2
0 3 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
79 1
129 0
2
0 4 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
79 1
130 0
2
0 5 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
79 1
131 0
2
0 6 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
79 1
132 0
2
0 7 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
79 1
133 0
2
0 8 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
79 1
134 0
2
0 9 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
79 1
135 0
2
0 10 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
79 1
136 0
2
0 11 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
79 1
137 0
2
0 12 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
79 1
138 0
2
0 13 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
79 1
139 0
2
0 14 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
79 1
140 0
2
0 15 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
79 1
141 0
2
0 16 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
79 1
142 0
2
0 17 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
79 1
143 0
2
0 18 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
79 1
144 0
2
0 19 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
79 1
145 0
2
0 20 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
79 1
146 0
2
0 21 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
79 1
147 0
2
0 22 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
79 1
148 0
2
0 23 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
79 1
149 0
2
0 24 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut31
3
0 0
79 1
150 0
2
0 25 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut32
3
0 0
79 1
151 0
2
0 26 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut33
3
0 0
79 1
152 0
2
0 27 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut34
3
0 0
79 1
153 0
2
0 28 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut35
3
0 0
79 1
154 0
2
0 29 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut36
3
0 0
79 1
155 0
2
0 30 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut37
3
0 0
79 1
156 0
2
0 31 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut38
3
0 0
79 1
157 0
2
0 32 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut39
3
0 0
79 1
158 0
2
0 33 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
79 1
159 0
2
0 34 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut40
3
0 0
79 1
160 0
2
0 35 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut41
3
0 0
79 1
161 0
2
0 36 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut42
3
0 0
79 1
162 0
2
0 37 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut43
3
0 0
79 1
163 0
2
0 38 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut44
3
0 0
79 1
164 0
2
0 39 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut45
3
0 0
79 1
165 0
2
0 40 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
79 1
166 0
2
0 41 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
79 1
167 0
2
0 42 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
79 1
168 0
2
0 43 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
79 1
169 0
2
0 44 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
79 1
170 0
2
0 45 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
80 1
126 0
2
0 1 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
80 1
127 0
2
0 2 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
80 1
128 0
2
0 3 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
80 1
129 0
2
0 4 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
80 1
130 0
2
0 5 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
80 1
131 0
2
0 6 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
80 1
132 0
2
0 7 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
80 1
133 0
2
0 8 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
80 1
134 0
2
0 9 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
80 1
135 0
2
0 10 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
80 1
136 0
2
0 11 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
80 1
137 0
2
0 12 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
80 1
138 0
2
0 13 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
80 1
139 0
2
0 14 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
80 1
140 0
2
0 15 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
80 1
141 0
2
0 16 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
80 1
142 0
2
0 17 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
80 1
143 0
2
0 18 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
80 1
144 0
2
0 19 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
80 1
145 0
2
0 20 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
80 1
146 0
2
0 21 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
80 1
147 0
2
0 22 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
80 1
148 0
2
0 23 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
80 1
149 0
2
0 24 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut31
3
0 0
80 1
150 0
2
0 25 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut32
3
0 0
80 1
151 0
2
0 26 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut33
3
0 0
80 1
152 0
2
0 27 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut34
3
0 0
80 1
153 0
2
0 28 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut35
3
0 0
80 1
154 0
2
0 29 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut36
3
0 0
80 1
155 0
2
0 30 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut37
3
0 0
80 1
156 0
2
0 31 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut38
3
0 0
80 1
157 0
2
0 32 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut39
3
0 0
80 1
158 0
2
0 33 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
80 1
159 0
2
0 34 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut40
3
0 0
80 1
160 0
2
0 35 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut41
3
0 0
80 1
161 0
2
0 36 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut42
3
0 0
80 1
162 0
2
0 37 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut43
3
0 0
80 1
163 0
2
0 38 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut44
3
0 0
80 1
164 0
2
0 39 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut45
3
0 0
80 1
165 0
2
0 40 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
80 1
166 0
2
0 41 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
80 1
167 0
2
0 42 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
80 1
168 0
2
0 43 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
80 1
169 0
2
0 44 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
80 1
170 0
2
0 45 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
81 1
126 0
2
0 1 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
81 1
127 0
2
0 2 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
81 1
128 0
2
0 3 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
81 1
129 0
2
0 4 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
81 1
130 0
2
0 5 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
81 1
131 0
2
0 6 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
81 1
132 0
2
0 7 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
81 1
133 0
2
0 8 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
81 1
134 0
2
0 9 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
81 1
135 0
2
0 10 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
81 1
136 0
2
0 11 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
81 1
137 0
2
0 12 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
81 1
138 0
2
0 13 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
81 1
139 0
2
0 14 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
81 1
140 0
2
0 15 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
81 1
141 0
2
0 16 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
81 1
142 0
2
0 17 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
81 1
143 0
2
0 18 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
81 1
144 0
2
0 19 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
81 1
145 0
2
0 20 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
81 1
146 0
2
0 21 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
81 1
147 0
2
0 22 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
81 1
148 0
2
0 23 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
81 1
149 0
2
0 24 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut31
3
0 0
81 1
150 0
2
0 25 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut32
3
0 0
81 1
151 0
2
0 26 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut33
3
0 0
81 1
152 0
2
0 27 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut34
3
0 0
81 1
153 0
2
0 28 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut35
3
0 0
81 1
154 0
2
0 29 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut36
3
0 0
81 1
155 0
2
0 30 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut37
3
0 0
81 1
156 0
2
0 31 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut38
3
0 0
81 1
157 0
2
0 32 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut39
3
0 0
81 1
158 0
2
0 33 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
81 1
159 0
2
0 34 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut40
3
0 0
81 1
160 0
2
0 35 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut41
3
0 0
81 1
161 0
2
0 36 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut42
3
0 0
81 1
162 0
2
0 37 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut43
3
0 0
81 1
163 0
2
0 38 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut44
3
0 0
81 1
164 0
2
0 39 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut45
3
0 0
81 1
165 0
2
0 40 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
81 1
166 0
2
0 41 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
81 1
167 0
2
0 42 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
81 1
168 0
2
0 43 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
81 1
169 0
2
0 44 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
81 1
170 0
2
0 45 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
82 1
126 0
2
0 1 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
82 1
127 0
2
0 2 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
82 1
128 0
2
0 3 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
82 1
129 0
2
0 4 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
82 1
130 0
2
0 5 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
82 1
131 0
2
0 6 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
82 1
132 0
2
0 7 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
82 1
133 0
2
0 8 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
82 1
134 0
2
0 9 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
82 1
135 0
2
0 10 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
82 1
136 0
2
0 11 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
82 1
137 0
2
0 12 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
82 1
138 0
2
0 13 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
82 1
139 0
2
0 14 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
82 1
140 0
2
0 15 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
82 1
141 0
2
0 16 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
82 1
142 0
2
0 17 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
82 1
143 0
2
0 18 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
82 1
144 0
2
0 19 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
82 1
145 0
2
0 20 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
82 1
146 0
2
0 21 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
82 1
147 0
2
0 22 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
82 1
148 0
2
0 23 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
82 1
149 0
2
0 24 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut31
3
0 0
82 1
150 0
2
0 25 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut32
3
0 0
82 1
151 0
2
0 26 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut33
3
0 0
82 1
152 0
2
0 27 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut34
3
0 0
82 1
153 0
2
0 28 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut35
3
0 0
82 1
154 0
2
0 29 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut36
3
0 0
82 1
155 0
2
0 30 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut37
3
0 0
82 1
156 0
2
0 31 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut38
3
0 0
82 1
157 0
2
0 32 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut39
3
0 0
82 1
158 0
2
0 33 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
82 1
159 0
2
0 34 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut40
3
0 0
82 1
160 0
2
0 35 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut41
3
0 0
82 1
161 0
2
0 36 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut42
3
0 0
82 1
162 0
2
0 37 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut43
3
0 0
82 1
163 0
2
0 38 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut44
3
0 0
82 1
164 0
2
0 39 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut45
3
0 0
82 1
165 0
2
0 40 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
82 1
166 0
2
0 41 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
82 1
167 0
2
0 42 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
82 1
168 0
2
0 43 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
82 1
169 0
2
0 44 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
82 1
170 0
2
0 45 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
83 1
126 0
2
0 1 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
83 1
127 0
2
0 2 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
83 1
128 0
2
0 3 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
83 1
129 0
2
0 4 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
83 1
130 0
2
0 5 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
83 1
131 0
2
0 6 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
83 1
132 0
2
0 7 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
83 1
133 0
2
0 8 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
83 1
134 0
2
0 9 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
83 1
135 0
2
0 10 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
83 1
136 0
2
0 11 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
83 1
137 0
2
0 12 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
83 1
138 0
2
0 13 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
83 1
139 0
2
0 14 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
83 1
140 0
2
0 15 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
83 1
141 0
2
0 16 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
83 1
142 0
2
0 17 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
83 1
143 0
2
0 18 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
83 1
144 0
2
0 19 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
83 1
145 0
2
0 20 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
83 1
146 0
2
0 21 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
83 1
147 0
2
0 22 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
83 1
148 0
2
0 23 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
83 1
149 0
2
0 24 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut31
3
0 0
83 1
150 0
2
0 25 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut32
3
0 0
83 1
151 0
2
0 26 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut33
3
0 0
83 1
152 0
2
0 27 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut34
3
0 0
83 1
153 0
2
0 28 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut35
3
0 0
83 1
154 0
2
0 29 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut36
3
0 0
83 1
155 0
2
0 30 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut37
3
0 0
83 1
156 0
2
0 31 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut38
3
0 0
83 1
157 0
2
0 32 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut39
3
0 0
83 1
158 0
2
0 33 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
83 1
159 0
2
0 34 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut40
3
0 0
83 1
160 0
2
0 35 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut41
3
0 0
83 1
161 0
2
0 36 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut42
3
0 0
83 1
162 0
2
0 37 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut43
3
0 0
83 1
163 0
2
0 38 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut44
3
0 0
83 1
164 0
2
0 39 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut45
3
0 0
83 1
165 0
2
0 40 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
83 1
166 0
2
0 41 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
83 1
167 0
2
0 42 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
83 1
168 0
2
0 43 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
83 1
169 0
2
0 44 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
83 1
170 0
2
0 45 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
84 1
126 0
2
0 1 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
84 1
127 0
2
0 2 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
84 1
128 0
2
0 3 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
84 1
129 0
2
0 4 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
84 1
130 0
2
0 5 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
84 1
131 0
2
0 6 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
84 1
132 0
2
0 7 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
84 1
133 0
2
0 8 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
84 1
134 0
2
0 9 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
84 1
135 0
2
0 10 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
84 1
136 0
2
0 11 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
84 1
137 0
2
0 12 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
84 1
138 0
2
0 13 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
84 1
139 0
2
0 14 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
84 1
140 0
2
0 15 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
84 1
141 0
2
0 16 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
84 1
142 0
2
0 17 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
84 1
143 0
2
0 18 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
84 1
144 0
2
0 19 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
84 1
145 0
2
0 20 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
84 1
146 0
2
0 21 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
84 1
147 0
2
0 22 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
84 1
148 0
2
0 23 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
84 1
149 0
2
0 24 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut31
3
0 0
84 1
150 0
2
0 25 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut32
3
0 0
84 1
151 0
2
0 26 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut33
3
0 0
84 1
152 0
2
0 27 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut34
3
0 0
84 1
153 0
2
0 28 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut35
3
0 0
84 1
154 0
2
0 29 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut36
3
0 0
84 1
155 0
2
0 30 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut37
3
0 0
84 1
156 0
2
0 31 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut38
3
0 0
84 1
157 0
2
0 32 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut39
3
0 0
84 1
158 0
2
0 33 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
84 1
159 0
2
0 34 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut40
3
0 0
84 1
160 0
2
0 35 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut41
3
0 0
84 1
161 0
2
0 36 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut42
3
0 0
84 1
162 0
2
0 37 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut43
3
0 0
84 1
163 0
2
0 38 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut44
3
0 0
84 1
164 0
2
0 39 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut45
3
0 0
84 1
165 0
2
0 40 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
84 1
166 0
2
0 41 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
84 1
167 0
2
0 42 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
84 1
168 0
2
0 43 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
84 1
169 0
2
0 44 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
84 1
170 0
2
0 45 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
85 1
126 0
2
0 1 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
85 1
127 0
2
0 2 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
85 1
128 0
2
0 3 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
85 1
129 0
2
0 4 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
85 1
130 0
2
0 5 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
85 1
131 0
2
0 6 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
85 1
132 0
2
0 7 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
85 1
133 0
2
0 8 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
85 1
134 0
2
0 9 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
85 1
135 0
2
0 10 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
85 1
136 0
2
0 11 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
85 1
137 0
2
0 12 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
85 1
138 0
2
0 13 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
85 1
139 0
2
0 14 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
85 1
140 0
2
0 15 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
85 1
141 0
2
0 16 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
85 1
142 0
2
0 17 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
85 1
143 0
2
0 18 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
85 1
144 0
2
0 19 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
85 1
145 0
2
0 20 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
85 1
146 0
2
0 21 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
85 1
147 0
2
0 22 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
85 1
148 0
2
0 23 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
85 1
149 0
2
0 24 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut31
3
0 0
85 1
150 0
2
0 25 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut32
3
0 0
85 1
151 0
2
0 26 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut33
3
0 0
85 1
152 0
2
0 27 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut34
3
0 0
85 1
153 0
2
0 28 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut35
3
0 0
85 1
154 0
2
0 29 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut36
3
0 0
85 1
155 0
2
0 30 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut37
3
0 0
85 1
156 0
2
0 31 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut38
3
0 0
85 1
157 0
2
0 32 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut39
3
0 0
85 1
158 0
2
0 33 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
85 1
159 0
2
0 34 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut40
3
0 0
85 1
160 0
2
0 35 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut41
3
0 0
85 1
161 0
2
0 36 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut42
3
0 0
85 1
162 0
2
0 37 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut43
3
0 0
85 1
163 0
2
0 38 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut44
3
0 0
85 1
164 0
2
0 39 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut45
3
0 0
85 1
165 0
2
0 40 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
85 1
166 0
2
0 41 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
85 1
167 0
2
0 42 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
85 1
168 0
2
0 43 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
85 1
169 0
2
0 44 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
85 1
170 0
2
0 45 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
86 1
126 0
2
0 1 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
86 1
127 0
2
0 2 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
86 1
128 0
2
0 3 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
86 1
129 0
2
0 4 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
86 1
130 0
2
0 5 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
86 1
131 0
2
0 6 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
86 1
132 0
2
0 7 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
86 1
133 0
2
0 8 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
86 1
134 0
2
0 9 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
86 1
135 0
2
0 10 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
86 1
136 0
2
0 11 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
86 1
137 0
2
0 12 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
86 1
138 0
2
0 13 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
86 1
139 0
2
0 14 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
86 1
140 0
2
0 15 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
86 1
141 0
2
0 16 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
86 1
142 0
2
0 17 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
86 1
143 0
2
0 18 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
86 1
144 0
2
0 19 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
86 1
145 0
2
0 20 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
86 1
146 0
2
0 21 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
86 1
147 0
2
0 22 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
86 1
148 0
2
0 23 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
86 1
149 0
2
0 24 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut31
3
0 0
86 1
150 0
2
0 25 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut32
3
0 0
86 1
151 0
2
0 26 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut33
3
0 0
86 1
152 0
2
0 27 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut34
3
0 0
86 1
153 0
2
0 28 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut35
3
0 0
86 1
154 0
2
0 29 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut36
3
0 0
86 1
155 0
2
0 30 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut37
3
0 0
86 1
156 0
2
0 31 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut38
3
0 0
86 1
157 0
2
0 32 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut39
3
0 0
86 1
158 0
2
0 33 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
86 1
159 0
2
0 34 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut40
3
0 0
86 1
160 0
2
0 35 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut41
3
0 0
86 1
161 0
2
0 36 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut42
3
0 0
86 1
162 0
2
0 37 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut43
3
0 0
86 1
163 0
2
0 38 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut44
3
0 0
86 1
164 0
2
0 39 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut45
3
0 0
86 1
165 0
2
0 40 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
86 1
166 0
2
0 41 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
86 1
167 0
2
0 42 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
86 1
168 0
2
0 43 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
86 1
169 0
2
0 44 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
86 1
170 0
2
0 45 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
87 1
126 0
2
0 1 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
87 1
127 0
2
0 2 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
87 1
128 0
2
0 3 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
87 1
129 0
2
0 4 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
87 1
130 0
2
0 5 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
87 1
131 0
2
0 6 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
87 1
132 0
2
0 7 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
87 1
133 0
2
0 8 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
87 1
134 0
2
0 9 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
87 1
135 0
2
0 10 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
87 1
136 0
2
0 11 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
87 1
137 0
2
0 12 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
87 1
138 0
2
0 13 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
87 1
139 0
2
0 14 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
87 1
140 0
2
0 15 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
87 1
141 0
2
0 16 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
87 1
142 0
2
0 17 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
87 1
143 0
2
0 18 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
87 1
144 0
2
0 19 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
87 1
145 0
2
0 20 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
87 1
146 0
2
0 21 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
87 1
147 0
2
0 22 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
87 1
148 0
2
0 23 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
87 1
149 0
2
0 24 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut31
3
0 0
87 1
150 0
2
0 25 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut32
3
0 0
87 1
151 0
2
0 26 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut33
3
0 0
87 1
152 0
2
0 27 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut34
3
0 0
87 1
153 0
2
0 28 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut35
3
0 0
87 1
154 0
2
0 29 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut36
3
0 0
87 1
155 0
2
0 30 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut37
3
0 0
87 1
156 0
2
0 31 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut38
3
0 0
87 1
157 0
2
0 32 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut39
3
0 0
87 1
158 0
2
0 33 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
87 1
159 0
2
0 34 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut40
3
0 0
87 1
160 0
2
0 35 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut41
3
0 0
87 1
161 0
2
0 36 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut42
3
0 0
87 1
162 0
2
0 37 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut43
3
0 0
87 1
163 0
2
0 38 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut44
3
0 0
87 1
164 0
2
0 39 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut45
3
0 0
87 1
165 0
2
0 40 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
87 1
166 0
2
0 41 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
87 1
167 0
2
0 42 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
87 1
168 0
2
0 43 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
87 1
169 0
2
0 44 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
87 1
170 0
2
0 45 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
88 1
126 0
2
0 1 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
88 1
127 0
2
0 2 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
88 1
128 0
2
0 3 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
88 1
129 0
2
0 4 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
88 1
130 0
2
0 5 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
88 1
131 0
2
0 6 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
88 1
132 0
2
0 7 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
88 1
133 0
2
0 8 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
88 1
134 0
2
0 9 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
88 1
135 0
2
0 10 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
88 1
136 0
2
0 11 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
88 1
137 0
2
0 12 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
88 1
138 0
2
0 13 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
88 1
139 0
2
0 14 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
88 1
140 0
2
0 15 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
88 1
141 0
2
0 16 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
88 1
142 0
2
0 17 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
88 1
143 0
2
0 18 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
88 1
144 0
2
0 19 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
88 1
145 0
2
0 20 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
88 1
146 0
2
0 21 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
88 1
147 0
2
0 22 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
88 1
148 0
2
0 23 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
88 1
149 0
2
0 24 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut31
3
0 0
88 1
150 0
2
0 25 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut32
3
0 0
88 1
151 0
2
0 26 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut33
3
0 0
88 1
152 0
2
0 27 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut34
3
0 0
88 1
153 0
2
0 28 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut35
3
0 0
88 1
154 0
2
0 29 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut36
3
0 0
88 1
155 0
2
0 30 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut37
3
0 0
88 1
156 0
2
0 31 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut38
3
0 0
88 1
157 0
2
0 32 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut39
3
0 0
88 1
158 0
2
0 33 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
88 1
159 0
2
0 34 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut40
3
0 0
88 1
160 0
2
0 35 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut41
3
0 0
88 1
161 0
2
0 36 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut42
3
0 0
88 1
162 0
2
0 37 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut43
3
0 0
88 1
163 0
2
0 38 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut44
3
0 0
88 1
164 0
2
0 39 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut45
3
0 0
88 1
165 0
2
0 40 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
88 1
166 0
2
0 41 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
88 1
167 0
2
0 42 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
88 1
168 0
2
0 43 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
88 1
169 0
2
0 44 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
88 1
170 0
2
0 45 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
89 1
126 0
2
0 1 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
89 1
127 0
2
0 2 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
89 1
128 0
2
0 3 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
89 1
129 0
2
0 4 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
89 1
130 0
2
0 5 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
89 1
131 0
2
0 6 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
89 1
132 0
2
0 7 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
89 1
133 0
2
0 8 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
89 1
134 0
2
0 9 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
89 1
135 0
2
0 10 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
89 1
136 0
2
0 11 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
89 1
137 0
2
0 12 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
89 1
138 0
2
0 13 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
89 1
139 0
2
0 14 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
89 1
140 0
2
0 15 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
89 1
141 0
2
0 16 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
89 1
142 0
2
0 17 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
89 1
143 0
2
0 18 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
89 1
144 0
2
0 19 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
89 1
145 0
2
0 20 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
89 1
146 0
2
0 21 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
89 1
147 0
2
0 22 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
89 1
148 0
2
0 23 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
89 1
149 0
2
0 24 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut31
3
0 0
89 1
150 0
2
0 25 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut32
3
0 0
89 1
151 0
2
0 26 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut33
3
0 0
89 1
152 0
2
0 27 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut34
3
0 0
89 1
153 0
2
0 28 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut35
3
0 0
89 1
154 0
2
0 29 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut36
3
0 0
89 1
155 0
2
0 30 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut37
3
0 0
89 1
156 0
2
0 31 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut38
3
0 0
89 1
157 0
2
0 32 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut39
3
0 0
89 1
158 0
2
0 33 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
89 1
159 0
2
0 34 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut40
3
0 0
89 1
160 0
2
0 35 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut41
3
0 0
89 1
161 0
2
0 36 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut42
3
0 0
89 1
162 0
2
0 37 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut43
3
0 0
89 1
163 0
2
0 38 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut44
3
0 0
89 1
164 0
2
0 39 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut45
3
0 0
89 1
165 0
2
0 40 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
89 1
166 0
2
0 41 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
89 1
167 0
2
0 42 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
89 1
168 0
2
0 43 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
89 1
169 0
2
0 44 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
89 1
170 0
2
0 45 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
90 1
126 0
2
0 1 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
90 1
127 0
2
0 2 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
90 1
128 0
2
0 3 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
90 1
129 0
2
0 4 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
90 1
130 0
2
0 5 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
90 1
131 0
2
0 6 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
90 1
132 0
2
0 7 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
90 1
133 0
2
0 8 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
90 1
134 0
2
0 9 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
90 1
135 0
2
0 10 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
90 1
136 0
2
0 11 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
90 1
137 0
2
0 12 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
90 1
138 0
2
0 13 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
90 1
139 0
2
0 14 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
90 1
140 0
2
0 15 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
90 1
141 0
2
0 16 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
90 1
142 0
2
0 17 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
90 1
143 0
2
0 18 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
90 1
144 0
2
0 19 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
90 1
145 0
2
0 20 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
90 1
146 0
2
0 21 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
90 1
147 0
2
0 22 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
90 1
148 0
2
0 23 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
90 1
149 0
2
0 24 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut31
3
0 0
90 1
150 0
2
0 25 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut32
3
0 0
90 1
151 0
2
0 26 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut33
3
0 0
90 1
152 0
2
0 27 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut34
3
0 0
90 1
153 0
2
0 28 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut35
3
0 0
90 1
154 0
2
0 29 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut36
3
0 0
90 1
155 0
2
0 30 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut37
3
0 0
90 1
156 0
2
0 31 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut38
3
0 0
90 1
157 0
2
0 32 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut39
3
0 0
90 1
158 0
2
0 33 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
90 1
159 0
2
0 34 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut40
3
0 0
90 1
160 0
2
0 35 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut41
3
0 0
90 1
161 0
2
0 36 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut42
3
0 0
90 1
162 0
2
0 37 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut43
3
0 0
90 1
163 0
2
0 38 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut44
3
0 0
90 1
164 0
2
0 39 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut45
3
0 0
90 1
165 0
2
0 40 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
90 1
166 0
2
0 41 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
90 1
167 0
2
0 42 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
90 1
168 0
2
0 43 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
90 1
169 0
2
0 44 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
90 1
170 0
2
0 45 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
91 1
126 0
2
0 1 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
91 1
127 0
2
0 2 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
91 1
128 0
2
0 3 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
91 1
129 0
2
0 4 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
91 1
130 0
2
0 5 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
91 1
131 0
2
0 6 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
91 1
132 0
2
0 7 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
91 1
133 0
2
0 8 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
91 1
134 0
2
0 9 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
91 1
135 0
2
0 10 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
91 1
136 0
2
0 11 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
91 1
137 0
2
0 12 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
91 1
138 0
2
0 13 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
91 1
139 0
2
0 14 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
91 1
140 0
2
0 15 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
91 1
141 0
2
0 16 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
91 1
142 0
2
0 17 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
91 1
143 0
2
0 18 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
91 1
144 0
2
0 19 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
91 1
145 0
2
0 20 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
91 1
146 0
2
0 21 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
91 1
147 0
2
0 22 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
91 1
148 0
2
0 23 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
91 1
149 0
2
0 24 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut31
3
0 0
91 1
150 0
2
0 25 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut32
3
0 0
91 1
151 0
2
0 26 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut33
3
0 0
91 1
152 0
2
0 27 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut34
3
0 0
91 1
153 0
2
0 28 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut35
3
0 0
91 1
154 0
2
0 29 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut36
3
0 0
91 1
155 0
2
0 30 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut37
3
0 0
91 1
156 0
2
0 31 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut38
3
0 0
91 1
157 0
2
0 32 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut39
3
0 0
91 1
158 0
2
0 33 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
91 1
159 0
2
0 34 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut40
3
0 0
91 1
160 0
2
0 35 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut41
3
0 0
91 1
161 0
2
0 36 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut42
3
0 0
91 1
162 0
2
0 37 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut43
3
0 0
91 1
163 0
2
0 38 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut44
3
0 0
91 1
164 0
2
0 39 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut45
3
0 0
91 1
165 0
2
0 40 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
91 1
166 0
2
0 41 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
91 1
167 0
2
0 42 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
91 1
168 0
2
0 43 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
91 1
169 0
2
0 44 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
91 1
170 0
2
0 45 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
92 1
126 0
2
0 1 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
92 1
127 0
2
0 2 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
92 1
128 0
2
0 3 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
92 1
129 0
2
0 4 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
92 1
130 0
2
0 5 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
92 1
131 0
2
0 6 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
92 1
132 0
2
0 7 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
92 1
133 0
2
0 8 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
92 1
134 0
2
0 9 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
92 1
135 0
2
0 10 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
92 1
136 0
2
0 11 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
92 1
137 0
2
0 12 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
92 1
138 0
2
0 13 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
92 1
139 0
2
0 14 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
92 1
140 0
2
0 15 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
92 1
141 0
2
0 16 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
92 1
142 0
2
0 17 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
92 1
143 0
2
0 18 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
92 1
144 0
2
0 19 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
92 1
145 0
2
0 20 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
92 1
146 0
2
0 21 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
92 1
147 0
2
0 22 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
92 1
148 0
2
0 23 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
92 1
149 0
2
0 24 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut31
3
0 0
92 1
150 0
2
0 25 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut32
3
0 0
92 1
151 0
2
0 26 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut33
3
0 0
92 1
152 0
2
0 27 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut34
3
0 0
92 1
153 0
2
0 28 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut35
3
0 0
92 1
154 0
2
0 29 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut36
3
0 0
92 1
155 0
2
0 30 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut37
3
0 0
92 1
156 0
2
0 31 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut38
3
0 0
92 1
157 0
2
0 32 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut39
3
0 0
92 1
158 0
2
0 33 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
92 1
159 0
2
0 34 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut40
3
0 0
92 1
160 0
2
0 35 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut41
3
0 0
92 1
161 0
2
0 36 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut42
3
0 0
92 1
162 0
2
0 37 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut43
3
0 0
92 1
163 0
2
0 38 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut44
3
0 0
92 1
164 0
2
0 39 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut45
3
0 0
92 1
165 0
2
0 40 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
92 1
166 0
2
0 41 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
92 1
167 0
2
0 42 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
92 1
168 0
2
0 43 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
92 1
169 0
2
0 44 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
92 1
170 0
2
0 45 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
93 1
126 0
2
0 1 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
93 1
127 0
2
0 2 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
93 1
128 0
2
0 3 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
93 1
129 0
2
0 4 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
93 1
130 0
2
0 5 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
93 1
131 0
2
0 6 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
93 1
132 0
2
0 7 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
93 1
133 0
2
0 8 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
93 1
134 0
2
0 9 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
93 1
135 0
2
0 10 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
93 1
136 0
2
0 11 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
93 1
137 0
2
0 12 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
93 1
138 0
2
0 13 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
93 1
139 0
2
0 14 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
93 1
140 0
2
0 15 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
93 1
141 0
2
0 16 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
93 1
142 0
2
0 17 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
93 1
143 0
2
0 18 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
93 1
144 0
2
0 19 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
93 1
145 0
2
0 20 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
93 1
146 0
2
0 21 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
93 1
147 0
2
0 22 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
93 1
148 0
2
0 23 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
93 1
149 0
2
0 24 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut31
3
0 0
93 1
150 0
2
0 25 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut32
3
0 0
93 1
151 0
2
0 26 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut33
3
0 0
93 1
152 0
2
0 27 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut34
3
0 0
93 1
153 0
2
0 28 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut35
3
0 0
93 1
154 0
2
0 29 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut36
3
0 0
93 1
155 0
2
0 30 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut37
3
0 0
93 1
156 0
2
0 31 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut38
3
0 0
93 1
157 0
2
0 32 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut39
3
0 0
93 1
158 0
2
0 33 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
93 1
159 0
2
0 34 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut40
3
0 0
93 1
160 0
2
0 35 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut41
3
0 0
93 1
161 0
2
0 36 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut42
3
0 0
93 1
162 0
2
0 37 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut43
3
0 0
93 1
163 0
2
0 38 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut44
3
0 0
93 1
164 0
2
0 39 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut45
3
0 0
93 1
165 0
2
0 40 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
93 1
166 0
2
0 41 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
93 1
167 0
2
0 42 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
93 1
168 0
2
0 43 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
93 1
169 0
2
0 44 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
93 1
170 0
2
0 45 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
94 1
126 0
2
0 1 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
94 1
127 0
2
0 2 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
94 1
128 0
2
0 3 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
94 1
129 0
2
0 4 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
94 1
130 0
2
0 5 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
94 1
131 0
2
0 6 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
94 1
132 0
2
0 7 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
94 1
133 0
2
0 8 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
94 1
134 0
2
0 9 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
94 1
135 0
2
0 10 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
94 1
136 0
2
0 11 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
94 1
137 0
2
0 12 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
94 1
138 0
2
0 13 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
94 1
139 0
2
0 14 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
94 1
140 0
2
0 15 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
94 1
141 0
2
0 16 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
94 1
142 0
2
0 17 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
94 1
143 0
2
0 18 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
94 1
144 0
2
0 19 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
94 1
145 0
2
0 20 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
94 1
146 0
2
0 21 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
94 1
147 0
2
0 22 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
94 1
148 0
2
0 23 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
94 1
149 0
2
0 24 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut31
3
0 0
94 1
150 0
2
0 25 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut32
3
0 0
94 1
151 0
2
0 26 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut33
3
0 0
94 1
152 0
2
0 27 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut34
3
0 0
94 1
153 0
2
0 28 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut35
3
0 0
94 1
154 0
2
0 29 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut36
3
0 0
94 1
155 0
2
0 30 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut37
3
0 0
94 1
156 0
2
0 31 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut38
3
0 0
94 1
157 0
2
0 32 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut39
3
0 0
94 1
158 0
2
0 33 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
94 1
159 0
2
0 34 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut40
3
0 0
94 1
160 0
2
0 35 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut41
3
0 0
94 1
161 0
2
0 36 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut42
3
0 0
94 1
162 0
2
0 37 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut43
3
0 0
94 1
163 0
2
0 38 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut44
3
0 0
94 1
164 0
2
0 39 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut45
3
0 0
94 1
165 0
2
0 40 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
94 1
166 0
2
0 41 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
94 1
167 0
2
0 42 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
94 1
168 0
2
0 43 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
94 1
169 0
2
0 44 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
94 1
170 0
2
0 45 0 1
0 219 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
95 1
126 0
2
0 1 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
95 1
127 0
2
0 2 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
95 1
128 0
2
0 3 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
95 1
129 0
2
0 4 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
95 1
130 0
2
0 5 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
95 1
131 0
2
0 6 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
95 1
132 0
2
0 7 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
95 1
133 0
2
0 8 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
95 1
134 0
2
0 9 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
95 1
135 0
2
0 10 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
95 1
136 0
2
0 11 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
95 1
137 0
2
0 12 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
95 1
138 0
2
0 13 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
95 1
139 0
2
0 14 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
95 1
140 0
2
0 15 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
95 1
141 0
2
0 16 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
95 1
142 0
2
0 17 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
95 1
143 0
2
0 18 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
95 1
144 0
2
0 19 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
95 1
145 0
2
0 20 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
95 1
146 0
2
0 21 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
95 1
147 0
2
0 22 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
95 1
148 0
2
0 23 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
95 1
149 0
2
0 24 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut31
3
0 0
95 1
150 0
2
0 25 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut32
3
0 0
95 1
151 0
2
0 26 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut33
3
0 0
95 1
152 0
2
0 27 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut34
3
0 0
95 1
153 0
2
0 28 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut35
3
0 0
95 1
154 0
2
0 29 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut36
3
0 0
95 1
155 0
2
0 30 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut37
3
0 0
95 1
156 0
2
0 31 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut38
3
0 0
95 1
157 0
2
0 32 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut39
3
0 0
95 1
158 0
2
0 33 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
95 1
159 0
2
0 34 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut40
3
0 0
95 1
160 0
2
0 35 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut41
3
0 0
95 1
161 0
2
0 36 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut42
3
0 0
95 1
162 0
2
0 37 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut43
3
0 0
95 1
163 0
2
0 38 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut44
3
0 0
95 1
164 0
2
0 39 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut45
3
0 0
95 1
165 0
2
0 40 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
95 1
166 0
2
0 41 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
95 1
167 0
2
0 42 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
95 1
168 0
2
0 43 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
95 1
169 0
2
0 44 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
95 1
170 0
2
0 45 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
96 1
126 0
2
0 1 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
96 1
127 0
2
0 2 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
96 1
128 0
2
0 3 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
96 1
129 0
2
0 4 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
96 1
130 0
2
0 5 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
96 1
131 0
2
0 6 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
96 1
132 0
2
0 7 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
96 1
133 0
2
0 8 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
96 1
134 0
2
0 9 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
96 1
135 0
2
0 10 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
96 1
136 0
2
0 11 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
96 1
137 0
2
0 12 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
96 1
138 0
2
0 13 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
96 1
139 0
2
0 14 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
96 1
140 0
2
0 15 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
96 1
141 0
2
0 16 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
96 1
142 0
2
0 17 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
96 1
143 0
2
0 18 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
96 1
144 0
2
0 19 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
96 1
145 0
2
0 20 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
96 1
146 0
2
0 21 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
96 1
147 0
2
0 22 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
96 1
148 0
2
0 23 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
96 1
149 0
2
0 24 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut31
3
0 0
96 1
150 0
2
0 25 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut32
3
0 0
96 1
151 0
2
0 26 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut33
3
0 0
96 1
152 0
2
0 27 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut34
3
0 0
96 1
153 0
2
0 28 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut35
3
0 0
96 1
154 0
2
0 29 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut36
3
0 0
96 1
155 0
2
0 30 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut37
3
0 0
96 1
156 0
2
0 31 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut38
3
0 0
96 1
157 0
2
0 32 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut39
3
0 0
96 1
158 0
2
0 33 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
96 1
159 0
2
0 34 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut40
3
0 0
96 1
160 0
2
0 35 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut41
3
0 0
96 1
161 0
2
0 36 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut42
3
0 0
96 1
162 0
2
0 37 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut43
3
0 0
96 1
163 0
2
0 38 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut44
3
0 0
96 1
164 0
2
0 39 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut45
3
0 0
96 1
165 0
2
0 40 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
96 1
166 0
2
0 41 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
96 1
167 0
2
0 42 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
96 1
168 0
2
0 43 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
96 1
169 0
2
0 44 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
96 1
170 0
2
0 45 0 1
0 221 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
97 1
126 0
2
0 1 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
97 1
127 0
2
0 2 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
97 1
128 0
2
0 3 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
97 1
129 0
2
0 4 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
97 1
130 0
2
0 5 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
97 1
131 0
2
0 6 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
97 1
132 0
2
0 7 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
97 1
133 0
2
0 8 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
97 1
134 0
2
0 9 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
97 1
135 0
2
0 10 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
97 1
136 0
2
0 11 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
97 1
137 0
2
0 12 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
97 1
138 0
2
0 13 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
97 1
139 0
2
0 14 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
97 1
140 0
2
0 15 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
97 1
141 0
2
0 16 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
97 1
142 0
2
0 17 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
97 1
143 0
2
0 18 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
97 1
144 0
2
0 19 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
97 1
145 0
2
0 20 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
97 1
146 0
2
0 21 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
97 1
147 0
2
0 22 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
97 1
148 0
2
0 23 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
97 1
149 0
2
0 24 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut31
3
0 0
97 1
150 0
2
0 25 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut32
3
0 0
97 1
151 0
2
0 26 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut33
3
0 0
97 1
152 0
2
0 27 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut34
3
0 0
97 1
153 0
2
0 28 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut35
3
0 0
97 1
154 0
2
0 29 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut36
3
0 0
97 1
155 0
2
0 30 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut37
3
0 0
97 1
156 0
2
0 31 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut38
3
0 0
97 1
157 0
2
0 32 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut39
3
0 0
97 1
158 0
2
0 33 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
97 1
159 0
2
0 34 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut40
3
0 0
97 1
160 0
2
0 35 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut41
3
0 0
97 1
161 0
2
0 36 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut42
3
0 0
97 1
162 0
2
0 37 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut43
3
0 0
97 1
163 0
2
0 38 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut44
3
0 0
97 1
164 0
2
0 39 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut45
3
0 0
97 1
165 0
2
0 40 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
97 1
166 0
2
0 41 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
97 1
167 0
2
0 42 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
97 1
168 0
2
0 43 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
97 1
169 0
2
0 44 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
97 1
170 0
2
0 45 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut1
3
0 0
98 1
126 0
2
0 1 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut10
3
0 0
98 1
127 0
2
0 2 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut11
3
0 0
98 1
128 0
2
0 3 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut12
3
0 0
98 1
129 0
2
0 4 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut13
3
0 0
98 1
130 0
2
0 5 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut14
3
0 0
98 1
131 0
2
0 6 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut15
3
0 0
98 1
132 0
2
0 7 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut16
3
0 0
98 1
133 0
2
0 8 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut17
3
0 0
98 1
134 0
2
0 9 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut18
3
0 0
98 1
135 0
2
0 10 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut19
3
0 0
98 1
136 0
2
0 11 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut2
3
0 0
98 1
137 0
2
0 12 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut20
3
0 0
98 1
138 0
2
0 13 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut21
3
0 0
98 1
139 0
2
0 14 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut22
3
0 0
98 1
140 0
2
0 15 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut23
3
0 0
98 1
141 0
2
0 16 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut24
3
0 0
98 1
142 0
2
0 17 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut25
3
0 0
98 1
143 0
2
0 18 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut26
3
0 0
98 1
144 0
2
0 19 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut27
3
0 0
98 1
145 0
2
0 20 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut28
3
0 0
98 1
146 0
2
0 21 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut29
3
0 0
98 1
147 0
2
0 22 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut3
3
0 0
98 1
148 0
2
0 23 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut30
3
0 0
98 1
149 0
2
0 24 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut31
3
0 0
98 1
150 0
2
0 25 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut32
3
0 0
98 1
151 0
2
0 26 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut33
3
0 0
98 1
152 0
2
0 27 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut34
3
0 0
98 1
153 0
2
0 28 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut35
3
0 0
98 1
154 0
2
0 29 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut36
3
0 0
98 1
155 0
2
0 30 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut37
3
0 0
98 1
156 0
2
0 31 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut38
3
0 0
98 1
157 0
2
0 32 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut39
3
0 0
98 1
158 0
2
0 33 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut4
3
0 0
98 1
159 0
2
0 34 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut40
3
0 0
98 1
160 0
2
0 35 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut41
3
0 0
98 1
161 0
2
0 36 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut42
3
0 0
98 1
162 0
2
0 37 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut43
3
0 0
98 1
163 0
2
0 38 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut44
3
0 0
98 1
164 0
2
0 39 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut45
3
0 0
98 1
165 0
2
0 40 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut5
3
0 0
98 1
166 0
2
0 41 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut6
3
0 0
98 1
167 0
2
0 42 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut7
3
0 0
98 1
168 0
2
0 43 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut8
3
0 0
98 1
169 0
2
0 44 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut9
3
0 0
98 1
170 0
2
0 45 0 1
0 223 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut1
3
0 0
99 1
126 0
2
0 1 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut10
3
0 0
99 1
127 0
2
0 2 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut11
3
0 0
99 1
128 0
2
0 3 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut12
3
0 0
99 1
129 0
2
0 4 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut13
3
0 0
99 1
130 0
2
0 5 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut14
3
0 0
99 1
131 0
2
0 6 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut15
3
0 0
99 1
132 0
2
0 7 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut16
3
0 0
99 1
133 0
2
0 8 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut17
3
0 0
99 1
134 0
2
0 9 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut18
3
0 0
99 1
135 0
2
0 10 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut19
3
0 0
99 1
136 0
2
0 11 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut2
3
0 0
99 1
137 0
2
0 12 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut20
3
0 0
99 1
138 0
2
0 13 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut21
3
0 0
99 1
139 0
2
0 14 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut22
3
0 0
99 1
140 0
2
0 15 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut23
3
0 0
99 1
141 0
2
0 16 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut24
3
0 0
99 1
142 0
2
0 17 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut25
3
0 0
99 1
143 0
2
0 18 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut26
3
0 0
99 1
144 0
2
0 19 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut27
3
0 0
99 1
145 0
2
0 20 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut28
3
0 0
99 1
146 0
2
0 21 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut29
3
0 0
99 1
147 0
2
0 22 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut3
3
0 0
99 1
148 0
2
0 23 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut30
3
0 0
99 1
149 0
2
0 24 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut31
3
0 0
99 1
150 0
2
0 25 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut32
3
0 0
99 1
151 0
2
0 26 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut33
3
0 0
99 1
152 0
2
0 27 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut34
3
0 0
99 1
153 0
2
0 28 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut35
3
0 0
99 1
154 0
2
0 29 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut36
3
0 0
99 1
155 0
2
0 30 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut37
3
0 0
99 1
156 0
2
0 31 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut38
3
0 0
99 1
157 0
2
0 32 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut39
3
0 0
99 1
158 0
2
0 33 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut4
3
0 0
99 1
159 0
2
0 34 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut40
3
0 0
99 1
160 0
2
0 35 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut41
3
0 0
99 1
161 0
2
0 36 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut42
3
0 0
99 1
162 0
2
0 37 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut43
3
0 0
99 1
163 0
2
0 38 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut44
3
0 0
99 1
164 0
2
0 39 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut45
3
0 0
99 1
165 0
2
0 40 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut5
3
0 0
99 1
166 0
2
0 41 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut6
3
0 0
99 1
167 0
2
0 42 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut7
3
0 0
99 1
168 0
2
0 43 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut8
3
0 0
99 1
169 0
2
0 44 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut9
3
0 0
99 1
170 0
2
0 45 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut1
3
0 0
100 1
126 0
2
0 1 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut10
3
0 0
100 1
127 0
2
0 2 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut11
3
0 0
100 1
128 0
2
0 3 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut12
3
0 0
100 1
129 0
2
0 4 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut13
3
0 0
100 1
130 0
2
0 5 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut14
3
0 0
100 1
131 0
2
0 6 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut15
3
0 0
100 1
132 0
2
0 7 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut16
3
0 0
100 1
133 0
2
0 8 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut17
3
0 0
100 1
134 0
2
0 9 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut18
3
0 0
100 1
135 0
2
0 10 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut19
3
0 0
100 1
136 0
2
0 11 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut2
3
0 0
100 1
137 0
2
0 12 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut20
3
0 0
100 1
138 0
2
0 13 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut21
3
0 0
100 1
139 0
2
0 14 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut22
3
0 0
100 1
140 0
2
0 15 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut23
3
0 0
100 1
141 0
2
0 16 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut24
3
0 0
100 1
142 0
2
0 17 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut25
3
0 0
100 1
143 0
2
0 18 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut26
3
0 0
100 1
144 0
2
0 19 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut27
3
0 0
100 1
145 0
2
0 20 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut28
3
0 0
100 1
146 0
2
0 21 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut29
3
0 0
100 1
147 0
2
0 22 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut3
3
0 0
100 1
148 0
2
0 23 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut30
3
0 0
100 1
149 0
2
0 24 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut31
3
0 0
100 1
150 0
2
0 25 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut32
3
0 0
100 1
151 0
2
0 26 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut33
3
0 0
100 1
152 0
2
0 27 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut34
3
0 0
100 1
153 0
2
0 28 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut35
3
0 0
100 1
154 0
2
0 29 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut36
3
0 0
100 1
155 0
2
0 30 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut37
3
0 0
100 1
156 0
2
0 31 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut38
3
0 0
100 1
157 0
2
0 32 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut39
3
0 0
100 1
158 0
2
0 33 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut4
3
0 0
100 1
159 0
2
0 34 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut40
3
0 0
100 1
160 0
2
0 35 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut41
3
0 0
100 1
161 0
2
0 36 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut42
3
0 0
100 1
162 0
2
0 37 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut43
3
0 0
100 1
163 0
2
0 38 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut44
3
0 0
100 1
164 0
2
0 39 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut45
3
0 0
100 1
165 0
2
0 40 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut5
3
0 0
100 1
166 0
2
0 41 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut6
3
0 0
100 1
167 0
2
0 42 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut7
3
0 0
100 1
168 0
2
0 43 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut8
3
0 0
100 1
169 0
2
0 44 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut9
3
0 0
100 1
170 0
2
0 45 0 1
0 225 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
101 1
126 0
2
0 1 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
101 1
127 0
2
0 2 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
101 1
128 0
2
0 3 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
101 1
129 0
2
0 4 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
101 1
130 0
2
0 5 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
101 1
131 0
2
0 6 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
101 1
132 0
2
0 7 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
101 1
133 0
2
0 8 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
101 1
134 0
2
0 9 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
101 1
135 0
2
0 10 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
101 1
136 0
2
0 11 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
101 1
137 0
2
0 12 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
101 1
138 0
2
0 13 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
101 1
139 0
2
0 14 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
101 1
140 0
2
0 15 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
101 1
141 0
2
0 16 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
101 1
142 0
2
0 17 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
101 1
143 0
2
0 18 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
101 1
144 0
2
0 19 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
101 1
145 0
2
0 20 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
101 1
146 0
2
0 21 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
101 1
147 0
2
0 22 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
101 1
148 0
2
0 23 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
101 1
149 0
2
0 24 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut31
3
0 0
101 1
150 0
2
0 25 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut32
3
0 0
101 1
151 0
2
0 26 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut33
3
0 0
101 1
152 0
2
0 27 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut34
3
0 0
101 1
153 0
2
0 28 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut35
3
0 0
101 1
154 0
2
0 29 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut36
3
0 0
101 1
155 0
2
0 30 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut37
3
0 0
101 1
156 0
2
0 31 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut38
3
0 0
101 1
157 0
2
0 32 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut39
3
0 0
101 1
158 0
2
0 33 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
101 1
159 0
2
0 34 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut40
3
0 0
101 1
160 0
2
0 35 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut41
3
0 0
101 1
161 0
2
0 36 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut42
3
0 0
101 1
162 0
2
0 37 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut43
3
0 0
101 1
163 0
2
0 38 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut44
3
0 0
101 1
164 0
2
0 39 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut45
3
0 0
101 1
165 0
2
0 40 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
101 1
166 0
2
0 41 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
101 1
167 0
2
0 42 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
101 1
168 0
2
0 43 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
101 1
169 0
2
0 44 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
101 1
170 0
2
0 45 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut1
3
0 0
102 1
126 0
2
0 1 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut10
3
0 0
102 1
127 0
2
0 2 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut11
3
0 0
102 1
128 0
2
0 3 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut12
3
0 0
102 1
129 0
2
0 4 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut13
3
0 0
102 1
130 0
2
0 5 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut14
3
0 0
102 1
131 0
2
0 6 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut15
3
0 0
102 1
132 0
2
0 7 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut16
3
0 0
102 1
133 0
2
0 8 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut17
3
0 0
102 1
134 0
2
0 9 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut18
3
0 0
102 1
135 0
2
0 10 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut19
3
0 0
102 1
136 0
2
0 11 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut2
3
0 0
102 1
137 0
2
0 12 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut20
3
0 0
102 1
138 0
2
0 13 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut21
3
0 0
102 1
139 0
2
0 14 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut22
3
0 0
102 1
140 0
2
0 15 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut23
3
0 0
102 1
141 0
2
0 16 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut24
3
0 0
102 1
142 0
2
0 17 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut25
3
0 0
102 1
143 0
2
0 18 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut26
3
0 0
102 1
144 0
2
0 19 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut27
3
0 0
102 1
145 0
2
0 20 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut28
3
0 0
102 1
146 0
2
0 21 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut29
3
0 0
102 1
147 0
2
0 22 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut3
3
0 0
102 1
148 0
2
0 23 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut30
3
0 0
102 1
149 0
2
0 24 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut31
3
0 0
102 1
150 0
2
0 25 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut32
3
0 0
102 1
151 0
2
0 26 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut33
3
0 0
102 1
152 0
2
0 27 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut34
3
0 0
102 1
153 0
2
0 28 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut35
3
0 0
102 1
154 0
2
0 29 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut36
3
0 0
102 1
155 0
2
0 30 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut37
3
0 0
102 1
156 0
2
0 31 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut38
3
0 0
102 1
157 0
2
0 32 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut39
3
0 0
102 1
158 0
2
0 33 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut4
3
0 0
102 1
159 0
2
0 34 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut40
3
0 0
102 1
160 0
2
0 35 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut41
3
0 0
102 1
161 0
2
0 36 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut42
3
0 0
102 1
162 0
2
0 37 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut43
3
0 0
102 1
163 0
2
0 38 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut44
3
0 0
102 1
164 0
2
0 39 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut45
3
0 0
102 1
165 0
2
0 40 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut5
3
0 0
102 1
166 0
2
0 41 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut6
3
0 0
102 1
167 0
2
0 42 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut7
3
0 0
102 1
168 0
2
0 43 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut8
3
0 0
102 1
169 0
2
0 44 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut9
3
0 0
102 1
170 0
2
0 45 0 1
0 227 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut1
3
0 0
103 1
126 0
2
0 1 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut10
3
0 0
103 1
127 0
2
0 2 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut11
3
0 0
103 1
128 0
2
0 3 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut12
3
0 0
103 1
129 0
2
0 4 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut13
3
0 0
103 1
130 0
2
0 5 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut14
3
0 0
103 1
131 0
2
0 6 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut15
3
0 0
103 1
132 0
2
0 7 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut16
3
0 0
103 1
133 0
2
0 8 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut17
3
0 0
103 1
134 0
2
0 9 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut18
3
0 0
103 1
135 0
2
0 10 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut19
3
0 0
103 1
136 0
2
0 11 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut2
3
0 0
103 1
137 0
2
0 12 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut20
3
0 0
103 1
138 0
2
0 13 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut21
3
0 0
103 1
139 0
2
0 14 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut22
3
0 0
103 1
140 0
2
0 15 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut23
3
0 0
103 1
141 0
2
0 16 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut24
3
0 0
103 1
142 0
2
0 17 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut25
3
0 0
103 1
143 0
2
0 18 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut26
3
0 0
103 1
144 0
2
0 19 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut27
3
0 0
103 1
145 0
2
0 20 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut28
3
0 0
103 1
146 0
2
0 21 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut29
3
0 0
103 1
147 0
2
0 22 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut3
3
0 0
103 1
148 0
2
0 23 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut30
3
0 0
103 1
149 0
2
0 24 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut31
3
0 0
103 1
150 0
2
0 25 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut32
3
0 0
103 1
151 0
2
0 26 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut33
3
0 0
103 1
152 0
2
0 27 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut34
3
0 0
103 1
153 0
2
0 28 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut35
3
0 0
103 1
154 0
2
0 29 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut36
3
0 0
103 1
155 0
2
0 30 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut37
3
0 0
103 1
156 0
2
0 31 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut38
3
0 0
103 1
157 0
2
0 32 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut39
3
0 0
103 1
158 0
2
0 33 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut4
3
0 0
103 1
159 0
2
0 34 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut40
3
0 0
103 1
160 0
2
0 35 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut41
3
0 0
103 1
161 0
2
0 36 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut42
3
0 0
103 1
162 0
2
0 37 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut43
3
0 0
103 1
163 0
2
0 38 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut44
3
0 0
103 1
164 0
2
0 39 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut45
3
0 0
103 1
165 0
2
0 40 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut5
3
0 0
103 1
166 0
2
0 41 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut6
3
0 0
103 1
167 0
2
0 42 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut7
3
0 0
103 1
168 0
2
0 43 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut8
3
0 0
103 1
169 0
2
0 44 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut9
3
0 0
103 1
170 0
2
0 45 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut1
3
0 0
104 1
126 0
2
0 1 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut10
3
0 0
104 1
127 0
2
0 2 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut11
3
0 0
104 1
128 0
2
0 3 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut12
3
0 0
104 1
129 0
2
0 4 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut13
3
0 0
104 1
130 0
2
0 5 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut14
3
0 0
104 1
131 0
2
0 6 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut15
3
0 0
104 1
132 0
2
0 7 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut16
3
0 0
104 1
133 0
2
0 8 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut17
3
0 0
104 1
134 0
2
0 9 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut18
3
0 0
104 1
135 0
2
0 10 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut19
3
0 0
104 1
136 0
2
0 11 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut2
3
0 0
104 1
137 0
2
0 12 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut20
3
0 0
104 1
138 0
2
0 13 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut21
3
0 0
104 1
139 0
2
0 14 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut22
3
0 0
104 1
140 0
2
0 15 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut23
3
0 0
104 1
141 0
2
0 16 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut24
3
0 0
104 1
142 0
2
0 17 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut25
3
0 0
104 1
143 0
2
0 18 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut26
3
0 0
104 1
144 0
2
0 19 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut27
3
0 0
104 1
145 0
2
0 20 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut28
3
0 0
104 1
146 0
2
0 21 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut29
3
0 0
104 1
147 0
2
0 22 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut3
3
0 0
104 1
148 0
2
0 23 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut30
3
0 0
104 1
149 0
2
0 24 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut31
3
0 0
104 1
150 0
2
0 25 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut32
3
0 0
104 1
151 0
2
0 26 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut33
3
0 0
104 1
152 0
2
0 27 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut34
3
0 0
104 1
153 0
2
0 28 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut35
3
0 0
104 1
154 0
2
0 29 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut36
3
0 0
104 1
155 0
2
0 30 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut37
3
0 0
104 1
156 0
2
0 31 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut38
3
0 0
104 1
157 0
2
0 32 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut39
3
0 0
104 1
158 0
2
0 33 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut4
3
0 0
104 1
159 0
2
0 34 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut40
3
0 0
104 1
160 0
2
0 35 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut41
3
0 0
104 1
161 0
2
0 36 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut42
3
0 0
104 1
162 0
2
0 37 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut43
3
0 0
104 1
163 0
2
0 38 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut44
3
0 0
104 1
164 0
2
0 39 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut45
3
0 0
104 1
165 0
2
0 40 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut5
3
0 0
104 1
166 0
2
0 41 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut6
3
0 0
104 1
167 0
2
0 42 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut7
3
0 0
104 1
168 0
2
0 43 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut8
3
0 0
104 1
169 0
2
0 44 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut9
3
0 0
104 1
170 0
2
0 45 0 1
0 229 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut1
3
0 0
105 1
126 0
2
0 1 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut10
3
0 0
105 1
127 0
2
0 2 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut11
3
0 0
105 1
128 0
2
0 3 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut12
3
0 0
105 1
129 0
2
0 4 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut13
3
0 0
105 1
130 0
2
0 5 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut14
3
0 0
105 1
131 0
2
0 6 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut15
3
0 0
105 1
132 0
2
0 7 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut16
3
0 0
105 1
133 0
2
0 8 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut17
3
0 0
105 1
134 0
2
0 9 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut18
3
0 0
105 1
135 0
2
0 10 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut19
3
0 0
105 1
136 0
2
0 11 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut2
3
0 0
105 1
137 0
2
0 12 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut20
3
0 0
105 1
138 0
2
0 13 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut21
3
0 0
105 1
139 0
2
0 14 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut22
3
0 0
105 1
140 0
2
0 15 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut23
3
0 0
105 1
141 0
2
0 16 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut24
3
0 0
105 1
142 0
2
0 17 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut25
3
0 0
105 1
143 0
2
0 18 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut26
3
0 0
105 1
144 0
2
0 19 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut27
3
0 0
105 1
145 0
2
0 20 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut28
3
0 0
105 1
146 0
2
0 21 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut29
3
0 0
105 1
147 0
2
0 22 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut3
3
0 0
105 1
148 0
2
0 23 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut30
3
0 0
105 1
149 0
2
0 24 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut31
3
0 0
105 1
150 0
2
0 25 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut32
3
0 0
105 1
151 0
2
0 26 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut33
3
0 0
105 1
152 0
2
0 27 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut34
3
0 0
105 1
153 0
2
0 28 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut35
3
0 0
105 1
154 0
2
0 29 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut36
3
0 0
105 1
155 0
2
0 30 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut37
3
0 0
105 1
156 0
2
0 31 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut38
3
0 0
105 1
157 0
2
0 32 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut39
3
0 0
105 1
158 0
2
0 33 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut4
3
0 0
105 1
159 0
2
0 34 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut40
3
0 0
105 1
160 0
2
0 35 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut41
3
0 0
105 1
161 0
2
0 36 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut42
3
0 0
105 1
162 0
2
0 37 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut43
3
0 0
105 1
163 0
2
0 38 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut44
3
0 0
105 1
164 0
2
0 39 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut45
3
0 0
105 1
165 0
2
0 40 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut5
3
0 0
105 1
166 0
2
0 41 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut6
3
0 0
105 1
167 0
2
0 42 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut7
3
0 0
105 1
168 0
2
0 43 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut8
3
0 0
105 1
169 0
2
0 44 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut9
3
0 0
105 1
170 0
2
0 45 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut1
3
0 0
106 1
126 0
2
0 1 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut10
3
0 0
106 1
127 0
2
0 2 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut11
3
0 0
106 1
128 0
2
0 3 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut12
3
0 0
106 1
129 0
2
0 4 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut13
3
0 0
106 1
130 0
2
0 5 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut14
3
0 0
106 1
131 0
2
0 6 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut15
3
0 0
106 1
132 0
2
0 7 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut16
3
0 0
106 1
133 0
2
0 8 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut17
3
0 0
106 1
134 0
2
0 9 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut18
3
0 0
106 1
135 0
2
0 10 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut19
3
0 0
106 1
136 0
2
0 11 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut2
3
0 0
106 1
137 0
2
0 12 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut20
3
0 0
106 1
138 0
2
0 13 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut21
3
0 0
106 1
139 0
2
0 14 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut22
3
0 0
106 1
140 0
2
0 15 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut23
3
0 0
106 1
141 0
2
0 16 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut24
3
0 0
106 1
142 0
2
0 17 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut25
3
0 0
106 1
143 0
2
0 18 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut26
3
0 0
106 1
144 0
2
0 19 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut27
3
0 0
106 1
145 0
2
0 20 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut28
3
0 0
106 1
146 0
2
0 21 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut29
3
0 0
106 1
147 0
2
0 22 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut3
3
0 0
106 1
148 0
2
0 23 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut30
3
0 0
106 1
149 0
2
0 24 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut31
3
0 0
106 1
150 0
2
0 25 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut32
3
0 0
106 1
151 0
2
0 26 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut33
3
0 0
106 1
152 0
2
0 27 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut34
3
0 0
106 1
153 0
2
0 28 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut35
3
0 0
106 1
154 0
2
0 29 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut36
3
0 0
106 1
155 0
2
0 30 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut37
3
0 0
106 1
156 0
2
0 31 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut38
3
0 0
106 1
157 0
2
0 32 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut39
3
0 0
106 1
158 0
2
0 33 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut4
3
0 0
106 1
159 0
2
0 34 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut40
3
0 0
106 1
160 0
2
0 35 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut41
3
0 0
106 1
161 0
2
0 36 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut42
3
0 0
106 1
162 0
2
0 37 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut43
3
0 0
106 1
163 0
2
0 38 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut44
3
0 0
106 1
164 0
2
0 39 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut45
3
0 0
106 1
165 0
2
0 40 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut5
3
0 0
106 1
166 0
2
0 41 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut6
3
0 0
106 1
167 0
2
0 42 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut7
3
0 0
106 1
168 0
2
0 43 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut8
3
0 0
106 1
169 0
2
0 44 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut9
3
0 0
106 1
170 0
2
0 45 0 1
0 231 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut1
3
0 0
107 1
126 0
2
0 1 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut10
3
0 0
107 1
127 0
2
0 2 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut11
3
0 0
107 1
128 0
2
0 3 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut12
3
0 0
107 1
129 0
2
0 4 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut13
3
0 0
107 1
130 0
2
0 5 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut14
3
0 0
107 1
131 0
2
0 6 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut15
3
0 0
107 1
132 0
2
0 7 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut16
3
0 0
107 1
133 0
2
0 8 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut17
3
0 0
107 1
134 0
2
0 9 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut18
3
0 0
107 1
135 0
2
0 10 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut19
3
0 0
107 1
136 0
2
0 11 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut2
3
0 0
107 1
137 0
2
0 12 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut20
3
0 0
107 1
138 0
2
0 13 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut21
3
0 0
107 1
139 0
2
0 14 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut22
3
0 0
107 1
140 0
2
0 15 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut23
3
0 0
107 1
141 0
2
0 16 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut24
3
0 0
107 1
142 0
2
0 17 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut25
3
0 0
107 1
143 0
2
0 18 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut26
3
0 0
107 1
144 0
2
0 19 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut27
3
0 0
107 1
145 0
2
0 20 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut28
3
0 0
107 1
146 0
2
0 21 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut29
3
0 0
107 1
147 0
2
0 22 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut3
3
0 0
107 1
148 0
2
0 23 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut30
3
0 0
107 1
149 0
2
0 24 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut31
3
0 0
107 1
150 0
2
0 25 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut32
3
0 0
107 1
151 0
2
0 26 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut33
3
0 0
107 1
152 0
2
0 27 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut34
3
0 0
107 1
153 0
2
0 28 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut35
3
0 0
107 1
154 0
2
0 29 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut36
3
0 0
107 1
155 0
2
0 30 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut37
3
0 0
107 1
156 0
2
0 31 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut38
3
0 0
107 1
157 0
2
0 32 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut39
3
0 0
107 1
158 0
2
0 33 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut4
3
0 0
107 1
159 0
2
0 34 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut40
3
0 0
107 1
160 0
2
0 35 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut41
3
0 0
107 1
161 0
2
0 36 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut42
3
0 0
107 1
162 0
2
0 37 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut43
3
0 0
107 1
163 0
2
0 38 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut44
3
0 0
107 1
164 0
2
0 39 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut45
3
0 0
107 1
165 0
2
0 40 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut5
3
0 0
107 1
166 0
2
0 41 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut6
3
0 0
107 1
167 0
2
0 42 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut7
3
0 0
107 1
168 0
2
0 43 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut8
3
0 0
107 1
169 0
2
0 44 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut9
3
0 0
107 1
170 0
2
0 45 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut1
3
0 0
108 1
126 0
2
0 1 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut10
3
0 0
108 1
127 0
2
0 2 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut11
3
0 0
108 1
128 0
2
0 3 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut12
3
0 0
108 1
129 0
2
0 4 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut13
3
0 0
108 1
130 0
2
0 5 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut14
3
0 0
108 1
131 0
2
0 6 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut15
3
0 0
108 1
132 0
2
0 7 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut16
3
0 0
108 1
133 0
2
0 8 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut17
3
0 0
108 1
134 0
2
0 9 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut18
3
0 0
108 1
135 0
2
0 10 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut19
3
0 0
108 1
136 0
2
0 11 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut2
3
0 0
108 1
137 0
2
0 12 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut20
3
0 0
108 1
138 0
2
0 13 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut21
3
0 0
108 1
139 0
2
0 14 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut22
3
0 0
108 1
140 0
2
0 15 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut23
3
0 0
108 1
141 0
2
0 16 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut24
3
0 0
108 1
142 0
2
0 17 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut25
3
0 0
108 1
143 0
2
0 18 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut26
3
0 0
108 1
144 0
2
0 19 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut27
3
0 0
108 1
145 0
2
0 20 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut28
3
0 0
108 1
146 0
2
0 21 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut29
3
0 0
108 1
147 0
2
0 22 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut3
3
0 0
108 1
148 0
2
0 23 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut30
3
0 0
108 1
149 0
2
0 24 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut31
3
0 0
108 1
150 0
2
0 25 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut32
3
0 0
108 1
151 0
2
0 26 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut33
3
0 0
108 1
152 0
2
0 27 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut34
3
0 0
108 1
153 0
2
0 28 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut35
3
0 0
108 1
154 0
2
0 29 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut36
3
0 0
108 1
155 0
2
0 30 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut37
3
0 0
108 1
156 0
2
0 31 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut38
3
0 0
108 1
157 0
2
0 32 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut39
3
0 0
108 1
158 0
2
0 33 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut4
3
0 0
108 1
159 0
2
0 34 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut40
3
0 0
108 1
160 0
2
0 35 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut41
3
0 0
108 1
161 0
2
0 36 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut42
3
0 0
108 1
162 0
2
0 37 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut43
3
0 0
108 1
163 0
2
0 38 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut44
3
0 0
108 1
164 0
2
0 39 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut45
3
0 0
108 1
165 0
2
0 40 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut5
3
0 0
108 1
166 0
2
0 41 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut6
3
0 0
108 1
167 0
2
0 42 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut7
3
0 0
108 1
168 0
2
0 43 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut8
3
0 0
108 1
169 0
2
0 44 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut9
3
0 0
108 1
170 0
2
0 45 0 1
0 233 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut1
3
0 0
109 1
126 0
2
0 1 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut10
3
0 0
109 1
127 0
2
0 2 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut11
3
0 0
109 1
128 0
2
0 3 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut12
3
0 0
109 1
129 0
2
0 4 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut13
3
0 0
109 1
130 0
2
0 5 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut14
3
0 0
109 1
131 0
2
0 6 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut15
3
0 0
109 1
132 0
2
0 7 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut16
3
0 0
109 1
133 0
2
0 8 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut17
3
0 0
109 1
134 0
2
0 9 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut18
3
0 0
109 1
135 0
2
0 10 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut19
3
0 0
109 1
136 0
2
0 11 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut2
3
0 0
109 1
137 0
2
0 12 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut20
3
0 0
109 1
138 0
2
0 13 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut21
3
0 0
109 1
139 0
2
0 14 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut22
3
0 0
109 1
140 0
2
0 15 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut23
3
0 0
109 1
141 0
2
0 16 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut24
3
0 0
109 1
142 0
2
0 17 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut25
3
0 0
109 1
143 0
2
0 18 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut26
3
0 0
109 1
144 0
2
0 19 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut27
3
0 0
109 1
145 0
2
0 20 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut28
3
0 0
109 1
146 0
2
0 21 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut29
3
0 0
109 1
147 0
2
0 22 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut3
3
0 0
109 1
148 0
2
0 23 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut30
3
0 0
109 1
149 0
2
0 24 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut31
3
0 0
109 1
150 0
2
0 25 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut32
3
0 0
109 1
151 0
2
0 26 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut33
3
0 0
109 1
152 0
2
0 27 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut34
3
0 0
109 1
153 0
2
0 28 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut35
3
0 0
109 1
154 0
2
0 29 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut36
3
0 0
109 1
155 0
2
0 30 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut37
3
0 0
109 1
156 0
2
0 31 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut38
3
0 0
109 1
157 0
2
0 32 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut39
3
0 0
109 1
158 0
2
0 33 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut4
3
0 0
109 1
159 0
2
0 34 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut40
3
0 0
109 1
160 0
2
0 35 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut41
3
0 0
109 1
161 0
2
0 36 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut42
3
0 0
109 1
162 0
2
0 37 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut43
3
0 0
109 1
163 0
2
0 38 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut44
3
0 0
109 1
164 0
2
0 39 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut45
3
0 0
109 1
165 0
2
0 40 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut5
3
0 0
109 1
166 0
2
0 41 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut6
3
0 0
109 1
167 0
2
0 42 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut7
3
0 0
109 1
168 0
2
0 43 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut8
3
0 0
109 1
169 0
2
0 44 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut9
3
0 0
109 1
170 0
2
0 45 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut1
3
0 0
110 1
126 0
2
0 1 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut10
3
0 0
110 1
127 0
2
0 2 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut11
3
0 0
110 1
128 0
2
0 3 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut12
3
0 0
110 1
129 0
2
0 4 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut13
3
0 0
110 1
130 0
2
0 5 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut14
3
0 0
110 1
131 0
2
0 6 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut15
3
0 0
110 1
132 0
2
0 7 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut16
3
0 0
110 1
133 0
2
0 8 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut17
3
0 0
110 1
134 0
2
0 9 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut18
3
0 0
110 1
135 0
2
0 10 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut19
3
0 0
110 1
136 0
2
0 11 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut2
3
0 0
110 1
137 0
2
0 12 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut20
3
0 0
110 1
138 0
2
0 13 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut21
3
0 0
110 1
139 0
2
0 14 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut22
3
0 0
110 1
140 0
2
0 15 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut23
3
0 0
110 1
141 0
2
0 16 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut24
3
0 0
110 1
142 0
2
0 17 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut25
3
0 0
110 1
143 0
2
0 18 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut26
3
0 0
110 1
144 0
2
0 19 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut27
3
0 0
110 1
145 0
2
0 20 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut28
3
0 0
110 1
146 0
2
0 21 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut29
3
0 0
110 1
147 0
2
0 22 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut3
3
0 0
110 1
148 0
2
0 23 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut30
3
0 0
110 1
149 0
2
0 24 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut31
3
0 0
110 1
150 0
2
0 25 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut32
3
0 0
110 1
151 0
2
0 26 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut33
3
0 0
110 1
152 0
2
0 27 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut34
3
0 0
110 1
153 0
2
0 28 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut35
3
0 0
110 1
154 0
2
0 29 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut36
3
0 0
110 1
155 0
2
0 30 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut37
3
0 0
110 1
156 0
2
0 31 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut38
3
0 0
110 1
157 0
2
0 32 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut39
3
0 0
110 1
158 0
2
0 33 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut4
3
0 0
110 1
159 0
2
0 34 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut40
3
0 0
110 1
160 0
2
0 35 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut41
3
0 0
110 1
161 0
2
0 36 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut42
3
0 0
110 1
162 0
2
0 37 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut43
3
0 0
110 1
163 0
2
0 38 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut44
3
0 0
110 1
164 0
2
0 39 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut45
3
0 0
110 1
165 0
2
0 40 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut5
3
0 0
110 1
166 0
2
0 41 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut6
3
0 0
110 1
167 0
2
0 42 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut7
3
0 0
110 1
168 0
2
0 43 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut8
3
0 0
110 1
169 0
2
0 44 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut9
3
0 0
110 1
170 0
2
0 45 0 1
0 235 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut1
3
0 0
111 1
126 0
2
0 1 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut10
3
0 0
111 1
127 0
2
0 2 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut11
3
0 0
111 1
128 0
2
0 3 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut12
3
0 0
111 1
129 0
2
0 4 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut13
3
0 0
111 1
130 0
2
0 5 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut14
3
0 0
111 1
131 0
2
0 6 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut15
3
0 0
111 1
132 0
2
0 7 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut16
3
0 0
111 1
133 0
2
0 8 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut17
3
0 0
111 1
134 0
2
0 9 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut18
3
0 0
111 1
135 0
2
0 10 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut19
3
0 0
111 1
136 0
2
0 11 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut2
3
0 0
111 1
137 0
2
0 12 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut20
3
0 0
111 1
138 0
2
0 13 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut21
3
0 0
111 1
139 0
2
0 14 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut22
3
0 0
111 1
140 0
2
0 15 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut23
3
0 0
111 1
141 0
2
0 16 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut24
3
0 0
111 1
142 0
2
0 17 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut25
3
0 0
111 1
143 0
2
0 18 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut26
3
0 0
111 1
144 0
2
0 19 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut27
3
0 0
111 1
145 0
2
0 20 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut28
3
0 0
111 1
146 0
2
0 21 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut29
3
0 0
111 1
147 0
2
0 22 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut3
3
0 0
111 1
148 0
2
0 23 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut30
3
0 0
111 1
149 0
2
0 24 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut31
3
0 0
111 1
150 0
2
0 25 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut32
3
0 0
111 1
151 0
2
0 26 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut33
3
0 0
111 1
152 0
2
0 27 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut34
3
0 0
111 1
153 0
2
0 28 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut35
3
0 0
111 1
154 0
2
0 29 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut36
3
0 0
111 1
155 0
2
0 30 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut37
3
0 0
111 1
156 0
2
0 31 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut38
3
0 0
111 1
157 0
2
0 32 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut39
3
0 0
111 1
158 0
2
0 33 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut4
3
0 0
111 1
159 0
2
0 34 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut40
3
0 0
111 1
160 0
2
0 35 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut41
3
0 0
111 1
161 0
2
0 36 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut42
3
0 0
111 1
162 0
2
0 37 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut43
3
0 0
111 1
163 0
2
0 38 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut44
3
0 0
111 1
164 0
2
0 39 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut45
3
0 0
111 1
165 0
2
0 40 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut5
3
0 0
111 1
166 0
2
0 41 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut6
3
0 0
111 1
167 0
2
0 42 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut7
3
0 0
111 1
168 0
2
0 43 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut8
3
0 0
111 1
169 0
2
0 44 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut9
3
0 0
111 1
170 0
2
0 45 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
112 1
126 0
2
0 1 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
112 1
127 0
2
0 2 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
112 1
128 0
2
0 3 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
112 1
129 0
2
0 4 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
112 1
130 0
2
0 5 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
112 1
131 0
2
0 6 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
112 1
132 0
2
0 7 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
112 1
133 0
2
0 8 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
112 1
134 0
2
0 9 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
112 1
135 0
2
0 10 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
112 1
136 0
2
0 11 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
112 1
137 0
2
0 12 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
112 1
138 0
2
0 13 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
112 1
139 0
2
0 14 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
112 1
140 0
2
0 15 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
112 1
141 0
2
0 16 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
112 1
142 0
2
0 17 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
112 1
143 0
2
0 18 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
112 1
144 0
2
0 19 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
112 1
145 0
2
0 20 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
112 1
146 0
2
0 21 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
112 1
147 0
2
0 22 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
112 1
148 0
2
0 23 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
112 1
149 0
2
0 24 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut31
3
0 0
112 1
150 0
2
0 25 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut32
3
0 0
112 1
151 0
2
0 26 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut33
3
0 0
112 1
152 0
2
0 27 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut34
3
0 0
112 1
153 0
2
0 28 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut35
3
0 0
112 1
154 0
2
0 29 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut36
3
0 0
112 1
155 0
2
0 30 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut37
3
0 0
112 1
156 0
2
0 31 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut38
3
0 0
112 1
157 0
2
0 32 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut39
3
0 0
112 1
158 0
2
0 33 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
112 1
159 0
2
0 34 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut40
3
0 0
112 1
160 0
2
0 35 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut41
3
0 0
112 1
161 0
2
0 36 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut42
3
0 0
112 1
162 0
2
0 37 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut43
3
0 0
112 1
163 0
2
0 38 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut44
3
0 0
112 1
164 0
2
0 39 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut45
3
0 0
112 1
165 0
2
0 40 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
112 1
166 0
2
0 41 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
112 1
167 0
2
0 42 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
112 1
168 0
2
0 43 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
112 1
169 0
2
0 44 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
112 1
170 0
2
0 45 0 1
0 237 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut1
3
0 0
113 1
126 0
2
0 1 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut10
3
0 0
113 1
127 0
2
0 2 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut11
3
0 0
113 1
128 0
2
0 3 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut12
3
0 0
113 1
129 0
2
0 4 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut13
3
0 0
113 1
130 0
2
0 5 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut14
3
0 0
113 1
131 0
2
0 6 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut15
3
0 0
113 1
132 0
2
0 7 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut16
3
0 0
113 1
133 0
2
0 8 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut17
3
0 0
113 1
134 0
2
0 9 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut18
3
0 0
113 1
135 0
2
0 10 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut19
3
0 0
113 1
136 0
2
0 11 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut2
3
0 0
113 1
137 0
2
0 12 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut20
3
0 0
113 1
138 0
2
0 13 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut21
3
0 0
113 1
139 0
2
0 14 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut22
3
0 0
113 1
140 0
2
0 15 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut23
3
0 0
113 1
141 0
2
0 16 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut24
3
0 0
113 1
142 0
2
0 17 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut25
3
0 0
113 1
143 0
2
0 18 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut26
3
0 0
113 1
144 0
2
0 19 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut27
3
0 0
113 1
145 0
2
0 20 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut28
3
0 0
113 1
146 0
2
0 21 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut29
3
0 0
113 1
147 0
2
0 22 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut3
3
0 0
113 1
148 0
2
0 23 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut30
3
0 0
113 1
149 0
2
0 24 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut31
3
0 0
113 1
150 0
2
0 25 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut32
3
0 0
113 1
151 0
2
0 26 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut33
3
0 0
113 1
152 0
2
0 27 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut34
3
0 0
113 1
153 0
2
0 28 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut35
3
0 0
113 1
154 0
2
0 29 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut36
3
0 0
113 1
155 0
2
0 30 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut37
3
0 0
113 1
156 0
2
0 31 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut38
3
0 0
113 1
157 0
2
0 32 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut39
3
0 0
113 1
158 0
2
0 33 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut4
3
0 0
113 1
159 0
2
0 34 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut40
3
0 0
113 1
160 0
2
0 35 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut41
3
0 0
113 1
161 0
2
0 36 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut42
3
0 0
113 1
162 0
2
0 37 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut43
3
0 0
113 1
163 0
2
0 38 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut44
3
0 0
113 1
164 0
2
0 39 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut45
3
0 0
113 1
165 0
2
0 40 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut5
3
0 0
113 1
166 0
2
0 41 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut6
3
0 0
113 1
167 0
2
0 42 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut7
3
0 0
113 1
168 0
2
0 43 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut8
3
0 0
113 1
169 0
2
0 44 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut9
3
0 0
113 1
170 0
2
0 45 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut1
3
0 0
114 1
126 0
2
0 1 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut10
3
0 0
114 1
127 0
2
0 2 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut11
3
0 0
114 1
128 0
2
0 3 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut12
3
0 0
114 1
129 0
2
0 4 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut13
3
0 0
114 1
130 0
2
0 5 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut14
3
0 0
114 1
131 0
2
0 6 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut15
3
0 0
114 1
132 0
2
0 7 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut16
3
0 0
114 1
133 0
2
0 8 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut17
3
0 0
114 1
134 0
2
0 9 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut18
3
0 0
114 1
135 0
2
0 10 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut19
3
0 0
114 1
136 0
2
0 11 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut2
3
0 0
114 1
137 0
2
0 12 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut20
3
0 0
114 1
138 0
2
0 13 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut21
3
0 0
114 1
139 0
2
0 14 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut22
3
0 0
114 1
140 0
2
0 15 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut23
3
0 0
114 1
141 0
2
0 16 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut24
3
0 0
114 1
142 0
2
0 17 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut25
3
0 0
114 1
143 0
2
0 18 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut26
3
0 0
114 1
144 0
2
0 19 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut27
3
0 0
114 1
145 0
2
0 20 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut28
3
0 0
114 1
146 0
2
0 21 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut29
3
0 0
114 1
147 0
2
0 22 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut3
3
0 0
114 1
148 0
2
0 23 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut30
3
0 0
114 1
149 0
2
0 24 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut31
3
0 0
114 1
150 0
2
0 25 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut32
3
0 0
114 1
151 0
2
0 26 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut33
3
0 0
114 1
152 0
2
0 27 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut34
3
0 0
114 1
153 0
2
0 28 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut35
3
0 0
114 1
154 0
2
0 29 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut36
3
0 0
114 1
155 0
2
0 30 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut37
3
0 0
114 1
156 0
2
0 31 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut38
3
0 0
114 1
157 0
2
0 32 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut39
3
0 0
114 1
158 0
2
0 33 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut4
3
0 0
114 1
159 0
2
0 34 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut40
3
0 0
114 1
160 0
2
0 35 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut41
3
0 0
114 1
161 0
2
0 36 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut42
3
0 0
114 1
162 0
2
0 37 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut43
3
0 0
114 1
163 0
2
0 38 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut44
3
0 0
114 1
164 0
2
0 39 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut45
3
0 0
114 1
165 0
2
0 40 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut5
3
0 0
114 1
166 0
2
0 41 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut6
3
0 0
114 1
167 0
2
0 42 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut7
3
0 0
114 1
168 0
2
0 43 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut8
3
0 0
114 1
169 0
2
0 44 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut9
3
0 0
114 1
170 0
2
0 45 0 1
0 239 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut1
3
0 0
115 1
126 0
2
0 1 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut10
3
0 0
115 1
127 0
2
0 2 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut11
3
0 0
115 1
128 0
2
0 3 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut12
3
0 0
115 1
129 0
2
0 4 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut13
3
0 0
115 1
130 0
2
0 5 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut14
3
0 0
115 1
131 0
2
0 6 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut15
3
0 0
115 1
132 0
2
0 7 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut16
3
0 0
115 1
133 0
2
0 8 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut17
3
0 0
115 1
134 0
2
0 9 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut18
3
0 0
115 1
135 0
2
0 10 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut19
3
0 0
115 1
136 0
2
0 11 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut2
3
0 0
115 1
137 0
2
0 12 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut20
3
0 0
115 1
138 0
2
0 13 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut21
3
0 0
115 1
139 0
2
0 14 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut22
3
0 0
115 1
140 0
2
0 15 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut23
3
0 0
115 1
141 0
2
0 16 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut24
3
0 0
115 1
142 0
2
0 17 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut25
3
0 0
115 1
143 0
2
0 18 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut26
3
0 0
115 1
144 0
2
0 19 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut27
3
0 0
115 1
145 0
2
0 20 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut28
3
0 0
115 1
146 0
2
0 21 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut29
3
0 0
115 1
147 0
2
0 22 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut3
3
0 0
115 1
148 0
2
0 23 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut30
3
0 0
115 1
149 0
2
0 24 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut31
3
0 0
115 1
150 0
2
0 25 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut32
3
0 0
115 1
151 0
2
0 26 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut33
3
0 0
115 1
152 0
2
0 27 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut34
3
0 0
115 1
153 0
2
0 28 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut35
3
0 0
115 1
154 0
2
0 29 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut36
3
0 0
115 1
155 0
2
0 30 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut37
3
0 0
115 1
156 0
2
0 31 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut38
3
0 0
115 1
157 0
2
0 32 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut39
3
0 0
115 1
158 0
2
0 33 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut4
3
0 0
115 1
159 0
2
0 34 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut40
3
0 0
115 1
160 0
2
0 35 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut41
3
0 0
115 1
161 0
2
0 36 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut42
3
0 0
115 1
162 0
2
0 37 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut43
3
0 0
115 1
163 0
2
0 38 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut44
3
0 0
115 1
164 0
2
0 39 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut45
3
0 0
115 1
165 0
2
0 40 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut5
3
0 0
115 1
166 0
2
0 41 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut6
3
0 0
115 1
167 0
2
0 42 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut7
3
0 0
115 1
168 0
2
0 43 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut8
3
0 0
115 1
169 0
2
0 44 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut9
3
0 0
115 1
170 0
2
0 45 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut1
3
0 0
116 1
126 0
2
0 1 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut10
3
0 0
116 1
127 0
2
0 2 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut11
3
0 0
116 1
128 0
2
0 3 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut12
3
0 0
116 1
129 0
2
0 4 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut13
3
0 0
116 1
130 0
2
0 5 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut14
3
0 0
116 1
131 0
2
0 6 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut15
3
0 0
116 1
132 0
2
0 7 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut16
3
0 0
116 1
133 0
2
0 8 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut17
3
0 0
116 1
134 0
2
0 9 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut18
3
0 0
116 1
135 0
2
0 10 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut19
3
0 0
116 1
136 0
2
0 11 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut2
3
0 0
116 1
137 0
2
0 12 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut20
3
0 0
116 1
138 0
2
0 13 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut21
3
0 0
116 1
139 0
2
0 14 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut22
3
0 0
116 1
140 0
2
0 15 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut23
3
0 0
116 1
141 0
2
0 16 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut24
3
0 0
116 1
142 0
2
0 17 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut25
3
0 0
116 1
143 0
2
0 18 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut26
3
0 0
116 1
144 0
2
0 19 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut27
3
0 0
116 1
145 0
2
0 20 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut28
3
0 0
116 1
146 0
2
0 21 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut29
3
0 0
116 1
147 0
2
0 22 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut3
3
0 0
116 1
148 0
2
0 23 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut30
3
0 0
116 1
149 0
2
0 24 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut31
3
0 0
116 1
150 0
2
0 25 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut32
3
0 0
116 1
151 0
2
0 26 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut33
3
0 0
116 1
152 0
2
0 27 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut34
3
0 0
116 1
153 0
2
0 28 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut35
3
0 0
116 1
154 0
2
0 29 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut36
3
0 0
116 1
155 0
2
0 30 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut37
3
0 0
116 1
156 0
2
0 31 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut38
3
0 0
116 1
157 0
2
0 32 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut39
3
0 0
116 1
158 0
2
0 33 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut4
3
0 0
116 1
159 0
2
0 34 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut40
3
0 0
116 1
160 0
2
0 35 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut41
3
0 0
116 1
161 0
2
0 36 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut42
3
0 0
116 1
162 0
2
0 37 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut43
3
0 0
116 1
163 0
2
0 38 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut44
3
0 0
116 1
164 0
2
0 39 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut45
3
0 0
116 1
165 0
2
0 40 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut5
3
0 0
116 1
166 0
2
0 41 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut6
3
0 0
116 1
167 0
2
0 42 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut7
3
0 0
116 1
168 0
2
0 43 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut8
3
0 0
116 1
169 0
2
0 44 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut9
3
0 0
116 1
170 0
2
0 45 0 1
0 241 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut1
3
0 0
117 1
126 0
2
0 1 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut10
3
0 0
117 1
127 0
2
0 2 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut11
3
0 0
117 1
128 0
2
0 3 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut12
3
0 0
117 1
129 0
2
0 4 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut13
3
0 0
117 1
130 0
2
0 5 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut14
3
0 0
117 1
131 0
2
0 6 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut15
3
0 0
117 1
132 0
2
0 7 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut16
3
0 0
117 1
133 0
2
0 8 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut17
3
0 0
117 1
134 0
2
0 9 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut18
3
0 0
117 1
135 0
2
0 10 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut19
3
0 0
117 1
136 0
2
0 11 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut2
3
0 0
117 1
137 0
2
0 12 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut20
3
0 0
117 1
138 0
2
0 13 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut21
3
0 0
117 1
139 0
2
0 14 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut22
3
0 0
117 1
140 0
2
0 15 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut23
3
0 0
117 1
141 0
2
0 16 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut24
3
0 0
117 1
142 0
2
0 17 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut25
3
0 0
117 1
143 0
2
0 18 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut26
3
0 0
117 1
144 0
2
0 19 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut27
3
0 0
117 1
145 0
2
0 20 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut28
3
0 0
117 1
146 0
2
0 21 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut29
3
0 0
117 1
147 0
2
0 22 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut3
3
0 0
117 1
148 0
2
0 23 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut30
3
0 0
117 1
149 0
2
0 24 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut31
3
0 0
117 1
150 0
2
0 25 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut32
3
0 0
117 1
151 0
2
0 26 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut33
3
0 0
117 1
152 0
2
0 27 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut34
3
0 0
117 1
153 0
2
0 28 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut35
3
0 0
117 1
154 0
2
0 29 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut36
3
0 0
117 1
155 0
2
0 30 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut37
3
0 0
117 1
156 0
2
0 31 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut38
3
0 0
117 1
157 0
2
0 32 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut39
3
0 0
117 1
158 0
2
0 33 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut4
3
0 0
117 1
159 0
2
0 34 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut40
3
0 0
117 1
160 0
2
0 35 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut41
3
0 0
117 1
161 0
2
0 36 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut42
3
0 0
117 1
162 0
2
0 37 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut43
3
0 0
117 1
163 0
2
0 38 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut44
3
0 0
117 1
164 0
2
0 39 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut45
3
0 0
117 1
165 0
2
0 40 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut5
3
0 0
117 1
166 0
2
0 41 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut6
3
0 0
117 1
167 0
2
0 42 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut7
3
0 0
117 1
168 0
2
0 43 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut8
3
0 0
117 1
169 0
2
0 44 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut9
3
0 0
117 1
170 0
2
0 45 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut1
3
0 0
118 1
126 0
2
0 1 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut10
3
0 0
118 1
127 0
2
0 2 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut11
3
0 0
118 1
128 0
2
0 3 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut12
3
0 0
118 1
129 0
2
0 4 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut13
3
0 0
118 1
130 0
2
0 5 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut14
3
0 0
118 1
131 0
2
0 6 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut15
3
0 0
118 1
132 0
2
0 7 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut16
3
0 0
118 1
133 0
2
0 8 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut17
3
0 0
118 1
134 0
2
0 9 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut18
3
0 0
118 1
135 0
2
0 10 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut19
3
0 0
118 1
136 0
2
0 11 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut2
3
0 0
118 1
137 0
2
0 12 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut20
3
0 0
118 1
138 0
2
0 13 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut21
3
0 0
118 1
139 0
2
0 14 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut22
3
0 0
118 1
140 0
2
0 15 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut23
3
0 0
118 1
141 0
2
0 16 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut24
3
0 0
118 1
142 0
2
0 17 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut25
3
0 0
118 1
143 0
2
0 18 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut26
3
0 0
118 1
144 0
2
0 19 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut27
3
0 0
118 1
145 0
2
0 20 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut28
3
0 0
118 1
146 0
2
0 21 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut29
3
0 0
118 1
147 0
2
0 22 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut3
3
0 0
118 1
148 0
2
0 23 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut30
3
0 0
118 1
149 0
2
0 24 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut31
3
0 0
118 1
150 0
2
0 25 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut32
3
0 0
118 1
151 0
2
0 26 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut33
3
0 0
118 1
152 0
2
0 27 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut34
3
0 0
118 1
153 0
2
0 28 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut35
3
0 0
118 1
154 0
2
0 29 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut36
3
0 0
118 1
155 0
2
0 30 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut37
3
0 0
118 1
156 0
2
0 31 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut38
3
0 0
118 1
157 0
2
0 32 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut39
3
0 0
118 1
158 0
2
0 33 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut4
3
0 0
118 1
159 0
2
0 34 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut40
3
0 0
118 1
160 0
2
0 35 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut41
3
0 0
118 1
161 0
2
0 36 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut42
3
0 0
118 1
162 0
2
0 37 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut43
3
0 0
118 1
163 0
2
0 38 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut44
3
0 0
118 1
164 0
2
0 39 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut45
3
0 0
118 1
165 0
2
0 40 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut5
3
0 0
118 1
166 0
2
0 41 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut6
3
0 0
118 1
167 0
2
0 42 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut7
3
0 0
118 1
168 0
2
0 43 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut8
3
0 0
118 1
169 0
2
0 44 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut9
3
0 0
118 1
170 0
2
0 45 0 1
0 243 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut1
3
0 0
119 1
126 0
2
0 1 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut10
3
0 0
119 1
127 0
2
0 2 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut11
3
0 0
119 1
128 0
2
0 3 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut12
3
0 0
119 1
129 0
2
0 4 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut13
3
0 0
119 1
130 0
2
0 5 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut14
3
0 0
119 1
131 0
2
0 6 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut15
3
0 0
119 1
132 0
2
0 7 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut16
3
0 0
119 1
133 0
2
0 8 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut17
3
0 0
119 1
134 0
2
0 9 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut18
3
0 0
119 1
135 0
2
0 10 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut19
3
0 0
119 1
136 0
2
0 11 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut2
3
0 0
119 1
137 0
2
0 12 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut20
3
0 0
119 1
138 0
2
0 13 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut21
3
0 0
119 1
139 0
2
0 14 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut22
3
0 0
119 1
140 0
2
0 15 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut23
3
0 0
119 1
141 0
2
0 16 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut24
3
0 0
119 1
142 0
2
0 17 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut25
3
0 0
119 1
143 0
2
0 18 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut26
3
0 0
119 1
144 0
2
0 19 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut27
3
0 0
119 1
145 0
2
0 20 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut28
3
0 0
119 1
146 0
2
0 21 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut29
3
0 0
119 1
147 0
2
0 22 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut3
3
0 0
119 1
148 0
2
0 23 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut30
3
0 0
119 1
149 0
2
0 24 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut31
3
0 0
119 1
150 0
2
0 25 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut32
3
0 0
119 1
151 0
2
0 26 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut33
3
0 0
119 1
152 0
2
0 27 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut34
3
0 0
119 1
153 0
2
0 28 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut35
3
0 0
119 1
154 0
2
0 29 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut36
3
0 0
119 1
155 0
2
0 30 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut37
3
0 0
119 1
156 0
2
0 31 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut38
3
0 0
119 1
157 0
2
0 32 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut39
3
0 0
119 1
158 0
2
0 33 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut4
3
0 0
119 1
159 0
2
0 34 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut40
3
0 0
119 1
160 0
2
0 35 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut41
3
0 0
119 1
161 0
2
0 36 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut42
3
0 0
119 1
162 0
2
0 37 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut43
3
0 0
119 1
163 0
2
0 38 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut44
3
0 0
119 1
164 0
2
0 39 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut45
3
0 0
119 1
165 0
2
0 40 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut5
3
0 0
119 1
166 0
2
0 41 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut6
3
0 0
119 1
167 0
2
0 42 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut7
3
0 0
119 1
168 0
2
0 43 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut8
3
0 0
119 1
169 0
2
0 44 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut9
3
0 0
119 1
170 0
2
0 45 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut1
3
0 0
120 1
126 0
2
0 1 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut10
3
0 0
120 1
127 0
2
0 2 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut11
3
0 0
120 1
128 0
2
0 3 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut12
3
0 0
120 1
129 0
2
0 4 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut13
3
0 0
120 1
130 0
2
0 5 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut14
3
0 0
120 1
131 0
2
0 6 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut15
3
0 0
120 1
132 0
2
0 7 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut16
3
0 0
120 1
133 0
2
0 8 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut17
3
0 0
120 1
134 0
2
0 9 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut18
3
0 0
120 1
135 0
2
0 10 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut19
3
0 0
120 1
136 0
2
0 11 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut2
3
0 0
120 1
137 0
2
0 12 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut20
3
0 0
120 1
138 0
2
0 13 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut21
3
0 0
120 1
139 0
2
0 14 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut22
3
0 0
120 1
140 0
2
0 15 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut23
3
0 0
120 1
141 0
2
0 16 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut24
3
0 0
120 1
142 0
2
0 17 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut25
3
0 0
120 1
143 0
2
0 18 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut26
3
0 0
120 1
144 0
2
0 19 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut27
3
0 0
120 1
145 0
2
0 20 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut28
3
0 0
120 1
146 0
2
0 21 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut29
3
0 0
120 1
147 0
2
0 22 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut3
3
0 0
120 1
148 0
2
0 23 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut30
3
0 0
120 1
149 0
2
0 24 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut31
3
0 0
120 1
150 0
2
0 25 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut32
3
0 0
120 1
151 0
2
0 26 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut33
3
0 0
120 1
152 0
2
0 27 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut34
3
0 0
120 1
153 0
2
0 28 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut35
3
0 0
120 1
154 0
2
0 29 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut36
3
0 0
120 1
155 0
2
0 30 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut37
3
0 0
120 1
156 0
2
0 31 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut38
3
0 0
120 1
157 0
2
0 32 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut39
3
0 0
120 1
158 0
2
0 33 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut4
3
0 0
120 1
159 0
2
0 34 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut40
3
0 0
120 1
160 0
2
0 35 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut41
3
0 0
120 1
161 0
2
0 36 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut42
3
0 0
120 1
162 0
2
0 37 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut43
3
0 0
120 1
163 0
2
0 38 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut44
3
0 0
120 1
164 0
2
0 39 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut45
3
0 0
120 1
165 0
2
0 40 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut5
3
0 0
120 1
166 0
2
0 41 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut6
3
0 0
120 1
167 0
2
0 42 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut7
3
0 0
120 1
168 0
2
0 43 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut8
3
0 0
120 1
169 0
2
0 44 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut9
3
0 0
120 1
170 0
2
0 45 0 1
0 245 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut1
3
0 0
121 1
126 0
2
0 1 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut10
3
0 0
121 1
127 0
2
0 2 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut11
3
0 0
121 1
128 0
2
0 3 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut12
3
0 0
121 1
129 0
2
0 4 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut13
3
0 0
121 1
130 0
2
0 5 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut14
3
0 0
121 1
131 0
2
0 6 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut15
3
0 0
121 1
132 0
2
0 7 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut16
3
0 0
121 1
133 0
2
0 8 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut17
3
0 0
121 1
134 0
2
0 9 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut18
3
0 0
121 1
135 0
2
0 10 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut19
3
0 0
121 1
136 0
2
0 11 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut2
3
0 0
121 1
137 0
2
0 12 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut20
3
0 0
121 1
138 0
2
0 13 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut21
3
0 0
121 1
139 0
2
0 14 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut22
3
0 0
121 1
140 0
2
0 15 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut23
3
0 0
121 1
141 0
2
0 16 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut24
3
0 0
121 1
142 0
2
0 17 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut25
3
0 0
121 1
143 0
2
0 18 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut26
3
0 0
121 1
144 0
2
0 19 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut27
3
0 0
121 1
145 0
2
0 20 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut28
3
0 0
121 1
146 0
2
0 21 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut29
3
0 0
121 1
147 0
2
0 22 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut3
3
0 0
121 1
148 0
2
0 23 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut30
3
0 0
121 1
149 0
2
0 24 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut31
3
0 0
121 1
150 0
2
0 25 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut32
3
0 0
121 1
151 0
2
0 26 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut33
3
0 0
121 1
152 0
2
0 27 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut34
3
0 0
121 1
153 0
2
0 28 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut35
3
0 0
121 1
154 0
2
0 29 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut36
3
0 0
121 1
155 0
2
0 30 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut37
3
0 0
121 1
156 0
2
0 31 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut38
3
0 0
121 1
157 0
2
0 32 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut39
3
0 0
121 1
158 0
2
0 33 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut4
3
0 0
121 1
159 0
2
0 34 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut40
3
0 0
121 1
160 0
2
0 35 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut41
3
0 0
121 1
161 0
2
0 36 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut42
3
0 0
121 1
162 0
2
0 37 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut43
3
0 0
121 1
163 0
2
0 38 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut44
3
0 0
121 1
164 0
2
0 39 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut45
3
0 0
121 1
165 0
2
0 40 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut5
3
0 0
121 1
166 0
2
0 41 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut6
3
0 0
121 1
167 0
2
0 42 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut7
3
0 0
121 1
168 0
2
0 43 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut8
3
0 0
121 1
169 0
2
0 44 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut9
3
0 0
121 1
170 0
2
0 45 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut1
3
0 0
122 1
126 0
2
0 1 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut10
3
0 0
122 1
127 0
2
0 2 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut11
3
0 0
122 1
128 0
2
0 3 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut12
3
0 0
122 1
129 0
2
0 4 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut13
3
0 0
122 1
130 0
2
0 5 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut14
3
0 0
122 1
131 0
2
0 6 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut15
3
0 0
122 1
132 0
2
0 7 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut16
3
0 0
122 1
133 0
2
0 8 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut17
3
0 0
122 1
134 0
2
0 9 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut18
3
0 0
122 1
135 0
2
0 10 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut19
3
0 0
122 1
136 0
2
0 11 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut2
3
0 0
122 1
137 0
2
0 12 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut20
3
0 0
122 1
138 0
2
0 13 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut21
3
0 0
122 1
139 0
2
0 14 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut22
3
0 0
122 1
140 0
2
0 15 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut23
3
0 0
122 1
141 0
2
0 16 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut24
3
0 0
122 1
142 0
2
0 17 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut25
3
0 0
122 1
143 0
2
0 18 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut26
3
0 0
122 1
144 0
2
0 19 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut27
3
0 0
122 1
145 0
2
0 20 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut28
3
0 0
122 1
146 0
2
0 21 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut29
3
0 0
122 1
147 0
2
0 22 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut3
3
0 0
122 1
148 0
2
0 23 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut30
3
0 0
122 1
149 0
2
0 24 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut31
3
0 0
122 1
150 0
2
0 25 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut32
3
0 0
122 1
151 0
2
0 26 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut33
3
0 0
122 1
152 0
2
0 27 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut34
3
0 0
122 1
153 0
2
0 28 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut35
3
0 0
122 1
154 0
2
0 29 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut36
3
0 0
122 1
155 0
2
0 30 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut37
3
0 0
122 1
156 0
2
0 31 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut38
3
0 0
122 1
157 0
2
0 32 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut39
3
0 0
122 1
158 0
2
0 33 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut4
3
0 0
122 1
159 0
2
0 34 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut40
3
0 0
122 1
160 0
2
0 35 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut41
3
0 0
122 1
161 0
2
0 36 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut42
3
0 0
122 1
162 0
2
0 37 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut43
3
0 0
122 1
163 0
2
0 38 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut44
3
0 0
122 1
164 0
2
0 39 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut45
3
0 0
122 1
165 0
2
0 40 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut5
3
0 0
122 1
166 0
2
0 41 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut6
3
0 0
122 1
167 0
2
0 42 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut7
3
0 0
122 1
168 0
2
0 43 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut8
3
0 0
122 1
169 0
2
0 44 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut9
3
0 0
122 1
170 0
2
0 45 0 1
0 247 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
123 1
126 0
2
0 1 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
123 1
127 0
2
0 2 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
123 1
128 0
2
0 3 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
123 1
129 0
2
0 4 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
123 1
130 0
2
0 5 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
123 1
131 0
2
0 6 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
123 1
132 0
2
0 7 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
123 1
133 0
2
0 8 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
123 1
134 0
2
0 9 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
123 1
135 0
2
0 10 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
123 1
136 0
2
0 11 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
123 1
137 0
2
0 12 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
123 1
138 0
2
0 13 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
123 1
139 0
2
0 14 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
123 1
140 0
2
0 15 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
123 1
141 0
2
0 16 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
123 1
142 0
2
0 17 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
123 1
143 0
2
0 18 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
123 1
144 0
2
0 19 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
123 1
145 0
2
0 20 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
123 1
146 0
2
0 21 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
123 1
147 0
2
0 22 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
123 1
148 0
2
0 23 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
123 1
149 0
2
0 24 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut31
3
0 0
123 1
150 0
2
0 25 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut32
3
0 0
123 1
151 0
2
0 26 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut33
3
0 0
123 1
152 0
2
0 27 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut34
3
0 0
123 1
153 0
2
0 28 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut35
3
0 0
123 1
154 0
2
0 29 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut36
3
0 0
123 1
155 0
2
0 30 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut37
3
0 0
123 1
156 0
2
0 31 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut38
3
0 0
123 1
157 0
2
0 32 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut39
3
0 0
123 1
158 0
2
0 33 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
123 1
159 0
2
0 34 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut40
3
0 0
123 1
160 0
2
0 35 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut41
3
0 0
123 1
161 0
2
0 36 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut42
3
0 0
123 1
162 0
2
0 37 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut43
3
0 0
123 1
163 0
2
0 38 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut44
3
0 0
123 1
164 0
2
0 39 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut45
3
0 0
123 1
165 0
2
0 40 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
123 1
166 0
2
0 41 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
123 1
167 0
2
0 42 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
123 1
168 0
2
0 43 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
123 1
169 0
2
0 44 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
123 1
170 0
2
0 45 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut1
3
0 0
124 1
126 0
2
0 1 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut10
3
0 0
124 1
127 0
2
0 2 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut11
3
0 0
124 1
128 0
2
0 3 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut12
3
0 0
124 1
129 0
2
0 4 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut13
3
0 0
124 1
130 0
2
0 5 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut14
3
0 0
124 1
131 0
2
0 6 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut15
3
0 0
124 1
132 0
2
0 7 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut16
3
0 0
124 1
133 0
2
0 8 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut17
3
0 0
124 1
134 0
2
0 9 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut18
3
0 0
124 1
135 0
2
0 10 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut19
3
0 0
124 1
136 0
2
0 11 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut2
3
0 0
124 1
137 0
2
0 12 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut20
3
0 0
124 1
138 0
2
0 13 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut21
3
0 0
124 1
139 0
2
0 14 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut22
3
0 0
124 1
140 0
2
0 15 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut23
3
0 0
124 1
141 0
2
0 16 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut24
3
0 0
124 1
142 0
2
0 17 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut25
3
0 0
124 1
143 0
2
0 18 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut26
3
0 0
124 1
144 0
2
0 19 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut27
3
0 0
124 1
145 0
2
0 20 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut28
3
0 0
124 1
146 0
2
0 21 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut29
3
0 0
124 1
147 0
2
0 22 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut3
3
0 0
124 1
148 0
2
0 23 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut30
3
0 0
124 1
149 0
2
0 24 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut31
3
0 0
124 1
150 0
2
0 25 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut32
3
0 0
124 1
151 0
2
0 26 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut33
3
0 0
124 1
152 0
2
0 27 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut34
3
0 0
124 1
153 0
2
0 28 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut35
3
0 0
124 1
154 0
2
0 29 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut36
3
0 0
124 1
155 0
2
0 30 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut37
3
0 0
124 1
156 0
2
0 31 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut38
3
0 0
124 1
157 0
2
0 32 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut39
3
0 0
124 1
158 0
2
0 33 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut4
3
0 0
124 1
159 0
2
0 34 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut40
3
0 0
124 1
160 0
2
0 35 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut41
3
0 0
124 1
161 0
2
0 36 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut42
3
0 0
124 1
162 0
2
0 37 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut43
3
0 0
124 1
163 0
2
0 38 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut44
3
0 0
124 1
164 0
2
0 39 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut45
3
0 0
124 1
165 0
2
0 40 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut5
3
0 0
124 1
166 0
2
0 41 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut6
3
0 0
124 1
167 0
2
0 42 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut7
3
0 0
124 1
168 0
2
0 43 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut8
3
0 0
124 1
169 0
2
0 44 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut9
3
0 0
124 1
170 0
2
0 45 0 1
0 249 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
125 1
126 0
2
0 1 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
125 1
127 0
2
0 2 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
125 1
128 0
2
0 3 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
125 1
129 0
2
0 4 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
125 1
130 0
2
0 5 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
125 1
131 0
2
0 6 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
125 1
132 0
2
0 7 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
125 1
133 0
2
0 8 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
125 1
134 0
2
0 9 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
125 1
135 0
2
0 10 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
125 1
136 0
2
0 11 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
125 1
137 0
2
0 12 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
125 1
138 0
2
0 13 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
125 1
139 0
2
0 14 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
125 1
140 0
2
0 15 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
125 1
141 0
2
0 16 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
125 1
142 0
2
0 17 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
125 1
143 0
2
0 18 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
125 1
144 0
2
0 19 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
125 1
145 0
2
0 20 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
125 1
146 0
2
0 21 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
125 1
147 0
2
0 22 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
125 1
148 0
2
0 23 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
125 1
149 0
2
0 24 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut31
3
0 0
125 1
150 0
2
0 25 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut32
3
0 0
125 1
151 0
2
0 26 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut33
3
0 0
125 1
152 0
2
0 27 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut34
3
0 0
125 1
153 0
2
0 28 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut35
3
0 0
125 1
154 0
2
0 29 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut36
3
0 0
125 1
155 0
2
0 30 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut37
3
0 0
125 1
156 0
2
0 31 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut38
3
0 0
125 1
157 0
2
0 32 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut39
3
0 0
125 1
158 0
2
0 33 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
125 1
159 0
2
0 34 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut40
3
0 0
125 1
160 0
2
0 35 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut41
3
0 0
125 1
161 0
2
0 36 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut42
3
0 0
125 1
162 0
2
0 37 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut43
3
0 0
125 1
163 0
2
0 38 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut44
3
0 0
125 1
164 0
2
0 39 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut45
3
0 0
125 1
165 0
2
0 40 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
125 1
166 0
2
0 41 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
125 1
167 0
2
0 42 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
125 1
168 0
2
0 43 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
125 1
169 0
2
0 44 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
125 1
170 0
2
0 45 0 1
0 250 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
251 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
252 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
253 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
254 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
255 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
256 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
257 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
258 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
259 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
260 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
261 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
262 0
1
0 0 12 23
1
end_operator
begin_operator
walk location20 location21 bob
1
263 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
264 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
265 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
266 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
267 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
268 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
269 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
270 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 location29 bob
1
271 0
1
0 0 21 22
1
end_operator
begin_operator
walk location29 location30 bob
1
272 0
1
0 0 22 24
1
end_operator
begin_operator
walk location3 location4 bob
1
273 0
1
0 0 23 34
1
end_operator
begin_operator
walk location30 location31 bob
1
274 0
1
0 0 24 25
1
end_operator
begin_operator
walk location31 location32 bob
1
275 0
1
0 0 25 26
1
end_operator
begin_operator
walk location32 location33 bob
1
276 0
1
0 0 26 27
1
end_operator
begin_operator
walk location33 location34 bob
1
277 0
1
0 0 27 28
1
end_operator
begin_operator
walk location34 location35 bob
1
278 0
1
0 0 28 29
1
end_operator
begin_operator
walk location35 location36 bob
1
279 0
1
0 0 29 30
1
end_operator
begin_operator
walk location36 location37 bob
1
280 0
1
0 0 30 31
1
end_operator
begin_operator
walk location37 location38 bob
1
281 0
1
0 0 31 32
1
end_operator
begin_operator
walk location38 location39 bob
1
282 0
1
0 0 32 33
1
end_operator
begin_operator
walk location39 location40 bob
1
283 0
1
0 0 33 35
1
end_operator
begin_operator
walk location4 location5 bob
1
284 0
1
0 0 34 36
1
end_operator
begin_operator
walk location40 gate bob
1
285 0
1
0 0 35 0
1
end_operator
begin_operator
walk location5 location6 bob
1
286 0
1
0 0 36 37
1
end_operator
begin_operator
walk location6 location7 bob
1
287 0
1
0 0 37 38
1
end_operator
begin_operator
walk location7 location8 bob
1
288 0
1
0 0 38 39
1
end_operator
begin_operator
walk location8 location9 bob
1
289 0
1
0 0 39 40
1
end_operator
begin_operator
walk location9 location10 bob
1
290 0
1
0 0 40 2
1
end_operator
begin_operator
walk shed location1 bob
1
291 0
1
0 0 41 1
1
end_operator
0
