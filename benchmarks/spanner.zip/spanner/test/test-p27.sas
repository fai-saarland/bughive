begin_version
3
end_version
begin_metric
1
end_metric
40
begin_variable
var0
-1
12
at bob gate
at bob location1
at bob location10
at bob location2
at bob location3
at bob location4
at bob location5
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location4
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner2 location5
carrying bob spanner2
end_variable
begin_variable
var3
-1
2
at spanner3 location8
carrying bob spanner3
end_variable
begin_variable
var4
-1
2
at spanner4 location2
carrying bob spanner4
end_variable
begin_variable
var5
-1
2
at spanner5 location2
carrying bob spanner5
end_variable
begin_variable
var6
-1
2
at spanner6 location4
carrying bob spanner6
end_variable
begin_variable
var7
-1
2
at spanner7 location1
carrying bob spanner7
end_variable
begin_variable
var8
-1
2
at spanner8 location7
carrying bob spanner8
end_variable
begin_variable
var9
-1
2
at spanner9 location7
carrying bob spanner9
end_variable
begin_variable
var10
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var11
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var12
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var13
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var14
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var15
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var16
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var17
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var18
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var19
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var20
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var21
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var22
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var23
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var24
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var25
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var26
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var27
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var28
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var29
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var30
-1
2
link location10 gate
none-of-those
end_variable
begin_variable
var31
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var32
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var33
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var34
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var35
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var36
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var37
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var38
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var39
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
11
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
5
10 1
11 1
12 1
13 1
14 1
end_goal
65
begin_operator
pickup_spanner location1 spanner7 bob
1
0 1
1
0 7 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner4 bob
1
0 3
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner5 bob
1
0 3
1
0 5 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner1 bob
1
0 5
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner6 bob
1
0 5
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner2 bob
1
0 6
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner8 bob
1
0 8
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner9 bob
1
0 8
1
0 9 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner3 bob
1
0 9
1
0 3 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
15 0
2
0 10 0 1
0 20 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
16 0
2
0 11 0 1
0 20 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
1 1
17 0
2
0 12 0 1
0 20 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
1 1
18 0
2
0 13 0 1
0 20 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
1 1
19 0
2
0 14 0 1
0 20 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
2 1
15 0
2
0 10 0 1
0 21 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
2 1
16 0
2
0 11 0 1
0 21 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
2 1
17 0
2
0 12 0 1
0 21 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
2 1
18 0
2
0 13 0 1
0 21 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
2 1
19 0
2
0 14 0 1
0 21 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
3 1
15 0
2
0 10 0 1
0 22 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
3 1
16 0
2
0 11 0 1
0 22 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
3 1
17 0
2
0 12 0 1
0 22 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
3 1
18 0
2
0 13 0 1
0 22 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
3 1
19 0
2
0 14 0 1
0 22 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
4 1
15 0
2
0 10 0 1
0 23 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
4 1
16 0
2
0 11 0 1
0 23 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
4 1
17 0
2
0 12 0 1
0 23 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
4 1
18 0
2
0 13 0 1
0 23 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
4 1
19 0
2
0 14 0 1
0 23 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
5 1
15 0
2
0 10 0 1
0 24 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
5 1
16 0
2
0 11 0 1
0 24 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
5 1
17 0
2
0 12 0 1
0 24 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
5 1
18 0
2
0 13 0 1
0 24 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
5 1
19 0
2
0 14 0 1
0 24 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
6 1
15 0
2
0 10 0 1
0 25 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
6 1
16 0
2
0 11 0 1
0 25 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
6 1
17 0
2
0 12 0 1
0 25 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
6 1
18 0
2
0 13 0 1
0 25 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
6 1
19 0
2
0 14 0 1
0 25 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
7 1
15 0
2
0 10 0 1
0 26 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
7 1
16 0
2
0 11 0 1
0 26 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
7 1
17 0
2
0 12 0 1
0 26 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
7 1
18 0
2
0 13 0 1
0 26 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
7 1
19 0
2
0 14 0 1
0 26 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
8 1
15 0
2
0 10 0 1
0 27 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
8 1
16 0
2
0 11 0 1
0 27 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
8 1
17 0
2
0 12 0 1
0 27 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
8 1
18 0
2
0 13 0 1
0 27 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
8 1
19 0
2
0 14 0 1
0 27 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
9 1
15 0
2
0 10 0 1
0 28 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
9 1
16 0
2
0 11 0 1
0 28 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
9 1
17 0
2
0 12 0 1
0 28 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
9 1
18 0
2
0 13 0 1
0 28 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
9 1
19 0
2
0 14 0 1
0 28 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
29 0
1
0 0 1 3
1
end_operator
begin_operator
walk location10 gate bob
1
30 0
1
0 0 2 0
1
end_operator
begin_operator
walk location2 location3 bob
1
31 0
1
0 0 3 4
1
end_operator
begin_operator
walk location3 location4 bob
1
32 0
1
0 0 4 5
1
end_operator
begin_operator
walk location4 location5 bob
1
33 0
1
0 0 5 6
1
end_operator
begin_operator
walk location5 location6 bob
1
34 0
1
0 0 6 7
1
end_operator
begin_operator
walk location6 location7 bob
1
35 0
1
0 0 7 8
1
end_operator
begin_operator
walk location7 location8 bob
1
36 0
1
0 0 8 9
1
end_operator
begin_operator
walk location8 location9 bob
1
37 0
1
0 0 9 10
1
end_operator
begin_operator
walk location9 location10 bob
1
38 0
1
0 0 10 2
1
end_operator
begin_operator
walk shed location1 bob
1
39 0
1
0 0 11 1
1
end_operator
0
