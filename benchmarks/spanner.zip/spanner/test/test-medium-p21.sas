begin_version
3
end_version
begin_metric
1
end_metric
255
begin_variable
var0
-1
37
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location29
at bob location3
at bob location30
at bob location31
at bob location32
at bob location33
at bob location34
at bob location35
at bob location4
at bob location5
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var2
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var3
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var4
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var5
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var6
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var7
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var8
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var9
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var10
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var11
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var12
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var13
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var14
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var15
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var16
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var17
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var18
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var19
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var20
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var21
-1
2
loose nut31
tightened nut31
end_variable
begin_variable
var22
-1
2
loose nut32
tightened nut32
end_variable
begin_variable
var23
-1
2
loose nut33
tightened nut33
end_variable
begin_variable
var24
-1
2
loose nut34
tightened nut34
end_variable
begin_variable
var25
-1
2
loose nut35
tightened nut35
end_variable
begin_variable
var26
-1
2
loose nut36
tightened nut36
end_variable
begin_variable
var27
-1
2
loose nut37
tightened nut37
end_variable
begin_variable
var28
-1
2
loose nut38
tightened nut38
end_variable
begin_variable
var29
-1
2
loose nut39
tightened nut39
end_variable
begin_variable
var30
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var31
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var32
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var33
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var34
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var35
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var36
-1
2
at spanner1 location2
carrying bob spanner1
end_variable
begin_variable
var37
-1
2
at spanner10 location3
carrying bob spanner10
end_variable
begin_variable
var38
-1
2
at spanner11 location33
carrying bob spanner11
end_variable
begin_variable
var39
-1
2
at spanner12 location33
carrying bob spanner12
end_variable
begin_variable
var40
-1
2
at spanner13 location4
carrying bob spanner13
end_variable
begin_variable
var41
-1
2
at spanner14 location17
carrying bob spanner14
end_variable
begin_variable
var42
-1
2
at spanner15 location24
carrying bob spanner15
end_variable
begin_variable
var43
-1
2
at spanner16 location18
carrying bob spanner16
end_variable
begin_variable
var44
-1
2
at spanner17 location31
carrying bob spanner17
end_variable
begin_variable
var45
-1
2
at spanner18 location4
carrying bob spanner18
end_variable
begin_variable
var46
-1
2
at spanner19 location25
carrying bob spanner19
end_variable
begin_variable
var47
-1
2
at spanner2 location8
carrying bob spanner2
end_variable
begin_variable
var48
-1
2
at spanner20 location6
carrying bob spanner20
end_variable
begin_variable
var49
-1
2
at spanner21 location7
carrying bob spanner21
end_variable
begin_variable
var50
-1
2
at spanner22 location5
carrying bob spanner22
end_variable
begin_variable
var51
-1
2
at spanner23 location34
carrying bob spanner23
end_variable
begin_variable
var52
-1
2
at spanner24 location18
carrying bob spanner24
end_variable
begin_variable
var53
-1
2
at spanner25 location20
carrying bob spanner25
end_variable
begin_variable
var54
-1
2
at spanner26 location1
carrying bob spanner26
end_variable
begin_variable
var55
-1
2
at spanner27 location29
carrying bob spanner27
end_variable
begin_variable
var56
-1
2
at spanner28 location34
carrying bob spanner28
end_variable
begin_variable
var57
-1
2
at spanner29 location24
carrying bob spanner29
end_variable
begin_variable
var58
-1
2
at spanner3 location6
carrying bob spanner3
end_variable
begin_variable
var59
-1
2
at spanner30 location26
carrying bob spanner30
end_variable
begin_variable
var60
-1
2
at spanner31 location32
carrying bob spanner31
end_variable
begin_variable
var61
-1
2
at spanner32 location13
carrying bob spanner32
end_variable
begin_variable
var62
-1
2
at spanner33 location27
carrying bob spanner33
end_variable
begin_variable
var63
-1
2
at spanner34 location30
carrying bob spanner34
end_variable
begin_variable
var64
-1
2
at spanner35 location3
carrying bob spanner35
end_variable
begin_variable
var65
-1
2
at spanner36 location7
carrying bob spanner36
end_variable
begin_variable
var66
-1
2
at spanner37 location34
carrying bob spanner37
end_variable
begin_variable
var67
-1
2
at spanner38 location10
carrying bob spanner38
end_variable
begin_variable
var68
-1
2
at spanner39 location10
carrying bob spanner39
end_variable
begin_variable
var69
-1
2
at spanner4 location35
carrying bob spanner4
end_variable
begin_variable
var70
-1
2
at spanner40 location19
carrying bob spanner40
end_variable
begin_variable
var71
-1
2
at spanner41 location19
carrying bob spanner41
end_variable
begin_variable
var72
-1
2
at spanner42 location35
carrying bob spanner42
end_variable
begin_variable
var73
-1
2
at spanner43 location1
carrying bob spanner43
end_variable
begin_variable
var74
-1
2
at spanner44 location10
carrying bob spanner44
end_variable
begin_variable
var75
-1
2
at spanner45 location25
carrying bob spanner45
end_variable
begin_variable
var76
-1
2
at spanner46 location30
carrying bob spanner46
end_variable
begin_variable
var77
-1
2
at spanner47 location29
carrying bob spanner47
end_variable
begin_variable
var78
-1
2
at spanner48 location21
carrying bob spanner48
end_variable
begin_variable
var79
-1
2
at spanner49 location25
carrying bob spanner49
end_variable
begin_variable
var80
-1
2
at spanner5 location32
carrying bob spanner5
end_variable
begin_variable
var81
-1
2
at spanner50 location7
carrying bob spanner50
end_variable
begin_variable
var82
-1
2
at spanner51 location9
carrying bob spanner51
end_variable
begin_variable
var83
-1
2
at spanner52 location11
carrying bob spanner52
end_variable
begin_variable
var84
-1
2
at spanner53 location3
carrying bob spanner53
end_variable
begin_variable
var85
-1
2
at spanner54 location29
carrying bob spanner54
end_variable
begin_variable
var86
-1
2
at spanner55 location4
carrying bob spanner55
end_variable
begin_variable
var87
-1
2
at spanner56 location10
carrying bob spanner56
end_variable
begin_variable
var88
-1
2
at spanner57 location7
carrying bob spanner57
end_variable
begin_variable
var89
-1
2
at spanner58 location8
carrying bob spanner58
end_variable
begin_variable
var90
-1
2
at spanner59 location31
carrying bob spanner59
end_variable
begin_variable
var91
-1
2
at spanner6 location15
carrying bob spanner6
end_variable
begin_variable
var92
-1
2
at spanner60 location35
carrying bob spanner60
end_variable
begin_variable
var93
-1
2
at spanner61 location16
carrying bob spanner61
end_variable
begin_variable
var94
-1
2
at spanner62 location31
carrying bob spanner62
end_variable
begin_variable
var95
-1
2
at spanner63 location3
carrying bob spanner63
end_variable
begin_variable
var96
-1
2
at spanner64 location8
carrying bob spanner64
end_variable
begin_variable
var97
-1
2
at spanner65 location3
carrying bob spanner65
end_variable
begin_variable
var98
-1
2
at spanner66 location35
carrying bob spanner66
end_variable
begin_variable
var99
-1
2
at spanner67 location6
carrying bob spanner67
end_variable
begin_variable
var100
-1
2
at spanner68 location2
carrying bob spanner68
end_variable
begin_variable
var101
-1
2
at spanner69 location31
carrying bob spanner69
end_variable
begin_variable
var102
-1
2
at spanner7 location1
carrying bob spanner7
end_variable
begin_variable
var103
-1
2
at spanner70 location27
carrying bob spanner70
end_variable
begin_variable
var104
-1
2
at spanner8 location27
carrying bob spanner8
end_variable
begin_variable
var105
-1
2
at spanner9 location34
carrying bob spanner9
end_variable
begin_variable
var106
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var107
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var108
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var109
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var110
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var111
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var112
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var113
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var114
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var115
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var116
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var117
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var118
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var119
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var120
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var121
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var122
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var123
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var124
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var125
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var126
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var127
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var128
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var129
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var130
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var131
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var132
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var133
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var134
-1
2
at nut31 gate
none-of-those
end_variable
begin_variable
var135
-1
2
at nut32 gate
none-of-those
end_variable
begin_variable
var136
-1
2
at nut33 gate
none-of-those
end_variable
begin_variable
var137
-1
2
at nut34 gate
none-of-those
end_variable
begin_variable
var138
-1
2
at nut35 gate
none-of-those
end_variable
begin_variable
var139
-1
2
at nut36 gate
none-of-those
end_variable
begin_variable
var140
-1
2
at nut37 gate
none-of-those
end_variable
begin_variable
var141
-1
2
at nut38 gate
none-of-those
end_variable
begin_variable
var142
-1
2
at nut39 gate
none-of-those
end_variable
begin_variable
var143
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var144
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var145
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var146
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var147
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var148
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var149
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var150
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var151
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var152
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var153
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var154
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var155
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var156
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var157
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var158
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var159
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var160
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var161
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var162
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var163
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var164
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var165
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var166
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var167
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var168
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var169
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var170
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var171
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var172
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var173
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var174
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var175
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var176
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var177
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var178
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var179
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var180
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var181
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var182
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var183
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var184
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var185
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var186
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var187
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var188
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var189
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var190
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var191
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var192
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var193
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var194
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var195
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var196
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var197
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var198
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var199
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var200
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var201
-1
2
usable spanner57
none-of-those
end_variable
begin_variable
var202
-1
2
usable spanner58
none-of-those
end_variable
begin_variable
var203
-1
2
usable spanner59
none-of-those
end_variable
begin_variable
var204
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var205
-1
2
usable spanner60
none-of-those
end_variable
begin_variable
var206
-1
2
usable spanner61
none-of-those
end_variable
begin_variable
var207
-1
2
usable spanner62
none-of-those
end_variable
begin_variable
var208
-1
2
usable spanner63
none-of-those
end_variable
begin_variable
var209
-1
2
usable spanner64
none-of-those
end_variable
begin_variable
var210
-1
2
usable spanner65
none-of-those
end_variable
begin_variable
var211
-1
2
usable spanner66
none-of-those
end_variable
begin_variable
var212
-1
2
usable spanner67
none-of-those
end_variable
begin_variable
var213
-1
2
usable spanner68
none-of-those
end_variable
begin_variable
var214
-1
2
usable spanner69
none-of-those
end_variable
begin_variable
var215
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var216
-1
2
usable spanner70
none-of-those
end_variable
begin_variable
var217
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var218
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var219
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var220
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var221
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var222
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var223
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var224
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var225
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var226
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var227
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var228
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var229
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var230
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var231
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var232
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var233
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var234
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var235
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var236
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var237
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var238
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var239
-1
2
link location28 location29
none-of-those
end_variable
begin_variable
var240
-1
2
link location29 location30
none-of-those
end_variable
begin_variable
var241
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var242
-1
2
link location30 location31
none-of-those
end_variable
begin_variable
var243
-1
2
link location31 location32
none-of-those
end_variable
begin_variable
var244
-1
2
link location32 location33
none-of-those
end_variable
begin_variable
var245
-1
2
link location33 location34
none-of-those
end_variable
begin_variable
var246
-1
2
link location34 location35
none-of-those
end_variable
begin_variable
var247
-1
2
link location35 gate
none-of-those
end_variable
begin_variable
var248
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var249
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var250
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var251
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var252
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var253
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var254
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
36
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
39
1 1
2 1
3 1
4 1
5 1
6 1
7 1
8 1
9 1
10 1
11 1
12 1
13 1
14 1
15 1
16 1
17 1
18 1
19 1
20 1
21 1
22 1
23 1
24 1
25 1
26 1
27 1
28 1
29 1
30 1
31 1
32 1
33 1
34 1
35 1
106 1
107 1
108 1
109 1
end_goal
2836
begin_operator
pickup_spanner location1 spanner26 bob
1
0 1
1
0 54 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner43 bob
1
0 1
1
0 73 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner7 bob
1
0 1
1
0 102 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner38 bob
1
0 2
1
0 67 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner39 bob
1
0 2
1
0 68 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner44 bob
1
0 2
1
0 74 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner56 bob
1
0 2
1
0 87 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner52 bob
1
0 3
1
0 83 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner32 bob
1
0 5
1
0 61 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner6 bob
1
0 7
1
0 91 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner61 bob
1
0 8
1
0 93 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner14 bob
1
0 9
1
0 41 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner16 bob
1
0 10
1
0 43 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner24 bob
1
0 10
1
0 52 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner40 bob
1
0 11
1
0 70 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner41 bob
1
0 11
1
0 71 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner1 bob
1
0 12
1
0 36 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner68 bob
1
0 12
1
0 100 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner25 bob
1
0 13
1
0 53 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner48 bob
1
0 14
1
0 78 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner15 bob
1
0 17
1
0 42 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner29 bob
1
0 17
1
0 57 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner19 bob
1
0 18
1
0 46 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner45 bob
1
0 18
1
0 75 0 1
1
end_operator
begin_operator
pickup_spanner location25 spanner49 bob
1
0 18
1
0 79 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner30 bob
1
0 19
1
0 59 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner33 bob
1
0 20
1
0 62 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner70 bob
1
0 20
1
0 103 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner8 bob
1
0 20
1
0 104 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner27 bob
1
0 22
1
0 55 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner47 bob
1
0 22
1
0 77 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner54 bob
1
0 22
1
0 85 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner10 bob
1
0 23
1
0 37 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner35 bob
1
0 23
1
0 64 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner53 bob
1
0 23
1
0 84 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner63 bob
1
0 23
1
0 95 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner65 bob
1
0 23
1
0 97 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner34 bob
1
0 24
1
0 63 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner46 bob
1
0 24
1
0 76 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner17 bob
1
0 25
1
0 44 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner59 bob
1
0 25
1
0 90 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner62 bob
1
0 25
1
0 94 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner69 bob
1
0 25
1
0 101 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner31 bob
1
0 26
1
0 60 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner5 bob
1
0 26
1
0 80 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner11 bob
1
0 27
1
0 38 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner12 bob
1
0 27
1
0 39 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner23 bob
1
0 28
1
0 51 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner28 bob
1
0 28
1
0 56 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner37 bob
1
0 28
1
0 66 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner9 bob
1
0 28
1
0 105 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner4 bob
1
0 29
1
0 69 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner42 bob
1
0 29
1
0 72 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner60 bob
1
0 29
1
0 92 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner66 bob
1
0 29
1
0 98 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner13 bob
1
0 30
1
0 40 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner18 bob
1
0 30
1
0 45 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner55 bob
1
0 30
1
0 86 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner22 bob
1
0 31
1
0 50 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner20 bob
1
0 32
1
0 48 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner3 bob
1
0 32
1
0 58 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner67 bob
1
0 32
1
0 99 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner21 bob
1
0 33
1
0 49 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner36 bob
1
0 33
1
0 65 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner50 bob
1
0 33
1
0 81 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner57 bob
1
0 33
1
0 88 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner2 bob
1
0 34
1
0 47 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner58 bob
1
0 34
1
0 89 0 1
1
end_operator
begin_operator
pickup_spanner location8 spanner64 bob
1
0 34
1
0 96 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner51 bob
1
0 35
1
0 82 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
36 1
110 0
2
0 106 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
36 1
111 0
2
0 107 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
36 1
112 0
2
0 108 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
36 1
113 0
2
0 109 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
36 1
114 0
2
0 1 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
36 1
115 0
2
0 2 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
36 1
116 0
2
0 3 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
36 1
117 0
2
0 4 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
36 1
118 0
2
0 5 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
36 1
119 0
2
0 6 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
36 1
120 0
2
0 7 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
36 1
121 0
2
0 8 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
36 1
122 0
2
0 9 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
36 1
123 0
2
0 10 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
36 1
124 0
2
0 11 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
36 1
125 0
2
0 12 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
36 1
126 0
2
0 13 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
36 1
127 0
2
0 14 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
36 1
128 0
2
0 15 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
36 1
129 0
2
0 16 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
36 1
130 0
2
0 17 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
36 1
131 0
2
0 18 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
36 1
132 0
2
0 19 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
36 1
133 0
2
0 20 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut31
3
0 0
36 1
134 0
2
0 21 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut32
3
0 0
36 1
135 0
2
0 22 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut33
3
0 0
36 1
136 0
2
0 23 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut34
3
0 0
36 1
137 0
2
0 24 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut35
3
0 0
36 1
138 0
2
0 25 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut36
3
0 0
36 1
139 0
2
0 26 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut37
3
0 0
36 1
140 0
2
0 27 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut38
3
0 0
36 1
141 0
2
0 28 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut39
3
0 0
36 1
142 0
2
0 29 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
36 1
143 0
2
0 30 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
36 1
144 0
2
0 31 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
36 1
145 0
2
0 32 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
36 1
146 0
2
0 33 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
36 1
147 0
2
0 34 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
36 1
149 0
2
0 35 0 1
0 148 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
37 1
110 0
2
0 106 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
37 1
111 0
2
0 107 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
37 1
112 0
2
0 108 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
37 1
113 0
2
0 109 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
37 1
114 0
2
0 1 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
37 1
115 0
2
0 2 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
37 1
116 0
2
0 3 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
37 1
117 0
2
0 4 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
37 1
118 0
2
0 5 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
37 1
119 0
2
0 6 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
37 1
120 0
2
0 7 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
37 1
121 0
2
0 8 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
37 1
122 0
2
0 9 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
37 1
123 0
2
0 10 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
37 1
124 0
2
0 11 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
37 1
125 0
2
0 12 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
37 1
126 0
2
0 13 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
37 1
127 0
2
0 14 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
37 1
128 0
2
0 15 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
37 1
129 0
2
0 16 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
37 1
130 0
2
0 17 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
37 1
131 0
2
0 18 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
37 1
132 0
2
0 19 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
37 1
133 0
2
0 20 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut31
3
0 0
37 1
134 0
2
0 21 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut32
3
0 0
37 1
135 0
2
0 22 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut33
3
0 0
37 1
136 0
2
0 23 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut34
3
0 0
37 1
137 0
2
0 24 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut35
3
0 0
37 1
138 0
2
0 25 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut36
3
0 0
37 1
139 0
2
0 26 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut37
3
0 0
37 1
140 0
2
0 27 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut38
3
0 0
37 1
141 0
2
0 28 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut39
3
0 0
37 1
142 0
2
0 29 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
37 1
143 0
2
0 30 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
37 1
144 0
2
0 31 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
37 1
145 0
2
0 32 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
37 1
146 0
2
0 33 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
37 1
147 0
2
0 34 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
37 1
149 0
2
0 35 0 1
0 150 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
38 1
110 0
2
0 106 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
38 1
111 0
2
0 107 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
38 1
112 0
2
0 108 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
38 1
113 0
2
0 109 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
38 1
114 0
2
0 1 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
38 1
115 0
2
0 2 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
38 1
116 0
2
0 3 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
38 1
117 0
2
0 4 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
38 1
118 0
2
0 5 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
38 1
119 0
2
0 6 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
38 1
120 0
2
0 7 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
38 1
121 0
2
0 8 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
38 1
122 0
2
0 9 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
38 1
123 0
2
0 10 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
38 1
124 0
2
0 11 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
38 1
125 0
2
0 12 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
38 1
126 0
2
0 13 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
38 1
127 0
2
0 14 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
38 1
128 0
2
0 15 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
38 1
129 0
2
0 16 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
38 1
130 0
2
0 17 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
38 1
131 0
2
0 18 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
38 1
132 0
2
0 19 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
38 1
133 0
2
0 20 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut31
3
0 0
38 1
134 0
2
0 21 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut32
3
0 0
38 1
135 0
2
0 22 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut33
3
0 0
38 1
136 0
2
0 23 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut34
3
0 0
38 1
137 0
2
0 24 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut35
3
0 0
38 1
138 0
2
0 25 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut36
3
0 0
38 1
139 0
2
0 26 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut37
3
0 0
38 1
140 0
2
0 27 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut38
3
0 0
38 1
141 0
2
0 28 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut39
3
0 0
38 1
142 0
2
0 29 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
38 1
143 0
2
0 30 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
38 1
144 0
2
0 31 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
38 1
145 0
2
0 32 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
38 1
146 0
2
0 33 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
38 1
147 0
2
0 34 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
38 1
149 0
2
0 35 0 1
0 151 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
39 1
110 0
2
0 106 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
39 1
111 0
2
0 107 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
39 1
112 0
2
0 108 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
39 1
113 0
2
0 109 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
39 1
114 0
2
0 1 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
39 1
115 0
2
0 2 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
39 1
116 0
2
0 3 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
39 1
117 0
2
0 4 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
39 1
118 0
2
0 5 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
39 1
119 0
2
0 6 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
39 1
120 0
2
0 7 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
39 1
121 0
2
0 8 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
39 1
122 0
2
0 9 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
39 1
123 0
2
0 10 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
39 1
124 0
2
0 11 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
39 1
125 0
2
0 12 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
39 1
126 0
2
0 13 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
39 1
127 0
2
0 14 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
39 1
128 0
2
0 15 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
39 1
129 0
2
0 16 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
39 1
130 0
2
0 17 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
39 1
131 0
2
0 18 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
39 1
132 0
2
0 19 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
39 1
133 0
2
0 20 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut31
3
0 0
39 1
134 0
2
0 21 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut32
3
0 0
39 1
135 0
2
0 22 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut33
3
0 0
39 1
136 0
2
0 23 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut34
3
0 0
39 1
137 0
2
0 24 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut35
3
0 0
39 1
138 0
2
0 25 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut36
3
0 0
39 1
139 0
2
0 26 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut37
3
0 0
39 1
140 0
2
0 27 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut38
3
0 0
39 1
141 0
2
0 28 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut39
3
0 0
39 1
142 0
2
0 29 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
39 1
143 0
2
0 30 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
39 1
144 0
2
0 31 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
39 1
145 0
2
0 32 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
39 1
146 0
2
0 33 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
39 1
147 0
2
0 34 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
39 1
149 0
2
0 35 0 1
0 152 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
40 1
110 0
2
0 106 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
40 1
111 0
2
0 107 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
40 1
112 0
2
0 108 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
40 1
113 0
2
0 109 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
40 1
114 0
2
0 1 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
40 1
115 0
2
0 2 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
40 1
116 0
2
0 3 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
40 1
117 0
2
0 4 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
40 1
118 0
2
0 5 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
40 1
119 0
2
0 6 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
40 1
120 0
2
0 7 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
40 1
121 0
2
0 8 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
40 1
122 0
2
0 9 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
40 1
123 0
2
0 10 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
40 1
124 0
2
0 11 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
40 1
125 0
2
0 12 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
40 1
126 0
2
0 13 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
40 1
127 0
2
0 14 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
40 1
128 0
2
0 15 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
40 1
129 0
2
0 16 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
40 1
130 0
2
0 17 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
40 1
131 0
2
0 18 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
40 1
132 0
2
0 19 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
40 1
133 0
2
0 20 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut31
3
0 0
40 1
134 0
2
0 21 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut32
3
0 0
40 1
135 0
2
0 22 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut33
3
0 0
40 1
136 0
2
0 23 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut34
3
0 0
40 1
137 0
2
0 24 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut35
3
0 0
40 1
138 0
2
0 25 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut36
3
0 0
40 1
139 0
2
0 26 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut37
3
0 0
40 1
140 0
2
0 27 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut38
3
0 0
40 1
141 0
2
0 28 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut39
3
0 0
40 1
142 0
2
0 29 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
40 1
143 0
2
0 30 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
40 1
144 0
2
0 31 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
40 1
145 0
2
0 32 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
40 1
146 0
2
0 33 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
40 1
147 0
2
0 34 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
40 1
149 0
2
0 35 0 1
0 153 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
41 1
110 0
2
0 106 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
41 1
111 0
2
0 107 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
41 1
112 0
2
0 108 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
41 1
113 0
2
0 109 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
41 1
114 0
2
0 1 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
41 1
115 0
2
0 2 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
41 1
116 0
2
0 3 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
41 1
117 0
2
0 4 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
41 1
118 0
2
0 5 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
41 1
119 0
2
0 6 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
41 1
120 0
2
0 7 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
41 1
121 0
2
0 8 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
41 1
122 0
2
0 9 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
41 1
123 0
2
0 10 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
41 1
124 0
2
0 11 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
41 1
125 0
2
0 12 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
41 1
126 0
2
0 13 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
41 1
127 0
2
0 14 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
41 1
128 0
2
0 15 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
41 1
129 0
2
0 16 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
41 1
130 0
2
0 17 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
41 1
131 0
2
0 18 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
41 1
132 0
2
0 19 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
41 1
133 0
2
0 20 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut31
3
0 0
41 1
134 0
2
0 21 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut32
3
0 0
41 1
135 0
2
0 22 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut33
3
0 0
41 1
136 0
2
0 23 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut34
3
0 0
41 1
137 0
2
0 24 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut35
3
0 0
41 1
138 0
2
0 25 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut36
3
0 0
41 1
139 0
2
0 26 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut37
3
0 0
41 1
140 0
2
0 27 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut38
3
0 0
41 1
141 0
2
0 28 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut39
3
0 0
41 1
142 0
2
0 29 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
41 1
143 0
2
0 30 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
41 1
144 0
2
0 31 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
41 1
145 0
2
0 32 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
41 1
146 0
2
0 33 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
41 1
147 0
2
0 34 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
41 1
149 0
2
0 35 0 1
0 154 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
42 1
110 0
2
0 106 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
42 1
111 0
2
0 107 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
42 1
112 0
2
0 108 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
42 1
113 0
2
0 109 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
42 1
114 0
2
0 1 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
42 1
115 0
2
0 2 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
42 1
116 0
2
0 3 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
42 1
117 0
2
0 4 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
42 1
118 0
2
0 5 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
42 1
119 0
2
0 6 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
42 1
120 0
2
0 7 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
42 1
121 0
2
0 8 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
42 1
122 0
2
0 9 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
42 1
123 0
2
0 10 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
42 1
124 0
2
0 11 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
42 1
125 0
2
0 12 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
42 1
126 0
2
0 13 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
42 1
127 0
2
0 14 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
42 1
128 0
2
0 15 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
42 1
129 0
2
0 16 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
42 1
130 0
2
0 17 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
42 1
131 0
2
0 18 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
42 1
132 0
2
0 19 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
42 1
133 0
2
0 20 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut31
3
0 0
42 1
134 0
2
0 21 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut32
3
0 0
42 1
135 0
2
0 22 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut33
3
0 0
42 1
136 0
2
0 23 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut34
3
0 0
42 1
137 0
2
0 24 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut35
3
0 0
42 1
138 0
2
0 25 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut36
3
0 0
42 1
139 0
2
0 26 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut37
3
0 0
42 1
140 0
2
0 27 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut38
3
0 0
42 1
141 0
2
0 28 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut39
3
0 0
42 1
142 0
2
0 29 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
42 1
143 0
2
0 30 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
42 1
144 0
2
0 31 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
42 1
145 0
2
0 32 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
42 1
146 0
2
0 33 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
42 1
147 0
2
0 34 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
42 1
149 0
2
0 35 0 1
0 155 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
43 1
110 0
2
0 106 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
43 1
111 0
2
0 107 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
43 1
112 0
2
0 108 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
43 1
113 0
2
0 109 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
43 1
114 0
2
0 1 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
43 1
115 0
2
0 2 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
43 1
116 0
2
0 3 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
43 1
117 0
2
0 4 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
43 1
118 0
2
0 5 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
43 1
119 0
2
0 6 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
43 1
120 0
2
0 7 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
43 1
121 0
2
0 8 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
43 1
122 0
2
0 9 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
43 1
123 0
2
0 10 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
43 1
124 0
2
0 11 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
43 1
125 0
2
0 12 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
43 1
126 0
2
0 13 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
43 1
127 0
2
0 14 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
43 1
128 0
2
0 15 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
43 1
129 0
2
0 16 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
43 1
130 0
2
0 17 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
43 1
131 0
2
0 18 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
43 1
132 0
2
0 19 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
43 1
133 0
2
0 20 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut31
3
0 0
43 1
134 0
2
0 21 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut32
3
0 0
43 1
135 0
2
0 22 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut33
3
0 0
43 1
136 0
2
0 23 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut34
3
0 0
43 1
137 0
2
0 24 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut35
3
0 0
43 1
138 0
2
0 25 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut36
3
0 0
43 1
139 0
2
0 26 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut37
3
0 0
43 1
140 0
2
0 27 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut38
3
0 0
43 1
141 0
2
0 28 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut39
3
0 0
43 1
142 0
2
0 29 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
43 1
143 0
2
0 30 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
43 1
144 0
2
0 31 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
43 1
145 0
2
0 32 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
43 1
146 0
2
0 33 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
43 1
147 0
2
0 34 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
43 1
149 0
2
0 35 0 1
0 156 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
44 1
110 0
2
0 106 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
44 1
111 0
2
0 107 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
44 1
112 0
2
0 108 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
44 1
113 0
2
0 109 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
44 1
114 0
2
0 1 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
44 1
115 0
2
0 2 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
44 1
116 0
2
0 3 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
44 1
117 0
2
0 4 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
44 1
118 0
2
0 5 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
44 1
119 0
2
0 6 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
44 1
120 0
2
0 7 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
44 1
121 0
2
0 8 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
44 1
122 0
2
0 9 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
44 1
123 0
2
0 10 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
44 1
124 0
2
0 11 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
44 1
125 0
2
0 12 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
44 1
126 0
2
0 13 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
44 1
127 0
2
0 14 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
44 1
128 0
2
0 15 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
44 1
129 0
2
0 16 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
44 1
130 0
2
0 17 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
44 1
131 0
2
0 18 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
44 1
132 0
2
0 19 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
44 1
133 0
2
0 20 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut31
3
0 0
44 1
134 0
2
0 21 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut32
3
0 0
44 1
135 0
2
0 22 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut33
3
0 0
44 1
136 0
2
0 23 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut34
3
0 0
44 1
137 0
2
0 24 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut35
3
0 0
44 1
138 0
2
0 25 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut36
3
0 0
44 1
139 0
2
0 26 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut37
3
0 0
44 1
140 0
2
0 27 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut38
3
0 0
44 1
141 0
2
0 28 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut39
3
0 0
44 1
142 0
2
0 29 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
44 1
143 0
2
0 30 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
44 1
144 0
2
0 31 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
44 1
145 0
2
0 32 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
44 1
146 0
2
0 33 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
44 1
147 0
2
0 34 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
44 1
149 0
2
0 35 0 1
0 157 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
45 1
110 0
2
0 106 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
45 1
111 0
2
0 107 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
45 1
112 0
2
0 108 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
45 1
113 0
2
0 109 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
45 1
114 0
2
0 1 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
45 1
115 0
2
0 2 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
45 1
116 0
2
0 3 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
45 1
117 0
2
0 4 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
45 1
118 0
2
0 5 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
45 1
119 0
2
0 6 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
45 1
120 0
2
0 7 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
45 1
121 0
2
0 8 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
45 1
122 0
2
0 9 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
45 1
123 0
2
0 10 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
45 1
124 0
2
0 11 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
45 1
125 0
2
0 12 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
45 1
126 0
2
0 13 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
45 1
127 0
2
0 14 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
45 1
128 0
2
0 15 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
45 1
129 0
2
0 16 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
45 1
130 0
2
0 17 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
45 1
131 0
2
0 18 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
45 1
132 0
2
0 19 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
45 1
133 0
2
0 20 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut31
3
0 0
45 1
134 0
2
0 21 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut32
3
0 0
45 1
135 0
2
0 22 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut33
3
0 0
45 1
136 0
2
0 23 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut34
3
0 0
45 1
137 0
2
0 24 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut35
3
0 0
45 1
138 0
2
0 25 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut36
3
0 0
45 1
139 0
2
0 26 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut37
3
0 0
45 1
140 0
2
0 27 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut38
3
0 0
45 1
141 0
2
0 28 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut39
3
0 0
45 1
142 0
2
0 29 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
45 1
143 0
2
0 30 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
45 1
144 0
2
0 31 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
45 1
145 0
2
0 32 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
45 1
146 0
2
0 33 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
45 1
147 0
2
0 34 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
45 1
149 0
2
0 35 0 1
0 158 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
46 1
110 0
2
0 106 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
46 1
111 0
2
0 107 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
46 1
112 0
2
0 108 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
46 1
113 0
2
0 109 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
46 1
114 0
2
0 1 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
46 1
115 0
2
0 2 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
46 1
116 0
2
0 3 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
46 1
117 0
2
0 4 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
46 1
118 0
2
0 5 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
46 1
119 0
2
0 6 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
46 1
120 0
2
0 7 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
46 1
121 0
2
0 8 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
46 1
122 0
2
0 9 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
46 1
123 0
2
0 10 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
46 1
124 0
2
0 11 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
46 1
125 0
2
0 12 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
46 1
126 0
2
0 13 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
46 1
127 0
2
0 14 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
46 1
128 0
2
0 15 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
46 1
129 0
2
0 16 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
46 1
130 0
2
0 17 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
46 1
131 0
2
0 18 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
46 1
132 0
2
0 19 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
46 1
133 0
2
0 20 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut31
3
0 0
46 1
134 0
2
0 21 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut32
3
0 0
46 1
135 0
2
0 22 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut33
3
0 0
46 1
136 0
2
0 23 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut34
3
0 0
46 1
137 0
2
0 24 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut35
3
0 0
46 1
138 0
2
0 25 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut36
3
0 0
46 1
139 0
2
0 26 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut37
3
0 0
46 1
140 0
2
0 27 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut38
3
0 0
46 1
141 0
2
0 28 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut39
3
0 0
46 1
142 0
2
0 29 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
46 1
143 0
2
0 30 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
46 1
144 0
2
0 31 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
46 1
145 0
2
0 32 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
46 1
146 0
2
0 33 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
46 1
147 0
2
0 34 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
46 1
149 0
2
0 35 0 1
0 159 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
47 1
110 0
2
0 106 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
47 1
111 0
2
0 107 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
47 1
112 0
2
0 108 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
47 1
113 0
2
0 109 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
47 1
114 0
2
0 1 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
47 1
115 0
2
0 2 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
47 1
116 0
2
0 3 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
47 1
117 0
2
0 4 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
47 1
118 0
2
0 5 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
47 1
119 0
2
0 6 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
47 1
120 0
2
0 7 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
47 1
121 0
2
0 8 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
47 1
122 0
2
0 9 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
47 1
123 0
2
0 10 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
47 1
124 0
2
0 11 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
47 1
125 0
2
0 12 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
47 1
126 0
2
0 13 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
47 1
127 0
2
0 14 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
47 1
128 0
2
0 15 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
47 1
129 0
2
0 16 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
47 1
130 0
2
0 17 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
47 1
131 0
2
0 18 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
47 1
132 0
2
0 19 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
47 1
133 0
2
0 20 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut31
3
0 0
47 1
134 0
2
0 21 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut32
3
0 0
47 1
135 0
2
0 22 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut33
3
0 0
47 1
136 0
2
0 23 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut34
3
0 0
47 1
137 0
2
0 24 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut35
3
0 0
47 1
138 0
2
0 25 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut36
3
0 0
47 1
139 0
2
0 26 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut37
3
0 0
47 1
140 0
2
0 27 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut38
3
0 0
47 1
141 0
2
0 28 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut39
3
0 0
47 1
142 0
2
0 29 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
47 1
143 0
2
0 30 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
47 1
144 0
2
0 31 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
47 1
145 0
2
0 32 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
47 1
146 0
2
0 33 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
47 1
147 0
2
0 34 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
47 1
149 0
2
0 35 0 1
0 160 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
48 1
110 0
2
0 106 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
48 1
111 0
2
0 107 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
48 1
112 0
2
0 108 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
48 1
113 0
2
0 109 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
48 1
114 0
2
0 1 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
48 1
115 0
2
0 2 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
48 1
116 0
2
0 3 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
48 1
117 0
2
0 4 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
48 1
118 0
2
0 5 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
48 1
119 0
2
0 6 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
48 1
120 0
2
0 7 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
48 1
121 0
2
0 8 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
48 1
122 0
2
0 9 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
48 1
123 0
2
0 10 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
48 1
124 0
2
0 11 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
48 1
125 0
2
0 12 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
48 1
126 0
2
0 13 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
48 1
127 0
2
0 14 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
48 1
128 0
2
0 15 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
48 1
129 0
2
0 16 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
48 1
130 0
2
0 17 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
48 1
131 0
2
0 18 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
48 1
132 0
2
0 19 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
48 1
133 0
2
0 20 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut31
3
0 0
48 1
134 0
2
0 21 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut32
3
0 0
48 1
135 0
2
0 22 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut33
3
0 0
48 1
136 0
2
0 23 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut34
3
0 0
48 1
137 0
2
0 24 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut35
3
0 0
48 1
138 0
2
0 25 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut36
3
0 0
48 1
139 0
2
0 26 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut37
3
0 0
48 1
140 0
2
0 27 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut38
3
0 0
48 1
141 0
2
0 28 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut39
3
0 0
48 1
142 0
2
0 29 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
48 1
143 0
2
0 30 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
48 1
144 0
2
0 31 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
48 1
145 0
2
0 32 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
48 1
146 0
2
0 33 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
48 1
147 0
2
0 34 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
48 1
149 0
2
0 35 0 1
0 161 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
49 1
110 0
2
0 106 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
49 1
111 0
2
0 107 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
49 1
112 0
2
0 108 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
49 1
113 0
2
0 109 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
49 1
114 0
2
0 1 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
49 1
115 0
2
0 2 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
49 1
116 0
2
0 3 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
49 1
117 0
2
0 4 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
49 1
118 0
2
0 5 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
49 1
119 0
2
0 6 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
49 1
120 0
2
0 7 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
49 1
121 0
2
0 8 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
49 1
122 0
2
0 9 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
49 1
123 0
2
0 10 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
49 1
124 0
2
0 11 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
49 1
125 0
2
0 12 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
49 1
126 0
2
0 13 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
49 1
127 0
2
0 14 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
49 1
128 0
2
0 15 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
49 1
129 0
2
0 16 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
49 1
130 0
2
0 17 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
49 1
131 0
2
0 18 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
49 1
132 0
2
0 19 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
49 1
133 0
2
0 20 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut31
3
0 0
49 1
134 0
2
0 21 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut32
3
0 0
49 1
135 0
2
0 22 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut33
3
0 0
49 1
136 0
2
0 23 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut34
3
0 0
49 1
137 0
2
0 24 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut35
3
0 0
49 1
138 0
2
0 25 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut36
3
0 0
49 1
139 0
2
0 26 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut37
3
0 0
49 1
140 0
2
0 27 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut38
3
0 0
49 1
141 0
2
0 28 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut39
3
0 0
49 1
142 0
2
0 29 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
49 1
143 0
2
0 30 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
49 1
144 0
2
0 31 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
49 1
145 0
2
0 32 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
49 1
146 0
2
0 33 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
49 1
147 0
2
0 34 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
49 1
149 0
2
0 35 0 1
0 162 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
50 1
110 0
2
0 106 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
50 1
111 0
2
0 107 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
50 1
112 0
2
0 108 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
50 1
113 0
2
0 109 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
50 1
114 0
2
0 1 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
50 1
115 0
2
0 2 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
50 1
116 0
2
0 3 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
50 1
117 0
2
0 4 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
50 1
118 0
2
0 5 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
50 1
119 0
2
0 6 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
50 1
120 0
2
0 7 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
50 1
121 0
2
0 8 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
50 1
122 0
2
0 9 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
50 1
123 0
2
0 10 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
50 1
124 0
2
0 11 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
50 1
125 0
2
0 12 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
50 1
126 0
2
0 13 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
50 1
127 0
2
0 14 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
50 1
128 0
2
0 15 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
50 1
129 0
2
0 16 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
50 1
130 0
2
0 17 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
50 1
131 0
2
0 18 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
50 1
132 0
2
0 19 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
50 1
133 0
2
0 20 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut31
3
0 0
50 1
134 0
2
0 21 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut32
3
0 0
50 1
135 0
2
0 22 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut33
3
0 0
50 1
136 0
2
0 23 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut34
3
0 0
50 1
137 0
2
0 24 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut35
3
0 0
50 1
138 0
2
0 25 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut36
3
0 0
50 1
139 0
2
0 26 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut37
3
0 0
50 1
140 0
2
0 27 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut38
3
0 0
50 1
141 0
2
0 28 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut39
3
0 0
50 1
142 0
2
0 29 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
50 1
143 0
2
0 30 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
50 1
144 0
2
0 31 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
50 1
145 0
2
0 32 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
50 1
146 0
2
0 33 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
50 1
147 0
2
0 34 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
50 1
149 0
2
0 35 0 1
0 163 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
51 1
110 0
2
0 106 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
51 1
111 0
2
0 107 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
51 1
112 0
2
0 108 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
51 1
113 0
2
0 109 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
51 1
114 0
2
0 1 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
51 1
115 0
2
0 2 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
51 1
116 0
2
0 3 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
51 1
117 0
2
0 4 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
51 1
118 0
2
0 5 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
51 1
119 0
2
0 6 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
51 1
120 0
2
0 7 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
51 1
121 0
2
0 8 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
51 1
122 0
2
0 9 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
51 1
123 0
2
0 10 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
51 1
124 0
2
0 11 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
51 1
125 0
2
0 12 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
51 1
126 0
2
0 13 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
51 1
127 0
2
0 14 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
51 1
128 0
2
0 15 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
51 1
129 0
2
0 16 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
51 1
130 0
2
0 17 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
51 1
131 0
2
0 18 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
51 1
132 0
2
0 19 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
51 1
133 0
2
0 20 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut31
3
0 0
51 1
134 0
2
0 21 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut32
3
0 0
51 1
135 0
2
0 22 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut33
3
0 0
51 1
136 0
2
0 23 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut34
3
0 0
51 1
137 0
2
0 24 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut35
3
0 0
51 1
138 0
2
0 25 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut36
3
0 0
51 1
139 0
2
0 26 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut37
3
0 0
51 1
140 0
2
0 27 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut38
3
0 0
51 1
141 0
2
0 28 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut39
3
0 0
51 1
142 0
2
0 29 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
51 1
143 0
2
0 30 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
51 1
144 0
2
0 31 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
51 1
145 0
2
0 32 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
51 1
146 0
2
0 33 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
51 1
147 0
2
0 34 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
51 1
149 0
2
0 35 0 1
0 164 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
52 1
110 0
2
0 106 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
52 1
111 0
2
0 107 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
52 1
112 0
2
0 108 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
52 1
113 0
2
0 109 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
52 1
114 0
2
0 1 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
52 1
115 0
2
0 2 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
52 1
116 0
2
0 3 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
52 1
117 0
2
0 4 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
52 1
118 0
2
0 5 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
52 1
119 0
2
0 6 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
52 1
120 0
2
0 7 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
52 1
121 0
2
0 8 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
52 1
122 0
2
0 9 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
52 1
123 0
2
0 10 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
52 1
124 0
2
0 11 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
52 1
125 0
2
0 12 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
52 1
126 0
2
0 13 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
52 1
127 0
2
0 14 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
52 1
128 0
2
0 15 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
52 1
129 0
2
0 16 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
52 1
130 0
2
0 17 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
52 1
131 0
2
0 18 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
52 1
132 0
2
0 19 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
52 1
133 0
2
0 20 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut31
3
0 0
52 1
134 0
2
0 21 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut32
3
0 0
52 1
135 0
2
0 22 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut33
3
0 0
52 1
136 0
2
0 23 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut34
3
0 0
52 1
137 0
2
0 24 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut35
3
0 0
52 1
138 0
2
0 25 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut36
3
0 0
52 1
139 0
2
0 26 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut37
3
0 0
52 1
140 0
2
0 27 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut38
3
0 0
52 1
141 0
2
0 28 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut39
3
0 0
52 1
142 0
2
0 29 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
52 1
143 0
2
0 30 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
52 1
144 0
2
0 31 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
52 1
145 0
2
0 32 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
52 1
146 0
2
0 33 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
52 1
147 0
2
0 34 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
52 1
149 0
2
0 35 0 1
0 165 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
53 1
110 0
2
0 106 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
53 1
111 0
2
0 107 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
53 1
112 0
2
0 108 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
53 1
113 0
2
0 109 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
53 1
114 0
2
0 1 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
53 1
115 0
2
0 2 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
53 1
116 0
2
0 3 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
53 1
117 0
2
0 4 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
53 1
118 0
2
0 5 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
53 1
119 0
2
0 6 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
53 1
120 0
2
0 7 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
53 1
121 0
2
0 8 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
53 1
122 0
2
0 9 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
53 1
123 0
2
0 10 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
53 1
124 0
2
0 11 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
53 1
125 0
2
0 12 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
53 1
126 0
2
0 13 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
53 1
127 0
2
0 14 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
53 1
128 0
2
0 15 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
53 1
129 0
2
0 16 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
53 1
130 0
2
0 17 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
53 1
131 0
2
0 18 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
53 1
132 0
2
0 19 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
53 1
133 0
2
0 20 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut31
3
0 0
53 1
134 0
2
0 21 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut32
3
0 0
53 1
135 0
2
0 22 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut33
3
0 0
53 1
136 0
2
0 23 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut34
3
0 0
53 1
137 0
2
0 24 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut35
3
0 0
53 1
138 0
2
0 25 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut36
3
0 0
53 1
139 0
2
0 26 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut37
3
0 0
53 1
140 0
2
0 27 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut38
3
0 0
53 1
141 0
2
0 28 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut39
3
0 0
53 1
142 0
2
0 29 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
53 1
143 0
2
0 30 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
53 1
144 0
2
0 31 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
53 1
145 0
2
0 32 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
53 1
146 0
2
0 33 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
53 1
147 0
2
0 34 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
53 1
149 0
2
0 35 0 1
0 166 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
54 1
110 0
2
0 106 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
54 1
111 0
2
0 107 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
54 1
112 0
2
0 108 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
54 1
113 0
2
0 109 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
54 1
114 0
2
0 1 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
54 1
115 0
2
0 2 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
54 1
116 0
2
0 3 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
54 1
117 0
2
0 4 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
54 1
118 0
2
0 5 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
54 1
119 0
2
0 6 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
54 1
120 0
2
0 7 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
54 1
121 0
2
0 8 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
54 1
122 0
2
0 9 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
54 1
123 0
2
0 10 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
54 1
124 0
2
0 11 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
54 1
125 0
2
0 12 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
54 1
126 0
2
0 13 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
54 1
127 0
2
0 14 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
54 1
128 0
2
0 15 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
54 1
129 0
2
0 16 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
54 1
130 0
2
0 17 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
54 1
131 0
2
0 18 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
54 1
132 0
2
0 19 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
54 1
133 0
2
0 20 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut31
3
0 0
54 1
134 0
2
0 21 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut32
3
0 0
54 1
135 0
2
0 22 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut33
3
0 0
54 1
136 0
2
0 23 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut34
3
0 0
54 1
137 0
2
0 24 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut35
3
0 0
54 1
138 0
2
0 25 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut36
3
0 0
54 1
139 0
2
0 26 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut37
3
0 0
54 1
140 0
2
0 27 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut38
3
0 0
54 1
141 0
2
0 28 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut39
3
0 0
54 1
142 0
2
0 29 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
54 1
143 0
2
0 30 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
54 1
144 0
2
0 31 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
54 1
145 0
2
0 32 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
54 1
146 0
2
0 33 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
54 1
147 0
2
0 34 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
54 1
149 0
2
0 35 0 1
0 167 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
55 1
110 0
2
0 106 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
55 1
111 0
2
0 107 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
55 1
112 0
2
0 108 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
55 1
113 0
2
0 109 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
55 1
114 0
2
0 1 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
55 1
115 0
2
0 2 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
55 1
116 0
2
0 3 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
55 1
117 0
2
0 4 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
55 1
118 0
2
0 5 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
55 1
119 0
2
0 6 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
55 1
120 0
2
0 7 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
55 1
121 0
2
0 8 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
55 1
122 0
2
0 9 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
55 1
123 0
2
0 10 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
55 1
124 0
2
0 11 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
55 1
125 0
2
0 12 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
55 1
126 0
2
0 13 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
55 1
127 0
2
0 14 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
55 1
128 0
2
0 15 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
55 1
129 0
2
0 16 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
55 1
130 0
2
0 17 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
55 1
131 0
2
0 18 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
55 1
132 0
2
0 19 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
55 1
133 0
2
0 20 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut31
3
0 0
55 1
134 0
2
0 21 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut32
3
0 0
55 1
135 0
2
0 22 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut33
3
0 0
55 1
136 0
2
0 23 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut34
3
0 0
55 1
137 0
2
0 24 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut35
3
0 0
55 1
138 0
2
0 25 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut36
3
0 0
55 1
139 0
2
0 26 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut37
3
0 0
55 1
140 0
2
0 27 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut38
3
0 0
55 1
141 0
2
0 28 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut39
3
0 0
55 1
142 0
2
0 29 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
55 1
143 0
2
0 30 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
55 1
144 0
2
0 31 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
55 1
145 0
2
0 32 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
55 1
146 0
2
0 33 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
55 1
147 0
2
0 34 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
55 1
149 0
2
0 35 0 1
0 168 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
56 1
110 0
2
0 106 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
56 1
111 0
2
0 107 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
56 1
112 0
2
0 108 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
56 1
113 0
2
0 109 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
56 1
114 0
2
0 1 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
56 1
115 0
2
0 2 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
56 1
116 0
2
0 3 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
56 1
117 0
2
0 4 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
56 1
118 0
2
0 5 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
56 1
119 0
2
0 6 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
56 1
120 0
2
0 7 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
56 1
121 0
2
0 8 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
56 1
122 0
2
0 9 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
56 1
123 0
2
0 10 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
56 1
124 0
2
0 11 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
56 1
125 0
2
0 12 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
56 1
126 0
2
0 13 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
56 1
127 0
2
0 14 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
56 1
128 0
2
0 15 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
56 1
129 0
2
0 16 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
56 1
130 0
2
0 17 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
56 1
131 0
2
0 18 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
56 1
132 0
2
0 19 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
56 1
133 0
2
0 20 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut31
3
0 0
56 1
134 0
2
0 21 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut32
3
0 0
56 1
135 0
2
0 22 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut33
3
0 0
56 1
136 0
2
0 23 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut34
3
0 0
56 1
137 0
2
0 24 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut35
3
0 0
56 1
138 0
2
0 25 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut36
3
0 0
56 1
139 0
2
0 26 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut37
3
0 0
56 1
140 0
2
0 27 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut38
3
0 0
56 1
141 0
2
0 28 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut39
3
0 0
56 1
142 0
2
0 29 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
56 1
143 0
2
0 30 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
56 1
144 0
2
0 31 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
56 1
145 0
2
0 32 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
56 1
146 0
2
0 33 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
56 1
147 0
2
0 34 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
56 1
149 0
2
0 35 0 1
0 169 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
57 1
110 0
2
0 106 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
57 1
111 0
2
0 107 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
57 1
112 0
2
0 108 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
57 1
113 0
2
0 109 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
57 1
114 0
2
0 1 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
57 1
115 0
2
0 2 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
57 1
116 0
2
0 3 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
57 1
117 0
2
0 4 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
57 1
118 0
2
0 5 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
57 1
119 0
2
0 6 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
57 1
120 0
2
0 7 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
57 1
121 0
2
0 8 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
57 1
122 0
2
0 9 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
57 1
123 0
2
0 10 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
57 1
124 0
2
0 11 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
57 1
125 0
2
0 12 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
57 1
126 0
2
0 13 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
57 1
127 0
2
0 14 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
57 1
128 0
2
0 15 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
57 1
129 0
2
0 16 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
57 1
130 0
2
0 17 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
57 1
131 0
2
0 18 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
57 1
132 0
2
0 19 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
57 1
133 0
2
0 20 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut31
3
0 0
57 1
134 0
2
0 21 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut32
3
0 0
57 1
135 0
2
0 22 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut33
3
0 0
57 1
136 0
2
0 23 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut34
3
0 0
57 1
137 0
2
0 24 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut35
3
0 0
57 1
138 0
2
0 25 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut36
3
0 0
57 1
139 0
2
0 26 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut37
3
0 0
57 1
140 0
2
0 27 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut38
3
0 0
57 1
141 0
2
0 28 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut39
3
0 0
57 1
142 0
2
0 29 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
57 1
143 0
2
0 30 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
57 1
144 0
2
0 31 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
57 1
145 0
2
0 32 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
57 1
146 0
2
0 33 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
57 1
147 0
2
0 34 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
57 1
149 0
2
0 35 0 1
0 170 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
58 1
110 0
2
0 106 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
58 1
111 0
2
0 107 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
58 1
112 0
2
0 108 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
58 1
113 0
2
0 109 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
58 1
114 0
2
0 1 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
58 1
115 0
2
0 2 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
58 1
116 0
2
0 3 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
58 1
117 0
2
0 4 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
58 1
118 0
2
0 5 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
58 1
119 0
2
0 6 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
58 1
120 0
2
0 7 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
58 1
121 0
2
0 8 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
58 1
122 0
2
0 9 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
58 1
123 0
2
0 10 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
58 1
124 0
2
0 11 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
58 1
125 0
2
0 12 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
58 1
126 0
2
0 13 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
58 1
127 0
2
0 14 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
58 1
128 0
2
0 15 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
58 1
129 0
2
0 16 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
58 1
130 0
2
0 17 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
58 1
131 0
2
0 18 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
58 1
132 0
2
0 19 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
58 1
133 0
2
0 20 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut31
3
0 0
58 1
134 0
2
0 21 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut32
3
0 0
58 1
135 0
2
0 22 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut33
3
0 0
58 1
136 0
2
0 23 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut34
3
0 0
58 1
137 0
2
0 24 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut35
3
0 0
58 1
138 0
2
0 25 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut36
3
0 0
58 1
139 0
2
0 26 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut37
3
0 0
58 1
140 0
2
0 27 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut38
3
0 0
58 1
141 0
2
0 28 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut39
3
0 0
58 1
142 0
2
0 29 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
58 1
143 0
2
0 30 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
58 1
144 0
2
0 31 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
58 1
145 0
2
0 32 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
58 1
146 0
2
0 33 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
58 1
147 0
2
0 34 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
58 1
149 0
2
0 35 0 1
0 171 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
59 1
110 0
2
0 106 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
59 1
111 0
2
0 107 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
59 1
112 0
2
0 108 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
59 1
113 0
2
0 109 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
59 1
114 0
2
0 1 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
59 1
115 0
2
0 2 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
59 1
116 0
2
0 3 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
59 1
117 0
2
0 4 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
59 1
118 0
2
0 5 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
59 1
119 0
2
0 6 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
59 1
120 0
2
0 7 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
59 1
121 0
2
0 8 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
59 1
122 0
2
0 9 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
59 1
123 0
2
0 10 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
59 1
124 0
2
0 11 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
59 1
125 0
2
0 12 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
59 1
126 0
2
0 13 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
59 1
127 0
2
0 14 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
59 1
128 0
2
0 15 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
59 1
129 0
2
0 16 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
59 1
130 0
2
0 17 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
59 1
131 0
2
0 18 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
59 1
132 0
2
0 19 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
59 1
133 0
2
0 20 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut31
3
0 0
59 1
134 0
2
0 21 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut32
3
0 0
59 1
135 0
2
0 22 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut33
3
0 0
59 1
136 0
2
0 23 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut34
3
0 0
59 1
137 0
2
0 24 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut35
3
0 0
59 1
138 0
2
0 25 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut36
3
0 0
59 1
139 0
2
0 26 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut37
3
0 0
59 1
140 0
2
0 27 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut38
3
0 0
59 1
141 0
2
0 28 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut39
3
0 0
59 1
142 0
2
0 29 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
59 1
143 0
2
0 30 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
59 1
144 0
2
0 31 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
59 1
145 0
2
0 32 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
59 1
146 0
2
0 33 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
59 1
147 0
2
0 34 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
59 1
149 0
2
0 35 0 1
0 172 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
60 1
110 0
2
0 106 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
60 1
111 0
2
0 107 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
60 1
112 0
2
0 108 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
60 1
113 0
2
0 109 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
60 1
114 0
2
0 1 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
60 1
115 0
2
0 2 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
60 1
116 0
2
0 3 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
60 1
117 0
2
0 4 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
60 1
118 0
2
0 5 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
60 1
119 0
2
0 6 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
60 1
120 0
2
0 7 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
60 1
121 0
2
0 8 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
60 1
122 0
2
0 9 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
60 1
123 0
2
0 10 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
60 1
124 0
2
0 11 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
60 1
125 0
2
0 12 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
60 1
126 0
2
0 13 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
60 1
127 0
2
0 14 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
60 1
128 0
2
0 15 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
60 1
129 0
2
0 16 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
60 1
130 0
2
0 17 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
60 1
131 0
2
0 18 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
60 1
132 0
2
0 19 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
60 1
133 0
2
0 20 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut31
3
0 0
60 1
134 0
2
0 21 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut32
3
0 0
60 1
135 0
2
0 22 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut33
3
0 0
60 1
136 0
2
0 23 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut34
3
0 0
60 1
137 0
2
0 24 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut35
3
0 0
60 1
138 0
2
0 25 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut36
3
0 0
60 1
139 0
2
0 26 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut37
3
0 0
60 1
140 0
2
0 27 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut38
3
0 0
60 1
141 0
2
0 28 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut39
3
0 0
60 1
142 0
2
0 29 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
60 1
143 0
2
0 30 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
60 1
144 0
2
0 31 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
60 1
145 0
2
0 32 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
60 1
146 0
2
0 33 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
60 1
147 0
2
0 34 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
60 1
149 0
2
0 35 0 1
0 173 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
61 1
110 0
2
0 106 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
61 1
111 0
2
0 107 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
61 1
112 0
2
0 108 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
61 1
113 0
2
0 109 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
61 1
114 0
2
0 1 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
61 1
115 0
2
0 2 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
61 1
116 0
2
0 3 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
61 1
117 0
2
0 4 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
61 1
118 0
2
0 5 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
61 1
119 0
2
0 6 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
61 1
120 0
2
0 7 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
61 1
121 0
2
0 8 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
61 1
122 0
2
0 9 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
61 1
123 0
2
0 10 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
61 1
124 0
2
0 11 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
61 1
125 0
2
0 12 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
61 1
126 0
2
0 13 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
61 1
127 0
2
0 14 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
61 1
128 0
2
0 15 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
61 1
129 0
2
0 16 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
61 1
130 0
2
0 17 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
61 1
131 0
2
0 18 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
61 1
132 0
2
0 19 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
61 1
133 0
2
0 20 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut31
3
0 0
61 1
134 0
2
0 21 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut32
3
0 0
61 1
135 0
2
0 22 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut33
3
0 0
61 1
136 0
2
0 23 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut34
3
0 0
61 1
137 0
2
0 24 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut35
3
0 0
61 1
138 0
2
0 25 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut36
3
0 0
61 1
139 0
2
0 26 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut37
3
0 0
61 1
140 0
2
0 27 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut38
3
0 0
61 1
141 0
2
0 28 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut39
3
0 0
61 1
142 0
2
0 29 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
61 1
143 0
2
0 30 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
61 1
144 0
2
0 31 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
61 1
145 0
2
0 32 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
61 1
146 0
2
0 33 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
61 1
147 0
2
0 34 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
61 1
149 0
2
0 35 0 1
0 174 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
62 1
110 0
2
0 106 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
62 1
111 0
2
0 107 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
62 1
112 0
2
0 108 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
62 1
113 0
2
0 109 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
62 1
114 0
2
0 1 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
62 1
115 0
2
0 2 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
62 1
116 0
2
0 3 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
62 1
117 0
2
0 4 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
62 1
118 0
2
0 5 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
62 1
119 0
2
0 6 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
62 1
120 0
2
0 7 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
62 1
121 0
2
0 8 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
62 1
122 0
2
0 9 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
62 1
123 0
2
0 10 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
62 1
124 0
2
0 11 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
62 1
125 0
2
0 12 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
62 1
126 0
2
0 13 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
62 1
127 0
2
0 14 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
62 1
128 0
2
0 15 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
62 1
129 0
2
0 16 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
62 1
130 0
2
0 17 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
62 1
131 0
2
0 18 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
62 1
132 0
2
0 19 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
62 1
133 0
2
0 20 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut31
3
0 0
62 1
134 0
2
0 21 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut32
3
0 0
62 1
135 0
2
0 22 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut33
3
0 0
62 1
136 0
2
0 23 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut34
3
0 0
62 1
137 0
2
0 24 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut35
3
0 0
62 1
138 0
2
0 25 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut36
3
0 0
62 1
139 0
2
0 26 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut37
3
0 0
62 1
140 0
2
0 27 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut38
3
0 0
62 1
141 0
2
0 28 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut39
3
0 0
62 1
142 0
2
0 29 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
62 1
143 0
2
0 30 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
62 1
144 0
2
0 31 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
62 1
145 0
2
0 32 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
62 1
146 0
2
0 33 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
62 1
147 0
2
0 34 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
62 1
149 0
2
0 35 0 1
0 175 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
63 1
110 0
2
0 106 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
63 1
111 0
2
0 107 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
63 1
112 0
2
0 108 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
63 1
113 0
2
0 109 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
63 1
114 0
2
0 1 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
63 1
115 0
2
0 2 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
63 1
116 0
2
0 3 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
63 1
117 0
2
0 4 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
63 1
118 0
2
0 5 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
63 1
119 0
2
0 6 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
63 1
120 0
2
0 7 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
63 1
121 0
2
0 8 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
63 1
122 0
2
0 9 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
63 1
123 0
2
0 10 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
63 1
124 0
2
0 11 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
63 1
125 0
2
0 12 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
63 1
126 0
2
0 13 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
63 1
127 0
2
0 14 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
63 1
128 0
2
0 15 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
63 1
129 0
2
0 16 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
63 1
130 0
2
0 17 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
63 1
131 0
2
0 18 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
63 1
132 0
2
0 19 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
63 1
133 0
2
0 20 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut31
3
0 0
63 1
134 0
2
0 21 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut32
3
0 0
63 1
135 0
2
0 22 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut33
3
0 0
63 1
136 0
2
0 23 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut34
3
0 0
63 1
137 0
2
0 24 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut35
3
0 0
63 1
138 0
2
0 25 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut36
3
0 0
63 1
139 0
2
0 26 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut37
3
0 0
63 1
140 0
2
0 27 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut38
3
0 0
63 1
141 0
2
0 28 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut39
3
0 0
63 1
142 0
2
0 29 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
63 1
143 0
2
0 30 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
63 1
144 0
2
0 31 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
63 1
145 0
2
0 32 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
63 1
146 0
2
0 33 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
63 1
147 0
2
0 34 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
63 1
149 0
2
0 35 0 1
0 176 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
64 1
110 0
2
0 106 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
64 1
111 0
2
0 107 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
64 1
112 0
2
0 108 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
64 1
113 0
2
0 109 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
64 1
114 0
2
0 1 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
64 1
115 0
2
0 2 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
64 1
116 0
2
0 3 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
64 1
117 0
2
0 4 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
64 1
118 0
2
0 5 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
64 1
119 0
2
0 6 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
64 1
120 0
2
0 7 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
64 1
121 0
2
0 8 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
64 1
122 0
2
0 9 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
64 1
123 0
2
0 10 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
64 1
124 0
2
0 11 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
64 1
125 0
2
0 12 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
64 1
126 0
2
0 13 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
64 1
127 0
2
0 14 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
64 1
128 0
2
0 15 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
64 1
129 0
2
0 16 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
64 1
130 0
2
0 17 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
64 1
131 0
2
0 18 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
64 1
132 0
2
0 19 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
64 1
133 0
2
0 20 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut31
3
0 0
64 1
134 0
2
0 21 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut32
3
0 0
64 1
135 0
2
0 22 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut33
3
0 0
64 1
136 0
2
0 23 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut34
3
0 0
64 1
137 0
2
0 24 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut35
3
0 0
64 1
138 0
2
0 25 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut36
3
0 0
64 1
139 0
2
0 26 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut37
3
0 0
64 1
140 0
2
0 27 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut38
3
0 0
64 1
141 0
2
0 28 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut39
3
0 0
64 1
142 0
2
0 29 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
64 1
143 0
2
0 30 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
64 1
144 0
2
0 31 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
64 1
145 0
2
0 32 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
64 1
146 0
2
0 33 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
64 1
147 0
2
0 34 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
64 1
149 0
2
0 35 0 1
0 177 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
65 1
110 0
2
0 106 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
65 1
111 0
2
0 107 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
65 1
112 0
2
0 108 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
65 1
113 0
2
0 109 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
65 1
114 0
2
0 1 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
65 1
115 0
2
0 2 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
65 1
116 0
2
0 3 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
65 1
117 0
2
0 4 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
65 1
118 0
2
0 5 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
65 1
119 0
2
0 6 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
65 1
120 0
2
0 7 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
65 1
121 0
2
0 8 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
65 1
122 0
2
0 9 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
65 1
123 0
2
0 10 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
65 1
124 0
2
0 11 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
65 1
125 0
2
0 12 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
65 1
126 0
2
0 13 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
65 1
127 0
2
0 14 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
65 1
128 0
2
0 15 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
65 1
129 0
2
0 16 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
65 1
130 0
2
0 17 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
65 1
131 0
2
0 18 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
65 1
132 0
2
0 19 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
65 1
133 0
2
0 20 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut31
3
0 0
65 1
134 0
2
0 21 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut32
3
0 0
65 1
135 0
2
0 22 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut33
3
0 0
65 1
136 0
2
0 23 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut34
3
0 0
65 1
137 0
2
0 24 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut35
3
0 0
65 1
138 0
2
0 25 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut36
3
0 0
65 1
139 0
2
0 26 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut37
3
0 0
65 1
140 0
2
0 27 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut38
3
0 0
65 1
141 0
2
0 28 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut39
3
0 0
65 1
142 0
2
0 29 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
65 1
143 0
2
0 30 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
65 1
144 0
2
0 31 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
65 1
145 0
2
0 32 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
65 1
146 0
2
0 33 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
65 1
147 0
2
0 34 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
65 1
149 0
2
0 35 0 1
0 178 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
66 1
110 0
2
0 106 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
66 1
111 0
2
0 107 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
66 1
112 0
2
0 108 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
66 1
113 0
2
0 109 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
66 1
114 0
2
0 1 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
66 1
115 0
2
0 2 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
66 1
116 0
2
0 3 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
66 1
117 0
2
0 4 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
66 1
118 0
2
0 5 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
66 1
119 0
2
0 6 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
66 1
120 0
2
0 7 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
66 1
121 0
2
0 8 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
66 1
122 0
2
0 9 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
66 1
123 0
2
0 10 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
66 1
124 0
2
0 11 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
66 1
125 0
2
0 12 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
66 1
126 0
2
0 13 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
66 1
127 0
2
0 14 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
66 1
128 0
2
0 15 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
66 1
129 0
2
0 16 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
66 1
130 0
2
0 17 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
66 1
131 0
2
0 18 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
66 1
132 0
2
0 19 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
66 1
133 0
2
0 20 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut31
3
0 0
66 1
134 0
2
0 21 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut32
3
0 0
66 1
135 0
2
0 22 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut33
3
0 0
66 1
136 0
2
0 23 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut34
3
0 0
66 1
137 0
2
0 24 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut35
3
0 0
66 1
138 0
2
0 25 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut36
3
0 0
66 1
139 0
2
0 26 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut37
3
0 0
66 1
140 0
2
0 27 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut38
3
0 0
66 1
141 0
2
0 28 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut39
3
0 0
66 1
142 0
2
0 29 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
66 1
143 0
2
0 30 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
66 1
144 0
2
0 31 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
66 1
145 0
2
0 32 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
66 1
146 0
2
0 33 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
66 1
147 0
2
0 34 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
66 1
149 0
2
0 35 0 1
0 179 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
67 1
110 0
2
0 106 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
67 1
111 0
2
0 107 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
67 1
112 0
2
0 108 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
67 1
113 0
2
0 109 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
67 1
114 0
2
0 1 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
67 1
115 0
2
0 2 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
67 1
116 0
2
0 3 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
67 1
117 0
2
0 4 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
67 1
118 0
2
0 5 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
67 1
119 0
2
0 6 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
67 1
120 0
2
0 7 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
67 1
121 0
2
0 8 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
67 1
122 0
2
0 9 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
67 1
123 0
2
0 10 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
67 1
124 0
2
0 11 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
67 1
125 0
2
0 12 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
67 1
126 0
2
0 13 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
67 1
127 0
2
0 14 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
67 1
128 0
2
0 15 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
67 1
129 0
2
0 16 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
67 1
130 0
2
0 17 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
67 1
131 0
2
0 18 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
67 1
132 0
2
0 19 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
67 1
133 0
2
0 20 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut31
3
0 0
67 1
134 0
2
0 21 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut32
3
0 0
67 1
135 0
2
0 22 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut33
3
0 0
67 1
136 0
2
0 23 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut34
3
0 0
67 1
137 0
2
0 24 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut35
3
0 0
67 1
138 0
2
0 25 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut36
3
0 0
67 1
139 0
2
0 26 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut37
3
0 0
67 1
140 0
2
0 27 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut38
3
0 0
67 1
141 0
2
0 28 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut39
3
0 0
67 1
142 0
2
0 29 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
67 1
143 0
2
0 30 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
67 1
144 0
2
0 31 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
67 1
145 0
2
0 32 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
67 1
146 0
2
0 33 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
67 1
147 0
2
0 34 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
67 1
149 0
2
0 35 0 1
0 180 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
68 1
110 0
2
0 106 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
68 1
111 0
2
0 107 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
68 1
112 0
2
0 108 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
68 1
113 0
2
0 109 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
68 1
114 0
2
0 1 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
68 1
115 0
2
0 2 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
68 1
116 0
2
0 3 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
68 1
117 0
2
0 4 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
68 1
118 0
2
0 5 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
68 1
119 0
2
0 6 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
68 1
120 0
2
0 7 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
68 1
121 0
2
0 8 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
68 1
122 0
2
0 9 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
68 1
123 0
2
0 10 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
68 1
124 0
2
0 11 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
68 1
125 0
2
0 12 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
68 1
126 0
2
0 13 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
68 1
127 0
2
0 14 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
68 1
128 0
2
0 15 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
68 1
129 0
2
0 16 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
68 1
130 0
2
0 17 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
68 1
131 0
2
0 18 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
68 1
132 0
2
0 19 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
68 1
133 0
2
0 20 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut31
3
0 0
68 1
134 0
2
0 21 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut32
3
0 0
68 1
135 0
2
0 22 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut33
3
0 0
68 1
136 0
2
0 23 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut34
3
0 0
68 1
137 0
2
0 24 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut35
3
0 0
68 1
138 0
2
0 25 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut36
3
0 0
68 1
139 0
2
0 26 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut37
3
0 0
68 1
140 0
2
0 27 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut38
3
0 0
68 1
141 0
2
0 28 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut39
3
0 0
68 1
142 0
2
0 29 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
68 1
143 0
2
0 30 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
68 1
144 0
2
0 31 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
68 1
145 0
2
0 32 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
68 1
146 0
2
0 33 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
68 1
147 0
2
0 34 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
68 1
149 0
2
0 35 0 1
0 181 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
69 1
110 0
2
0 106 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
69 1
111 0
2
0 107 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
69 1
112 0
2
0 108 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
69 1
113 0
2
0 109 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
69 1
114 0
2
0 1 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
69 1
115 0
2
0 2 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
69 1
116 0
2
0 3 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
69 1
117 0
2
0 4 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
69 1
118 0
2
0 5 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
69 1
119 0
2
0 6 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
69 1
120 0
2
0 7 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
69 1
121 0
2
0 8 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
69 1
122 0
2
0 9 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
69 1
123 0
2
0 10 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
69 1
124 0
2
0 11 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
69 1
125 0
2
0 12 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
69 1
126 0
2
0 13 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
69 1
127 0
2
0 14 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
69 1
128 0
2
0 15 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
69 1
129 0
2
0 16 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
69 1
130 0
2
0 17 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
69 1
131 0
2
0 18 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
69 1
132 0
2
0 19 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
69 1
133 0
2
0 20 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut31
3
0 0
69 1
134 0
2
0 21 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut32
3
0 0
69 1
135 0
2
0 22 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut33
3
0 0
69 1
136 0
2
0 23 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut34
3
0 0
69 1
137 0
2
0 24 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut35
3
0 0
69 1
138 0
2
0 25 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut36
3
0 0
69 1
139 0
2
0 26 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut37
3
0 0
69 1
140 0
2
0 27 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut38
3
0 0
69 1
141 0
2
0 28 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut39
3
0 0
69 1
142 0
2
0 29 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
69 1
143 0
2
0 30 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
69 1
144 0
2
0 31 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
69 1
145 0
2
0 32 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
69 1
146 0
2
0 33 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
69 1
147 0
2
0 34 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
69 1
149 0
2
0 35 0 1
0 182 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
70 1
110 0
2
0 106 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
70 1
111 0
2
0 107 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
70 1
112 0
2
0 108 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
70 1
113 0
2
0 109 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
70 1
114 0
2
0 1 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
70 1
115 0
2
0 2 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
70 1
116 0
2
0 3 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
70 1
117 0
2
0 4 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
70 1
118 0
2
0 5 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
70 1
119 0
2
0 6 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
70 1
120 0
2
0 7 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
70 1
121 0
2
0 8 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
70 1
122 0
2
0 9 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
70 1
123 0
2
0 10 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
70 1
124 0
2
0 11 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
70 1
125 0
2
0 12 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
70 1
126 0
2
0 13 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
70 1
127 0
2
0 14 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
70 1
128 0
2
0 15 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
70 1
129 0
2
0 16 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
70 1
130 0
2
0 17 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
70 1
131 0
2
0 18 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
70 1
132 0
2
0 19 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
70 1
133 0
2
0 20 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut31
3
0 0
70 1
134 0
2
0 21 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut32
3
0 0
70 1
135 0
2
0 22 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut33
3
0 0
70 1
136 0
2
0 23 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut34
3
0 0
70 1
137 0
2
0 24 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut35
3
0 0
70 1
138 0
2
0 25 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut36
3
0 0
70 1
139 0
2
0 26 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut37
3
0 0
70 1
140 0
2
0 27 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut38
3
0 0
70 1
141 0
2
0 28 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut39
3
0 0
70 1
142 0
2
0 29 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
70 1
143 0
2
0 30 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
70 1
144 0
2
0 31 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
70 1
145 0
2
0 32 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
70 1
146 0
2
0 33 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
70 1
147 0
2
0 34 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
70 1
149 0
2
0 35 0 1
0 183 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
71 1
110 0
2
0 106 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
71 1
111 0
2
0 107 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
71 1
112 0
2
0 108 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
71 1
113 0
2
0 109 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
71 1
114 0
2
0 1 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
71 1
115 0
2
0 2 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
71 1
116 0
2
0 3 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
71 1
117 0
2
0 4 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
71 1
118 0
2
0 5 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
71 1
119 0
2
0 6 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
71 1
120 0
2
0 7 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
71 1
121 0
2
0 8 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
71 1
122 0
2
0 9 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
71 1
123 0
2
0 10 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
71 1
124 0
2
0 11 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
71 1
125 0
2
0 12 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
71 1
126 0
2
0 13 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
71 1
127 0
2
0 14 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
71 1
128 0
2
0 15 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
71 1
129 0
2
0 16 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
71 1
130 0
2
0 17 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
71 1
131 0
2
0 18 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
71 1
132 0
2
0 19 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
71 1
133 0
2
0 20 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut31
3
0 0
71 1
134 0
2
0 21 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut32
3
0 0
71 1
135 0
2
0 22 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut33
3
0 0
71 1
136 0
2
0 23 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut34
3
0 0
71 1
137 0
2
0 24 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut35
3
0 0
71 1
138 0
2
0 25 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut36
3
0 0
71 1
139 0
2
0 26 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut37
3
0 0
71 1
140 0
2
0 27 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut38
3
0 0
71 1
141 0
2
0 28 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut39
3
0 0
71 1
142 0
2
0 29 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
71 1
143 0
2
0 30 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
71 1
144 0
2
0 31 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
71 1
145 0
2
0 32 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
71 1
146 0
2
0 33 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
71 1
147 0
2
0 34 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
71 1
149 0
2
0 35 0 1
0 184 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
72 1
110 0
2
0 106 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
72 1
111 0
2
0 107 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
72 1
112 0
2
0 108 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
72 1
113 0
2
0 109 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
72 1
114 0
2
0 1 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
72 1
115 0
2
0 2 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
72 1
116 0
2
0 3 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
72 1
117 0
2
0 4 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
72 1
118 0
2
0 5 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
72 1
119 0
2
0 6 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
72 1
120 0
2
0 7 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
72 1
121 0
2
0 8 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
72 1
122 0
2
0 9 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
72 1
123 0
2
0 10 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
72 1
124 0
2
0 11 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
72 1
125 0
2
0 12 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
72 1
126 0
2
0 13 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
72 1
127 0
2
0 14 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
72 1
128 0
2
0 15 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
72 1
129 0
2
0 16 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
72 1
130 0
2
0 17 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
72 1
131 0
2
0 18 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
72 1
132 0
2
0 19 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
72 1
133 0
2
0 20 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut31
3
0 0
72 1
134 0
2
0 21 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut32
3
0 0
72 1
135 0
2
0 22 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut33
3
0 0
72 1
136 0
2
0 23 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut34
3
0 0
72 1
137 0
2
0 24 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut35
3
0 0
72 1
138 0
2
0 25 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut36
3
0 0
72 1
139 0
2
0 26 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut37
3
0 0
72 1
140 0
2
0 27 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut38
3
0 0
72 1
141 0
2
0 28 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut39
3
0 0
72 1
142 0
2
0 29 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
72 1
143 0
2
0 30 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
72 1
144 0
2
0 31 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
72 1
145 0
2
0 32 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
72 1
146 0
2
0 33 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
72 1
147 0
2
0 34 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
72 1
149 0
2
0 35 0 1
0 185 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
73 1
110 0
2
0 106 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
73 1
111 0
2
0 107 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
73 1
112 0
2
0 108 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
73 1
113 0
2
0 109 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
73 1
114 0
2
0 1 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
73 1
115 0
2
0 2 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
73 1
116 0
2
0 3 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
73 1
117 0
2
0 4 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
73 1
118 0
2
0 5 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
73 1
119 0
2
0 6 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
73 1
120 0
2
0 7 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
73 1
121 0
2
0 8 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
73 1
122 0
2
0 9 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
73 1
123 0
2
0 10 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
73 1
124 0
2
0 11 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
73 1
125 0
2
0 12 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
73 1
126 0
2
0 13 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
73 1
127 0
2
0 14 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
73 1
128 0
2
0 15 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
73 1
129 0
2
0 16 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
73 1
130 0
2
0 17 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
73 1
131 0
2
0 18 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
73 1
132 0
2
0 19 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
73 1
133 0
2
0 20 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut31
3
0 0
73 1
134 0
2
0 21 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut32
3
0 0
73 1
135 0
2
0 22 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut33
3
0 0
73 1
136 0
2
0 23 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut34
3
0 0
73 1
137 0
2
0 24 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut35
3
0 0
73 1
138 0
2
0 25 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut36
3
0 0
73 1
139 0
2
0 26 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut37
3
0 0
73 1
140 0
2
0 27 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut38
3
0 0
73 1
141 0
2
0 28 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut39
3
0 0
73 1
142 0
2
0 29 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
73 1
143 0
2
0 30 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
73 1
144 0
2
0 31 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
73 1
145 0
2
0 32 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
73 1
146 0
2
0 33 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
73 1
147 0
2
0 34 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
73 1
149 0
2
0 35 0 1
0 186 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
74 1
110 0
2
0 106 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
74 1
111 0
2
0 107 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
74 1
112 0
2
0 108 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
74 1
113 0
2
0 109 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
74 1
114 0
2
0 1 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
74 1
115 0
2
0 2 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
74 1
116 0
2
0 3 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
74 1
117 0
2
0 4 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
74 1
118 0
2
0 5 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
74 1
119 0
2
0 6 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
74 1
120 0
2
0 7 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
74 1
121 0
2
0 8 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
74 1
122 0
2
0 9 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
74 1
123 0
2
0 10 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
74 1
124 0
2
0 11 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
74 1
125 0
2
0 12 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
74 1
126 0
2
0 13 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
74 1
127 0
2
0 14 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
74 1
128 0
2
0 15 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
74 1
129 0
2
0 16 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
74 1
130 0
2
0 17 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
74 1
131 0
2
0 18 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
74 1
132 0
2
0 19 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
74 1
133 0
2
0 20 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut31
3
0 0
74 1
134 0
2
0 21 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut32
3
0 0
74 1
135 0
2
0 22 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut33
3
0 0
74 1
136 0
2
0 23 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut34
3
0 0
74 1
137 0
2
0 24 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut35
3
0 0
74 1
138 0
2
0 25 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut36
3
0 0
74 1
139 0
2
0 26 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut37
3
0 0
74 1
140 0
2
0 27 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut38
3
0 0
74 1
141 0
2
0 28 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut39
3
0 0
74 1
142 0
2
0 29 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
74 1
143 0
2
0 30 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
74 1
144 0
2
0 31 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
74 1
145 0
2
0 32 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
74 1
146 0
2
0 33 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
74 1
147 0
2
0 34 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
74 1
149 0
2
0 35 0 1
0 187 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
75 1
110 0
2
0 106 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
75 1
111 0
2
0 107 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
75 1
112 0
2
0 108 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
75 1
113 0
2
0 109 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
75 1
114 0
2
0 1 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
75 1
115 0
2
0 2 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
75 1
116 0
2
0 3 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
75 1
117 0
2
0 4 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
75 1
118 0
2
0 5 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
75 1
119 0
2
0 6 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
75 1
120 0
2
0 7 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
75 1
121 0
2
0 8 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
75 1
122 0
2
0 9 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
75 1
123 0
2
0 10 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
75 1
124 0
2
0 11 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
75 1
125 0
2
0 12 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
75 1
126 0
2
0 13 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
75 1
127 0
2
0 14 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
75 1
128 0
2
0 15 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
75 1
129 0
2
0 16 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
75 1
130 0
2
0 17 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
75 1
131 0
2
0 18 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
75 1
132 0
2
0 19 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
75 1
133 0
2
0 20 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut31
3
0 0
75 1
134 0
2
0 21 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut32
3
0 0
75 1
135 0
2
0 22 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut33
3
0 0
75 1
136 0
2
0 23 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut34
3
0 0
75 1
137 0
2
0 24 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut35
3
0 0
75 1
138 0
2
0 25 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut36
3
0 0
75 1
139 0
2
0 26 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut37
3
0 0
75 1
140 0
2
0 27 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut38
3
0 0
75 1
141 0
2
0 28 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut39
3
0 0
75 1
142 0
2
0 29 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
75 1
143 0
2
0 30 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
75 1
144 0
2
0 31 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
75 1
145 0
2
0 32 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
75 1
146 0
2
0 33 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
75 1
147 0
2
0 34 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
75 1
149 0
2
0 35 0 1
0 188 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
76 1
110 0
2
0 106 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
76 1
111 0
2
0 107 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
76 1
112 0
2
0 108 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
76 1
113 0
2
0 109 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
76 1
114 0
2
0 1 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
76 1
115 0
2
0 2 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
76 1
116 0
2
0 3 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
76 1
117 0
2
0 4 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
76 1
118 0
2
0 5 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
76 1
119 0
2
0 6 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
76 1
120 0
2
0 7 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
76 1
121 0
2
0 8 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
76 1
122 0
2
0 9 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
76 1
123 0
2
0 10 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
76 1
124 0
2
0 11 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
76 1
125 0
2
0 12 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
76 1
126 0
2
0 13 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
76 1
127 0
2
0 14 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
76 1
128 0
2
0 15 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
76 1
129 0
2
0 16 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
76 1
130 0
2
0 17 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
76 1
131 0
2
0 18 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
76 1
132 0
2
0 19 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
76 1
133 0
2
0 20 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut31
3
0 0
76 1
134 0
2
0 21 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut32
3
0 0
76 1
135 0
2
0 22 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut33
3
0 0
76 1
136 0
2
0 23 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut34
3
0 0
76 1
137 0
2
0 24 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut35
3
0 0
76 1
138 0
2
0 25 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut36
3
0 0
76 1
139 0
2
0 26 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut37
3
0 0
76 1
140 0
2
0 27 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut38
3
0 0
76 1
141 0
2
0 28 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut39
3
0 0
76 1
142 0
2
0 29 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
76 1
143 0
2
0 30 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
76 1
144 0
2
0 31 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
76 1
145 0
2
0 32 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
76 1
146 0
2
0 33 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
76 1
147 0
2
0 34 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
76 1
149 0
2
0 35 0 1
0 189 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
77 1
110 0
2
0 106 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
77 1
111 0
2
0 107 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
77 1
112 0
2
0 108 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
77 1
113 0
2
0 109 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
77 1
114 0
2
0 1 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
77 1
115 0
2
0 2 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
77 1
116 0
2
0 3 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
77 1
117 0
2
0 4 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
77 1
118 0
2
0 5 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
77 1
119 0
2
0 6 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
77 1
120 0
2
0 7 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
77 1
121 0
2
0 8 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
77 1
122 0
2
0 9 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
77 1
123 0
2
0 10 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
77 1
124 0
2
0 11 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
77 1
125 0
2
0 12 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
77 1
126 0
2
0 13 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
77 1
127 0
2
0 14 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
77 1
128 0
2
0 15 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
77 1
129 0
2
0 16 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
77 1
130 0
2
0 17 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
77 1
131 0
2
0 18 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
77 1
132 0
2
0 19 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
77 1
133 0
2
0 20 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut31
3
0 0
77 1
134 0
2
0 21 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut32
3
0 0
77 1
135 0
2
0 22 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut33
3
0 0
77 1
136 0
2
0 23 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut34
3
0 0
77 1
137 0
2
0 24 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut35
3
0 0
77 1
138 0
2
0 25 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut36
3
0 0
77 1
139 0
2
0 26 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut37
3
0 0
77 1
140 0
2
0 27 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut38
3
0 0
77 1
141 0
2
0 28 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut39
3
0 0
77 1
142 0
2
0 29 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
77 1
143 0
2
0 30 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
77 1
144 0
2
0 31 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
77 1
145 0
2
0 32 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
77 1
146 0
2
0 33 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
77 1
147 0
2
0 34 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
77 1
149 0
2
0 35 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
78 1
110 0
2
0 106 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
78 1
111 0
2
0 107 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
78 1
112 0
2
0 108 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
78 1
113 0
2
0 109 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
78 1
114 0
2
0 1 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
78 1
115 0
2
0 2 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
78 1
116 0
2
0 3 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
78 1
117 0
2
0 4 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
78 1
118 0
2
0 5 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
78 1
119 0
2
0 6 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
78 1
120 0
2
0 7 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
78 1
121 0
2
0 8 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
78 1
122 0
2
0 9 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
78 1
123 0
2
0 10 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
78 1
124 0
2
0 11 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
78 1
125 0
2
0 12 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
78 1
126 0
2
0 13 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
78 1
127 0
2
0 14 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
78 1
128 0
2
0 15 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
78 1
129 0
2
0 16 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
78 1
130 0
2
0 17 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
78 1
131 0
2
0 18 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
78 1
132 0
2
0 19 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
78 1
133 0
2
0 20 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut31
3
0 0
78 1
134 0
2
0 21 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut32
3
0 0
78 1
135 0
2
0 22 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut33
3
0 0
78 1
136 0
2
0 23 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut34
3
0 0
78 1
137 0
2
0 24 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut35
3
0 0
78 1
138 0
2
0 25 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut36
3
0 0
78 1
139 0
2
0 26 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut37
3
0 0
78 1
140 0
2
0 27 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut38
3
0 0
78 1
141 0
2
0 28 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut39
3
0 0
78 1
142 0
2
0 29 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
78 1
143 0
2
0 30 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
78 1
144 0
2
0 31 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
78 1
145 0
2
0 32 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
78 1
146 0
2
0 33 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
78 1
147 0
2
0 34 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
78 1
149 0
2
0 35 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
79 1
110 0
2
0 106 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
79 1
111 0
2
0 107 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
79 1
112 0
2
0 108 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
79 1
113 0
2
0 109 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
79 1
114 0
2
0 1 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
79 1
115 0
2
0 2 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
79 1
116 0
2
0 3 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
79 1
117 0
2
0 4 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
79 1
118 0
2
0 5 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
79 1
119 0
2
0 6 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
79 1
120 0
2
0 7 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
79 1
121 0
2
0 8 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
79 1
122 0
2
0 9 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
79 1
123 0
2
0 10 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
79 1
124 0
2
0 11 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
79 1
125 0
2
0 12 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
79 1
126 0
2
0 13 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
79 1
127 0
2
0 14 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
79 1
128 0
2
0 15 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
79 1
129 0
2
0 16 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
79 1
130 0
2
0 17 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
79 1
131 0
2
0 18 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
79 1
132 0
2
0 19 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
79 1
133 0
2
0 20 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut31
3
0 0
79 1
134 0
2
0 21 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut32
3
0 0
79 1
135 0
2
0 22 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut33
3
0 0
79 1
136 0
2
0 23 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut34
3
0 0
79 1
137 0
2
0 24 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut35
3
0 0
79 1
138 0
2
0 25 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut36
3
0 0
79 1
139 0
2
0 26 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut37
3
0 0
79 1
140 0
2
0 27 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut38
3
0 0
79 1
141 0
2
0 28 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut39
3
0 0
79 1
142 0
2
0 29 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
79 1
143 0
2
0 30 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
79 1
144 0
2
0 31 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
79 1
145 0
2
0 32 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
79 1
146 0
2
0 33 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
79 1
147 0
2
0 34 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
79 1
149 0
2
0 35 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
80 1
110 0
2
0 106 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
80 1
111 0
2
0 107 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
80 1
112 0
2
0 108 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
80 1
113 0
2
0 109 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
80 1
114 0
2
0 1 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
80 1
115 0
2
0 2 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
80 1
116 0
2
0 3 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
80 1
117 0
2
0 4 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
80 1
118 0
2
0 5 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
80 1
119 0
2
0 6 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
80 1
120 0
2
0 7 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
80 1
121 0
2
0 8 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
80 1
122 0
2
0 9 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
80 1
123 0
2
0 10 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
80 1
124 0
2
0 11 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
80 1
125 0
2
0 12 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
80 1
126 0
2
0 13 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
80 1
127 0
2
0 14 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
80 1
128 0
2
0 15 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
80 1
129 0
2
0 16 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
80 1
130 0
2
0 17 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
80 1
131 0
2
0 18 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
80 1
132 0
2
0 19 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
80 1
133 0
2
0 20 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut31
3
0 0
80 1
134 0
2
0 21 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut32
3
0 0
80 1
135 0
2
0 22 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut33
3
0 0
80 1
136 0
2
0 23 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut34
3
0 0
80 1
137 0
2
0 24 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut35
3
0 0
80 1
138 0
2
0 25 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut36
3
0 0
80 1
139 0
2
0 26 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut37
3
0 0
80 1
140 0
2
0 27 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut38
3
0 0
80 1
141 0
2
0 28 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut39
3
0 0
80 1
142 0
2
0 29 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
80 1
143 0
2
0 30 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
80 1
144 0
2
0 31 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
80 1
145 0
2
0 32 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
80 1
146 0
2
0 33 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
80 1
147 0
2
0 34 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
80 1
149 0
2
0 35 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
81 1
110 0
2
0 106 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
81 1
111 0
2
0 107 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
81 1
112 0
2
0 108 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
81 1
113 0
2
0 109 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
81 1
114 0
2
0 1 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
81 1
115 0
2
0 2 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
81 1
116 0
2
0 3 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
81 1
117 0
2
0 4 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
81 1
118 0
2
0 5 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
81 1
119 0
2
0 6 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
81 1
120 0
2
0 7 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
81 1
121 0
2
0 8 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
81 1
122 0
2
0 9 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
81 1
123 0
2
0 10 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
81 1
124 0
2
0 11 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
81 1
125 0
2
0 12 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
81 1
126 0
2
0 13 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
81 1
127 0
2
0 14 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
81 1
128 0
2
0 15 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
81 1
129 0
2
0 16 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
81 1
130 0
2
0 17 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
81 1
131 0
2
0 18 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
81 1
132 0
2
0 19 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
81 1
133 0
2
0 20 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut31
3
0 0
81 1
134 0
2
0 21 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut32
3
0 0
81 1
135 0
2
0 22 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut33
3
0 0
81 1
136 0
2
0 23 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut34
3
0 0
81 1
137 0
2
0 24 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut35
3
0 0
81 1
138 0
2
0 25 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut36
3
0 0
81 1
139 0
2
0 26 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut37
3
0 0
81 1
140 0
2
0 27 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut38
3
0 0
81 1
141 0
2
0 28 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut39
3
0 0
81 1
142 0
2
0 29 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
81 1
143 0
2
0 30 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
81 1
144 0
2
0 31 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
81 1
145 0
2
0 32 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
81 1
146 0
2
0 33 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
81 1
147 0
2
0 34 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
81 1
149 0
2
0 35 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
82 1
110 0
2
0 106 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
82 1
111 0
2
0 107 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
82 1
112 0
2
0 108 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
82 1
113 0
2
0 109 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
82 1
114 0
2
0 1 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
82 1
115 0
2
0 2 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
82 1
116 0
2
0 3 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
82 1
117 0
2
0 4 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
82 1
118 0
2
0 5 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
82 1
119 0
2
0 6 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
82 1
120 0
2
0 7 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
82 1
121 0
2
0 8 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
82 1
122 0
2
0 9 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
82 1
123 0
2
0 10 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
82 1
124 0
2
0 11 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
82 1
125 0
2
0 12 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
82 1
126 0
2
0 13 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
82 1
127 0
2
0 14 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
82 1
128 0
2
0 15 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
82 1
129 0
2
0 16 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
82 1
130 0
2
0 17 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
82 1
131 0
2
0 18 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
82 1
132 0
2
0 19 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
82 1
133 0
2
0 20 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut31
3
0 0
82 1
134 0
2
0 21 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut32
3
0 0
82 1
135 0
2
0 22 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut33
3
0 0
82 1
136 0
2
0 23 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut34
3
0 0
82 1
137 0
2
0 24 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut35
3
0 0
82 1
138 0
2
0 25 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut36
3
0 0
82 1
139 0
2
0 26 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut37
3
0 0
82 1
140 0
2
0 27 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut38
3
0 0
82 1
141 0
2
0 28 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut39
3
0 0
82 1
142 0
2
0 29 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
82 1
143 0
2
0 30 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
82 1
144 0
2
0 31 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
82 1
145 0
2
0 32 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
82 1
146 0
2
0 33 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
82 1
147 0
2
0 34 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
82 1
149 0
2
0 35 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
83 1
110 0
2
0 106 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
83 1
111 0
2
0 107 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
83 1
112 0
2
0 108 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
83 1
113 0
2
0 109 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
83 1
114 0
2
0 1 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
83 1
115 0
2
0 2 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
83 1
116 0
2
0 3 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
83 1
117 0
2
0 4 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
83 1
118 0
2
0 5 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
83 1
119 0
2
0 6 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
83 1
120 0
2
0 7 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
83 1
121 0
2
0 8 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
83 1
122 0
2
0 9 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
83 1
123 0
2
0 10 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
83 1
124 0
2
0 11 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
83 1
125 0
2
0 12 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
83 1
126 0
2
0 13 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
83 1
127 0
2
0 14 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
83 1
128 0
2
0 15 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
83 1
129 0
2
0 16 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
83 1
130 0
2
0 17 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
83 1
131 0
2
0 18 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
83 1
132 0
2
0 19 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
83 1
133 0
2
0 20 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut31
3
0 0
83 1
134 0
2
0 21 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut32
3
0 0
83 1
135 0
2
0 22 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut33
3
0 0
83 1
136 0
2
0 23 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut34
3
0 0
83 1
137 0
2
0 24 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut35
3
0 0
83 1
138 0
2
0 25 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut36
3
0 0
83 1
139 0
2
0 26 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut37
3
0 0
83 1
140 0
2
0 27 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut38
3
0 0
83 1
141 0
2
0 28 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut39
3
0 0
83 1
142 0
2
0 29 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
83 1
143 0
2
0 30 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
83 1
144 0
2
0 31 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
83 1
145 0
2
0 32 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
83 1
146 0
2
0 33 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
83 1
147 0
2
0 34 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
83 1
149 0
2
0 35 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
84 1
110 0
2
0 106 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
84 1
111 0
2
0 107 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
84 1
112 0
2
0 108 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
84 1
113 0
2
0 109 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
84 1
114 0
2
0 1 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
84 1
115 0
2
0 2 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
84 1
116 0
2
0 3 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
84 1
117 0
2
0 4 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
84 1
118 0
2
0 5 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
84 1
119 0
2
0 6 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
84 1
120 0
2
0 7 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
84 1
121 0
2
0 8 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
84 1
122 0
2
0 9 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
84 1
123 0
2
0 10 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
84 1
124 0
2
0 11 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
84 1
125 0
2
0 12 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
84 1
126 0
2
0 13 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
84 1
127 0
2
0 14 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
84 1
128 0
2
0 15 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
84 1
129 0
2
0 16 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
84 1
130 0
2
0 17 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
84 1
131 0
2
0 18 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
84 1
132 0
2
0 19 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
84 1
133 0
2
0 20 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut31
3
0 0
84 1
134 0
2
0 21 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut32
3
0 0
84 1
135 0
2
0 22 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut33
3
0 0
84 1
136 0
2
0 23 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut34
3
0 0
84 1
137 0
2
0 24 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut35
3
0 0
84 1
138 0
2
0 25 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut36
3
0 0
84 1
139 0
2
0 26 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut37
3
0 0
84 1
140 0
2
0 27 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut38
3
0 0
84 1
141 0
2
0 28 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut39
3
0 0
84 1
142 0
2
0 29 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
84 1
143 0
2
0 30 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
84 1
144 0
2
0 31 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
84 1
145 0
2
0 32 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
84 1
146 0
2
0 33 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
84 1
147 0
2
0 34 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
84 1
149 0
2
0 35 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
85 1
110 0
2
0 106 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
85 1
111 0
2
0 107 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
85 1
112 0
2
0 108 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
85 1
113 0
2
0 109 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
85 1
114 0
2
0 1 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
85 1
115 0
2
0 2 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
85 1
116 0
2
0 3 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
85 1
117 0
2
0 4 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
85 1
118 0
2
0 5 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
85 1
119 0
2
0 6 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
85 1
120 0
2
0 7 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
85 1
121 0
2
0 8 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
85 1
122 0
2
0 9 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
85 1
123 0
2
0 10 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
85 1
124 0
2
0 11 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
85 1
125 0
2
0 12 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
85 1
126 0
2
0 13 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
85 1
127 0
2
0 14 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
85 1
128 0
2
0 15 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
85 1
129 0
2
0 16 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
85 1
130 0
2
0 17 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
85 1
131 0
2
0 18 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
85 1
132 0
2
0 19 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
85 1
133 0
2
0 20 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut31
3
0 0
85 1
134 0
2
0 21 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut32
3
0 0
85 1
135 0
2
0 22 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut33
3
0 0
85 1
136 0
2
0 23 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut34
3
0 0
85 1
137 0
2
0 24 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut35
3
0 0
85 1
138 0
2
0 25 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut36
3
0 0
85 1
139 0
2
0 26 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut37
3
0 0
85 1
140 0
2
0 27 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut38
3
0 0
85 1
141 0
2
0 28 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut39
3
0 0
85 1
142 0
2
0 29 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
85 1
143 0
2
0 30 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
85 1
144 0
2
0 31 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
85 1
145 0
2
0 32 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
85 1
146 0
2
0 33 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
85 1
147 0
2
0 34 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
85 1
149 0
2
0 35 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
86 1
110 0
2
0 106 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
86 1
111 0
2
0 107 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
86 1
112 0
2
0 108 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
86 1
113 0
2
0 109 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
86 1
114 0
2
0 1 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
86 1
115 0
2
0 2 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
86 1
116 0
2
0 3 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
86 1
117 0
2
0 4 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
86 1
118 0
2
0 5 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
86 1
119 0
2
0 6 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
86 1
120 0
2
0 7 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
86 1
121 0
2
0 8 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
86 1
122 0
2
0 9 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
86 1
123 0
2
0 10 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
86 1
124 0
2
0 11 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
86 1
125 0
2
0 12 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
86 1
126 0
2
0 13 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
86 1
127 0
2
0 14 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
86 1
128 0
2
0 15 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
86 1
129 0
2
0 16 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
86 1
130 0
2
0 17 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
86 1
131 0
2
0 18 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
86 1
132 0
2
0 19 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
86 1
133 0
2
0 20 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut31
3
0 0
86 1
134 0
2
0 21 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut32
3
0 0
86 1
135 0
2
0 22 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut33
3
0 0
86 1
136 0
2
0 23 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut34
3
0 0
86 1
137 0
2
0 24 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut35
3
0 0
86 1
138 0
2
0 25 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut36
3
0 0
86 1
139 0
2
0 26 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut37
3
0 0
86 1
140 0
2
0 27 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut38
3
0 0
86 1
141 0
2
0 28 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut39
3
0 0
86 1
142 0
2
0 29 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
86 1
143 0
2
0 30 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
86 1
144 0
2
0 31 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
86 1
145 0
2
0 32 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
86 1
146 0
2
0 33 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
86 1
147 0
2
0 34 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
86 1
149 0
2
0 35 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
87 1
110 0
2
0 106 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
87 1
111 0
2
0 107 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
87 1
112 0
2
0 108 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
87 1
113 0
2
0 109 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
87 1
114 0
2
0 1 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
87 1
115 0
2
0 2 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
87 1
116 0
2
0 3 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
87 1
117 0
2
0 4 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
87 1
118 0
2
0 5 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
87 1
119 0
2
0 6 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
87 1
120 0
2
0 7 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
87 1
121 0
2
0 8 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
87 1
122 0
2
0 9 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
87 1
123 0
2
0 10 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
87 1
124 0
2
0 11 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
87 1
125 0
2
0 12 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
87 1
126 0
2
0 13 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
87 1
127 0
2
0 14 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
87 1
128 0
2
0 15 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
87 1
129 0
2
0 16 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
87 1
130 0
2
0 17 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
87 1
131 0
2
0 18 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
87 1
132 0
2
0 19 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
87 1
133 0
2
0 20 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut31
3
0 0
87 1
134 0
2
0 21 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut32
3
0 0
87 1
135 0
2
0 22 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut33
3
0 0
87 1
136 0
2
0 23 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut34
3
0 0
87 1
137 0
2
0 24 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut35
3
0 0
87 1
138 0
2
0 25 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut36
3
0 0
87 1
139 0
2
0 26 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut37
3
0 0
87 1
140 0
2
0 27 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut38
3
0 0
87 1
141 0
2
0 28 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut39
3
0 0
87 1
142 0
2
0 29 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
87 1
143 0
2
0 30 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
87 1
144 0
2
0 31 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
87 1
145 0
2
0 32 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
87 1
146 0
2
0 33 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
87 1
147 0
2
0 34 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
87 1
149 0
2
0 35 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut1
3
0 0
88 1
110 0
2
0 106 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut10
3
0 0
88 1
111 0
2
0 107 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut11
3
0 0
88 1
112 0
2
0 108 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut12
3
0 0
88 1
113 0
2
0 109 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut13
3
0 0
88 1
114 0
2
0 1 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut14
3
0 0
88 1
115 0
2
0 2 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut15
3
0 0
88 1
116 0
2
0 3 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut16
3
0 0
88 1
117 0
2
0 4 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut17
3
0 0
88 1
118 0
2
0 5 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut18
3
0 0
88 1
119 0
2
0 6 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut19
3
0 0
88 1
120 0
2
0 7 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut2
3
0 0
88 1
121 0
2
0 8 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut20
3
0 0
88 1
122 0
2
0 9 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut21
3
0 0
88 1
123 0
2
0 10 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut22
3
0 0
88 1
124 0
2
0 11 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut23
3
0 0
88 1
125 0
2
0 12 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut24
3
0 0
88 1
126 0
2
0 13 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut25
3
0 0
88 1
127 0
2
0 14 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut26
3
0 0
88 1
128 0
2
0 15 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut27
3
0 0
88 1
129 0
2
0 16 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut28
3
0 0
88 1
130 0
2
0 17 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut29
3
0 0
88 1
131 0
2
0 18 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut3
3
0 0
88 1
132 0
2
0 19 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut30
3
0 0
88 1
133 0
2
0 20 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut31
3
0 0
88 1
134 0
2
0 21 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut32
3
0 0
88 1
135 0
2
0 22 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut33
3
0 0
88 1
136 0
2
0 23 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut34
3
0 0
88 1
137 0
2
0 24 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut35
3
0 0
88 1
138 0
2
0 25 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut36
3
0 0
88 1
139 0
2
0 26 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut37
3
0 0
88 1
140 0
2
0 27 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut38
3
0 0
88 1
141 0
2
0 28 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut39
3
0 0
88 1
142 0
2
0 29 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut4
3
0 0
88 1
143 0
2
0 30 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut5
3
0 0
88 1
144 0
2
0 31 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut6
3
0 0
88 1
145 0
2
0 32 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut7
3
0 0
88 1
146 0
2
0 33 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut8
3
0 0
88 1
147 0
2
0 34 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut9
3
0 0
88 1
149 0
2
0 35 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut1
3
0 0
89 1
110 0
2
0 106 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut10
3
0 0
89 1
111 0
2
0 107 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut11
3
0 0
89 1
112 0
2
0 108 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut12
3
0 0
89 1
113 0
2
0 109 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut13
3
0 0
89 1
114 0
2
0 1 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut14
3
0 0
89 1
115 0
2
0 2 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut15
3
0 0
89 1
116 0
2
0 3 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut16
3
0 0
89 1
117 0
2
0 4 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut17
3
0 0
89 1
118 0
2
0 5 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut18
3
0 0
89 1
119 0
2
0 6 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut19
3
0 0
89 1
120 0
2
0 7 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut2
3
0 0
89 1
121 0
2
0 8 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut20
3
0 0
89 1
122 0
2
0 9 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut21
3
0 0
89 1
123 0
2
0 10 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut22
3
0 0
89 1
124 0
2
0 11 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut23
3
0 0
89 1
125 0
2
0 12 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut24
3
0 0
89 1
126 0
2
0 13 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut25
3
0 0
89 1
127 0
2
0 14 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut26
3
0 0
89 1
128 0
2
0 15 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut27
3
0 0
89 1
129 0
2
0 16 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut28
3
0 0
89 1
130 0
2
0 17 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut29
3
0 0
89 1
131 0
2
0 18 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut3
3
0 0
89 1
132 0
2
0 19 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut30
3
0 0
89 1
133 0
2
0 20 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut31
3
0 0
89 1
134 0
2
0 21 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut32
3
0 0
89 1
135 0
2
0 22 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut33
3
0 0
89 1
136 0
2
0 23 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut34
3
0 0
89 1
137 0
2
0 24 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut35
3
0 0
89 1
138 0
2
0 25 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut36
3
0 0
89 1
139 0
2
0 26 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut37
3
0 0
89 1
140 0
2
0 27 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut38
3
0 0
89 1
141 0
2
0 28 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut39
3
0 0
89 1
142 0
2
0 29 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut4
3
0 0
89 1
143 0
2
0 30 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut5
3
0 0
89 1
144 0
2
0 31 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut6
3
0 0
89 1
145 0
2
0 32 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut7
3
0 0
89 1
146 0
2
0 33 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut8
3
0 0
89 1
147 0
2
0 34 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut9
3
0 0
89 1
149 0
2
0 35 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut1
3
0 0
90 1
110 0
2
0 106 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut10
3
0 0
90 1
111 0
2
0 107 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut11
3
0 0
90 1
112 0
2
0 108 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut12
3
0 0
90 1
113 0
2
0 109 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut13
3
0 0
90 1
114 0
2
0 1 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut14
3
0 0
90 1
115 0
2
0 2 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut15
3
0 0
90 1
116 0
2
0 3 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut16
3
0 0
90 1
117 0
2
0 4 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut17
3
0 0
90 1
118 0
2
0 5 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut18
3
0 0
90 1
119 0
2
0 6 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut19
3
0 0
90 1
120 0
2
0 7 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut2
3
0 0
90 1
121 0
2
0 8 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut20
3
0 0
90 1
122 0
2
0 9 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut21
3
0 0
90 1
123 0
2
0 10 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut22
3
0 0
90 1
124 0
2
0 11 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut23
3
0 0
90 1
125 0
2
0 12 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut24
3
0 0
90 1
126 0
2
0 13 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut25
3
0 0
90 1
127 0
2
0 14 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut26
3
0 0
90 1
128 0
2
0 15 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut27
3
0 0
90 1
129 0
2
0 16 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut28
3
0 0
90 1
130 0
2
0 17 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut29
3
0 0
90 1
131 0
2
0 18 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut3
3
0 0
90 1
132 0
2
0 19 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut30
3
0 0
90 1
133 0
2
0 20 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut31
3
0 0
90 1
134 0
2
0 21 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut32
3
0 0
90 1
135 0
2
0 22 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut33
3
0 0
90 1
136 0
2
0 23 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut34
3
0 0
90 1
137 0
2
0 24 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut35
3
0 0
90 1
138 0
2
0 25 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut36
3
0 0
90 1
139 0
2
0 26 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut37
3
0 0
90 1
140 0
2
0 27 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut38
3
0 0
90 1
141 0
2
0 28 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut39
3
0 0
90 1
142 0
2
0 29 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut4
3
0 0
90 1
143 0
2
0 30 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut5
3
0 0
90 1
144 0
2
0 31 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut6
3
0 0
90 1
145 0
2
0 32 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut7
3
0 0
90 1
146 0
2
0 33 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut8
3
0 0
90 1
147 0
2
0 34 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut9
3
0 0
90 1
149 0
2
0 35 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
91 1
110 0
2
0 106 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
91 1
111 0
2
0 107 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
91 1
112 0
2
0 108 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
91 1
113 0
2
0 109 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
91 1
114 0
2
0 1 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
91 1
115 0
2
0 2 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
91 1
116 0
2
0 3 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
91 1
117 0
2
0 4 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
91 1
118 0
2
0 5 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
91 1
119 0
2
0 6 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
91 1
120 0
2
0 7 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
91 1
121 0
2
0 8 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
91 1
122 0
2
0 9 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
91 1
123 0
2
0 10 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
91 1
124 0
2
0 11 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
91 1
125 0
2
0 12 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
91 1
126 0
2
0 13 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
91 1
127 0
2
0 14 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
91 1
128 0
2
0 15 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
91 1
129 0
2
0 16 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
91 1
130 0
2
0 17 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
91 1
131 0
2
0 18 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
91 1
132 0
2
0 19 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
91 1
133 0
2
0 20 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut31
3
0 0
91 1
134 0
2
0 21 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut32
3
0 0
91 1
135 0
2
0 22 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut33
3
0 0
91 1
136 0
2
0 23 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut34
3
0 0
91 1
137 0
2
0 24 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut35
3
0 0
91 1
138 0
2
0 25 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut36
3
0 0
91 1
139 0
2
0 26 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut37
3
0 0
91 1
140 0
2
0 27 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut38
3
0 0
91 1
141 0
2
0 28 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut39
3
0 0
91 1
142 0
2
0 29 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
91 1
143 0
2
0 30 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
91 1
144 0
2
0 31 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
91 1
145 0
2
0 32 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
91 1
146 0
2
0 33 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
91 1
147 0
2
0 34 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
91 1
149 0
2
0 35 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut1
3
0 0
92 1
110 0
2
0 106 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut10
3
0 0
92 1
111 0
2
0 107 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut11
3
0 0
92 1
112 0
2
0 108 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut12
3
0 0
92 1
113 0
2
0 109 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut13
3
0 0
92 1
114 0
2
0 1 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut14
3
0 0
92 1
115 0
2
0 2 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut15
3
0 0
92 1
116 0
2
0 3 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut16
3
0 0
92 1
117 0
2
0 4 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut17
3
0 0
92 1
118 0
2
0 5 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut18
3
0 0
92 1
119 0
2
0 6 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut19
3
0 0
92 1
120 0
2
0 7 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut2
3
0 0
92 1
121 0
2
0 8 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut20
3
0 0
92 1
122 0
2
0 9 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut21
3
0 0
92 1
123 0
2
0 10 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut22
3
0 0
92 1
124 0
2
0 11 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut23
3
0 0
92 1
125 0
2
0 12 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut24
3
0 0
92 1
126 0
2
0 13 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut25
3
0 0
92 1
127 0
2
0 14 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut26
3
0 0
92 1
128 0
2
0 15 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut27
3
0 0
92 1
129 0
2
0 16 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut28
3
0 0
92 1
130 0
2
0 17 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut29
3
0 0
92 1
131 0
2
0 18 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut3
3
0 0
92 1
132 0
2
0 19 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut30
3
0 0
92 1
133 0
2
0 20 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut31
3
0 0
92 1
134 0
2
0 21 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut32
3
0 0
92 1
135 0
2
0 22 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut33
3
0 0
92 1
136 0
2
0 23 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut34
3
0 0
92 1
137 0
2
0 24 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut35
3
0 0
92 1
138 0
2
0 25 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut36
3
0 0
92 1
139 0
2
0 26 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut37
3
0 0
92 1
140 0
2
0 27 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut38
3
0 0
92 1
141 0
2
0 28 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut39
3
0 0
92 1
142 0
2
0 29 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut4
3
0 0
92 1
143 0
2
0 30 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut5
3
0 0
92 1
144 0
2
0 31 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut6
3
0 0
92 1
145 0
2
0 32 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut7
3
0 0
92 1
146 0
2
0 33 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut8
3
0 0
92 1
147 0
2
0 34 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut9
3
0 0
92 1
149 0
2
0 35 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut1
3
0 0
93 1
110 0
2
0 106 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut10
3
0 0
93 1
111 0
2
0 107 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut11
3
0 0
93 1
112 0
2
0 108 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut12
3
0 0
93 1
113 0
2
0 109 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut13
3
0 0
93 1
114 0
2
0 1 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut14
3
0 0
93 1
115 0
2
0 2 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut15
3
0 0
93 1
116 0
2
0 3 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut16
3
0 0
93 1
117 0
2
0 4 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut17
3
0 0
93 1
118 0
2
0 5 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut18
3
0 0
93 1
119 0
2
0 6 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut19
3
0 0
93 1
120 0
2
0 7 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut2
3
0 0
93 1
121 0
2
0 8 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut20
3
0 0
93 1
122 0
2
0 9 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut21
3
0 0
93 1
123 0
2
0 10 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut22
3
0 0
93 1
124 0
2
0 11 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut23
3
0 0
93 1
125 0
2
0 12 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut24
3
0 0
93 1
126 0
2
0 13 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut25
3
0 0
93 1
127 0
2
0 14 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut26
3
0 0
93 1
128 0
2
0 15 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut27
3
0 0
93 1
129 0
2
0 16 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut28
3
0 0
93 1
130 0
2
0 17 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut29
3
0 0
93 1
131 0
2
0 18 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut3
3
0 0
93 1
132 0
2
0 19 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut30
3
0 0
93 1
133 0
2
0 20 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut31
3
0 0
93 1
134 0
2
0 21 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut32
3
0 0
93 1
135 0
2
0 22 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut33
3
0 0
93 1
136 0
2
0 23 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut34
3
0 0
93 1
137 0
2
0 24 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut35
3
0 0
93 1
138 0
2
0 25 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut36
3
0 0
93 1
139 0
2
0 26 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut37
3
0 0
93 1
140 0
2
0 27 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut38
3
0 0
93 1
141 0
2
0 28 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut39
3
0 0
93 1
142 0
2
0 29 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut4
3
0 0
93 1
143 0
2
0 30 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut5
3
0 0
93 1
144 0
2
0 31 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut6
3
0 0
93 1
145 0
2
0 32 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut7
3
0 0
93 1
146 0
2
0 33 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut8
3
0 0
93 1
147 0
2
0 34 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut9
3
0 0
93 1
149 0
2
0 35 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut1
3
0 0
94 1
110 0
2
0 106 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut10
3
0 0
94 1
111 0
2
0 107 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut11
3
0 0
94 1
112 0
2
0 108 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut12
3
0 0
94 1
113 0
2
0 109 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut13
3
0 0
94 1
114 0
2
0 1 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut14
3
0 0
94 1
115 0
2
0 2 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut15
3
0 0
94 1
116 0
2
0 3 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut16
3
0 0
94 1
117 0
2
0 4 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut17
3
0 0
94 1
118 0
2
0 5 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut18
3
0 0
94 1
119 0
2
0 6 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut19
3
0 0
94 1
120 0
2
0 7 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut2
3
0 0
94 1
121 0
2
0 8 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut20
3
0 0
94 1
122 0
2
0 9 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut21
3
0 0
94 1
123 0
2
0 10 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut22
3
0 0
94 1
124 0
2
0 11 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut23
3
0 0
94 1
125 0
2
0 12 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut24
3
0 0
94 1
126 0
2
0 13 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut25
3
0 0
94 1
127 0
2
0 14 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut26
3
0 0
94 1
128 0
2
0 15 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut27
3
0 0
94 1
129 0
2
0 16 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut28
3
0 0
94 1
130 0
2
0 17 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut29
3
0 0
94 1
131 0
2
0 18 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut3
3
0 0
94 1
132 0
2
0 19 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut30
3
0 0
94 1
133 0
2
0 20 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut31
3
0 0
94 1
134 0
2
0 21 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut32
3
0 0
94 1
135 0
2
0 22 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut33
3
0 0
94 1
136 0
2
0 23 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut34
3
0 0
94 1
137 0
2
0 24 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut35
3
0 0
94 1
138 0
2
0 25 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut36
3
0 0
94 1
139 0
2
0 26 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut37
3
0 0
94 1
140 0
2
0 27 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut38
3
0 0
94 1
141 0
2
0 28 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut39
3
0 0
94 1
142 0
2
0 29 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut4
3
0 0
94 1
143 0
2
0 30 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut5
3
0 0
94 1
144 0
2
0 31 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut6
3
0 0
94 1
145 0
2
0 32 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut7
3
0 0
94 1
146 0
2
0 33 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut8
3
0 0
94 1
147 0
2
0 34 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut9
3
0 0
94 1
149 0
2
0 35 0 1
0 207 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut1
3
0 0
95 1
110 0
2
0 106 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut10
3
0 0
95 1
111 0
2
0 107 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut11
3
0 0
95 1
112 0
2
0 108 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut12
3
0 0
95 1
113 0
2
0 109 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut13
3
0 0
95 1
114 0
2
0 1 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut14
3
0 0
95 1
115 0
2
0 2 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut15
3
0 0
95 1
116 0
2
0 3 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut16
3
0 0
95 1
117 0
2
0 4 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut17
3
0 0
95 1
118 0
2
0 5 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut18
3
0 0
95 1
119 0
2
0 6 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut19
3
0 0
95 1
120 0
2
0 7 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut2
3
0 0
95 1
121 0
2
0 8 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut20
3
0 0
95 1
122 0
2
0 9 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut21
3
0 0
95 1
123 0
2
0 10 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut22
3
0 0
95 1
124 0
2
0 11 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut23
3
0 0
95 1
125 0
2
0 12 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut24
3
0 0
95 1
126 0
2
0 13 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut25
3
0 0
95 1
127 0
2
0 14 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut26
3
0 0
95 1
128 0
2
0 15 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut27
3
0 0
95 1
129 0
2
0 16 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut28
3
0 0
95 1
130 0
2
0 17 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut29
3
0 0
95 1
131 0
2
0 18 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut3
3
0 0
95 1
132 0
2
0 19 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut30
3
0 0
95 1
133 0
2
0 20 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut31
3
0 0
95 1
134 0
2
0 21 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut32
3
0 0
95 1
135 0
2
0 22 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut33
3
0 0
95 1
136 0
2
0 23 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut34
3
0 0
95 1
137 0
2
0 24 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut35
3
0 0
95 1
138 0
2
0 25 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut36
3
0 0
95 1
139 0
2
0 26 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut37
3
0 0
95 1
140 0
2
0 27 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut38
3
0 0
95 1
141 0
2
0 28 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut39
3
0 0
95 1
142 0
2
0 29 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut4
3
0 0
95 1
143 0
2
0 30 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut5
3
0 0
95 1
144 0
2
0 31 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut6
3
0 0
95 1
145 0
2
0 32 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut7
3
0 0
95 1
146 0
2
0 33 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut8
3
0 0
95 1
147 0
2
0 34 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut9
3
0 0
95 1
149 0
2
0 35 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut1
3
0 0
96 1
110 0
2
0 106 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut10
3
0 0
96 1
111 0
2
0 107 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut11
3
0 0
96 1
112 0
2
0 108 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut12
3
0 0
96 1
113 0
2
0 109 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut13
3
0 0
96 1
114 0
2
0 1 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut14
3
0 0
96 1
115 0
2
0 2 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut15
3
0 0
96 1
116 0
2
0 3 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut16
3
0 0
96 1
117 0
2
0 4 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut17
3
0 0
96 1
118 0
2
0 5 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut18
3
0 0
96 1
119 0
2
0 6 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut19
3
0 0
96 1
120 0
2
0 7 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut2
3
0 0
96 1
121 0
2
0 8 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut20
3
0 0
96 1
122 0
2
0 9 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut21
3
0 0
96 1
123 0
2
0 10 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut22
3
0 0
96 1
124 0
2
0 11 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut23
3
0 0
96 1
125 0
2
0 12 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut24
3
0 0
96 1
126 0
2
0 13 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut25
3
0 0
96 1
127 0
2
0 14 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut26
3
0 0
96 1
128 0
2
0 15 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut27
3
0 0
96 1
129 0
2
0 16 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut28
3
0 0
96 1
130 0
2
0 17 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut29
3
0 0
96 1
131 0
2
0 18 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut3
3
0 0
96 1
132 0
2
0 19 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut30
3
0 0
96 1
133 0
2
0 20 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut31
3
0 0
96 1
134 0
2
0 21 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut32
3
0 0
96 1
135 0
2
0 22 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut33
3
0 0
96 1
136 0
2
0 23 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut34
3
0 0
96 1
137 0
2
0 24 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut35
3
0 0
96 1
138 0
2
0 25 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut36
3
0 0
96 1
139 0
2
0 26 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut37
3
0 0
96 1
140 0
2
0 27 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut38
3
0 0
96 1
141 0
2
0 28 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut39
3
0 0
96 1
142 0
2
0 29 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut4
3
0 0
96 1
143 0
2
0 30 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut5
3
0 0
96 1
144 0
2
0 31 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut6
3
0 0
96 1
145 0
2
0 32 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut7
3
0 0
96 1
146 0
2
0 33 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut8
3
0 0
96 1
147 0
2
0 34 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut9
3
0 0
96 1
149 0
2
0 35 0 1
0 209 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut1
3
0 0
97 1
110 0
2
0 106 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut10
3
0 0
97 1
111 0
2
0 107 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut11
3
0 0
97 1
112 0
2
0 108 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut12
3
0 0
97 1
113 0
2
0 109 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut13
3
0 0
97 1
114 0
2
0 1 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut14
3
0 0
97 1
115 0
2
0 2 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut15
3
0 0
97 1
116 0
2
0 3 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut16
3
0 0
97 1
117 0
2
0 4 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut17
3
0 0
97 1
118 0
2
0 5 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut18
3
0 0
97 1
119 0
2
0 6 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut19
3
0 0
97 1
120 0
2
0 7 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut2
3
0 0
97 1
121 0
2
0 8 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut20
3
0 0
97 1
122 0
2
0 9 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut21
3
0 0
97 1
123 0
2
0 10 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut22
3
0 0
97 1
124 0
2
0 11 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut23
3
0 0
97 1
125 0
2
0 12 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut24
3
0 0
97 1
126 0
2
0 13 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut25
3
0 0
97 1
127 0
2
0 14 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut26
3
0 0
97 1
128 0
2
0 15 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut27
3
0 0
97 1
129 0
2
0 16 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut28
3
0 0
97 1
130 0
2
0 17 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut29
3
0 0
97 1
131 0
2
0 18 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut3
3
0 0
97 1
132 0
2
0 19 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut30
3
0 0
97 1
133 0
2
0 20 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut31
3
0 0
97 1
134 0
2
0 21 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut32
3
0 0
97 1
135 0
2
0 22 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut33
3
0 0
97 1
136 0
2
0 23 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut34
3
0 0
97 1
137 0
2
0 24 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut35
3
0 0
97 1
138 0
2
0 25 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut36
3
0 0
97 1
139 0
2
0 26 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut37
3
0 0
97 1
140 0
2
0 27 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut38
3
0 0
97 1
141 0
2
0 28 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut39
3
0 0
97 1
142 0
2
0 29 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut4
3
0 0
97 1
143 0
2
0 30 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut5
3
0 0
97 1
144 0
2
0 31 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut6
3
0 0
97 1
145 0
2
0 32 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut7
3
0 0
97 1
146 0
2
0 33 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut8
3
0 0
97 1
147 0
2
0 34 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut9
3
0 0
97 1
149 0
2
0 35 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut1
3
0 0
98 1
110 0
2
0 106 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut10
3
0 0
98 1
111 0
2
0 107 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut11
3
0 0
98 1
112 0
2
0 108 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut12
3
0 0
98 1
113 0
2
0 109 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut13
3
0 0
98 1
114 0
2
0 1 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut14
3
0 0
98 1
115 0
2
0 2 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut15
3
0 0
98 1
116 0
2
0 3 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut16
3
0 0
98 1
117 0
2
0 4 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut17
3
0 0
98 1
118 0
2
0 5 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut18
3
0 0
98 1
119 0
2
0 6 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut19
3
0 0
98 1
120 0
2
0 7 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut2
3
0 0
98 1
121 0
2
0 8 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut20
3
0 0
98 1
122 0
2
0 9 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut21
3
0 0
98 1
123 0
2
0 10 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut22
3
0 0
98 1
124 0
2
0 11 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut23
3
0 0
98 1
125 0
2
0 12 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut24
3
0 0
98 1
126 0
2
0 13 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut25
3
0 0
98 1
127 0
2
0 14 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut26
3
0 0
98 1
128 0
2
0 15 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut27
3
0 0
98 1
129 0
2
0 16 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut28
3
0 0
98 1
130 0
2
0 17 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut29
3
0 0
98 1
131 0
2
0 18 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut3
3
0 0
98 1
132 0
2
0 19 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut30
3
0 0
98 1
133 0
2
0 20 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut31
3
0 0
98 1
134 0
2
0 21 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut32
3
0 0
98 1
135 0
2
0 22 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut33
3
0 0
98 1
136 0
2
0 23 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut34
3
0 0
98 1
137 0
2
0 24 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut35
3
0 0
98 1
138 0
2
0 25 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut36
3
0 0
98 1
139 0
2
0 26 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut37
3
0 0
98 1
140 0
2
0 27 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut38
3
0 0
98 1
141 0
2
0 28 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut39
3
0 0
98 1
142 0
2
0 29 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut4
3
0 0
98 1
143 0
2
0 30 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut5
3
0 0
98 1
144 0
2
0 31 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut6
3
0 0
98 1
145 0
2
0 32 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut7
3
0 0
98 1
146 0
2
0 33 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut8
3
0 0
98 1
147 0
2
0 34 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut9
3
0 0
98 1
149 0
2
0 35 0 1
0 211 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut1
3
0 0
99 1
110 0
2
0 106 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut10
3
0 0
99 1
111 0
2
0 107 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut11
3
0 0
99 1
112 0
2
0 108 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut12
3
0 0
99 1
113 0
2
0 109 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut13
3
0 0
99 1
114 0
2
0 1 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut14
3
0 0
99 1
115 0
2
0 2 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut15
3
0 0
99 1
116 0
2
0 3 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut16
3
0 0
99 1
117 0
2
0 4 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut17
3
0 0
99 1
118 0
2
0 5 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut18
3
0 0
99 1
119 0
2
0 6 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut19
3
0 0
99 1
120 0
2
0 7 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut2
3
0 0
99 1
121 0
2
0 8 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut20
3
0 0
99 1
122 0
2
0 9 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut21
3
0 0
99 1
123 0
2
0 10 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut22
3
0 0
99 1
124 0
2
0 11 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut23
3
0 0
99 1
125 0
2
0 12 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut24
3
0 0
99 1
126 0
2
0 13 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut25
3
0 0
99 1
127 0
2
0 14 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut26
3
0 0
99 1
128 0
2
0 15 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut27
3
0 0
99 1
129 0
2
0 16 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut28
3
0 0
99 1
130 0
2
0 17 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut29
3
0 0
99 1
131 0
2
0 18 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut3
3
0 0
99 1
132 0
2
0 19 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut30
3
0 0
99 1
133 0
2
0 20 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut31
3
0 0
99 1
134 0
2
0 21 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut32
3
0 0
99 1
135 0
2
0 22 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut33
3
0 0
99 1
136 0
2
0 23 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut34
3
0 0
99 1
137 0
2
0 24 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut35
3
0 0
99 1
138 0
2
0 25 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut36
3
0 0
99 1
139 0
2
0 26 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut37
3
0 0
99 1
140 0
2
0 27 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut38
3
0 0
99 1
141 0
2
0 28 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut39
3
0 0
99 1
142 0
2
0 29 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut4
3
0 0
99 1
143 0
2
0 30 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut5
3
0 0
99 1
144 0
2
0 31 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut6
3
0 0
99 1
145 0
2
0 32 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut7
3
0 0
99 1
146 0
2
0 33 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut8
3
0 0
99 1
147 0
2
0 34 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut9
3
0 0
99 1
149 0
2
0 35 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut1
3
0 0
100 1
110 0
2
0 106 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut10
3
0 0
100 1
111 0
2
0 107 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut11
3
0 0
100 1
112 0
2
0 108 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut12
3
0 0
100 1
113 0
2
0 109 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut13
3
0 0
100 1
114 0
2
0 1 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut14
3
0 0
100 1
115 0
2
0 2 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut15
3
0 0
100 1
116 0
2
0 3 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut16
3
0 0
100 1
117 0
2
0 4 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut17
3
0 0
100 1
118 0
2
0 5 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut18
3
0 0
100 1
119 0
2
0 6 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut19
3
0 0
100 1
120 0
2
0 7 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut2
3
0 0
100 1
121 0
2
0 8 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut20
3
0 0
100 1
122 0
2
0 9 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut21
3
0 0
100 1
123 0
2
0 10 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut22
3
0 0
100 1
124 0
2
0 11 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut23
3
0 0
100 1
125 0
2
0 12 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut24
3
0 0
100 1
126 0
2
0 13 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut25
3
0 0
100 1
127 0
2
0 14 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut26
3
0 0
100 1
128 0
2
0 15 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut27
3
0 0
100 1
129 0
2
0 16 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut28
3
0 0
100 1
130 0
2
0 17 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut29
3
0 0
100 1
131 0
2
0 18 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut3
3
0 0
100 1
132 0
2
0 19 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut30
3
0 0
100 1
133 0
2
0 20 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut31
3
0 0
100 1
134 0
2
0 21 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut32
3
0 0
100 1
135 0
2
0 22 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut33
3
0 0
100 1
136 0
2
0 23 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut34
3
0 0
100 1
137 0
2
0 24 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut35
3
0 0
100 1
138 0
2
0 25 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut36
3
0 0
100 1
139 0
2
0 26 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut37
3
0 0
100 1
140 0
2
0 27 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut38
3
0 0
100 1
141 0
2
0 28 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut39
3
0 0
100 1
142 0
2
0 29 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut4
3
0 0
100 1
143 0
2
0 30 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut5
3
0 0
100 1
144 0
2
0 31 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut6
3
0 0
100 1
145 0
2
0 32 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut7
3
0 0
100 1
146 0
2
0 33 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut8
3
0 0
100 1
147 0
2
0 34 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut9
3
0 0
100 1
149 0
2
0 35 0 1
0 213 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut1
3
0 0
101 1
110 0
2
0 106 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut10
3
0 0
101 1
111 0
2
0 107 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut11
3
0 0
101 1
112 0
2
0 108 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut12
3
0 0
101 1
113 0
2
0 109 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut13
3
0 0
101 1
114 0
2
0 1 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut14
3
0 0
101 1
115 0
2
0 2 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut15
3
0 0
101 1
116 0
2
0 3 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut16
3
0 0
101 1
117 0
2
0 4 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut17
3
0 0
101 1
118 0
2
0 5 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut18
3
0 0
101 1
119 0
2
0 6 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut19
3
0 0
101 1
120 0
2
0 7 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut2
3
0 0
101 1
121 0
2
0 8 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut20
3
0 0
101 1
122 0
2
0 9 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut21
3
0 0
101 1
123 0
2
0 10 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut22
3
0 0
101 1
124 0
2
0 11 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut23
3
0 0
101 1
125 0
2
0 12 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut24
3
0 0
101 1
126 0
2
0 13 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut25
3
0 0
101 1
127 0
2
0 14 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut26
3
0 0
101 1
128 0
2
0 15 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut27
3
0 0
101 1
129 0
2
0 16 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut28
3
0 0
101 1
130 0
2
0 17 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut29
3
0 0
101 1
131 0
2
0 18 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut3
3
0 0
101 1
132 0
2
0 19 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut30
3
0 0
101 1
133 0
2
0 20 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut31
3
0 0
101 1
134 0
2
0 21 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut32
3
0 0
101 1
135 0
2
0 22 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut33
3
0 0
101 1
136 0
2
0 23 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut34
3
0 0
101 1
137 0
2
0 24 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut35
3
0 0
101 1
138 0
2
0 25 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut36
3
0 0
101 1
139 0
2
0 26 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut37
3
0 0
101 1
140 0
2
0 27 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut38
3
0 0
101 1
141 0
2
0 28 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut39
3
0 0
101 1
142 0
2
0 29 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut4
3
0 0
101 1
143 0
2
0 30 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut5
3
0 0
101 1
144 0
2
0 31 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut6
3
0 0
101 1
145 0
2
0 32 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut7
3
0 0
101 1
146 0
2
0 33 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut8
3
0 0
101 1
147 0
2
0 34 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut9
3
0 0
101 1
149 0
2
0 35 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
102 1
110 0
2
0 106 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
102 1
111 0
2
0 107 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
102 1
112 0
2
0 108 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
102 1
113 0
2
0 109 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
102 1
114 0
2
0 1 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
102 1
115 0
2
0 2 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
102 1
116 0
2
0 3 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
102 1
117 0
2
0 4 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
102 1
118 0
2
0 5 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
102 1
119 0
2
0 6 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
102 1
120 0
2
0 7 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
102 1
121 0
2
0 8 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
102 1
122 0
2
0 9 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
102 1
123 0
2
0 10 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
102 1
124 0
2
0 11 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
102 1
125 0
2
0 12 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
102 1
126 0
2
0 13 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
102 1
127 0
2
0 14 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
102 1
128 0
2
0 15 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
102 1
129 0
2
0 16 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
102 1
130 0
2
0 17 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
102 1
131 0
2
0 18 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
102 1
132 0
2
0 19 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
102 1
133 0
2
0 20 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut31
3
0 0
102 1
134 0
2
0 21 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut32
3
0 0
102 1
135 0
2
0 22 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut33
3
0 0
102 1
136 0
2
0 23 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut34
3
0 0
102 1
137 0
2
0 24 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut35
3
0 0
102 1
138 0
2
0 25 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut36
3
0 0
102 1
139 0
2
0 26 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut37
3
0 0
102 1
140 0
2
0 27 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut38
3
0 0
102 1
141 0
2
0 28 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut39
3
0 0
102 1
142 0
2
0 29 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
102 1
143 0
2
0 30 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
102 1
144 0
2
0 31 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
102 1
145 0
2
0 32 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
102 1
146 0
2
0 33 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
102 1
147 0
2
0 34 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
102 1
149 0
2
0 35 0 1
0 215 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut1
3
0 0
103 1
110 0
2
0 106 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut10
3
0 0
103 1
111 0
2
0 107 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut11
3
0 0
103 1
112 0
2
0 108 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut12
3
0 0
103 1
113 0
2
0 109 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut13
3
0 0
103 1
114 0
2
0 1 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut14
3
0 0
103 1
115 0
2
0 2 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut15
3
0 0
103 1
116 0
2
0 3 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut16
3
0 0
103 1
117 0
2
0 4 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut17
3
0 0
103 1
118 0
2
0 5 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut18
3
0 0
103 1
119 0
2
0 6 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut19
3
0 0
103 1
120 0
2
0 7 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut2
3
0 0
103 1
121 0
2
0 8 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut20
3
0 0
103 1
122 0
2
0 9 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut21
3
0 0
103 1
123 0
2
0 10 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut22
3
0 0
103 1
124 0
2
0 11 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut23
3
0 0
103 1
125 0
2
0 12 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut24
3
0 0
103 1
126 0
2
0 13 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut25
3
0 0
103 1
127 0
2
0 14 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut26
3
0 0
103 1
128 0
2
0 15 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut27
3
0 0
103 1
129 0
2
0 16 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut28
3
0 0
103 1
130 0
2
0 17 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut29
3
0 0
103 1
131 0
2
0 18 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut3
3
0 0
103 1
132 0
2
0 19 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut30
3
0 0
103 1
133 0
2
0 20 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut31
3
0 0
103 1
134 0
2
0 21 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut32
3
0 0
103 1
135 0
2
0 22 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut33
3
0 0
103 1
136 0
2
0 23 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut34
3
0 0
103 1
137 0
2
0 24 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut35
3
0 0
103 1
138 0
2
0 25 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut36
3
0 0
103 1
139 0
2
0 26 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut37
3
0 0
103 1
140 0
2
0 27 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut38
3
0 0
103 1
141 0
2
0 28 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut39
3
0 0
103 1
142 0
2
0 29 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut4
3
0 0
103 1
143 0
2
0 30 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut5
3
0 0
103 1
144 0
2
0 31 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut6
3
0 0
103 1
145 0
2
0 32 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut7
3
0 0
103 1
146 0
2
0 33 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut8
3
0 0
103 1
147 0
2
0 34 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut9
3
0 0
103 1
149 0
2
0 35 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
104 1
110 0
2
0 106 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
104 1
111 0
2
0 107 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
104 1
112 0
2
0 108 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
104 1
113 0
2
0 109 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
104 1
114 0
2
0 1 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
104 1
115 0
2
0 2 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
104 1
116 0
2
0 3 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
104 1
117 0
2
0 4 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
104 1
118 0
2
0 5 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
104 1
119 0
2
0 6 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
104 1
120 0
2
0 7 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
104 1
121 0
2
0 8 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
104 1
122 0
2
0 9 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
104 1
123 0
2
0 10 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
104 1
124 0
2
0 11 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
104 1
125 0
2
0 12 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
104 1
126 0
2
0 13 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
104 1
127 0
2
0 14 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
104 1
128 0
2
0 15 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
104 1
129 0
2
0 16 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
104 1
130 0
2
0 17 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
104 1
131 0
2
0 18 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
104 1
132 0
2
0 19 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
104 1
133 0
2
0 20 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut31
3
0 0
104 1
134 0
2
0 21 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut32
3
0 0
104 1
135 0
2
0 22 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut33
3
0 0
104 1
136 0
2
0 23 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut34
3
0 0
104 1
137 0
2
0 24 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut35
3
0 0
104 1
138 0
2
0 25 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut36
3
0 0
104 1
139 0
2
0 26 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut37
3
0 0
104 1
140 0
2
0 27 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut38
3
0 0
104 1
141 0
2
0 28 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut39
3
0 0
104 1
142 0
2
0 29 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
104 1
143 0
2
0 30 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
104 1
144 0
2
0 31 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
104 1
145 0
2
0 32 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
104 1
146 0
2
0 33 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
104 1
147 0
2
0 34 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
104 1
149 0
2
0 35 0 1
0 217 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
105 1
110 0
2
0 106 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
105 1
111 0
2
0 107 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
105 1
112 0
2
0 108 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
105 1
113 0
2
0 109 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
105 1
114 0
2
0 1 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
105 1
115 0
2
0 2 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
105 1
116 0
2
0 3 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
105 1
117 0
2
0 4 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
105 1
118 0
2
0 5 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
105 1
119 0
2
0 6 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
105 1
120 0
2
0 7 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
105 1
121 0
2
0 8 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
105 1
122 0
2
0 9 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
105 1
123 0
2
0 10 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
105 1
124 0
2
0 11 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
105 1
125 0
2
0 12 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
105 1
126 0
2
0 13 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
105 1
127 0
2
0 14 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
105 1
128 0
2
0 15 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
105 1
129 0
2
0 16 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
105 1
130 0
2
0 17 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
105 1
131 0
2
0 18 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
105 1
132 0
2
0 19 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
105 1
133 0
2
0 20 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut31
3
0 0
105 1
134 0
2
0 21 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut32
3
0 0
105 1
135 0
2
0 22 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut33
3
0 0
105 1
136 0
2
0 23 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut34
3
0 0
105 1
137 0
2
0 24 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut35
3
0 0
105 1
138 0
2
0 25 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut36
3
0 0
105 1
139 0
2
0 26 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut37
3
0 0
105 1
140 0
2
0 27 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut38
3
0 0
105 1
141 0
2
0 28 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut39
3
0 0
105 1
142 0
2
0 29 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
105 1
143 0
2
0 30 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
105 1
144 0
2
0 31 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
105 1
145 0
2
0 32 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
105 1
146 0
2
0 33 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
105 1
147 0
2
0 34 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
105 1
149 0
2
0 35 0 1
0 218 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
219 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
220 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
221 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
222 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
223 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
224 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
225 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
226 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
227 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
228 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
229 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
230 0
1
0 0 12 23
1
end_operator
begin_operator
walk location20 location21 bob
1
231 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
232 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
233 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
234 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
235 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
236 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
237 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
238 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 location29 bob
1
239 0
1
0 0 21 22
1
end_operator
begin_operator
walk location29 location30 bob
1
240 0
1
0 0 22 24
1
end_operator
begin_operator
walk location3 location4 bob
1
241 0
1
0 0 23 30
1
end_operator
begin_operator
walk location30 location31 bob
1
242 0
1
0 0 24 25
1
end_operator
begin_operator
walk location31 location32 bob
1
243 0
1
0 0 25 26
1
end_operator
begin_operator
walk location32 location33 bob
1
244 0
1
0 0 26 27
1
end_operator
begin_operator
walk location33 location34 bob
1
245 0
1
0 0 27 28
1
end_operator
begin_operator
walk location34 location35 bob
1
246 0
1
0 0 28 29
1
end_operator
begin_operator
walk location35 gate bob
1
247 0
1
0 0 29 0
1
end_operator
begin_operator
walk location4 location5 bob
1
248 0
1
0 0 30 31
1
end_operator
begin_operator
walk location5 location6 bob
1
249 0
1
0 0 31 32
1
end_operator
begin_operator
walk location6 location7 bob
1
250 0
1
0 0 32 33
1
end_operator
begin_operator
walk location7 location8 bob
1
251 0
1
0 0 33 34
1
end_operator
begin_operator
walk location8 location9 bob
1
252 0
1
0 0 34 35
1
end_operator
begin_operator
walk location9 location10 bob
1
253 0
1
0 0 35 2
1
end_operator
begin_operator
walk shed location1 bob
1
254 0
1
0 0 36 1
1
end_operator
0
