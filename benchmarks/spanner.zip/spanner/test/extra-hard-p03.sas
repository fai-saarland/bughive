begin_version
3
end_version
begin_metric
1
end_metric
433
begin_variable
var0
-1
55
at bob gate
at bob location1
at bob location10
at bob location11
at bob location12
at bob location13
at bob location14
at bob location15
at bob location16
at bob location17
at bob location18
at bob location19
at bob location2
at bob location20
at bob location21
at bob location22
at bob location23
at bob location24
at bob location25
at bob location26
at bob location27
at bob location28
at bob location29
at bob location3
at bob location30
at bob location31
at bob location32
at bob location33
at bob location34
at bob location35
at bob location36
at bob location37
at bob location38
at bob location39
at bob location4
at bob location40
at bob location41
at bob location42
at bob location43
at bob location44
at bob location45
at bob location46
at bob location47
at bob location48
at bob location49
at bob location5
at bob location50
at bob location51
at bob location52
at bob location53
at bob location6
at bob location7
at bob location8
at bob location9
at bob shed
end_variable
begin_variable
var1
-1
2
at spanner1 location12
carrying bob spanner1
end_variable
begin_variable
var2
-1
2
at spanner10 location50
carrying bob spanner10
end_variable
begin_variable
var3
-1
2
at spanner100 location19
carrying bob spanner100
end_variable
begin_variable
var4
-1
2
at spanner101 location53
carrying bob spanner101
end_variable
begin_variable
var5
-1
2
at spanner102 location21
carrying bob spanner102
end_variable
begin_variable
var6
-1
2
at spanner103 location49
carrying bob spanner103
end_variable
begin_variable
var7
-1
2
at spanner104 location30
carrying bob spanner104
end_variable
begin_variable
var8
-1
2
at spanner105 location9
carrying bob spanner105
end_variable
begin_variable
var9
-1
2
at spanner106 location10
carrying bob spanner106
end_variable
begin_variable
var10
-1
2
at spanner107 location46
carrying bob spanner107
end_variable
begin_variable
var11
-1
2
at spanner108 location12
carrying bob spanner108
end_variable
begin_variable
var12
-1
2
at spanner109 location26
carrying bob spanner109
end_variable
begin_variable
var13
-1
2
at spanner11 location53
carrying bob spanner11
end_variable
begin_variable
var14
-1
2
at spanner110 location21
carrying bob spanner110
end_variable
begin_variable
var15
-1
2
at spanner111 location49
carrying bob spanner111
end_variable
begin_variable
var16
-1
2
at spanner112 location40
carrying bob spanner112
end_variable
begin_variable
var17
-1
2
at spanner113 location39
carrying bob spanner113
end_variable
begin_variable
var18
-1
2
at spanner114 location26
carrying bob spanner114
end_variable
begin_variable
var19
-1
2
at spanner115 location15
carrying bob spanner115
end_variable
begin_variable
var20
-1
2
at spanner116 location49
carrying bob spanner116
end_variable
begin_variable
var21
-1
2
at spanner117 location15
carrying bob spanner117
end_variable
begin_variable
var22
-1
2
at spanner118 location17
carrying bob spanner118
end_variable
begin_variable
var23
-1
2
at spanner119 location21
carrying bob spanner119
end_variable
begin_variable
var24
-1
2
at spanner12 location50
carrying bob spanner12
end_variable
begin_variable
var25
-1
2
at spanner120 location18
carrying bob spanner120
end_variable
begin_variable
var26
-1
2
at spanner121 location5
carrying bob spanner121
end_variable
begin_variable
var27
-1
2
at spanner122 location9
carrying bob spanner122
end_variable
begin_variable
var28
-1
2
at spanner123 location35
carrying bob spanner123
end_variable
begin_variable
var29
-1
2
at spanner124 location4
carrying bob spanner124
end_variable
begin_variable
var30
-1
2
at spanner125 location32
carrying bob spanner125
end_variable
begin_variable
var31
-1
2
at spanner126 location4
carrying bob spanner126
end_variable
begin_variable
var32
-1
2
at spanner13 location52
carrying bob spanner13
end_variable
begin_variable
var33
-1
2
at spanner14 location16
carrying bob spanner14
end_variable
begin_variable
var34
-1
2
at spanner15 location14
carrying bob spanner15
end_variable
begin_variable
var35
-1
2
at spanner16 location18
carrying bob spanner16
end_variable
begin_variable
var36
-1
2
at spanner17 location6
carrying bob spanner17
end_variable
begin_variable
var37
-1
2
at spanner18 location3
carrying bob spanner18
end_variable
begin_variable
var38
-1
2
at spanner19 location14
carrying bob spanner19
end_variable
begin_variable
var39
-1
2
at spanner2 location1
carrying bob spanner2
end_variable
begin_variable
var40
-1
2
at spanner20 location13
carrying bob spanner20
end_variable
begin_variable
var41
-1
2
at spanner21 location38
carrying bob spanner21
end_variable
begin_variable
var42
-1
2
at spanner22 location5
carrying bob spanner22
end_variable
begin_variable
var43
-1
2
at spanner23 location44
carrying bob spanner23
end_variable
begin_variable
var44
-1
2
at spanner24 location32
carrying bob spanner24
end_variable
begin_variable
var45
-1
2
at spanner25 location11
carrying bob spanner25
end_variable
begin_variable
var46
-1
2
at spanner26 location33
carrying bob spanner26
end_variable
begin_variable
var47
-1
2
at spanner27 location48
carrying bob spanner27
end_variable
begin_variable
var48
-1
2
at spanner28 location7
carrying bob spanner28
end_variable
begin_variable
var49
-1
2
at spanner29 location37
carrying bob spanner29
end_variable
begin_variable
var50
-1
2
at spanner3 location32
carrying bob spanner3
end_variable
begin_variable
var51
-1
2
at spanner30 location22
carrying bob spanner30
end_variable
begin_variable
var52
-1
2
loose nut1
tightened nut1
end_variable
begin_variable
var53
-1
2
at spanner31 location30
carrying bob spanner31
end_variable
begin_variable
var54
-1
2
loose nut10
tightened nut10
end_variable
begin_variable
var55
-1
2
at spanner32 location1
carrying bob spanner32
end_variable
begin_variable
var56
-1
2
loose nut11
tightened nut11
end_variable
begin_variable
var57
-1
2
at spanner33 location33
carrying bob spanner33
end_variable
begin_variable
var58
-1
2
loose nut12
tightened nut12
end_variable
begin_variable
var59
-1
2
at spanner34 location9
carrying bob spanner34
end_variable
begin_variable
var60
-1
2
loose nut13
tightened nut13
end_variable
begin_variable
var61
-1
2
at spanner35 location39
carrying bob spanner35
end_variable
begin_variable
var62
-1
2
loose nut14
tightened nut14
end_variable
begin_variable
var63
-1
2
at spanner36 location23
carrying bob spanner36
end_variable
begin_variable
var64
-1
2
loose nut15
tightened nut15
end_variable
begin_variable
var65
-1
2
at spanner37 location41
carrying bob spanner37
end_variable
begin_variable
var66
-1
2
loose nut16
tightened nut16
end_variable
begin_variable
var67
-1
2
at spanner38 location9
carrying bob spanner38
end_variable
begin_variable
var68
-1
2
loose nut17
tightened nut17
end_variable
begin_variable
var69
-1
2
at spanner39 location9
carrying bob spanner39
end_variable
begin_variable
var70
-1
2
loose nut18
tightened nut18
end_variable
begin_variable
var71
-1
2
at spanner4 location5
carrying bob spanner4
end_variable
begin_variable
var72
-1
2
loose nut19
tightened nut19
end_variable
begin_variable
var73
-1
2
at spanner40 location45
carrying bob spanner40
end_variable
begin_variable
var74
-1
2
loose nut2
tightened nut2
end_variable
begin_variable
var75
-1
2
at spanner41 location41
carrying bob spanner41
end_variable
begin_variable
var76
-1
2
loose nut20
tightened nut20
end_variable
begin_variable
var77
-1
2
at spanner42 location30
carrying bob spanner42
end_variable
begin_variable
var78
-1
2
loose nut21
tightened nut21
end_variable
begin_variable
var79
-1
2
at spanner43 location50
carrying bob spanner43
end_variable
begin_variable
var80
-1
2
loose nut22
tightened nut22
end_variable
begin_variable
var81
-1
2
at spanner44 location14
carrying bob spanner44
end_variable
begin_variable
var82
-1
2
loose nut23
tightened nut23
end_variable
begin_variable
var83
-1
2
at spanner45 location28
carrying bob spanner45
end_variable
begin_variable
var84
-1
2
loose nut24
tightened nut24
end_variable
begin_variable
var85
-1
2
at spanner46 location2
carrying bob spanner46
end_variable
begin_variable
var86
-1
2
loose nut25
tightened nut25
end_variable
begin_variable
var87
-1
2
at spanner47 location51
carrying bob spanner47
end_variable
begin_variable
var88
-1
2
loose nut26
tightened nut26
end_variable
begin_variable
var89
-1
2
at spanner48 location11
carrying bob spanner48
end_variable
begin_variable
var90
-1
2
loose nut27
tightened nut27
end_variable
begin_variable
var91
-1
2
at spanner49 location30
carrying bob spanner49
end_variable
begin_variable
var92
-1
2
loose nut28
tightened nut28
end_variable
begin_variable
var93
-1
2
at spanner5 location48
carrying bob spanner5
end_variable
begin_variable
var94
-1
2
loose nut29
tightened nut29
end_variable
begin_variable
var95
-1
2
at spanner50 location30
carrying bob spanner50
end_variable
begin_variable
var96
-1
2
loose nut3
tightened nut3
end_variable
begin_variable
var97
-1
2
at spanner51 location20
carrying bob spanner51
end_variable
begin_variable
var98
-1
2
loose nut30
tightened nut30
end_variable
begin_variable
var99
-1
2
at spanner52 location20
carrying bob spanner52
end_variable
begin_variable
var100
-1
2
loose nut31
tightened nut31
end_variable
begin_variable
var101
-1
2
at spanner53 location18
carrying bob spanner53
end_variable
begin_variable
var102
-1
2
loose nut32
tightened nut32
end_variable
begin_variable
var103
-1
2
at spanner54 location14
carrying bob spanner54
end_variable
begin_variable
var104
-1
2
loose nut33
tightened nut33
end_variable
begin_variable
var105
-1
2
at spanner55 location27
carrying bob spanner55
end_variable
begin_variable
var106
-1
2
loose nut34
tightened nut34
end_variable
begin_variable
var107
-1
2
at spanner56 location24
carrying bob spanner56
end_variable
begin_variable
var108
-1
2
loose nut35
tightened nut35
end_variable
begin_variable
var109
-1
2
at spanner57 location22
carrying bob spanner57
end_variable
begin_variable
var110
-1
2
loose nut36
tightened nut36
end_variable
begin_variable
var111
-1
2
at spanner58 location22
carrying bob spanner58
end_variable
begin_variable
var112
-1
2
loose nut37
tightened nut37
end_variable
begin_variable
var113
-1
2
at spanner59 location3
carrying bob spanner59
end_variable
begin_variable
var114
-1
2
loose nut38
tightened nut38
end_variable
begin_variable
var115
-1
2
at spanner6 location34
carrying bob spanner6
end_variable
begin_variable
var116
-1
2
loose nut39
tightened nut39
end_variable
begin_variable
var117
-1
2
at spanner60 location29
carrying bob spanner60
end_variable
begin_variable
var118
-1
2
loose nut4
tightened nut4
end_variable
begin_variable
var119
-1
2
at spanner61 location35
carrying bob spanner61
end_variable
begin_variable
var120
-1
2
loose nut40
tightened nut40
end_variable
begin_variable
var121
-1
2
at spanner62 location18
carrying bob spanner62
end_variable
begin_variable
var122
-1
2
loose nut41
tightened nut41
end_variable
begin_variable
var123
-1
2
at spanner63 location21
carrying bob spanner63
end_variable
begin_variable
var124
-1
2
loose nut42
tightened nut42
end_variable
begin_variable
var125
-1
2
at spanner64 location13
carrying bob spanner64
end_variable
begin_variable
var126
-1
2
loose nut43
tightened nut43
end_variable
begin_variable
var127
-1
2
at spanner65 location44
carrying bob spanner65
end_variable
begin_variable
var128
-1
2
loose nut44
tightened nut44
end_variable
begin_variable
var129
-1
2
at spanner66 location9
carrying bob spanner66
end_variable
begin_variable
var130
-1
2
loose nut45
tightened nut45
end_variable
begin_variable
var131
-1
2
at spanner67 location9
carrying bob spanner67
end_variable
begin_variable
var132
-1
2
loose nut46
tightened nut46
end_variable
begin_variable
var133
-1
2
at spanner68 location50
carrying bob spanner68
end_variable
begin_variable
var134
-1
2
loose nut47
tightened nut47
end_variable
begin_variable
var135
-1
2
at spanner69 location35
carrying bob spanner69
end_variable
begin_variable
var136
-1
2
loose nut48
tightened nut48
end_variable
begin_variable
var137
-1
2
at spanner7 location31
carrying bob spanner7
end_variable
begin_variable
var138
-1
2
loose nut49
tightened nut49
end_variable
begin_variable
var139
-1
2
at spanner70 location22
carrying bob spanner70
end_variable
begin_variable
var140
-1
2
loose nut5
tightened nut5
end_variable
begin_variable
var141
-1
2
at spanner71 location45
carrying bob spanner71
end_variable
begin_variable
var142
-1
2
loose nut50
tightened nut50
end_variable
begin_variable
var143
-1
2
at spanner72 location21
carrying bob spanner72
end_variable
begin_variable
var144
-1
2
loose nut51
tightened nut51
end_variable
begin_variable
var145
-1
2
at spanner73 location53
carrying bob spanner73
end_variable
begin_variable
var146
-1
2
loose nut52
tightened nut52
end_variable
begin_variable
var147
-1
2
at spanner74 location51
carrying bob spanner74
end_variable
begin_variable
var148
-1
2
loose nut53
tightened nut53
end_variable
begin_variable
var149
-1
2
at spanner75 location48
carrying bob spanner75
end_variable
begin_variable
var150
-1
2
loose nut54
tightened nut54
end_variable
begin_variable
var151
-1
2
at spanner76 location45
carrying bob spanner76
end_variable
begin_variable
var152
-1
2
loose nut55
tightened nut55
end_variable
begin_variable
var153
-1
2
at spanner77 location5
carrying bob spanner77
end_variable
begin_variable
var154
-1
2
loose nut56
tightened nut56
end_variable
begin_variable
var155
-1
2
at spanner78 location1
carrying bob spanner78
end_variable
begin_variable
var156
-1
2
loose nut57
tightened nut57
end_variable
begin_variable
var157
-1
2
at spanner79 location49
carrying bob spanner79
end_variable
begin_variable
var158
-1
2
loose nut58
tightened nut58
end_variable
begin_variable
var159
-1
2
at spanner8 location11
carrying bob spanner8
end_variable
begin_variable
var160
-1
2
loose nut59
tightened nut59
end_variable
begin_variable
var161
-1
2
at spanner80 location16
carrying bob spanner80
end_variable
begin_variable
var162
-1
2
loose nut6
tightened nut6
end_variable
begin_variable
var163
-1
2
at spanner81 location29
carrying bob spanner81
end_variable
begin_variable
var164
-1
2
loose nut60
tightened nut60
end_variable
begin_variable
var165
-1
2
at spanner82 location28
carrying bob spanner82
end_variable
begin_variable
var166
-1
2
loose nut61
tightened nut61
end_variable
begin_variable
var167
-1
2
at spanner83 location52
carrying bob spanner83
end_variable
begin_variable
var168
-1
2
loose nut62
tightened nut62
end_variable
begin_variable
var169
-1
2
at spanner84 location20
carrying bob spanner84
end_variable
begin_variable
var170
-1
2
loose nut63
tightened nut63
end_variable
begin_variable
var171
-1
2
at spanner85 location13
carrying bob spanner85
end_variable
begin_variable
var172
-1
2
loose nut7
tightened nut7
end_variable
begin_variable
var173
-1
2
at spanner86 location13
carrying bob spanner86
end_variable
begin_variable
var174
-1
2
loose nut8
tightened nut8
end_variable
begin_variable
var175
-1
2
at spanner87 location35
carrying bob spanner87
end_variable
begin_variable
var176
-1
2
loose nut9
tightened nut9
end_variable
begin_variable
var177
-1
2
at spanner88 location47
carrying bob spanner88
end_variable
begin_variable
var178
-1
2
at spanner89 location18
carrying bob spanner89
end_variable
begin_variable
var179
-1
2
at spanner9 location33
carrying bob spanner9
end_variable
begin_variable
var180
-1
2
at spanner90 location7
carrying bob spanner90
end_variable
begin_variable
var181
-1
2
at spanner91 location34
carrying bob spanner91
end_variable
begin_variable
var182
-1
2
at spanner92 location34
carrying bob spanner92
end_variable
begin_variable
var183
-1
2
at spanner93 location24
carrying bob spanner93
end_variable
begin_variable
var184
-1
2
at spanner94 location18
carrying bob spanner94
end_variable
begin_variable
var185
-1
2
at spanner95 location10
carrying bob spanner95
end_variable
begin_variable
var186
-1
2
at spanner96 location26
carrying bob spanner96
end_variable
begin_variable
var187
-1
2
at spanner97 location35
carrying bob spanner97
end_variable
begin_variable
var188
-1
2
at spanner98 location2
carrying bob spanner98
end_variable
begin_variable
var189
-1
2
at spanner99 location27
carrying bob spanner99
end_variable
begin_variable
var190
-1
2
usable spanner1
none-of-those
end_variable
begin_variable
var191
-1
2
usable spanner10
none-of-those
end_variable
begin_variable
var192
-1
2
usable spanner100
none-of-those
end_variable
begin_variable
var193
-1
2
usable spanner101
none-of-those
end_variable
begin_variable
var194
-1
2
usable spanner102
none-of-those
end_variable
begin_variable
var195
-1
2
usable spanner103
none-of-those
end_variable
begin_variable
var196
-1
2
usable spanner104
none-of-those
end_variable
begin_variable
var197
-1
2
usable spanner105
none-of-those
end_variable
begin_variable
var198
-1
2
usable spanner106
none-of-those
end_variable
begin_variable
var199
-1
2
usable spanner107
none-of-those
end_variable
begin_variable
var200
-1
2
usable spanner108
none-of-those
end_variable
begin_variable
var201
-1
2
usable spanner109
none-of-those
end_variable
begin_variable
var202
-1
2
usable spanner11
none-of-those
end_variable
begin_variable
var203
-1
2
usable spanner110
none-of-those
end_variable
begin_variable
var204
-1
2
usable spanner111
none-of-those
end_variable
begin_variable
var205
-1
2
usable spanner112
none-of-those
end_variable
begin_variable
var206
-1
2
usable spanner113
none-of-those
end_variable
begin_variable
var207
-1
2
at nut1 gate
none-of-those
end_variable
begin_variable
var208
-1
2
usable spanner114
none-of-those
end_variable
begin_variable
var209
-1
2
at nut10 gate
none-of-those
end_variable
begin_variable
var210
-1
2
usable spanner115
none-of-those
end_variable
begin_variable
var211
-1
2
at nut11 gate
none-of-those
end_variable
begin_variable
var212
-1
2
usable spanner116
none-of-those
end_variable
begin_variable
var213
-1
2
at nut12 gate
none-of-those
end_variable
begin_variable
var214
-1
2
usable spanner117
none-of-those
end_variable
begin_variable
var215
-1
2
at nut13 gate
none-of-those
end_variable
begin_variable
var216
-1
2
usable spanner118
none-of-those
end_variable
begin_variable
var217
-1
2
at nut14 gate
none-of-those
end_variable
begin_variable
var218
-1
2
usable spanner119
none-of-those
end_variable
begin_variable
var219
-1
2
at nut15 gate
none-of-those
end_variable
begin_variable
var220
-1
2
usable spanner12
none-of-those
end_variable
begin_variable
var221
-1
2
at nut16 gate
none-of-those
end_variable
begin_variable
var222
-1
2
usable spanner120
none-of-those
end_variable
begin_variable
var223
-1
2
at nut17 gate
none-of-those
end_variable
begin_variable
var224
-1
2
usable spanner121
none-of-those
end_variable
begin_variable
var225
-1
2
at nut18 gate
none-of-those
end_variable
begin_variable
var226
-1
2
usable spanner122
none-of-those
end_variable
begin_variable
var227
-1
2
at nut19 gate
none-of-those
end_variable
begin_variable
var228
-1
2
usable spanner123
none-of-those
end_variable
begin_variable
var229
-1
2
at nut2 gate
none-of-those
end_variable
begin_variable
var230
-1
2
usable spanner124
none-of-those
end_variable
begin_variable
var231
-1
2
at nut20 gate
none-of-those
end_variable
begin_variable
var232
-1
2
usable spanner125
none-of-those
end_variable
begin_variable
var233
-1
2
at nut21 gate
none-of-those
end_variable
begin_variable
var234
-1
2
usable spanner126
none-of-those
end_variable
begin_variable
var235
-1
2
at nut22 gate
none-of-those
end_variable
begin_variable
var236
-1
2
usable spanner13
none-of-those
end_variable
begin_variable
var237
-1
2
at nut23 gate
none-of-those
end_variable
begin_variable
var238
-1
2
usable spanner14
none-of-those
end_variable
begin_variable
var239
-1
2
at nut24 gate
none-of-those
end_variable
begin_variable
var240
-1
2
usable spanner15
none-of-those
end_variable
begin_variable
var241
-1
2
at nut25 gate
none-of-those
end_variable
begin_variable
var242
-1
2
usable spanner16
none-of-those
end_variable
begin_variable
var243
-1
2
at nut26 gate
none-of-those
end_variable
begin_variable
var244
-1
2
usable spanner17
none-of-those
end_variable
begin_variable
var245
-1
2
at nut27 gate
none-of-those
end_variable
begin_variable
var246
-1
2
usable spanner18
none-of-those
end_variable
begin_variable
var247
-1
2
at nut28 gate
none-of-those
end_variable
begin_variable
var248
-1
2
usable spanner19
none-of-those
end_variable
begin_variable
var249
-1
2
at nut29 gate
none-of-those
end_variable
begin_variable
var250
-1
2
usable spanner2
none-of-those
end_variable
begin_variable
var251
-1
2
at nut3 gate
none-of-those
end_variable
begin_variable
var252
-1
2
usable spanner20
none-of-those
end_variable
begin_variable
var253
-1
2
at nut30 gate
none-of-those
end_variable
begin_variable
var254
-1
2
usable spanner21
none-of-those
end_variable
begin_variable
var255
-1
2
at nut31 gate
none-of-those
end_variable
begin_variable
var256
-1
2
usable spanner22
none-of-those
end_variable
begin_variable
var257
-1
2
at nut32 gate
none-of-those
end_variable
begin_variable
var258
-1
2
usable spanner23
none-of-those
end_variable
begin_variable
var259
-1
2
at nut33 gate
none-of-those
end_variable
begin_variable
var260
-1
2
usable spanner24
none-of-those
end_variable
begin_variable
var261
-1
2
at nut34 gate
none-of-those
end_variable
begin_variable
var262
-1
2
usable spanner25
none-of-those
end_variable
begin_variable
var263
-1
2
at nut35 gate
none-of-those
end_variable
begin_variable
var264
-1
2
usable spanner26
none-of-those
end_variable
begin_variable
var265
-1
2
at nut36 gate
none-of-those
end_variable
begin_variable
var266
-1
2
usable spanner27
none-of-those
end_variable
begin_variable
var267
-1
2
at nut37 gate
none-of-those
end_variable
begin_variable
var268
-1
2
usable spanner28
none-of-those
end_variable
begin_variable
var269
-1
2
at nut38 gate
none-of-those
end_variable
begin_variable
var270
-1
2
usable spanner29
none-of-those
end_variable
begin_variable
var271
-1
2
at nut39 gate
none-of-those
end_variable
begin_variable
var272
-1
2
usable spanner3
none-of-those
end_variable
begin_variable
var273
-1
2
at nut4 gate
none-of-those
end_variable
begin_variable
var274
-1
2
usable spanner30
none-of-those
end_variable
begin_variable
var275
-1
2
at nut40 gate
none-of-those
end_variable
begin_variable
var276
-1
2
usable spanner31
none-of-those
end_variable
begin_variable
var277
-1
2
at nut41 gate
none-of-those
end_variable
begin_variable
var278
-1
2
usable spanner32
none-of-those
end_variable
begin_variable
var279
-1
2
at nut42 gate
none-of-those
end_variable
begin_variable
var280
-1
2
usable spanner33
none-of-those
end_variable
begin_variable
var281
-1
2
at nut43 gate
none-of-those
end_variable
begin_variable
var282
-1
2
usable spanner34
none-of-those
end_variable
begin_variable
var283
-1
2
at nut44 gate
none-of-those
end_variable
begin_variable
var284
-1
2
usable spanner35
none-of-those
end_variable
begin_variable
var285
-1
2
at nut45 gate
none-of-those
end_variable
begin_variable
var286
-1
2
usable spanner36
none-of-those
end_variable
begin_variable
var287
-1
2
at nut46 gate
none-of-those
end_variable
begin_variable
var288
-1
2
usable spanner37
none-of-those
end_variable
begin_variable
var289
-1
2
at nut47 gate
none-of-those
end_variable
begin_variable
var290
-1
2
usable spanner38
none-of-those
end_variable
begin_variable
var291
-1
2
at nut48 gate
none-of-those
end_variable
begin_variable
var292
-1
2
usable spanner39
none-of-those
end_variable
begin_variable
var293
-1
2
at nut49 gate
none-of-those
end_variable
begin_variable
var294
-1
2
usable spanner4
none-of-those
end_variable
begin_variable
var295
-1
2
at nut5 gate
none-of-those
end_variable
begin_variable
var296
-1
2
usable spanner40
none-of-those
end_variable
begin_variable
var297
-1
2
at nut50 gate
none-of-those
end_variable
begin_variable
var298
-1
2
usable spanner41
none-of-those
end_variable
begin_variable
var299
-1
2
at nut51 gate
none-of-those
end_variable
begin_variable
var300
-1
2
usable spanner42
none-of-those
end_variable
begin_variable
var301
-1
2
at nut52 gate
none-of-those
end_variable
begin_variable
var302
-1
2
usable spanner43
none-of-those
end_variable
begin_variable
var303
-1
2
at nut53 gate
none-of-those
end_variable
begin_variable
var304
-1
2
usable spanner44
none-of-those
end_variable
begin_variable
var305
-1
2
at nut54 gate
none-of-those
end_variable
begin_variable
var306
-1
2
usable spanner45
none-of-those
end_variable
begin_variable
var307
-1
2
at nut55 gate
none-of-those
end_variable
begin_variable
var308
-1
2
usable spanner46
none-of-those
end_variable
begin_variable
var309
-1
2
at nut56 gate
none-of-those
end_variable
begin_variable
var310
-1
2
usable spanner47
none-of-those
end_variable
begin_variable
var311
-1
2
at nut57 gate
none-of-those
end_variable
begin_variable
var312
-1
2
usable spanner48
none-of-those
end_variable
begin_variable
var313
-1
2
at nut58 gate
none-of-those
end_variable
begin_variable
var314
-1
2
usable spanner49
none-of-those
end_variable
begin_variable
var315
-1
2
at nut59 gate
none-of-those
end_variable
begin_variable
var316
-1
2
usable spanner5
none-of-those
end_variable
begin_variable
var317
-1
2
at nut6 gate
none-of-those
end_variable
begin_variable
var318
-1
2
usable spanner50
none-of-those
end_variable
begin_variable
var319
-1
2
at nut60 gate
none-of-those
end_variable
begin_variable
var320
-1
2
usable spanner51
none-of-those
end_variable
begin_variable
var321
-1
2
at nut61 gate
none-of-those
end_variable
begin_variable
var322
-1
2
usable spanner52
none-of-those
end_variable
begin_variable
var323
-1
2
at nut62 gate
none-of-those
end_variable
begin_variable
var324
-1
2
usable spanner53
none-of-those
end_variable
begin_variable
var325
-1
2
at nut63 gate
none-of-those
end_variable
begin_variable
var326
-1
2
usable spanner54
none-of-those
end_variable
begin_variable
var327
-1
2
at nut7 gate
none-of-those
end_variable
begin_variable
var328
-1
2
usable spanner55
none-of-those
end_variable
begin_variable
var329
-1
2
at nut8 gate
none-of-those
end_variable
begin_variable
var330
-1
2
usable spanner56
none-of-those
end_variable
begin_variable
var331
-1
2
at nut9 gate
none-of-those
end_variable
begin_variable
var332
-1
2
usable spanner57
none-of-those
end_variable
begin_variable
var333
-1
2
usable spanner58
none-of-those
end_variable
begin_variable
var334
-1
2
usable spanner59
none-of-those
end_variable
begin_variable
var335
-1
2
usable spanner6
none-of-those
end_variable
begin_variable
var336
-1
2
usable spanner60
none-of-those
end_variable
begin_variable
var337
-1
2
usable spanner61
none-of-those
end_variable
begin_variable
var338
-1
2
usable spanner62
none-of-those
end_variable
begin_variable
var339
-1
2
usable spanner63
none-of-those
end_variable
begin_variable
var340
-1
2
usable spanner64
none-of-those
end_variable
begin_variable
var341
-1
2
usable spanner65
none-of-those
end_variable
begin_variable
var342
-1
2
usable spanner66
none-of-those
end_variable
begin_variable
var343
-1
2
usable spanner67
none-of-those
end_variable
begin_variable
var344
-1
2
usable spanner68
none-of-those
end_variable
begin_variable
var345
-1
2
usable spanner69
none-of-those
end_variable
begin_variable
var346
-1
2
usable spanner7
none-of-those
end_variable
begin_variable
var347
-1
2
usable spanner70
none-of-those
end_variable
begin_variable
var348
-1
2
usable spanner71
none-of-those
end_variable
begin_variable
var349
-1
2
usable spanner72
none-of-those
end_variable
begin_variable
var350
-1
2
usable spanner73
none-of-those
end_variable
begin_variable
var351
-1
2
usable spanner74
none-of-those
end_variable
begin_variable
var352
-1
2
usable spanner75
none-of-those
end_variable
begin_variable
var353
-1
2
usable spanner76
none-of-those
end_variable
begin_variable
var354
-1
2
usable spanner77
none-of-those
end_variable
begin_variable
var355
-1
2
usable spanner78
none-of-those
end_variable
begin_variable
var356
-1
2
usable spanner79
none-of-those
end_variable
begin_variable
var357
-1
2
usable spanner8
none-of-those
end_variable
begin_variable
var358
-1
2
usable spanner80
none-of-those
end_variable
begin_variable
var359
-1
2
usable spanner81
none-of-those
end_variable
begin_variable
var360
-1
2
usable spanner82
none-of-those
end_variable
begin_variable
var361
-1
2
usable spanner83
none-of-those
end_variable
begin_variable
var362
-1
2
usable spanner84
none-of-those
end_variable
begin_variable
var363
-1
2
usable spanner85
none-of-those
end_variable
begin_variable
var364
-1
2
usable spanner86
none-of-those
end_variable
begin_variable
var365
-1
2
usable spanner87
none-of-those
end_variable
begin_variable
var366
-1
2
usable spanner88
none-of-those
end_variable
begin_variable
var367
-1
2
usable spanner89
none-of-those
end_variable
begin_variable
var368
-1
2
usable spanner9
none-of-those
end_variable
begin_variable
var369
-1
2
usable spanner90
none-of-those
end_variable
begin_variable
var370
-1
2
usable spanner91
none-of-those
end_variable
begin_variable
var371
-1
2
usable spanner92
none-of-those
end_variable
begin_variable
var372
-1
2
usable spanner93
none-of-those
end_variable
begin_variable
var373
-1
2
usable spanner94
none-of-those
end_variable
begin_variable
var374
-1
2
usable spanner95
none-of-those
end_variable
begin_variable
var375
-1
2
usable spanner96
none-of-those
end_variable
begin_variable
var376
-1
2
usable spanner97
none-of-those
end_variable
begin_variable
var377
-1
2
usable spanner98
none-of-those
end_variable
begin_variable
var378
-1
2
usable spanner99
none-of-those
end_variable
begin_variable
var379
-1
2
link location1 location2
none-of-those
end_variable
begin_variable
var380
-1
2
link location10 location11
none-of-those
end_variable
begin_variable
var381
-1
2
link location11 location12
none-of-those
end_variable
begin_variable
var382
-1
2
link location12 location13
none-of-those
end_variable
begin_variable
var383
-1
2
link location13 location14
none-of-those
end_variable
begin_variable
var384
-1
2
link location14 location15
none-of-those
end_variable
begin_variable
var385
-1
2
link location15 location16
none-of-those
end_variable
begin_variable
var386
-1
2
link location16 location17
none-of-those
end_variable
begin_variable
var387
-1
2
link location17 location18
none-of-those
end_variable
begin_variable
var388
-1
2
link location18 location19
none-of-those
end_variable
begin_variable
var389
-1
2
link location19 location20
none-of-those
end_variable
begin_variable
var390
-1
2
link location2 location3
none-of-those
end_variable
begin_variable
var391
-1
2
link location20 location21
none-of-those
end_variable
begin_variable
var392
-1
2
link location21 location22
none-of-those
end_variable
begin_variable
var393
-1
2
link location22 location23
none-of-those
end_variable
begin_variable
var394
-1
2
link location23 location24
none-of-those
end_variable
begin_variable
var395
-1
2
link location24 location25
none-of-those
end_variable
begin_variable
var396
-1
2
link location25 location26
none-of-those
end_variable
begin_variable
var397
-1
2
link location26 location27
none-of-those
end_variable
begin_variable
var398
-1
2
link location27 location28
none-of-those
end_variable
begin_variable
var399
-1
2
link location28 location29
none-of-those
end_variable
begin_variable
var400
-1
2
link location29 location30
none-of-those
end_variable
begin_variable
var401
-1
2
link location3 location4
none-of-those
end_variable
begin_variable
var402
-1
2
link location30 location31
none-of-those
end_variable
begin_variable
var403
-1
2
link location31 location32
none-of-those
end_variable
begin_variable
var404
-1
2
link location32 location33
none-of-those
end_variable
begin_variable
var405
-1
2
link location33 location34
none-of-those
end_variable
begin_variable
var406
-1
2
link location34 location35
none-of-those
end_variable
begin_variable
var407
-1
2
link location35 location36
none-of-those
end_variable
begin_variable
var408
-1
2
link location36 location37
none-of-those
end_variable
begin_variable
var409
-1
2
link location37 location38
none-of-those
end_variable
begin_variable
var410
-1
2
link location38 location39
none-of-those
end_variable
begin_variable
var411
-1
2
link location39 location40
none-of-those
end_variable
begin_variable
var412
-1
2
link location4 location5
none-of-those
end_variable
begin_variable
var413
-1
2
link location40 location41
none-of-those
end_variable
begin_variable
var414
-1
2
link location41 location42
none-of-those
end_variable
begin_variable
var415
-1
2
link location42 location43
none-of-those
end_variable
begin_variable
var416
-1
2
link location43 location44
none-of-those
end_variable
begin_variable
var417
-1
2
link location44 location45
none-of-those
end_variable
begin_variable
var418
-1
2
link location45 location46
none-of-those
end_variable
begin_variable
var419
-1
2
link location46 location47
none-of-those
end_variable
begin_variable
var420
-1
2
link location47 location48
none-of-those
end_variable
begin_variable
var421
-1
2
link location48 location49
none-of-those
end_variable
begin_variable
var422
-1
2
link location49 location50
none-of-those
end_variable
begin_variable
var423
-1
2
link location5 location6
none-of-those
end_variable
begin_variable
var424
-1
2
link location50 location51
none-of-those
end_variable
begin_variable
var425
-1
2
link location51 location52
none-of-those
end_variable
begin_variable
var426
-1
2
link location52 location53
none-of-those
end_variable
begin_variable
var427
-1
2
link location53 gate
none-of-those
end_variable
begin_variable
var428
-1
2
link location6 location7
none-of-those
end_variable
begin_variable
var429
-1
2
link location7 location8
none-of-those
end_variable
begin_variable
var430
-1
2
link location8 location9
none-of-those
end_variable
begin_variable
var431
-1
2
link location9 location10
none-of-those
end_variable
begin_variable
var432
-1
2
link shed location1
none-of-those
end_variable
0
begin_state
54
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
end_state
begin_goal
63
52 1
54 1
56 1
58 1
60 1
62 1
64 1
66 1
68 1
70 1
72 1
74 1
76 1
78 1
80 1
82 1
84 1
86 1
88 1
90 1
92 1
94 1
96 1
98 1
100 1
102 1
104 1
106 1
108 1
110 1
112 1
114 1
116 1
118 1
120 1
122 1
124 1
126 1
128 1
130 1
132 1
134 1
136 1
138 1
140 1
142 1
144 1
146 1
148 1
150 1
152 1
154 1
156 1
158 1
160 1
162 1
164 1
166 1
168 1
170 1
172 1
174 1
176 1
end_goal
8118
begin_operator
pickup_spanner location1 spanner2 bob
1
0 1
1
0 39 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner32 bob
1
0 1
1
0 55 0 1
1
end_operator
begin_operator
pickup_spanner location1 spanner78 bob
1
0 1
1
0 155 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner106 bob
1
0 2
1
0 9 0 1
1
end_operator
begin_operator
pickup_spanner location10 spanner95 bob
1
0 2
1
0 185 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner25 bob
1
0 3
1
0 45 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner48 bob
1
0 3
1
0 89 0 1
1
end_operator
begin_operator
pickup_spanner location11 spanner8 bob
1
0 3
1
0 159 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner1 bob
1
0 4
1
0 1 0 1
1
end_operator
begin_operator
pickup_spanner location12 spanner108 bob
1
0 4
1
0 11 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner20 bob
1
0 5
1
0 40 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner64 bob
1
0 5
1
0 125 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner85 bob
1
0 5
1
0 171 0 1
1
end_operator
begin_operator
pickup_spanner location13 spanner86 bob
1
0 5
1
0 173 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner15 bob
1
0 6
1
0 34 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner19 bob
1
0 6
1
0 38 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner44 bob
1
0 6
1
0 81 0 1
1
end_operator
begin_operator
pickup_spanner location14 spanner54 bob
1
0 6
1
0 103 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner115 bob
1
0 7
1
0 19 0 1
1
end_operator
begin_operator
pickup_spanner location15 spanner117 bob
1
0 7
1
0 21 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner14 bob
1
0 8
1
0 33 0 1
1
end_operator
begin_operator
pickup_spanner location16 spanner80 bob
1
0 8
1
0 161 0 1
1
end_operator
begin_operator
pickup_spanner location17 spanner118 bob
1
0 9
1
0 22 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner120 bob
1
0 10
1
0 25 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner16 bob
1
0 10
1
0 35 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner53 bob
1
0 10
1
0 101 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner62 bob
1
0 10
1
0 121 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner89 bob
1
0 10
1
0 178 0 1
1
end_operator
begin_operator
pickup_spanner location18 spanner94 bob
1
0 10
1
0 184 0 1
1
end_operator
begin_operator
pickup_spanner location19 spanner100 bob
1
0 11
1
0 3 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner46 bob
1
0 12
1
0 85 0 1
1
end_operator
begin_operator
pickup_spanner location2 spanner98 bob
1
0 12
1
0 188 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner51 bob
1
0 13
1
0 97 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner52 bob
1
0 13
1
0 99 0 1
1
end_operator
begin_operator
pickup_spanner location20 spanner84 bob
1
0 13
1
0 169 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner102 bob
1
0 14
1
0 5 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner110 bob
1
0 14
1
0 14 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner119 bob
1
0 14
1
0 23 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner63 bob
1
0 14
1
0 123 0 1
1
end_operator
begin_operator
pickup_spanner location21 spanner72 bob
1
0 14
1
0 143 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner30 bob
1
0 15
1
0 51 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner57 bob
1
0 15
1
0 109 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner58 bob
1
0 15
1
0 111 0 1
1
end_operator
begin_operator
pickup_spanner location22 spanner70 bob
1
0 15
1
0 139 0 1
1
end_operator
begin_operator
pickup_spanner location23 spanner36 bob
1
0 16
1
0 63 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner56 bob
1
0 17
1
0 107 0 1
1
end_operator
begin_operator
pickup_spanner location24 spanner93 bob
1
0 17
1
0 183 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner109 bob
1
0 19
1
0 12 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner114 bob
1
0 19
1
0 18 0 1
1
end_operator
begin_operator
pickup_spanner location26 spanner96 bob
1
0 19
1
0 186 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner55 bob
1
0 20
1
0 105 0 1
1
end_operator
begin_operator
pickup_spanner location27 spanner99 bob
1
0 20
1
0 189 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner45 bob
1
0 21
1
0 83 0 1
1
end_operator
begin_operator
pickup_spanner location28 spanner82 bob
1
0 21
1
0 165 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner60 bob
1
0 22
1
0 117 0 1
1
end_operator
begin_operator
pickup_spanner location29 spanner81 bob
1
0 22
1
0 163 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner18 bob
1
0 23
1
0 37 0 1
1
end_operator
begin_operator
pickup_spanner location3 spanner59 bob
1
0 23
1
0 113 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner104 bob
1
0 24
1
0 7 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner31 bob
1
0 24
1
0 53 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner42 bob
1
0 24
1
0 77 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner49 bob
1
0 24
1
0 91 0 1
1
end_operator
begin_operator
pickup_spanner location30 spanner50 bob
1
0 24
1
0 95 0 1
1
end_operator
begin_operator
pickup_spanner location31 spanner7 bob
1
0 25
1
0 137 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner125 bob
1
0 26
1
0 30 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner24 bob
1
0 26
1
0 44 0 1
1
end_operator
begin_operator
pickup_spanner location32 spanner3 bob
1
0 26
1
0 50 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner26 bob
1
0 27
1
0 46 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner33 bob
1
0 27
1
0 57 0 1
1
end_operator
begin_operator
pickup_spanner location33 spanner9 bob
1
0 27
1
0 179 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner6 bob
1
0 28
1
0 115 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner91 bob
1
0 28
1
0 181 0 1
1
end_operator
begin_operator
pickup_spanner location34 spanner92 bob
1
0 28
1
0 182 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner123 bob
1
0 29
1
0 28 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner61 bob
1
0 29
1
0 119 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner69 bob
1
0 29
1
0 135 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner87 bob
1
0 29
1
0 175 0 1
1
end_operator
begin_operator
pickup_spanner location35 spanner97 bob
1
0 29
1
0 187 0 1
1
end_operator
begin_operator
pickup_spanner location37 spanner29 bob
1
0 31
1
0 49 0 1
1
end_operator
begin_operator
pickup_spanner location38 spanner21 bob
1
0 32
1
0 41 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner113 bob
1
0 33
1
0 17 0 1
1
end_operator
begin_operator
pickup_spanner location39 spanner35 bob
1
0 33
1
0 61 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner124 bob
1
0 34
1
0 29 0 1
1
end_operator
begin_operator
pickup_spanner location4 spanner126 bob
1
0 34
1
0 31 0 1
1
end_operator
begin_operator
pickup_spanner location40 spanner112 bob
1
0 35
1
0 16 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner37 bob
1
0 36
1
0 65 0 1
1
end_operator
begin_operator
pickup_spanner location41 spanner41 bob
1
0 36
1
0 75 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner23 bob
1
0 39
1
0 43 0 1
1
end_operator
begin_operator
pickup_spanner location44 spanner65 bob
1
0 39
1
0 127 0 1
1
end_operator
begin_operator
pickup_spanner location45 spanner40 bob
1
0 40
1
0 73 0 1
1
end_operator
begin_operator
pickup_spanner location45 spanner71 bob
1
0 40
1
0 141 0 1
1
end_operator
begin_operator
pickup_spanner location45 spanner76 bob
1
0 40
1
0 151 0 1
1
end_operator
begin_operator
pickup_spanner location46 spanner107 bob
1
0 41
1
0 10 0 1
1
end_operator
begin_operator
pickup_spanner location47 spanner88 bob
1
0 42
1
0 177 0 1
1
end_operator
begin_operator
pickup_spanner location48 spanner27 bob
1
0 43
1
0 47 0 1
1
end_operator
begin_operator
pickup_spanner location48 spanner5 bob
1
0 43
1
0 93 0 1
1
end_operator
begin_operator
pickup_spanner location48 spanner75 bob
1
0 43
1
0 149 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner103 bob
1
0 44
1
0 6 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner111 bob
1
0 44
1
0 15 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner116 bob
1
0 44
1
0 20 0 1
1
end_operator
begin_operator
pickup_spanner location49 spanner79 bob
1
0 44
1
0 157 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner121 bob
1
0 45
1
0 26 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner22 bob
1
0 45
1
0 42 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner4 bob
1
0 45
1
0 71 0 1
1
end_operator
begin_operator
pickup_spanner location5 spanner77 bob
1
0 45
1
0 153 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner10 bob
1
0 46
1
0 2 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner12 bob
1
0 46
1
0 24 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner43 bob
1
0 46
1
0 79 0 1
1
end_operator
begin_operator
pickup_spanner location50 spanner68 bob
1
0 46
1
0 133 0 1
1
end_operator
begin_operator
pickup_spanner location51 spanner47 bob
1
0 47
1
0 87 0 1
1
end_operator
begin_operator
pickup_spanner location51 spanner74 bob
1
0 47
1
0 147 0 1
1
end_operator
begin_operator
pickup_spanner location52 spanner13 bob
1
0 48
1
0 32 0 1
1
end_operator
begin_operator
pickup_spanner location52 spanner83 bob
1
0 48
1
0 167 0 1
1
end_operator
begin_operator
pickup_spanner location53 spanner101 bob
1
0 49
1
0 4 0 1
1
end_operator
begin_operator
pickup_spanner location53 spanner11 bob
1
0 49
1
0 13 0 1
1
end_operator
begin_operator
pickup_spanner location53 spanner73 bob
1
0 49
1
0 145 0 1
1
end_operator
begin_operator
pickup_spanner location6 spanner17 bob
1
0 50
1
0 36 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner28 bob
1
0 51
1
0 48 0 1
1
end_operator
begin_operator
pickup_spanner location7 spanner90 bob
1
0 51
1
0 180 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner105 bob
1
0 53
1
0 8 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner122 bob
1
0 53
1
0 27 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner34 bob
1
0 53
1
0 59 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner38 bob
1
0 53
1
0 67 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner39 bob
1
0 53
1
0 69 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner66 bob
1
0 53
1
0 129 0 1
1
end_operator
begin_operator
pickup_spanner location9 spanner67 bob
1
0 53
1
0 131 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut1
3
0 0
1 1
207 0
2
0 52 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut10
3
0 0
1 1
209 0
2
0 54 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut11
3
0 0
1 1
211 0
2
0 56 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut12
3
0 0
1 1
213 0
2
0 58 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut13
3
0 0
1 1
215 0
2
0 60 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut14
3
0 0
1 1
217 0
2
0 62 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut15
3
0 0
1 1
219 0
2
0 64 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut16
3
0 0
1 1
221 0
2
0 66 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut17
3
0 0
1 1
223 0
2
0 68 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut18
3
0 0
1 1
225 0
2
0 70 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut19
3
0 0
1 1
227 0
2
0 72 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut2
3
0 0
1 1
229 0
2
0 74 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut20
3
0 0
1 1
231 0
2
0 76 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut21
3
0 0
1 1
233 0
2
0 78 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut22
3
0 0
1 1
235 0
2
0 80 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut23
3
0 0
1 1
237 0
2
0 82 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut24
3
0 0
1 1
239 0
2
0 84 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut25
3
0 0
1 1
241 0
2
0 86 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut26
3
0 0
1 1
243 0
2
0 88 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut27
3
0 0
1 1
245 0
2
0 90 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut28
3
0 0
1 1
247 0
2
0 92 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut29
3
0 0
1 1
249 0
2
0 94 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut3
3
0 0
1 1
251 0
2
0 96 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut30
3
0 0
1 1
253 0
2
0 98 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut31
3
0 0
1 1
255 0
2
0 100 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut32
3
0 0
1 1
257 0
2
0 102 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut33
3
0 0
1 1
259 0
2
0 104 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut34
3
0 0
1 1
261 0
2
0 106 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut35
3
0 0
1 1
263 0
2
0 108 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut36
3
0 0
1 1
265 0
2
0 110 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut37
3
0 0
1 1
267 0
2
0 112 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut38
3
0 0
1 1
269 0
2
0 114 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut39
3
0 0
1 1
271 0
2
0 116 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut4
3
0 0
1 1
273 0
2
0 118 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut40
3
0 0
1 1
275 0
2
0 120 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut41
3
0 0
1 1
277 0
2
0 122 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut42
3
0 0
1 1
279 0
2
0 124 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut43
3
0 0
1 1
281 0
2
0 126 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut44
3
0 0
1 1
283 0
2
0 128 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut45
3
0 0
1 1
285 0
2
0 130 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut46
3
0 0
1 1
287 0
2
0 132 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut47
3
0 0
1 1
289 0
2
0 134 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut48
3
0 0
1 1
291 0
2
0 136 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut49
3
0 0
1 1
293 0
2
0 138 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut5
3
0 0
1 1
295 0
2
0 140 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut50
3
0 0
1 1
297 0
2
0 142 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut51
3
0 0
1 1
299 0
2
0 144 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut52
3
0 0
1 1
301 0
2
0 146 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut53
3
0 0
1 1
303 0
2
0 148 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut54
3
0 0
1 1
305 0
2
0 150 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut55
3
0 0
1 1
307 0
2
0 152 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut56
3
0 0
1 1
309 0
2
0 154 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut57
3
0 0
1 1
311 0
2
0 156 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut58
3
0 0
1 1
313 0
2
0 158 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut59
3
0 0
1 1
315 0
2
0 160 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut6
3
0 0
1 1
317 0
2
0 162 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut60
3
0 0
1 1
319 0
2
0 164 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut61
3
0 0
1 1
321 0
2
0 166 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut62
3
0 0
1 1
323 0
2
0 168 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut63
3
0 0
1 1
325 0
2
0 170 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut7
3
0 0
1 1
327 0
2
0 172 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut8
3
0 0
1 1
329 0
2
0 174 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner1 bob nut9
3
0 0
1 1
331 0
2
0 176 0 1
0 190 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut1
3
0 0
2 1
207 0
2
0 52 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut10
3
0 0
2 1
209 0
2
0 54 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut11
3
0 0
2 1
211 0
2
0 56 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut12
3
0 0
2 1
213 0
2
0 58 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut13
3
0 0
2 1
215 0
2
0 60 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut14
3
0 0
2 1
217 0
2
0 62 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut15
3
0 0
2 1
219 0
2
0 64 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut16
3
0 0
2 1
221 0
2
0 66 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut17
3
0 0
2 1
223 0
2
0 68 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut18
3
0 0
2 1
225 0
2
0 70 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut19
3
0 0
2 1
227 0
2
0 72 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut2
3
0 0
2 1
229 0
2
0 74 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut20
3
0 0
2 1
231 0
2
0 76 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut21
3
0 0
2 1
233 0
2
0 78 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut22
3
0 0
2 1
235 0
2
0 80 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut23
3
0 0
2 1
237 0
2
0 82 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut24
3
0 0
2 1
239 0
2
0 84 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut25
3
0 0
2 1
241 0
2
0 86 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut26
3
0 0
2 1
243 0
2
0 88 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut27
3
0 0
2 1
245 0
2
0 90 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut28
3
0 0
2 1
247 0
2
0 92 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut29
3
0 0
2 1
249 0
2
0 94 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut3
3
0 0
2 1
251 0
2
0 96 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut30
3
0 0
2 1
253 0
2
0 98 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut31
3
0 0
2 1
255 0
2
0 100 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut32
3
0 0
2 1
257 0
2
0 102 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut33
3
0 0
2 1
259 0
2
0 104 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut34
3
0 0
2 1
261 0
2
0 106 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut35
3
0 0
2 1
263 0
2
0 108 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut36
3
0 0
2 1
265 0
2
0 110 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut37
3
0 0
2 1
267 0
2
0 112 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut38
3
0 0
2 1
269 0
2
0 114 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut39
3
0 0
2 1
271 0
2
0 116 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut4
3
0 0
2 1
273 0
2
0 118 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut40
3
0 0
2 1
275 0
2
0 120 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut41
3
0 0
2 1
277 0
2
0 122 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut42
3
0 0
2 1
279 0
2
0 124 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut43
3
0 0
2 1
281 0
2
0 126 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut44
3
0 0
2 1
283 0
2
0 128 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut45
3
0 0
2 1
285 0
2
0 130 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut46
3
0 0
2 1
287 0
2
0 132 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut47
3
0 0
2 1
289 0
2
0 134 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut48
3
0 0
2 1
291 0
2
0 136 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut49
3
0 0
2 1
293 0
2
0 138 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut5
3
0 0
2 1
295 0
2
0 140 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut50
3
0 0
2 1
297 0
2
0 142 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut51
3
0 0
2 1
299 0
2
0 144 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut52
3
0 0
2 1
301 0
2
0 146 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut53
3
0 0
2 1
303 0
2
0 148 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut54
3
0 0
2 1
305 0
2
0 150 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut55
3
0 0
2 1
307 0
2
0 152 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut56
3
0 0
2 1
309 0
2
0 154 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut57
3
0 0
2 1
311 0
2
0 156 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut58
3
0 0
2 1
313 0
2
0 158 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut59
3
0 0
2 1
315 0
2
0 160 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut6
3
0 0
2 1
317 0
2
0 162 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut60
3
0 0
2 1
319 0
2
0 164 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut61
3
0 0
2 1
321 0
2
0 166 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut62
3
0 0
2 1
323 0
2
0 168 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut63
3
0 0
2 1
325 0
2
0 170 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut7
3
0 0
2 1
327 0
2
0 172 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut8
3
0 0
2 1
329 0
2
0 174 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner10 bob nut9
3
0 0
2 1
331 0
2
0 176 0 1
0 191 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut1
3
0 0
3 1
207 0
2
0 52 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut10
3
0 0
3 1
209 0
2
0 54 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut11
3
0 0
3 1
211 0
2
0 56 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut12
3
0 0
3 1
213 0
2
0 58 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut13
3
0 0
3 1
215 0
2
0 60 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut14
3
0 0
3 1
217 0
2
0 62 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut15
3
0 0
3 1
219 0
2
0 64 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut16
3
0 0
3 1
221 0
2
0 66 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut17
3
0 0
3 1
223 0
2
0 68 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut18
3
0 0
3 1
225 0
2
0 70 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut19
3
0 0
3 1
227 0
2
0 72 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut2
3
0 0
3 1
229 0
2
0 74 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut20
3
0 0
3 1
231 0
2
0 76 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut21
3
0 0
3 1
233 0
2
0 78 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut22
3
0 0
3 1
235 0
2
0 80 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut23
3
0 0
3 1
237 0
2
0 82 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut24
3
0 0
3 1
239 0
2
0 84 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut25
3
0 0
3 1
241 0
2
0 86 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut26
3
0 0
3 1
243 0
2
0 88 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut27
3
0 0
3 1
245 0
2
0 90 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut28
3
0 0
3 1
247 0
2
0 92 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut29
3
0 0
3 1
249 0
2
0 94 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut3
3
0 0
3 1
251 0
2
0 96 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut30
3
0 0
3 1
253 0
2
0 98 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut31
3
0 0
3 1
255 0
2
0 100 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut32
3
0 0
3 1
257 0
2
0 102 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut33
3
0 0
3 1
259 0
2
0 104 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut34
3
0 0
3 1
261 0
2
0 106 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut35
3
0 0
3 1
263 0
2
0 108 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut36
3
0 0
3 1
265 0
2
0 110 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut37
3
0 0
3 1
267 0
2
0 112 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut38
3
0 0
3 1
269 0
2
0 114 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut39
3
0 0
3 1
271 0
2
0 116 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut4
3
0 0
3 1
273 0
2
0 118 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut40
3
0 0
3 1
275 0
2
0 120 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut41
3
0 0
3 1
277 0
2
0 122 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut42
3
0 0
3 1
279 0
2
0 124 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut43
3
0 0
3 1
281 0
2
0 126 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut44
3
0 0
3 1
283 0
2
0 128 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut45
3
0 0
3 1
285 0
2
0 130 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut46
3
0 0
3 1
287 0
2
0 132 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut47
3
0 0
3 1
289 0
2
0 134 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut48
3
0 0
3 1
291 0
2
0 136 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut49
3
0 0
3 1
293 0
2
0 138 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut5
3
0 0
3 1
295 0
2
0 140 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut50
3
0 0
3 1
297 0
2
0 142 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut51
3
0 0
3 1
299 0
2
0 144 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut52
3
0 0
3 1
301 0
2
0 146 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut53
3
0 0
3 1
303 0
2
0 148 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut54
3
0 0
3 1
305 0
2
0 150 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut55
3
0 0
3 1
307 0
2
0 152 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut56
3
0 0
3 1
309 0
2
0 154 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut57
3
0 0
3 1
311 0
2
0 156 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut58
3
0 0
3 1
313 0
2
0 158 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut59
3
0 0
3 1
315 0
2
0 160 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut6
3
0 0
3 1
317 0
2
0 162 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut60
3
0 0
3 1
319 0
2
0 164 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut61
3
0 0
3 1
321 0
2
0 166 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut62
3
0 0
3 1
323 0
2
0 168 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut63
3
0 0
3 1
325 0
2
0 170 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut7
3
0 0
3 1
327 0
2
0 172 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut8
3
0 0
3 1
329 0
2
0 174 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner100 bob nut9
3
0 0
3 1
331 0
2
0 176 0 1
0 192 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut1
3
0 0
4 1
207 0
2
0 52 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut10
3
0 0
4 1
209 0
2
0 54 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut11
3
0 0
4 1
211 0
2
0 56 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut12
3
0 0
4 1
213 0
2
0 58 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut13
3
0 0
4 1
215 0
2
0 60 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut14
3
0 0
4 1
217 0
2
0 62 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut15
3
0 0
4 1
219 0
2
0 64 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut16
3
0 0
4 1
221 0
2
0 66 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut17
3
0 0
4 1
223 0
2
0 68 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut18
3
0 0
4 1
225 0
2
0 70 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut19
3
0 0
4 1
227 0
2
0 72 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut2
3
0 0
4 1
229 0
2
0 74 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut20
3
0 0
4 1
231 0
2
0 76 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut21
3
0 0
4 1
233 0
2
0 78 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut22
3
0 0
4 1
235 0
2
0 80 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut23
3
0 0
4 1
237 0
2
0 82 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut24
3
0 0
4 1
239 0
2
0 84 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut25
3
0 0
4 1
241 0
2
0 86 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut26
3
0 0
4 1
243 0
2
0 88 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut27
3
0 0
4 1
245 0
2
0 90 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut28
3
0 0
4 1
247 0
2
0 92 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut29
3
0 0
4 1
249 0
2
0 94 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut3
3
0 0
4 1
251 0
2
0 96 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut30
3
0 0
4 1
253 0
2
0 98 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut31
3
0 0
4 1
255 0
2
0 100 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut32
3
0 0
4 1
257 0
2
0 102 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut33
3
0 0
4 1
259 0
2
0 104 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut34
3
0 0
4 1
261 0
2
0 106 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut35
3
0 0
4 1
263 0
2
0 108 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut36
3
0 0
4 1
265 0
2
0 110 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut37
3
0 0
4 1
267 0
2
0 112 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut38
3
0 0
4 1
269 0
2
0 114 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut39
3
0 0
4 1
271 0
2
0 116 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut4
3
0 0
4 1
273 0
2
0 118 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut40
3
0 0
4 1
275 0
2
0 120 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut41
3
0 0
4 1
277 0
2
0 122 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut42
3
0 0
4 1
279 0
2
0 124 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut43
3
0 0
4 1
281 0
2
0 126 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut44
3
0 0
4 1
283 0
2
0 128 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut45
3
0 0
4 1
285 0
2
0 130 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut46
3
0 0
4 1
287 0
2
0 132 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut47
3
0 0
4 1
289 0
2
0 134 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut48
3
0 0
4 1
291 0
2
0 136 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut49
3
0 0
4 1
293 0
2
0 138 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut5
3
0 0
4 1
295 0
2
0 140 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut50
3
0 0
4 1
297 0
2
0 142 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut51
3
0 0
4 1
299 0
2
0 144 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut52
3
0 0
4 1
301 0
2
0 146 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut53
3
0 0
4 1
303 0
2
0 148 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut54
3
0 0
4 1
305 0
2
0 150 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut55
3
0 0
4 1
307 0
2
0 152 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut56
3
0 0
4 1
309 0
2
0 154 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut57
3
0 0
4 1
311 0
2
0 156 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut58
3
0 0
4 1
313 0
2
0 158 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut59
3
0 0
4 1
315 0
2
0 160 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut6
3
0 0
4 1
317 0
2
0 162 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut60
3
0 0
4 1
319 0
2
0 164 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut61
3
0 0
4 1
321 0
2
0 166 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut62
3
0 0
4 1
323 0
2
0 168 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut63
3
0 0
4 1
325 0
2
0 170 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut7
3
0 0
4 1
327 0
2
0 172 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut8
3
0 0
4 1
329 0
2
0 174 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner101 bob nut9
3
0 0
4 1
331 0
2
0 176 0 1
0 193 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut1
3
0 0
5 1
207 0
2
0 52 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut10
3
0 0
5 1
209 0
2
0 54 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut11
3
0 0
5 1
211 0
2
0 56 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut12
3
0 0
5 1
213 0
2
0 58 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut13
3
0 0
5 1
215 0
2
0 60 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut14
3
0 0
5 1
217 0
2
0 62 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut15
3
0 0
5 1
219 0
2
0 64 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut16
3
0 0
5 1
221 0
2
0 66 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut17
3
0 0
5 1
223 0
2
0 68 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut18
3
0 0
5 1
225 0
2
0 70 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut19
3
0 0
5 1
227 0
2
0 72 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut2
3
0 0
5 1
229 0
2
0 74 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut20
3
0 0
5 1
231 0
2
0 76 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut21
3
0 0
5 1
233 0
2
0 78 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut22
3
0 0
5 1
235 0
2
0 80 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut23
3
0 0
5 1
237 0
2
0 82 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut24
3
0 0
5 1
239 0
2
0 84 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut25
3
0 0
5 1
241 0
2
0 86 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut26
3
0 0
5 1
243 0
2
0 88 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut27
3
0 0
5 1
245 0
2
0 90 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut28
3
0 0
5 1
247 0
2
0 92 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut29
3
0 0
5 1
249 0
2
0 94 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut3
3
0 0
5 1
251 0
2
0 96 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut30
3
0 0
5 1
253 0
2
0 98 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut31
3
0 0
5 1
255 0
2
0 100 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut32
3
0 0
5 1
257 0
2
0 102 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut33
3
0 0
5 1
259 0
2
0 104 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut34
3
0 0
5 1
261 0
2
0 106 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut35
3
0 0
5 1
263 0
2
0 108 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut36
3
0 0
5 1
265 0
2
0 110 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut37
3
0 0
5 1
267 0
2
0 112 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut38
3
0 0
5 1
269 0
2
0 114 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut39
3
0 0
5 1
271 0
2
0 116 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut4
3
0 0
5 1
273 0
2
0 118 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut40
3
0 0
5 1
275 0
2
0 120 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut41
3
0 0
5 1
277 0
2
0 122 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut42
3
0 0
5 1
279 0
2
0 124 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut43
3
0 0
5 1
281 0
2
0 126 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut44
3
0 0
5 1
283 0
2
0 128 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut45
3
0 0
5 1
285 0
2
0 130 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut46
3
0 0
5 1
287 0
2
0 132 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut47
3
0 0
5 1
289 0
2
0 134 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut48
3
0 0
5 1
291 0
2
0 136 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut49
3
0 0
5 1
293 0
2
0 138 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut5
3
0 0
5 1
295 0
2
0 140 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut50
3
0 0
5 1
297 0
2
0 142 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut51
3
0 0
5 1
299 0
2
0 144 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut52
3
0 0
5 1
301 0
2
0 146 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut53
3
0 0
5 1
303 0
2
0 148 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut54
3
0 0
5 1
305 0
2
0 150 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut55
3
0 0
5 1
307 0
2
0 152 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut56
3
0 0
5 1
309 0
2
0 154 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut57
3
0 0
5 1
311 0
2
0 156 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut58
3
0 0
5 1
313 0
2
0 158 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut59
3
0 0
5 1
315 0
2
0 160 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut6
3
0 0
5 1
317 0
2
0 162 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut60
3
0 0
5 1
319 0
2
0 164 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut61
3
0 0
5 1
321 0
2
0 166 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut62
3
0 0
5 1
323 0
2
0 168 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut63
3
0 0
5 1
325 0
2
0 170 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut7
3
0 0
5 1
327 0
2
0 172 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut8
3
0 0
5 1
329 0
2
0 174 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner102 bob nut9
3
0 0
5 1
331 0
2
0 176 0 1
0 194 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut1
3
0 0
6 1
207 0
2
0 52 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut10
3
0 0
6 1
209 0
2
0 54 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut11
3
0 0
6 1
211 0
2
0 56 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut12
3
0 0
6 1
213 0
2
0 58 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut13
3
0 0
6 1
215 0
2
0 60 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut14
3
0 0
6 1
217 0
2
0 62 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut15
3
0 0
6 1
219 0
2
0 64 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut16
3
0 0
6 1
221 0
2
0 66 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut17
3
0 0
6 1
223 0
2
0 68 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut18
3
0 0
6 1
225 0
2
0 70 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut19
3
0 0
6 1
227 0
2
0 72 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut2
3
0 0
6 1
229 0
2
0 74 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut20
3
0 0
6 1
231 0
2
0 76 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut21
3
0 0
6 1
233 0
2
0 78 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut22
3
0 0
6 1
235 0
2
0 80 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut23
3
0 0
6 1
237 0
2
0 82 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut24
3
0 0
6 1
239 0
2
0 84 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut25
3
0 0
6 1
241 0
2
0 86 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut26
3
0 0
6 1
243 0
2
0 88 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut27
3
0 0
6 1
245 0
2
0 90 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut28
3
0 0
6 1
247 0
2
0 92 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut29
3
0 0
6 1
249 0
2
0 94 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut3
3
0 0
6 1
251 0
2
0 96 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut30
3
0 0
6 1
253 0
2
0 98 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut31
3
0 0
6 1
255 0
2
0 100 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut32
3
0 0
6 1
257 0
2
0 102 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut33
3
0 0
6 1
259 0
2
0 104 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut34
3
0 0
6 1
261 0
2
0 106 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut35
3
0 0
6 1
263 0
2
0 108 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut36
3
0 0
6 1
265 0
2
0 110 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut37
3
0 0
6 1
267 0
2
0 112 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut38
3
0 0
6 1
269 0
2
0 114 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut39
3
0 0
6 1
271 0
2
0 116 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut4
3
0 0
6 1
273 0
2
0 118 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut40
3
0 0
6 1
275 0
2
0 120 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut41
3
0 0
6 1
277 0
2
0 122 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut42
3
0 0
6 1
279 0
2
0 124 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut43
3
0 0
6 1
281 0
2
0 126 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut44
3
0 0
6 1
283 0
2
0 128 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut45
3
0 0
6 1
285 0
2
0 130 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut46
3
0 0
6 1
287 0
2
0 132 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut47
3
0 0
6 1
289 0
2
0 134 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut48
3
0 0
6 1
291 0
2
0 136 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut49
3
0 0
6 1
293 0
2
0 138 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut5
3
0 0
6 1
295 0
2
0 140 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut50
3
0 0
6 1
297 0
2
0 142 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut51
3
0 0
6 1
299 0
2
0 144 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut52
3
0 0
6 1
301 0
2
0 146 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut53
3
0 0
6 1
303 0
2
0 148 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut54
3
0 0
6 1
305 0
2
0 150 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut55
3
0 0
6 1
307 0
2
0 152 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut56
3
0 0
6 1
309 0
2
0 154 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut57
3
0 0
6 1
311 0
2
0 156 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut58
3
0 0
6 1
313 0
2
0 158 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut59
3
0 0
6 1
315 0
2
0 160 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut6
3
0 0
6 1
317 0
2
0 162 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut60
3
0 0
6 1
319 0
2
0 164 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut61
3
0 0
6 1
321 0
2
0 166 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut62
3
0 0
6 1
323 0
2
0 168 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut63
3
0 0
6 1
325 0
2
0 170 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut7
3
0 0
6 1
327 0
2
0 172 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut8
3
0 0
6 1
329 0
2
0 174 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner103 bob nut9
3
0 0
6 1
331 0
2
0 176 0 1
0 195 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut1
3
0 0
7 1
207 0
2
0 52 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut10
3
0 0
7 1
209 0
2
0 54 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut11
3
0 0
7 1
211 0
2
0 56 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut12
3
0 0
7 1
213 0
2
0 58 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut13
3
0 0
7 1
215 0
2
0 60 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut14
3
0 0
7 1
217 0
2
0 62 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut15
3
0 0
7 1
219 0
2
0 64 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut16
3
0 0
7 1
221 0
2
0 66 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut17
3
0 0
7 1
223 0
2
0 68 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut18
3
0 0
7 1
225 0
2
0 70 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut19
3
0 0
7 1
227 0
2
0 72 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut2
3
0 0
7 1
229 0
2
0 74 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut20
3
0 0
7 1
231 0
2
0 76 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut21
3
0 0
7 1
233 0
2
0 78 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut22
3
0 0
7 1
235 0
2
0 80 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut23
3
0 0
7 1
237 0
2
0 82 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut24
3
0 0
7 1
239 0
2
0 84 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut25
3
0 0
7 1
241 0
2
0 86 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut26
3
0 0
7 1
243 0
2
0 88 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut27
3
0 0
7 1
245 0
2
0 90 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut28
3
0 0
7 1
247 0
2
0 92 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut29
3
0 0
7 1
249 0
2
0 94 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut3
3
0 0
7 1
251 0
2
0 96 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut30
3
0 0
7 1
253 0
2
0 98 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut31
3
0 0
7 1
255 0
2
0 100 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut32
3
0 0
7 1
257 0
2
0 102 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut33
3
0 0
7 1
259 0
2
0 104 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut34
3
0 0
7 1
261 0
2
0 106 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut35
3
0 0
7 1
263 0
2
0 108 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut36
3
0 0
7 1
265 0
2
0 110 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut37
3
0 0
7 1
267 0
2
0 112 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut38
3
0 0
7 1
269 0
2
0 114 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut39
3
0 0
7 1
271 0
2
0 116 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut4
3
0 0
7 1
273 0
2
0 118 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut40
3
0 0
7 1
275 0
2
0 120 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut41
3
0 0
7 1
277 0
2
0 122 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut42
3
0 0
7 1
279 0
2
0 124 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut43
3
0 0
7 1
281 0
2
0 126 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut44
3
0 0
7 1
283 0
2
0 128 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut45
3
0 0
7 1
285 0
2
0 130 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut46
3
0 0
7 1
287 0
2
0 132 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut47
3
0 0
7 1
289 0
2
0 134 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut48
3
0 0
7 1
291 0
2
0 136 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut49
3
0 0
7 1
293 0
2
0 138 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut5
3
0 0
7 1
295 0
2
0 140 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut50
3
0 0
7 1
297 0
2
0 142 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut51
3
0 0
7 1
299 0
2
0 144 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut52
3
0 0
7 1
301 0
2
0 146 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut53
3
0 0
7 1
303 0
2
0 148 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut54
3
0 0
7 1
305 0
2
0 150 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut55
3
0 0
7 1
307 0
2
0 152 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut56
3
0 0
7 1
309 0
2
0 154 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut57
3
0 0
7 1
311 0
2
0 156 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut58
3
0 0
7 1
313 0
2
0 158 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut59
3
0 0
7 1
315 0
2
0 160 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut6
3
0 0
7 1
317 0
2
0 162 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut60
3
0 0
7 1
319 0
2
0 164 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut61
3
0 0
7 1
321 0
2
0 166 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut62
3
0 0
7 1
323 0
2
0 168 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut63
3
0 0
7 1
325 0
2
0 170 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut7
3
0 0
7 1
327 0
2
0 172 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut8
3
0 0
7 1
329 0
2
0 174 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner104 bob nut9
3
0 0
7 1
331 0
2
0 176 0 1
0 196 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut1
3
0 0
8 1
207 0
2
0 52 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut10
3
0 0
8 1
209 0
2
0 54 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut11
3
0 0
8 1
211 0
2
0 56 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut12
3
0 0
8 1
213 0
2
0 58 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut13
3
0 0
8 1
215 0
2
0 60 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut14
3
0 0
8 1
217 0
2
0 62 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut15
3
0 0
8 1
219 0
2
0 64 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut16
3
0 0
8 1
221 0
2
0 66 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut17
3
0 0
8 1
223 0
2
0 68 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut18
3
0 0
8 1
225 0
2
0 70 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut19
3
0 0
8 1
227 0
2
0 72 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut2
3
0 0
8 1
229 0
2
0 74 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut20
3
0 0
8 1
231 0
2
0 76 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut21
3
0 0
8 1
233 0
2
0 78 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut22
3
0 0
8 1
235 0
2
0 80 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut23
3
0 0
8 1
237 0
2
0 82 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut24
3
0 0
8 1
239 0
2
0 84 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut25
3
0 0
8 1
241 0
2
0 86 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut26
3
0 0
8 1
243 0
2
0 88 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut27
3
0 0
8 1
245 0
2
0 90 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut28
3
0 0
8 1
247 0
2
0 92 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut29
3
0 0
8 1
249 0
2
0 94 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut3
3
0 0
8 1
251 0
2
0 96 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut30
3
0 0
8 1
253 0
2
0 98 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut31
3
0 0
8 1
255 0
2
0 100 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut32
3
0 0
8 1
257 0
2
0 102 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut33
3
0 0
8 1
259 0
2
0 104 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut34
3
0 0
8 1
261 0
2
0 106 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut35
3
0 0
8 1
263 0
2
0 108 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut36
3
0 0
8 1
265 0
2
0 110 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut37
3
0 0
8 1
267 0
2
0 112 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut38
3
0 0
8 1
269 0
2
0 114 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut39
3
0 0
8 1
271 0
2
0 116 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut4
3
0 0
8 1
273 0
2
0 118 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut40
3
0 0
8 1
275 0
2
0 120 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut41
3
0 0
8 1
277 0
2
0 122 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut42
3
0 0
8 1
279 0
2
0 124 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut43
3
0 0
8 1
281 0
2
0 126 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut44
3
0 0
8 1
283 0
2
0 128 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut45
3
0 0
8 1
285 0
2
0 130 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut46
3
0 0
8 1
287 0
2
0 132 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut47
3
0 0
8 1
289 0
2
0 134 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut48
3
0 0
8 1
291 0
2
0 136 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut49
3
0 0
8 1
293 0
2
0 138 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut5
3
0 0
8 1
295 0
2
0 140 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut50
3
0 0
8 1
297 0
2
0 142 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut51
3
0 0
8 1
299 0
2
0 144 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut52
3
0 0
8 1
301 0
2
0 146 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut53
3
0 0
8 1
303 0
2
0 148 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut54
3
0 0
8 1
305 0
2
0 150 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut55
3
0 0
8 1
307 0
2
0 152 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut56
3
0 0
8 1
309 0
2
0 154 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut57
3
0 0
8 1
311 0
2
0 156 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut58
3
0 0
8 1
313 0
2
0 158 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut59
3
0 0
8 1
315 0
2
0 160 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut6
3
0 0
8 1
317 0
2
0 162 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut60
3
0 0
8 1
319 0
2
0 164 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut61
3
0 0
8 1
321 0
2
0 166 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut62
3
0 0
8 1
323 0
2
0 168 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut63
3
0 0
8 1
325 0
2
0 170 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut7
3
0 0
8 1
327 0
2
0 172 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut8
3
0 0
8 1
329 0
2
0 174 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner105 bob nut9
3
0 0
8 1
331 0
2
0 176 0 1
0 197 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut1
3
0 0
9 1
207 0
2
0 52 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut10
3
0 0
9 1
209 0
2
0 54 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut11
3
0 0
9 1
211 0
2
0 56 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut12
3
0 0
9 1
213 0
2
0 58 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut13
3
0 0
9 1
215 0
2
0 60 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut14
3
0 0
9 1
217 0
2
0 62 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut15
3
0 0
9 1
219 0
2
0 64 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut16
3
0 0
9 1
221 0
2
0 66 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut17
3
0 0
9 1
223 0
2
0 68 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut18
3
0 0
9 1
225 0
2
0 70 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut19
3
0 0
9 1
227 0
2
0 72 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut2
3
0 0
9 1
229 0
2
0 74 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut20
3
0 0
9 1
231 0
2
0 76 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut21
3
0 0
9 1
233 0
2
0 78 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut22
3
0 0
9 1
235 0
2
0 80 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut23
3
0 0
9 1
237 0
2
0 82 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut24
3
0 0
9 1
239 0
2
0 84 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut25
3
0 0
9 1
241 0
2
0 86 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut26
3
0 0
9 1
243 0
2
0 88 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut27
3
0 0
9 1
245 0
2
0 90 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut28
3
0 0
9 1
247 0
2
0 92 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut29
3
0 0
9 1
249 0
2
0 94 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut3
3
0 0
9 1
251 0
2
0 96 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut30
3
0 0
9 1
253 0
2
0 98 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut31
3
0 0
9 1
255 0
2
0 100 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut32
3
0 0
9 1
257 0
2
0 102 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut33
3
0 0
9 1
259 0
2
0 104 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut34
3
0 0
9 1
261 0
2
0 106 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut35
3
0 0
9 1
263 0
2
0 108 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut36
3
0 0
9 1
265 0
2
0 110 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut37
3
0 0
9 1
267 0
2
0 112 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut38
3
0 0
9 1
269 0
2
0 114 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut39
3
0 0
9 1
271 0
2
0 116 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut4
3
0 0
9 1
273 0
2
0 118 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut40
3
0 0
9 1
275 0
2
0 120 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut41
3
0 0
9 1
277 0
2
0 122 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut42
3
0 0
9 1
279 0
2
0 124 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut43
3
0 0
9 1
281 0
2
0 126 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut44
3
0 0
9 1
283 0
2
0 128 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut45
3
0 0
9 1
285 0
2
0 130 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut46
3
0 0
9 1
287 0
2
0 132 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut47
3
0 0
9 1
289 0
2
0 134 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut48
3
0 0
9 1
291 0
2
0 136 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut49
3
0 0
9 1
293 0
2
0 138 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut5
3
0 0
9 1
295 0
2
0 140 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut50
3
0 0
9 1
297 0
2
0 142 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut51
3
0 0
9 1
299 0
2
0 144 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut52
3
0 0
9 1
301 0
2
0 146 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut53
3
0 0
9 1
303 0
2
0 148 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut54
3
0 0
9 1
305 0
2
0 150 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut55
3
0 0
9 1
307 0
2
0 152 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut56
3
0 0
9 1
309 0
2
0 154 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut57
3
0 0
9 1
311 0
2
0 156 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut58
3
0 0
9 1
313 0
2
0 158 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut59
3
0 0
9 1
315 0
2
0 160 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut6
3
0 0
9 1
317 0
2
0 162 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut60
3
0 0
9 1
319 0
2
0 164 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut61
3
0 0
9 1
321 0
2
0 166 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut62
3
0 0
9 1
323 0
2
0 168 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut63
3
0 0
9 1
325 0
2
0 170 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut7
3
0 0
9 1
327 0
2
0 172 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut8
3
0 0
9 1
329 0
2
0 174 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner106 bob nut9
3
0 0
9 1
331 0
2
0 176 0 1
0 198 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut1
3
0 0
10 1
207 0
2
0 52 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut10
3
0 0
10 1
209 0
2
0 54 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut11
3
0 0
10 1
211 0
2
0 56 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut12
3
0 0
10 1
213 0
2
0 58 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut13
3
0 0
10 1
215 0
2
0 60 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut14
3
0 0
10 1
217 0
2
0 62 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut15
3
0 0
10 1
219 0
2
0 64 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut16
3
0 0
10 1
221 0
2
0 66 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut17
3
0 0
10 1
223 0
2
0 68 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut18
3
0 0
10 1
225 0
2
0 70 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut19
3
0 0
10 1
227 0
2
0 72 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut2
3
0 0
10 1
229 0
2
0 74 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut20
3
0 0
10 1
231 0
2
0 76 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut21
3
0 0
10 1
233 0
2
0 78 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut22
3
0 0
10 1
235 0
2
0 80 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut23
3
0 0
10 1
237 0
2
0 82 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut24
3
0 0
10 1
239 0
2
0 84 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut25
3
0 0
10 1
241 0
2
0 86 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut26
3
0 0
10 1
243 0
2
0 88 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut27
3
0 0
10 1
245 0
2
0 90 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut28
3
0 0
10 1
247 0
2
0 92 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut29
3
0 0
10 1
249 0
2
0 94 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut3
3
0 0
10 1
251 0
2
0 96 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut30
3
0 0
10 1
253 0
2
0 98 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut31
3
0 0
10 1
255 0
2
0 100 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut32
3
0 0
10 1
257 0
2
0 102 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut33
3
0 0
10 1
259 0
2
0 104 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut34
3
0 0
10 1
261 0
2
0 106 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut35
3
0 0
10 1
263 0
2
0 108 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut36
3
0 0
10 1
265 0
2
0 110 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut37
3
0 0
10 1
267 0
2
0 112 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut38
3
0 0
10 1
269 0
2
0 114 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut39
3
0 0
10 1
271 0
2
0 116 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut4
3
0 0
10 1
273 0
2
0 118 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut40
3
0 0
10 1
275 0
2
0 120 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut41
3
0 0
10 1
277 0
2
0 122 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut42
3
0 0
10 1
279 0
2
0 124 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut43
3
0 0
10 1
281 0
2
0 126 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut44
3
0 0
10 1
283 0
2
0 128 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut45
3
0 0
10 1
285 0
2
0 130 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut46
3
0 0
10 1
287 0
2
0 132 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut47
3
0 0
10 1
289 0
2
0 134 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut48
3
0 0
10 1
291 0
2
0 136 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut49
3
0 0
10 1
293 0
2
0 138 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut5
3
0 0
10 1
295 0
2
0 140 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut50
3
0 0
10 1
297 0
2
0 142 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut51
3
0 0
10 1
299 0
2
0 144 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut52
3
0 0
10 1
301 0
2
0 146 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut53
3
0 0
10 1
303 0
2
0 148 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut54
3
0 0
10 1
305 0
2
0 150 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut55
3
0 0
10 1
307 0
2
0 152 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut56
3
0 0
10 1
309 0
2
0 154 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut57
3
0 0
10 1
311 0
2
0 156 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut58
3
0 0
10 1
313 0
2
0 158 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut59
3
0 0
10 1
315 0
2
0 160 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut6
3
0 0
10 1
317 0
2
0 162 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut60
3
0 0
10 1
319 0
2
0 164 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut61
3
0 0
10 1
321 0
2
0 166 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut62
3
0 0
10 1
323 0
2
0 168 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut63
3
0 0
10 1
325 0
2
0 170 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut7
3
0 0
10 1
327 0
2
0 172 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut8
3
0 0
10 1
329 0
2
0 174 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner107 bob nut9
3
0 0
10 1
331 0
2
0 176 0 1
0 199 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut1
3
0 0
11 1
207 0
2
0 52 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut10
3
0 0
11 1
209 0
2
0 54 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut11
3
0 0
11 1
211 0
2
0 56 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut12
3
0 0
11 1
213 0
2
0 58 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut13
3
0 0
11 1
215 0
2
0 60 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut14
3
0 0
11 1
217 0
2
0 62 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut15
3
0 0
11 1
219 0
2
0 64 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut16
3
0 0
11 1
221 0
2
0 66 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut17
3
0 0
11 1
223 0
2
0 68 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut18
3
0 0
11 1
225 0
2
0 70 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut19
3
0 0
11 1
227 0
2
0 72 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut2
3
0 0
11 1
229 0
2
0 74 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut20
3
0 0
11 1
231 0
2
0 76 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut21
3
0 0
11 1
233 0
2
0 78 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut22
3
0 0
11 1
235 0
2
0 80 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut23
3
0 0
11 1
237 0
2
0 82 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut24
3
0 0
11 1
239 0
2
0 84 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut25
3
0 0
11 1
241 0
2
0 86 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut26
3
0 0
11 1
243 0
2
0 88 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut27
3
0 0
11 1
245 0
2
0 90 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut28
3
0 0
11 1
247 0
2
0 92 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut29
3
0 0
11 1
249 0
2
0 94 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut3
3
0 0
11 1
251 0
2
0 96 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut30
3
0 0
11 1
253 0
2
0 98 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut31
3
0 0
11 1
255 0
2
0 100 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut32
3
0 0
11 1
257 0
2
0 102 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut33
3
0 0
11 1
259 0
2
0 104 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut34
3
0 0
11 1
261 0
2
0 106 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut35
3
0 0
11 1
263 0
2
0 108 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut36
3
0 0
11 1
265 0
2
0 110 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut37
3
0 0
11 1
267 0
2
0 112 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut38
3
0 0
11 1
269 0
2
0 114 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut39
3
0 0
11 1
271 0
2
0 116 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut4
3
0 0
11 1
273 0
2
0 118 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut40
3
0 0
11 1
275 0
2
0 120 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut41
3
0 0
11 1
277 0
2
0 122 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut42
3
0 0
11 1
279 0
2
0 124 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut43
3
0 0
11 1
281 0
2
0 126 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut44
3
0 0
11 1
283 0
2
0 128 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut45
3
0 0
11 1
285 0
2
0 130 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut46
3
0 0
11 1
287 0
2
0 132 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut47
3
0 0
11 1
289 0
2
0 134 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut48
3
0 0
11 1
291 0
2
0 136 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut49
3
0 0
11 1
293 0
2
0 138 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut5
3
0 0
11 1
295 0
2
0 140 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut50
3
0 0
11 1
297 0
2
0 142 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut51
3
0 0
11 1
299 0
2
0 144 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut52
3
0 0
11 1
301 0
2
0 146 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut53
3
0 0
11 1
303 0
2
0 148 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut54
3
0 0
11 1
305 0
2
0 150 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut55
3
0 0
11 1
307 0
2
0 152 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut56
3
0 0
11 1
309 0
2
0 154 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut57
3
0 0
11 1
311 0
2
0 156 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut58
3
0 0
11 1
313 0
2
0 158 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut59
3
0 0
11 1
315 0
2
0 160 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut6
3
0 0
11 1
317 0
2
0 162 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut60
3
0 0
11 1
319 0
2
0 164 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut61
3
0 0
11 1
321 0
2
0 166 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut62
3
0 0
11 1
323 0
2
0 168 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut63
3
0 0
11 1
325 0
2
0 170 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut7
3
0 0
11 1
327 0
2
0 172 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut8
3
0 0
11 1
329 0
2
0 174 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner108 bob nut9
3
0 0
11 1
331 0
2
0 176 0 1
0 200 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut1
3
0 0
12 1
207 0
2
0 52 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut10
3
0 0
12 1
209 0
2
0 54 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut11
3
0 0
12 1
211 0
2
0 56 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut12
3
0 0
12 1
213 0
2
0 58 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut13
3
0 0
12 1
215 0
2
0 60 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut14
3
0 0
12 1
217 0
2
0 62 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut15
3
0 0
12 1
219 0
2
0 64 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut16
3
0 0
12 1
221 0
2
0 66 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut17
3
0 0
12 1
223 0
2
0 68 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut18
3
0 0
12 1
225 0
2
0 70 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut19
3
0 0
12 1
227 0
2
0 72 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut2
3
0 0
12 1
229 0
2
0 74 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut20
3
0 0
12 1
231 0
2
0 76 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut21
3
0 0
12 1
233 0
2
0 78 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut22
3
0 0
12 1
235 0
2
0 80 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut23
3
0 0
12 1
237 0
2
0 82 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut24
3
0 0
12 1
239 0
2
0 84 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut25
3
0 0
12 1
241 0
2
0 86 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut26
3
0 0
12 1
243 0
2
0 88 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut27
3
0 0
12 1
245 0
2
0 90 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut28
3
0 0
12 1
247 0
2
0 92 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut29
3
0 0
12 1
249 0
2
0 94 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut3
3
0 0
12 1
251 0
2
0 96 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut30
3
0 0
12 1
253 0
2
0 98 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut31
3
0 0
12 1
255 0
2
0 100 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut32
3
0 0
12 1
257 0
2
0 102 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut33
3
0 0
12 1
259 0
2
0 104 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut34
3
0 0
12 1
261 0
2
0 106 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut35
3
0 0
12 1
263 0
2
0 108 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut36
3
0 0
12 1
265 0
2
0 110 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut37
3
0 0
12 1
267 0
2
0 112 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut38
3
0 0
12 1
269 0
2
0 114 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut39
3
0 0
12 1
271 0
2
0 116 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut4
3
0 0
12 1
273 0
2
0 118 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut40
3
0 0
12 1
275 0
2
0 120 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut41
3
0 0
12 1
277 0
2
0 122 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut42
3
0 0
12 1
279 0
2
0 124 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut43
3
0 0
12 1
281 0
2
0 126 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut44
3
0 0
12 1
283 0
2
0 128 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut45
3
0 0
12 1
285 0
2
0 130 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut46
3
0 0
12 1
287 0
2
0 132 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut47
3
0 0
12 1
289 0
2
0 134 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut48
3
0 0
12 1
291 0
2
0 136 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut49
3
0 0
12 1
293 0
2
0 138 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut5
3
0 0
12 1
295 0
2
0 140 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut50
3
0 0
12 1
297 0
2
0 142 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut51
3
0 0
12 1
299 0
2
0 144 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut52
3
0 0
12 1
301 0
2
0 146 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut53
3
0 0
12 1
303 0
2
0 148 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut54
3
0 0
12 1
305 0
2
0 150 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut55
3
0 0
12 1
307 0
2
0 152 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut56
3
0 0
12 1
309 0
2
0 154 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut57
3
0 0
12 1
311 0
2
0 156 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut58
3
0 0
12 1
313 0
2
0 158 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut59
3
0 0
12 1
315 0
2
0 160 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut6
3
0 0
12 1
317 0
2
0 162 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut60
3
0 0
12 1
319 0
2
0 164 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut61
3
0 0
12 1
321 0
2
0 166 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut62
3
0 0
12 1
323 0
2
0 168 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut63
3
0 0
12 1
325 0
2
0 170 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut7
3
0 0
12 1
327 0
2
0 172 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut8
3
0 0
12 1
329 0
2
0 174 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner109 bob nut9
3
0 0
12 1
331 0
2
0 176 0 1
0 201 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut1
3
0 0
13 1
207 0
2
0 52 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut10
3
0 0
13 1
209 0
2
0 54 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut11
3
0 0
13 1
211 0
2
0 56 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut12
3
0 0
13 1
213 0
2
0 58 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut13
3
0 0
13 1
215 0
2
0 60 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut14
3
0 0
13 1
217 0
2
0 62 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut15
3
0 0
13 1
219 0
2
0 64 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut16
3
0 0
13 1
221 0
2
0 66 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut17
3
0 0
13 1
223 0
2
0 68 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut18
3
0 0
13 1
225 0
2
0 70 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut19
3
0 0
13 1
227 0
2
0 72 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut2
3
0 0
13 1
229 0
2
0 74 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut20
3
0 0
13 1
231 0
2
0 76 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut21
3
0 0
13 1
233 0
2
0 78 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut22
3
0 0
13 1
235 0
2
0 80 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut23
3
0 0
13 1
237 0
2
0 82 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut24
3
0 0
13 1
239 0
2
0 84 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut25
3
0 0
13 1
241 0
2
0 86 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut26
3
0 0
13 1
243 0
2
0 88 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut27
3
0 0
13 1
245 0
2
0 90 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut28
3
0 0
13 1
247 0
2
0 92 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut29
3
0 0
13 1
249 0
2
0 94 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut3
3
0 0
13 1
251 0
2
0 96 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut30
3
0 0
13 1
253 0
2
0 98 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut31
3
0 0
13 1
255 0
2
0 100 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut32
3
0 0
13 1
257 0
2
0 102 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut33
3
0 0
13 1
259 0
2
0 104 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut34
3
0 0
13 1
261 0
2
0 106 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut35
3
0 0
13 1
263 0
2
0 108 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut36
3
0 0
13 1
265 0
2
0 110 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut37
3
0 0
13 1
267 0
2
0 112 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut38
3
0 0
13 1
269 0
2
0 114 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut39
3
0 0
13 1
271 0
2
0 116 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut4
3
0 0
13 1
273 0
2
0 118 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut40
3
0 0
13 1
275 0
2
0 120 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut41
3
0 0
13 1
277 0
2
0 122 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut42
3
0 0
13 1
279 0
2
0 124 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut43
3
0 0
13 1
281 0
2
0 126 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut44
3
0 0
13 1
283 0
2
0 128 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut45
3
0 0
13 1
285 0
2
0 130 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut46
3
0 0
13 1
287 0
2
0 132 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut47
3
0 0
13 1
289 0
2
0 134 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut48
3
0 0
13 1
291 0
2
0 136 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut49
3
0 0
13 1
293 0
2
0 138 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut5
3
0 0
13 1
295 0
2
0 140 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut50
3
0 0
13 1
297 0
2
0 142 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut51
3
0 0
13 1
299 0
2
0 144 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut52
3
0 0
13 1
301 0
2
0 146 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut53
3
0 0
13 1
303 0
2
0 148 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut54
3
0 0
13 1
305 0
2
0 150 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut55
3
0 0
13 1
307 0
2
0 152 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut56
3
0 0
13 1
309 0
2
0 154 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut57
3
0 0
13 1
311 0
2
0 156 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut58
3
0 0
13 1
313 0
2
0 158 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut59
3
0 0
13 1
315 0
2
0 160 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut6
3
0 0
13 1
317 0
2
0 162 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut60
3
0 0
13 1
319 0
2
0 164 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut61
3
0 0
13 1
321 0
2
0 166 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut62
3
0 0
13 1
323 0
2
0 168 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut63
3
0 0
13 1
325 0
2
0 170 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut7
3
0 0
13 1
327 0
2
0 172 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut8
3
0 0
13 1
329 0
2
0 174 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner11 bob nut9
3
0 0
13 1
331 0
2
0 176 0 1
0 202 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut1
3
0 0
14 1
207 0
2
0 52 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut10
3
0 0
14 1
209 0
2
0 54 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut11
3
0 0
14 1
211 0
2
0 56 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut12
3
0 0
14 1
213 0
2
0 58 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut13
3
0 0
14 1
215 0
2
0 60 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut14
3
0 0
14 1
217 0
2
0 62 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut15
3
0 0
14 1
219 0
2
0 64 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut16
3
0 0
14 1
221 0
2
0 66 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut17
3
0 0
14 1
223 0
2
0 68 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut18
3
0 0
14 1
225 0
2
0 70 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut19
3
0 0
14 1
227 0
2
0 72 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut2
3
0 0
14 1
229 0
2
0 74 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut20
3
0 0
14 1
231 0
2
0 76 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut21
3
0 0
14 1
233 0
2
0 78 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut22
3
0 0
14 1
235 0
2
0 80 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut23
3
0 0
14 1
237 0
2
0 82 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut24
3
0 0
14 1
239 0
2
0 84 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut25
3
0 0
14 1
241 0
2
0 86 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut26
3
0 0
14 1
243 0
2
0 88 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut27
3
0 0
14 1
245 0
2
0 90 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut28
3
0 0
14 1
247 0
2
0 92 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut29
3
0 0
14 1
249 0
2
0 94 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut3
3
0 0
14 1
251 0
2
0 96 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut30
3
0 0
14 1
253 0
2
0 98 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut31
3
0 0
14 1
255 0
2
0 100 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut32
3
0 0
14 1
257 0
2
0 102 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut33
3
0 0
14 1
259 0
2
0 104 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut34
3
0 0
14 1
261 0
2
0 106 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut35
3
0 0
14 1
263 0
2
0 108 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut36
3
0 0
14 1
265 0
2
0 110 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut37
3
0 0
14 1
267 0
2
0 112 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut38
3
0 0
14 1
269 0
2
0 114 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut39
3
0 0
14 1
271 0
2
0 116 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut4
3
0 0
14 1
273 0
2
0 118 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut40
3
0 0
14 1
275 0
2
0 120 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut41
3
0 0
14 1
277 0
2
0 122 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut42
3
0 0
14 1
279 0
2
0 124 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut43
3
0 0
14 1
281 0
2
0 126 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut44
3
0 0
14 1
283 0
2
0 128 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut45
3
0 0
14 1
285 0
2
0 130 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut46
3
0 0
14 1
287 0
2
0 132 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut47
3
0 0
14 1
289 0
2
0 134 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut48
3
0 0
14 1
291 0
2
0 136 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut49
3
0 0
14 1
293 0
2
0 138 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut5
3
0 0
14 1
295 0
2
0 140 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut50
3
0 0
14 1
297 0
2
0 142 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut51
3
0 0
14 1
299 0
2
0 144 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut52
3
0 0
14 1
301 0
2
0 146 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut53
3
0 0
14 1
303 0
2
0 148 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut54
3
0 0
14 1
305 0
2
0 150 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut55
3
0 0
14 1
307 0
2
0 152 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut56
3
0 0
14 1
309 0
2
0 154 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut57
3
0 0
14 1
311 0
2
0 156 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut58
3
0 0
14 1
313 0
2
0 158 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut59
3
0 0
14 1
315 0
2
0 160 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut6
3
0 0
14 1
317 0
2
0 162 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut60
3
0 0
14 1
319 0
2
0 164 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut61
3
0 0
14 1
321 0
2
0 166 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut62
3
0 0
14 1
323 0
2
0 168 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut63
3
0 0
14 1
325 0
2
0 170 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut7
3
0 0
14 1
327 0
2
0 172 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut8
3
0 0
14 1
329 0
2
0 174 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner110 bob nut9
3
0 0
14 1
331 0
2
0 176 0 1
0 203 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut1
3
0 0
15 1
207 0
2
0 52 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut10
3
0 0
15 1
209 0
2
0 54 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut11
3
0 0
15 1
211 0
2
0 56 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut12
3
0 0
15 1
213 0
2
0 58 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut13
3
0 0
15 1
215 0
2
0 60 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut14
3
0 0
15 1
217 0
2
0 62 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut15
3
0 0
15 1
219 0
2
0 64 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut16
3
0 0
15 1
221 0
2
0 66 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut17
3
0 0
15 1
223 0
2
0 68 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut18
3
0 0
15 1
225 0
2
0 70 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut19
3
0 0
15 1
227 0
2
0 72 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut2
3
0 0
15 1
229 0
2
0 74 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut20
3
0 0
15 1
231 0
2
0 76 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut21
3
0 0
15 1
233 0
2
0 78 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut22
3
0 0
15 1
235 0
2
0 80 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut23
3
0 0
15 1
237 0
2
0 82 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut24
3
0 0
15 1
239 0
2
0 84 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut25
3
0 0
15 1
241 0
2
0 86 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut26
3
0 0
15 1
243 0
2
0 88 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut27
3
0 0
15 1
245 0
2
0 90 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut28
3
0 0
15 1
247 0
2
0 92 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut29
3
0 0
15 1
249 0
2
0 94 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut3
3
0 0
15 1
251 0
2
0 96 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut30
3
0 0
15 1
253 0
2
0 98 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut31
3
0 0
15 1
255 0
2
0 100 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut32
3
0 0
15 1
257 0
2
0 102 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut33
3
0 0
15 1
259 0
2
0 104 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut34
3
0 0
15 1
261 0
2
0 106 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut35
3
0 0
15 1
263 0
2
0 108 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut36
3
0 0
15 1
265 0
2
0 110 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut37
3
0 0
15 1
267 0
2
0 112 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut38
3
0 0
15 1
269 0
2
0 114 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut39
3
0 0
15 1
271 0
2
0 116 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut4
3
0 0
15 1
273 0
2
0 118 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut40
3
0 0
15 1
275 0
2
0 120 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut41
3
0 0
15 1
277 0
2
0 122 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut42
3
0 0
15 1
279 0
2
0 124 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut43
3
0 0
15 1
281 0
2
0 126 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut44
3
0 0
15 1
283 0
2
0 128 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut45
3
0 0
15 1
285 0
2
0 130 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut46
3
0 0
15 1
287 0
2
0 132 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut47
3
0 0
15 1
289 0
2
0 134 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut48
3
0 0
15 1
291 0
2
0 136 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut49
3
0 0
15 1
293 0
2
0 138 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut5
3
0 0
15 1
295 0
2
0 140 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut50
3
0 0
15 1
297 0
2
0 142 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut51
3
0 0
15 1
299 0
2
0 144 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut52
3
0 0
15 1
301 0
2
0 146 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut53
3
0 0
15 1
303 0
2
0 148 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut54
3
0 0
15 1
305 0
2
0 150 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut55
3
0 0
15 1
307 0
2
0 152 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut56
3
0 0
15 1
309 0
2
0 154 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut57
3
0 0
15 1
311 0
2
0 156 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut58
3
0 0
15 1
313 0
2
0 158 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut59
3
0 0
15 1
315 0
2
0 160 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut6
3
0 0
15 1
317 0
2
0 162 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut60
3
0 0
15 1
319 0
2
0 164 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut61
3
0 0
15 1
321 0
2
0 166 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut62
3
0 0
15 1
323 0
2
0 168 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut63
3
0 0
15 1
325 0
2
0 170 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut7
3
0 0
15 1
327 0
2
0 172 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut8
3
0 0
15 1
329 0
2
0 174 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner111 bob nut9
3
0 0
15 1
331 0
2
0 176 0 1
0 204 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut1
3
0 0
16 1
207 0
2
0 52 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut10
3
0 0
16 1
209 0
2
0 54 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut11
3
0 0
16 1
211 0
2
0 56 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut12
3
0 0
16 1
213 0
2
0 58 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut13
3
0 0
16 1
215 0
2
0 60 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut14
3
0 0
16 1
217 0
2
0 62 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut15
3
0 0
16 1
219 0
2
0 64 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut16
3
0 0
16 1
221 0
2
0 66 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut17
3
0 0
16 1
223 0
2
0 68 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut18
3
0 0
16 1
225 0
2
0 70 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut19
3
0 0
16 1
227 0
2
0 72 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut2
3
0 0
16 1
229 0
2
0 74 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut20
3
0 0
16 1
231 0
2
0 76 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut21
3
0 0
16 1
233 0
2
0 78 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut22
3
0 0
16 1
235 0
2
0 80 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut23
3
0 0
16 1
237 0
2
0 82 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut24
3
0 0
16 1
239 0
2
0 84 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut25
3
0 0
16 1
241 0
2
0 86 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut26
3
0 0
16 1
243 0
2
0 88 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut27
3
0 0
16 1
245 0
2
0 90 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut28
3
0 0
16 1
247 0
2
0 92 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut29
3
0 0
16 1
249 0
2
0 94 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut3
3
0 0
16 1
251 0
2
0 96 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut30
3
0 0
16 1
253 0
2
0 98 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut31
3
0 0
16 1
255 0
2
0 100 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut32
3
0 0
16 1
257 0
2
0 102 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut33
3
0 0
16 1
259 0
2
0 104 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut34
3
0 0
16 1
261 0
2
0 106 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut35
3
0 0
16 1
263 0
2
0 108 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut36
3
0 0
16 1
265 0
2
0 110 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut37
3
0 0
16 1
267 0
2
0 112 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut38
3
0 0
16 1
269 0
2
0 114 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut39
3
0 0
16 1
271 0
2
0 116 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut4
3
0 0
16 1
273 0
2
0 118 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut40
3
0 0
16 1
275 0
2
0 120 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut41
3
0 0
16 1
277 0
2
0 122 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut42
3
0 0
16 1
279 0
2
0 124 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut43
3
0 0
16 1
281 0
2
0 126 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut44
3
0 0
16 1
283 0
2
0 128 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut45
3
0 0
16 1
285 0
2
0 130 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut46
3
0 0
16 1
287 0
2
0 132 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut47
3
0 0
16 1
289 0
2
0 134 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut48
3
0 0
16 1
291 0
2
0 136 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut49
3
0 0
16 1
293 0
2
0 138 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut5
3
0 0
16 1
295 0
2
0 140 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut50
3
0 0
16 1
297 0
2
0 142 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut51
3
0 0
16 1
299 0
2
0 144 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut52
3
0 0
16 1
301 0
2
0 146 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut53
3
0 0
16 1
303 0
2
0 148 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut54
3
0 0
16 1
305 0
2
0 150 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut55
3
0 0
16 1
307 0
2
0 152 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut56
3
0 0
16 1
309 0
2
0 154 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut57
3
0 0
16 1
311 0
2
0 156 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut58
3
0 0
16 1
313 0
2
0 158 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut59
3
0 0
16 1
315 0
2
0 160 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut6
3
0 0
16 1
317 0
2
0 162 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut60
3
0 0
16 1
319 0
2
0 164 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut61
3
0 0
16 1
321 0
2
0 166 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut62
3
0 0
16 1
323 0
2
0 168 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut63
3
0 0
16 1
325 0
2
0 170 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut7
3
0 0
16 1
327 0
2
0 172 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut8
3
0 0
16 1
329 0
2
0 174 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner112 bob nut9
3
0 0
16 1
331 0
2
0 176 0 1
0 205 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut1
3
0 0
17 1
207 0
2
0 52 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut10
3
0 0
17 1
209 0
2
0 54 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut11
3
0 0
17 1
211 0
2
0 56 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut12
3
0 0
17 1
213 0
2
0 58 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut13
3
0 0
17 1
215 0
2
0 60 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut14
3
0 0
17 1
217 0
2
0 62 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut15
3
0 0
17 1
219 0
2
0 64 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut16
3
0 0
17 1
221 0
2
0 66 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut17
3
0 0
17 1
223 0
2
0 68 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut18
3
0 0
17 1
225 0
2
0 70 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut19
3
0 0
17 1
227 0
2
0 72 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut2
3
0 0
17 1
229 0
2
0 74 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut20
3
0 0
17 1
231 0
2
0 76 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut21
3
0 0
17 1
233 0
2
0 78 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut22
3
0 0
17 1
235 0
2
0 80 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut23
3
0 0
17 1
237 0
2
0 82 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut24
3
0 0
17 1
239 0
2
0 84 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut25
3
0 0
17 1
241 0
2
0 86 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut26
3
0 0
17 1
243 0
2
0 88 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut27
3
0 0
17 1
245 0
2
0 90 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut28
3
0 0
17 1
247 0
2
0 92 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut29
3
0 0
17 1
249 0
2
0 94 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut3
3
0 0
17 1
251 0
2
0 96 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut30
3
0 0
17 1
253 0
2
0 98 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut31
3
0 0
17 1
255 0
2
0 100 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut32
3
0 0
17 1
257 0
2
0 102 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut33
3
0 0
17 1
259 0
2
0 104 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut34
3
0 0
17 1
261 0
2
0 106 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut35
3
0 0
17 1
263 0
2
0 108 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut36
3
0 0
17 1
265 0
2
0 110 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut37
3
0 0
17 1
267 0
2
0 112 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut38
3
0 0
17 1
269 0
2
0 114 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut39
3
0 0
17 1
271 0
2
0 116 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut4
3
0 0
17 1
273 0
2
0 118 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut40
3
0 0
17 1
275 0
2
0 120 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut41
3
0 0
17 1
277 0
2
0 122 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut42
3
0 0
17 1
279 0
2
0 124 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut43
3
0 0
17 1
281 0
2
0 126 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut44
3
0 0
17 1
283 0
2
0 128 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut45
3
0 0
17 1
285 0
2
0 130 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut46
3
0 0
17 1
287 0
2
0 132 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut47
3
0 0
17 1
289 0
2
0 134 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut48
3
0 0
17 1
291 0
2
0 136 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut49
3
0 0
17 1
293 0
2
0 138 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut5
3
0 0
17 1
295 0
2
0 140 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut50
3
0 0
17 1
297 0
2
0 142 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut51
3
0 0
17 1
299 0
2
0 144 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut52
3
0 0
17 1
301 0
2
0 146 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut53
3
0 0
17 1
303 0
2
0 148 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut54
3
0 0
17 1
305 0
2
0 150 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut55
3
0 0
17 1
307 0
2
0 152 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut56
3
0 0
17 1
309 0
2
0 154 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut57
3
0 0
17 1
311 0
2
0 156 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut58
3
0 0
17 1
313 0
2
0 158 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut59
3
0 0
17 1
315 0
2
0 160 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut6
3
0 0
17 1
317 0
2
0 162 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut60
3
0 0
17 1
319 0
2
0 164 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut61
3
0 0
17 1
321 0
2
0 166 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut62
3
0 0
17 1
323 0
2
0 168 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut63
3
0 0
17 1
325 0
2
0 170 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut7
3
0 0
17 1
327 0
2
0 172 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut8
3
0 0
17 1
329 0
2
0 174 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner113 bob nut9
3
0 0
17 1
331 0
2
0 176 0 1
0 206 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut1
3
0 0
18 1
207 0
2
0 52 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut10
3
0 0
18 1
209 0
2
0 54 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut11
3
0 0
18 1
211 0
2
0 56 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut12
3
0 0
18 1
213 0
2
0 58 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut13
3
0 0
18 1
215 0
2
0 60 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut14
3
0 0
18 1
217 0
2
0 62 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut15
3
0 0
18 1
219 0
2
0 64 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut16
3
0 0
18 1
221 0
2
0 66 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut17
3
0 0
18 1
223 0
2
0 68 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut18
3
0 0
18 1
225 0
2
0 70 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut19
3
0 0
18 1
227 0
2
0 72 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut2
3
0 0
18 1
229 0
2
0 74 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut20
3
0 0
18 1
231 0
2
0 76 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut21
3
0 0
18 1
233 0
2
0 78 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut22
3
0 0
18 1
235 0
2
0 80 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut23
3
0 0
18 1
237 0
2
0 82 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut24
3
0 0
18 1
239 0
2
0 84 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut25
3
0 0
18 1
241 0
2
0 86 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut26
3
0 0
18 1
243 0
2
0 88 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut27
3
0 0
18 1
245 0
2
0 90 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut28
3
0 0
18 1
247 0
2
0 92 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut29
3
0 0
18 1
249 0
2
0 94 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut3
3
0 0
18 1
251 0
2
0 96 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut30
3
0 0
18 1
253 0
2
0 98 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut31
3
0 0
18 1
255 0
2
0 100 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut32
3
0 0
18 1
257 0
2
0 102 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut33
3
0 0
18 1
259 0
2
0 104 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut34
3
0 0
18 1
261 0
2
0 106 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut35
3
0 0
18 1
263 0
2
0 108 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut36
3
0 0
18 1
265 0
2
0 110 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut37
3
0 0
18 1
267 0
2
0 112 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut38
3
0 0
18 1
269 0
2
0 114 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut39
3
0 0
18 1
271 0
2
0 116 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut4
3
0 0
18 1
273 0
2
0 118 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut40
3
0 0
18 1
275 0
2
0 120 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut41
3
0 0
18 1
277 0
2
0 122 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut42
3
0 0
18 1
279 0
2
0 124 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut43
3
0 0
18 1
281 0
2
0 126 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut44
3
0 0
18 1
283 0
2
0 128 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut45
3
0 0
18 1
285 0
2
0 130 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut46
3
0 0
18 1
287 0
2
0 132 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut47
3
0 0
18 1
289 0
2
0 134 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut48
3
0 0
18 1
291 0
2
0 136 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut49
3
0 0
18 1
293 0
2
0 138 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut5
3
0 0
18 1
295 0
2
0 140 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut50
3
0 0
18 1
297 0
2
0 142 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut51
3
0 0
18 1
299 0
2
0 144 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut52
3
0 0
18 1
301 0
2
0 146 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut53
3
0 0
18 1
303 0
2
0 148 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut54
3
0 0
18 1
305 0
2
0 150 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut55
3
0 0
18 1
307 0
2
0 152 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut56
3
0 0
18 1
309 0
2
0 154 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut57
3
0 0
18 1
311 0
2
0 156 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut58
3
0 0
18 1
313 0
2
0 158 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut59
3
0 0
18 1
315 0
2
0 160 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut6
3
0 0
18 1
317 0
2
0 162 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut60
3
0 0
18 1
319 0
2
0 164 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut61
3
0 0
18 1
321 0
2
0 166 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut62
3
0 0
18 1
323 0
2
0 168 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut63
3
0 0
18 1
325 0
2
0 170 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut7
3
0 0
18 1
327 0
2
0 172 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut8
3
0 0
18 1
329 0
2
0 174 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner114 bob nut9
3
0 0
18 1
331 0
2
0 176 0 1
0 208 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut1
3
0 0
19 1
207 0
2
0 52 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut10
3
0 0
19 1
209 0
2
0 54 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut11
3
0 0
19 1
211 0
2
0 56 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut12
3
0 0
19 1
213 0
2
0 58 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut13
3
0 0
19 1
215 0
2
0 60 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut14
3
0 0
19 1
217 0
2
0 62 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut15
3
0 0
19 1
219 0
2
0 64 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut16
3
0 0
19 1
221 0
2
0 66 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut17
3
0 0
19 1
223 0
2
0 68 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut18
3
0 0
19 1
225 0
2
0 70 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut19
3
0 0
19 1
227 0
2
0 72 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut2
3
0 0
19 1
229 0
2
0 74 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut20
3
0 0
19 1
231 0
2
0 76 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut21
3
0 0
19 1
233 0
2
0 78 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut22
3
0 0
19 1
235 0
2
0 80 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut23
3
0 0
19 1
237 0
2
0 82 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut24
3
0 0
19 1
239 0
2
0 84 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut25
3
0 0
19 1
241 0
2
0 86 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut26
3
0 0
19 1
243 0
2
0 88 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut27
3
0 0
19 1
245 0
2
0 90 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut28
3
0 0
19 1
247 0
2
0 92 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut29
3
0 0
19 1
249 0
2
0 94 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut3
3
0 0
19 1
251 0
2
0 96 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut30
3
0 0
19 1
253 0
2
0 98 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut31
3
0 0
19 1
255 0
2
0 100 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut32
3
0 0
19 1
257 0
2
0 102 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut33
3
0 0
19 1
259 0
2
0 104 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut34
3
0 0
19 1
261 0
2
0 106 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut35
3
0 0
19 1
263 0
2
0 108 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut36
3
0 0
19 1
265 0
2
0 110 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut37
3
0 0
19 1
267 0
2
0 112 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut38
3
0 0
19 1
269 0
2
0 114 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut39
3
0 0
19 1
271 0
2
0 116 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut4
3
0 0
19 1
273 0
2
0 118 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut40
3
0 0
19 1
275 0
2
0 120 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut41
3
0 0
19 1
277 0
2
0 122 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut42
3
0 0
19 1
279 0
2
0 124 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut43
3
0 0
19 1
281 0
2
0 126 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut44
3
0 0
19 1
283 0
2
0 128 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut45
3
0 0
19 1
285 0
2
0 130 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut46
3
0 0
19 1
287 0
2
0 132 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut47
3
0 0
19 1
289 0
2
0 134 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut48
3
0 0
19 1
291 0
2
0 136 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut49
3
0 0
19 1
293 0
2
0 138 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut5
3
0 0
19 1
295 0
2
0 140 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut50
3
0 0
19 1
297 0
2
0 142 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut51
3
0 0
19 1
299 0
2
0 144 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut52
3
0 0
19 1
301 0
2
0 146 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut53
3
0 0
19 1
303 0
2
0 148 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut54
3
0 0
19 1
305 0
2
0 150 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut55
3
0 0
19 1
307 0
2
0 152 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut56
3
0 0
19 1
309 0
2
0 154 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut57
3
0 0
19 1
311 0
2
0 156 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut58
3
0 0
19 1
313 0
2
0 158 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut59
3
0 0
19 1
315 0
2
0 160 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut6
3
0 0
19 1
317 0
2
0 162 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut60
3
0 0
19 1
319 0
2
0 164 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut61
3
0 0
19 1
321 0
2
0 166 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut62
3
0 0
19 1
323 0
2
0 168 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut63
3
0 0
19 1
325 0
2
0 170 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut7
3
0 0
19 1
327 0
2
0 172 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut8
3
0 0
19 1
329 0
2
0 174 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner115 bob nut9
3
0 0
19 1
331 0
2
0 176 0 1
0 210 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut1
3
0 0
20 1
207 0
2
0 52 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut10
3
0 0
20 1
209 0
2
0 54 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut11
3
0 0
20 1
211 0
2
0 56 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut12
3
0 0
20 1
213 0
2
0 58 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut13
3
0 0
20 1
215 0
2
0 60 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut14
3
0 0
20 1
217 0
2
0 62 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut15
3
0 0
20 1
219 0
2
0 64 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut16
3
0 0
20 1
221 0
2
0 66 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut17
3
0 0
20 1
223 0
2
0 68 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut18
3
0 0
20 1
225 0
2
0 70 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut19
3
0 0
20 1
227 0
2
0 72 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut2
3
0 0
20 1
229 0
2
0 74 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut20
3
0 0
20 1
231 0
2
0 76 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut21
3
0 0
20 1
233 0
2
0 78 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut22
3
0 0
20 1
235 0
2
0 80 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut23
3
0 0
20 1
237 0
2
0 82 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut24
3
0 0
20 1
239 0
2
0 84 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut25
3
0 0
20 1
241 0
2
0 86 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut26
3
0 0
20 1
243 0
2
0 88 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut27
3
0 0
20 1
245 0
2
0 90 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut28
3
0 0
20 1
247 0
2
0 92 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut29
3
0 0
20 1
249 0
2
0 94 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut3
3
0 0
20 1
251 0
2
0 96 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut30
3
0 0
20 1
253 0
2
0 98 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut31
3
0 0
20 1
255 0
2
0 100 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut32
3
0 0
20 1
257 0
2
0 102 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut33
3
0 0
20 1
259 0
2
0 104 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut34
3
0 0
20 1
261 0
2
0 106 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut35
3
0 0
20 1
263 0
2
0 108 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut36
3
0 0
20 1
265 0
2
0 110 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut37
3
0 0
20 1
267 0
2
0 112 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut38
3
0 0
20 1
269 0
2
0 114 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut39
3
0 0
20 1
271 0
2
0 116 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut4
3
0 0
20 1
273 0
2
0 118 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut40
3
0 0
20 1
275 0
2
0 120 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut41
3
0 0
20 1
277 0
2
0 122 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut42
3
0 0
20 1
279 0
2
0 124 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut43
3
0 0
20 1
281 0
2
0 126 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut44
3
0 0
20 1
283 0
2
0 128 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut45
3
0 0
20 1
285 0
2
0 130 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut46
3
0 0
20 1
287 0
2
0 132 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut47
3
0 0
20 1
289 0
2
0 134 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut48
3
0 0
20 1
291 0
2
0 136 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut49
3
0 0
20 1
293 0
2
0 138 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut5
3
0 0
20 1
295 0
2
0 140 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut50
3
0 0
20 1
297 0
2
0 142 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut51
3
0 0
20 1
299 0
2
0 144 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut52
3
0 0
20 1
301 0
2
0 146 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut53
3
0 0
20 1
303 0
2
0 148 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut54
3
0 0
20 1
305 0
2
0 150 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut55
3
0 0
20 1
307 0
2
0 152 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut56
3
0 0
20 1
309 0
2
0 154 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut57
3
0 0
20 1
311 0
2
0 156 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut58
3
0 0
20 1
313 0
2
0 158 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut59
3
0 0
20 1
315 0
2
0 160 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut6
3
0 0
20 1
317 0
2
0 162 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut60
3
0 0
20 1
319 0
2
0 164 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut61
3
0 0
20 1
321 0
2
0 166 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut62
3
0 0
20 1
323 0
2
0 168 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut63
3
0 0
20 1
325 0
2
0 170 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut7
3
0 0
20 1
327 0
2
0 172 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut8
3
0 0
20 1
329 0
2
0 174 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner116 bob nut9
3
0 0
20 1
331 0
2
0 176 0 1
0 212 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut1
3
0 0
21 1
207 0
2
0 52 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut10
3
0 0
21 1
209 0
2
0 54 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut11
3
0 0
21 1
211 0
2
0 56 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut12
3
0 0
21 1
213 0
2
0 58 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut13
3
0 0
21 1
215 0
2
0 60 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut14
3
0 0
21 1
217 0
2
0 62 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut15
3
0 0
21 1
219 0
2
0 64 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut16
3
0 0
21 1
221 0
2
0 66 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut17
3
0 0
21 1
223 0
2
0 68 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut18
3
0 0
21 1
225 0
2
0 70 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut19
3
0 0
21 1
227 0
2
0 72 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut2
3
0 0
21 1
229 0
2
0 74 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut20
3
0 0
21 1
231 0
2
0 76 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut21
3
0 0
21 1
233 0
2
0 78 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut22
3
0 0
21 1
235 0
2
0 80 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut23
3
0 0
21 1
237 0
2
0 82 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut24
3
0 0
21 1
239 0
2
0 84 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut25
3
0 0
21 1
241 0
2
0 86 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut26
3
0 0
21 1
243 0
2
0 88 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut27
3
0 0
21 1
245 0
2
0 90 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut28
3
0 0
21 1
247 0
2
0 92 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut29
3
0 0
21 1
249 0
2
0 94 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut3
3
0 0
21 1
251 0
2
0 96 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut30
3
0 0
21 1
253 0
2
0 98 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut31
3
0 0
21 1
255 0
2
0 100 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut32
3
0 0
21 1
257 0
2
0 102 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut33
3
0 0
21 1
259 0
2
0 104 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut34
3
0 0
21 1
261 0
2
0 106 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut35
3
0 0
21 1
263 0
2
0 108 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut36
3
0 0
21 1
265 0
2
0 110 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut37
3
0 0
21 1
267 0
2
0 112 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut38
3
0 0
21 1
269 0
2
0 114 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut39
3
0 0
21 1
271 0
2
0 116 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut4
3
0 0
21 1
273 0
2
0 118 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut40
3
0 0
21 1
275 0
2
0 120 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut41
3
0 0
21 1
277 0
2
0 122 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut42
3
0 0
21 1
279 0
2
0 124 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut43
3
0 0
21 1
281 0
2
0 126 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut44
3
0 0
21 1
283 0
2
0 128 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut45
3
0 0
21 1
285 0
2
0 130 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut46
3
0 0
21 1
287 0
2
0 132 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut47
3
0 0
21 1
289 0
2
0 134 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut48
3
0 0
21 1
291 0
2
0 136 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut49
3
0 0
21 1
293 0
2
0 138 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut5
3
0 0
21 1
295 0
2
0 140 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut50
3
0 0
21 1
297 0
2
0 142 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut51
3
0 0
21 1
299 0
2
0 144 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut52
3
0 0
21 1
301 0
2
0 146 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut53
3
0 0
21 1
303 0
2
0 148 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut54
3
0 0
21 1
305 0
2
0 150 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut55
3
0 0
21 1
307 0
2
0 152 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut56
3
0 0
21 1
309 0
2
0 154 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut57
3
0 0
21 1
311 0
2
0 156 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut58
3
0 0
21 1
313 0
2
0 158 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut59
3
0 0
21 1
315 0
2
0 160 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut6
3
0 0
21 1
317 0
2
0 162 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut60
3
0 0
21 1
319 0
2
0 164 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut61
3
0 0
21 1
321 0
2
0 166 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut62
3
0 0
21 1
323 0
2
0 168 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut63
3
0 0
21 1
325 0
2
0 170 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut7
3
0 0
21 1
327 0
2
0 172 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut8
3
0 0
21 1
329 0
2
0 174 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner117 bob nut9
3
0 0
21 1
331 0
2
0 176 0 1
0 214 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut1
3
0 0
22 1
207 0
2
0 52 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut10
3
0 0
22 1
209 0
2
0 54 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut11
3
0 0
22 1
211 0
2
0 56 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut12
3
0 0
22 1
213 0
2
0 58 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut13
3
0 0
22 1
215 0
2
0 60 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut14
3
0 0
22 1
217 0
2
0 62 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut15
3
0 0
22 1
219 0
2
0 64 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut16
3
0 0
22 1
221 0
2
0 66 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut17
3
0 0
22 1
223 0
2
0 68 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut18
3
0 0
22 1
225 0
2
0 70 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut19
3
0 0
22 1
227 0
2
0 72 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut2
3
0 0
22 1
229 0
2
0 74 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut20
3
0 0
22 1
231 0
2
0 76 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut21
3
0 0
22 1
233 0
2
0 78 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut22
3
0 0
22 1
235 0
2
0 80 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut23
3
0 0
22 1
237 0
2
0 82 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut24
3
0 0
22 1
239 0
2
0 84 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut25
3
0 0
22 1
241 0
2
0 86 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut26
3
0 0
22 1
243 0
2
0 88 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut27
3
0 0
22 1
245 0
2
0 90 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut28
3
0 0
22 1
247 0
2
0 92 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut29
3
0 0
22 1
249 0
2
0 94 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut3
3
0 0
22 1
251 0
2
0 96 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut30
3
0 0
22 1
253 0
2
0 98 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut31
3
0 0
22 1
255 0
2
0 100 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut32
3
0 0
22 1
257 0
2
0 102 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut33
3
0 0
22 1
259 0
2
0 104 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut34
3
0 0
22 1
261 0
2
0 106 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut35
3
0 0
22 1
263 0
2
0 108 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut36
3
0 0
22 1
265 0
2
0 110 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut37
3
0 0
22 1
267 0
2
0 112 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut38
3
0 0
22 1
269 0
2
0 114 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut39
3
0 0
22 1
271 0
2
0 116 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut4
3
0 0
22 1
273 0
2
0 118 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut40
3
0 0
22 1
275 0
2
0 120 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut41
3
0 0
22 1
277 0
2
0 122 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut42
3
0 0
22 1
279 0
2
0 124 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut43
3
0 0
22 1
281 0
2
0 126 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut44
3
0 0
22 1
283 0
2
0 128 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut45
3
0 0
22 1
285 0
2
0 130 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut46
3
0 0
22 1
287 0
2
0 132 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut47
3
0 0
22 1
289 0
2
0 134 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut48
3
0 0
22 1
291 0
2
0 136 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut49
3
0 0
22 1
293 0
2
0 138 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut5
3
0 0
22 1
295 0
2
0 140 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut50
3
0 0
22 1
297 0
2
0 142 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut51
3
0 0
22 1
299 0
2
0 144 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut52
3
0 0
22 1
301 0
2
0 146 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut53
3
0 0
22 1
303 0
2
0 148 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut54
3
0 0
22 1
305 0
2
0 150 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut55
3
0 0
22 1
307 0
2
0 152 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut56
3
0 0
22 1
309 0
2
0 154 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut57
3
0 0
22 1
311 0
2
0 156 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut58
3
0 0
22 1
313 0
2
0 158 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut59
3
0 0
22 1
315 0
2
0 160 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut6
3
0 0
22 1
317 0
2
0 162 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut60
3
0 0
22 1
319 0
2
0 164 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut61
3
0 0
22 1
321 0
2
0 166 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut62
3
0 0
22 1
323 0
2
0 168 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut63
3
0 0
22 1
325 0
2
0 170 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut7
3
0 0
22 1
327 0
2
0 172 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut8
3
0 0
22 1
329 0
2
0 174 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner118 bob nut9
3
0 0
22 1
331 0
2
0 176 0 1
0 216 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut1
3
0 0
23 1
207 0
2
0 52 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut10
3
0 0
23 1
209 0
2
0 54 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut11
3
0 0
23 1
211 0
2
0 56 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut12
3
0 0
23 1
213 0
2
0 58 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut13
3
0 0
23 1
215 0
2
0 60 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut14
3
0 0
23 1
217 0
2
0 62 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut15
3
0 0
23 1
219 0
2
0 64 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut16
3
0 0
23 1
221 0
2
0 66 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut17
3
0 0
23 1
223 0
2
0 68 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut18
3
0 0
23 1
225 0
2
0 70 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut19
3
0 0
23 1
227 0
2
0 72 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut2
3
0 0
23 1
229 0
2
0 74 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut20
3
0 0
23 1
231 0
2
0 76 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut21
3
0 0
23 1
233 0
2
0 78 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut22
3
0 0
23 1
235 0
2
0 80 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut23
3
0 0
23 1
237 0
2
0 82 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut24
3
0 0
23 1
239 0
2
0 84 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut25
3
0 0
23 1
241 0
2
0 86 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut26
3
0 0
23 1
243 0
2
0 88 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut27
3
0 0
23 1
245 0
2
0 90 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut28
3
0 0
23 1
247 0
2
0 92 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut29
3
0 0
23 1
249 0
2
0 94 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut3
3
0 0
23 1
251 0
2
0 96 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut30
3
0 0
23 1
253 0
2
0 98 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut31
3
0 0
23 1
255 0
2
0 100 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut32
3
0 0
23 1
257 0
2
0 102 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut33
3
0 0
23 1
259 0
2
0 104 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut34
3
0 0
23 1
261 0
2
0 106 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut35
3
0 0
23 1
263 0
2
0 108 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut36
3
0 0
23 1
265 0
2
0 110 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut37
3
0 0
23 1
267 0
2
0 112 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut38
3
0 0
23 1
269 0
2
0 114 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut39
3
0 0
23 1
271 0
2
0 116 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut4
3
0 0
23 1
273 0
2
0 118 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut40
3
0 0
23 1
275 0
2
0 120 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut41
3
0 0
23 1
277 0
2
0 122 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut42
3
0 0
23 1
279 0
2
0 124 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut43
3
0 0
23 1
281 0
2
0 126 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut44
3
0 0
23 1
283 0
2
0 128 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut45
3
0 0
23 1
285 0
2
0 130 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut46
3
0 0
23 1
287 0
2
0 132 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut47
3
0 0
23 1
289 0
2
0 134 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut48
3
0 0
23 1
291 0
2
0 136 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut49
3
0 0
23 1
293 0
2
0 138 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut5
3
0 0
23 1
295 0
2
0 140 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut50
3
0 0
23 1
297 0
2
0 142 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut51
3
0 0
23 1
299 0
2
0 144 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut52
3
0 0
23 1
301 0
2
0 146 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut53
3
0 0
23 1
303 0
2
0 148 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut54
3
0 0
23 1
305 0
2
0 150 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut55
3
0 0
23 1
307 0
2
0 152 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut56
3
0 0
23 1
309 0
2
0 154 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut57
3
0 0
23 1
311 0
2
0 156 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut58
3
0 0
23 1
313 0
2
0 158 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut59
3
0 0
23 1
315 0
2
0 160 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut6
3
0 0
23 1
317 0
2
0 162 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut60
3
0 0
23 1
319 0
2
0 164 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut61
3
0 0
23 1
321 0
2
0 166 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut62
3
0 0
23 1
323 0
2
0 168 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut63
3
0 0
23 1
325 0
2
0 170 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut7
3
0 0
23 1
327 0
2
0 172 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut8
3
0 0
23 1
329 0
2
0 174 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner119 bob nut9
3
0 0
23 1
331 0
2
0 176 0 1
0 218 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut1
3
0 0
24 1
207 0
2
0 52 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut10
3
0 0
24 1
209 0
2
0 54 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut11
3
0 0
24 1
211 0
2
0 56 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut12
3
0 0
24 1
213 0
2
0 58 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut13
3
0 0
24 1
215 0
2
0 60 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut14
3
0 0
24 1
217 0
2
0 62 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut15
3
0 0
24 1
219 0
2
0 64 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut16
3
0 0
24 1
221 0
2
0 66 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut17
3
0 0
24 1
223 0
2
0 68 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut18
3
0 0
24 1
225 0
2
0 70 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut19
3
0 0
24 1
227 0
2
0 72 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut2
3
0 0
24 1
229 0
2
0 74 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut20
3
0 0
24 1
231 0
2
0 76 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut21
3
0 0
24 1
233 0
2
0 78 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut22
3
0 0
24 1
235 0
2
0 80 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut23
3
0 0
24 1
237 0
2
0 82 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut24
3
0 0
24 1
239 0
2
0 84 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut25
3
0 0
24 1
241 0
2
0 86 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut26
3
0 0
24 1
243 0
2
0 88 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut27
3
0 0
24 1
245 0
2
0 90 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut28
3
0 0
24 1
247 0
2
0 92 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut29
3
0 0
24 1
249 0
2
0 94 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut3
3
0 0
24 1
251 0
2
0 96 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut30
3
0 0
24 1
253 0
2
0 98 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut31
3
0 0
24 1
255 0
2
0 100 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut32
3
0 0
24 1
257 0
2
0 102 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut33
3
0 0
24 1
259 0
2
0 104 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut34
3
0 0
24 1
261 0
2
0 106 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut35
3
0 0
24 1
263 0
2
0 108 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut36
3
0 0
24 1
265 0
2
0 110 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut37
3
0 0
24 1
267 0
2
0 112 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut38
3
0 0
24 1
269 0
2
0 114 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut39
3
0 0
24 1
271 0
2
0 116 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut4
3
0 0
24 1
273 0
2
0 118 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut40
3
0 0
24 1
275 0
2
0 120 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut41
3
0 0
24 1
277 0
2
0 122 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut42
3
0 0
24 1
279 0
2
0 124 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut43
3
0 0
24 1
281 0
2
0 126 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut44
3
0 0
24 1
283 0
2
0 128 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut45
3
0 0
24 1
285 0
2
0 130 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut46
3
0 0
24 1
287 0
2
0 132 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut47
3
0 0
24 1
289 0
2
0 134 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut48
3
0 0
24 1
291 0
2
0 136 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut49
3
0 0
24 1
293 0
2
0 138 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut5
3
0 0
24 1
295 0
2
0 140 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut50
3
0 0
24 1
297 0
2
0 142 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut51
3
0 0
24 1
299 0
2
0 144 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut52
3
0 0
24 1
301 0
2
0 146 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut53
3
0 0
24 1
303 0
2
0 148 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut54
3
0 0
24 1
305 0
2
0 150 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut55
3
0 0
24 1
307 0
2
0 152 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut56
3
0 0
24 1
309 0
2
0 154 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut57
3
0 0
24 1
311 0
2
0 156 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut58
3
0 0
24 1
313 0
2
0 158 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut59
3
0 0
24 1
315 0
2
0 160 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut6
3
0 0
24 1
317 0
2
0 162 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut60
3
0 0
24 1
319 0
2
0 164 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut61
3
0 0
24 1
321 0
2
0 166 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut62
3
0 0
24 1
323 0
2
0 168 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut63
3
0 0
24 1
325 0
2
0 170 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut7
3
0 0
24 1
327 0
2
0 172 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut8
3
0 0
24 1
329 0
2
0 174 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner12 bob nut9
3
0 0
24 1
331 0
2
0 176 0 1
0 220 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut1
3
0 0
25 1
207 0
2
0 52 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut10
3
0 0
25 1
209 0
2
0 54 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut11
3
0 0
25 1
211 0
2
0 56 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut12
3
0 0
25 1
213 0
2
0 58 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut13
3
0 0
25 1
215 0
2
0 60 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut14
3
0 0
25 1
217 0
2
0 62 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut15
3
0 0
25 1
219 0
2
0 64 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut16
3
0 0
25 1
221 0
2
0 66 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut17
3
0 0
25 1
223 0
2
0 68 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut18
3
0 0
25 1
225 0
2
0 70 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut19
3
0 0
25 1
227 0
2
0 72 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut2
3
0 0
25 1
229 0
2
0 74 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut20
3
0 0
25 1
231 0
2
0 76 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut21
3
0 0
25 1
233 0
2
0 78 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut22
3
0 0
25 1
235 0
2
0 80 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut23
3
0 0
25 1
237 0
2
0 82 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut24
3
0 0
25 1
239 0
2
0 84 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut25
3
0 0
25 1
241 0
2
0 86 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut26
3
0 0
25 1
243 0
2
0 88 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut27
3
0 0
25 1
245 0
2
0 90 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut28
3
0 0
25 1
247 0
2
0 92 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut29
3
0 0
25 1
249 0
2
0 94 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut3
3
0 0
25 1
251 0
2
0 96 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut30
3
0 0
25 1
253 0
2
0 98 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut31
3
0 0
25 1
255 0
2
0 100 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut32
3
0 0
25 1
257 0
2
0 102 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut33
3
0 0
25 1
259 0
2
0 104 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut34
3
0 0
25 1
261 0
2
0 106 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut35
3
0 0
25 1
263 0
2
0 108 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut36
3
0 0
25 1
265 0
2
0 110 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut37
3
0 0
25 1
267 0
2
0 112 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut38
3
0 0
25 1
269 0
2
0 114 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut39
3
0 0
25 1
271 0
2
0 116 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut4
3
0 0
25 1
273 0
2
0 118 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut40
3
0 0
25 1
275 0
2
0 120 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut41
3
0 0
25 1
277 0
2
0 122 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut42
3
0 0
25 1
279 0
2
0 124 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut43
3
0 0
25 1
281 0
2
0 126 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut44
3
0 0
25 1
283 0
2
0 128 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut45
3
0 0
25 1
285 0
2
0 130 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut46
3
0 0
25 1
287 0
2
0 132 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut47
3
0 0
25 1
289 0
2
0 134 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut48
3
0 0
25 1
291 0
2
0 136 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut49
3
0 0
25 1
293 0
2
0 138 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut5
3
0 0
25 1
295 0
2
0 140 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut50
3
0 0
25 1
297 0
2
0 142 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut51
3
0 0
25 1
299 0
2
0 144 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut52
3
0 0
25 1
301 0
2
0 146 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut53
3
0 0
25 1
303 0
2
0 148 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut54
3
0 0
25 1
305 0
2
0 150 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut55
3
0 0
25 1
307 0
2
0 152 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut56
3
0 0
25 1
309 0
2
0 154 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut57
3
0 0
25 1
311 0
2
0 156 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut58
3
0 0
25 1
313 0
2
0 158 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut59
3
0 0
25 1
315 0
2
0 160 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut6
3
0 0
25 1
317 0
2
0 162 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut60
3
0 0
25 1
319 0
2
0 164 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut61
3
0 0
25 1
321 0
2
0 166 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut62
3
0 0
25 1
323 0
2
0 168 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut63
3
0 0
25 1
325 0
2
0 170 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut7
3
0 0
25 1
327 0
2
0 172 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut8
3
0 0
25 1
329 0
2
0 174 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner120 bob nut9
3
0 0
25 1
331 0
2
0 176 0 1
0 222 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut1
3
0 0
26 1
207 0
2
0 52 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut10
3
0 0
26 1
209 0
2
0 54 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut11
3
0 0
26 1
211 0
2
0 56 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut12
3
0 0
26 1
213 0
2
0 58 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut13
3
0 0
26 1
215 0
2
0 60 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut14
3
0 0
26 1
217 0
2
0 62 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut15
3
0 0
26 1
219 0
2
0 64 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut16
3
0 0
26 1
221 0
2
0 66 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut17
3
0 0
26 1
223 0
2
0 68 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut18
3
0 0
26 1
225 0
2
0 70 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut19
3
0 0
26 1
227 0
2
0 72 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut2
3
0 0
26 1
229 0
2
0 74 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut20
3
0 0
26 1
231 0
2
0 76 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut21
3
0 0
26 1
233 0
2
0 78 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut22
3
0 0
26 1
235 0
2
0 80 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut23
3
0 0
26 1
237 0
2
0 82 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut24
3
0 0
26 1
239 0
2
0 84 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut25
3
0 0
26 1
241 0
2
0 86 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut26
3
0 0
26 1
243 0
2
0 88 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut27
3
0 0
26 1
245 0
2
0 90 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut28
3
0 0
26 1
247 0
2
0 92 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut29
3
0 0
26 1
249 0
2
0 94 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut3
3
0 0
26 1
251 0
2
0 96 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut30
3
0 0
26 1
253 0
2
0 98 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut31
3
0 0
26 1
255 0
2
0 100 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut32
3
0 0
26 1
257 0
2
0 102 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut33
3
0 0
26 1
259 0
2
0 104 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut34
3
0 0
26 1
261 0
2
0 106 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut35
3
0 0
26 1
263 0
2
0 108 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut36
3
0 0
26 1
265 0
2
0 110 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut37
3
0 0
26 1
267 0
2
0 112 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut38
3
0 0
26 1
269 0
2
0 114 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut39
3
0 0
26 1
271 0
2
0 116 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut4
3
0 0
26 1
273 0
2
0 118 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut40
3
0 0
26 1
275 0
2
0 120 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut41
3
0 0
26 1
277 0
2
0 122 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut42
3
0 0
26 1
279 0
2
0 124 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut43
3
0 0
26 1
281 0
2
0 126 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut44
3
0 0
26 1
283 0
2
0 128 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut45
3
0 0
26 1
285 0
2
0 130 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut46
3
0 0
26 1
287 0
2
0 132 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut47
3
0 0
26 1
289 0
2
0 134 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut48
3
0 0
26 1
291 0
2
0 136 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut49
3
0 0
26 1
293 0
2
0 138 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut5
3
0 0
26 1
295 0
2
0 140 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut50
3
0 0
26 1
297 0
2
0 142 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut51
3
0 0
26 1
299 0
2
0 144 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut52
3
0 0
26 1
301 0
2
0 146 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut53
3
0 0
26 1
303 0
2
0 148 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut54
3
0 0
26 1
305 0
2
0 150 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut55
3
0 0
26 1
307 0
2
0 152 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut56
3
0 0
26 1
309 0
2
0 154 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut57
3
0 0
26 1
311 0
2
0 156 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut58
3
0 0
26 1
313 0
2
0 158 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut59
3
0 0
26 1
315 0
2
0 160 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut6
3
0 0
26 1
317 0
2
0 162 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut60
3
0 0
26 1
319 0
2
0 164 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut61
3
0 0
26 1
321 0
2
0 166 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut62
3
0 0
26 1
323 0
2
0 168 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut63
3
0 0
26 1
325 0
2
0 170 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut7
3
0 0
26 1
327 0
2
0 172 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut8
3
0 0
26 1
329 0
2
0 174 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner121 bob nut9
3
0 0
26 1
331 0
2
0 176 0 1
0 224 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut1
3
0 0
27 1
207 0
2
0 52 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut10
3
0 0
27 1
209 0
2
0 54 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut11
3
0 0
27 1
211 0
2
0 56 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut12
3
0 0
27 1
213 0
2
0 58 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut13
3
0 0
27 1
215 0
2
0 60 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut14
3
0 0
27 1
217 0
2
0 62 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut15
3
0 0
27 1
219 0
2
0 64 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut16
3
0 0
27 1
221 0
2
0 66 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut17
3
0 0
27 1
223 0
2
0 68 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut18
3
0 0
27 1
225 0
2
0 70 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut19
3
0 0
27 1
227 0
2
0 72 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut2
3
0 0
27 1
229 0
2
0 74 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut20
3
0 0
27 1
231 0
2
0 76 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut21
3
0 0
27 1
233 0
2
0 78 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut22
3
0 0
27 1
235 0
2
0 80 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut23
3
0 0
27 1
237 0
2
0 82 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut24
3
0 0
27 1
239 0
2
0 84 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut25
3
0 0
27 1
241 0
2
0 86 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut26
3
0 0
27 1
243 0
2
0 88 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut27
3
0 0
27 1
245 0
2
0 90 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut28
3
0 0
27 1
247 0
2
0 92 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut29
3
0 0
27 1
249 0
2
0 94 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut3
3
0 0
27 1
251 0
2
0 96 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut30
3
0 0
27 1
253 0
2
0 98 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut31
3
0 0
27 1
255 0
2
0 100 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut32
3
0 0
27 1
257 0
2
0 102 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut33
3
0 0
27 1
259 0
2
0 104 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut34
3
0 0
27 1
261 0
2
0 106 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut35
3
0 0
27 1
263 0
2
0 108 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut36
3
0 0
27 1
265 0
2
0 110 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut37
3
0 0
27 1
267 0
2
0 112 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut38
3
0 0
27 1
269 0
2
0 114 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut39
3
0 0
27 1
271 0
2
0 116 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut4
3
0 0
27 1
273 0
2
0 118 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut40
3
0 0
27 1
275 0
2
0 120 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut41
3
0 0
27 1
277 0
2
0 122 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut42
3
0 0
27 1
279 0
2
0 124 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut43
3
0 0
27 1
281 0
2
0 126 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut44
3
0 0
27 1
283 0
2
0 128 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut45
3
0 0
27 1
285 0
2
0 130 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut46
3
0 0
27 1
287 0
2
0 132 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut47
3
0 0
27 1
289 0
2
0 134 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut48
3
0 0
27 1
291 0
2
0 136 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut49
3
0 0
27 1
293 0
2
0 138 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut5
3
0 0
27 1
295 0
2
0 140 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut50
3
0 0
27 1
297 0
2
0 142 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut51
3
0 0
27 1
299 0
2
0 144 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut52
3
0 0
27 1
301 0
2
0 146 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut53
3
0 0
27 1
303 0
2
0 148 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut54
3
0 0
27 1
305 0
2
0 150 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut55
3
0 0
27 1
307 0
2
0 152 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut56
3
0 0
27 1
309 0
2
0 154 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut57
3
0 0
27 1
311 0
2
0 156 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut58
3
0 0
27 1
313 0
2
0 158 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut59
3
0 0
27 1
315 0
2
0 160 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut6
3
0 0
27 1
317 0
2
0 162 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut60
3
0 0
27 1
319 0
2
0 164 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut61
3
0 0
27 1
321 0
2
0 166 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut62
3
0 0
27 1
323 0
2
0 168 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut63
3
0 0
27 1
325 0
2
0 170 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut7
3
0 0
27 1
327 0
2
0 172 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut8
3
0 0
27 1
329 0
2
0 174 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner122 bob nut9
3
0 0
27 1
331 0
2
0 176 0 1
0 226 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut1
3
0 0
28 1
207 0
2
0 52 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut10
3
0 0
28 1
209 0
2
0 54 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut11
3
0 0
28 1
211 0
2
0 56 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut12
3
0 0
28 1
213 0
2
0 58 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut13
3
0 0
28 1
215 0
2
0 60 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut14
3
0 0
28 1
217 0
2
0 62 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut15
3
0 0
28 1
219 0
2
0 64 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut16
3
0 0
28 1
221 0
2
0 66 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut17
3
0 0
28 1
223 0
2
0 68 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut18
3
0 0
28 1
225 0
2
0 70 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut19
3
0 0
28 1
227 0
2
0 72 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut2
3
0 0
28 1
229 0
2
0 74 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut20
3
0 0
28 1
231 0
2
0 76 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut21
3
0 0
28 1
233 0
2
0 78 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut22
3
0 0
28 1
235 0
2
0 80 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut23
3
0 0
28 1
237 0
2
0 82 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut24
3
0 0
28 1
239 0
2
0 84 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut25
3
0 0
28 1
241 0
2
0 86 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut26
3
0 0
28 1
243 0
2
0 88 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut27
3
0 0
28 1
245 0
2
0 90 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut28
3
0 0
28 1
247 0
2
0 92 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut29
3
0 0
28 1
249 0
2
0 94 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut3
3
0 0
28 1
251 0
2
0 96 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut30
3
0 0
28 1
253 0
2
0 98 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut31
3
0 0
28 1
255 0
2
0 100 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut32
3
0 0
28 1
257 0
2
0 102 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut33
3
0 0
28 1
259 0
2
0 104 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut34
3
0 0
28 1
261 0
2
0 106 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut35
3
0 0
28 1
263 0
2
0 108 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut36
3
0 0
28 1
265 0
2
0 110 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut37
3
0 0
28 1
267 0
2
0 112 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut38
3
0 0
28 1
269 0
2
0 114 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut39
3
0 0
28 1
271 0
2
0 116 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut4
3
0 0
28 1
273 0
2
0 118 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut40
3
0 0
28 1
275 0
2
0 120 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut41
3
0 0
28 1
277 0
2
0 122 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut42
3
0 0
28 1
279 0
2
0 124 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut43
3
0 0
28 1
281 0
2
0 126 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut44
3
0 0
28 1
283 0
2
0 128 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut45
3
0 0
28 1
285 0
2
0 130 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut46
3
0 0
28 1
287 0
2
0 132 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut47
3
0 0
28 1
289 0
2
0 134 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut48
3
0 0
28 1
291 0
2
0 136 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut49
3
0 0
28 1
293 0
2
0 138 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut5
3
0 0
28 1
295 0
2
0 140 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut50
3
0 0
28 1
297 0
2
0 142 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut51
3
0 0
28 1
299 0
2
0 144 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut52
3
0 0
28 1
301 0
2
0 146 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut53
3
0 0
28 1
303 0
2
0 148 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut54
3
0 0
28 1
305 0
2
0 150 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut55
3
0 0
28 1
307 0
2
0 152 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut56
3
0 0
28 1
309 0
2
0 154 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut57
3
0 0
28 1
311 0
2
0 156 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut58
3
0 0
28 1
313 0
2
0 158 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut59
3
0 0
28 1
315 0
2
0 160 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut6
3
0 0
28 1
317 0
2
0 162 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut60
3
0 0
28 1
319 0
2
0 164 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut61
3
0 0
28 1
321 0
2
0 166 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut62
3
0 0
28 1
323 0
2
0 168 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut63
3
0 0
28 1
325 0
2
0 170 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut7
3
0 0
28 1
327 0
2
0 172 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut8
3
0 0
28 1
329 0
2
0 174 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner123 bob nut9
3
0 0
28 1
331 0
2
0 176 0 1
0 228 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut1
3
0 0
29 1
207 0
2
0 52 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut10
3
0 0
29 1
209 0
2
0 54 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut11
3
0 0
29 1
211 0
2
0 56 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut12
3
0 0
29 1
213 0
2
0 58 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut13
3
0 0
29 1
215 0
2
0 60 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut14
3
0 0
29 1
217 0
2
0 62 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut15
3
0 0
29 1
219 0
2
0 64 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut16
3
0 0
29 1
221 0
2
0 66 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut17
3
0 0
29 1
223 0
2
0 68 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut18
3
0 0
29 1
225 0
2
0 70 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut19
3
0 0
29 1
227 0
2
0 72 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut2
3
0 0
29 1
229 0
2
0 74 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut20
3
0 0
29 1
231 0
2
0 76 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut21
3
0 0
29 1
233 0
2
0 78 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut22
3
0 0
29 1
235 0
2
0 80 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut23
3
0 0
29 1
237 0
2
0 82 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut24
3
0 0
29 1
239 0
2
0 84 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut25
3
0 0
29 1
241 0
2
0 86 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut26
3
0 0
29 1
243 0
2
0 88 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut27
3
0 0
29 1
245 0
2
0 90 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut28
3
0 0
29 1
247 0
2
0 92 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut29
3
0 0
29 1
249 0
2
0 94 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut3
3
0 0
29 1
251 0
2
0 96 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut30
3
0 0
29 1
253 0
2
0 98 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut31
3
0 0
29 1
255 0
2
0 100 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut32
3
0 0
29 1
257 0
2
0 102 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut33
3
0 0
29 1
259 0
2
0 104 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut34
3
0 0
29 1
261 0
2
0 106 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut35
3
0 0
29 1
263 0
2
0 108 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut36
3
0 0
29 1
265 0
2
0 110 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut37
3
0 0
29 1
267 0
2
0 112 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut38
3
0 0
29 1
269 0
2
0 114 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut39
3
0 0
29 1
271 0
2
0 116 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut4
3
0 0
29 1
273 0
2
0 118 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut40
3
0 0
29 1
275 0
2
0 120 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut41
3
0 0
29 1
277 0
2
0 122 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut42
3
0 0
29 1
279 0
2
0 124 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut43
3
0 0
29 1
281 0
2
0 126 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut44
3
0 0
29 1
283 0
2
0 128 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut45
3
0 0
29 1
285 0
2
0 130 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut46
3
0 0
29 1
287 0
2
0 132 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut47
3
0 0
29 1
289 0
2
0 134 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut48
3
0 0
29 1
291 0
2
0 136 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut49
3
0 0
29 1
293 0
2
0 138 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut5
3
0 0
29 1
295 0
2
0 140 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut50
3
0 0
29 1
297 0
2
0 142 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut51
3
0 0
29 1
299 0
2
0 144 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut52
3
0 0
29 1
301 0
2
0 146 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut53
3
0 0
29 1
303 0
2
0 148 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut54
3
0 0
29 1
305 0
2
0 150 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut55
3
0 0
29 1
307 0
2
0 152 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut56
3
0 0
29 1
309 0
2
0 154 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut57
3
0 0
29 1
311 0
2
0 156 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut58
3
0 0
29 1
313 0
2
0 158 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut59
3
0 0
29 1
315 0
2
0 160 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut6
3
0 0
29 1
317 0
2
0 162 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut60
3
0 0
29 1
319 0
2
0 164 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut61
3
0 0
29 1
321 0
2
0 166 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut62
3
0 0
29 1
323 0
2
0 168 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut63
3
0 0
29 1
325 0
2
0 170 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut7
3
0 0
29 1
327 0
2
0 172 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut8
3
0 0
29 1
329 0
2
0 174 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner124 bob nut9
3
0 0
29 1
331 0
2
0 176 0 1
0 230 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut1
3
0 0
30 1
207 0
2
0 52 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut10
3
0 0
30 1
209 0
2
0 54 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut11
3
0 0
30 1
211 0
2
0 56 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut12
3
0 0
30 1
213 0
2
0 58 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut13
3
0 0
30 1
215 0
2
0 60 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut14
3
0 0
30 1
217 0
2
0 62 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut15
3
0 0
30 1
219 0
2
0 64 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut16
3
0 0
30 1
221 0
2
0 66 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut17
3
0 0
30 1
223 0
2
0 68 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut18
3
0 0
30 1
225 0
2
0 70 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut19
3
0 0
30 1
227 0
2
0 72 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut2
3
0 0
30 1
229 0
2
0 74 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut20
3
0 0
30 1
231 0
2
0 76 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut21
3
0 0
30 1
233 0
2
0 78 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut22
3
0 0
30 1
235 0
2
0 80 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut23
3
0 0
30 1
237 0
2
0 82 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut24
3
0 0
30 1
239 0
2
0 84 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut25
3
0 0
30 1
241 0
2
0 86 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut26
3
0 0
30 1
243 0
2
0 88 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut27
3
0 0
30 1
245 0
2
0 90 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut28
3
0 0
30 1
247 0
2
0 92 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut29
3
0 0
30 1
249 0
2
0 94 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut3
3
0 0
30 1
251 0
2
0 96 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut30
3
0 0
30 1
253 0
2
0 98 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut31
3
0 0
30 1
255 0
2
0 100 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut32
3
0 0
30 1
257 0
2
0 102 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut33
3
0 0
30 1
259 0
2
0 104 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut34
3
0 0
30 1
261 0
2
0 106 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut35
3
0 0
30 1
263 0
2
0 108 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut36
3
0 0
30 1
265 0
2
0 110 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut37
3
0 0
30 1
267 0
2
0 112 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut38
3
0 0
30 1
269 0
2
0 114 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut39
3
0 0
30 1
271 0
2
0 116 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut4
3
0 0
30 1
273 0
2
0 118 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut40
3
0 0
30 1
275 0
2
0 120 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut41
3
0 0
30 1
277 0
2
0 122 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut42
3
0 0
30 1
279 0
2
0 124 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut43
3
0 0
30 1
281 0
2
0 126 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut44
3
0 0
30 1
283 0
2
0 128 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut45
3
0 0
30 1
285 0
2
0 130 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut46
3
0 0
30 1
287 0
2
0 132 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut47
3
0 0
30 1
289 0
2
0 134 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut48
3
0 0
30 1
291 0
2
0 136 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut49
3
0 0
30 1
293 0
2
0 138 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut5
3
0 0
30 1
295 0
2
0 140 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut50
3
0 0
30 1
297 0
2
0 142 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut51
3
0 0
30 1
299 0
2
0 144 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut52
3
0 0
30 1
301 0
2
0 146 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut53
3
0 0
30 1
303 0
2
0 148 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut54
3
0 0
30 1
305 0
2
0 150 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut55
3
0 0
30 1
307 0
2
0 152 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut56
3
0 0
30 1
309 0
2
0 154 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut57
3
0 0
30 1
311 0
2
0 156 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut58
3
0 0
30 1
313 0
2
0 158 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut59
3
0 0
30 1
315 0
2
0 160 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut6
3
0 0
30 1
317 0
2
0 162 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut60
3
0 0
30 1
319 0
2
0 164 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut61
3
0 0
30 1
321 0
2
0 166 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut62
3
0 0
30 1
323 0
2
0 168 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut63
3
0 0
30 1
325 0
2
0 170 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut7
3
0 0
30 1
327 0
2
0 172 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut8
3
0 0
30 1
329 0
2
0 174 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner125 bob nut9
3
0 0
30 1
331 0
2
0 176 0 1
0 232 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut1
3
0 0
31 1
207 0
2
0 52 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut10
3
0 0
31 1
209 0
2
0 54 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut11
3
0 0
31 1
211 0
2
0 56 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut12
3
0 0
31 1
213 0
2
0 58 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut13
3
0 0
31 1
215 0
2
0 60 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut14
3
0 0
31 1
217 0
2
0 62 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut15
3
0 0
31 1
219 0
2
0 64 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut16
3
0 0
31 1
221 0
2
0 66 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut17
3
0 0
31 1
223 0
2
0 68 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut18
3
0 0
31 1
225 0
2
0 70 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut19
3
0 0
31 1
227 0
2
0 72 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut2
3
0 0
31 1
229 0
2
0 74 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut20
3
0 0
31 1
231 0
2
0 76 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut21
3
0 0
31 1
233 0
2
0 78 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut22
3
0 0
31 1
235 0
2
0 80 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut23
3
0 0
31 1
237 0
2
0 82 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut24
3
0 0
31 1
239 0
2
0 84 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut25
3
0 0
31 1
241 0
2
0 86 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut26
3
0 0
31 1
243 0
2
0 88 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut27
3
0 0
31 1
245 0
2
0 90 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut28
3
0 0
31 1
247 0
2
0 92 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut29
3
0 0
31 1
249 0
2
0 94 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut3
3
0 0
31 1
251 0
2
0 96 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut30
3
0 0
31 1
253 0
2
0 98 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut31
3
0 0
31 1
255 0
2
0 100 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut32
3
0 0
31 1
257 0
2
0 102 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut33
3
0 0
31 1
259 0
2
0 104 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut34
3
0 0
31 1
261 0
2
0 106 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut35
3
0 0
31 1
263 0
2
0 108 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut36
3
0 0
31 1
265 0
2
0 110 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut37
3
0 0
31 1
267 0
2
0 112 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut38
3
0 0
31 1
269 0
2
0 114 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut39
3
0 0
31 1
271 0
2
0 116 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut4
3
0 0
31 1
273 0
2
0 118 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut40
3
0 0
31 1
275 0
2
0 120 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut41
3
0 0
31 1
277 0
2
0 122 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut42
3
0 0
31 1
279 0
2
0 124 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut43
3
0 0
31 1
281 0
2
0 126 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut44
3
0 0
31 1
283 0
2
0 128 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut45
3
0 0
31 1
285 0
2
0 130 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut46
3
0 0
31 1
287 0
2
0 132 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut47
3
0 0
31 1
289 0
2
0 134 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut48
3
0 0
31 1
291 0
2
0 136 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut49
3
0 0
31 1
293 0
2
0 138 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut5
3
0 0
31 1
295 0
2
0 140 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut50
3
0 0
31 1
297 0
2
0 142 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut51
3
0 0
31 1
299 0
2
0 144 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut52
3
0 0
31 1
301 0
2
0 146 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut53
3
0 0
31 1
303 0
2
0 148 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut54
3
0 0
31 1
305 0
2
0 150 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut55
3
0 0
31 1
307 0
2
0 152 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut56
3
0 0
31 1
309 0
2
0 154 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut57
3
0 0
31 1
311 0
2
0 156 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut58
3
0 0
31 1
313 0
2
0 158 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut59
3
0 0
31 1
315 0
2
0 160 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut6
3
0 0
31 1
317 0
2
0 162 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut60
3
0 0
31 1
319 0
2
0 164 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut61
3
0 0
31 1
321 0
2
0 166 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut62
3
0 0
31 1
323 0
2
0 168 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut63
3
0 0
31 1
325 0
2
0 170 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut7
3
0 0
31 1
327 0
2
0 172 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut8
3
0 0
31 1
329 0
2
0 174 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner126 bob nut9
3
0 0
31 1
331 0
2
0 176 0 1
0 234 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut1
3
0 0
32 1
207 0
2
0 52 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut10
3
0 0
32 1
209 0
2
0 54 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut11
3
0 0
32 1
211 0
2
0 56 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut12
3
0 0
32 1
213 0
2
0 58 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut13
3
0 0
32 1
215 0
2
0 60 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut14
3
0 0
32 1
217 0
2
0 62 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut15
3
0 0
32 1
219 0
2
0 64 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut16
3
0 0
32 1
221 0
2
0 66 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut17
3
0 0
32 1
223 0
2
0 68 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut18
3
0 0
32 1
225 0
2
0 70 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut19
3
0 0
32 1
227 0
2
0 72 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut2
3
0 0
32 1
229 0
2
0 74 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut20
3
0 0
32 1
231 0
2
0 76 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut21
3
0 0
32 1
233 0
2
0 78 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut22
3
0 0
32 1
235 0
2
0 80 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut23
3
0 0
32 1
237 0
2
0 82 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut24
3
0 0
32 1
239 0
2
0 84 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut25
3
0 0
32 1
241 0
2
0 86 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut26
3
0 0
32 1
243 0
2
0 88 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut27
3
0 0
32 1
245 0
2
0 90 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut28
3
0 0
32 1
247 0
2
0 92 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut29
3
0 0
32 1
249 0
2
0 94 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut3
3
0 0
32 1
251 0
2
0 96 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut30
3
0 0
32 1
253 0
2
0 98 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut31
3
0 0
32 1
255 0
2
0 100 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut32
3
0 0
32 1
257 0
2
0 102 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut33
3
0 0
32 1
259 0
2
0 104 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut34
3
0 0
32 1
261 0
2
0 106 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut35
3
0 0
32 1
263 0
2
0 108 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut36
3
0 0
32 1
265 0
2
0 110 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut37
3
0 0
32 1
267 0
2
0 112 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut38
3
0 0
32 1
269 0
2
0 114 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut39
3
0 0
32 1
271 0
2
0 116 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut4
3
0 0
32 1
273 0
2
0 118 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut40
3
0 0
32 1
275 0
2
0 120 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut41
3
0 0
32 1
277 0
2
0 122 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut42
3
0 0
32 1
279 0
2
0 124 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut43
3
0 0
32 1
281 0
2
0 126 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut44
3
0 0
32 1
283 0
2
0 128 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut45
3
0 0
32 1
285 0
2
0 130 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut46
3
0 0
32 1
287 0
2
0 132 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut47
3
0 0
32 1
289 0
2
0 134 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut48
3
0 0
32 1
291 0
2
0 136 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut49
3
0 0
32 1
293 0
2
0 138 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut5
3
0 0
32 1
295 0
2
0 140 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut50
3
0 0
32 1
297 0
2
0 142 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut51
3
0 0
32 1
299 0
2
0 144 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut52
3
0 0
32 1
301 0
2
0 146 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut53
3
0 0
32 1
303 0
2
0 148 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut54
3
0 0
32 1
305 0
2
0 150 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut55
3
0 0
32 1
307 0
2
0 152 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut56
3
0 0
32 1
309 0
2
0 154 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut57
3
0 0
32 1
311 0
2
0 156 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut58
3
0 0
32 1
313 0
2
0 158 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut59
3
0 0
32 1
315 0
2
0 160 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut6
3
0 0
32 1
317 0
2
0 162 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut60
3
0 0
32 1
319 0
2
0 164 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut61
3
0 0
32 1
321 0
2
0 166 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut62
3
0 0
32 1
323 0
2
0 168 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut63
3
0 0
32 1
325 0
2
0 170 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut7
3
0 0
32 1
327 0
2
0 172 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut8
3
0 0
32 1
329 0
2
0 174 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner13 bob nut9
3
0 0
32 1
331 0
2
0 176 0 1
0 236 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut1
3
0 0
33 1
207 0
2
0 52 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut10
3
0 0
33 1
209 0
2
0 54 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut11
3
0 0
33 1
211 0
2
0 56 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut12
3
0 0
33 1
213 0
2
0 58 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut13
3
0 0
33 1
215 0
2
0 60 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut14
3
0 0
33 1
217 0
2
0 62 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut15
3
0 0
33 1
219 0
2
0 64 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut16
3
0 0
33 1
221 0
2
0 66 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut17
3
0 0
33 1
223 0
2
0 68 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut18
3
0 0
33 1
225 0
2
0 70 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut19
3
0 0
33 1
227 0
2
0 72 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut2
3
0 0
33 1
229 0
2
0 74 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut20
3
0 0
33 1
231 0
2
0 76 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut21
3
0 0
33 1
233 0
2
0 78 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut22
3
0 0
33 1
235 0
2
0 80 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut23
3
0 0
33 1
237 0
2
0 82 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut24
3
0 0
33 1
239 0
2
0 84 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut25
3
0 0
33 1
241 0
2
0 86 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut26
3
0 0
33 1
243 0
2
0 88 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut27
3
0 0
33 1
245 0
2
0 90 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut28
3
0 0
33 1
247 0
2
0 92 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut29
3
0 0
33 1
249 0
2
0 94 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut3
3
0 0
33 1
251 0
2
0 96 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut30
3
0 0
33 1
253 0
2
0 98 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut31
3
0 0
33 1
255 0
2
0 100 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut32
3
0 0
33 1
257 0
2
0 102 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut33
3
0 0
33 1
259 0
2
0 104 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut34
3
0 0
33 1
261 0
2
0 106 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut35
3
0 0
33 1
263 0
2
0 108 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut36
3
0 0
33 1
265 0
2
0 110 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut37
3
0 0
33 1
267 0
2
0 112 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut38
3
0 0
33 1
269 0
2
0 114 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut39
3
0 0
33 1
271 0
2
0 116 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut4
3
0 0
33 1
273 0
2
0 118 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut40
3
0 0
33 1
275 0
2
0 120 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut41
3
0 0
33 1
277 0
2
0 122 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut42
3
0 0
33 1
279 0
2
0 124 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut43
3
0 0
33 1
281 0
2
0 126 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut44
3
0 0
33 1
283 0
2
0 128 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut45
3
0 0
33 1
285 0
2
0 130 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut46
3
0 0
33 1
287 0
2
0 132 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut47
3
0 0
33 1
289 0
2
0 134 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut48
3
0 0
33 1
291 0
2
0 136 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut49
3
0 0
33 1
293 0
2
0 138 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut5
3
0 0
33 1
295 0
2
0 140 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut50
3
0 0
33 1
297 0
2
0 142 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut51
3
0 0
33 1
299 0
2
0 144 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut52
3
0 0
33 1
301 0
2
0 146 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut53
3
0 0
33 1
303 0
2
0 148 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut54
3
0 0
33 1
305 0
2
0 150 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut55
3
0 0
33 1
307 0
2
0 152 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut56
3
0 0
33 1
309 0
2
0 154 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut57
3
0 0
33 1
311 0
2
0 156 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut58
3
0 0
33 1
313 0
2
0 158 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut59
3
0 0
33 1
315 0
2
0 160 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut6
3
0 0
33 1
317 0
2
0 162 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut60
3
0 0
33 1
319 0
2
0 164 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut61
3
0 0
33 1
321 0
2
0 166 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut62
3
0 0
33 1
323 0
2
0 168 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut63
3
0 0
33 1
325 0
2
0 170 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut7
3
0 0
33 1
327 0
2
0 172 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut8
3
0 0
33 1
329 0
2
0 174 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner14 bob nut9
3
0 0
33 1
331 0
2
0 176 0 1
0 238 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut1
3
0 0
34 1
207 0
2
0 52 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut10
3
0 0
34 1
209 0
2
0 54 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut11
3
0 0
34 1
211 0
2
0 56 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut12
3
0 0
34 1
213 0
2
0 58 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut13
3
0 0
34 1
215 0
2
0 60 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut14
3
0 0
34 1
217 0
2
0 62 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut15
3
0 0
34 1
219 0
2
0 64 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut16
3
0 0
34 1
221 0
2
0 66 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut17
3
0 0
34 1
223 0
2
0 68 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut18
3
0 0
34 1
225 0
2
0 70 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut19
3
0 0
34 1
227 0
2
0 72 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut2
3
0 0
34 1
229 0
2
0 74 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut20
3
0 0
34 1
231 0
2
0 76 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut21
3
0 0
34 1
233 0
2
0 78 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut22
3
0 0
34 1
235 0
2
0 80 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut23
3
0 0
34 1
237 0
2
0 82 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut24
3
0 0
34 1
239 0
2
0 84 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut25
3
0 0
34 1
241 0
2
0 86 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut26
3
0 0
34 1
243 0
2
0 88 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut27
3
0 0
34 1
245 0
2
0 90 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut28
3
0 0
34 1
247 0
2
0 92 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut29
3
0 0
34 1
249 0
2
0 94 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut3
3
0 0
34 1
251 0
2
0 96 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut30
3
0 0
34 1
253 0
2
0 98 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut31
3
0 0
34 1
255 0
2
0 100 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut32
3
0 0
34 1
257 0
2
0 102 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut33
3
0 0
34 1
259 0
2
0 104 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut34
3
0 0
34 1
261 0
2
0 106 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut35
3
0 0
34 1
263 0
2
0 108 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut36
3
0 0
34 1
265 0
2
0 110 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut37
3
0 0
34 1
267 0
2
0 112 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut38
3
0 0
34 1
269 0
2
0 114 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut39
3
0 0
34 1
271 0
2
0 116 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut4
3
0 0
34 1
273 0
2
0 118 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut40
3
0 0
34 1
275 0
2
0 120 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut41
3
0 0
34 1
277 0
2
0 122 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut42
3
0 0
34 1
279 0
2
0 124 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut43
3
0 0
34 1
281 0
2
0 126 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut44
3
0 0
34 1
283 0
2
0 128 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut45
3
0 0
34 1
285 0
2
0 130 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut46
3
0 0
34 1
287 0
2
0 132 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut47
3
0 0
34 1
289 0
2
0 134 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut48
3
0 0
34 1
291 0
2
0 136 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut49
3
0 0
34 1
293 0
2
0 138 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut5
3
0 0
34 1
295 0
2
0 140 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut50
3
0 0
34 1
297 0
2
0 142 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut51
3
0 0
34 1
299 0
2
0 144 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut52
3
0 0
34 1
301 0
2
0 146 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut53
3
0 0
34 1
303 0
2
0 148 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut54
3
0 0
34 1
305 0
2
0 150 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut55
3
0 0
34 1
307 0
2
0 152 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut56
3
0 0
34 1
309 0
2
0 154 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut57
3
0 0
34 1
311 0
2
0 156 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut58
3
0 0
34 1
313 0
2
0 158 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut59
3
0 0
34 1
315 0
2
0 160 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut6
3
0 0
34 1
317 0
2
0 162 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut60
3
0 0
34 1
319 0
2
0 164 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut61
3
0 0
34 1
321 0
2
0 166 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut62
3
0 0
34 1
323 0
2
0 168 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut63
3
0 0
34 1
325 0
2
0 170 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut7
3
0 0
34 1
327 0
2
0 172 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut8
3
0 0
34 1
329 0
2
0 174 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner15 bob nut9
3
0 0
34 1
331 0
2
0 176 0 1
0 240 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut1
3
0 0
35 1
207 0
2
0 52 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut10
3
0 0
35 1
209 0
2
0 54 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut11
3
0 0
35 1
211 0
2
0 56 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut12
3
0 0
35 1
213 0
2
0 58 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut13
3
0 0
35 1
215 0
2
0 60 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut14
3
0 0
35 1
217 0
2
0 62 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut15
3
0 0
35 1
219 0
2
0 64 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut16
3
0 0
35 1
221 0
2
0 66 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut17
3
0 0
35 1
223 0
2
0 68 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut18
3
0 0
35 1
225 0
2
0 70 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut19
3
0 0
35 1
227 0
2
0 72 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut2
3
0 0
35 1
229 0
2
0 74 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut20
3
0 0
35 1
231 0
2
0 76 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut21
3
0 0
35 1
233 0
2
0 78 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut22
3
0 0
35 1
235 0
2
0 80 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut23
3
0 0
35 1
237 0
2
0 82 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut24
3
0 0
35 1
239 0
2
0 84 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut25
3
0 0
35 1
241 0
2
0 86 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut26
3
0 0
35 1
243 0
2
0 88 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut27
3
0 0
35 1
245 0
2
0 90 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut28
3
0 0
35 1
247 0
2
0 92 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut29
3
0 0
35 1
249 0
2
0 94 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut3
3
0 0
35 1
251 0
2
0 96 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut30
3
0 0
35 1
253 0
2
0 98 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut31
3
0 0
35 1
255 0
2
0 100 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut32
3
0 0
35 1
257 0
2
0 102 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut33
3
0 0
35 1
259 0
2
0 104 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut34
3
0 0
35 1
261 0
2
0 106 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut35
3
0 0
35 1
263 0
2
0 108 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut36
3
0 0
35 1
265 0
2
0 110 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut37
3
0 0
35 1
267 0
2
0 112 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut38
3
0 0
35 1
269 0
2
0 114 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut39
3
0 0
35 1
271 0
2
0 116 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut4
3
0 0
35 1
273 0
2
0 118 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut40
3
0 0
35 1
275 0
2
0 120 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut41
3
0 0
35 1
277 0
2
0 122 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut42
3
0 0
35 1
279 0
2
0 124 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut43
3
0 0
35 1
281 0
2
0 126 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut44
3
0 0
35 1
283 0
2
0 128 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut45
3
0 0
35 1
285 0
2
0 130 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut46
3
0 0
35 1
287 0
2
0 132 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut47
3
0 0
35 1
289 0
2
0 134 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut48
3
0 0
35 1
291 0
2
0 136 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut49
3
0 0
35 1
293 0
2
0 138 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut5
3
0 0
35 1
295 0
2
0 140 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut50
3
0 0
35 1
297 0
2
0 142 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut51
3
0 0
35 1
299 0
2
0 144 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut52
3
0 0
35 1
301 0
2
0 146 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut53
3
0 0
35 1
303 0
2
0 148 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut54
3
0 0
35 1
305 0
2
0 150 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut55
3
0 0
35 1
307 0
2
0 152 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut56
3
0 0
35 1
309 0
2
0 154 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut57
3
0 0
35 1
311 0
2
0 156 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut58
3
0 0
35 1
313 0
2
0 158 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut59
3
0 0
35 1
315 0
2
0 160 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut6
3
0 0
35 1
317 0
2
0 162 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut60
3
0 0
35 1
319 0
2
0 164 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut61
3
0 0
35 1
321 0
2
0 166 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut62
3
0 0
35 1
323 0
2
0 168 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut63
3
0 0
35 1
325 0
2
0 170 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut7
3
0 0
35 1
327 0
2
0 172 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut8
3
0 0
35 1
329 0
2
0 174 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner16 bob nut9
3
0 0
35 1
331 0
2
0 176 0 1
0 242 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut1
3
0 0
36 1
207 0
2
0 52 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut10
3
0 0
36 1
209 0
2
0 54 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut11
3
0 0
36 1
211 0
2
0 56 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut12
3
0 0
36 1
213 0
2
0 58 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut13
3
0 0
36 1
215 0
2
0 60 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut14
3
0 0
36 1
217 0
2
0 62 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut15
3
0 0
36 1
219 0
2
0 64 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut16
3
0 0
36 1
221 0
2
0 66 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut17
3
0 0
36 1
223 0
2
0 68 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut18
3
0 0
36 1
225 0
2
0 70 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut19
3
0 0
36 1
227 0
2
0 72 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut2
3
0 0
36 1
229 0
2
0 74 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut20
3
0 0
36 1
231 0
2
0 76 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut21
3
0 0
36 1
233 0
2
0 78 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut22
3
0 0
36 1
235 0
2
0 80 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut23
3
0 0
36 1
237 0
2
0 82 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut24
3
0 0
36 1
239 0
2
0 84 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut25
3
0 0
36 1
241 0
2
0 86 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut26
3
0 0
36 1
243 0
2
0 88 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut27
3
0 0
36 1
245 0
2
0 90 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut28
3
0 0
36 1
247 0
2
0 92 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut29
3
0 0
36 1
249 0
2
0 94 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut3
3
0 0
36 1
251 0
2
0 96 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut30
3
0 0
36 1
253 0
2
0 98 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut31
3
0 0
36 1
255 0
2
0 100 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut32
3
0 0
36 1
257 0
2
0 102 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut33
3
0 0
36 1
259 0
2
0 104 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut34
3
0 0
36 1
261 0
2
0 106 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut35
3
0 0
36 1
263 0
2
0 108 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut36
3
0 0
36 1
265 0
2
0 110 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut37
3
0 0
36 1
267 0
2
0 112 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut38
3
0 0
36 1
269 0
2
0 114 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut39
3
0 0
36 1
271 0
2
0 116 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut4
3
0 0
36 1
273 0
2
0 118 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut40
3
0 0
36 1
275 0
2
0 120 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut41
3
0 0
36 1
277 0
2
0 122 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut42
3
0 0
36 1
279 0
2
0 124 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut43
3
0 0
36 1
281 0
2
0 126 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut44
3
0 0
36 1
283 0
2
0 128 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut45
3
0 0
36 1
285 0
2
0 130 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut46
3
0 0
36 1
287 0
2
0 132 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut47
3
0 0
36 1
289 0
2
0 134 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut48
3
0 0
36 1
291 0
2
0 136 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut49
3
0 0
36 1
293 0
2
0 138 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut5
3
0 0
36 1
295 0
2
0 140 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut50
3
0 0
36 1
297 0
2
0 142 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut51
3
0 0
36 1
299 0
2
0 144 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut52
3
0 0
36 1
301 0
2
0 146 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut53
3
0 0
36 1
303 0
2
0 148 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut54
3
0 0
36 1
305 0
2
0 150 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut55
3
0 0
36 1
307 0
2
0 152 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut56
3
0 0
36 1
309 0
2
0 154 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut57
3
0 0
36 1
311 0
2
0 156 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut58
3
0 0
36 1
313 0
2
0 158 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut59
3
0 0
36 1
315 0
2
0 160 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut6
3
0 0
36 1
317 0
2
0 162 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut60
3
0 0
36 1
319 0
2
0 164 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut61
3
0 0
36 1
321 0
2
0 166 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut62
3
0 0
36 1
323 0
2
0 168 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut63
3
0 0
36 1
325 0
2
0 170 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut7
3
0 0
36 1
327 0
2
0 172 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut8
3
0 0
36 1
329 0
2
0 174 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner17 bob nut9
3
0 0
36 1
331 0
2
0 176 0 1
0 244 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut1
3
0 0
37 1
207 0
2
0 52 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut10
3
0 0
37 1
209 0
2
0 54 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut11
3
0 0
37 1
211 0
2
0 56 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut12
3
0 0
37 1
213 0
2
0 58 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut13
3
0 0
37 1
215 0
2
0 60 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut14
3
0 0
37 1
217 0
2
0 62 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut15
3
0 0
37 1
219 0
2
0 64 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut16
3
0 0
37 1
221 0
2
0 66 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut17
3
0 0
37 1
223 0
2
0 68 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut18
3
0 0
37 1
225 0
2
0 70 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut19
3
0 0
37 1
227 0
2
0 72 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut2
3
0 0
37 1
229 0
2
0 74 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut20
3
0 0
37 1
231 0
2
0 76 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut21
3
0 0
37 1
233 0
2
0 78 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut22
3
0 0
37 1
235 0
2
0 80 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut23
3
0 0
37 1
237 0
2
0 82 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut24
3
0 0
37 1
239 0
2
0 84 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut25
3
0 0
37 1
241 0
2
0 86 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut26
3
0 0
37 1
243 0
2
0 88 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut27
3
0 0
37 1
245 0
2
0 90 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut28
3
0 0
37 1
247 0
2
0 92 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut29
3
0 0
37 1
249 0
2
0 94 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut3
3
0 0
37 1
251 0
2
0 96 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut30
3
0 0
37 1
253 0
2
0 98 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut31
3
0 0
37 1
255 0
2
0 100 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut32
3
0 0
37 1
257 0
2
0 102 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut33
3
0 0
37 1
259 0
2
0 104 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut34
3
0 0
37 1
261 0
2
0 106 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut35
3
0 0
37 1
263 0
2
0 108 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut36
3
0 0
37 1
265 0
2
0 110 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut37
3
0 0
37 1
267 0
2
0 112 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut38
3
0 0
37 1
269 0
2
0 114 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut39
3
0 0
37 1
271 0
2
0 116 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut4
3
0 0
37 1
273 0
2
0 118 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut40
3
0 0
37 1
275 0
2
0 120 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut41
3
0 0
37 1
277 0
2
0 122 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut42
3
0 0
37 1
279 0
2
0 124 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut43
3
0 0
37 1
281 0
2
0 126 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut44
3
0 0
37 1
283 0
2
0 128 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut45
3
0 0
37 1
285 0
2
0 130 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut46
3
0 0
37 1
287 0
2
0 132 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut47
3
0 0
37 1
289 0
2
0 134 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut48
3
0 0
37 1
291 0
2
0 136 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut49
3
0 0
37 1
293 0
2
0 138 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut5
3
0 0
37 1
295 0
2
0 140 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut50
3
0 0
37 1
297 0
2
0 142 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut51
3
0 0
37 1
299 0
2
0 144 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut52
3
0 0
37 1
301 0
2
0 146 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut53
3
0 0
37 1
303 0
2
0 148 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut54
3
0 0
37 1
305 0
2
0 150 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut55
3
0 0
37 1
307 0
2
0 152 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut56
3
0 0
37 1
309 0
2
0 154 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut57
3
0 0
37 1
311 0
2
0 156 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut58
3
0 0
37 1
313 0
2
0 158 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut59
3
0 0
37 1
315 0
2
0 160 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut6
3
0 0
37 1
317 0
2
0 162 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut60
3
0 0
37 1
319 0
2
0 164 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut61
3
0 0
37 1
321 0
2
0 166 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut62
3
0 0
37 1
323 0
2
0 168 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut63
3
0 0
37 1
325 0
2
0 170 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut7
3
0 0
37 1
327 0
2
0 172 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut8
3
0 0
37 1
329 0
2
0 174 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner18 bob nut9
3
0 0
37 1
331 0
2
0 176 0 1
0 246 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut1
3
0 0
38 1
207 0
2
0 52 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut10
3
0 0
38 1
209 0
2
0 54 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut11
3
0 0
38 1
211 0
2
0 56 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut12
3
0 0
38 1
213 0
2
0 58 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut13
3
0 0
38 1
215 0
2
0 60 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut14
3
0 0
38 1
217 0
2
0 62 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut15
3
0 0
38 1
219 0
2
0 64 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut16
3
0 0
38 1
221 0
2
0 66 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut17
3
0 0
38 1
223 0
2
0 68 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut18
3
0 0
38 1
225 0
2
0 70 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut19
3
0 0
38 1
227 0
2
0 72 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut2
3
0 0
38 1
229 0
2
0 74 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut20
3
0 0
38 1
231 0
2
0 76 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut21
3
0 0
38 1
233 0
2
0 78 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut22
3
0 0
38 1
235 0
2
0 80 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut23
3
0 0
38 1
237 0
2
0 82 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut24
3
0 0
38 1
239 0
2
0 84 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut25
3
0 0
38 1
241 0
2
0 86 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut26
3
0 0
38 1
243 0
2
0 88 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut27
3
0 0
38 1
245 0
2
0 90 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut28
3
0 0
38 1
247 0
2
0 92 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut29
3
0 0
38 1
249 0
2
0 94 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut3
3
0 0
38 1
251 0
2
0 96 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut30
3
0 0
38 1
253 0
2
0 98 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut31
3
0 0
38 1
255 0
2
0 100 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut32
3
0 0
38 1
257 0
2
0 102 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut33
3
0 0
38 1
259 0
2
0 104 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut34
3
0 0
38 1
261 0
2
0 106 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut35
3
0 0
38 1
263 0
2
0 108 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut36
3
0 0
38 1
265 0
2
0 110 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut37
3
0 0
38 1
267 0
2
0 112 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut38
3
0 0
38 1
269 0
2
0 114 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut39
3
0 0
38 1
271 0
2
0 116 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut4
3
0 0
38 1
273 0
2
0 118 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut40
3
0 0
38 1
275 0
2
0 120 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut41
3
0 0
38 1
277 0
2
0 122 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut42
3
0 0
38 1
279 0
2
0 124 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut43
3
0 0
38 1
281 0
2
0 126 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut44
3
0 0
38 1
283 0
2
0 128 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut45
3
0 0
38 1
285 0
2
0 130 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut46
3
0 0
38 1
287 0
2
0 132 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut47
3
0 0
38 1
289 0
2
0 134 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut48
3
0 0
38 1
291 0
2
0 136 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut49
3
0 0
38 1
293 0
2
0 138 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut5
3
0 0
38 1
295 0
2
0 140 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut50
3
0 0
38 1
297 0
2
0 142 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut51
3
0 0
38 1
299 0
2
0 144 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut52
3
0 0
38 1
301 0
2
0 146 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut53
3
0 0
38 1
303 0
2
0 148 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut54
3
0 0
38 1
305 0
2
0 150 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut55
3
0 0
38 1
307 0
2
0 152 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut56
3
0 0
38 1
309 0
2
0 154 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut57
3
0 0
38 1
311 0
2
0 156 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut58
3
0 0
38 1
313 0
2
0 158 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut59
3
0 0
38 1
315 0
2
0 160 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut6
3
0 0
38 1
317 0
2
0 162 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut60
3
0 0
38 1
319 0
2
0 164 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut61
3
0 0
38 1
321 0
2
0 166 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut62
3
0 0
38 1
323 0
2
0 168 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut63
3
0 0
38 1
325 0
2
0 170 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut7
3
0 0
38 1
327 0
2
0 172 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut8
3
0 0
38 1
329 0
2
0 174 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner19 bob nut9
3
0 0
38 1
331 0
2
0 176 0 1
0 248 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut1
3
0 0
39 1
207 0
2
0 52 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut10
3
0 0
39 1
209 0
2
0 54 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut11
3
0 0
39 1
211 0
2
0 56 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut12
3
0 0
39 1
213 0
2
0 58 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut13
3
0 0
39 1
215 0
2
0 60 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut14
3
0 0
39 1
217 0
2
0 62 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut15
3
0 0
39 1
219 0
2
0 64 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut16
3
0 0
39 1
221 0
2
0 66 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut17
3
0 0
39 1
223 0
2
0 68 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut18
3
0 0
39 1
225 0
2
0 70 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut19
3
0 0
39 1
227 0
2
0 72 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut2
3
0 0
39 1
229 0
2
0 74 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut20
3
0 0
39 1
231 0
2
0 76 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut21
3
0 0
39 1
233 0
2
0 78 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut22
3
0 0
39 1
235 0
2
0 80 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut23
3
0 0
39 1
237 0
2
0 82 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut24
3
0 0
39 1
239 0
2
0 84 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut25
3
0 0
39 1
241 0
2
0 86 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut26
3
0 0
39 1
243 0
2
0 88 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut27
3
0 0
39 1
245 0
2
0 90 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut28
3
0 0
39 1
247 0
2
0 92 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut29
3
0 0
39 1
249 0
2
0 94 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut3
3
0 0
39 1
251 0
2
0 96 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut30
3
0 0
39 1
253 0
2
0 98 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut31
3
0 0
39 1
255 0
2
0 100 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut32
3
0 0
39 1
257 0
2
0 102 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut33
3
0 0
39 1
259 0
2
0 104 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut34
3
0 0
39 1
261 0
2
0 106 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut35
3
0 0
39 1
263 0
2
0 108 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut36
3
0 0
39 1
265 0
2
0 110 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut37
3
0 0
39 1
267 0
2
0 112 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut38
3
0 0
39 1
269 0
2
0 114 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut39
3
0 0
39 1
271 0
2
0 116 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut4
3
0 0
39 1
273 0
2
0 118 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut40
3
0 0
39 1
275 0
2
0 120 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut41
3
0 0
39 1
277 0
2
0 122 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut42
3
0 0
39 1
279 0
2
0 124 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut43
3
0 0
39 1
281 0
2
0 126 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut44
3
0 0
39 1
283 0
2
0 128 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut45
3
0 0
39 1
285 0
2
0 130 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut46
3
0 0
39 1
287 0
2
0 132 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut47
3
0 0
39 1
289 0
2
0 134 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut48
3
0 0
39 1
291 0
2
0 136 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut49
3
0 0
39 1
293 0
2
0 138 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut5
3
0 0
39 1
295 0
2
0 140 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut50
3
0 0
39 1
297 0
2
0 142 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut51
3
0 0
39 1
299 0
2
0 144 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut52
3
0 0
39 1
301 0
2
0 146 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut53
3
0 0
39 1
303 0
2
0 148 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut54
3
0 0
39 1
305 0
2
0 150 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut55
3
0 0
39 1
307 0
2
0 152 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut56
3
0 0
39 1
309 0
2
0 154 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut57
3
0 0
39 1
311 0
2
0 156 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut58
3
0 0
39 1
313 0
2
0 158 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut59
3
0 0
39 1
315 0
2
0 160 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut6
3
0 0
39 1
317 0
2
0 162 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut60
3
0 0
39 1
319 0
2
0 164 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut61
3
0 0
39 1
321 0
2
0 166 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut62
3
0 0
39 1
323 0
2
0 168 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut63
3
0 0
39 1
325 0
2
0 170 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut7
3
0 0
39 1
327 0
2
0 172 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut8
3
0 0
39 1
329 0
2
0 174 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner2 bob nut9
3
0 0
39 1
331 0
2
0 176 0 1
0 250 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut1
3
0 0
40 1
207 0
2
0 52 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut10
3
0 0
40 1
209 0
2
0 54 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut11
3
0 0
40 1
211 0
2
0 56 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut12
3
0 0
40 1
213 0
2
0 58 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut13
3
0 0
40 1
215 0
2
0 60 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut14
3
0 0
40 1
217 0
2
0 62 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut15
3
0 0
40 1
219 0
2
0 64 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut16
3
0 0
40 1
221 0
2
0 66 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut17
3
0 0
40 1
223 0
2
0 68 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut18
3
0 0
40 1
225 0
2
0 70 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut19
3
0 0
40 1
227 0
2
0 72 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut2
3
0 0
40 1
229 0
2
0 74 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut20
3
0 0
40 1
231 0
2
0 76 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut21
3
0 0
40 1
233 0
2
0 78 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut22
3
0 0
40 1
235 0
2
0 80 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut23
3
0 0
40 1
237 0
2
0 82 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut24
3
0 0
40 1
239 0
2
0 84 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut25
3
0 0
40 1
241 0
2
0 86 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut26
3
0 0
40 1
243 0
2
0 88 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut27
3
0 0
40 1
245 0
2
0 90 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut28
3
0 0
40 1
247 0
2
0 92 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut29
3
0 0
40 1
249 0
2
0 94 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut3
3
0 0
40 1
251 0
2
0 96 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut30
3
0 0
40 1
253 0
2
0 98 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut31
3
0 0
40 1
255 0
2
0 100 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut32
3
0 0
40 1
257 0
2
0 102 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut33
3
0 0
40 1
259 0
2
0 104 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut34
3
0 0
40 1
261 0
2
0 106 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut35
3
0 0
40 1
263 0
2
0 108 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut36
3
0 0
40 1
265 0
2
0 110 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut37
3
0 0
40 1
267 0
2
0 112 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut38
3
0 0
40 1
269 0
2
0 114 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut39
3
0 0
40 1
271 0
2
0 116 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut4
3
0 0
40 1
273 0
2
0 118 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut40
3
0 0
40 1
275 0
2
0 120 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut41
3
0 0
40 1
277 0
2
0 122 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut42
3
0 0
40 1
279 0
2
0 124 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut43
3
0 0
40 1
281 0
2
0 126 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut44
3
0 0
40 1
283 0
2
0 128 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut45
3
0 0
40 1
285 0
2
0 130 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut46
3
0 0
40 1
287 0
2
0 132 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut47
3
0 0
40 1
289 0
2
0 134 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut48
3
0 0
40 1
291 0
2
0 136 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut49
3
0 0
40 1
293 0
2
0 138 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut5
3
0 0
40 1
295 0
2
0 140 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut50
3
0 0
40 1
297 0
2
0 142 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut51
3
0 0
40 1
299 0
2
0 144 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut52
3
0 0
40 1
301 0
2
0 146 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut53
3
0 0
40 1
303 0
2
0 148 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut54
3
0 0
40 1
305 0
2
0 150 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut55
3
0 0
40 1
307 0
2
0 152 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut56
3
0 0
40 1
309 0
2
0 154 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut57
3
0 0
40 1
311 0
2
0 156 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut58
3
0 0
40 1
313 0
2
0 158 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut59
3
0 0
40 1
315 0
2
0 160 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut6
3
0 0
40 1
317 0
2
0 162 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut60
3
0 0
40 1
319 0
2
0 164 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut61
3
0 0
40 1
321 0
2
0 166 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut62
3
0 0
40 1
323 0
2
0 168 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut63
3
0 0
40 1
325 0
2
0 170 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut7
3
0 0
40 1
327 0
2
0 172 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut8
3
0 0
40 1
329 0
2
0 174 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner20 bob nut9
3
0 0
40 1
331 0
2
0 176 0 1
0 252 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut1
3
0 0
41 1
207 0
2
0 52 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut10
3
0 0
41 1
209 0
2
0 54 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut11
3
0 0
41 1
211 0
2
0 56 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut12
3
0 0
41 1
213 0
2
0 58 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut13
3
0 0
41 1
215 0
2
0 60 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut14
3
0 0
41 1
217 0
2
0 62 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut15
3
0 0
41 1
219 0
2
0 64 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut16
3
0 0
41 1
221 0
2
0 66 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut17
3
0 0
41 1
223 0
2
0 68 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut18
3
0 0
41 1
225 0
2
0 70 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut19
3
0 0
41 1
227 0
2
0 72 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut2
3
0 0
41 1
229 0
2
0 74 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut20
3
0 0
41 1
231 0
2
0 76 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut21
3
0 0
41 1
233 0
2
0 78 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut22
3
0 0
41 1
235 0
2
0 80 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut23
3
0 0
41 1
237 0
2
0 82 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut24
3
0 0
41 1
239 0
2
0 84 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut25
3
0 0
41 1
241 0
2
0 86 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut26
3
0 0
41 1
243 0
2
0 88 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut27
3
0 0
41 1
245 0
2
0 90 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut28
3
0 0
41 1
247 0
2
0 92 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut29
3
0 0
41 1
249 0
2
0 94 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut3
3
0 0
41 1
251 0
2
0 96 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut30
3
0 0
41 1
253 0
2
0 98 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut31
3
0 0
41 1
255 0
2
0 100 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut32
3
0 0
41 1
257 0
2
0 102 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut33
3
0 0
41 1
259 0
2
0 104 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut34
3
0 0
41 1
261 0
2
0 106 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut35
3
0 0
41 1
263 0
2
0 108 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut36
3
0 0
41 1
265 0
2
0 110 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut37
3
0 0
41 1
267 0
2
0 112 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut38
3
0 0
41 1
269 0
2
0 114 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut39
3
0 0
41 1
271 0
2
0 116 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut4
3
0 0
41 1
273 0
2
0 118 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut40
3
0 0
41 1
275 0
2
0 120 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut41
3
0 0
41 1
277 0
2
0 122 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut42
3
0 0
41 1
279 0
2
0 124 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut43
3
0 0
41 1
281 0
2
0 126 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut44
3
0 0
41 1
283 0
2
0 128 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut45
3
0 0
41 1
285 0
2
0 130 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut46
3
0 0
41 1
287 0
2
0 132 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut47
3
0 0
41 1
289 0
2
0 134 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut48
3
0 0
41 1
291 0
2
0 136 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut49
3
0 0
41 1
293 0
2
0 138 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut5
3
0 0
41 1
295 0
2
0 140 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut50
3
0 0
41 1
297 0
2
0 142 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut51
3
0 0
41 1
299 0
2
0 144 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut52
3
0 0
41 1
301 0
2
0 146 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut53
3
0 0
41 1
303 0
2
0 148 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut54
3
0 0
41 1
305 0
2
0 150 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut55
3
0 0
41 1
307 0
2
0 152 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut56
3
0 0
41 1
309 0
2
0 154 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut57
3
0 0
41 1
311 0
2
0 156 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut58
3
0 0
41 1
313 0
2
0 158 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut59
3
0 0
41 1
315 0
2
0 160 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut6
3
0 0
41 1
317 0
2
0 162 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut60
3
0 0
41 1
319 0
2
0 164 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut61
3
0 0
41 1
321 0
2
0 166 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut62
3
0 0
41 1
323 0
2
0 168 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut63
3
0 0
41 1
325 0
2
0 170 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut7
3
0 0
41 1
327 0
2
0 172 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut8
3
0 0
41 1
329 0
2
0 174 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner21 bob nut9
3
0 0
41 1
331 0
2
0 176 0 1
0 254 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut1
3
0 0
42 1
207 0
2
0 52 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut10
3
0 0
42 1
209 0
2
0 54 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut11
3
0 0
42 1
211 0
2
0 56 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut12
3
0 0
42 1
213 0
2
0 58 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut13
3
0 0
42 1
215 0
2
0 60 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut14
3
0 0
42 1
217 0
2
0 62 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut15
3
0 0
42 1
219 0
2
0 64 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut16
3
0 0
42 1
221 0
2
0 66 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut17
3
0 0
42 1
223 0
2
0 68 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut18
3
0 0
42 1
225 0
2
0 70 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut19
3
0 0
42 1
227 0
2
0 72 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut2
3
0 0
42 1
229 0
2
0 74 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut20
3
0 0
42 1
231 0
2
0 76 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut21
3
0 0
42 1
233 0
2
0 78 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut22
3
0 0
42 1
235 0
2
0 80 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut23
3
0 0
42 1
237 0
2
0 82 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut24
3
0 0
42 1
239 0
2
0 84 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut25
3
0 0
42 1
241 0
2
0 86 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut26
3
0 0
42 1
243 0
2
0 88 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut27
3
0 0
42 1
245 0
2
0 90 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut28
3
0 0
42 1
247 0
2
0 92 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut29
3
0 0
42 1
249 0
2
0 94 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut3
3
0 0
42 1
251 0
2
0 96 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut30
3
0 0
42 1
253 0
2
0 98 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut31
3
0 0
42 1
255 0
2
0 100 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut32
3
0 0
42 1
257 0
2
0 102 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut33
3
0 0
42 1
259 0
2
0 104 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut34
3
0 0
42 1
261 0
2
0 106 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut35
3
0 0
42 1
263 0
2
0 108 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut36
3
0 0
42 1
265 0
2
0 110 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut37
3
0 0
42 1
267 0
2
0 112 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut38
3
0 0
42 1
269 0
2
0 114 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut39
3
0 0
42 1
271 0
2
0 116 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut4
3
0 0
42 1
273 0
2
0 118 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut40
3
0 0
42 1
275 0
2
0 120 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut41
3
0 0
42 1
277 0
2
0 122 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut42
3
0 0
42 1
279 0
2
0 124 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut43
3
0 0
42 1
281 0
2
0 126 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut44
3
0 0
42 1
283 0
2
0 128 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut45
3
0 0
42 1
285 0
2
0 130 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut46
3
0 0
42 1
287 0
2
0 132 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut47
3
0 0
42 1
289 0
2
0 134 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut48
3
0 0
42 1
291 0
2
0 136 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut49
3
0 0
42 1
293 0
2
0 138 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut5
3
0 0
42 1
295 0
2
0 140 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut50
3
0 0
42 1
297 0
2
0 142 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut51
3
0 0
42 1
299 0
2
0 144 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut52
3
0 0
42 1
301 0
2
0 146 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut53
3
0 0
42 1
303 0
2
0 148 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut54
3
0 0
42 1
305 0
2
0 150 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut55
3
0 0
42 1
307 0
2
0 152 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut56
3
0 0
42 1
309 0
2
0 154 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut57
3
0 0
42 1
311 0
2
0 156 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut58
3
0 0
42 1
313 0
2
0 158 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut59
3
0 0
42 1
315 0
2
0 160 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut6
3
0 0
42 1
317 0
2
0 162 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut60
3
0 0
42 1
319 0
2
0 164 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut61
3
0 0
42 1
321 0
2
0 166 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut62
3
0 0
42 1
323 0
2
0 168 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut63
3
0 0
42 1
325 0
2
0 170 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut7
3
0 0
42 1
327 0
2
0 172 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut8
3
0 0
42 1
329 0
2
0 174 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner22 bob nut9
3
0 0
42 1
331 0
2
0 176 0 1
0 256 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut1
3
0 0
43 1
207 0
2
0 52 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut10
3
0 0
43 1
209 0
2
0 54 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut11
3
0 0
43 1
211 0
2
0 56 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut12
3
0 0
43 1
213 0
2
0 58 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut13
3
0 0
43 1
215 0
2
0 60 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut14
3
0 0
43 1
217 0
2
0 62 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut15
3
0 0
43 1
219 0
2
0 64 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut16
3
0 0
43 1
221 0
2
0 66 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut17
3
0 0
43 1
223 0
2
0 68 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut18
3
0 0
43 1
225 0
2
0 70 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut19
3
0 0
43 1
227 0
2
0 72 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut2
3
0 0
43 1
229 0
2
0 74 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut20
3
0 0
43 1
231 0
2
0 76 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut21
3
0 0
43 1
233 0
2
0 78 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut22
3
0 0
43 1
235 0
2
0 80 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut23
3
0 0
43 1
237 0
2
0 82 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut24
3
0 0
43 1
239 0
2
0 84 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut25
3
0 0
43 1
241 0
2
0 86 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut26
3
0 0
43 1
243 0
2
0 88 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut27
3
0 0
43 1
245 0
2
0 90 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut28
3
0 0
43 1
247 0
2
0 92 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut29
3
0 0
43 1
249 0
2
0 94 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut3
3
0 0
43 1
251 0
2
0 96 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut30
3
0 0
43 1
253 0
2
0 98 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut31
3
0 0
43 1
255 0
2
0 100 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut32
3
0 0
43 1
257 0
2
0 102 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut33
3
0 0
43 1
259 0
2
0 104 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut34
3
0 0
43 1
261 0
2
0 106 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut35
3
0 0
43 1
263 0
2
0 108 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut36
3
0 0
43 1
265 0
2
0 110 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut37
3
0 0
43 1
267 0
2
0 112 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut38
3
0 0
43 1
269 0
2
0 114 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut39
3
0 0
43 1
271 0
2
0 116 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut4
3
0 0
43 1
273 0
2
0 118 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut40
3
0 0
43 1
275 0
2
0 120 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut41
3
0 0
43 1
277 0
2
0 122 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut42
3
0 0
43 1
279 0
2
0 124 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut43
3
0 0
43 1
281 0
2
0 126 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut44
3
0 0
43 1
283 0
2
0 128 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut45
3
0 0
43 1
285 0
2
0 130 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut46
3
0 0
43 1
287 0
2
0 132 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut47
3
0 0
43 1
289 0
2
0 134 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut48
3
0 0
43 1
291 0
2
0 136 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut49
3
0 0
43 1
293 0
2
0 138 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut5
3
0 0
43 1
295 0
2
0 140 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut50
3
0 0
43 1
297 0
2
0 142 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut51
3
0 0
43 1
299 0
2
0 144 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut52
3
0 0
43 1
301 0
2
0 146 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut53
3
0 0
43 1
303 0
2
0 148 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut54
3
0 0
43 1
305 0
2
0 150 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut55
3
0 0
43 1
307 0
2
0 152 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut56
3
0 0
43 1
309 0
2
0 154 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut57
3
0 0
43 1
311 0
2
0 156 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut58
3
0 0
43 1
313 0
2
0 158 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut59
3
0 0
43 1
315 0
2
0 160 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut6
3
0 0
43 1
317 0
2
0 162 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut60
3
0 0
43 1
319 0
2
0 164 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut61
3
0 0
43 1
321 0
2
0 166 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut62
3
0 0
43 1
323 0
2
0 168 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut63
3
0 0
43 1
325 0
2
0 170 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut7
3
0 0
43 1
327 0
2
0 172 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut8
3
0 0
43 1
329 0
2
0 174 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner23 bob nut9
3
0 0
43 1
331 0
2
0 176 0 1
0 258 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut1
3
0 0
44 1
207 0
2
0 52 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut10
3
0 0
44 1
209 0
2
0 54 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut11
3
0 0
44 1
211 0
2
0 56 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut12
3
0 0
44 1
213 0
2
0 58 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut13
3
0 0
44 1
215 0
2
0 60 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut14
3
0 0
44 1
217 0
2
0 62 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut15
3
0 0
44 1
219 0
2
0 64 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut16
3
0 0
44 1
221 0
2
0 66 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut17
3
0 0
44 1
223 0
2
0 68 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut18
3
0 0
44 1
225 0
2
0 70 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut19
3
0 0
44 1
227 0
2
0 72 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut2
3
0 0
44 1
229 0
2
0 74 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut20
3
0 0
44 1
231 0
2
0 76 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut21
3
0 0
44 1
233 0
2
0 78 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut22
3
0 0
44 1
235 0
2
0 80 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut23
3
0 0
44 1
237 0
2
0 82 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut24
3
0 0
44 1
239 0
2
0 84 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut25
3
0 0
44 1
241 0
2
0 86 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut26
3
0 0
44 1
243 0
2
0 88 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut27
3
0 0
44 1
245 0
2
0 90 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut28
3
0 0
44 1
247 0
2
0 92 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut29
3
0 0
44 1
249 0
2
0 94 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut3
3
0 0
44 1
251 0
2
0 96 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut30
3
0 0
44 1
253 0
2
0 98 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut31
3
0 0
44 1
255 0
2
0 100 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut32
3
0 0
44 1
257 0
2
0 102 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut33
3
0 0
44 1
259 0
2
0 104 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut34
3
0 0
44 1
261 0
2
0 106 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut35
3
0 0
44 1
263 0
2
0 108 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut36
3
0 0
44 1
265 0
2
0 110 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut37
3
0 0
44 1
267 0
2
0 112 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut38
3
0 0
44 1
269 0
2
0 114 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut39
3
0 0
44 1
271 0
2
0 116 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut4
3
0 0
44 1
273 0
2
0 118 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut40
3
0 0
44 1
275 0
2
0 120 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut41
3
0 0
44 1
277 0
2
0 122 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut42
3
0 0
44 1
279 0
2
0 124 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut43
3
0 0
44 1
281 0
2
0 126 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut44
3
0 0
44 1
283 0
2
0 128 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut45
3
0 0
44 1
285 0
2
0 130 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut46
3
0 0
44 1
287 0
2
0 132 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut47
3
0 0
44 1
289 0
2
0 134 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut48
3
0 0
44 1
291 0
2
0 136 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut49
3
0 0
44 1
293 0
2
0 138 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut5
3
0 0
44 1
295 0
2
0 140 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut50
3
0 0
44 1
297 0
2
0 142 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut51
3
0 0
44 1
299 0
2
0 144 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut52
3
0 0
44 1
301 0
2
0 146 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut53
3
0 0
44 1
303 0
2
0 148 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut54
3
0 0
44 1
305 0
2
0 150 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut55
3
0 0
44 1
307 0
2
0 152 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut56
3
0 0
44 1
309 0
2
0 154 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut57
3
0 0
44 1
311 0
2
0 156 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut58
3
0 0
44 1
313 0
2
0 158 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut59
3
0 0
44 1
315 0
2
0 160 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut6
3
0 0
44 1
317 0
2
0 162 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut60
3
0 0
44 1
319 0
2
0 164 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut61
3
0 0
44 1
321 0
2
0 166 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut62
3
0 0
44 1
323 0
2
0 168 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut63
3
0 0
44 1
325 0
2
0 170 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut7
3
0 0
44 1
327 0
2
0 172 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut8
3
0 0
44 1
329 0
2
0 174 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner24 bob nut9
3
0 0
44 1
331 0
2
0 176 0 1
0 260 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut1
3
0 0
45 1
207 0
2
0 52 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut10
3
0 0
45 1
209 0
2
0 54 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut11
3
0 0
45 1
211 0
2
0 56 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut12
3
0 0
45 1
213 0
2
0 58 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut13
3
0 0
45 1
215 0
2
0 60 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut14
3
0 0
45 1
217 0
2
0 62 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut15
3
0 0
45 1
219 0
2
0 64 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut16
3
0 0
45 1
221 0
2
0 66 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut17
3
0 0
45 1
223 0
2
0 68 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut18
3
0 0
45 1
225 0
2
0 70 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut19
3
0 0
45 1
227 0
2
0 72 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut2
3
0 0
45 1
229 0
2
0 74 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut20
3
0 0
45 1
231 0
2
0 76 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut21
3
0 0
45 1
233 0
2
0 78 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut22
3
0 0
45 1
235 0
2
0 80 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut23
3
0 0
45 1
237 0
2
0 82 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut24
3
0 0
45 1
239 0
2
0 84 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut25
3
0 0
45 1
241 0
2
0 86 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut26
3
0 0
45 1
243 0
2
0 88 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut27
3
0 0
45 1
245 0
2
0 90 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut28
3
0 0
45 1
247 0
2
0 92 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut29
3
0 0
45 1
249 0
2
0 94 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut3
3
0 0
45 1
251 0
2
0 96 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut30
3
0 0
45 1
253 0
2
0 98 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut31
3
0 0
45 1
255 0
2
0 100 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut32
3
0 0
45 1
257 0
2
0 102 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut33
3
0 0
45 1
259 0
2
0 104 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut34
3
0 0
45 1
261 0
2
0 106 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut35
3
0 0
45 1
263 0
2
0 108 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut36
3
0 0
45 1
265 0
2
0 110 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut37
3
0 0
45 1
267 0
2
0 112 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut38
3
0 0
45 1
269 0
2
0 114 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut39
3
0 0
45 1
271 0
2
0 116 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut4
3
0 0
45 1
273 0
2
0 118 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut40
3
0 0
45 1
275 0
2
0 120 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut41
3
0 0
45 1
277 0
2
0 122 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut42
3
0 0
45 1
279 0
2
0 124 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut43
3
0 0
45 1
281 0
2
0 126 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut44
3
0 0
45 1
283 0
2
0 128 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut45
3
0 0
45 1
285 0
2
0 130 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut46
3
0 0
45 1
287 0
2
0 132 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut47
3
0 0
45 1
289 0
2
0 134 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut48
3
0 0
45 1
291 0
2
0 136 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut49
3
0 0
45 1
293 0
2
0 138 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut5
3
0 0
45 1
295 0
2
0 140 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut50
3
0 0
45 1
297 0
2
0 142 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut51
3
0 0
45 1
299 0
2
0 144 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut52
3
0 0
45 1
301 0
2
0 146 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut53
3
0 0
45 1
303 0
2
0 148 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut54
3
0 0
45 1
305 0
2
0 150 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut55
3
0 0
45 1
307 0
2
0 152 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut56
3
0 0
45 1
309 0
2
0 154 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut57
3
0 0
45 1
311 0
2
0 156 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut58
3
0 0
45 1
313 0
2
0 158 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut59
3
0 0
45 1
315 0
2
0 160 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut6
3
0 0
45 1
317 0
2
0 162 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut60
3
0 0
45 1
319 0
2
0 164 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut61
3
0 0
45 1
321 0
2
0 166 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut62
3
0 0
45 1
323 0
2
0 168 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut63
3
0 0
45 1
325 0
2
0 170 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut7
3
0 0
45 1
327 0
2
0 172 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut8
3
0 0
45 1
329 0
2
0 174 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner25 bob nut9
3
0 0
45 1
331 0
2
0 176 0 1
0 262 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut1
3
0 0
46 1
207 0
2
0 52 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut10
3
0 0
46 1
209 0
2
0 54 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut11
3
0 0
46 1
211 0
2
0 56 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut12
3
0 0
46 1
213 0
2
0 58 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut13
3
0 0
46 1
215 0
2
0 60 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut14
3
0 0
46 1
217 0
2
0 62 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut15
3
0 0
46 1
219 0
2
0 64 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut16
3
0 0
46 1
221 0
2
0 66 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut17
3
0 0
46 1
223 0
2
0 68 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut18
3
0 0
46 1
225 0
2
0 70 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut19
3
0 0
46 1
227 0
2
0 72 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut2
3
0 0
46 1
229 0
2
0 74 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut20
3
0 0
46 1
231 0
2
0 76 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut21
3
0 0
46 1
233 0
2
0 78 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut22
3
0 0
46 1
235 0
2
0 80 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut23
3
0 0
46 1
237 0
2
0 82 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut24
3
0 0
46 1
239 0
2
0 84 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut25
3
0 0
46 1
241 0
2
0 86 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut26
3
0 0
46 1
243 0
2
0 88 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut27
3
0 0
46 1
245 0
2
0 90 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut28
3
0 0
46 1
247 0
2
0 92 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut29
3
0 0
46 1
249 0
2
0 94 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut3
3
0 0
46 1
251 0
2
0 96 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut30
3
0 0
46 1
253 0
2
0 98 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut31
3
0 0
46 1
255 0
2
0 100 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut32
3
0 0
46 1
257 0
2
0 102 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut33
3
0 0
46 1
259 0
2
0 104 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut34
3
0 0
46 1
261 0
2
0 106 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut35
3
0 0
46 1
263 0
2
0 108 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut36
3
0 0
46 1
265 0
2
0 110 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut37
3
0 0
46 1
267 0
2
0 112 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut38
3
0 0
46 1
269 0
2
0 114 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut39
3
0 0
46 1
271 0
2
0 116 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut4
3
0 0
46 1
273 0
2
0 118 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut40
3
0 0
46 1
275 0
2
0 120 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut41
3
0 0
46 1
277 0
2
0 122 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut42
3
0 0
46 1
279 0
2
0 124 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut43
3
0 0
46 1
281 0
2
0 126 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut44
3
0 0
46 1
283 0
2
0 128 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut45
3
0 0
46 1
285 0
2
0 130 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut46
3
0 0
46 1
287 0
2
0 132 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut47
3
0 0
46 1
289 0
2
0 134 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut48
3
0 0
46 1
291 0
2
0 136 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut49
3
0 0
46 1
293 0
2
0 138 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut5
3
0 0
46 1
295 0
2
0 140 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut50
3
0 0
46 1
297 0
2
0 142 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut51
3
0 0
46 1
299 0
2
0 144 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut52
3
0 0
46 1
301 0
2
0 146 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut53
3
0 0
46 1
303 0
2
0 148 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut54
3
0 0
46 1
305 0
2
0 150 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut55
3
0 0
46 1
307 0
2
0 152 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut56
3
0 0
46 1
309 0
2
0 154 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut57
3
0 0
46 1
311 0
2
0 156 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut58
3
0 0
46 1
313 0
2
0 158 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut59
3
0 0
46 1
315 0
2
0 160 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut6
3
0 0
46 1
317 0
2
0 162 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut60
3
0 0
46 1
319 0
2
0 164 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut61
3
0 0
46 1
321 0
2
0 166 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut62
3
0 0
46 1
323 0
2
0 168 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut63
3
0 0
46 1
325 0
2
0 170 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut7
3
0 0
46 1
327 0
2
0 172 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut8
3
0 0
46 1
329 0
2
0 174 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner26 bob nut9
3
0 0
46 1
331 0
2
0 176 0 1
0 264 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut1
3
0 0
47 1
207 0
2
0 52 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut10
3
0 0
47 1
209 0
2
0 54 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut11
3
0 0
47 1
211 0
2
0 56 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut12
3
0 0
47 1
213 0
2
0 58 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut13
3
0 0
47 1
215 0
2
0 60 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut14
3
0 0
47 1
217 0
2
0 62 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut15
3
0 0
47 1
219 0
2
0 64 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut16
3
0 0
47 1
221 0
2
0 66 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut17
3
0 0
47 1
223 0
2
0 68 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut18
3
0 0
47 1
225 0
2
0 70 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut19
3
0 0
47 1
227 0
2
0 72 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut2
3
0 0
47 1
229 0
2
0 74 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut20
3
0 0
47 1
231 0
2
0 76 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut21
3
0 0
47 1
233 0
2
0 78 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut22
3
0 0
47 1
235 0
2
0 80 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut23
3
0 0
47 1
237 0
2
0 82 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut24
3
0 0
47 1
239 0
2
0 84 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut25
3
0 0
47 1
241 0
2
0 86 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut26
3
0 0
47 1
243 0
2
0 88 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut27
3
0 0
47 1
245 0
2
0 90 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut28
3
0 0
47 1
247 0
2
0 92 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut29
3
0 0
47 1
249 0
2
0 94 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut3
3
0 0
47 1
251 0
2
0 96 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut30
3
0 0
47 1
253 0
2
0 98 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut31
3
0 0
47 1
255 0
2
0 100 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut32
3
0 0
47 1
257 0
2
0 102 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut33
3
0 0
47 1
259 0
2
0 104 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut34
3
0 0
47 1
261 0
2
0 106 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut35
3
0 0
47 1
263 0
2
0 108 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut36
3
0 0
47 1
265 0
2
0 110 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut37
3
0 0
47 1
267 0
2
0 112 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut38
3
0 0
47 1
269 0
2
0 114 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut39
3
0 0
47 1
271 0
2
0 116 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut4
3
0 0
47 1
273 0
2
0 118 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut40
3
0 0
47 1
275 0
2
0 120 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut41
3
0 0
47 1
277 0
2
0 122 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut42
3
0 0
47 1
279 0
2
0 124 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut43
3
0 0
47 1
281 0
2
0 126 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut44
3
0 0
47 1
283 0
2
0 128 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut45
3
0 0
47 1
285 0
2
0 130 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut46
3
0 0
47 1
287 0
2
0 132 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut47
3
0 0
47 1
289 0
2
0 134 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut48
3
0 0
47 1
291 0
2
0 136 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut49
3
0 0
47 1
293 0
2
0 138 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut5
3
0 0
47 1
295 0
2
0 140 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut50
3
0 0
47 1
297 0
2
0 142 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut51
3
0 0
47 1
299 0
2
0 144 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut52
3
0 0
47 1
301 0
2
0 146 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut53
3
0 0
47 1
303 0
2
0 148 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut54
3
0 0
47 1
305 0
2
0 150 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut55
3
0 0
47 1
307 0
2
0 152 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut56
3
0 0
47 1
309 0
2
0 154 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut57
3
0 0
47 1
311 0
2
0 156 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut58
3
0 0
47 1
313 0
2
0 158 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut59
3
0 0
47 1
315 0
2
0 160 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut6
3
0 0
47 1
317 0
2
0 162 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut60
3
0 0
47 1
319 0
2
0 164 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut61
3
0 0
47 1
321 0
2
0 166 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut62
3
0 0
47 1
323 0
2
0 168 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut63
3
0 0
47 1
325 0
2
0 170 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut7
3
0 0
47 1
327 0
2
0 172 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut8
3
0 0
47 1
329 0
2
0 174 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner27 bob nut9
3
0 0
47 1
331 0
2
0 176 0 1
0 266 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut1
3
0 0
48 1
207 0
2
0 52 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut10
3
0 0
48 1
209 0
2
0 54 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut11
3
0 0
48 1
211 0
2
0 56 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut12
3
0 0
48 1
213 0
2
0 58 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut13
3
0 0
48 1
215 0
2
0 60 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut14
3
0 0
48 1
217 0
2
0 62 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut15
3
0 0
48 1
219 0
2
0 64 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut16
3
0 0
48 1
221 0
2
0 66 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut17
3
0 0
48 1
223 0
2
0 68 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut18
3
0 0
48 1
225 0
2
0 70 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut19
3
0 0
48 1
227 0
2
0 72 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut2
3
0 0
48 1
229 0
2
0 74 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut20
3
0 0
48 1
231 0
2
0 76 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut21
3
0 0
48 1
233 0
2
0 78 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut22
3
0 0
48 1
235 0
2
0 80 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut23
3
0 0
48 1
237 0
2
0 82 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut24
3
0 0
48 1
239 0
2
0 84 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut25
3
0 0
48 1
241 0
2
0 86 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut26
3
0 0
48 1
243 0
2
0 88 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut27
3
0 0
48 1
245 0
2
0 90 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut28
3
0 0
48 1
247 0
2
0 92 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut29
3
0 0
48 1
249 0
2
0 94 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut3
3
0 0
48 1
251 0
2
0 96 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut30
3
0 0
48 1
253 0
2
0 98 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut31
3
0 0
48 1
255 0
2
0 100 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut32
3
0 0
48 1
257 0
2
0 102 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut33
3
0 0
48 1
259 0
2
0 104 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut34
3
0 0
48 1
261 0
2
0 106 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut35
3
0 0
48 1
263 0
2
0 108 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut36
3
0 0
48 1
265 0
2
0 110 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut37
3
0 0
48 1
267 0
2
0 112 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut38
3
0 0
48 1
269 0
2
0 114 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut39
3
0 0
48 1
271 0
2
0 116 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut4
3
0 0
48 1
273 0
2
0 118 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut40
3
0 0
48 1
275 0
2
0 120 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut41
3
0 0
48 1
277 0
2
0 122 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut42
3
0 0
48 1
279 0
2
0 124 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut43
3
0 0
48 1
281 0
2
0 126 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut44
3
0 0
48 1
283 0
2
0 128 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut45
3
0 0
48 1
285 0
2
0 130 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut46
3
0 0
48 1
287 0
2
0 132 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut47
3
0 0
48 1
289 0
2
0 134 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut48
3
0 0
48 1
291 0
2
0 136 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut49
3
0 0
48 1
293 0
2
0 138 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut5
3
0 0
48 1
295 0
2
0 140 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut50
3
0 0
48 1
297 0
2
0 142 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut51
3
0 0
48 1
299 0
2
0 144 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut52
3
0 0
48 1
301 0
2
0 146 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut53
3
0 0
48 1
303 0
2
0 148 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut54
3
0 0
48 1
305 0
2
0 150 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut55
3
0 0
48 1
307 0
2
0 152 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut56
3
0 0
48 1
309 0
2
0 154 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut57
3
0 0
48 1
311 0
2
0 156 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut58
3
0 0
48 1
313 0
2
0 158 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut59
3
0 0
48 1
315 0
2
0 160 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut6
3
0 0
48 1
317 0
2
0 162 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut60
3
0 0
48 1
319 0
2
0 164 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut61
3
0 0
48 1
321 0
2
0 166 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut62
3
0 0
48 1
323 0
2
0 168 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut63
3
0 0
48 1
325 0
2
0 170 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut7
3
0 0
48 1
327 0
2
0 172 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut8
3
0 0
48 1
329 0
2
0 174 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner28 bob nut9
3
0 0
48 1
331 0
2
0 176 0 1
0 268 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut1
3
0 0
49 1
207 0
2
0 52 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut10
3
0 0
49 1
209 0
2
0 54 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut11
3
0 0
49 1
211 0
2
0 56 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut12
3
0 0
49 1
213 0
2
0 58 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut13
3
0 0
49 1
215 0
2
0 60 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut14
3
0 0
49 1
217 0
2
0 62 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut15
3
0 0
49 1
219 0
2
0 64 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut16
3
0 0
49 1
221 0
2
0 66 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut17
3
0 0
49 1
223 0
2
0 68 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut18
3
0 0
49 1
225 0
2
0 70 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut19
3
0 0
49 1
227 0
2
0 72 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut2
3
0 0
49 1
229 0
2
0 74 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut20
3
0 0
49 1
231 0
2
0 76 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut21
3
0 0
49 1
233 0
2
0 78 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut22
3
0 0
49 1
235 0
2
0 80 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut23
3
0 0
49 1
237 0
2
0 82 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut24
3
0 0
49 1
239 0
2
0 84 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut25
3
0 0
49 1
241 0
2
0 86 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut26
3
0 0
49 1
243 0
2
0 88 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut27
3
0 0
49 1
245 0
2
0 90 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut28
3
0 0
49 1
247 0
2
0 92 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut29
3
0 0
49 1
249 0
2
0 94 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut3
3
0 0
49 1
251 0
2
0 96 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut30
3
0 0
49 1
253 0
2
0 98 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut31
3
0 0
49 1
255 0
2
0 100 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut32
3
0 0
49 1
257 0
2
0 102 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut33
3
0 0
49 1
259 0
2
0 104 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut34
3
0 0
49 1
261 0
2
0 106 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut35
3
0 0
49 1
263 0
2
0 108 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut36
3
0 0
49 1
265 0
2
0 110 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut37
3
0 0
49 1
267 0
2
0 112 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut38
3
0 0
49 1
269 0
2
0 114 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut39
3
0 0
49 1
271 0
2
0 116 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut4
3
0 0
49 1
273 0
2
0 118 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut40
3
0 0
49 1
275 0
2
0 120 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut41
3
0 0
49 1
277 0
2
0 122 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut42
3
0 0
49 1
279 0
2
0 124 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut43
3
0 0
49 1
281 0
2
0 126 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut44
3
0 0
49 1
283 0
2
0 128 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut45
3
0 0
49 1
285 0
2
0 130 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut46
3
0 0
49 1
287 0
2
0 132 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut47
3
0 0
49 1
289 0
2
0 134 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut48
3
0 0
49 1
291 0
2
0 136 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut49
3
0 0
49 1
293 0
2
0 138 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut5
3
0 0
49 1
295 0
2
0 140 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut50
3
0 0
49 1
297 0
2
0 142 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut51
3
0 0
49 1
299 0
2
0 144 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut52
3
0 0
49 1
301 0
2
0 146 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut53
3
0 0
49 1
303 0
2
0 148 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut54
3
0 0
49 1
305 0
2
0 150 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut55
3
0 0
49 1
307 0
2
0 152 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut56
3
0 0
49 1
309 0
2
0 154 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut57
3
0 0
49 1
311 0
2
0 156 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut58
3
0 0
49 1
313 0
2
0 158 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut59
3
0 0
49 1
315 0
2
0 160 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut6
3
0 0
49 1
317 0
2
0 162 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut60
3
0 0
49 1
319 0
2
0 164 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut61
3
0 0
49 1
321 0
2
0 166 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut62
3
0 0
49 1
323 0
2
0 168 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut63
3
0 0
49 1
325 0
2
0 170 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut7
3
0 0
49 1
327 0
2
0 172 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut8
3
0 0
49 1
329 0
2
0 174 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner29 bob nut9
3
0 0
49 1
331 0
2
0 176 0 1
0 270 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut1
3
0 0
50 1
207 0
2
0 52 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut10
3
0 0
50 1
209 0
2
0 54 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut11
3
0 0
50 1
211 0
2
0 56 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut12
3
0 0
50 1
213 0
2
0 58 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut13
3
0 0
50 1
215 0
2
0 60 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut14
3
0 0
50 1
217 0
2
0 62 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut15
3
0 0
50 1
219 0
2
0 64 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut16
3
0 0
50 1
221 0
2
0 66 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut17
3
0 0
50 1
223 0
2
0 68 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut18
3
0 0
50 1
225 0
2
0 70 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut19
3
0 0
50 1
227 0
2
0 72 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut2
3
0 0
50 1
229 0
2
0 74 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut20
3
0 0
50 1
231 0
2
0 76 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut21
3
0 0
50 1
233 0
2
0 78 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut22
3
0 0
50 1
235 0
2
0 80 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut23
3
0 0
50 1
237 0
2
0 82 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut24
3
0 0
50 1
239 0
2
0 84 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut25
3
0 0
50 1
241 0
2
0 86 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut26
3
0 0
50 1
243 0
2
0 88 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut27
3
0 0
50 1
245 0
2
0 90 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut28
3
0 0
50 1
247 0
2
0 92 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut29
3
0 0
50 1
249 0
2
0 94 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut3
3
0 0
50 1
251 0
2
0 96 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut30
3
0 0
50 1
253 0
2
0 98 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut31
3
0 0
50 1
255 0
2
0 100 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut32
3
0 0
50 1
257 0
2
0 102 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut33
3
0 0
50 1
259 0
2
0 104 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut34
3
0 0
50 1
261 0
2
0 106 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut35
3
0 0
50 1
263 0
2
0 108 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut36
3
0 0
50 1
265 0
2
0 110 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut37
3
0 0
50 1
267 0
2
0 112 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut38
3
0 0
50 1
269 0
2
0 114 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut39
3
0 0
50 1
271 0
2
0 116 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut4
3
0 0
50 1
273 0
2
0 118 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut40
3
0 0
50 1
275 0
2
0 120 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut41
3
0 0
50 1
277 0
2
0 122 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut42
3
0 0
50 1
279 0
2
0 124 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut43
3
0 0
50 1
281 0
2
0 126 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut44
3
0 0
50 1
283 0
2
0 128 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut45
3
0 0
50 1
285 0
2
0 130 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut46
3
0 0
50 1
287 0
2
0 132 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut47
3
0 0
50 1
289 0
2
0 134 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut48
3
0 0
50 1
291 0
2
0 136 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut49
3
0 0
50 1
293 0
2
0 138 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut5
3
0 0
50 1
295 0
2
0 140 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut50
3
0 0
50 1
297 0
2
0 142 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut51
3
0 0
50 1
299 0
2
0 144 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut52
3
0 0
50 1
301 0
2
0 146 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut53
3
0 0
50 1
303 0
2
0 148 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut54
3
0 0
50 1
305 0
2
0 150 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut55
3
0 0
50 1
307 0
2
0 152 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut56
3
0 0
50 1
309 0
2
0 154 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut57
3
0 0
50 1
311 0
2
0 156 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut58
3
0 0
50 1
313 0
2
0 158 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut59
3
0 0
50 1
315 0
2
0 160 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut6
3
0 0
50 1
317 0
2
0 162 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut60
3
0 0
50 1
319 0
2
0 164 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut61
3
0 0
50 1
321 0
2
0 166 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut62
3
0 0
50 1
323 0
2
0 168 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut63
3
0 0
50 1
325 0
2
0 170 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut7
3
0 0
50 1
327 0
2
0 172 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut8
3
0 0
50 1
329 0
2
0 174 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner3 bob nut9
3
0 0
50 1
331 0
2
0 176 0 1
0 272 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut1
3
0 0
51 1
207 0
2
0 52 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut10
3
0 0
51 1
209 0
2
0 54 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut11
3
0 0
51 1
211 0
2
0 56 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut12
3
0 0
51 1
213 0
2
0 58 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut13
3
0 0
51 1
215 0
2
0 60 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut14
3
0 0
51 1
217 0
2
0 62 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut15
3
0 0
51 1
219 0
2
0 64 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut16
3
0 0
51 1
221 0
2
0 66 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut17
3
0 0
51 1
223 0
2
0 68 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut18
3
0 0
51 1
225 0
2
0 70 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut19
3
0 0
51 1
227 0
2
0 72 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut2
3
0 0
51 1
229 0
2
0 74 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut20
3
0 0
51 1
231 0
2
0 76 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut21
3
0 0
51 1
233 0
2
0 78 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut22
3
0 0
51 1
235 0
2
0 80 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut23
3
0 0
51 1
237 0
2
0 82 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut24
3
0 0
51 1
239 0
2
0 84 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut25
3
0 0
51 1
241 0
2
0 86 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut26
3
0 0
51 1
243 0
2
0 88 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut27
3
0 0
51 1
245 0
2
0 90 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut28
3
0 0
51 1
247 0
2
0 92 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut29
3
0 0
51 1
249 0
2
0 94 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut3
3
0 0
51 1
251 0
2
0 96 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut30
3
0 0
51 1
253 0
2
0 98 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut31
3
0 0
51 1
255 0
2
0 100 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut32
3
0 0
51 1
257 0
2
0 102 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut33
3
0 0
51 1
259 0
2
0 104 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut34
3
0 0
51 1
261 0
2
0 106 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut35
3
0 0
51 1
263 0
2
0 108 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut36
3
0 0
51 1
265 0
2
0 110 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut37
3
0 0
51 1
267 0
2
0 112 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut38
3
0 0
51 1
269 0
2
0 114 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut39
3
0 0
51 1
271 0
2
0 116 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut4
3
0 0
51 1
273 0
2
0 118 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut40
3
0 0
51 1
275 0
2
0 120 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut41
3
0 0
51 1
277 0
2
0 122 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut42
3
0 0
51 1
279 0
2
0 124 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut43
3
0 0
51 1
281 0
2
0 126 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut44
3
0 0
51 1
283 0
2
0 128 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut45
3
0 0
51 1
285 0
2
0 130 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut46
3
0 0
51 1
287 0
2
0 132 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut47
3
0 0
51 1
289 0
2
0 134 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut48
3
0 0
51 1
291 0
2
0 136 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut49
3
0 0
51 1
293 0
2
0 138 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut5
3
0 0
51 1
295 0
2
0 140 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut50
3
0 0
51 1
297 0
2
0 142 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut51
3
0 0
51 1
299 0
2
0 144 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut52
3
0 0
51 1
301 0
2
0 146 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut53
3
0 0
51 1
303 0
2
0 148 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut54
3
0 0
51 1
305 0
2
0 150 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut55
3
0 0
51 1
307 0
2
0 152 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut56
3
0 0
51 1
309 0
2
0 154 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut57
3
0 0
51 1
311 0
2
0 156 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut58
3
0 0
51 1
313 0
2
0 158 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut59
3
0 0
51 1
315 0
2
0 160 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut6
3
0 0
51 1
317 0
2
0 162 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut60
3
0 0
51 1
319 0
2
0 164 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut61
3
0 0
51 1
321 0
2
0 166 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut62
3
0 0
51 1
323 0
2
0 168 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut63
3
0 0
51 1
325 0
2
0 170 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut7
3
0 0
51 1
327 0
2
0 172 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut8
3
0 0
51 1
329 0
2
0 174 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner30 bob nut9
3
0 0
51 1
331 0
2
0 176 0 1
0 274 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut1
3
0 0
53 1
207 0
2
0 52 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut10
3
0 0
53 1
209 0
2
0 54 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut11
3
0 0
53 1
211 0
2
0 56 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut12
3
0 0
53 1
213 0
2
0 58 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut13
3
0 0
53 1
215 0
2
0 60 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut14
3
0 0
53 1
217 0
2
0 62 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut15
3
0 0
53 1
219 0
2
0 64 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut16
3
0 0
53 1
221 0
2
0 66 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut17
3
0 0
53 1
223 0
2
0 68 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut18
3
0 0
53 1
225 0
2
0 70 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut19
3
0 0
53 1
227 0
2
0 72 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut2
3
0 0
53 1
229 0
2
0 74 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut20
3
0 0
53 1
231 0
2
0 76 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut21
3
0 0
53 1
233 0
2
0 78 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut22
3
0 0
53 1
235 0
2
0 80 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut23
3
0 0
53 1
237 0
2
0 82 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut24
3
0 0
53 1
239 0
2
0 84 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut25
3
0 0
53 1
241 0
2
0 86 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut26
3
0 0
53 1
243 0
2
0 88 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut27
3
0 0
53 1
245 0
2
0 90 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut28
3
0 0
53 1
247 0
2
0 92 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut29
3
0 0
53 1
249 0
2
0 94 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut3
3
0 0
53 1
251 0
2
0 96 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut30
3
0 0
53 1
253 0
2
0 98 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut31
3
0 0
53 1
255 0
2
0 100 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut32
3
0 0
53 1
257 0
2
0 102 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut33
3
0 0
53 1
259 0
2
0 104 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut34
3
0 0
53 1
261 0
2
0 106 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut35
3
0 0
53 1
263 0
2
0 108 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut36
3
0 0
53 1
265 0
2
0 110 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut37
3
0 0
53 1
267 0
2
0 112 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut38
3
0 0
53 1
269 0
2
0 114 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut39
3
0 0
53 1
271 0
2
0 116 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut4
3
0 0
53 1
273 0
2
0 118 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut40
3
0 0
53 1
275 0
2
0 120 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut41
3
0 0
53 1
277 0
2
0 122 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut42
3
0 0
53 1
279 0
2
0 124 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut43
3
0 0
53 1
281 0
2
0 126 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut44
3
0 0
53 1
283 0
2
0 128 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut45
3
0 0
53 1
285 0
2
0 130 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut46
3
0 0
53 1
287 0
2
0 132 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut47
3
0 0
53 1
289 0
2
0 134 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut48
3
0 0
53 1
291 0
2
0 136 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut49
3
0 0
53 1
293 0
2
0 138 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut5
3
0 0
53 1
295 0
2
0 140 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut50
3
0 0
53 1
297 0
2
0 142 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut51
3
0 0
53 1
299 0
2
0 144 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut52
3
0 0
53 1
301 0
2
0 146 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut53
3
0 0
53 1
303 0
2
0 148 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut54
3
0 0
53 1
305 0
2
0 150 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut55
3
0 0
53 1
307 0
2
0 152 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut56
3
0 0
53 1
309 0
2
0 154 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut57
3
0 0
53 1
311 0
2
0 156 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut58
3
0 0
53 1
313 0
2
0 158 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut59
3
0 0
53 1
315 0
2
0 160 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut6
3
0 0
53 1
317 0
2
0 162 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut60
3
0 0
53 1
319 0
2
0 164 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut61
3
0 0
53 1
321 0
2
0 166 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut62
3
0 0
53 1
323 0
2
0 168 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut63
3
0 0
53 1
325 0
2
0 170 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut7
3
0 0
53 1
327 0
2
0 172 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut8
3
0 0
53 1
329 0
2
0 174 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner31 bob nut9
3
0 0
53 1
331 0
2
0 176 0 1
0 276 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut1
3
0 0
55 1
207 0
2
0 52 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut10
3
0 0
55 1
209 0
2
0 54 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut11
3
0 0
55 1
211 0
2
0 56 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut12
3
0 0
55 1
213 0
2
0 58 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut13
3
0 0
55 1
215 0
2
0 60 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut14
3
0 0
55 1
217 0
2
0 62 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut15
3
0 0
55 1
219 0
2
0 64 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut16
3
0 0
55 1
221 0
2
0 66 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut17
3
0 0
55 1
223 0
2
0 68 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut18
3
0 0
55 1
225 0
2
0 70 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut19
3
0 0
55 1
227 0
2
0 72 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut2
3
0 0
55 1
229 0
2
0 74 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut20
3
0 0
55 1
231 0
2
0 76 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut21
3
0 0
55 1
233 0
2
0 78 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut22
3
0 0
55 1
235 0
2
0 80 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut23
3
0 0
55 1
237 0
2
0 82 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut24
3
0 0
55 1
239 0
2
0 84 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut25
3
0 0
55 1
241 0
2
0 86 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut26
3
0 0
55 1
243 0
2
0 88 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut27
3
0 0
55 1
245 0
2
0 90 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut28
3
0 0
55 1
247 0
2
0 92 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut29
3
0 0
55 1
249 0
2
0 94 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut3
3
0 0
55 1
251 0
2
0 96 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut30
3
0 0
55 1
253 0
2
0 98 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut31
3
0 0
55 1
255 0
2
0 100 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut32
3
0 0
55 1
257 0
2
0 102 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut33
3
0 0
55 1
259 0
2
0 104 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut34
3
0 0
55 1
261 0
2
0 106 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut35
3
0 0
55 1
263 0
2
0 108 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut36
3
0 0
55 1
265 0
2
0 110 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut37
3
0 0
55 1
267 0
2
0 112 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut38
3
0 0
55 1
269 0
2
0 114 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut39
3
0 0
55 1
271 0
2
0 116 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut4
3
0 0
55 1
273 0
2
0 118 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut40
3
0 0
55 1
275 0
2
0 120 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut41
3
0 0
55 1
277 0
2
0 122 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut42
3
0 0
55 1
279 0
2
0 124 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut43
3
0 0
55 1
281 0
2
0 126 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut44
3
0 0
55 1
283 0
2
0 128 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut45
3
0 0
55 1
285 0
2
0 130 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut46
3
0 0
55 1
287 0
2
0 132 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut47
3
0 0
55 1
289 0
2
0 134 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut48
3
0 0
55 1
291 0
2
0 136 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut49
3
0 0
55 1
293 0
2
0 138 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut5
3
0 0
55 1
295 0
2
0 140 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut50
3
0 0
55 1
297 0
2
0 142 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut51
3
0 0
55 1
299 0
2
0 144 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut52
3
0 0
55 1
301 0
2
0 146 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut53
3
0 0
55 1
303 0
2
0 148 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut54
3
0 0
55 1
305 0
2
0 150 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut55
3
0 0
55 1
307 0
2
0 152 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut56
3
0 0
55 1
309 0
2
0 154 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut57
3
0 0
55 1
311 0
2
0 156 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut58
3
0 0
55 1
313 0
2
0 158 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut59
3
0 0
55 1
315 0
2
0 160 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut6
3
0 0
55 1
317 0
2
0 162 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut60
3
0 0
55 1
319 0
2
0 164 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut61
3
0 0
55 1
321 0
2
0 166 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut62
3
0 0
55 1
323 0
2
0 168 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut63
3
0 0
55 1
325 0
2
0 170 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut7
3
0 0
55 1
327 0
2
0 172 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut8
3
0 0
55 1
329 0
2
0 174 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner32 bob nut9
3
0 0
55 1
331 0
2
0 176 0 1
0 278 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut1
3
0 0
57 1
207 0
2
0 52 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut10
3
0 0
57 1
209 0
2
0 54 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut11
3
0 0
57 1
211 0
2
0 56 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut12
3
0 0
57 1
213 0
2
0 58 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut13
3
0 0
57 1
215 0
2
0 60 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut14
3
0 0
57 1
217 0
2
0 62 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut15
3
0 0
57 1
219 0
2
0 64 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut16
3
0 0
57 1
221 0
2
0 66 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut17
3
0 0
57 1
223 0
2
0 68 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut18
3
0 0
57 1
225 0
2
0 70 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut19
3
0 0
57 1
227 0
2
0 72 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut2
3
0 0
57 1
229 0
2
0 74 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut20
3
0 0
57 1
231 0
2
0 76 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut21
3
0 0
57 1
233 0
2
0 78 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut22
3
0 0
57 1
235 0
2
0 80 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut23
3
0 0
57 1
237 0
2
0 82 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut24
3
0 0
57 1
239 0
2
0 84 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut25
3
0 0
57 1
241 0
2
0 86 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut26
3
0 0
57 1
243 0
2
0 88 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut27
3
0 0
57 1
245 0
2
0 90 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut28
3
0 0
57 1
247 0
2
0 92 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut29
3
0 0
57 1
249 0
2
0 94 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut3
3
0 0
57 1
251 0
2
0 96 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut30
3
0 0
57 1
253 0
2
0 98 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut31
3
0 0
57 1
255 0
2
0 100 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut32
3
0 0
57 1
257 0
2
0 102 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut33
3
0 0
57 1
259 0
2
0 104 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut34
3
0 0
57 1
261 0
2
0 106 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut35
3
0 0
57 1
263 0
2
0 108 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut36
3
0 0
57 1
265 0
2
0 110 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut37
3
0 0
57 1
267 0
2
0 112 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut38
3
0 0
57 1
269 0
2
0 114 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut39
3
0 0
57 1
271 0
2
0 116 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut4
3
0 0
57 1
273 0
2
0 118 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut40
3
0 0
57 1
275 0
2
0 120 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut41
3
0 0
57 1
277 0
2
0 122 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut42
3
0 0
57 1
279 0
2
0 124 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut43
3
0 0
57 1
281 0
2
0 126 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut44
3
0 0
57 1
283 0
2
0 128 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut45
3
0 0
57 1
285 0
2
0 130 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut46
3
0 0
57 1
287 0
2
0 132 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut47
3
0 0
57 1
289 0
2
0 134 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut48
3
0 0
57 1
291 0
2
0 136 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut49
3
0 0
57 1
293 0
2
0 138 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut5
3
0 0
57 1
295 0
2
0 140 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut50
3
0 0
57 1
297 0
2
0 142 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut51
3
0 0
57 1
299 0
2
0 144 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut52
3
0 0
57 1
301 0
2
0 146 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut53
3
0 0
57 1
303 0
2
0 148 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut54
3
0 0
57 1
305 0
2
0 150 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut55
3
0 0
57 1
307 0
2
0 152 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut56
3
0 0
57 1
309 0
2
0 154 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut57
3
0 0
57 1
311 0
2
0 156 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut58
3
0 0
57 1
313 0
2
0 158 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut59
3
0 0
57 1
315 0
2
0 160 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut6
3
0 0
57 1
317 0
2
0 162 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut60
3
0 0
57 1
319 0
2
0 164 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut61
3
0 0
57 1
321 0
2
0 166 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut62
3
0 0
57 1
323 0
2
0 168 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut63
3
0 0
57 1
325 0
2
0 170 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut7
3
0 0
57 1
327 0
2
0 172 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut8
3
0 0
57 1
329 0
2
0 174 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner33 bob nut9
3
0 0
57 1
331 0
2
0 176 0 1
0 280 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut1
3
0 0
59 1
207 0
2
0 52 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut10
3
0 0
59 1
209 0
2
0 54 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut11
3
0 0
59 1
211 0
2
0 56 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut12
3
0 0
59 1
213 0
2
0 58 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut13
3
0 0
59 1
215 0
2
0 60 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut14
3
0 0
59 1
217 0
2
0 62 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut15
3
0 0
59 1
219 0
2
0 64 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut16
3
0 0
59 1
221 0
2
0 66 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut17
3
0 0
59 1
223 0
2
0 68 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut18
3
0 0
59 1
225 0
2
0 70 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut19
3
0 0
59 1
227 0
2
0 72 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut2
3
0 0
59 1
229 0
2
0 74 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut20
3
0 0
59 1
231 0
2
0 76 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut21
3
0 0
59 1
233 0
2
0 78 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut22
3
0 0
59 1
235 0
2
0 80 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut23
3
0 0
59 1
237 0
2
0 82 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut24
3
0 0
59 1
239 0
2
0 84 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut25
3
0 0
59 1
241 0
2
0 86 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut26
3
0 0
59 1
243 0
2
0 88 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut27
3
0 0
59 1
245 0
2
0 90 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut28
3
0 0
59 1
247 0
2
0 92 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut29
3
0 0
59 1
249 0
2
0 94 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut3
3
0 0
59 1
251 0
2
0 96 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut30
3
0 0
59 1
253 0
2
0 98 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut31
3
0 0
59 1
255 0
2
0 100 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut32
3
0 0
59 1
257 0
2
0 102 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut33
3
0 0
59 1
259 0
2
0 104 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut34
3
0 0
59 1
261 0
2
0 106 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut35
3
0 0
59 1
263 0
2
0 108 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut36
3
0 0
59 1
265 0
2
0 110 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut37
3
0 0
59 1
267 0
2
0 112 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut38
3
0 0
59 1
269 0
2
0 114 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut39
3
0 0
59 1
271 0
2
0 116 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut4
3
0 0
59 1
273 0
2
0 118 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut40
3
0 0
59 1
275 0
2
0 120 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut41
3
0 0
59 1
277 0
2
0 122 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut42
3
0 0
59 1
279 0
2
0 124 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut43
3
0 0
59 1
281 0
2
0 126 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut44
3
0 0
59 1
283 0
2
0 128 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut45
3
0 0
59 1
285 0
2
0 130 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut46
3
0 0
59 1
287 0
2
0 132 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut47
3
0 0
59 1
289 0
2
0 134 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut48
3
0 0
59 1
291 0
2
0 136 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut49
3
0 0
59 1
293 0
2
0 138 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut5
3
0 0
59 1
295 0
2
0 140 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut50
3
0 0
59 1
297 0
2
0 142 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut51
3
0 0
59 1
299 0
2
0 144 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut52
3
0 0
59 1
301 0
2
0 146 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut53
3
0 0
59 1
303 0
2
0 148 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut54
3
0 0
59 1
305 0
2
0 150 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut55
3
0 0
59 1
307 0
2
0 152 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut56
3
0 0
59 1
309 0
2
0 154 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut57
3
0 0
59 1
311 0
2
0 156 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut58
3
0 0
59 1
313 0
2
0 158 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut59
3
0 0
59 1
315 0
2
0 160 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut6
3
0 0
59 1
317 0
2
0 162 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut60
3
0 0
59 1
319 0
2
0 164 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut61
3
0 0
59 1
321 0
2
0 166 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut62
3
0 0
59 1
323 0
2
0 168 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut63
3
0 0
59 1
325 0
2
0 170 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut7
3
0 0
59 1
327 0
2
0 172 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut8
3
0 0
59 1
329 0
2
0 174 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner34 bob nut9
3
0 0
59 1
331 0
2
0 176 0 1
0 282 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut1
3
0 0
61 1
207 0
2
0 52 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut10
3
0 0
61 1
209 0
2
0 54 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut11
3
0 0
61 1
211 0
2
0 56 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut12
3
0 0
61 1
213 0
2
0 58 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut13
3
0 0
61 1
215 0
2
0 60 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut14
3
0 0
61 1
217 0
2
0 62 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut15
3
0 0
61 1
219 0
2
0 64 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut16
3
0 0
61 1
221 0
2
0 66 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut17
3
0 0
61 1
223 0
2
0 68 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut18
3
0 0
61 1
225 0
2
0 70 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut19
3
0 0
61 1
227 0
2
0 72 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut2
3
0 0
61 1
229 0
2
0 74 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut20
3
0 0
61 1
231 0
2
0 76 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut21
3
0 0
61 1
233 0
2
0 78 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut22
3
0 0
61 1
235 0
2
0 80 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut23
3
0 0
61 1
237 0
2
0 82 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut24
3
0 0
61 1
239 0
2
0 84 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut25
3
0 0
61 1
241 0
2
0 86 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut26
3
0 0
61 1
243 0
2
0 88 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut27
3
0 0
61 1
245 0
2
0 90 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut28
3
0 0
61 1
247 0
2
0 92 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut29
3
0 0
61 1
249 0
2
0 94 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut3
3
0 0
61 1
251 0
2
0 96 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut30
3
0 0
61 1
253 0
2
0 98 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut31
3
0 0
61 1
255 0
2
0 100 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut32
3
0 0
61 1
257 0
2
0 102 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut33
3
0 0
61 1
259 0
2
0 104 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut34
3
0 0
61 1
261 0
2
0 106 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut35
3
0 0
61 1
263 0
2
0 108 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut36
3
0 0
61 1
265 0
2
0 110 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut37
3
0 0
61 1
267 0
2
0 112 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut38
3
0 0
61 1
269 0
2
0 114 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut39
3
0 0
61 1
271 0
2
0 116 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut4
3
0 0
61 1
273 0
2
0 118 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut40
3
0 0
61 1
275 0
2
0 120 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut41
3
0 0
61 1
277 0
2
0 122 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut42
3
0 0
61 1
279 0
2
0 124 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut43
3
0 0
61 1
281 0
2
0 126 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut44
3
0 0
61 1
283 0
2
0 128 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut45
3
0 0
61 1
285 0
2
0 130 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut46
3
0 0
61 1
287 0
2
0 132 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut47
3
0 0
61 1
289 0
2
0 134 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut48
3
0 0
61 1
291 0
2
0 136 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut49
3
0 0
61 1
293 0
2
0 138 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut5
3
0 0
61 1
295 0
2
0 140 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut50
3
0 0
61 1
297 0
2
0 142 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut51
3
0 0
61 1
299 0
2
0 144 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut52
3
0 0
61 1
301 0
2
0 146 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut53
3
0 0
61 1
303 0
2
0 148 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut54
3
0 0
61 1
305 0
2
0 150 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut55
3
0 0
61 1
307 0
2
0 152 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut56
3
0 0
61 1
309 0
2
0 154 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut57
3
0 0
61 1
311 0
2
0 156 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut58
3
0 0
61 1
313 0
2
0 158 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut59
3
0 0
61 1
315 0
2
0 160 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut6
3
0 0
61 1
317 0
2
0 162 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut60
3
0 0
61 1
319 0
2
0 164 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut61
3
0 0
61 1
321 0
2
0 166 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut62
3
0 0
61 1
323 0
2
0 168 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut63
3
0 0
61 1
325 0
2
0 170 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut7
3
0 0
61 1
327 0
2
0 172 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut8
3
0 0
61 1
329 0
2
0 174 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner35 bob nut9
3
0 0
61 1
331 0
2
0 176 0 1
0 284 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut1
3
0 0
63 1
207 0
2
0 52 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut10
3
0 0
63 1
209 0
2
0 54 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut11
3
0 0
63 1
211 0
2
0 56 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut12
3
0 0
63 1
213 0
2
0 58 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut13
3
0 0
63 1
215 0
2
0 60 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut14
3
0 0
63 1
217 0
2
0 62 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut15
3
0 0
63 1
219 0
2
0 64 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut16
3
0 0
63 1
221 0
2
0 66 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut17
3
0 0
63 1
223 0
2
0 68 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut18
3
0 0
63 1
225 0
2
0 70 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut19
3
0 0
63 1
227 0
2
0 72 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut2
3
0 0
63 1
229 0
2
0 74 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut20
3
0 0
63 1
231 0
2
0 76 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut21
3
0 0
63 1
233 0
2
0 78 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut22
3
0 0
63 1
235 0
2
0 80 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut23
3
0 0
63 1
237 0
2
0 82 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut24
3
0 0
63 1
239 0
2
0 84 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut25
3
0 0
63 1
241 0
2
0 86 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut26
3
0 0
63 1
243 0
2
0 88 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut27
3
0 0
63 1
245 0
2
0 90 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut28
3
0 0
63 1
247 0
2
0 92 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut29
3
0 0
63 1
249 0
2
0 94 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut3
3
0 0
63 1
251 0
2
0 96 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut30
3
0 0
63 1
253 0
2
0 98 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut31
3
0 0
63 1
255 0
2
0 100 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut32
3
0 0
63 1
257 0
2
0 102 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut33
3
0 0
63 1
259 0
2
0 104 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut34
3
0 0
63 1
261 0
2
0 106 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut35
3
0 0
63 1
263 0
2
0 108 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut36
3
0 0
63 1
265 0
2
0 110 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut37
3
0 0
63 1
267 0
2
0 112 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut38
3
0 0
63 1
269 0
2
0 114 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut39
3
0 0
63 1
271 0
2
0 116 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut4
3
0 0
63 1
273 0
2
0 118 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut40
3
0 0
63 1
275 0
2
0 120 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut41
3
0 0
63 1
277 0
2
0 122 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut42
3
0 0
63 1
279 0
2
0 124 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut43
3
0 0
63 1
281 0
2
0 126 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut44
3
0 0
63 1
283 0
2
0 128 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut45
3
0 0
63 1
285 0
2
0 130 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut46
3
0 0
63 1
287 0
2
0 132 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut47
3
0 0
63 1
289 0
2
0 134 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut48
3
0 0
63 1
291 0
2
0 136 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut49
3
0 0
63 1
293 0
2
0 138 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut5
3
0 0
63 1
295 0
2
0 140 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut50
3
0 0
63 1
297 0
2
0 142 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut51
3
0 0
63 1
299 0
2
0 144 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut52
3
0 0
63 1
301 0
2
0 146 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut53
3
0 0
63 1
303 0
2
0 148 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut54
3
0 0
63 1
305 0
2
0 150 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut55
3
0 0
63 1
307 0
2
0 152 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut56
3
0 0
63 1
309 0
2
0 154 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut57
3
0 0
63 1
311 0
2
0 156 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut58
3
0 0
63 1
313 0
2
0 158 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut59
3
0 0
63 1
315 0
2
0 160 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut6
3
0 0
63 1
317 0
2
0 162 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut60
3
0 0
63 1
319 0
2
0 164 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut61
3
0 0
63 1
321 0
2
0 166 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut62
3
0 0
63 1
323 0
2
0 168 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut63
3
0 0
63 1
325 0
2
0 170 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut7
3
0 0
63 1
327 0
2
0 172 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut8
3
0 0
63 1
329 0
2
0 174 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner36 bob nut9
3
0 0
63 1
331 0
2
0 176 0 1
0 286 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut1
3
0 0
65 1
207 0
2
0 52 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut10
3
0 0
65 1
209 0
2
0 54 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut11
3
0 0
65 1
211 0
2
0 56 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut12
3
0 0
65 1
213 0
2
0 58 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut13
3
0 0
65 1
215 0
2
0 60 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut14
3
0 0
65 1
217 0
2
0 62 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut15
3
0 0
65 1
219 0
2
0 64 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut16
3
0 0
65 1
221 0
2
0 66 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut17
3
0 0
65 1
223 0
2
0 68 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut18
3
0 0
65 1
225 0
2
0 70 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut19
3
0 0
65 1
227 0
2
0 72 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut2
3
0 0
65 1
229 0
2
0 74 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut20
3
0 0
65 1
231 0
2
0 76 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut21
3
0 0
65 1
233 0
2
0 78 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut22
3
0 0
65 1
235 0
2
0 80 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut23
3
0 0
65 1
237 0
2
0 82 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut24
3
0 0
65 1
239 0
2
0 84 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut25
3
0 0
65 1
241 0
2
0 86 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut26
3
0 0
65 1
243 0
2
0 88 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut27
3
0 0
65 1
245 0
2
0 90 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut28
3
0 0
65 1
247 0
2
0 92 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut29
3
0 0
65 1
249 0
2
0 94 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut3
3
0 0
65 1
251 0
2
0 96 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut30
3
0 0
65 1
253 0
2
0 98 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut31
3
0 0
65 1
255 0
2
0 100 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut32
3
0 0
65 1
257 0
2
0 102 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut33
3
0 0
65 1
259 0
2
0 104 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut34
3
0 0
65 1
261 0
2
0 106 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut35
3
0 0
65 1
263 0
2
0 108 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut36
3
0 0
65 1
265 0
2
0 110 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut37
3
0 0
65 1
267 0
2
0 112 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut38
3
0 0
65 1
269 0
2
0 114 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut39
3
0 0
65 1
271 0
2
0 116 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut4
3
0 0
65 1
273 0
2
0 118 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut40
3
0 0
65 1
275 0
2
0 120 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut41
3
0 0
65 1
277 0
2
0 122 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut42
3
0 0
65 1
279 0
2
0 124 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut43
3
0 0
65 1
281 0
2
0 126 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut44
3
0 0
65 1
283 0
2
0 128 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut45
3
0 0
65 1
285 0
2
0 130 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut46
3
0 0
65 1
287 0
2
0 132 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut47
3
0 0
65 1
289 0
2
0 134 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut48
3
0 0
65 1
291 0
2
0 136 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut49
3
0 0
65 1
293 0
2
0 138 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut5
3
0 0
65 1
295 0
2
0 140 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut50
3
0 0
65 1
297 0
2
0 142 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut51
3
0 0
65 1
299 0
2
0 144 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut52
3
0 0
65 1
301 0
2
0 146 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut53
3
0 0
65 1
303 0
2
0 148 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut54
3
0 0
65 1
305 0
2
0 150 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut55
3
0 0
65 1
307 0
2
0 152 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut56
3
0 0
65 1
309 0
2
0 154 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut57
3
0 0
65 1
311 0
2
0 156 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut58
3
0 0
65 1
313 0
2
0 158 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut59
3
0 0
65 1
315 0
2
0 160 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut6
3
0 0
65 1
317 0
2
0 162 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut60
3
0 0
65 1
319 0
2
0 164 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut61
3
0 0
65 1
321 0
2
0 166 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut62
3
0 0
65 1
323 0
2
0 168 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut63
3
0 0
65 1
325 0
2
0 170 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut7
3
0 0
65 1
327 0
2
0 172 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut8
3
0 0
65 1
329 0
2
0 174 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner37 bob nut9
3
0 0
65 1
331 0
2
0 176 0 1
0 288 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut1
3
0 0
67 1
207 0
2
0 52 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut10
3
0 0
67 1
209 0
2
0 54 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut11
3
0 0
67 1
211 0
2
0 56 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut12
3
0 0
67 1
213 0
2
0 58 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut13
3
0 0
67 1
215 0
2
0 60 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut14
3
0 0
67 1
217 0
2
0 62 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut15
3
0 0
67 1
219 0
2
0 64 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut16
3
0 0
67 1
221 0
2
0 66 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut17
3
0 0
67 1
223 0
2
0 68 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut18
3
0 0
67 1
225 0
2
0 70 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut19
3
0 0
67 1
227 0
2
0 72 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut2
3
0 0
67 1
229 0
2
0 74 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut20
3
0 0
67 1
231 0
2
0 76 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut21
3
0 0
67 1
233 0
2
0 78 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut22
3
0 0
67 1
235 0
2
0 80 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut23
3
0 0
67 1
237 0
2
0 82 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut24
3
0 0
67 1
239 0
2
0 84 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut25
3
0 0
67 1
241 0
2
0 86 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut26
3
0 0
67 1
243 0
2
0 88 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut27
3
0 0
67 1
245 0
2
0 90 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut28
3
0 0
67 1
247 0
2
0 92 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut29
3
0 0
67 1
249 0
2
0 94 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut3
3
0 0
67 1
251 0
2
0 96 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut30
3
0 0
67 1
253 0
2
0 98 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut31
3
0 0
67 1
255 0
2
0 100 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut32
3
0 0
67 1
257 0
2
0 102 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut33
3
0 0
67 1
259 0
2
0 104 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut34
3
0 0
67 1
261 0
2
0 106 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut35
3
0 0
67 1
263 0
2
0 108 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut36
3
0 0
67 1
265 0
2
0 110 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut37
3
0 0
67 1
267 0
2
0 112 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut38
3
0 0
67 1
269 0
2
0 114 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut39
3
0 0
67 1
271 0
2
0 116 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut4
3
0 0
67 1
273 0
2
0 118 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut40
3
0 0
67 1
275 0
2
0 120 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut41
3
0 0
67 1
277 0
2
0 122 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut42
3
0 0
67 1
279 0
2
0 124 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut43
3
0 0
67 1
281 0
2
0 126 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut44
3
0 0
67 1
283 0
2
0 128 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut45
3
0 0
67 1
285 0
2
0 130 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut46
3
0 0
67 1
287 0
2
0 132 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut47
3
0 0
67 1
289 0
2
0 134 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut48
3
0 0
67 1
291 0
2
0 136 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut49
3
0 0
67 1
293 0
2
0 138 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut5
3
0 0
67 1
295 0
2
0 140 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut50
3
0 0
67 1
297 0
2
0 142 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut51
3
0 0
67 1
299 0
2
0 144 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut52
3
0 0
67 1
301 0
2
0 146 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut53
3
0 0
67 1
303 0
2
0 148 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut54
3
0 0
67 1
305 0
2
0 150 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut55
3
0 0
67 1
307 0
2
0 152 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut56
3
0 0
67 1
309 0
2
0 154 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut57
3
0 0
67 1
311 0
2
0 156 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut58
3
0 0
67 1
313 0
2
0 158 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut59
3
0 0
67 1
315 0
2
0 160 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut6
3
0 0
67 1
317 0
2
0 162 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut60
3
0 0
67 1
319 0
2
0 164 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut61
3
0 0
67 1
321 0
2
0 166 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut62
3
0 0
67 1
323 0
2
0 168 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut63
3
0 0
67 1
325 0
2
0 170 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut7
3
0 0
67 1
327 0
2
0 172 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut8
3
0 0
67 1
329 0
2
0 174 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner38 bob nut9
3
0 0
67 1
331 0
2
0 176 0 1
0 290 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut1
3
0 0
69 1
207 0
2
0 52 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut10
3
0 0
69 1
209 0
2
0 54 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut11
3
0 0
69 1
211 0
2
0 56 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut12
3
0 0
69 1
213 0
2
0 58 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut13
3
0 0
69 1
215 0
2
0 60 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut14
3
0 0
69 1
217 0
2
0 62 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut15
3
0 0
69 1
219 0
2
0 64 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut16
3
0 0
69 1
221 0
2
0 66 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut17
3
0 0
69 1
223 0
2
0 68 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut18
3
0 0
69 1
225 0
2
0 70 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut19
3
0 0
69 1
227 0
2
0 72 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut2
3
0 0
69 1
229 0
2
0 74 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut20
3
0 0
69 1
231 0
2
0 76 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut21
3
0 0
69 1
233 0
2
0 78 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut22
3
0 0
69 1
235 0
2
0 80 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut23
3
0 0
69 1
237 0
2
0 82 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut24
3
0 0
69 1
239 0
2
0 84 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut25
3
0 0
69 1
241 0
2
0 86 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut26
3
0 0
69 1
243 0
2
0 88 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut27
3
0 0
69 1
245 0
2
0 90 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut28
3
0 0
69 1
247 0
2
0 92 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut29
3
0 0
69 1
249 0
2
0 94 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut3
3
0 0
69 1
251 0
2
0 96 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut30
3
0 0
69 1
253 0
2
0 98 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut31
3
0 0
69 1
255 0
2
0 100 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut32
3
0 0
69 1
257 0
2
0 102 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut33
3
0 0
69 1
259 0
2
0 104 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut34
3
0 0
69 1
261 0
2
0 106 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut35
3
0 0
69 1
263 0
2
0 108 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut36
3
0 0
69 1
265 0
2
0 110 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut37
3
0 0
69 1
267 0
2
0 112 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut38
3
0 0
69 1
269 0
2
0 114 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut39
3
0 0
69 1
271 0
2
0 116 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut4
3
0 0
69 1
273 0
2
0 118 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut40
3
0 0
69 1
275 0
2
0 120 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut41
3
0 0
69 1
277 0
2
0 122 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut42
3
0 0
69 1
279 0
2
0 124 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut43
3
0 0
69 1
281 0
2
0 126 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut44
3
0 0
69 1
283 0
2
0 128 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut45
3
0 0
69 1
285 0
2
0 130 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut46
3
0 0
69 1
287 0
2
0 132 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut47
3
0 0
69 1
289 0
2
0 134 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut48
3
0 0
69 1
291 0
2
0 136 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut49
3
0 0
69 1
293 0
2
0 138 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut5
3
0 0
69 1
295 0
2
0 140 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut50
3
0 0
69 1
297 0
2
0 142 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut51
3
0 0
69 1
299 0
2
0 144 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut52
3
0 0
69 1
301 0
2
0 146 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut53
3
0 0
69 1
303 0
2
0 148 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut54
3
0 0
69 1
305 0
2
0 150 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut55
3
0 0
69 1
307 0
2
0 152 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut56
3
0 0
69 1
309 0
2
0 154 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut57
3
0 0
69 1
311 0
2
0 156 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut58
3
0 0
69 1
313 0
2
0 158 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut59
3
0 0
69 1
315 0
2
0 160 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut6
3
0 0
69 1
317 0
2
0 162 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut60
3
0 0
69 1
319 0
2
0 164 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut61
3
0 0
69 1
321 0
2
0 166 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut62
3
0 0
69 1
323 0
2
0 168 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut63
3
0 0
69 1
325 0
2
0 170 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut7
3
0 0
69 1
327 0
2
0 172 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut8
3
0 0
69 1
329 0
2
0 174 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner39 bob nut9
3
0 0
69 1
331 0
2
0 176 0 1
0 292 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut1
3
0 0
71 1
207 0
2
0 52 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut10
3
0 0
71 1
209 0
2
0 54 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut11
3
0 0
71 1
211 0
2
0 56 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut12
3
0 0
71 1
213 0
2
0 58 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut13
3
0 0
71 1
215 0
2
0 60 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut14
3
0 0
71 1
217 0
2
0 62 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut15
3
0 0
71 1
219 0
2
0 64 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut16
3
0 0
71 1
221 0
2
0 66 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut17
3
0 0
71 1
223 0
2
0 68 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut18
3
0 0
71 1
225 0
2
0 70 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut19
3
0 0
71 1
227 0
2
0 72 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut2
3
0 0
71 1
229 0
2
0 74 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut20
3
0 0
71 1
231 0
2
0 76 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut21
3
0 0
71 1
233 0
2
0 78 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut22
3
0 0
71 1
235 0
2
0 80 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut23
3
0 0
71 1
237 0
2
0 82 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut24
3
0 0
71 1
239 0
2
0 84 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut25
3
0 0
71 1
241 0
2
0 86 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut26
3
0 0
71 1
243 0
2
0 88 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut27
3
0 0
71 1
245 0
2
0 90 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut28
3
0 0
71 1
247 0
2
0 92 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut29
3
0 0
71 1
249 0
2
0 94 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut3
3
0 0
71 1
251 0
2
0 96 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut30
3
0 0
71 1
253 0
2
0 98 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut31
3
0 0
71 1
255 0
2
0 100 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut32
3
0 0
71 1
257 0
2
0 102 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut33
3
0 0
71 1
259 0
2
0 104 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut34
3
0 0
71 1
261 0
2
0 106 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut35
3
0 0
71 1
263 0
2
0 108 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut36
3
0 0
71 1
265 0
2
0 110 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut37
3
0 0
71 1
267 0
2
0 112 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut38
3
0 0
71 1
269 0
2
0 114 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut39
3
0 0
71 1
271 0
2
0 116 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut4
3
0 0
71 1
273 0
2
0 118 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut40
3
0 0
71 1
275 0
2
0 120 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut41
3
0 0
71 1
277 0
2
0 122 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut42
3
0 0
71 1
279 0
2
0 124 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut43
3
0 0
71 1
281 0
2
0 126 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut44
3
0 0
71 1
283 0
2
0 128 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut45
3
0 0
71 1
285 0
2
0 130 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut46
3
0 0
71 1
287 0
2
0 132 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut47
3
0 0
71 1
289 0
2
0 134 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut48
3
0 0
71 1
291 0
2
0 136 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut49
3
0 0
71 1
293 0
2
0 138 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut5
3
0 0
71 1
295 0
2
0 140 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut50
3
0 0
71 1
297 0
2
0 142 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut51
3
0 0
71 1
299 0
2
0 144 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut52
3
0 0
71 1
301 0
2
0 146 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut53
3
0 0
71 1
303 0
2
0 148 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut54
3
0 0
71 1
305 0
2
0 150 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut55
3
0 0
71 1
307 0
2
0 152 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut56
3
0 0
71 1
309 0
2
0 154 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut57
3
0 0
71 1
311 0
2
0 156 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut58
3
0 0
71 1
313 0
2
0 158 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut59
3
0 0
71 1
315 0
2
0 160 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut6
3
0 0
71 1
317 0
2
0 162 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut60
3
0 0
71 1
319 0
2
0 164 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut61
3
0 0
71 1
321 0
2
0 166 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut62
3
0 0
71 1
323 0
2
0 168 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut63
3
0 0
71 1
325 0
2
0 170 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut7
3
0 0
71 1
327 0
2
0 172 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut8
3
0 0
71 1
329 0
2
0 174 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner4 bob nut9
3
0 0
71 1
331 0
2
0 176 0 1
0 294 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut1
3
0 0
73 1
207 0
2
0 52 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut10
3
0 0
73 1
209 0
2
0 54 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut11
3
0 0
73 1
211 0
2
0 56 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut12
3
0 0
73 1
213 0
2
0 58 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut13
3
0 0
73 1
215 0
2
0 60 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut14
3
0 0
73 1
217 0
2
0 62 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut15
3
0 0
73 1
219 0
2
0 64 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut16
3
0 0
73 1
221 0
2
0 66 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut17
3
0 0
73 1
223 0
2
0 68 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut18
3
0 0
73 1
225 0
2
0 70 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut19
3
0 0
73 1
227 0
2
0 72 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut2
3
0 0
73 1
229 0
2
0 74 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut20
3
0 0
73 1
231 0
2
0 76 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut21
3
0 0
73 1
233 0
2
0 78 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut22
3
0 0
73 1
235 0
2
0 80 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut23
3
0 0
73 1
237 0
2
0 82 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut24
3
0 0
73 1
239 0
2
0 84 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut25
3
0 0
73 1
241 0
2
0 86 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut26
3
0 0
73 1
243 0
2
0 88 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut27
3
0 0
73 1
245 0
2
0 90 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut28
3
0 0
73 1
247 0
2
0 92 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut29
3
0 0
73 1
249 0
2
0 94 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut3
3
0 0
73 1
251 0
2
0 96 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut30
3
0 0
73 1
253 0
2
0 98 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut31
3
0 0
73 1
255 0
2
0 100 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut32
3
0 0
73 1
257 0
2
0 102 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut33
3
0 0
73 1
259 0
2
0 104 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut34
3
0 0
73 1
261 0
2
0 106 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut35
3
0 0
73 1
263 0
2
0 108 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut36
3
0 0
73 1
265 0
2
0 110 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut37
3
0 0
73 1
267 0
2
0 112 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut38
3
0 0
73 1
269 0
2
0 114 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut39
3
0 0
73 1
271 0
2
0 116 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut4
3
0 0
73 1
273 0
2
0 118 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut40
3
0 0
73 1
275 0
2
0 120 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut41
3
0 0
73 1
277 0
2
0 122 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut42
3
0 0
73 1
279 0
2
0 124 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut43
3
0 0
73 1
281 0
2
0 126 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut44
3
0 0
73 1
283 0
2
0 128 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut45
3
0 0
73 1
285 0
2
0 130 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut46
3
0 0
73 1
287 0
2
0 132 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut47
3
0 0
73 1
289 0
2
0 134 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut48
3
0 0
73 1
291 0
2
0 136 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut49
3
0 0
73 1
293 0
2
0 138 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut5
3
0 0
73 1
295 0
2
0 140 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut50
3
0 0
73 1
297 0
2
0 142 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut51
3
0 0
73 1
299 0
2
0 144 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut52
3
0 0
73 1
301 0
2
0 146 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut53
3
0 0
73 1
303 0
2
0 148 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut54
3
0 0
73 1
305 0
2
0 150 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut55
3
0 0
73 1
307 0
2
0 152 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut56
3
0 0
73 1
309 0
2
0 154 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut57
3
0 0
73 1
311 0
2
0 156 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut58
3
0 0
73 1
313 0
2
0 158 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut59
3
0 0
73 1
315 0
2
0 160 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut6
3
0 0
73 1
317 0
2
0 162 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut60
3
0 0
73 1
319 0
2
0 164 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut61
3
0 0
73 1
321 0
2
0 166 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut62
3
0 0
73 1
323 0
2
0 168 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut63
3
0 0
73 1
325 0
2
0 170 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut7
3
0 0
73 1
327 0
2
0 172 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut8
3
0 0
73 1
329 0
2
0 174 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner40 bob nut9
3
0 0
73 1
331 0
2
0 176 0 1
0 296 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut1
3
0 0
75 1
207 0
2
0 52 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut10
3
0 0
75 1
209 0
2
0 54 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut11
3
0 0
75 1
211 0
2
0 56 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut12
3
0 0
75 1
213 0
2
0 58 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut13
3
0 0
75 1
215 0
2
0 60 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut14
3
0 0
75 1
217 0
2
0 62 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut15
3
0 0
75 1
219 0
2
0 64 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut16
3
0 0
75 1
221 0
2
0 66 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut17
3
0 0
75 1
223 0
2
0 68 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut18
3
0 0
75 1
225 0
2
0 70 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut19
3
0 0
75 1
227 0
2
0 72 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut2
3
0 0
75 1
229 0
2
0 74 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut20
3
0 0
75 1
231 0
2
0 76 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut21
3
0 0
75 1
233 0
2
0 78 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut22
3
0 0
75 1
235 0
2
0 80 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut23
3
0 0
75 1
237 0
2
0 82 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut24
3
0 0
75 1
239 0
2
0 84 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut25
3
0 0
75 1
241 0
2
0 86 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut26
3
0 0
75 1
243 0
2
0 88 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut27
3
0 0
75 1
245 0
2
0 90 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut28
3
0 0
75 1
247 0
2
0 92 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut29
3
0 0
75 1
249 0
2
0 94 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut3
3
0 0
75 1
251 0
2
0 96 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut30
3
0 0
75 1
253 0
2
0 98 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut31
3
0 0
75 1
255 0
2
0 100 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut32
3
0 0
75 1
257 0
2
0 102 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut33
3
0 0
75 1
259 0
2
0 104 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut34
3
0 0
75 1
261 0
2
0 106 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut35
3
0 0
75 1
263 0
2
0 108 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut36
3
0 0
75 1
265 0
2
0 110 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut37
3
0 0
75 1
267 0
2
0 112 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut38
3
0 0
75 1
269 0
2
0 114 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut39
3
0 0
75 1
271 0
2
0 116 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut4
3
0 0
75 1
273 0
2
0 118 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut40
3
0 0
75 1
275 0
2
0 120 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut41
3
0 0
75 1
277 0
2
0 122 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut42
3
0 0
75 1
279 0
2
0 124 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut43
3
0 0
75 1
281 0
2
0 126 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut44
3
0 0
75 1
283 0
2
0 128 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut45
3
0 0
75 1
285 0
2
0 130 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut46
3
0 0
75 1
287 0
2
0 132 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut47
3
0 0
75 1
289 0
2
0 134 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut48
3
0 0
75 1
291 0
2
0 136 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut49
3
0 0
75 1
293 0
2
0 138 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut5
3
0 0
75 1
295 0
2
0 140 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut50
3
0 0
75 1
297 0
2
0 142 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut51
3
0 0
75 1
299 0
2
0 144 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut52
3
0 0
75 1
301 0
2
0 146 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut53
3
0 0
75 1
303 0
2
0 148 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut54
3
0 0
75 1
305 0
2
0 150 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut55
3
0 0
75 1
307 0
2
0 152 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut56
3
0 0
75 1
309 0
2
0 154 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut57
3
0 0
75 1
311 0
2
0 156 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut58
3
0 0
75 1
313 0
2
0 158 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut59
3
0 0
75 1
315 0
2
0 160 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut6
3
0 0
75 1
317 0
2
0 162 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut60
3
0 0
75 1
319 0
2
0 164 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut61
3
0 0
75 1
321 0
2
0 166 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut62
3
0 0
75 1
323 0
2
0 168 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut63
3
0 0
75 1
325 0
2
0 170 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut7
3
0 0
75 1
327 0
2
0 172 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut8
3
0 0
75 1
329 0
2
0 174 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner41 bob nut9
3
0 0
75 1
331 0
2
0 176 0 1
0 298 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut1
3
0 0
77 1
207 0
2
0 52 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut10
3
0 0
77 1
209 0
2
0 54 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut11
3
0 0
77 1
211 0
2
0 56 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut12
3
0 0
77 1
213 0
2
0 58 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut13
3
0 0
77 1
215 0
2
0 60 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut14
3
0 0
77 1
217 0
2
0 62 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut15
3
0 0
77 1
219 0
2
0 64 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut16
3
0 0
77 1
221 0
2
0 66 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut17
3
0 0
77 1
223 0
2
0 68 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut18
3
0 0
77 1
225 0
2
0 70 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut19
3
0 0
77 1
227 0
2
0 72 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut2
3
0 0
77 1
229 0
2
0 74 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut20
3
0 0
77 1
231 0
2
0 76 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut21
3
0 0
77 1
233 0
2
0 78 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut22
3
0 0
77 1
235 0
2
0 80 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut23
3
0 0
77 1
237 0
2
0 82 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut24
3
0 0
77 1
239 0
2
0 84 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut25
3
0 0
77 1
241 0
2
0 86 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut26
3
0 0
77 1
243 0
2
0 88 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut27
3
0 0
77 1
245 0
2
0 90 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut28
3
0 0
77 1
247 0
2
0 92 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut29
3
0 0
77 1
249 0
2
0 94 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut3
3
0 0
77 1
251 0
2
0 96 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut30
3
0 0
77 1
253 0
2
0 98 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut31
3
0 0
77 1
255 0
2
0 100 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut32
3
0 0
77 1
257 0
2
0 102 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut33
3
0 0
77 1
259 0
2
0 104 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut34
3
0 0
77 1
261 0
2
0 106 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut35
3
0 0
77 1
263 0
2
0 108 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut36
3
0 0
77 1
265 0
2
0 110 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut37
3
0 0
77 1
267 0
2
0 112 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut38
3
0 0
77 1
269 0
2
0 114 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut39
3
0 0
77 1
271 0
2
0 116 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut4
3
0 0
77 1
273 0
2
0 118 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut40
3
0 0
77 1
275 0
2
0 120 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut41
3
0 0
77 1
277 0
2
0 122 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut42
3
0 0
77 1
279 0
2
0 124 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut43
3
0 0
77 1
281 0
2
0 126 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut44
3
0 0
77 1
283 0
2
0 128 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut45
3
0 0
77 1
285 0
2
0 130 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut46
3
0 0
77 1
287 0
2
0 132 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut47
3
0 0
77 1
289 0
2
0 134 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut48
3
0 0
77 1
291 0
2
0 136 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut49
3
0 0
77 1
293 0
2
0 138 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut5
3
0 0
77 1
295 0
2
0 140 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut50
3
0 0
77 1
297 0
2
0 142 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut51
3
0 0
77 1
299 0
2
0 144 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut52
3
0 0
77 1
301 0
2
0 146 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut53
3
0 0
77 1
303 0
2
0 148 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut54
3
0 0
77 1
305 0
2
0 150 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut55
3
0 0
77 1
307 0
2
0 152 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut56
3
0 0
77 1
309 0
2
0 154 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut57
3
0 0
77 1
311 0
2
0 156 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut58
3
0 0
77 1
313 0
2
0 158 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut59
3
0 0
77 1
315 0
2
0 160 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut6
3
0 0
77 1
317 0
2
0 162 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut60
3
0 0
77 1
319 0
2
0 164 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut61
3
0 0
77 1
321 0
2
0 166 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut62
3
0 0
77 1
323 0
2
0 168 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut63
3
0 0
77 1
325 0
2
0 170 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut7
3
0 0
77 1
327 0
2
0 172 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut8
3
0 0
77 1
329 0
2
0 174 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner42 bob nut9
3
0 0
77 1
331 0
2
0 176 0 1
0 300 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut1
3
0 0
79 1
207 0
2
0 52 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut10
3
0 0
79 1
209 0
2
0 54 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut11
3
0 0
79 1
211 0
2
0 56 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut12
3
0 0
79 1
213 0
2
0 58 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut13
3
0 0
79 1
215 0
2
0 60 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut14
3
0 0
79 1
217 0
2
0 62 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut15
3
0 0
79 1
219 0
2
0 64 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut16
3
0 0
79 1
221 0
2
0 66 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut17
3
0 0
79 1
223 0
2
0 68 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut18
3
0 0
79 1
225 0
2
0 70 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut19
3
0 0
79 1
227 0
2
0 72 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut2
3
0 0
79 1
229 0
2
0 74 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut20
3
0 0
79 1
231 0
2
0 76 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut21
3
0 0
79 1
233 0
2
0 78 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut22
3
0 0
79 1
235 0
2
0 80 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut23
3
0 0
79 1
237 0
2
0 82 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut24
3
0 0
79 1
239 0
2
0 84 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut25
3
0 0
79 1
241 0
2
0 86 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut26
3
0 0
79 1
243 0
2
0 88 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut27
3
0 0
79 1
245 0
2
0 90 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut28
3
0 0
79 1
247 0
2
0 92 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut29
3
0 0
79 1
249 0
2
0 94 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut3
3
0 0
79 1
251 0
2
0 96 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut30
3
0 0
79 1
253 0
2
0 98 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut31
3
0 0
79 1
255 0
2
0 100 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut32
3
0 0
79 1
257 0
2
0 102 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut33
3
0 0
79 1
259 0
2
0 104 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut34
3
0 0
79 1
261 0
2
0 106 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut35
3
0 0
79 1
263 0
2
0 108 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut36
3
0 0
79 1
265 0
2
0 110 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut37
3
0 0
79 1
267 0
2
0 112 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut38
3
0 0
79 1
269 0
2
0 114 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut39
3
0 0
79 1
271 0
2
0 116 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut4
3
0 0
79 1
273 0
2
0 118 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut40
3
0 0
79 1
275 0
2
0 120 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut41
3
0 0
79 1
277 0
2
0 122 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut42
3
0 0
79 1
279 0
2
0 124 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut43
3
0 0
79 1
281 0
2
0 126 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut44
3
0 0
79 1
283 0
2
0 128 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut45
3
0 0
79 1
285 0
2
0 130 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut46
3
0 0
79 1
287 0
2
0 132 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut47
3
0 0
79 1
289 0
2
0 134 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut48
3
0 0
79 1
291 0
2
0 136 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut49
3
0 0
79 1
293 0
2
0 138 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut5
3
0 0
79 1
295 0
2
0 140 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut50
3
0 0
79 1
297 0
2
0 142 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut51
3
0 0
79 1
299 0
2
0 144 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut52
3
0 0
79 1
301 0
2
0 146 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut53
3
0 0
79 1
303 0
2
0 148 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut54
3
0 0
79 1
305 0
2
0 150 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut55
3
0 0
79 1
307 0
2
0 152 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut56
3
0 0
79 1
309 0
2
0 154 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut57
3
0 0
79 1
311 0
2
0 156 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut58
3
0 0
79 1
313 0
2
0 158 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut59
3
0 0
79 1
315 0
2
0 160 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut6
3
0 0
79 1
317 0
2
0 162 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut60
3
0 0
79 1
319 0
2
0 164 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut61
3
0 0
79 1
321 0
2
0 166 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut62
3
0 0
79 1
323 0
2
0 168 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut63
3
0 0
79 1
325 0
2
0 170 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut7
3
0 0
79 1
327 0
2
0 172 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut8
3
0 0
79 1
329 0
2
0 174 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner43 bob nut9
3
0 0
79 1
331 0
2
0 176 0 1
0 302 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut1
3
0 0
81 1
207 0
2
0 52 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut10
3
0 0
81 1
209 0
2
0 54 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut11
3
0 0
81 1
211 0
2
0 56 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut12
3
0 0
81 1
213 0
2
0 58 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut13
3
0 0
81 1
215 0
2
0 60 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut14
3
0 0
81 1
217 0
2
0 62 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut15
3
0 0
81 1
219 0
2
0 64 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut16
3
0 0
81 1
221 0
2
0 66 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut17
3
0 0
81 1
223 0
2
0 68 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut18
3
0 0
81 1
225 0
2
0 70 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut19
3
0 0
81 1
227 0
2
0 72 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut2
3
0 0
81 1
229 0
2
0 74 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut20
3
0 0
81 1
231 0
2
0 76 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut21
3
0 0
81 1
233 0
2
0 78 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut22
3
0 0
81 1
235 0
2
0 80 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut23
3
0 0
81 1
237 0
2
0 82 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut24
3
0 0
81 1
239 0
2
0 84 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut25
3
0 0
81 1
241 0
2
0 86 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut26
3
0 0
81 1
243 0
2
0 88 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut27
3
0 0
81 1
245 0
2
0 90 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut28
3
0 0
81 1
247 0
2
0 92 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut29
3
0 0
81 1
249 0
2
0 94 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut3
3
0 0
81 1
251 0
2
0 96 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut30
3
0 0
81 1
253 0
2
0 98 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut31
3
0 0
81 1
255 0
2
0 100 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut32
3
0 0
81 1
257 0
2
0 102 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut33
3
0 0
81 1
259 0
2
0 104 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut34
3
0 0
81 1
261 0
2
0 106 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut35
3
0 0
81 1
263 0
2
0 108 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut36
3
0 0
81 1
265 0
2
0 110 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut37
3
0 0
81 1
267 0
2
0 112 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut38
3
0 0
81 1
269 0
2
0 114 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut39
3
0 0
81 1
271 0
2
0 116 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut4
3
0 0
81 1
273 0
2
0 118 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut40
3
0 0
81 1
275 0
2
0 120 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut41
3
0 0
81 1
277 0
2
0 122 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut42
3
0 0
81 1
279 0
2
0 124 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut43
3
0 0
81 1
281 0
2
0 126 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut44
3
0 0
81 1
283 0
2
0 128 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut45
3
0 0
81 1
285 0
2
0 130 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut46
3
0 0
81 1
287 0
2
0 132 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut47
3
0 0
81 1
289 0
2
0 134 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut48
3
0 0
81 1
291 0
2
0 136 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut49
3
0 0
81 1
293 0
2
0 138 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut5
3
0 0
81 1
295 0
2
0 140 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut50
3
0 0
81 1
297 0
2
0 142 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut51
3
0 0
81 1
299 0
2
0 144 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut52
3
0 0
81 1
301 0
2
0 146 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut53
3
0 0
81 1
303 0
2
0 148 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut54
3
0 0
81 1
305 0
2
0 150 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut55
3
0 0
81 1
307 0
2
0 152 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut56
3
0 0
81 1
309 0
2
0 154 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut57
3
0 0
81 1
311 0
2
0 156 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut58
3
0 0
81 1
313 0
2
0 158 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut59
3
0 0
81 1
315 0
2
0 160 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut6
3
0 0
81 1
317 0
2
0 162 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut60
3
0 0
81 1
319 0
2
0 164 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut61
3
0 0
81 1
321 0
2
0 166 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut62
3
0 0
81 1
323 0
2
0 168 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut63
3
0 0
81 1
325 0
2
0 170 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut7
3
0 0
81 1
327 0
2
0 172 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut8
3
0 0
81 1
329 0
2
0 174 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner44 bob nut9
3
0 0
81 1
331 0
2
0 176 0 1
0 304 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut1
3
0 0
83 1
207 0
2
0 52 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut10
3
0 0
83 1
209 0
2
0 54 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut11
3
0 0
83 1
211 0
2
0 56 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut12
3
0 0
83 1
213 0
2
0 58 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut13
3
0 0
83 1
215 0
2
0 60 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut14
3
0 0
83 1
217 0
2
0 62 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut15
3
0 0
83 1
219 0
2
0 64 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut16
3
0 0
83 1
221 0
2
0 66 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut17
3
0 0
83 1
223 0
2
0 68 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut18
3
0 0
83 1
225 0
2
0 70 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut19
3
0 0
83 1
227 0
2
0 72 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut2
3
0 0
83 1
229 0
2
0 74 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut20
3
0 0
83 1
231 0
2
0 76 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut21
3
0 0
83 1
233 0
2
0 78 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut22
3
0 0
83 1
235 0
2
0 80 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut23
3
0 0
83 1
237 0
2
0 82 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut24
3
0 0
83 1
239 0
2
0 84 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut25
3
0 0
83 1
241 0
2
0 86 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut26
3
0 0
83 1
243 0
2
0 88 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut27
3
0 0
83 1
245 0
2
0 90 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut28
3
0 0
83 1
247 0
2
0 92 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut29
3
0 0
83 1
249 0
2
0 94 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut3
3
0 0
83 1
251 0
2
0 96 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut30
3
0 0
83 1
253 0
2
0 98 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut31
3
0 0
83 1
255 0
2
0 100 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut32
3
0 0
83 1
257 0
2
0 102 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut33
3
0 0
83 1
259 0
2
0 104 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut34
3
0 0
83 1
261 0
2
0 106 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut35
3
0 0
83 1
263 0
2
0 108 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut36
3
0 0
83 1
265 0
2
0 110 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut37
3
0 0
83 1
267 0
2
0 112 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut38
3
0 0
83 1
269 0
2
0 114 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut39
3
0 0
83 1
271 0
2
0 116 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut4
3
0 0
83 1
273 0
2
0 118 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut40
3
0 0
83 1
275 0
2
0 120 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut41
3
0 0
83 1
277 0
2
0 122 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut42
3
0 0
83 1
279 0
2
0 124 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut43
3
0 0
83 1
281 0
2
0 126 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut44
3
0 0
83 1
283 0
2
0 128 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut45
3
0 0
83 1
285 0
2
0 130 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut46
3
0 0
83 1
287 0
2
0 132 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut47
3
0 0
83 1
289 0
2
0 134 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut48
3
0 0
83 1
291 0
2
0 136 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut49
3
0 0
83 1
293 0
2
0 138 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut5
3
0 0
83 1
295 0
2
0 140 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut50
3
0 0
83 1
297 0
2
0 142 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut51
3
0 0
83 1
299 0
2
0 144 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut52
3
0 0
83 1
301 0
2
0 146 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut53
3
0 0
83 1
303 0
2
0 148 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut54
3
0 0
83 1
305 0
2
0 150 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut55
3
0 0
83 1
307 0
2
0 152 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut56
3
0 0
83 1
309 0
2
0 154 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut57
3
0 0
83 1
311 0
2
0 156 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut58
3
0 0
83 1
313 0
2
0 158 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut59
3
0 0
83 1
315 0
2
0 160 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut6
3
0 0
83 1
317 0
2
0 162 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut60
3
0 0
83 1
319 0
2
0 164 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut61
3
0 0
83 1
321 0
2
0 166 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut62
3
0 0
83 1
323 0
2
0 168 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut63
3
0 0
83 1
325 0
2
0 170 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut7
3
0 0
83 1
327 0
2
0 172 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut8
3
0 0
83 1
329 0
2
0 174 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner45 bob nut9
3
0 0
83 1
331 0
2
0 176 0 1
0 306 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut1
3
0 0
85 1
207 0
2
0 52 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut10
3
0 0
85 1
209 0
2
0 54 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut11
3
0 0
85 1
211 0
2
0 56 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut12
3
0 0
85 1
213 0
2
0 58 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut13
3
0 0
85 1
215 0
2
0 60 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut14
3
0 0
85 1
217 0
2
0 62 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut15
3
0 0
85 1
219 0
2
0 64 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut16
3
0 0
85 1
221 0
2
0 66 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut17
3
0 0
85 1
223 0
2
0 68 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut18
3
0 0
85 1
225 0
2
0 70 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut19
3
0 0
85 1
227 0
2
0 72 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut2
3
0 0
85 1
229 0
2
0 74 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut20
3
0 0
85 1
231 0
2
0 76 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut21
3
0 0
85 1
233 0
2
0 78 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut22
3
0 0
85 1
235 0
2
0 80 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut23
3
0 0
85 1
237 0
2
0 82 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut24
3
0 0
85 1
239 0
2
0 84 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut25
3
0 0
85 1
241 0
2
0 86 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut26
3
0 0
85 1
243 0
2
0 88 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut27
3
0 0
85 1
245 0
2
0 90 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut28
3
0 0
85 1
247 0
2
0 92 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut29
3
0 0
85 1
249 0
2
0 94 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut3
3
0 0
85 1
251 0
2
0 96 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut30
3
0 0
85 1
253 0
2
0 98 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut31
3
0 0
85 1
255 0
2
0 100 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut32
3
0 0
85 1
257 0
2
0 102 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut33
3
0 0
85 1
259 0
2
0 104 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut34
3
0 0
85 1
261 0
2
0 106 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut35
3
0 0
85 1
263 0
2
0 108 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut36
3
0 0
85 1
265 0
2
0 110 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut37
3
0 0
85 1
267 0
2
0 112 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut38
3
0 0
85 1
269 0
2
0 114 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut39
3
0 0
85 1
271 0
2
0 116 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut4
3
0 0
85 1
273 0
2
0 118 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut40
3
0 0
85 1
275 0
2
0 120 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut41
3
0 0
85 1
277 0
2
0 122 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut42
3
0 0
85 1
279 0
2
0 124 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut43
3
0 0
85 1
281 0
2
0 126 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut44
3
0 0
85 1
283 0
2
0 128 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut45
3
0 0
85 1
285 0
2
0 130 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut46
3
0 0
85 1
287 0
2
0 132 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut47
3
0 0
85 1
289 0
2
0 134 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut48
3
0 0
85 1
291 0
2
0 136 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut49
3
0 0
85 1
293 0
2
0 138 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut5
3
0 0
85 1
295 0
2
0 140 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut50
3
0 0
85 1
297 0
2
0 142 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut51
3
0 0
85 1
299 0
2
0 144 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut52
3
0 0
85 1
301 0
2
0 146 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut53
3
0 0
85 1
303 0
2
0 148 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut54
3
0 0
85 1
305 0
2
0 150 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut55
3
0 0
85 1
307 0
2
0 152 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut56
3
0 0
85 1
309 0
2
0 154 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut57
3
0 0
85 1
311 0
2
0 156 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut58
3
0 0
85 1
313 0
2
0 158 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut59
3
0 0
85 1
315 0
2
0 160 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut6
3
0 0
85 1
317 0
2
0 162 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut60
3
0 0
85 1
319 0
2
0 164 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut61
3
0 0
85 1
321 0
2
0 166 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut62
3
0 0
85 1
323 0
2
0 168 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut63
3
0 0
85 1
325 0
2
0 170 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut7
3
0 0
85 1
327 0
2
0 172 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut8
3
0 0
85 1
329 0
2
0 174 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner46 bob nut9
3
0 0
85 1
331 0
2
0 176 0 1
0 308 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut1
3
0 0
87 1
207 0
2
0 52 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut10
3
0 0
87 1
209 0
2
0 54 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut11
3
0 0
87 1
211 0
2
0 56 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut12
3
0 0
87 1
213 0
2
0 58 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut13
3
0 0
87 1
215 0
2
0 60 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut14
3
0 0
87 1
217 0
2
0 62 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut15
3
0 0
87 1
219 0
2
0 64 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut16
3
0 0
87 1
221 0
2
0 66 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut17
3
0 0
87 1
223 0
2
0 68 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut18
3
0 0
87 1
225 0
2
0 70 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut19
3
0 0
87 1
227 0
2
0 72 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut2
3
0 0
87 1
229 0
2
0 74 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut20
3
0 0
87 1
231 0
2
0 76 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut21
3
0 0
87 1
233 0
2
0 78 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut22
3
0 0
87 1
235 0
2
0 80 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut23
3
0 0
87 1
237 0
2
0 82 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut24
3
0 0
87 1
239 0
2
0 84 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut25
3
0 0
87 1
241 0
2
0 86 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut26
3
0 0
87 1
243 0
2
0 88 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut27
3
0 0
87 1
245 0
2
0 90 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut28
3
0 0
87 1
247 0
2
0 92 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut29
3
0 0
87 1
249 0
2
0 94 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut3
3
0 0
87 1
251 0
2
0 96 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut30
3
0 0
87 1
253 0
2
0 98 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut31
3
0 0
87 1
255 0
2
0 100 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut32
3
0 0
87 1
257 0
2
0 102 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut33
3
0 0
87 1
259 0
2
0 104 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut34
3
0 0
87 1
261 0
2
0 106 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut35
3
0 0
87 1
263 0
2
0 108 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut36
3
0 0
87 1
265 0
2
0 110 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut37
3
0 0
87 1
267 0
2
0 112 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut38
3
0 0
87 1
269 0
2
0 114 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut39
3
0 0
87 1
271 0
2
0 116 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut4
3
0 0
87 1
273 0
2
0 118 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut40
3
0 0
87 1
275 0
2
0 120 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut41
3
0 0
87 1
277 0
2
0 122 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut42
3
0 0
87 1
279 0
2
0 124 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut43
3
0 0
87 1
281 0
2
0 126 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut44
3
0 0
87 1
283 0
2
0 128 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut45
3
0 0
87 1
285 0
2
0 130 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut46
3
0 0
87 1
287 0
2
0 132 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut47
3
0 0
87 1
289 0
2
0 134 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut48
3
0 0
87 1
291 0
2
0 136 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut49
3
0 0
87 1
293 0
2
0 138 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut5
3
0 0
87 1
295 0
2
0 140 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut50
3
0 0
87 1
297 0
2
0 142 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut51
3
0 0
87 1
299 0
2
0 144 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut52
3
0 0
87 1
301 0
2
0 146 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut53
3
0 0
87 1
303 0
2
0 148 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut54
3
0 0
87 1
305 0
2
0 150 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut55
3
0 0
87 1
307 0
2
0 152 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut56
3
0 0
87 1
309 0
2
0 154 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut57
3
0 0
87 1
311 0
2
0 156 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut58
3
0 0
87 1
313 0
2
0 158 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut59
3
0 0
87 1
315 0
2
0 160 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut6
3
0 0
87 1
317 0
2
0 162 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut60
3
0 0
87 1
319 0
2
0 164 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut61
3
0 0
87 1
321 0
2
0 166 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut62
3
0 0
87 1
323 0
2
0 168 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut63
3
0 0
87 1
325 0
2
0 170 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut7
3
0 0
87 1
327 0
2
0 172 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut8
3
0 0
87 1
329 0
2
0 174 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner47 bob nut9
3
0 0
87 1
331 0
2
0 176 0 1
0 310 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut1
3
0 0
89 1
207 0
2
0 52 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut10
3
0 0
89 1
209 0
2
0 54 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut11
3
0 0
89 1
211 0
2
0 56 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut12
3
0 0
89 1
213 0
2
0 58 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut13
3
0 0
89 1
215 0
2
0 60 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut14
3
0 0
89 1
217 0
2
0 62 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut15
3
0 0
89 1
219 0
2
0 64 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut16
3
0 0
89 1
221 0
2
0 66 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut17
3
0 0
89 1
223 0
2
0 68 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut18
3
0 0
89 1
225 0
2
0 70 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut19
3
0 0
89 1
227 0
2
0 72 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut2
3
0 0
89 1
229 0
2
0 74 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut20
3
0 0
89 1
231 0
2
0 76 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut21
3
0 0
89 1
233 0
2
0 78 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut22
3
0 0
89 1
235 0
2
0 80 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut23
3
0 0
89 1
237 0
2
0 82 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut24
3
0 0
89 1
239 0
2
0 84 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut25
3
0 0
89 1
241 0
2
0 86 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut26
3
0 0
89 1
243 0
2
0 88 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut27
3
0 0
89 1
245 0
2
0 90 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut28
3
0 0
89 1
247 0
2
0 92 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut29
3
0 0
89 1
249 0
2
0 94 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut3
3
0 0
89 1
251 0
2
0 96 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut30
3
0 0
89 1
253 0
2
0 98 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut31
3
0 0
89 1
255 0
2
0 100 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut32
3
0 0
89 1
257 0
2
0 102 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut33
3
0 0
89 1
259 0
2
0 104 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut34
3
0 0
89 1
261 0
2
0 106 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut35
3
0 0
89 1
263 0
2
0 108 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut36
3
0 0
89 1
265 0
2
0 110 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut37
3
0 0
89 1
267 0
2
0 112 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut38
3
0 0
89 1
269 0
2
0 114 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut39
3
0 0
89 1
271 0
2
0 116 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut4
3
0 0
89 1
273 0
2
0 118 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut40
3
0 0
89 1
275 0
2
0 120 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut41
3
0 0
89 1
277 0
2
0 122 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut42
3
0 0
89 1
279 0
2
0 124 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut43
3
0 0
89 1
281 0
2
0 126 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut44
3
0 0
89 1
283 0
2
0 128 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut45
3
0 0
89 1
285 0
2
0 130 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut46
3
0 0
89 1
287 0
2
0 132 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut47
3
0 0
89 1
289 0
2
0 134 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut48
3
0 0
89 1
291 0
2
0 136 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut49
3
0 0
89 1
293 0
2
0 138 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut5
3
0 0
89 1
295 0
2
0 140 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut50
3
0 0
89 1
297 0
2
0 142 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut51
3
0 0
89 1
299 0
2
0 144 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut52
3
0 0
89 1
301 0
2
0 146 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut53
3
0 0
89 1
303 0
2
0 148 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut54
3
0 0
89 1
305 0
2
0 150 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut55
3
0 0
89 1
307 0
2
0 152 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut56
3
0 0
89 1
309 0
2
0 154 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut57
3
0 0
89 1
311 0
2
0 156 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut58
3
0 0
89 1
313 0
2
0 158 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut59
3
0 0
89 1
315 0
2
0 160 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut6
3
0 0
89 1
317 0
2
0 162 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut60
3
0 0
89 1
319 0
2
0 164 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut61
3
0 0
89 1
321 0
2
0 166 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut62
3
0 0
89 1
323 0
2
0 168 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut63
3
0 0
89 1
325 0
2
0 170 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut7
3
0 0
89 1
327 0
2
0 172 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut8
3
0 0
89 1
329 0
2
0 174 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner48 bob nut9
3
0 0
89 1
331 0
2
0 176 0 1
0 312 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut1
3
0 0
91 1
207 0
2
0 52 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut10
3
0 0
91 1
209 0
2
0 54 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut11
3
0 0
91 1
211 0
2
0 56 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut12
3
0 0
91 1
213 0
2
0 58 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut13
3
0 0
91 1
215 0
2
0 60 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut14
3
0 0
91 1
217 0
2
0 62 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut15
3
0 0
91 1
219 0
2
0 64 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut16
3
0 0
91 1
221 0
2
0 66 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut17
3
0 0
91 1
223 0
2
0 68 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut18
3
0 0
91 1
225 0
2
0 70 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut19
3
0 0
91 1
227 0
2
0 72 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut2
3
0 0
91 1
229 0
2
0 74 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut20
3
0 0
91 1
231 0
2
0 76 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut21
3
0 0
91 1
233 0
2
0 78 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut22
3
0 0
91 1
235 0
2
0 80 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut23
3
0 0
91 1
237 0
2
0 82 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut24
3
0 0
91 1
239 0
2
0 84 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut25
3
0 0
91 1
241 0
2
0 86 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut26
3
0 0
91 1
243 0
2
0 88 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut27
3
0 0
91 1
245 0
2
0 90 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut28
3
0 0
91 1
247 0
2
0 92 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut29
3
0 0
91 1
249 0
2
0 94 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut3
3
0 0
91 1
251 0
2
0 96 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut30
3
0 0
91 1
253 0
2
0 98 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut31
3
0 0
91 1
255 0
2
0 100 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut32
3
0 0
91 1
257 0
2
0 102 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut33
3
0 0
91 1
259 0
2
0 104 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut34
3
0 0
91 1
261 0
2
0 106 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut35
3
0 0
91 1
263 0
2
0 108 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut36
3
0 0
91 1
265 0
2
0 110 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut37
3
0 0
91 1
267 0
2
0 112 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut38
3
0 0
91 1
269 0
2
0 114 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut39
3
0 0
91 1
271 0
2
0 116 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut4
3
0 0
91 1
273 0
2
0 118 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut40
3
0 0
91 1
275 0
2
0 120 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut41
3
0 0
91 1
277 0
2
0 122 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut42
3
0 0
91 1
279 0
2
0 124 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut43
3
0 0
91 1
281 0
2
0 126 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut44
3
0 0
91 1
283 0
2
0 128 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut45
3
0 0
91 1
285 0
2
0 130 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut46
3
0 0
91 1
287 0
2
0 132 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut47
3
0 0
91 1
289 0
2
0 134 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut48
3
0 0
91 1
291 0
2
0 136 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut49
3
0 0
91 1
293 0
2
0 138 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut5
3
0 0
91 1
295 0
2
0 140 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut50
3
0 0
91 1
297 0
2
0 142 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut51
3
0 0
91 1
299 0
2
0 144 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut52
3
0 0
91 1
301 0
2
0 146 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut53
3
0 0
91 1
303 0
2
0 148 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut54
3
0 0
91 1
305 0
2
0 150 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut55
3
0 0
91 1
307 0
2
0 152 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut56
3
0 0
91 1
309 0
2
0 154 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut57
3
0 0
91 1
311 0
2
0 156 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut58
3
0 0
91 1
313 0
2
0 158 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut59
3
0 0
91 1
315 0
2
0 160 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut6
3
0 0
91 1
317 0
2
0 162 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut60
3
0 0
91 1
319 0
2
0 164 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut61
3
0 0
91 1
321 0
2
0 166 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut62
3
0 0
91 1
323 0
2
0 168 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut63
3
0 0
91 1
325 0
2
0 170 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut7
3
0 0
91 1
327 0
2
0 172 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut8
3
0 0
91 1
329 0
2
0 174 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner49 bob nut9
3
0 0
91 1
331 0
2
0 176 0 1
0 314 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut1
3
0 0
93 1
207 0
2
0 52 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut10
3
0 0
93 1
209 0
2
0 54 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut11
3
0 0
93 1
211 0
2
0 56 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut12
3
0 0
93 1
213 0
2
0 58 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut13
3
0 0
93 1
215 0
2
0 60 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut14
3
0 0
93 1
217 0
2
0 62 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut15
3
0 0
93 1
219 0
2
0 64 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut16
3
0 0
93 1
221 0
2
0 66 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut17
3
0 0
93 1
223 0
2
0 68 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut18
3
0 0
93 1
225 0
2
0 70 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut19
3
0 0
93 1
227 0
2
0 72 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut2
3
0 0
93 1
229 0
2
0 74 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut20
3
0 0
93 1
231 0
2
0 76 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut21
3
0 0
93 1
233 0
2
0 78 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut22
3
0 0
93 1
235 0
2
0 80 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut23
3
0 0
93 1
237 0
2
0 82 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut24
3
0 0
93 1
239 0
2
0 84 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut25
3
0 0
93 1
241 0
2
0 86 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut26
3
0 0
93 1
243 0
2
0 88 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut27
3
0 0
93 1
245 0
2
0 90 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut28
3
0 0
93 1
247 0
2
0 92 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut29
3
0 0
93 1
249 0
2
0 94 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut3
3
0 0
93 1
251 0
2
0 96 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut30
3
0 0
93 1
253 0
2
0 98 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut31
3
0 0
93 1
255 0
2
0 100 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut32
3
0 0
93 1
257 0
2
0 102 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut33
3
0 0
93 1
259 0
2
0 104 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut34
3
0 0
93 1
261 0
2
0 106 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut35
3
0 0
93 1
263 0
2
0 108 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut36
3
0 0
93 1
265 0
2
0 110 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut37
3
0 0
93 1
267 0
2
0 112 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut38
3
0 0
93 1
269 0
2
0 114 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut39
3
0 0
93 1
271 0
2
0 116 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut4
3
0 0
93 1
273 0
2
0 118 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut40
3
0 0
93 1
275 0
2
0 120 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut41
3
0 0
93 1
277 0
2
0 122 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut42
3
0 0
93 1
279 0
2
0 124 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut43
3
0 0
93 1
281 0
2
0 126 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut44
3
0 0
93 1
283 0
2
0 128 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut45
3
0 0
93 1
285 0
2
0 130 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut46
3
0 0
93 1
287 0
2
0 132 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut47
3
0 0
93 1
289 0
2
0 134 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut48
3
0 0
93 1
291 0
2
0 136 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut49
3
0 0
93 1
293 0
2
0 138 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut5
3
0 0
93 1
295 0
2
0 140 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut50
3
0 0
93 1
297 0
2
0 142 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut51
3
0 0
93 1
299 0
2
0 144 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut52
3
0 0
93 1
301 0
2
0 146 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut53
3
0 0
93 1
303 0
2
0 148 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut54
3
0 0
93 1
305 0
2
0 150 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut55
3
0 0
93 1
307 0
2
0 152 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut56
3
0 0
93 1
309 0
2
0 154 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut57
3
0 0
93 1
311 0
2
0 156 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut58
3
0 0
93 1
313 0
2
0 158 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut59
3
0 0
93 1
315 0
2
0 160 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut6
3
0 0
93 1
317 0
2
0 162 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut60
3
0 0
93 1
319 0
2
0 164 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut61
3
0 0
93 1
321 0
2
0 166 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut62
3
0 0
93 1
323 0
2
0 168 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut63
3
0 0
93 1
325 0
2
0 170 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut7
3
0 0
93 1
327 0
2
0 172 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut8
3
0 0
93 1
329 0
2
0 174 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner5 bob nut9
3
0 0
93 1
331 0
2
0 176 0 1
0 316 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut1
3
0 0
95 1
207 0
2
0 52 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut10
3
0 0
95 1
209 0
2
0 54 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut11
3
0 0
95 1
211 0
2
0 56 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut12
3
0 0
95 1
213 0
2
0 58 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut13
3
0 0
95 1
215 0
2
0 60 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut14
3
0 0
95 1
217 0
2
0 62 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut15
3
0 0
95 1
219 0
2
0 64 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut16
3
0 0
95 1
221 0
2
0 66 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut17
3
0 0
95 1
223 0
2
0 68 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut18
3
0 0
95 1
225 0
2
0 70 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut19
3
0 0
95 1
227 0
2
0 72 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut2
3
0 0
95 1
229 0
2
0 74 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut20
3
0 0
95 1
231 0
2
0 76 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut21
3
0 0
95 1
233 0
2
0 78 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut22
3
0 0
95 1
235 0
2
0 80 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut23
3
0 0
95 1
237 0
2
0 82 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut24
3
0 0
95 1
239 0
2
0 84 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut25
3
0 0
95 1
241 0
2
0 86 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut26
3
0 0
95 1
243 0
2
0 88 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut27
3
0 0
95 1
245 0
2
0 90 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut28
3
0 0
95 1
247 0
2
0 92 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut29
3
0 0
95 1
249 0
2
0 94 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut3
3
0 0
95 1
251 0
2
0 96 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut30
3
0 0
95 1
253 0
2
0 98 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut31
3
0 0
95 1
255 0
2
0 100 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut32
3
0 0
95 1
257 0
2
0 102 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut33
3
0 0
95 1
259 0
2
0 104 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut34
3
0 0
95 1
261 0
2
0 106 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut35
3
0 0
95 1
263 0
2
0 108 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut36
3
0 0
95 1
265 0
2
0 110 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut37
3
0 0
95 1
267 0
2
0 112 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut38
3
0 0
95 1
269 0
2
0 114 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut39
3
0 0
95 1
271 0
2
0 116 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut4
3
0 0
95 1
273 0
2
0 118 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut40
3
0 0
95 1
275 0
2
0 120 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut41
3
0 0
95 1
277 0
2
0 122 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut42
3
0 0
95 1
279 0
2
0 124 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut43
3
0 0
95 1
281 0
2
0 126 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut44
3
0 0
95 1
283 0
2
0 128 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut45
3
0 0
95 1
285 0
2
0 130 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut46
3
0 0
95 1
287 0
2
0 132 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut47
3
0 0
95 1
289 0
2
0 134 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut48
3
0 0
95 1
291 0
2
0 136 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut49
3
0 0
95 1
293 0
2
0 138 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut5
3
0 0
95 1
295 0
2
0 140 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut50
3
0 0
95 1
297 0
2
0 142 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut51
3
0 0
95 1
299 0
2
0 144 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut52
3
0 0
95 1
301 0
2
0 146 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut53
3
0 0
95 1
303 0
2
0 148 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut54
3
0 0
95 1
305 0
2
0 150 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut55
3
0 0
95 1
307 0
2
0 152 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut56
3
0 0
95 1
309 0
2
0 154 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut57
3
0 0
95 1
311 0
2
0 156 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut58
3
0 0
95 1
313 0
2
0 158 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut59
3
0 0
95 1
315 0
2
0 160 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut6
3
0 0
95 1
317 0
2
0 162 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut60
3
0 0
95 1
319 0
2
0 164 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut61
3
0 0
95 1
321 0
2
0 166 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut62
3
0 0
95 1
323 0
2
0 168 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut63
3
0 0
95 1
325 0
2
0 170 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut7
3
0 0
95 1
327 0
2
0 172 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut8
3
0 0
95 1
329 0
2
0 174 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner50 bob nut9
3
0 0
95 1
331 0
2
0 176 0 1
0 318 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut1
3
0 0
97 1
207 0
2
0 52 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut10
3
0 0
97 1
209 0
2
0 54 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut11
3
0 0
97 1
211 0
2
0 56 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut12
3
0 0
97 1
213 0
2
0 58 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut13
3
0 0
97 1
215 0
2
0 60 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut14
3
0 0
97 1
217 0
2
0 62 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut15
3
0 0
97 1
219 0
2
0 64 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut16
3
0 0
97 1
221 0
2
0 66 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut17
3
0 0
97 1
223 0
2
0 68 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut18
3
0 0
97 1
225 0
2
0 70 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut19
3
0 0
97 1
227 0
2
0 72 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut2
3
0 0
97 1
229 0
2
0 74 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut20
3
0 0
97 1
231 0
2
0 76 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut21
3
0 0
97 1
233 0
2
0 78 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut22
3
0 0
97 1
235 0
2
0 80 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut23
3
0 0
97 1
237 0
2
0 82 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut24
3
0 0
97 1
239 0
2
0 84 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut25
3
0 0
97 1
241 0
2
0 86 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut26
3
0 0
97 1
243 0
2
0 88 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut27
3
0 0
97 1
245 0
2
0 90 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut28
3
0 0
97 1
247 0
2
0 92 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut29
3
0 0
97 1
249 0
2
0 94 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut3
3
0 0
97 1
251 0
2
0 96 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut30
3
0 0
97 1
253 0
2
0 98 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut31
3
0 0
97 1
255 0
2
0 100 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut32
3
0 0
97 1
257 0
2
0 102 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut33
3
0 0
97 1
259 0
2
0 104 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut34
3
0 0
97 1
261 0
2
0 106 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut35
3
0 0
97 1
263 0
2
0 108 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut36
3
0 0
97 1
265 0
2
0 110 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut37
3
0 0
97 1
267 0
2
0 112 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut38
3
0 0
97 1
269 0
2
0 114 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut39
3
0 0
97 1
271 0
2
0 116 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut4
3
0 0
97 1
273 0
2
0 118 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut40
3
0 0
97 1
275 0
2
0 120 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut41
3
0 0
97 1
277 0
2
0 122 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut42
3
0 0
97 1
279 0
2
0 124 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut43
3
0 0
97 1
281 0
2
0 126 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut44
3
0 0
97 1
283 0
2
0 128 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut45
3
0 0
97 1
285 0
2
0 130 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut46
3
0 0
97 1
287 0
2
0 132 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut47
3
0 0
97 1
289 0
2
0 134 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut48
3
0 0
97 1
291 0
2
0 136 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut49
3
0 0
97 1
293 0
2
0 138 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut5
3
0 0
97 1
295 0
2
0 140 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut50
3
0 0
97 1
297 0
2
0 142 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut51
3
0 0
97 1
299 0
2
0 144 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut52
3
0 0
97 1
301 0
2
0 146 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut53
3
0 0
97 1
303 0
2
0 148 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut54
3
0 0
97 1
305 0
2
0 150 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut55
3
0 0
97 1
307 0
2
0 152 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut56
3
0 0
97 1
309 0
2
0 154 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut57
3
0 0
97 1
311 0
2
0 156 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut58
3
0 0
97 1
313 0
2
0 158 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut59
3
0 0
97 1
315 0
2
0 160 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut6
3
0 0
97 1
317 0
2
0 162 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut60
3
0 0
97 1
319 0
2
0 164 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut61
3
0 0
97 1
321 0
2
0 166 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut62
3
0 0
97 1
323 0
2
0 168 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut63
3
0 0
97 1
325 0
2
0 170 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut7
3
0 0
97 1
327 0
2
0 172 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut8
3
0 0
97 1
329 0
2
0 174 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner51 bob nut9
3
0 0
97 1
331 0
2
0 176 0 1
0 320 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut1
3
0 0
99 1
207 0
2
0 52 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut10
3
0 0
99 1
209 0
2
0 54 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut11
3
0 0
99 1
211 0
2
0 56 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut12
3
0 0
99 1
213 0
2
0 58 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut13
3
0 0
99 1
215 0
2
0 60 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut14
3
0 0
99 1
217 0
2
0 62 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut15
3
0 0
99 1
219 0
2
0 64 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut16
3
0 0
99 1
221 0
2
0 66 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut17
3
0 0
99 1
223 0
2
0 68 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut18
3
0 0
99 1
225 0
2
0 70 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut19
3
0 0
99 1
227 0
2
0 72 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut2
3
0 0
99 1
229 0
2
0 74 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut20
3
0 0
99 1
231 0
2
0 76 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut21
3
0 0
99 1
233 0
2
0 78 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut22
3
0 0
99 1
235 0
2
0 80 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut23
3
0 0
99 1
237 0
2
0 82 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut24
3
0 0
99 1
239 0
2
0 84 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut25
3
0 0
99 1
241 0
2
0 86 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut26
3
0 0
99 1
243 0
2
0 88 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut27
3
0 0
99 1
245 0
2
0 90 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut28
3
0 0
99 1
247 0
2
0 92 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut29
3
0 0
99 1
249 0
2
0 94 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut3
3
0 0
99 1
251 0
2
0 96 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut30
3
0 0
99 1
253 0
2
0 98 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut31
3
0 0
99 1
255 0
2
0 100 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut32
3
0 0
99 1
257 0
2
0 102 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut33
3
0 0
99 1
259 0
2
0 104 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut34
3
0 0
99 1
261 0
2
0 106 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut35
3
0 0
99 1
263 0
2
0 108 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut36
3
0 0
99 1
265 0
2
0 110 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut37
3
0 0
99 1
267 0
2
0 112 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut38
3
0 0
99 1
269 0
2
0 114 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut39
3
0 0
99 1
271 0
2
0 116 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut4
3
0 0
99 1
273 0
2
0 118 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut40
3
0 0
99 1
275 0
2
0 120 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut41
3
0 0
99 1
277 0
2
0 122 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut42
3
0 0
99 1
279 0
2
0 124 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut43
3
0 0
99 1
281 0
2
0 126 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut44
3
0 0
99 1
283 0
2
0 128 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut45
3
0 0
99 1
285 0
2
0 130 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut46
3
0 0
99 1
287 0
2
0 132 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut47
3
0 0
99 1
289 0
2
0 134 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut48
3
0 0
99 1
291 0
2
0 136 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut49
3
0 0
99 1
293 0
2
0 138 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut5
3
0 0
99 1
295 0
2
0 140 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut50
3
0 0
99 1
297 0
2
0 142 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut51
3
0 0
99 1
299 0
2
0 144 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut52
3
0 0
99 1
301 0
2
0 146 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut53
3
0 0
99 1
303 0
2
0 148 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut54
3
0 0
99 1
305 0
2
0 150 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut55
3
0 0
99 1
307 0
2
0 152 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut56
3
0 0
99 1
309 0
2
0 154 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut57
3
0 0
99 1
311 0
2
0 156 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut58
3
0 0
99 1
313 0
2
0 158 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut59
3
0 0
99 1
315 0
2
0 160 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut6
3
0 0
99 1
317 0
2
0 162 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut60
3
0 0
99 1
319 0
2
0 164 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut61
3
0 0
99 1
321 0
2
0 166 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut62
3
0 0
99 1
323 0
2
0 168 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut63
3
0 0
99 1
325 0
2
0 170 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut7
3
0 0
99 1
327 0
2
0 172 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut8
3
0 0
99 1
329 0
2
0 174 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner52 bob nut9
3
0 0
99 1
331 0
2
0 176 0 1
0 322 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut1
3
0 0
101 1
207 0
2
0 52 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut10
3
0 0
101 1
209 0
2
0 54 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut11
3
0 0
101 1
211 0
2
0 56 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut12
3
0 0
101 1
213 0
2
0 58 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut13
3
0 0
101 1
215 0
2
0 60 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut14
3
0 0
101 1
217 0
2
0 62 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut15
3
0 0
101 1
219 0
2
0 64 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut16
3
0 0
101 1
221 0
2
0 66 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut17
3
0 0
101 1
223 0
2
0 68 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut18
3
0 0
101 1
225 0
2
0 70 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut19
3
0 0
101 1
227 0
2
0 72 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut2
3
0 0
101 1
229 0
2
0 74 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut20
3
0 0
101 1
231 0
2
0 76 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut21
3
0 0
101 1
233 0
2
0 78 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut22
3
0 0
101 1
235 0
2
0 80 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut23
3
0 0
101 1
237 0
2
0 82 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut24
3
0 0
101 1
239 0
2
0 84 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut25
3
0 0
101 1
241 0
2
0 86 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut26
3
0 0
101 1
243 0
2
0 88 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut27
3
0 0
101 1
245 0
2
0 90 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut28
3
0 0
101 1
247 0
2
0 92 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut29
3
0 0
101 1
249 0
2
0 94 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut3
3
0 0
101 1
251 0
2
0 96 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut30
3
0 0
101 1
253 0
2
0 98 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut31
3
0 0
101 1
255 0
2
0 100 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut32
3
0 0
101 1
257 0
2
0 102 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut33
3
0 0
101 1
259 0
2
0 104 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut34
3
0 0
101 1
261 0
2
0 106 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut35
3
0 0
101 1
263 0
2
0 108 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut36
3
0 0
101 1
265 0
2
0 110 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut37
3
0 0
101 1
267 0
2
0 112 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut38
3
0 0
101 1
269 0
2
0 114 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut39
3
0 0
101 1
271 0
2
0 116 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut4
3
0 0
101 1
273 0
2
0 118 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut40
3
0 0
101 1
275 0
2
0 120 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut41
3
0 0
101 1
277 0
2
0 122 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut42
3
0 0
101 1
279 0
2
0 124 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut43
3
0 0
101 1
281 0
2
0 126 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut44
3
0 0
101 1
283 0
2
0 128 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut45
3
0 0
101 1
285 0
2
0 130 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut46
3
0 0
101 1
287 0
2
0 132 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut47
3
0 0
101 1
289 0
2
0 134 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut48
3
0 0
101 1
291 0
2
0 136 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut49
3
0 0
101 1
293 0
2
0 138 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut5
3
0 0
101 1
295 0
2
0 140 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut50
3
0 0
101 1
297 0
2
0 142 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut51
3
0 0
101 1
299 0
2
0 144 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut52
3
0 0
101 1
301 0
2
0 146 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut53
3
0 0
101 1
303 0
2
0 148 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut54
3
0 0
101 1
305 0
2
0 150 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut55
3
0 0
101 1
307 0
2
0 152 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut56
3
0 0
101 1
309 0
2
0 154 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut57
3
0 0
101 1
311 0
2
0 156 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut58
3
0 0
101 1
313 0
2
0 158 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut59
3
0 0
101 1
315 0
2
0 160 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut6
3
0 0
101 1
317 0
2
0 162 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut60
3
0 0
101 1
319 0
2
0 164 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut61
3
0 0
101 1
321 0
2
0 166 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut62
3
0 0
101 1
323 0
2
0 168 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut63
3
0 0
101 1
325 0
2
0 170 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut7
3
0 0
101 1
327 0
2
0 172 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut8
3
0 0
101 1
329 0
2
0 174 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner53 bob nut9
3
0 0
101 1
331 0
2
0 176 0 1
0 324 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut1
3
0 0
103 1
207 0
2
0 52 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut10
3
0 0
103 1
209 0
2
0 54 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut11
3
0 0
103 1
211 0
2
0 56 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut12
3
0 0
103 1
213 0
2
0 58 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut13
3
0 0
103 1
215 0
2
0 60 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut14
3
0 0
103 1
217 0
2
0 62 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut15
3
0 0
103 1
219 0
2
0 64 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut16
3
0 0
103 1
221 0
2
0 66 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut17
3
0 0
103 1
223 0
2
0 68 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut18
3
0 0
103 1
225 0
2
0 70 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut19
3
0 0
103 1
227 0
2
0 72 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut2
3
0 0
103 1
229 0
2
0 74 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut20
3
0 0
103 1
231 0
2
0 76 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut21
3
0 0
103 1
233 0
2
0 78 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut22
3
0 0
103 1
235 0
2
0 80 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut23
3
0 0
103 1
237 0
2
0 82 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut24
3
0 0
103 1
239 0
2
0 84 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut25
3
0 0
103 1
241 0
2
0 86 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut26
3
0 0
103 1
243 0
2
0 88 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut27
3
0 0
103 1
245 0
2
0 90 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut28
3
0 0
103 1
247 0
2
0 92 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut29
3
0 0
103 1
249 0
2
0 94 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut3
3
0 0
103 1
251 0
2
0 96 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut30
3
0 0
103 1
253 0
2
0 98 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut31
3
0 0
103 1
255 0
2
0 100 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut32
3
0 0
103 1
257 0
2
0 102 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut33
3
0 0
103 1
259 0
2
0 104 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut34
3
0 0
103 1
261 0
2
0 106 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut35
3
0 0
103 1
263 0
2
0 108 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut36
3
0 0
103 1
265 0
2
0 110 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut37
3
0 0
103 1
267 0
2
0 112 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut38
3
0 0
103 1
269 0
2
0 114 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut39
3
0 0
103 1
271 0
2
0 116 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut4
3
0 0
103 1
273 0
2
0 118 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut40
3
0 0
103 1
275 0
2
0 120 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut41
3
0 0
103 1
277 0
2
0 122 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut42
3
0 0
103 1
279 0
2
0 124 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut43
3
0 0
103 1
281 0
2
0 126 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut44
3
0 0
103 1
283 0
2
0 128 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut45
3
0 0
103 1
285 0
2
0 130 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut46
3
0 0
103 1
287 0
2
0 132 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut47
3
0 0
103 1
289 0
2
0 134 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut48
3
0 0
103 1
291 0
2
0 136 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut49
3
0 0
103 1
293 0
2
0 138 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut5
3
0 0
103 1
295 0
2
0 140 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut50
3
0 0
103 1
297 0
2
0 142 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut51
3
0 0
103 1
299 0
2
0 144 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut52
3
0 0
103 1
301 0
2
0 146 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut53
3
0 0
103 1
303 0
2
0 148 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut54
3
0 0
103 1
305 0
2
0 150 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut55
3
0 0
103 1
307 0
2
0 152 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut56
3
0 0
103 1
309 0
2
0 154 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut57
3
0 0
103 1
311 0
2
0 156 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut58
3
0 0
103 1
313 0
2
0 158 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut59
3
0 0
103 1
315 0
2
0 160 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut6
3
0 0
103 1
317 0
2
0 162 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut60
3
0 0
103 1
319 0
2
0 164 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut61
3
0 0
103 1
321 0
2
0 166 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut62
3
0 0
103 1
323 0
2
0 168 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut63
3
0 0
103 1
325 0
2
0 170 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut7
3
0 0
103 1
327 0
2
0 172 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut8
3
0 0
103 1
329 0
2
0 174 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner54 bob nut9
3
0 0
103 1
331 0
2
0 176 0 1
0 326 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut1
3
0 0
105 1
207 0
2
0 52 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut10
3
0 0
105 1
209 0
2
0 54 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut11
3
0 0
105 1
211 0
2
0 56 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut12
3
0 0
105 1
213 0
2
0 58 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut13
3
0 0
105 1
215 0
2
0 60 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut14
3
0 0
105 1
217 0
2
0 62 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut15
3
0 0
105 1
219 0
2
0 64 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut16
3
0 0
105 1
221 0
2
0 66 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut17
3
0 0
105 1
223 0
2
0 68 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut18
3
0 0
105 1
225 0
2
0 70 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut19
3
0 0
105 1
227 0
2
0 72 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut2
3
0 0
105 1
229 0
2
0 74 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut20
3
0 0
105 1
231 0
2
0 76 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut21
3
0 0
105 1
233 0
2
0 78 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut22
3
0 0
105 1
235 0
2
0 80 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut23
3
0 0
105 1
237 0
2
0 82 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut24
3
0 0
105 1
239 0
2
0 84 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut25
3
0 0
105 1
241 0
2
0 86 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut26
3
0 0
105 1
243 0
2
0 88 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut27
3
0 0
105 1
245 0
2
0 90 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut28
3
0 0
105 1
247 0
2
0 92 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut29
3
0 0
105 1
249 0
2
0 94 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut3
3
0 0
105 1
251 0
2
0 96 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut30
3
0 0
105 1
253 0
2
0 98 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut31
3
0 0
105 1
255 0
2
0 100 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut32
3
0 0
105 1
257 0
2
0 102 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut33
3
0 0
105 1
259 0
2
0 104 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut34
3
0 0
105 1
261 0
2
0 106 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut35
3
0 0
105 1
263 0
2
0 108 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut36
3
0 0
105 1
265 0
2
0 110 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut37
3
0 0
105 1
267 0
2
0 112 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut38
3
0 0
105 1
269 0
2
0 114 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut39
3
0 0
105 1
271 0
2
0 116 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut4
3
0 0
105 1
273 0
2
0 118 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut40
3
0 0
105 1
275 0
2
0 120 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut41
3
0 0
105 1
277 0
2
0 122 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut42
3
0 0
105 1
279 0
2
0 124 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut43
3
0 0
105 1
281 0
2
0 126 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut44
3
0 0
105 1
283 0
2
0 128 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut45
3
0 0
105 1
285 0
2
0 130 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut46
3
0 0
105 1
287 0
2
0 132 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut47
3
0 0
105 1
289 0
2
0 134 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut48
3
0 0
105 1
291 0
2
0 136 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut49
3
0 0
105 1
293 0
2
0 138 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut5
3
0 0
105 1
295 0
2
0 140 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut50
3
0 0
105 1
297 0
2
0 142 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut51
3
0 0
105 1
299 0
2
0 144 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut52
3
0 0
105 1
301 0
2
0 146 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut53
3
0 0
105 1
303 0
2
0 148 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut54
3
0 0
105 1
305 0
2
0 150 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut55
3
0 0
105 1
307 0
2
0 152 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut56
3
0 0
105 1
309 0
2
0 154 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut57
3
0 0
105 1
311 0
2
0 156 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut58
3
0 0
105 1
313 0
2
0 158 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut59
3
0 0
105 1
315 0
2
0 160 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut6
3
0 0
105 1
317 0
2
0 162 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut60
3
0 0
105 1
319 0
2
0 164 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut61
3
0 0
105 1
321 0
2
0 166 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut62
3
0 0
105 1
323 0
2
0 168 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut63
3
0 0
105 1
325 0
2
0 170 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut7
3
0 0
105 1
327 0
2
0 172 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut8
3
0 0
105 1
329 0
2
0 174 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner55 bob nut9
3
0 0
105 1
331 0
2
0 176 0 1
0 328 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut1
3
0 0
107 1
207 0
2
0 52 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut10
3
0 0
107 1
209 0
2
0 54 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut11
3
0 0
107 1
211 0
2
0 56 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut12
3
0 0
107 1
213 0
2
0 58 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut13
3
0 0
107 1
215 0
2
0 60 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut14
3
0 0
107 1
217 0
2
0 62 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut15
3
0 0
107 1
219 0
2
0 64 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut16
3
0 0
107 1
221 0
2
0 66 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut17
3
0 0
107 1
223 0
2
0 68 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut18
3
0 0
107 1
225 0
2
0 70 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut19
3
0 0
107 1
227 0
2
0 72 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut2
3
0 0
107 1
229 0
2
0 74 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut20
3
0 0
107 1
231 0
2
0 76 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut21
3
0 0
107 1
233 0
2
0 78 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut22
3
0 0
107 1
235 0
2
0 80 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut23
3
0 0
107 1
237 0
2
0 82 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut24
3
0 0
107 1
239 0
2
0 84 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut25
3
0 0
107 1
241 0
2
0 86 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut26
3
0 0
107 1
243 0
2
0 88 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut27
3
0 0
107 1
245 0
2
0 90 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut28
3
0 0
107 1
247 0
2
0 92 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut29
3
0 0
107 1
249 0
2
0 94 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut3
3
0 0
107 1
251 0
2
0 96 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut30
3
0 0
107 1
253 0
2
0 98 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut31
3
0 0
107 1
255 0
2
0 100 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut32
3
0 0
107 1
257 0
2
0 102 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut33
3
0 0
107 1
259 0
2
0 104 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut34
3
0 0
107 1
261 0
2
0 106 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut35
3
0 0
107 1
263 0
2
0 108 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut36
3
0 0
107 1
265 0
2
0 110 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut37
3
0 0
107 1
267 0
2
0 112 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut38
3
0 0
107 1
269 0
2
0 114 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut39
3
0 0
107 1
271 0
2
0 116 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut4
3
0 0
107 1
273 0
2
0 118 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut40
3
0 0
107 1
275 0
2
0 120 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut41
3
0 0
107 1
277 0
2
0 122 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut42
3
0 0
107 1
279 0
2
0 124 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut43
3
0 0
107 1
281 0
2
0 126 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut44
3
0 0
107 1
283 0
2
0 128 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut45
3
0 0
107 1
285 0
2
0 130 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut46
3
0 0
107 1
287 0
2
0 132 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut47
3
0 0
107 1
289 0
2
0 134 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut48
3
0 0
107 1
291 0
2
0 136 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut49
3
0 0
107 1
293 0
2
0 138 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut5
3
0 0
107 1
295 0
2
0 140 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut50
3
0 0
107 1
297 0
2
0 142 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut51
3
0 0
107 1
299 0
2
0 144 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut52
3
0 0
107 1
301 0
2
0 146 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut53
3
0 0
107 1
303 0
2
0 148 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut54
3
0 0
107 1
305 0
2
0 150 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut55
3
0 0
107 1
307 0
2
0 152 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut56
3
0 0
107 1
309 0
2
0 154 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut57
3
0 0
107 1
311 0
2
0 156 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut58
3
0 0
107 1
313 0
2
0 158 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut59
3
0 0
107 1
315 0
2
0 160 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut6
3
0 0
107 1
317 0
2
0 162 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut60
3
0 0
107 1
319 0
2
0 164 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut61
3
0 0
107 1
321 0
2
0 166 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut62
3
0 0
107 1
323 0
2
0 168 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut63
3
0 0
107 1
325 0
2
0 170 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut7
3
0 0
107 1
327 0
2
0 172 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut8
3
0 0
107 1
329 0
2
0 174 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner56 bob nut9
3
0 0
107 1
331 0
2
0 176 0 1
0 330 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut1
3
0 0
109 1
207 0
2
0 52 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut10
3
0 0
109 1
209 0
2
0 54 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut11
3
0 0
109 1
211 0
2
0 56 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut12
3
0 0
109 1
213 0
2
0 58 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut13
3
0 0
109 1
215 0
2
0 60 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut14
3
0 0
109 1
217 0
2
0 62 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut15
3
0 0
109 1
219 0
2
0 64 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut16
3
0 0
109 1
221 0
2
0 66 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut17
3
0 0
109 1
223 0
2
0 68 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut18
3
0 0
109 1
225 0
2
0 70 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut19
3
0 0
109 1
227 0
2
0 72 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut2
3
0 0
109 1
229 0
2
0 74 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut20
3
0 0
109 1
231 0
2
0 76 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut21
3
0 0
109 1
233 0
2
0 78 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut22
3
0 0
109 1
235 0
2
0 80 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut23
3
0 0
109 1
237 0
2
0 82 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut24
3
0 0
109 1
239 0
2
0 84 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut25
3
0 0
109 1
241 0
2
0 86 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut26
3
0 0
109 1
243 0
2
0 88 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut27
3
0 0
109 1
245 0
2
0 90 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut28
3
0 0
109 1
247 0
2
0 92 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut29
3
0 0
109 1
249 0
2
0 94 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut3
3
0 0
109 1
251 0
2
0 96 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut30
3
0 0
109 1
253 0
2
0 98 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut31
3
0 0
109 1
255 0
2
0 100 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut32
3
0 0
109 1
257 0
2
0 102 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut33
3
0 0
109 1
259 0
2
0 104 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut34
3
0 0
109 1
261 0
2
0 106 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut35
3
0 0
109 1
263 0
2
0 108 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut36
3
0 0
109 1
265 0
2
0 110 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut37
3
0 0
109 1
267 0
2
0 112 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut38
3
0 0
109 1
269 0
2
0 114 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut39
3
0 0
109 1
271 0
2
0 116 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut4
3
0 0
109 1
273 0
2
0 118 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut40
3
0 0
109 1
275 0
2
0 120 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut41
3
0 0
109 1
277 0
2
0 122 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut42
3
0 0
109 1
279 0
2
0 124 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut43
3
0 0
109 1
281 0
2
0 126 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut44
3
0 0
109 1
283 0
2
0 128 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut45
3
0 0
109 1
285 0
2
0 130 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut46
3
0 0
109 1
287 0
2
0 132 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut47
3
0 0
109 1
289 0
2
0 134 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut48
3
0 0
109 1
291 0
2
0 136 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut49
3
0 0
109 1
293 0
2
0 138 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut5
3
0 0
109 1
295 0
2
0 140 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut50
3
0 0
109 1
297 0
2
0 142 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut51
3
0 0
109 1
299 0
2
0 144 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut52
3
0 0
109 1
301 0
2
0 146 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut53
3
0 0
109 1
303 0
2
0 148 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut54
3
0 0
109 1
305 0
2
0 150 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut55
3
0 0
109 1
307 0
2
0 152 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut56
3
0 0
109 1
309 0
2
0 154 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut57
3
0 0
109 1
311 0
2
0 156 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut58
3
0 0
109 1
313 0
2
0 158 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut59
3
0 0
109 1
315 0
2
0 160 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut6
3
0 0
109 1
317 0
2
0 162 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut60
3
0 0
109 1
319 0
2
0 164 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut61
3
0 0
109 1
321 0
2
0 166 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut62
3
0 0
109 1
323 0
2
0 168 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut63
3
0 0
109 1
325 0
2
0 170 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut7
3
0 0
109 1
327 0
2
0 172 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut8
3
0 0
109 1
329 0
2
0 174 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner57 bob nut9
3
0 0
109 1
331 0
2
0 176 0 1
0 332 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut1
3
0 0
111 1
207 0
2
0 52 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut10
3
0 0
111 1
209 0
2
0 54 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut11
3
0 0
111 1
211 0
2
0 56 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut12
3
0 0
111 1
213 0
2
0 58 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut13
3
0 0
111 1
215 0
2
0 60 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut14
3
0 0
111 1
217 0
2
0 62 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut15
3
0 0
111 1
219 0
2
0 64 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut16
3
0 0
111 1
221 0
2
0 66 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut17
3
0 0
111 1
223 0
2
0 68 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut18
3
0 0
111 1
225 0
2
0 70 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut19
3
0 0
111 1
227 0
2
0 72 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut2
3
0 0
111 1
229 0
2
0 74 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut20
3
0 0
111 1
231 0
2
0 76 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut21
3
0 0
111 1
233 0
2
0 78 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut22
3
0 0
111 1
235 0
2
0 80 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut23
3
0 0
111 1
237 0
2
0 82 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut24
3
0 0
111 1
239 0
2
0 84 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut25
3
0 0
111 1
241 0
2
0 86 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut26
3
0 0
111 1
243 0
2
0 88 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut27
3
0 0
111 1
245 0
2
0 90 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut28
3
0 0
111 1
247 0
2
0 92 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut29
3
0 0
111 1
249 0
2
0 94 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut3
3
0 0
111 1
251 0
2
0 96 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut30
3
0 0
111 1
253 0
2
0 98 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut31
3
0 0
111 1
255 0
2
0 100 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut32
3
0 0
111 1
257 0
2
0 102 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut33
3
0 0
111 1
259 0
2
0 104 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut34
3
0 0
111 1
261 0
2
0 106 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut35
3
0 0
111 1
263 0
2
0 108 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut36
3
0 0
111 1
265 0
2
0 110 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut37
3
0 0
111 1
267 0
2
0 112 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut38
3
0 0
111 1
269 0
2
0 114 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut39
3
0 0
111 1
271 0
2
0 116 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut4
3
0 0
111 1
273 0
2
0 118 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut40
3
0 0
111 1
275 0
2
0 120 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut41
3
0 0
111 1
277 0
2
0 122 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut42
3
0 0
111 1
279 0
2
0 124 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut43
3
0 0
111 1
281 0
2
0 126 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut44
3
0 0
111 1
283 0
2
0 128 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut45
3
0 0
111 1
285 0
2
0 130 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut46
3
0 0
111 1
287 0
2
0 132 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut47
3
0 0
111 1
289 0
2
0 134 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut48
3
0 0
111 1
291 0
2
0 136 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut49
3
0 0
111 1
293 0
2
0 138 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut5
3
0 0
111 1
295 0
2
0 140 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut50
3
0 0
111 1
297 0
2
0 142 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut51
3
0 0
111 1
299 0
2
0 144 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut52
3
0 0
111 1
301 0
2
0 146 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut53
3
0 0
111 1
303 0
2
0 148 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut54
3
0 0
111 1
305 0
2
0 150 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut55
3
0 0
111 1
307 0
2
0 152 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut56
3
0 0
111 1
309 0
2
0 154 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut57
3
0 0
111 1
311 0
2
0 156 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut58
3
0 0
111 1
313 0
2
0 158 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut59
3
0 0
111 1
315 0
2
0 160 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut6
3
0 0
111 1
317 0
2
0 162 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut60
3
0 0
111 1
319 0
2
0 164 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut61
3
0 0
111 1
321 0
2
0 166 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut62
3
0 0
111 1
323 0
2
0 168 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut63
3
0 0
111 1
325 0
2
0 170 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut7
3
0 0
111 1
327 0
2
0 172 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut8
3
0 0
111 1
329 0
2
0 174 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner58 bob nut9
3
0 0
111 1
331 0
2
0 176 0 1
0 333 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut1
3
0 0
113 1
207 0
2
0 52 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut10
3
0 0
113 1
209 0
2
0 54 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut11
3
0 0
113 1
211 0
2
0 56 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut12
3
0 0
113 1
213 0
2
0 58 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut13
3
0 0
113 1
215 0
2
0 60 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut14
3
0 0
113 1
217 0
2
0 62 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut15
3
0 0
113 1
219 0
2
0 64 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut16
3
0 0
113 1
221 0
2
0 66 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut17
3
0 0
113 1
223 0
2
0 68 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut18
3
0 0
113 1
225 0
2
0 70 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut19
3
0 0
113 1
227 0
2
0 72 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut2
3
0 0
113 1
229 0
2
0 74 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut20
3
0 0
113 1
231 0
2
0 76 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut21
3
0 0
113 1
233 0
2
0 78 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut22
3
0 0
113 1
235 0
2
0 80 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut23
3
0 0
113 1
237 0
2
0 82 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut24
3
0 0
113 1
239 0
2
0 84 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut25
3
0 0
113 1
241 0
2
0 86 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut26
3
0 0
113 1
243 0
2
0 88 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut27
3
0 0
113 1
245 0
2
0 90 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut28
3
0 0
113 1
247 0
2
0 92 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut29
3
0 0
113 1
249 0
2
0 94 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut3
3
0 0
113 1
251 0
2
0 96 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut30
3
0 0
113 1
253 0
2
0 98 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut31
3
0 0
113 1
255 0
2
0 100 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut32
3
0 0
113 1
257 0
2
0 102 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut33
3
0 0
113 1
259 0
2
0 104 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut34
3
0 0
113 1
261 0
2
0 106 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut35
3
0 0
113 1
263 0
2
0 108 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut36
3
0 0
113 1
265 0
2
0 110 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut37
3
0 0
113 1
267 0
2
0 112 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut38
3
0 0
113 1
269 0
2
0 114 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut39
3
0 0
113 1
271 0
2
0 116 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut4
3
0 0
113 1
273 0
2
0 118 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut40
3
0 0
113 1
275 0
2
0 120 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut41
3
0 0
113 1
277 0
2
0 122 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut42
3
0 0
113 1
279 0
2
0 124 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut43
3
0 0
113 1
281 0
2
0 126 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut44
3
0 0
113 1
283 0
2
0 128 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut45
3
0 0
113 1
285 0
2
0 130 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut46
3
0 0
113 1
287 0
2
0 132 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut47
3
0 0
113 1
289 0
2
0 134 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut48
3
0 0
113 1
291 0
2
0 136 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut49
3
0 0
113 1
293 0
2
0 138 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut5
3
0 0
113 1
295 0
2
0 140 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut50
3
0 0
113 1
297 0
2
0 142 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut51
3
0 0
113 1
299 0
2
0 144 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut52
3
0 0
113 1
301 0
2
0 146 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut53
3
0 0
113 1
303 0
2
0 148 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut54
3
0 0
113 1
305 0
2
0 150 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut55
3
0 0
113 1
307 0
2
0 152 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut56
3
0 0
113 1
309 0
2
0 154 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut57
3
0 0
113 1
311 0
2
0 156 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut58
3
0 0
113 1
313 0
2
0 158 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut59
3
0 0
113 1
315 0
2
0 160 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut6
3
0 0
113 1
317 0
2
0 162 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut60
3
0 0
113 1
319 0
2
0 164 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut61
3
0 0
113 1
321 0
2
0 166 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut62
3
0 0
113 1
323 0
2
0 168 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut63
3
0 0
113 1
325 0
2
0 170 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut7
3
0 0
113 1
327 0
2
0 172 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut8
3
0 0
113 1
329 0
2
0 174 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner59 bob nut9
3
0 0
113 1
331 0
2
0 176 0 1
0 334 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut1
3
0 0
115 1
207 0
2
0 52 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut10
3
0 0
115 1
209 0
2
0 54 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut11
3
0 0
115 1
211 0
2
0 56 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut12
3
0 0
115 1
213 0
2
0 58 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut13
3
0 0
115 1
215 0
2
0 60 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut14
3
0 0
115 1
217 0
2
0 62 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut15
3
0 0
115 1
219 0
2
0 64 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut16
3
0 0
115 1
221 0
2
0 66 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut17
3
0 0
115 1
223 0
2
0 68 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut18
3
0 0
115 1
225 0
2
0 70 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut19
3
0 0
115 1
227 0
2
0 72 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut2
3
0 0
115 1
229 0
2
0 74 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut20
3
0 0
115 1
231 0
2
0 76 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut21
3
0 0
115 1
233 0
2
0 78 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut22
3
0 0
115 1
235 0
2
0 80 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut23
3
0 0
115 1
237 0
2
0 82 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut24
3
0 0
115 1
239 0
2
0 84 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut25
3
0 0
115 1
241 0
2
0 86 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut26
3
0 0
115 1
243 0
2
0 88 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut27
3
0 0
115 1
245 0
2
0 90 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut28
3
0 0
115 1
247 0
2
0 92 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut29
3
0 0
115 1
249 0
2
0 94 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut3
3
0 0
115 1
251 0
2
0 96 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut30
3
0 0
115 1
253 0
2
0 98 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut31
3
0 0
115 1
255 0
2
0 100 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut32
3
0 0
115 1
257 0
2
0 102 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut33
3
0 0
115 1
259 0
2
0 104 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut34
3
0 0
115 1
261 0
2
0 106 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut35
3
0 0
115 1
263 0
2
0 108 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut36
3
0 0
115 1
265 0
2
0 110 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut37
3
0 0
115 1
267 0
2
0 112 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut38
3
0 0
115 1
269 0
2
0 114 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut39
3
0 0
115 1
271 0
2
0 116 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut4
3
0 0
115 1
273 0
2
0 118 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut40
3
0 0
115 1
275 0
2
0 120 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut41
3
0 0
115 1
277 0
2
0 122 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut42
3
0 0
115 1
279 0
2
0 124 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut43
3
0 0
115 1
281 0
2
0 126 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut44
3
0 0
115 1
283 0
2
0 128 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut45
3
0 0
115 1
285 0
2
0 130 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut46
3
0 0
115 1
287 0
2
0 132 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut47
3
0 0
115 1
289 0
2
0 134 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut48
3
0 0
115 1
291 0
2
0 136 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut49
3
0 0
115 1
293 0
2
0 138 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut5
3
0 0
115 1
295 0
2
0 140 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut50
3
0 0
115 1
297 0
2
0 142 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut51
3
0 0
115 1
299 0
2
0 144 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut52
3
0 0
115 1
301 0
2
0 146 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut53
3
0 0
115 1
303 0
2
0 148 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut54
3
0 0
115 1
305 0
2
0 150 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut55
3
0 0
115 1
307 0
2
0 152 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut56
3
0 0
115 1
309 0
2
0 154 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut57
3
0 0
115 1
311 0
2
0 156 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut58
3
0 0
115 1
313 0
2
0 158 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut59
3
0 0
115 1
315 0
2
0 160 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut6
3
0 0
115 1
317 0
2
0 162 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut60
3
0 0
115 1
319 0
2
0 164 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut61
3
0 0
115 1
321 0
2
0 166 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut62
3
0 0
115 1
323 0
2
0 168 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut63
3
0 0
115 1
325 0
2
0 170 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut7
3
0 0
115 1
327 0
2
0 172 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut8
3
0 0
115 1
329 0
2
0 174 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner6 bob nut9
3
0 0
115 1
331 0
2
0 176 0 1
0 335 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut1
3
0 0
117 1
207 0
2
0 52 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut10
3
0 0
117 1
209 0
2
0 54 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut11
3
0 0
117 1
211 0
2
0 56 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut12
3
0 0
117 1
213 0
2
0 58 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut13
3
0 0
117 1
215 0
2
0 60 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut14
3
0 0
117 1
217 0
2
0 62 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut15
3
0 0
117 1
219 0
2
0 64 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut16
3
0 0
117 1
221 0
2
0 66 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut17
3
0 0
117 1
223 0
2
0 68 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut18
3
0 0
117 1
225 0
2
0 70 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut19
3
0 0
117 1
227 0
2
0 72 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut2
3
0 0
117 1
229 0
2
0 74 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut20
3
0 0
117 1
231 0
2
0 76 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut21
3
0 0
117 1
233 0
2
0 78 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut22
3
0 0
117 1
235 0
2
0 80 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut23
3
0 0
117 1
237 0
2
0 82 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut24
3
0 0
117 1
239 0
2
0 84 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut25
3
0 0
117 1
241 0
2
0 86 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut26
3
0 0
117 1
243 0
2
0 88 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut27
3
0 0
117 1
245 0
2
0 90 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut28
3
0 0
117 1
247 0
2
0 92 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut29
3
0 0
117 1
249 0
2
0 94 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut3
3
0 0
117 1
251 0
2
0 96 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut30
3
0 0
117 1
253 0
2
0 98 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut31
3
0 0
117 1
255 0
2
0 100 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut32
3
0 0
117 1
257 0
2
0 102 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut33
3
0 0
117 1
259 0
2
0 104 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut34
3
0 0
117 1
261 0
2
0 106 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut35
3
0 0
117 1
263 0
2
0 108 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut36
3
0 0
117 1
265 0
2
0 110 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut37
3
0 0
117 1
267 0
2
0 112 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut38
3
0 0
117 1
269 0
2
0 114 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut39
3
0 0
117 1
271 0
2
0 116 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut4
3
0 0
117 1
273 0
2
0 118 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut40
3
0 0
117 1
275 0
2
0 120 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut41
3
0 0
117 1
277 0
2
0 122 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut42
3
0 0
117 1
279 0
2
0 124 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut43
3
0 0
117 1
281 0
2
0 126 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut44
3
0 0
117 1
283 0
2
0 128 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut45
3
0 0
117 1
285 0
2
0 130 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut46
3
0 0
117 1
287 0
2
0 132 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut47
3
0 0
117 1
289 0
2
0 134 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut48
3
0 0
117 1
291 0
2
0 136 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut49
3
0 0
117 1
293 0
2
0 138 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut5
3
0 0
117 1
295 0
2
0 140 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut50
3
0 0
117 1
297 0
2
0 142 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut51
3
0 0
117 1
299 0
2
0 144 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut52
3
0 0
117 1
301 0
2
0 146 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut53
3
0 0
117 1
303 0
2
0 148 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut54
3
0 0
117 1
305 0
2
0 150 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut55
3
0 0
117 1
307 0
2
0 152 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut56
3
0 0
117 1
309 0
2
0 154 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut57
3
0 0
117 1
311 0
2
0 156 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut58
3
0 0
117 1
313 0
2
0 158 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut59
3
0 0
117 1
315 0
2
0 160 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut6
3
0 0
117 1
317 0
2
0 162 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut60
3
0 0
117 1
319 0
2
0 164 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut61
3
0 0
117 1
321 0
2
0 166 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut62
3
0 0
117 1
323 0
2
0 168 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut63
3
0 0
117 1
325 0
2
0 170 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut7
3
0 0
117 1
327 0
2
0 172 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut8
3
0 0
117 1
329 0
2
0 174 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner60 bob nut9
3
0 0
117 1
331 0
2
0 176 0 1
0 336 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut1
3
0 0
119 1
207 0
2
0 52 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut10
3
0 0
119 1
209 0
2
0 54 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut11
3
0 0
119 1
211 0
2
0 56 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut12
3
0 0
119 1
213 0
2
0 58 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut13
3
0 0
119 1
215 0
2
0 60 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut14
3
0 0
119 1
217 0
2
0 62 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut15
3
0 0
119 1
219 0
2
0 64 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut16
3
0 0
119 1
221 0
2
0 66 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut17
3
0 0
119 1
223 0
2
0 68 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut18
3
0 0
119 1
225 0
2
0 70 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut19
3
0 0
119 1
227 0
2
0 72 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut2
3
0 0
119 1
229 0
2
0 74 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut20
3
0 0
119 1
231 0
2
0 76 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut21
3
0 0
119 1
233 0
2
0 78 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut22
3
0 0
119 1
235 0
2
0 80 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut23
3
0 0
119 1
237 0
2
0 82 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut24
3
0 0
119 1
239 0
2
0 84 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut25
3
0 0
119 1
241 0
2
0 86 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut26
3
0 0
119 1
243 0
2
0 88 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut27
3
0 0
119 1
245 0
2
0 90 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut28
3
0 0
119 1
247 0
2
0 92 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut29
3
0 0
119 1
249 0
2
0 94 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut3
3
0 0
119 1
251 0
2
0 96 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut30
3
0 0
119 1
253 0
2
0 98 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut31
3
0 0
119 1
255 0
2
0 100 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut32
3
0 0
119 1
257 0
2
0 102 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut33
3
0 0
119 1
259 0
2
0 104 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut34
3
0 0
119 1
261 0
2
0 106 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut35
3
0 0
119 1
263 0
2
0 108 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut36
3
0 0
119 1
265 0
2
0 110 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut37
3
0 0
119 1
267 0
2
0 112 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut38
3
0 0
119 1
269 0
2
0 114 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut39
3
0 0
119 1
271 0
2
0 116 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut4
3
0 0
119 1
273 0
2
0 118 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut40
3
0 0
119 1
275 0
2
0 120 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut41
3
0 0
119 1
277 0
2
0 122 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut42
3
0 0
119 1
279 0
2
0 124 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut43
3
0 0
119 1
281 0
2
0 126 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut44
3
0 0
119 1
283 0
2
0 128 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut45
3
0 0
119 1
285 0
2
0 130 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut46
3
0 0
119 1
287 0
2
0 132 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut47
3
0 0
119 1
289 0
2
0 134 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut48
3
0 0
119 1
291 0
2
0 136 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut49
3
0 0
119 1
293 0
2
0 138 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut5
3
0 0
119 1
295 0
2
0 140 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut50
3
0 0
119 1
297 0
2
0 142 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut51
3
0 0
119 1
299 0
2
0 144 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut52
3
0 0
119 1
301 0
2
0 146 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut53
3
0 0
119 1
303 0
2
0 148 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut54
3
0 0
119 1
305 0
2
0 150 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut55
3
0 0
119 1
307 0
2
0 152 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut56
3
0 0
119 1
309 0
2
0 154 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut57
3
0 0
119 1
311 0
2
0 156 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut58
3
0 0
119 1
313 0
2
0 158 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut59
3
0 0
119 1
315 0
2
0 160 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut6
3
0 0
119 1
317 0
2
0 162 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut60
3
0 0
119 1
319 0
2
0 164 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut61
3
0 0
119 1
321 0
2
0 166 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut62
3
0 0
119 1
323 0
2
0 168 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut63
3
0 0
119 1
325 0
2
0 170 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut7
3
0 0
119 1
327 0
2
0 172 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut8
3
0 0
119 1
329 0
2
0 174 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner61 bob nut9
3
0 0
119 1
331 0
2
0 176 0 1
0 337 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut1
3
0 0
121 1
207 0
2
0 52 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut10
3
0 0
121 1
209 0
2
0 54 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut11
3
0 0
121 1
211 0
2
0 56 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut12
3
0 0
121 1
213 0
2
0 58 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut13
3
0 0
121 1
215 0
2
0 60 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut14
3
0 0
121 1
217 0
2
0 62 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut15
3
0 0
121 1
219 0
2
0 64 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut16
3
0 0
121 1
221 0
2
0 66 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut17
3
0 0
121 1
223 0
2
0 68 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut18
3
0 0
121 1
225 0
2
0 70 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut19
3
0 0
121 1
227 0
2
0 72 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut2
3
0 0
121 1
229 0
2
0 74 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut20
3
0 0
121 1
231 0
2
0 76 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut21
3
0 0
121 1
233 0
2
0 78 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut22
3
0 0
121 1
235 0
2
0 80 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut23
3
0 0
121 1
237 0
2
0 82 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut24
3
0 0
121 1
239 0
2
0 84 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut25
3
0 0
121 1
241 0
2
0 86 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut26
3
0 0
121 1
243 0
2
0 88 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut27
3
0 0
121 1
245 0
2
0 90 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut28
3
0 0
121 1
247 0
2
0 92 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut29
3
0 0
121 1
249 0
2
0 94 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut3
3
0 0
121 1
251 0
2
0 96 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut30
3
0 0
121 1
253 0
2
0 98 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut31
3
0 0
121 1
255 0
2
0 100 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut32
3
0 0
121 1
257 0
2
0 102 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut33
3
0 0
121 1
259 0
2
0 104 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut34
3
0 0
121 1
261 0
2
0 106 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut35
3
0 0
121 1
263 0
2
0 108 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut36
3
0 0
121 1
265 0
2
0 110 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut37
3
0 0
121 1
267 0
2
0 112 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut38
3
0 0
121 1
269 0
2
0 114 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut39
3
0 0
121 1
271 0
2
0 116 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut4
3
0 0
121 1
273 0
2
0 118 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut40
3
0 0
121 1
275 0
2
0 120 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut41
3
0 0
121 1
277 0
2
0 122 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut42
3
0 0
121 1
279 0
2
0 124 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut43
3
0 0
121 1
281 0
2
0 126 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut44
3
0 0
121 1
283 0
2
0 128 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut45
3
0 0
121 1
285 0
2
0 130 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut46
3
0 0
121 1
287 0
2
0 132 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut47
3
0 0
121 1
289 0
2
0 134 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut48
3
0 0
121 1
291 0
2
0 136 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut49
3
0 0
121 1
293 0
2
0 138 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut5
3
0 0
121 1
295 0
2
0 140 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut50
3
0 0
121 1
297 0
2
0 142 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut51
3
0 0
121 1
299 0
2
0 144 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut52
3
0 0
121 1
301 0
2
0 146 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut53
3
0 0
121 1
303 0
2
0 148 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut54
3
0 0
121 1
305 0
2
0 150 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut55
3
0 0
121 1
307 0
2
0 152 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut56
3
0 0
121 1
309 0
2
0 154 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut57
3
0 0
121 1
311 0
2
0 156 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut58
3
0 0
121 1
313 0
2
0 158 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut59
3
0 0
121 1
315 0
2
0 160 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut6
3
0 0
121 1
317 0
2
0 162 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut60
3
0 0
121 1
319 0
2
0 164 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut61
3
0 0
121 1
321 0
2
0 166 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut62
3
0 0
121 1
323 0
2
0 168 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut63
3
0 0
121 1
325 0
2
0 170 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut7
3
0 0
121 1
327 0
2
0 172 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut8
3
0 0
121 1
329 0
2
0 174 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner62 bob nut9
3
0 0
121 1
331 0
2
0 176 0 1
0 338 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut1
3
0 0
123 1
207 0
2
0 52 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut10
3
0 0
123 1
209 0
2
0 54 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut11
3
0 0
123 1
211 0
2
0 56 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut12
3
0 0
123 1
213 0
2
0 58 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut13
3
0 0
123 1
215 0
2
0 60 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut14
3
0 0
123 1
217 0
2
0 62 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut15
3
0 0
123 1
219 0
2
0 64 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut16
3
0 0
123 1
221 0
2
0 66 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut17
3
0 0
123 1
223 0
2
0 68 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut18
3
0 0
123 1
225 0
2
0 70 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut19
3
0 0
123 1
227 0
2
0 72 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut2
3
0 0
123 1
229 0
2
0 74 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut20
3
0 0
123 1
231 0
2
0 76 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut21
3
0 0
123 1
233 0
2
0 78 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut22
3
0 0
123 1
235 0
2
0 80 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut23
3
0 0
123 1
237 0
2
0 82 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut24
3
0 0
123 1
239 0
2
0 84 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut25
3
0 0
123 1
241 0
2
0 86 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut26
3
0 0
123 1
243 0
2
0 88 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut27
3
0 0
123 1
245 0
2
0 90 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut28
3
0 0
123 1
247 0
2
0 92 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut29
3
0 0
123 1
249 0
2
0 94 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut3
3
0 0
123 1
251 0
2
0 96 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut30
3
0 0
123 1
253 0
2
0 98 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut31
3
0 0
123 1
255 0
2
0 100 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut32
3
0 0
123 1
257 0
2
0 102 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut33
3
0 0
123 1
259 0
2
0 104 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut34
3
0 0
123 1
261 0
2
0 106 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut35
3
0 0
123 1
263 0
2
0 108 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut36
3
0 0
123 1
265 0
2
0 110 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut37
3
0 0
123 1
267 0
2
0 112 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut38
3
0 0
123 1
269 0
2
0 114 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut39
3
0 0
123 1
271 0
2
0 116 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut4
3
0 0
123 1
273 0
2
0 118 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut40
3
0 0
123 1
275 0
2
0 120 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut41
3
0 0
123 1
277 0
2
0 122 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut42
3
0 0
123 1
279 0
2
0 124 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut43
3
0 0
123 1
281 0
2
0 126 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut44
3
0 0
123 1
283 0
2
0 128 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut45
3
0 0
123 1
285 0
2
0 130 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut46
3
0 0
123 1
287 0
2
0 132 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut47
3
0 0
123 1
289 0
2
0 134 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut48
3
0 0
123 1
291 0
2
0 136 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut49
3
0 0
123 1
293 0
2
0 138 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut5
3
0 0
123 1
295 0
2
0 140 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut50
3
0 0
123 1
297 0
2
0 142 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut51
3
0 0
123 1
299 0
2
0 144 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut52
3
0 0
123 1
301 0
2
0 146 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut53
3
0 0
123 1
303 0
2
0 148 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut54
3
0 0
123 1
305 0
2
0 150 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut55
3
0 0
123 1
307 0
2
0 152 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut56
3
0 0
123 1
309 0
2
0 154 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut57
3
0 0
123 1
311 0
2
0 156 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut58
3
0 0
123 1
313 0
2
0 158 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut59
3
0 0
123 1
315 0
2
0 160 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut6
3
0 0
123 1
317 0
2
0 162 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut60
3
0 0
123 1
319 0
2
0 164 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut61
3
0 0
123 1
321 0
2
0 166 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut62
3
0 0
123 1
323 0
2
0 168 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut63
3
0 0
123 1
325 0
2
0 170 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut7
3
0 0
123 1
327 0
2
0 172 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut8
3
0 0
123 1
329 0
2
0 174 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner63 bob nut9
3
0 0
123 1
331 0
2
0 176 0 1
0 339 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut1
3
0 0
125 1
207 0
2
0 52 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut10
3
0 0
125 1
209 0
2
0 54 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut11
3
0 0
125 1
211 0
2
0 56 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut12
3
0 0
125 1
213 0
2
0 58 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut13
3
0 0
125 1
215 0
2
0 60 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut14
3
0 0
125 1
217 0
2
0 62 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut15
3
0 0
125 1
219 0
2
0 64 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut16
3
0 0
125 1
221 0
2
0 66 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut17
3
0 0
125 1
223 0
2
0 68 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut18
3
0 0
125 1
225 0
2
0 70 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut19
3
0 0
125 1
227 0
2
0 72 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut2
3
0 0
125 1
229 0
2
0 74 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut20
3
0 0
125 1
231 0
2
0 76 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut21
3
0 0
125 1
233 0
2
0 78 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut22
3
0 0
125 1
235 0
2
0 80 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut23
3
0 0
125 1
237 0
2
0 82 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut24
3
0 0
125 1
239 0
2
0 84 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut25
3
0 0
125 1
241 0
2
0 86 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut26
3
0 0
125 1
243 0
2
0 88 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut27
3
0 0
125 1
245 0
2
0 90 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut28
3
0 0
125 1
247 0
2
0 92 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut29
3
0 0
125 1
249 0
2
0 94 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut3
3
0 0
125 1
251 0
2
0 96 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut30
3
0 0
125 1
253 0
2
0 98 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut31
3
0 0
125 1
255 0
2
0 100 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut32
3
0 0
125 1
257 0
2
0 102 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut33
3
0 0
125 1
259 0
2
0 104 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut34
3
0 0
125 1
261 0
2
0 106 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut35
3
0 0
125 1
263 0
2
0 108 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut36
3
0 0
125 1
265 0
2
0 110 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut37
3
0 0
125 1
267 0
2
0 112 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut38
3
0 0
125 1
269 0
2
0 114 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut39
3
0 0
125 1
271 0
2
0 116 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut4
3
0 0
125 1
273 0
2
0 118 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut40
3
0 0
125 1
275 0
2
0 120 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut41
3
0 0
125 1
277 0
2
0 122 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut42
3
0 0
125 1
279 0
2
0 124 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut43
3
0 0
125 1
281 0
2
0 126 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut44
3
0 0
125 1
283 0
2
0 128 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut45
3
0 0
125 1
285 0
2
0 130 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut46
3
0 0
125 1
287 0
2
0 132 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut47
3
0 0
125 1
289 0
2
0 134 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut48
3
0 0
125 1
291 0
2
0 136 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut49
3
0 0
125 1
293 0
2
0 138 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut5
3
0 0
125 1
295 0
2
0 140 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut50
3
0 0
125 1
297 0
2
0 142 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut51
3
0 0
125 1
299 0
2
0 144 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut52
3
0 0
125 1
301 0
2
0 146 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut53
3
0 0
125 1
303 0
2
0 148 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut54
3
0 0
125 1
305 0
2
0 150 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut55
3
0 0
125 1
307 0
2
0 152 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut56
3
0 0
125 1
309 0
2
0 154 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut57
3
0 0
125 1
311 0
2
0 156 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut58
3
0 0
125 1
313 0
2
0 158 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut59
3
0 0
125 1
315 0
2
0 160 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut6
3
0 0
125 1
317 0
2
0 162 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut60
3
0 0
125 1
319 0
2
0 164 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut61
3
0 0
125 1
321 0
2
0 166 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut62
3
0 0
125 1
323 0
2
0 168 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut63
3
0 0
125 1
325 0
2
0 170 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut7
3
0 0
125 1
327 0
2
0 172 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut8
3
0 0
125 1
329 0
2
0 174 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner64 bob nut9
3
0 0
125 1
331 0
2
0 176 0 1
0 340 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut1
3
0 0
127 1
207 0
2
0 52 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut10
3
0 0
127 1
209 0
2
0 54 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut11
3
0 0
127 1
211 0
2
0 56 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut12
3
0 0
127 1
213 0
2
0 58 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut13
3
0 0
127 1
215 0
2
0 60 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut14
3
0 0
127 1
217 0
2
0 62 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut15
3
0 0
127 1
219 0
2
0 64 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut16
3
0 0
127 1
221 0
2
0 66 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut17
3
0 0
127 1
223 0
2
0 68 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut18
3
0 0
127 1
225 0
2
0 70 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut19
3
0 0
127 1
227 0
2
0 72 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut2
3
0 0
127 1
229 0
2
0 74 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut20
3
0 0
127 1
231 0
2
0 76 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut21
3
0 0
127 1
233 0
2
0 78 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut22
3
0 0
127 1
235 0
2
0 80 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut23
3
0 0
127 1
237 0
2
0 82 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut24
3
0 0
127 1
239 0
2
0 84 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut25
3
0 0
127 1
241 0
2
0 86 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut26
3
0 0
127 1
243 0
2
0 88 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut27
3
0 0
127 1
245 0
2
0 90 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut28
3
0 0
127 1
247 0
2
0 92 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut29
3
0 0
127 1
249 0
2
0 94 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut3
3
0 0
127 1
251 0
2
0 96 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut30
3
0 0
127 1
253 0
2
0 98 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut31
3
0 0
127 1
255 0
2
0 100 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut32
3
0 0
127 1
257 0
2
0 102 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut33
3
0 0
127 1
259 0
2
0 104 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut34
3
0 0
127 1
261 0
2
0 106 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut35
3
0 0
127 1
263 0
2
0 108 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut36
3
0 0
127 1
265 0
2
0 110 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut37
3
0 0
127 1
267 0
2
0 112 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut38
3
0 0
127 1
269 0
2
0 114 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut39
3
0 0
127 1
271 0
2
0 116 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut4
3
0 0
127 1
273 0
2
0 118 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut40
3
0 0
127 1
275 0
2
0 120 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut41
3
0 0
127 1
277 0
2
0 122 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut42
3
0 0
127 1
279 0
2
0 124 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut43
3
0 0
127 1
281 0
2
0 126 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut44
3
0 0
127 1
283 0
2
0 128 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut45
3
0 0
127 1
285 0
2
0 130 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut46
3
0 0
127 1
287 0
2
0 132 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut47
3
0 0
127 1
289 0
2
0 134 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut48
3
0 0
127 1
291 0
2
0 136 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut49
3
0 0
127 1
293 0
2
0 138 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut5
3
0 0
127 1
295 0
2
0 140 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut50
3
0 0
127 1
297 0
2
0 142 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut51
3
0 0
127 1
299 0
2
0 144 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut52
3
0 0
127 1
301 0
2
0 146 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut53
3
0 0
127 1
303 0
2
0 148 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut54
3
0 0
127 1
305 0
2
0 150 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut55
3
0 0
127 1
307 0
2
0 152 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut56
3
0 0
127 1
309 0
2
0 154 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut57
3
0 0
127 1
311 0
2
0 156 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut58
3
0 0
127 1
313 0
2
0 158 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut59
3
0 0
127 1
315 0
2
0 160 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut6
3
0 0
127 1
317 0
2
0 162 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut60
3
0 0
127 1
319 0
2
0 164 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut61
3
0 0
127 1
321 0
2
0 166 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut62
3
0 0
127 1
323 0
2
0 168 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut63
3
0 0
127 1
325 0
2
0 170 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut7
3
0 0
127 1
327 0
2
0 172 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut8
3
0 0
127 1
329 0
2
0 174 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner65 bob nut9
3
0 0
127 1
331 0
2
0 176 0 1
0 341 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut1
3
0 0
129 1
207 0
2
0 52 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut10
3
0 0
129 1
209 0
2
0 54 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut11
3
0 0
129 1
211 0
2
0 56 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut12
3
0 0
129 1
213 0
2
0 58 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut13
3
0 0
129 1
215 0
2
0 60 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut14
3
0 0
129 1
217 0
2
0 62 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut15
3
0 0
129 1
219 0
2
0 64 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut16
3
0 0
129 1
221 0
2
0 66 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut17
3
0 0
129 1
223 0
2
0 68 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut18
3
0 0
129 1
225 0
2
0 70 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut19
3
0 0
129 1
227 0
2
0 72 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut2
3
0 0
129 1
229 0
2
0 74 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut20
3
0 0
129 1
231 0
2
0 76 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut21
3
0 0
129 1
233 0
2
0 78 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut22
3
0 0
129 1
235 0
2
0 80 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut23
3
0 0
129 1
237 0
2
0 82 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut24
3
0 0
129 1
239 0
2
0 84 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut25
3
0 0
129 1
241 0
2
0 86 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut26
3
0 0
129 1
243 0
2
0 88 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut27
3
0 0
129 1
245 0
2
0 90 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut28
3
0 0
129 1
247 0
2
0 92 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut29
3
0 0
129 1
249 0
2
0 94 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut3
3
0 0
129 1
251 0
2
0 96 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut30
3
0 0
129 1
253 0
2
0 98 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut31
3
0 0
129 1
255 0
2
0 100 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut32
3
0 0
129 1
257 0
2
0 102 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut33
3
0 0
129 1
259 0
2
0 104 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut34
3
0 0
129 1
261 0
2
0 106 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut35
3
0 0
129 1
263 0
2
0 108 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut36
3
0 0
129 1
265 0
2
0 110 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut37
3
0 0
129 1
267 0
2
0 112 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut38
3
0 0
129 1
269 0
2
0 114 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut39
3
0 0
129 1
271 0
2
0 116 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut4
3
0 0
129 1
273 0
2
0 118 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut40
3
0 0
129 1
275 0
2
0 120 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut41
3
0 0
129 1
277 0
2
0 122 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut42
3
0 0
129 1
279 0
2
0 124 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut43
3
0 0
129 1
281 0
2
0 126 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut44
3
0 0
129 1
283 0
2
0 128 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut45
3
0 0
129 1
285 0
2
0 130 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut46
3
0 0
129 1
287 0
2
0 132 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut47
3
0 0
129 1
289 0
2
0 134 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut48
3
0 0
129 1
291 0
2
0 136 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut49
3
0 0
129 1
293 0
2
0 138 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut5
3
0 0
129 1
295 0
2
0 140 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut50
3
0 0
129 1
297 0
2
0 142 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut51
3
0 0
129 1
299 0
2
0 144 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut52
3
0 0
129 1
301 0
2
0 146 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut53
3
0 0
129 1
303 0
2
0 148 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut54
3
0 0
129 1
305 0
2
0 150 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut55
3
0 0
129 1
307 0
2
0 152 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut56
3
0 0
129 1
309 0
2
0 154 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut57
3
0 0
129 1
311 0
2
0 156 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut58
3
0 0
129 1
313 0
2
0 158 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut59
3
0 0
129 1
315 0
2
0 160 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut6
3
0 0
129 1
317 0
2
0 162 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut60
3
0 0
129 1
319 0
2
0 164 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut61
3
0 0
129 1
321 0
2
0 166 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut62
3
0 0
129 1
323 0
2
0 168 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut63
3
0 0
129 1
325 0
2
0 170 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut7
3
0 0
129 1
327 0
2
0 172 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut8
3
0 0
129 1
329 0
2
0 174 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner66 bob nut9
3
0 0
129 1
331 0
2
0 176 0 1
0 342 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut1
3
0 0
131 1
207 0
2
0 52 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut10
3
0 0
131 1
209 0
2
0 54 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut11
3
0 0
131 1
211 0
2
0 56 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut12
3
0 0
131 1
213 0
2
0 58 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut13
3
0 0
131 1
215 0
2
0 60 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut14
3
0 0
131 1
217 0
2
0 62 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut15
3
0 0
131 1
219 0
2
0 64 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut16
3
0 0
131 1
221 0
2
0 66 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut17
3
0 0
131 1
223 0
2
0 68 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut18
3
0 0
131 1
225 0
2
0 70 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut19
3
0 0
131 1
227 0
2
0 72 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut2
3
0 0
131 1
229 0
2
0 74 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut20
3
0 0
131 1
231 0
2
0 76 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut21
3
0 0
131 1
233 0
2
0 78 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut22
3
0 0
131 1
235 0
2
0 80 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut23
3
0 0
131 1
237 0
2
0 82 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut24
3
0 0
131 1
239 0
2
0 84 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut25
3
0 0
131 1
241 0
2
0 86 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut26
3
0 0
131 1
243 0
2
0 88 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut27
3
0 0
131 1
245 0
2
0 90 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut28
3
0 0
131 1
247 0
2
0 92 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut29
3
0 0
131 1
249 0
2
0 94 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut3
3
0 0
131 1
251 0
2
0 96 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut30
3
0 0
131 1
253 0
2
0 98 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut31
3
0 0
131 1
255 0
2
0 100 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut32
3
0 0
131 1
257 0
2
0 102 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut33
3
0 0
131 1
259 0
2
0 104 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut34
3
0 0
131 1
261 0
2
0 106 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut35
3
0 0
131 1
263 0
2
0 108 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut36
3
0 0
131 1
265 0
2
0 110 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut37
3
0 0
131 1
267 0
2
0 112 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut38
3
0 0
131 1
269 0
2
0 114 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut39
3
0 0
131 1
271 0
2
0 116 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut4
3
0 0
131 1
273 0
2
0 118 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut40
3
0 0
131 1
275 0
2
0 120 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut41
3
0 0
131 1
277 0
2
0 122 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut42
3
0 0
131 1
279 0
2
0 124 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut43
3
0 0
131 1
281 0
2
0 126 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut44
3
0 0
131 1
283 0
2
0 128 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut45
3
0 0
131 1
285 0
2
0 130 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut46
3
0 0
131 1
287 0
2
0 132 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut47
3
0 0
131 1
289 0
2
0 134 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut48
3
0 0
131 1
291 0
2
0 136 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut49
3
0 0
131 1
293 0
2
0 138 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut5
3
0 0
131 1
295 0
2
0 140 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut50
3
0 0
131 1
297 0
2
0 142 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut51
3
0 0
131 1
299 0
2
0 144 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut52
3
0 0
131 1
301 0
2
0 146 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut53
3
0 0
131 1
303 0
2
0 148 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut54
3
0 0
131 1
305 0
2
0 150 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut55
3
0 0
131 1
307 0
2
0 152 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut56
3
0 0
131 1
309 0
2
0 154 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut57
3
0 0
131 1
311 0
2
0 156 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut58
3
0 0
131 1
313 0
2
0 158 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut59
3
0 0
131 1
315 0
2
0 160 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut6
3
0 0
131 1
317 0
2
0 162 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut60
3
0 0
131 1
319 0
2
0 164 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut61
3
0 0
131 1
321 0
2
0 166 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut62
3
0 0
131 1
323 0
2
0 168 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut63
3
0 0
131 1
325 0
2
0 170 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut7
3
0 0
131 1
327 0
2
0 172 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut8
3
0 0
131 1
329 0
2
0 174 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner67 bob nut9
3
0 0
131 1
331 0
2
0 176 0 1
0 343 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut1
3
0 0
133 1
207 0
2
0 52 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut10
3
0 0
133 1
209 0
2
0 54 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut11
3
0 0
133 1
211 0
2
0 56 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut12
3
0 0
133 1
213 0
2
0 58 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut13
3
0 0
133 1
215 0
2
0 60 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut14
3
0 0
133 1
217 0
2
0 62 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut15
3
0 0
133 1
219 0
2
0 64 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut16
3
0 0
133 1
221 0
2
0 66 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut17
3
0 0
133 1
223 0
2
0 68 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut18
3
0 0
133 1
225 0
2
0 70 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut19
3
0 0
133 1
227 0
2
0 72 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut2
3
0 0
133 1
229 0
2
0 74 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut20
3
0 0
133 1
231 0
2
0 76 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut21
3
0 0
133 1
233 0
2
0 78 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut22
3
0 0
133 1
235 0
2
0 80 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut23
3
0 0
133 1
237 0
2
0 82 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut24
3
0 0
133 1
239 0
2
0 84 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut25
3
0 0
133 1
241 0
2
0 86 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut26
3
0 0
133 1
243 0
2
0 88 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut27
3
0 0
133 1
245 0
2
0 90 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut28
3
0 0
133 1
247 0
2
0 92 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut29
3
0 0
133 1
249 0
2
0 94 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut3
3
0 0
133 1
251 0
2
0 96 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut30
3
0 0
133 1
253 0
2
0 98 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut31
3
0 0
133 1
255 0
2
0 100 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut32
3
0 0
133 1
257 0
2
0 102 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut33
3
0 0
133 1
259 0
2
0 104 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut34
3
0 0
133 1
261 0
2
0 106 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut35
3
0 0
133 1
263 0
2
0 108 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut36
3
0 0
133 1
265 0
2
0 110 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut37
3
0 0
133 1
267 0
2
0 112 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut38
3
0 0
133 1
269 0
2
0 114 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut39
3
0 0
133 1
271 0
2
0 116 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut4
3
0 0
133 1
273 0
2
0 118 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut40
3
0 0
133 1
275 0
2
0 120 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut41
3
0 0
133 1
277 0
2
0 122 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut42
3
0 0
133 1
279 0
2
0 124 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut43
3
0 0
133 1
281 0
2
0 126 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut44
3
0 0
133 1
283 0
2
0 128 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut45
3
0 0
133 1
285 0
2
0 130 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut46
3
0 0
133 1
287 0
2
0 132 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut47
3
0 0
133 1
289 0
2
0 134 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut48
3
0 0
133 1
291 0
2
0 136 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut49
3
0 0
133 1
293 0
2
0 138 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut5
3
0 0
133 1
295 0
2
0 140 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut50
3
0 0
133 1
297 0
2
0 142 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut51
3
0 0
133 1
299 0
2
0 144 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut52
3
0 0
133 1
301 0
2
0 146 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut53
3
0 0
133 1
303 0
2
0 148 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut54
3
0 0
133 1
305 0
2
0 150 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut55
3
0 0
133 1
307 0
2
0 152 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut56
3
0 0
133 1
309 0
2
0 154 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut57
3
0 0
133 1
311 0
2
0 156 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut58
3
0 0
133 1
313 0
2
0 158 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut59
3
0 0
133 1
315 0
2
0 160 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut6
3
0 0
133 1
317 0
2
0 162 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut60
3
0 0
133 1
319 0
2
0 164 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut61
3
0 0
133 1
321 0
2
0 166 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut62
3
0 0
133 1
323 0
2
0 168 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut63
3
0 0
133 1
325 0
2
0 170 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut7
3
0 0
133 1
327 0
2
0 172 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut8
3
0 0
133 1
329 0
2
0 174 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner68 bob nut9
3
0 0
133 1
331 0
2
0 176 0 1
0 344 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut1
3
0 0
135 1
207 0
2
0 52 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut10
3
0 0
135 1
209 0
2
0 54 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut11
3
0 0
135 1
211 0
2
0 56 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut12
3
0 0
135 1
213 0
2
0 58 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut13
3
0 0
135 1
215 0
2
0 60 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut14
3
0 0
135 1
217 0
2
0 62 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut15
3
0 0
135 1
219 0
2
0 64 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut16
3
0 0
135 1
221 0
2
0 66 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut17
3
0 0
135 1
223 0
2
0 68 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut18
3
0 0
135 1
225 0
2
0 70 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut19
3
0 0
135 1
227 0
2
0 72 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut2
3
0 0
135 1
229 0
2
0 74 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut20
3
0 0
135 1
231 0
2
0 76 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut21
3
0 0
135 1
233 0
2
0 78 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut22
3
0 0
135 1
235 0
2
0 80 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut23
3
0 0
135 1
237 0
2
0 82 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut24
3
0 0
135 1
239 0
2
0 84 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut25
3
0 0
135 1
241 0
2
0 86 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut26
3
0 0
135 1
243 0
2
0 88 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut27
3
0 0
135 1
245 0
2
0 90 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut28
3
0 0
135 1
247 0
2
0 92 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut29
3
0 0
135 1
249 0
2
0 94 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut3
3
0 0
135 1
251 0
2
0 96 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut30
3
0 0
135 1
253 0
2
0 98 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut31
3
0 0
135 1
255 0
2
0 100 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut32
3
0 0
135 1
257 0
2
0 102 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut33
3
0 0
135 1
259 0
2
0 104 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut34
3
0 0
135 1
261 0
2
0 106 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut35
3
0 0
135 1
263 0
2
0 108 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut36
3
0 0
135 1
265 0
2
0 110 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut37
3
0 0
135 1
267 0
2
0 112 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut38
3
0 0
135 1
269 0
2
0 114 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut39
3
0 0
135 1
271 0
2
0 116 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut4
3
0 0
135 1
273 0
2
0 118 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut40
3
0 0
135 1
275 0
2
0 120 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut41
3
0 0
135 1
277 0
2
0 122 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut42
3
0 0
135 1
279 0
2
0 124 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut43
3
0 0
135 1
281 0
2
0 126 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut44
3
0 0
135 1
283 0
2
0 128 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut45
3
0 0
135 1
285 0
2
0 130 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut46
3
0 0
135 1
287 0
2
0 132 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut47
3
0 0
135 1
289 0
2
0 134 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut48
3
0 0
135 1
291 0
2
0 136 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut49
3
0 0
135 1
293 0
2
0 138 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut5
3
0 0
135 1
295 0
2
0 140 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut50
3
0 0
135 1
297 0
2
0 142 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut51
3
0 0
135 1
299 0
2
0 144 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut52
3
0 0
135 1
301 0
2
0 146 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut53
3
0 0
135 1
303 0
2
0 148 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut54
3
0 0
135 1
305 0
2
0 150 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut55
3
0 0
135 1
307 0
2
0 152 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut56
3
0 0
135 1
309 0
2
0 154 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut57
3
0 0
135 1
311 0
2
0 156 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut58
3
0 0
135 1
313 0
2
0 158 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut59
3
0 0
135 1
315 0
2
0 160 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut6
3
0 0
135 1
317 0
2
0 162 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut60
3
0 0
135 1
319 0
2
0 164 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut61
3
0 0
135 1
321 0
2
0 166 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut62
3
0 0
135 1
323 0
2
0 168 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut63
3
0 0
135 1
325 0
2
0 170 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut7
3
0 0
135 1
327 0
2
0 172 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut8
3
0 0
135 1
329 0
2
0 174 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner69 bob nut9
3
0 0
135 1
331 0
2
0 176 0 1
0 345 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut1
3
0 0
137 1
207 0
2
0 52 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut10
3
0 0
137 1
209 0
2
0 54 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut11
3
0 0
137 1
211 0
2
0 56 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut12
3
0 0
137 1
213 0
2
0 58 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut13
3
0 0
137 1
215 0
2
0 60 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut14
3
0 0
137 1
217 0
2
0 62 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut15
3
0 0
137 1
219 0
2
0 64 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut16
3
0 0
137 1
221 0
2
0 66 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut17
3
0 0
137 1
223 0
2
0 68 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut18
3
0 0
137 1
225 0
2
0 70 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut19
3
0 0
137 1
227 0
2
0 72 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut2
3
0 0
137 1
229 0
2
0 74 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut20
3
0 0
137 1
231 0
2
0 76 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut21
3
0 0
137 1
233 0
2
0 78 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut22
3
0 0
137 1
235 0
2
0 80 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut23
3
0 0
137 1
237 0
2
0 82 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut24
3
0 0
137 1
239 0
2
0 84 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut25
3
0 0
137 1
241 0
2
0 86 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut26
3
0 0
137 1
243 0
2
0 88 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut27
3
0 0
137 1
245 0
2
0 90 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut28
3
0 0
137 1
247 0
2
0 92 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut29
3
0 0
137 1
249 0
2
0 94 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut3
3
0 0
137 1
251 0
2
0 96 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut30
3
0 0
137 1
253 0
2
0 98 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut31
3
0 0
137 1
255 0
2
0 100 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut32
3
0 0
137 1
257 0
2
0 102 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut33
3
0 0
137 1
259 0
2
0 104 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut34
3
0 0
137 1
261 0
2
0 106 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut35
3
0 0
137 1
263 0
2
0 108 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut36
3
0 0
137 1
265 0
2
0 110 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut37
3
0 0
137 1
267 0
2
0 112 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut38
3
0 0
137 1
269 0
2
0 114 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut39
3
0 0
137 1
271 0
2
0 116 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut4
3
0 0
137 1
273 0
2
0 118 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut40
3
0 0
137 1
275 0
2
0 120 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut41
3
0 0
137 1
277 0
2
0 122 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut42
3
0 0
137 1
279 0
2
0 124 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut43
3
0 0
137 1
281 0
2
0 126 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut44
3
0 0
137 1
283 0
2
0 128 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut45
3
0 0
137 1
285 0
2
0 130 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut46
3
0 0
137 1
287 0
2
0 132 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut47
3
0 0
137 1
289 0
2
0 134 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut48
3
0 0
137 1
291 0
2
0 136 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut49
3
0 0
137 1
293 0
2
0 138 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut5
3
0 0
137 1
295 0
2
0 140 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut50
3
0 0
137 1
297 0
2
0 142 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut51
3
0 0
137 1
299 0
2
0 144 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut52
3
0 0
137 1
301 0
2
0 146 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut53
3
0 0
137 1
303 0
2
0 148 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut54
3
0 0
137 1
305 0
2
0 150 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut55
3
0 0
137 1
307 0
2
0 152 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut56
3
0 0
137 1
309 0
2
0 154 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut57
3
0 0
137 1
311 0
2
0 156 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut58
3
0 0
137 1
313 0
2
0 158 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut59
3
0 0
137 1
315 0
2
0 160 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut6
3
0 0
137 1
317 0
2
0 162 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut60
3
0 0
137 1
319 0
2
0 164 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut61
3
0 0
137 1
321 0
2
0 166 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut62
3
0 0
137 1
323 0
2
0 168 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut63
3
0 0
137 1
325 0
2
0 170 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut7
3
0 0
137 1
327 0
2
0 172 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut8
3
0 0
137 1
329 0
2
0 174 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner7 bob nut9
3
0 0
137 1
331 0
2
0 176 0 1
0 346 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut1
3
0 0
139 1
207 0
2
0 52 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut10
3
0 0
139 1
209 0
2
0 54 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut11
3
0 0
139 1
211 0
2
0 56 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut12
3
0 0
139 1
213 0
2
0 58 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut13
3
0 0
139 1
215 0
2
0 60 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut14
3
0 0
139 1
217 0
2
0 62 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut15
3
0 0
139 1
219 0
2
0 64 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut16
3
0 0
139 1
221 0
2
0 66 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut17
3
0 0
139 1
223 0
2
0 68 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut18
3
0 0
139 1
225 0
2
0 70 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut19
3
0 0
139 1
227 0
2
0 72 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut2
3
0 0
139 1
229 0
2
0 74 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut20
3
0 0
139 1
231 0
2
0 76 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut21
3
0 0
139 1
233 0
2
0 78 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut22
3
0 0
139 1
235 0
2
0 80 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut23
3
0 0
139 1
237 0
2
0 82 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut24
3
0 0
139 1
239 0
2
0 84 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut25
3
0 0
139 1
241 0
2
0 86 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut26
3
0 0
139 1
243 0
2
0 88 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut27
3
0 0
139 1
245 0
2
0 90 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut28
3
0 0
139 1
247 0
2
0 92 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut29
3
0 0
139 1
249 0
2
0 94 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut3
3
0 0
139 1
251 0
2
0 96 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut30
3
0 0
139 1
253 0
2
0 98 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut31
3
0 0
139 1
255 0
2
0 100 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut32
3
0 0
139 1
257 0
2
0 102 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut33
3
0 0
139 1
259 0
2
0 104 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut34
3
0 0
139 1
261 0
2
0 106 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut35
3
0 0
139 1
263 0
2
0 108 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut36
3
0 0
139 1
265 0
2
0 110 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut37
3
0 0
139 1
267 0
2
0 112 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut38
3
0 0
139 1
269 0
2
0 114 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut39
3
0 0
139 1
271 0
2
0 116 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut4
3
0 0
139 1
273 0
2
0 118 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut40
3
0 0
139 1
275 0
2
0 120 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut41
3
0 0
139 1
277 0
2
0 122 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut42
3
0 0
139 1
279 0
2
0 124 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut43
3
0 0
139 1
281 0
2
0 126 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut44
3
0 0
139 1
283 0
2
0 128 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut45
3
0 0
139 1
285 0
2
0 130 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut46
3
0 0
139 1
287 0
2
0 132 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut47
3
0 0
139 1
289 0
2
0 134 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut48
3
0 0
139 1
291 0
2
0 136 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut49
3
0 0
139 1
293 0
2
0 138 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut5
3
0 0
139 1
295 0
2
0 140 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut50
3
0 0
139 1
297 0
2
0 142 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut51
3
0 0
139 1
299 0
2
0 144 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut52
3
0 0
139 1
301 0
2
0 146 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut53
3
0 0
139 1
303 0
2
0 148 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut54
3
0 0
139 1
305 0
2
0 150 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut55
3
0 0
139 1
307 0
2
0 152 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut56
3
0 0
139 1
309 0
2
0 154 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut57
3
0 0
139 1
311 0
2
0 156 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut58
3
0 0
139 1
313 0
2
0 158 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut59
3
0 0
139 1
315 0
2
0 160 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut6
3
0 0
139 1
317 0
2
0 162 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut60
3
0 0
139 1
319 0
2
0 164 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut61
3
0 0
139 1
321 0
2
0 166 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut62
3
0 0
139 1
323 0
2
0 168 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut63
3
0 0
139 1
325 0
2
0 170 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut7
3
0 0
139 1
327 0
2
0 172 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut8
3
0 0
139 1
329 0
2
0 174 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner70 bob nut9
3
0 0
139 1
331 0
2
0 176 0 1
0 347 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut1
3
0 0
141 1
207 0
2
0 52 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut10
3
0 0
141 1
209 0
2
0 54 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut11
3
0 0
141 1
211 0
2
0 56 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut12
3
0 0
141 1
213 0
2
0 58 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut13
3
0 0
141 1
215 0
2
0 60 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut14
3
0 0
141 1
217 0
2
0 62 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut15
3
0 0
141 1
219 0
2
0 64 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut16
3
0 0
141 1
221 0
2
0 66 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut17
3
0 0
141 1
223 0
2
0 68 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut18
3
0 0
141 1
225 0
2
0 70 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut19
3
0 0
141 1
227 0
2
0 72 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut2
3
0 0
141 1
229 0
2
0 74 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut20
3
0 0
141 1
231 0
2
0 76 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut21
3
0 0
141 1
233 0
2
0 78 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut22
3
0 0
141 1
235 0
2
0 80 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut23
3
0 0
141 1
237 0
2
0 82 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut24
3
0 0
141 1
239 0
2
0 84 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut25
3
0 0
141 1
241 0
2
0 86 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut26
3
0 0
141 1
243 0
2
0 88 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut27
3
0 0
141 1
245 0
2
0 90 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut28
3
0 0
141 1
247 0
2
0 92 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut29
3
0 0
141 1
249 0
2
0 94 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut3
3
0 0
141 1
251 0
2
0 96 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut30
3
0 0
141 1
253 0
2
0 98 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut31
3
0 0
141 1
255 0
2
0 100 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut32
3
0 0
141 1
257 0
2
0 102 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut33
3
0 0
141 1
259 0
2
0 104 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut34
3
0 0
141 1
261 0
2
0 106 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut35
3
0 0
141 1
263 0
2
0 108 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut36
3
0 0
141 1
265 0
2
0 110 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut37
3
0 0
141 1
267 0
2
0 112 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut38
3
0 0
141 1
269 0
2
0 114 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut39
3
0 0
141 1
271 0
2
0 116 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut4
3
0 0
141 1
273 0
2
0 118 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut40
3
0 0
141 1
275 0
2
0 120 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut41
3
0 0
141 1
277 0
2
0 122 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut42
3
0 0
141 1
279 0
2
0 124 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut43
3
0 0
141 1
281 0
2
0 126 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut44
3
0 0
141 1
283 0
2
0 128 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut45
3
0 0
141 1
285 0
2
0 130 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut46
3
0 0
141 1
287 0
2
0 132 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut47
3
0 0
141 1
289 0
2
0 134 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut48
3
0 0
141 1
291 0
2
0 136 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut49
3
0 0
141 1
293 0
2
0 138 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut5
3
0 0
141 1
295 0
2
0 140 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut50
3
0 0
141 1
297 0
2
0 142 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut51
3
0 0
141 1
299 0
2
0 144 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut52
3
0 0
141 1
301 0
2
0 146 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut53
3
0 0
141 1
303 0
2
0 148 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut54
3
0 0
141 1
305 0
2
0 150 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut55
3
0 0
141 1
307 0
2
0 152 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut56
3
0 0
141 1
309 0
2
0 154 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut57
3
0 0
141 1
311 0
2
0 156 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut58
3
0 0
141 1
313 0
2
0 158 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut59
3
0 0
141 1
315 0
2
0 160 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut6
3
0 0
141 1
317 0
2
0 162 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut60
3
0 0
141 1
319 0
2
0 164 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut61
3
0 0
141 1
321 0
2
0 166 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut62
3
0 0
141 1
323 0
2
0 168 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut63
3
0 0
141 1
325 0
2
0 170 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut7
3
0 0
141 1
327 0
2
0 172 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut8
3
0 0
141 1
329 0
2
0 174 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner71 bob nut9
3
0 0
141 1
331 0
2
0 176 0 1
0 348 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut1
3
0 0
143 1
207 0
2
0 52 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut10
3
0 0
143 1
209 0
2
0 54 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut11
3
0 0
143 1
211 0
2
0 56 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut12
3
0 0
143 1
213 0
2
0 58 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut13
3
0 0
143 1
215 0
2
0 60 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut14
3
0 0
143 1
217 0
2
0 62 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut15
3
0 0
143 1
219 0
2
0 64 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut16
3
0 0
143 1
221 0
2
0 66 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut17
3
0 0
143 1
223 0
2
0 68 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut18
3
0 0
143 1
225 0
2
0 70 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut19
3
0 0
143 1
227 0
2
0 72 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut2
3
0 0
143 1
229 0
2
0 74 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut20
3
0 0
143 1
231 0
2
0 76 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut21
3
0 0
143 1
233 0
2
0 78 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut22
3
0 0
143 1
235 0
2
0 80 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut23
3
0 0
143 1
237 0
2
0 82 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut24
3
0 0
143 1
239 0
2
0 84 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut25
3
0 0
143 1
241 0
2
0 86 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut26
3
0 0
143 1
243 0
2
0 88 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut27
3
0 0
143 1
245 0
2
0 90 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut28
3
0 0
143 1
247 0
2
0 92 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut29
3
0 0
143 1
249 0
2
0 94 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut3
3
0 0
143 1
251 0
2
0 96 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut30
3
0 0
143 1
253 0
2
0 98 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut31
3
0 0
143 1
255 0
2
0 100 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut32
3
0 0
143 1
257 0
2
0 102 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut33
3
0 0
143 1
259 0
2
0 104 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut34
3
0 0
143 1
261 0
2
0 106 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut35
3
0 0
143 1
263 0
2
0 108 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut36
3
0 0
143 1
265 0
2
0 110 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut37
3
0 0
143 1
267 0
2
0 112 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut38
3
0 0
143 1
269 0
2
0 114 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut39
3
0 0
143 1
271 0
2
0 116 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut4
3
0 0
143 1
273 0
2
0 118 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut40
3
0 0
143 1
275 0
2
0 120 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut41
3
0 0
143 1
277 0
2
0 122 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut42
3
0 0
143 1
279 0
2
0 124 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut43
3
0 0
143 1
281 0
2
0 126 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut44
3
0 0
143 1
283 0
2
0 128 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut45
3
0 0
143 1
285 0
2
0 130 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut46
3
0 0
143 1
287 0
2
0 132 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut47
3
0 0
143 1
289 0
2
0 134 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut48
3
0 0
143 1
291 0
2
0 136 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut49
3
0 0
143 1
293 0
2
0 138 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut5
3
0 0
143 1
295 0
2
0 140 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut50
3
0 0
143 1
297 0
2
0 142 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut51
3
0 0
143 1
299 0
2
0 144 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut52
3
0 0
143 1
301 0
2
0 146 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut53
3
0 0
143 1
303 0
2
0 148 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut54
3
0 0
143 1
305 0
2
0 150 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut55
3
0 0
143 1
307 0
2
0 152 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut56
3
0 0
143 1
309 0
2
0 154 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut57
3
0 0
143 1
311 0
2
0 156 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut58
3
0 0
143 1
313 0
2
0 158 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut59
3
0 0
143 1
315 0
2
0 160 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut6
3
0 0
143 1
317 0
2
0 162 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut60
3
0 0
143 1
319 0
2
0 164 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut61
3
0 0
143 1
321 0
2
0 166 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut62
3
0 0
143 1
323 0
2
0 168 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut63
3
0 0
143 1
325 0
2
0 170 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut7
3
0 0
143 1
327 0
2
0 172 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut8
3
0 0
143 1
329 0
2
0 174 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner72 bob nut9
3
0 0
143 1
331 0
2
0 176 0 1
0 349 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut1
3
0 0
145 1
207 0
2
0 52 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut10
3
0 0
145 1
209 0
2
0 54 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut11
3
0 0
145 1
211 0
2
0 56 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut12
3
0 0
145 1
213 0
2
0 58 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut13
3
0 0
145 1
215 0
2
0 60 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut14
3
0 0
145 1
217 0
2
0 62 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut15
3
0 0
145 1
219 0
2
0 64 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut16
3
0 0
145 1
221 0
2
0 66 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut17
3
0 0
145 1
223 0
2
0 68 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut18
3
0 0
145 1
225 0
2
0 70 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut19
3
0 0
145 1
227 0
2
0 72 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut2
3
0 0
145 1
229 0
2
0 74 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut20
3
0 0
145 1
231 0
2
0 76 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut21
3
0 0
145 1
233 0
2
0 78 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut22
3
0 0
145 1
235 0
2
0 80 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut23
3
0 0
145 1
237 0
2
0 82 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut24
3
0 0
145 1
239 0
2
0 84 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut25
3
0 0
145 1
241 0
2
0 86 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut26
3
0 0
145 1
243 0
2
0 88 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut27
3
0 0
145 1
245 0
2
0 90 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut28
3
0 0
145 1
247 0
2
0 92 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut29
3
0 0
145 1
249 0
2
0 94 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut3
3
0 0
145 1
251 0
2
0 96 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut30
3
0 0
145 1
253 0
2
0 98 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut31
3
0 0
145 1
255 0
2
0 100 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut32
3
0 0
145 1
257 0
2
0 102 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut33
3
0 0
145 1
259 0
2
0 104 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut34
3
0 0
145 1
261 0
2
0 106 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut35
3
0 0
145 1
263 0
2
0 108 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut36
3
0 0
145 1
265 0
2
0 110 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut37
3
0 0
145 1
267 0
2
0 112 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut38
3
0 0
145 1
269 0
2
0 114 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut39
3
0 0
145 1
271 0
2
0 116 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut4
3
0 0
145 1
273 0
2
0 118 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut40
3
0 0
145 1
275 0
2
0 120 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut41
3
0 0
145 1
277 0
2
0 122 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut42
3
0 0
145 1
279 0
2
0 124 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut43
3
0 0
145 1
281 0
2
0 126 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut44
3
0 0
145 1
283 0
2
0 128 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut45
3
0 0
145 1
285 0
2
0 130 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut46
3
0 0
145 1
287 0
2
0 132 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut47
3
0 0
145 1
289 0
2
0 134 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut48
3
0 0
145 1
291 0
2
0 136 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut49
3
0 0
145 1
293 0
2
0 138 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut5
3
0 0
145 1
295 0
2
0 140 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut50
3
0 0
145 1
297 0
2
0 142 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut51
3
0 0
145 1
299 0
2
0 144 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut52
3
0 0
145 1
301 0
2
0 146 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut53
3
0 0
145 1
303 0
2
0 148 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut54
3
0 0
145 1
305 0
2
0 150 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut55
3
0 0
145 1
307 0
2
0 152 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut56
3
0 0
145 1
309 0
2
0 154 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut57
3
0 0
145 1
311 0
2
0 156 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut58
3
0 0
145 1
313 0
2
0 158 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut59
3
0 0
145 1
315 0
2
0 160 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut6
3
0 0
145 1
317 0
2
0 162 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut60
3
0 0
145 1
319 0
2
0 164 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut61
3
0 0
145 1
321 0
2
0 166 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut62
3
0 0
145 1
323 0
2
0 168 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut63
3
0 0
145 1
325 0
2
0 170 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut7
3
0 0
145 1
327 0
2
0 172 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut8
3
0 0
145 1
329 0
2
0 174 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner73 bob nut9
3
0 0
145 1
331 0
2
0 176 0 1
0 350 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut1
3
0 0
147 1
207 0
2
0 52 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut10
3
0 0
147 1
209 0
2
0 54 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut11
3
0 0
147 1
211 0
2
0 56 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut12
3
0 0
147 1
213 0
2
0 58 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut13
3
0 0
147 1
215 0
2
0 60 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut14
3
0 0
147 1
217 0
2
0 62 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut15
3
0 0
147 1
219 0
2
0 64 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut16
3
0 0
147 1
221 0
2
0 66 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut17
3
0 0
147 1
223 0
2
0 68 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut18
3
0 0
147 1
225 0
2
0 70 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut19
3
0 0
147 1
227 0
2
0 72 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut2
3
0 0
147 1
229 0
2
0 74 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut20
3
0 0
147 1
231 0
2
0 76 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut21
3
0 0
147 1
233 0
2
0 78 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut22
3
0 0
147 1
235 0
2
0 80 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut23
3
0 0
147 1
237 0
2
0 82 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut24
3
0 0
147 1
239 0
2
0 84 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut25
3
0 0
147 1
241 0
2
0 86 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut26
3
0 0
147 1
243 0
2
0 88 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut27
3
0 0
147 1
245 0
2
0 90 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut28
3
0 0
147 1
247 0
2
0 92 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut29
3
0 0
147 1
249 0
2
0 94 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut3
3
0 0
147 1
251 0
2
0 96 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut30
3
0 0
147 1
253 0
2
0 98 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut31
3
0 0
147 1
255 0
2
0 100 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut32
3
0 0
147 1
257 0
2
0 102 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut33
3
0 0
147 1
259 0
2
0 104 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut34
3
0 0
147 1
261 0
2
0 106 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut35
3
0 0
147 1
263 0
2
0 108 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut36
3
0 0
147 1
265 0
2
0 110 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut37
3
0 0
147 1
267 0
2
0 112 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut38
3
0 0
147 1
269 0
2
0 114 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut39
3
0 0
147 1
271 0
2
0 116 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut4
3
0 0
147 1
273 0
2
0 118 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut40
3
0 0
147 1
275 0
2
0 120 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut41
3
0 0
147 1
277 0
2
0 122 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut42
3
0 0
147 1
279 0
2
0 124 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut43
3
0 0
147 1
281 0
2
0 126 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut44
3
0 0
147 1
283 0
2
0 128 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut45
3
0 0
147 1
285 0
2
0 130 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut46
3
0 0
147 1
287 0
2
0 132 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut47
3
0 0
147 1
289 0
2
0 134 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut48
3
0 0
147 1
291 0
2
0 136 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut49
3
0 0
147 1
293 0
2
0 138 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut5
3
0 0
147 1
295 0
2
0 140 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut50
3
0 0
147 1
297 0
2
0 142 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut51
3
0 0
147 1
299 0
2
0 144 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut52
3
0 0
147 1
301 0
2
0 146 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut53
3
0 0
147 1
303 0
2
0 148 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut54
3
0 0
147 1
305 0
2
0 150 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut55
3
0 0
147 1
307 0
2
0 152 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut56
3
0 0
147 1
309 0
2
0 154 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut57
3
0 0
147 1
311 0
2
0 156 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut58
3
0 0
147 1
313 0
2
0 158 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut59
3
0 0
147 1
315 0
2
0 160 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut6
3
0 0
147 1
317 0
2
0 162 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut60
3
0 0
147 1
319 0
2
0 164 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut61
3
0 0
147 1
321 0
2
0 166 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut62
3
0 0
147 1
323 0
2
0 168 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut63
3
0 0
147 1
325 0
2
0 170 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut7
3
0 0
147 1
327 0
2
0 172 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut8
3
0 0
147 1
329 0
2
0 174 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner74 bob nut9
3
0 0
147 1
331 0
2
0 176 0 1
0 351 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut1
3
0 0
149 1
207 0
2
0 52 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut10
3
0 0
149 1
209 0
2
0 54 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut11
3
0 0
149 1
211 0
2
0 56 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut12
3
0 0
149 1
213 0
2
0 58 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut13
3
0 0
149 1
215 0
2
0 60 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut14
3
0 0
149 1
217 0
2
0 62 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut15
3
0 0
149 1
219 0
2
0 64 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut16
3
0 0
149 1
221 0
2
0 66 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut17
3
0 0
149 1
223 0
2
0 68 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut18
3
0 0
149 1
225 0
2
0 70 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut19
3
0 0
149 1
227 0
2
0 72 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut2
3
0 0
149 1
229 0
2
0 74 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut20
3
0 0
149 1
231 0
2
0 76 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut21
3
0 0
149 1
233 0
2
0 78 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut22
3
0 0
149 1
235 0
2
0 80 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut23
3
0 0
149 1
237 0
2
0 82 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut24
3
0 0
149 1
239 0
2
0 84 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut25
3
0 0
149 1
241 0
2
0 86 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut26
3
0 0
149 1
243 0
2
0 88 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut27
3
0 0
149 1
245 0
2
0 90 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut28
3
0 0
149 1
247 0
2
0 92 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut29
3
0 0
149 1
249 0
2
0 94 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut3
3
0 0
149 1
251 0
2
0 96 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut30
3
0 0
149 1
253 0
2
0 98 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut31
3
0 0
149 1
255 0
2
0 100 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut32
3
0 0
149 1
257 0
2
0 102 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut33
3
0 0
149 1
259 0
2
0 104 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut34
3
0 0
149 1
261 0
2
0 106 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut35
3
0 0
149 1
263 0
2
0 108 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut36
3
0 0
149 1
265 0
2
0 110 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut37
3
0 0
149 1
267 0
2
0 112 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut38
3
0 0
149 1
269 0
2
0 114 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut39
3
0 0
149 1
271 0
2
0 116 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut4
3
0 0
149 1
273 0
2
0 118 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut40
3
0 0
149 1
275 0
2
0 120 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut41
3
0 0
149 1
277 0
2
0 122 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut42
3
0 0
149 1
279 0
2
0 124 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut43
3
0 0
149 1
281 0
2
0 126 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut44
3
0 0
149 1
283 0
2
0 128 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut45
3
0 0
149 1
285 0
2
0 130 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut46
3
0 0
149 1
287 0
2
0 132 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut47
3
0 0
149 1
289 0
2
0 134 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut48
3
0 0
149 1
291 0
2
0 136 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut49
3
0 0
149 1
293 0
2
0 138 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut5
3
0 0
149 1
295 0
2
0 140 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut50
3
0 0
149 1
297 0
2
0 142 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut51
3
0 0
149 1
299 0
2
0 144 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut52
3
0 0
149 1
301 0
2
0 146 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut53
3
0 0
149 1
303 0
2
0 148 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut54
3
0 0
149 1
305 0
2
0 150 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut55
3
0 0
149 1
307 0
2
0 152 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut56
3
0 0
149 1
309 0
2
0 154 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut57
3
0 0
149 1
311 0
2
0 156 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut58
3
0 0
149 1
313 0
2
0 158 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut59
3
0 0
149 1
315 0
2
0 160 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut6
3
0 0
149 1
317 0
2
0 162 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut60
3
0 0
149 1
319 0
2
0 164 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut61
3
0 0
149 1
321 0
2
0 166 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut62
3
0 0
149 1
323 0
2
0 168 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut63
3
0 0
149 1
325 0
2
0 170 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut7
3
0 0
149 1
327 0
2
0 172 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut8
3
0 0
149 1
329 0
2
0 174 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner75 bob nut9
3
0 0
149 1
331 0
2
0 176 0 1
0 352 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut1
3
0 0
151 1
207 0
2
0 52 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut10
3
0 0
151 1
209 0
2
0 54 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut11
3
0 0
151 1
211 0
2
0 56 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut12
3
0 0
151 1
213 0
2
0 58 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut13
3
0 0
151 1
215 0
2
0 60 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut14
3
0 0
151 1
217 0
2
0 62 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut15
3
0 0
151 1
219 0
2
0 64 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut16
3
0 0
151 1
221 0
2
0 66 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut17
3
0 0
151 1
223 0
2
0 68 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut18
3
0 0
151 1
225 0
2
0 70 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut19
3
0 0
151 1
227 0
2
0 72 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut2
3
0 0
151 1
229 0
2
0 74 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut20
3
0 0
151 1
231 0
2
0 76 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut21
3
0 0
151 1
233 0
2
0 78 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut22
3
0 0
151 1
235 0
2
0 80 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut23
3
0 0
151 1
237 0
2
0 82 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut24
3
0 0
151 1
239 0
2
0 84 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut25
3
0 0
151 1
241 0
2
0 86 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut26
3
0 0
151 1
243 0
2
0 88 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut27
3
0 0
151 1
245 0
2
0 90 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut28
3
0 0
151 1
247 0
2
0 92 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut29
3
0 0
151 1
249 0
2
0 94 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut3
3
0 0
151 1
251 0
2
0 96 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut30
3
0 0
151 1
253 0
2
0 98 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut31
3
0 0
151 1
255 0
2
0 100 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut32
3
0 0
151 1
257 0
2
0 102 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut33
3
0 0
151 1
259 0
2
0 104 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut34
3
0 0
151 1
261 0
2
0 106 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut35
3
0 0
151 1
263 0
2
0 108 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut36
3
0 0
151 1
265 0
2
0 110 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut37
3
0 0
151 1
267 0
2
0 112 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut38
3
0 0
151 1
269 0
2
0 114 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut39
3
0 0
151 1
271 0
2
0 116 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut4
3
0 0
151 1
273 0
2
0 118 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut40
3
0 0
151 1
275 0
2
0 120 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut41
3
0 0
151 1
277 0
2
0 122 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut42
3
0 0
151 1
279 0
2
0 124 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut43
3
0 0
151 1
281 0
2
0 126 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut44
3
0 0
151 1
283 0
2
0 128 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut45
3
0 0
151 1
285 0
2
0 130 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut46
3
0 0
151 1
287 0
2
0 132 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut47
3
0 0
151 1
289 0
2
0 134 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut48
3
0 0
151 1
291 0
2
0 136 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut49
3
0 0
151 1
293 0
2
0 138 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut5
3
0 0
151 1
295 0
2
0 140 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut50
3
0 0
151 1
297 0
2
0 142 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut51
3
0 0
151 1
299 0
2
0 144 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut52
3
0 0
151 1
301 0
2
0 146 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut53
3
0 0
151 1
303 0
2
0 148 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut54
3
0 0
151 1
305 0
2
0 150 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut55
3
0 0
151 1
307 0
2
0 152 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut56
3
0 0
151 1
309 0
2
0 154 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut57
3
0 0
151 1
311 0
2
0 156 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut58
3
0 0
151 1
313 0
2
0 158 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut59
3
0 0
151 1
315 0
2
0 160 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut6
3
0 0
151 1
317 0
2
0 162 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut60
3
0 0
151 1
319 0
2
0 164 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut61
3
0 0
151 1
321 0
2
0 166 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut62
3
0 0
151 1
323 0
2
0 168 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut63
3
0 0
151 1
325 0
2
0 170 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut7
3
0 0
151 1
327 0
2
0 172 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut8
3
0 0
151 1
329 0
2
0 174 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner76 bob nut9
3
0 0
151 1
331 0
2
0 176 0 1
0 353 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut1
3
0 0
153 1
207 0
2
0 52 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut10
3
0 0
153 1
209 0
2
0 54 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut11
3
0 0
153 1
211 0
2
0 56 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut12
3
0 0
153 1
213 0
2
0 58 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut13
3
0 0
153 1
215 0
2
0 60 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut14
3
0 0
153 1
217 0
2
0 62 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut15
3
0 0
153 1
219 0
2
0 64 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut16
3
0 0
153 1
221 0
2
0 66 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut17
3
0 0
153 1
223 0
2
0 68 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut18
3
0 0
153 1
225 0
2
0 70 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut19
3
0 0
153 1
227 0
2
0 72 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut2
3
0 0
153 1
229 0
2
0 74 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut20
3
0 0
153 1
231 0
2
0 76 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut21
3
0 0
153 1
233 0
2
0 78 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut22
3
0 0
153 1
235 0
2
0 80 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut23
3
0 0
153 1
237 0
2
0 82 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut24
3
0 0
153 1
239 0
2
0 84 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut25
3
0 0
153 1
241 0
2
0 86 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut26
3
0 0
153 1
243 0
2
0 88 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut27
3
0 0
153 1
245 0
2
0 90 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut28
3
0 0
153 1
247 0
2
0 92 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut29
3
0 0
153 1
249 0
2
0 94 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut3
3
0 0
153 1
251 0
2
0 96 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut30
3
0 0
153 1
253 0
2
0 98 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut31
3
0 0
153 1
255 0
2
0 100 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut32
3
0 0
153 1
257 0
2
0 102 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut33
3
0 0
153 1
259 0
2
0 104 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut34
3
0 0
153 1
261 0
2
0 106 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut35
3
0 0
153 1
263 0
2
0 108 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut36
3
0 0
153 1
265 0
2
0 110 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut37
3
0 0
153 1
267 0
2
0 112 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut38
3
0 0
153 1
269 0
2
0 114 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut39
3
0 0
153 1
271 0
2
0 116 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut4
3
0 0
153 1
273 0
2
0 118 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut40
3
0 0
153 1
275 0
2
0 120 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut41
3
0 0
153 1
277 0
2
0 122 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut42
3
0 0
153 1
279 0
2
0 124 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut43
3
0 0
153 1
281 0
2
0 126 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut44
3
0 0
153 1
283 0
2
0 128 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut45
3
0 0
153 1
285 0
2
0 130 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut46
3
0 0
153 1
287 0
2
0 132 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut47
3
0 0
153 1
289 0
2
0 134 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut48
3
0 0
153 1
291 0
2
0 136 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut49
3
0 0
153 1
293 0
2
0 138 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut5
3
0 0
153 1
295 0
2
0 140 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut50
3
0 0
153 1
297 0
2
0 142 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut51
3
0 0
153 1
299 0
2
0 144 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut52
3
0 0
153 1
301 0
2
0 146 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut53
3
0 0
153 1
303 0
2
0 148 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut54
3
0 0
153 1
305 0
2
0 150 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut55
3
0 0
153 1
307 0
2
0 152 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut56
3
0 0
153 1
309 0
2
0 154 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut57
3
0 0
153 1
311 0
2
0 156 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut58
3
0 0
153 1
313 0
2
0 158 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut59
3
0 0
153 1
315 0
2
0 160 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut6
3
0 0
153 1
317 0
2
0 162 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut60
3
0 0
153 1
319 0
2
0 164 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut61
3
0 0
153 1
321 0
2
0 166 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut62
3
0 0
153 1
323 0
2
0 168 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut63
3
0 0
153 1
325 0
2
0 170 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut7
3
0 0
153 1
327 0
2
0 172 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut8
3
0 0
153 1
329 0
2
0 174 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner77 bob nut9
3
0 0
153 1
331 0
2
0 176 0 1
0 354 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut1
3
0 0
155 1
207 0
2
0 52 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut10
3
0 0
155 1
209 0
2
0 54 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut11
3
0 0
155 1
211 0
2
0 56 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut12
3
0 0
155 1
213 0
2
0 58 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut13
3
0 0
155 1
215 0
2
0 60 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut14
3
0 0
155 1
217 0
2
0 62 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut15
3
0 0
155 1
219 0
2
0 64 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut16
3
0 0
155 1
221 0
2
0 66 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut17
3
0 0
155 1
223 0
2
0 68 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut18
3
0 0
155 1
225 0
2
0 70 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut19
3
0 0
155 1
227 0
2
0 72 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut2
3
0 0
155 1
229 0
2
0 74 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut20
3
0 0
155 1
231 0
2
0 76 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut21
3
0 0
155 1
233 0
2
0 78 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut22
3
0 0
155 1
235 0
2
0 80 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut23
3
0 0
155 1
237 0
2
0 82 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut24
3
0 0
155 1
239 0
2
0 84 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut25
3
0 0
155 1
241 0
2
0 86 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut26
3
0 0
155 1
243 0
2
0 88 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut27
3
0 0
155 1
245 0
2
0 90 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut28
3
0 0
155 1
247 0
2
0 92 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut29
3
0 0
155 1
249 0
2
0 94 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut3
3
0 0
155 1
251 0
2
0 96 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut30
3
0 0
155 1
253 0
2
0 98 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut31
3
0 0
155 1
255 0
2
0 100 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut32
3
0 0
155 1
257 0
2
0 102 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut33
3
0 0
155 1
259 0
2
0 104 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut34
3
0 0
155 1
261 0
2
0 106 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut35
3
0 0
155 1
263 0
2
0 108 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut36
3
0 0
155 1
265 0
2
0 110 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut37
3
0 0
155 1
267 0
2
0 112 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut38
3
0 0
155 1
269 0
2
0 114 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut39
3
0 0
155 1
271 0
2
0 116 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut4
3
0 0
155 1
273 0
2
0 118 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut40
3
0 0
155 1
275 0
2
0 120 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut41
3
0 0
155 1
277 0
2
0 122 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut42
3
0 0
155 1
279 0
2
0 124 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut43
3
0 0
155 1
281 0
2
0 126 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut44
3
0 0
155 1
283 0
2
0 128 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut45
3
0 0
155 1
285 0
2
0 130 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut46
3
0 0
155 1
287 0
2
0 132 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut47
3
0 0
155 1
289 0
2
0 134 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut48
3
0 0
155 1
291 0
2
0 136 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut49
3
0 0
155 1
293 0
2
0 138 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut5
3
0 0
155 1
295 0
2
0 140 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut50
3
0 0
155 1
297 0
2
0 142 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut51
3
0 0
155 1
299 0
2
0 144 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut52
3
0 0
155 1
301 0
2
0 146 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut53
3
0 0
155 1
303 0
2
0 148 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut54
3
0 0
155 1
305 0
2
0 150 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut55
3
0 0
155 1
307 0
2
0 152 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut56
3
0 0
155 1
309 0
2
0 154 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut57
3
0 0
155 1
311 0
2
0 156 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut58
3
0 0
155 1
313 0
2
0 158 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut59
3
0 0
155 1
315 0
2
0 160 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut6
3
0 0
155 1
317 0
2
0 162 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut60
3
0 0
155 1
319 0
2
0 164 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut61
3
0 0
155 1
321 0
2
0 166 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut62
3
0 0
155 1
323 0
2
0 168 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut63
3
0 0
155 1
325 0
2
0 170 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut7
3
0 0
155 1
327 0
2
0 172 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut8
3
0 0
155 1
329 0
2
0 174 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner78 bob nut9
3
0 0
155 1
331 0
2
0 176 0 1
0 355 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut1
3
0 0
157 1
207 0
2
0 52 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut10
3
0 0
157 1
209 0
2
0 54 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut11
3
0 0
157 1
211 0
2
0 56 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut12
3
0 0
157 1
213 0
2
0 58 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut13
3
0 0
157 1
215 0
2
0 60 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut14
3
0 0
157 1
217 0
2
0 62 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut15
3
0 0
157 1
219 0
2
0 64 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut16
3
0 0
157 1
221 0
2
0 66 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut17
3
0 0
157 1
223 0
2
0 68 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut18
3
0 0
157 1
225 0
2
0 70 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut19
3
0 0
157 1
227 0
2
0 72 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut2
3
0 0
157 1
229 0
2
0 74 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut20
3
0 0
157 1
231 0
2
0 76 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut21
3
0 0
157 1
233 0
2
0 78 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut22
3
0 0
157 1
235 0
2
0 80 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut23
3
0 0
157 1
237 0
2
0 82 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut24
3
0 0
157 1
239 0
2
0 84 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut25
3
0 0
157 1
241 0
2
0 86 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut26
3
0 0
157 1
243 0
2
0 88 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut27
3
0 0
157 1
245 0
2
0 90 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut28
3
0 0
157 1
247 0
2
0 92 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut29
3
0 0
157 1
249 0
2
0 94 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut3
3
0 0
157 1
251 0
2
0 96 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut30
3
0 0
157 1
253 0
2
0 98 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut31
3
0 0
157 1
255 0
2
0 100 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut32
3
0 0
157 1
257 0
2
0 102 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut33
3
0 0
157 1
259 0
2
0 104 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut34
3
0 0
157 1
261 0
2
0 106 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut35
3
0 0
157 1
263 0
2
0 108 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut36
3
0 0
157 1
265 0
2
0 110 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut37
3
0 0
157 1
267 0
2
0 112 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut38
3
0 0
157 1
269 0
2
0 114 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut39
3
0 0
157 1
271 0
2
0 116 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut4
3
0 0
157 1
273 0
2
0 118 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut40
3
0 0
157 1
275 0
2
0 120 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut41
3
0 0
157 1
277 0
2
0 122 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut42
3
0 0
157 1
279 0
2
0 124 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut43
3
0 0
157 1
281 0
2
0 126 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut44
3
0 0
157 1
283 0
2
0 128 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut45
3
0 0
157 1
285 0
2
0 130 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut46
3
0 0
157 1
287 0
2
0 132 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut47
3
0 0
157 1
289 0
2
0 134 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut48
3
0 0
157 1
291 0
2
0 136 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut49
3
0 0
157 1
293 0
2
0 138 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut5
3
0 0
157 1
295 0
2
0 140 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut50
3
0 0
157 1
297 0
2
0 142 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut51
3
0 0
157 1
299 0
2
0 144 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut52
3
0 0
157 1
301 0
2
0 146 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut53
3
0 0
157 1
303 0
2
0 148 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut54
3
0 0
157 1
305 0
2
0 150 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut55
3
0 0
157 1
307 0
2
0 152 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut56
3
0 0
157 1
309 0
2
0 154 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut57
3
0 0
157 1
311 0
2
0 156 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut58
3
0 0
157 1
313 0
2
0 158 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut59
3
0 0
157 1
315 0
2
0 160 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut6
3
0 0
157 1
317 0
2
0 162 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut60
3
0 0
157 1
319 0
2
0 164 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut61
3
0 0
157 1
321 0
2
0 166 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut62
3
0 0
157 1
323 0
2
0 168 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut63
3
0 0
157 1
325 0
2
0 170 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut7
3
0 0
157 1
327 0
2
0 172 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut8
3
0 0
157 1
329 0
2
0 174 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner79 bob nut9
3
0 0
157 1
331 0
2
0 176 0 1
0 356 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut1
3
0 0
159 1
207 0
2
0 52 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut10
3
0 0
159 1
209 0
2
0 54 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut11
3
0 0
159 1
211 0
2
0 56 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut12
3
0 0
159 1
213 0
2
0 58 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut13
3
0 0
159 1
215 0
2
0 60 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut14
3
0 0
159 1
217 0
2
0 62 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut15
3
0 0
159 1
219 0
2
0 64 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut16
3
0 0
159 1
221 0
2
0 66 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut17
3
0 0
159 1
223 0
2
0 68 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut18
3
0 0
159 1
225 0
2
0 70 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut19
3
0 0
159 1
227 0
2
0 72 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut2
3
0 0
159 1
229 0
2
0 74 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut20
3
0 0
159 1
231 0
2
0 76 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut21
3
0 0
159 1
233 0
2
0 78 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut22
3
0 0
159 1
235 0
2
0 80 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut23
3
0 0
159 1
237 0
2
0 82 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut24
3
0 0
159 1
239 0
2
0 84 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut25
3
0 0
159 1
241 0
2
0 86 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut26
3
0 0
159 1
243 0
2
0 88 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut27
3
0 0
159 1
245 0
2
0 90 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut28
3
0 0
159 1
247 0
2
0 92 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut29
3
0 0
159 1
249 0
2
0 94 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut3
3
0 0
159 1
251 0
2
0 96 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut30
3
0 0
159 1
253 0
2
0 98 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut31
3
0 0
159 1
255 0
2
0 100 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut32
3
0 0
159 1
257 0
2
0 102 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut33
3
0 0
159 1
259 0
2
0 104 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut34
3
0 0
159 1
261 0
2
0 106 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut35
3
0 0
159 1
263 0
2
0 108 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut36
3
0 0
159 1
265 0
2
0 110 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut37
3
0 0
159 1
267 0
2
0 112 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut38
3
0 0
159 1
269 0
2
0 114 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut39
3
0 0
159 1
271 0
2
0 116 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut4
3
0 0
159 1
273 0
2
0 118 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut40
3
0 0
159 1
275 0
2
0 120 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut41
3
0 0
159 1
277 0
2
0 122 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut42
3
0 0
159 1
279 0
2
0 124 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut43
3
0 0
159 1
281 0
2
0 126 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut44
3
0 0
159 1
283 0
2
0 128 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut45
3
0 0
159 1
285 0
2
0 130 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut46
3
0 0
159 1
287 0
2
0 132 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut47
3
0 0
159 1
289 0
2
0 134 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut48
3
0 0
159 1
291 0
2
0 136 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut49
3
0 0
159 1
293 0
2
0 138 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut5
3
0 0
159 1
295 0
2
0 140 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut50
3
0 0
159 1
297 0
2
0 142 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut51
3
0 0
159 1
299 0
2
0 144 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut52
3
0 0
159 1
301 0
2
0 146 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut53
3
0 0
159 1
303 0
2
0 148 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut54
3
0 0
159 1
305 0
2
0 150 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut55
3
0 0
159 1
307 0
2
0 152 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut56
3
0 0
159 1
309 0
2
0 154 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut57
3
0 0
159 1
311 0
2
0 156 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut58
3
0 0
159 1
313 0
2
0 158 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut59
3
0 0
159 1
315 0
2
0 160 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut6
3
0 0
159 1
317 0
2
0 162 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut60
3
0 0
159 1
319 0
2
0 164 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut61
3
0 0
159 1
321 0
2
0 166 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut62
3
0 0
159 1
323 0
2
0 168 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut63
3
0 0
159 1
325 0
2
0 170 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut7
3
0 0
159 1
327 0
2
0 172 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut8
3
0 0
159 1
329 0
2
0 174 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner8 bob nut9
3
0 0
159 1
331 0
2
0 176 0 1
0 357 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut1
3
0 0
161 1
207 0
2
0 52 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut10
3
0 0
161 1
209 0
2
0 54 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut11
3
0 0
161 1
211 0
2
0 56 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut12
3
0 0
161 1
213 0
2
0 58 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut13
3
0 0
161 1
215 0
2
0 60 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut14
3
0 0
161 1
217 0
2
0 62 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut15
3
0 0
161 1
219 0
2
0 64 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut16
3
0 0
161 1
221 0
2
0 66 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut17
3
0 0
161 1
223 0
2
0 68 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut18
3
0 0
161 1
225 0
2
0 70 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut19
3
0 0
161 1
227 0
2
0 72 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut2
3
0 0
161 1
229 0
2
0 74 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut20
3
0 0
161 1
231 0
2
0 76 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut21
3
0 0
161 1
233 0
2
0 78 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut22
3
0 0
161 1
235 0
2
0 80 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut23
3
0 0
161 1
237 0
2
0 82 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut24
3
0 0
161 1
239 0
2
0 84 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut25
3
0 0
161 1
241 0
2
0 86 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut26
3
0 0
161 1
243 0
2
0 88 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut27
3
0 0
161 1
245 0
2
0 90 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut28
3
0 0
161 1
247 0
2
0 92 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut29
3
0 0
161 1
249 0
2
0 94 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut3
3
0 0
161 1
251 0
2
0 96 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut30
3
0 0
161 1
253 0
2
0 98 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut31
3
0 0
161 1
255 0
2
0 100 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut32
3
0 0
161 1
257 0
2
0 102 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut33
3
0 0
161 1
259 0
2
0 104 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut34
3
0 0
161 1
261 0
2
0 106 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut35
3
0 0
161 1
263 0
2
0 108 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut36
3
0 0
161 1
265 0
2
0 110 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut37
3
0 0
161 1
267 0
2
0 112 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut38
3
0 0
161 1
269 0
2
0 114 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut39
3
0 0
161 1
271 0
2
0 116 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut4
3
0 0
161 1
273 0
2
0 118 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut40
3
0 0
161 1
275 0
2
0 120 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut41
3
0 0
161 1
277 0
2
0 122 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut42
3
0 0
161 1
279 0
2
0 124 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut43
3
0 0
161 1
281 0
2
0 126 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut44
3
0 0
161 1
283 0
2
0 128 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut45
3
0 0
161 1
285 0
2
0 130 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut46
3
0 0
161 1
287 0
2
0 132 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut47
3
0 0
161 1
289 0
2
0 134 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut48
3
0 0
161 1
291 0
2
0 136 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut49
3
0 0
161 1
293 0
2
0 138 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut5
3
0 0
161 1
295 0
2
0 140 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut50
3
0 0
161 1
297 0
2
0 142 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut51
3
0 0
161 1
299 0
2
0 144 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut52
3
0 0
161 1
301 0
2
0 146 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut53
3
0 0
161 1
303 0
2
0 148 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut54
3
0 0
161 1
305 0
2
0 150 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut55
3
0 0
161 1
307 0
2
0 152 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut56
3
0 0
161 1
309 0
2
0 154 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut57
3
0 0
161 1
311 0
2
0 156 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut58
3
0 0
161 1
313 0
2
0 158 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut59
3
0 0
161 1
315 0
2
0 160 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut6
3
0 0
161 1
317 0
2
0 162 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut60
3
0 0
161 1
319 0
2
0 164 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut61
3
0 0
161 1
321 0
2
0 166 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut62
3
0 0
161 1
323 0
2
0 168 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut63
3
0 0
161 1
325 0
2
0 170 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut7
3
0 0
161 1
327 0
2
0 172 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut8
3
0 0
161 1
329 0
2
0 174 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner80 bob nut9
3
0 0
161 1
331 0
2
0 176 0 1
0 358 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut1
3
0 0
163 1
207 0
2
0 52 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut10
3
0 0
163 1
209 0
2
0 54 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut11
3
0 0
163 1
211 0
2
0 56 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut12
3
0 0
163 1
213 0
2
0 58 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut13
3
0 0
163 1
215 0
2
0 60 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut14
3
0 0
163 1
217 0
2
0 62 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut15
3
0 0
163 1
219 0
2
0 64 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut16
3
0 0
163 1
221 0
2
0 66 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut17
3
0 0
163 1
223 0
2
0 68 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut18
3
0 0
163 1
225 0
2
0 70 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut19
3
0 0
163 1
227 0
2
0 72 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut2
3
0 0
163 1
229 0
2
0 74 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut20
3
0 0
163 1
231 0
2
0 76 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut21
3
0 0
163 1
233 0
2
0 78 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut22
3
0 0
163 1
235 0
2
0 80 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut23
3
0 0
163 1
237 0
2
0 82 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut24
3
0 0
163 1
239 0
2
0 84 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut25
3
0 0
163 1
241 0
2
0 86 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut26
3
0 0
163 1
243 0
2
0 88 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut27
3
0 0
163 1
245 0
2
0 90 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut28
3
0 0
163 1
247 0
2
0 92 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut29
3
0 0
163 1
249 0
2
0 94 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut3
3
0 0
163 1
251 0
2
0 96 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut30
3
0 0
163 1
253 0
2
0 98 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut31
3
0 0
163 1
255 0
2
0 100 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut32
3
0 0
163 1
257 0
2
0 102 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut33
3
0 0
163 1
259 0
2
0 104 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut34
3
0 0
163 1
261 0
2
0 106 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut35
3
0 0
163 1
263 0
2
0 108 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut36
3
0 0
163 1
265 0
2
0 110 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut37
3
0 0
163 1
267 0
2
0 112 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut38
3
0 0
163 1
269 0
2
0 114 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut39
3
0 0
163 1
271 0
2
0 116 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut4
3
0 0
163 1
273 0
2
0 118 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut40
3
0 0
163 1
275 0
2
0 120 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut41
3
0 0
163 1
277 0
2
0 122 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut42
3
0 0
163 1
279 0
2
0 124 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut43
3
0 0
163 1
281 0
2
0 126 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut44
3
0 0
163 1
283 0
2
0 128 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut45
3
0 0
163 1
285 0
2
0 130 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut46
3
0 0
163 1
287 0
2
0 132 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut47
3
0 0
163 1
289 0
2
0 134 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut48
3
0 0
163 1
291 0
2
0 136 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut49
3
0 0
163 1
293 0
2
0 138 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut5
3
0 0
163 1
295 0
2
0 140 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut50
3
0 0
163 1
297 0
2
0 142 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut51
3
0 0
163 1
299 0
2
0 144 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut52
3
0 0
163 1
301 0
2
0 146 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut53
3
0 0
163 1
303 0
2
0 148 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut54
3
0 0
163 1
305 0
2
0 150 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut55
3
0 0
163 1
307 0
2
0 152 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut56
3
0 0
163 1
309 0
2
0 154 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut57
3
0 0
163 1
311 0
2
0 156 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut58
3
0 0
163 1
313 0
2
0 158 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut59
3
0 0
163 1
315 0
2
0 160 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut6
3
0 0
163 1
317 0
2
0 162 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut60
3
0 0
163 1
319 0
2
0 164 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut61
3
0 0
163 1
321 0
2
0 166 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut62
3
0 0
163 1
323 0
2
0 168 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut63
3
0 0
163 1
325 0
2
0 170 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut7
3
0 0
163 1
327 0
2
0 172 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut8
3
0 0
163 1
329 0
2
0 174 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner81 bob nut9
3
0 0
163 1
331 0
2
0 176 0 1
0 359 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut1
3
0 0
165 1
207 0
2
0 52 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut10
3
0 0
165 1
209 0
2
0 54 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut11
3
0 0
165 1
211 0
2
0 56 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut12
3
0 0
165 1
213 0
2
0 58 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut13
3
0 0
165 1
215 0
2
0 60 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut14
3
0 0
165 1
217 0
2
0 62 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut15
3
0 0
165 1
219 0
2
0 64 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut16
3
0 0
165 1
221 0
2
0 66 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut17
3
0 0
165 1
223 0
2
0 68 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut18
3
0 0
165 1
225 0
2
0 70 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut19
3
0 0
165 1
227 0
2
0 72 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut2
3
0 0
165 1
229 0
2
0 74 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut20
3
0 0
165 1
231 0
2
0 76 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut21
3
0 0
165 1
233 0
2
0 78 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut22
3
0 0
165 1
235 0
2
0 80 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut23
3
0 0
165 1
237 0
2
0 82 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut24
3
0 0
165 1
239 0
2
0 84 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut25
3
0 0
165 1
241 0
2
0 86 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut26
3
0 0
165 1
243 0
2
0 88 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut27
3
0 0
165 1
245 0
2
0 90 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut28
3
0 0
165 1
247 0
2
0 92 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut29
3
0 0
165 1
249 0
2
0 94 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut3
3
0 0
165 1
251 0
2
0 96 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut30
3
0 0
165 1
253 0
2
0 98 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut31
3
0 0
165 1
255 0
2
0 100 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut32
3
0 0
165 1
257 0
2
0 102 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut33
3
0 0
165 1
259 0
2
0 104 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut34
3
0 0
165 1
261 0
2
0 106 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut35
3
0 0
165 1
263 0
2
0 108 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut36
3
0 0
165 1
265 0
2
0 110 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut37
3
0 0
165 1
267 0
2
0 112 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut38
3
0 0
165 1
269 0
2
0 114 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut39
3
0 0
165 1
271 0
2
0 116 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut4
3
0 0
165 1
273 0
2
0 118 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut40
3
0 0
165 1
275 0
2
0 120 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut41
3
0 0
165 1
277 0
2
0 122 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut42
3
0 0
165 1
279 0
2
0 124 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut43
3
0 0
165 1
281 0
2
0 126 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut44
3
0 0
165 1
283 0
2
0 128 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut45
3
0 0
165 1
285 0
2
0 130 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut46
3
0 0
165 1
287 0
2
0 132 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut47
3
0 0
165 1
289 0
2
0 134 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut48
3
0 0
165 1
291 0
2
0 136 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut49
3
0 0
165 1
293 0
2
0 138 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut5
3
0 0
165 1
295 0
2
0 140 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut50
3
0 0
165 1
297 0
2
0 142 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut51
3
0 0
165 1
299 0
2
0 144 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut52
3
0 0
165 1
301 0
2
0 146 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut53
3
0 0
165 1
303 0
2
0 148 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut54
3
0 0
165 1
305 0
2
0 150 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut55
3
0 0
165 1
307 0
2
0 152 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut56
3
0 0
165 1
309 0
2
0 154 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut57
3
0 0
165 1
311 0
2
0 156 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut58
3
0 0
165 1
313 0
2
0 158 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut59
3
0 0
165 1
315 0
2
0 160 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut6
3
0 0
165 1
317 0
2
0 162 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut60
3
0 0
165 1
319 0
2
0 164 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut61
3
0 0
165 1
321 0
2
0 166 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut62
3
0 0
165 1
323 0
2
0 168 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut63
3
0 0
165 1
325 0
2
0 170 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut7
3
0 0
165 1
327 0
2
0 172 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut8
3
0 0
165 1
329 0
2
0 174 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner82 bob nut9
3
0 0
165 1
331 0
2
0 176 0 1
0 360 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut1
3
0 0
167 1
207 0
2
0 52 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut10
3
0 0
167 1
209 0
2
0 54 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut11
3
0 0
167 1
211 0
2
0 56 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut12
3
0 0
167 1
213 0
2
0 58 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut13
3
0 0
167 1
215 0
2
0 60 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut14
3
0 0
167 1
217 0
2
0 62 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut15
3
0 0
167 1
219 0
2
0 64 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut16
3
0 0
167 1
221 0
2
0 66 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut17
3
0 0
167 1
223 0
2
0 68 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut18
3
0 0
167 1
225 0
2
0 70 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut19
3
0 0
167 1
227 0
2
0 72 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut2
3
0 0
167 1
229 0
2
0 74 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut20
3
0 0
167 1
231 0
2
0 76 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut21
3
0 0
167 1
233 0
2
0 78 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut22
3
0 0
167 1
235 0
2
0 80 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut23
3
0 0
167 1
237 0
2
0 82 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut24
3
0 0
167 1
239 0
2
0 84 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut25
3
0 0
167 1
241 0
2
0 86 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut26
3
0 0
167 1
243 0
2
0 88 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut27
3
0 0
167 1
245 0
2
0 90 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut28
3
0 0
167 1
247 0
2
0 92 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut29
3
0 0
167 1
249 0
2
0 94 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut3
3
0 0
167 1
251 0
2
0 96 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut30
3
0 0
167 1
253 0
2
0 98 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut31
3
0 0
167 1
255 0
2
0 100 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut32
3
0 0
167 1
257 0
2
0 102 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut33
3
0 0
167 1
259 0
2
0 104 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut34
3
0 0
167 1
261 0
2
0 106 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut35
3
0 0
167 1
263 0
2
0 108 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut36
3
0 0
167 1
265 0
2
0 110 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut37
3
0 0
167 1
267 0
2
0 112 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut38
3
0 0
167 1
269 0
2
0 114 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut39
3
0 0
167 1
271 0
2
0 116 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut4
3
0 0
167 1
273 0
2
0 118 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut40
3
0 0
167 1
275 0
2
0 120 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut41
3
0 0
167 1
277 0
2
0 122 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut42
3
0 0
167 1
279 0
2
0 124 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut43
3
0 0
167 1
281 0
2
0 126 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut44
3
0 0
167 1
283 0
2
0 128 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut45
3
0 0
167 1
285 0
2
0 130 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut46
3
0 0
167 1
287 0
2
0 132 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut47
3
0 0
167 1
289 0
2
0 134 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut48
3
0 0
167 1
291 0
2
0 136 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut49
3
0 0
167 1
293 0
2
0 138 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut5
3
0 0
167 1
295 0
2
0 140 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut50
3
0 0
167 1
297 0
2
0 142 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut51
3
0 0
167 1
299 0
2
0 144 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut52
3
0 0
167 1
301 0
2
0 146 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut53
3
0 0
167 1
303 0
2
0 148 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut54
3
0 0
167 1
305 0
2
0 150 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut55
3
0 0
167 1
307 0
2
0 152 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut56
3
0 0
167 1
309 0
2
0 154 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut57
3
0 0
167 1
311 0
2
0 156 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut58
3
0 0
167 1
313 0
2
0 158 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut59
3
0 0
167 1
315 0
2
0 160 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut6
3
0 0
167 1
317 0
2
0 162 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut60
3
0 0
167 1
319 0
2
0 164 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut61
3
0 0
167 1
321 0
2
0 166 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut62
3
0 0
167 1
323 0
2
0 168 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut63
3
0 0
167 1
325 0
2
0 170 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut7
3
0 0
167 1
327 0
2
0 172 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut8
3
0 0
167 1
329 0
2
0 174 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner83 bob nut9
3
0 0
167 1
331 0
2
0 176 0 1
0 361 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut1
3
0 0
169 1
207 0
2
0 52 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut10
3
0 0
169 1
209 0
2
0 54 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut11
3
0 0
169 1
211 0
2
0 56 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut12
3
0 0
169 1
213 0
2
0 58 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut13
3
0 0
169 1
215 0
2
0 60 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut14
3
0 0
169 1
217 0
2
0 62 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut15
3
0 0
169 1
219 0
2
0 64 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut16
3
0 0
169 1
221 0
2
0 66 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut17
3
0 0
169 1
223 0
2
0 68 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut18
3
0 0
169 1
225 0
2
0 70 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut19
3
0 0
169 1
227 0
2
0 72 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut2
3
0 0
169 1
229 0
2
0 74 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut20
3
0 0
169 1
231 0
2
0 76 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut21
3
0 0
169 1
233 0
2
0 78 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut22
3
0 0
169 1
235 0
2
0 80 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut23
3
0 0
169 1
237 0
2
0 82 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut24
3
0 0
169 1
239 0
2
0 84 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut25
3
0 0
169 1
241 0
2
0 86 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut26
3
0 0
169 1
243 0
2
0 88 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut27
3
0 0
169 1
245 0
2
0 90 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut28
3
0 0
169 1
247 0
2
0 92 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut29
3
0 0
169 1
249 0
2
0 94 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut3
3
0 0
169 1
251 0
2
0 96 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut30
3
0 0
169 1
253 0
2
0 98 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut31
3
0 0
169 1
255 0
2
0 100 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut32
3
0 0
169 1
257 0
2
0 102 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut33
3
0 0
169 1
259 0
2
0 104 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut34
3
0 0
169 1
261 0
2
0 106 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut35
3
0 0
169 1
263 0
2
0 108 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut36
3
0 0
169 1
265 0
2
0 110 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut37
3
0 0
169 1
267 0
2
0 112 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut38
3
0 0
169 1
269 0
2
0 114 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut39
3
0 0
169 1
271 0
2
0 116 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut4
3
0 0
169 1
273 0
2
0 118 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut40
3
0 0
169 1
275 0
2
0 120 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut41
3
0 0
169 1
277 0
2
0 122 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut42
3
0 0
169 1
279 0
2
0 124 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut43
3
0 0
169 1
281 0
2
0 126 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut44
3
0 0
169 1
283 0
2
0 128 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut45
3
0 0
169 1
285 0
2
0 130 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut46
3
0 0
169 1
287 0
2
0 132 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut47
3
0 0
169 1
289 0
2
0 134 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut48
3
0 0
169 1
291 0
2
0 136 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut49
3
0 0
169 1
293 0
2
0 138 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut5
3
0 0
169 1
295 0
2
0 140 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut50
3
0 0
169 1
297 0
2
0 142 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut51
3
0 0
169 1
299 0
2
0 144 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut52
3
0 0
169 1
301 0
2
0 146 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut53
3
0 0
169 1
303 0
2
0 148 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut54
3
0 0
169 1
305 0
2
0 150 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut55
3
0 0
169 1
307 0
2
0 152 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut56
3
0 0
169 1
309 0
2
0 154 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut57
3
0 0
169 1
311 0
2
0 156 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut58
3
0 0
169 1
313 0
2
0 158 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut59
3
0 0
169 1
315 0
2
0 160 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut6
3
0 0
169 1
317 0
2
0 162 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut60
3
0 0
169 1
319 0
2
0 164 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut61
3
0 0
169 1
321 0
2
0 166 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut62
3
0 0
169 1
323 0
2
0 168 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut63
3
0 0
169 1
325 0
2
0 170 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut7
3
0 0
169 1
327 0
2
0 172 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut8
3
0 0
169 1
329 0
2
0 174 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner84 bob nut9
3
0 0
169 1
331 0
2
0 176 0 1
0 362 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut1
3
0 0
171 1
207 0
2
0 52 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut10
3
0 0
171 1
209 0
2
0 54 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut11
3
0 0
171 1
211 0
2
0 56 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut12
3
0 0
171 1
213 0
2
0 58 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut13
3
0 0
171 1
215 0
2
0 60 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut14
3
0 0
171 1
217 0
2
0 62 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut15
3
0 0
171 1
219 0
2
0 64 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut16
3
0 0
171 1
221 0
2
0 66 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut17
3
0 0
171 1
223 0
2
0 68 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut18
3
0 0
171 1
225 0
2
0 70 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut19
3
0 0
171 1
227 0
2
0 72 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut2
3
0 0
171 1
229 0
2
0 74 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut20
3
0 0
171 1
231 0
2
0 76 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut21
3
0 0
171 1
233 0
2
0 78 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut22
3
0 0
171 1
235 0
2
0 80 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut23
3
0 0
171 1
237 0
2
0 82 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut24
3
0 0
171 1
239 0
2
0 84 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut25
3
0 0
171 1
241 0
2
0 86 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut26
3
0 0
171 1
243 0
2
0 88 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut27
3
0 0
171 1
245 0
2
0 90 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut28
3
0 0
171 1
247 0
2
0 92 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut29
3
0 0
171 1
249 0
2
0 94 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut3
3
0 0
171 1
251 0
2
0 96 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut30
3
0 0
171 1
253 0
2
0 98 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut31
3
0 0
171 1
255 0
2
0 100 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut32
3
0 0
171 1
257 0
2
0 102 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut33
3
0 0
171 1
259 0
2
0 104 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut34
3
0 0
171 1
261 0
2
0 106 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut35
3
0 0
171 1
263 0
2
0 108 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut36
3
0 0
171 1
265 0
2
0 110 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut37
3
0 0
171 1
267 0
2
0 112 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut38
3
0 0
171 1
269 0
2
0 114 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut39
3
0 0
171 1
271 0
2
0 116 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut4
3
0 0
171 1
273 0
2
0 118 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut40
3
0 0
171 1
275 0
2
0 120 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut41
3
0 0
171 1
277 0
2
0 122 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut42
3
0 0
171 1
279 0
2
0 124 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut43
3
0 0
171 1
281 0
2
0 126 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut44
3
0 0
171 1
283 0
2
0 128 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut45
3
0 0
171 1
285 0
2
0 130 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut46
3
0 0
171 1
287 0
2
0 132 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut47
3
0 0
171 1
289 0
2
0 134 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut48
3
0 0
171 1
291 0
2
0 136 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut49
3
0 0
171 1
293 0
2
0 138 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut5
3
0 0
171 1
295 0
2
0 140 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut50
3
0 0
171 1
297 0
2
0 142 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut51
3
0 0
171 1
299 0
2
0 144 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut52
3
0 0
171 1
301 0
2
0 146 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut53
3
0 0
171 1
303 0
2
0 148 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut54
3
0 0
171 1
305 0
2
0 150 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut55
3
0 0
171 1
307 0
2
0 152 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut56
3
0 0
171 1
309 0
2
0 154 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut57
3
0 0
171 1
311 0
2
0 156 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut58
3
0 0
171 1
313 0
2
0 158 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut59
3
0 0
171 1
315 0
2
0 160 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut6
3
0 0
171 1
317 0
2
0 162 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut60
3
0 0
171 1
319 0
2
0 164 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut61
3
0 0
171 1
321 0
2
0 166 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut62
3
0 0
171 1
323 0
2
0 168 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut63
3
0 0
171 1
325 0
2
0 170 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut7
3
0 0
171 1
327 0
2
0 172 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut8
3
0 0
171 1
329 0
2
0 174 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner85 bob nut9
3
0 0
171 1
331 0
2
0 176 0 1
0 363 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut1
3
0 0
173 1
207 0
2
0 52 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut10
3
0 0
173 1
209 0
2
0 54 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut11
3
0 0
173 1
211 0
2
0 56 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut12
3
0 0
173 1
213 0
2
0 58 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut13
3
0 0
173 1
215 0
2
0 60 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut14
3
0 0
173 1
217 0
2
0 62 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut15
3
0 0
173 1
219 0
2
0 64 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut16
3
0 0
173 1
221 0
2
0 66 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut17
3
0 0
173 1
223 0
2
0 68 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut18
3
0 0
173 1
225 0
2
0 70 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut19
3
0 0
173 1
227 0
2
0 72 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut2
3
0 0
173 1
229 0
2
0 74 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut20
3
0 0
173 1
231 0
2
0 76 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut21
3
0 0
173 1
233 0
2
0 78 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut22
3
0 0
173 1
235 0
2
0 80 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut23
3
0 0
173 1
237 0
2
0 82 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut24
3
0 0
173 1
239 0
2
0 84 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut25
3
0 0
173 1
241 0
2
0 86 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut26
3
0 0
173 1
243 0
2
0 88 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut27
3
0 0
173 1
245 0
2
0 90 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut28
3
0 0
173 1
247 0
2
0 92 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut29
3
0 0
173 1
249 0
2
0 94 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut3
3
0 0
173 1
251 0
2
0 96 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut30
3
0 0
173 1
253 0
2
0 98 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut31
3
0 0
173 1
255 0
2
0 100 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut32
3
0 0
173 1
257 0
2
0 102 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut33
3
0 0
173 1
259 0
2
0 104 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut34
3
0 0
173 1
261 0
2
0 106 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut35
3
0 0
173 1
263 0
2
0 108 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut36
3
0 0
173 1
265 0
2
0 110 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut37
3
0 0
173 1
267 0
2
0 112 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut38
3
0 0
173 1
269 0
2
0 114 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut39
3
0 0
173 1
271 0
2
0 116 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut4
3
0 0
173 1
273 0
2
0 118 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut40
3
0 0
173 1
275 0
2
0 120 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut41
3
0 0
173 1
277 0
2
0 122 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut42
3
0 0
173 1
279 0
2
0 124 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut43
3
0 0
173 1
281 0
2
0 126 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut44
3
0 0
173 1
283 0
2
0 128 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut45
3
0 0
173 1
285 0
2
0 130 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut46
3
0 0
173 1
287 0
2
0 132 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut47
3
0 0
173 1
289 0
2
0 134 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut48
3
0 0
173 1
291 0
2
0 136 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut49
3
0 0
173 1
293 0
2
0 138 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut5
3
0 0
173 1
295 0
2
0 140 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut50
3
0 0
173 1
297 0
2
0 142 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut51
3
0 0
173 1
299 0
2
0 144 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut52
3
0 0
173 1
301 0
2
0 146 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut53
3
0 0
173 1
303 0
2
0 148 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut54
3
0 0
173 1
305 0
2
0 150 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut55
3
0 0
173 1
307 0
2
0 152 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut56
3
0 0
173 1
309 0
2
0 154 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut57
3
0 0
173 1
311 0
2
0 156 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut58
3
0 0
173 1
313 0
2
0 158 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut59
3
0 0
173 1
315 0
2
0 160 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut6
3
0 0
173 1
317 0
2
0 162 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut60
3
0 0
173 1
319 0
2
0 164 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut61
3
0 0
173 1
321 0
2
0 166 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut62
3
0 0
173 1
323 0
2
0 168 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut63
3
0 0
173 1
325 0
2
0 170 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut7
3
0 0
173 1
327 0
2
0 172 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut8
3
0 0
173 1
329 0
2
0 174 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner86 bob nut9
3
0 0
173 1
331 0
2
0 176 0 1
0 364 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut1
3
0 0
175 1
207 0
2
0 52 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut10
3
0 0
175 1
209 0
2
0 54 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut11
3
0 0
175 1
211 0
2
0 56 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut12
3
0 0
175 1
213 0
2
0 58 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut13
3
0 0
175 1
215 0
2
0 60 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut14
3
0 0
175 1
217 0
2
0 62 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut15
3
0 0
175 1
219 0
2
0 64 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut16
3
0 0
175 1
221 0
2
0 66 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut17
3
0 0
175 1
223 0
2
0 68 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut18
3
0 0
175 1
225 0
2
0 70 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut19
3
0 0
175 1
227 0
2
0 72 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut2
3
0 0
175 1
229 0
2
0 74 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut20
3
0 0
175 1
231 0
2
0 76 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut21
3
0 0
175 1
233 0
2
0 78 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut22
3
0 0
175 1
235 0
2
0 80 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut23
3
0 0
175 1
237 0
2
0 82 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut24
3
0 0
175 1
239 0
2
0 84 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut25
3
0 0
175 1
241 0
2
0 86 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut26
3
0 0
175 1
243 0
2
0 88 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut27
3
0 0
175 1
245 0
2
0 90 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut28
3
0 0
175 1
247 0
2
0 92 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut29
3
0 0
175 1
249 0
2
0 94 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut3
3
0 0
175 1
251 0
2
0 96 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut30
3
0 0
175 1
253 0
2
0 98 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut31
3
0 0
175 1
255 0
2
0 100 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut32
3
0 0
175 1
257 0
2
0 102 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut33
3
0 0
175 1
259 0
2
0 104 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut34
3
0 0
175 1
261 0
2
0 106 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut35
3
0 0
175 1
263 0
2
0 108 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut36
3
0 0
175 1
265 0
2
0 110 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut37
3
0 0
175 1
267 0
2
0 112 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut38
3
0 0
175 1
269 0
2
0 114 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut39
3
0 0
175 1
271 0
2
0 116 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut4
3
0 0
175 1
273 0
2
0 118 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut40
3
0 0
175 1
275 0
2
0 120 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut41
3
0 0
175 1
277 0
2
0 122 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut42
3
0 0
175 1
279 0
2
0 124 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut43
3
0 0
175 1
281 0
2
0 126 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut44
3
0 0
175 1
283 0
2
0 128 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut45
3
0 0
175 1
285 0
2
0 130 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut46
3
0 0
175 1
287 0
2
0 132 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut47
3
0 0
175 1
289 0
2
0 134 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut48
3
0 0
175 1
291 0
2
0 136 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut49
3
0 0
175 1
293 0
2
0 138 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut5
3
0 0
175 1
295 0
2
0 140 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut50
3
0 0
175 1
297 0
2
0 142 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut51
3
0 0
175 1
299 0
2
0 144 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut52
3
0 0
175 1
301 0
2
0 146 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut53
3
0 0
175 1
303 0
2
0 148 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut54
3
0 0
175 1
305 0
2
0 150 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut55
3
0 0
175 1
307 0
2
0 152 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut56
3
0 0
175 1
309 0
2
0 154 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut57
3
0 0
175 1
311 0
2
0 156 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut58
3
0 0
175 1
313 0
2
0 158 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut59
3
0 0
175 1
315 0
2
0 160 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut6
3
0 0
175 1
317 0
2
0 162 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut60
3
0 0
175 1
319 0
2
0 164 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut61
3
0 0
175 1
321 0
2
0 166 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut62
3
0 0
175 1
323 0
2
0 168 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut63
3
0 0
175 1
325 0
2
0 170 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut7
3
0 0
175 1
327 0
2
0 172 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut8
3
0 0
175 1
329 0
2
0 174 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner87 bob nut9
3
0 0
175 1
331 0
2
0 176 0 1
0 365 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut1
3
0 0
177 1
207 0
2
0 52 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut10
3
0 0
177 1
209 0
2
0 54 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut11
3
0 0
177 1
211 0
2
0 56 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut12
3
0 0
177 1
213 0
2
0 58 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut13
3
0 0
177 1
215 0
2
0 60 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut14
3
0 0
177 1
217 0
2
0 62 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut15
3
0 0
177 1
219 0
2
0 64 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut16
3
0 0
177 1
221 0
2
0 66 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut17
3
0 0
177 1
223 0
2
0 68 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut18
3
0 0
177 1
225 0
2
0 70 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut19
3
0 0
177 1
227 0
2
0 72 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut2
3
0 0
177 1
229 0
2
0 74 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut20
3
0 0
177 1
231 0
2
0 76 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut21
3
0 0
177 1
233 0
2
0 78 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut22
3
0 0
177 1
235 0
2
0 80 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut23
3
0 0
177 1
237 0
2
0 82 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut24
3
0 0
177 1
239 0
2
0 84 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut25
3
0 0
177 1
241 0
2
0 86 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut26
3
0 0
177 1
243 0
2
0 88 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut27
3
0 0
177 1
245 0
2
0 90 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut28
3
0 0
177 1
247 0
2
0 92 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut29
3
0 0
177 1
249 0
2
0 94 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut3
3
0 0
177 1
251 0
2
0 96 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut30
3
0 0
177 1
253 0
2
0 98 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut31
3
0 0
177 1
255 0
2
0 100 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut32
3
0 0
177 1
257 0
2
0 102 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut33
3
0 0
177 1
259 0
2
0 104 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut34
3
0 0
177 1
261 0
2
0 106 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut35
3
0 0
177 1
263 0
2
0 108 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut36
3
0 0
177 1
265 0
2
0 110 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut37
3
0 0
177 1
267 0
2
0 112 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut38
3
0 0
177 1
269 0
2
0 114 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut39
3
0 0
177 1
271 0
2
0 116 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut4
3
0 0
177 1
273 0
2
0 118 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut40
3
0 0
177 1
275 0
2
0 120 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut41
3
0 0
177 1
277 0
2
0 122 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut42
3
0 0
177 1
279 0
2
0 124 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut43
3
0 0
177 1
281 0
2
0 126 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut44
3
0 0
177 1
283 0
2
0 128 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut45
3
0 0
177 1
285 0
2
0 130 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut46
3
0 0
177 1
287 0
2
0 132 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut47
3
0 0
177 1
289 0
2
0 134 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut48
3
0 0
177 1
291 0
2
0 136 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut49
3
0 0
177 1
293 0
2
0 138 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut5
3
0 0
177 1
295 0
2
0 140 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut50
3
0 0
177 1
297 0
2
0 142 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut51
3
0 0
177 1
299 0
2
0 144 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut52
3
0 0
177 1
301 0
2
0 146 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut53
3
0 0
177 1
303 0
2
0 148 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut54
3
0 0
177 1
305 0
2
0 150 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut55
3
0 0
177 1
307 0
2
0 152 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut56
3
0 0
177 1
309 0
2
0 154 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut57
3
0 0
177 1
311 0
2
0 156 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut58
3
0 0
177 1
313 0
2
0 158 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut59
3
0 0
177 1
315 0
2
0 160 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut6
3
0 0
177 1
317 0
2
0 162 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut60
3
0 0
177 1
319 0
2
0 164 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut61
3
0 0
177 1
321 0
2
0 166 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut62
3
0 0
177 1
323 0
2
0 168 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut63
3
0 0
177 1
325 0
2
0 170 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut7
3
0 0
177 1
327 0
2
0 172 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut8
3
0 0
177 1
329 0
2
0 174 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner88 bob nut9
3
0 0
177 1
331 0
2
0 176 0 1
0 366 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut1
3
0 0
178 1
207 0
2
0 52 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut10
3
0 0
178 1
209 0
2
0 54 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut11
3
0 0
178 1
211 0
2
0 56 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut12
3
0 0
178 1
213 0
2
0 58 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut13
3
0 0
178 1
215 0
2
0 60 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut14
3
0 0
178 1
217 0
2
0 62 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut15
3
0 0
178 1
219 0
2
0 64 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut16
3
0 0
178 1
221 0
2
0 66 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut17
3
0 0
178 1
223 0
2
0 68 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut18
3
0 0
178 1
225 0
2
0 70 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut19
3
0 0
178 1
227 0
2
0 72 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut2
3
0 0
178 1
229 0
2
0 74 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut20
3
0 0
178 1
231 0
2
0 76 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut21
3
0 0
178 1
233 0
2
0 78 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut22
3
0 0
178 1
235 0
2
0 80 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut23
3
0 0
178 1
237 0
2
0 82 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut24
3
0 0
178 1
239 0
2
0 84 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut25
3
0 0
178 1
241 0
2
0 86 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut26
3
0 0
178 1
243 0
2
0 88 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut27
3
0 0
178 1
245 0
2
0 90 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut28
3
0 0
178 1
247 0
2
0 92 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut29
3
0 0
178 1
249 0
2
0 94 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut3
3
0 0
178 1
251 0
2
0 96 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut30
3
0 0
178 1
253 0
2
0 98 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut31
3
0 0
178 1
255 0
2
0 100 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut32
3
0 0
178 1
257 0
2
0 102 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut33
3
0 0
178 1
259 0
2
0 104 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut34
3
0 0
178 1
261 0
2
0 106 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut35
3
0 0
178 1
263 0
2
0 108 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut36
3
0 0
178 1
265 0
2
0 110 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut37
3
0 0
178 1
267 0
2
0 112 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut38
3
0 0
178 1
269 0
2
0 114 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut39
3
0 0
178 1
271 0
2
0 116 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut4
3
0 0
178 1
273 0
2
0 118 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut40
3
0 0
178 1
275 0
2
0 120 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut41
3
0 0
178 1
277 0
2
0 122 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut42
3
0 0
178 1
279 0
2
0 124 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut43
3
0 0
178 1
281 0
2
0 126 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut44
3
0 0
178 1
283 0
2
0 128 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut45
3
0 0
178 1
285 0
2
0 130 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut46
3
0 0
178 1
287 0
2
0 132 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut47
3
0 0
178 1
289 0
2
0 134 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut48
3
0 0
178 1
291 0
2
0 136 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut49
3
0 0
178 1
293 0
2
0 138 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut5
3
0 0
178 1
295 0
2
0 140 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut50
3
0 0
178 1
297 0
2
0 142 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut51
3
0 0
178 1
299 0
2
0 144 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut52
3
0 0
178 1
301 0
2
0 146 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut53
3
0 0
178 1
303 0
2
0 148 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut54
3
0 0
178 1
305 0
2
0 150 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut55
3
0 0
178 1
307 0
2
0 152 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut56
3
0 0
178 1
309 0
2
0 154 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut57
3
0 0
178 1
311 0
2
0 156 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut58
3
0 0
178 1
313 0
2
0 158 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut59
3
0 0
178 1
315 0
2
0 160 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut6
3
0 0
178 1
317 0
2
0 162 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut60
3
0 0
178 1
319 0
2
0 164 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut61
3
0 0
178 1
321 0
2
0 166 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut62
3
0 0
178 1
323 0
2
0 168 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut63
3
0 0
178 1
325 0
2
0 170 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut7
3
0 0
178 1
327 0
2
0 172 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut8
3
0 0
178 1
329 0
2
0 174 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner89 bob nut9
3
0 0
178 1
331 0
2
0 176 0 1
0 367 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut1
3
0 0
179 1
207 0
2
0 52 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut10
3
0 0
179 1
209 0
2
0 54 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut11
3
0 0
179 1
211 0
2
0 56 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut12
3
0 0
179 1
213 0
2
0 58 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut13
3
0 0
179 1
215 0
2
0 60 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut14
3
0 0
179 1
217 0
2
0 62 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut15
3
0 0
179 1
219 0
2
0 64 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut16
3
0 0
179 1
221 0
2
0 66 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut17
3
0 0
179 1
223 0
2
0 68 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut18
3
0 0
179 1
225 0
2
0 70 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut19
3
0 0
179 1
227 0
2
0 72 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut2
3
0 0
179 1
229 0
2
0 74 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut20
3
0 0
179 1
231 0
2
0 76 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut21
3
0 0
179 1
233 0
2
0 78 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut22
3
0 0
179 1
235 0
2
0 80 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut23
3
0 0
179 1
237 0
2
0 82 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut24
3
0 0
179 1
239 0
2
0 84 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut25
3
0 0
179 1
241 0
2
0 86 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut26
3
0 0
179 1
243 0
2
0 88 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut27
3
0 0
179 1
245 0
2
0 90 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut28
3
0 0
179 1
247 0
2
0 92 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut29
3
0 0
179 1
249 0
2
0 94 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut3
3
0 0
179 1
251 0
2
0 96 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut30
3
0 0
179 1
253 0
2
0 98 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut31
3
0 0
179 1
255 0
2
0 100 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut32
3
0 0
179 1
257 0
2
0 102 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut33
3
0 0
179 1
259 0
2
0 104 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut34
3
0 0
179 1
261 0
2
0 106 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut35
3
0 0
179 1
263 0
2
0 108 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut36
3
0 0
179 1
265 0
2
0 110 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut37
3
0 0
179 1
267 0
2
0 112 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut38
3
0 0
179 1
269 0
2
0 114 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut39
3
0 0
179 1
271 0
2
0 116 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut4
3
0 0
179 1
273 0
2
0 118 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut40
3
0 0
179 1
275 0
2
0 120 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut41
3
0 0
179 1
277 0
2
0 122 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut42
3
0 0
179 1
279 0
2
0 124 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut43
3
0 0
179 1
281 0
2
0 126 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut44
3
0 0
179 1
283 0
2
0 128 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut45
3
0 0
179 1
285 0
2
0 130 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut46
3
0 0
179 1
287 0
2
0 132 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut47
3
0 0
179 1
289 0
2
0 134 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut48
3
0 0
179 1
291 0
2
0 136 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut49
3
0 0
179 1
293 0
2
0 138 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut5
3
0 0
179 1
295 0
2
0 140 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut50
3
0 0
179 1
297 0
2
0 142 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut51
3
0 0
179 1
299 0
2
0 144 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut52
3
0 0
179 1
301 0
2
0 146 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut53
3
0 0
179 1
303 0
2
0 148 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut54
3
0 0
179 1
305 0
2
0 150 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut55
3
0 0
179 1
307 0
2
0 152 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut56
3
0 0
179 1
309 0
2
0 154 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut57
3
0 0
179 1
311 0
2
0 156 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut58
3
0 0
179 1
313 0
2
0 158 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut59
3
0 0
179 1
315 0
2
0 160 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut6
3
0 0
179 1
317 0
2
0 162 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut60
3
0 0
179 1
319 0
2
0 164 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut61
3
0 0
179 1
321 0
2
0 166 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut62
3
0 0
179 1
323 0
2
0 168 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut63
3
0 0
179 1
325 0
2
0 170 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut7
3
0 0
179 1
327 0
2
0 172 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut8
3
0 0
179 1
329 0
2
0 174 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner9 bob nut9
3
0 0
179 1
331 0
2
0 176 0 1
0 368 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut1
3
0 0
180 1
207 0
2
0 52 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut10
3
0 0
180 1
209 0
2
0 54 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut11
3
0 0
180 1
211 0
2
0 56 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut12
3
0 0
180 1
213 0
2
0 58 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut13
3
0 0
180 1
215 0
2
0 60 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut14
3
0 0
180 1
217 0
2
0 62 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut15
3
0 0
180 1
219 0
2
0 64 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut16
3
0 0
180 1
221 0
2
0 66 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut17
3
0 0
180 1
223 0
2
0 68 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut18
3
0 0
180 1
225 0
2
0 70 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut19
3
0 0
180 1
227 0
2
0 72 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut2
3
0 0
180 1
229 0
2
0 74 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut20
3
0 0
180 1
231 0
2
0 76 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut21
3
0 0
180 1
233 0
2
0 78 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut22
3
0 0
180 1
235 0
2
0 80 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut23
3
0 0
180 1
237 0
2
0 82 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut24
3
0 0
180 1
239 0
2
0 84 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut25
3
0 0
180 1
241 0
2
0 86 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut26
3
0 0
180 1
243 0
2
0 88 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut27
3
0 0
180 1
245 0
2
0 90 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut28
3
0 0
180 1
247 0
2
0 92 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut29
3
0 0
180 1
249 0
2
0 94 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut3
3
0 0
180 1
251 0
2
0 96 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut30
3
0 0
180 1
253 0
2
0 98 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut31
3
0 0
180 1
255 0
2
0 100 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut32
3
0 0
180 1
257 0
2
0 102 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut33
3
0 0
180 1
259 0
2
0 104 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut34
3
0 0
180 1
261 0
2
0 106 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut35
3
0 0
180 1
263 0
2
0 108 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut36
3
0 0
180 1
265 0
2
0 110 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut37
3
0 0
180 1
267 0
2
0 112 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut38
3
0 0
180 1
269 0
2
0 114 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut39
3
0 0
180 1
271 0
2
0 116 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut4
3
0 0
180 1
273 0
2
0 118 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut40
3
0 0
180 1
275 0
2
0 120 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut41
3
0 0
180 1
277 0
2
0 122 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut42
3
0 0
180 1
279 0
2
0 124 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut43
3
0 0
180 1
281 0
2
0 126 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut44
3
0 0
180 1
283 0
2
0 128 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut45
3
0 0
180 1
285 0
2
0 130 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut46
3
0 0
180 1
287 0
2
0 132 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut47
3
0 0
180 1
289 0
2
0 134 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut48
3
0 0
180 1
291 0
2
0 136 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut49
3
0 0
180 1
293 0
2
0 138 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut5
3
0 0
180 1
295 0
2
0 140 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut50
3
0 0
180 1
297 0
2
0 142 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut51
3
0 0
180 1
299 0
2
0 144 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut52
3
0 0
180 1
301 0
2
0 146 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut53
3
0 0
180 1
303 0
2
0 148 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut54
3
0 0
180 1
305 0
2
0 150 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut55
3
0 0
180 1
307 0
2
0 152 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut56
3
0 0
180 1
309 0
2
0 154 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut57
3
0 0
180 1
311 0
2
0 156 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut58
3
0 0
180 1
313 0
2
0 158 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut59
3
0 0
180 1
315 0
2
0 160 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut6
3
0 0
180 1
317 0
2
0 162 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut60
3
0 0
180 1
319 0
2
0 164 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut61
3
0 0
180 1
321 0
2
0 166 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut62
3
0 0
180 1
323 0
2
0 168 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut63
3
0 0
180 1
325 0
2
0 170 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut7
3
0 0
180 1
327 0
2
0 172 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut8
3
0 0
180 1
329 0
2
0 174 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner90 bob nut9
3
0 0
180 1
331 0
2
0 176 0 1
0 369 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut1
3
0 0
181 1
207 0
2
0 52 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut10
3
0 0
181 1
209 0
2
0 54 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut11
3
0 0
181 1
211 0
2
0 56 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut12
3
0 0
181 1
213 0
2
0 58 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut13
3
0 0
181 1
215 0
2
0 60 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut14
3
0 0
181 1
217 0
2
0 62 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut15
3
0 0
181 1
219 0
2
0 64 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut16
3
0 0
181 1
221 0
2
0 66 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut17
3
0 0
181 1
223 0
2
0 68 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut18
3
0 0
181 1
225 0
2
0 70 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut19
3
0 0
181 1
227 0
2
0 72 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut2
3
0 0
181 1
229 0
2
0 74 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut20
3
0 0
181 1
231 0
2
0 76 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut21
3
0 0
181 1
233 0
2
0 78 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut22
3
0 0
181 1
235 0
2
0 80 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut23
3
0 0
181 1
237 0
2
0 82 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut24
3
0 0
181 1
239 0
2
0 84 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut25
3
0 0
181 1
241 0
2
0 86 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut26
3
0 0
181 1
243 0
2
0 88 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut27
3
0 0
181 1
245 0
2
0 90 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut28
3
0 0
181 1
247 0
2
0 92 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut29
3
0 0
181 1
249 0
2
0 94 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut3
3
0 0
181 1
251 0
2
0 96 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut30
3
0 0
181 1
253 0
2
0 98 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut31
3
0 0
181 1
255 0
2
0 100 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut32
3
0 0
181 1
257 0
2
0 102 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut33
3
0 0
181 1
259 0
2
0 104 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut34
3
0 0
181 1
261 0
2
0 106 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut35
3
0 0
181 1
263 0
2
0 108 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut36
3
0 0
181 1
265 0
2
0 110 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut37
3
0 0
181 1
267 0
2
0 112 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut38
3
0 0
181 1
269 0
2
0 114 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut39
3
0 0
181 1
271 0
2
0 116 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut4
3
0 0
181 1
273 0
2
0 118 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut40
3
0 0
181 1
275 0
2
0 120 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut41
3
0 0
181 1
277 0
2
0 122 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut42
3
0 0
181 1
279 0
2
0 124 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut43
3
0 0
181 1
281 0
2
0 126 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut44
3
0 0
181 1
283 0
2
0 128 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut45
3
0 0
181 1
285 0
2
0 130 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut46
3
0 0
181 1
287 0
2
0 132 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut47
3
0 0
181 1
289 0
2
0 134 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut48
3
0 0
181 1
291 0
2
0 136 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut49
3
0 0
181 1
293 0
2
0 138 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut5
3
0 0
181 1
295 0
2
0 140 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut50
3
0 0
181 1
297 0
2
0 142 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut51
3
0 0
181 1
299 0
2
0 144 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut52
3
0 0
181 1
301 0
2
0 146 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut53
3
0 0
181 1
303 0
2
0 148 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut54
3
0 0
181 1
305 0
2
0 150 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut55
3
0 0
181 1
307 0
2
0 152 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut56
3
0 0
181 1
309 0
2
0 154 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut57
3
0 0
181 1
311 0
2
0 156 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut58
3
0 0
181 1
313 0
2
0 158 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut59
3
0 0
181 1
315 0
2
0 160 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut6
3
0 0
181 1
317 0
2
0 162 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut60
3
0 0
181 1
319 0
2
0 164 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut61
3
0 0
181 1
321 0
2
0 166 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut62
3
0 0
181 1
323 0
2
0 168 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut63
3
0 0
181 1
325 0
2
0 170 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut7
3
0 0
181 1
327 0
2
0 172 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut8
3
0 0
181 1
329 0
2
0 174 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner91 bob nut9
3
0 0
181 1
331 0
2
0 176 0 1
0 370 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut1
3
0 0
182 1
207 0
2
0 52 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut10
3
0 0
182 1
209 0
2
0 54 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut11
3
0 0
182 1
211 0
2
0 56 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut12
3
0 0
182 1
213 0
2
0 58 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut13
3
0 0
182 1
215 0
2
0 60 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut14
3
0 0
182 1
217 0
2
0 62 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut15
3
0 0
182 1
219 0
2
0 64 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut16
3
0 0
182 1
221 0
2
0 66 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut17
3
0 0
182 1
223 0
2
0 68 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut18
3
0 0
182 1
225 0
2
0 70 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut19
3
0 0
182 1
227 0
2
0 72 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut2
3
0 0
182 1
229 0
2
0 74 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut20
3
0 0
182 1
231 0
2
0 76 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut21
3
0 0
182 1
233 0
2
0 78 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut22
3
0 0
182 1
235 0
2
0 80 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut23
3
0 0
182 1
237 0
2
0 82 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut24
3
0 0
182 1
239 0
2
0 84 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut25
3
0 0
182 1
241 0
2
0 86 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut26
3
0 0
182 1
243 0
2
0 88 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut27
3
0 0
182 1
245 0
2
0 90 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut28
3
0 0
182 1
247 0
2
0 92 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut29
3
0 0
182 1
249 0
2
0 94 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut3
3
0 0
182 1
251 0
2
0 96 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut30
3
0 0
182 1
253 0
2
0 98 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut31
3
0 0
182 1
255 0
2
0 100 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut32
3
0 0
182 1
257 0
2
0 102 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut33
3
0 0
182 1
259 0
2
0 104 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut34
3
0 0
182 1
261 0
2
0 106 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut35
3
0 0
182 1
263 0
2
0 108 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut36
3
0 0
182 1
265 0
2
0 110 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut37
3
0 0
182 1
267 0
2
0 112 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut38
3
0 0
182 1
269 0
2
0 114 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut39
3
0 0
182 1
271 0
2
0 116 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut4
3
0 0
182 1
273 0
2
0 118 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut40
3
0 0
182 1
275 0
2
0 120 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut41
3
0 0
182 1
277 0
2
0 122 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut42
3
0 0
182 1
279 0
2
0 124 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut43
3
0 0
182 1
281 0
2
0 126 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut44
3
0 0
182 1
283 0
2
0 128 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut45
3
0 0
182 1
285 0
2
0 130 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut46
3
0 0
182 1
287 0
2
0 132 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut47
3
0 0
182 1
289 0
2
0 134 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut48
3
0 0
182 1
291 0
2
0 136 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut49
3
0 0
182 1
293 0
2
0 138 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut5
3
0 0
182 1
295 0
2
0 140 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut50
3
0 0
182 1
297 0
2
0 142 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut51
3
0 0
182 1
299 0
2
0 144 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut52
3
0 0
182 1
301 0
2
0 146 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut53
3
0 0
182 1
303 0
2
0 148 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut54
3
0 0
182 1
305 0
2
0 150 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut55
3
0 0
182 1
307 0
2
0 152 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut56
3
0 0
182 1
309 0
2
0 154 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut57
3
0 0
182 1
311 0
2
0 156 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut58
3
0 0
182 1
313 0
2
0 158 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut59
3
0 0
182 1
315 0
2
0 160 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut6
3
0 0
182 1
317 0
2
0 162 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut60
3
0 0
182 1
319 0
2
0 164 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut61
3
0 0
182 1
321 0
2
0 166 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut62
3
0 0
182 1
323 0
2
0 168 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut63
3
0 0
182 1
325 0
2
0 170 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut7
3
0 0
182 1
327 0
2
0 172 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut8
3
0 0
182 1
329 0
2
0 174 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner92 bob nut9
3
0 0
182 1
331 0
2
0 176 0 1
0 371 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut1
3
0 0
183 1
207 0
2
0 52 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut10
3
0 0
183 1
209 0
2
0 54 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut11
3
0 0
183 1
211 0
2
0 56 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut12
3
0 0
183 1
213 0
2
0 58 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut13
3
0 0
183 1
215 0
2
0 60 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut14
3
0 0
183 1
217 0
2
0 62 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut15
3
0 0
183 1
219 0
2
0 64 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut16
3
0 0
183 1
221 0
2
0 66 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut17
3
0 0
183 1
223 0
2
0 68 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut18
3
0 0
183 1
225 0
2
0 70 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut19
3
0 0
183 1
227 0
2
0 72 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut2
3
0 0
183 1
229 0
2
0 74 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut20
3
0 0
183 1
231 0
2
0 76 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut21
3
0 0
183 1
233 0
2
0 78 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut22
3
0 0
183 1
235 0
2
0 80 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut23
3
0 0
183 1
237 0
2
0 82 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut24
3
0 0
183 1
239 0
2
0 84 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut25
3
0 0
183 1
241 0
2
0 86 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut26
3
0 0
183 1
243 0
2
0 88 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut27
3
0 0
183 1
245 0
2
0 90 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut28
3
0 0
183 1
247 0
2
0 92 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut29
3
0 0
183 1
249 0
2
0 94 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut3
3
0 0
183 1
251 0
2
0 96 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut30
3
0 0
183 1
253 0
2
0 98 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut31
3
0 0
183 1
255 0
2
0 100 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut32
3
0 0
183 1
257 0
2
0 102 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut33
3
0 0
183 1
259 0
2
0 104 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut34
3
0 0
183 1
261 0
2
0 106 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut35
3
0 0
183 1
263 0
2
0 108 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut36
3
0 0
183 1
265 0
2
0 110 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut37
3
0 0
183 1
267 0
2
0 112 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut38
3
0 0
183 1
269 0
2
0 114 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut39
3
0 0
183 1
271 0
2
0 116 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut4
3
0 0
183 1
273 0
2
0 118 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut40
3
0 0
183 1
275 0
2
0 120 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut41
3
0 0
183 1
277 0
2
0 122 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut42
3
0 0
183 1
279 0
2
0 124 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut43
3
0 0
183 1
281 0
2
0 126 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut44
3
0 0
183 1
283 0
2
0 128 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut45
3
0 0
183 1
285 0
2
0 130 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut46
3
0 0
183 1
287 0
2
0 132 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut47
3
0 0
183 1
289 0
2
0 134 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut48
3
0 0
183 1
291 0
2
0 136 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut49
3
0 0
183 1
293 0
2
0 138 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut5
3
0 0
183 1
295 0
2
0 140 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut50
3
0 0
183 1
297 0
2
0 142 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut51
3
0 0
183 1
299 0
2
0 144 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut52
3
0 0
183 1
301 0
2
0 146 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut53
3
0 0
183 1
303 0
2
0 148 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut54
3
0 0
183 1
305 0
2
0 150 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut55
3
0 0
183 1
307 0
2
0 152 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut56
3
0 0
183 1
309 0
2
0 154 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut57
3
0 0
183 1
311 0
2
0 156 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut58
3
0 0
183 1
313 0
2
0 158 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut59
3
0 0
183 1
315 0
2
0 160 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut6
3
0 0
183 1
317 0
2
0 162 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut60
3
0 0
183 1
319 0
2
0 164 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut61
3
0 0
183 1
321 0
2
0 166 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut62
3
0 0
183 1
323 0
2
0 168 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut63
3
0 0
183 1
325 0
2
0 170 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut7
3
0 0
183 1
327 0
2
0 172 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut8
3
0 0
183 1
329 0
2
0 174 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner93 bob nut9
3
0 0
183 1
331 0
2
0 176 0 1
0 372 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut1
3
0 0
184 1
207 0
2
0 52 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut10
3
0 0
184 1
209 0
2
0 54 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut11
3
0 0
184 1
211 0
2
0 56 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut12
3
0 0
184 1
213 0
2
0 58 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut13
3
0 0
184 1
215 0
2
0 60 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut14
3
0 0
184 1
217 0
2
0 62 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut15
3
0 0
184 1
219 0
2
0 64 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut16
3
0 0
184 1
221 0
2
0 66 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut17
3
0 0
184 1
223 0
2
0 68 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut18
3
0 0
184 1
225 0
2
0 70 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut19
3
0 0
184 1
227 0
2
0 72 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut2
3
0 0
184 1
229 0
2
0 74 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut20
3
0 0
184 1
231 0
2
0 76 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut21
3
0 0
184 1
233 0
2
0 78 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut22
3
0 0
184 1
235 0
2
0 80 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut23
3
0 0
184 1
237 0
2
0 82 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut24
3
0 0
184 1
239 0
2
0 84 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut25
3
0 0
184 1
241 0
2
0 86 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut26
3
0 0
184 1
243 0
2
0 88 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut27
3
0 0
184 1
245 0
2
0 90 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut28
3
0 0
184 1
247 0
2
0 92 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut29
3
0 0
184 1
249 0
2
0 94 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut3
3
0 0
184 1
251 0
2
0 96 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut30
3
0 0
184 1
253 0
2
0 98 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut31
3
0 0
184 1
255 0
2
0 100 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut32
3
0 0
184 1
257 0
2
0 102 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut33
3
0 0
184 1
259 0
2
0 104 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut34
3
0 0
184 1
261 0
2
0 106 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut35
3
0 0
184 1
263 0
2
0 108 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut36
3
0 0
184 1
265 0
2
0 110 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut37
3
0 0
184 1
267 0
2
0 112 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut38
3
0 0
184 1
269 0
2
0 114 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut39
3
0 0
184 1
271 0
2
0 116 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut4
3
0 0
184 1
273 0
2
0 118 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut40
3
0 0
184 1
275 0
2
0 120 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut41
3
0 0
184 1
277 0
2
0 122 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut42
3
0 0
184 1
279 0
2
0 124 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut43
3
0 0
184 1
281 0
2
0 126 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut44
3
0 0
184 1
283 0
2
0 128 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut45
3
0 0
184 1
285 0
2
0 130 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut46
3
0 0
184 1
287 0
2
0 132 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut47
3
0 0
184 1
289 0
2
0 134 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut48
3
0 0
184 1
291 0
2
0 136 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut49
3
0 0
184 1
293 0
2
0 138 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut5
3
0 0
184 1
295 0
2
0 140 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut50
3
0 0
184 1
297 0
2
0 142 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut51
3
0 0
184 1
299 0
2
0 144 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut52
3
0 0
184 1
301 0
2
0 146 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut53
3
0 0
184 1
303 0
2
0 148 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut54
3
0 0
184 1
305 0
2
0 150 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut55
3
0 0
184 1
307 0
2
0 152 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut56
3
0 0
184 1
309 0
2
0 154 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut57
3
0 0
184 1
311 0
2
0 156 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut58
3
0 0
184 1
313 0
2
0 158 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut59
3
0 0
184 1
315 0
2
0 160 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut6
3
0 0
184 1
317 0
2
0 162 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut60
3
0 0
184 1
319 0
2
0 164 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut61
3
0 0
184 1
321 0
2
0 166 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut62
3
0 0
184 1
323 0
2
0 168 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut63
3
0 0
184 1
325 0
2
0 170 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut7
3
0 0
184 1
327 0
2
0 172 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut8
3
0 0
184 1
329 0
2
0 174 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner94 bob nut9
3
0 0
184 1
331 0
2
0 176 0 1
0 373 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut1
3
0 0
185 1
207 0
2
0 52 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut10
3
0 0
185 1
209 0
2
0 54 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut11
3
0 0
185 1
211 0
2
0 56 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut12
3
0 0
185 1
213 0
2
0 58 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut13
3
0 0
185 1
215 0
2
0 60 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut14
3
0 0
185 1
217 0
2
0 62 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut15
3
0 0
185 1
219 0
2
0 64 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut16
3
0 0
185 1
221 0
2
0 66 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut17
3
0 0
185 1
223 0
2
0 68 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut18
3
0 0
185 1
225 0
2
0 70 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut19
3
0 0
185 1
227 0
2
0 72 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut2
3
0 0
185 1
229 0
2
0 74 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut20
3
0 0
185 1
231 0
2
0 76 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut21
3
0 0
185 1
233 0
2
0 78 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut22
3
0 0
185 1
235 0
2
0 80 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut23
3
0 0
185 1
237 0
2
0 82 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut24
3
0 0
185 1
239 0
2
0 84 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut25
3
0 0
185 1
241 0
2
0 86 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut26
3
0 0
185 1
243 0
2
0 88 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut27
3
0 0
185 1
245 0
2
0 90 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut28
3
0 0
185 1
247 0
2
0 92 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut29
3
0 0
185 1
249 0
2
0 94 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut3
3
0 0
185 1
251 0
2
0 96 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut30
3
0 0
185 1
253 0
2
0 98 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut31
3
0 0
185 1
255 0
2
0 100 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut32
3
0 0
185 1
257 0
2
0 102 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut33
3
0 0
185 1
259 0
2
0 104 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut34
3
0 0
185 1
261 0
2
0 106 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut35
3
0 0
185 1
263 0
2
0 108 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut36
3
0 0
185 1
265 0
2
0 110 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut37
3
0 0
185 1
267 0
2
0 112 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut38
3
0 0
185 1
269 0
2
0 114 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut39
3
0 0
185 1
271 0
2
0 116 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut4
3
0 0
185 1
273 0
2
0 118 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut40
3
0 0
185 1
275 0
2
0 120 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut41
3
0 0
185 1
277 0
2
0 122 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut42
3
0 0
185 1
279 0
2
0 124 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut43
3
0 0
185 1
281 0
2
0 126 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut44
3
0 0
185 1
283 0
2
0 128 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut45
3
0 0
185 1
285 0
2
0 130 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut46
3
0 0
185 1
287 0
2
0 132 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut47
3
0 0
185 1
289 0
2
0 134 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut48
3
0 0
185 1
291 0
2
0 136 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut49
3
0 0
185 1
293 0
2
0 138 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut5
3
0 0
185 1
295 0
2
0 140 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut50
3
0 0
185 1
297 0
2
0 142 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut51
3
0 0
185 1
299 0
2
0 144 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut52
3
0 0
185 1
301 0
2
0 146 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut53
3
0 0
185 1
303 0
2
0 148 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut54
3
0 0
185 1
305 0
2
0 150 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut55
3
0 0
185 1
307 0
2
0 152 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut56
3
0 0
185 1
309 0
2
0 154 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut57
3
0 0
185 1
311 0
2
0 156 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut58
3
0 0
185 1
313 0
2
0 158 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut59
3
0 0
185 1
315 0
2
0 160 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut6
3
0 0
185 1
317 0
2
0 162 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut60
3
0 0
185 1
319 0
2
0 164 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut61
3
0 0
185 1
321 0
2
0 166 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut62
3
0 0
185 1
323 0
2
0 168 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut63
3
0 0
185 1
325 0
2
0 170 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut7
3
0 0
185 1
327 0
2
0 172 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut8
3
0 0
185 1
329 0
2
0 174 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner95 bob nut9
3
0 0
185 1
331 0
2
0 176 0 1
0 374 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut1
3
0 0
186 1
207 0
2
0 52 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut10
3
0 0
186 1
209 0
2
0 54 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut11
3
0 0
186 1
211 0
2
0 56 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut12
3
0 0
186 1
213 0
2
0 58 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut13
3
0 0
186 1
215 0
2
0 60 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut14
3
0 0
186 1
217 0
2
0 62 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut15
3
0 0
186 1
219 0
2
0 64 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut16
3
0 0
186 1
221 0
2
0 66 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut17
3
0 0
186 1
223 0
2
0 68 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut18
3
0 0
186 1
225 0
2
0 70 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut19
3
0 0
186 1
227 0
2
0 72 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut2
3
0 0
186 1
229 0
2
0 74 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut20
3
0 0
186 1
231 0
2
0 76 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut21
3
0 0
186 1
233 0
2
0 78 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut22
3
0 0
186 1
235 0
2
0 80 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut23
3
0 0
186 1
237 0
2
0 82 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut24
3
0 0
186 1
239 0
2
0 84 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut25
3
0 0
186 1
241 0
2
0 86 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut26
3
0 0
186 1
243 0
2
0 88 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut27
3
0 0
186 1
245 0
2
0 90 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut28
3
0 0
186 1
247 0
2
0 92 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut29
3
0 0
186 1
249 0
2
0 94 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut3
3
0 0
186 1
251 0
2
0 96 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut30
3
0 0
186 1
253 0
2
0 98 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut31
3
0 0
186 1
255 0
2
0 100 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut32
3
0 0
186 1
257 0
2
0 102 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut33
3
0 0
186 1
259 0
2
0 104 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut34
3
0 0
186 1
261 0
2
0 106 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut35
3
0 0
186 1
263 0
2
0 108 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut36
3
0 0
186 1
265 0
2
0 110 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut37
3
0 0
186 1
267 0
2
0 112 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut38
3
0 0
186 1
269 0
2
0 114 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut39
3
0 0
186 1
271 0
2
0 116 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut4
3
0 0
186 1
273 0
2
0 118 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut40
3
0 0
186 1
275 0
2
0 120 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut41
3
0 0
186 1
277 0
2
0 122 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut42
3
0 0
186 1
279 0
2
0 124 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut43
3
0 0
186 1
281 0
2
0 126 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut44
3
0 0
186 1
283 0
2
0 128 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut45
3
0 0
186 1
285 0
2
0 130 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut46
3
0 0
186 1
287 0
2
0 132 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut47
3
0 0
186 1
289 0
2
0 134 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut48
3
0 0
186 1
291 0
2
0 136 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut49
3
0 0
186 1
293 0
2
0 138 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut5
3
0 0
186 1
295 0
2
0 140 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut50
3
0 0
186 1
297 0
2
0 142 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut51
3
0 0
186 1
299 0
2
0 144 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut52
3
0 0
186 1
301 0
2
0 146 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut53
3
0 0
186 1
303 0
2
0 148 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut54
3
0 0
186 1
305 0
2
0 150 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut55
3
0 0
186 1
307 0
2
0 152 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut56
3
0 0
186 1
309 0
2
0 154 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut57
3
0 0
186 1
311 0
2
0 156 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut58
3
0 0
186 1
313 0
2
0 158 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut59
3
0 0
186 1
315 0
2
0 160 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut6
3
0 0
186 1
317 0
2
0 162 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut60
3
0 0
186 1
319 0
2
0 164 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut61
3
0 0
186 1
321 0
2
0 166 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut62
3
0 0
186 1
323 0
2
0 168 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut63
3
0 0
186 1
325 0
2
0 170 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut7
3
0 0
186 1
327 0
2
0 172 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut8
3
0 0
186 1
329 0
2
0 174 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner96 bob nut9
3
0 0
186 1
331 0
2
0 176 0 1
0 375 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut1
3
0 0
187 1
207 0
2
0 52 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut10
3
0 0
187 1
209 0
2
0 54 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut11
3
0 0
187 1
211 0
2
0 56 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut12
3
0 0
187 1
213 0
2
0 58 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut13
3
0 0
187 1
215 0
2
0 60 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut14
3
0 0
187 1
217 0
2
0 62 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut15
3
0 0
187 1
219 0
2
0 64 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut16
3
0 0
187 1
221 0
2
0 66 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut17
3
0 0
187 1
223 0
2
0 68 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut18
3
0 0
187 1
225 0
2
0 70 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut19
3
0 0
187 1
227 0
2
0 72 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut2
3
0 0
187 1
229 0
2
0 74 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut20
3
0 0
187 1
231 0
2
0 76 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut21
3
0 0
187 1
233 0
2
0 78 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut22
3
0 0
187 1
235 0
2
0 80 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut23
3
0 0
187 1
237 0
2
0 82 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut24
3
0 0
187 1
239 0
2
0 84 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut25
3
0 0
187 1
241 0
2
0 86 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut26
3
0 0
187 1
243 0
2
0 88 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut27
3
0 0
187 1
245 0
2
0 90 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut28
3
0 0
187 1
247 0
2
0 92 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut29
3
0 0
187 1
249 0
2
0 94 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut3
3
0 0
187 1
251 0
2
0 96 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut30
3
0 0
187 1
253 0
2
0 98 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut31
3
0 0
187 1
255 0
2
0 100 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut32
3
0 0
187 1
257 0
2
0 102 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut33
3
0 0
187 1
259 0
2
0 104 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut34
3
0 0
187 1
261 0
2
0 106 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut35
3
0 0
187 1
263 0
2
0 108 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut36
3
0 0
187 1
265 0
2
0 110 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut37
3
0 0
187 1
267 0
2
0 112 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut38
3
0 0
187 1
269 0
2
0 114 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut39
3
0 0
187 1
271 0
2
0 116 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut4
3
0 0
187 1
273 0
2
0 118 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut40
3
0 0
187 1
275 0
2
0 120 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut41
3
0 0
187 1
277 0
2
0 122 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut42
3
0 0
187 1
279 0
2
0 124 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut43
3
0 0
187 1
281 0
2
0 126 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut44
3
0 0
187 1
283 0
2
0 128 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut45
3
0 0
187 1
285 0
2
0 130 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut46
3
0 0
187 1
287 0
2
0 132 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut47
3
0 0
187 1
289 0
2
0 134 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut48
3
0 0
187 1
291 0
2
0 136 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut49
3
0 0
187 1
293 0
2
0 138 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut5
3
0 0
187 1
295 0
2
0 140 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut50
3
0 0
187 1
297 0
2
0 142 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut51
3
0 0
187 1
299 0
2
0 144 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut52
3
0 0
187 1
301 0
2
0 146 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut53
3
0 0
187 1
303 0
2
0 148 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut54
3
0 0
187 1
305 0
2
0 150 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut55
3
0 0
187 1
307 0
2
0 152 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut56
3
0 0
187 1
309 0
2
0 154 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut57
3
0 0
187 1
311 0
2
0 156 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut58
3
0 0
187 1
313 0
2
0 158 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut59
3
0 0
187 1
315 0
2
0 160 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut6
3
0 0
187 1
317 0
2
0 162 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut60
3
0 0
187 1
319 0
2
0 164 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut61
3
0 0
187 1
321 0
2
0 166 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut62
3
0 0
187 1
323 0
2
0 168 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut63
3
0 0
187 1
325 0
2
0 170 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut7
3
0 0
187 1
327 0
2
0 172 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut8
3
0 0
187 1
329 0
2
0 174 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner97 bob nut9
3
0 0
187 1
331 0
2
0 176 0 1
0 376 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut1
3
0 0
188 1
207 0
2
0 52 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut10
3
0 0
188 1
209 0
2
0 54 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut11
3
0 0
188 1
211 0
2
0 56 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut12
3
0 0
188 1
213 0
2
0 58 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut13
3
0 0
188 1
215 0
2
0 60 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut14
3
0 0
188 1
217 0
2
0 62 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut15
3
0 0
188 1
219 0
2
0 64 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut16
3
0 0
188 1
221 0
2
0 66 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut17
3
0 0
188 1
223 0
2
0 68 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut18
3
0 0
188 1
225 0
2
0 70 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut19
3
0 0
188 1
227 0
2
0 72 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut2
3
0 0
188 1
229 0
2
0 74 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut20
3
0 0
188 1
231 0
2
0 76 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut21
3
0 0
188 1
233 0
2
0 78 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut22
3
0 0
188 1
235 0
2
0 80 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut23
3
0 0
188 1
237 0
2
0 82 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut24
3
0 0
188 1
239 0
2
0 84 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut25
3
0 0
188 1
241 0
2
0 86 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut26
3
0 0
188 1
243 0
2
0 88 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut27
3
0 0
188 1
245 0
2
0 90 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut28
3
0 0
188 1
247 0
2
0 92 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut29
3
0 0
188 1
249 0
2
0 94 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut3
3
0 0
188 1
251 0
2
0 96 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut30
3
0 0
188 1
253 0
2
0 98 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut31
3
0 0
188 1
255 0
2
0 100 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut32
3
0 0
188 1
257 0
2
0 102 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut33
3
0 0
188 1
259 0
2
0 104 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut34
3
0 0
188 1
261 0
2
0 106 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut35
3
0 0
188 1
263 0
2
0 108 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut36
3
0 0
188 1
265 0
2
0 110 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut37
3
0 0
188 1
267 0
2
0 112 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut38
3
0 0
188 1
269 0
2
0 114 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut39
3
0 0
188 1
271 0
2
0 116 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut4
3
0 0
188 1
273 0
2
0 118 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut40
3
0 0
188 1
275 0
2
0 120 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut41
3
0 0
188 1
277 0
2
0 122 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut42
3
0 0
188 1
279 0
2
0 124 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut43
3
0 0
188 1
281 0
2
0 126 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut44
3
0 0
188 1
283 0
2
0 128 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut45
3
0 0
188 1
285 0
2
0 130 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut46
3
0 0
188 1
287 0
2
0 132 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut47
3
0 0
188 1
289 0
2
0 134 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut48
3
0 0
188 1
291 0
2
0 136 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut49
3
0 0
188 1
293 0
2
0 138 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut5
3
0 0
188 1
295 0
2
0 140 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut50
3
0 0
188 1
297 0
2
0 142 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut51
3
0 0
188 1
299 0
2
0 144 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut52
3
0 0
188 1
301 0
2
0 146 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut53
3
0 0
188 1
303 0
2
0 148 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut54
3
0 0
188 1
305 0
2
0 150 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut55
3
0 0
188 1
307 0
2
0 152 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut56
3
0 0
188 1
309 0
2
0 154 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut57
3
0 0
188 1
311 0
2
0 156 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut58
3
0 0
188 1
313 0
2
0 158 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut59
3
0 0
188 1
315 0
2
0 160 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut6
3
0 0
188 1
317 0
2
0 162 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut60
3
0 0
188 1
319 0
2
0 164 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut61
3
0 0
188 1
321 0
2
0 166 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut62
3
0 0
188 1
323 0
2
0 168 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut63
3
0 0
188 1
325 0
2
0 170 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut7
3
0 0
188 1
327 0
2
0 172 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut8
3
0 0
188 1
329 0
2
0 174 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner98 bob nut9
3
0 0
188 1
331 0
2
0 176 0 1
0 377 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut1
3
0 0
189 1
207 0
2
0 52 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut10
3
0 0
189 1
209 0
2
0 54 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut11
3
0 0
189 1
211 0
2
0 56 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut12
3
0 0
189 1
213 0
2
0 58 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut13
3
0 0
189 1
215 0
2
0 60 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut14
3
0 0
189 1
217 0
2
0 62 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut15
3
0 0
189 1
219 0
2
0 64 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut16
3
0 0
189 1
221 0
2
0 66 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut17
3
0 0
189 1
223 0
2
0 68 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut18
3
0 0
189 1
225 0
2
0 70 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut19
3
0 0
189 1
227 0
2
0 72 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut2
3
0 0
189 1
229 0
2
0 74 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut20
3
0 0
189 1
231 0
2
0 76 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut21
3
0 0
189 1
233 0
2
0 78 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut22
3
0 0
189 1
235 0
2
0 80 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut23
3
0 0
189 1
237 0
2
0 82 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut24
3
0 0
189 1
239 0
2
0 84 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut25
3
0 0
189 1
241 0
2
0 86 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut26
3
0 0
189 1
243 0
2
0 88 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut27
3
0 0
189 1
245 0
2
0 90 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut28
3
0 0
189 1
247 0
2
0 92 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut29
3
0 0
189 1
249 0
2
0 94 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut3
3
0 0
189 1
251 0
2
0 96 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut30
3
0 0
189 1
253 0
2
0 98 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut31
3
0 0
189 1
255 0
2
0 100 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut32
3
0 0
189 1
257 0
2
0 102 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut33
3
0 0
189 1
259 0
2
0 104 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut34
3
0 0
189 1
261 0
2
0 106 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut35
3
0 0
189 1
263 0
2
0 108 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut36
3
0 0
189 1
265 0
2
0 110 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut37
3
0 0
189 1
267 0
2
0 112 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut38
3
0 0
189 1
269 0
2
0 114 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut39
3
0 0
189 1
271 0
2
0 116 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut4
3
0 0
189 1
273 0
2
0 118 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut40
3
0 0
189 1
275 0
2
0 120 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut41
3
0 0
189 1
277 0
2
0 122 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut42
3
0 0
189 1
279 0
2
0 124 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut43
3
0 0
189 1
281 0
2
0 126 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut44
3
0 0
189 1
283 0
2
0 128 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut45
3
0 0
189 1
285 0
2
0 130 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut46
3
0 0
189 1
287 0
2
0 132 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut47
3
0 0
189 1
289 0
2
0 134 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut48
3
0 0
189 1
291 0
2
0 136 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut49
3
0 0
189 1
293 0
2
0 138 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut5
3
0 0
189 1
295 0
2
0 140 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut50
3
0 0
189 1
297 0
2
0 142 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut51
3
0 0
189 1
299 0
2
0 144 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut52
3
0 0
189 1
301 0
2
0 146 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut53
3
0 0
189 1
303 0
2
0 148 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut54
3
0 0
189 1
305 0
2
0 150 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut55
3
0 0
189 1
307 0
2
0 152 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut56
3
0 0
189 1
309 0
2
0 154 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut57
3
0 0
189 1
311 0
2
0 156 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut58
3
0 0
189 1
313 0
2
0 158 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut59
3
0 0
189 1
315 0
2
0 160 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut6
3
0 0
189 1
317 0
2
0 162 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut60
3
0 0
189 1
319 0
2
0 164 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut61
3
0 0
189 1
321 0
2
0 166 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut62
3
0 0
189 1
323 0
2
0 168 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut63
3
0 0
189 1
325 0
2
0 170 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut7
3
0 0
189 1
327 0
2
0 172 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut8
3
0 0
189 1
329 0
2
0 174 0 1
0 378 0 1
1
end_operator
begin_operator
tighten_nut gate spanner99 bob nut9
3
0 0
189 1
331 0
2
0 176 0 1
0 378 0 1
1
end_operator
begin_operator
walk location1 location2 bob
1
379 0
1
0 0 1 12
1
end_operator
begin_operator
walk location10 location11 bob
1
380 0
1
0 0 2 3
1
end_operator
begin_operator
walk location11 location12 bob
1
381 0
1
0 0 3 4
1
end_operator
begin_operator
walk location12 location13 bob
1
382 0
1
0 0 4 5
1
end_operator
begin_operator
walk location13 location14 bob
1
383 0
1
0 0 5 6
1
end_operator
begin_operator
walk location14 location15 bob
1
384 0
1
0 0 6 7
1
end_operator
begin_operator
walk location15 location16 bob
1
385 0
1
0 0 7 8
1
end_operator
begin_operator
walk location16 location17 bob
1
386 0
1
0 0 8 9
1
end_operator
begin_operator
walk location17 location18 bob
1
387 0
1
0 0 9 10
1
end_operator
begin_operator
walk location18 location19 bob
1
388 0
1
0 0 10 11
1
end_operator
begin_operator
walk location19 location20 bob
1
389 0
1
0 0 11 13
1
end_operator
begin_operator
walk location2 location3 bob
1
390 0
1
0 0 12 23
1
end_operator
begin_operator
walk location20 location21 bob
1
391 0
1
0 0 13 14
1
end_operator
begin_operator
walk location21 location22 bob
1
392 0
1
0 0 14 15
1
end_operator
begin_operator
walk location22 location23 bob
1
393 0
1
0 0 15 16
1
end_operator
begin_operator
walk location23 location24 bob
1
394 0
1
0 0 16 17
1
end_operator
begin_operator
walk location24 location25 bob
1
395 0
1
0 0 17 18
1
end_operator
begin_operator
walk location25 location26 bob
1
396 0
1
0 0 18 19
1
end_operator
begin_operator
walk location26 location27 bob
1
397 0
1
0 0 19 20
1
end_operator
begin_operator
walk location27 location28 bob
1
398 0
1
0 0 20 21
1
end_operator
begin_operator
walk location28 location29 bob
1
399 0
1
0 0 21 22
1
end_operator
begin_operator
walk location29 location30 bob
1
400 0
1
0 0 22 24
1
end_operator
begin_operator
walk location3 location4 bob
1
401 0
1
0 0 23 34
1
end_operator
begin_operator
walk location30 location31 bob
1
402 0
1
0 0 24 25
1
end_operator
begin_operator
walk location31 location32 bob
1
403 0
1
0 0 25 26
1
end_operator
begin_operator
walk location32 location33 bob
1
404 0
1
0 0 26 27
1
end_operator
begin_operator
walk location33 location34 bob
1
405 0
1
0 0 27 28
1
end_operator
begin_operator
walk location34 location35 bob
1
406 0
1
0 0 28 29
1
end_operator
begin_operator
walk location35 location36 bob
1
407 0
1
0 0 29 30
1
end_operator
begin_operator
walk location36 location37 bob
1
408 0
1
0 0 30 31
1
end_operator
begin_operator
walk location37 location38 bob
1
409 0
1
0 0 31 32
1
end_operator
begin_operator
walk location38 location39 bob
1
410 0
1
0 0 32 33
1
end_operator
begin_operator
walk location39 location40 bob
1
411 0
1
0 0 33 35
1
end_operator
begin_operator
walk location4 location5 bob
1
412 0
1
0 0 34 45
1
end_operator
begin_operator
walk location40 location41 bob
1
413 0
1
0 0 35 36
1
end_operator
begin_operator
walk location41 location42 bob
1
414 0
1
0 0 36 37
1
end_operator
begin_operator
walk location42 location43 bob
1
415 0
1
0 0 37 38
1
end_operator
begin_operator
walk location43 location44 bob
1
416 0
1
0 0 38 39
1
end_operator
begin_operator
walk location44 location45 bob
1
417 0
1
0 0 39 40
1
end_operator
begin_operator
walk location45 location46 bob
1
418 0
1
0 0 40 41
1
end_operator
begin_operator
walk location46 location47 bob
1
419 0
1
0 0 41 42
1
end_operator
begin_operator
walk location47 location48 bob
1
420 0
1
0 0 42 43
1
end_operator
begin_operator
walk location48 location49 bob
1
421 0
1
0 0 43 44
1
end_operator
begin_operator
walk location49 location50 bob
1
422 0
1
0 0 44 46
1
end_operator
begin_operator
walk location5 location6 bob
1
423 0
1
0 0 45 50
1
end_operator
begin_operator
walk location50 location51 bob
1
424 0
1
0 0 46 47
1
end_operator
begin_operator
walk location51 location52 bob
1
425 0
1
0 0 47 48
1
end_operator
begin_operator
walk location52 location53 bob
1
426 0
1
0 0 48 49
1
end_operator
begin_operator
walk location53 gate bob
1
427 0
1
0 0 49 0
1
end_operator
begin_operator
walk location6 location7 bob
1
428 0
1
0 0 50 51
1
end_operator
begin_operator
walk location7 location8 bob
1
429 0
1
0 0 51 52
1
end_operator
begin_operator
walk location8 location9 bob
1
430 0
1
0 0 52 53
1
end_operator
begin_operator
walk location9 location10 bob
1
431 0
1
0 0 53 2
1
end_operator
begin_operator
walk shed location1 bob
1
432 0
1
0 0 54 1
1
end_operator
0
